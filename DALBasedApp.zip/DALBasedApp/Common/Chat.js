var windowFocus = true;
var toLoginSNo;
var chatHeartBeatCount = 0;
var onlineChatWindowHeartBeatCount = 0;
var minChatHeartBeat = 1000;
var maxChatHeartBeat = 33000;
var chatHeartBeatTime = minChatHeartBeat;
//Online chat window heart beat times...
var minOnlineChatMainWindowHeartBeat = 1000;
var maxOnlineChatMainWindowHeartBeat = 33000;
var onlineChatWindowHeartBeatTime = minOnlineChatMainWindowHeartBeat;
var originalTitle;
var blinkOrder = 0;

var chatBoxFocus = new Array();
var newMessages = new Array();
var newMessagesWin = new Array();
var chatBoxes = new Array();
var initialPaddingRight = 200;

//Signifies the status of the user... 0 - Offline, 1 - Online...
var chatStatus = 'False';

$(document).ready(function() {
    //Create the chat window which will load the online users...
    originalTitle = document.title;

    //Setting the chat status and other things before starting the chat...
    //StartChatSession();

    $([window, document]).blur(function() {
        windowFocus = false;
    }).focus(function() {
        windowFocus = true;
        document.title = originalTitle;
    });


    //Set the toggle effect go online or offline...
    $('#divChatStatus').click(function() {
        //Toggle the chat status...
        ToggleChatStatus(chatStatus);
    });

    //Set the toggle effect to the main online user chat window...
    $('#divOnlineChatWindowMinimizedButton').click(function() {
        if (chatStatus != 'False')
            if ($('#divOnlineChatMainWindow').css('display') == 'none') {
            $('#divOnlineChatMainWindow').css('display', 'block');
            $('#divOnlineChatWindowMinimizedButton').removeClass('maximizeButtonEffect');
            $('#divOnlineChatWindowMinimizedButton').addClass('minimizeButtonEffect');
        }
        else {
            $('#divOnlineChatMainWindow').css('display', 'none');
            $('#divOnlineChatWindowMinimizedButton').removeClass('minimizeButtonEffect');
            $('#divOnlineChatWindowMinimizedButton').addClass('maximizeButtonEffect');
        }
    });
});

//Method to toggle the chat status.
function ToggleChatStatus(chatStatus) {
    chatStatus = chatStatus == 'True' ? false : true;
    $.ajax({
        url: "Services/Chat.ashx?MethodName=ToggleChatStatus&ChatStatus=" + chatStatus,
        cache: false,
        dataType: "json",
        success: function(data) {
            chatStatus = data.chatStatus;
            InitializeChatStatus(chatStatus);
        }
    }
    );
}

//Method to initialize the chat window and similar things on the conditional change of the chatStatus.
function InitializeChatStatus(chatStatus) {
    this.chatStatus = chatStatus;
    if (chatStatus == 'False')//if the user is offline now
    {
        $('#divOnlineChatMainWindow').css('display', 'none');
        $('#divOnlineChatWindowMinimizedButton').css('display', 'none');
        $('.chatMinimized').css('background', 'transparent url(Images/CfiStatusBar.png) no-repeat scroll -647px -99px');
    }
    else {
        $('#divOnlineChatMainWindow').css('display', 'block');
        $('#divOnlineChatWindowMinimizedButton').css('display', 'block');
        $('#divOnlineChatWindowMinimizedButton').removeClass('maximizeButtonEffect');
        $('#divOnlineChatWindowMinimizedButton').addClass('minimizeButtonEffect');
        $('.chatMinimized').css('background', 'transparent url(Images/CfiStatusBar.png) no-repeat scroll -631px -99px');
        OnlineChatMainWindowData();
        ChatHeartBeat();
    }
}

function RestructureChatBoxes() {
    align = 0;
    for (x in chatBoxes) {
        toLoginSNo = chatBoxes[x];

        if ($("#divCfiChatBox" + toLoginSNo).css('display') != 'none') {
            if (align == 0) {
                $("#divCfiChatBox" + toLoginSNo).css('right', initialPaddingRight + 'px');
            } else {
                width = (align) * (225 + 7) + initialPaddingRight;
                $("#divCfiChatBox" + toLoginSNo).css('right', width + 'px');
            }
            align++;
        }
    }
}

function ChatWith(toLoginSNo, toLoginName, fromLoginSNo, fromLoginName) {
    CreateChatBox(toLoginSNo, toLoginName, fromLoginSNo, fromLoginName);
    $("#divCfiChatBox" + toLoginSNo + " .chatboxtextarea").focus();
}

function CreateChatBox(toLoginSNo, toLoginName, fromLoginSNo, fromLoginName, minimizeChatBox) {
    if ($("#divCfiChatBox" + toLoginSNo).length > 0) {
        if ($("#divCfiChatBox" + toLoginSNo).css('display') == 'none') {
            $("#divCfiChatBox" + toLoginSNo).css('display', 'block');
            RestructureChatBoxes();
        }
        $("#divCfiChatBox" + toLoginSNo + " .chatboxtextarea").focus();
        return;
    }

    $(" <div />").attr("id", "divCfiChatBox" + toLoginSNo)
	.addClass("chatbox")
	.html(
	'<div class="chatboxhead">' +
	    '<div class="chatboxtitle">' + toLoginName + '</div>' +
	    '<div class="chatboxoptions">' +
	        '<a href="javascript:void(0)" onclick="javascript:ToggleChatBoxGrowth(\'' + toLoginSNo + '\')"><div id=\'divChatBoxHeader' + toLoginSNo + '\' class=\'minimizeButtonEffect\' style=\'right:23px;\'></div></a>' +
	        '&nbsp;&nbsp;' +
	        '<a href="javascript:void(0)" onclick="javascript:CloseChatBox(\'' + toLoginSNo + '\')"><image src=\'Images/CloseButton.gif\' border=\'0\'  style=\'position:absolute; top:5px; right:5px;\'/></a>' +
	    '</div>' +
	    '<br clear="all"/>' +
    '</div>' +
    '<div class="chatboxcontent"></div>' +
    '<div class="chatboxinput">' +
    '<textarea class="chatboxtextarea" onkeydown="javascript:return CheckChatBoxInputKey(event,this,\'' + toLoginSNo + '\',\'' + toLoginName + '\',\'' + fromLoginSNo + '\',\'' + fromLoginName + '\');"></textarea>' +
    '</div>'
    )
	.appendTo($("body"));

    $("#divCfiChatBox" + toLoginSNo).css('bottom', '0px');
    $("#divCfiChatBox" + toLoginSNo).css('z-index', '9999');

    chatBoxeslength = 0;

    for (x in chatBoxes) {
        if ($("#divCfiChatBox" + chatBoxes[x]).css('display') != 'none') {
            chatBoxeslength++;
        }
    }

    if (chatBoxeslength == 0) {
        $("#divCfiChatBox" + toLoginSNo).css('right', initialPaddingRight + 'px');
    } else {
        width = (chatBoxeslength) * (225 + 7) + initialPaddingRight;
        $("#divCfiChatBox" + toLoginSNo).css('right', width + 'px');
    }
    chatBoxes.push(toLoginSNo);

    if (minimizeChatBox == 1) {
        minimizedChatBoxes = new Array();

        if ($.cookie('chatbox_minimized')) {
            minimizedChatBoxes = $.cookie('chatbox_minimized').split(/\|/);
        }
        minimize = 0;
        for (j = 0; j < minimizedChatBoxes.length; j++) {
            if (minimizedChatBoxes[j] == toLoginSNo) {
                minimize = 1;
            }
        }

        if (minimize == 1) {
            $('#divCfiChatBox' + toLoginSNo + ' .chatboxcontent').css('display', 'none');
            $('#divCfiChatBox' + toLoginSNo + ' .chatboxinput').css('display', 'none');
        }
    }

    chatBoxFocus[toLoginSNo] = false;

    $("#divCfiChatBox" + toLoginSNo + " .chatboxtextarea").blur(function() {
        chatBoxFocus[toLoginSNo] = false;
        $("#divCfiChatBox" + toLoginSNo + " .chatboxtextarea").removeClass('chatboxtextareaselected');
    }).focus(function() {
        chatBoxFocus[toLoginSNo] = true;
        newMessages[toLoginSNo] = false;
        $('#divCfiChatBox' + toLoginSNo + ' .chatboxhead').removeClass('chatboxblink');
        $("#divCfiChatBox" + toLoginSNo + " .chatboxtextarea").addClass('chatboxtextareaselected');
    });

    $("#divCfiChatBox" + toLoginSNo).click(function() {
        if ($('#divCfiChatBox' + toLoginSNo + ' .chatboxcontent').css('display') != 'none') {
            $("#divCfiChatBox" + toLoginSNo + " .chatboxtextarea").focus();
        }
    });

    $("#divCfiChatBox" + toLoginSNo).show();
}


function ChatHeartBeat() {

    var itemsfound = 0;

    if (windowFocus == false) {

        var blinkNumber = 0;
        var titleChanged = 0;
        for (x in newMessagesWin) {
            if (newMessagesWin[x] == true) {
                ++blinkNumber;
                if (blinkNumber >= blinkOrder) {
                    document.title = x + ' says...';
                    titleChanged = 1;
                    break;
                }
            }
        }

        if (titleChanged == 0) {
            document.title = originalTitle;
            blinkOrder = 0;
        } else {
            ++blinkOrder;
        }

    } else {
        for (x in newMessagesWin) {
            newMessagesWin[x] = false;
        }
    }

    for (x in newMessages) {
        if (newMessages[x] == true) {
            if (chatBoxFocus[x] == false) {
                //FIXME: add toggle all or none policy, otherwise it looks funny
                $('#divCfiChatBox' + x + ' .chatboxhead').toggleClass('chatboxblink');
            }
        }
    }

    $.ajax({
        url: "Services/Chat.ashx?MethodName=ChatHeartBeat",
        cache: false,
        dataType: "json",
        success: function(data) {
            if (data != null) {
                $.each(data.items, function(i, item) {
                    if (item) { // fix strange ie bug

                        toLoginSNo = item.fromLoginSNo;
                        toLoginName = item.fromLoginName;
                        fromLoginSNo = item.toLoginSNo;
                        fromLoginName = item.toLoginName;

                        if ($("#divCfiChatBox" + fromLoginSNo).length <= 0) {
                            CreateChatBox(toLoginSNo, toLoginName, fromLoginSNo, fromLoginName);
                        }
                        if ($("#divCfiChatBox" + toLoginSNo).css('display') == 'none') {
                            $("#divCfiChatBox" + toLoginSNo).css('display', 'block');
                            RestructureChatBoxes();
                        }
                        newMessages[toLoginSNo] = true;
                        newMessagesWin[toLoginSNo] = true;
                        message = item.message.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;");
                        $("#divCfiChatBox" + toLoginSNo + " .chatboxcontent").append('<div class="chatboxmessage"><span class="chatboxmessagefrom">' + toLoginName + ':&nbsp;&nbsp;</span><span class="chatboxmessagecontent">' + message + '</span></div>');
                        $("#divCfiChatBox" + toLoginSNo + " .chatboxcontent").scrollTop($("#divCfiChatBox" + toLoginSNo + " .chatboxcontent")[0].scrollHeight);
                        itemsfound += 1;
                    }
                });
            }
            chatHeartBeatCount++;

            if (itemsfound > 0) {
                chatHeartBeatTime = minChatHeartBeat;
                chatHeartBeatCount = 1;
            } else if (chatHeartBeatCount >= 10) {
                chatHeartBeatTime *= 2;
                chatHeartBeatCount = 1;
                if (chatHeartBeatTime > maxChatHeartBeat) {
                    chatHeartBeatTime = maxChatHeartBeat;
                }
            }
            if (chatStatus == 'True')
                setTimeout('ChatHeartBeat();', chatHeartBeatTime);
        }
    });
}

function CloseChatBox(toLoginSNo) {
    $('#divCfiChatBox' + toLoginSNo).css('display', 'none');
    RestructureChatBoxes();
}

function ToggleChatBoxGrowth(toLoginSNo) {
    if ($('#divCfiChatBox' + toLoginSNo + ' .chatboxcontent').css('display') == 'none') {
        var minimizedChatBoxes = new Array();
        if ($.cookie('chatbox_minimized'))
            minimizedChatBoxes = $.cookie('chatbox_minimized').split(/\|/);
        var newCookie = '';
        for (i = 0; i < minimizedChatBoxes.length; i++)
            if (minimizedChatBoxes[i] != toLoginSNo)
            newCookie += toLoginSNo + '|';
        newCookie = newCookie.slice(0, -1)
        $.cookie('chatbox_minimized', newCookie);
        $('#divCfiChatBox' + toLoginSNo + ' .chatboxcontent').css('display', 'block');
        $('#divCfiChatBox' + toLoginSNo + ' .chatboxinput').css('display', 'block');
        $("#divCfiChatBox" + toLoginSNo + " .chatboxcontent").scrollTop($("#divCfiChatBox" + toLoginSNo + " .chatboxcontent")[0].scrollHeight);
        $('#divChatBoxHeader' + toLoginSNo).addClass('minimizeButtonEffect');
        $('#divChatBoxHeader' + toLoginSNo).removeClass('maximizeButtonEffect');
    } else {
        var newCookie = toLoginSNo;
        if ($.cookie('chatbox_minimized'))
            newCookie += '|' + $.cookie('chatbox_minimized');
        $.cookie('chatbox_minimized', newCookie);
        $('#divCfiChatBox' + toLoginSNo + ' .chatboxcontent').css('display', 'none');
        $('#divCfiChatBox' + toLoginSNo + ' .chatboxinput').css('display', 'none');
        $('#divChatBoxHeader' + toLoginSNo).addClass('maximizeButtonEffect');
        $('#divChatBoxHeader' + toLoginSNo).removeClass('minimizeButtonEffect');
    }
}

function CheckChatBoxInputKey(event, chatboxtextarea, toLoginSNo, toLoginName, fromLoginSNo, fromLoginName) {

    if (event.keyCode == 13 && event.shiftKey == 0) {
        message = $(chatboxtextarea).val();
        message = message.replace(/^\s+|\s+$/g, "");

        $(chatboxtextarea).val('');
        $(chatboxtextarea).focus();
        $(chatboxtextarea).css('height', '44px');
        if (message != '') {
            $.post("Services/Chat.ashx?MethodName=SendMessage", { ToLoginSNo: toLoginSNo, ToLoginName: toLoginName, FromLoginSNo: fromLoginSNo, FromLoginName: fromLoginName, message: message }, function(data) {
                message = message.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;");
                $("#divCfiChatBox" + toLoginSNo + " .chatboxcontent").append('<div class="chatboxmessage"><span class="chatboxmessagefrom">' + fromLoginName + ':&nbsp;&nbsp;</span><span class="chatboxmessagecontent">' + message + '</span></div>');
                $("#divCfiChatBox" + toLoginSNo + " .chatboxcontent").scrollTop($("#divCfiChatBox" + toLoginSNo + " .chatboxcontent")[0].scrollHeight);
            });
        }
        chatHeartBeatTime = minChatHeartBeat;
        chatHeartBeatCount = 1;

        return false;
    }

    var adjustedHeight = chatboxtextarea.clientHeight;
    var maxHeight = 94;

    if (maxHeight > adjustedHeight) {
        adjustedHeight = Math.max(chatboxtextarea.scrollHeight, adjustedHeight);
        if (maxHeight)
            adjustedHeight = Math.min(maxHeight, adjustedHeight);
        if (adjustedHeight > chatboxtextarea.clientHeight)
            $(chatboxtextarea).css('height', adjustedHeight + 8 + 'px');
    } else {
        $(chatboxtextarea).css('overflow', 'auto');
    }

}

function StartChatSession() {
    $.ajax({
        url: "Services/Chat.ashx?MethodName=StartChatSession",
        cache: false,
        dataType: "json",
        success: function(data) {
            chatStatus = data.chatStatus;
            InitializeChatStatus(chatStatus);
        }
    });
}

//Sudhir Yadav: 01 Feb 2010. Method to get the list of currently logged in users and creation of the main online chat window.
function OnlineChatMainWindowData() {
    var onlineUsersHtml = '';
    $.ajax({
        url: "Services/Chat.ashx?MethodName=OnlineChatMainWindowHeartBeat",
        cache: false,
        dataType: "json",
        success: function(data) {
            $.each(data.items, function(i, item) {
                if (item) { // fix strange ie bug
                    toLoginSNo = item.loginSNo;
                    toLoginName = item.loginName;
                    loginTypeSNo = item.loginTypeSNo;
                    loginTypeName = item.loginTypeName;
                    fromLoginSNo = item.fromLoginSNo;
                    fromLoginName = item.fromLoginName;
                    onlineUsersHtml += '<div ><a href="javascript: void(0);" onclick="ChatWith(\'' + toLoginSNo + '\',\'' + toLoginName + '\',\'' + fromLoginSNo + '\',\'' + fromLoginName + '\');">' + toLoginName + '</a></div></br>'
                }
            });
            $('#divOnlineChatUsers').html('');
            $(" <div />").attr("id", "divOnlineChatMainWindowUsers").addClass("chatboxusers")
    .html('<div class="onlineUsers">' + onlineUsersHtml + '</div>')
    .appendTo($('#divOnlineChatUsers'));
            $('#divOnlineChatMainWindowUsers').show();

            if (chatStatus == 'True')
                setTimeout('OnlineChatMainWindowData();', onlineChatWindowHeartBeatTime);
        }
    });
}

/**
* Cookie plugin
*
* Copyright (c) 2006 Klaus Hartl (stilbuero.de)
* Dual licensed under the MIT and GPL licenses:
* http://www.opensource.org/licenses/mit-license.php
* http://www.gnu.org/licenses/gpl.html
*
*/

jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        // CAUTION: Needed to parenthesize options.path and options.domain
        // in the following expressions, otherwise they evaluate to undefined
        // in the packed version for some reason...
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};