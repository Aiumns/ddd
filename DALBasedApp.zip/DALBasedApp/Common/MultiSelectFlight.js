﻿

function AddFlight() {

    var flights = document.getElementById(hdnFlight).value;
    var innerHTML = document.getElementById(txtFlightNo).value;
    //alert('yes');
    var flag = "0";
    //if (innerHTML.length >0) 
    {
        var checkExisting = new Array();
        checkExisting = document.getElementById(hdnFlight).value.split('—');
        for (var i = 0; i < checkExisting.length; i++) {

            if (innerHTML != "") {
                if (checkExisting[i] == innerHTML.toUpperCase()) {
                    flag = "1";
                    //jAlert(innerHTML+' Already Exists!');
                    return false;
                }
            }
        }

        if (flag == "0")
            document.getElementById(hdnAddFlight).value += innerHTML;
        if (innerHTML.length > 0)
            document.getElementById(hdnFlight).value += innerHTML + "—";
        document.getElementById(txtFlightNo).value = "";
        var flights = new Array();
        document.getElementById(hdnFlight).value = document.getElementById(hdnFlight).value.toUpperCase();
        document.getElementById(hdnStringFlight).value = "";
        flights = document.getElementById(hdnFlight).value.split('—');
        var innerHTML = '';
        if (flights.length > 1) {
            var controls = "";
            for (var i = 0; i < flights.length - 1; i++) {
                var flight = flights[i];
                var close = "<img  src='../../Images/CloseButton.gif' style='vertical-align=bottom' alt='Close' onclick='Deleteflight(this.id);' id='img" + flight + "' />";
                innerHTML = innerHTML + "<td  style='vertical-align=top' id=td" + flight + " ><span  style='vertical-align=top' id=lbl" + flight + " >" + flight + "&nbsp;" + close + " — </span> </td>";
            }

        }
        var openHTML = "<table style='vertical-align=top' ><tr>";
        var closeHTML = "</tr></table>";
        document.getElementById(hdnStringFlight).value = openHTML + innerHTML + closeHTML;
        var trimchar = document.getElementById(hdnStringFlight).value;
        document.getElementById(hdnStringFlight).value = trimchar.substring(0, trimchar.lastIndexOf('—'))
        document.getElementById(lblAddFlight).innerHTML = document.getElementById(hdnStringFlight).value;
        document.getElementById(hdnStringFlight).value = "";
        // document.getElementById(txtCityCode).focus();
    }

}


function Deleteflight(idClose) {
    var closeflight = idClose.substring(3, idClose.length);
    var existingcities = document.getElementById(hdnFlight).value;
    document.getElementById(hdnFlight).value = existingcities.replace("—" + closeflight, "");
    document.getElementById(hdnAddFlight).value = "—";
    document.getElementById(hdnStringFlight).value = "";
    document.getElementById(idClose).parentNode.style.display = 'none';
    document.getElementById(hdnFlight).value = "";
}
