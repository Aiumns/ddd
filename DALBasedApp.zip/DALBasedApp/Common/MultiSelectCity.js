﻿//Method to add cities dynamically:By Dhiraj Kumar
function AddCities() {
    var cities = document.getElementById(hdnCities).value;
    var city = document.getElementById(txtCityCode).value;
    var flag = "0";
         var checkExisting = new Array();
        checkExisting = document.getElementById(hdnCities).value.split('-');
        for (var i = 0; i < checkExisting.length; i++) {
            if (city != "") {
                if (checkExisting[i] == city.toUpperCase()) {
                    flag = "1";
                    return false;
                }
            }
        }
        if (flag == "0")
            document.getElementById(hdnAddCities).value += city;
        if (city.length == 3)
            document.getElementById(hdnCities).value += city + "-";
        document.getElementById(txtCityCode).value = "";
        var cities = new Array();
        document.getElementById(hdnCities).value = document.getElementById(hdnCities).value.toUpperCase();
        document.getElementById(hdnString).value = "";
        cities = document.getElementById(hdnCities).value.split('-');
        var innerHTML = '';
        if (cities.length > 1) {
            var controls = "";
            for (var i = 0; i < cities.length - 1; i++) {
                var city = cities[i];
                var close = "<img  src='../../Images/CloseButton.gif' style='vertical-align=bottom' alt='Close' onclick='Deletecity(this.id);' id='img" + city + "' />";
                if (i == 0)
                    innerHTML = innerHTML + "<td  style='vertical-align=top' id=td" + city + " ><span  style='vertical-align=top' id=lbl" + city + " > " + city + "&nbsp;" + close + " </span> </td>";
                else
                    innerHTML = innerHTML + "<td  style='vertical-align=top' id=td" + city + " ><span  style='vertical-align=top' id=lbl" + city + " > - " + city + "&nbsp;" + close + " </span> </td>";
            }

        }
        var openHTML = "<table style='vertical-align=top' ><tr>";
        var closeHTML = "</tr></table>";
        document.getElementById(hdnString).value = openHTML + innerHTML + closeHTML;
        var trimchar = document.getElementById(hdnString).value;
        document.getElementById(lblADDCities).innerHTML = trimchar;
        document.getElementById(hdnString).value = "";
        if (city != "") {
            document.getElementById(txtCityCode).focus();
            document.getElementById(txtCityCode).select();
        }
        return true;
    
}

function Deletecity(idClose) {
    var closecity = idClose.substring(3, idClose.length);
    var existingCities = document.getElementById(hdnCities).value;
    document.getElementById(hdnCities).value = existingCities.replace(closecity + "-", "");
    document.getElementById(hdnAddCities).value = "-";
    document.getElementById(hdnString).value = "";
    document.getElementById(idClose).parentNode.style.display = 'none';
}

function ControlVisibility(targetid, isShown) {
    document.getElementById(targetid).style.display = isShown ? '' : 'none';
}

function ControlVisibility(targetid, isShown) {
    document.getElementById(targetid).style.display = isShown ? '' : 'none';
}

function CityByCountry() {
    /// TODO: Cache has to be flushed before another request comes.
    document.getElementById(hdnCities).value = "";
    document.getElementById(lblADDCities).innerHTML = "";
    var country = $("#" + txtCountryCode).val();
    var options;
    var autoCompleteForCountry = "";
    jQuery(
function() {
    options =
    {
        serviceUrl: '../Services/City.ashx?CountryCode=' + country, width: 200, onExtraFunction: AddCities

    };

    autoCompleteForCountry = $("#" + txtCityCode).autocomplete(options).clearCache();
});
}



