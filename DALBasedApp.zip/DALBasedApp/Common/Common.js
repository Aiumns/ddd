﻿/* Common Javascript Description.
* Company              :   CargoFlash Infotech	Pvt. Ltd.
* Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
* Purpose              :   This class takes care of the Default page and loading of the javascript and css on each page.
* Created By           :   Sudhir Yadav.
* Created On           :   29 Mar 2010.
* Modified By          :   Dhiraj Kumar
* Modified On          :   05 April 2010
* Description          :   Add Methods related to CrossList(In case of add new,update and Delete)
*/

// Added by Sudhir Yadav. Dt: 29 Mar 2010.
// Method to fill the drop down using json from another drop down...
// destinationDropdown: The dropdown that will be filled according to next param.
// entityName: The name of the table from which the drop down will be filled.
// valueColumn: The column that will go in the value column of the drop down.
// textColumn: The column which will be shown as the text in the destination drop down.
// whereCondition: The condition against which the destination drop down in the first param will be filled.
// firstValue: The first value that will be added in the starting or the end depending on the addAdditionalValueInStarting param. Keep null if not required.
// firstText: The first text that will be added in the starting or the end depending on the addAdditionalValueInStarting param. keep null if not required.
// addAdditionalValueInStarting: Weather to add the additional values in the end or in the starting.
function FillDropDownConditionally(destinationDropdownClientID, entityName, valueColumn, textColumn, whereCondition, firstValue, firstText, addAdditionalValueInStarting) {
    $("#" + destinationDropdownClientID).html("");
    $.ajax({
        url: '../Services/CustomValidation.ashx',
        cache: false,
        async: false,
        data: 'Entity=' + entityName + '&Columns=' + valueColumn + ' AS Value, ' + textColumn + ' AS Text&WhereCondition=' + whereCondition,
        success: function(data) {
            if (firstValue != null & firstText != null && addAdditionalValueInStarting)
                $("#" + destinationDropdownClientID).append($("<option></option>").val(firstValue).html(firstText));
            $.each(data.items, function(i, item) {
                if (item) {
                    $("#" + destinationDropdownClientID).append($("<option></option>").val(item.Value).html(item.Text));
                }
            });
        }
    });
}
