﻿using System;
using System.Data;
using System.Collections;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.Common;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;
using System.Data.SqlClient;
using System.Text;
using Cfi.App.Pace.Business;
using CfiAppCRMBusiness;

public partial class CRM_MasterPage : System.Web.UI.MasterPage
{

    protected void Page_Load(object sender, EventArgs e)
    {

        string[] pageNameArrary = Request.Url.ToString().Split('?');
        int getLastSlashIndex = pageNameArrary[0].LastIndexOf('/');

        string pageName = pageNameArrary[0].ToString().Substring(getLastSlashIndex + 1, (pageNameArrary[0].Length - getLastSlashIndex) - 1);
        string[] path = pageName.Split('/');
        //pageName = path[path.Length - 2] + "/" + path[path.Length - 1];
      
        using (ApplicationPage applicationPage = new ApplicationPage())
        {
            if (path[path.Length - 1] != "Navigation.aspx")
            {
                string breadCrumb = applicationPage.GetBreadCrumb(pageName, 0);

                if (pageName.Contains("MyAccount"))
                    breadCrumb = "My Account";

                if (pageName.Contains("Home"))
                    breadCrumb = "Home";
                //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "InsertBreadCrumb", " $(function(){$('#divbreadcrumb').html('" + breadCrumb + "');});", true);
                //string CompBrSNo=Session["CompBrSNo"].ToString();
            }
            else
            {
                string breadCrumb = applicationPage.GetBreadCrumb("", Convert.ToInt32(Request.QueryString["id"]));
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "InsertBreadCrumb", " $(function(){$('#divbreadcrumb').html('" + breadCrumb + "');});", true);
            }
        }

        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ChangeBreadCrumb", @"$(function(){
        $('#divbreadcrumb a').each(function(){
              var name=$(this).html();
              var convname = TranslateScript(name);
              $(this).html(convname);
        });
    });", true);
    }

    /// <summary>
    /// Get the user control for the message placed in the master page.
    /// </summary>
    public AppControls_Messages UserControlMessage
    {
        get { return ucMessages; }
    }
}