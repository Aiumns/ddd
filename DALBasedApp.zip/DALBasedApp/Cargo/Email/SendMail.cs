﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Text;
/// <summary>
/// Summary description for SendMail
/// </summary>
public class SendMail
{ 
	public SendMail()
	{
        MailMessage mail = new MailMessage();
        string userName = "asrivastava@cargoflash.com";//ConfigurationManager.AppSettings["MailuserName"];
        string password = "anand$567";//ConfigurationManager.AppSettings["Mailpassword"];
        string smtpHost = "mail.cargoflash.com";//ConfigurationManager.AppSettings["MailServer"];

        mail.Subject = "Hi";
        mail.SubjectEncoding = Encoding.UTF8;
        mail.BodyEncoding = Encoding.UTF8;
        mail.IsBodyHtml = true;
        mail.Priority = MailPriority.High;
        mail.To.Add(new MailAddress("anandvfan@gmail.com"));
        mail.From = new MailAddress(userName);
        //string[] Company = Session["CompName"].ToString().Split('-');
        mail.Body = "Hi Mail from Pace Power";
        mail.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient(smtpHost, 25);
        smtp.Credentials = new NetworkCredential(userName, password);
        smtp.Send(mail);
		//
		// TODO: Add constructor logic here
		//
	}
}