﻿// JScript File
function actbConsigneeName(obj,ca){
	/* ---- Public Variables ---- */
	this.actbConsigneeName_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbConsigneeName_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbConsigneeName_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbConsigneeName_mouse = true; // Enable Mouse Support
	this.actbConsigneeName_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbConsigneeName_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbConsigneeName_bgColor = '#F1F0F0';
	this.actbConsigneeName_textColor = '#D60000';
	this.actbConsigneeName_hColor = '#FFFFFF';
	this.actbConsigneeName_fFamily = 'Verdana';
	this.actbConsigneeName_fSize = '11px';
	this.actbConsigneeName_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbConsigneeName_delimwords = new Array();
	var actbConsigneeName_cdelimword = 0;
	var actbConsigneeName_delimchar = new Array();
	var actbConsigneeName_display = false;
	var actbConsigneeName_pos = 0;
	var actbConsigneeName_total = 0;
	var actbConsigneeName_curr = null;
	var actbConsigneeName_rangeu = 0;
	var actbConsigneeName_ranged = 0;
	var actbConsigneeName_bool = new Array();
	var actbConsigneeName_pre = 0;
	var actbConsigneeName_toid;
	var actbConsigneeName_tomake = false;
	var actbConsigneeName_getpre = "";
	var actbConsigneeName_mouse_on_list = 1;
	var actbConsigneeName_kwcount = 0;
	var actbConsigneeName_caretmove = false;
	this.actbConsigneeName_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbConsigneeName_keywords = ca;
	var actbConsigneeName_self = this;

	actbConsigneeName_curr = obj;
	
	addEvent(actbConsigneeName_curr,"focus",actbConsigneeName_setup);
	function actbConsigneeName_setup(){
		addEvent(document,"keydown",actbConsigneeName_checkkey);
		addEvent(actbConsigneeName_curr,"blur",actbConsigneeName_clear);
		addEvent(document,"keypress",actbConsigneeName_keypress);
	}

	function actbConsigneeName_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbConsigneeName_checkkey);
		removeEvent(actbConsigneeName_curr,"blur",actbConsigneeName_clear);
		removeEvent(document,"keypress",actbConsigneeName_keypress);
		actbConsigneeName_removedisp();
	}
	function actbConsigneeName_parse(n){
		if (actbConsigneeName_self.actbConsigneeName_delimiter.length > 0){
			var t = actbConsigneeName_delimwords[actbConsigneeName_cdelimword].addslashes();
			var plen = actbConsigneeName_delimwords[actbConsigneeName_cdelimword].length;
		}else{
			var t = actbConsigneeName_curr.value.addslashes();
			var plen = actbConsigneeName_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbConsigneeName_self.actbConsigneeName_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbConsigneeName_self.actbConsigneeName_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbConsigneeName_generate(){
		if (document.getElementById('tat_table')){ actbConsigneeName_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbConsigneeName_kwcount == 0){
			actbConsigneeName_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbConsigneeName_curr) + actbConsigneeName_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbConsigneeName_curr) + "px";
		a.style.backgroundColor=actbConsigneeName_self.actbConsigneeName_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbConsigneeName_self.actbConsigneeName_mouse){
			a.onmouseout = actbConsigneeName_table_unfocus;
			a.onmouseover = actbConsigneeName_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbConsigneeName_self.actbConsigneeName_keywords.length;i++){
			if (actbConsigneeName_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbConsigneeName_tomake){
					r.style.backgroundColor = actbConsigneeName_self.actbConsigneeName_hColor;
					first = false;
					actbConsigneeName_pos = counter;
				}else if(actbConsigneeName_pre == i){
					r.style.backgroundColor = actbConsigneeName_self.actbConsigneeName_hColor;
					first = false;
					actbConsigneeName_pos = counter;
				}else{
					r.style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbConsigneeName_self.actbConsigneeName_textColor;
				c.style.fontFamily = actbConsigneeName_self.actbConsigneeName_fFamily;
				c.style.fontSize = actbConsigneeName_self.actbConsigneeName_fSize;
				c.innerHTML = actbConsigneeName_parse(actbConsigneeName_self.actbConsigneeName_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbConsigneeName_self.actbConsigneeName_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbConsigneeName_mouseclick;
					c.onmouseover = actbConsigneeName_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbConsigneeName_self.actbConsigneeName_lim && j < actbConsigneeName_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbConsigneeName_self.actbConsigneeName_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbConsigneeName_self.actbConsigneeName_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbConsigneeName_self.actbConsigneeName_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbConsigneeName_mouse_down;
				}
				break;
			}
		}
		actbConsigneeName_rangeu = 1;
		actbConsigneeName_ranged = j-1;
		actbConsigneeName_display = true;
		if (actbConsigneeName_pos <= 0) actbConsigneeName_pos = 1;
	}
	function actbConsigneeName_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbConsigneeName_curr) + actbConsigneeName_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbConsigneeName_curr) + "px";
		a.style.backgroundColor=actbConsigneeName_self.actbConsigneeName_bgColor;
		a.id = 'tat_table';
		if (actbConsigneeName_self.actbConsigneeName_mouse){
			a.onmouseout= actbConsigneeName_table_unfocus;
			a.onmouseover=actbConsigneeName_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbConsigneeName_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbConsigneeName_self.actbConsigneeName_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbConsigneeName_self.actbConsigneeName_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbConsigneeName_self.actbConsigneeName_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbConsigneeName_mouse_up;
			}
		}
		for (i=0;i<actbConsigneeName_self.actbConsigneeName_keywords.length;i++){
			if (actbConsigneeName_bool[i]){
				if (j >= actbConsigneeName_rangeu && j <= actbConsigneeName_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbConsigneeName_self.actbConsigneeName_textColor;
					c.style.fontFamily = actbConsigneeName_self.actbConsigneeName_fFamily;
					c.style.fontSize = actbConsigneeName_self.actbConsigneeName_fSize;
					c.innerHTML = actbConsigneeName_parse(actbConsigneeName_self.actbConsigneeName_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbConsigneeName_self.actbConsigneeName_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbConsigneeName_mouseclick;
						c.onmouseover = actbConsigneeName_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbConsigneeName_ranged) break;
		}
		if (j-1 < actbConsigneeName_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbConsigneeName_self.actbConsigneeName_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbConsigneeName_self.actbConsigneeName_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbConsigneeName_self.actbConsigneeName_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbConsigneeName_mouse_down;
			}
		}
	}
	function actbConsigneeName_goup(){
		if (!actbConsigneeName_display) return;
		if (actbConsigneeName_pos == 1) return;
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
		actbConsigneeName_pos--;
		if (actbConsigneeName_pos < actbConsigneeName_rangeu) actbConsigneeName_moveup();
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_hColor;
		if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		if (actbConsigneeName_self.actbConsigneeName_timeOut > 0) actbConsigneeName_toid = setTimeout(function(){actbConsigneeName_mouse_on_list=0;actbConsigneeName_removedisp();},actbConsigneeName_self.actbConsigneeName_timeOut);
	}
	function actbConsigneeName_godown(){
		if (!actbConsigneeName_display) return;
		if (actbConsigneeName_pos == actbConsigneeName_total) return;
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
		actbConsigneeName_pos++;
		if (actbConsigneeName_pos > actbConsigneeName_ranged) actbConsigneeName_movedown();
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_hColor;
		if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		if (actbConsigneeName_self.actbConsigneeName_timeOut > 0) actbConsigneeName_toid = setTimeout(function(){actbConsigneeName_mouse_on_list=0;actbConsigneeName_removedisp();},actbConsigneeName_self.actbConsigneeName_timeOut);
	}
	function actbConsigneeName_movedown(){
		actbConsigneeName_rangeu++;
		actbConsigneeName_ranged++;
		actbConsigneeName_remake();
	}
	function actbConsigneeName_moveup(){
		actbConsigneeName_rangeu--;
		actbConsigneeName_ranged--;
		actbConsigneeName_remake();
	}

	/* Mouse */
	function actbConsigneeName_mouse_down(){
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
		actbConsigneeName_pos++;
		actbConsigneeName_movedown();
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_hColor;
		actbConsigneeName_curr.focus();
		actbConsigneeName_mouse_on_list = 0;
		if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		if (actbConsigneeName_self.actbConsigneeName_timeOut > 0) actbConsigneeName_toid = setTimeout(function(){actbConsigneeName_mouse_on_list=0;actbConsigneeName_removedisp();},actbConsigneeName_self.actbConsigneeName_timeOut);
	}
	function actbConsigneeName_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
		actbConsigneeName_pos--;
		actbConsigneeName_moveup();
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_hColor;
		actbConsigneeName_curr.focus();
		actbConsigneeName_mouse_on_list = 0;
		if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		if (actbConsigneeName_self.actbConsigneeName_timeOut > 0) actbConsigneeName_toid = setTimeout(function(){actbConsigneeName_mouse_on_list=0;actbConsigneeName_removedisp();},actbConsigneeName_self.actbConsigneeName_timeOut);
	}
	function actbConsigneeName_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbConsigneeName_display) return;
		actbConsigneeName_mouse_on_list = 0;
		actbConsigneeName_pos = this.getAttribute('pos');
		actbConsigneeName_penter();
	}
	function actbConsigneeName_table_focus(){
		actbConsigneeName_mouse_on_list = 1;
	}
	function actbConsigneeName_table_unfocus(){
		actbConsigneeName_mouse_on_list = 0;
		if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		if (actbConsigneeName_self.actbConsigneeName_timeOut > 0) actbConsigneeName_toid = setTimeout(function(){actbConsigneeName_mouse_on_list = 0;actbConsigneeName_removedisp();},actbConsigneeName_self.actbConsigneeName_timeOut);
	}
	function actbConsigneeName_table_highlight(){
		actbConsigneeName_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_bgColor;
		actbConsigneeName_pos = this.getAttribute('pos');
		while (actbConsigneeName_pos < actbConsigneeName_rangeu) actbConsigneeName_moveup();
		while (actbConsigneeName_pos > actbConsigneeName_ranged) actbConsigneeName_movedown();
		document.getElementById('tat_tr'+actbConsigneeName_pos).style.backgroundColor = actbConsigneeName_self.actbConsigneeName_hColor;
		if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		if (actbConsigneeName_self.actbConsigneeName_timeOut > 0) actbConsigneeName_toid = setTimeout(function(){actbConsigneeName_mouse_on_list = 0;actbConsigneeName_removedisp();},actbConsigneeName_self.actbConsigneeName_timeOut);
	}
	/* ---- */

	function actbConsigneeName_insertword(a){
		if (actbConsigneeName_self.actbConsigneeName_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbConsigneeName_delimwords.length;i++){
				if (actbConsigneeName_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbConsigneeName_delimwords[i].length;++j){
						if (actbConsigneeName_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbConsigneeName_delimwords[i].length-1;j>=0;--j){
						if (actbConsigneeName_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbConsigneeName_delimwords[i];
				}
				if (i != actbConsigneeName_delimwords.length - 1){
					str += actbConsigneeName_delimchar[i];
				}
			}
			actbConsigneeName_curr.value = str;
			setCaret(actbConsigneeName_curr,l);
		}else{
			actbConsigneeName_curr.value = a;
		}
		actbConsigneeName_mouse_on_list = 0;
		actbConsigneeName_removedisp();
	}
	function actbConsigneeName_penter(){
		if (!actbConsigneeName_display) return;
		actbConsigneeName_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbConsigneeName_self.actbConsigneeName_keywords.length;i++){
			if (actbConsigneeName_bool[i]) c++;
			if (c == actbConsigneeName_pos){
				word = actbConsigneeName_self.actbConsigneeName_keywords[i];
				break;
			}
		}
		actbConsigneeName_insertword(word);
		l = getCaretStart(actbConsigneeName_curr);
	}
	function actbConsigneeName_removedisp(){
		if (actbConsigneeName_mouse_on_list==0){
			actbConsigneeName_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		}
	}
	function actbConsigneeName_keypress(e){
		if (actbConsigneeName_caretmove) stopEvent(e);
		return !actbConsigneeName_caretmove;
	}
	function actbConsigneeName_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbConsigneeName_curr);
		actbConsigneeName_caretmove = 0;
		switch (a){
			case 38:
				actbConsigneeName_goup();
				actbConsigneeName_caretmove = 1;
				return false;
				break;
			case 40:
				actbConsigneeName_godown();
				actbConsigneeName_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbConsigneeName_display){
					actbConsigneeName_caretmove = 1;
					actbConsigneeName_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbConsigneeName_tocomplete(a)},50);
				break;
		}
	}

	function actbConsigneeName_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbConsigneeName_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbConsigneeName_self.actbConsigneeName_keywords.length;i++){
				if (actbConsigneeName_bool[i]) c++;
				if (c == actbConsigneeName_pos){
					word = i;
					break;
				}
			}
			actbConsigneeName_pre = word;
		}else{ actbConsigneeName_pre = -1};
		
		if (actbConsigneeName_curr.value == ''){
			actbConsigneeName_mouse_on_list = 0;
			actbConsigneeName_removedisp();
			return;
		}
		if (actbConsigneeName_self.actbConsigneeName_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbConsigneeName_curr);
			caret_pos_end = getCaretEnd(actbConsigneeName_curr);
			
			delim_split = '';
			for (i=0;i<actbConsigneeName_self.actbConsigneeName_delimiter.length;i++){
				delim_split += actbConsigneeName_self.actbConsigneeName_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbConsigneeName_delimwords = new Array();
			actbConsigneeName_delimwords[0] = '';
			for (i=0,j=actbConsigneeName_curr.value.length;i<actbConsigneeName_curr.value.length;i++,j--){
				if (actbConsigneeName_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbConsigneeName_curr.value.substr(i,j).match(delim_split_rx);
					actbConsigneeName_delimchar[c] = ma[1];
					c++;
					actbConsigneeName_delimwords[c] = '';
				}else{
					actbConsigneeName_delimwords[c] += actbConsigneeName_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbConsigneeName_cdelimword = -1;
			for (i=0;i<actbConsigneeName_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbConsigneeName_delimwords[i].length){
					actbConsigneeName_cdelimword = i;
				}
				l+=actbConsigneeName_delimwords[i].length + 1;
			}
			var ot = actbConsigneeName_delimwords[actbConsigneeName_cdelimword]; 
			var t = actbConsigneeName_delimwords[actbConsigneeName_cdelimword].addslashes();
		}else{
			var ot = actbConsigneeName_curr.value;
			var t = actbConsigneeName_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbConsigneeName_mouse_on_list = 0;
			actbConsigneeName_removedisp();
		}
		if (ot.length < actbConsigneeName_self.actbConsigneeName_startcheck) return this;
		if (actbConsigneeName_self.actbConsigneeName_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbConsigneeName_total = 0;
		actbConsigneeName_tomake = false;
		actbConsigneeName_kwcount = 0;
		for (i=0;i<actbConsigneeName_self.actbConsigneeName_keywords.length;i++){
			actbConsigneeName_bool[i] = false;
			if (re.test(actbConsigneeName_self.actbConsigneeName_keywords[i])){
				actbConsigneeName_total++;
				actbConsigneeName_bool[i] = true;
				actbConsigneeName_kwcount++;
				if (actbConsigneeName_pre == i) actbConsigneeName_tomake = true;
			}
		}

		if (actbConsigneeName_toid) clearTimeout(actbConsigneeName_toid);
		if (actbConsigneeName_self.actbConsigneeName_timeOut > 0) actbConsigneeName_toid = setTimeout(function(){actbConsigneeName_mouse_on_list = 0;actbConsigneeName_removedisp();},actbConsigneeName_self.actbConsigneeName_timeOut);
		actbConsigneeName_generate();
	}
	return this;
}
