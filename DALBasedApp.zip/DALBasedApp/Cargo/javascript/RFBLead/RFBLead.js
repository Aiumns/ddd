﻿/*
*****************************************************************************
File Name       :	     RFBLead.js   
Purpose         :        This provides Javascript functionality to the RFBLead Page. 
Company         :		 CargoFlash Infotech
Created By      :        Ashutosh Kumar
Created On      :        01 June 2010.
*****************************************************************************
*/
function ShowCompetitorDialog(dropdown) {
    var myindex = dropdown.selectedIndex;
    var selectValue = dropdown.options[myindex].value;
    var $dialogContent = $("#divDialog");
    if (selectValue == 'Competitor') {
        $dialogContent.dialog({
            modal: true,
            title: "Enter Competitor's Rate",
            close: function () {
                $dialogContent.dialog("destroy");
                $dialogContent.hide();
            },
            buttons: {
                save: function () {
                    var competitorsNo = document.getElementById('ctl00_ContentPlaceHolderMain_ddlCompetitor').value;
                    var origin = document.getElementById('ctl00_ContentPlaceHolderMain_txtOriginCompetitor').value;
                    var destination = document.getElementById('ctl00_ContentPlaceHolderMain_txtDestinationCompetitor').value;
                    var rate = document.getElementById('ctl00_ContentPlaceHolderMain_txtRateCompetitor').value;
                    var description = document.getElementById('ctl00_ContentPlaceHolderMain_txtDescriptionCompetitor').value;
                    var leadSno = document.getElementById('ctl00_ContentPlaceHolderMain_hdnLeadSno').value;
                    var usersno = document.getElementById('ctl00_ContentPlaceHolderMain_hdnUserSno').value;

                    $.ajax({
                        url: "Handlers/InsertCompetitorRate.ashx?CompetitorSNo=" + competitorsNo + "&Origin="
        + origin + "&Destination=" + destination + "&Rate=" + rate + "&Description=" + description + "&BookingSNo=" + leadSno + "&UpdatedBy=" + usersno,
                        cache: false,
                        dataType: "json",
                        success: function (data) {
                            
                        }
                    });
                    //alert(competitorsNo + ":" + origin + ":" + destination + ":" + rate + ":" + description);
                    $dialogContent.dialog("close");

                },
                cancel: function () {
                    $dialogContent.dialog("close");
                }
            }
        }).show();

    }
}

function ShowRejectReason(dropdown) {
    var myindex = dropdown.selectedIndex;
    var selectValue = dropdown.options[myindex].value;
    var leadSno = document.getElementById('ctl00_ContentPlaceHolderMain_hdnLeadSno').value;
    if (leadSno != "") {
        if (selectValue == 'Rejected') {
            $('#divRejectReason').show();
            return false;
        }
        else {
            $('#divRejectReason').hide();
            return false;
        }
    }
}