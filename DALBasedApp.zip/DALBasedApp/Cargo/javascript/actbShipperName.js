﻿// JScript File
function actbShipperName(obj,ca){
	/* ---- Public Variables ---- */
	this.actbShipperName_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbShipperName_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbShipperName_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbShipperName_mouse = true; // Enable Mouse Support
	this.actbShipperName_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbShipperName_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbShipperName_bgColor = '#F1F0F0';
	this.actbShipperName_textColor = '#D60000';
	this.actbShipperName_hColor = '#FFFFFF';
	this.actbShipperName_fFamily = 'Verdana';
	this.actbShipperName_fSize = '11px';
	this.actbShipperName_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbShipperName_delimwords = new Array();
	var actbShipperName_cdelimword = 0;
	var actbShipperName_delimchar = new Array();
	var actbShipperName_display = false;
	var actbShipperName_pos = 0;
	var actbShipperName_total = 0;
	var actbShipperName_curr = null;
	var actbShipperName_rangeu = 0;
	var actbShipperName_ranged = 0;
	var actbShipperName_bool = new Array();
	var actbShipperName_pre = 0;
	var actbShipperName_toid;
	var actbShipperName_tomake = false;
	var actbShipperName_getpre = "";
	var actbShipperName_mouse_on_list = 1;
	var actbShipperName_kwcount = 0;
	var actbShipperName_caretmove = false;
	this.actbShipperName_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbShipperName_keywords = ca;
	var actbShipperName_self = this;

	actbShipperName_curr = obj;
	
	addEvent(actbShipperName_curr,"focus",actbShipperName_setup);
	function actbShipperName_setup(){
		addEvent(document,"keydown",actbShipperName_checkkey);
		addEvent(actbShipperName_curr,"blur",actbShipperName_clear);
		addEvent(document,"keypress",actbShipperName_keypress);
	}

	function actbShipperName_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbShipperName_checkkey);
		removeEvent(actbShipperName_curr,"blur",actbShipperName_clear);
		removeEvent(document,"keypress",actbShipperName_keypress);
		actbShipperName_removedisp();
	}
	function actbShipperName_parse(n){
		if (actbShipperName_self.actbShipperName_delimiter.length > 0){
			var t = actbShipperName_delimwords[actbShipperName_cdelimword].addslashes();
			var plen = actbShipperName_delimwords[actbShipperName_cdelimword].length;
		}else{
			var t = actbShipperName_curr.value.addslashes();
			var plen = actbShipperName_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbShipperName_self.actbShipperName_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbShipperName_self.actbShipperName_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbShipperName_generate(){
		if (document.getElementById('tat_table')){ actbShipperName_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbShipperName_kwcount == 0){
			actbShipperName_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbShipperName_curr) + actbShipperName_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbShipperName_curr) + "px";
		a.style.backgroundColor=actbShipperName_self.actbShipperName_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbShipperName_self.actbShipperName_mouse){
			a.onmouseout = actbShipperName_table_unfocus;
			a.onmouseover = actbShipperName_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbShipperName_self.actbShipperName_keywords.length;i++){
			if (actbShipperName_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbShipperName_tomake){
					r.style.backgroundColor = actbShipperName_self.actbShipperName_hColor;
					first = false;
					actbShipperName_pos = counter;
				}else if(actbShipperName_pre == i){
					r.style.backgroundColor = actbShipperName_self.actbShipperName_hColor;
					first = false;
					actbShipperName_pos = counter;
				}else{
					r.style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbShipperName_self.actbShipperName_textColor;
				c.style.fontFamily = actbShipperName_self.actbShipperName_fFamily;
				c.style.fontSize = actbShipperName_self.actbShipperName_fSize;
				c.innerHTML = actbShipperName_parse(actbShipperName_self.actbShipperName_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbShipperName_self.actbShipperName_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbShipperName_mouseclick;
					c.onmouseover = actbShipperName_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbShipperName_self.actbShipperName_lim && j < actbShipperName_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbShipperName_self.actbShipperName_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbShipperName_self.actbShipperName_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbShipperName_self.actbShipperName_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbShipperName_mouse_down;
				}
				break;
			}
		}
		actbShipperName_rangeu = 1;
		actbShipperName_ranged = j-1;
		actbShipperName_display = true;
		if (actbShipperName_pos <= 0) actbShipperName_pos = 1;
	}
	function actbShipperName_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbShipperName_curr) + actbShipperName_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbShipperName_curr) + "px";
		a.style.backgroundColor=actbShipperName_self.actbShipperName_bgColor;
		a.id = 'tat_table';
		if (actbShipperName_self.actbShipperName_mouse){
			a.onmouseout= actbShipperName_table_unfocus;
			a.onmouseover=actbShipperName_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbShipperName_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbShipperName_self.actbShipperName_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbShipperName_self.actbShipperName_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbShipperName_self.actbShipperName_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbShipperName_mouse_up;
			}
		}
		for (i=0;i<actbShipperName_self.actbShipperName_keywords.length;i++){
			if (actbShipperName_bool[i]){
				if (j >= actbShipperName_rangeu && j <= actbShipperName_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbShipperName_self.actbShipperName_textColor;
					c.style.fontFamily = actbShipperName_self.actbShipperName_fFamily;
					c.style.fontSize = actbShipperName_self.actbShipperName_fSize;
					c.innerHTML = actbShipperName_parse(actbShipperName_self.actbShipperName_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbShipperName_self.actbShipperName_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbShipperName_mouseclick;
						c.onmouseover = actbShipperName_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbShipperName_ranged) break;
		}
		if (j-1 < actbShipperName_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbShipperName_self.actbShipperName_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbShipperName_self.actbShipperName_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbShipperName_self.actbShipperName_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbShipperName_mouse_down;
			}
		}
	}
	function actbShipperName_goup(){
		if (!actbShipperName_display) return;
		if (actbShipperName_pos == 1) return;
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
		actbShipperName_pos--;
		if (actbShipperName_pos < actbShipperName_rangeu) actbShipperName_moveup();
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_hColor;
		if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		if (actbShipperName_self.actbShipperName_timeOut > 0) actbShipperName_toid = setTimeout(function(){actbShipperName_mouse_on_list=0;actbShipperName_removedisp();},actbShipperName_self.actbShipperName_timeOut);
	}
	function actbShipperName_godown(){
		if (!actbShipperName_display) return;
		if (actbShipperName_pos == actbShipperName_total) return;
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
		actbShipperName_pos++;
		if (actbShipperName_pos > actbShipperName_ranged) actbShipperName_movedown();
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_hColor;
		if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		if (actbShipperName_self.actbShipperName_timeOut > 0) actbShipperName_toid = setTimeout(function(){actbShipperName_mouse_on_list=0;actbShipperName_removedisp();},actbShipperName_self.actbShipperName_timeOut);
	}
	function actbShipperName_movedown(){
		actbShipperName_rangeu++;
		actbShipperName_ranged++;
		actbShipperName_remake();
	}
	function actbShipperName_moveup(){
		actbShipperName_rangeu--;
		actbShipperName_ranged--;
		actbShipperName_remake();
	}

	/* Mouse */
	function actbShipperName_mouse_down(){
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
		actbShipperName_pos++;
		actbShipperName_movedown();
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_hColor;
		actbShipperName_curr.focus();
		actbShipperName_mouse_on_list = 0;
		if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		if (actbShipperName_self.actbShipperName_timeOut > 0) actbShipperName_toid = setTimeout(function(){actbShipperName_mouse_on_list=0;actbShipperName_removedisp();},actbShipperName_self.actbShipperName_timeOut);
	}
	function actbShipperName_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
		actbShipperName_pos--;
		actbShipperName_moveup();
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_hColor;
		actbShipperName_curr.focus();
		actbShipperName_mouse_on_list = 0;
		if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		if (actbShipperName_self.actbShipperName_timeOut > 0) actbShipperName_toid = setTimeout(function(){actbShipperName_mouse_on_list=0;actbShipperName_removedisp();},actbShipperName_self.actbShipperName_timeOut);
	}
	function actbShipperName_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbShipperName_display) return;
		actbShipperName_mouse_on_list = 0;
		actbShipperName_pos = this.getAttribute('pos');
		actbShipperName_penter();
	}
	function actbShipperName_table_focus(){
		actbShipperName_mouse_on_list = 1;
	}
	function actbShipperName_table_unfocus(){
		actbShipperName_mouse_on_list = 0;
		if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		if (actbShipperName_self.actbShipperName_timeOut > 0) actbShipperName_toid = setTimeout(function(){actbShipperName_mouse_on_list = 0;actbShipperName_removedisp();},actbShipperName_self.actbShipperName_timeOut);
	}
	function actbShipperName_table_highlight(){
		actbShipperName_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_bgColor;
		actbShipperName_pos = this.getAttribute('pos');
		while (actbShipperName_pos < actbShipperName_rangeu) actbShipperName_moveup();
		while (actbShipperName_pos > actbShipperName_ranged) actbShipperName_movedown();
		document.getElementById('tat_tr'+actbShipperName_pos).style.backgroundColor = actbShipperName_self.actbShipperName_hColor;
		if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		if (actbShipperName_self.actbShipperName_timeOut > 0) actbShipperName_toid = setTimeout(function(){actbShipperName_mouse_on_list = 0;actbShipperName_removedisp();},actbShipperName_self.actbShipperName_timeOut);
	}
	/* ---- */

	function actbShipperName_insertword(a){
		if (actbShipperName_self.actbShipperName_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbShipperName_delimwords.length;i++){
				if (actbShipperName_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbShipperName_delimwords[i].length;++j){
						if (actbShipperName_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbShipperName_delimwords[i].length-1;j>=0;--j){
						if (actbShipperName_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbShipperName_delimwords[i];
				}
				if (i != actbShipperName_delimwords.length - 1){
					str += actbShipperName_delimchar[i];
				}
			}
			actbShipperName_curr.value = str;
			setCaret(actbShipperName_curr,l);
		}else{
			actbShipperName_curr.value = a;
		}
		actbShipperName_mouse_on_list = 0;
		actbShipperName_removedisp();
	}
	function actbShipperName_penter(){
		if (!actbShipperName_display) return;
		actbShipperName_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbShipperName_self.actbShipperName_keywords.length;i++){
			if (actbShipperName_bool[i]) c++;
			if (c == actbShipperName_pos){
				word = actbShipperName_self.actbShipperName_keywords[i];
				break;
			}
		}
		actbShipperName_insertword(word);
		l = getCaretStart(actbShipperName_curr);
	}
	function actbShipperName_removedisp(){
		if (actbShipperName_mouse_on_list==0){
			actbShipperName_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		}
	}
	function actbShipperName_keypress(e){
		if (actbShipperName_caretmove) stopEvent(e);
		return !actbShipperName_caretmove;
	}
	function actbShipperName_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbShipperName_curr);
		actbShipperName_caretmove = 0;
		switch (a){
			case 38:
				actbShipperName_goup();
				actbShipperName_caretmove = 1;
				return false;
				break;
			case 40:
				actbShipperName_godown();
				actbShipperName_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbShipperName_display){
					actbShipperName_caretmove = 1;
					actbShipperName_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbShipperName_tocomplete(a)},50);
				break;
		}
	}

	function actbShipperName_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbShipperName_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbShipperName_self.actbShipperName_keywords.length;i++){
				if (actbShipperName_bool[i]) c++;
				if (c == actbShipperName_pos){
					word = i;
					break;
				}
			}
			actbShipperName_pre = word;
		}else{ actbShipperName_pre = -1};
		
		if (actbShipperName_curr.value == ''){
			actbShipperName_mouse_on_list = 0;
			actbShipperName_removedisp();
			return;
		}
		if (actbShipperName_self.actbShipperName_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbShipperName_curr);
			caret_pos_end = getCaretEnd(actbShipperName_curr);
			
			delim_split = '';
			for (i=0;i<actbShipperName_self.actbShipperName_delimiter.length;i++){
				delim_split += actbShipperName_self.actbShipperName_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbShipperName_delimwords = new Array();
			actbShipperName_delimwords[0] = '';
			for (i=0,j=actbShipperName_curr.value.length;i<actbShipperName_curr.value.length;i++,j--){
				if (actbShipperName_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbShipperName_curr.value.substr(i,j).match(delim_split_rx);
					actbShipperName_delimchar[c] = ma[1];
					c++;
					actbShipperName_delimwords[c] = '';
				}else{
					actbShipperName_delimwords[c] += actbShipperName_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbShipperName_cdelimword = -1;
			for (i=0;i<actbShipperName_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbShipperName_delimwords[i].length){
					actbShipperName_cdelimword = i;
				}
				l+=actbShipperName_delimwords[i].length + 1;
			}
			var ot = actbShipperName_delimwords[actbShipperName_cdelimword]; 
			var t = actbShipperName_delimwords[actbShipperName_cdelimword].addslashes();
		}else{
			var ot = actbShipperName_curr.value;
			var t = actbShipperName_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbShipperName_mouse_on_list = 0;
			actbShipperName_removedisp();
		}
		if (ot.length < actbShipperName_self.actbShipperName_startcheck) return this;
		if (actbShipperName_self.actbShipperName_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbShipperName_total = 0;
		actbShipperName_tomake = false;
		actbShipperName_kwcount = 0;
		for (i=0;i<actbShipperName_self.actbShipperName_keywords.length;i++){
			actbShipperName_bool[i] = false;
			if (re.test(actbShipperName_self.actbShipperName_keywords[i])){
				actbShipperName_total++;
				actbShipperName_bool[i] = true;
				actbShipperName_kwcount++;
				if (actbShipperName_pre == i) actbShipperName_tomake = true;
			}
		}

		if (actbShipperName_toid) clearTimeout(actbShipperName_toid);
		if (actbShipperName_self.actbShipperName_timeOut > 0) actbShipperName_toid = setTimeout(function(){actbShipperName_mouse_on_list = 0;actbShipperName_removedisp();},actbShipperName_self.actbShipperName_timeOut);
		actbShipperName_generate();
	}
	return this;
}

