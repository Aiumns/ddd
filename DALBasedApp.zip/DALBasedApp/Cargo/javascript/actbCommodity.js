﻿function actbCommodity(obj,ca){
	/* ---- Public Variables ---- */
	this.actbCommodity_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbCommodity_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbCommodity_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbCommodity_mouse = true; // Enable Mouse Support
	this.actbCommodity_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbCommodity_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbCommodity_bgColor = '#F1F0F0';
	this.actbCommodity_textColor = '#D60000';
	this.actbCommodity_hColor = '#FFFFFF';
	this.actbCommodity_fFamily = 'Verdana';
	this.actbCommodity_fSize = '11px';
	this.actbCommodity_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbCommodity_delimwords = new Array();
	var actbCommodity_cdelimword = 0;
	var actbCommodity_delimchar = new Array();
	var actbCommodity_display = false;
	var actbCommodity_pos = 0;
	var actbCommodity_total = 0;
	var actbCommodity_curr = null;
	var actbCommodity_rangeu = 0;
	var actbCommodity_ranged = 0;
	var actbCommodity_bool = new Array();
	var actbCommodity_pre = 0;
	var actbCommodity_toid;
	var actbCommodity_tomake = false;
	var actbCommodity_getpre = "";
	var actbCommodity_mouse_on_list = 1;
	var actbCommodity_kwcount = 0;
	var actbCommodity_caretmove = false;
	this.actbCommodity_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbCommodity_keywords = ca;
	var actbCommodity_self = this;

	actbCommodity_curr = obj;
	
	addEvent(actbCommodity_curr,"focus",actbCommodity_setup);
	function actbCommodity_setup(){
		addEvent(document,"keydown",actbCommodity_checkkey);
		addEvent(actbCommodity_curr,"blur",actbCommodity_clear);
		addEvent(document,"keypress",actbCommodity_keypress);
	}

	function actbCommodity_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbCommodity_checkkey);
		removeEvent(actbCommodity_curr,"blur",actbCommodity_clear);
		removeEvent(document,"keypress",actbCommodity_keypress);
		actbCommodity_removedisp();
	}
	function actbCommodity_parse(n){
		if (actbCommodity_self.actbCommodity_delimiter.length > 0){
			var t = actbCommodity_delimwords[actbCommodity_cdelimword].addslashes();
			var plen = actbCommodity_delimwords[actbCommodity_cdelimword].length;
		}else{
			var t = actbCommodity_curr.value.addslashes();
			var plen = actbCommodity_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbCommodity_self.actbCommodity_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbCommodity_self.actbCommodity_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbCommodity_generate(){
		if (document.getElementById('tat_table')){ actbCommodity_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbCommodity_kwcount == 0){
			actbCommodity_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbCommodity_curr) + actbCommodity_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbCommodity_curr) + "px";
		a.style.backgroundColor=actbCommodity_self.actbCommodity_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbCommodity_self.actbCommodity_mouse){
			a.onmouseout = actbCommodity_table_unfocus;
			a.onmouseover = actbCommodity_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbCommodity_self.actbCommodity_keywords.length;i++){
			if (actbCommodity_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbCommodity_tomake){
					r.style.backgroundColor = actbCommodity_self.actbCommodity_hColor;
					first = false;
					actbCommodity_pos = counter;
				}else if(actbCommodity_pre == i){
					r.style.backgroundColor = actbCommodity_self.actbCommodity_hColor;
					first = false;
					actbCommodity_pos = counter;
				}else{
					r.style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbCommodity_self.actbCommodity_textColor;
				c.style.fontFamily = actbCommodity_self.actbCommodity_fFamily;
				c.style.fontSize = actbCommodity_self.actbCommodity_fSize;
				c.innerHTML = actbCommodity_parse(actbCommodity_self.actbCommodity_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbCommodity_self.actbCommodity_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbCommodity_mouseclick;
					c.onmouseover = actbCommodity_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbCommodity_self.actbCommodity_lim && j < actbCommodity_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbCommodity_self.actbCommodity_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbCommodity_self.actbCommodity_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbCommodity_self.actbCommodity_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbCommodity_mouse_down;
				}
				break;
			}
		}
		actbCommodity_rangeu = 1;
		actbCommodity_ranged = j-1;
		actbCommodity_display = true;
		if (actbCommodity_pos <= 0) actbCommodity_pos = 1;
	}
	function actbCommodity_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbCommodity_curr) + actbCommodity_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbCommodity_curr) + "px";
		a.style.backgroundColor=actbCommodity_self.actbCommodity_bgColor;
		a.id = 'tat_table';
		if (actbCommodity_self.actbCommodity_mouse){
			a.onmouseout= actbCommodity_table_unfocus;
			a.onmouseover=actbCommodity_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbCommodity_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbCommodity_self.actbCommodity_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbCommodity_self.actbCommodity_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbCommodity_self.actbCommodity_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbCommodity_mouse_up;
			}
		}
		for (i=0;i<actbCommodity_self.actbCommodity_keywords.length;i++){
			if (actbCommodity_bool[i]){
				if (j >= actbCommodity_rangeu && j <= actbCommodity_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbCommodity_self.actbCommodity_textColor;
					c.style.fontFamily = actbCommodity_self.actbCommodity_fFamily;
					c.style.fontSize = actbCommodity_self.actbCommodity_fSize;
					c.innerHTML = actbCommodity_parse(actbCommodity_self.actbCommodity_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbCommodity_self.actbCommodity_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbCommodity_mouseclick;
						c.onmouseover = actbCommodity_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbCommodity_ranged) break;
		}
		if (j-1 < actbCommodity_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbCommodity_self.actbCommodity_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbCommodity_self.actbCommodity_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbCommodity_self.actbCommodity_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbCommodity_mouse_down;
			}
		}
	}
	function actbCommodity_goup(){
		if (!actbCommodity_display) return;
		if (actbCommodity_pos == 1) return;
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
		actbCommodity_pos--;
		if (actbCommodity_pos < actbCommodity_rangeu) actbCommodity_moveup();
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_hColor;
		if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		if (actbCommodity_self.actbCommodity_timeOut > 0) actbCommodity_toid = setTimeout(function(){actbCommodity_mouse_on_list=0;actbCommodity_removedisp();},actbCommodity_self.actbCommodity_timeOut);
	}
	function actbCommodity_godown(){
		if (!actbCommodity_display) return;
		if (actbCommodity_pos == actbCommodity_total) return;
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
		actbCommodity_pos++;
		if (actbCommodity_pos > actbCommodity_ranged) actbCommodity_movedown();
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_hColor;
		if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		if (actbCommodity_self.actbCommodity_timeOut > 0) actbCommodity_toid = setTimeout(function(){actbCommodity_mouse_on_list=0;actbCommodity_removedisp();},actbCommodity_self.actbCommodity_timeOut);
	}
	function actbCommodity_movedown(){
		actbCommodity_rangeu++;
		actbCommodity_ranged++;
		actbCommodity_remake();
	}
	function actbCommodity_moveup(){
		actbCommodity_rangeu--;
		actbCommodity_ranged--;
		actbCommodity_remake();
	}

	/* Mouse */
	function actbCommodity_mouse_down(){
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
		actbCommodity_pos++;
		actbCommodity_movedown();
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_hColor;
		actbCommodity_curr.focus();
		actbCommodity_mouse_on_list = 0;
		if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		if (actbCommodity_self.actbCommodity_timeOut > 0) actbCommodity_toid = setTimeout(function(){actbCommodity_mouse_on_list=0;actbCommodity_removedisp();},actbCommodity_self.actbCommodity_timeOut);
	}
	function actbCommodity_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
		actbCommodity_pos--;
		actbCommodity_moveup();
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_hColor;
		actbCommodity_curr.focus();
		actbCommodity_mouse_on_list = 0;
		if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		if (actbCommodity_self.actbCommodity_timeOut > 0) actbCommodity_toid = setTimeout(function(){actbCommodity_mouse_on_list=0;actbCommodity_removedisp();},actbCommodity_self.actbCommodity_timeOut);
	}
	function actbCommodity_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbCommodity_display) return;
		actbCommodity_mouse_on_list = 0;
		actbCommodity_pos = this.getAttribute('pos');
		actbCommodity_penter();
	}
	function actbCommodity_table_focus(){
		actbCommodity_mouse_on_list = 1;
	}
	function actbCommodity_table_unfocus(){
		actbCommodity_mouse_on_list = 0;
		if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		if (actbCommodity_self.actbCommodity_timeOut > 0) actbCommodity_toid = setTimeout(function(){actbCommodity_mouse_on_list = 0;actbCommodity_removedisp();},actbCommodity_self.actbCommodity_timeOut);
	}
	function actbCommodity_table_highlight(){
		actbCommodity_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_bgColor;
		actbCommodity_pos = this.getAttribute('pos');
		while (actbCommodity_pos < actbCommodity_rangeu) actbCommodity_moveup();
		while (actbCommodity_pos > actbCommodity_ranged) actbCommodity_movedown();
		document.getElementById('tat_tr'+actbCommodity_pos).style.backgroundColor = actbCommodity_self.actbCommodity_hColor;
		if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		if (actbCommodity_self.actbCommodity_timeOut > 0) actbCommodity_toid = setTimeout(function(){actbCommodity_mouse_on_list = 0;actbCommodity_removedisp();},actbCommodity_self.actbCommodity_timeOut);
	}
	/* ---- */

	function actbCommodity_insertword(a){
		if (actbCommodity_self.actbCommodity_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbCommodity_delimwords.length;i++){
				if (actbCommodity_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbCommodity_delimwords[i].length;++j){
						if (actbCommodity_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbCommodity_delimwords[i].length-1;j>=0;--j){
						if (actbCommodity_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbCommodity_delimwords[i];
				}
				if (i != actbCommodity_delimwords.length - 1){
					str += actbCommodity_delimchar[i];
				}
			}
			actbCommodity_curr.value = str;
			setCaret(actbCommodity_curr,l);
		}else{
			actbCommodity_curr.value = a;
		}
		actbCommodity_mouse_on_list = 0;
		actbCommodity_removedisp();
	}
	function actbCommodity_penter(){
		if (!actbCommodity_display) return;
		actbCommodity_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbCommodity_self.actbCommodity_keywords.length;i++){
			if (actbCommodity_bool[i]) c++;
			if (c == actbCommodity_pos){
				word = actbCommodity_self.actbCommodity_keywords[i];
				break;
			}
		}
		actbCommodity_insertword(word);
		l = getCaretStart(actbCommodity_curr);
	}
	function actbCommodity_removedisp(){
		if (actbCommodity_mouse_on_list==0){
			actbCommodity_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		}
	}
	function actbCommodity_keypress(e){
		if (actbCommodity_caretmove) stopEvent(e);
		return !actbCommodity_caretmove;
	}
	function actbCommodity_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbCommodity_curr);
		actbCommodity_caretmove = 0;
		switch (a){
			case 38:
				actbCommodity_goup();
				actbCommodity_caretmove = 1;
				return false;
				break;
			case 40:
				actbCommodity_godown();
				actbCommodity_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbCommodity_display){
					actbCommodity_caretmove = 1;
					actbCommodity_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbCommodity_tocomplete(a)},50);
				break;
		}
	}

	function actbCommodity_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbCommodity_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbCommodity_self.actbCommodity_keywords.length;i++){
				if (actbCommodity_bool[i]) c++;
				if (c == actbCommodity_pos){
					word = i;
					break;
				}
			}
			actbCommodity_pre = word;
		}else{ actbCommodity_pre = -1};
		
		if (actbCommodity_curr.value == ''){
			actbCommodity_mouse_on_list = 0;
			actbCommodity_removedisp();
			return;
		}
		if (actbCommodity_self.actbCommodity_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbCommodity_curr);
			caret_pos_end = getCaretEnd(actbCommodity_curr);
			
			delim_split = '';
			for (i=0;i<actbCommodity_self.actbCommodity_delimiter.length;i++){
				delim_split += actbCommodity_self.actbCommodity_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbCommodity_delimwords = new Array();
			actbCommodity_delimwords[0] = '';
			for (i=0,j=actbCommodity_curr.value.length;i<actbCommodity_curr.value.length;i++,j--){
				if (actbCommodity_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbCommodity_curr.value.substr(i,j).match(delim_split_rx);
					actbCommodity_delimchar[c] = ma[1];
					c++;
					actbCommodity_delimwords[c] = '';
				}else{
					actbCommodity_delimwords[c] += actbCommodity_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbCommodity_cdelimword = -1;
			for (i=0;i<actbCommodity_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbCommodity_delimwords[i].length){
					actbCommodity_cdelimword = i;
				}
				l+=actbCommodity_delimwords[i].length + 1;
			}
			var ot = actbCommodity_delimwords[actbCommodity_cdelimword]; 
			var t = actbCommodity_delimwords[actbCommodity_cdelimword].addslashes();
		}else{
			var ot = actbCommodity_curr.value;
			var t = actbCommodity_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbCommodity_mouse_on_list = 0;
			actbCommodity_removedisp();
		}
		if (ot.length < actbCommodity_self.actbCommodity_startcheck) return this;
		if (actbCommodity_self.actbCommodity_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbCommodity_total = 0;
		actbCommodity_tomake = false;
		actbCommodity_kwcount = 0;
		for (i=0;i<actbCommodity_self.actbCommodity_keywords.length;i++){
			actbCommodity_bool[i] = false;
			if (re.test(actbCommodity_self.actbCommodity_keywords[i])){
				actbCommodity_total++;
				actbCommodity_bool[i] = true;
				actbCommodity_kwcount++;
				if (actbCommodity_pre == i) actbCommodity_tomake = true;
			}
		}

		if (actbCommodity_toid) clearTimeout(actbCommodity_toid);
		if (actbCommodity_self.actbCommodity_timeOut > 0) actbCommodity_toid = setTimeout(function(){actbCommodity_mouse_on_list = 0;actbCommodity_removedisp();},actbCommodity_self.actbCommodity_timeOut);
		actbCommodity_generate();
	}
	return this;
}