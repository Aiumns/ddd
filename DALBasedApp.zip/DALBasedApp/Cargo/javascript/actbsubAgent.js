﻿function actbsubAgent(obj,ca){
	/* ---- Public Variables ---- */
	this.actbsubAgent_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbsubAgent_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbsubAgent_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbsubAgent_mouse = true; // Enable Mouse Support
	this.actbsubAgent_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbsubAgent_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbsubAgent_bgColor = '#F1F0F0';
	this.actbsubAgent_textColor = '#D60000';
	this.actbsubAgent_hColor = '#FFFFFF';
	this.actbsubAgent_fFamily = 'Verdana';
	this.actbsubAgent_fSize = '11px';
	this.actbsubAgent_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbsubAgent_delimwords = new Array();
	var actbsubAgent_cdelimword = 0;
	var actbsubAgent_delimchar = new Array();
	var actbsubAgent_display = false;
	var actbsubAgent_pos = 0;
	var actbsubAgent_total = 0;
	var actbsubAgent_curr = null;
	var actbsubAgent_rangeu = 0;
	var actbsubAgent_ranged = 0;
	var actbsubAgent_bool = new Array();
	var actbsubAgent_pre = 0;
	var actbsubAgent_toid;
	var actbsubAgent_tomake = false;
	var actbsubAgent_getpre = "";
	var actbsubAgent_mouse_on_list = 1;
	var actbsubAgent_kwcount = 0;
	var actbsubAgent_caretmove = false;
	this.actbsubAgent_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbsubAgent_keywords = ca;
	var actbsubAgent_self = this;

	actbsubAgent_curr = obj;
	
	addEvent(actbsubAgent_curr,"focus",actbsubAgent_setup);
	function actbsubAgent_setup(){
		addEvent(document,"keydown",actbsubAgent_checkkey);
		addEvent(actbsubAgent_curr,"blur",actbsubAgent_clear);
		addEvent(document,"keypress",actbsubAgent_keypress);
	}

	function actbsubAgent_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbsubAgent_checkkey);
		removeEvent(actbsubAgent_curr,"blur",actbsubAgent_clear);
		removeEvent(document,"keypress",actbsubAgent_keypress);
		actbsubAgent_removedisp();
	}
	function actbsubAgent_parse(n){
		if (actbsubAgent_self.actbsubAgent_delimiter.length > 0){
			var t = actbsubAgent_delimwords[actbsubAgent_cdelimword].addslashes();
			var plen = actbsubAgent_delimwords[actbsubAgent_cdelimword].length;
		}else{
			var t = actbsubAgent_curr.value.addslashes();
			var plen = actbsubAgent_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbsubAgent_self.actbsubAgent_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbsubAgent_self.actbsubAgent_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbsubAgent_generate(){
		if (document.getElementById('tat_table')){ actbsubAgent_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbsubAgent_kwcount == 0){
			actbsubAgent_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbsubAgent_curr) + actbsubAgent_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbsubAgent_curr) + "px";
		a.style.backgroundColor=actbsubAgent_self.actbsubAgent_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbsubAgent_self.actbsubAgent_mouse){
			a.onmouseout = actbsubAgent_table_unfocus;
			a.onmouseover = actbsubAgent_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbsubAgent_self.actbsubAgent_keywords.length;i++){
			if (actbsubAgent_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbsubAgent_tomake){
					r.style.backgroundColor = actbsubAgent_self.actbsubAgent_hColor;
					first = false;
					actbsubAgent_pos = counter;
				}else if(actbsubAgent_pre == i){
					r.style.backgroundColor = actbsubAgent_self.actbsubAgent_hColor;
					first = false;
					actbsubAgent_pos = counter;
				}else{
					r.style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbsubAgent_self.actbsubAgent_textColor;
				c.style.fontFamily = actbsubAgent_self.actbsubAgent_fFamily;
				c.style.fontSize = actbsubAgent_self.actbsubAgent_fSize;
				c.innerHTML = actbsubAgent_parse(actbsubAgent_self.actbsubAgent_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbsubAgent_self.actbsubAgent_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbsubAgent_mouseclick;
					c.onmouseover = actbsubAgent_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbsubAgent_self.actbsubAgent_lim && j < actbsubAgent_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbsubAgent_self.actbsubAgent_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbsubAgent_self.actbsubAgent_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbsubAgent_self.actbsubAgent_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbsubAgent_mouse_down;
				}
				break;
			}
		}
		actbsubAgent_rangeu = 1;
		actbsubAgent_ranged = j-1;
		actbsubAgent_display = true;
		if (actbsubAgent_pos <= 0) actbsubAgent_pos = 1;
	}
	function actbsubAgent_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbsubAgent_curr) + actbsubAgent_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbsubAgent_curr) + "px";
		a.style.backgroundColor=actbsubAgent_self.actbsubAgent_bgColor;
		a.id = 'tat_table';
		if (actbsubAgent_self.actbsubAgent_mouse){
			a.onmouseout= actbsubAgent_table_unfocus;
			a.onmouseover=actbsubAgent_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbsubAgent_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbsubAgent_self.actbsubAgent_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbsubAgent_self.actbsubAgent_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbsubAgent_self.actbsubAgent_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbsubAgent_mouse_up;
			}
		}
		for (i=0;i<actbsubAgent_self.actbsubAgent_keywords.length;i++){
			if (actbsubAgent_bool[i]){
				if (j >= actbsubAgent_rangeu && j <= actbsubAgent_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbsubAgent_self.actbsubAgent_textColor;
					c.style.fontFamily = actbsubAgent_self.actbsubAgent_fFamily;
					c.style.fontSize = actbsubAgent_self.actbsubAgent_fSize;
					c.innerHTML = actbsubAgent_parse(actbsubAgent_self.actbsubAgent_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbsubAgent_self.actbsubAgent_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbsubAgent_mouseclick;
						c.onmouseover = actbsubAgent_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbsubAgent_ranged) break;
		}
		if (j-1 < actbsubAgent_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbsubAgent_self.actbsubAgent_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbsubAgent_self.actbsubAgent_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbsubAgent_self.actbsubAgent_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbsubAgent_mouse_down;
			}
		}
	}
	function actbsubAgent_goup(){
		if (!actbsubAgent_display) return;
		if (actbsubAgent_pos == 1) return;
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
		actbsubAgent_pos--;
		if (actbsubAgent_pos < actbsubAgent_rangeu) actbsubAgent_moveup();
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_hColor;
		if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		if (actbsubAgent_self.actbsubAgent_timeOut > 0) actbsubAgent_toid = setTimeout(function(){actbsubAgent_mouse_on_list=0;actbsubAgent_removedisp();},actbsubAgent_self.actbsubAgent_timeOut);
	}
	function actbsubAgent_godown(){
		if (!actbsubAgent_display) return;
		if (actbsubAgent_pos == actbsubAgent_total) return;
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
		actbsubAgent_pos++;
		if (actbsubAgent_pos > actbsubAgent_ranged) actbsubAgent_movedown();
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_hColor;
		if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		if (actbsubAgent_self.actbsubAgent_timeOut > 0) actbsubAgent_toid = setTimeout(function(){actbsubAgent_mouse_on_list=0;actbsubAgent_removedisp();},actbsubAgent_self.actbsubAgent_timeOut);
	}
	function actbsubAgent_movedown(){
		actbsubAgent_rangeu++;
		actbsubAgent_ranged++;
		actbsubAgent_remake();
	}
	function actbsubAgent_moveup(){
		actbsubAgent_rangeu--;
		actbsubAgent_ranged--;
		actbsubAgent_remake();
	}

	/* Mouse */
	function actbsubAgent_mouse_down(){
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
		actbsubAgent_pos++;
		actbsubAgent_movedown();
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_hColor;
		actbsubAgent_curr.focus();
		actbsubAgent_mouse_on_list = 0;
		if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		if (actbsubAgent_self.actbsubAgent_timeOut > 0) actbsubAgent_toid = setTimeout(function(){actbsubAgent_mouse_on_list=0;actbsubAgent_removedisp();},actbsubAgent_self.actbsubAgent_timeOut);
	}
	function actbsubAgent_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
		actbsubAgent_pos--;
		actbsubAgent_moveup();
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_hColor;
		actbsubAgent_curr.focus();
		actbsubAgent_mouse_on_list = 0;
		if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		if (actbsubAgent_self.actbsubAgent_timeOut > 0) actbsubAgent_toid = setTimeout(function(){actbsubAgent_mouse_on_list=0;actbsubAgent_removedisp();},actbsubAgent_self.actbsubAgent_timeOut);
	}
	function actbsubAgent_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbsubAgent_display) return;
		actbsubAgent_mouse_on_list = 0;
		actbsubAgent_pos = this.getAttribute('pos');
		actbsubAgent_penter();
	}
	function actbsubAgent_table_focus(){
		actbsubAgent_mouse_on_list = 1;
	}
	function actbsubAgent_table_unfocus(){
		actbsubAgent_mouse_on_list = 0;
		if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		if (actbsubAgent_self.actbsubAgent_timeOut > 0) actbsubAgent_toid = setTimeout(function(){actbsubAgent_mouse_on_list = 0;actbsubAgent_removedisp();},actbsubAgent_self.actbsubAgent_timeOut);
	}
	function actbsubAgent_table_highlight(){
		actbsubAgent_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_bgColor;
		actbsubAgent_pos = this.getAttribute('pos');
		while (actbsubAgent_pos < actbsubAgent_rangeu) actbsubAgent_moveup();
		while (actbsubAgent_pos > actbsubAgent_ranged) actbsubAgent_movedown();
		document.getElementById('tat_tr'+actbsubAgent_pos).style.backgroundColor = actbsubAgent_self.actbsubAgent_hColor;
		if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		if (actbsubAgent_self.actbsubAgent_timeOut > 0) actbsubAgent_toid = setTimeout(function(){actbsubAgent_mouse_on_list = 0;actbsubAgent_removedisp();},actbsubAgent_self.actbsubAgent_timeOut);
	}
	/* ---- */

	function actbsubAgent_insertword(a){
		if (actbsubAgent_self.actbsubAgent_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbsubAgent_delimwords.length;i++){
				if (actbsubAgent_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbsubAgent_delimwords[i].length;++j){
						if (actbsubAgent_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbsubAgent_delimwords[i].length-1;j>=0;--j){
						if (actbsubAgent_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbsubAgent_delimwords[i];
				}
				if (i != actbsubAgent_delimwords.length - 1){
					str += actbsubAgent_delimchar[i];
				}
			}
			actbsubAgent_curr.value = str;
			setCaret(actbsubAgent_curr,l);
		}else{
			actbsubAgent_curr.value = a;
		}
		actbsubAgent_mouse_on_list = 0;
		actbsubAgent_removedisp();
	}
	function actbsubAgent_penter(){
		if (!actbsubAgent_display) return;
		actbsubAgent_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbsubAgent_self.actbsubAgent_keywords.length;i++){
			if (actbsubAgent_bool[i]) c++;
			if (c == actbsubAgent_pos){
				word = actbsubAgent_self.actbsubAgent_keywords[i];
				break;
			}
		}
		actbsubAgent_insertword(word);
		l = getCaretStart(actbsubAgent_curr);
	}
	function actbsubAgent_removedisp(){
		if (actbsubAgent_mouse_on_list==0){
			actbsubAgent_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		}
	}
	function actbsubAgent_keypress(e){
		if (actbsubAgent_caretmove) stopEvent(e);
		return !actbsubAgent_caretmove;
	}
	function actbsubAgent_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbsubAgent_curr);
		actbsubAgent_caretmove = 0;
		switch (a){
			case 38:
				actbsubAgent_goup();
				actbsubAgent_caretmove = 1;
				return false;
				break;
			case 40:
				actbsubAgent_godown();
				actbsubAgent_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbsubAgent_display){
					actbsubAgent_caretmove = 1;
					actbsubAgent_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbsubAgent_tocomplete(a)},50);
				break;
		}
	}

	function actbsubAgent_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbsubAgent_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbsubAgent_self.actbsubAgent_keywords.length;i++){
				if (actbsubAgent_bool[i]) c++;
				if (c == actbsubAgent_pos){
					word = i;
					break;
				}
			}
			actbsubAgent_pre = word;
		}else{ actbsubAgent_pre = -1};
		
		if (actbsubAgent_curr.value == ''){
			actbsubAgent_mouse_on_list = 0;
			actbsubAgent_removedisp();
			return;
		}
		if (actbsubAgent_self.actbsubAgent_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbsubAgent_curr);
			caret_pos_end = getCaretEnd(actbsubAgent_curr);
			
			delim_split = '';
			for (i=0;i<actbsubAgent_self.actbsubAgent_delimiter.length;i++){
				delim_split += actbsubAgent_self.actbsubAgent_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbsubAgent_delimwords = new Array();
			actbsubAgent_delimwords[0] = '';
			for (i=0,j=actbsubAgent_curr.value.length;i<actbsubAgent_curr.value.length;i++,j--){
				if (actbsubAgent_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbsubAgent_curr.value.substr(i,j).match(delim_split_rx);
					actbsubAgent_delimchar[c] = ma[1];
					c++;
					actbsubAgent_delimwords[c] = '';
				}else{
					actbsubAgent_delimwords[c] += actbsubAgent_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbsubAgent_cdelimword = -1;
			for (i=0;i<actbsubAgent_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbsubAgent_delimwords[i].length){
					actbsubAgent_cdelimword = i;
				}
				l+=actbsubAgent_delimwords[i].length + 1;
			}
			var ot = actbsubAgent_delimwords[actbsubAgent_cdelimword]; 
			var t = actbsubAgent_delimwords[actbsubAgent_cdelimword].addslashes();
		}else{
			var ot = actbsubAgent_curr.value;
			var t = actbsubAgent_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbsubAgent_mouse_on_list = 0;
			actbsubAgent_removedisp();
		}
		if (ot.length < actbsubAgent_self.actbsubAgent_startcheck) return this;
		if (actbsubAgent_self.actbsubAgent_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbsubAgent_total = 0;
		actbsubAgent_tomake = false;
		actbsubAgent_kwcount = 0;
		for (i=0;i<actbsubAgent_self.actbsubAgent_keywords.length;i++){
			actbsubAgent_bool[i] = false;
			if (re.test(actbsubAgent_self.actbsubAgent_keywords[i])){
				actbsubAgent_total++;
				actbsubAgent_bool[i] = true;
				actbsubAgent_kwcount++;
				if (actbsubAgent_pre == i) actbsubAgent_tomake = true;
			}
		}

		if (actbsubAgent_toid) clearTimeout(actbsubAgent_toid);
		if (actbsubAgent_self.actbsubAgent_timeOut > 0) actbsubAgent_toid = setTimeout(function(){actbsubAgent_mouse_on_list = 0;actbsubAgent_removedisp();},actbsubAgent_self.actbsubAgent_timeOut);
		actbsubAgent_generate();
	}
	return this;
}