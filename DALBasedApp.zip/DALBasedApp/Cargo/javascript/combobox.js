
	function txbkd()
	{
		var p = window.event.srcElement.cbx.lst;
		
		if (window.event.keyCode == 9)
		{
			phide(p);
			return true;
		}
		
		if (window.event.keyCode == 13)
		{
			if (p.selectedItem != null)
			{
				p.cbx.txb.value = p.selectedItem.innerText;
				//itemDeselect(p.selectedItem);
				phide(p);
				window.event.returnValue = false;
				window.event.srcElement.select();
				
				__combobox_invokepostback(p.cbx);
					
				return false;
			}
		}
		
		if (window.event.keyCode == 40 || window.event.keyCode == 38)
		{
				if (p.selectedItem != null && p.style.visibility == 'visible')
				{
					var index = p.selectedIndex;
					itemDeselect(p.selectedItem);
					var dir = window.event.keyCode == 40 ? 1 : -1;
					if (index + dir >= 0 && index + dir < p.childNodes.length )
					{
						itemSelect(p.childNodes[index + dir]);
					}
				}
				else
				{
					p.style.visibility = 'visible';
					if (0 < p.childNodes.length)
					{
						itemSelect(p.childNodes[0]);
					}
				}
		}
		else if (window.event.keyCode == 27)
		{
			phide(p);
		}
	}
	
	function itemFocus()
	{
	}
	
	function getSelectedItem(comboBox)
	{
		var cbx = _cbx(comboBox);
		var li = cbx.lst.childNodes;
		for (var i = 0; i < li.length; i++)
			if (li[i].isSelected) return li[i];
	}
	
	function txbku()
	{
		var ev = window.event;
		var e = window.event.srcElement;
		var c = e.cbx;
		var p = c.lst;
		var txt = e.value;
		if (ev.keyCode != 38 && ev.keyCode != 40 && e.keyCode != 37 && ev.keyCode != 39 && ev.keyCode != 9 && ev.keyCode != 13)
		{
			itemDeselect(p.selectedItem);
			if (txt != '' && e.cbx.autocomplete)
			{
				var j = 0;
				if (c.cases)
				{
					for (var i = 0; i < p.items.length; i++) if (p.items[i].indexOf(txt) == 0) j++;
				}
				else
				{
					for (var i = 0; i < p.items.length; i++) if (p.items[i].toLowerCase().indexOf(txt.toLowerCase()) == 0) j++;
				}
				
				var selectedList = new Array(j);
				
				j = 0;
				if (c.cases)
				{
					for (var i = 0; i < p.items.length; i++)
						if (p.items[i].indexOf(txt) == 0)
							selectedList[j++] = p.items[i];
				}
				else
				{
					for (var i = 0; i < p.items.length; i++)
						if (p.items[i].toLowerCase().indexOf(txt.toLowerCase()) == 0)
							selectedList[j++] = p.items[i];
				}
				
				var fireList = (j != 0 ? selectedList : null);
				
				popItems(e.cbx, fireList);
				
				// set the textbox value & selection
				if (((ev.keyCode >= 48 && ev.keyCode <= 57) || (ev.keyCode >= 65 && ev.keyCode <= 90)) && j != 0)
				{
					for (var i = 0; i < p.items.length; i++)
					{
						if ((!c.cases && ((p.items[i].toLowerCase().indexOf(txt.toLowerCase()) == 0))) || (p.items[i].indexOf(txt) == 0))
						{
							e.value = p.items[i];
							var tr = e.createTextRange();
							tr.moveStart('character', txt.length);
							tr.select();
							break;
						}
					}
				}
			}
			else
			{
				popItems(e.cbx, null);
			}
		}
	}
	
	function txblur()
	{
		var e = window.event.srcElement;
		var p = e.cbx.lst;
		var b = e.cbx.btn;
		if (!p.ison && !b.ison)
		{
			phide(p);
			//p.style.visibility = 'hidden';
		}//itemDeselect(p.selectedItem);
		//itemsDeselect(p);
	}
	
	function pmr()
	{
		var d = window.event.srcElement;
		d.ison = true;
	}
	
	function pmt()
	{
		var d = window.event.srcElement;
		d.ison = false;
	}

	function mr()
	{
		itemSelect(window.event.srcElement);
	}
	
	function itemSelect(i)
	{
		if (i != null)
		{
			i.style.backgroundColor = 'buttonshadow';
			i.style.color = 'window';
			
			i.isSelected = true;
			i.parentElement.cbx.lst.ison = true;
			i.parentElement.selectedItem = i;
			i.parentElement.selectedIndex = i.itemIndex;
		}
	}
	
	function itemDeselect(i)
	{
		if (i != null)
		{
			i.style.backgroundColor = 'window';
			i.style.color = 'windowtext';
			
			i.isSelected = false;
			i.parentElement.cbx.lst.ison = false;
			i.parentElement.selectedItem = null;
			i.parentElement.selectedIndex = -1;
		}
	}
	
	function itemsDeselect(p)
	{
		for (var i = 0; i < p.subitems.length; i++)
		{
			itemDeselect(p.childNodes[i]);
		}
	}
	
	function phide(p)
	{
		if (p.style.visibility == 'visible')
			p.style.visibility = 'hidden';
		itemsDeselect(p);
	}
	
	function mt()
	{
		itemDeselect(window.event.srcElement);
	}
	
	function getRealIndex(comboBox)
	{
		var l = comboBox.lst;
		var t = comboBox.txb;
		
		for (i = 0; i < l.items.length; i++)
			if (l.items[i] == t.value)
				return i;
		return -1;
	}
	
	function mc()
	{
		var d = window.event.srcElement;
		var l = d.parentElement;
		var c = l.cbx;
		var t = c.txb;
		
		t.value = d.innerText;
		if (c.autopostback)
		{
			__combobox_postback(c, getRealIndex(c));
		}
		else
		{
			phide(l);
			t.focus();
			t.select();
		}
	}
	
	function _cbx(comboBox)
	{
		return document.getElementById(comboBox);
	}
	
	function clearlst(lst)
	{
		lst.innerHTML = '';
	}
	
	function popItems(comboBox, list, itin)
	{	
		var p = comboBox.lst;
		
		if (itin)
		{
			p.items = list;
		}
		p.subitems = (list == null ? p.items : list);
		
		clearlst(p);
		
		for (var c = 0; c < p.subitems.length; c++)
		{
			var ps = p.style;
			var i = document.createElement('div');
			
			i.id = 'item' + p.childNodes.length;
			
			//if (itin)
				i.itemIndex = c;
			
			i.style.cursor = 'default';
			i.style.whitespace = 'default';
			
			
			i.bgcolor = '#000000';
			i.innerText = p.subitems[c];
			
			i.style.fontFamily =  comboBox.txb.style.fontFamily;
			i.style.fontSize = comboBox.txb.style.fontSize;
			
			i.style. Width = isNaN(parseInt(comboBox.txb.style. Width, 10)) ? '200px' : comboBox.txb.style. Width;
			//i.style.height = '24px';
			
			i.style.verticalAlign = 'middle';
			
			//i.innerHTML = "<table class="formInsideTable"><tr><td valign = 'center'>" + p.subitems[c] + "</td></tr></table>";
			
			i.onmouseover = mr;
			i.onmouseout = mt;
			i.onclick = mc;
			
			p.appendChild(i);
		}
	}
	
	function pstyle(p)
	{
		var ps = p.style;
		ps.position = 'absolute';
		ps. Width = p.cbx.style. Width;
		var iHeight = p.cbx.offsetHeight - 5;
		ps.height = (p.maxDropDownItems * iHeight) + 2 + 'px';
		
		ps.top = p.cbx.style.position != 'absolute' ? getElementPosition(p.cbx).top + p.cbx.offsetHeight + 2 : p.cbx.offsetHeight + 1;//+ 'px';
	
		ps.border = '1px solid #000000';
		ps.backgroundColor = '#ffffff';
	}

	function getElementPosition(el)
	{
		var c = el, l = 0, t = 0;
		for (; c.offsetParent.offsetParent; c = c.offsetParent)
		{
			l += c.offsetLeft;
			t += c.offsetTop;
		}
		return {left: l, top: t};
	}
	
	function flip()
	{
		var e = window.event.srcElement;
		var t = e.cbx.txb;
		var p = e.cbx.lst;
		var ps = p.style;
		
		if (ps.visibility == 'hidden')
		{
			ps.visibility = 'visible';
			t.focus();
		}
		else
		{
			phide(p);
		}
	}
	
	function __combobox_invokepostback(comboBox)
	{
		if (comboBox.autopostback)
			__combobox_postback(comboBox, getRealIndex(comboBox));
	}
	
	function initCombo(comboBox, _items, apb, autocomplete, cases, maxDropDownItems)
	{
		var e = document.getElementById(comboBox);
		e.lst = e.childNodes[0];
		e.txb = e.childNodes[1].rows[0].cells[0].childNodes[0];
		e.btn = e.childNodes[1].rows[0].cells[1];
		e.btn.cbx = e.lst.cbx = e.txb.cbx = e;
		e.lst.maxDropDownItems = maxDropDownItems;
		
		if (e.autocomplete = autocomplete)
			e.cases = cases;
		
		e.autopostback = apb;
		
		pstyle(e.lst);
		
		popItems(e, _items, true);
	}