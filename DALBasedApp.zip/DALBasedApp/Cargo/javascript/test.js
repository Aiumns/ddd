﻿// JScript File

function CheckBoxChange()
{
if(document.getElementById("<%=Label1.ClientID%>").innerHTML=="Plus 100 To 300")
{
alert("hiii");
 document.getElementById("<%=Label1.ClientID%>").innerHTML = "Plus 100 To 250";
 document.getElementById("<%=Label2.ClientID%>").innerHTML = "Plus 250 To 500";
 return false;
 }
 else if(document.getElementById("<%= Label1.ClientID %>").innerHTML=="Plus 100 To 250")
 {
 document.getElementById("<%= Label1.ClientID %>").innerHTML = "Plus 100 To 300";
 document.getElementById("<%= Label2.ClientID %>").innerHTML = "Plus 300 To 500";
 return false;
 }
 return false;
}