﻿function actbAirline(obj,ca){
	/* ---- Public Variables ---- */
	this.actbAirline_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbAirline_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbAirline_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbAirline_mouse = true; // Enable Mouse Support
	this.actbAirline_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbAirline_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbAirline_bgColor = '#F1F0F0';
	this.actbAirline_textColor = '#D60000';
	this.actbAirline_hColor = '#FFFFFF';
	this.actbAirline_fFamily = 'Verdana';
	this.actbAirline_fSize = '11px';
	this.actbAirline_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbAirline_delimwords = new Array();
	var actbAirline_cdelimword = 0;
	var actbAirline_delimchar = new Array();
	var actbAirline_display = false;
	var actbAirline_pos = 0;
	var actbAirline_total = 0;
	var actbAirline_curr = null;
	var actbAirline_rangeu = 0;
	var actbAirline_ranged = 0;
	var actbAirline_bool = new Array();
	var actbAirline_pre = 0;
	var actbAirline_toid;
	var actbAirline_tomake = false;
	var actbAirline_getpre = "";
	var actbAirline_mouse_on_list = 1;
	var actbAirline_kwcount = 0;
	var actbAirline_caretmove = false;
	this.actbAirline_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbAirline_keywords = ca;
	var actbAirline_self = this;

	actbAirline_curr = obj;
	
	addEvent(actbAirline_curr,"focus",actbAirline_setup);
	function actbAirline_setup(){
		addEvent(document,"keydown",actbAirline_checkkey);
		addEvent(actbAirline_curr,"blur",actbAirline_clear);
		addEvent(document,"keypress",actbAirline_keypress);
	}

	function actbAirline_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbAirline_checkkey);
		removeEvent(actbAirline_curr,"blur",actbAirline_clear);
		removeEvent(document,"keypress",actbAirline_keypress);
		actbAirline_removedisp();
	}
	function actbAirline_parse(n){
		if (actbAirline_self.actbAirline_delimiter.length > 0){
			var t = actbAirline_delimwords[actbAirline_cdelimword].addslashes();
			var plen = actbAirline_delimwords[actbAirline_cdelimword].length;
		}else{
			var t = actbAirline_curr.value.addslashes();
			var plen = actbAirline_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbAirline_self.actbAirline_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbAirline_self.actbAirline_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbAirline_generate(){
		if (document.getElementById('tat_table')){ actbAirline_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbAirline_kwcount == 0){
			actbAirline_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbAirline_curr) + actbAirline_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbAirline_curr) + "px";
		a.style.backgroundColor=actbAirline_self.actbAirline_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbAirline_self.actbAirline_mouse){
			a.onmouseout = actbAirline_table_unfocus;
			a.onmouseover = actbAirline_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbAirline_self.actbAirline_keywords.length;i++){
			if (actbAirline_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbAirline_tomake){
					r.style.backgroundColor = actbAirline_self.actbAirline_hColor;
					first = false;
					actbAirline_pos = counter;
				}else if(actbAirline_pre == i){
					r.style.backgroundColor = actbAirline_self.actbAirline_hColor;
					first = false;
					actbAirline_pos = counter;
				}else{
					r.style.backgroundColor = actbAirline_self.actbAirline_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbAirline_self.actbAirline_textColor;
				c.style.fontFamily = actbAirline_self.actbAirline_fFamily;
				c.style.fontSize = actbAirline_self.actbAirline_fSize;
				c.innerHTML = actbAirline_parse(actbAirline_self.actbAirline_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbAirline_self.actbAirline_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbAirline_mouseclick;
					c.onmouseover = actbAirline_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbAirline_self.actbAirline_lim && j < actbAirline_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbAirline_self.actbAirline_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbAirline_self.actbAirline_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbAirline_self.actbAirline_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbAirline_self.actbAirline_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbAirline_mouse_down;
				}
				break;
			}
		}
		actbAirline_rangeu = 1;
		actbAirline_ranged = j-1;
		actbAirline_display = true;
		if (actbAirline_pos <= 0) actbAirline_pos = 1;
	}
	function actbAirline_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbAirline_curr) + actbAirline_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbAirline_curr) + "px";
		a.style.backgroundColor=actbAirline_self.actbAirline_bgColor;
		a.id = 'tat_table';
		if (actbAirline_self.actbAirline_mouse){
			a.onmouseout= actbAirline_table_unfocus;
			a.onmouseover=actbAirline_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbAirline_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbAirline_self.actbAirline_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbAirline_self.actbAirline_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbAirline_self.actbAirline_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbAirline_self.actbAirline_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbAirline_mouse_up;
			}
		}
		for (i=0;i<actbAirline_self.actbAirline_keywords.length;i++){
			if (actbAirline_bool[i]){
				if (j >= actbAirline_rangeu && j <= actbAirline_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbAirline_self.actbAirline_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbAirline_self.actbAirline_textColor;
					c.style.fontFamily = actbAirline_self.actbAirline_fFamily;
					c.style.fontSize = actbAirline_self.actbAirline_fSize;
					c.innerHTML = actbAirline_parse(actbAirline_self.actbAirline_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbAirline_self.actbAirline_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbAirline_mouseclick;
						c.onmouseover = actbAirline_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbAirline_ranged) break;
		}
		if (j-1 < actbAirline_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbAirline_self.actbAirline_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbAirline_self.actbAirline_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbAirline_self.actbAirline_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbAirline_self.actbAirline_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbAirline_mouse_down;
			}
		}
	}
	function actbAirline_goup(){
		if (!actbAirline_display) return;
		if (actbAirline_pos == 1) return;
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_bgColor;
		actbAirline_pos--;
		if (actbAirline_pos < actbAirline_rangeu) actbAirline_moveup();
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_hColor;
		if (actbAirline_toid) clearTimeout(actbAirline_toid);
		if (actbAirline_self.actbAirline_timeOut > 0) actbAirline_toid = setTimeout(function(){actbAirline_mouse_on_list=0;actbAirline_removedisp();},actbAirline_self.actbAirline_timeOut);
	}
	function actbAirline_godown(){
		if (!actbAirline_display) return;
		if (actbAirline_pos == actbAirline_total) return;
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_bgColor;
		actbAirline_pos++;
		if (actbAirline_pos > actbAirline_ranged) actbAirline_movedown();
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_hColor;
		if (actbAirline_toid) clearTimeout(actbAirline_toid);
		if (actbAirline_self.actbAirline_timeOut > 0) actbAirline_toid = setTimeout(function(){actbAirline_mouse_on_list=0;actbAirline_removedisp();},actbAirline_self.actbAirline_timeOut);
	}
	function actbAirline_movedown(){
		actbAirline_rangeu++;
		actbAirline_ranged++;
		actbAirline_remake();
	}
	function actbAirline_moveup(){
		actbAirline_rangeu--;
		actbAirline_ranged--;
		actbAirline_remake();
	}

	/* Mouse */
	function actbAirline_mouse_down(){
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_bgColor;
		actbAirline_pos++;
		actbAirline_movedown();
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_hColor;
		actbAirline_curr.focus();
		actbAirline_mouse_on_list = 0;
		if (actbAirline_toid) clearTimeout(actbAirline_toid);
		if (actbAirline_self.actbAirline_timeOut > 0) actbAirline_toid = setTimeout(function(){actbAirline_mouse_on_list=0;actbAirline_removedisp();},actbAirline_self.actbAirline_timeOut);
	}
	function actbAirline_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_bgColor;
		actbAirline_pos--;
		actbAirline_moveup();
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_hColor;
		actbAirline_curr.focus();
		actbAirline_mouse_on_list = 0;
		if (actbAirline_toid) clearTimeout(actbAirline_toid);
		if (actbAirline_self.actbAirline_timeOut > 0) actbAirline_toid = setTimeout(function(){actbAirline_mouse_on_list=0;actbAirline_removedisp();},actbAirline_self.actbAirline_timeOut);
	}
	function actbAirline_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbAirline_display) return;
		actbAirline_mouse_on_list = 0;
		actbAirline_pos = this.getAttribute('pos');
		actbAirline_penter();
	}
	function actbAirline_table_focus(){
		actbAirline_mouse_on_list = 1;
	}
	function actbAirline_table_unfocus(){
		actbAirline_mouse_on_list = 0;
		if (actbAirline_toid) clearTimeout(actbAirline_toid);
		if (actbAirline_self.actbAirline_timeOut > 0) actbAirline_toid = setTimeout(function(){actbAirline_mouse_on_list = 0;actbAirline_removedisp();},actbAirline_self.actbAirline_timeOut);
	}
	function actbAirline_table_highlight(){
		actbAirline_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_bgColor;
		actbAirline_pos = this.getAttribute('pos');
		while (actbAirline_pos < actbAirline_rangeu) actbAirline_moveup();
		while (actbAirline_pos > actbAirline_ranged) actbAirline_movedown();
		document.getElementById('tat_tr'+actbAirline_pos).style.backgroundColor = actbAirline_self.actbAirline_hColor;
		if (actbAirline_toid) clearTimeout(actbAirline_toid);
		if (actbAirline_self.actbAirline_timeOut > 0) actbAirline_toid = setTimeout(function(){actbAirline_mouse_on_list = 0;actbAirline_removedisp();},actbAirline_self.actbAirline_timeOut);
	}
	/* ---- */

	function actbAirline_insertword(a){
		if (actbAirline_self.actbAirline_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbAirline_delimwords.length;i++){
				if (actbAirline_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbAirline_delimwords[i].length;++j){
						if (actbAirline_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbAirline_delimwords[i].length-1;j>=0;--j){
						if (actbAirline_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbAirline_delimwords[i];
				}
				if (i != actbAirline_delimwords.length - 1){
					str += actbAirline_delimchar[i];
				}
			}
			actbAirline_curr.value = str;
			setCaret(actbAirline_curr,l);
		}else{
			actbAirline_curr.value = a;
		}
		actbAirline_mouse_on_list = 0;
		actbAirline_removedisp();
	}
	function actbAirline_penter(){
		if (!actbAirline_display) return;
		actbAirline_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbAirline_self.actbAirline_keywords.length;i++){
			if (actbAirline_bool[i]) c++;
			if (c == actbAirline_pos){
				word = actbAirline_self.actbAirline_keywords[i];
				break;
			}
		}
		actbAirline_insertword(word);
		l = getCaretStart(actbAirline_curr);
	}
	function actbAirline_removedisp(){
		if (actbAirline_mouse_on_list==0){
			actbAirline_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbAirline_toid) clearTimeout(actbAirline_toid);
		}
	}
	function actbAirline_keypress(e){
		if (actbAirline_caretmove) stopEvent(e);
		return !actbAirline_caretmove;
	}
	function actbAirline_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbAirline_curr);
		actbAirline_caretmove = 0;
		switch (a){
			case 38:
				actbAirline_goup();
				actbAirline_caretmove = 1;
				return false;
				break;
			case 40:
				actbAirline_godown();
				actbAirline_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbAirline_display){
					actbAirline_caretmove = 1;
					actbAirline_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbAirline_tocomplete(a)},50);
				break;
		}
	}

	function actbAirline_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbAirline_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbAirline_self.actbAirline_keywords.length;i++){
				if (actbAirline_bool[i]) c++;
				if (c == actbAirline_pos){
					word = i;
					break;
				}
			}
			actbAirline_pre = word;
		}else{ actbAirline_pre = -1};
		
		if (actbAirline_curr.value == ''){
			actbAirline_mouse_on_list = 0;
			actbAirline_removedisp();
			return;
		}
		if (actbAirline_self.actbAirline_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbAirline_curr);
			caret_pos_end = getCaretEnd(actbAirline_curr);
			
			delim_split = '';
			for (i=0;i<actbAirline_self.actbAirline_delimiter.length;i++){
				delim_split += actbAirline_self.actbAirline_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbAirline_delimwords = new Array();
			actbAirline_delimwords[0] = '';
			for (i=0,j=actbAirline_curr.value.length;i<actbAirline_curr.value.length;i++,j--){
				if (actbAirline_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbAirline_curr.value.substr(i,j).match(delim_split_rx);
					actbAirline_delimchar[c] = ma[1];
					c++;
					actbAirline_delimwords[c] = '';
				}else{
					actbAirline_delimwords[c] += actbAirline_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbAirline_cdelimword = -1;
			for (i=0;i<actbAirline_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbAirline_delimwords[i].length){
					actbAirline_cdelimword = i;
				}
				l+=actbAirline_delimwords[i].length + 1;
			}
			var ot = actbAirline_delimwords[actbAirline_cdelimword]; 
			var t = actbAirline_delimwords[actbAirline_cdelimword].addslashes();
		}else{
			var ot = actbAirline_curr.value;
			var t = actbAirline_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbAirline_mouse_on_list = 0;
			actbAirline_removedisp();
		}
		if (ot.length < actbAirline_self.actbAirline_startcheck) return this;
		if (actbAirline_self.actbAirline_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbAirline_total = 0;
		actbAirline_tomake = false;
		actbAirline_kwcount = 0;
		for (i=0;i<actbAirline_self.actbAirline_keywords.length;i++){
			actbAirline_bool[i] = false;
			if (re.test(actbAirline_self.actbAirline_keywords[i])){
				actbAirline_total++;
				actbAirline_bool[i] = true;
				actbAirline_kwcount++;
				if (actbAirline_pre == i) actbAirline_tomake = true;
			}
		}

		if (actbAirline_toid) clearTimeout(actbAirline_toid);
		if (actbAirline_self.actbAirline_timeOut > 0) actbAirline_toid = setTimeout(function(){actbAirline_mouse_on_list = 0;actbAirline_removedisp();},actbAirline_self.actbAirline_timeOut);
		actbAirline_generate();
	}
	return this;
}