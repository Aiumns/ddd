﻿// JScript File
function actbConsigneeAddress(obj,ca){
	/* ---- Public Variables ---- */
	this.actbConsigneeAddress_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbConsigneeAddress_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbConsigneeAddress_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbConsigneeAddress_mouse = true; // Enable Mouse Support
	this.actbConsigneeAddress_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbConsigneeAddress_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbConsigneeAddress_bgColor = '#F1F0F0';
	this.actbConsigneeAddress_textColor = '#D60000';
	this.actbConsigneeAddress_hColor = '#FFFFFF';
	this.actbConsigneeAddress_fFamily = 'Verdana';
	this.actbConsigneeAddress_fSize = '11px';
	this.actbConsigneeAddress_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbConsigneeAddress_delimwords = new Array();
	var actbConsigneeAddress_cdelimword = 0;
	var actbConsigneeAddress_delimchar = new Array();
	var actbConsigneeAddress_display = false;
	var actbConsigneeAddress_pos = 0;
	var actbConsigneeAddress_total = 0;
	var actbConsigneeAddress_curr = null;
	var actbConsigneeAddress_rangeu = 0;
	var actbConsigneeAddress_ranged = 0;
	var actbConsigneeAddress_bool = new Array();
	var actbConsigneeAddress_pre = 0;
	var actbConsigneeAddress_toid;
	var actbConsigneeAddress_tomake = false;
	var actbConsigneeAddress_getpre = "";
	var actbConsigneeAddress_mouse_on_list = 1;
	var actbConsigneeAddress_kwcount = 0;
	var actbConsigneeAddress_caretmove = false;
	this.actbConsigneeAddress_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbConsigneeAddress_keywords = ca;
	var actbConsigneeAddress_self = this;

	actbConsigneeAddress_curr = obj;
	
	addEvent(actbConsigneeAddress_curr,"focus",actbConsigneeAddress_setup);
	function actbConsigneeAddress_setup(){
		addEvent(document,"keydown",actbConsigneeAddress_checkkey);
		addEvent(actbConsigneeAddress_curr,"blur",actbConsigneeAddress_clear);
		addEvent(document,"keypress",actbConsigneeAddress_keypress);
	}

	function actbConsigneeAddress_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbConsigneeAddress_checkkey);
		removeEvent(actbConsigneeAddress_curr,"blur",actbConsigneeAddress_clear);
		removeEvent(document,"keypress",actbConsigneeAddress_keypress);
		actbConsigneeAddress_removedisp();
	}
	function actbConsigneeAddress_parse(n){
		if (actbConsigneeAddress_self.actbConsigneeAddress_delimiter.length > 0){
			var t = actbConsigneeAddress_delimwords[actbConsigneeAddress_cdelimword].addslashes();
			var plen = actbConsigneeAddress_delimwords[actbConsigneeAddress_cdelimword].length;
		}else{
			var t = actbConsigneeAddress_curr.value.addslashes();
			var plen = actbConsigneeAddress_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbConsigneeAddress_self.actbConsigneeAddress_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbConsigneeAddress_self.actbConsigneeAddress_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbConsigneeAddress_generate(){
		if (document.getElementById('tat_table')){ actbConsigneeAddress_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbConsigneeAddress_kwcount == 0){
			actbConsigneeAddress_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbConsigneeAddress_curr) + actbConsigneeAddress_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbConsigneeAddress_curr) + "px";
		a.style.backgroundColor=actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbConsigneeAddress_self.actbConsigneeAddress_mouse){
			a.onmouseout = actbConsigneeAddress_table_unfocus;
			a.onmouseover = actbConsigneeAddress_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbConsigneeAddress_self.actbConsigneeAddress_keywords.length;i++){
			if (actbConsigneeAddress_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbConsigneeAddress_tomake){
					r.style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_hColor;
					first = false;
					actbConsigneeAddress_pos = counter;
				}else if(actbConsigneeAddress_pre == i){
					r.style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_hColor;
					first = false;
					actbConsigneeAddress_pos = counter;
				}else{
					r.style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbConsigneeAddress_self.actbConsigneeAddress_textColor;
				c.style.fontFamily = actbConsigneeAddress_self.actbConsigneeAddress_fFamily;
				c.style.fontSize = actbConsigneeAddress_self.actbConsigneeAddress_fSize;
				c.innerHTML = actbConsigneeAddress_parse(actbConsigneeAddress_self.actbConsigneeAddress_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbConsigneeAddress_self.actbConsigneeAddress_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbConsigneeAddress_mouseclick;
					c.onmouseover = actbConsigneeAddress_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbConsigneeAddress_self.actbConsigneeAddress_lim && j < actbConsigneeAddress_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbConsigneeAddress_self.actbConsigneeAddress_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbConsigneeAddress_self.actbConsigneeAddress_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbConsigneeAddress_self.actbConsigneeAddress_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbConsigneeAddress_mouse_down;
				}
				break;
			}
		}
		actbConsigneeAddress_rangeu = 1;
		actbConsigneeAddress_ranged = j-1;
		actbConsigneeAddress_display = true;
		if (actbConsigneeAddress_pos <= 0) actbConsigneeAddress_pos = 1;
	}
	function actbConsigneeAddress_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbConsigneeAddress_curr) + actbConsigneeAddress_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbConsigneeAddress_curr) + "px";
		a.style.backgroundColor=actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
		a.id = 'tat_table';
		if (actbConsigneeAddress_self.actbConsigneeAddress_mouse){
			a.onmouseout= actbConsigneeAddress_table_unfocus;
			a.onmouseover=actbConsigneeAddress_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbConsigneeAddress_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbConsigneeAddress_self.actbConsigneeAddress_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbConsigneeAddress_self.actbConsigneeAddress_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbConsigneeAddress_self.actbConsigneeAddress_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbConsigneeAddress_mouse_up;
			}
		}
		for (i=0;i<actbConsigneeAddress_self.actbConsigneeAddress_keywords.length;i++){
			if (actbConsigneeAddress_bool[i]){
				if (j >= actbConsigneeAddress_rangeu && j <= actbConsigneeAddress_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbConsigneeAddress_self.actbConsigneeAddress_textColor;
					c.style.fontFamily = actbConsigneeAddress_self.actbConsigneeAddress_fFamily;
					c.style.fontSize = actbConsigneeAddress_self.actbConsigneeAddress_fSize;
					c.innerHTML = actbConsigneeAddress_parse(actbConsigneeAddress_self.actbConsigneeAddress_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbConsigneeAddress_self.actbConsigneeAddress_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbConsigneeAddress_mouseclick;
						c.onmouseover = actbConsigneeAddress_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbConsigneeAddress_ranged) break;
		}
		if (j-1 < actbConsigneeAddress_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbConsigneeAddress_self.actbConsigneeAddress_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbConsigneeAddress_self.actbConsigneeAddress_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbConsigneeAddress_self.actbConsigneeAddress_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbConsigneeAddress_mouse_down;
			}
		}
	}
	function actbConsigneeAddress_goup(){
		if (!actbConsigneeAddress_display) return;
		if (actbConsigneeAddress_pos == 1) return;
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
		actbConsigneeAddress_pos--;
		if (actbConsigneeAddress_pos < actbConsigneeAddress_rangeu) actbConsigneeAddress_moveup();
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_hColor;
		if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		if (actbConsigneeAddress_self.actbConsigneeAddress_timeOut > 0) actbConsigneeAddress_toid = setTimeout(function(){actbConsigneeAddress_mouse_on_list=0;actbConsigneeAddress_removedisp();},actbConsigneeAddress_self.actbConsigneeAddress_timeOut);
	}
	function actbConsigneeAddress_godown(){
		if (!actbConsigneeAddress_display) return;
		if (actbConsigneeAddress_pos == actbConsigneeAddress_total) return;
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
		actbConsigneeAddress_pos++;
		if (actbConsigneeAddress_pos > actbConsigneeAddress_ranged) actbConsigneeAddress_movedown();
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_hColor;
		if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		if (actbConsigneeAddress_self.actbConsigneeAddress_timeOut > 0) actbConsigneeAddress_toid = setTimeout(function(){actbConsigneeAddress_mouse_on_list=0;actbConsigneeAddress_removedisp();},actbConsigneeAddress_self.actbConsigneeAddress_timeOut);
	}
	function actbConsigneeAddress_movedown(){
		actbConsigneeAddress_rangeu++;
		actbConsigneeAddress_ranged++;
		actbConsigneeAddress_remake();
	}
	function actbConsigneeAddress_moveup(){
		actbConsigneeAddress_rangeu--;
		actbConsigneeAddress_ranged--;
		actbConsigneeAddress_remake();
	}

	/* Mouse */
	function actbConsigneeAddress_mouse_down(){
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
		actbConsigneeAddress_pos++;
		actbConsigneeAddress_movedown();
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_hColor;
		actbConsigneeAddress_curr.focus();
		actbConsigneeAddress_mouse_on_list = 0;
		if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		if (actbConsigneeAddress_self.actbConsigneeAddress_timeOut > 0) actbConsigneeAddress_toid = setTimeout(function(){actbConsigneeAddress_mouse_on_list=0;actbConsigneeAddress_removedisp();},actbConsigneeAddress_self.actbConsigneeAddress_timeOut);
	}
	function actbConsigneeAddress_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
		actbConsigneeAddress_pos--;
		actbConsigneeAddress_moveup();
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_hColor;
		actbConsigneeAddress_curr.focus();
		actbConsigneeAddress_mouse_on_list = 0;
		if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		if (actbConsigneeAddress_self.actbConsigneeAddress_timeOut > 0) actbConsigneeAddress_toid = setTimeout(function(){actbConsigneeAddress_mouse_on_list=0;actbConsigneeAddress_removedisp();},actbConsigneeAddress_self.actbConsigneeAddress_timeOut);
	}
	function actbConsigneeAddress_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbConsigneeAddress_display) return;
		actbConsigneeAddress_mouse_on_list = 0;
		actbConsigneeAddress_pos = this.getAttribute('pos');
		actbConsigneeAddress_penter();
	}
	function actbConsigneeAddress_table_focus(){
		actbConsigneeAddress_mouse_on_list = 1;
	}
	function actbConsigneeAddress_table_unfocus(){
		actbConsigneeAddress_mouse_on_list = 0;
		if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		if (actbConsigneeAddress_self.actbConsigneeAddress_timeOut > 0) actbConsigneeAddress_toid = setTimeout(function(){actbConsigneeAddress_mouse_on_list = 0;actbConsigneeAddress_removedisp();},actbConsigneeAddress_self.actbConsigneeAddress_timeOut);
	}
	function actbConsigneeAddress_table_highlight(){
		actbConsigneeAddress_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_bgColor;
		actbConsigneeAddress_pos = this.getAttribute('pos');
		while (actbConsigneeAddress_pos < actbConsigneeAddress_rangeu) actbConsigneeAddress_moveup();
		while (actbConsigneeAddress_pos > actbConsigneeAddress_ranged) actbConsigneeAddress_movedown();
		document.getElementById('tat_tr'+actbConsigneeAddress_pos).style.backgroundColor = actbConsigneeAddress_self.actbConsigneeAddress_hColor;
		if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		if (actbConsigneeAddress_self.actbConsigneeAddress_timeOut > 0) actbConsigneeAddress_toid = setTimeout(function(){actbConsigneeAddress_mouse_on_list = 0;actbConsigneeAddress_removedisp();},actbConsigneeAddress_self.actbConsigneeAddress_timeOut);
	}
	/* ---- */

	function actbConsigneeAddress_insertword(a){
		if (actbConsigneeAddress_self.actbConsigneeAddress_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbConsigneeAddress_delimwords.length;i++){
				if (actbConsigneeAddress_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbConsigneeAddress_delimwords[i].length;++j){
						if (actbConsigneeAddress_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbConsigneeAddress_delimwords[i].length-1;j>=0;--j){
						if (actbConsigneeAddress_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbConsigneeAddress_delimwords[i];
				}
				if (i != actbConsigneeAddress_delimwords.length - 1){
					str += actbConsigneeAddress_delimchar[i];
				}
			}
			actbConsigneeAddress_curr.value = str;
			setCaret(actbConsigneeAddress_curr,l);
		}else{
			actbConsigneeAddress_curr.value = a;
		}
		actbConsigneeAddress_mouse_on_list = 0;
		actbConsigneeAddress_removedisp();
	}
	function actbConsigneeAddress_penter(){
		if (!actbConsigneeAddress_display) return;
		actbConsigneeAddress_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbConsigneeAddress_self.actbConsigneeAddress_keywords.length;i++){
			if (actbConsigneeAddress_bool[i]) c++;
			if (c == actbConsigneeAddress_pos){
				word = actbConsigneeAddress_self.actbConsigneeAddress_keywords[i];
				break;
			}
		}
		actbConsigneeAddress_insertword(word);
		l = getCaretStart(actbConsigneeAddress_curr);
	}
	function actbConsigneeAddress_removedisp(){
		if (actbConsigneeAddress_mouse_on_list==0){
			actbConsigneeAddress_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		}
	}
	function actbConsigneeAddress_keypress(e){
		if (actbConsigneeAddress_caretmove) stopEvent(e);
		return !actbConsigneeAddress_caretmove;
	}
	function actbConsigneeAddress_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbConsigneeAddress_curr);
		actbConsigneeAddress_caretmove = 0;
		switch (a){
			case 38:
				actbConsigneeAddress_goup();
				actbConsigneeAddress_caretmove = 1;
				return false;
				break;
			case 40:
				actbConsigneeAddress_godown();
				actbConsigneeAddress_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbConsigneeAddress_display){
					actbConsigneeAddress_caretmove = 1;
					actbConsigneeAddress_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbConsigneeAddress_tocomplete(a)},50);
				break;
		}
	}

	function actbConsigneeAddress_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbConsigneeAddress_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbConsigneeAddress_self.actbConsigneeAddress_keywords.length;i++){
				if (actbConsigneeAddress_bool[i]) c++;
				if (c == actbConsigneeAddress_pos){
					word = i;
					break;
				}
			}
			actbConsigneeAddress_pre = word;
		}else{ actbConsigneeAddress_pre = -1};
		
		if (actbConsigneeAddress_curr.value == ''){
			actbConsigneeAddress_mouse_on_list = 0;
			actbConsigneeAddress_removedisp();
			return;
		}
		if (actbConsigneeAddress_self.actbConsigneeAddress_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbConsigneeAddress_curr);
			caret_pos_end = getCaretEnd(actbConsigneeAddress_curr);
			
			delim_split = '';
			for (i=0;i<actbConsigneeAddress_self.actbConsigneeAddress_delimiter.length;i++){
				delim_split += actbConsigneeAddress_self.actbConsigneeAddress_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbConsigneeAddress_delimwords = new Array();
			actbConsigneeAddress_delimwords[0] = '';
			for (i=0,j=actbConsigneeAddress_curr.value.length;i<actbConsigneeAddress_curr.value.length;i++,j--){
				if (actbConsigneeAddress_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbConsigneeAddress_curr.value.substr(i,j).match(delim_split_rx);
					actbConsigneeAddress_delimchar[c] = ma[1];
					c++;
					actbConsigneeAddress_delimwords[c] = '';
				}else{
					actbConsigneeAddress_delimwords[c] += actbConsigneeAddress_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbConsigneeAddress_cdelimword = -1;
			for (i=0;i<actbConsigneeAddress_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbConsigneeAddress_delimwords[i].length){
					actbConsigneeAddress_cdelimword = i;
				}
				l+=actbConsigneeAddress_delimwords[i].length + 1;
			}
			var ot = actbConsigneeAddress_delimwords[actbConsigneeAddress_cdelimword]; 
			var t = actbConsigneeAddress_delimwords[actbConsigneeAddress_cdelimword].addslashes();
		}else{
			var ot = actbConsigneeAddress_curr.value;
			var t = actbConsigneeAddress_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbConsigneeAddress_mouse_on_list = 0;
			actbConsigneeAddress_removedisp();
		}
		if (ot.length < actbConsigneeAddress_self.actbConsigneeAddress_startcheck) return this;
		if (actbConsigneeAddress_self.actbConsigneeAddress_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbConsigneeAddress_total = 0;
		actbConsigneeAddress_tomake = false;
		actbConsigneeAddress_kwcount = 0;
		for (i=0;i<actbConsigneeAddress_self.actbConsigneeAddress_keywords.length;i++){
			actbConsigneeAddress_bool[i] = false;
			if (re.test(actbConsigneeAddress_self.actbConsigneeAddress_keywords[i])){
				actbConsigneeAddress_total++;
				actbConsigneeAddress_bool[i] = true;
				actbConsigneeAddress_kwcount++;
				if (actbConsigneeAddress_pre == i) actbConsigneeAddress_tomake = true;
			}
		}

		if (actbConsigneeAddress_toid) clearTimeout(actbConsigneeAddress_toid);
		if (actbConsigneeAddress_self.actbConsigneeAddress_timeOut > 0) actbConsigneeAddress_toid = setTimeout(function(){actbConsigneeAddress_mouse_on_list = 0;actbConsigneeAddress_removedisp();},actbConsigneeAddress_self.actbConsigneeAddress_timeOut);
		actbConsigneeAddress_generate();
	}
	return this;
}
