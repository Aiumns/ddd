﻿// JScript File
function actbShipperAddress(obj,ca){
	/* ---- Public Variables ---- */
	this.actbShipperAddress_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbShipperAddress_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbShipperAddress_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbShipperAddress_mouse = true; // Enable Mouse Support
	this.actbShipperAddress_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbShipperAddress_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbShipperAddress_bgColor = '#F1F0F0';
	this.actbShipperAddress_textColor = '#D60000';
	this.actbShipperAddress_hColor = '#FFFFFF';
	this.actbShipperAddress_fFamily = 'Verdana';
	this.actbShipperAddress_fSize = '11px';
	this.actbShipperAddress_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbShipperAddress_delimwords = new Array();
	var actbShipperAddress_cdelimword = 0;
	var actbShipperAddress_delimchar = new Array();
	var actbShipperAddress_display = false;
	var actbShipperAddress_pos = 0;
	var actbShipperAddress_total = 0;
	var actbShipperAddress_curr = null;
	var actbShipperAddress_rangeu = 0;
	var actbShipperAddress_ranged = 0;
	var actbShipperAddress_bool = new Array();
	var actbShipperAddress_pre = 0;
	var actbShipperAddress_toid;
	var actbShipperAddress_tomake = false;
	var actbShipperAddress_getpre = "";
	var actbShipperAddress_mouse_on_list = 1;
	var actbShipperAddress_kwcount = 0;
	var actbShipperAddress_caretmove = false;
	this.actbShipperAddress_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbShipperAddress_keywords = ca;
	var actbShipperAddress_self = this;

	actbShipperAddress_curr = obj;
	
	addEvent(actbShipperAddress_curr,"focus",actbShipperAddress_setup);
	function actbShipperAddress_setup(){
		addEvent(document,"keydown",actbShipperAddress_checkkey);
		addEvent(actbShipperAddress_curr,"blur",actbShipperAddress_clear);
		addEvent(document,"keypress",actbShipperAddress_keypress);
	}

	function actbShipperAddress_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbShipperAddress_checkkey);
		removeEvent(actbShipperAddress_curr,"blur",actbShipperAddress_clear);
		removeEvent(document,"keypress",actbShipperAddress_keypress);
		actbShipperAddress_removedisp();
	}
	function actbShipperAddress_parse(n){
		if (actbShipperAddress_self.actbShipperAddress_delimiter.length > 0){
			var t = actbShipperAddress_delimwords[actbShipperAddress_cdelimword].addslashes();
			var plen = actbShipperAddress_delimwords[actbShipperAddress_cdelimword].length;
		}else{
			var t = actbShipperAddress_curr.value.addslashes();
			var plen = actbShipperAddress_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbShipperAddress_self.actbShipperAddress_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbShipperAddress_self.actbShipperAddress_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbShipperAddress_generate(){
		if (document.getElementById('tat_table')){ actbShipperAddress_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbShipperAddress_kwcount == 0){
			actbShipperAddress_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbShipperAddress_curr) + actbShipperAddress_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbShipperAddress_curr) + "px";
		a.style.backgroundColor=actbShipperAddress_self.actbShipperAddress_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbShipperAddress_self.actbShipperAddress_mouse){
			a.onmouseout = actbShipperAddress_table_unfocus;
			a.onmouseover = actbShipperAddress_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbShipperAddress_self.actbShipperAddress_keywords.length;i++){
			if (actbShipperAddress_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbShipperAddress_tomake){
					r.style.backgroundColor = actbShipperAddress_self.actbShipperAddress_hColor;
					first = false;
					actbShipperAddress_pos = counter;
				}else if(actbShipperAddress_pre == i){
					r.style.backgroundColor = actbShipperAddress_self.actbShipperAddress_hColor;
					first = false;
					actbShipperAddress_pos = counter;
				}else{
					r.style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbShipperAddress_self.actbShipperAddress_textColor;
				c.style.fontFamily = actbShipperAddress_self.actbShipperAddress_fFamily;
				c.style.fontSize = actbShipperAddress_self.actbShipperAddress_fSize;
				c.innerHTML = actbShipperAddress_parse(actbShipperAddress_self.actbShipperAddress_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbShipperAddress_self.actbShipperAddress_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbShipperAddress_mouseclick;
					c.onmouseover = actbShipperAddress_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbShipperAddress_self.actbShipperAddress_lim && j < actbShipperAddress_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbShipperAddress_self.actbShipperAddress_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbShipperAddress_self.actbShipperAddress_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbShipperAddress_self.actbShipperAddress_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbShipperAddress_mouse_down;
				}
				break;
			}
		}
		actbShipperAddress_rangeu = 1;
		actbShipperAddress_ranged = j-1;
		actbShipperAddress_display = true;
		if (actbShipperAddress_pos <= 0) actbShipperAddress_pos = 1;
	}
	function actbShipperAddress_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbShipperAddress_curr) + actbShipperAddress_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbShipperAddress_curr) + "px";
		a.style.backgroundColor=actbShipperAddress_self.actbShipperAddress_bgColor;
		a.id = 'tat_table';
		if (actbShipperAddress_self.actbShipperAddress_mouse){
			a.onmouseout= actbShipperAddress_table_unfocus;
			a.onmouseover=actbShipperAddress_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbShipperAddress_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbShipperAddress_self.actbShipperAddress_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbShipperAddress_self.actbShipperAddress_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbShipperAddress_self.actbShipperAddress_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbShipperAddress_mouse_up;
			}
		}
		for (i=0;i<actbShipperAddress_self.actbShipperAddress_keywords.length;i++){
			if (actbShipperAddress_bool[i]){
				if (j >= actbShipperAddress_rangeu && j <= actbShipperAddress_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbShipperAddress_self.actbShipperAddress_textColor;
					c.style.fontFamily = actbShipperAddress_self.actbShipperAddress_fFamily;
					c.style.fontSize = actbShipperAddress_self.actbShipperAddress_fSize;
					c.innerHTML = actbShipperAddress_parse(actbShipperAddress_self.actbShipperAddress_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbShipperAddress_self.actbShipperAddress_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbShipperAddress_mouseclick;
						c.onmouseover = actbShipperAddress_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbShipperAddress_ranged) break;
		}
		if (j-1 < actbShipperAddress_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbShipperAddress_self.actbShipperAddress_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbShipperAddress_self.actbShipperAddress_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbShipperAddress_self.actbShipperAddress_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbShipperAddress_mouse_down;
			}
		}
	}
	function actbShipperAddress_goup(){
		if (!actbShipperAddress_display) return;
		if (actbShipperAddress_pos == 1) return;
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
		actbShipperAddress_pos--;
		if (actbShipperAddress_pos < actbShipperAddress_rangeu) actbShipperAddress_moveup();
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_hColor;
		if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		if (actbShipperAddress_self.actbShipperAddress_timeOut > 0) actbShipperAddress_toid = setTimeout(function(){actbShipperAddress_mouse_on_list=0;actbShipperAddress_removedisp();},actbShipperAddress_self.actbShipperAddress_timeOut);
	}
	function actbShipperAddress_godown(){
		if (!actbShipperAddress_display) return;
		if (actbShipperAddress_pos == actbShipperAddress_total) return;
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
		actbShipperAddress_pos++;
		if (actbShipperAddress_pos > actbShipperAddress_ranged) actbShipperAddress_movedown();
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_hColor;
		if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		if (actbShipperAddress_self.actbShipperAddress_timeOut > 0) actbShipperAddress_toid = setTimeout(function(){actbShipperAddress_mouse_on_list=0;actbShipperAddress_removedisp();},actbShipperAddress_self.actbShipperAddress_timeOut);
	}
	function actbShipperAddress_movedown(){
		actbShipperAddress_rangeu++;
		actbShipperAddress_ranged++;
		actbShipperAddress_remake();
	}
	function actbShipperAddress_moveup(){
		actbShipperAddress_rangeu--;
		actbShipperAddress_ranged--;
		actbShipperAddress_remake();
	}

	/* Mouse */
	function actbShipperAddress_mouse_down(){
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
		actbShipperAddress_pos++;
		actbShipperAddress_movedown();
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_hColor;
		actbShipperAddress_curr.focus();
		actbShipperAddress_mouse_on_list = 0;
		if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		if (actbShipperAddress_self.actbShipperAddress_timeOut > 0) actbShipperAddress_toid = setTimeout(function(){actbShipperAddress_mouse_on_list=0;actbShipperAddress_removedisp();},actbShipperAddress_self.actbShipperAddress_timeOut);
	}
	function actbShipperAddress_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
		actbShipperAddress_pos--;
		actbShipperAddress_moveup();
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_hColor;
		actbShipperAddress_curr.focus();
		actbShipperAddress_mouse_on_list = 0;
		if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		if (actbShipperAddress_self.actbShipperAddress_timeOut > 0) actbShipperAddress_toid = setTimeout(function(){actbShipperAddress_mouse_on_list=0;actbShipperAddress_removedisp();},actbShipperAddress_self.actbShipperAddress_timeOut);
	}
	function actbShipperAddress_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbShipperAddress_display) return;
		actbShipperAddress_mouse_on_list = 0;
		actbShipperAddress_pos = this.getAttribute('pos');
		actbShipperAddress_penter();
	}
	function actbShipperAddress_table_focus(){
		actbShipperAddress_mouse_on_list = 1;
	}
	function actbShipperAddress_table_unfocus(){
		actbShipperAddress_mouse_on_list = 0;
		if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		if (actbShipperAddress_self.actbShipperAddress_timeOut > 0) actbShipperAddress_toid = setTimeout(function(){actbShipperAddress_mouse_on_list = 0;actbShipperAddress_removedisp();},actbShipperAddress_self.actbShipperAddress_timeOut);
	}
	function actbShipperAddress_table_highlight(){
		actbShipperAddress_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_bgColor;
		actbShipperAddress_pos = this.getAttribute('pos');
		while (actbShipperAddress_pos < actbShipperAddress_rangeu) actbShipperAddress_moveup();
		while (actbShipperAddress_pos > actbShipperAddress_ranged) actbShipperAddress_movedown();
		document.getElementById('tat_tr'+actbShipperAddress_pos).style.backgroundColor = actbShipperAddress_self.actbShipperAddress_hColor;
		if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		if (actbShipperAddress_self.actbShipperAddress_timeOut > 0) actbShipperAddress_toid = setTimeout(function(){actbShipperAddress_mouse_on_list = 0;actbShipperAddress_removedisp();},actbShipperAddress_self.actbShipperAddress_timeOut);
	}
	/* ---- */

	function actbShipperAddress_insertword(a){
		if (actbShipperAddress_self.actbShipperAddress_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbShipperAddress_delimwords.length;i++){
				if (actbShipperAddress_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbShipperAddress_delimwords[i].length;++j){
						if (actbShipperAddress_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbShipperAddress_delimwords[i].length-1;j>=0;--j){
						if (actbShipperAddress_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbShipperAddress_delimwords[i];
				}
				if (i != actbShipperAddress_delimwords.length - 1){
					str += actbShipperAddress_delimchar[i];
				}
			}
			actbShipperAddress_curr.value = str;
			setCaret(actbShipperAddress_curr,l);
		}else{
			actbShipperAddress_curr.value = a;
		}
		actbShipperAddress_mouse_on_list = 0;
		actbShipperAddress_removedisp();
	}
	function actbShipperAddress_penter(){
		if (!actbShipperAddress_display) return;
		actbShipperAddress_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbShipperAddress_self.actbShipperAddress_keywords.length;i++){
			if (actbShipperAddress_bool[i]) c++;
			if (c == actbShipperAddress_pos){
				word = actbShipperAddress_self.actbShipperAddress_keywords[i];
				break;
			}
		}
		actbShipperAddress_insertword(word);
		l = getCaretStart(actbShipperAddress_curr);
	}
	function actbShipperAddress_removedisp(){
		if (actbShipperAddress_mouse_on_list==0){
			actbShipperAddress_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		}
	}
	function actbShipperAddress_keypress(e){
		if (actbShipperAddress_caretmove) stopEvent(e);
		return !actbShipperAddress_caretmove;
	}
	function actbShipperAddress_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbShipperAddress_curr);
		actbShipperAddress_caretmove = 0;
		switch (a){
			case 38:
				actbShipperAddress_goup();
				actbShipperAddress_caretmove = 1;
				return false;
				break;
			case 40:
				actbShipperAddress_godown();
				actbShipperAddress_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbShipperAddress_display){
					actbShipperAddress_caretmove = 1;
					actbShipperAddress_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbShipperAddress_tocomplete(a)},50);
				break;
		}
	}

	function actbShipperAddress_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbShipperAddress_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbShipperAddress_self.actbShipperAddress_keywords.length;i++){
				if (actbShipperAddress_bool[i]) c++;
				if (c == actbShipperAddress_pos){
					word = i;
					break;
				}
			}
			actbShipperAddress_pre = word;
		}else{ actbShipperAddress_pre = -1};
		
		if (actbShipperAddress_curr.value == ''){
			actbShipperAddress_mouse_on_list = 0;
			actbShipperAddress_removedisp();
			return;
		}
		if (actbShipperAddress_self.actbShipperAddress_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbShipperAddress_curr);
			caret_pos_end = getCaretEnd(actbShipperAddress_curr);
			
			delim_split = '';
			for (i=0;i<actbShipperAddress_self.actbShipperAddress_delimiter.length;i++){
				delim_split += actbShipperAddress_self.actbShipperAddress_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbShipperAddress_delimwords = new Array();
			actbShipperAddress_delimwords[0] = '';
			for (i=0,j=actbShipperAddress_curr.value.length;i<actbShipperAddress_curr.value.length;i++,j--){
				if (actbShipperAddress_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbShipperAddress_curr.value.substr(i,j).match(delim_split_rx);
					actbShipperAddress_delimchar[c] = ma[1];
					c++;
					actbShipperAddress_delimwords[c] = '';
				}else{
					actbShipperAddress_delimwords[c] += actbShipperAddress_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbShipperAddress_cdelimword = -1;
			for (i=0;i<actbShipperAddress_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbShipperAddress_delimwords[i].length){
					actbShipperAddress_cdelimword = i;
				}
				l+=actbShipperAddress_delimwords[i].length + 1;
			}
			var ot = actbShipperAddress_delimwords[actbShipperAddress_cdelimword]; 
			var t = actbShipperAddress_delimwords[actbShipperAddress_cdelimword].addslashes();
		}else{
			var ot = actbShipperAddress_curr.value;
			var t = actbShipperAddress_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbShipperAddress_mouse_on_list = 0;
			actbShipperAddress_removedisp();
		}
		if (ot.length < actbShipperAddress_self.actbShipperAddress_startcheck) return this;
		if (actbShipperAddress_self.actbShipperAddress_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbShipperAddress_total = 0;
		actbShipperAddress_tomake = false;
		actbShipperAddress_kwcount = 0;
		for (i=0;i<actbShipperAddress_self.actbShipperAddress_keywords.length;i++){
			actbShipperAddress_bool[i] = false;
			if (re.test(actbShipperAddress_self.actbShipperAddress_keywords[i])){
				actbShipperAddress_total++;
				actbShipperAddress_bool[i] = true;
				actbShipperAddress_kwcount++;
				if (actbShipperAddress_pre == i) actbShipperAddress_tomake = true;
			}
		}

		if (actbShipperAddress_toid) clearTimeout(actbShipperAddress_toid);
		if (actbShipperAddress_self.actbShipperAddress_timeOut > 0) actbShipperAddress_toid = setTimeout(function(){actbShipperAddress_mouse_on_list = 0;actbShipperAddress_removedisp();},actbShipperAddress_self.actbShipperAddress_timeOut);
		actbShipperAddress_generate();
	}
	return this;
}
