/*My Code for hiding all the drop down list..*/
function combosVisible(bool) {
    combos = document.getElementsByTagName('select');
    for (var i = 0; i < combos.length; i++) {
        if (bool) {
            combos[i].style.display = '';
        } else {
            combos[i].style.display = 'none';
        }
    }
}

/* Event Functions */

// Add an event to the obj given
// event_name refers to the event trigger, without the "on", like click or mouseover
// func_name refers to the function callback when event is triggered
function addEvent(obj, event_name, func_name) {
    if (obj.attachEvent) {
        obj.attachEvent("on" + event_name, func_name);
    } else if (obj.addEventListener) {
        obj.addEventListener(event_name, func_name, true);
    } else {
        obj["on" + event_name] = func_name;
    }
}

// Removes an event from the object
function removeEvent(obj, event_name, func_name) {
    if (obj.detachEvent) {
        obj.detachEvent("on" + event_name, func_name);
    } else if (obj.removeEventListener) {
        obj.removeEventListener(event_name, func_name, true);
    } else {
        obj["on" + event_name] = null;
    }
}

// Stop an event from bubbling up the event DOM
function stopEvent(evt) {
    evt || window.event;
    if (evt.stopPropagation) {
        evt.stopPropagation();
        evt.preventDefault();
    } else if (typeof evt.cancelBubble != "undefined") {
        evt.cancelBubble = true;
        evt.returnValue = false;
    }
    return false;
}

// Get the obj that starts the event
function getElement(evt) {
    if (window.event) {
        return window.event.srcElement;
    } else {
        return evt.currentTarget;
    }
}
// Get the obj that triggers off the event
function getTargetElement(evt) {
    if (window.event) {
        return window.event.srcElement;
    } else {
        return evt.target;
    }
}
// For IE only, stops the obj from being selected
function stopSelect(obj) {
    if (typeof obj.onselectstart != 'undefined') {
        addEvent(obj, "selectstart", function () { return false; });
    }
}

/*    Caret Functions     */

// Get the end position of the caret in the object. Note that the obj needs to be in focus first
function getCaretEnd(obj) {
    if (typeof obj.selectionEnd != "undefined") {
        return obj.selectionEnd;
    } else if (document.selection && document.selection.createRange) {
        var M = document.selection.createRange();
        try {
            var Lp = M.duplicate();
            Lp.moveToElementText(obj);
        } catch (e) {
            var Lp = obj.createTextRange();
        }
        Lp.setEndPoint("EndToEnd", M);
        var rb = Lp.text.length;
        if (rb > obj.value.length) {
            return -1;
        }
        return rb;
    }
}
// Get the start position of the caret in the object
function getCaretStart(obj) {
    if (typeof obj.selectionStart != "undefined") {
        return obj.selectionStart;
    } else if (document.selection && document.selection.createRange) {
        var M = document.selection.createRange();
        try {
            var Lp = M.duplicate();
            Lp.moveToElementText(obj);
        } catch (e) {
            var Lp = obj.createTextRange();
        }
        Lp.setEndPoint("EndToStart", M);
        var rb = Lp.text.length;
        if (rb > obj.value.length) {
            return -1;
        }
        return rb;
    }
}
// sets the caret position to l in the object
function setCaret(obj, l) {
    obj.focus();
    if (obj.setSelectionRange) {
        obj.setSelectionRange(l, l);
    } else if (obj.createTextRange) {
        m = obj.createTextRange();
        m.moveStart('character', l);
        m.collapse();
        m.select();
    }
}
// sets the caret selection from s to e in the object
function setSelection(obj, s, e) {
    obj.focus();
    if (obj.setSelectionRange) {
        obj.setSelectionRange(s, e);
    } else if (obj.createTextRange) {
        m = obj.createTextRange();
        m.moveStart('character', s);
        m.moveEnd('character', e);
        m.select();
    }
}

/*    Escape function   */
String.prototype.addslashes = function () {
    return this.replace(/(["\\\.\|\[\]\^\*\+\?\$\(\)])/g, '\\$1');
}
String.prototype.trim = function () {
    return this.replace(/^\s*(\S*(\s+\S+)*)\s*$/, "$1");
};
/* --- Escape --- */

/* Offset position from top of the screen */
function curTop(obj) {
    toreturn = 0;
    while (obj) {
        toreturn += obj.offsetTop;
        obj = obj.offsetParent;
    }
    return toreturn;
}
function curLeft(obj) {
    toreturn = 0;
    while (obj) {
        toreturn += obj.offsetLeft;
        obj = obj.offsetParent;
    }
    return toreturn;
}
/* ------ End of Offset function ------- */

/* Types Function */

// is a given input a number?
function isNumber(a) {
    return typeof a == 'number' && isFinite(a);
}

/* Object Functions */

function replaceHTML(obj, text) {
    while (el = obj.childNodes[0]) {
        obj.removeChild(el);
    };
    obj.appendChild(document.createTextNode(text));
}
function isCharInput(field, event) {
return true;
    var key, keyChar;
    if (window.event)
        key = window.event.keyCode;
    else if (event)
        key = event.which;
    else
        return false;
    // Check for special characters like backspace

    if (key == null || key == 0 || key == 8 || key == 9 || key == 13 || key == 16 || key == 20 || key == 27 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40) {
        return false;
    }
    // Check to see if it's a number
    keyChar = String.fromCharCode(key);

    if (key < 65) {

        field.value = field.value.substring(0, field.value.length - 1);
        return false;
    }
    else if (key > 90) {
        field.value = field.value.substring(0, field.value.length - 1);
        return false;
    }
    else {
        window.status = "";
        return true;
    }
}
//Number Only
function blockNonNumbers(obj, e, allowDecimal, allowNegative) {
    var key;
    var isCtrl = false;
    var keychar;
    var reg;


    if (window.event) {
        key = e.keyCode;
        isCtrl = window.event.ctrlKey
    }
    else if (e.which) {
        key = e.which;
        isCtrl = e.ctrlKey;
    }

    if (isNaN(key)) return true;

    keychar = String.fromCharCode(key);

    // check for backspace or delete, or if Ctrl was pressed
    if (key == 8 || isCtrl) {
        return true;
    }

    reg = /\d/;
    var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
    var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;

    return isFirstN || isFirstD || reg.test(keychar);
}

function putHyphen(obj) {
    if ((obj.value.length + 1) % 4 == 0)
        obj.value = obj.value + '-';
}

function removeHyphen(obj) {
    if (obj.value.charAt(obj.value.length - 1) == '-')
        obj.value = obj.value.substring(0, obj.value.length - 1);
}

function ReturnNumbers(obj) {
    var kk;
    if (eval(obj.value) > 0) {
        kk = Math.round(obj.value * 100) / 100;
        obj.value = kk;
    }
    else
        obj.value = '0';

    return obj.value;
}


function EDDue(obj) {
    if (obj == 'Date') {
        document.getElementById('ctl00$ContentPlaceHolderMain$txtMin2').disabled = true;
        document.getElementById('ctl00$ContentPlaceHolderMain$txtVPKG2').disabled = true;
        document.getElementById('ctl00$ContentPlaceHolderMain$drpOnWt2').disabled = true;
    }
    else if (obj == 'All') {
        document.getElementById('ctl00$ContentPlaceHolderMain$txtMin2').disabled = false;
        document.getElementById('ctl00$ContentPlaceHolderMain$txtVPKG2').disabled = false;
        document.getElementById('ctl00$ContentPlaceHolderMain$drpOnWt2').disabled = false;
    }
}


function HideTextBoxBooking(obj, obj1, obj2) {
    if (obj == 'City') {
        document.getElementById('ctl00$ContentPlaceHolderMain$btnGetData').value = 'Get Agent';
        document.getElementById(obj1).style.display = 'none';
        document.getElementById(obj2).style.display = '';
    }
    else if (obj == 'AWB') {
        document.getElementById(obj2).style.display = 'none';
        document.getElementById(obj1).style.display = '';
        document.getElementById('ctl00$ContentPlaceHolderMain$btnGetData').value = 'Booking';
    }
}

function HideTextBoxBooking1(obj, obj1, obj2) {
    if (obj == 'City') {
        document.getElementById(obj1).style.display = 'none';
        document.getElementById(obj2).style.display = '';
    }
    else if (obj == 'AWB') {
        document.getElementById(obj2).style.display = 'none';
        document.getElementById(obj1).style.display = '';
    }
}

function HideTextBox(obj, obj1, obj2) {
    document.getElementById(obj2).value = '';
    document.getElementById(obj1).value = '';
    if (obj.value == 'Country') {
        document.getElementById(obj2).value = '@1@';
        document.getElementById(obj2).style.display = 'none';
        document.getElementById(obj1).style.display = '';
    }
    else if (obj.value == 'City') {
        document.getElementById(obj1).value = '@1@';
        document.getElementById(obj1).style.display = 'none';
        document.getElementById(obj2).style.display = '';
    }
    else {
        document.getElementById(obj1).value = '@1@';
        document.getElementById(obj1).style.display = 'none';
        document.getElementById(obj2).style.display = '';
    }
}

function HideTextBox1(obj, obj1, obj2) {
    if (obj.value == 'Country') {
        document.getElementById(obj2).value = '@1@';
        document.getElementById(obj2).style.display = 'none';
        document.getElementById(obj1).style.display = '';
    }
    else if (obj.value == 'City') {
        document.getElementById(obj1).value = '@1@';
        document.getElementById(obj1).style.display = 'none';
        document.getElementById(obj2).style.display = '';
    }
    else {
        document.getElementById(obj1).value = '@1@';
        document.getElementById(obj1).style.display = 'none';
        document.getElementById(obj2).style.display = '';
    }
}

//document.onkeydown = function(e)
//{    
//    if (((event.keyCode == 78) && (event.ctrlKey)) || event.keyCode == 122)
//    {
//        //alert ("This Feature is disabled by system.")
//        event.cancelBubble = true;
//        event.returnValue = false;
//        event.keyCode = false; 
//        return false;
//    }          
//}

//document.onkeypress = function()
//{
//    if (((event.keyCode == 78) && (event.ctrlKey)) || event.keyCode == 122 )
//    {
//        //alert ("This Feature is disabled by system.")
//        event.cancelBubble = true;
//        event.returnValue = false;
//        event.keyCode = false; 
//        return false;
//    }        
//    
//}



function CheckValue(obj) {
    if (obj.value > 200) {
        alert("Value should be less or equal to 200");
        obj.focus();
        return false;
    }
    else if ((obj.value == '') || (obj.value == '0')) {
        alert("Please enter a value greater than 0");
        obj.focus();
        return false;
    }
    else
        return true;
}

function checkVal(obj) {
    if ((obj.value == '') || (obj.value == '0')) {
        alert("Weight should be greater than ZERO");
        //obj.focus();
        return false;
    }
    if ((eval(document.getElementById("ctl00_ContentPlaceHolder1_txtGW").value) > eval(document.getElementById("ctl00_ContentPlaceHolder1_txtVW").value)) && (eval(document.getElementById("ctl00_ContentPlaceHolder1_txtGW").value) > eval(document.getElementById("ctl00_ContentPlaceHolder1_txtCW").value)))
        document.getElementById("ctl00_ContentPlaceHolder1_txtCW").innerText = document.getElementById("ctl00_ContentPlaceHolder1_txtGW").value;
    else if ((eval(document.getElementById("ctl00_ContentPlaceHolder1_txtVW").value) > eval(document.getElementById("ctl00_ContentPlaceHolder1_txtGW").value)) && (eval(document.getElementById("ctl00_ContentPlaceHolder1_txtVW").value) > eval(document.getElementById("ctl00_ContentPlaceHolder1_txtCW").value)))
        document.getElementById("ctl00_ContentPlaceHolder1_txtCW").innerText = document.getElementById("ctl00_ContentPlaceHolder1_txtVW").value;
}

function checkCW(obj) {
    if ((obj.value == '') || (obj.value == '0')) {
        alert("Chargeable Weight should be greater than ZERO");
        obj.focus();
        return false;
    }
    else if (eval(document.getElementById("ctl00_ContentPlaceHolder1_txtGW").value) > eval(obj.value)) {
        alert("Chargeable Weight should not be less than Gross Weight");
        obj.focus();
        return false;
    }
    else if (eval(document.getElementById("ctl00_ContentPlaceHolder1_txtVW").value) > eval(obj.value)) {
        alert("Chargeable Weight should not be less than Volume Weight");
        obj.focus();
        return false;
    }
}



//document.onclick = function()
//{    
//    
//    var e = window.event.srcElement
//    if ((e.tagName == "A" && window.event.shiftKey))
//    {
//        window.location.href = e.href;
//        window.event.returnValue = false; 
//    }    
//    else
//        window.event.returnValue = true; 
//}


//document.onload = function()
//{
//    window.menubar.visible = false; 
//    window.locationbar.visible = false; 
//    window.scrollbars.visible = false; 
//    window.personalbar.visible = false; 
//    window.statusbar.visible = false; 
//    window.toolbar.visible = false;    
//}
function FillDGridData() {
    for (i = 0; i < aspnetForm.length; i++) {
        if ((aspnetForm[i].type == 'text') && (aspnetForm[i].name.indexOf('grdDDDD') != -1) && (aspnetForm[i].name.indexOf('txtVF') != -1))
            document.getElementById(aspnetForm[i].id).value = document.getElementById('ctl00_ContentPlaceHolder1_txtVF').value;
        if ((aspnetForm[i].type == 'text') && (aspnetForm[i].name.indexOf('grdDDDD') != -1) && (aspnetForm[i].name.indexOf('txtVto') != -1))
            document.getElementById(aspnetForm[i].id).value = document.getElementById('ctl00_ContentPlaceHolder1_txtVto').value;
    }
}

// Page Restriction Code..................

var offset = (navigator.userAgent.indexOf("Mac") != -1 ||
              navigator.userAgent.indexOf("Mozila Firefox") != -1 ||
              navigator.userAgent.indexOf("Gecko") != -1 ||
              navigator.appName.indexOf("Netscape") != -1) ? 0 : 4;
window.moveTo(-offset, -offset);
window.resizeTo(screen.availWidth + (2 * offset), screen.availHeight + (2 * offset));

top.window.moveTo(0, 0);
if (document.all) {
    top.window.resizeTo(screen.availWidth, screen.availHeight);
}
else if (document.layers || document.getElementById) {
    if (top.window.outerHeight < screen.availHeight || top.window.outerWidth < screen.availWidth) {
        top.window.outerHeight = screen.availHeight;
        top.window.outerWidth = screen.availWidth;
    }
}


function findPosX(X) {
    var obj = document.getElementById(X);
    var curleft = 0;
    if (obj.offsetParent)
        while (1) {
            curleft += obj.offsetLeft;
            if (!obj.offsetParent)
                break;
            obj = obj.offsetParent;
        }
    else if (obj.x)
        curleft += obj.x;
    return curleft;
}

function findPosY(Y) {
    var obj = document.getElementById(Y);
    var curtop = 0;
    if (obj.offsetParent)
        while (1) {
            curtop += obj.offsetTop;
            if (!obj.offsetParent)
                break;
            obj = obj.offsetParent;
        }
    else if (obj.y)
        curtop += obj.y;
    return curtop;
}

/////////------------------------------------


var msg = 'This functionality is restricted.';
var asciiBack = 8;
var asciiTab = 9;
var asciiSHIFT = 16;
var asciiCTRL = 17;
var asciiALT = 18;
var asciiHome = 36;
var asciiLeftArrow = 37;
var asciiRightArrow = 39;
var asciiMS = 92;
var asciiView = 93;
var asciiF1 = 112;
var asciiF2 = 113;
var asciiF3 = 114;
var asciiF4 = 115;
var asciiF5 = 116;
var asciiF6 = 117;
var asciiF11 = 122;
var asciiF12 = 123;
var asciiF11 = 122;



if (document.all) { //ie has to block in the key down
    document.onkeydown = onKeyPress;
    document.onclick = onClick;
    document.onmouseup = OnMouse;
    document.onmouseover = OnMouse;
    document.onmousedown = OnMouse;
} else if (document.layers || document.getElementById) { //NS and mozilla have to block in the key press
    document.onkeypress = onKeyPress;
    document.onclick = onClick;
    document.onmouseup = OnMouse;
    document.onmouseover = OnMouse;
    document.onmousedown = OnMouse;
}

function OnMouse(evt) {
    //alert("aa");
    window.status = '';
    var oEvent = (window.event) ? window.event : evt;
    var e;
    if (navigator.appName != "Netscape")
        e = oEvent.srcElement;
    else
        e = oEvent.target;

    if (e.tagName == "A") {
        //alert('aa');   
        window.status = "PacExpress";
    }
    return true;
}

function onClick(evt) {

    window.status = '';
    var oEvent = (window.event) ? window.event : evt;

    var bShiftPressed = (oEvent.shiftKey) ? oEvent.shiftKey : oEvent.modifiers & 4 > 0;
    var e;
    if (navigator.appName != "Netscape")
        e = oEvent.srcElement;
    else
        e = oEvent.target;

    if ((e.tagName == "A" && bShiftPressed)) {
        window.location.href = e.href;
        if (document.all) {
            oEvent.returnValue = false;
            oEvent.cancelBubble = true;
        }
        else {
            oEvent.preventDefault();
            oEvent.stopPropagation();
        }
    }
    else {
        oEvent.returnValue = true;
    }
    window.status = "PacExpress";
    return true;
}

function onKeyPress(evt) {
    window.status = '';
    //get the event object
    var oEvent = (window.event) ? window.event : evt;

    //hmmm in mozilla this is jacked, so i have to record these seperate
    //what key was pressed
    var nKeyCode = oEvent.keyCode ? oEvent.keyCode : oEvent.which ? oEvent.which : void 0;

    var bIsFunctionKey = false;

    //hmmm in mozilla the keycode would contain a function key ONLY IF the charcode IS 0    
    //else key code and charcode read funny, the charcode for 't' 
    //returns 116, which is the same as the ascii for F5
    //SOOO,... to check if a the keycode is truly a function key, 
    //ONLY check when the charcode is null OR 0, IE returns null, mozilla returns 0 

    if (oEvent.charCode == null || oEvent.charCode == 0) {
        bIsFunctionKey = (nKeyCode >= asciiF2 && nKeyCode <= asciiF12) || (nKeyCode == asciiALT || nKeyCode == asciiMS || nKeyCode == asciiView || nKeyCode == asciiHome)
    }

    //convert the key to a character, makes for more readable code  
    var sChar = String.fromCharCode(nKeyCode).toUpperCase();

    //get the active tag that has the focus on the page, and its tag type
    var oTarget = (oEvent.target) ? oEvent.target : oEvent.srcElement;
    var sTag = oTarget.tagName.toLowerCase();
    var sTagType = oTarget.getAttribute("type");

    var bAltPressed = (oEvent.altKey) ? oEvent.altKey : oEvent.modifiers & 1 > 0;
    var bShiftPressed = (oEvent.shiftKey) ? oEvent.shiftKey : oEvent.modifiers & 4 > 0;
    var bCtrlPressed = (oEvent.ctrlKey) ? oEvent.ctrlKey : oEvent.modifiers & 2 > 0;
    var bMetaPressed = (oEvent.metaKey) ? oEvent.metaKey : oEvent.modifiers & 8 > 0;

    var bRet = true; //assume true as that will be the case most times
    //alert (nKeyCode + ' ' + sChar + ' ' + sTag + ' ' + sTagType + ' ' + bShiftPressed + ' ' + bCtrlPressed + ' ' + bAltPressed);

    if (sTagType != null) { sTagType = sTagType.toLowerCase(); }

    //allow these keys inside a text box
    if (sTag == "textarea" || (sTag == "input" && (sTagType == "text" || sTagType == "password")) &&
        (
             nKeyCode == asciiSHIFT || nKeyCode == asciiHome || bShiftPressed || (bCtrlPressed && (nKeyCode == asciiLeftArrow || nKeyCode == asciiRightArrow)))
        ) {
        return true;
    } else if (bAltPressed && (nKeyCode == asciiLeftArrow || nKeyCode == asciiRightArrow)) {
        // block alt + left or right arrow
        bRet = false;
    } else if (bCtrlPressed && (sChar == 'A' || sChar == 'C' || sChar == 'V' || sChar == 'X')) { // ALLOW cut, copy and paste, and SELECT ALL
        bRet = true;
    } else if (bShiftPressed && nKeyCode == asciiTab) {//allow shift + tab
        bRet = true;
    } else if (bIsFunctionKey) { // Capture and stop these keys
        bRet = false;
    } else if (bCtrlPressed || bShiftPressed || bAltPressed) { //block ALL other sequences, includes CTRL+O, CTRL+P, CTRL+N, etc....
        bRet = false;
    }

    if (!bRet) {
        try {
            oEvent.returnValue = false;
            oEvent.cancelBubble = true;

            if (document.all) { //IE
                oEvent.keyCode = 0;
            } else { //NS
                oEvent.preventDefault();
                oEvent.stopPropagation();
            }
            window.status = msg;
        } catch (ex) {
            //alert(ex);
        }
    }
    return bRet;
}


function roundNumber(num, dec) {
    var result = Math.round(num * Math.pow(10, dec)) / Math.pow(10, dec);
    return result;
}
 
