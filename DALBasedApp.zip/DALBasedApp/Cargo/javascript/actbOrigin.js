function actbOrigin(obj,ca){
	/* ---- Public Variables ---- */
	this.actbOrigin_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbOrigin_lim = 10;    // Number of elements autocomplete can show (-1: no limit)
	this.actbOrigin_firstText = true; // should the auto complete be limited to the beginning of keyword?
	this.actbOrigin_mouse = true; // Enable Mouse Support
	this.actbOrigin_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbOrigin_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbOrigin_bgColor = '#F1F0F0';
	this.actbOrigin_textColor = '#D60000';
	this.actbOrigin_hColor = '#FFFFFF';
	this.actbOrigin_fFamily = 'Verdana';
	this.actbOrigin_fSize = '11px';
	this.actbOrigin_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbOrigin_delimwords = new Array();
	var actbOrigin_cdelimword = 0;
	var actbOrigin_delimchar = new Array();
	var actbOrigin_display = false;
	var actbOrigin_pos = 0;
	var actbOrigin_total = 0;
	var actbOrigin_curr = null;
	var actbOrigin_rangeu = 0;
	var actbOrigin_ranged = 0;
	var actbOrigin_bool = new Array();
	var actbOrigin_pre = 0;
	var actbOrigin_toid;
	var actbOrigin_tomake = false;
	var actbOrigin_getpre = "";
	var actbOrigin_mouse_on_list = 1;
	var actbOrigin_kwcount = 0;
	var actbOrigin_caretmove = false;
	this.actbOrigin_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbOrigin_keywords = ca;
	var actbOrigin_self = this;

	actbOrigin_curr = obj;
	
	addEvent(actbOrigin_curr,"focus",actbOrigin_setup);
	function actbOrigin_setup(){
		addEvent(document,"keydown",actbOrigin_checkkey);
		addEvent(actbOrigin_curr,"blur",actbOrigin_clear);
		addEvent(document,"keypress",actbOrigin_keypress);
	}

	function actbOrigin_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbOrigin_checkkey);
		removeEvent(actbOrigin_curr,"blur",actbOrigin_clear);
		removeEvent(document,"keypress",actbOrigin_keypress);
		actbOrigin_removedisp();
	}
	function actbOrigin_parse(n){
		if (actbOrigin_self.actbOrigin_delimiter.length > 0){
			var t = actbOrigin_delimwords[actbOrigin_cdelimword].addslashes();
			var plen = actbOrigin_delimwords[actbOrigin_cdelimword].length;
		}else{
			var t = actbOrigin_curr.value.addslashes();
			var plen = actbOrigin_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbOrigin_self.actbOrigin_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbOrigin_self.actbOrigin_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbOrigin_generate(){
		if (document.getElementById('tat_table')){ actbOrigin_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbOrigin_kwcount == 0){
			actbOrigin_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbOrigin_curr) + actbOrigin_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbOrigin_curr) + "px";
		a.style.backgroundColor=actbOrigin_self.actbOrigin_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbOrigin_self.actbOrigin_mouse){
			a.onmouseout = actbOrigin_table_unfocus;
			a.onmouseover = actbOrigin_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbOrigin_self.actbOrigin_keywords.length;i++){
			if (actbOrigin_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbOrigin_tomake){
					r.style.backgroundColor = actbOrigin_self.actbOrigin_hColor;
					first = false;
					actbOrigin_pos = counter;
				}else if(actbOrigin_pre == i){
					r.style.backgroundColor = actbOrigin_self.actbOrigin_hColor;
					first = false;
					actbOrigin_pos = counter;
				}else{
					r.style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbOrigin_self.actbOrigin_textColor;
				c.style.fontFamily = actbOrigin_self.actbOrigin_fFamily;
				c.style.fontSize = actbOrigin_self.actbOrigin_fSize;
				c.innerHTML = actbOrigin_parse(actbOrigin_self.actbOrigin_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbOrigin_self.actbOrigin_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbOrigin_mouseclick;
					c.onmouseover = actbOrigin_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbOrigin_self.actbOrigin_lim && j < actbOrigin_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbOrigin_self.actbOrigin_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbOrigin_self.actbOrigin_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbOrigin_self.actbOrigin_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbOrigin_mouse_down;
				}
				break;
			}
		}
		actbOrigin_rangeu = 1;
		actbOrigin_ranged = j-1;
		actbOrigin_display = true;
		if (actbOrigin_pos <= 0) actbOrigin_pos = 1;
	}
	function actbOrigin_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbOrigin_curr) + actbOrigin_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbOrigin_curr) + "px";
		a.style.backgroundColor=actbOrigin_self.actbOrigin_bgColor;
		a.id = 'tat_table';
		if (actbOrigin_self.actbOrigin_mouse){
			a.onmouseout= actbOrigin_table_unfocus;
			a.onmouseover=actbOrigin_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbOrigin_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbOrigin_self.actbOrigin_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbOrigin_self.actbOrigin_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbOrigin_self.actbOrigin_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbOrigin_mouse_up;
			}
		}
		for (i=0;i<actbOrigin_self.actbOrigin_keywords.length;i++){
			if (actbOrigin_bool[i]){
				if (j >= actbOrigin_rangeu && j <= actbOrigin_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbOrigin_self.actbOrigin_textColor;
					c.style.fontFamily = actbOrigin_self.actbOrigin_fFamily;
					c.style.fontSize = actbOrigin_self.actbOrigin_fSize;
					c.innerHTML = actbOrigin_parse(actbOrigin_self.actbOrigin_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbOrigin_self.actbOrigin_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbOrigin_mouseclick;
						c.onmouseover = actbOrigin_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbOrigin_ranged) break;
		}
		if (j-1 < actbOrigin_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbOrigin_self.actbOrigin_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbOrigin_self.actbOrigin_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbOrigin_self.actbOrigin_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbOrigin_mouse_down;
			}
		}
	}
	function actbOrigin_goup(){
		if (!actbOrigin_display) return;
		if (actbOrigin_pos == 1) return;
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
		actbOrigin_pos--;
		if (actbOrigin_pos < actbOrigin_rangeu) actbOrigin_moveup();
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_hColor;
		if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		if (actbOrigin_self.actbOrigin_timeOut > 0) actbOrigin_toid = setTimeout(function(){actbOrigin_mouse_on_list=0;actbOrigin_removedisp();},actbOrigin_self.actbOrigin_timeOut);
	}
	function actbOrigin_godown(){
		if (!actbOrigin_display) return;
		if (actbOrigin_pos == actbOrigin_total) return;
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
		actbOrigin_pos++;
		if (actbOrigin_pos > actbOrigin_ranged) actbOrigin_movedown();
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_hColor;
		if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		if (actbOrigin_self.actbOrigin_timeOut > 0) actbOrigin_toid = setTimeout(function(){actbOrigin_mouse_on_list=0;actbOrigin_removedisp();},actbOrigin_self.actbOrigin_timeOut);
	}
	function actbOrigin_movedown(){
		actbOrigin_rangeu++;
		actbOrigin_ranged++;
		actbOrigin_remake();
	}
	function actbOrigin_moveup(){
		actbOrigin_rangeu--;
		actbOrigin_ranged--;
		actbOrigin_remake();
	}

	/* Mouse */
	function actbOrigin_mouse_down(){
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
		actbOrigin_pos++;
		actbOrigin_movedown();
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_hColor;
		actbOrigin_curr.focus();
		actbOrigin_mouse_on_list = 0;
		if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		if (actbOrigin_self.actbOrigin_timeOut > 0) actbOrigin_toid = setTimeout(function(){actbOrigin_mouse_on_list=0;actbOrigin_removedisp();},actbOrigin_self.actbOrigin_timeOut);
	}
	function actbOrigin_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
		actbOrigin_pos--;
		actbOrigin_moveup();
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_hColor;
		actbOrigin_curr.focus();
		actbOrigin_mouse_on_list = 0;
		if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		if (actbOrigin_self.actbOrigin_timeOut > 0) actbOrigin_toid = setTimeout(function(){actbOrigin_mouse_on_list=0;actbOrigin_removedisp();},actbOrigin_self.actbOrigin_timeOut);
	}
	function actbOrigin_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbOrigin_display) return;
		actbOrigin_mouse_on_list = 0;
		actbOrigin_pos = this.getAttribute('pos');
		actbOrigin_penter();
	}
	function actbOrigin_table_focus(){
		actbOrigin_mouse_on_list = 1;
	}
	function actbOrigin_table_unfocus(){
		actbOrigin_mouse_on_list = 0;
		if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		if (actbOrigin_self.actbOrigin_timeOut > 0) actbOrigin_toid = setTimeout(function(){actbOrigin_mouse_on_list = 0;actbOrigin_removedisp();},actbOrigin_self.actbOrigin_timeOut);
	}
	function actbOrigin_table_highlight(){
		actbOrigin_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_bgColor;
		actbOrigin_pos = this.getAttribute('pos');
		while (actbOrigin_pos < actbOrigin_rangeu) actbOrigin_moveup();
		while (actbOrigin_pos > actbOrigin_ranged) actbOrigin_movedown();
		document.getElementById('tat_tr'+actbOrigin_pos).style.backgroundColor = actbOrigin_self.actbOrigin_hColor;
		if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		if (actbOrigin_self.actbOrigin_timeOut > 0) actbOrigin_toid = setTimeout(function(){actbOrigin_mouse_on_list = 0;actbOrigin_removedisp();},actbOrigin_self.actbOrigin_timeOut);
	}
	/* ---- */

	function actbOrigin_insertword(a){
		if (actbOrigin_self.actbOrigin_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbOrigin_delimwords.length;i++){
				if (actbOrigin_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbOrigin_delimwords[i].length;++j){
						if (actbOrigin_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbOrigin_delimwords[i].length-1;j>=0;--j){
						if (actbOrigin_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbOrigin_delimwords[i];
				}
				if (i != actbOrigin_delimwords.length - 1){
					str += actbOrigin_delimchar[i];
				}
			}
			actbOrigin_curr.value = str;
			setCaret(actbOrigin_curr,l);
		}else{
			actbOrigin_curr.value = a;
		}
		actbOrigin_mouse_on_list = 0;
		actbOrigin_removedisp();
	}
	function actbOrigin_penter(){
		if (!actbOrigin_display) return;
		actbOrigin_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbOrigin_self.actbOrigin_keywords.length;i++){
			if (actbOrigin_bool[i]) c++;
			if (c == actbOrigin_pos){
				word = actbOrigin_self.actbOrigin_keywords[i];
				break;
			}
		}
		actbOrigin_insertword(word);
		l = getCaretStart(actbOrigin_curr);
	}
	function actbOrigin_removedisp(){
		if (actbOrigin_mouse_on_list==0){
			actbOrigin_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		}
	}
	function actbOrigin_keypress(e){
		if (actbOrigin_caretmove) stopEvent(e);
		return !actbOrigin_caretmove;
	}
	function actbOrigin_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbOrigin_curr);
		actbOrigin_caretmove = 0;
		switch (a){
			case 38:
				actbOrigin_goup();
				actbOrigin_caretmove = 1;
				return false;
				break;
			case 40:
				actbOrigin_godown();
				actbOrigin_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbOrigin_display){
					actbOrigin_caretmove = 1;
					actbOrigin_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbOrigin_tocomplete(a)},50);
				break;
		}
	}

	function actbOrigin_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbOrigin_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbOrigin_self.actbOrigin_keywords.length;i++){
				if (actbOrigin_bool[i]) c++;
				if (c == actbOrigin_pos){
					word = i;
					break;
				}
			}
			actbOrigin_pre = word;
		}else{ actbOrigin_pre = -1};
		
		if (actbOrigin_curr.value == ''){
			actbOrigin_mouse_on_list = 0;
			actbOrigin_removedisp();
			return;
		}
		if (actbOrigin_self.actbOrigin_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbOrigin_curr);
			caret_pos_end = getCaretEnd(actbOrigin_curr);
			
			delim_split = '';
			for (i=0;i<actbOrigin_self.actbOrigin_delimiter.length;i++){
				delim_split += actbOrigin_self.actbOrigin_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbOrigin_delimwords = new Array();
			actbOrigin_delimwords[0] = '';
			for (i=0,j=actbOrigin_curr.value.length;i<actbOrigin_curr.value.length;i++,j--){
				if (actbOrigin_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbOrigin_curr.value.substr(i,j).match(delim_split_rx);
					actbOrigin_delimchar[c] = ma[1];
					c++;
					actbOrigin_delimwords[c] = '';
				}else{
					actbOrigin_delimwords[c] += actbOrigin_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbOrigin_cdelimword = -1;
			for (i=0;i<actbOrigin_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbOrigin_delimwords[i].length){
					actbOrigin_cdelimword = i;
				}
				l+=actbOrigin_delimwords[i].length + 1;
			}
			var ot = actbOrigin_delimwords[actbOrigin_cdelimword]; 
			var t = actbOrigin_delimwords[actbOrigin_cdelimword].addslashes();
		}else{
			var ot = actbOrigin_curr.value;
			var t = actbOrigin_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbOrigin_mouse_on_list = 0;
			actbOrigin_removedisp();
		}
		if (ot.length < actbOrigin_self.actbOrigin_startcheck) return this;
		if (actbOrigin_self.actbOrigin_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbOrigin_total = 0;
		actbOrigin_tomake = false;
		actbOrigin_kwcount = 0;
		for (i=0;i<actbOrigin_self.actbOrigin_keywords.length;i++){
			actbOrigin_bool[i] = false;
			if (re.test(actbOrigin_self.actbOrigin_keywords[i])){
				actbOrigin_total++;
				actbOrigin_bool[i] = true;
				actbOrigin_kwcount++;
				if (actbOrigin_pre == i) actbOrigin_tomake = true;
			}
		}

		if (actbOrigin_toid) clearTimeout(actbOrigin_toid);
		if (actbOrigin_self.actbOrigin_timeOut > 0) actbOrigin_toid = setTimeout(function(){actbOrigin_mouse_on_list = 0;actbOrigin_removedisp();},actbOrigin_self.actbOrigin_timeOut);
		actbOrigin_generate();
	}
	return this;
}