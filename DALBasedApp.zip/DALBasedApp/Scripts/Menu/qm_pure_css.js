;

function qm_pure(sd) {
    if (sd.tagName == "UL") {
        var nd = document.createElement("DIV");
        nd.qmpure = 1;
        qm_convert(sd, nd);
        var csp = document.createElement("SPAN");
        csp.className = "qmclear";
        csp.innerHTML = "&nbsp;";
        nd.appendChild(csp);
        sd = sd[qp].replaceChild(nd, sd);
        sd = nd;
    }
    return sd;
};

function qm_convert(a, bm, l) {
    if (!l) {
        bm.className = a.className;
        bm.id = a.id;
    }
    var ch = a.childNodes;
    for (var i = 0; i < ch.length; i++) {
        if (ch[i].tagName == "LI") {
            var sh = ch[i].childNodes;
            for (var j = 0; j < sh.length; j++) {
                if (sh[j] && (sh[j].tagName == "A" || sh[j].tagName == "SPAN")) bm.appendChild(ch[i].removeChild(sh[j]));
                if (sh[j] && sh[j].tagName == "UL") {
                    var na = document.createElement("DIV");
                    var c;
                    if (c = sh[j].style.cssText) na.style.cssText = c;
                    if (c = sh[j].className) na.className = c;
                    na = bm.appendChild(na);
                    new qm_convert(sh[j], na, 1)
                }
            }
        }
    }
}