﻿

function CheckPassword() {
    var msg = '';
    if ($('#' + txtPassword).val() != '' && $("#" + txtPasswordRe).val() != '') {
        if ($("#" + txtPassword).val() != $("#" + txtPasswordRe).val()) {
            msg = 'Password should be same.';
        }
    }
    else {
        if ($('#' + txtPassword).val() == '') {
            msg = 'Password can not left blank.';
        }
        msg = '';
    }
    $("#" + hdnPassword).val(msg);
    $("#" + lblLoginPassword).text(msg);
}

function SelectCustomHouseAgent(objectId) { 
    $("#" + objectId + " option").each(function () {
        if ($(this).attr('selected')) {
            if ($(this).text() == "CUSTOMHOUSE-AGENT") {
                $("#divCHA").animate({ width: 'show', height: 'show', opacity: 'toggle' }, 700);
            }
            else {
                $("#divCHA").animate({ width: 'hide', height: 'hide', opacity: 'toggle' }, 700);
            }
        }
    });
}