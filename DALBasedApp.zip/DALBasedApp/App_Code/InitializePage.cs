﻿/* Initialize Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This class takes care of the Default page and loading of the javascript and css on each page.
 * Created By           :   
 * Created On           :   

*/

using System;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.App.CRM.Business;
using System.Web.UI;

namespace Cfi.App.Pace.WebUI
{
    /// <summary>
    /// Class for the Default page and loading of the javascript and css on each page.
    /// </summary>
    public class InitializePage
    {
        /// <summary>
        /// The get java script master page reference.
        /// </summary>
        /// <returns> An array of string that contains the locations of the javascript files that needs to be loaded.
        /// </returns>
        public string[] GetJavaScriptMasterPageReference()
        {
            string[] pageNameArrary = HttpContext.Current.Request.Url.ToString().Split('?');
            string pageName = pageNameArrary[0];

            Regex regex = new Regex("\\w*.aspx");
            if(regex.Matches(pageName).Count == 0)
                return null;
            string jsApplicationPath = pageName.Replace(HttpContext.Current.Request.CurrentExecutionFilePath, string.Empty) + HttpContext.Current.Request.ApplicationPath + "/";
            pageName = regex.Matches(pageName)[0].Value.Replace(".aspx", string.Empty);
            string jsJQuery = jsApplicationPath + "Scripts/Common/JQuery/jquery-1.4.2.js";
            string jsJQueryUICustomMin = jsApplicationPath + "Scripts/Common/JQuery/jquery-ui-1.8.4.custom.min.js";
            string jsJQueryUICore = jsApplicationPath + "Scripts/Common/JQuery/jquery.ui.core.js";
            string jsJQueryWidget = jsApplicationPath + "Scripts/Common/JQuery/jquery.ui.widget.js";
            string jsJQueryPosition = "";// jsApplicationPath + "Scripts/Common/JQuery/jquery.ui.position.js";
            string jsCommon = jsApplicationPath + "Scripts/Common/Common.js";
            string jsJQueryQuicksearch = jsApplicationPath + "Scripts/Common/JQuery/jquery.quicksearch.js";
            string jsJQueryWatermark = jsApplicationPath + "Scripts/Common/JQuery/jquery.watermark.js";
            string jsJQueryRoundCorner = jsApplicationPath + "Scripts/Common/JQuery/jquery.corners.js";
            string jsQueryQm = jsApplicationPath + "Scripts/Menu/qm.js";
            string jsQueryQmPure = jsApplicationPath + "Scripts/Menu/qm_pure_css.js";
            string jsQueryQmRoundCorner = jsApplicationPath + "Scripts/Menu/qm_round_corners.js";
            string jsQueryQmRoundItems = jsApplicationPath + "Scripts/Menu/qm_round_items.js";
            string jsJQueryCalender = jsApplicationPath + "Scripts/Common/jquery.fullcalender.js/";
            string jsJQueryPlugginValidate = jsApplicationPath + "Scripts/Common/JQuery/jquery.validate.js";
            string jsJQueryTableSorter = jsApplicationPath + "Scripts/Common/JQuery/jquery.tablesorter.js";
            string jsJQueryTablePager = jsApplicationPath + "Scripts/Common/JQuery/jquery.tablesorter.pager.js";
            string jsJQueryPlugginAlerts = jsApplicationPath + "Scripts/Common/JQuery/jquery.alerts.js";
            string jsJQueryCookies = jsApplicationPath + "Scripts/Common/JQuery/jquery.cookie.js";
            string jsAutoCompleteOld = jsApplicationPath + "Scripts/Common/JQuery/jquery.autocomplete.js";
            


            StringBuilder sbJavascript = new StringBuilder();
            // Commonly used script used all over the application...
            sbJavascript.Append(jsJQuery + "," + jsJQueryWidget + "," + jsJQueryPosition + "," + jsJQueryUICore + "," + jsCommon + "," + jsQueryQm + "," + jsQueryQmPure + "," + jsQueryQmRoundCorner + "," + jsQueryQmRoundItems + "," + jsJQueryRoundCorner + "," + jsJQueryPlugginValidate + "," + jsJQueryTablePager + "," + jsJQueryQuicksearch + "," + jsJQueryPlugginAlerts + "," + "," + jsJQueryTableSorter + "," + jsJQueryCookies + "," + jsAutoCompleteOld + ",");
            switch(pageName)
            {
                case "Home":
                    sbJavascript.Append(jsApplicationPath + "Scripts/Home.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "Scripts/Common/JQuery/jquery.stickynotes.js" + ",");
                    break;
                case "Appointment":
                    sbJavascript.Append(jsJQueryCalender + "FullCalendar.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Appointment.js" + ",");
                    break;
                case "GroupEmails":
                    sbJavascript.Append(jsJQueryQuicksearch + ",");
                    sbJavascript.Append(jsApplicationPath + "Scripts/Common/AddItemsWithCrossImageButton.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Marketing/EmailGroupContactDetail.js" + ",");
                    break;
                case "AnnualBudget":
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Marketing/AnnualBudget.js" + ",");
                    break;

                case "Login":
                    sbJavascript.Append(jsApplicationPath + "Scripts/Manage/Login.js" + ",");
                    break; 

                case "Target":
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Common/Target.js" + ",");
                    break; 

                case "CampaignType":
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Master/CampaignType.js" + ",");
                    break;
                case "EmailMarketing":
                    sbJavascript.Append(jsJQueryQuicksearch + ",");
                    sbJavascript.Append(jsApplicationPath + "Scripts/Common/AddItemsWithCrossImageButton.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Marketing/EmailMarketing.js" + ",");
                    break;
                case "Greeting":
                    sbJavascript.Append(jsJQueryQuicksearch + ",");
                    sbJavascript.Append(jsApplicationPath + "Scripts/Common/AddItemsWithCrossImageButton.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Marketing/EmailMarketing.js" + ",");
                    break;
                case "WebMail":
                    sbJavascript.Append(jsApplicationPath + "Scripts/Common/AddItemsWithCrossImageButton.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "CRM/Scripts/Common/WebMail.js" + ",");
                    //sbJavascript.Append(jsApplicationPath + "Scripts/Common/JQuery/jquery.tinymce.js/jquery.tinymce.js" + ",");
                   // sbJavascript.Append(jsApplicationPath + "Scripts/Common/JQuery/jquery.tinymce.js/tiny_mce.js" + ",");
                    break;
                case "RFBLead":
                    sbJavascript.Append(jsJQueryQuicksearch + ",");
                    sbJavascript.Append(jsApplicationPath + "Cargo/javascript/actbCity.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "Cargo/javascript/actbShipperName.js" + ",");
                    sbJavascript.Append(jsApplicationPath + "Cargo/javascript/RFBLead/RFBLead.js" + ",");
                    break;
                case "Competitor":
                    sbJavascript.Append(jsJQueryQuicksearch + ",");
                    break;
                case "AssortedLeads":
                    sbJavascript.Append(jsJQueryQuicksearch + ",");
                    break;
                case "CompetitorMovement":
                    sbJavascript.Append(jsJQueryQuicksearch + ","); 
                    break;
                case "MaximumCreditLimitAndBlacklisted":
                    sbJavascript.Append(jsApplicationPath + "CRM/scripts/Reports/CrmReport.js" + ",");
                    break;
                case "ClosedSalesThisMonth":
                    sbJavascript.Append(jsApplicationPath + "CRM/scripts/Reports/CrmReport.js" + ",");
                    break;
                case "ClosedSalesByTerritory":
                    sbJavascript.Append(jsApplicationPath + "CRM/scripts/Reports/CrmReport.js" + ",");
                    break;
                case "Page":
                    sbJavascript.Append(jsJQueryQuicksearch + ",");
                    break;
                default:
                    break;
            }

           sbJavascript.Append(jsJQueryUICustomMin + ",");
            return sbJavascript.ToString().Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
        }

        /// <summary>
        /// The get style sheet master page reference.
        /// </summary>
        /// <returns>
        /// An array of string that contains the locations of the css files that needs to be loaded.
        /// </returns>
        public string[] GetStyleSheetMasterPageReference()
        {
            string pageName = HttpContext.Current.Request.Url.ToString(); // .Replace("?StatusNo=4", "").Replace("?StatusNo=3", ""); ;
            string[] QueryStringKeys = pageName.Split('?');
            pageName = QueryStringKeys[0];
            Regex regex = new Regex("\\w*.aspx");
            if(regex.Matches(pageName).Count == 0)
                return null;

            string cssApplicationPath = pageName.Replace(HttpContext.Current.Request.CurrentExecutionFilePath, string.Empty) + HttpContext.Current.Request.ApplicationPath + "/";
            pageName = regex.Matches(pageName)[0].Value.Replace(".aspx", string.Empty);
            string cssApplication = cssApplicationPath + "CSS/Application.css";
            string cssSoftGreyGridView = cssApplicationPath + "CSS/SoftGreyGridView.css";
            string cssJQueryUI = cssApplicationPath + "CSS/JQuery/Themes/custom-theme/jquery-ui-1.8.1.custom.css";
            string cssAlerts = cssApplicationPath + "CSS/JQuery/jquery.alerts.css";
            string cssMenu = cssApplicationPath + "CSS/Menu.css";
            string cssSubStyle = cssApplicationPath + "CSS/sub_style.css";
            string cssTableSorter = cssApplicationPath + "CSS/TableSorter.css";
            string cssPaceDashBoard = cssApplicationPath + "CSS/Dashboardstyle.css";
            // Adding the common css to all the pages...
            StringBuilder sbCSS = new StringBuilder();
            sbCSS.Append(cssApplication + "," + cssAlerts + "," + cssJQueryUI + "," + cssMenu + "," + cssSubStyle + "," + cssSoftGreyGridView + ",");

            switch(pageName)
            {
                case "Home":
                    sbCSS.Append(cssApplicationPath + "CSS/JQuery/jquery.stickynotes.css" + ",");
                    break;

                case "Appointment":
                    sbCSS.Append(cssApplicationPath + "CSS/Fullcalendar.css" + ",");
                    //To do:implement this theme in case of calender.Issue of scroll down has to be fixed after implementing this theme.
                   sbCSS.Append(cssApplicationPath + "CSS/JQuery/Themes/custom-theme/calender.theme.css" + ",");
                    break;
                case "ReportPreview":
                    sbCSS.Append(cssTableSorter + ",");
                    break;
                case "SubReportPreview":
                    sbCSS.Append(cssTableSorter + ",");
                    break;
                case "ReportWPage":
                    sbCSS.Append(cssTableSorter + ",");
                    break;
                case"NewDashboard":
                     sbCSS.Append(cssPaceDashBoard + ",");
                     break;
                case "DashBoardAccount":
                     sbCSS.Append(cssPaceDashBoard + ",");
                    break;
                case "Page":
                    sbCSS.Append(cssApplicationPath + "CSS/JQuery/jquery.stickynotes.css" + ",");
                    break; 
                default:
                    break;
            }

            return sbCSS.ToString().Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
        }

        public string GenerateMenu(Page page)
        {
            bool menu = false;
            string path = HttpContext.Current.Request.Path.ToLower().Contains("login.aspx") ? HttpContext.Current.Request.Path.ToLower().Replace("login.aspx", String.Empty) : HttpContext.Current.Request.Path.ToLower().Replace("logincrm.aspx", String.Empty);
            StringBuilder strMenu = new StringBuilder();
            using(StoredProcedure myMenu = new StoredProcedure())
            {
                strMenu.Append("<div class=\"menuHeader\" id=\"divMenuHeader\">");
                strMenu.Append("<table class=\"menuTable\" >");
                strMenu.Append("<tr>");
                strMenu.Append("<td>");
                strMenu.Append("<div class=\"menuHomeDiv\" > <a href='Home.aspx'> ");
                strMenu.Append("<img src=\"" + page.ResolveUrl("~/Images/home.png") + "\" border=0 /></a>");
                strMenu.Append("</div>");
                strMenu.Append("</td>");
                strMenu.Append("<td class=\"menuTdWidth\" >");
                strMenu.Append("<ul id=\"qm0\" class=\"qmmc\">");

                int i = 0;

                DataTable dtGetMenuList = myMenu.GetList("vPage", "distinct *", "LoginSno=" + ((UserLogin)HttpContext.Current.Session["LoginDetails"]).SNo);


                // DataTable dtGetMenuList = myMenu.GetList("Page", "*", "");
                DataRow[] drModuleArray = dtGetMenuList.Select("MenuSno IS NULL AND HyperLink IS NULL", "DisplayOrder ASC");

                foreach(DataRow drModule in drModuleArray)
                {
                    i++;
                    DataRow[] drAppCheck = dtGetMenuList.Select("MenuSno = " + drModule["Sno"], "DisplayOrder ASC");
                    if(drAppCheck.Length > 0)
                    {
                        if(menu == false)
                        {
                            strMenu.Append("<li><a href=\"javascript:void(0)\" style=\"font-weight:600;\">" + drModule["Name"] + "</a>");
                            menu = true;
                        }
                        else
                        {
                            strMenu.Append("<li><span class=\"qmdivider qmdividery\"></span></li>");
                            strMenu.Append("<li><a href=\"javascript:void(0)\" style=\"font-weight:600;\">" + drModule["Name"] + "</a>");
                        }

                        int menuID = Convert.ToInt32(drModule["Sno"]);
                        GetSubMenu(menuID, ref dtGetMenuList, ref strMenu, path, page);
                    }
                }

                strMenu.Append("<li class=\"qmclear\">&nbsp;</li></ul>");
                strMenu.Append("</td></tr></table></div><script type=\"text/javascript\">qm_create(0,false,0,250,false,false,false,false);</script>");
            }

            return strMenu.ToString();
        }

        private void GetSubMenu(int MenuID, ref DataTable dtGetMenuList, ref StringBuilder strMenu, string path, Page page)
        {

            strMenu.Append("<ul >");
            DataRow[] drSubMenuArray = dtGetMenuList.Select("MenuSno = " + MenuID, "DisplayOrder ASC");
            foreach(DataRow drSubMenu in drSubMenuArray)
            {
                if(drSubMenu["HyperLink"].ToString() == string.Empty)
                {
                    strMenu.Append("<li><a href=\"javascript:void(0)\">" + drSubMenu["Name"] + " <img src=\"" + page.ResolveUrl("~/Images/ci_weather_rightarrow.gif") + "\" style=\"border:0;\" /></a>");
                    //strMenu.Append("<li><a href=\"javascript:void(0)\" style=\"font-weight:600;\">" + drSubMenu["Name"] + "</a>");
                    GetSubMenu(Convert.ToInt32(drSubMenu["SNo"]), ref dtGetMenuList, ref strMenu, path, page);
                    strMenu.Append("</li>");
                }
                else
                    strMenu.Append("<li><a href=" + path + drSubMenu["HyperLink"] + ">" + drSubMenu["Name"] + "</a></li>");
            }
            strMenu.Append("</ul>");
        }

        public string GenerateMenu()
        {
            string[] pageNameArrary = HttpContext.Current.Request.Url.ToString().Split('?');
            string pageName = pageNameArrary[0];
            Regex regex = new Regex("\\w*.aspx");
            if(regex.Matches(pageName).Count == 0)
                return "";
            string path = pageName.Replace(HttpContext.Current.Request.CurrentExecutionFilePath, string.Empty) + HttpContext.Current.Request.ApplicationPath + "/";

            StringBuilder strMenu = new StringBuilder();
            using(StoredProcedure myMenu = new StoredProcedure())
            {
                strMenu.Append("<ul id='ulTopHorizontalMenu'>");
                DataTable dtGetMenuList = myMenu.GetList("vPage", "distinct *", "LoginSno=" + ((UserLogin)HttpContext.Current.Session["LoginDetails"]).SNo);

                // DataTable dtGetMenuList = myMenu.GetList("Page", "*", "");
                DataRow[] drModuleArray = dtGetMenuList.Select("MenuSno IS NULL AND HyperLink IS NULL", "DisplayOrder ASC");
                foreach(DataRow drModule in drModuleArray)
                {
                    DataRow[] drAppCheck = dtGetMenuList.Select("MenuSno = " + drModule["Sno"], "DisplayOrder ASC");
                    if(drAppCheck.Length > 0)
                    {
                        strMenu.Append("<li><a href='#'>" + drModule["Name"] + "</a>");
                        GetSubMenu(Convert.ToInt32(drModule["SNo"]), ref dtGetMenuList, ref strMenu, path);
                    }
                }
                strMenu.Append("</ul>");
            }
            return strMenu.ToString();
        }

        private void GetSubMenu(int menuID, ref DataTable dtGetMenuList, ref StringBuilder strMenu, string path)
        {
            strMenu.Append("<ul>");
            DataRow[] drSubMenuArray = dtGetMenuList.Select("MenuSno = " + menuID, "DisplayOrder ASC");
            foreach(DataRow drSubMenu in drSubMenuArray)
            {
                if(drSubMenu["HyperLink"].ToString() == string.Empty)
                {
                    strMenu.Append("<li nowrap><a href='#'>" + drSubMenu["Name"] + "</a>");
                    GetSubMenu(Convert.ToInt32(drSubMenu["SNo"]), ref dtGetMenuList, ref strMenu, path);
                    strMenu.Append("</li>");
                }
                else
                    strMenu.Append("<li><a href='" + path + drSubMenu["HyperLink"] + "'>" + drSubMenu["Name"] + "</a></li>");
            }
            strMenu.Append("</ul>");
        }
    }
}