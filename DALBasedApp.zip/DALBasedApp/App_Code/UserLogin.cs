﻿/* UserLogin Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   Class used to get the User details.
 * Created By           :   Chandra Prakash.
 * Created On           :   31 Dec 2009.
 * Updated By           :   Chander Shekhar Sharma.
 * Updated On           :   30 Mar 2010.
 * Desc                 :   Add Currency property only.
 * Updated By           :   Sudhir Yadav.
 * Updated On           :   08 Jun 2010.
 * Desc                 :   Added Alerts property to set or get the alerts of the user specially for CRM module. Removed unneccesary properties and made all prop to auto prop.
*/
using System;

namespace Cfi.App.CRM.Business
{
    /// <summary>
    /// Class used to get the User details.
    /// </summary>
    [Serializable]
    public class UserLogin : IDisposable
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserLogin"/> class.
        /// </summary>
        public UserLogin()
        {
            // Default Parameters we r using in Global asax file
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UserLogin"/> class. 
        /// Default constructor with sno and name of the user as input. So, that they can be accessed from anywhere in the application as long as the Session is active.
        /// </summary>
        /// <param name="sno">
        /// The SNo of the user.
        /// </param>
        /// <param name="name">
        /// The name of the user.
        /// </param>
        /// <param name="loginTypeSNo">
        /// The login Type S No.
        /// </param>
        /// <param name="cityCode">
        /// The city Code.
        /// </param>
        /// <param name="officeSNo">
        /// The office S No.
        /// </param>
        /// <param name="agentBranchSno">
        /// The agent Branch Sno.
        /// </param>
        /// <param name="officeName">
        /// The office Name.
        /// </param>
        /// <param name="isHeadOffice">
        /// The is Head Office.
        /// </param>
        /// <param name="name">
        /// City Code of the user.
        /// </param>
        /// <param name="name">
        /// Office SNo of the user.
        /// </param>
        /// <param name="name">
        /// Agent Branch Sno of the user.
        /// </param>
        /// <param name="currency">
        /// User Currency.
        /// </param>
        public UserLogin(int sno, string name, int loginTypeSNo, string cityCode, string currency)
        {
            Name = name;
            SNo = sno;
            LoginTypeSNo = loginTypeSNo;
            CityCode = cityCode;
            Currency = currency;
        }

        /// <summary>
        /// Gets or sets SNo.
        /// </summary>
        public int SNo { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets LoginTypeSNo.
        /// </summary>
        public int LoginTypeSNo { get; set; }

        /// <summary>
        /// Gets or sets CityCode.
        /// </summary>
        public string CityCode { get; set; }

        /// <summary>
        /// Gets or sets a value user currency.
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets a value user alerts, specially used in CRM module.
        /// </summary>
        public string Alerts { get; set; }

        /// <summary>
        /// Gets or sets the company branch name of the user logged in.
        /// </summary>
        public string CompanyBranchName{ get; set; }

        public void Dispose()
        {
            
        }
    }
}