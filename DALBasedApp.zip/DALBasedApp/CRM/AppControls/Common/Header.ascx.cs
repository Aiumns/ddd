﻿/* Header UserControl Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This class implements  header at home page.
 * Created By           :   Aditya kumar
 * Created On           :   1 May 2010.
 * Modified by          :   Dhiraj Kumar
 * Modified on          :   21 June 2010
 * Desc                 :   Removed unnecessary code and added javascript code to remove postback when selecting company branch to fetch company based logo and hence almost revamped the whole code.
                            (This class is basically a replica of pre-existing cargo/home.aspx with some code cleaning exercises)
 */


using System;
using System.Web.UI;
using System.Text;
using Cfi.App.Pace.Business;

public partial class CRM_AppControls_Common_Header : System.Web.UI.UserControl
{
    BLLogin bl = new BLLogin();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            var imageSource = string.Empty;
            if (!string.IsNullOrEmpty(Session["CompBrSNo"].ToString()))
                if (Session["CompBrSNo"].ToString().Split(',').Length < 2)
                    imageSource = Page.ResolveClientUrl("~/Services/DisplayCompanyLogo.ashx?CompanyBranchSNo=" + Session["CompBrSNo"]);
            iBtnChangeCompany.Visible = Session["AllCompBrSNo"].ToString().Split(',').Length > 1 && Session["LoginType"].ToString() != "SUPER ADMIN";
            if (!IsPostBack)
            {
                lblMenu.Text = Session["Menu"].ToString();
                string lastLogin = "";
                if (Session["LastLogin"].ToString() != "")
                    lastLogin = "Last Visit : " + Session["LastLogin"];
                string str = "<B>" + Session["DisplayName"].ToString().ToUpper() + "</B>" + "[" + Session["LoginType"].ToString().ToUpper() + "]" + "<br/> <font size='2px'>" + "<div id='clock1'>This div will be turned into a dynamic clock</div>" + lastLogin + "</font>";
                spanUserDetail.InnerHtml = str;
            }
            if (Session["CompName"] == null)
            {
                string[] compBrSNo = Session["AllCompBrSNo"].ToString().Split(',');
                if (compBrSNo.Length == 1)
                {
                    string compBrSno = Session["compBrSNo"].ToString();
                    string[] Type = bl.getCompTypeNew(compBrSno).Split('~');
                    Session["CompBrType"] = Type[0].ToString();
                    Session["compBrSNo"] = compBrSno;
                    Session["CompName"] = Type[1].ToString();
                    Session["InvoicePrefix"] = Type[2].ToString();
                }
            }


            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("$(function(){");
            stringBuilder.Append(!string.IsNullOrEmpty(imageSource)
                                     ? "$('#imgCompanyLogo').attr('src','" + imageSource + "'); $('#imgCompanyLogo').css('display','block');"
                                     : "$('#imgCompanyLogo').css('display','none');");
            stringBuilder.Append("$('#spanCompanyName').text('" + (Session["CompName"] != null ? Session["CompName"].ToString() : "") + "');");
            stringBuilder.Append("});");
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "CompanylogoImage", stringBuilder.ToString(), true);


        }
        
    }

    protected void imgHelp_Click(object sender, ImageClickEventArgs e)
    {
        GetHelp(Request.Url.AbsolutePath);
    }

    public void GetHelp(string urlString)
    {
    }

    protected void imghome_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["Project"].ToString() == "PACE")
        {
            if (Session["LoginType"].ToString() == "MANAGER")
            {

                Response.Redirect("~/Cargo/NewDashboard.aspx");
            }
            else if (Session["LoginType"].ToString() == "ACCOUNTS MANAGER" || Session["LoginType"].ToString() == "ACCOUNTS EXECUTIVE")
                Response.Redirect("~/Cargo/DashBoardAccount.aspx", false);
            else
                Response.Redirect("~/Home.aspx");
        }
        else
        {
            Response.Redirect("~/HomeCRM.aspx");
        }
    }

    protected void imgchpwd_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/Cargo/ChangePass.aspx");
    }

    protected void imglogout_Click(object sender, ImageClickEventArgs e)
    {
       
        if (Session["Project"].ToString() == "PACE")
        {
            Session.RemoveAll();
                       
            Response.Redirect("~/Login.aspx");
        }
        else
        {
            Response.Redirect("~/LoginCRM.aspx");
        }

    }

    protected void iBtnChangeCompany_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/Cargo/ChangeCompany.aspx",false);
    }

    protected void iBtnRFB_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Cargo/RFQBookingRate2.aspx");
    }
}
