﻿/* Appointment Javascript Description.
* Company              :   CargoFlash Infotech	Pvt. Ltd.
* Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
* Purpose              :   This class implements the javascript functionality related to Appoinment calender.
* Created By           :   Dhiraj  Kumar.
* Created On           :   11 April 2010.
*/

$(document).ready(function () {

    debugger;
    $("#calendar").fullCalendar({
        theme: true,
        firstDay: 1,
        firstHour: 8,
        slotMinutes: 15,
        minTime: 8,
        maxTime: 18,
        defaultEventMinutes: 120,
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
        editable: true,
        dayClick: function (date, allDay, jsEvent, view) {
            var $dialogContent = $("#event_edit_container");
            resetForm($dialogContent);

            var $titleField = $dialogContent.find("input[name='title']");
            var $bodyField = $dialogContent.find("textarea[name='descriptionBody']");
            $dialogContent.dialog({
                modal: true,
                title: "New Calendar Event",
                close: function () {
                    $dialogContent.dialog("destroy");
                    $dialogContent.hide();
                },
                buttons: {
                    save: function () {

                        $.ajax({
                            url: "../Services/AppointmentData.ashx?Mode=Save&title=" + $titleField.val() + "&description=" + $bodyField.val() + "&date=" + date.format('yyyy-MM-dd hh:mm:ss'),
                            cache: false,
                            async: true,
                            success: function (data) {
                                if (data != null) {
                                    $('#calendar').fullCalendar('renderEvent', { title: $titleField.val(),
                                        start: date,
                                        description: $bodyField.val()
                                    }, true);
                                    alert(data);
                                }
                            }
                        });
                        $dialogContent.dialog("close");

                    },
                    cancel: function () {
                        $dialogContent.dialog("close");
                    }
                }
            }).show();

        },
        eventClick: function (calEvent, jsEvent, view) { CallDialogBox(calEvent, jsEvent, view); },
        events: "../Services/AppointmentData.ashx"
    });

});
//Method to reset dialogbox
function resetForm($dialogContent) {
    $dialogContent.find("input").val("");
    $dialogContent.find("textarea").val("");
}

//Method to call dialog box
function CallDialogBox(calEvent, jsEvent, view) {
    var $dialogContent = $("#event_edit_container");
    resetForm($dialogContent);
    //alert(calEvent.start);
    var startField = $dialogContent.find(".timePickerStart").val(calEvent.start);
    var titleField = $dialogContent.find("input[name='title']").val(calEvent.title);
    var bodyField = $dialogContent.find("textarea[name='descriptionBody']").val(calEvent.description);
    $dialogContent.dialog({
        modal: true,
        title: "Update Calendar Event",
        close: function () {
            $dialogContent.dialog("destroy");
            $dialogContent.hide();
        },
        buttons: {
            save: function () {
                $.ajax({
                    url: "../Services/AppointmentData.ashx?Mode=Update&SNo="+calEvent.id+"&title=" + titleField.val() + "&description=" + bodyField.val() + "&date=" + calEvent.start.format('yyyy-MM-dd hh:mm:ss'),
                    cache: false,
                    async: true,
                    success: function (data) {
                        if (data != null) {
                          
                            alert(data);
                        }
                    }
                });
                calEvent.title = titleField.val();
                calEvent.description = bodyField.val();
                calEvent.start = startField.val();
                $('#calendar').fullCalendar("updateEvent", calEvent);
                $dialogContent.dialog("close");


            },
            cancel: function () {
                $dialogContent.dialog("close");
            }
        }
    }).show();

}