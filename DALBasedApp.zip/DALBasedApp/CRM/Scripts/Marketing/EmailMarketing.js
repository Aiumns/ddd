﻿/* EmailMarketing  Description.
* Company              :   CargoFlash Infotech	Pvt. Ltd.
* Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
* Purpose              :   This script used to get email schedule criteria.
* Created By           :   Ashutosh Kumar
* Created On           :   20 May 2010
*/



function ManageReccuranceDiv(rblRepeat) {
    var scheduleType = $('#' + rblRepeat + ' :input:radio:checked').val();
    if (scheduleType == '1') {
        $('#divWeekly').show();
        $('#divMonthly').hide();
        return;
    }
    else if (scheduleType == '2') {
        $('#divWeekly').hide();
        $('#divMonthly').show();
        return;
    }
    else {
        $('#divWeekly').hide();
        $('#divMonthly').hide();
        return;
    }
    $("#" + hdn).val(scheduleType);
}
