﻿debugger
function GetValue(obj, targetControlID, lblBudget) {
    document.getElementById(targetControlID).innerHTML = obj.value;
    document.getElementById(targetControlID).disabled = false;
    document.getElementById(lblBudget).value = obj.value;

}

function GetCalValue(hdnField, lblAvailableBudget, dataListControlId) {
    var valueTextBox;

    var dataListid = document.getElementById(dataListControlId);

    for (var i = 0; i < dataListid.rows.count; i++) {
        valueTextBox = dataListid.rows[i].cells[2].children[0];
    }
}