﻿/* EmailGroupContactDetail Page Description.
* Company              :   CargoFlash Infotech	Pvt. Ltd.
* Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
* Purpose              :   This script used to get contact detail for email group based on search criteria.
* Created By           :   Ashutosh Kumar
* Created On           :   19 May 2010
*/

function BindContactDetails(location, productType, customerType, department, destination, companySNos) {
   
    var getcompanyNos = $("#" + companySNos).val();
    $.ajax({
        url: "../Services/GetEMailGroupContactDetail.ashx?ProductType=" + $('#' + productType).val() + "&CustomerType="
        + $('#' + customerType).val() + "&Department=" + $('#' + department).val() + "&Destination=" + $('#' + destination).val() + "&Location=" + $('#' + location).val() + "&CompanySNos=" + getcompanyNos,
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                var contactSearchTable = "<table class=\"grdTable\" id=\"tableGetRecord\"><tr><th class=\"grdTableHeader\"><input id='chkSelectAll' CheckAll='CheckallContacts' type='checkbox' /></th><th class=\"grdTableHeader\">Customer Name</th><th class=\"grdTableHeader\">Contact Person</th><th class=\"grdTableHeader\">Contact Type</th><th class=\"grdTableHeader\">Location</th><th class=\"grdTableHeader\">Company</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {
                        contactSearchTable += "<tr><td><input id='chk" + item.CustomerContactSNo + "'  Apply=" + item.CustomerContactSNo + " type='checkbox' name='checkall' /></td><td>" + item.CustomerName + "</td><td>" + item.Name + "</td><td>" + item.Department + "</td><td>" + item.Location + "</td><td>" + item.Company + "</td></tr>";
                    }
                });
                contactSearchTable += "</table>";
                //alert(contactSearchTable);
                $("#divContactSearch").html(contactSearchTable);
                $("#chkSelectAll", $("#divContactSearch")).bind("click", function () { GetAllCheck(); });
            }
        }
    });
}

function StoreCheckBoxValues(type) {
    var allValsSelected = [];
    $("#tableGetRecord input[type=checkbox]").each(function () {
        if ($(this).attr("checked")) {
            allValsSelected.push($(this).attr('Apply')) + ',';
        }
    });
    $('#ctl00_ContentPlaceHolderMain_ucUserControlMain_hdnCheckBoxValue').val(allValsSelected);
}


function GetContactDetailsByEmailGroupId(emailGroupId) {

    $.ajax({
        url: "../Services/GetContactDetailsByEmailGroupId.ashx?EmailGroupId=" + emailGroupId,
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                var contactSearchTable = "<table class=\"grdTable\"><tr><th class=\"grdTableHeader\">Customer Name</th><th class=\"grdTableHeader\">Contact Person</th><th class=\"grdTableHeader\">Contact Type</th><th class=\"grdTableHeader\">Location</th><th class=\"grdTableHeader\">Company</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {
                        contactSearchTable += "<tr><td>" + item.CustomerName + "</td><td>" + item.Name + "</td><td>" + item.Department + "</td><td>" + item.Location + "</td><td>" + item.Company + "</td></tr>";
                    }
                });
                contactSearchTable += "</table>";
                $("#divContactSearch").html(contactSearchTable);
            }
        }
    });
}
function GetContactDetailsByEmailGroupIdForUpdate(emailGroupId) {
    $.ajax({
        url: "../Services/GetContactDetailsByEmailGroupId.ashx?EmailGroupId=" + emailGroupId,
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                var contactSearchTable = "<table class=\"grdTable\" id=\"tableGetRecord\"><tr><th class=\"grdTableHeader\"><input id='chkSelectAll' CheckAll='CheckallContacts' type='checkbox' /></th><th class=\"grdTableHeader\">Customer Name</th><th class=\"grdTableHeader\">Contact Person</th><th class=\"grdTableHeader\">Contact Type</th><th class=\"grdTableHeader\">Location</th><th class=\"grdTableHeader\">Company</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {
                        contactSearchTable += "<tr><td><input id='chk" + item.CustomerContactSNo + "'  Apply=" + item.CustomerContactSNo + " type='checkbox' name='checkall' /></td><td>" + item.CustomerName + "</td><td>" + item.Name + "</td><td>" + item.Department + "</td><td>" + item.Location + "</td><td>" + item.Company + "</td></tr>";
                    }
                });
                 contactSearchTable += "</table>";
                $("#divContactSearch").html(contactSearchTable);
                $("#chkSelectAll", $("#divContactSearch")).bind("click", function () { GetAllCheck(); });
            }
        }
    });
}


function GetAllCheck() {
    if ($('#chkSelectAll').attr('checked')) {
        $("input[name=checkall]").each(function () {
            this.checked = true;
        });
    }
    else {
        $("input[name=checkall]").each(function () {
            this.checked = false;
        });
    }
}


var finalId = '';
function StoreID(conId) {
    if (finalId != '') {
        var checkId = finalId.indexOf(conId);
        if (checkId > 0) {
            finalId = finalId.replace(conId, '');
            finalId = finalId.substr(0, finalId.length - 1);

        }
        else {
            finalId = finalId + ',' + conId;
        }
    }
    else {
        finalId = conId;
    }
    $('#ctl00_ContentPlaceHolderMain_ucUserControlMain_hdnCheckBoxValue').val(finalId);
}

function GetAssignedGroupContactId(emailGroupId) {
    $.ajax({
        url: "../Services/GetAssignedGroupContactId.ashx?EmailGroupId=" + emailGroupId,
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                $.each(data.items, function (i, item) {
                    if (item) {
                        $('#divContactSearch :checkbox').each(function () {
                            var chkedBox = '';
                            var subValue = '';
                            chkedBox = $(this).attr('id');
                            subValue = chkedBox.substr(3, chkedBox.length);

                            if (item.CustomerContactSNo == subValue) {

                                $(this).attr('checked', true);
                            }
                        });
                    }
                });
            }
        }
    });
}

function AllCheck() {
    if ($('#ChkAllCompany').attr('checked') == true) {
        $('#' + lstCompanyName + ' option').attr('selected', 'selected');
        $('#' + lblCheckBox).text('Deselect all company');
    }
    else {
        $('#' + lstCompanyName + ' option').attr('selected', false);
        $('#' + lblCheckBox).text('Select all company');
    }

    var getListBoxValue = '';
    $('#' + lstCompanyName + ' :selected').each(function () {
        getListBoxValue = $('#' + lstCompanyName).val() + ',';
    });
    $('#' + hdnCompany).val(getListBoxValue);

}

function GetCompanyValue() {
    var getListBoxValue = '';
    $('#' + lstCompanyName + ' :selected').each(function () {
        getListBoxValue = $('#' + lstCompanyName).val() + ',';
    });
    $("#" + hdnCompany).val(getListBoxValue);
}
