﻿function ShowHide(id) {
debugger
    var idx = "#" + id + " :checked";
    var val = $(idx).val();
    if (val == 1) {
        $("#divRemarks").hide();
    }
    else {
        $("#divRemarks").show();
    }
}