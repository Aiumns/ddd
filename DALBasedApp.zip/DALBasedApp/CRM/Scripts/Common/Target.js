﻿function ShowInfo(obj, Message) {
    $("#divShowStatus").html(Message);

    if (document.all) {
        $("#divShowStatus").css('top', window.event.clientY + 10 + 'px');
        $("#divShowStatus").css('left', window.event.clientX + 10 + 'px');
    }
    else {
        $("#divShowStatus").css('top', mousey + 10 + 'px');
        $("#divShowStatus").css('left', mousex + 10 + 'px');
    }

    $("#divShowStatus").css('background-color', '#FF0');
    $("#divShowStatus").show();
}



function HideInfo() {
    $("#divShowStatus").html("");
    $("#divShowStatus").hide();
}