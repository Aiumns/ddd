﻿/* WebMail Page Description.
* Company              :   CargoFlash Infotech	Pvt. Ltd.
* Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
* Purpose              :   This script used to manage all functionality related to web mail.
* Created By           :   Ashutosh Kumar
* Created On           :   25 May 2010
*/
function BindContactDetails(customerType, department, companyDetailSNo) {
    $.ajax({
        url: "../Services/GetCustomerContactForWebMail.ashx?CustomerType="
        + $('#' + customerType).val() + "&Department=" + $('#' + department).val() + "&CompanyDetailSNo=" + $("#" + companyDetailSNo).val(),
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                var contactSearchTable = "<table id='tblContactDetail' class=\"grdTable\"><tr><th class=\"grdTableHeader\"><input id='chkSelectAll' CheckAll='CheckallContacts' type='checkbox' /></th><th class=\"grdTableHeader\">Customer Name</th><th class=\"grdTableHeader\">Contact Person</th><th class=\"grdTableHeader\">Email</th><th class=\"grdTableHeader\">Contact Type</th><th class=\"grdTableHeader\">Location</th><th class=\"grdTableHeader\">Company</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {
                        contactSearchTable += "<tr><td><input id='chk" + item.CustomerContactSNo + "' Apply=" + item.Email + " onclick = 'StoreCheckBoxValues(\"" + item.Email + "\");'  type='checkbox' name='checkall' /></td><td>" + item.CustomerName + "</td><td>" + item.Name + "</td><td>" + item.Email + "</td><td>" + item.Department + "</td><td>" + item.Location + "</td><td>" + item.Company + "</td></tr>";
                    }
                });
                contactSearchTable += "</table>";
                $("#divContactSearch").html(contactSearchTable);
                $('#chkSelectAll', $('#divContactSearch')).bind("click", function () { GetAllCheck(); });
            }
        }
    });
}

function GetAllCheck() {
    var allValsSelected = [];
    if ($('#chkSelectAll').attr('checked')) {
        $("input[name=checkall]").each(function () {
            this.checked = true;
            if ($(this).attr("checked"))
                allValsSelected.push($(this).attr('Apply')) + ',';
            $('#ctl00_ContentPlaceHolderMain_ucUserControlMain_txtTo').val(allValsSelected) + ',';
        });
    }
    else {
        $("input[name=checkall]").each(function () {
            this.checked = false;
            $('#ctl00_ContentPlaceHolderMain_ucUserControlMain_txtTo').val('');
        });
    }
}

function StoreCheckBoxValues() {
    var allValsSelected = [];
    $("#tblContactDetail input[type=checkbox]").each(function () {
        if ($(this).attr("checked")) {
            allValsSelected.push($(this).attr('Apply')) + ',';
        }
    });
    $('#ctl00_ContentPlaceHolderMain_ucUserControlMain_txtTo').val(allValsSelected)
}


function SelectAllCheckboxes(chk) {
    $('#divContactSearch').find("input:checkbox").each(function (i) {
        if (this != chk) {
            this.checked = chk.checked;
            if (i > 0) {
                var finalId = $(this).attr('id').replace('chk', '');
                $.ajax({
                    url: "../Services/GetContactEmailById.ashx?ContactId=" + finalId,
                    cache: false,
                    dataType: "json",
                    success: function (data) {
                        if (data != null) {
                            $.each(data.items, function (i, item) {
                                if (item) {
                                    if (finalEmail != '') {
                                        finalEmail = finalEmail + ',' + item.ContactEmail;
                                    }
                                    else {
                                        finalEmail = item.ContactEmail;
                                    }

                                }
                            });
                            $('#ctl00_ContentPlaceHolderMain_ucUserControlMain_txtTo').val(finalEmail)
                            // $('#toEmail').val(finalEmail);
                        }
                    }
                });
            }
        }
    });
}

function AllCheck() {
    if ($('#ChkAllCompany').attr('checked') == true) {
        $('#' + lstCompanyName + ' option').attr('selected', 'selected');
        $('#' + lblCheckBox).text('Deselect all company');
    }
    else {
        $('#' + lstCompanyName + ' option').attr('selected', false);
        $('#' + lblCheckBox).text('Select all company');
    }

    var getListBoxValue = '';
    $('#' + lstCompanyName + ' :selected').each(function () {
        getListBoxValue = $('#' + lstCompanyName).val() + ',';
    });
    $('#' + hdnCompany).val(getListBoxValue);
}

function GetCompanyValue() {
    var getListBoxValue = '';
    $('#' + lstCompanyName + ' :selected').each(function () {
        getListBoxValue = $('#' + lstCompanyName).val() + ',';
    });
    $("#" + hdnCompany).val(getListBoxValue);
}