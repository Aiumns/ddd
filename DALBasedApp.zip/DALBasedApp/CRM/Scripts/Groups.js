﻿
/*
*****************************************************************************
File Name       :	      Groups.js   
Purpose         :         This provides Javascript functionality to the groupemail Page. 
Company         :		  CargoFlash Infotech
Created By      :         Ashutosh Kumar
Created On      :         17 May 2010.
*****************************************************************************
*/

function FillBranchCompanyWise() {
    FillDropDownConditionally(ddlBranchName, 'ViewCustomerBranch', 'SNo', 'Street|^ - ^|Place', 'CustomerName=^' + document.getElementById(txtCustomer).value + '^', '', 'Select', true);
}

