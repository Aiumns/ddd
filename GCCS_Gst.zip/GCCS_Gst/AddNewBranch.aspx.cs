using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Default4 : System.Web.UI.Page
{
    
    /// <summary>
    /// <class>Add New Branch</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>--------SAROJ KUMAR GUPTA--------</createdBy>
    /// <createdOn>-----Oct 18, 2007-------</createdOn>
    /// <modifications>
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy>--------SAROJ KUMAR GUPTA---------</modifiedBy>
    /// <modifiedOn>--------22, 23 Oct 2007--------</modifiedOn>
    /// <modifiedBy>--------RAKHI on 11 Dec---------</modifiedBy>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand com;
    SqlTransaction trans = null;
    DataSet ds;
    string TodayDate;
    public string strLen = "";
    public string strAgent = ""; 
    int AgentID,AgentBranchID, CityID;
    int CityId;
    string AgentCode,ts1;
    string loginid, name, strAgentBranchID;
  

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;    // connectionString

    protected void Page_Load(object sender, EventArgs e)
    {
        btnAdd.Attributes.Add("onclick", "return CheckEmpty()");
        btnUpdate.Attributes.Add("onclick", "return CheckEmpty()");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            TodayDate = DateTime.Now.ToShortDateString();
            strAgent = "<script>var FillAgent=new Array(" + getAgentName() + ")</script>";
            //strLen = "<script>var FillCity=new Array(" + City() + ")</script>";
            loginid = Session["EMailID"].ToString();

            if (!IsPostBack)
            {
                if (Request.QueryString["Agent_ID"] != null)
                {
                 
                    FillDetails();
                    CityName();
                    BindAirlineAccess();
                    BindGroupName();
                    CheckGroupType();
                    btnAddBranchAdmin.Visible = false;
                }
                else
                {
                    CityName();
                    //BindAirlineAccess();  // Call for Bind Airline Access
                    BindGroupName();  // Call for Bind Group Name
                    //getAgentName();   // call for Bind Agent Name
                    CheckGroupType();
                }
            }
            if (!Page.IsPostBack && Request.QueryString["Agent_Branch_ID"] != null && Request.QueryString["action"] == "e")
            {

                strAgentBranchID = Request.QueryString["Agent_Branch_ID"].ToString();
                btnUpdate.Visible = true;
                btnAdd.Visible = false;
                //btnAddByAdmin.Visible = false;
                lblHead.Text = "EDIT AGENT BRANCH";
                btnCancel.Visible = false;
                txtCity.Enabled = false;
                //update
                showtd.Visible = false;
                txtLogin.ReadOnly = true;
                textAgentName.ReadOnly = true;
                txtPassword.TextMode = TextBoxMode.SingleLine;
                FillDataAgentBranch();
                FillDataLoginMaster();
                splitAirlineAccess();
                showagentBranchByAdmin();
                BindAgent_Master();
                btnAddBranchAdmin.Visible = false;
                txtAgentNameselectByAdmin.ReadOnly = true;
            }
        }

    }
    

    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        txtLogin.Text = "";
        txtPassword.Text = "";
        ddlGroupName.SelectedItem.Text = "Agent";    
        txtAddress.Text = "";
        txtCity.SelectedIndex=0;
        CheckAirlineAccess.Items.Clear();
        //txtContactPerson.Text = "";
        txtPhone.Text = "";
        txtFax.Text = "";
        txtConcernPerson.Text = "";
        //txtCsrEmailID.Text = "";     
        txtPanNo.Text = "";
        ddlStatus.SelectedIndex = 0;
        lblAccesss.Visible = false;
        
    }
    
    public string getAgentName()
    {
        string strAgentName = "";
        con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT distinct(Agent_Name) FROM Agent_Master where Parent_ID=0";
            com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strAgentName == "")
                    strAgentName = "'" + Convert.ToString(dr["Agent_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strAgentName = strAgentName + "," + "'" + Convert.ToString(dr["Agent_Name"]).ToString().ToUpper().Trim() + "'";
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strAgentName;
    }

    public void CheckGroupType()    // check Group Type
    {

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ = "select Group_Type from Group_Master where group_ID=(select Group_ID from Login_Master where  Email_ID=@Login_id)";
            com = new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@Login_id", loginid);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr["Group_Type"].ToString().ToUpper().Trim().Equals("AGENT"))
                {
                    //tdAgentType.Visible = true;
                    //tdOtherType.Visible = false;
                    //btnAddByAdmin.Visible = false;
                    txtAgentType.Text = FindAgentName();
                    textAgentName.Text = FindAgentName();
                    BindAgentMaster();
                    tabform.Visible = true;
                    
                 }
                else
                {
                    
                    //tdOtherType.Visible = true;
                    //tdAgentType.Visible = false;
                    showtd.Visible = true;
                    txtAgentType.Visible = false;
                    lblAgentType.Visible = false;
                    btnAdd.Visible = true;
                    //btnAddByAdmin.Visible = true;
                    lblAgentNameAdmin.Visible = true;
                    btnAddBranchAdmin.Visible = true;
                    txtAgentNameselectByAdmin.Visible = true;
                    
                }
            }
            con.Close();
        }
        catch (SqlException esx)
        {
            string err = esx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }

    }

    public string FindAgentName()   // Find agent Name According  login id
    {
        con = new SqlConnection(strCon);
        con.Open();

        SqlCommand comm = new SqlCommand("select Agent_Name from Agent_Master where Agent_ID=(select Agent_ID from Agent_Branch where Agent_Email=@loginID)", con);
        comm.Parameters.AddWithValue("@loginID", loginid);
        name = comm.ExecuteScalar().ToString();
        con.Close();
        return name;
    }
  
    public void BindAirlineAccess()  // Bind Airline_Access
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectQ;
        string citycode = txtCity.SelectedItem.Text;
        int m = citycode.IndexOf("-") + 1;
        string city_code = citycode.Substring(0, m - 1);

        ////selectQ = "select (a.Airline_Code+'-'+a.Airline_Name) as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where c.City_Code='" + city_code + "' and b.Status=2";


        //*********************Modify On 31_DEC_2010******************* City Free Airline***************

        //selectQ = "select (a.Airline_Code+'-'+a.Airline_Name) as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where c.City_Code='" + city_code + "' and b.Status=2";

        selectQ = "select (a.Airline_Code+'-'+a.Airline_Name+'('+c.City_Code+')') as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where b.Status=2";


        //***************************End Of Modification***************************



        com = new SqlCommand(selectQ, con);
        com.Connection = con;
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);

        CheckAirlineAccess.DataSource = ds;
        CheckAirlineAccess.DataTextField = "NameCode";
        CheckAirlineAccess.DataValueField = "Airline_detail_ID";

        CheckAirlineAccess.DataBind();
        com.Dispose();
        con.Close();
        //CheckBoxList chk = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
        if (ds.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                lblAccesss.Visible = false;
                pnlCheck.Visible = true;
                CheckAirlineAccess.Items[i].Selected = true;
                
            }
        }
        else
        {
            lblAccesss.Visible = true;
            lblAccesss.Text ="No Airline Exist For " + txtCity.SelectedItem.Text.Trim() + ", Please select Another City";
            pnlCheck.Visible = false;   
        }
       
    }
 
    public void BindGroupName()     // Bind Group_Name
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectQ;
        selectQ = "select Group_Name,Group_ID from Group_Master where Group_Type='Agent'";
        com = new SqlCommand(selectQ, con);
        com.Connection = con;
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        ddlGroupName.DataSource = ds;
        ddlGroupName.DataTextField = "Group_Name";
        ddlGroupName.DataValueField = "Group_ID";
        ddlGroupName.DataBind();

        ddlCsrGroupName.DataSource = ds;
        ddlCsrGroupName.DataTextField = "Group_Name";
        ddlCsrGroupName.DataValueField = "Group_ID";
        ddlCsrGroupName.DataBind();
        //ddlGroupName.DataTextField = ds.Tables[0].Rows[0]["Group_Name"].ToString();
        //ddlGroupName.DataValueField = ds.Tables[0].Rows[0]["Group_ID"].ToString();
       
        
        //if (ds.Tables[0].Rows.Count > 0)
        //{
            
        //}
       
        com.Dispose();
        con.Close();

    }
    public void CityName()
    {
        string cityid = null;
        if (Request.QueryString["city"] != null)
        {
             cityid = Convert.ToString(Request.QueryString["city"]);
        }
        string sql=null;
      
        con = new SqlConnection(strCon);
        con.Open();
        if (cityid != null)
        {
            sql = "Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master where City_ID='" + cityid + "' ";
        }
        else
        {
            sql = "Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master ";
        }
        com = new SqlCommand(sql,con);
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        txtCity.DataSource = ds;
        txtCity.DataTextField = "CodeName";
        txtCity.DataValueField = "City_ID";
       
        txtCity.DataBind();
        if (cityid != null)
        {
            txtCity.SelectedItem.Value = (cityid);
        }
        else
        {
            txtCity.Items.Insert(0, new ListItem("--Select--", "0"));
        }
       
        con.Close();
    }
    public string City() // Bind City_Name and City_Code
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT City_Name,City_Code  FROM City_Master";
            SqlCommand com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }

    public void BindAgentMaster()   // Show Agent_Master Data according Agent_Name
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ;
            selectQ = "select Agent_Type,IATA_Code,IATA_Commission,TaxDeductiononSource,TDS_Exemption_Limit,SurCharge from Agent_Master where Agent_Name=@AgentName";
            com = new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@AgentName",textAgentName.Text);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp=ds.Tables[0].Rows.Count;
            for (int i = 0; i <temp ; i++)
            {
                //rakhi
               
                rb1.SelectedValue = ds.Tables[0].Rows[i]["Agent_Type"].ToString();
                rb1.Enabled=false;               
                txtIATACode.Text = ds.Tables[0].Rows[i]["IATA_Code"].ToString();
                //txtCreditLimit.Text = ds.Tables[0].Rows[i]["Credit_Limit"].ToString();
                txtIATAComm.Text = ds.Tables[0].Rows[i]["IATA_Commission"].ToString();
                //txtTDSDeducSource.Text = ds.Tables[0].Rows[i]["TaxDeductiononSource"].ToString();
                //txtTDSExemLimit.Text = ds.Tables[0].Rows[i]["TDS_Exemption_Limit"].ToString();
                //txtSurcharge.Text = ds.Tables[0].Rows[i]["SurCharge"].ToString();
                //ddlStatus.SelectedValue = ds.Tables[i].Rows[0]["Status"].ToString();
            }

        }
        catch (SqlException sqlEx)
        {
            string err = sqlEx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;

        }
        finally
        {
            if(con!=null && con.State==ConnectionState.Open)
            con.Close();
        }
    }

    public void BindAgent_Master() // Show Agent_Master Data according AgentName selected by Admin
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ;
            selectQ = "select Agent_Type,IATA_Code,IATA_Commission,TaxDeductiononSource,TDS_Exemption_Limit,SurCharge from Agent_Master where Agent_Name=@AgentName";
            com = new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@AgentName", txtAgentNameselectByAdmin.Text);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp = ds.Tables[0].Rows.Count;
            for (int i = 0; i < temp; i++)
            {
                textAgentName.Text = txtAgentNameselectByAdmin.Text;
                //rakhi
                
                txtIATACode.Text = ds.Tables[0].Rows[i]["IATA_Code"].ToString();
               // txtCreditLimit.Text = ds.Tables[0].Rows[i]["Credit_Limit"].ToString();
                txtIATAComm.Text = ds.Tables[0].Rows[i]["IATA_Commission"].ToString();
                //rb1.SelectedValue = ds.Tables[0].Rows[i]["Agent_Type"].ToString();
                rb1.Enabled = false; 
                //txtTDSDeducSource.Text = ds.Tables[0].Rows[i]["TaxDeductiononSource"].ToString();
                //txtTDSExemLimit.Text = ds.Tables[0].Rows[i]["TDS_Exemption_Limit"].ToString();
                //txtSurcharge.Text = ds.Tables[0].Rows[i]["SurCharge"].ToString();
                //ddlStatus.SelectedValue = ds.Tables[i].Rows[0]["Status"].ToString();
            }

        }
        catch (SqlException sqlEx)
        {
            string err = sqlEx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
      
        if (check())
        {
            lblMessage.Visible = true;
            lblMessage.Text = "Login ID Already Exist";
        }

        else if (checkCityName())
        {
            int m = CheckAirlineAccess.Items.Count;
               for (int i = 0; i < m; i++)
               {
                   CheckBoxList chk1 = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
                   if (chk1.Items[i].Selected == false)
                   {

                       lblMessage.Text = "Please Check AtLeast One Airline Access";
                       lblMessage.Visible = true;
                   }
                 else
                   {

                      lblMessage.Visible = false;
                      FillData();

                   }
               }
        }
        else 
        {
            lblMessage.Text = "Select Valid City Name";
            lblMessage.Visible = true;
            // FillData();
            
        }
    }
    public bool check()     // Check Login_ID exists
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectloginid;
        selectloginid = "SELECT Email_ID FROM Login_Master_CSR  WHERE (EMAIL_ID=@EmailID OR EMAIL_ID=@CSREmailID) UNION SELECT Email_ID FROM Login_Master WHERE (EMAIL_ID=@EmailID OR EMAIL_ID=@CSREmailID)";
        com = new SqlCommand(selectloginid, con);
        com.Parameters.AddWithValue("@EmailID", txtLogin.Text);
        com.Parameters.AddWithValue("@CSREmailID", txtCsrEmailID.Text);
        SqlDataReader sdr = com.ExecuteReader();
        //if (sdr.Read())
        //{
        //    con.Close();
        //    con.Open();
        //    return true;
        //}
        //else
        //{
        //    con.Close();
        //    con.Open();
        //    return false;
        //}
        if (sdr.Read())
        {
            if (sdr["Email_ID"].ToString() == "" || sdr["Email_ID"].ToString() == null)
            {
                con.Close();
                con.Open();

                return false;
            }
            else
            {

                con.Close();
                con.Open();

                return true;
            }
        }
        else
        {
            con.Close();
            con.Open();
            return false;
        }    
    }

    // Check Agent Name Exists.

    public bool checkCityName()
    {
         
        con = new SqlConnection(strCon);
        con.Open();
      
         string citycode = txtCity.SelectedItem.Text;
         int m = citycode.IndexOf("-");
         if (m > 0)
         {
             string city_code = citycode.Substring(0, m - 1);
             string selectloginid;
             selectloginid = "select City_Code+'-'+City_Name from City_Master  where City_Code=@cityName or City_Name=@City_CodeId";
             com = new SqlCommand(selectloginid, con);
             com.Parameters.AddWithValue("@cityName", city_code);
             com.Parameters.AddWithValue("@City_CodeId", FindCityName());
             SqlDataReader sdr = com.ExecuteReader();
             if (sdr.Read())
             {
                 con.Close();
                 con.Open();
                 return true;
             }
             else
             {
                 con.Close();
                 con.Open();
                 return false;
             }
         }
         else
         {
             lblMessage.Text = "select Valid City Name";
             lblMessage.Visible=true;
             return false;
         }       
    }

    public void FillData()      // INSERT Data in  All Table
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectQ,INSERTQ,selectQ1,INSERTQ1;

        try
        {
            // Find City name
            string citycode = txtCity.SelectedItem.Text;
            int m = citycode.IndexOf("-") + 1;
            citycode = citycode.Substring(0, m - 1);
            com = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con);
            SqlDataReader dr1 = com.ExecuteReader();
            while (dr1.Read())
            {
                CityID = Convert.ToInt32(dr1["City_ID"].ToString());
            }
            con.Close();
            dr1.Dispose();
            con.Open();
            selectQ = "select Agent_ID from Agent_Master where Agent_Name=@AgentName";
            com = new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@AgentName", textAgentName.Text);
            AgentID = Convert.ToInt32(com.ExecuteScalar().ToString());
            com.Dispose();

            selectQ = "select Belongs_To_City from Agent_Branch where Agent_ID='" + AgentID + "' and Belongs_To_City='" + CityID + "'";
            com= new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@AgentName", textAgentName.Text);
            dr1=com.ExecuteReader();
                if(dr1.HasRows)
                    {                      
                        lblMessage.Text = "City Name Already Exists";
                        lblMessage.Visible = true;
                        dr1.Dispose();
                        con.Close();
                        return;
                    }
                 else
                    {            
                    dr1.Dispose();
                    con.Close();
                    con.Open();
                    trans = con.BeginTransaction();

                    string strNeut = "";
                    if (chkNeutral.Checked == true)
                    {
                        strNeut = "Y";
                    }
                    else
                    {
                        strNeut = "N";
                    }
                // INSERT Data in Agent_Branch
                    INSERTQ = "INSERT INTO Agent_Branch(Agent_ID,Branch_Status,Belongs_To_City,Credit_Limit,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,CSR_Contact_Person,CSR_Email,Pan_No,Status,Agent_Contactno,AutoNeutral) VALUES(@Agent_ID,@Branch_Status,@Belongs_To_City,@Credit_Limit,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@CSR_Contact_Person,@CSR_Email,@Pan_No,@Status,@Agent_Contactno,@AutoNeutral)";

                    //INSERTQ = "INSERT INTO Agent_Branch(Agent_ID,Branch_Status,Belongs_To_City,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,CSR_Contact_Person,Pan_No,Status)VALUES(@Agent_ID,@Branch_Status,@Belongs_To_City,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@CSR_Contact_Person,@Pan_No,@Status)";
               SqlCommand cmd = new SqlCommand(INSERTQ, con, trans);
                cmd.Parameters.AddWithValue("@Agent_ID", AgentID);
                cmd.Parameters.AddWithValue("@Branch_Status",19);
                cmd.Parameters.AddWithValue("@Belongs_To_City", CityID);
                cmd.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
                //com.Parameters.AddWithValue("@Agent_Contactno1",txtcontactno.Text);
                //cmd.Parameters.AddWithValue("@Agent_Contactno", txtcontactno.Text);
                cmd.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
                cmd.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
                cmd.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
                cmd.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                cmd.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
                cmd.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
                cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@Agent_Contactno", txtcontactno.Text);
                cmd.Parameters.AddWithValue("@AutoNeutral", strNeut);
                cmd.ExecuteNonQuery();

                // Find AgentBranchId

                selectQ1 = "select max(Agent_Branch_ID) From Agent_Branch where Agent_ID=@agent_id";
                cmd = new SqlCommand(selectQ1, con, trans);
                cmd.Parameters.AddWithValue("@agent_id", AgentID);
                AgentBranchID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

                //INSERT INTO Data Login_Master

                INSERTQ1 = "INSERT INTO Login_Master(Email_ID,Login_Password,Agent_ID,Group_ID,Airline_Access )VALUES(@Email_ID,@Login_Password,@Agent_ID,@Group_ID,@Airline_Access)";
                cmd = new SqlCommand(INSERTQ1, con, trans);


                for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // VALUES store in listbox
                {
                    if (CheckAirlineAccess.Items[i].Selected)
                    {

                        ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
                    }
                }
                ts1 = ts1.Remove(ts1.LastIndexOf(","));
                cmd.Parameters.AddWithValue("@Email_ID", txtLogin.Text);
                cmd.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
                cmd.Parameters.AddWithValue("@Agent_ID", AgentBranchID);
                cmd.Parameters.AddWithValue("@Airline_Access", ts1);
                cmd.Parameters.AddWithValue("@Group_ID", ddlGroupName.SelectedValue);
                cmd.ExecuteNonQuery();
                if (txtCsrEmailID.Text != "")
                {
                    if (txtPassCSR.Text != "")
                    {
                        if (txtCsrEmailID.Text != txtLogin.Text)
                        {
                            string INSERTCSR = "INSERT INTO Login_Master_CSR(Email_ID,Login_Password,Agent_Branch_ID,Group_ID,Airline_Access )VALUES(@Email_ID,@Login_Password,@Agent_Branch_ID,@Group_ID,@Airline_Access)";
                            cmd = new SqlCommand(INSERTCSR, con, trans);
                            cmd.Parameters.AddWithValue("@Email_ID", txtCsrEmailID.Text);
                            cmd.Parameters.AddWithValue("@Login_Password", txtPassCSR.Text);
                            cmd.Parameters.AddWithValue("@Agent_Branch_ID", AgentBranchID);
                            cmd.Parameters.AddWithValue("@Airline_Access", ts1);
                            cmd.Parameters.AddWithValue("@Group_ID", ddlCsrGroupName.SelectedValue);
                            cmd.ExecuteNonQuery();
                        }
                    }

                }
                trans.Commit();
                lblMessage.Text = "Records Added Successfully";
                lblMessage.Visible = true;
                con.Close();
            }
        }
        catch (SqlException sqlExe)
        {
            string err = sqlExe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
            trans.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Response.Redirect("ViewAgentBranch.aspx");

    }
    //protected void ddlAgentName_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    BindAgentMaster();
    //}
    protected string FindCityName() // split CityName
    {
        string str = txtCity.SelectedItem.Text;
        string str1;
        int j = str.IndexOf("-") + 1;
        int k = str.Length;
        str1 = str.Substring(j);
        return str1;
    }

    protected void FillDetails()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string agent_id = Request.QueryString["Agent_ID"].ToString();
        string selectAgentName = "select Agent_Name from Agent_Master Where Agent_id='" + agent_id + "'";
        com = new SqlCommand(selectAgentName, con);
        SqlDataReader dr = com.ExecuteReader();
        if (dr.Read())
        {
            txtAgentNameselectByAdmin.Text = dr["Agent_Name"].ToString();
            BindAgent_Master();
            showtd.Visible = false;
            tabform.Visible = true;
            lblMessage.Visible = false;
            txtAgentNameselectByAdmin.ReadOnly = true;
        }
        else
        {
            tabform.Visible = false;
            lblMessage.Text = "Select Valid Agent Name";
            lblMessage.Visible = true;
        }
        dr.Dispose();
        con.Close();
    }
    protected void btnAddBranchAdmin_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectAgentName = "select Agent_Name from Agent_Master Where Parent_ID=0 and Agent_Name='" + txtAgentNameselectByAdmin.Text + "'";
        com = new SqlCommand(selectAgentName, con);
        SqlDataReader dr = com.ExecuteReader();
        if (dr.Read())
        {
            BindAgent_Master();
            showtd.Visible = false;
            tabform.Visible = true;           
            lblMessage.Visible = false;
            txtAgentNameselectByAdmin.ReadOnly = true;
        }
        else
        {
            tabform.Visible = false;
            lblMessage.Text = "Select Valid Agent Name";
            lblMessage.Visible = true;
        }
        dr.Dispose();
        con.Close();
       

       
    }

    //*********************************UPDATE**************************************************************



 public string showStatus()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string str9 = Request.QueryString["Agent_Branch_ID"].ToString(); ;
        com = new SqlCommand("select Status_Name from Status_Master where Status_ID=(Select Status From Agent_Branch Where Agent_Branch_ID='"+str9+"')", con);
        string status = com.ExecuteScalar().ToString();
        con.Close();
        return status;
    }
    
    public void  FillDataAgentBranch()
    {
        con=new SqlConnection(strCon);
        con.Open();
        try
        {
            string str = Request.QueryString["Agent_Branch_ID"].ToString();
            string selectQ;
            selectQ = "select * from Agent_Branch where Agent_Branch_ID=@AgentBranch_Id";
            com = new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@AgentBranch_Id", str);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp = ds.Tables[0].Rows.Count;
            for (int i = 0; i < temp; i++)
            {
                txtAddress.Text = ds.Tables[0].Rows[i]["Agent_Address"].ToString();
                txtCity.Text = ds.Tables[0].Rows[i]["Belongs_To_City"].ToString();
                txtPhone.Text = ds.Tables[0].Rows[i]["Agent_Phone"].ToString();
                txtcontactno.Text = ds.Tables[0].Rows[i]["Agent_Contactno"].ToString();
                txtFax.Text = ds.Tables[0].Rows[i]["Agent_Fax"].ToString();
                txtConcernPerson.Text = ds.Tables[0].Rows[i]["Concerned_Person"].ToString();
                txtContactPerson.Text = ds.Tables[0].Rows[i]["CSR_Contact_Person"].ToString();
                txtCreditLimit.Text = ds.Tables[0].Rows[i]["Credit_Limit"].ToString();
                //txtCsrEmailID.Text = ds.Tables[0].Rows[i]["CSR_Email"].ToString();
                txtPanNo.Text = ds.Tables[0].Rows[i]["Pan_No"].ToString();

                if (showStatus() == "Active")
                    ddlStatus.SelectedValue = "2";
                else
                    ddlStatus.SelectedValue = "5";
            }
            con.Close();

        }
        catch (SqlException sqlexx)
        {
            string err = sqlexx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void FillDataLoginMaster()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string str1 = Request.QueryString["Agent_Branch_ID"].ToString();
            com = new SqlCommand("select * from Login_Master where Agent_ID=@AgentBranchID", con);
            com.Parameters.AddWithValue("@AgentBranchID", str1);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp = ds.Tables[0].Rows.Count;
            for (int i = 0; i < temp; i++)
            {
                txtLogin.Text = ds.Tables[0].Rows[i]["Email_ID"].ToString();
                txtPassword.Text = ds.Tables[0].Rows[i]["Login_Password"].ToString();
                txtCity.Text = cityname();

            }
            con.Close();
        }
        catch (SqlException sqlExe)
        {
            string err = sqlExe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void splitAirlineAccess()
    {
        BindAirlineAccess();
         foreach (ListItem lt in CheckAirlineAccess.Items)
        {
            if (lt.Selected)
            {
                lt.Selected =false;              
            }               
          }
        string str = "";
        con = new SqlConnection(strCon);
        con.Open();
        
        try
        {
            string str2 = Request.QueryString["Agent_Branch_ID"].ToString();
            string select = "select Airline_Access from Login_Master where Agent_ID=@airline";
            com = new SqlCommand(select, con);
            com.Parameters.AddWithValue("@airline", str2);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp = ds.Tables[0].Rows.Count;
            for (int i = 0; i < temp; i++)
            {
                str = ds.Tables[0].Rows[i]["Airline_Access"].ToString();
            }
            //str = str.Remove(str.LastIndexOf(","));
            //string[] a = str.Split(',');
            //string str1 = string.Empty;
            //com = new SqlCommand("select (Airline_Code+'-'+Airline_Name) as NameCode,Airline_ID From Airline_Master where Airline_ID in("+str+")",con);
            com = new SqlCommand("select (Airline_Code+'-'+Airline_Name) as NameCode  From Airline_Master am inner join airline_detail ad on am.airline_id=ad.airline_id where Airline_detail_ID in(" + str + ")", con);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            //CheckAirlineAccess.DataSource = ds;
            //CheckAirlineAccess.DataTextField = "NameCode";
            //CheckAirlineAccess.DataValueField = "Airline_ID";
            //CheckAirlineAccess.DataBind();
            //CheckBoxList lst = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");


            //CheckBoxList chk = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                CheckAirlineAccess.Items[i].Selected = true;
            }
            com.Dispose();
            con.Close();
            //for (int i = 0; i < lst.Items.Count; i++)
            //{
            //    for (int j = 0; j < a.Length; j++)
            //    {
            //        if (lst.Items[i].Value == a[j])
            //        {
            //            lst.Items[i].Selected = true;

            //        }
            //    }
            //}

          
        }
        catch (SqlException exe)
        {
            string err1 = exe.Message;
            lblMessage.Text = err1;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void showagentBranchByAdmin()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string str3 = Request.QueryString["Agent_Branch_ID"].ToString();
            com = new SqlCommand("select Agent_Name from Agent_Master where agent_ID=(select Agent_ID from Agent_Branch where Agent_Branch_ID='" + str3 + "')", con);
            string nameagent = com.ExecuteScalar().ToString();
            txtAgentNameselectByAdmin.Text = nameagent;
            btnUpdate.Visible = true;
            // btnUpdateAdmin.Visible = true;
            tabform.Visible = true;
            con.Close();
        }
        catch (SqlException sqlex)
        {
            string err2 = sqlex.Message;
            lblMessage.Text = err2;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string cityname()
    {
        string cityname="";
        string str4 = Request.QueryString["Agent_Branch_ID"].ToString();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select  (city_Code+'-'+City_Name) as City from City_Master where City_ID=(select Belongs_To_City from Agent_Branch where Agent_Branch_ID='" + str4 + "')", con);
            cityname = com.ExecuteScalar().ToString();
            con.Close();
        }
        catch (SqlException sqlEXE)
        {
            string err2 = sqlEXE.Message;
            lblMessage.Text = err2;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return cityname;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (checkCityName())
        { 
             int m = CheckAirlineAccess.Items.Count;
             for (int i = 0; i < m; i++)
             {
                 CheckBoxList chk1 = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
                 if (chk1.Items[i].Selected == false)
                 {

                     lblMessage.Text = "Please Check AtLeast One Airline Access";
                     lblMessage.Visible = true;
                 }
                 else
                 {
                     UpdateData();
                 }
             }
        }
        else
        {
            lblMessage.Text = "Select Valid City Name";
            lblMessage.Visible = true;
        }
    }

    public void UpdateData()
    {
        
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string str4 = Request.QueryString["Agent_Branch_ID"].ToString();
            trans = con.BeginTransaction();
            string UpdateAgentBranch;

            // Find City name
            string citycode = txtCity.SelectedItem.Text;
            int m = citycode.IndexOf("-") + 1;
            citycode = citycode.Substring(0, m - 1);
            com = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con, trans);
            SqlDataReader dr1 = com.ExecuteReader();
            while (dr1.Read())
            {
                CityId = Convert.ToInt32(dr1["City_ID"].ToString());
            }
            dr1.Close();

            //*** check  Branch City 
            com = new SqlCommand("select Belongs_To_City from Agent_Branch where Agent_Branch_ID='" + str4 + "' and Belongs_To_City='" + CityId + "'", con, trans);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count == 1)
            {

                // Agent_Branch

                UpdateAgentBranch = "update Agent_Branch set Agent_Address=@Agent_Address,Credit_Limit=@Credit_Limit,Belongs_To_City=@Belongs_To_City,Agent_Phone=@Agent_Phone,Agent_Contactno=@Agent_Contactno,Agent_Fax=@AgentFax,Concerned_Person=@Concerned_Person,CSR_Contact_Person=@CSR_Contact_Person,Pan_No=@panno,Status=@Status where Agent_Branch_ID=@agentBranchid";
               com = new SqlCommand(UpdateAgentBranch, con, trans);
                com.Parameters.AddWithValue("@agentBranchid", str4);
                com.Parameters.AddWithValue("@Belongs_To_City", CityId);
                com.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
                com.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
                com.Parameters.AddWithValue("@Agent_Contactno", txtcontactno.Text);                
                com.Parameters.AddWithValue("@AgentFax", txtFax.Text);
                com.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
                com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                com.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
                
                //com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                //com.Parameters.AddWithValue("@CSREmail", txtCsrEmailID.Text);
                com.Parameters.AddWithValue("@panno", txtPanNo.Text);
                com.Parameters.AddWithValue("@Status",ddlStatus.SelectedValue);
                com.ExecuteNonQuery();

                // Login _Master

                com = new SqlCommand("select Login_Master_ID from  Login_Master where Agent_ID='" + str4 + "'", con, trans);
                string loginMasterid = com.ExecuteScalar().ToString();
                //**

                string updateQ3;
                updateQ3 = "update Login_Master set Login_Password=@login_Password, Airline_Access=@airline_Access,Group_ID=@Group_ID where Login_Master_ID=@loginMasterid";

                for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // VALUES store in listbox
                {
                    if (CheckAirlineAccess.Items[i].Selected)
                    {

                        ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
                    }
                }
                ts1 = ts1.Remove(ts1.LastIndexOf(","));
                com = new SqlCommand(updateQ3, con, trans);
                com.Parameters.AddWithValue("@login_Password", txtPassword.Text);
                com.Parameters.AddWithValue("@airline_Access", ts1);
                com.Parameters.AddWithValue("@Group_ID", ddlGroupName.SelectedValue);
                com.Parameters.AddWithValue("@loginMasterid", loginMasterid);
                com.ExecuteNonQuery();

                // select Branch Status
                string BranchHistory = "select Status_Name from Status_Master where Status_ID=(select Branch_Status From Agent_Branch where Agent_Branch_ID=@agentBranch_id)";
                com = new SqlCommand(BranchHistory, con, trans);
                com.Parameters.AddWithValue("@agentBranch_id", str4);
                string statusname = com.ExecuteScalar().ToString();

                // Agent_History



                string INSERTQ1 = "INSERT INTO dbo.Agent_History(Agent_Code,Login_ID,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,IATA_Code,IATA_Commission,Credit_Limit,Branch_Status,CSR_Contact_Person,Pan_No,Status,Entered_By,Entered_On)VALUES(@Agent_Code,@Login_ID,@Login_Password,@Group_Name,@Airline_Access,@Belongs_To_City,@Agent_Name,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@IATA_Code,@IATA_Commission,@Credit_Limit,@Branch_Status,@CSR_Contact_Person,@Pan_No,@Status,@Entered_By,@Entered_On)";

                // select Agent_Code

                com = new SqlCommand("select Agent_Code from Agent_Master where Agent_ID=(select Agent_ID from Agent_Branch where Agent_Branch_ID=@id)", con, trans);
                com.Parameters.AddWithValue("@id", str4);
                string AgentCode = com.ExecuteScalar().ToString();

                //

                com = new SqlCommand(INSERTQ1, con, trans);
                com.Parameters.AddWithValue("@Agent_Code", AgentCode);
                com.Parameters.AddWithValue("@Login_ID", txtLogin.Text);
                com.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
                com.Parameters.AddWithValue("@Group_Name", ddlGroupName.SelectedItem.Text);
                com.Parameters.AddWithValue("@Airline_Access", ts1);
                com.Parameters.AddWithValue("@Belongs_To_City", FindCityName());
                com.Parameters.AddWithValue("@Agent_Name", textAgentName.Text);
                com.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
                com.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
                com.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
                com.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
                com.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
                com.Parameters.AddWithValue("@IATA_Code", txtIATACode.Text);
                com.Parameters.AddWithValue("@IATA_Commission", txtIATAComm.Text);
                //com.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
                //com.Parameters.AddWithValue("@TDS_Exemption_Limit",txtTDSExemLimit.Text);
                com.Parameters.AddWithValue("@Credit_Limit",txtCreditLimit.Text );
                com.Parameters.AddWithValue("@Branch_Status", statusname);
                //com.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
                //com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                //com.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
                com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                com.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
                com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Text);
                com.Parameters.AddWithValue("@Entered_By", loginid);
                com.Parameters.AddWithValue("@Entered_On", TodayDate);
                com.ExecuteNonQuery();
                trans.Commit();
                lblMessage.Text = "Records Updated Successfuly";
                lblMessage.Visible = true;
                con.Close();


            }
            else 
            {

                com = new SqlCommand("Select Agent_Id from Agent_Branch where Agent_Branch_Id='" + str4 + "'", con,trans);
                string AgentnewID = com.ExecuteScalar().ToString();
                com.Dispose();
                //**
                com = new SqlCommand("select Belongs_To_City from Agent_Branch where Agent_ID='"+AgentnewID+"' and Belongs_To_City='"+CityId+"'",con,trans );
                 SqlDataReader dr2 = com.ExecuteReader();
                if (dr2.HasRows)
                {
                    lblMessage.Text = "City Name Already Exists";
                    lblMessage.Visible = true;
                    dr2.Close();
                   
                    
                }
                else
                {
                    dr1.Close();
                    dr2.Close();
                    UpdateAgentBranch = "update Agent_Branch set Agent_Address=@Agent_Address,Belongs_To_City=@Belongs_To_City,Agent_Phone=@Agent_Phone,Agent_Fax=@AgentFax,Concerned_Person=@Concerned_Person,CSR_Contact_Person=@CSR_Contact_Person,Pan_No=@panno,Status=@Status where Agent_Branch_ID=@agentBranchid";
                   SqlCommand com1 = new SqlCommand(UpdateAgentBranch, con, trans);
                    com1.Parameters.AddWithValue("@agentBranchid", str4);
                    com1.Parameters.AddWithValue("@Belongs_To_City", CityId);
                    com1.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
                    com1.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
                    com1.Parameters.AddWithValue("@AgentFax", txtFax.Text);
                    com1.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
                    com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                    //com.Parameters.AddWithValue("@CSREmail", txtCsrEmailID.Text);
                    com1.Parameters.AddWithValue("@panno", txtPanNo.Text);
                    com1.Parameters.AddWithValue("@Status", ddlStatus.SelectedValue);
                   
                    com1.ExecuteNonQuery();

                    // Login _Master

                    com = new SqlCommand("select Login_Master_ID from  Login_Master where Agent_ID='" + str4 + "'", con, trans);
                    string loginMasterid = com.ExecuteScalar().ToString();
                    //**

                    string updateQ3;
                    updateQ3 = "update Login_Master set Login_Password=@login_Password, Airline_Access=@airline_Access,Group_ID=@Group_ID where Login_Master_ID=@loginMasterid";

                    for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // VALUES store in listbox
                    {
                        if (CheckAirlineAccess.Items[i].Selected)
                        {

                            ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
                        }
                    }
                    ts1 = ts1.Remove(ts1.LastIndexOf(","));
                    com = new SqlCommand(updateQ3, con, trans);
                    com.Parameters.AddWithValue("@login_Password",txtPassword.Text);
                    com.Parameters.AddWithValue("@airline_Access", ts1);
                    com.Parameters.AddWithValue("@Group_ID", ddlGroupName.SelectedValue);
                    com.Parameters.AddWithValue("@loginMasterid", loginMasterid);
                    com.ExecuteNonQuery();

                    // select Branch Status
                    string BranchHistory = "select Status_Name from Status_Master where Status_ID=(select Branch_Status From Agent_Branch where Agent_Branch_ID=@agentBranch_id)";
                    com = new SqlCommand(BranchHistory, con, trans);
                    com.Parameters.AddWithValue("@agentBranch_id", str4);
                    string statusname = com.ExecuteScalar().ToString();

                    // Agent_History



                    string INSERTQ1 = "INSERT INTO dbo.Agent_History(Agent_Code,Login_ID,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,IATA_Code,IATA_Commission,Credit_Limit,Branch_Status,CSR_Contact_Person,Pan_No,Status,Entered_By,Entered_On)VALUES(@Agent_Code,@Login_ID,@Login_Password,@Group_Name,@Airline_Access,@Belongs_To_City,@Agent_Name,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@IATA_Code,@IATA_Commission,@Credit_Limit,@Branch_Status,@CSR_Contact_Person,@Pan_No,@Status,@Entered_By,@Entered_On)";

                    // select Agent_Code

                    com = new SqlCommand("select Agent_Code from Agent_Master where Agent_ID=(select Agent_ID from Agent_Branch where Agent_Branch_ID=@id)", con, trans);
                    com.Parameters.AddWithValue("@id", str4);
                    string AgentCode = com.ExecuteScalar().ToString();

                    //

                    com = new SqlCommand(INSERTQ1, con, trans);
                    com.Parameters.AddWithValue("@Agent_Code", AgentCode);
                    com.Parameters.AddWithValue("@Login_ID", txtLogin.Text);
                    com.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
                    com.Parameters.AddWithValue("@Group_Name", ddlGroupName.SelectedItem.Text);
                    com.Parameters.AddWithValue("@Airline_Access", ts1);
                    com.Parameters.AddWithValue("@Belongs_To_City", FindCityName());
                    com.Parameters.AddWithValue("@Agent_Name", textAgentName.Text);
                    com.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
                    com.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
                    com.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
                    com.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
                    com.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
                    com.Parameters.AddWithValue("@IATA_Code", txtIATACode.Text);
                    com.Parameters.AddWithValue("@IATA_Commission", txtIATAComm.Text);
                    //com.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
                    //com.Parameters.AddWithValue("@TDS_Exemption_Limit",txtTDSExemLimit.Text );
                    com.Parameters.AddWithValue("@Credit_Limit",txtCreditLimit.Text);
                    com.Parameters.AddWithValue("@Branch_Status", statusname);
                    //com.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
                    //com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                    //com.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
                    com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                    com.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
                    com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Text);
                    com.Parameters.AddWithValue("@Entered_By", loginid);
                    com.Parameters.AddWithValue("@Entered_On", TodayDate);
                    com.ExecuteNonQuery();
                    trans.Commit();
                    lblMessage.Text = "Records Updated Successfuly";
                    lblMessage.Visible = true;
                    con.Close();


                }
                dr2.Close();
            }
            
        }
        catch (SqlException sqlexep)
        {
            string err = sqlexep.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
            trans.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Response.Redirect("ViewAgentBranch.aspx");
    }
    //protected void txtCity_TextChanged(object sender, EventArgs e)
    //{
    //    BindAirlineAccess();
    //}
    protected void txtCity_SelectedIndexChanged(object sender, EventArgs e)
    { 
        
        BindAirlineAccess();
        //if (CheckAirlineAccess.SelectedItem.Value == "")
        //{
        //    lblMessage.Text = "No";

        //    pnlCheck.Visible = false;
        //}
        //else
        //{

        //    BindAirlineAccess();
        //}
    }
    protected void btn_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewAgentBranch.aspx");
    }
}



