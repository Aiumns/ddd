using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

// This Page is Design & Coding By Alok Date:28.11.2007


public partial class Delivery_Order : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataSet ds;
    SqlDataReader dr;
    SqlTransaction trans;
    string Import_AWB_ID;
    string finalDon;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnDelivery.Attributes.Add("onclick", "return CheckEmpty();");
            lblDate.Value = DateTime.Now.ToString("dd/MM/yyyy");
            string str1;
            if (!IsPostBack && Request.QueryString["Import_AWB_ID"] != null)
            {
               
                con = new SqlConnection(strCon);
                try
                {


                    Import_AWB_ID = Convert.ToString(Request.QueryString["Import_AWB_ID"]);
                    str1 = "select IFO.Import_Flight_Open_ID as 'Import_Flight_Open_ID',IA.Import_AWB_No as 'Import_AWB_No',IA.Agent_Name as 'Agent_Name',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight',IFO.Import_Flight_No as'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IA.Nature_of_Goods as 'Nature_of_Goods',IA.CAN_Status as 'CAN_Status',IA.Delivery_Order as 'Delivery_Order',IA.No_of_Houses as 'No_of_Houses',IA.Freight_Type as 'Freight_Type',IA.Delivery_Order_Rate_House as 'Delivery_Order_Rate_House',IA.Delivery_Order_Rate_Master as 'Delivery_Order_Rate_Master' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID  where IA.Import_AWB_ID='" + Import_AWB_ID + "'";
                    btnupdate.Visible = false;
                    btnDelivery.Visible = true;
                    con.Open();
                    trans = con.BeginTransaction();
                    com = new SqlCommand(str1, con, trans);
                    dr = com.ExecuteReader();
                    dr.Read();

                    txtAwb.Text = dr["Import_AWB_No"].ToString();
                    txtAgentName.Text = dr["Agent_Name"].ToString();
                    txtFltNo.Text = dr["Import_Flight_No"].ToString();
                    txtFlDate.Text = dr["Flight_Date"].ToString();
                    txtContents.Text = dr["Nature_of_Goods"].ToString();
                    txtGw.Text = dr["Gross_Weight"].ToString();
                    txtPcs.Text = dr["No_of_Packages"].ToString();
                    txtNoOfHouses.Text = dr["No_of_Houses"].ToString();
                    lblDlhouseRate.Value = dr["Delivery_Order_Rate_House"].ToString();
                    lblDlRateMaster.Value = dr["Delivery_Order_Rate_Master"].ToString();
                    lblStaus.Text = dr["Delivery_Order"].ToString();

                    double MAWB = double.Parse(txtNoOfHouses.Text.Trim()) * double.Parse(lblDlRateMaster.Value.Trim());
                    txtMAwbAmt.Text = MAWB.ToString();
                    double HAWB = double.Parse(txtNoOfHouses.Text.Trim()) * double.Parse(lblDlhouseRate.Value.Trim());
                    txtHAwbAmt.Text = HAWB.ToString();
                    txtDeliveryDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    dr.Close();

                    string strAwb = txtAwb.Text;
                    int AW = strAwb.IndexOf("-");
                    string strAwb1 = strAwb.Substring(0, AW);
                    string str11 = "select Airline_Text_Code from Airline_Master where Airline_Code='" + strAwb1 + "'";
                    com = new SqlCommand(str11, con, trans);
                    dr = com.ExecuteReader();
                    dr.Read();
                    string ATC = dr["Airline_Text_Code"].ToString();
                    string YR = DateTime.Now.ToString("yyyy");
                    dr.Close();
                    string DON = "select isnull(max(Delivery_Order_No),null) from Delivery_Order where Delivery_Order_No like '" + ATC + "%' group by Delivery_Order_No";
                    com = new SqlCommand(DON, con, trans);
                    da = new SqlDataAdapter(com);
                    ds = new DataSet();
                    da.Fill(ds);
                    string cot = "1";
                    if (ds.Tables[0].Rows.Count <= 0)
                    {
                        finalDon = ATC + '/' + cot + '/' + YR;
                    }
                    else
                    {
                        for (int i = 0; i <= ds.Tables[0].Rows.Count; i++)
                        {
                            int cot1 = Convert.ToInt32(cot);
                            cot1 = cot1 + i;
                            finalDon = ATC + '/' + cot1 + '/' + YR;
                        }
                    }
                    txtDNo.Text = finalDon;
                    string S_charge1 = "select Service_Tax from Fix_Charges";
                    com = new SqlCommand(S_charge1, con,trans);
                    dr = com.ExecuteReader();
                    dr.Read();
                    lblStax.Value = dr["Service_Tax"].ToString();
                    dr.Close();
                    if (lblStaus.Text == "13")
                    {
                        //btnDelivery.Visible = false;
                        btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                        btnDelivery.Visible = false;
                        btnupdate.Visible = true;
                        string strdel = "select IFO.Import_Flight_Open_ID as 'Import_Flight_Open_ID',IA.Import_AWB_No as 'Import_AWB_No',DM.Destination_Name as 'Destination_Name',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight',IFO.Import_Flight_No as'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IFO.IGM_No as 'IGM_No',convert(varchar,IFO.IGM_Date,103) as 'IGM_Date',IA.Nature_of_Goods as 'Nature_of_Goods',IA.CAN_Status as 'CAN_Status',IA.Delivery_Order as 'Delivery_Order',IA.No_of_Houses as 'No_of_Houses',IA.Freight_Type as 'Freight_Type',IA.Delivery_Order_Rate_House as 'Delivery_Order_Rate_House',IA.Delivery_Order_Rate_Master as 'Delivery_Order_Rate_Master',DO.Delivery_Order_No as 'Delivery_Order_No',convert(varchar,DO.Delivery_Order_Date,103) as Delivery_Order_Date,DO.No_of_Packages as 'No_of_Packages',DO.Gross_Weight as 'Gross_Weight',DO.Master_AWB_Amount as 'Master_AWB_Amount',DO.House_AWB_Amount as 'House_AWB_Amount',DO.Deliver_To as 'Deliver_To',IA.Amount_Received  as 'Amount_Received',DO.Other_Charges as 'Other_Charges' ,DO.Other_Charges_Description as 'Other_Charges_Description',DO.Service_Tax_Amount as 'Service_Tax_Amount'  from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID inner join Delivery_Order  DO  on DO.Import_AWB_ID=IA.Import_AWB_ID inner join Destination_Master DM on IFO.Import_Origin=DM.Destination_ID where IA.Import_AWB_ID='" + Import_AWB_ID + "'";
                        com = new SqlCommand(strdel, con, trans);
                        dr = com.ExecuteReader();
                        dr.Read();
                        txtDNo.Text = dr["Delivery_Order_No"].ToString();
                        txtDeliveryDate.Text = dr["Delivery_Order_Date"].ToString();
                        txtPcs.Text = dr["No_of_Packages"].ToString();
                        txtGw.Text = dr["Gross_Weight"].ToString();
                        txtMAwbAmt.Text = dr["Master_AWB_Amount"].ToString();
                        txtHAwbAmt.Text = dr["House_AWB_Amount"].ToString();
                        txtDeliverTo.Text = dr["Deliver_To"].ToString();
                        txtNoOfHouses.Text = dr["No_of_Houses"].ToString();
                        txtAmtRec.Text = dr["Amount_Received"].ToString();
                        txtOthers.Text = dr["Other_Charges"].ToString();
                        txtDescription.Text = dr["Other_Charges_Description"].ToString();
                        txtServiceTax.Text = dr["Service_Tax_Amount"].ToString();
                        //txtDNo.ReadOnly = true;
                        //txtDeliveryDate.ReadOnly = true;
                        //txtPcs.ReadOnly = true;
                        //txtGw.ReadOnly = true;
                        //txtMAwbAmt.ReadOnly = true;
                        //txtHAwbAmt.ReadOnly = true;
                        //txtDeliverTo.ReadOnly = true;
                        //txtNoOfHouses.ReadOnly = true;
                        //txtAmtRec.ReadOnly = true;
                        //txtOthers.ReadOnly = true;
                        //txtDescription.ReadOnly = true;
                        //txtServiceTax.ReadOnly = true;
                        dr.Close();
                    }
                    trans.Commit();
                    con.Close();

                }
                catch (SqlException se)
                {
                    string err = se.Message;
                    trans.Rollback();
                    lblmsg.Text = err;
                }
                catch (Exception se)
                {
                    string err = se.Message;
                    lblmsg.Text = err;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Browse_ImportAwb.aspx");
    }

    public string ConvertDate(string strD)
    {

        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];

    }
    protected void btnDelivery_Click(object sender, EventArgs e)
    {
       
        Add1();
       
                  
    }

   
    public void Add1()
    {
        con = new SqlConnection(strCon);//Making Connection
        string UpdateQ, InsertQ, DoDate;
        DoDate = ConvertDate(txtDeliveryDate.Text);
        try
        {
            con.Open();
            trans = con.BeginTransaction();

            {
                decimal amt_rec = (txtAmtRec.Text.Trim() == "" ? 0 : decimal.Parse(txtAmtRec.Text));
                decimal other_chg = (txtOthers.Text.Trim() == "" ? 0 : decimal.Parse(txtOthers.Text));
                decimal stx = (txtServiceTax.Text.Trim() == "" ? 0 : decimal.Parse(txtServiceTax.Text));
                //decimal dl_to = (Deliver_To.Text.Trim() == "" ? 0 : decimal.Parse(Deliver_To.Text));
                InsertQ = "insert into Delivery_Order(Import_AWB_ID,Delivery_Order_No,Delivery_Order_Date,No_of_Packages,Gross_Weight,Master_AWB_Amount,House_AWB_Amount,Deliver_To,Other_Charges,Other_Charges_Description,Service_Tax_Amount) values('" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "','" + txtDNo.Text + "','" + DoDate + "','" + txtPcs.Text.Trim() + "','" + txtGw.Text.Trim() + "','" + txtMAwbAmt.Text.Trim() + "','" + txtHAwbAmt.Text.Trim() + "','" + txtDeliverTo.Text.Trim() + "','" + other_chg + "','" + txtDescription.Text.Trim() + "','" + stx + "')";

                com = new SqlCommand(InsertQ, con, trans);
                com.ExecuteNonQuery();
                //Update Import_AWB table
                UpdateQ = "update Import_AWB set Delivery_Order='13',Gross_Weight='" + txtGw.Text + "',No_of_Packages='" + txtPcs.Text + "',No_of_Houses='" + txtNoOfHouses.Text + "',Amount_Received='" + amt_rec + "' where Import_AWB_ID='" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "'";
                com = new SqlCommand(UpdateQ, con, trans);
                com.ExecuteNonQuery();

            }

            trans.Commit();
            con.Close();
            Response.Redirect("Browse_ImportAwb.aspx");

        }
        catch (SqlException se)
        {
            string err = se.Message;
            trans.Rollback();
            lblmsg.Text = err;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
        UpdateDO();
    }
    public void UpdateDO()
    {
        con = new SqlConnection(strCon);//Making Connection
        string UpdateQ, InsertQ, DoDate;
        DoDate = ConvertDate(txtDeliveryDate.Text);
        try
        {
            con.Open();
            trans = con.BeginTransaction();

            {
                decimal amt_rec1 = (txtAmtRec.Text.Trim() == "" ? 0 : decimal.Parse(txtAmtRec.Text));
                decimal other_chg1 = (txtOthers.Text.Trim() == "" ? 0 : decimal.Parse(txtOthers.Text));
                decimal stx = (txtServiceTax.Text.Trim() == "" ? 0 : decimal.Parse(txtServiceTax.Text));
                InsertQ = "update Delivery_Order set Import_AWB_ID='" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "',Delivery_Order_No='" + txtDNo.Text + "',Delivery_Order_Date='" + DoDate + "',No_of_Packages='" + txtPcs.Text.Trim() + "',Gross_Weight='" + txtGw.Text.Trim() + "',Master_AWB_Amount='" + txtMAwbAmt.Text.Trim() + "',House_AWB_Amount='" + txtHAwbAmt.Text.Trim() + "',Deliver_To='" + txtDeliverTo.Text.Trim() + "',Other_Charges='" + other_chg1 + "',Other_Charges_Description='" + txtDescription.Text + "',Service_Tax_Amount='" + stx + "'";

                com = new SqlCommand(InsertQ, con, trans);
                com.ExecuteNonQuery();
                //Update Import_AWB table
                UpdateQ = "update Import_AWB set Delivery_Order='13',Gross_Weight='" + txtGw.Text + "',No_of_Packages='" + txtPcs.Text + "',No_of_Houses='" + txtNoOfHouses.Text + "',Amount_Received='" + amt_rec1 + "' where Import_AWB_ID='" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "'";
                com = new SqlCommand(UpdateQ, con, trans);
                com.ExecuteNonQuery();

            }

            trans.Commit();
            con.Close();
            Response.Redirect("Browse_ImportAwb.aspx");

        }
        catch (SqlException se)
        {
            string err = se.Message;
            trans.Rollback();
            lblmsg.Text = err;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

}
