﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class CompanyWise_TDS : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    SqlTransaction trans = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadFinancialYear();
            LoadAgentName();
        }
    }
    public void LoadFinancialYear()
    {
        string FinancialYear = String.Empty;
        string CSR_Date = (DateTime.Now.ToShortDateString());
        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[1];
        string strMM = d[0];
        string strYYYY = d[2];
        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            int FYF = 0;
            int FYL = 0;
            FinancialYearFirst = DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = LastYear.ToString();
            FinancialYear = FinancialYearFirst.ToString() + "-" + FinancialYearLast.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);
            FYF = int.Parse(FinancialYearFirst) - 1;
            FYL = int.Parse(FinancialYearLast) - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);
            FYF = FYF - 1;
            FYL = FYL - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);
        }
        else
        {
            int FYF = 0;
            int FYL = 0;
            FinancialYearLast = DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = LastYear.ToString();
            FinancialYear = FinancialYearFirst.ToString() + "-" + FinancialYearLast.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);
            FYF = int.Parse(FinancialYearFirst) - 1;
            FYL = int.Parse(FinancialYearLast) - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);
            FYF = FYF - 1;
            FYL = FYL - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);
        }
    }
    public void LoadAgentName()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("Company_Getlist", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = com.ExecuteReader();
            ddlCompany.Items.Insert(0, "- -Select- -");
            ddlCompany.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlCompany.Items.Add(new ListItem(dr["Company_Name"].ToString(), dr["Company_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string URL = "CompanyWise_TDS_Show.aspx?Company_ID="+ddlCompany.SelectedValue+"&Fin_Year="+ddlFinancialYear.SelectedValue+"&Company_Name="+ddlCompany.SelectedItem.Text+"";
        ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open( '" + URL + "');</script>");
    }
}
