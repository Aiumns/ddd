﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class CompanyWise_TDS_Show : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    decimal aaloklimit = 0;
    string flag = "F";
    string flag_Total = "F";
    SqlDataReader dr = null;
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    SqlDataAdapter da;
    DataTable dt;
    SqlTransaction trans = null;
    string table = "";
    
   
    protected void Page_Load(object sender, EventArgs e)
    {
        string CompanyID = Request.QueryString["Company_ID"].ToString();
        string[] ddlfnArray = Request.QueryString["Fin_Year"].ToString().Split('-');
        string v_from = "04/01/" + ddlfnArray[0];
        string v_To = "03/31/" + ddlfnArray[1];
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string selectQ = null;
            selectQ = "select distinct AT.Agent_TDS_Id as 'Agent_TDS_Id',AG.Agent_Name as 'Agent_Name',CM.Company_Name as 'Company_Name',AT.Airline_Detail_ID,AT.Exempted_TDS_Rate as 'Exempted_TDS_Rate',AT.TDS_Exemption_Limit as 'TDS_Exemption_Limit',(case when AT.TDS_Status_Limited='14' then 'Unlimited' else 'Limited' end ) as 'TDS_Status_Limited',AT.Education_Cess as 'Education_Cess',convert(varchar,AT.Valid_From ,103) as 'Valid_From',convert(varchar,AT.Valid_To ,103) as 'Valid_To',AT.Entered_By as 'Entered_By',AT.Entered_On as 'Entered_On',AT.Remarks as 'Remarks' from Agentwise_TDS AT  inner join Company_Master CM on CM.Company_ID=AT.Company_ID inner join Agent_master AG on AG.Agent_ID=AT.Agent_Id  where at.agent_id in (SELECT Agent_ID FROM dbo.Agent_Master ) and valid_from>='" + v_from.ToString() + "' and valid_to<='" + v_To.ToString() + "' AND cm.Company_ID=" + CompanyID + " order by Agent_Name";
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            con.Close();

            lblheader.Text = "<table width=100%  border=0 cellspacing=0 cellpadding=0  align=center ><tr><td><br/></td></tr><tr align=center  ><td><h2>AgentWise TDS Limit Report</h2></td></tr><tr align=center><td><h3>" + Request.QueryString["Company_Name"].ToString() + "</h3> </td></tr><tr align=center ><td><h4>" + FormatDateMM(v_from) + " - " + FormatDateMM(v_To) + "</h4></td></tr><tr><td><br/></td></tr></table>";

            table += "<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle1><td align=center>SNo</td><td align=center>Company Name</td><td align=center>Agent Name</td><td align=center>Airline Name</td><td align=center>Exemption Limit</td><td align=center>Used Limit</td><td align=center>Exemption Rate</td><td align=center>Valid From</td><td align=center>Valid To</td></tr>";
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    table += @"<tr class=tabletd><td align=left>" + (i+1) + "</td><td align=left>" + dt.Rows[i]["Company_Name"].ToString() + "</td><td align=left>" + dt.Rows[i]["Agent_Name"].ToString() + "</td>";

                    
                    if (dt.Rows[0]["TDS_Status_Limited"].ToString() == "Limited")
                    {
                        Details(dt.Rows[i]["Agent_TDS_Id"].ToString());
                    }
                    else
                    {
                        Details_unlimited(dt.Rows[i]["Agent_TDS_Id"].ToString());
                    }
                    table += @"<td align=right>" + dt.Rows[i]["Exempted_TDS_Rate"].ToString() + "</td><td align=left>" + dt.Rows[i]["Valid_From"].ToString() + "</td><td align=left>" + dt.Rows[i]["Valid_To"].ToString() + "</td></tr>";
                }
                lblDetails.Text = table.ToString();
            }
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void Details_unlimited(string Agent_TDS_ID)
    {
        string F_Year = Request.QueryString["Fin_Year"].ToString();
        string[] Arr = F_Year.Split('-');
        DataTable dtinnerul = dw.GetAllFromQuery("Select  AT.AGENT_ID,AT.Airline_Detail_ID,C.COMPANY_NAME,Exempted_TDS_Rate,TDS_Exemption_Limit,CONVERT(VARCHAR,Valid_From,103)AS Valid_From,CONVERT(VARCHAR,Valid_To,103)AS Valid_To,TDS_Status_Limited  from Agentwise_TDS AT INNER JOIN COMPANY_MASTER C ON C.COMPANY_ID=AT.COMPANY_ID where Agent_TDS_Id=" + Agent_TDS_ID + " and C.Company_ID=" + Request.QueryString["Company_ID"].ToString() + "");
        if (dtinnerul.Rows.Count > 0)
        {

            string Airline_Access = dtinnerul.Rows[0]["Airline_Detail_ID"].ToString();
            string[] Arr_Airline = Airline_Access.Split(',');
            decimal Limit = 0;
            string Limit_Status = "";
            if (dtinnerul.Rows[0]["TDS_Status_Limited"].ToString() == "13")
            {
                Limit = decimal.Parse(dtinnerul.Rows[0]["TDS_Exemption_Limit"].ToString());
                Limit_Status = "Limited";
            }
            else
            {
                Limit_Status = "Unlimited";
            }
            string Start = "04/01/" + Arr[0];
            string End = "03/31/" + Arr[1];
            string Limit_Start = ConvertDate(dtinnerul.Rows[0]["Valid_From"].ToString());
            string Limit_End = ConvertDate(dtinnerul.Rows[0]["Valid_To"].ToString());
            decimal Total_TDS = 0;
            string Class_ = "";
            string str = string.Empty;
            for (int i = 0; i < Arr_Airline.Length; i++)
            {
                DataTable dt_Air = dw.GetAllFromQuery("SELECT AM.AIRLINE_NAME,AM.Airline_Text_Code,CM.CITY_CODE FROM AIRLINE_MASTER AM INNER JOIN AIRLINE_DETAIL AD ON AM.AIRLINE_ID=AD.AIRLINE_ID INNER JOIN CITY_MASTER CM ON AD.BELONGS_TO_CITY=CM.CITY_ID WHERE AIRLINE_DETAIL_ID in (" + Arr_Airline.GetValue(i) + ")");
                if (dt_Air.Rows.Count > 0)
                {
                    // STRING CONCATENATION
                    str = str + (dt_Air.Rows[0]["Airline_Text_Code"].ToString().Trim() + "-" + dt_Air.Rows[0]["city_code"].ToString().Trim() + ",");
                }
            }
            str = str.Remove(str.LastIndexOf(","));

            table += @"<td align=left>" + str + "</td><td align=right>" + Limit + "</td>";

            string Query_Part = "";
            string AgntId = "";
            DataTable dtParentId = dw.GetAllFromQuery("select distinct agent_id from Agentwise_TDS where parent_id=(select agent_id from Agentwise_TDS where Agent_TDS_Id=" + Agent_TDS_ID + " ) AND company_id=(select company_id from Agentwise_TDS where Agent_TDS_Id=" + Agent_TDS_ID + ")");
            if (dtParentId.Rows.Count > 0)
            {
                for (int j = 0; j < dtParentId.Rows.Count; j++)
                {
                    AgntId += dtParentId.Rows[j]["agent_id"].ToString() + ",";
                }
                AgntId = AgntId + dtinnerul.Rows[0]["AGENT_ID"].ToString();
                Query_Part = "Agent_ID in (" + AgntId + ") AND AIRLINE_DETAIL_ID IN (" + Airline_Access + ") AND ((csr_DATE) BETWEEN '" + Start + "'  AND '" + Limit_End + "') AND status=11 ORDER BY TDS,sales_id";
            }
            else
            {
                Query_Part = "Agent_ID in(" + dtinnerul.Rows[0]["AGENT_ID"].ToString() + ") AND AIRLINE_DETAIL_ID IN (" + Airline_Access + ") AND ((csr_DATE) BETWEEN '" + Start + "'  AND '" + Limit_End + "') AND status=11 ORDER BY TDS,sales_id";
            }
            con = new SqlConnection(strCon);
            con.Open();
            ////com = new SqlCommand("TDS_DETAILS_AWBWISE", con);
            com = new SqlCommand("TDS_DETAILS_AWBWISE_temp", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("Agent_Id", Query_Part);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                int count = 0;
                flag_Total = "F";
                decimal TDSable_Amt = 0;
                decimal tdsable_amt_cal = 0;
                decimal discount = 0;
                decimal tdsable_discount = 0;
                while (dr.Read())
                {
                    decimal TDS_Rate = Convert.ToDecimal(dr["TDS"].ToString());
                    if (Limit_Status == "Unlimited")
                    {
                        if (TDS_Rate == Convert.ToDecimal(dr["TDS"].ToString()))
                        {
                            discount = Math.Ceiling(decimal.Parse(dr["Discount"].ToString()));
                            tdsable_amt_cal = decimal.Parse(dr["TDSABLE_AMOUNT"].ToString());
                            if (dr["Freight_type"].ToString().Trim() == "Collect")
                            {
                                tdsable_discount = Math.Ceiling((tdsable_amt_cal)) + Math.Round((discount), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                tdsable_discount = Math.Ceiling((tdsable_amt_cal));
                            }
                            Total_TDS += tdsable_discount;
                            TDS_Rate = Convert.ToDecimal(dr["TDS"].ToString());
                            if (TDS_Rate < 10)
                                TDSable_Amt += tdsable_discount;
                            if (dr["TDS"].ToString() != "10.00")
                                aaloklimit = aaloklimit + tdsable_discount;
                            count++;
                        }
                        else
                        {
                            TDS_Rate = 0;
                            TDSable_Amt = 0;
                        }
                    }
                }

                table += @"<td align=right>" + Math.Ceiling(TDSable_Amt) + "</td>";
            }
            else
            {
                table += @"<td align=right>0</td>";
            }
            //}
        }

        else
        {
            table += @"<td align=right>0</td>";
        }
    }
    public void Details(string Agent_TDS_ID)
    {
        string F_Year = Request.QueryString["Fin_Year"].ToString();
        string[] Arr = F_Year.Split('-');
        
        DataTable dtinner = dw.GetAllFromQuery("Select AT.AGENT_ID,AT.Airline_Detail_ID,C.COMPANY_NAME,Exempted_TDS_Rate,TDS_Exemption_Limit,CONVERT(VARCHAR,Valid_From,103)AS Valid_From,CONVERT(VARCHAR,Valid_To,103)AS Valid_To,TDS_Status_Limited  from Agentwise_TDS AT INNER JOIN COMPANY_MASTER C ON C.COMPANY_ID=AT.COMPANY_ID where Agent_TDS_Id=" + Agent_TDS_ID + " and C.Company_ID=" + Request.QueryString["Company_ID"].ToString() + "");
        if (dtinner.Rows.Count > 0)
        {
            string Airline_Access = dtinner.Rows[0]["Airline_Detail_ID"].ToString();
            string[] Arr_Airline = Airline_Access.Split(',');
            decimal Limit = 0;
            string Limit_Status = "";
            if (dtinner.Rows[0]["TDS_Status_Limited"].ToString() == "13")
            {
                Limit = decimal.Parse(dtinner.Rows[0]["TDS_Exemption_Limit"].ToString());
                Limit_Status = "Limited";
            }
            else
            {
                Limit_Status = "Unlimited";
            }
            string str = string.Empty;
            for (int i = 0; i < Arr_Airline.Length; i++)
            {
                DataTable dt_Air = dw.GetAllFromQuery("SELECT AM.AIRLINE_NAME,AM.Airline_Text_Code,CM.CITY_CODE FROM AIRLINE_MASTER AM INNER JOIN AIRLINE_DETAIL AD ON AM.AIRLINE_ID=AD.AIRLINE_ID INNER JOIN CITY_MASTER CM ON AD.BELONGS_TO_CITY=CM.CITY_ID WHERE AIRLINE_DETAIL_ID in (" + Arr_Airline.GetValue(i) + ")");
                if (dt_Air.Rows.Count > 0)
                {
                    // STRING CONCATENATION
                    str = str + (dt_Air.Rows[0]["Airline_Text_Code"].ToString().Trim() + "-" + dt_Air.Rows[0]["city_code"].ToString().Trim() + ",");
                }
            }
            str = str.Remove(str.LastIndexOf(","));

            table += @"<td align=left>" + str + "</td><td align=right>" + Limit + "</td>";
            string Start = "04/01/" + Arr[0];
            string End = "03/31/" + Arr[1];
            string Limit_Start = ConvertDate(dtinner.Rows[0]["Valid_From"].ToString());
            string Limit_End = ConvertDate(dtinner.Rows[0]["Valid_To"].ToString());
            decimal Total_TDS = 0;
            string Class_ = "";
           
            ////string Query_Part = "" + dt.Rows[0]["AGENT_ID"].ToString() + " AND AIRLINE_DETAIL_ID IN (" + Airline_Access + ") AND ((csr_DATE) BETWEEN '" + Start + "'  AND '" + Limit_End + "') AND status=11 ORDER BY TDS,sales_id";
            string Query_Part = "";
            string AgntId = "";
            DataTable dtParentId = dw.GetAllFromQuery("select distinct agent_id from Agentwise_TDS where parent_id=(select agent_id from Agentwise_TDS where Agent_TDS_Id=" + Agent_TDS_ID + " ) AND company_id=(select company_id from Agentwise_TDS where Agent_TDS_Id=" + Agent_TDS_ID + ")");
            if (dtParentId.Rows.Count > 0)
            {
                for (int j = 0; j < dtParentId.Rows.Count; j++)
                {
                    AgntId += dtParentId.Rows[j]["agent_id"].ToString() + ",";
                }
                AgntId = AgntId + dtinner.Rows[0]["AGENT_ID"].ToString();
                Query_Part = "Agent_ID in (" + AgntId + ") AND AIRLINE_DETAIL_ID IN (" + Airline_Access + ") AND ((csr_DATE) BETWEEN '" + Start + "'  AND '" + Limit_End + "') AND status=11 ORDER BY TDS,sales_id";
            }
            else
            {
                Query_Part = "Agent_ID in(" + dtinner.Rows[0]["AGENT_ID"].ToString() + ") AND AIRLINE_DETAIL_ID IN (" + Airline_Access + ") AND ((csr_DATE) BETWEEN '" + Start + "'  AND '" + Limit_End + "') AND status=11 ORDER BY TDS,sales_id";
            }
            con = new SqlConnection(strCon);
            con.Open();
            ////com = new SqlCommand("TDS_DETAILS_AWBWISE", con);
            com = new SqlCommand("TDS_DETAILS_AWBWISE_temp", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("Agent_Id", Query_Part);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                //Response.Write(@"<TD style='text-align: right;'class=boldtext>EDCESS Amount</TD>");
                int count = 0;
                flag_Total = "F";
                decimal TDSable_Amt = 0;
                decimal TDSable_Amt_AboveLimit = 0;
                decimal tdsable_amt_cal = 0;
                decimal discount = 0;
                decimal tdsable_discount = 0;
               
                while (dr.Read())
                {
                    decimal TDS_Rate = Convert.ToDecimal(dr["TDS"].ToString());
                    if (Limit_Status == "Limited")
                    {
                        if (TDS_Rate == Convert.ToDecimal(dr["TDS"].ToString()))
                        {
                            discount = Math.Ceiling(decimal.Parse(dr["Discount"].ToString()));
                            tdsable_amt_cal = decimal.Parse(dr["TDSABLE_AMOUNT"].ToString());
                            if (dr["Freight_type"].ToString().Trim() == "COLLECT")
                            {
                                tdsable_discount = Math.Ceiling((tdsable_amt_cal)) + Math.Round((discount), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                tdsable_discount = Math.Ceiling(tdsable_amt_cal);
                            }
                            //if(TDS_Rate<10)
                            Total_TDS += tdsable_discount;
                            TDS_Rate = Convert.ToDecimal(dr["TDS"].ToString());
                            if (TDS_Rate < 10)
                                TDSable_Amt += tdsable_discount;
                            else
                                TDSable_Amt_AboveLimit += tdsable_discount;
                           

                            if (dr["TDS"].ToString() != "10.00")
                                aaloklimit = aaloklimit + tdsable_discount;
                            count++;
                        }
                    }
                }
                table += @"<td align=right>" + Math.Ceiling(TDSable_Amt) + "</td>";
            }
            else
            {
                table += @"<td align=right>0</td>";
            }
            //}
        }
        else
        {
            table += @"<td align=right>0</td>";
        }
        
    }

    protected string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    
}
