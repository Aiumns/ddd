﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class AwbTo_Issue_UnIssueStage : System.Web.UI.Page
{
    SqlConnection con=null;
    SqlDataAdapter da;
    SqlCommand com;
    DataTable dt;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;    // connectionString
    protected void Page_Load(object sender, EventArgs e)
    {
        //btnSubmit.Attributes.Add("onclick", "return CheckEmpty()");

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            return;
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
            {
        DataTable dtawb = dw.GetAllFromQuery("select * from stock_master where airwaybill_no='" + txtawb.Text + "'");
        if (dtawb.Rows.Count > 0)
        {
            if (ddlawb.SelectedValue == "8")
            {
                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand cmd = new SqlCommand("AwbtoUnsedstate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@awbno", txtawb.Text);
                cmd.ExecuteNonQuery();//Executing Commands
                con.Close();
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Airwaybill on Un-Issued stage now.');</script>");
            }
            else if (ddlawb.SelectedValue == "16")
            {
                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand cmd = new SqlCommand("AwbToIssueState", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@awbno", txtawb.Text);
                cmd.ExecuteNonQuery();//Executing Commands
                con.Close();
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Airwaybill on Issued stage now.');</script>");
            }

            else if (ddlawb.SelectedValue == "9")
            {
                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand cmd = new SqlCommand("Handover_delete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Airwaybill_no", txtawb.Text);
                cmd.ExecuteNonQuery();//Executing Commands
                con.Close();
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Airwaybill on Booked stage now.');</script>");
            }

            else if (ddlawb.SelectedValue == "10")
            {
                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand cmd = new SqlCommand("TrasnferAwbTo_HandoverFromSales", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Airwaybill_no", txtawb.Text);
                cmd.ExecuteNonQuery();//Executing Commands
                con.Close();
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Airwaybill on Handovered stage now.');</script>");
            }

            else if (ddlawb.SelectedValue == "12")
            {
                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand cmd = new SqlCommand("Void_Awb", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Airwaybill_no", txtawb.Text);
                cmd.ExecuteNonQuery();//Executing Commands
                con.Close();
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Airwaybill on Handovered stage now.');</script>");
            }
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Please enter correct airwaybill..');</script>");
            // return;
        }
        txtawb.Text = "";
      }
            
        catch (Exception ee)
        {
            string msg = ee.ToString();
            ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Server link failure....Try later.');</script>");
        }
    
    }
       
}
