using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

public partial class Browse_item : System.Web.UI.Page
{
    public int sno = 1;
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection mycn = new SqlConnection(strCon);

            SqlDataAdapter da = new SqlDataAdapter("select category from ImageGallery order by category", mycn);
            DataSet ds = new DataSet();
            da.Fill(ds, "ImageGallery");

            ddl_category.DataSource = ds.Tables[0];
            ddl_category.DataTextField = ds.Tables[0].Columns["category"].ColumnName.ToString();
            ddl_category.DataValueField = ds.Tables[0].Columns["category"].ColumnName.ToString();
            ddl_category.DataBind();
            for (int i = 0; i < ddl_category.Items.Count; i++)
            {
                ddl_category.Items[i].Attributes.Add("style", "color:");
            }


        }
        GridView1.DataSource = FetchAllImagesInfo();
        GridView1.DataBind();

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        GridView1.DataSource = FetchAllImagesInfo2();
        GridView1.DataBind();
    }
    public DataTable FetchAllImagesInfo()
    {
        string sql = "Select img_id,item_name,model_no,cpp_required from tbimage order by item_name";
        SqlDataAdapter da = new SqlDataAdapter(sql, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }
    public DataTable FetchAllImagesInfo2()
    {
        string sql = "Select img_id,item_name,model_no,cpp_required from tbimage where category='" + ddl_category.SelectedValue.ToString() + "' order by item_name";
        SqlDataAdapter da = new SqlDataAdapter(sql, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

}
