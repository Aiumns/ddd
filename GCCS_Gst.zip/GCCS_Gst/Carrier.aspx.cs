﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Carrier : System.Web.UI.Page
{
    #region Created by Pradeep Sharma
    /// <summary>
    /// <class>shipment_details</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Pradeep Sharma</createdBy>
    /// <createdOn>10 sep 2014</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion
    #region ConnectionString
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  //connection string
    #endregion
    #region global variables
    SqlConnection con;
    public string strLen = "";
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           show();
        }
    }

    protected void lnkadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("add_CarrierCode.aspx");
    }

    protected void btnSearch_Click1(object sender, EventArgs e)
    {
        show();
    }

    #region function for display
    public void show()
    {
        string search = null;
        con = new SqlConnection(strCon);
        if (txtsearch.Text == "")
            search = "SELECT CarrierCode,CarrierName,Interline  FROM db_owner.InterLineCarrier";
        else
        {
            search = "SELECT CarrierCode,CarrierName,Interline  FROM db_owner.InterLineCarrier where CarrierCode like '" + txtsearch.Text + "'+ '%'";
        }
        con.Open();
        SqlDataAdapter sda = new SqlDataAdapter(search, con);
        DataSet dsssss = new DataSet();
        sda.Fill(dsssss);
        GridView1.DataSource = dsssss;
        GridView1.DataBind();
        con.Close();

    }
    #endregion

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        show();
    }

    #region command event for modify
    protected void modify(object sender, CommandEventArgs e)
    {
        Response.Redirect("add_CarrierCode.aspx?CarrierCode=" + e.CommandName);

    }
    #endregion
}