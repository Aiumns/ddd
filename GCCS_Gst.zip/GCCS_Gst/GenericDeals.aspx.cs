using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class GenericDeals : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["D"] != null)
                {
                    UpdateGDeal.Attributes.Add("onclick", "return CheckEmpty();");
                    ShowAirline();
                    fillDest();
                    addGDeal.Visible = false;
                    UpdateGDeal.Visible = true;
                    btnCancel.Visible = true;
                    CancelGDeal.Visible = false;
                    
                    fillUpdateDate();
                    
                }
                else
                {
                    addGDeal.Attributes.Add("onclick", "return CheckEmpty();");
                    ShowAirline();
                    fillDest();
                    addGDeal.Visible = true; 
                    UpdateGDeal.Visible =false;
                    btnCancel.Visible = false; 
                    CancelGDeal.Visible = true;

                }
            }
        }

    }
    protected void addGDeal_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
           
          
            com = new SqlCommand("insert into Generic_Deal(Airline_Detail_ID,Destination_ID,ChWt_From,ChWt_To,Spot_Rate,Commission,Special_Commodity_Incentive,Entered_By,Entered_On) values(@Airline_Detail_ID,@Destination_ID,@ChWt_From,@ChWt_To,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Entered_By,@Entered_On)", con);
            com.Parameters.AddWithValue("@Airline_Detail_ID",int.Parse(ddlAirlineDetail.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@Destination_ID",Int64.Parse(ddlDest.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@ChWt_From", decimal.Parse(txtChWtFrom.Text));
            com.Parameters.AddWithValue("@ChWt_To", decimal.Parse(txtChWtTo.Text));
            com.Parameters.AddWithValue("@Spot_Rate", decimal.Parse(txtSpotRate.Text == "" ? "0" : txtSpotRate.Text));
            com.Parameters.AddWithValue("@Commission", decimal.Parse(txtComm.Text == "" ? "0" : txtComm.Text));
            com.Parameters.AddWithValue("@Special_Commodity_Incentive", decimal.Parse(txtscIncentive.Text == "" ? "0" : txtscIncentive.Text));
            com.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());
            com.Parameters.AddWithValue("@Entered_On",DateTime.Today);
            com.ExecuteNonQuery();
            com.Dispose();
            con.Close();
            Response.Redirect("ShowGenericDeals.aspx");
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
            
        
        }
    protected void ShowAirline()
    {

        ddlAirlineDetail.Items.Clear();

        con = new SqlConnection(strCon);
        con.Open();
        try
        {           
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineDetail.Items.Add("Select airline name");
            ddlAirlineDetail.Items[0].Value = "";
            while (dr.Read())
            {
                int s = int.Parse(dr["Airline_Detail_ID"].ToString());
                ddlAirlineDetail.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void fillDest()
    {
       ddlDest.Items.Clear();

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select destination_id,destination_code from destination_master order by destination_code", con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlDest.Items.Add("Select Destination");
            //ddlDest.Items[0].Value = "";
            ddlDest.Items.Add("All Destination");
            ddlDest.Items[0].Value ="0";
            while (dr.Read())
            {
                ddlDest.Items.Add(new ListItem(dr["destination_code"].ToString(), dr["destination_id"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }

    protected void CancelGDeal_Click(object sender, EventArgs e)
    {
        Response.Redirect("GenericDeals.aspx");

    }
    protected void UpdateGDeal_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("update  Generic_Deal set Airline_Detail_ID=@Airline_Detail_ID,Destination_ID=@Destination_ID,ChWt_From=@ChWt_From, ChWt_To=@ChWt_To,Spot_Rate=@Spot_Rate,Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Entered_By=@Entered_By,Entered_On=@Entered_On where deal_id=@deal_id", con);

            com.Parameters.AddWithValue("@Airline_Detail_ID", int.Parse(ddlAirlineDetail.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@Destination_ID", Int64.Parse(ddlDest.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@ChWt_From", decimal.Parse(txtChWtFrom.Text));
            com.Parameters.AddWithValue("@ChWt_To", decimal.Parse(txtChWtTo.Text));
            com.Parameters.AddWithValue("@Spot_Rate",decimal.Parse(txtSpotRate.Text == "" ? "0" : txtSpotRate.Text));
            com.Parameters.AddWithValue("@Commission", decimal.Parse(txtComm.Text == "" ? "0" : txtComm.Text));
            com.Parameters.AddWithValue("@Special_Commodity_Incentive", decimal.Parse(txtscIncentive.Text == "" ? "0" : txtscIncentive.Text));
            com.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());
            com.Parameters.AddWithValue("@Entered_On", DateTime.Today);
            com.Parameters.AddWithValue("@deal_id", int.Parse(Request.QueryString["d"].ToString()));

            com.ExecuteNonQuery();
            com.Dispose();
            con.Close();
            Response.Redirect("ShowGenericDeals.aspx");
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }           

    }
    protected void fillUpdateDate()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select Airline_Detail_ID,Destination_ID,ChWt_From,ChWt_To,Spot_Rate,Commission,Special_Commodity_Incentive from Generic_Deal where Deal_id="+Request.QueryString["d"].ToString()+" ", con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                //ddlcompanyname.SelectedIndex = ddlcompanyname.Items.IndexOf(ddlcompanyname.Items.FindByValue(Company_Id));
                //ddlStatus.SelectedIndex = ddlStatus.Items.IndexOf(ddlStatus.Items.FindByValue(Status_ID));

                ddlAirlineDetail.SelectedIndex = ddlAirlineDetail.Items.IndexOf(ddlAirlineDetail.Items.FindByValue(dr["Airline_Detail_ID"].ToString()));
                ddlDest.SelectedIndex = ddlDest.Items.IndexOf(ddlDest.Items.FindByValue(dr["Destination_ID"].ToString()));
                txtChWtFrom.Text = dr["ChWt_From"].ToString();
                txtChWtTo.Text = dr["ChWt_To"].ToString();
                txtComm.Text = dr["Commission"].ToString();
                txtSpotRate.Text = dr["Spot_Rate"].ToString();
                txtscIncentive.Text = dr["Special_Commodity_Incentive"].ToString();                

            }           
            com.Dispose();
            con.Close();
            
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }           


    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowGenericDeals.aspx");
    }
}
