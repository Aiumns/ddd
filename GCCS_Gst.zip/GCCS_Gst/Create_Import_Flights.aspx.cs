using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Create_Import_Flights : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    string Import_Flight_ID;
    string Airline_Detail_ID;
    string Import_Flight_No;
    string Import_Flight_Date;
    string IGM_No;
    SqlTransaction trans = null;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack && Request.QueryString["Import_Flight_ID"] != null)
            {
                lbladd.Text = "Update Import Flight";
                Button1.Visible = false;
                Import_Flight_ID = Convert.ToString(Request.QueryString["Import_Flight_ID"]);
                //string str1 = "select Airline_Detail_ID,Import_Flight_No,convert(varchar,Import_Flight_Date,103) as Import_Flight_Date ,IGM_No from Import_Flights where Import_Flight_ID='" + Import_Flight_ID + "'";

                string str1 = "select Airline_Detail_ID,Import_Flight_No,convert(varchar,Import_Flight_Date,103) as Import_Flight_Date ,IGM_No,Reg_No,Flight_Status_Check,_Action,status from Import_Flights where Import_Flight_ID='" + Import_Flight_ID + "'";
                con = new SqlConnection(strCon);
                con.Open();

                com = new SqlCommand(str1, con);
                SqlDataReader dr = com.ExecuteReader();
                dr.Read();

                Airline_Detail_ID = dr["Airline_Detail_ID"].ToString();

                Import_Flight_No = dr["Import_Flight_No"].ToString();
                Import_Flight_Date = dr["Import_Flight_Date"].ToString();
                IGM_No = dr["IGM_No"].ToString();
                txtFlightName.Text = Import_Flight_No;
                txtFlightDate.Text = Import_Flight_Date;
                txtIgmNo.Text = IGM_No;
                txtRegNo.Text = dr["Reg_No"].ToString();
                txtFlightCheckStatus.Text = dr["Flight_Status_Check"].ToString();
                txtAction.Text = dr["_Action"].ToString();
                ddlstatus.SelectedValue = dr["Status"].ToString();
                //lblid.Text = Airline_Code.ToString();
                con.Close();
                FillAirline();
                ddlAirlineName.SelectedIndex = ddlAirlineName.Items.IndexOf(ddlAirlineName.Items.FindByValue(Airline_Detail_ID));
                ddlAirlineName.Enabled = false; ;


            }
            else if (!IsPostBack)
            {
                btnupdate.Visible = false;
                FillAirline();

            }
        }

    }
    /// <summary>
    /// This Function  is used to bind the Airline  name in dropdownlist according to their rights
    /// </summary>
    public void FillAirline()
    {
        string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in(" + Airline_Access + ") order by Airline_Name", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        ddlAirlineName.DataSource = dr;
        ddlAirlineName.DataTextField = "Airline";
        ddlAirlineName.DataValueField = "Airline_Detail_ID";
        ddlAirlineName.DataBind();
        con.Close();
        com.Dispose();
        ddlAirlineName.Items.Insert(0, new ListItem("Select Airline", "-1"));
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        return Access;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Browse_Import_Flights.aspx");
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        string strupdate = "";
        try
        {
            strupdate = "select * from Import_Flights where Import_Flight_No='" + Label5.Text.Trim() + txtFlightName.Text.Trim() + "' and Import_Flight_Date='" + ConvertDate(txtFlightDate.Text) + "' and  IGM_No='" + txtIgmNo.Text + "'";
            con.Open();
            da = new SqlDataAdapter(strupdate, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count <= 1)
            {

                try
                {
                    con.Open();
                    string strupdate1 = "update Import_Flights  set Import_Flight_No='" + Label5.Text.Trim() + txtFlightName.Text.Trim() + "',Import_Flight_Date='" + ConvertDate(txtFlightDate.Text) + "',IGM_No='" + txtIgmNo.Text + "',Last_Modified_By='" + Session["EMailID"].ToString() + "',Last_Modified_On='" + DateTime.Now + "',Flight_Status_Check='" + txtFlightCheckStatus.Text + "',Reg_No='" + txtRegNo.Text + "',_Action='" + txtAction.Text + "',Status='" + ddlstatus.SelectedValue + "' where Import_Flight_ID='" + Convert.ToString(Request.QueryString["Import_Flight_ID"]) + "'";
                    com = new SqlCommand(strupdate1, con);
                    com.ExecuteNonQuery();
                    con.Close();
                    Response.Redirect("Browse_Import_Flights.aspx");
                }
                catch (SqlException se)
                {
                    string err = se.Message;
                    lblError.Text = err;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            else
            {

                lblError.Text = " Record already exists.";
                Button1.Visible = false;
                btnupdate.Visible = true;
                lbladd.Text = "Update Import Flight";
            }

        }

        catch (SqlException err)
        {
            string msg = err.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAirlineName_SelectedIndexChanged(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        if (ddlAirlineName.SelectedIndex <= 0)
        {
            txtFlightName.Text = "";
            Label5.Visible = false;
            lblError.Visible = true;
            lblError.Text = "Please Select Airline Name";
            ddlAirlineName.Focus();

        }
        else
        {
            txtFlightName.Text = "";
            lblError.Visible = false;
            string[] strAwb = ddlAirlineName.SelectedItem.Text.Split('-');
            //int AW = strAwb.IndexOf("-");
            //string strAwb1 = strAwb.Substring(0, AW);
            string str11 = "select Airline_Text_Code from Airline_Master where Airline_Name='" + strAwb[0] + "'";
            SqlCommand com = new SqlCommand(str11, con);
            SqlDataReader dr11 = com.ExecuteReader();
            dr11.Read();
            string ATC = dr11["Airline_Text_Code"].ToString();
            Label5.Visible = true;

            //if (ddlAirlineName.SelectedValue == "158" )
            //    ATC = "HY";
            if ((ddlAirlineName.SelectedValue == "159") || (ddlAirlineName.SelectedValue == "158"))
            {
                Label5.Visible = false;
                txtprefix.Visible = true;
                txtprefix.Text = ATC;


            }
            else
            {
                Label5.Visible = true;
                txtprefix.Visible = false;
            
            }

            //if (ATC == "KE")
            //    ATC = "HY";
            Label5.Text = ATC + "-";
        }
        con.Close();
    }
    string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        string stradd = "";
        try
        {
            if (ddlAirlineName.SelectedValue == "159")
            {
                Label5.Text = txtprefix.Text + "-";
            }
            //stradd = "select * from Import_Flights where Airline_detail_id="+ddlAirlineName.SelectedItem.Value+" and Import_Flight_No='" + Label5.Text.Trim()+txtFlightName.Text.Trim() + "' and Import_Flight_Date='" + ConvertDate(txtFlightDate.Text) + "' and  IGM_No='" + txtIgmNo.Text + "'";
            stradd = "select * from Import_Flights where Import_Flight_No='" + Label5.Text.Trim() + txtFlightName.Text.Trim() + "' and Import_Flight_Date='" + ConvertDate(txtFlightDate.Text) + "' and  IGM_No='" + txtIgmNo.Text + "' and status=2";
            con.Open();
            da = new SqlDataAdapter(stradd, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblError.Visible = true;
                lblError.Text = " Records already exists.";
            }
            else
            {
                string stradd1 = "insert into  Import_Flights(Airline_Detail_ID,Import_Flight_No,Import_Flight_Date,IGM_No,Entered_By,Entered_On,Flight_Status_Check,Reg_No,_Action,Status) values('" + ddlAirlineName.SelectedItem.Value + "','" + Label5.Text.Trim() + txtFlightName.Text.Trim() + "','" + ConvertDate(txtFlightDate.Text) + "','" + txtIgmNo.Text + "','" + Session["EMailID"].ToString() + "','" + DateTime.Now + "','" + txtFlightCheckStatus.Text + "','" + txtRegNo.Text + "','" + txtAction.Text + "','" + ddlstatus.SelectedValue + "')";
                con.Open();
                com = new SqlCommand(stradd1, con);
                com.ExecuteNonQuery();
                com.Dispose();
                con.Close();
                Response.Redirect("Browse_Import_Flights.aspx");
            }
        }
        catch (SqlException err)
        {
            string msg = err.ToString();
        }
        finally
        {
            if(con != null || con.State == ConnectionState.Open)
               con.Close();
        }
    }
}
