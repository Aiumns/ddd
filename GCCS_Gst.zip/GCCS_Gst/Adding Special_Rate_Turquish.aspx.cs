using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Adding_Special_Rate_Turquish : System.Web.UI.Page
{
    string s;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con,con1;
    SqlCommand com = null;
    SqlCommand com1 = null;
    SqlDataReader dr = null;
    SqlDataReader dr1 = null;
    string table = null;
    string strcom = "";
    string AirWayBill = "";
    string specialRate = "";
    string a = "";
    string btxt = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
       // btxt = txtSpl_Rate.Text;
        con = new SqlConnection(strCon);
        con.Open();
        AirWayBill = Request.QueryString["AWB"].ToString();
        //specialRate = Request.QueryString["splRate"].ToString();
        
        strcom = "Select AirWayBill_No,Principle_Rate,Principle_Spot_Rate,Spot_Rate, Remarks from Sales where AirWayBill_No='" + AirWayBill.ToString() + "'";
        com = new SqlCommand(strcom, con);
        dr = com.ExecuteReader(CommandBehavior.CloseConnection);
        dr.Read();
            a = dr["Principle_Spot_Rate"].ToString();
            if (dr.HasRows)
        {
           
            lblAirwayBill.Text = dr["AirWayBill_No"].ToString();
            
                
              //  txtSpl_Rate.Text = dr["Principle_Rate"].ToString();
               
            
               // txtSpl_Rate.Text = dr["Principle_Spot_Rate"].ToString();
               
            }
            com.Dispose();
            dr.Dispose();
            con.Close();
        }
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            AirWayBill = Request.QueryString["AWB"].ToString();
            con1 = new SqlConnection(strCon);
            con1.Open();
            strcom = "Select AirWayBill_No,Principle_Rate,Principle_Spot_Rate,Spot_Rate, Remarks from Sales where AirWayBill_No='" + AirWayBill.ToString() + "'";
            com1 = new SqlCommand(strcom, con1);
            dr1 = com1.ExecuteReader(CommandBehavior.CloseConnection);
            dr1.Read();
            a = dr1["Principle_Spot_Rate"].ToString();
            if(dr1.HasRows)
            {
            con = new SqlConnection(strCon);
            con.Open();
            

             string airline_name =Session.Contents["airline_name"].ToString();
            string airline_detail_id=Session.Contents["airline_detail_id"].ToString();
            string from_date = Session.Contents["from_date"].ToString() ;
            string to_date =Session.Contents["to_date"].ToString();
                com = new SqlCommand("update Sales set Principle_Spot_Rate=" + txtSpl_Rate.Text + ", Remarks='" + txtRemarks.Text + "' where AirWayBill_No='" + lblAirwayBill.Text + "'", con);
                com.ExecuteNonQuery();

                string url = "PrincipalTurkishReportShow.aspx?airlineName="+airline_name+"&airline_detail_id="+airline_detail_id+"&from="+from_date+"&to="+to_date;

                con.Close();
                // //Response.Write("Updated Successfully");
               Response.Redirect(url);
  
            }
            con1.Close();
        }
        catch (Exception io)
        {
            
            Trace.Warn(io.Message);
           // Response.Write(io.Message);

        }
    }
}
