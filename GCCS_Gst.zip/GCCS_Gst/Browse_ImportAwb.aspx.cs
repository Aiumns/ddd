using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


//This Page is Design & Coding By Alok Date:27.11.2007

public partial class Browse_ImportAwb : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;

    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        {
            Search();
        }
    }

    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        dr.Dispose();
        con.Close();
        cmd.Dispose();
        return Access;
    }
    // function for bind grid
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string strAirline_Access = Rights();
            string selectQ = null;
            if (txt_search.Text == "")
            {
                selectQ = "select distinct IA.Import_AWB_ID as 'Import_AWB_ID',IA.Import_AWB_No as 'Import_AWB_No',IFO.Airline_detail_id as 'Airline_detail_id',IA.Agent_Name as 'Agent_Name',IFO.Import_Flight_No as 'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight', (case when IA.CAN_Status='13' then 'View' else 'Issue' end ) as 'CAN_Status',(case when IA.Delivery_Order='13' then 'View' else 'Issue' end ) as 'Delivery_Order',IA.Freight_Type as 'Freight_Type' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID  and IFO.Airline_Detail_ID in(" + strAirline_Access + ") order by Import_Flight_No,Flight_Date";



                //selectQ = "select IA.Import_AWB_ID as 'Import_AWB_ID',IFO.Airline_detail_id as 'Airline_detail_id',IA.Import_AWB_No as 'Import_AWB_No',IA.Agent_Name as 'Agent_Name',IFO.Import_Flight_No as 'Import_Flight_No',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight', (case when IA.CAN_Status='13' then 'Issue' else 'Issue' end ) as 'CAN_Status',(case when IA.Delivery_Order='13' then 'Issue' else 'Issue' end ) as 'Delivery_Order',IA.Freight_Type as 'Freight_Type' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID";
            }

            else
            {
                if (ddlSearch.SelectedValue == "1")
                {
                    selectQ = "select distinct IA.Import_AWB_ID as 'Import_AWB_ID',IA.Import_AWB_No as 'Import_AWB_No',IFO.Airline_detail_id as 'Airline_detail_id',IA.Agent_Name as 'Agent_Name',IFO.Import_Flight_No as 'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight', (case when IA.CAN_Status='13' then 'View' else 'Issue' end ) as 'CAN_Status',(case when IA.Delivery_Order='13' then 'View' else 'Issue' end ) as 'Delivery_Order',IA.Freight_Type as 'Freight_Type' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID where IA.Agent_Name like '" + txt_search.Text + "%' and IFO.Airline_Detail_ID in(" + strAirline_Access + ") order by Import_Flight_No,Flight_Date";

                }
                else if (ddlSearch.SelectedValue == "2")
                {
                    selectQ = "select distinct IA.Import_AWB_ID as 'Import_AWB_ID',IA.Import_AWB_No as 'Import_AWB_No',IFO.Airline_detail_id as 'Airline_detail_id',IA.Agent_Name as 'Agent_Name',IFO.Import_Flight_No as 'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight', (case when IA.CAN_Status='13' then 'View' else 'Issue' end ) as 'CAN_Status',(case when IA.Delivery_Order='13' then 'View' else 'Issue' end ) as 'Delivery_Order',IA.Freight_Type as 'Freight_Type' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID where IA.Import_AWB_No like '%" + txt_search.Text + "%' and IFO.Airline_Detail_ID in(" + strAirline_Access + ") order by Import_Flight_No,Flight_Date";

                }
                ////selectQ = "select distinct IA.Import_AWB_ID as 'Import_AWB_ID',IA.Import_AWB_No as 'Import_AWB_No',IFO.Airline_detail_id as 'Airline_detail_id',IA.Agent_Name as 'Agent_Name',IFO.Import_Flight_No as 'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight', (case when IA.CAN_Status='13' then 'View' else 'Issue' end ) as 'CAN_Status',(case when IA.Delivery_Order='13' then 'View' else 'Issue' end ) as 'Delivery_Order',IA.Freight_Type as 'Freight_Type' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID where IA.Agent_Name like '" + txt_search.Text + "%' and IFO.Airline_Detail_ID in(" + strAirline_Access + ") order by Import_Flight_No,Flight_Date";

                //selectQ = "select IA.Import_AWB_ID as 'Import_AWB_ID',IFO.Airline_detail_id as 'Airline_detail_id',IA.Import_AWB_No as 'Import_AWB_No',IA.Agent_Name as 'Agent_Name',IFO.Import_Flight_No as 'Import_Flight_No',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight', (case when IA.CAN_Status='13' then 'Issue' else 'Issue' end ) as 'CAN_Status',(case when IA.Delivery_Order='13' then 'Issue' else 'Issue' end ) as 'Delivery_Order',IA.Freight_Type as 'Freight_Type' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.
                //Import_Flight_Open_ID where IA.Agent_Name like '" + txt_search.Text + "%'";
            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdSearch.DataSource = dt;
            grdSearch.DataBind();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void grdSearch_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdSearch.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void CAN(object sender, CommandEventArgs e)
    {
        Response.Redirect("Issue_Can.aspx?Import_AWB_ID=" + e.CommandName);
    }
    protected void Delivery(object sender, CommandEventArgs e)
    {
        try
        {
            string str = e.CommandName;
            con = new SqlConnection(strCon);
            con.Open();
            string str1 = "select distinct IA.Import_AWB_ID as 'Import_AWB_ID',IA.Import_AWB_No as 'Import_AWB_No',IA.Agent_Name as 'Agent_Name',IFO.Import_Flight_No as 'Import_Flight_No',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight', (case when IA.CAN_Status='13' then 'View' else 'Issue' end ) as 'CAN_Status',(case when IA.Delivery_Order='13' then 'View' else 'Issue' end ) as 'Delivery_Order',IA.Freight_Type as 'Freight_Type' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID where Import_AWB_ID='" + str + "'";
            com = new SqlCommand(str1, con);
            SqlDataReader dr = com.ExecuteReader();
            dr.Read();
            string Cans = dr["CAN_Status"].ToString();
            string Do = dr["Delivery_Order"].ToString();
            string Ft = dr["Freight_Type"].ToString();
            if (Cans == "View" && Do == "Issue" || Cans == "View" && Do == "View")
            {
                Response.Redirect("Delivery_Order.aspx?Import_AWB_ID=" + str + "");
            }
            else if (Cans == "Issue")
            {
                if (Do == "Issue" && Ft == "Prepaid" || Do == "View" && Ft == "Prepaid")
                {
                    Response.Redirect("Delivery_Order.aspx?Import_AWB_ID=" + str + "");
                }
                else if (Do == "View" && Ft == "Collect")
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "Please First Issue the CAN";
                    for (int i = 0; i <= grdSearch.Rows.Count; i++)
                    {
 
                    }
                    
                }
                else if (Do == "Issue" && Ft == "Collect")
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "Please First Issue the CAN";
                }

            }
            con.Close ();


        }
           
        catch (Exception)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }



    protected void grdSearch_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            GridViewRow gr = e.Row;
            Label lbl = (Label)e.Row.FindControl("lbl");
            Label lbl_air = (Label)e.Row.FindControl("Label3");
           gr.Cells[1].Text = "<a href=Issue_Can_Print.aspx?Import_AWB_ID=" + lbl.Text + "&amp;airline_detail_id=" + lbl_air.Text + "  target=_blank>";
        }
    }
    protected void CAN_Edit(object sender, CommandEventArgs e)
    {
        Response.Redirect("Issue_Can.aspx?Import_AWB_ID=" + e.CommandName);
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("issue_can.aspx");
    }
    protected void DO_Edit(object sender, CommandEventArgs e)
    {
        Response.Redirect("Delivery_Order.aspx?Import_AWB_ID=" + e.CommandName);
    }
}
