using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Import_register : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Request.QueryString["flightno"] != null)
            {
                con = new SqlConnection(strCon);
                con.Open();
                string strQuery = "select Ifa.import_awb_Id AS Sno,IFA.Import_AWB_No as AwbNo,IFA.Pcs,IFA.Charged_Weight as ChgsWt,IFA.Commodity as Comm,IFA.Origin,IFA.Destination as Dest,ifa.Freight_Type as [PP/CC],IFA.No_of_Houses AS Hawb,ifa.consignee_name AS Cnee,Ifa.Recipt_No as ReciptNo,IFA.Remarks from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID where IFs.Import_flight_No='" + Request.QueryString["flightno"].ToString() + "' AND ifs.igm_no='" + Request.QueryString["igmno"].ToString() + "'and Import_Flight_Date>='" + FormatDateDD(Request.QueryString["fromdate"].ToString()) + "'and Import_Flight_Date<='" + FormatDateDD(Request.QueryString["todate"].ToString()) + "' ";
                com = new SqlCommand(strQuery, con);
                da = new SqlDataAdapter(com);
                dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
                con.Close();
            }
        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
