using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;

public partial class Import_Browse : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    SqlTransaction trans = null;
    DisplayWrap dw = new DisplayWrap();
    GridView gv = new GridView();
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            FillGrd();
            rowColor();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
        rowColor();
    }
    public void FillGrd()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string selectQ = null;
            //selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,Agent_Name,Consignee_Name,notify,rotation_no,remarks,landing_type,status from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + " ";

            //selectQ = "Select IFA.import_awb_id,IFA.import_awb_no,IFA.import_flight_id,IFA.pcs,IFA.part_pcs,IFA.part_shipment_type,IFA.charged_weight,IFA.Gross_Weight,IFA.Origin,IFA.Destination,IFA.Freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_Name,IFA.shipment_type,IFA.agent_id,IFA.Agent_Name,IFA.Consignee_Name,IFA.notify,IFA.rotation_no,IFA.remarks,IFA.landing_type,IFA.status,IMF.Import_Flight_No,CONVERT(VARCHAR,IMF.Import_Flight_date,103) AS Import_Flight_Date,IMF.IGM_NO,CONVERT(VARCHAR,IFA.Reminder1Date,106) AS Reminder1Date,CONVERT(VARCHAR,IFA.Reminder2Date,106) AS Reminder2Date,CONVERT(VARCHAR,IFA.Reminder3Date,106) AS Reminder3Date from Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IMF ON IFA.Import_Flight_ID=IMF.Import_Flight_ID where IFA.status!='DO Generated' "; 

            //com = new SqlCommand(selectQ, con);
            //da = new SqlDataAdapter(com);


            con = new SqlConnection(strCon);
            com = new SqlCommand("Import_Browse", con);
            com.CommandType = CommandType.StoredProcedure;
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdDisplayAllocation.DataSource = dt;
            grdDisplayAllocation.DataBind();

            for (int i = 0; i < grdDisplayAllocation.Rows.Count; i++)
            {
                Label lblStatus = (Label)grdDisplayAllocation.Rows[i].FindControl("lblStatus");
                Label lblReminder1date = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date");
                Label lblReminder2date = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date");
                Label lblReminder3date = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date");
                Label lblReminder = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder");
                Label lblReminder2 = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2");
                Label lblReminder3 = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3");
                LinkButton lblPrintCanReminder3 = (LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3");
                LinkButton lblPrintCan = (LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan");

                string aa = lblStatus.Text;
                if (aa == "CAN Created")
                {
                    if (lblReminder1date.Text != "" && lblReminder2date.Text == "" && lblReminder3date.Text=="")
                    {
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = true;

                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = false;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = false;

                    }
                    else if (lblReminder1date.Text != "" && lblReminder2date.Text != "" && lblReminder3date.Text == "")
                    {
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = false;

                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = false;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = true;
                       
                    }


                    else if (lblReminder1date.Text != "" && lblReminder2date.Text != "" && lblReminder3date.Text != "")
                    {
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = false;

                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = false;

                    }
                }
                else
                {

                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = false;
                    ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = false;
                    ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = false;
                }


                
               
            }
            con.Close();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    // Display Row Color
    protected void rowColor()
    {
        
        int c = grdDisplayAllocation.Columns.Count;
        for (int i = 0; i < grdDisplayAllocation.Rows.Count; i++)
        {
            GridViewRow gr = grdDisplayAllocation.Rows[i];
            //LinkButton l1 = (LinkButton)(gr.FindControl("lblPrint"));
            //LinkButton l2 = (LinkButton)(gr.FindControl("lblPrintCan"));
            if (((Label)(gr.FindControl("lblStatus"))).Text == "CAN Created" && ((Label)(gr.FindControl("lblReminder1date"))).Text == "")
            {
                gr.BackColor = System.Drawing.Color.SkyBlue;
                ((Label)(gr.FindControl("lblStatus"))).Text = "No CAN Created/No DO Generated";
            }
            else if (((Label)(gr.FindControl("lblStatus"))).Text == "CAN Created" && ((Label)(gr.FindControl("lblReminder1date"))).Text != "")
            {
                gr.BackColor = System.Drawing.Color.LightCyan;
                ((Label)(gr.FindControl("lblStatus"))).Text = "CAN Created/No DO Generated";
            }

            else if (((Label)(gr.FindControl("lblStatus"))).Text == "DO Generated")
            {
                gr.BackColor = System.Drawing.Color.PeachPuff;
                ((Label)(gr.FindControl("lblStatus"))).Text = "DO Generated";
            }
        }
    }
    public void Search()
    {
        string s1 = txtSearch.Text;

        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string selectQ = null;

              if (ddlSearch.SelectedItem.Text == "Awb" && txtSearch.Text=="" )
            {
                //selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,Agent_Name,Consignee_Name,notify,rotation_no,remarks,landing_type,status from Import_Flight_AWB where import_awb_no like'%" + txtSearch.Text + "%'";


                selectQ = "Select IFA.import_awb_id,IFA.import_awb_no,IFA.import_flight_id,IFA.pcs,IFA.part_pcs,IFA.part_shipment_type,IFA.charged_weight,IFA.Gross_Weight,IFA.Origin,IFA.Destination,IFA.Freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_Name,IFA.shipment_type,IFA.agent_id,IFA.Agent_Name,IFA.Consignee_Name,IFA.notify,IFA.rotation_no,IFA.remarks,IFA.landing_type,IFA.status,IMF.Import_Flight_No,CONVERT(VARCHAR,IMF.Import_Flight_date,103) AS Import_Flight_Date,IMF.IGM_NO,CONVERT(VARCHAR,IFA.Reminder1Date,106)as Reminder1Date,CONVERT(VARCHAR,IFA.Reminder2Date,106)as Reminder2Date,CONVERT(VARCHAR,IFA.Reminder3Date,106)as Reminder3Date from Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IMF ON IFA.Import_Flight_ID=IMF.Import_Flight_ID  where IFA.import_awb_no like'%" + txtSearch.Text + "%'";
            }
            else if (ddlSearch.SelectedItem.Text == "Awb" && txtSearch.Text != "")
            {
                selectQ = "Select IFA.import_awb_id,IFA.import_awb_no,IFA.import_flight_id,IFA.pcs,IFA.part_pcs,IFA.part_shipment_type,IFA.charged_weight,IFA.Gross_Weight,IFA.Origin,IFA.Destination,IFA.Freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_Name,IFA.shipment_type,IFA.agent_id,IFA.Agent_Name,IFA.Consignee_Name,IFA.notify,IFA.rotation_no,IFA.remarks,IFA.landing_type,IFA.status,IMF.Import_Flight_No,CONVERT(VARCHAR,IMF.Import_Flight_date,103) AS Import_Flight_Date,IMF.IGM_NO,CONVERT(VARCHAR,IFA.Reminder1Date,106)as Reminder1Date,CONVERT(VARCHAR,IFA.Reminder2Date,106)as Reminder2Date,CONVERT(VARCHAR,IFA.Reminder3Date,106)as Reminder3Date from Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IMF ON IFA.Import_Flight_ID=IMF.Import_Flight_ID  where IFA.import_awb_no like'%" + txtSearch.Text + "%'";
            }

            else if (ddlSearch.SelectedItem.Text == "Consignee" && txtSearch.Text != "")
            {
                selectQ = "Select IFA.import_awb_id,IFA.import_awb_no,IFA.import_flight_id,IFA.pcs,IFA.part_pcs,IFA.part_shipment_type,IFA.charged_weight,IFA.Gross_Weight,IFA.Origin,IFA.Destination,IFA.Freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_Name,IFA.shipment_type,IFA.agent_id,IFA.Agent_Name,IFA.Consignee_Name,IFA.notify,IFA.rotation_no,IFA.remarks,IFA.landing_type,IFA.status,IMF.Import_Flight_No,CONVERT(VARCHAR,IMF.Import_Flight_date,103) AS Import_Flight_Date,IMF.IGM_NO,CONVERT(VARCHAR,IFA.Reminder1Date,106)as Reminder1Date,CONVERT(VARCHAR,IFA.Reminder2Date,106)as Reminder2Date,CONVERT(VARCHAR,IFA.Reminder3Date,106)as Reminder3Date from Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IMF ON IFA.Import_Flight_ID=IMF.Import_Flight_ID  where IFA.Consignee_Name like'%" + txtSearch.Text + "%'";

            }

            else if (ddlSearch.SelectedItem.Text == "Agent" && txtSearch.Text != "")
            {
                selectQ = "Select IFA.import_awb_id,IFA.import_awb_no,IFA.import_flight_id,IFA.pcs,IFA.part_pcs,IFA.part_shipment_type,IFA.charged_weight,IFA.Gross_Weight,IFA.Origin,IFA.Destination,IFA.Freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_Name,IFA.shipment_type,IFA.agent_id,IFA.Agent_Name,IFA.Consignee_Name,IFA.notify,IFA.rotation_no,IFA.remarks,IFA.landing_type,IFA.status,IMF.Import_Flight_No,CONVERT(VARCHAR,IMF.Import_Flight_date,103) AS Import_Flight_Date,IMF.IGM_NO,CONVERT(VARCHAR,IFA.Reminder1Date,106)as Reminder1Date,CONVERT(VARCHAR,IFA.Reminder2Date,106)as Reminder2Date,CONVERT(VARCHAR,IFA.Reminder3Date,106)as Reminder3Date from Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IMF ON IFA.Import_Flight_ID=IMF.Import_Flight_ID  where IFA.Agent_Name like'%" + txtSearch.Text + "%'";

            }

            else if (ddlSearch.SelectedItem.Text == "Flight Date" && txtdate.Text != "")
            {
                pnldate.Visible = true;
                string strdate = null;
                txtSearch.Visible = false;
                try
                {
                    if (txtdate.Text != null)
                    {
                        strdate = FormatDateMM(txtdate.Text);
                    }
                    else
                    {

                    }
                }
                catch (Exception)
                {

                }

                selectQ = "Select IFA.import_awb_id,IFA.import_awb_no,IFA.import_flight_id,IFA.pcs,IFA.part_pcs,IFA.part_shipment_type,IFA.charged_weight,IFA.Gross_Weight,IFA.Origin,IFA.Destination,IFA.Freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_Name,IFA.shipment_type,IFA.agent_id,IFA.Agent_Name,IFA.Consignee_Name,IFA.notify,IFA.rotation_no,IFA.remarks,IFA.landing_type,IFA.status,IMF.Import_Flight_No,CONVERT(VARCHAR,IMF.Import_Flight_date,103) AS Import_Flight_Date,IMF.IGM_NO,CONVERT(VARCHAR,IFA.Reminder1Date,106)as Reminder1Date,CONVERT(VARCHAR,IFA.Reminder2Date,106)as Reminder2Date,CONVERT(VARCHAR,IFA.Reminder3Date,106)as Reminder3Date from Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IMF ON IFA.Import_Flight_ID=IMF.Import_Flight_ID  where IMF.Import_Flight_Date=" + "'" + strdate + "'";

            }

            else if ((ddlSearch.SelectedItem.Text == "Awb" && txtSearch.Text == "") || (ddlSearch.SelectedItem.Text == "Consignee" && txtSearch.Text == "") || (ddlSearch.SelectedItem.Text == "Agent" && txtSearch.Text == "") || (ddlSearch.SelectedItem.Text == "Flight Date" && txtdate.Text == ""))
            {
                selectQ = "Select IFA.import_awb_id,IFA.import_awb_no,IFA.import_flight_id,IFA.pcs,IFA.part_pcs,IFA.part_shipment_type,IFA.charged_weight,IFA.Gross_Weight,IFA.Origin,IFA.Destination,IFA.Freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_Name,IFA.shipment_type,IFA.agent_id,IFA.Agent_Name,IFA.Consignee_Name,IFA.notify,IFA.rotation_no,IFA.remarks,IFA.landing_type,IFA.status,IMF.Import_Flight_No,CONVERT(VARCHAR,IMF.Import_Flight_date,103) AS Import_Flight_Date,IMF.IGM_NO,CONVERT(VARCHAR,IFA.Reminder1Date,106)as Reminder1Date,CONVERT(VARCHAR,IFA.Reminder2Date,106)as Reminder2Date,CONVERT(VARCHAR,IFA.Reminder3Date,106)as Reminder3Date  from Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IMF ON IFA.Import_Flight_ID=IMF.Import_Flight_ID";

            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdDisplayAllocation.DataSource = dt;
            grdDisplayAllocation.DataBind();



            //Condition Bind with grid


            for (int i = 0; i < grdDisplayAllocation.Rows.Count; i++)
            {
                Label lblStatus = (Label)grdDisplayAllocation.Rows[i].FindControl("lblStatus");
                Label lblReminder1date = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date");
                Label lblReminder2date = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date");
                Label lblReminder3date = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date");
                Label lblReminder = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder");
                Label lblReminder2 = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2");
                Label lblReminder3 = (Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3");
                LinkButton lblPrintCanReminder3 = (LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3");
                LinkButton lblPrintCan = (LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan");

                string aa = lblStatus.Text;
                if (aa == "CAN Created")
                {
                    if (lblReminder1date.Text != "" && lblReminder2date.Text == "" && lblReminder3date.Text == "")
                    {
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = true;

                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = false;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = false;

                    }
                    else if (lblReminder1date.Text != "" && lblReminder2date.Text != "" && lblReminder3date.Text == "")
                    {
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = false;

                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = false;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = false;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = true;

                    }


                    else if (lblReminder1date.Text != "" && lblReminder2date.Text != "" && lblReminder3date.Text != "")
                    {
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = false;

                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = true;
                        ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = true;
                        ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = false;

                    }
                }
                else
                {

                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder1date")).Visible = false;
                    ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCan")).Visible = false;


                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder2date")).Visible = false;
                    ((Label)grdDisplayAllocation.Rows[i].FindControl("lblReminder3date")).Visible = false;
                    ((LinkButton)grdDisplayAllocation.Rows[i].FindControl("lblPrintCanReminder3")).Visible = false;
                }




            }


            // End 


           
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void grdDisplayAllocation_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdDisplayAllocation.PageIndex = e.NewPageIndex;
        FillGrd();
        rowColor();
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void ddlSearch_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlSearch.SelectedItem.Text=="Flight Date")
        {
            txtSearch.Text = "";
            pnldate.Visible = true;
            txtSearch.Visible = false;
        }
        else
        {
            txtdate.Text = "";
            pnldate.Visible = false;
            txtSearch.Visible = true; ;
        }
    }


    public string GetViewUrlWithQueryStringCAN(string sno)
    {
        
        
        string[] _Sno = sno.Split('&');
        string Flight_Id = _Sno[2].ToString();
        string[] FltId = Flight_Id.Split('=');
        string _Import_FltId = FltId[1].ToString();

        return "if (confirm('Already CAN printed...Still Do you want to Print CAN ?')){window.open('CAN_Print.aspx?AWBID=" + sno + "&import_flight_id=" + _Import_FltId + "&st=CAN" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')}";


    }


    public string GetViewUrlWithQueryStringCAN1(string sno)
    {


        string[] _Sno = sno.Split('&');
        string Flight_Id = _Sno[2].ToString();
        string[] FltId = Flight_Id.Split('=');
        string _Import_FltId = FltId[1].ToString();

        return "if (confirm('Already CAN printed...Still Do you want to Print CAN ?')){window.open('CAN_Print.aspx?AWBID=" + sno + "&import_flight_id=" + _Import_FltId + "&st=CAN" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')}";


    }
}
