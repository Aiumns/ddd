using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Created By Rakhi on 2 Nov 2007
/// </summary>

public partial class Booking_NoShow : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    string strquery;
    SqlTransaction tr=null;
    SqlCommand com;
    string AirWayBill_No;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            AirWayBill_No = Request.QueryString["AirWayBill_No"].ToString();
            btnNoShow.Attributes.Add("onclick", "return CheckEmpty()");
            if (!Page.IsPostBack && Request.QueryString["AirWayBill_No"] != null)
            {
                search();
            }
        }
    }
    public void search()
    {
        try
        {
            string id = Request.QueryString["AirWayBill_No"].ToString();
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmd = new SqlCommand("Booking_Select", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AirWayBill_No", id);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Label1.Text = dr["AirWayBill_No"].ToString();

                }
            }

            con.Close();
            cmd.Dispose();
        }
        catch (Exception)
        {

        }
            finally 
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    private void Noshow()
    {

        con = new SqlConnection(strCon);
        con.Open();
        tr = con.BeginTransaction();
       
        try
        {
            string insertQuery = "";

            insertQuery = "Update Stock_Master set Status='" + 16 + "',Remarks='" + txtRemarks.Text + "',USED_DATE=NULL where AirWayBill_No='" + AirWayBill_No + "' ";  
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();




            insertQuery = "Insert into dbo.NoShow_Details select * from Booking_master where stock_id=(select stock_id from stock_master where AirWayBill_No='" + AirWayBill_No + "')";
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();


            insertQuery = "Insert into db_owner.Booking_AWB_NoShowDetails select * from db_owner.Booking_AWB where booking_id=(select booking_id from booking_master where  stock_id=(select stock_id from stock_master where AirWayBill_No='" + AirWayBill_No + "'))";
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();

            insertQuery = " Delete from Booking_Awb where booking_id=(select booking_id from booking_master where  stock_id=(select stock_id from stock_master where AirWayBill_No='" + AirWayBill_No + "'))"; 
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();


            insertQuery = " Delete from Booking_Dimensions where booking_id=(select booking_id from booking_master where  stock_id=(select stock_id from stock_master where AirWayBill_No='" + AirWayBill_No + "'))"; ;
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();


            insertQuery = " Delete from Booking_master where stock_id=(select stock_id from stock_master where AirWayBill_No='" + AirWayBill_No + "')"; ;
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose(); 



            //insertQuery="Insert Into Stock_History SELECT  sm.AirWayBill_No, cm.City_Name, sm.Receipt_Date, sm.Receipt_LotNo,am.Agent_Name, sm.Issue_Date, sm.Issue_LotNo, stm.Status_Name, sm.Remarks, sm.Used_Date, sm.Created_By, sm.Created_On FROM Stock_Master sm INNER JOIN City_Master cm ON sm.City_ID = cm.City_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON sm.Status = stm.Status_ID where AirWayBill_No='" + AirWayBill_No + "'";
            insertQuery = "Insert Into Stock_History(AirWayBill_No,City_Name,Receipt_Date,Receipt_LotNo,Agent_Name,Issue_Date,Issue_LotNo,Status,Remarks,Used_Date,Created_By,Created_On) SELECT  sm.AirWayBill_No, cm.City_Name, sm.Receipt_Date, sm.Receipt_LotNo,am.Agent_Name, sm.Issue_Date, sm.Issue_LotNo, stm.Status_Name, sm.Remarks, sm.Used_Date, '" + Session["EMailID"].ToString() + "',getdate() FROM Stock_Master sm INNER JOIN City_Master cm ON sm.City_ID = cm.City_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON sm.Status = stm.Status_ID where AirWayBill_No='" + AirWayBill_No + "'";
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();       

            ////insertQuery = "Update Booking_Master set Status='" + 17 + "' where Stock_ID=(select Stock_ID from stock_Master where AirWayBill_No='" + AirWayBill_No + "')";

            ////com = new SqlCommand(insertQuery, con, tr);
            //////com = new SqlCommand(insertQuery, con);
            ////com.ExecuteNonQuery();
            ////com.Dispose();

            //insertQuery = "Insert Into Booking_History SELECT  bm.Booking_ID, fm.Flight_No, bm.Booking_Date,sm.AirWayBill_No,alm.Airline_Name, scm.Special_Commodity_Name, shm.Shipment_Name, cm.City_Name, dm.Destination_Name, am.Agent_Code, bm.Flight_Date, bm.No_of_Packages, bm.Measurement_Unit, bm.Gross_Weight, bm.Volume_Weight, bm.Charged_Weight, bm.Spot_Rate, bm.Commission, bm.Special_Commodity_Incentive, bm.Agent_Deal_Remarks, bm.Expected_Handover_Date, bm.Freight_Type, bm.Tariff_Rate, bm.Freight_Amount, bm.Special_Rate, bm.Special_Amount, bm.Entered_By, bm.Entered_On, stm.Status_Name as Status, stm1.Status_Name as Handover_status FROM Booking_Master bm INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Flight_Master fm ON fo.Flight_ID = fm.Flight_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Special_Commodity_Master scm ON bm.Special_Commodity_ID = scm.Special_Commodity_ID INNER JOIN Shipment_Master shm ON bm.Shipment_ID = shm.Shipment_ID INNER JOIN City_Master cm ON bm.City_ID = cm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Agent_Master am ON bm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON bm.Status = stm.Status_ID INNER JOIN Status_Master stm1 on bm.Handovered_Status=stm1.Status_ID inner join Airline_Master alm on substring(sm.AirWayBill_No,1,3)=alm.Airline_Code where AirWayBill_No='" + AirWayBill_No + "'";
            //insertQuery = "Insert Into Booking_History SELECT bm.Booking_ID,bm.Booking_Date,sm.AirWayBill_No,alm.Airline_Name, fm.Flight_No,  cm.City_Name, dm.Destination_Name, am.Agent_Code, scm.Special_Commodity_Name, shm.Shipment_Name,bm.Flight_Date, bm.No_of_Packages, bm.Measurement_Unit, bm.Gross_Weight, bm.Volume_Weight, bm.Charged_Weight, bm.Spot_Rate, bm.Commission, bm.Special_Commodity_Incentive, bm.Agent_Deal_Remarks, bm.Expected_Handover_Date, bm.Freight_Type, bm.Tariff_Rate, bm.Freight_Amount, bm.Special_Rate, bm.Special_Amount, stm1.Status_Name as Handover_status ,stm.Status_Name as Status,bm.Entered_By, bm.Entered_On FROM Booking_Master bm INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Flight_Master fm ON fo.Flight_ID = fm.Flight_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Special_Commodity_Master scm ON bm.Special_Commodity_ID = scm.Special_Commodity_ID INNER JOIN Shipment_Master shm ON bm.Shipment_ID = shm.Shipment_ID INNER JOIN City_Master cm ON bm.City_ID = cm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Agent_Master am ON bm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON bm.Status = stm.Status_ID INNER JOIN Status_Master stm1 on bm.Handovered_Status=stm1.Status_ID inner join Airline_Master alm on substring(sm.AirWayBill_No,1,3)=alm.Airline_Code where AirWayBill_No='" + AirWayBill_No + "'";
            insertQuery = "Insert Into Booking_History(Booking_ID,Booking_Date,AirWayBill_No,Airline_Name,Flight_No,Origin,Destination,Agent_Code,Special_Commodity_Name,Shipment_Name,Flight_Date,No_of_Packages,Measurement_Unit,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Agent_Deal_Remarks,Expected_Handover_Date,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Handovered_Status,Status,Entered_By,Entered_On) SELECT bm.Booking_ID,bm.Booking_Date,sm.AirWayBill_No,alm.Airline_Name, fm.Flight_No,  cm.City_Name, dm.Destination_Name, am.Agent_Code, scm.Special_Commodity_Name, shm.Shipment_Name,bm.Flight_Date, bm.No_of_Packages, bm.Measurement_Unit, bm.Gross_Weight, bm.Volume_Weight, bm.Charged_Weight, bm.Spot_Rate, bm.Commission, bm.Special_Commodity_Incentive, bm.Agent_Deal_Remarks, bm.Expected_Handover_Date, bm.Freight_Type, bm.Tariff_Rate, bm.Freight_Amount, bm.Special_Rate, bm.Special_Amount, stm1.Status_Name as Handover_status ,stm.Status_Name as Status,'" + Session["EMailID"].ToString() + "',getdate() FROM Booking_Master bm INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Flight_Master fm ON fo.Flight_ID = fm.Flight_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Special_Commodity_Master scm ON bm.Special_Commodity_ID = scm.Special_Commodity_ID INNER JOIN Shipment_Master shm ON bm.Shipment_ID = shm.Shipment_ID INNER JOIN City_Master cm ON bm.City_ID = cm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Agent_Master am ON bm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON bm.Status = stm.Status_ID INNER JOIN Status_Master stm1 on bm.Handovered_Status=stm1.Status_ID inner join Airline_Master alm on substring(sm.AirWayBill_No,1,3)=alm.Airline_Code where AirWayBill_No='" + AirWayBill_No + "'";

            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            tr.Commit();
            con.Close();
            
        }

        catch (Exception ex)
        {
            tr.Rollback();
            Response.Write(ex.Message);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    } 
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Noshow();
        updateamount();
        Response.Redirect("booking_details.aspx?id="+AirWayBill_No);
        //lblMsg.Text = "Has been Cancelled (No Show SuccessFully)";
    }
    protected void updateamount()
    {
        using (con)
        {
            try
            {
                int j = int.Parse(Request.QueryString["booking_id"].ToString());
                con = new SqlConnection(strCon);
                con.Open();
                strquery = "SELECT dbo.Booking_Master.Booking_ID,dbo.Booking_Master.stock_ID, dbo.Booking_Master.Special_Amount,Booking_AWB.Total_DueCarrier, dbo.Agent_Master.Agent_ID,dbo.Agent_Master.Used_Limit FROM dbo.Booking_Master INNER JOIN dbo.Agent_Master ON dbo.Booking_Master.Agent_ID = dbo.Agent_Master.Agent_ID INNER JOIN dbo.Stock_Master ON dbo.Booking_Master.Stock_ID = dbo.Stock_Master.Stock_ID AND dbo.Agent_Master.Agent_ID = dbo.Stock_Master.Agent_ID INNER JOIN db_owner.Booking_AWB ON dbo.Booking_Master.Booking_ID = db_owner.Booking_AWB.Booking_ID where dbo.Booking_Master.Booking_ID=" + j;
                com = new SqlCommand(strquery, con);
                SqlDataReader rdr = com.ExecuteReader();
                rdr.Read();
                int agentid = int.Parse(rdr["Agent_ID"].ToString());

                decimal specialammount = Convert.ToDecimal(rdr["Special_Amount"].ToString());
                decimal totalduecarrier = Convert.ToDecimal(rdr["Total_DueCarrier"].ToString());
                decimal total = specialammount + totalduecarrier;
                decimal usedlimit = Convert.ToDecimal(rdr["Used_Limit"].ToString());
                decimal trueusedlimit = usedlimit - total;
                rdr.Close();

                strquery = "update agent_master set used_limit='" + trueusedlimit + "' where Agent_ID=" + agentid;
                com = new SqlCommand(strquery, con);
                com.ExecuteNonQuery();

            }
            catch (Exception)
            {


            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }


            
        
        
        }
    
    }
   
}
