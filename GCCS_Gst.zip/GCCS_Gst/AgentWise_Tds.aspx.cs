using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


// This Page is Design & Coding By Alok Date:10.12.2007
public partial class AgentWise_Tds : System.Web.UI.Page
{     
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
#region Variables Declaration
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    string loginid;
    string Access;
    string Arl_Access;
    string Agent_TDS_Id;
    string Agent_TDSId;
    string ts1;
    string ts2;
    string[] Sdate;
    string tt;
    string mm;
    string status;
    string aid;
    string Airdid;
    SqlTransaction trans = null;
    DisplayWrap dw = new DisplayWrap();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        #region PageLoad

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {          
            loginid = Session["EMailID"].ToString();
            if (!IsPostBack && Request.QueryString["Agent_TDS_Id"] != null)
            {
                uphistory();
                LoadAgentName();
                ShowCompany();
                //UserAirlineNamePlusCode();              
                lblAdd.Visible = false;
                lblUpdate.Visible = true;
                btnupdate.Visible = true;
                btnAdd.Visible = false;
                HtmlGenericControl body = (HtmlGenericControl)Page.Master.FindControl("MyBody");
                body.Attributes.Add("onload", "both(this)");
                btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
                //Radio2.Attributes.Add("onClick", "javascript :unlimit()");
                Agent_TDS_Id = Convert.ToString(Request.QueryString["Agent_TDS_Id"]);
                string str1 = "select AT.Agent_TDS_Id as 'Agent_TDS_Id',AG.Agent_Name as 'Agent_Name',AT.Airline_detail_id,AG.Agent_ID as 'Agent_ID',AT.Company_ID as 'Company_ID',CM.Company_Name as 'Company_Name',AT.Exempted_TDS_Rate as 'Exempted_TDS_Rate',AT.TDS_Exemption_Limit as 'TDS_Exemption_Limit',TDS_Status_Limited,AT.Education_Cess as 'Education_Cess',AT.Remarks as 'Remarks',convert(varchar,AT.Valid_From ,103) as 'Valid_From',convert(varchar,AT.Valid_To ,103) as 'Valid_To',AT.Airline_Detail_ID as 'Airline_Detail_ID',AT.Entered_By as 'Entered_By',AT.Entered_On as 'Entered_On'  from Agentwise_TDS AT inner join Company_Master CM on CM.Company_ID=AT.Company_ID inner join Agent_master AG on AG.Agent_ID=AT.Agent_Id  where AT.Agent_TDS_Id='" + Agent_TDS_Id + "'";
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(str1, con);
                SqlDataReader dr = com.ExecuteReader();
                dr.Read();
                Airdid = dr["Airline_Detail_ID"].ToString();
                string aid = dr["Agent_ID"].ToString();
                for (int p = 0; p <= (ddlAgent.Items.Count - 1); p++)
                {
                    if (ddlAgent.Items[p].Value == aid)
                    {
                        ddlAgent.Items[p].Selected = true;
                    }
                }
                ddlAgent.Enabled = false;
                string z = dr["Company_ID"].ToString();
                for (int i = 0; i <= (ddlCompany.Items.Count - 1); i++)
                {
                    if (ddlCompany.Items[i].Value == z)
                    {
                        ddlCompany.Items[i].Selected = true;
                    }
                }        
                ddlCompany.Enabled = false;
                txtTdsRate.Text = dr["Exempted_TDS_Rate"].ToString();
                txtTdsLimit.Text = dr["TDS_Exemption_Limit"].ToString();
                lblLimited.Value = txtTdsLimit.Text;
                //txtEdCess.Text = dr["Education_Cess"].ToString();
                txtRemarks.Text = dr["Remarks"].ToString();
                txtfromdate.Text = dr["Valid_From"].ToString();
                txttodate.Text = dr["Valid_To"].ToString();
                status = dr["TDS_Status_Limited"].ToString();
                lblstaus.Value = dr["TDS_Status_Limited"].ToString();
                //if (status == "14")
                //{
                //    Radio2.Checked = true;
                //}
                //else
                //{
                //    Radio1.Checked = true;
                //}
                con.Close();
                UserAirlineNamePlusCode1();           
            }
            else if (!IsPostBack)
            {
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
                //rdlimited.Attributes.Add("onClick", "javascript :Limited()");
                //rdunLimited.Attributes.Add("onClick", "javascript :UnLimited()");
                btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
                txtfromdate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                Sdate = txtfromdate.Text.Split('/');
                string month = Sdate[1];
                string year = Sdate[2];
                if (Sdate[1] == "01" || Sdate[1] == "02" || Sdate[1] == "03")
                {
                    int yy = int.Parse(year);
                    string destdata = "31/03/" + yy.ToString();
                    txttodate.Text = destdata;
                }
                if (Sdate[1] == "04" || Sdate[1] == "05" || Sdate[1] == "06" || Sdate[1] == "07" || Sdate[1] == "08" || Sdate[1] == "09" || Sdate[1] == "10" || Sdate[1] == "11" || Sdate[1] == "12")
                {
                    int yy = int.Parse(year) + 1;
                    string destdata = "31/03/" + yy.ToString();
                    txttodate.Text = destdata;
                }
                LoadAgentName();
                ShowCompany();
                lblAdd.Visible = true;
                lblUpdate.Visible = false;
                btnupdate.Visible = false;
                btnAdd.Visible = true;
            }
        }
        #endregion
    }
       

    // This Function is used  to update history
    public void uphistory()
    {
        con = new SqlConnection(strCon);
        string  cInsert, str1, agname, compname, airname, aid, cityname, tsource, tlimit, tedcess, tremarks, eby, tstatus;
        DateTime vdate, vdate1, eon;
        try
        {
            con.Open();
            Agent_TDS_Id = Convert.ToString(Request.QueryString["Agent_TDS_Id"]);
            str1 = "select AT.Agent_TDS_Id as 'Agent_TDS_Id',AG.Agent_Name as 'Agent_Name',AT.Airline_detail_id,AG.Agent_ID as 'Agent_ID',AT.Company_ID as 'Company_ID',CM.Company_Name as 'Company_Name',AT.Exempted_TDS_Rate as 'Exempted_TDS_Rate',AT.TDS_Exemption_Limit as 'TDS_Exemption_Limit',TDS_Status_Limited,AT.Education_Cess as 'Education_Cess',AT.Remarks as 'Remarks',AT.Valid_From as 'Valid_From',AT.Valid_To as 'Valid_To',AT.Airline_Detail_ID as 'Airline_Detail_ID',AT.Entered_By as 'Entered_By',AT.Entered_On as 'Entered_On'  from Agentwise_TDS AT inner join Company_Master CM on CM.Company_ID=AT.Company_ID inner join Agent_master AG on AG.Agent_ID=AT.Agent_Id  where AT.Agent_TDS_Id='" + Agent_TDS_Id + "'";
            com = new SqlCommand(str1,con);
            SqlDataReader dr = com.ExecuteReader();
            dr.Read();
            agname = dr["Agent_Name"].ToString();
            compname = dr["Company_Name"].ToString();
            //airname = dr["Airline_Name"].ToString();
            //cityname = dr["City_Name"].ToString();
            aid = dr["Airline_Detail_ID"].ToString();
            tsource = dr["Exempted_TDS_Rate"].ToString();
            tlimit = dr["TDS_Exemption_Limit"].ToString();
            tedcess = dr["Education_Cess"].ToString();
            tstatus = dr["TDS_Status_Limited"].ToString();
            tremarks = dr["Remarks"].ToString();
            vdate = DateTime.Parse(dr["Valid_From"].ToString());
            vdate1 = DateTime.Parse(dr["Valid_To"].ToString());
            eby = dr["Entered_By"].ToString();
            eon = DateTime.Parse(dr["Entered_On"].ToString());
            dr.Close();
            cInsert = "INSERT INTO Agentwise_TDS_History (Agent_Name,Company_Name,Airline_Detail_ID,Exempted_TDS_Rate,TDS_Exemption_Limit,TDS_Status_Limited,Remarks,Valid_From,Valid_To,Entered_By,Entered_On)values('" + agname + "','" + compname + "','" + aid + "','" + tsource + "','" + tlimit + "','" + tstatus + "','" + tremarks.ToString() + "','" + vdate + "','" + vdate1 + "','" + eby + "','" + eon + "')";
            com = new SqlCommand(cInsert, con);
            com.ExecuteNonQuery();
            con.Close();
        }
        catch (SqlException ex)
        {
            string str = ex.ToString();
            trans.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
 
    }  
    // This Function is used for 
    # region For Agent Display
    public void LoadAgentName()
    {
        try
        {
            string strAgent = "select Agent_ID,Agent_Name from Agent_Master  order by Agent_Name asc";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAgent.Items.Insert(0, "Select Agent Name");
            ddlAgent.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAgent.Items.Add(new ListItem(dr["Agent_Name"].ToString(), dr["Agent_ID"].ToString()));

            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    #endregion
    // This Function is used for show company in ListBox
    #region For Company Display
    public void ShowCompany()
    {
        try
        {
            string strComp = "select Company_Name,Company_ID from Company_master where Status='2' and Parent_ID='0'";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strComp, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlCompany.Items.Insert(0, "Select Company Name");
            ddlCompany.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlCompany.Items.Add(new ListItem(dr["Company_Name"].ToString() , dr["Company_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    #endregion
    #region Display Airline/City in  Update Case
    public void UserAirlineNamePlusCode1()
    {
        try
        {
            string strQuery = "";
            string Airline_Access = Rights1();
            lstAirlineCity.Items.Clear();
            strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City  where b.Airline_detail_id in" + "(" + Airline_Access + ") and a.Company_ID='" + ddlCompany.SelectedItem.Value + "' order by  a.Airline_Name";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                lstAirlineCity.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));

            }
            string[] zz = Airdid.Split(new char[] { ',' });
            for (int j = 0; j < zz.Length; j++)
            {
                for (int i = 0; i <= (lstAirlineCity.Items.Count - 1); i++)
                {
                    if (lstAirlineCity.Items[i].Value == zz[j])
                    {
                        lstAirlineCity.Items[i].Selected = true;
                    }
                }
            }
            con.Close();

        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string Rights1()
    {
        string sql_Access = "select Airline_Access from Agent_Master a inner join Agent_Branch b on a.Agent_ID=b.agent_id inner join login_master c on b.Agent_Branch_ID=c.Agent_ID where a.agent_id=" + ddlAgent.SelectedValue;


        con = new SqlConnection(strCon);
        con.Open();

        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        Access = "";
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                //Access = dr.GetValue(0).ToString();
                if (Access == "")
                {
                    Access = dr.GetValue(0).ToString();
                }
                else
                {
                    Access = Access + "," + dr.GetValue(0).ToString();
                }
            }
        }

        if (Access == null)
        {
            lblmsg.Visible = true;
            lblmsg.Text = " There Is No Airline Exists For Agent " + ddlAgent.SelectedItem.Text;

        }
        else
        {
            lblmsg.Visible = false;
            //int Split_Acces = Access.Length;
            //Arl_Access = Access.Substring(0, (Split_Acces - 1));
            Session["Arl_Access"] = Access;

        }
        return Access;

    }
    #endregion
    #region Display Airline/City in  ADD Case
    public void UserAirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            string Airline_Access = Rights();
           lstAirlineCity .Items.Clear();
           strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City  where b.Airline_Detail_ID in" + "(" + Airline_Access + ") and a.Company_ID='" + ddlCompany.SelectedItem.Value + "' order by  a.Airline_Name";

                    con = new SqlConnection(strCon);
                    con.Open();
                    SqlCommand com = new SqlCommand(strQuery, con);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        lstAirlineCity.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));

                    }
                    con.Close();  
            }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string Rights()
    {

        string agentId="";
        string  agent_Name="";
        ////string sql_Access = "select Airline_Access from Agent_Master a inner join Agent_Branch b on a.Agent_ID=b.agent_id inner join login_master c on b.Agent_Branch_ID=c.Agent_ID where a.agent_id=" + ddlAgent.SelectedValue;

        //**Added On 29 Mar 2011 (selection of Airline access based on sub Agent,rather than Agent)*****
        foreach (int i in lstsubAgent.GetSelectedIndices())    // values store in listbox
        {
            if (lstsubAgent.Items[i].Selected)
            {
                agentId += lstsubAgent.Items[i].Value + ",";
                agent_Name += lstsubAgent.Items[i].Text + ",";
            }
        }
        agentId = agentId.TrimEnd(',');
        agent_Name = agent_Name.TrimEnd(',');
        string sql_Access = "select Airline_Access from Agent_Master a inner join Agent_Branch b on a.Agent_ID=b.agent_id inner join login_master c on b.Agent_Branch_ID=c.Agent_ID where a.agent_id in(" + agentId + ")";


        con = new SqlConnection(strCon);
        con.Open();

        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        Access = "";
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                if (Access == "")
                {
                    Access =  dr.GetValue(0).ToString();
                }
                else
                {
                    Access = Access +","+ dr.GetValue(0).ToString();
                }
            }
        }
        
        if (Access == null)
        {
            lblmsg.Visible = true;
            lblmsg.Text = " There Is No Airline Exists For Agent " + ddlAgent.SelectedItem.Text;
     
        }
        else
        {
            lblmsg.Visible = false;
            //int Split_Acces = Access.Length;
            //Arl_Access = Access.Substring(0, (Split_Acces - 1));
            Session["Arl_Access"] = Access;
                     
        }
        return Access;

    }
    #endregion 
    #region Functions For Convert Date 
    public string ConvertDate(string strD)
    {

        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];

    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split('/');
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strYYYY + "/" + strMM + "/" + strDD;
        return strMMDDYYYY;
    }
    #endregion
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        AddData();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewAgentWise_Tds.aspx");
    }
    public void AddData()
    {

        con = new SqlConnection(strCon);//Making Connection
            string insertQ;
            string fromDat = ConvertDate(txtfromdate.Text);
            string todat = ConvertDate(txttodate.Text);
            DateTime dt1 = DateTime.Parse(ConvertDate(txtfromdate.Text));
            DateTime dt2 = DateTime.Parse(ConvertDate(txttodate.Text));
            try
            {
                string airlines = "";
                string airline_exist="";
                bool flag = false;
                con.Open();
                while (dt1 <= dt2)
                {
                    try
                    {

                        foreach (int i in lstAirlineCity.GetSelectedIndices())    // values store in listbox
                        {
                            if (lstAirlineCity.Items[i].Selected)
                            {
                                airlines = lstAirlineCity.Items[i].Value;
                                airline_exist = lstAirlineCity.Items[i].Text;
                                string strSelect = "select Agent_TDS_Id,Agent_ID from Agentwise_TDS where '" + dt1 + "' between  valid_From and Valid_To and Agent_ID='" + ddlAgent.SelectedItem.Value + "' and Company_ID='" + ddlCompany.SelectedItem.Value.Trim() + "' and Airline_Detail_ID like '%" + airlines + "%'";
                                SqlConnection con1 = new SqlConnection(strCon);
                                con1.Open();
                                com = new SqlCommand(strSelect, con1);
                                SqlDataReader dr = com.ExecuteReader();
                                if (dr.Read())
                                {
                                    Agent_TDSId = dr["Agent_TDS_Id"].ToString();
                                    flag = true;
                                    break;
                                }
                                dt1 = dt1.AddDays(1);
                                com.Dispose();
                                dr.Dispose();
                                con1.Close();

                            }
                           
                        }
                        if (flag == true)
                        {
                            break;
                        }
                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;
                        lblmsg.Text = err;
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    }

                          
                     
                }
                com.Dispose();
                con.Close();

                if (flag == false)
                {

                    if (lstAirlineCity.Items.Count > 0)
                    {
                        try
                        {
                            con.Open();

                            foreach (int i in lstAirlineCity.GetSelectedIndices())    // values store in listbox
                            {
                                if (lstAirlineCity.Items[i].Selected)
                                {
                                    tt = lstAirlineCity.Items[i].Value + ",";
                                    mm = mm + tt;

                                }
                            }
                            mm=mm.Remove(mm.LastIndexOf(","));
                           
                            if (Radio1.Checked==true)
                            {
                                insertQ = "INSERT INTO Agentwise_TDS (Agent_Id,Company_ID,Airline_Detail_ID,Exempted_TDS_Rate,TDS_Exemption_Limit,TDS_Status_Limited,Remarks,Valid_From,Valid_To,Entered_By,Entered_On)values('" + ddlAgent.SelectedItem.Value.Trim() + "','" + ddlCompany.SelectedItem.Value + "','" + mm + "','" + txtTdsRate.Text.Trim() + "','" + txtTdsLimit.Text.Trim() + "','13','" + txtRemarks.Text.Trim() + "','" + fromDat + "','" + todat + "','" + loginid + "','" + DateTime.Now + "')";
                            }
                            else
                            {
                                insertQ = "INSERT INTO Agentwise_TDS (Agent_Id,Company_ID,Airline_Detail_ID,Exempted_TDS_Rate,TDS_Exemption_Limit,TDS_Status_Limited,Remarks,Valid_From,Valid_To,Entered_By,Entered_On)values('" + ddlAgent.SelectedItem.Value.Trim() + "','" + ddlCompany.SelectedItem.Value + "','" + mm + "','" + txtTdsRate.Text.Trim() + "','0','14','" + txtRemarks.Text.Trim() + "','" + fromDat + "','" + todat + "','" + loginid + "','" + DateTime.Now + "')";
                            }
                            com = new SqlCommand(insertQ, con);
                            com.ExecuteNonQuery();
                            con.Close();
                            Response.Redirect("ViewAgentWise_Tds.aspx");

                        }

                        catch (SqlException se)
                        {
                            string err = se.Message;
                            lblmsg.Text = err;
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }

                    }
                }//end of if flag.
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = " TDS Rate Alredy Exists Betweent Date " + txtfromdate.Text + " To " + txttodate.Text + "  For Agent " + ddlAgent.SelectedItem.Text + "And Airline" + airline_exist;
                    //Response.Redirect("UpdateAgentWise_TDS.aspx?id=" + Agent_TDSId + "&AirlineDetailId=" + lblmsg.Text);
                    Response.Redirect("UpdateAgentWise_TDS.aspx?id=" + Agent_TDSId +"&AirlineName=" +airline_exist);
                }

            }
            catch (SqlException se)
            {
                string err = se.Message;

                trans.Rollback();
                lblmsg.Text = err;
            }

            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

        }
    public void UpdateData()
    {
           con = new SqlConnection(strCon);//Making Connection
            string updateQ;
            string fromDat = ConvertDate(txtfromdate.Text);
            string todat = ConvertDate(txttodate.Text);
            try 
            {            
                if (lstAirlineCity.Items.Count > 0)
                    {
                        try
                        {
                            con.Open();

                            foreach (int i in lstAirlineCity.GetSelectedIndices())    // values store in listbox
                            {
                                if (lstAirlineCity.Items[i].Selected)
                                {
                                    tt = lstAirlineCity.Items[i].Value + ",";
                                    mm = mm + tt;

                                }
                            }
                            mm = mm.Remove(mm.LastIndexOf(","));
                            if (Radio1.Checked == true)
                            {
                                updateQ = "update Agentwise_TDS  set Airline_Detail_ID='" + mm + "',Exempted_TDS_Rate='" + txtTdsRate.Text + "',TDS_Exemption_Limit='" + txtTdsLimit.Text + "',TDS_Status_Limited='13',Remarks='" + txtRemarks.Text + "',Valid_From='" + fromDat + "',Valid_To='" + todat + "',Entered_By='" + loginid + "',Entered_On='" + DateTime.Now + "' where Agent_Tds_ID='" + Convert.ToString(Request.QueryString["Agent_Tds_ID"]) + "'";
                            }
                            else
                            {
                                updateQ = "update Agentwise_TDS  set Airline_Detail_ID='" + mm + "',Exempted_TDS_Rate='" + txtTdsRate.Text + "',TDS_Exemption_Limit='0',TDS_Status_Limited='14',Remarks='" + txtRemarks.Text + "',Valid_From='" + fromDat + "',Valid_To='" + todat + "',Entered_By='" + loginid + "',Entered_On='" + DateTime.Now + "' where Agent_Tds_ID='" + Convert.ToString(Request.QueryString["Agent_Tds_ID"]) + "'";
                            }
                            com = new SqlCommand(updateQ, con);
                            com.ExecuteNonQuery();
                            con.Close();
                            Response.Redirect("ViewAgentWise_Tds.aspx");

                        }

                        catch (SqlException se)
                        {
                            string err = se.Message;
                            lblmsg.Text = err;
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }

                    }

            }
            catch (SqlException se)
            {
                string err = se.Message;

                trans.Rollback();
                lblmsg.Text = err;
            }

            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        UpdateData();
    }

    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        UserAirlineNamePlusCode();
        if (lstAirlineCity.Items.Count <= 0)
        {
            lblmsg.Visible = true;
            lblmsg.Text = " There Is No Airline/City Exists For Agent " + ddlAgent.SelectedItem.Text + " And  Company  " + ddlCompany.SelectedItem.Text;
        }
    }
    protected void ddlAgent_SelectedIndexChanged(object sender, EventArgs e)
    {
         ddlCompany.SelectedIndex = 0;
        lstAirlineCity.Items.Clear();
        LoadsubAgent();
        lblmsg.Visible = false;
    }
    //************Added on 29 Mar 2011 (For Sub Agent)******************
    public void LoadsubAgent()
    {
        try
        {
            string strQuery = "";
            //string Airline_Access = Rights();
            lstsubAgent.Items.Clear();
            DataTable dtIATACodeForSubAgnt = dw.GetAllFromQuery("select IATA_CODE from agent_master where agent_id=" + ddlAgent.SelectedValue);
            if (dtIATACodeForSubAgnt.Rows.Count > 0)
            {
                strQuery = "select agent_name,agent_id from agent_master where IATA_CODE='" + dtIATACodeForSubAgnt.Rows[0]["IATA_CODE"].ToString() + "'"; ;

                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand com = new SqlCommand(strQuery, con);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    lstsubAgent.Items.Add(new ListItem(dr["agent_name"].ToString(), dr["agent_id"].ToString()));

                }
                con.Close();
            }
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
