using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CrDrDateWise : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    static string csrFooter = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
        rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");

        if (!Page.IsPostBack)
        {
            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            hdnDate.Value = first.ToString();
            txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            ddlyear.Items.Clear();
            for (int year = 2006; year <= DateTime.Today.Year; year++)
                ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
            ddlyear.SelectedValue = DateTime.Today.Year.ToString();

            int dt = System.DateTime.Now.Month;
            if (dt == 1)
                dt = 1;
            ddlMonth.Items[dt - 1].Selected = true;
            ShowAirline();
        
        }
    }
    protected void ShowAirline()
    {

        ddl_airline_city.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            dr = cmd.ExecuteReader();
            ddl_airline_city.Items.Add("Select airline name");
            ddl_airline_city.Items[0].Value = "";
            while (dr.Read())
            {
                ddl_airline_city.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            cmd.Dispose();
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddl_airline_city_SelectedIndexChanged(object sender, EventArgs e)
    {
        string agentId = null;
        string bID = null;
        lstAgent.Items.Clear();
        if (ddl_airline_city.SelectedValue != "0")
        {

            string[] ddl_airline_city_value = ddl_airline_city.SelectedItem.Value.Split(',');
            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                cmd = new SqlCommand("select airline_detail_id,belongs_to_city,Csr_Footer from airline_detail where airline_detail_id=" + ddl_airline_city_value[0] + "", con);
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    agentId = dr["airline_detail_id"].ToString();
                    bID = dr["belongs_to_city"].ToString();
                    csrFooter = dr["Csr_Footer"].ToString();
                    char ch = (char)System.Windows.Forms.Keys.Return;
                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                    string ch1 = Convert.ToString(ch);
                    string ch3 = Convert.ToString(ch2);
                    csrFooter = csrFooter.Replace(ch1, "<br>");
                    csrFooter = csrFooter.Replace(ch3, "&nbsp;");
                }
                dr.Dispose();
                cmd.Dispose();
                cmd = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + agentId + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lstAgent.Items.Add(new ListItem(dr["agent_name"].ToString(), dr["agent_id"].ToString()));
                }

            }
            catch (SqlException ex)
            {
                string strer = ex.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        //Page.Form.Target = "_blank";
        string agent_selected_id = "";
        string agent_selected_name = "";
        bool SelectedAgent = true;
        for (int i = 0; i < lstAgent.Items.Count; i++)
        {
            if (lstAgent.Items[i].Selected)
            {
                agent_selected_id = agent_selected_id + lstAgent.Items[i].Value + "~";
                agent_selected_name = agent_selected_name + lstAgent.Items[i].Text + "~";
                SelectedAgent = false;
            }
        }
        if (SelectedAgent)
        {
            ClientScript.RegisterStartupScript(GetType(), "Alert", "<SCRIPT LANGUAGE='javascript'>alert('Please Select The Agent');</script>");
        }
        else
        {
            string startDate = ddlMonth.SelectedValue + "/" + ((rbtnFirstFortn.Checked == true) ? "1" : "16") + "/" + ddlyear.SelectedValue;

            string endDate = ddlMonth.SelectedValue + "/" + ((rbtnFirstFortn.Checked == true) ? "15" : (Convert.ToDateTime(ddlMonth.SelectedValue + "/1/" + ddlyear.SelectedValue).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + ddlyear.SelectedValue;

            TextBox TextBox1 = new TextBox();
            TextBox TextBox2 = new TextBox();

            TextBox1.Text = startDate;
            TextBox2.Text = endDate;
            Session["Agent_List_value"] = agent_selected_id;
            Session["Agent_list_Text"] = agent_selected_name;
            Session["airline_name"] = ddl_airline_city.SelectedItem.Text;
            Session["airline_value"] = ddl_airline_city.SelectedItem.Value;
            Session["StartDate"] = txtValidFrom.Text;
            Session["EndDate"] = txtValidTo.Text;
            Session["csr_footer"] = csrFooter;
            Session["StartDate_fortnight"] = startDate;
            Session["EndDate_fortnight"] = endDate;
            if (chkstatus.Checked == true)
            {
                Session["chkstatus"] = "Y";
            }
            else
            {
                Session["chkstatus"] = "N";
            }
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open('CrDrDateWise_Show.aspx');</script>");

        }
    }
}
