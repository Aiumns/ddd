using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Add_Submenu : System.Web.UI.Page
{
    #region created by Mukul Chandra
    /// <summary>
    /// <class>Add Sub Menu</class>
    /// <description>
    /// 
    /// </description>
    /// <dependency></dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>15 dec</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// </modification>
    
    /// </modifications> 
    /// </summary> 
    /// 
    #endregion
    SqlConnection con;
    SqlCommand cmd;
    
    string strquery;
    SqlDataReader rdr;
    string strCon=ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        ddlmenu();
    }
    public void ddlmenu()
    {
        con =new  SqlConnection(strCon);
        con.Open();
        strquery = "select menu_id,menu_name from main_menu where menu_link='#'";
        cmd = new SqlCommand(strquery, con);
        rdr = cmd.ExecuteReader();
        DropDownList1.Items.Insert(0, "--Select--");
        DropDownList1.Items[0].Value = "0";
        while (rdr.Read())
        {
            DropDownList1.Items.Add(new ListItem (rdr["menu_name"].ToString(),rdr["menu_id"].ToString()));
            
        
        }
        rdr.Close();
        con.Close();
    
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        using (con)
        {
            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                strquery = "select * from main_menu where menu_name like'" + txtsubmenu.Text + "'  and parent_id='" + DropDownList1.SelectedItem.Value + "'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows == true)
                {
                    lblerror.Visible = true;
                    lblerror.Text = "Submenu Already Exists";
                    rdr.Close();

                }
                else
                {
                    rdr.Close();
                    strquery = "select count(menu_name) from main_menu where parent_id='" + DropDownList1.SelectedItem.Value + "'";
                    cmd = new SqlCommand(strquery, con);
                    int p = int.Parse(cmd.ExecuteScalar().ToString());
                    int k;
                    if (p > 0)
                    {

                        k = p;
                    }
                    else
                    {
                        k = 0;
                    }

                    strquery = "insert into dbo.Main_Menu(Menu_Name,Parent_ID,Sequence,Menu_Link)values(@Menu_Name,@Parent_ID,@Sequence,@Menu_Link)";
                    cmd = new SqlCommand(strquery, con);
                    cmd.Parameters.AddWithValue("@Menu_Name", txtsubmenu.Text );
                    cmd.Parameters.AddWithValue("@Parent_ID", DropDownList1.SelectedItem.Value);
                    cmd.Parameters.AddWithValue("@Sequence", k);
                    cmd.Parameters.AddWithValue("@Menu_Link", txtmenu.Text);

                    cmd.ExecuteNonQuery();
                    lblerror.Visible = true;
                    lblerror.Text = "Submenu Added Successfully for parent menu:" + DropDownList1.SelectedItem.Text;
                    txtmenu.Text = null;
                    txtsubmenu.Text = null;
                    DropDownList1.SelectedIndex = 0;
                    con.Close();

                }
            }
            catch (SqlException kk)
            {
                lblerror.Visible = true;
                lblerror.Text = "Sql Error::" + kk.Message;

            }
            catch (Exception yy)
            {
                lblerror.Visible = true;
                lblerror.Text = "Error Occur ::" + yy.Message;

            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }              
            
            }
        
        }
    }
}
