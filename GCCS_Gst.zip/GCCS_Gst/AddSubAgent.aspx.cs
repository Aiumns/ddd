using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Default5 : System.Web.UI.Page
{
    /// <summary>
    /// <class>Add Sub Agent</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>--------SAROJ KUMAR GUPTA--------</createdBy>
    /// <createdOn>-----Oct 25, 2007-------</createdOn>
    /// <modifications>
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy>--------SAROJ KUMAR GUPTA---------</modifiedBy>
    /// <modifiedOn>-------25,26 OCT 2007---------</modifiedOn>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand com;
    SqlTransaction trans = null;
    DataSet ds;
    string TodayDate;
    public string strLen = "";
    public string strAgent = "";
    int AgentID, AgentBranchID, CityID;
    public string ts1,ts2,name;   
    string loginid;
    public int ParentID,CityId;
    string strAgentID;
    //string Agent_Branchid;
    string Agent_Branchid,city;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;    // connectionString

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (Request.QueryString["Agent_ID"].ToString() == "AddSubAgent")
                btnUpdate.Visible = false;
            TodayDate = DateTime.Now.ToShortDateString();
            strAgent = "<script>var FillAgent=new Array(" + getAgentName() + ")</script>";
            //strLen = "<script>var FillCity=new Array(" + City() + ")</script>"; // call for CityName & CityCode

            loginid = Session["EMailID"].ToString();

            if (!Page.IsPostBack)
            {
                CityName();
                //BindAirlineAccess();
                BindGroupName();
                CheckGroupType();
                //btnUpdate.Visible = false;


            }
            //strAgentID = Request.QueryString["Agent_ID"].ToString();
            if (!Page.IsPostBack && Request.QueryString["Agent_ID"] != null && Request.QueryString["action"] == "e")
            {
                strAgentID = Request.QueryString["Agent_ID"].ToString();
                txtPassword.TextMode = TextBoxMode.SingleLine;
                btnUpdate.Visible = true;
                btnAgenttype.Visible = false;
                btnAdd.Visible = false;
                btnCancel.Visible = false;
                txtCity.Enabled = false;
                showtd.Visible = false;
                // Readonly---------
                txtLogin.ReadOnly = true;
                txtSubAgentName.ReadOnly = true;

                //txtSubAgentName.ReadOnly = true;
                lblHead.Text = "EDIT SUB AGENT";
                btnAddSubAgent.Visible = false;
                txtAgentName.ReadOnly = true;

                //Update
                ShowSubAgentData();
                findSubAgentDetails();
                FindLoginDetails();
                splitAirlineAccess();
                showSubagentByAdmin();

            }
        }
          
        
    }
  public void CityName()
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master order by city_code", con);
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        txtCity.DataSource = ds;
        txtCity.DataTextField = "CodeName";
        txtCity.DataValueField = "City_ID";

        txtCity.DataBind();
        txtCity.Items.Insert(0, new ListItem("--Select--", "0"));
        con.Close();
    }

    public string getAgentName()
    {
        string strAgentName = "";
        con = new SqlConnection(strCon);
        try
        {
            
                string selectGroupName = "SELECT distinct(Agent_Name) FROM Agent_Master where Parent_ID=0";
                com = new SqlCommand(selectGroupName, con);
                con.Open();
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (strAgentName == "")
                        strAgentName = "'" + Convert.ToString(dr["Agent_Name"]).ToString().ToUpper().Trim() + "'";
                    else
                        strAgentName = strAgentName + "," + "'" + Convert.ToString(dr["Agent_Name"]).ToString().ToUpper().Trim() + "'";
                }
                dr.Close();
                com.Dispose();
                con.Close();
            
               
        }
        catch (SqlException sqe)
        {
            string err = sqe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strAgentName;
    }
    protected void btnAddSubAgent_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectAgentName = "select Agent_Name from Agent_Master Where Parent_ID=0 and Agent_Name='"+txtAgentName.Text+"'";
        com = new SqlCommand(selectAgentName,con);
         SqlDataReader dr=com.ExecuteReader();
         if (dr.Read())
         {
             showtd.Visible = false;
             tabAddSubAgent.Visible = true;
             lblMessage.Visible = false;
             txtAgentName.ReadOnly = true;
         }
         else
         {
             tabAddSubAgent.Visible = false;
             lblMessage.Text = "Select Valid Agent Name";
             lblMessage.Visible = true;
         }
         dr.Dispose();
         con.Close();
         
    }

    public void BindAirlineAccess()  // Bind Airline_Access
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ;
           
            string citycode = txtCity.SelectedItem.Text;
            int m = citycode.IndexOf("-") + 1;
            string city_code = citycode.Substring(0, m - 1);

            ////selectQ = "select (a.Airline_Code+'-'+a.Airline_Name) as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where c.City_Code='" + city_code + "'and b.Status=2";

            //*********************Modify On 31_DEC_2010******************* City Free Airline***************

            //selectQ = "select (a.Airline_Code+'-'+a.Airline_Name) as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where c.City_Code='" + city_code + "' and b.Status=2";

            selectQ = "select (a.Airline_Code+'-'+a.Airline_Name+'('+c.City_Code+')') as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where b.Status=2";


            //***************************End Of Modification***************************



            com = new SqlCommand(selectQ, con);
            com.Connection = con;
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);

            CheckAirlineAccess.DataSource = ds;
            CheckAirlineAccess.DataTextField = "NameCode";
            CheckAirlineAccess.DataValueField = "Airline_detail_ID";
            CheckAirlineAccess.DataBind();
            CheckBoxList chk = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                chk.Items[i].Selected = true;
            }
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqlexep) 
        {
            string err = sqlexep.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
    }
    public string City() // Bind City_Code and City_Name
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT City_Name,City_Code  FROM City_Master";
            SqlCommand com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }
    public void BindGroupName()     // Bind Group_Name
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ;
            selectQ = "select Group_Name,Group_ID from Group_Master where Group_Type='Agent'";
            com = new SqlCommand(selectQ, con);
            com.Connection = con;
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            ddlGroupName.DataSource = ds;
            ddlGroupName.DataTextField = "Group_Name";
            ddlGroupName.DataValueField = "Group_ID";
            ddlGroupName.DataBind();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqlexe)
        {
            string err = sqlexe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtLogin.Text = "";
        txtPassword.Text = "";
        ddlGroupName.SelectedItem.Text = "Agent";
        txtSubAgentName.Text = "";
        txtAddress.Text = "";
        txtCity.SelectedIndex = 0;
         CheckAirlineAccess.Items.Clear();
        //txtContactPerson.Text = "";
        txtPhone.Text = "";
        txtFax.Text = "";
        txtConcernPerson.Text = "";
        //ddlStatus.SelectedItem.Text = "--Select--";
        //txtTDSExemLimit.Text = "";
        //txtCsrEmailID.Text = "";
        //txtIATAComm.Text = "";
        txtPanNo.Text = "";
        //txtSurcharge.Text = "";
        //txtTDSDeducSource.Text = "";
        txtCreditLimit.Text = "";
        ddlGroupName.SelectedIndex = 0;
        ddlStatus.SelectedIndex = 0;
        //txtIATACode.Text = "";
        lblMessage.Visible = false;
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (check())
        {
            
            lblMessage.Text = "Login ID Already Exists";
            lblMessage.Visible = true;
        }
        else if (checkAgentName())
        {
            lblMessage.Text = " Sub Agent Name Already Exists.";
            lblMessage.Visible = true;
        }
        else if (checkCityName())
        {
            int m = CheckAirlineAccess.Items.Count;
            for (int i = 0; i < m; i++)
            {
              CheckBoxList chk1 = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
                if (chk1.Items[i].Selected == false)
                {
                    lblMessage.Text = " Please Check at least One Airline Access";
                    lblMessage.Visible = true;

                }
                else
                {
                    FillData();     // call for Insert data into all Table
                    lblMessage.Text = "Records Added Successfully";
                    lblMessage.Visible = true;
                }
            }
        }
        else 
        {
            lblMessage.Text = "Select Valid City";
            lblMessage.Visible = true;
        }

    }
    public bool checkCityName()
    {

        con = new SqlConnection(strCon);
        con.Open();

        string citycode = txtCity.SelectedItem.Text;
        int m = citycode.IndexOf("-");
        if (m > 0)
        {
            string city_code = citycode.Substring(0, m - 1);
            string selectloginid;
            selectloginid = "select City_Code+'-'+City_Name from City_Master  where City_Code=@cityName or City_Name=@City_CodeId";
            com = new SqlCommand(selectloginid, con);
            com.Parameters.AddWithValue("@cityName", city_code);
            com.Parameters.AddWithValue("@City_CodeId", FindCityName());
            SqlDataReader sdr = com.ExecuteReader();
            if (sdr.Read())
            {
                con.Close();
                con.Open();

                return true;
            }
            else
            {
                con.Close();
                con.Open();
                return false;
            }
        }
        else
        {
            lblMessage.Text = "select Valid City";
            lblMessage.Visible = true;
            return false;
        }

    }
    public void CheckGroupType()    // check Group Type
    {

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ = "select Group_Type from Group_Master where group_ID=(select Group_ID from Login_Master where  Email_ID=@Login_id)";
            com = new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@Login_id", loginid);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr["Group_Type"].ToString().ToUpper().Trim().Equals( "AGENT"))
                {
                    showtd.Visible = false;
                    tdAgentType.Visible = true;
                    //tabAgentSub.Visible = true;
                    tabAddSubAgent.Visible = true ;
                    btnAgenttype.Visible = true;
                    btnAdd.Visible = false;
                    tdAgent.Visible = false;
                    txtAgent_Name.Text = FindAgentName();
                }
                else
                {
                    showtd.Visible = true;
                    tdAgent.Visible = true;
                    btnAdd.Visible = true;
                    btnAgenttype.Visible = false;
                }
            }
            con.Close();
        }
        catch(SqlException esx)
        {
            string err = esx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
       

    }
    public string FindAgentName()   // Find agent Name According  login id
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            SqlCommand comm = new SqlCommand("select Agent_Name from Agent_Master where Agent_ID=(select Agent_ID from Agent_Branch where Agent_Email=@loginID)", con);
            comm.Parameters.AddWithValue("@loginID", loginid);
            name = comm.ExecuteScalar().ToString();
            con.Close();
        }
        catch (SqlException esx)
        {
            string err = esx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        return name;
    }
    public void FillData()      // insert Data in All Table
    {
        con = new SqlConnection(strCon);
        con.Open();
        string insertQ,insertQ2, insertQ3; ;

        try
        {
            trans = con.BeginTransaction();
            string str = txtCity.SelectedItem.Text;
            string str1;
            int j = str.IndexOf("-") + 1;
            int k = str.Length;
            str1 = str.Substring(0, j - 1);
            // Response.Write(str1);
            string id = "00001";
            //string username = txtAgentName.Text;
            //string ch = username.Substring(0, 1);
            //SqlConnection con = new SqlConnection(strCon);
            //con.Open();
            SqlCommand cmd = new SqlCommand("select isnull(max(Agent_Code),0) from Agent_Master where Agent_Code like '" + str1 + "%'", con, trans);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() && dr[0].ToString() != "0")
            {
                string str2 = dr[0].ToString().Substring(0, dr[0].ToString().Length);
                string ch1 = str2.Substring(3);

                int i = Convert.ToInt32(ch1) + 1;
                string si = i.ToString();
                if (si.Length == 1)
                {
                    id = str1.ToUpper() + "0000" + i;
                }
                else if (si.Length == 2)
                {
                    id = str1.ToUpper() + "000" + i;
                }
                else if (si.Length == 3)
                {
                    id = str1.ToUpper() + "00" + i;
                }
                else if (si.Length == 4)
                    id = str1.ToUpper() + "0" + i;

            }
            else
            {
                id = str1.ToUpper() + id;

            }

            con.Close();
            con.Open();
            
            // Find Parent_ID
            string selectParentID;
            selectParentID = "select Agent_ID from Agent_Master where Agent_Name=@AgentName";
            cmd = new SqlCommand(selectParentID, con, trans);
            cmd.Parameters.AddWithValue("@AgentName", txtAgentName.Text);
            ParentID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            // insert into Agent_Master

            insertQ = "insert into dbo.Agent_Master(Agent_Code,Agent_Name,Credit_Limit,Parent_ID,Entered_By,Entered_On)values(@Agent_Code,@Agent_Name,@Credit_Limit,@Parent_ID,@Entered_By,@Entered_On)";
            cmd = new SqlCommand(insertQ, con, trans);
            cmd.Parameters.AddWithValue("@Agent_Code",id);
            cmd.Parameters.AddWithValue("@Agent_Name", txtSubAgentName.Text.Replace("'", "`"));
            //cmd.Parameters.AddWithValue("@IATA_Code",txtIATACode.Text);
            //cmd.Parameters.AddWithValue("IATA_Commission", txtIATAComm.Text);
            //cmd.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
            //cmd.Parameters.AddWithValue("@TDS_Exemption_Limit", txtCreditLimit.Text);
            cmd.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
            //cmd.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
            cmd.Parameters.AddWithValue("@Parent_ID", ParentID);
            //cmd.Parameters.AddWithValue("@Status",ddlStatus.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@Entered_By", loginid);
            cmd.Parameters.AddWithValue("@Entered_On", TodayDate);
            cmd.ExecuteNonQuery();
            // Find Agent_ID
            string selectQ;
            selectQ = "select max(Agent_ID) From Agent_Master ";
            cmd = new SqlCommand(selectQ, con, trans);
            AgentID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            // Find City name
            string citycode = txtCity.SelectedItem.Text;
            int m = citycode.IndexOf("-") + 1;
            citycode = citycode.Substring(0, m - 1);
            cmd = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con, trans);
            SqlDataReader dr1 = cmd.ExecuteReader();
            while (dr1.Read())
            {
                CityID = Convert.ToInt32(dr1["City_ID"].ToString());
            }
            con.Close();
            con.Open();
            dr1.Close();

            //Insert Agent_Branch
            insertQ3 = "insert into Agent_Branch(Agent_ID,Branch_Status,Belongs_To_City,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,Pan_No,Status)values(@Agent_ID,@Branch_Status,@Belongs_To_City,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@Pan_No,@Status)";
            cmd = new SqlCommand(insertQ3, con, trans);
            cmd.Parameters.AddWithValue("@Agent_ID", AgentID);
            cmd.Parameters.AddWithValue("@Branch_Status",18);
            cmd.Parameters.AddWithValue("@Belongs_To_City", CityID);
            cmd.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
            cmd.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
            cmd.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
            //cmd.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
            //cmd.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
            cmd.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
            cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
            cmd.ExecuteNonQuery();

            // Find AgentBranchId
            string selectQ1;
            selectQ1 = "select max(Agent_Branch_ID) From Agent_Branch ";
            //selectQ = "select @@identity from Agent_Branch";
            cmd = new SqlCommand(selectQ1, con, trans);
            AgentBranchID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            // Insert into Login_Master
            insertQ2 = "insert into Login_Master(Email_ID,Login_Password,Agent_ID,Group_ID,Airline_Access )values(@Email_ID,@Login_Password,@Agent_ID,@Group_ID,@Airline_Access)";
            cmd = new SqlCommand(insertQ2, con, trans);


            for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // values store in listbox
            {
                if (CheckAirlineAccess.Items[i].Selected)
                {

                    ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
                }
            }
            ts1 = ts1.Remove(ts1.LastIndexOf(","));
            cmd.Parameters.AddWithValue("@Email_ID", txtLogin.Text);
            cmd.Parameters.AddWithValue("@Login_Password",txtPassword.Text);
            cmd.Parameters.AddWithValue("@Agent_ID", AgentBranchID);
            cmd.Parameters.AddWithValue("@Airline_Access", ts1);
            cmd.Parameters.AddWithValue("@Group_ID", ddlGroupName.SelectedValue);
            cmd.ExecuteNonQuery();

            // insert into Agent_History
            //insertQ1 = "insert into dbo.Agent_History(Agent_Code,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,Credit_Limit,Pan_No,Status,Entered_By,Entered_On)values(@Agent_Code,@Login_Password,@Group_Name,@Airline_Access,@Belongs_To_City,@Agent_Name,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@Credit_Limit,@Pan_No,@Status,@Entered_By,@Entered_On)";

            //cmd = new SqlCommand(insertQ1, con, trans);
            //cmd.Parameters.AddWithValue("@Agent_Code", id);
            //cmd.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
            //cmd.Parameters.AddWithValue("@Group_Name", ddlGroupName.SelectedItem.Text);
            //cmd.Parameters.AddWithValue("@Airline_Access", ts1);
            //cmd.Parameters.AddWithValue("@Belongs_To_City", FindCityName());
            //cmd.Parameters.AddWithValue("@Agent_Name",txtSubAgentName.Text);
            //cmd.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
            //cmd.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
            //cmd.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
            //cmd.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
            //cmd.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
            ////cmd.Parameters.AddWithValue("@IATA_Code",txtIATACode.Text);
            ////cmd.Parameters.AddWithValue("@IATA_Commission", txtIATAComm.Text);
            ////cmd.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
            ////cmd.Parameters.AddWithValue("@TDS_Exemption_Limit", txtCreditLimit.Text);
            //cmd.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
            ////cmd.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
            ////cmd.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
            ////cmd.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
            //cmd.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
            //cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
            //cmd.Parameters.AddWithValue("@Entered_By", loginid);
            //cmd.Parameters.AddWithValue("@Entered_On", TodayDate);
            //cmd.ExecuteNonQuery();
            //trans.Commit();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
            trans.Rollback();
            lblMessage.Text = err;
            lblMessage.Visible = true;
           
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Response.Redirect("ViewSubAgents.aspx");
    }
    protected string FindCityName()        // Split City Name
    {
        string str = txtCity.SelectedItem.Text;
        string str1;
        int j = str.IndexOf("-") + 1;
        int k = str.Length;
        str1 = str.Substring(j);
        return str1;
    }
    public bool check()     // check for Login Id Exists or Not
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectloginid;
        selectloginid = "select Email_ID from Login_Master where Email_ID=@EmailID";
        com = new SqlCommand(selectloginid, con);
        com.Parameters.AddWithValue("@EmailID",txtLogin.Text);
        SqlDataReader sdr = com.ExecuteReader();
        if (sdr.Read())
        {
            con.Close();
            con.Open();
            return true;
        }
        else
        {
            con.Close();
            con.Open();
            return false;
        }
    }
    public bool checkAgentName()        // Check Agent Name Exists.
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectloginid;
        selectloginid = "select Agent_Name from Agent_Master where Agent_Name=@AgentName";
        com = new SqlCommand(selectloginid, con);
        com.Parameters.AddWithValue("@AgentName",txtSubAgentName.Text);
        SqlDataReader sdr = com.ExecuteReader();
        if (sdr.Read())
        {
            con.Close();
            con.Open();
            return true;
        }
        else
        {
            con.Close();
            con.Open();
            return false;
        }
    }
    protected void btnAgenttype_Click(object sender, EventArgs e)
    {
        if (check())
        {
            lblMessage.Text = "Login ID Already Exists";
            lblMessage.Visible = true;
            
        }
        else if (checkAgentName())
        {
            lblMessage.Text = " Sub Agent Name Already Exists";
            lblMessage.Visible = true;
        }
        else if (checkCityName())
        {
            int m = CheckAirlineAccess.Items.Count;
            for (int i = 0; i < m; i++)
            {
              CheckBoxList chk1 = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
                if (chk1.Items[i].Selected == false)
                {
                    lblMessage.Text = " Please Check at least One Airline Access";
                    lblMessage.Visible = true;

                }
                else
                {
                    FillAgentData();     // call for Insert data into all Table
                    lblMessage.Text = "Records Added Successfully";
                    lblMessage.Visible = true;
                }
            }
        }
        else
        {
            lblMessage.Text = "Select Valid City Name";
            lblMessage.Visible = true;
        }

    }
    public void FillAgentData()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string insertQ,insertQ2, insertQ3; ;

        try
        {
            trans = con.BeginTransaction();
            string str = txtCity.SelectedItem.Text;
            string str1;
            int j = str.IndexOf("-") + 1;
            int k = str.Length;
            str1 = str.Substring(0, j - 1);
            // Response.Write(str1);
            string id = "00001";
            //string username = txtAgentName.Text;
            //string ch = username.Substring(0, 1);
            //SqlConnection con = new SqlConnection(strCon);
            //con.Open();
            SqlCommand cmd = new SqlCommand("select isnull(max(Agent_Code),0) from Agent_Master where Agent_Code like '" + str1 + "%'", con, trans);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() && dr[0].ToString() != "0")
            {
                string str2 = dr[0].ToString().Substring(0, dr[0].ToString().Length);
                string ch1 = str2.Substring(3);

                int i = Convert.ToInt32(ch1) + 1;
                string si = i.ToString();
                if (si.Length == 1)
                {
                    id = str1.ToUpper() + "0000" + i;
                }
                else if (si.Length == 2)
                {
                    id = str1.ToUpper() + "000" + i;
                }
                else if (si.Length == 3)
                {
                    id = str1.ToUpper() + "00" + i;
                }
                else if (si.Length == 4)
                    id = str1.ToUpper() + "0" + i;

            }
            else
            {
                id = str1.ToUpper() + id;

            }

            con.Close();
            con.Open();

            // Find Parent_ID
            string selectParentID;
            selectParentID = "select Agent_ID from Agent_Master where Agent_Name=@AgentName";
            cmd = new SqlCommand(selectParentID, con, trans);
            cmd.Parameters.AddWithValue("@AgentName",txtAgent_Name.Text);
            ParentID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            // insert into Agent_Master

            insertQ = "insert into dbo.Agent_Master(Agent_Code,Agent_Name,Credit_Limit,Parent_ID,Entered_By,Entered_On)values(@Agent_Code,@Agent_Name,@Credit_Limit,@Parent_ID,@Entered_By,@Entered_On)";
            cmd = new SqlCommand(insertQ, con, trans);
            cmd.Parameters.AddWithValue("@Agent_Code", id);
            cmd.Parameters.AddWithValue("@Agent_Name", txtSubAgentName.Text.Replace("'", "`"));
            //cmd.Parameters.AddWithValue("@IATA_Code", txtIATACode.Text);
           // cmd.Parameters.AddWithValue("IATA_Commission", txtIATAComm.Text);
            //cmd.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
            //cmd.Parameters.AddWithValue("@TDS_Exemption_Limit", txtCreditLimit.Text);
            cmd.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
            //cmd.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
            cmd.Parameters.AddWithValue("@Parent_ID", ParentID);
            //cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@Entered_By", loginid);
            cmd.Parameters.AddWithValue("@Entered_On", TodayDate);
            cmd.ExecuteNonQuery();
            // Find Agent_ID
            string selectQ;
            selectQ = "select max(Agent_ID) From Agent_Master ";
            cmd = new SqlCommand(selectQ, con, trans);
            AgentID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            // Find City name
            string citycode = txtCity.SelectedItem.Text;
            int m = citycode.IndexOf("-") + 1;
            citycode = citycode.Substring(0, m - 1);
            cmd = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con, trans);
            SqlDataReader dr1 = cmd.ExecuteReader();
            while (dr1.Read())
            {
                CityID = Convert.ToInt32(dr1["City_ID"].ToString());
            }
            con.Close();
            con.Open();
            dr1.Close();

            //Insert Agent_Branch
            insertQ3 = "insert into Agent_Branch(Agent_ID,Branch_Status,Belongs_To_City,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,Pan_No,Status)values(@Agent_ID,@Branch_Status,@Belongs_To_City,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@Pan_No,@Status)";
            cmd = new SqlCommand(insertQ3, con, trans);
            cmd.Parameters.AddWithValue("@Agent_ID", AgentID);
            cmd.Parameters.AddWithValue("@Branch_Status",18);
            cmd.Parameters.AddWithValue("@Belongs_To_City", CityID);
            cmd.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
            cmd.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
            cmd.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
            //cmd.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
            //cmd.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
            cmd.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
            cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
            cmd.ExecuteNonQuery();

            // Find AgentBranchId
            string selectQ1;
            selectQ1 = "select max(Agent_Branch_ID) From Agent_Branch ";
            //selectQ = "select @@identity from Agent_Branch";
            cmd = new SqlCommand(selectQ1, con, trans);
            AgentBranchID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            // Insert into Login_Master
            insertQ2 = "insert into Login_Master(Email_ID,Login_Password,Agent_ID,Group_ID,Airline_Access )values(@Email_ID,@Login_Password,@Agent_ID,@Group_ID,@Airline_Access)";
            cmd = new SqlCommand(insertQ2, con, trans);


            for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // values store in listbox
            {
                if (CheckAirlineAccess.Items[i].Selected)
                {

                    ts2 = ts2 + CheckAirlineAccess.Items[i].Value + ",";
                }
            }
            ts1 = ts1.Remove(ts1.LastIndexOf(","));
            cmd.Parameters.AddWithValue("@Email_ID", txtLogin.Text);
            cmd.Parameters.AddWithValue("@Login_Password",txtPassword.Text);
            cmd.Parameters.AddWithValue("@Agent_ID", AgentBranchID);
            cmd.Parameters.AddWithValue("@Airline_Access", ts2);
            cmd.Parameters.AddWithValue("@Group_ID", ddlGroupName.SelectedValue);
            cmd.ExecuteNonQuery();

            // insert into Agent_History
            //insertQ1 = "insert into dbo.Agent_History(Agent_Code,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,Credit_Limit,Pan_No,Status,Entered_By,Entered_On)values(@Agent_Code,@Login_Password,@Group_Name,@Airline_Access,@Belongs_To_City,@Agent_Name,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@Credit_Limit,@Pan_No,@Status,@Entered_By,@Entered_On)";

            //cmd = new SqlCommand(insertQ1, con, trans);
            //cmd.Parameters.AddWithValue("@Agent_Code", id);
            //cmd.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
            //cmd.Parameters.AddWithValue("@Group_Name", ddlGroupName.SelectedItem.Text);
            //cmd.Parameters.AddWithValue("@Airline_Access", ts2);
            //cmd.Parameters.AddWithValue("@Belongs_To_City", FindCityName());
            //cmd.Parameters.AddWithValue("@Agent_Name", txtSubAgentName.Text);
            //cmd.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
            //cmd.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
            //cmd.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
            //cmd.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
            //cmd.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
            ////cmd.Parameters.AddWithValue("@IATA_Code", txtIATACode.Text);
            ////cmd.Parameters.AddWithValue("@IATA_Commission", txtIATAComm.Text);
            ////cmd.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
            ////cmd.Parameters.AddWithValue("@TDS_Exemption_Limit", txtCreditLimit.Text);
            //cmd.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
            ////cmd.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
            ////cmd.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
            ////cmd.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
            //cmd.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
            //cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
            //cmd.Parameters.AddWithValue("@Entered_By", loginid);
            //cmd.Parameters.AddWithValue("@Entered_On", TodayDate);
            //cmd.ExecuteNonQuery();  
            trans.Commit();
            con.Close();
        }
        catch (SqlException se)
        {
            
            string err = se.Message;
            trans.Rollback();
            lblMessage.Text = err;
            lblMessage.Visible = true;
            
            
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Response.Redirect("ViewSubAgents.aspx");
    }
    //********************************************* for  Update *******************************************

   public void ShowSubAgentData()
    {
        con=new SqlConnection(strCon);
        con.Open();
        string str=Request.QueryString["Agent_ID"].ToString();
        try
        {
             string selectQ;
            selectQ="select * from Agent_Master where Agent_ID=@agent_ID";
            com=new SqlCommand(selectQ,con);
            com.Parameters.AddWithValue("@agent_ID",str);
            da=new SqlDataAdapter(com);
            ds=new DataSet();
            da.Fill(ds);
            int temp=ds.Tables[0].Rows.Count;
            for(int i=0;i<temp;i++)
            {
                //txtIATACode.Text=ds.Tables[0].Rows[i]["IATA_Code"].ToString();
                txtSubAgentName.Text = ds.Tables[0].Rows[i]["Agent_Name"].ToString();
                //txtIATAComm.Text = ds.Tables[0].Rows[i]["IATA_Commission"].ToString();
                txtCreditLimit.Text = ds.Tables[0].Rows[i]["Credit_Limit"].ToString();
                //txtSurcharge.Text = ds.Tables[0].Rows[i]["Surcharge"].ToString();
                //txtTDSDeducSource.Text = ds.Tables[0].Rows[i]["TaxDeductiononSource"].ToString();
                //txtTDSExemLimit.Text = ds.Tables[0].Rows[i]["TDS_Exemption_Limit"].ToString();
                //if (showStatus() == "Active")
                //    ddlStatus.SelectedValue = "2";
                //else
                //    ddlStatus.SelectedValue = "5";
             }
        }
       catch(SqlException exec)
       {
           string err=exec.Message;
           lblMessage.Text = err;
           lblMessage.Visible = true;
       }
    }
    public void findSubAgentDetails()// Agent_Branch Details
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string str1 = Request.QueryString["Agent_ID"].ToString();
            string selectQ;
            selectQ = "select * from Agent_Branch where Agent_ID=@agent_Id";
            com = new SqlCommand(selectQ, con);
            com.Parameters.AddWithValue("@agent_Id", str1);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp = ds.Tables[0].Rows.Count;
            for (int i = 0; i < temp; i++)
            {
                city= ds.Tables[0].Rows[i]["Belongs_To_City"].ToString();
                txtCity.SelectedItem.Text=cityname();
                txtAddress.Text = ds.Tables[0].Rows[i]["Agent_Address"].ToString();
                txtFax.Text = ds.Tables[0].Rows[i]["Agent_Fax"].ToString();
                txtPhone.Text = ds.Tables[0].Rows[i]["Agent_Phone"].ToString();
                txtPanNo.Text = ds.Tables[0].Rows[i]["Pan_No"].ToString();
                txtConcernPerson.Text = ds.Tables[0].Rows[i]["Concerned_Person"].ToString();
                //txtContactPerson.Text = ds.Tables[0].Rows[i]["CSR_Contact_Person"].ToString();
                //txtCsrEmailID.Text = ds.Tables[0].Rows[i]["CSR_Email"].ToString();
                Agent_Branchid = ds.Tables[0].Rows[i]["Agent_Branch_ID"].ToString();
                if (showStatus() == "Active")
                    ddlStatus.SelectedValue = "2";
                else
                    ddlStatus.SelectedValue = "5";
            }
        }

        catch (SqlException esx)
        {
            string err = esx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
    }
    public void FindLoginDetails()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectLogin;
            selectLogin = "select * from Login_Master where Agent_ID=@Agentid";
            com = new SqlCommand(selectLogin, con);
            com.Parameters.AddWithValue("@Agentid", Agent_Branchid);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp = ds.Tables[0].Rows.Count;
            for (int i = 0; i < temp; i++)
            {
                txtLogin.Text = ds.Tables[0].Rows[i]["Email_ID"].ToString();
                txtPassword.Text = ds.Tables[0].Rows[i]["Login_Password"].ToString();
                //splitAirlineAccess();
            }
        }

        catch (SqlException esx)
        {
            string err = esx.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }

    }
    public string cityname()
    {
        string cityname;
        con=new SqlConnection(strCon);
        con.Open();
         com = new SqlCommand("select  (city_Code+'-'+City_Name) as City from City_Master where City_ID='" + city + "'",con);      
        cityname=com.ExecuteScalar().ToString();
        con.Close();
        return cityname;
    }

    public void splitAirlineAccess()
    {
        BindAirlineAccess();
        foreach (ListItem lt in CheckAirlineAccess.Items)
        {
            if (lt.Selected)
            {
                lt.Selected = false;
            }
        }
        string str ="";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string select = "select Airline_Access from Login_Master where Agent_ID=@airline";
            com = new SqlCommand(select, con);
            com.Parameters.AddWithValue("@airline", Agent_Branchid);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            int temp = ds.Tables[0].Rows.Count;
            for (int i = 0; i < temp; i++)
            {
                str = ds.Tables[0].Rows[i]["Airline_Access"].ToString();
            }
            com = new SqlCommand("select (Airline_Code+'-'+Airline_Name) as NameCode  From Airline_Master am inner join airline_detail ad on am.airline_id=ad.airline_id where Airline_detail_ID in(" + str + ")", con);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            //CheckAirlineAccess.DataSource = ds;
            //CheckAirlineAccess.DataTextField = "NameCode";
            //CheckAirlineAccess.DataValueField = "Airline_ID";
            //CheckAirlineAccess.DataBind();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                CheckAirlineAccess.Items[i].Selected = true;
            }
            com.Dispose();
           // string[] a = str.Split(',');
            //string str1 = string.Empty;
            //CheckBoxList lst = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");

            //for (int i = 0; i < lst.Items.Count; i++)
            //{
            //    for (int j = 0; j < a.Length; j++)
            //    {
            //        if (lst.Items[i].Value == a[j])
            //        {
            //            lst.Items[i].Selected = true;

            //        }
            //    }
            //}

            con.Close();
        }
        catch (SqlException exe)
        {
            string err1 = exe.Message;
            lblMessage.Text = err1;
            lblMessage.Visible = true;
        }
    }
    public string showStatus()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string str1 = Request.QueryString["Agent_ID"].ToString();
        //string str2 = Request.QueryString["Agent_Branch_ID"].ToString();
        com = new SqlCommand("select Status_Name from Status_Master where Status_ID=(Select Status From Agent_Branch Where Agent_ID='" + str1 + "')", con);
        string status= com.ExecuteScalar().ToString();
        con.Close();
        return status;
    }




    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (checkCityName())
        {
            int m = CheckAirlineAccess.Items.Count;
            for (int i = 0; i < m; i++)
            {
              CheckBoxList chk1 = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
                if (chk1.Items[i].Selected == false)
                {
                    lblMessage.Text = " Please Check at least One Airline Access";
                    lblMessage.Visible = true;

                }
                else
                {
                    UpdateData();
                    lblMessage.Text = "Record updated Successfuly";
                    lblMessage.Visible = true;
                }
            }
        }
        else 
        {
            lblMessage.Text = "Select Valid City Name";
            lblMessage.Visible = true;
        }
    }
    public void UpdateData()
    {
        
        con = new SqlConnection(strCon);
        con.Open();
        string strAgent_id = Request.QueryString["Agent_ID"].ToString();
        
        try
        {
           
            trans = con.BeginTransaction();
           // check Agent Name in Update case
            com = new SqlCommand("select Agent_Name from Agent_Master where  Agent_Id=@Agent_Id", con, trans);
            com.Parameters.AddWithValue("@Agent_Id",strAgent_id);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count <= 1)
            {
                string updateQ;
                updateQ = "update Agent_Master set Agent_Name=@agent_Name,Credit_Limit=@creditlimit where Agent_ID=@agentid ";
                com = new SqlCommand(updateQ, con, trans);
                com.Parameters.AddWithValue("@agent_Name", txtSubAgentName.Text.Replace("'", "`"));
                //com.Parameters.AddWithValue("@iataCode", txtIATACode.Text);
                //com.Parameters.AddWithValue("@iata_Comm", txtIATAComm.Text);
                //com.Parameters.AddWithValue("@taxDeduc", txtTDSDeducSource.Text);
                //com.Parameters.AddWithValue("@TDSlimit", txtTDSExemLimit.Text);
                com.Parameters.AddWithValue("@creditlimit", txtCreditLimit.Text);
                //com.Parameters.AddWithValue("@surCharge", txtSurcharge.Text);
                //com.Parameters.AddWithValue("@status", ddlStatus.Text);
                com.Parameters.AddWithValue("@agentid", strAgent_id);
                com.ExecuteNonQuery();

            }
            else
            {
                lblMessage.Text = "Sub Agent Name Already Exist.";
                lblMessage.Visible = true;
            }
           
           
            
                // Agent_branch

           

                com = new SqlCommand("select Agent_Branch_ID from Agent_Branch where Agent_Id=@agentid", con, trans);
                com.Parameters.AddWithValue("@agentid", strAgent_id);
                string str2 = com.ExecuteScalar().ToString();
                //***

                // Find City name
                string citycode = txtCity.SelectedItem.Text;
                int m = citycode.IndexOf("-") + 1;           
                citycode = citycode.Substring(0, m - 1);
                com = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con, trans);
                SqlDataReader dr1 = com.ExecuteReader();
                while (dr1.Read())
                {
                    CityId = Convert.ToInt32(dr1["City_ID"].ToString());
                }
                dr1.Close();

                //*** 

       
       string update2 = "update Agent_Branch set Agent_Address=@Agent_Address,Belongs_To_City=@Belongs_To_City,Agent_Phone=@Agent_Phone,Agent_Fax=@AgentFax,Concerned_Person=@Concerned_Person,Pan_No=@panno,Status=@Status where Agent_Branch_ID=@agentBranchid";
                com = new SqlCommand(update2, con, trans);
                com.Parameters.AddWithValue("@agentBranchid", str2);
                com.Parameters.AddWithValue("@Belongs_To_City", CityId);
                com.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
                com.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
                com.Parameters.AddWithValue("@AgentFax", txtFax.Text);
                //com.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
                com.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
                //com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                //com.Parameters.AddWithValue("@CSREmail", txtCsrEmailID.Text);
                com.Parameters.AddWithValue("@panno", txtPanNo.Text);
                com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);

                com.ExecuteNonQuery();
            
            //***

            for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // values store in listbox
            {
                if (CheckAirlineAccess.Items[i].Selected)
                {

                    ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
                }
            }
            ts1 = ts1.Remove(ts1.LastIndexOf(","));

            //**
            com = new SqlCommand("select Login_Master_ID from  Login_Master where Agent_ID='" + str2 + "'", con, trans);
            string loginMasterid = com.ExecuteScalar().ToString();

            //**         
            string updateQ3;
            updateQ3 = "update Login_Master set Login_Password=@login_Password, Airline_Access=@airline_Access,Group_ID=@Group_ID where Login_Master_ID=@loginMasterid";
            com = new SqlCommand(updateQ3, con, trans);
            com.Parameters.AddWithValue("@login_Password",txtPassword.Text);
            com.Parameters.AddWithValue("@airline_Access",ts1);
            com.Parameters.AddWithValue("@Group_ID",ddlGroupName.SelectedValue);
            com.Parameters.AddWithValue("@loginMasterid", loginMasterid);
            com.ExecuteNonQuery();

            // insert Agent History
            com = new SqlCommand("select Agent_Name from Agent_Master where Agent_ID='" + strAgent_id + "'", con, trans);
            string agentName1 = com.ExecuteScalar().ToString();
            //****
          com = new SqlCommand("select Status_Name from Status_Master where Status_ID=18",con,trans);
          string selectBranchStatus = com.ExecuteScalar().ToString(); ;

            //****
          string insertQ1 = "insert into dbo.Agent_History(Agent_Code,Login_ID,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,Credit_Limit,Parent_Name,Branch_Status,Pan_No,Status,Entered_By,Entered_On)values(@Agent_Code,@Login_ID,@Login_Password,@Group_Name,@Airline_Access,@Belongs_To_City,@Agent_Name,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@Credit_Limit,@Parent_Name,@Branch_Status,@Pan_No,@Status,@Entered_By,@Entered_On)";

            // select Agent_Code

            com = new SqlCommand("select Agent_Code from Agent_Master where Agent_ID=@id", con, trans);

            com.Parameters.AddWithValue("@id", strAgent_id);
            string id = com.ExecuteScalar().ToString();
            //******
            com = new SqlCommand(insertQ1, con, trans);
            com.Parameters.AddWithValue("@Agent_Code", id);
            com.Parameters.AddWithValue("@Login_ID",txtLogin.Text);
            com.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
            com.Parameters.AddWithValue("@Group_Name", ddlGroupName.SelectedItem.Text);
            com.Parameters.AddWithValue("@Airline_Access", ts1);
            com.Parameters.AddWithValue("@Belongs_To_City", FindCityName());
            com.Parameters.AddWithValue("@Agent_Name", txtSubAgentName.Text);
            com.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
            com.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
            com.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
            com.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
            com.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
            //com.Parameters.AddWithValue("@IATA_Code", txtIATACode.Text);
            //com.Parameters.AddWithValue("@IATA_Commission", txtIATAComm.Text);
            //com.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
            //com.Parameters.AddWithValue("@TDS_Exemption_Limit", txtCreditLimit.Text);
            com.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
            com.Parameters.AddWithValue("@Parent_Name",agentName1);
            com.Parameters.AddWithValue("@Branch_Status", selectBranchStatus);
            //com.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
            //com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
            //com.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
            com.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
            com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Text);
            com.Parameters.AddWithValue("@Entered_By", loginid);
            com.Parameters.AddWithValue("@Entered_On", TodayDate);
            com.ExecuteNonQuery();
            trans.Commit();
            con.Close();
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.Message;
            trans.Rollback();
            lblMessage.Text = err;
            lblMessage.Visible = true;
            
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Response.Redirect("ViewSubAgents.aspx");


    }
    //protected void btnUpdateAdmin_Click(object sender, EventArgs e)
    //{
    //    //UpdateByAdmin();
    //    lblMessage.Text = "Record Updated Successfully";
    //    lblMessage.Visible = true;
    //}

    //******************** update data by admin

    //public void UpdateByAdmin()
    //{

    //    con = new SqlConnection(strCon);
    //    con.Open();
    //    string strAgent_id = Request.QueryString["Agent_ID"].ToString();
    //    try
    //    {
    //        string updateQ;
    //        trans = con.BeginTransaction();
    //        updateQ = "update Agent_Master set Agent_Name=@agent_Name,IATA_Commission=@iata_Comm,IATA_Code=@iataCode,TaxDeductiononSource=@taxDeduc,TDS_Exemption_Limit=@TDSlimit,Credit_Limit=@creditlimit,SurCharge=@surCharge,Status=@status where Agent_ID=@agentid ";
    //        com = new SqlCommand(updateQ, con, trans);
    //        com.Parameters.AddWithValue("@agent_Name", txtSubAgentName.Text);
    //        com.Parameters.AddWithValue("@iataCode", txtIATACode.Text);
    //        com.Parameters.AddWithValue("@iata_Comm", txtIATAComm.Text);
    //        com.Parameters.AddWithValue("@taxDeduc", txtTDSDeducSource.Text);
    //        com.Parameters.AddWithValue("@TDSlimit", txtTDSExemLimit.Text);
    //        com.Parameters.AddWithValue("@creditlimit", txtCreditLimit.Text);
    //        com.Parameters.AddWithValue("@surCharge", txtSurcharge.Text);
    //        com.Parameters.AddWithValue("@status", ddlStatus.SelectedItem.Text);
    //        com.Parameters.AddWithValue("@agentid", strAgent_id);
    //        com.ExecuteNonQuery();

    //        //string updateQ2;
    //        //updateQ2 = "";


    //        string update2 = "update Agent_Branch set Agent_Address=@Agent_Address,Belongs_To_City=@Belongs_To_City,Agent_Phone=@Agent_Phone,Agent_Fax=@AgentFax,Concerned_Person=@Concerned_Person,CSR_Contact_Person=@CSR_Contact_Person,CSR_Email=@CSREmail,Pan_No=@panno where Agent_Branch_ID=@agentBranchid";

    //        // Agent_branch

    //        com = new SqlCommand("select Agent_Branch_ID from Agent_Branch where Agent_Id=@agentid", con, trans);
    //        com.Parameters.AddWithValue("@agentid", strAgent_id);
    //        string str2 = com.ExecuteScalar().ToString();
    //        //***

    //        // Find City name
    //        string citycode = txtCity.Text;
    //        int m = citycode.IndexOf("-") + 1;
    //        citycode = citycode.Substring(0, m - 1);
    //        com = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con, trans);
    //        SqlDataReader dr1 = com.ExecuteReader();
    //        while (dr1.Read())
    //        {
    //            CityId = Convert.ToInt32(dr1["City_ID"].ToString());
    //        }
    //        dr1.Close();
    //        //***
    //        com = new SqlCommand(update2, con, trans);
    //        com.Parameters.AddWithValue("@agentBranchid", str2);
    //        com.Parameters.AddWithValue("@Belongs_To_City", CityId);
    //        com.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
    //        com.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
    //        com.Parameters.AddWithValue("@AgentFax", txtFax.Text);
    //        //com.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
    //        com.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
    //        com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
    //        com.Parameters.AddWithValue("@CSREmail", txtCsrEmailID.Text);
    //        com.Parameters.AddWithValue("@panno", txtPanNo.Text);

    //        com.ExecuteNonQuery();
    //        //***

    //        for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // values store in listbox
    //        {
    //            if (CheckAirlineAccess.Items[i].Selected)
    //            {

    //                ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
    //            }
    //        }

    //        //**
    //        com = new SqlCommand("select Login_Master_ID from  Login_Master where Agent_ID='" + str2 + "'", con, trans);
    //        string loginMasterid = com.ExecuteScalar().ToString();
    //        //**

    //        string updateQ3;
    //        updateQ3 = "update Login_Master set Login_Password=@login_Password, Airline_Access=@airline_Access where Login_Master_ID=@loginMasterid";


    //        com = new SqlCommand(updateQ3, con, trans);
    //        com.Parameters.AddWithValue("@login_Password", txtPassword.Text);
    //        com.Parameters.AddWithValue("@airline_Access", ts1);
    //        com.Parameters.AddWithValue("@loginMasterid", loginMasterid);
    //        com.ExecuteNonQuery();

    //        // insert

    //        string insertQ1 = "insert into dbo.Agent_History(Agent_Code,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,IATA_Code,IATA_Commission,TaxDeductiononSource,TDS_Exemption_Limit,Credit_Limit,SurCharge,CSR_Contact_Person,CSR_Email,Pan_No,Status,Entered_By,Entered_On)values(@Agent_Code,@Login_Password,@Group_Name,@Airline_Access,@Belongs_To_City,@Agent_Name,@Agent_Address,@Agent_Phone,@Agent_Fax,@Agent_Email,@Concerned_Person,@IATA_Code,@IATA_Commission,@TaxDeductiononSource,@TDS_Exemption_Limit,@Credit_Limit,@SurCharge,@CSR_Contact_Person,@CSR_Email,@Pan_No,@Status,@Entered_By,@Entered_On)";

    //        // select Agent_Code

    //        com = new SqlCommand("select Agent_Code from Agent_Master where Agent_ID=@id", con, trans);

    //        com.Parameters.AddWithValue("@id", strAgent_id);
    //        string id = com.ExecuteScalar().ToString();

    //        //for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // values store in listbox
    //        //{
    //        //    if (CheckAirlineAccess.Items[i].Selected)
    //        //    {

    //        //        ts2 = ts2 + CheckAirlineAccess.Items[i].Value + ",";
    //        //    }
    //        //}

    //        com = new SqlCommand(insertQ1, con, trans);
    //        com.Parameters.AddWithValue("@Agent_Code", id);
    //        com.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
    //        com.Parameters.AddWithValue("@Group_Name", ddlGroupName.SelectedItem.Text);
    //        com.Parameters.AddWithValue("@Airline_Access", ts1);
    //        com.Parameters.AddWithValue("@Belongs_To_City", FindCityName());
    //        com.Parameters.AddWithValue("@Agent_Name", txtSubAgentName.Text);
    //        com.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
    //        com.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
    //        com.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
    //        com.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
    //        com.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
    //        com.Parameters.AddWithValue("@IATA_Code", txtIATACode.Text);
    //        com.Parameters.AddWithValue("@IATA_Commission", txtIATAComm.Text);
    //        com.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
    //        com.Parameters.AddWithValue("@TDS_Exemption_Limit", txtCreditLimit.Text);
    //        com.Parameters.AddWithValue("@Credit_Limit", txtTDSExemLimit.Text);
    //        com.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text);
    //        com.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
    //        com.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
    //        com.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
    //        com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
    //        com.Parameters.AddWithValue("@Entered_By", loginid);
    //        com.Parameters.AddWithValue("@Entered_On", TodayDate);
    //        com.ExecuteNonQuery();
    //        trans.Commit();
    //        con.Close();
    //    }
    //    catch (SqlException sqlex)
    //    {
    //        string err = sqlex.ToString();
    //        trans.Rollback();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }


    //}
    public void showSubagentByAdmin()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            strAgentID = Request.QueryString["Agent_ID"].ToString();
            com = new SqlCommand("select Agent_Name from Agent_Master where Agent_ID='" + strAgentID + "'", con);
            string nameagent = com.ExecuteScalar().ToString();
            txtAgentName.Text = nameagent;
            btnUpdate.Visible = true;
            // btnUpdateAdmin.Visible = true;
            tabAddSubAgent.Visible = true;
            con.Close();
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
    }

    protected void txtCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAirlineAccess();           
    }
    
    protected void btn_Click1(object sender, EventArgs e)
    {
        Response.Redirect("ViewSubAgents.aspx");
    }
    
}
