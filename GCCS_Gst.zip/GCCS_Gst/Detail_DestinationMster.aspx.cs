using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Destination_Mster : System.Web.UI.Page
{    
    // this form has disign by praveen singh
    // this form has coded by praveen singh
    SqlConnection cn=new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString);
    SqlCommand cmd;
    SqlDataReader red;
    SqlDataAdapter adp;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            try
            {

                search();
            }
            catch (Exception)
            {

            }
        }
    }
    protected void grddestination_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    public void search()
    {
        string strq="";
        if (txtsearch.Text == "")
        {
            strq = "select * from Destination_master order by Destination_Code";
        }
        else
        {
            if (ddlsearch.SelectedValue == "0")
            {
                strq = "select * from Destination_Master where Destination_Name like '" + txtsearch.Text + "%' order by Destination_Code";
            }
            if (ddlsearch.SelectedValue == "1")
            {
                strq = "select * from Destination_Master where Destination_Code like '" + txtsearch.Text + "%' order by Destination_Code";
            }
            if (ddlsearch.SelectedValue == "2")
            {
                strq = "select * from Destination_Master where Country_Code like '" + txtsearch.Text + "%' order by Destination_Code";
            }
        }
        cmd = new SqlCommand(strq, cn);
        adp = new SqlDataAdapter(cmd);
        ds = new DataSet();
        adp.Fill(ds);
        grddestination.DataSource = ds;
        grddestination.DataBind();
        Session["ds"] = ds;
    }
   
    public void modify(object sender, CommandEventArgs e)
    {
        //
        Response.Redirect("Destinationmaster.aspx?Destination_ID=" + e.CommandArgument + "&action=e");
    }
    protected void lnkbutton_Click(object sender, EventArgs e)
    {
        Response.Redirect("DestinationMaster.aspx");
    }
    protected void grddestination_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
    protected void grddestination_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        grddestination.PageIndex = e.NewPageIndex;
        grddestination.DataSource = ds;
        grddestination.DataBind();
    }
}
