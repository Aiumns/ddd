using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//************************************************
// Created By ---------- Rajesh Parbat
// Date       ---------- 18/11/2007
//************************************************
public partial class _Default : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            FillGV();
        } 
    }

    void FillGV()
    {
        string Query = null;
        con = new SqlConnection(strCon);
        if (txtSearch.Text == "")
        {
            Query = "select * from Booking_AWB_History";

        }
        else
        { 
        Query = "select * from Booking_AWB_History where AirWayBill_No like'"+txtSearch.Text+"%'";
        //txtSearch.Text = "";
        }
         SqlCommand com = new SqlCommand(Query, con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        FillGV();
    }
}
