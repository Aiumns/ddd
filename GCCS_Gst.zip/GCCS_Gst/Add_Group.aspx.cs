using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Add_Group : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com,com1,com2;
    DataSet ds;
    SqlDataReader dr;
    DisplayWrap dw=new DisplayWrap();
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        
    }


    protected void btnADD_Click(object sender, EventArgs e)
    {
       addgroup();
    }
    public void addgroup()
    {
        TextBox txtid = new TextBox();
        txtid.Text = "7,48";
        string grpnm = txtGroupName.Text;
        con = new SqlConnection(strcon);
        con.Open();
        try
        {
            com = new SqlCommand("Select Group_Name,Group_Type from Group_Master where Group_Name='" + txtGroupName.Text.Trim() + "'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader(CommandBehavior.CloseConnection);
            if (dr.Read())
            {
                lblmsg.Visible = true;
            }

            else
            {
                lblmsg.Visible = false; ;

                dr.Close();
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                   
                   // string str = "7,48";
                    string strcom = "insert into Group_Master(Group_Name,Mainmenu_Rights,Group_Type) values(' " + txtGroupName.Text.Trim() + "',  '" + txtid.Text + "' ,'" + ddlGroupType.SelectedItem.Text + "')";


                    com1 = new SqlCommand(strcom, con);
                    com1.ExecuteNonQuery();
                }
                con.Close();
                Response.Redirect("Groups.aspx");
              
            }
        }
        catch (Exception ex)
        {
            Label label54 = new Label();
            label54.Text = ex.Message;

        }
        DataTable dtGroupID = dw.GetAllFromQuery("select ident_current('Group_Master') as GroupID");

                string Group_ID = dtGroupID.Rows[0]["GroupID"].ToString();
               // Response.Redirect("MenuRights.aspx?DATA=" + Group_ID);

                Response.Redirect("MenuRights.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("id", Group_ID)));
    }

}
