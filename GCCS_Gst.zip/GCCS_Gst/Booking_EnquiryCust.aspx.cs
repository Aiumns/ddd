using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Booking_EnquiryCust : System.Web.UI.Page
{

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    Int16 SRno;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader red;
    SqlTransaction trans = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        rem.Visible = false;
        remText.Visible = false;
        assignawb.Visible = false;
        assignAwbtext.Visible = false;
        tdsubmit.Visible = false;
        tdcancel.Visible = false;
        
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
          
        else if (!IsPostBack && Request.QueryString["sno"].ToString()!="")
        {
            btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");
            
            SRno = Int16.Parse(Request.QueryString["sno"].ToString());
            DataTable dt_agent = dw.GetAllFromQuery("SELECT Ag.Agent_name as Agent_name,Ag.Agent_ID as Agent_ID,AD.Belongs_to_city as Belongs_to_city,Cm.City_code as city_code,BE.Airline_Detail_Id as Airline_Detail_Id,AM.Airline_name as Airline_name,AM.airline_code as airline_code,BE.Dest_code as dest_code,BE.Gross_Weight as Gross_Weight,BE.Volume_Weight,BE.No_of_Packages as No_of_Packages,BE.Commodity as Commodity,convert(varchar,BE.Handover_date,103) as Handover_date,BE.Remarks as Remarks,CM.city_id as city_id FROM Booking_Enquiry BE Inner join Airline_Detail AD on AD.Airline_detail_id=BE.Airline_Detail_ID inner join Airline_Master AM on Am.Airline_ID=AD.Airline_ID inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join City_Master CM on CM.city_id=AD.Belongs_to_city where Booking_EnquiryNo=" + SRno + "");
            if (dt_agent.Rows.Count > 0)
            {
                lblAgent.Text = dt_agent.Rows[0]["Agent_name"].ToString();
                ViewState["Agent_ID"] = dt_agent.Rows[0]["Agent_ID"].ToString();
                lblAirlinename.Text = dt_agent.Rows[0]["Airline_Name"].ToString();
                lblCityCode.Text = dt_agent.Rows[0]["city_code"].ToString();
                lblDestCode.Text = dt_agent.Rows[0]["Dest_code"].ToString();
                lblGrwT.Text = dt_agent.Rows[0]["Gross_Weight"].ToString();
                lblVolWt.Text = dt_agent.Rows[0]["Volume_Weight"].ToString();
                lblPcs.Text = dt_agent.Rows[0]["No_of_Packages"].ToString();
                lblComm.Text = dt_agent.Rows[0]["Commodity"].ToString();
                lblHandDate.Text = dt_agent.Rows[0]["Handover_date"].ToString();
                lblRemarks.Text = dt_agent.Rows[0]["Remarks"].ToString();
                ViewState["airline_code"] = dt_agent.Rows[0]["Airline_code"].ToString();
                ViewState["CtID"] = dt_agent.Rows[0]["city_id"].ToString();

            }
            FillAWB();
 
        }


    }
    public void FillAWB()
    {
        con = new SqlConnection(strCon);
        ////cmd = new SqlCommand("select * from stock_master where status=8 and Neutral='Y' and substring(Airwaybill_no,1,3)='" + ViewState["airline_code"].ToString() + "'", con);
        cmd = new SqlCommand("select * from stock_master where status=8 and Neutral='Y' and agent_id is null and substring(Airwaybill_no,1,3)='" + ViewState["airline_code"].ToString() + "' and city_id='" + ViewState["CtID"].ToString() + "'", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlAsignAWB.DataSource = red;
        ddlAsignAWB.DataTextField = "Airwaybill_no";
        ddlAsignAWB.DataValueField = "Stock_ID";
        ddlAsignAWB.DataBind();
        con.Close();
        cmd.Dispose();
        ddlAsignAWB.Items.Insert(0, new ListItem("Select AWBNO", "-1"));
    }

    protected void rdbtnList_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rdbtnList.SelectedItem.Value == "I")
        {
            rem.Visible = true;
            remText.Visible = true;
            assignawb.Visible = true;
            assignAwbtext.Visible = true;
            tdsubmit.Visible = true;
            tdcancel.Visible = true;
        }
        else if (rdbtnList.SelectedItem.Value == "C")
        {
            rem.Visible = true;
            remText.Visible = true;
            tdsubmit.Visible = true;
            tdcancel.Visible = true;
        }
        else
        {
            rem.Visible = false;
            remText.Visible = false;
            assignawb.Visible = false;
            assignAwbtext.Visible = false;
            tdsubmit.Visible = false;
            tdcancel.Visible = false;
 
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Booking_EnquiryDetails.aspx");
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");
        if (rdbtnList.SelectedItem.Value == "I")
        {
            con = new SqlConnection(strCon);
                try
                    {
                        con.Open();
                        trans = con.BeginTransaction();  // Insert Value in Booking Enquiry table
                        string strupdate1 = "update Booking_Enquiry  set CCRemarks='" + txtRemarks.Text + "',awb_no='" + ddlAsignAWB.SelectedItem.Text + "',Status='I',updated_by='" + Session["EMailID"].ToString() + "',updated_at='" + DateTime.Now + "' where Booking_EnquiryNo='"+Request.QueryString["sno"].ToString()+"'";
                        cmd = new SqlCommand(strupdate1, con, trans);
                        cmd.ExecuteNonQuery();

                        // Update Stock Master
                        string up1 = "update  Stock_Master set status='16',Neutral='Y',Agent_id='" + ViewState["Agent_ID"] + "' where Stock_ID='" + ddlAsignAWB.SelectedItem.Value + "'"; ;
                        cmd = new SqlCommand(up1, con, trans);
                        cmd.ExecuteNonQuery();
                        trans.Commit();
                        con.Close();
                        Response.Redirect("Booking_EnquiryDetails.aspx");
                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;
                       
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    }
        }
        else if (rdbtnList.SelectedItem.Value == "C")
        {
            con = new SqlConnection(strCon);
            try
            {
                con.Open();
                trans = con.BeginTransaction();  // Insert Value in Booking Enquiry table
                string strupdate1 = "update Booking_Enquiry  set CCRemarks='" + txtRemarks.Text + "',Status='C',updated_by='" + Session["EMailID"].ToString() + "',updated_at='" + DateTime.Now + "'  where Booking_EnquiryNo='"+Request.QueryString["sno"].ToString()+"'";
                cmd = new SqlCommand(strupdate1, con, trans);
                cmd.ExecuteNonQuery();
                Response.Redirect("Booking_EnquiryDetails.aspx");
            }
            catch (SqlException se)
            {
                string err = se.Message;
                trans.Rollback();
          
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
}
