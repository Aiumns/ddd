using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
///This Page is Design & Coding By Alok Date:01.02.2008
/// Last Modified By Alok Date:08.02.2008
/// </summary>

public partial class Booking_Details : System.Web.UI.Page
{
    //Declare Public Variables here
    SqlConnection con = null;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null;
    string sort = null;
    string groupId = null;
    string agent_branch_id = null;
    //Make connection from web.config
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        else
        {
            groupId = Session["groupid"].ToString();
            agent_branch_id = Session["ID"].ToString();
            if (!IsPostBack && Request.QueryString["id"] != null)
            {
                    lblmsg.Visible = true;
                    lblmsg.Text = " AirWayBill No '" + Request.QueryString["id"] + "' Has been Cancelled (No Show SuccessFully) ";
                    if (ddl.SelectedValue == "1")
                    {
                        txtsearch.Text = "";
                    }
                    else if (Request.QueryString["awb_no"] != null)
                    {
                        sort = "sm.AirWayBill_No";
                    }
                    else if (Request.QueryString["agent"] != null)
                    {
                        sort = "am.Agent_Name";
                    }
                    else if (Request.QueryString["flt"] != null)
                    {
                        sort = "fm.Flight_No";
                    }
                    else if (Request.QueryString["fltd"] != null)
                    {
                        sort = "bm.Flight_Date";
                    }
                    //else if (Request.QueryString["org"] != null)
                    //{
                    //    sort = "f.City_code";
                    //}
                    else if (Request.QueryString["dst"] != null)
                    {
                        sort = "dm.Destination_Code";
                    }
                    else
                    {
                        sort = "bm.Flight_Date,fm.Flight_No,am.Agent_Name";
                    }

                  //  htmlTableSimple();
                }
                else if (!IsPostBack && Request.QueryString["id1"] != null)
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = " AirWayBill No '" + Request.QueryString["id1"] + "' Has been Cancelled (Void SuccessFully) ";
                   
                    if (ddl.SelectedValue == "1")
                    {
                        txtsearch.Text = "";
                    }
                    else if (Request.QueryString["awb_no"] != null)
                    {
                        sort = "sm.AirWayBill_No";
                    }
                    else if (Request.QueryString["agent"] != null)
                    {
                        sort = "am.Agent_Name";
                    }
                    else if (Request.QueryString["flt"] != null)
                    {
                        sort = "fm.Flight_No";
                    }
                    else if (Request.QueryString["fltd"] != null)
                    {
                        sort = "bm.Flight_Date";
                    }
                    //else if (Request.QueryString["org"] != null)
                    //{
                    //    sort = "f.City_code";
                    //}
                    else if (Request.QueryString["dst"] != null)
                    {
                        sort = "dm.Destination_Code";
                    }
                    else
                    {
                        sort = "bm.Flight_Date,fm.Flight_No,am.Agent_Name";
                    }
                  //  htmlTableSimple();
                }
               
              else if (groupId == "5")
                {
                    if (Request.QueryString["awb_no"] != null)
                    {
                        sort = "sm.AirWayBill_No";
                    }
                    else if (Request.QueryString["agent"] != null)
                    {
                        sort = "am.Agent_Name";
                    }
                    else if (Request.QueryString["flt"] != null)
                    {
                        sort = "fm.Flight_No";
                    }
                    else if (Request.QueryString["fltd"] != null)
                    {
                        sort = "bm.Flight_Date";
                    }
                    //else if (Request.QueryString["org"] != null)
                    //{
                    //    sort = "f.City_code";
                    //}
                    else if (Request.QueryString["dst"] != null)
                    {
                        sort = "dm.Destination_Code";
                    }
                    else
                    {
                        sort = "bm.Flight_Date,fm.Flight_No,am.Agent_Name";
                    }
                lblsearch.Visible = false;
                ddl.Visible = false;
                txtsearch.Visible = false;
                btnsearch.Visible = false;
                lblmsg.Visible = false;
             //   htmlTableAgent();
                //GridView1.DataSource = null;
                //GridView1.DataBind();


            }
            else
            {
                lblmsg.Visible = false;

                if (ddl.SelectedValue == "1")
                {
                    txtsearch.Text = "";
                }
                else if (Request.QueryString["awb_no"] != null)
                {
                    sort = "sm.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "am.Agent_Name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "fm.Flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "bm.Flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "dm.Destination_Code";
                }
                else
                {
                    sort = "bm.Flight_Date,fm.Flight_No,am.Agent_Name";
                }
                
              //  htmlTableSimple();
                                 
                //GridView1.DataSource = null;
                //GridView1.DataBind();
            }
        }
    }
    public string Rights()
    { 
        string Access = "";
        try
        {
            string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


            con = new SqlConnection(strCon);
            con.Open();
           
            SqlCommand cmd = new SqlCommand(sql_Access, con);

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Access = dr["Airline_Access"].ToString();
                }

            }
            dr.Dispose();
            con.Close();
            cmd.Dispose();
            
        }
        catch (Exception ee)
        {
            ee.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
        return Access;
       
    }
    public void htmlTableAgent()
    {


        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
              
                //table Row Create daynamically.
                com = new SqlCommand("SELECT ab.Agent_Branch_ID, bm.Booking_ID as 'Booking_ID',sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm  ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID inner join Agent_Branch ab on am.Agent_ID =ab.Agent_ID where  ab.Agent_Branch_ID='" + agent_branch_id + "' and ((bm.Status=9 or bm.Status=3)AND sm.Status=9) and  ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' order by  " + sort + "", con);
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td align=""center"" nowrap>Booking</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?awb_no=awb_no'>Awb No.</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?agent=agent'>Agent Name</a></td><td  align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?flt=flt'>Flight No</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?fltd=fltd'>Flight Date</a></td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?dst=dst'>Dstn</a></td><td align=""center"" nowrap>Pcs.</td><td align=""center"" nowrap>Gwt.</td><td align=""center"" nowrap>Chg Wt.</td></tr>
";
                    while (dr1.Read())
                    {
                        table += @"<tr><td align=left class=boldtext><a href=BookingEdit.aspx?Booking_ID=" + dr1["Booking_ID"].ToString() + " class=boldtext>Edit</a></td><td align=left nowrap class=text>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["agent_name"].ToString() + @"</td><td align=""left"" nowrap class=text>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_Date"].ToString() + @"</td><td align=""left"" class=text>" + dr1["city_code"].ToString() + @"</td><td align=""left"" class=text>" + dr1["destination_code"].ToString() + @"</td><td align=""right"" class=text>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""right"" class=text>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""right"" class=text>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";
                    }
                }
                else
                {
                    //table += @"<table table width=""100%"" id=""Table1"" border=""0"">";
                    
                }

                //table += @"<tr></tr></table>";
                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public void htmlTableSimple()
    {
        int flag = 0;
            //data3();
            try
            {
                // table header create
                string strAirline_Access = Rights();
                con = new SqlConnection(strCon);
                con.Open();

                com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

                int ip = 1;
                SqlDataAdapter da = new SqlDataAdapter(com);
                DataSet ds = new DataSet();
                da.Fill(ds);

                foreach (DataRow drx in ds.Tables[0].Rows)
                {
                    //table Row Create daynamically.
                    if (txtsearch.Text == "" && txtdate.Text =="" )
                    {

                        com = new SqlCommand("SELECT  bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where ((bm.Status=9 or bm.Status=3)AND sm.Status=9) and  ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' order by " + sort + " ", con);

                    }
                    else
                    {

                        if (ddl.SelectedValue == "0")
                        {
                            txtdate.Text = "";
                            com = new SqlCommand("SELECT  bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where ((bm.Status=9 or bm.Status=3)AND sm.Status=9) and  ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' and fm.Flight_No like " + "'" + txtsearch.Text + "%'  order by " + sort + "", con);
                        }
                        if (ddl.SelectedValue == "2")
                        {
                            txtdate.Text = "";
                            com = new SqlCommand("SELECT  bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where ((bm.Status=9 or bm.Status=3)AND sm.Status=9) and  ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' and sm.AirWayBill_No like " + "'%" + txtsearch.Text + "%'  order by " + sort + "", con);

                        }
                        if (ddl.SelectedValue == "3")
                        {
                            txtdate.Text = "";
                            com = new SqlCommand("SELECT  bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where ((bm.Status=9 or bm.Status=3)AND sm.Status=9) and  ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' and am.Agent_Name like " + "'" + txtsearch.Text + "%' order by " + sort + "", con);

                        }
                        if (ddl.SelectedValue == "4")
                        {

                            com = new SqlCommand("SELECT  bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where ((bm.Status=9 or bm.Status=3)AND sm.Status=9) and  ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' and cm.City_Name like " + "'" + txtsearch.Text + "%'  order by " + sort + "", con);

                        }

                        if (ddl.SelectedValue == "1")
                        {
                            pnldate.Visible = true;
                            string strdate = null;
                            txtsearch.Visible = false;
                            try
                            {
                                if (txtdate.Text != null)
                                {
                                    strdate = FormatDateMM(txtdate.Text);
                                }
                                else
                                {

                                }
                            }
                            catch(Exception)
                            {

                            }

                            com = new SqlCommand("SELECT  bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where ((bm.Status=9 or bm.Status=3)AND sm.Status=9) and  ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' and bm.Flight_Date=" + "'" + strdate + "'  order by " + sort + "", con);

                        }
                    }

                    SqlDataReader dr1 = com.ExecuteReader();
                    
                    if (dr1.HasRows)
                    {
                        table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td align=""center"" nowrap >Booking</td><td align=""center"" nowrap>Handover</td><td align=""center"" nowrap>NoShow</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?awb_no=awb_no'>Awb No.</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?agent=agent'>Agent Name</a></td><td  align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?flt=flt'>Flight No</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?fltd=fltd'>Flight Date</a></td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='booking_details.aspx?dst=dst'>Dstn</a></td><td align=""center"" nowrap>Pcs.</td><td align=""center"" nowrap>Gwt.</td><td align=""center"" nowrap>Chg Wt.</td></tr>
";
                        while (dr1.Read())
                        {

                            string url_noshow = "Booking_NoShow.aspx?Airwaybill_no=" + dr1["Airwaybill_no"] + "&amp;Booking_id=" + dr1["Booking_id"];
                            //string url_void = "Booking_Void.aspx?Airwaybill_no=" + dr1["Airwaybill_no"] + "&amp;Booking_id=" + dr1["Booking_id"];
                            table += @"<tr><td align=left class=boldtext><a href=BookingEdit.aspx?Booking_ID=" + dr1["Booking_ID"].ToString() + " class=boldtext>Edit</a></td><td align=left class=boldtext><a href=Handover_New.aspx?Booking_ID=" + dr1["Booking_ID"].ToString() + " class=boldtext>Handover</a></td><td align=left class=boldtext><a href=" + url_noshow + " class=boldtext>NoShow</a></td><td align=left nowrap class=text>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left"" class=text >" + dr1["agent_name"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_Date"].ToString() + @"</td><td align=""left"" class=text>" + dr1["city_code"].ToString() + @"</td><td align=""right"" class=text>" + dr1["destination_code"].ToString() + @"</td><td align=""right"" class=text>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""right"" class=text>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""right"" class=text>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";
                            flag = 1;

                        }
                    }
                    else
                    {
                        if (flag == 0)
                        {
                            //table += @"<table table width=""100%"" id=""Table1"" border=""0""><tr><td>No Record Found !!!</td></tr>";
                            Label4.Visible = true;
                        }
                        else
                        {
                            Label4.Visible = false;
                            flag = 1;
                        }
                        
                       
                    }

                    //table += @"<tr></tr></table>";
                    dr1.Close();
                    ip = ip + 1;
                }
                table += @"</table>";
                Label1.Text = table;

              
            }
            catch (SqlException ex)
            {
                string strer = ex.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            }
        
    }
    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Booking_New.aspx");
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddl.SelectedValue == "1")
        {
            txtsearch.Text = "";
            pnldate.Visible = true;
            txtsearch.Visible = false;
        }
        else
        {
            txtdate.Text = "";
            pnldate.Visible = false;
            txtsearch.Visible = true; ;
        }
    }

    protected void btnsearch_Click1(object sender, EventArgs e)
    {
        //lblmsg.Visible = false;

        //if (ddl.SelectedValue == "1")
        //{
        //    txtsearch.Text = "";
        //}

        htmlTableSimple();
    }
}
