using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;



public partial class Default6 : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string login_id;
    string table = null;
    string sort = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    bool flag = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            login_id = Session["EMailID"].ToString();
            if (!IsPostBack && Request.QueryString["id"] != null &&( Session["groupid"].ToString() == "1" || Session["groupid"].ToString() == "13" || Session["groupid"].ToString() == "73" || Session["groupid"].ToString() == "58"))
            {
                lblmsg.Visible = true;
                lblmsg.Text = " AirWayBill No '" + Request.QueryString["id"] + "' has been  Added to Sales ";
               // htmlTableBoth();
            }

           else if (Session["groupid"].ToString() == "1" || Session["groupid"].ToString() == "13" || Session["groupid"].ToString() == "73" || Session["groupid"].ToString() == "58")
            {
                if (!IsPostBack && Request.QueryString["id1"] != null)
                    {
                        
                        lblmsg_void.Visible = true;
                        lblmsg_void.Text = " AirWayBill No '" + Request.QueryString["id1"] + "' Has been Cancelled (Void SuccessFully) ";
                }
                if (Request.QueryString["awb_no"] != null)
            {
                sort = "b.AirWayBill_No";
            }
              
            else if (Request.QueryString["agent"] != null)
            {
                sort = "c.agent_name";
            }
            else if (Request.QueryString["flt"] != null)
            {
                sort = "e.flight_No";
            }
            else if (Request.QueryString["fltd"] != null)
            {
                sort = "d.flight_Date";
            }
            //else if (Request.QueryString["org"] != null)
            //{
            //    sort = "f.City_code";
            //}
            else if (Request.QueryString["dst"] != null)
            {
                sort = "g.destination_code";
            }
            else
            {
                sort = "d.flight_Date ,Flight_no,Agent_name";
            }
                lblmsg.Visible = false;

             //   htmlTableBoth();
                //gv.DataSource = null;
                //gv.DataBind();
            }

            else if (Session["groupid"].ToString() == "7")
            {
               
                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
              //  htmlTableWithDeal();
                //gv.DataSource = null;
                //gv.DataBind();

            }
            else if (Session["groupid"].ToString() == "6")
            {

                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
              //  handoveredit();
            

            }
            else if (Session["groupid"].ToString() == "8")
            {
               
                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
               // htmlTableWithDeal();
                //gv.DataSource = null;
                //gv.DataBind();
            }

            else if (Session["groupid"].ToString() == "15")
            {
               
                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
             //   htmlTableWithDeal();
                //gv.DataSource = null;
                //gv.DataBind();
            }

            else if (Session["groupid"].ToString() == "11")
            {
                htmlTableWithDeal();
                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
           //     htmlTableWithDeal();
                //gv.DataSource = null;
                //gv.DataBind();
            }
           else if (!IsPostBack && Request.QueryString["id"] != null && (Session["groupid"].ToString() == "13" || Session["groupid"].ToString() == "73"))
            {
                lblmsg.Visible = true;
                lblmsg.Text = " AirWayBill No '" + Request.QueryString["id"] + "' has been  Added to Sales ";
                htmlTableBoth();
            }
           else if (Session["groupid"].ToString() == "13" || Session["groupid"].ToString() == "73")
            {
               
                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
                lblmsg.Visible = false;
            //    htmlTableBoth();
                //gv.DataSource = null;
                //gv.DataBind();
            }
           else if (Session["groupid"].ToString() == "58")
           {

               if (Request.QueryString["awb_no"] != null)
               {
                   sort = "b.AirWayBill_No";
               }
               else if (Request.QueryString["agent"] != null)
               {
                   sort = "c.agent_name";
               }
               else if (Request.QueryString["flt"] != null)
               {
                   sort = "e.flight_No";
               }
               else if (Request.QueryString["fltd"] != null)
               {
                   sort = "d.flight_Date";
               }
               //else if (Request.QueryString["org"] != null)
               //{
               //    sort = "f.City_code";
               //}
               else if (Request.QueryString["dst"] != null)
               {
                   sort = "g.destination_code";
               }
               else
               {
                   sort = "d.flight_Date ,Flight_no,Agent_name";
               }
               lblmsg.Visible = false;
           //    htmlTableBoth();
               //gv.DataSource = null;
               //gv.DataBind();
           }
            else if (Session["groupid"].ToString() == "10")
            {
              
                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
            //    htmlTableSales();
                //gv.DataSource = null;
                //gv.DataBind();
            }

            else if (Session["groupid"].ToString() == "5")
            {
              
                if (Request.QueryString["awb_no"] != null)
                {
                    sort = "b.AirWayBill_No";
                }
                else if (Request.QueryString["agent"] != null)
                {
                    sort = "c.agent_name";
                }
                else if (Request.QueryString["flt"] != null)
                {
                    sort = "e.flight_No";
                }
                else if (Request.QueryString["fltd"] != null)
                {
                    sort = "d.flight_Date";
                }
                //else if (Request.QueryString["org"] != null)
                //{
                //    sort = "f.City_code";
                //}
                else if (Request.QueryString["dst"] != null)
                {
                    sort = "g.destination_code";
                }
                else
                {
                    sort = "d.flight_Date ,Flight_no,Agent_name";
                }
            //    htmlTableSimple();
                //gv.DataSource = null;
                //gv.DataBind();
            }
           

            //if (ddl.SelectedValue == "2")
            //{
            //    txtsearch.Text = "";
            //}

        }

    }

 
    public void htmlTableSimple()
    {
        try
        {
            // table header create
            int i = 0;
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            //com = new SqlCommand("select Airline_Name,Airline_Code from Airline_Master where status=2 order by airline_name", con);changed By Rajinder

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //                table += @"<table table width=""100%"" id=""Table1"" border=""1"" class=""text""><th align=""center"" colspan=""20"" class=""h5 boldtext"" style=""text-transform: uppercase;"">" + drx[0].ToString() + "-" + drx[2].ToString() + @"</th><tr class=""h1 boldtext""><td align=""left"" >Awb No.</td><td align=""left"" >Agent Name</td><td align=""left"" >Flight No.</td><td align=""left"" >Flight Date</td><td align=""left"" >Origin</td><td align=""left"" >Dstn</td><td align=""left"" >Pcs.</td><td align=""left"" >Gwt.</td><td align=""left"" >Chg Wt.</td></tr></th>
                //";
                //table Row Create daynamically.

                com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' order by " + sort + "", con);
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    flag = false;
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td  align=""center"" nowrap></td><td  align=""center"" nowrap></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?awb_no=awb_no'>Awb No.</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?agent=agent'>Agent Name</a></td><td  align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?flt=flt'>Flight No</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?fltd=fltd'>Flight Date</a></td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?dst=dst'>Dstn</a></td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Chg Wt.</td></tr></th>";
                    while (dr1.Read())
                    {
                        table += @"<tr><td align=left class=text>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["agent_name"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_Date"].ToString() + @"</td><td align=""left"" class=text>" + dr1["city_code"].ToString() + @"</td><td align=""left"" class=text>" + dr1["destination_code"].ToString() + @"</td><td align=""left"" class=text>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";
                    }
                }
                else
                {
                  //  flag = true;

                   
                    //lblmsg.Text = "No Record Found...";
                }

         
                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;
            if (flag == true)
                Label1.Text = "No Record Found...";

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void htmlTableWithDeal()
    {
        //data3();
        try
        {
            // table header create
            int i = 0;
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            //com = new SqlCommand("select Airline_Name,Airline_Code from Airline_Master where status=2 order by airline_name", con);Changed by Rajinder

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);
            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //                table += @"<table table width=""100%"" id=""Table1"" border=""1"" class=""text""><th align=""center"" colspan=""20"" class=""h5 boldtext"" style=""text-transform: uppercase;>" + drx[0].ToString() + "-" + drx[2].ToString() + @"</th><tr class=""h1 boldtext""><td align=""left"" ></td><td align=""left"" >Awb No.</td><td align=""left"" >Agent Name</td><td align=""left"" >Flight No.</td><td align=""left"" >Flight Date</td><td align=""left"" >Origin</td><td align=""left"" >Dstn</td><td align=""left"" >Pcs.</td><td align=""left"" >Gwt.</td><td align=""left"" >Chg Wt.</td></tr></th>
                //";
                //table Row Create daynamically.

                if (txtsearch.Text == "" && txtdate.Text == "")
                {

                    com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' order by " + sort + "", con);
                }
                else
                {
                    if (ddl.SelectedValue == "0")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and e.flight_No like " + "'" + txtsearch.Text + "%'  order by " + sort + "", con);
                    }
                    if (ddl.SelectedValue == "2")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and b.AirWayBill_No like " + "'%" + txtsearch.Text + "%' order by " + sort + "", con);
                    }
                    if (ddl.SelectedValue == "3")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and c.agent_name  like " + "'" + txtsearch.Text + "%' order by " + sort + " ", con);
                    }

                    if (ddl.SelectedValue == "4")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and f.city_code like " + "'" + txtsearch.Text + "%' order by " + sort + " ", con);
                    }

                    if (ddl.SelectedValue == "1")
                    {
                        pnldate.Visible = true;
                        string strdate = null;
                        txtsearch.Visible = false;
                        try
                        {
                            if (txtdate.Text != null)
                            {
                                strdate = FormatDateMM(txtdate.Text);
                            }
                            else
                            {

                            }
                        }
                        catch (Exception)
                        {

                        }

                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and d.flight_Date=" + "'" + strdate + "' order by " + sort + "", con);


                    }

                }
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    flag = false;
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td  align=""center"" nowrap></td><td  align=""center"" nowrap>Handover</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?awb_no=awb_no'>Awb No.</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?agent=agent'>Agent Name</a></td><td  align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?flt=flt'>Flight No</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?fltd=fltd'>Flight Date</a></td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?dst=dst'>Dstn</a></td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Chg Wt.</td></tr></th>";

                    string html_table = "";
                    while (dr1.Read())
                    {
                        if (dr1["Add_to_Deal"].ToString() == "NoDeal")
                        {
                            html_table = "<a href=AddDeal.aspx?hid=" + dr1["handover_id"].ToString() + " class=boldtext>AddDeal</a>";
                        }
                        else
                        {
                            html_table = "<a href=AddDeal.aspx?hid=" + dr1["handover_id"].ToString() + " class=boldtext>UpdateDeal</a>";
                        }

                        table += @"<tr><td align=""left"" >" + html_table + "</td><td align=left ><a href=Handover_Edit.aspx?Handover_ID=" + dr1["handover_id"].ToString() + " class=boldtext>Edit</a></td><td align=left  class=text nowrap>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["agent_name"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_Date"].ToString() + @"</td><td align=""left"" class=text>" + dr1["city_code"].ToString() + @"</td><td align=""left"" class=text>" + dr1["destination_code"].ToString() + @"</td><td align=""left"" class=text>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";
                    }
                }
                else
                {

                  // flag = true;
                    //lblmsg.Text = "No Record Found...";
                }

           
                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;
            if (flag == true)
                Label1.Text = "No Record Found...";

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        dr.Dispose();
        con.Close();
        cmd.Dispose();
        return Access;
    }
    public void htmlTableSales()
    {
        //data3();
        try
        {
            // table header create
            int i = 0;
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            //com = new SqlCommand("select Airline_Name,Airline_Code from Airline_Master where status=2 order by airline_name", con);Changed by Rajinder

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);
            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //                table += @"<table table width=""100%"" id=""Table1"" border=""1"" class=""text""><th align=""center"" colspan=""20"" class=""h5 boldtext"" style="" text-transform: uppercase;"">" + drx[0].ToString() + "-" + drx[2].ToString() + @"</th><tr class=""h1 boldtext""><td align=""left"" ></td><td align=""left"" >Awb No.</td><td align=""left"" >Agent Name</td><td align=""left"" >Flight No.</td><td align=""left"" >Flight Date</td><td align=""left"" >Origin</td><td align=""left"" >Dstn</td><td align=""left"" >Pcs.</td><td align=""left"" >Gwt.</td><td align=""left"" >Chg Wt.</td></tr></th>
                //";
                //table Row Create daynamically.
                if (txtsearch.Text == "" && txtdate.Text == "")
                {

                    com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' order by " + sort + "", con);
                }
                else
                {
                    if (ddl.SelectedValue == "0")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and e.flight_No like " + "'" + txtsearch.Text + "%'  order by " + sort + "", con);
                    }
                    if (ddl.SelectedValue == "2")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and b.AirWayBill_No like " + "'%" + txtsearch.Text + "%' order by " + sort + "", con);
                    }
                    if (ddl.SelectedValue == "3")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and c.agent_name  like " + "'" + txtsearch.Text + "%' order by " + sort + "", con);
                    }

                    if (ddl.SelectedValue == "4")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and f.city_code like " + "'" + txtsearch.Text + "%' order by " + sort + "", con);
                    }

                    if (ddl.SelectedValue == "1")
                    {
                        pnldate.Visible = true;
                        string strdate = null;
                        txtsearch.Visible = false;
                        try
                        {
                            if (txtdate.Text != null)
                            {
                                strdate = FormatDateMM(txtdate.Text);
                            }
                            else
                            {

                            }
                        }
                        catch (Exception)
                        {

                        }

                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and d.flight_Date=" + "'" + strdate + "' order by " + sort + "", con);


                    }

                }
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    flag = false;
                   table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td  align=""center"" nowrap></td></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?awb_no=awb_no'>Awb No.</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?agent=agent'>Agent Name</a></td><td  align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?flt=flt'>Flight No</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?fltd=fltd'>Flight Date</a></td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?dst=dst'>Dstn</a></td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Chg Wt.</td></tr></th>";

                    while (dr1.Read())
                    {

                        table += @"<tr><td align=left ><a href=Sales_New.aspx?Handover_ID=" + dr1["handover_id"].ToString() + " class=boldtext>AddToSales</a></td><td align=left nowrap class=text>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["agent_name"].ToString() + @"</td><td align=""left"" nowrap class=text>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["flight_Date"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["city_code"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["destination_code"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""right"" class=text nowrap>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""right"" class=text nowrap>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";
                    }
                }
                else
                {

                 //  flag = true;
                    //lblmsg.Text = "No Record Found...";
                }

               
                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;
            if (flag == true)
                Label1.Text = "No Record Found...";

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public void handoveredit()
    {
        //data3();
        try
        {

            // table header create
            int i = 0;
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            //com = new SqlCommand("select Airline_Name,Airline_Code from Airline_Master where status=2 order by airline_name", con);Changed by Rajinder


            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
         
                //table Row Create daynamically.
                if (txtsearch.Text == "" && txtdate.Text == "")
                {

                    com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' order by " + sort + "", con);
                }
                else
                {
                    if (ddl.SelectedValue == "0")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and e.flight_No like " + "'" + txtsearch.Text + "%'  order by " + sort + "", con);
                    }
                    if (ddl.SelectedValue == "2")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and b.AirWayBill_No like " + "'%" + txtsearch.Text + "%' order by " + sort + " ", con);
                    }
                    if (ddl.SelectedValue == "3")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and c.agent_name  like " + "'" + txtsearch.Text + "%' order by " + sort + "", con);
                    }

                    if (ddl.SelectedValue == "4")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and f.city_code like " + "'" + txtsearch.Text + "%' order by " + sort + " ", con);
                    }

                    if (ddl.SelectedValue == "1")
                    {
                        pnldate.Visible = true;
                        string strdate = null;
                        txtsearch.Visible = false;
                        try
                        {
                            if (txtdate.Text != null)
                            {
                                strdate = FormatDateMM(txtdate.Text);
                            }
                            else
                            {

                            }
                        }
                        catch (Exception)
                        {

                        }

                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and d.flight_Date=" + "'" + strdate + "' order by " + sort + " ", con);


                    }

                }

                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    flag = false;
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td align=""center"" nowrap >Handover</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?awb_no=awb_no'>Awb No.</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?agent=agent'>Agent Name</a></td><td  align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?flt=flt'>Flight No</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?fltd=fltd'>Flight Date</a></td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?dst=dst'>Dstn</a></td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Chg Wt.</td></tr></th>";

                
                    while (dr1.Read())
                    {
                        table += @"<tr><td align=left ><a href=Handover_Edit.aspx?Handover_ID=" + dr1["handover_id"].ToString() + " class=boldtext>Edit</a></td><td align=left nowrap class=text>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left""class=text >" + dr1["agent_name"].ToString() + @"</td><td align=""left"" nowrap class=text>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["flight_Date"].ToString() + @"</td><td align=""left""  nowrap class=text>" + dr1["city_code"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["destination_code"].ToString() + @"</td><td class=text align=""left"" nowrap>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""right"" class=text nowrap>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""right"" class=text nowrap>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";
                        //table += @"<tr>&nbsp</tr></table>";
                    }
                }
                else
                {
                 //  flag = true;
                    //lblmsg.Text = "No Record Found...";
                }
                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;
            if (flag == true)
                Label1.Text = "No Record Found...";
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public void htmlTableBoth()
    {
        //data3();
        try
        {

            // table header create
            int i = 0;
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            //com = new SqlCommand("select Airline_Name,Airline_Code from Airline_Master where status=2 order by airline_name", con);Changed by Rajinder


            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
            //table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td  align=""center"" nowrap></td><td  align=""center"" nowrap></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?group='Airwaybill_no'>Awb No.</a></td><td  align=""center"" nowrap>Agent Name</td><td  align=""center""nowrap>Flight No.</td><td  align=""center"" nowrap>Flight Date</td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap>Dstn</td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Chg Wt.</td></tr></th>";
                //table Row Create daynamically.
                if (txtsearch.Text == "" && txtdate.Text == "")
                {

                    com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' order by " + sort + "", con);
                }
                else
                {
                    if (ddl.SelectedValue == "0")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and e.flight_No like " + "'" + txtsearch.Text + "%'  order by " + sort + "", con);
                    }
                    if (ddl.SelectedValue == "2")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and b.AirWayBill_No like " + "'%" + txtsearch.Text + "%' order by " + sort + " ", con);
                    }
                    if (ddl.SelectedValue == "3")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and c.agent_name  like " + "'" + txtsearch.Text + "%' order by " + sort + "", con);
                    }

                    if (ddl.SelectedValue == "4")
                    {
                        txtdate.Text = "";
                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and f.city_code like " + "'" + txtsearch.Text + "%' order by " + sort + " ", con);
                    }

                    if (ddl.SelectedValue == "1")
                    {
                        pnldate.Visible = true;
                        string strdate = null;
                        txtsearch.Visible = false;
                        try
                        {
                            if (txtdate.Text != null)
                            {
                                strdate = FormatDateMM(txtdate.Text);
                            }
                            else
                            {

                            }
                        }
                        catch (Exception)
                        {

                        }

                        com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' and d.flight_Date=" + "'" + strdate + "' order by " + sort + " ", con);


                    }

                }

                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    flag = false;
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td  align=""center"" nowrap></td><td align=""center"" nowrap >Handover</td><td  align=""center"" nowrap></td><td align=""center"" nowrap>Void</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?awb_no=awb_no'>Awb No.</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?agent=agent'>Agent Name</a></td><td  align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?flt=flt'>Flight No</a></td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?fltd=fltd'>Flight Date</a></td><td  align=""center"" nowrap>Origin</td><td  align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='handoverdetails.aspx?dst=dst'>Dstn</a></td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Chg Wt.</td></tr></th>";

                    string html_table = "";
                    while (dr1.Read())
                    {
                        if (dr1["Add_to_Deal"].ToString() == "NoDeal")
                        {
                            html_table = "<a href=AddDeal.aspx?hid=" + dr1["handover_id"].ToString() + " class=boldtext>AddDeal</a>";
                        }
                        else
                        {
                            html_table = "<a href=AddDeal.aspx?hid=" + dr1["handover_id"].ToString() + " class=boldtext>UpdateDeal</a>";
                        }
                        string url_void = "Booking_Void.aspx?Airwaybill_no=" + dr1["Airwaybill_no"] + "&amp;Booking_id=" + dr1["Booking_id"];

                        table += @"<tr><td align=""left"" >" + html_table + "</td><td align=left ><a href=Handover_Edit.aspx?Handover_ID=" + dr1["handover_id"].ToString() + " class=boldtext>Edit</a></td><td align=left ><a href=Sales_New.aspx?Handover_ID=" + dr1["handover_id"].ToString() + " class=boldtext>AddToSales</a></td><td align=left class=boldtext><a href=" + url_void + " class=boldtext>Void</a></td><td align=left nowrap class=text>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left""class=text >" + dr1["agent_name"].ToString() + @"</td><td align=""left"" nowrap class=text>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["flight_Date"].ToString() + @"</td><td align=""left""  nowrap class=text>" + dr1["city_code"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["destination_code"].ToString() + @"</td><td class=text align=""left"" nowrap>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""right"" class=text nowrap>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""right"" class=text nowrap>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";
                      //table += @"<tr>&nbsp</tr></table>";
                    }
                }
                else
                {
                                //lblmsg.Text = "No Record Found...";
                    
                    
                }
                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;
            if (flag == true)
                Label1.Text = "No Record Found...";
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    //protected void rowColor()
    //{
    //    int c = grdHandoverDetails.Columns.Count;
    //    for (int i = 0; i < grdHandoverDetails.Rows.Count; i++)
    //    {
    //        GridViewRow gr = grdHandoverDetails.Rows[i];

    //        if (((Label)(gr.FindControl("Label1"))).Text == "Deal")
    //        {
    //            //((Label)(gr.FindControl("Label4"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label5"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label6"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label7"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label8"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label9"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label10"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label11"))).ForeColor = System.Drawing.Color.Red;
    //            //((Label)(gr.FindControl("Label12"))).ForeColor = System.Drawing.Color.Red;
    //            ((Button)(gr.FindControl("btnAddToDeal"))).Visible = false;

    //        }
    //    }
    //}

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        lblmsg_void.Visible = false;
        Label3.Visible = false;
        flag = true;
        if (Session["groupid"].ToString() == "1"||Session["groupid"].ToString() == "13" || Session["groupid"].ToString() == "73"||Session["groupid"].ToString() == "58")
            htmlTableBoth();
        else if (Session["groupid"].ToString() == "7"||Session["groupid"].ToString() == "11"||Session["groupid"].ToString() == "8"||Session["groupid"].ToString() == "15")
            htmlTableWithDeal();
        else if (Session["groupid"].ToString() == "6")
            handoveredit();
        else if (Session["groupid"].ToString() == "10")
            htmlTableSales();
        else if (Session["groupid"].ToString() == "5")
            htmlTableSimple();


    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddl.SelectedValue == "1")
        {
            txtsearch.Text = "";
            pnldate.Visible = true;
            txtsearch.Visible = false;
        }
        else
        {
            txtdate.Text = "";
            pnldate.Visible = false;
            txtsearch.Visible = true; ;
        }
    }
    
}
