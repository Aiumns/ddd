using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Approve_CSR : System.Web.UI.Page
{
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    #region Variables Declaration
    
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    string Access;
    string Arl_Access;

    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                UserAirlineNamePlusCode();
            }
        }
    }


    #region Display Airline/City in  ADD Case
    public void UserAirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            string Airline_Access = Rights();
            ddlAirline.Items.Clear();

            strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City  where b.Airline_Detail_ID in" + "(" + Airline_Access + ") order by  a.Airline_Name";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirline.Items.Insert(0, "--Select Airline--");
            ddlAirline.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));

            }
            con.Close();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string Rights()
    {
        string sql_Access = "";
        if(Session["groupid"].ToString()=="5")
        {

            sql_Access = "select Airline_Access from Agent_Master a inner join Agent_Branch b on a.Agent_ID=b.agent_id inner join login_master c on b.Agent_Branch_ID=c.Agent_ID where a.agent_id=" + Session["ID"].ToString();
        }
        else
        {
            sql_Access = "SELECT Airline_Access FROM USER_MASTER A INNER JOIN login_master B ON A.UserID=B.User_ID where a.UserID=" + Session["ID"].ToString();
        
        }

        con = new SqlConnection(strCon);
        con.Open();

        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }
        }

        if (Access == null)
        {
            lblmsg.Visible = true;
            lblmsg.Text = " There is No Airline Exists ";

        }
        else
        {
            lblmsg.Visible = false;
            
            Arl_Access = Access;
           

        }
        return Arl_Access;

    }
    #endregion 


    #region Fill valid Duration For CSR
    public void FillDuration()
    {
        try
        {
            string strQuery = "";
            ddlDuration.Items.Clear();
            //strQuery = "SELECT CSR_Duration_ID,CSR_Duration FROM CSR_Duration WHERE CSR_Duration_ID NOT IN (SELECT CSR_Duration_ID FROM Approved_CSR WHERE Airline_Detail_ID='" + ddlAirline.SelectedValue+"')";

            //strQuery = "SELECT CSR_Duration_ID,CSR_Duration FROM CSR_Duration WHERE CSR_Duration_ID NOT IN (SELECT CSR_Duration_ID FROM Approved_CSR WHERE Airline_Detail_ID='" + ddlAirline.SelectedValue + "')and  SUBSTRING(CSR_Duration,7,2 )<=substring(convert(varchar, GETDATE(), 101),9,2)and SUBSTRING(CSR_Duration,1,2 )<=month(GETDATE()) AND SUBSTRING(CSR_Duration,4,2 )<=DAY(GETDATE()) ";
            strQuery = "SELECT CSR_Duration_ID,CSR_Duration FROM CSR_Duration WHERE CSR_Duration_ID NOT IN (SELECT CSR_Duration_ID FROM Approved_CSR WHERE Airline_Detail_ID='" + ddlAirline.SelectedValue + "')and SUBSTRING(CSR_Duration,1,8 )<=GETDATE()";
            // strQuery = "SELECT CSR_Duration_ID,CSR_Duration FROM CSR_Duration ";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDuration.Items.Insert(0, "Select Period");
            ddlDuration.Items[0].Value = "0";
            while (dr.Read())
            {
                string csr_d = dr["CSR_Duration"].ToString();
                string[] arr_csr = csr_d.Split('-');
                string First_Fort = arr_csr[0];
                string Sec_Fort = arr_csr[1];
                string[] Arr_First_Fort = First_Fort.Split('/');
                string MM = Arr_First_Fort[0];
                string DD = Arr_First_Fort[1];
                string yy = Arr_First_Fort[2];
                string DDMMYYYY = DD + "/" + MM + "/" + yy;

                string[] Arr_Sec_Fort = Sec_Fort.Split('/');
                string strMM = Arr_Sec_Fort[0];
                string strDD = Arr_Sec_Fort[1];
                string stryy = Arr_Sec_Fort[2];
                string strDDMMYYYY = strDD + "/" + strMM + "/" + stryy;

                string Final_CSR_Duration = DDMMYYYY + "-" + strDDMMYYYY;
                ddlDuration.Items.Add(new ListItem(Final_CSR_Duration, dr["CSR_Duration"].ToString()));

                //ddlDuration.Items.Add(new ListItem(dr["CSR_Duration"].ToString(), dr["CSR_Duration_ID"].ToString()));

            }
            con.Close();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    #endregion
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string Duration=ddlDuration.SelectedValue;
        string AirlineDetailId = ddlAirline.SelectedItem.Value;
        //////////////************************Updated By Hemant Sharm on 14 May 2014**************////////////
        #region If Double Entry Of Agent Found
        string[] period = Duration.Split('-');
        string valid_from = period[0];
        string valid_to = period[1];
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand("Double_AgentCase_Before_Approve_CSR", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@airline_detail_id", SqlDbType.Int).Value = AirlineDetailId;
        com.Parameters.Add("@valid_from", SqlDbType.DateTime).Value = Convert.ToDateTime(valid_from);
        com.Parameters.Add("@valid_to", SqlDbType.DateTime).Value = Convert.ToDateTime(valid_to);
        com.ExecuteNonQuery();
        con.Close();
        #endregion
        Response.Redirect("Approve_CSR_Details.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("Duration", Duration), new Pair("AirlineDetailId", AirlineDetailId)));
        //btnAdd.Attributes.Add("onclick", "javascript:window.open('Approve_CSR_Details.aspx'); return false;");
      

     

      
    }
    protected void ddlAirline_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillDuration();
    }
}
