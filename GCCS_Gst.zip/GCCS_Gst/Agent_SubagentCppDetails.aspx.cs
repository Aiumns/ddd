﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class Agent_SubagentCppDetails : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    string Agent_Id = "";

    string City_ID = "";
    string Agent_Name = "";
    string City_Name = "";
    string Company_ID = "";
    string SubAgent_ID = "";
    string table;
    DataTable dtM;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }



        else
        {
            LoadDetails1();
        }



    }
    public void LoadDetails1()
    {
        if (Request.QueryString["rbntype"] == "0")
        {
            Agent_Id = Request.QueryString["ID"];
            SubAgent_ID = "0";
        }
        else
        {
            Agent_Id = "0";
            SubAgent_ID = Request.QueryString["ID"];
        }


        City_ID = Request.QueryString["City_ID"];
        Company_ID = Request.QueryString["Company_ID"];

        //Panel2.Visible = true;

        int totaldebit = 0;
        int totalcpp = 0;
        int totalredeem = 0;
        string table = "";
        string table1 = "";
        string table2 = "";
        string table3 = "";
        string oldStartDate = "";
        string oldEndDate = "";
        string ValueDate = "";
        string ExpiryDate = "";
        decimal Cpp=0;
        decimal Redeemcpp=0;
        decimal AvalCpp=0;
        string ReedeemID = "";
        int k = 0;
        //---------------------------------------------------create table1//--------------------------------------
        con = new SqlConnection(strCon);
        com = new SqlCommand("GetCppDetailsData", con);
        com.CommandType = CommandType.StoredProcedure;

        com.Parameters.Add("@AgentID", SqlDbType.Int).Value = Convert.ToInt32(Agent_Id);
        com.Parameters.Add("@SubAgentID", SqlDbType.Int).Value = Convert.ToInt32(SubAgent_ID);
        com.Parameters.Add("@CityID", SqlDbType.Int).Value = Convert.ToInt32(City_ID);
        com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = Convert.ToInt32(Company_ID);
        DataTable dt1 = new DataTable();
        SqlDataAdapter sdaCppDetails = new SqlDataAdapter(com);

        sdaCppDetails.Fill(dt1);
        //DataTable dt1 = dw.GetAllFromQuery("SELECT Sno, Convert(varchar,ValueDate,3) as [Value Date],Convert(varchar,StartDate,3) as [Start Date],Convert(varchar,EndDate,3) as [End Date],Totalcpp as [cpp],RedeemedCpp as [Reedeem CPP],AvailableCPP as [Available CPP],RedeemID as [Redeemed ID],Convert(varchar,ExpiryDate,3) as [Expiry Date],isadvance as [advance] FROM CPP_AgentwiseTotal  WHERE AGENTID=" + Agent_Id + " AND CITYID=" + City_ID + " order by startdate ");

        table1 = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding> <tr class=HeaderStyle1  width=100%><td align=center class=boldtext width=30% colspan=10 NOWRAP><h4> Cpp Details </h4></td></tr>";
        if (dt1.Rows.Count > 0)
        {

            table1 = table1 + @"<tr class=HeaderStyle2><td   align=center colspan=2 >S.No</td><td  >Val Date</td><td  nowrap >Start Date</td><td   nowrap>End Date</td><td  nowrap>cpp</td><td  >Rdm CPP</td><td   >Avl CPP</td><td  width=30%  >Rdm ID</td><td   nowrap>Expiry Date</td></tr>";

            oldStartDate = dt1.Rows[0]["StartDate"].ToString();
            oldEndDate = dt1.Rows[0]["EndDate"].ToString();
            ValueDate = dt1.Rows[0]["ValueDate"].ToString();
            ExpiryDate = dt1.Rows[0]["ExpiryDate"].ToString();
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                if (oldStartDate == dt1.Rows[i]["StartDate"].ToString() && oldEndDate == dt1.Rows[i]["EndDate"].ToString())
                {
                    k = 1;

                    Cpp+= decimal.Parse(dt1.Rows[i]["cpp"].ToString());
                    Redeemcpp += decimal.Parse(dt1.Rows[i]["RedeemedCPP"].ToString());
                    AvalCpp += decimal.Parse(dt1.Rows[i]["AvailableCPP"].ToString());
                    ReedeemID += dt1.Rows[i]["RedeemID"].ToString();
               }
                else
                {
                    if (k == 1)
                    {
                        table1 = table1 + @"<tr><td class=text  align=center colspan=2 >" + (i + 1) + @" </td><td class=text >" + ValueDate + @"</td><td class=text nowrap >" + oldStartDate + @"</td><td  class=text nowrap>" + oldEndDate + @"</td><td  class=text nowrap align=right>" + Convert.ToString(Math.Round(Cpp, 0, MidpointRounding.AwayFromZero)) + @"</td><td  class=text nowrap align=right>" + Convert.ToString(Math.Round(Redeemcpp, 0, MidpointRounding.AwayFromZero)) + @"</td><td  class=boltextdtext nowrap align=right>" + Convert.ToString(Math.Round(AvalCpp, 0, MidpointRounding.AwayFromZero)) + @"</td><td width=30% class=text >" + ReedeemID + @"</td><td class=text nowrap>" + ExpiryDate + @"</td></tr>";
                        k = 0;
                        oldStartDate = dt1.Rows[i]["StartDate"].ToString();
                        oldEndDate = dt1.Rows[i]["EndDate"].ToString();
                        ValueDate = dt1.Rows[i]["ValueDate"].ToString();
                        ExpiryDate = dt1.Rows[i]["ExpiryDate"].ToString();
                        Cpp = decimal.Parse(dt1.Rows[i]["cpp"].ToString());
                        Redeemcpp = decimal.Parse(dt1.Rows[i]["RedeemedCPP"].ToString());
                        AvalCpp = decimal.Parse(dt1.Rows[i]["AvailableCPP"].ToString());
                        ReedeemID = dt1.Rows[i]["RedeemID"].ToString();
                    }
                    else
                    {
                        table1 = table1 + @"<tr><td class=text  align=center colspan=2 >" + (i + 1) + @" </td><td class=text >" + dt1.Rows[i]["ValueDate"].ToString() + @"</td><td class=text nowrap >" + dt1.Rows[i]["StartDate"].ToString() + @"</td><td  class=text nowrap>" + dt1.Rows[i]["EndDate"].ToString() + @"</td><td  class=text nowrap align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt1.Rows[i]["cpp"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td  class=text nowrap align=right>" +Convert.ToString(Math.Round(decimal.Parse(dt1.Rows[i]["RedeemedCPP"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td  class=text nowrap align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt1.Rows[i]["AvailableCPP"].ToString()), 0, MidpointRounding.AwayFromZero))  + @"</td><td width=30% class=text >" + dt1.Rows[i]["RedeemID"].ToString() + @"</td><td class=text nowrap>" + dt1.Rows[i]["ExpiryDate"].ToString() + @"</td></tr>";
                    
                    }
                    
                }



                totaldebit += Convert.ToInt32(dt1.Rows[i]["cpp"]);

                //if (dt1.Rows[i]["advance"].ToString() == "N")
                //{
                totalcpp = totalcpp + Convert.ToInt32(dt1.Rows[i]["RedeemedCPP"]);
                //}
            }
            //for (int i = dt1.Rows.Count-1; i < dt1.Rows.Count; i++)
            //{
            //    Cpp += decimal.Parse(dt1.Rows[i]["cpp"].ToString());
            //    Redeemcpp += decimal.Parse(dt1.Rows[i]["RedeemedCPP"].ToString());
            //    AvalCpp += decimal.Parse(dt1.Rows[i]["AvailableCPP"].ToString());
            //    ReedeemID += dt1.Rows[i]["RedeemID"].ToString();
            //}
            table1 = table1 + @"<tr><td class=text  align=center colspan=2 >" + 1 + @" </td><td class=text >" + ValueDate + @"</td><td class=text nowrap >" + oldStartDate + @"</td><td  class=text nowrap>" + oldEndDate + @"</td><td  class=text nowrap align=right>" + Convert.ToString(Math.Round(Cpp, 0, MidpointRounding.AwayFromZero)) + @"</td><td  class=text nowrap align=right>" + Convert.ToString(Math.Round(Redeemcpp, 0, MidpointRounding.AwayFromZero)) + @"</td><td  class=text nowrap align=right>" + Convert.ToString(Math.Round(AvalCpp, 0, MidpointRounding.AwayFromZero)) + @"</td><td width=30% class=text >" + ReedeemID + @"</td><td class=text nowrap>" + ExpiryDate + @"</td></tr>";

            table1 = table1 + @"<tr> <td class=boldtext  align=center colspan=5 >Total cpp</td><td class=boldtext style=""color: blue;font-family:verdana;font-size:10px;  text-align: right;"" >" + totaldebit + @"</td> <td class=boldtext  style=""color: blue;font-family:verdana;font-size:10px;  text-align: right;"" >" + totalcpp + @"</td><td></td><td></td><td></td> </tr>";

        }
        else
        {
            table1 = table1 + @"<tr><td class=boldtext style=""color: Red;font-family:verdana;font-size:12px;  text-align: center;"" colspan=6>No CPP Found for this Agent</td></tr>";

        }


        table1 = table1 + @"</table>";

        //----------------------end table1------------------------------





        //-------------------------create table2------------------------------

        con = new SqlConnection(strCon);
        com = new SqlCommand("GetCppReedeemData", con);
        com.CommandType = CommandType.StoredProcedure;

        com.Parameters.Add("@AgentID", SqlDbType.Int).Value = Convert.ToInt32(Agent_Id);
        com.Parameters.Add("@SubAgentID", SqlDbType.Int).Value = Convert.ToInt32(SubAgent_ID);
        com.Parameters.Add("@CityID", SqlDbType.Int).Value = Convert.ToInt32(City_ID);
        com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = Convert.ToInt32(Company_ID);
        DataTable dt2 = new DataTable();
        SqlDataAdapter sdareedem = new SqlDataAdapter(com);
        sdareedem.Fill(dt2);
        //DataTable dt2 = dw.GetAllFromQuery("SELECT Redeem_id, Redeemed_cpp_excltax,taxamount,Redeemed_cpp,Remarks,status,entered_by,Convert(varchar,entered_on,3) as [Enter Date],Concerned_Person from Redeem_CPPNew  WHERE AGENT_ID=" + Agent_Id + " AND CITY_ID=" + City_ID + " order by Entered_on ");
        table2 = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding> <tr class=HeaderStyle1  width=100%><td align=center  width=30% colspan=9 NOWRAP><h4> Redeem Details </h4></td></tr>";
        if (dt2.Rows.Count > 0)
        {

            table2 = table2 + @"<tr class=HeaderStyle2 ><td  width=20% align=center  >ID</td><td  width=30%>Rdm</td><td   width=30%>Tax</td><td width=30%  nowrap>Tot Rdm</td><td width=30%  >Remarks</td><td width=30%  >Status</td><td width=30%  >Entered By</td><td width=30%  nowrap>Entered Date</td><td width=30%  nowrap>Authorised Person</td></tr>";

            for (int i = 0; i < dt2.Rows.Count; i++)
            {


                table2 = table2 + @"<tr><td class=text width=20% align=center  nowrap>" + dt2.Rows[i]["Redeem_id"].ToString() + @" </td><td class=text nowrap width=30% align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt2.Rows[i]["Redeemed_cpp_excltax"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td class=text nowrap width=30% align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt2.Rows[i]["taxamount"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td width=30% class=text nowrap align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt2.Rows[i]["Redeemed_cpp"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td width=30% class=text >" + dt2.Rows[i]["Remarks"].ToString() + @"</td><td width=30% class=text >" + dt2.Rows[i]["status"].ToString() + @"</td><td width=30% class=text nowrap>" + dt2.Rows[i]["Entered_By"].ToString().Substring(0, 5) + @"</td><td width=30% class=text nowrap>" + dt2.Rows[i]["EnterDate"].ToString() + @"</td><td width=30% class=text nowrap>" + dt2.Rows[i]["Concerned_Person"].ToString() + @"</td></tr>";
                totalredeem = totalredeem + Convert.ToInt32(dt2.Rows[i]["Redeemed_cpp"]);
            }




            if (totalcpp == totalredeem)
            {
                table2 = table2 + @"<tr><td class=boldtext width=20% align=center colspan=3 nowrap>Total redeem </td><td class=boldtext style=""color: blue;font-family:verdana;font-size:10px;  text-align: right;"">" + totalredeem + @"</td><td class=boldtext width=20% align=center colspan=4 nowrap></td></tr>";
            }
            else
            {
                table2 = table2 + @"<tr><td class=boldtext width=20% align=center colspan=3 nowrap>Total redeem </td><td class=boldtext width=20% align=center  >" + totalredeem + @"</td><td style=""color: Red;font-family:verdana;font-size:12px;  text-align: center;"" colspan=4> ERROR........ </td></tr>";
            }

        }
        else
        {
            table2 = table2 + @"<tr><td style=""color: Red;font-family:verdana;font-size:10px;  text-align: center;"" colspan=6>No CPP Found for this Agent</td></tr>";
            // btnCpp.Enabled = false;
        }

        table2 = table2 + @"</table>";

        //lblredeemdetail.Text = table2;

        //------------------------end table2---------------------------------------





        ////--------------------start table3----------------------------------------
        table3 = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding> <tr class=HeaderStyle1  width=100%><td align=center  width=30% colspan=8 NOWRAP><h4> Cpp Transaction</h4></td></tr>";
        com = new SqlCommand("GetCppData_Main", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Agent_ID", SqlDbType.Int).Value = Convert.ToInt32(Agent_Id);
        com.Parameters.Add("@SubAgentID", SqlDbType.Int).Value = Convert.ToInt32(SubAgent_ID);
        com.Parameters.Add("@city_id", SqlDbType.Int).Value = Convert.ToInt32(City_ID);
        com.Parameters.Add("@Company_Id", SqlDbType.Int).Value = Convert.ToInt32(Company_ID);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt3 = new DataTable();
        da.Fill(dt3);

        //DataTable dt3 = dw.GetAllFromQuery("SELECT  Convert(varchar,tran_date,3) as Date,Convert(varchar,ValueDate,3) as Value_Date,Opening_bal as [Opening Balance],cpp,closing_bal as [closing Balance],tran_type as [Transaction  Type],remarks FROM CPP_Tran  WHERE AGENT_ID=" + Agent_Id + " AND CITY_ID=" + City_ID + " order by ValueDate");
        if (dt3.Rows.Count > 0)
        {

            table3 = table3 + @"<tr class=HeaderStyle2><td  width=20% align=center colspan=0 nowrap>Entry Date</td><td  width=20% align=center colspan=0 nowrap>Value Date</td><td  width=20% nowrap >Openeing Bal</td><td  width=20% nowrap >CPP</td><td   width=20%  nowrap>Closing Bal</td><td   width=20%  nowrap>Trans Type</td><td   width=20% nowrap>Remarks</td></tr>";

            for (int i = 0; i < dt3.Rows.Count; i++)
            {


                table3 = table3 + @"<tr><td class=boldtext width=20% align=center colspan=0 nowrap>" + dt3.Rows[i]["Date"].ToString() + @" </td><td class=boldtext width=20% align=center colspan=0 nowrap>" + dt3.Rows[i]["Value_Date"].ToString() + @" </td><td class=boldtext width=20% nowrap align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt3.Rows[i]["Opening Balance"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td class=boldtext width=20% align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt3.Rows[i]["cpp"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td  class=boldtext width=20% nowrap align=right>" + Convert.ToString(Math.Round(decimal.Parse(dt3.Rows[i]["closing Balance"].ToString()), 0, MidpointRounding.AwayFromZero)) + @"</td><td width=20% class=boldtext nowrap>" + dt3.Rows[i]["Transaction  Type"].ToString() + @"</td><td width=20% class=boldtext nowrap  >" + dt3.Rows[i]["remarks"].ToString() + @"</td></tr>";
            }


        }
        else
        {
            table3 = table3 + @"<tr><td style=""color: Red;font-family:verdana;font-size:10px;  text-align: center;"" colspan=6>No CPP Found for this Agent</td></tr>";

        }


        table3 = table3 + @"</table>";




        //--------------------end table3-----------------------------------------


        //------------------start outer table--------------------------------------


        ////table = @"<table border=2px width=900px  align=center border-color=black><tr class=h1><td align=center class=boldtext width=30% colspan=2 NOWRAP>" + Agent_Name + " [" + City_Name.Substring(0, 3) + "]</td></tr>";


        con = new SqlConnection(strCon);
        com = new SqlCommand("GetCppClientInformation", con);
        com.CommandType = CommandType.StoredProcedure;

        com.Parameters.Add("@AgentID", SqlDbType.Int).Value = Convert.ToInt32(Agent_Id);
        com.Parameters.Add("@SubAgentID", SqlDbType.Int).Value = Convert.ToInt32(SubAgent_ID);
        com.Parameters.Add("@CityID", SqlDbType.Int).Value = Convert.ToInt32(City_ID);
        com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = Convert.ToInt32(Company_ID);
        DataSet dsInformation = new DataSet();
        SqlDataAdapter sdaInformation = new SqlDataAdapter(com);
        sdaInformation.Fill(dsInformation);

        Label1.Text = "<table width=100% border=0 cellspacing=0 cellpadding=0  align=center><tr><td><br/></td></tr><tr align=center><td><h2>Cpp Details For " + dsInformation.Tables[0].Rows[0]["NAME"] + "(" + dsInformation.Tables[1].Rows[0]["City_Name"] + ")-" + dsInformation.Tables[2].Rows[0]["Company_Name"].ToString() + "</h2></td></tr><tr><td><br/></td></tr></table>";


        table = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";

        table = table + @"<tr> <td valign=top width=50%>" + table1 + "</td><td valign=top width=50%>" + table2 + "</td> </tr>";
        table = table + @"<tr><td valign=top width=100% colspan=2>" + table3 + " </td> ";
        table = table + @"</table>";






        Label2.Text = table;


        // end outer table




    }


}
