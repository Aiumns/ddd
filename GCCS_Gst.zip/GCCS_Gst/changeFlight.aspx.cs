using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class changeFlight : System.Web.UI.Page
{
    SqlConnection con = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString; 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {

            Label3.Visible = false;
        }
       
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    private void Search()
    {
        string flightDate = "";
        string Data = "";
        string airline = "";
        DataTable dt = dw.GetAllFromQuery("select airline_detail_id,AirWayBill_No,convert(varchar,flight_date,103) as flight_date,flight_no,destination_code,Charged_Weight from sales where AirWayBill_No='" + txtawb.Text.Trim() + "'");
        if (dt.Rows.Count > 0)
        {
            Data = "<Table align=center width=70%><tr class=h1><td>Awb No.</td><td>Dstn.</td><td>Ch.Wt.</td><td>Current Flight No.</td><td>Current Flight Date.</td></tr>";
            foreach (DataRow drow in dt.Rows)
            {
                Data += "<tr><td>" + drow["AirWayBill_No"].ToString() + "</td><td>" + drow["destination_code"].ToString() + "</td><td>" + drow["Charged_Weight"].ToString() + "</td><td>" + drow["flight_no"].ToString() + "</td><td>" + drow["flight_date"].ToString() + "</td></tr>";
                flightDate = drow["flight_date"].ToString();
                airline = drow["airline_detail_id"].ToString();
            }
            Data += "<tr><td></td><td></td><td></td><td></td><td></td></tr></table>";
            Label2.Text = Data;

            DataTable dt2 = dw.GetAllFromQuery("select Flight_no+'-'+convert(varchar,flight_date,103) as flight_date from Flight_Open inner join flight_master on Flight_Open.flight_id=flight_master.flight_id where flight_date between Convert(datetime,'" + FormatDateMM(flightDate) + "')-15 and Convert(datetime,'" + FormatDateMM(flightDate) + "')+15 and airline_detail_id="+Convert.ToInt64(airline) +"");
            ddlflight.Items.Clear();  
            foreach (DataRow Drow in dt2.Rows)
            {
                ddlflight.Items.Add(Drow["flight_date"].ToString());

            }
            Label3.Visible = false; 
            Panel1.Visible = true; 

        }
        else
        {
            Label3.Visible = false; 
            Panel1.Visible = false;
            Label2.Text = "";
            Label2.Text = "No Record Found";
            Label2.CssClass = "error";
            Label2.Visible = true;
            Label3.Visible = false;

        }
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string[] flight_date_no = ddlflight.SelectedItem.Text.Split('-');
        string query = "update sales set Flight_no='" + flight_date_no[0] + "-" + flight_date_no[1] + "',flight_date='" + FormatDateMM(flight_date_no[2]) + "' where AirWayBill_No='" + txtawb.Text.Trim() + "'";

        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = query;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            Label3.Visible = true;
            Panel1.Visible = false;
            Label2.Text = "";  
        }
        catch (Exception)
        {
                 
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }



   
    }
}
