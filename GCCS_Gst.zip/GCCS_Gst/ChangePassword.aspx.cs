using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class ChangePassword : System.Web.UI.Page
{
    //this form has disign by praveen singh
    //this form has coded by praveen singh
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString);
    SqlCommand cmd;
    SqlDataReader red;
    SqlParameter parm;
    public string email;
    public string pwd;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {


            int i;
            int loginmasterid = Convert.ToInt32(Session["Login_Master_ID"]);
            string email = Session["ID"].ToString();
            cmd = new SqlCommand("select Login_Master_ID,Email_ID,Login_Password  from Login_Master where Login_Master_ID=@Login_Master_ID ", cn);
            cmd.Parameters.AddWithValue("@Login_Master_ID", SqlDbType.Int).Value = Convert.ToInt32(loginmasterid);
            cn.Open();
            red = cmd.ExecuteReader();
            if (red.Read())
            {
                email = red["Email_ID"].ToString();
                pwd = red["Login_Password"].ToString();
                cn.Close();
                cmd.Dispose();
                red.Close();

                if (txtconfirmpassword.Text == txtNewpassword.Text)
                {
                    cmd = new SqlCommand("select Email_ID,Login_Password from  Login_Master where Email_ID=@Emailid and Login_Password=@password", cn);
                    cmd.Parameters.AddWithValue("@Emailid", email);
                    cmd.Parameters.AddWithValue("@password", txtoldpassword.Text);
                    cn.Open();
                    red = cmd.ExecuteReader();
                    if (red.HasRows)
                    {
                        cn.Close();
                        cmd.Dispose();
                        red.Close();
                        cmd = new SqlCommand("update Login_Master set Login_Password=@NewPassworld  where Login_Master_ID=@ID", cn);
                        cmd.Parameters.AddWithValue("@ID", SqlDbType.Int).Value = Convert.ToInt32(loginmasterid);
                        cmd.Parameters.AddWithValue("@NewPassworld", txtNewpassword.Text);
                        cn.Open();
                        cmd.ExecuteNonQuery();
                        cn.Close();
                        cmd.Dispose();
                        lblmsg.Visible = true;
                        lblmsg.Text = "Password has updated";

                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.Text = "Invalid User";
                        cn.Close();
                        cmd.Dispose();
                        red.Close();
                    }
                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "Confirm password and new password do not match";
                }
            }
        }
        catch (Exception)
        {

        }
        finally
        {
            if (cn != null && cn.State == ConnectionState.Open)
                cn.Close();
        }
    }
}