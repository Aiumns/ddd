using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class CrDrNote : System.Web.UI.Page
{
    public string page_pop = "";
    string agentName = null, lastTsdsRate = null;
    string lastSurcharge = null;
    string tableAll = null, comName = null;
    string massage = null;
    static string csrFooter = null;
    string city_id = null;

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;


    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {

                DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
                hdnDate.Value = first.ToString();
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");

                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();

                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 1;
                ddlMonth.Items[dt - 1].Selected = true;

                ShowAirline();
                if (Session["groupid"].ToString() != "5")
                {
                    ddlAirLine.AutoPostBack = true;
                    Pantab.Visible = true;

                }
                else
                {
                    Pantab.Visible = false;
                    ddlAirLine.AutoPostBack = false;
                    lstAgent.Items.Clear();
                    lstAgent.Items.Add(new ListItem(Session["AGENT_NAME"].ToString(), Session["ID"].ToString()));
                    lstAgent.Items[0].Selected = true;

                }

            }

        }

    }

    protected void ShowAirline()
    {

        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select airline name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            com.Dispose();
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        rbtnDSelect.Checked = true;
        rbtnSelectAll.Checked = false;
        string agentId = null;
        string bID = null;
        lstAgent.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select airline_id,belongs_to_city,Csr_Footer from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
            dr = com.ExecuteReader();
            if (dr.Read())
            {
                agentId = dr["airline_id"].ToString();
                bID = dr["belongs_to_city"].ToString();
                csrFooter = dr["Csr_Footer"].ToString();
                char ch = (char)System.Windows.Forms.Keys.Return;
                char ch2 = (char)System.Windows.Forms.Keys.Space;
                string ch1 = Convert.ToString(ch);
                string ch3 = Convert.ToString(ch2);
                csrFooter = csrFooter.Replace(ch1, "<br>");
                csrFooter = csrFooter.Replace(ch3, "&nbsp;");
            }
            dr.Dispose();
            com.Dispose();
            com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                lstAgent.Items.Add(new ListItem(dr["agent_name"].ToString(), dr["agent_id"].ToString()));
            }
            if (Session["groupid"].ToString() == "5")
            {
                lstAgent.SelectedIndex = lstAgent.Items.IndexOf(lstAgent.Items.FindByText(Session["AGENT_NAME"].ToString()));
            }
            dr.Close();
            com.Dispose();
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }


    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        string startDate = ddlMonth.SelectedValue + "/" + ((rbtnFirstFortn.Checked == true) ? "1" : "16") + "/" + ddlyear.SelectedValue;

        string endDate = ddlMonth.SelectedValue + "/" + ((rbtnFirstFortn.Checked == true) ? "15" : (Convert.ToDateTime(ddlMonth.SelectedValue + "/1/" + ddlyear.SelectedValue).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + ddlyear.SelectedValue;

        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();

        TextBox1.Text = startDate;
        TextBox2.Text = endDate;
        string agent_selected_id = "";
        string agent_selected_name = "";

        for (int i = 0; i < lstAgent.Items.Count; i++)
        {
            if (lstAgent.Items[i].Selected)
        {
                agent_selected_id = agent_selected_id + lstAgent.Items[i].Value + "~";
                agent_selected_name = agent_selected_name + lstAgent.Items[i].Text + "~";
            }
        }
        Session["airline_name"] = ddlAirLine.SelectedItem.Text;
        Session["airline_value"] = ddlAirLine.SelectedItem.Value;
        Session["StartDate"] = startDate;
        Session["EndDate"] = endDate;
        Session["Agent_List_value"] = agent_selected_id;
        Session["Agent_list_Text"] = agent_selected_name;
        //if (RadioButton1.Checked == true)
        //{
        //    Session["rdbtn1"] = RadioButton1.Text;
        //}
        //else
        //{
        //    Session["rdbtn1"] = RadioButton2.Text;
        //}

        Session["csr_footer"] = csrFooter;
        if (chkstatus.Checked == true)
        {
            Session["chkstatus"] = "Y";
        }
        else
        {
            Session["chkstatus"] = "N";
        }
        ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CRDR_generate.aspx');</script>");



    }

}
