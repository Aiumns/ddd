using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// Created By Rakhi
/// </summary>

public partial class Flight_SectorWise_Add : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    SqlTransaction trans = null;
    //string Sector_ID;
    public int id;
    string ts1;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack && Request.QueryString["Flight_Sector_ID"] != null)
        {
            btnupdate.Attributes.Add("onclick", "return CheckEmpty()");
            btnupdate.Visible = true;
            btnadd.Visible = false;
            lblAdd.Visible = false;
            lblUpdate.Visible = true;
            ddlFlight.Enabled = false;
            Label8.Visible = false;
            if (!Page.IsPostBack)
            {
                FillFlight();
                FillSector();
                selectData();
            }
        }
        else
        {
            btnupdate.Visible = false;
            btnadd.Visible = true;
            lblAdd.Visible = true;
            lblUpdate.Visible = false;
            btnadd.Attributes.Add("onclick", "return CheckEmpty()");
            if (!Page.IsPostBack)
            {
                FillFlight();
                FillSector();
            }
            //lblHead.Text = "ADD SUBCATEGORY";
            //btnSubmit.Text = "Add";

        }

        //if (!IsPostBack && Request.QueryString["Flight_Sector_ID"] != null)
        //{
        //    btnadd.Visible = false;
        //    btnupdate.Visible = true;
        //    btnupdate.Attributes.Add("onclick", "return CheckEmpty()");
        //    ddlFlight.Enabled = false;
        //    selectData();
        //    //ddlFlight.SelectedIndex = ddlFlight.Items.IndexOf(ddlFlight.Items.FindByValue(id));
        //}
        //else
        //{
        //    btnadd.Visible = true;
        //    btnupdate.Visible = false;
        //    btnadd.Attributes.Add("onclick", "return CheckEmpty()");
        //    if (!IsPostBack)
        //    {
        //        FillFlight();
        //        FillSector();
        //    }   

       
     

        //}    
       
       
       

    }
    private void FillFlight()
    {
        con = new SqlConnection(strCon);
        SqlCommand com = new SqlCommand("select * from Flight_Master fm inner join Airline_Detail ad on fm.Airline_Detail_ID=ad.Airline_Detail_ID ", con);
        //SqlCommand com = new SqlCommand("select * from Flight_Master ", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        //ddlFlight.Items.Add("--Select--");
        ddlFlight.Items.Add(new ListItem("--Select--", "y"));
        //ddlFlight.Items[0].Value = "";
        while (dr.Read())
        {

            ddlFlight.Items.Add(new ListItem(dr["Flight_No"].ToString(), dr["Flight_ID"].ToString()));
        }
        dr.Close();
        con.Close();
    }
    private void FillSector()
    {
        con = new SqlConnection(strCon);
        if (ddlFlight.SelectedValue.Equals("y"))
        {
            lstSector.Enabled = false;
        }
        else
        {
            lstSector.Enabled = true;            
            string Str_id = ddlFlight.SelectedValue.ToString();
            con = new SqlConnection(strCon);
            //SqlCommand com = new SqlCommand("select * from Airline_Sector_Master ", con);
            SqlCommand com = new SqlCommand("select * from Flight_Master F inner join Airline_Detail A on F.Airline_Detail_ID = A.Airline_Detail_ID inner join Airline_Sector_Master S on A.Airline_ID = S.Airline_ID where flight_ID=" + Str_id + "  ", con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            lstSector.Items.Clear();
            //lstSector.Items.Add("--Select--");
            //lstSector.Items[0].Value = "";
            while (dr.Read())
            {                
                lstSector.Items.Add(new ListItem(dr["Sector_Name"].ToString(), dr["Sector_ID"].ToString()));
             }
            dr.Close();
            con.Close();
            
        }
        //con.Close();
    }
    protected void ddlFlight_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillSector();
        lblError.Text = "";
    }
   
    protected void btnadd_Click(object sender, EventArgs e)
    {
        add12();       
    }

    private void add12()
    {       
        con = new SqlConnection(strCon);
        string str1 = "";
        string ts1;
        //string insert1;
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            str1 = "select * from Flight_Sectorwise where Flight_ID=" + ddlFlight.SelectedValue + " and Sector_ID='" + lstSector.SelectedValue + "'";
            //str1 = "select * from Company_Master where Company_Email='" + txtCompanyEmail.Text + "'";
            da = new SqlDataAdapter(str1, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblError.Text = "Records already exist";
            }
            else
            {
                string insert2;
                con = new SqlConnection(strCon);//Making Connection
                try
                {
                    con.Open();
                    trans = con.BeginTransaction();                                                                         // Insert Value in Airline_Detail table
                    SqlCommand com;  
              
                    for (int i = 0; i < lstSector.Items.Count; i++)    // values store in listbox
                    {                       
                            if (lstSector.Items[i].Selected)
                            {

                                ts1 = lstSector.Items[i].Value;
                                insert2 = "insert into Flight_Sectorwise(Flight_ID,Sector_ID) values('" + ddlFlight.SelectedValue + "','" + ts1 + "')";                               
                                com = new SqlCommand(insert2, con, trans);                            
                                com.ExecuteNonQuery();
                            }                     
                        }
                    trans.Commit();
                    con.Close();
                    Response.Redirect("Flight_SectorWise_Details.aspx");
                }
                catch (SqlException se)
                {
                    string err = se.Message;
                    trans.Rollback();
                    lblError.Text = err;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            Response.Write(er);
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string update1;
        string str1 = "";
        string ts1;
        //string insert1; 
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            str1 = "select * from Flight_Sectorwise where Flight_ID=" + ddlFlight.SelectedValue + " and Sector_ID='" + lstSector.SelectedValue + "'";
            //str1 = "select * from Company_Master where Company_Email='" + txtCompanyEmail.Text + "'";
            da = new SqlDataAdapter(str1, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblError.Text = "Records already exist";
            }
            else
            {

                for (int i = 0; i < lstSector.Items.Count; i++)    // values store in listbox
                {
                    if (lstSector.Items[i].Selected)
                    {
                        ts1 = lstSector.Items[i].Value;
                        long Flight_Sector_ID = Convert.ToInt64(Request.QueryString["Flight_Sector_ID"]);
                        update1 = "update Flight_Sectorwise set Flight_ID=@Flight_ID,Sector_ID=@Sector_ID where Flight_Sector_ID=" + Flight_Sector_ID + "";

                        SqlCommand com = new SqlCommand(update1, con);
                        com.CommandType = CommandType.Text;
                        com.Parameters.AddWithValue("@Flight_ID", ddlFlight.SelectedValue);
                        com.Parameters.AddWithValue("@Sector_ID", lstSector.SelectedValue);
                        com.ExecuteNonQuery();
                    }
                }
                con.Close();
                //cmd.Connection.Close();
                //Clear();
                Response.Redirect("Flight_SectorWise_Details.aspx");
            }
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }  
    }
    
    public void selectData()
    {
        string FId = "";

        con = new SqlConnection(strCon);
        con.Open();

        string Flight_Sector_ID = Convert.ToString(Request.QueryString["Flight_Sector_ID"]);
        DataTable dtAirline = new DataTable();
        cmd = new SqlCommand("select * from Flight_Sectorwise where Flight_Sector_ID='" + Flight_Sector_ID + "'");
        cmd.Connection = con;
        da = new SqlDataAdapter(cmd);
        da.Fill(dtAirline);
        if (dtAirline.Rows.Count > 0)
        {
            //ddlFlight.SelectedValue = dtAirline.Rows[0]["Flight_ID"].ToString();
            lstSector.SelectedValue = dtAirline.Rows[0]["Sector_ID"].ToString();
            FId = dtAirline.Rows[0]["Flight_ID"].ToString();
        }
        FillFlight();
        ddlFlight.SelectedIndex = ddlFlight.Items.IndexOf(ddlFlight.Items.FindByValue(FId));
        FillSector();      

        con.Close();
        cmd.Dispose();

    }    

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Flight_SectorWise_Details.aspx");
    }
}
