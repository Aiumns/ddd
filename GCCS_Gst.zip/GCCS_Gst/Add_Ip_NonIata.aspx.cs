﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Add_Ip_NonIata : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string CompGstNo = "07";
    string AgentGstNo = "08";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        LoadGstStateCode();
        Button2.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        //string flight_id= Request["hid"].ToString();
        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////DataTable dtStaxRate = dw.GetAllFromQuery("SELECT TDS_Id,Stax,Education_Cess,SB_Cess,HigherEducation_Cess FROM tds_Fedex WHERE GETDATE() BETWEEN Valid_From AND Valid_To");
        #region Gst/Tax Calcuclation Convert into LoadStax() function
        ////DataTable dtStaxRate = dw.GetAllFromQuery("SELECT TDS_Id,Stax,Education_Cess,IsNull(SB_Cess,0) as SB_Cess,IsNull(KK_Cess,0) as KK_Cess,HigherEducation_Cess FROM tds_Fedex WHERE GETDATE() BETWEEN Valid_From AND Valid_To");
        ////if (dtStaxRate.Rows.Count > 0)
        ////{
        ////     #region GST Applicable from 01 1 Apr 2017
        ////    if (GstRadioButtonList.SelectedIndex == 0)
        ////    {
        ////        txtBStaxRate.Text = dtStaxRate.Rows[0]["Stax"].ToString();
        ////        txtBSBcesRate.Text = dtStaxRate.Rows[0]["SB_Cess"].ToString();
        ////        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////        txtBKKcesRate.Text = "0.00";
        ////        txtSellStaxRate.Text = dtStaxRate.Rows[0]["Stax"].ToString();
        ////        txtSellSBcesRate.Text = dtStaxRate.Rows[0]["SB_Cess"].ToString();
        ////        txtSellKKcesRate.Text = "0.00"; 
        ////        txtBeduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtSelEduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtBHeduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////        txtSelHEduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////    }
        ////    else
        ////    {
        ////        txtBStaxRate.Text = "0.00";
        ////        txtBSBcesRate.Text = "0.00";
        ////        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////        txtBKKcesRate.Text = dtStaxRate.Rows[0]["KK_Cess"].ToString();
        ////        txtSellStaxRate.Text = "0.00";
        ////        txtSellSBcesRate.Text = "0.00";
        ////        txtSellKKcesRate.Text = dtStaxRate.Rows[0]["KK_Cess"].ToString();
        ////        txtBeduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtSelEduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtBHeduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////        txtSelHEduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////    }
        ////     #endregion
        ////}
        ////else
        ////{
        ////      #region GST Applicable from 01 1 Apr 2017
        ////    if (GstRadioButtonList.SelectedIndex == 0)
        ////    {
        ////        txtBSBcesRate.Text = "9.00";
        ////        txtBKKcesRate.Text = "0.00";
        ////        txtBStaxRate.Text = "9.00";
        ////        txtSellStaxRate.Text = "9.00";
        ////        txtBeduCessRate.Text = "2";
        ////        txtSelEduCessRate.Text = "2";
        ////        txtBHeduCessRate.Text = "1";
        ////        txtSelHEduCessRate.Text = "1";
        ////    }
        ////    else
        ////    {
        ////        txtBSBcesRate.Text = "0.00";
        ////        txtBKKcesRate.Text = "18.00";
        ////        txtBStaxRate.Text = "0.00";
        ////        txtSellStaxRate.Text = "0.00";
        ////        txtBeduCessRate.Text = "2";
        ////        txtSelEduCessRate.Text = "2";
        ////        txtBHeduCessRate.Text = "1";
        ////        txtSelHEduCessRate.Text = "1";
        ////    }
        ////      #endregion
        ////}
        #endregion

        LoadStax();
        if ((Request["sno"] != null) && (!IsPostBack))
        {
            LoadAgentName();
            LoadDestination();
            LoadModify();
            Button2.Text = "Update";
        }
        else
        {
            if (Request["hid"] != null)
            {
                LoadDestination();
                //LoadShipmentType();
                LoadAgentName();
                if (!IsPostBack)
                {
                    awbdate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    handdate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    flightdate.Text = Request["par"].ToString();
                    flightdate.Enabled = false;
                    DataTable dt = dw.GetAllFromQuery("select * from flight_master inner join flight_open on flight_open.Flight_id=flight_master.Flight_id inner join city_master on Flight_Master.origin=city_master.city_id where Flight_open_id=" + Convert.ToInt64(Request["hid"].ToString()) + "");
                    ViewState["Airline_Detail_ID"] = dt.Rows[0]["Airline_Detail_ID"].ToString();
                    txtorigin.Text = dt.Rows[0]["City_name"].ToString();
                    origin_id.Value = dt.Rows[0]["City_id"].ToString();
                    txtflightno.Text = Request["flhid"].ToString();
                    txtselrate.Text = "0";
                    txtsamount.Text = "0";
                    txtbuyamt.Text = "0";
                    ////txtbuyrate.Text = "0";
                    txtchwt.Text = "0";
                }
            }
            else
            {
            }
        }
    }
    public void LoadDestination()
    {
        try
        {
            string strAgent = "";
            //strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=152";
            strAgent = "select country_code,Destination_Code,Destination_Name,Destination_ID from destination_master order by country_code";
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand(strAgent, con);
            SqlDataReader dr = cmd.ExecuteReader();
            dlldest.Items.Clear();
            dlldest.Items.Insert(0, "- -Select- -");
            //ddlDestination.Items.Insert(0, "- -Select- -");
            //ddlDestination.Items[0].Value = "0";
            while (dr.Read())
            {
                dlldest.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadShipmentType()
    {
        try
        {
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand(strAgent, con);
            SqlDataReader dr = cmd.ExecuteReader();
            dllspt.Items.Insert(0, "- -Select- -");
            dllspt.Items[0].Value = "0";
            while (dr.Read())
            {
                dllspt.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadAgentName()
    {
        try
        {
            string strAgent = "SELECT DISTINCT am.Agent_Name,am.Sno,am.Agent_Name,Gst_No,Gst_Address,City_Name FROM IP_Agent am inner join city_master cm on am.Agent_City=cm.city_id  WHERE Agent_City in (6,2) ORDER BY am.Agent_Name";
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand(strAgent, con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlAgentName.Items.Insert(0, "- -Select- -");
            ddlAgentName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAgentName.Items.Add(new ListItem(dr["Agent_Name"].ToString() + "-" + dr["City_Name"].ToString().ToUpper(), dr["sno"].ToString()));
                ////ddlGst.Items.Add(new ListItem(dr["Gst_No"].ToString() + "-" + dr["Gst_Address"].ToString().ToUpper(), dr["Gst_No"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    private void insertToTable()
    {
        /////DataTable dtairline_detail_id = dw.GetAllFromQuery("select Airline_detail_id from Airline_detail where belongs_to_city=" + txtorigin.text + "");
        ////string query = @"insert into FedexIP_NONIATA(TRK,Account,awbNo,awbDt,UpliftmentDt,handoverDt,agent_id,origin,dstnCd,actualdstn,shptType,basicRate,sellingRate,buyingRate,fscRate,staxRate,DG_Surcharge,sellingAmt,fscAmt,staxAmt,buyingAmt,pcs,Gross_wt,chargeable_wt,fltNo,fltDt,shipper,consignee,remarks,entered_by,entered_at,modified_by,modified_at) values(@TRK,@Account,@awbNo,@awbDt,@UpliftmentDt,@handoverDt,@agent_id,@origin,@dstnCd,@actualdstn,@shptType,@basicRate,@sellingRate,@buyingRate,@fscRate,@staxRate,@DG_Surcharge,@sellingAmt,@fscAmt,@staxAmt,@buyingAmt,@pcs,@Gross_wt,@chargeable_wt,@fltNo,@fltDt,@shipper,@consignee,@remarks,@entered_by,@entered_at,@modified_by,@modified_at)";
        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////string query = @"insert into FedexIP_NONIATA(TRK,Account,awbNo,awbDt,UpliftmentDt,handoverDt,agent_id,origin,dstnCd,actualdstn,shptType,basicRate,sellingRate,BuyingfscRate,BuyingstaxRate,SellingfscRate,SellingstaxRate,BuyingDG_Surcharge,SellingDG_Surcharge,sellingAmtBeforStax,BuyingfscAmt,BuyingstaxAmt,SellingfscAmt,SellingstaxAmt,buyingAmtBeforStax,pcs,Gross_wt,chargeable_wt,fltNo,fltDt,shipper,consignee,remarks,entered_by,entered_at,modified_by,modified_at,GrandSellingAmt,GrandBuyingAmt,BuyingEduCessRate,SellingEduCessRate,BuyingHEduCessRate,SellingHEduCessRate,BuyingEduCessAmt,SellingEduCessAmt,BuyingHEduCessAmt,SellingHEduCessAmt,BuyingOtherChrgs,SellingOtherChrgs,GrandBuyingStaxAmt,GrandSellingStaxAmt,Airline_Detail_ID,BuyingSBCessRate,SellingSBCessRate,BuyingSBCessAmt,SellingSBCessAmt) values(@TRK,@Account,@awbNo,@awbDt,@UpliftmentDt,@handoverDt,@agent_id,@origin,@dstnCd,@actualdstn,@shptType,@basicRate,@sellingRate,@BuyingfscRate,@BuyingstaxRate,@SellingfscRate,@SellingstaxRate,@BuyingDG_Surcharge,@SellingDG_Surcharge,@sellingAmtBeforStax,@BuyingfscAmt,@BuyingstaxAmt,@SellingfscAmt,@SellingstaxAmt,@buyingAmtBeforStax,@pcs,@Gross_wt,@chargeable_wt,@fltNo,@fltDt,@shipper,@consignee,@remarks,@entered_by,@entered_at,@modified_by,@modified_at,@GrandSellingAmt,@GrandBuyingAmt,@BuyingEduCessRate,@SellingEduCessRate,@BuyingHEduCessRate,@SellingHEduCessRate,@BuyingEduCessAmt,@SellingEduCessAmt,@BuyingHEduCessAmt,@SellingHEduCessAmt,@BuyingOtherChrgs,@SellingOtherChrgs,@GrandBuyingStaxAmt,@GrandSellingStaxAmt,@Airline_Detail_ID,@BuyingSBCessRate,@SellingSBCessRate,@BuyingSBCessAmt,@SellingSBCessAmt)";
        string query = @"insert into FedexIP_NONIATA(TRK,Account,awbNo,awbDt,UpliftmentDt,handoverDt,agent_id,origin,dstnCd,actualdstn,shptType,basicRate,sellingRate,BuyingfscRate,BuyingstaxRate,SellingfscRate,SellingstaxRate,BuyingDG_Surcharge,SellingDG_Surcharge,sellingAmtBeforStax,BuyingfscAmt,BuyingstaxAmt,SellingfscAmt,SellingstaxAmt,buyingAmtBeforStax,pcs,Gross_wt,chargeable_wt,fltNo,fltDt,shipper,consignee,remarks,entered_by,entered_at,modified_by,modified_at,GrandSellingAmt,GrandBuyingAmt,BuyingEduCessRate,SellingEduCessRate,BuyingHEduCessRate,SellingHEduCessRate,BuyingEduCessAmt,SellingEduCessAmt,BuyingHEduCessAmt,SellingHEduCessAmt,BuyingOtherChrgs,SellingOtherChrgs,GrandBuyingStaxAmt,GrandSellingStaxAmt,Airline_Detail_ID,BuyingSBCessRate,BuyingKKCessRate,SellingSBCessRate,SellingKKCessRate,BuyingSBCessAmt,BuyingKKCessAmt,SellingSBCessAmt,SellingKKCessAmt,Gst_Type,GstNo,StateCode) values(@TRK,@Account,@awbNo,@awbDt,@UpliftmentDt,@handoverDt,@agent_id,@origin,@dstnCd,@actualdstn,@shptType,@basicRate,@sellingRate,@BuyingfscRate,@BuyingstaxRate,@SellingfscRate,@SellingstaxRate,@BuyingDG_Surcharge,@SellingDG_Surcharge,@sellingAmtBeforStax,@BuyingfscAmt,@BuyingstaxAmt,@SellingfscAmt,@SellingstaxAmt,@buyingAmtBeforStax,@pcs,@Gross_wt,@chargeable_wt,@fltNo,@fltDt,@shipper,@consignee,@remarks,@entered_by,@entered_at,@modified_by,@modified_at,@GrandSellingAmt,@GrandBuyingAmt,@BuyingEduCessRate,@SellingEduCessRate,@BuyingHEduCessRate,@SellingHEduCessRate,@BuyingEduCessAmt,@SellingEduCessAmt,@BuyingHEduCessAmt,@SellingHEduCessAmt,@BuyingOtherChrgs,@SellingOtherChrgs,@GrandBuyingStaxAmt,@GrandSellingStaxAmt,@Airline_Detail_ID,@BuyingSBCessRate,@BuyingKKCessRate,@SellingSBCessRate,@SellingKKCessRate,@BuyingSBCessAmt,@BuyingKKCessAmt,@SellingSBCessAmt,@SellingKKCessAmt,@Gst_Type,@GstNo,@StateCode)";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand(query, con);
            // cmd.Parameters.AddWithValue("@billing_company_code",);  
            cmd.Parameters.AddWithValue("@TRK", txtTRK.Text.Trim());
            cmd.Parameters.AddWithValue("@Account", txtAccount.Text.Trim());
            cmd.Parameters.AddWithValue("@awbNo", txtawbno.Text.Trim());
            cmd.Parameters.AddWithValue("@awbDt", FormatDateMM(awbdate.Text.Trim()));
            cmd.Parameters.AddWithValue("@UpliftmentDt", FormatDateMM(txtUpliftmentDate.Text.Trim()));
            cmd.Parameters.AddWithValue("@handoverDt", FormatDateMM(handdate.Text.Trim()));
            cmd.Parameters.AddWithValue("@agent_id", ddlAgentName.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@origin", origin_id.Value.Trim());
            cmd.Parameters.AddWithValue("@dstnCd", dlldest.SelectedValue.ToString().Trim());
            cmd.Parameters.AddWithValue("@actualdstn", txtdtd.Text);
            cmd.Parameters.AddWithValue("@shptType", dllspt.SelectedValue.ToString().Trim());
            decimal b_rate = (txtbasicRate.Text.Trim() == "" ? 0 : decimal.Parse(txtbasicRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@basicRate", b_rate);
            decimal selling_rate = (txtselrate.Text.Trim() == "" ? 0 : decimal.Parse(txtselrate.Text.Trim()));
            cmd.Parameters.AddWithValue("@sellingRate", selling_rate);
            ////decimal spot_rate = (txtbuyrate.Text.Trim() == "" ? 0 : decimal.Parse(txtbuyrate.Text.Trim()));
            ////cmd.Parameters.AddWithValue("@buyingRate", spot_rate);
            decimal Buyingfsc_rate = (txtBFSCRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBFSCRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingfscRate", Buyingfsc_rate);
            decimal Buyingstax_rate = (txtBStaxRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBStaxRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingstaxRate", Buyingstax_rate);
            decimal Sellingfsc_rate = (txtSFSCRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSFSCRate.Text.Trim()));
            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            decimal BuyingSBCess_rate = (txtBSBcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBSBcesRate.Text.Trim()));
            decimal BuyingKKCess_rate = (txtBKKcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBKKcesRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingSBCessRate", BuyingSBCess_rate);
            cmd.Parameters.AddWithValue("@BuyingKKCessRate", BuyingKKCess_rate);

            cmd.Parameters.AddWithValue("@SellingfscRate", Sellingfsc_rate);
            decimal Sellingstax_rate = (txtSellStaxRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSellStaxRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingstaxRate", Sellingstax_rate);
            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            decimal SellingSBCess_rate = (txtSellSBcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSellSBcesRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingSBCessRate", SellingSBCess_rate);
            decimal SellingKKCess_rate = (txtSellKKcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSellKKcesRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingKKCessRate", SellingKKCess_rate);

            decimal Buyingdg_sur = (txtBuyDgSurcharge.Text.Trim() == "" ? 0 : decimal.Parse(txtBuyDgSurcharge.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingDG_Surcharge", Buyingdg_sur);
            decimal Sellingdg_sur = (txtSellingDgSurcharge.Text.Trim() == "" ? 0 : decimal.Parse(txtSellingDgSurcharge.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingDG_Surcharge", Sellingdg_sur);
            decimal selling_amt = (txtsamount.Text.Trim() == "" ? 0 : decimal.Parse(txtsamount.Text.Trim()));
            cmd.Parameters.AddWithValue("@sellingAmtBeforStax", selling_amt);
            decimal Buyingfsc_amt = (txtBFSCAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBFSCAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingfscAmt", Buyingfsc_amt);
            decimal Buyingstax_amt = (txtBServiceTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBServiceTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingstaxAmt", Buyingstax_amt);
            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            decimal BuyingSBCess_amt = (txtBSBcessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBSBcessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingSBCessAmt", BuyingSBCess_amt);

            decimal BuyingKKCess_amt = (txtBKKcessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBKKcessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingKKCessAmt", BuyingKKCess_amt);

            decimal Sellingfsc_amt = (txtSFSCAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSFSCAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingfscAmt", Sellingfsc_amt);
            decimal Sellingstax_amt = (txtSellServiceTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSellServiceTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingstaxAmt", Sellingstax_amt);

            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************

            decimal SellingSBCess_amt = (txtSellSBCessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSellSBCessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingSBCessAmt", SellingSBCess_amt);

            decimal SellingKKCess_amt = (txtSellKKCessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSellKKCessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingKKCessAmt", SellingKKCess_amt);

            decimal buyingg_amt = (txtbuyamt.Text.Trim() == "" ? 0 : decimal.Parse(txtbuyamt.Text.Trim()));
            cmd.Parameters.AddWithValue("@buyingAmtBeforStax", buyingg_amt);
            int pcs = (txtpcs.Text.Trim() == "" ? 0 : int.Parse(txtpcs.Text.Trim()));
            cmd.Parameters.AddWithValue("@pcs", pcs);
            decimal gwt = (txtGrwt.Text.Trim() == "" ? 0 : decimal.Parse(txtGrwt.Text.Trim()));
            cmd.Parameters.AddWithValue("@Gross_wt", gwt);
            decimal chwt = (txtchwt.Text.Trim() == "" ? 0 : decimal.Parse(txtchwt.Text.Trim()));
            cmd.Parameters.AddWithValue("@chargeable_wt", chwt);
            cmd.Parameters.AddWithValue("@fltNo", txtflightno.Text.Trim());
            cmd.Parameters.AddWithValue("@fltDt", FormatDateMM(flightdate.Text.Trim()));
            cmd.Parameters.AddWithValue("@shipper", txtshpr.Text.Trim());
            cmd.Parameters.AddWithValue("@consignee", txtcons.Text.Trim());
            cmd.Parameters.AddWithValue("@remarks", txtremarks.Text.Trim());
            cmd.Parameters.AddWithValue("@entered_by", Session["EMailID"].ToString());
            cmd.Parameters.AddWithValue("@entered_at", DateTime.Now);
            cmd.Parameters.AddWithValue("@modified_by", Session["EMailID"].ToString());
            cmd.Parameters.AddWithValue("@modified_at", DateTime.Now);
            //TotalSellingAmt,TotalBuyingAmt,BuyingEduCessRate,SellingEduCessRate,BuyingHEduCessRate,SellingHEduCessRate,BuyingEduCessAmt,SellingEduCessAmt,BuyingHEduCessAmt,SellingHEduCessAmt
            decimal GrandSellingAmt = (txtTotalSellingAmtStax.Text.Trim() == "" ? 0 : decimal.Parse(txtTotalSellingAmtStax.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandSellingAmt", GrandSellingAmt);
            decimal GrandBuyingAmt = (txtTotalBuyingAmtStax.Text.Trim() == "" ? 0 : decimal.Parse(txtTotalBuyingAmtStax.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandBuyingAmt", GrandBuyingAmt);
            decimal BuyingEduCessRate = (txtBeduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBeduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingEduCessRate", BuyingEduCessRate);
            decimal SellingEduCessRate = (txtSelEduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSelEduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingEduCessRate", SellingEduCessRate);
            decimal BuyingHEduCessRate = (txtBHeduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBHeduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingHEduCessRate", BuyingHEduCessRate);
            decimal SellingHEduCessRate = (txtSelHEduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSelHEduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingHEduCessRate", SellingHEduCessRate);
            decimal BuyingEduCessAmt = (txtBEduCessAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtBEduCessAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingEduCessAmt", BuyingEduCessAmt);
            decimal SellingEduCessAmt = (txtSellEduCessAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtSellEduCessAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingEduCessAmt", SellingEduCessAmt);
            decimal BuyingHEduCessAmt = (txtBHEduCessAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtBHEduCessAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingHEduCessAmt", BuyingHEduCessAmt);
            decimal SellingHEduCessAmt = (txtSellHEduCess.Text.Trim() == "" ? 0 : decimal.Parse(txtSellHEduCess.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingHEduCessAmt", SellingHEduCessAmt);
            decimal BuyingOtherChrgs = (txtBOther.Text.Trim() == "" ? 0 : decimal.Parse(txtBOther.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingOtherChrgs", BuyingOtherChrgs);
            decimal SellingOtherChrgs = (txtSOther.Text.Trim() == "" ? 0 : decimal.Parse(txtSOther.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingOtherChrgs", SellingOtherChrgs);
            decimal GrandBuyingStaxAmt = (txtBuyingStaxAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtBuyingStaxAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandBuyingStaxAmt", GrandBuyingStaxAmt);
            decimal GrandSellingStaxAmt = (txtSellingStaxAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtSellingStaxAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandSellingStaxAmt", GrandSellingStaxAmt);
            cmd.Parameters.AddWithValue("@Airline_Detail_ID", Convert.ToInt32(ViewState["Airline_Detail_ID"]));
            //Gst Applicable
            cmd.Parameters.AddWithValue("@GST_Type", GstRadioButtonList.SelectedItem.Text);

            cmd.Parameters.Add("@StateCode", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
            if (txtGstNo.Text == "")
            {
                cmd.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
            }
            else
            {
                cmd.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = txtGstNo.Text;
            }
            //End of Gst Applicable

            cmd.ExecuteNonQuery();
            con.Close();
            cmd.Dispose();



            #region Generate Invoice No for GST effecting 01 Apr 2017

            string Flight_date = flightdate.Text;
            string[] dateSplit = Flight_date.Split('/');
            string Month = dateSplit[1].ToString();
            string Year = dateSplit[2].ToString();
            string Date1 = dateSplit[0].ToString();
            string currentdate = Month + "/" + Date1 + "/" + Year;
            string FinYear = Year.Substring(2, 2);
            // string dateCurrent = DateTime.Now.ToShortDateString();

            DateTime CurrDate = Convert.ToDateTime(currentdate);
            string DateFinancial = "4/1/20" + FinYear + "";
            DateTime FinanciaDate = DateTime.Parse(DateFinancial);


            if (CurrDate < FinanciaDate)
            {
                FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
            }
            else
            {
                FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
            }
            //*********************End***************************************************************

            //*******************End****************************************

            string Lastdate = "";
            bool flagInvoice = false;
            if (int.Parse(Date1) < 16)
            {
                Date1 = "1";
                flagInvoice = true;
            }
            else
            {
                Date1 = "16";
            }

            //for (int year = 2006; year <= DateTime.Today.Year; year++)
            //    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
            // string Year = DateTime.Today.Year.ToString();

            string startDate = Month + "/" + Date1 + "/" + Year;
            string endDate = Month + "/" + (flagInvoice ? "15" : (Convert.ToDateTime(Month + "/1/" + Year).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + Year;

            ////DataTable dtInvPrFx = dw.GetAllFromQuery("select prifix from Invoice_no where airline_detail_id=" + ddlAirline.SelectedValue + "");

            ///**************************************end of invoice function **********************************
            #endregion

            #region Invoiceno Generation For GST effecting 01 Apr 2017
            DataTable dtInvoiceNo = new DataTable();
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmd1;
            cmd1 = new SqlCommand("InsertInvoiceno_FedexIP_NONIATA", con);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.Add("@agent_id ", SqlDbType.BigInt).Value = ddlAgentName.SelectedValue.ToString();
            cmd1.Parameters.Add("@startDate ", SqlDbType.VarChar).Value = startDate;
            cmd1.Parameters.Add("@endDate ", SqlDbType.VarChar).Value = endDate;
            cmd1.Parameters.Add("@Fin_Year ", SqlDbType.VarChar).Value = FinYear;
            cmd1.Parameters.Add("@awbno", SqlDbType.VarChar).Value = txtawbno.Text.Trim();

            cmd1.Parameters.Add("@AirlineID", SqlDbType.Int).Value = int.Parse(ViewState["Airline_Detail_ID"].ToString());
            cmd1.ExecuteNonQuery();
            con.Close();
            #endregion



            Response.Redirect("Browse_ip_NonIata.aspx?cub=asdgagdsajdgjsagdjga");
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if (Convert.ToDateTime(FormatDateMM(flightdate.Text)) >= Convert.ToDateTime("07/01/2017"))
        {
            if (txtGstNo.Text == "" && ddlGstStateCode.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412');</script>");
                txtGstNo.Focus();
                return;
            }
        }
        if (Request["sno"] == null)
        {
            DataTable dt = dw.GetAllFromQuery("Select awbNo from FedexIP_NONIATA where awbNo='" + txtawbno.Text.Trim() + "'");
            if (dt.Rows.Count > 0)
            {
                lblErr.Visible = true;
                lblErr.Text = "Awb No Already Exist.";
            }
            else
            {
                insertToTable();
            }
        }
        else
        {
            DataTable dt = dw.GetAllFromQuery("Select awbNo from FedexIP_NONIATA where awbNo='" + txtawbno.Text.Trim() + "'AND SNO NOT IN(" + Request["sno"].ToString() + ")");
            if (dt.Rows.Count > 0)
            {
                lblErr.Visible = true;
                lblErr.Text = "Awb No Already Exist.";
            }
            else
            {
                Modify();
            }
        }
    }

    private void Modify()
    {

        ////string Query = @"update FedexIP_NONIATA set TRK=@TRK,Account=@Account,awbNo=@awbNo,awbDt=@awbDt,UpliftmentDt=@UpliftmentDt,handoverDt=@handoverDt,agent_id=@agent_id,origin=@origin,dstnCd=@dstnCd,actualdstn=@actualdstn,shptType=@shptType,basicRate=@basicRate,DG_Surcharge=@DG_Surcharge,sellingRate=@sellingRate,buyingRate=@buyingRate,fscRate=@fscRate,staxRate=@staxRate,sellingAmt=@sellingAmt,fscAmt=@fscAmt,staxAmt=@staxAmt,buyingAmt=@buyingAmt,pcs=@pcs,Gross_wt=@Gross_wt,chargeable_wt=@chargeable_wt,fltNo=@fltNo,fltDt=@fltDt,shipper=@shipper,consignee=@consignee,remarks=@remarks,modified_by=@modified_by,modified_at=@modified_at where sno=" + Convert.ToInt64(Request["sno"].ToString()) + "";

        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////string Query = @"update FedexIP_NONIATA set TRK=@TRK,Account=@Account,awbNo=@awbNo,awbDt=@awbDt,UpliftmentDt=@UpliftmentDt,handoverDt=@handoverDt,agent_id=@agent_id,origin=@origin,dstnCd=@dstnCd,actualdstn=@actualdstn,shptType=@shptType,basicRate=@basicRate,sellingRate=@sellingRate,BuyingfscRate=@BuyingfscRate,BuyingstaxRate=@BuyingstaxRate,SellingfscRate=@SellingfscRate,SellingstaxRate=@SellingstaxRate,BuyingDG_Surcharge=@BuyingDG_Surcharge,SellingDG_Surcharge=@SellingDG_Surcharge,sellingAmtBeforStax=@sellingAmtBeforStax,BuyingfscAmt=@BuyingfscAmt,BuyingstaxAmt=@BuyingstaxAmt,SellingfscAmt=@SellingfscAmt,SellingstaxAmt=@SellingstaxAmt,buyingAmtBeforStax=@buyingAmtBeforStax,pcs=@pcs,Gross_wt=@Gross_wt,chargeable_wt=@chargeable_wt,fltNo=@fltNo,fltDt=@fltDt,shipper=@shipper,consignee=@consignee,remarks=@remarks,entered_by=@entered_by,entered_at=@entered_at,modified_by=@modified_by,modified_at=@modified_at,GrandSellingAmt=@GrandSellingAmt,GrandBuyingAmt=@GrandBuyingAmt,BuyingEduCessRate=@BuyingEduCessRate,SellingEduCessRate=@SellingEduCessRate,BuyingHEduCessRate=@BuyingHEduCessRate,SellingHEduCessRate=@SellingHEduCessRate,BuyingEduCessAmt=@BuyingEduCessAmt,SellingEduCessAmt=@SellingEduCessAmt,BuyingHEduCessAmt=@BuyingHEduCessAmt,SellingHEduCessAmt=@SellingHEduCessAmt,BuyingOtherChrgs=@BuyingOtherChrgs,SellingOtherChrgs=@SellingOtherChrgs,GrandBuyingStaxAmt=@GrandBuyingStaxAmt,GrandSellingStaxAmt=@GrandSellingStaxAmt,Airline_Detail_ID=@Airline_Detail_ID,BuyingSBCessRate=@BuyingSBCessRate,SellingSBCessRate=@SellingSBCessRate,BuyingSBCessAmt=@BuyingSBCessAmt,SellingSBCessAmt=@SellingSBCessAmt where sno=" + Convert.ToInt64(Request["sno"].ToString()) + "";

        string Query = @"update FedexIP_NONIATA set TRK=@TRK,Account=@Account,awbNo=@awbNo,awbDt=@awbDt,UpliftmentDt=@UpliftmentDt,handoverDt=@handoverDt,agent_id=@agent_id,origin=@origin,dstnCd=@dstnCd,actualdstn=@actualdstn,shptType=@shptType,basicRate=@basicRate,sellingRate=@sellingRate,BuyingfscRate=@BuyingfscRate,BuyingstaxRate=@BuyingstaxRate,SellingfscRate=@SellingfscRate,SellingstaxRate=@SellingstaxRate,BuyingDG_Surcharge=@BuyingDG_Surcharge,SellingDG_Surcharge=@SellingDG_Surcharge,sellingAmtBeforStax=@sellingAmtBeforStax,BuyingfscAmt=@BuyingfscAmt,BuyingstaxAmt=@BuyingstaxAmt,SellingfscAmt=@SellingfscAmt,SellingstaxAmt=@SellingstaxAmt,buyingAmtBeforStax=@buyingAmtBeforStax,pcs=@pcs,Gross_wt=@Gross_wt,chargeable_wt=@chargeable_wt,fltNo=@fltNo,fltDt=@fltDt,shipper=@shipper,consignee=@consignee,remarks=@remarks,entered_by=@entered_by,entered_at=@entered_at,modified_by=@modified_by,modified_at=@modified_at,GrandSellingAmt=@GrandSellingAmt,GrandBuyingAmt=@GrandBuyingAmt,BuyingEduCessRate=@BuyingEduCessRate,SellingEduCessRate=@SellingEduCessRate,BuyingHEduCessRate=@BuyingHEduCessRate,SellingHEduCessRate=@SellingHEduCessRate,BuyingEduCessAmt=@BuyingEduCessAmt,SellingEduCessAmt=@SellingEduCessAmt,BuyingHEduCessAmt=@BuyingHEduCessAmt,SellingHEduCessAmt=@SellingHEduCessAmt,BuyingOtherChrgs=@BuyingOtherChrgs,SellingOtherChrgs=@SellingOtherChrgs,GrandBuyingStaxAmt=@GrandBuyingStaxAmt,GrandSellingStaxAmt=@GrandSellingStaxAmt,Airline_Detail_ID=@Airline_Detail_ID,BuyingSBCessRate=@BuyingSBCessRate,BuyingKKCessRate=@BuyingKKCessRate,SellingSBCessRate=@SellingSBCessRate,SellingKKCessRate=@SellingKKCessRate,BuyingSBCessAmt=@BuyingSBCessAmt,BuyingKKCessAmt=@BuyingKKCessAmt,SellingSBCessAmt=@SellingSBCessAmt,SellingKKCessAmt=@SellingKKCessAmt,Gst_Type=@Gst_Type,StateCode=@StateCode,GstNo=@GstNo where sno=" + Convert.ToInt64(Request["sno"].ToString()) + "";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand(Query, con);
            // cmd.Parameters.AddWithValue("@billing_company_code",);    
            cmd.Parameters.AddWithValue("@TRK", txtTRK.Text.Trim());
            cmd.Parameters.AddWithValue("@Account", txtAccount.Text.Trim());
            cmd.Parameters.AddWithValue("@awbNo", txtawbno.Text.Trim());
            cmd.Parameters.AddWithValue("@awbDt", FormatDateMM(awbdate.Text.Trim()));
            cmd.Parameters.AddWithValue("@UpliftmentDt", FormatDateMM(txtUpliftmentDate.Text.Trim()));
            cmd.Parameters.AddWithValue("@handoverDt", FormatDateMM(handdate.Text.Trim()));
            cmd.Parameters.AddWithValue("@agent_id", ddlAgentName.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@origin", origin_id.Value.Trim());
            cmd.Parameters.AddWithValue("@dstnCd", dlldest.SelectedValue.ToString().Trim());
            cmd.Parameters.AddWithValue("@actualdstn", txtdtd.Text);
            cmd.Parameters.AddWithValue("@shptType", dllspt.SelectedValue.ToString().Trim());
            decimal b_rate = (txtbasicRate.Text.Trim() == "" ? 0 : decimal.Parse(txtbasicRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@basicRate", b_rate);
            decimal selling_rate = (txtselrate.Text.Trim() == "" ? 0 : decimal.Parse(txtselrate.Text.Trim()));
            cmd.Parameters.AddWithValue("@sellingRate", selling_rate);
            ////decimal spot_rate = (txtbuyrate.Text.Trim() == "" ? 0 : decimal.Parse(txtbuyrate.Text.Trim()));
            ////cmd.Parameters.AddWithValue("@buyingRate", spot_rate);
            decimal Buyingfsc_rate = (txtBFSCRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBFSCRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingfscRate", Buyingfsc_rate);

            decimal Buyingstax_rate = (txtBStaxRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBStaxRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingstaxRate", Buyingstax_rate);

            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            decimal BuyingSBCess_rate = (txtBSBcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBSBcesRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingSBCessRate", BuyingSBCess_rate);

            decimal BuyingKKCess_rate = (txtBKKcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBKKcesRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingKKCessRate", BuyingKKCess_rate);


            decimal Sellingfsc_rate = (txtSFSCRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSFSCRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingfscRate", Sellingfsc_rate);

            decimal Sellingstax_rate = (txtSellStaxRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSellStaxRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingstaxRate", Sellingstax_rate);

            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            decimal SellingSBCess_rate = (txtSellSBcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSellSBcesRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingSBCessRate", SellingSBCess_rate);

            decimal SellingKKCess_rate = (txtSellKKcesRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSellKKcesRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingKKCessRate", SellingKKCess_rate);

            decimal Buyingdg_sur = (txtBuyDgSurcharge.Text.Trim() == "" ? 0 : decimal.Parse(txtBuyDgSurcharge.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingDG_Surcharge", Buyingdg_sur);
            decimal Sellingdg_sur = (txtSellingDgSurcharge.Text.Trim() == "" ? 0 : decimal.Parse(txtSellingDgSurcharge.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingDG_Surcharge", Sellingdg_sur);
            decimal selling_amt = (txtsamount.Text.Trim() == "" ? 0 : decimal.Parse(txtsamount.Text.Trim()));
            cmd.Parameters.AddWithValue("@sellingAmtBeforStax", selling_amt);
            decimal Buyingfsc_amt = (txtBFSCAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBFSCAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingfscAmt", Buyingfsc_amt);

            decimal Buyingstax_amt = (txtBServiceTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBServiceTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingstaxAmt", Buyingstax_amt);

            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            decimal BuyingSBCess_amt = (txtBSBcessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBSBcessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingSBCessAmt", BuyingSBCess_amt);

            decimal BuyingKKCess_amt = (txtBKKcessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtBKKcessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingKKCessAmt", BuyingKKCess_amt);


            decimal Sellingfsc_amt = (txtSFSCAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSFSCAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingfscAmt", Sellingfsc_amt);



            decimal Sellingstax_amt = (txtSellServiceTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSellServiceTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingstaxAmt", Sellingstax_amt);

            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            decimal SellingSBCess_amt = (txtSellSBCessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSellSBCessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingSBCessAmt", SellingSBCess_amt);
            decimal SellingKKCess_amt = (txtSellKKCessTaxAmount.Text.Trim() == "" ? 0 : decimal.Parse(txtSellKKCessTaxAmount.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingKKCessAmt", SellingKKCess_amt);

            decimal buyingg_amt = (txtbuyamt.Text.Trim() == "" ? 0 : decimal.Parse(txtbuyamt.Text.Trim()));
            cmd.Parameters.AddWithValue("@buyingAmtBeforStax", buyingg_amt);
            int pcs = (txtpcs.Text.Trim() == "" ? 0 : int.Parse(txtpcs.Text.Trim()));
            cmd.Parameters.AddWithValue("@pcs", pcs);
            decimal gwt = (txtGrwt.Text.Trim() == "" ? 0 : decimal.Parse(txtGrwt.Text.Trim()));
            cmd.Parameters.AddWithValue("@Gross_wt", gwt);
            decimal chwt = (txtchwt.Text.Trim() == "" ? 0 : decimal.Parse(txtchwt.Text.Trim()));
            cmd.Parameters.AddWithValue("@chargeable_wt", chwt);
            cmd.Parameters.AddWithValue("@fltNo", txtflightno.Text.Trim());
            cmd.Parameters.AddWithValue("@fltDt", FormatDateMM(flightdate.Text.Trim()));
            cmd.Parameters.AddWithValue("@shipper", txtshpr.Text.Trim());
            cmd.Parameters.AddWithValue("@consignee", txtcons.Text.Trim());
            cmd.Parameters.AddWithValue("@remarks", txtremarks.Text.Trim());
            cmd.Parameters.AddWithValue("@entered_by", Session["EMailID"].ToString());
            cmd.Parameters.AddWithValue("@entered_at", DateTime.Now);
            cmd.Parameters.AddWithValue("@modified_by", Session["EMailID"].ToString());
            cmd.Parameters.AddWithValue("@modified_at", DateTime.Now);
            //TotalSellingAmt,TotalBuyingAmt,BuyingEduCessRate,SellingEduCessRate,BuyingHEduCessRate,SellingHEduCessRate,BuyingEduCessAmt,SellingEduCessAmt,BuyingHEduCessAmt,SellingHEduCessAmt
            decimal GrandSellingAmt = (txtTotalSellingAmtStax.Text.Trim() == "" ? 0 : decimal.Parse(txtTotalSellingAmtStax.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandSellingAmt", GrandSellingAmt);
            decimal GrandBuyingAmt = (txtTotalBuyingAmtStax.Text.Trim() == "" ? 0 : decimal.Parse(txtTotalBuyingAmtStax.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandBuyingAmt", GrandBuyingAmt);
            decimal BuyingEduCessRate = (txtBeduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBeduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingEduCessRate", BuyingEduCessRate);
            decimal SellingEduCessRate = (txtSelEduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSelEduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingEduCessRate", SellingEduCessRate);
            decimal BuyingHEduCessRate = (txtBHeduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtBHeduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingHEduCessRate", BuyingHEduCessRate);
            decimal SellingHEduCessRate = (txtSelHEduCessRate.Text.Trim() == "" ? 0 : decimal.Parse(txtSelHEduCessRate.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingHEduCessRate", SellingHEduCessRate);
            decimal BuyingEduCessAmt = (txtBEduCessAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtBEduCessAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingEduCessAmt", BuyingEduCessAmt);
            decimal SellingEduCessAmt = (txtSellEduCessAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtSellEduCessAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingEduCessAmt", SellingEduCessAmt);
            decimal BuyingHEduCessAmt = (txtBHEduCessAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtBHEduCessAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingHEduCessAmt", BuyingHEduCessAmt);
            decimal SellingHEduCessAmt = (txtSellHEduCess.Text.Trim() == "" ? 0 : decimal.Parse(txtSellHEduCess.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingHEduCessAmt", SellingHEduCessAmt);
            decimal BuyingOtherChrgs = (txtBOther.Text.Trim() == "" ? 0 : decimal.Parse(txtBOther.Text.Trim()));
            cmd.Parameters.AddWithValue("@BuyingOtherChrgs", BuyingOtherChrgs);
            decimal SellingOtherChrgs = (txtSOther.Text.Trim() == "" ? 0 : decimal.Parse(txtSOther.Text.Trim()));
            cmd.Parameters.AddWithValue("@SellingOtherChrgs", SellingOtherChrgs);
            decimal GrandBuyingStaxAmt = (txtBuyingStaxAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtBuyingStaxAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandBuyingStaxAmt", GrandBuyingStaxAmt);
            decimal GrandSellingStaxAmt = (txtSellingStaxAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtSellingStaxAmt.Text.Trim()));
            cmd.Parameters.AddWithValue("@GrandSellingStaxAmt", GrandSellingStaxAmt);
            cmd.Parameters.AddWithValue("@Airline_Detail_ID", Convert.ToInt32(ViewState["Airline_Detail_ID"]));
            //Gst Applicable
            cmd.Parameters.AddWithValue("@GST_Type", GstRadioButtonList.SelectedItem.Text);

            cmd.Parameters.Add("@StateCode", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
            if (txtGstNo.Text == "")
            {
                cmd.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
            }
            else
            {
                cmd.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = txtGstNo.Text;
            }
            //End of Gst Applicable

            cmd.ExecuteNonQuery();
            con.Close();
            cmd.Dispose();
            Response.Redirect("Browse_ip_NonIata.aspx?upd=asdgagdsajdgjsagdjga");
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
            cmd.Dispose();
        }
    }
    private void LoadModify()
    {
        string sno = Request["sno"].ToString();
        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////string Query = "select TRK,Account,pcs,Gross_wt,city_name,origin,dstncd,sno,awbno,Convert(varchar,awbdt,103) as awbdt,status=case when awbdt<getdate()-20 then 1 else 0 end ,agent_name,destination_code,city_code,chargeable_wt,Convert(varchar,UpliftmentDt,103) as UpliftmentDt,Convert(varchar,handoverdt,103) as handoverdt,fltno,Convert(varchar,fltdt,103) as fltdt,actualdstn,shptType,shipper,consignee,remarks,basicRate,sellingRate,BuyingfscRate,BuyingstaxRate,SellingfscRate,SellingstaxRate,BuyingDG_Surcharge,SellingDG_Surcharge,sellingAmtBeforStax,BuyingfscAmt,BuyingstaxAmt,SellingfscAmt,SellingstaxAmt,buyingAmtBeforStax,GrandSellingAmt,GrandBuyingAmt,BuyingEduCessRate,SellingEduCessRate,BuyingHEduCessRate,SellingHEduCessRate,BuyingEduCessAmt,SellingEduCessAmt,BuyingHEduCessAmt,SellingHEduCessAmt,BuyingOtherChrgs,SellingOtherChrgs,GrandBuyingStaxAmt,GrandSellingStaxAmt,Airline_Detail_ID,BuyingSBCessRate,SellingSBCessRate,BuyingSBCessAmt,SellingSBCessAmt from FedexIP_NONIATA inner join agent_master on FedexIP_NONIATA.Agent_id=agent_master.Agent_id inner join destination_master on FedexIP_NONIATA.dstncd=destination_master.destination_id inner join city_master on FedexIP_NONIATA.origin=city_master.city_id where sno=" + sno + "";
        string Query = "select TRK,FedexIP_NONIATA.agent_id,FedexIP_NONIATA.GstNo,statecode,Account,pcs,Gross_wt,city_name,origin,dstncd,FedexIP_NONIATA.sno,awbno,Convert(varchar,awbdt,103) as awbdt,status=case when awbdt<getdate()-20 then 1 else 0 end ,agent_name,destination_code,city_code,chargeable_wt,Convert(varchar,UpliftmentDt,103) as UpliftmentDt,Convert(varchar,handoverdt,103) as handoverdt,fltno,Convert(varchar,fltdt,103) as fltdt,actualdstn,shptType,shipper,consignee,remarks,basicRate,sellingRate,BuyingfscRate,BuyingstaxRate,SellingfscRate,SellingstaxRate,BuyingDG_Surcharge,SellingDG_Surcharge,sellingAmtBeforStax,BuyingfscAmt,BuyingstaxAmt,SellingfscAmt,SellingstaxAmt,buyingAmtBeforStax,GrandSellingAmt,GrandBuyingAmt,BuyingEduCessRate,SellingEduCessRate,BuyingHEduCessRate,SellingHEduCessRate,BuyingEduCessAmt,SellingEduCessAmt,BuyingHEduCessAmt,SellingHEduCessAmt,BuyingOtherChrgs,SellingOtherChrgs,GrandBuyingStaxAmt,GrandSellingStaxAmt,FedexIP_NONIATA.Airline_Detail_ID,BuyingSBCessRate,BuyingKKCessRate,SellingSBCessRate,SellingKKCessRate,BuyingSBCessAmt,BuyingKKCessAmt,SellingSBCessAmt,SellingKKCessAmt,Gst_Type from FedexIP_NONIATA inner join IP_Agent on FedexIP_NONIATA.Agent_id=IP_Agent.Sno inner join destination_master on FedexIP_NONIATA.dstncd=destination_master.destination_id inner join city_master on FedexIP_NONIATA.origin=city_master.city_id where FedexIP_NONIATA.sno=" + sno + "";
        DataTable dt = dw.GetAllFromQuery(Query);
        foreach (DataRow drow in dt.Rows)
        {
            #region GstNo Applicable
            if (drow["Gst_Type"].ToString() == "IGST")
            {
                GstRadioButtonList.SelectedIndex = 1;
            }
            else
            {
                GstRadioButtonList.SelectedIndex = 0;
            }





            DataTable dtagentgstNo = new DataTable();
            ddlGst.Items.Insert(0, "-Select-");
            ddlGst.Items[0].Value = "0";
            dtagentgstNo = dw.GetAllFromQuery("Select GstNo from AgentGstNo where agentname like '" + drow["agent_name"].ToString() + "%'");
            if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
            {

                for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
                {

                    ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["GstNo"].ToString(), dtagentgstNo.Rows[i]["GstNo"].ToString()));
                }
            }





            txtGstNo.Text = drow["GstNo"].ToString();
            if (txtGstNo.Text != "")
            {
                //// txtGstNo.Enabled = false;
                ddlGst.SelectedValue = drow["GstNo"].ToString();
                ///ddlGst.Enabled = false;
            }
            else
            {
                //txtGstNo.Enabled = true;
                //ddlGst.Enabled = true;
                ddlGst.SelectedValue = drow["GstNo"].ToString();
            }

            ddlGstStateCode.SelectedValue = drow["StateCode"].ToString();
            ///// GST Applicable
            #endregion End of GstApplicable





            ////GstRadioButtonList.SelectedItem.Text = drow["Gst_Type"].ToString();
            txtawbno.Text = drow["awbno"].ToString();
            //txtawbno.Enabled = false;
            awbdate.Text = drow["awbdt"].ToString();
            handdate.Text = drow["handoverdt"].ToString();
            txtUpliftmentDate.Text = drow["UpliftmentDt"].ToString();
            int index = ddlAgentName.Items.IndexOf(ddlAgentName.Items.FindByText(drow["agent_name"].ToString() + "-" + drow["city_name"].ToString().ToUpper()));
            ddlAgentName.Items[index].Selected = true;
            txtorigin.Text = drow["city_name"].ToString();
            txtdtd.Text = drow["actualdstn"].ToString();
            origin_id.Value = drow["origin"].ToString();
            txtflightno.Text = drow["fltno"].ToString();
            txtremarks.Text = drow["remarks"].ToString();
            txtshpr.Text = drow["shipper"].ToString();
            txtcons.Text = drow["consignee"].ToString();
            flightdate.Text = drow["fltdt"].ToString();
            txtTRK.Text = drow["TRK"].ToString();
            txtAccount.Text = drow["Account"].ToString();
            txtpcs.Text = drow["pcs"].ToString();
            txtGrwt.Text = drow["Gross_wt"].ToString();
            txtchwt.Text = drow["chargeable_wt"].ToString();
            ViewState["Airline_Detail_ID"] = drow["Airline_Detail_ID"].ToString();
            txtsamount.Text = drow["sellingAmtBeforStax"].ToString();
            txtbuyamt.Text = drow["buyingAmtBeforStax"].ToString();
            ////txtbuyrate.Text = drow["BuyingRate"].ToString();
            txtselrate.Text = drow["sellingRate"].ToString();
            txtbasicRate.Text = drow["basicRate"].ToString();
            txtBuyDgSurcharge.Text = drow["BuyingDG_Surcharge"].ToString();
            txtSellingDgSurcharge.Text = drow["SellingDG_Surcharge"].ToString();
            txtBFSCRate.Text = drow["BuyingfscRate"].ToString();
            txtSFSCRate.Text = drow["SellingfscRate"].ToString();
            txtBFSCAmount.Text = drow["BuyingfscAmt"].ToString();
            txtSFSCAmount.Text = drow["SellingfscAmt"].ToString();
            txtBOther.Text = drow["BuyingOtherChrgs"].ToString();
            txtSOther.Text = drow["SellingOtherChrgs"].ToString();
            txtBStaxRate.Text = drow["BuyingstaxRate"].ToString();
            txtBServiceTaxAmount.Text = drow["BuyingstaxAmt"].ToString();
            txtSellStaxRate.Text = drow["SellingstaxRate"].ToString();
            txtSellServiceTaxAmount.Text = drow["SellingstaxAmt"].ToString();

            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************

            txtBSBcesRate.Text = drow["BuyingSBCessRate"].ToString();
            txtBKKcesRate.Text = drow["BuyingKKCessRate"].ToString();
            txtBSBcessTaxAmount.Text = drow["BuyingSBCessAmt"].ToString();
            txtBKKcessTaxAmount.Text = drow["BuyingKKCessAmt"].ToString();
            txtSellSBcesRate.Text = drow["SellingSBCessRate"].ToString();
            txtSellKKcesRate.Text = drow["SellingKKCessRate"].ToString();
            txtSellSBCessTaxAmount.Text = drow["SellingSBCessAmt"].ToString();
            txtSellKKCessTaxAmount.Text = drow["SellingKKCessAmt"].ToString();

            txtBeduCessRate.Text = drow["BuyingEduCessRate"].ToString();
            txtBEduCessAmt.Text = drow["BuyingEduCessAmt"].ToString();
            txtSelEduCessRate.Text = drow["SellingEduCessRate"].ToString();
            txtSellEduCessAmt.Text = drow["SellingEduCessAmt"].ToString();
            txtBHeduCessRate.Text = drow["BuyingHEduCessRate"].ToString();
            txtBHEduCessAmt.Text = drow["BuyingHEduCessAmt"].ToString();
            txtSelHEduCessRate.Text = drow["SellingHEduCessRate"].ToString();
            txtSellHEduCess.Text = drow["SellingHEduCessAmt"].ToString();
            txtBuyingStaxAmt.Text = drow["GrandBuyingStaxAmt"].ToString();
            txtSellingStaxAmt.Text = drow["GrandSellingStaxAmt"].ToString();
            txtTotalBuyingAmtStax.Text = drow["GrandBuyingAmt"].ToString();
            txtTotalSellingAmtStax.Text = drow["GrandSellingAmt"].ToString();
            int index_dest = dlldest.Items.IndexOf(dlldest.Items.FindByValue(drow["dstncd"].ToString()));
            dlldest.Items[index_dest].Selected = true;
            int index_spt = dllspt.Items.IndexOf(dllspt.Items.FindByValue(drow["shptType"].ToString()));
            dllspt.Items[index_spt].Selected = true;
            if (drow["shptType"].ToString().Trim() == "ATA")
            {
                ////StaxTD.Visible = false;
                ////StaxAmtTD.Visible = false;
                StaxDetail.Visible = false;
            }
        }
    }
    protected void dllspt_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (dllspt.SelectedItem.Value.ToString().Trim() == "ATA")
        {
            StaxDetail.Visible = false;
        }
        else
        {
            StaxDetail.Visible = true;
        }
    }
    protected void rbtnServiceTax_SelectedIndexChanged2(object sender, EventArgs e)
    {
        LoadStax();
        // For Buying
        decimal BCGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBStaxRate.Text) / 100;
        txtBServiceTaxAmount.Text = Convert.ToString(BCGSTAmt);
        decimal BSGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBSBcesRate.Text) / 100;
        txtBSBcessTaxAmount.Text = Convert.ToString(BSGSTAmt);
        decimal BIGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBKKcesRate.Text) / 100;
        txtBKKcessTaxAmount.Text = Convert.ToString(BIGSTAmt);
        //End of Buying

        // For Selling
        decimal SCGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellStaxRate.Text) / 100;
        txtSellServiceTaxAmount.Text = Convert.ToString(SCGSTAmt);
        decimal SSGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellSBcesRate.Text) / 100;
        txtSellSBCessTaxAmount.Text = Convert.ToString(SSGSTAmt);
        decimal SIGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellKKcesRate.Text) / 100;
        txtSellKKCessTaxAmount.Text = Convert.ToString(SIGSTAmt);
        //End of Selling
        ////DataTable dtStaxRate = dw.GetAllFromQuery("SELECT TDS_Id,Stax,Education_Cess,IsNull(SB_Cess,0) as SB_Cess,IsNull(KK_Cess,0) as KK_Cess,HigherEducation_Cess FROM tds_Fedex WHERE GETDATE() BETWEEN Valid_From AND Valid_To");
        ////if (dtStaxRate.Rows.Count > 0)
        ////{
        ////    #region GST Applicable from 01 1 Apr 2017
        ////    if (GstRadioButtonList.SelectedIndex == 0)
        ////    {
        ////        txtBStaxRate.Text = dtStaxRate.Rows[0]["Stax"].ToString();
        ////        txtBSBcesRate.Text = dtStaxRate.Rows[0]["SB_Cess"].ToString();
        ////        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////        txtBKKcesRate.Text = "0.00";
        ////        txtSellStaxRate.Text = dtStaxRate.Rows[0]["Stax"].ToString();
        ////        txtSellSBcesRate.Text = dtStaxRate.Rows[0]["SB_Cess"].ToString();
        ////        txtSellKKcesRate.Text = "0.00";
        ////        txtBeduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtSelEduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtBHeduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////        txtSelHEduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////    }
        ////    else
        ////    {
        ////        txtBStaxRate.Text = "0.00";
        ////        txtBSBcesRate.Text = "0.00";
        ////        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////        txtBKKcesRate.Text = dtStaxRate.Rows[0]["KK_Cess"].ToString();
        ////        txtSellStaxRate.Text = "0.00";
        ////        txtSellSBcesRate.Text = "0.00";
        ////        txtSellKKcesRate.Text = dtStaxRate.Rows[0]["KK_Cess"].ToString();
        ////        txtBeduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtSelEduCessRate.Text = dtStaxRate.Rows[0]["Education_Cess"].ToString();
        ////        txtBHeduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////        txtSelHEduCessRate.Text = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
        ////    }
        ////    #endregion
        ////}
        ////else
        ////{
        ////    #region GST Applicable from 01 1 Apr 2017
        ////    if (GstRadioButtonList.SelectedIndex == 0)
        ////    {
        ////        txtBSBcesRate.Text = "9.00";
        ////        txtBKKcesRate.Text = "0.00";
        ////        txtBStaxRate.Text = "9.00";
        ////        txtSellStaxRate.Text = "9.00";
        ////        txtBeduCessRate.Text = "2";
        ////        txtSelEduCessRate.Text = "2";
        ////        txtBHeduCessRate.Text = "1";
        ////        txtSelHEduCessRate.Text = "1";
        ////    }
        ////    else
        ////    {
        ////        txtBSBcesRate.Text = "0.00";
        ////        txtBKKcesRate.Text = "18.00";
        ////        txtBStaxRate.Text = "0.00";
        ////        txtSellStaxRate.Text = "0.00";
        ////        txtBeduCessRate.Text = "2";
        ////        txtSelEduCessRate.Text = "2";
        ////        txtBHeduCessRate.Text = "1";
        ////        txtSelHEduCessRate.Text = "1";
        ////    }
        ////    #endregion
        ////}
    }

    public void LoadStax()
    {
        try
        {
            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            ////string strStax = "SELECT Stax,Education_Cess,SB_Cess,HigherEducation_Cess FROM db_owner.tds_flydubai where GETDATE() BETWEEN Valid_From AND Valid_To";
            string strStax = "SELECT TDS_Id,Stax,Education_Cess,IsNull(SB_Cess,0) as SB_Cess,IsNull(KK_Cess,0) as KK_Cess,HigherEducation_Cess FROM tds_Fedex WHERE GETDATE() BETWEEN Valid_From AND Valid_To";
            con = new SqlConnection(strCon);
            con.Open();
            SqlDataAdapter adp = new SqlDataAdapter(strStax, con);
            DataSet ds = new DataSet();
            adp.Fill(ds);

            DataTable dt = ds.Tables[0];
            if (dt.Rows.Count > 0)
            {
                #region GST Applicable from 01 1 Apr 2017
                if (GstRadioButtonList.SelectedIndex == 0)
                {
                    txtBStaxRate.Text = dt.Rows[0]["Stax"].ToString();
                    txtBSBcesRate.Text = dt.Rows[0]["SB_Cess"].ToString();
                    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    txtBKKcesRate.Text = "0.00";
                    txtSellStaxRate.Text = dt.Rows[0]["Stax"].ToString();
                    txtSellSBcesRate.Text = dt.Rows[0]["SB_Cess"].ToString();
                    txtSellKKcesRate.Text = "0.00";
                    txtBeduCessRate.Text = dt.Rows[0]["Education_Cess"].ToString();
                    txtSelEduCessRate.Text = dt.Rows[0]["Education_Cess"].ToString();
                    txtBHeduCessRate.Text = dt.Rows[0]["HigherEducation_Cess"].ToString();
                    txtSelHEduCessRate.Text = dt.Rows[0]["HigherEducation_Cess"].ToString();
                    txtBKKcessTaxAmount.Text = "0.00";
                    txtSellKKCessTaxAmount.Text = "0.00";
                    ////// For Buying
                    ////decimal BCGSTAmt=decimal.Parse(txtbuyamt.Text)*decimal.Parse(txtBStaxRate.Text)/100;
                    ////txtBServiceTaxAmount.Text = Convert.ToString(BCGSTAmt);
                    ////decimal BSGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBSBcesRate.Text) / 100;
                    ////txtBSBcessTaxAmount.Text = Convert.ToString(BSGSTAmt);
                    ////decimal BIGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBKKcesRate.Text) / 100;
                    ////txtBKKcessTaxAmount.Text = Convert.ToString(BIGSTAmt);
                    //////End of Buying

                    ////// For Selling
                    ////decimal SCGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellStaxRate.Text) / 100;
                    ////txtSellServiceTaxAmount.Text = Convert.ToString(SCGSTAmt);
                    ////decimal SSGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellSBcesRate.Text) / 100;
                    ////txtSellSBCessTaxAmount.Text = Convert.ToString(SSGSTAmt);
                    ////decimal SIGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellKKcesRate.Text) / 100;
                    ////txtSellKKCessTaxAmount.Text = Convert.ToString(SIGSTAmt);
                    //////End of Selling

                }
                else
                {
                    txtBStaxRate.Text = "0.00";
                    txtBSBcesRate.Text = "0.00";
                    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    txtBKKcesRate.Text = dt.Rows[0]["KK_Cess"].ToString();
                    txtSellStaxRate.Text = "0.00";
                    txtSellSBcesRate.Text = "0.00";
                    txtSellKKcesRate.Text = dt.Rows[0]["KK_Cess"].ToString();
                    txtBeduCessRate.Text = dt.Rows[0]["Education_Cess"].ToString();
                    txtSelEduCessRate.Text = dt.Rows[0]["Education_Cess"].ToString();
                    txtBHeduCessRate.Text = dt.Rows[0]["HigherEducation_Cess"].ToString();
                    txtSelHEduCessRate.Text = dt.Rows[0]["HigherEducation_Cess"].ToString();
                    txtBServiceTaxAmount.Text = "0.00";
                    txtSellServiceTaxAmount.Text = "0.00";
                    txtBSBcessTaxAmount.Text = "0.00";
                    txtSellSBCessTaxAmount.Text = "0.00";
                    ////// For Buying
                    ////decimal BCGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBStaxRate.Text) / 100;
                    ////txtBServiceTaxAmount.Text = Convert.ToString(BCGSTAmt);
                    ////decimal BSGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBSBcesRate.Text) / 100;
                    ////txtBSBcessTaxAmount.Text = Convert.ToString(BSGSTAmt);
                    ////decimal BIGSTAmt = decimal.Parse(txtbuyamt.Text) * decimal.Parse(txtBKKcesRate.Text) / 100;
                    ////txtBKKcessTaxAmount.Text = Convert.ToString(BIGSTAmt);
                    //////End of Buying

                    ////// For Selling
                    ////decimal SCGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellStaxRate.Text) / 100;
                    ////txtSellServiceTaxAmount.Text = Convert.ToString(SCGSTAmt);
                    ////decimal SSGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellSBcesRate.Text) / 100;
                    ////txtSellSBCessTaxAmount.Text = Convert.ToString(SSGSTAmt);
                    ////decimal SIGSTAmt = decimal.Parse(txtsamount.Text) * decimal.Parse(txtSellKKcesRate.Text) / 100;
                    ////txtSellKKCessTaxAmount.Text = Convert.ToString(SIGSTAmt);
                    //////End of Selling
                }
                #endregion
            }
            else
            {
                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                #region GST Applicable from 01 1 Apr 2017
                if (GstRadioButtonList.SelectedIndex == 0)
                {
                    txtBSBcesRate.Text = "9.00";
                    txtBKKcesRate.Text = "0.00";
                    txtBStaxRate.Text = "9.00";
                    txtSellStaxRate.Text = "9.00";
                    txtBeduCessRate.Text = "2";
                    txtSelEduCessRate.Text = "2";
                    txtBHeduCessRate.Text = "1";
                    txtSelHEduCessRate.Text = "1";
                    txtBKKcessTaxAmount.Text = "0.00";
                    txtSellKKCessTaxAmount.Text = "0.00";
                }
                else
                {
                    txtBSBcesRate.Text = "0.00";
                    txtBKKcesRate.Text = "18.00";
                    txtBStaxRate.Text = "0.00";
                    txtSellStaxRate.Text = "0.00";
                    txtBeduCessRate.Text = "2";
                    txtSelEduCessRate.Text = "2";
                    txtBHeduCessRate.Text = "1";
                    txtSelHEduCessRate.Text = "1";
                    txtBServiceTaxAmount.Text = "0.00";
                    txtSellServiceTaxAmount.Text = "0.00";
                    txtBSBcessTaxAmount.Text = "0.00";
                    txtSellSBCessTaxAmount.Text = "0.00";
                }
                #endregion
            }
            ////txtSellStaxRate.Text = dt.Rows[0]["Stax"].ToString();
            ////txtBStaxRate.Text = dt.Rows[0]["Stax"].ToString();
            ////txtBSBcesRate.Text = dt.Rows[0]["SB_Cess"].ToString();
            ////txtSellSBcesRate.Text = dt.Rows[0]["SB_Cess"].ToString();
            //txtBStaxRate.Enabled = false;
            // txtSellStaxRate.Enabled = false;

            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

    protected void ddlAgentName_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region findout from and to date
        string Flight_date = Request["par"].ToString();
        string[] dateSplit = Flight_date.Split('/');
        string Month = dateSplit[1].ToString();
        string Year = dateSplit[2].ToString();
        string Date1 = dateSplit[0].ToString();
        string currentdate = Month + "/" + Date1 + "/" + Year;
        string FinYear = Year.Substring(2, 2);
        DateTime CurrDate = Convert.ToDateTime(currentdate);
        string DateFinancial = "4/1/20" + FinYear + "";
        DateTime FinanciaDate = DateTime.Parse(DateFinancial);
        if (CurrDate < FinanciaDate)
        {
            FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
        }
        else
        {
            FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
        }
        string Lastdate = "";
        bool flagInvoice = false;
        if (int.Parse(Date1) < 16)
        {
            Date1 = "1";
            flagInvoice = true;
        }
        else
        {
            Date1 = "16";
        }
        string startDate = Month + "/" + Date1 + "/" + Year;
        string endDate = Month + "/" + (flagInvoice ? "15" : (Convert.ToDateTime(Month + "/1/" + Year).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + Year;
        #endregion
        #region GstNo Applicable
        DataTable dtagentgstNo = new DataTable();
        DataTable dtGstNAlreadyExist = dw.GetAllFromQuery("Select gstNo from FedexIP_NONIATA where agent_id=" + ddlAgentName.SelectedValue + " and fltdt between '" + startDate + "' and '" + endDate + "' and airline_detail_id=" + ViewState["Airline_Detail_ID"] + "  and Gstno is not null");
        if (dtGstNAlreadyExist != null && dtGstNAlreadyExist.Rows.Count > 0)
        {
            txtGstNo.Text = dtGstNAlreadyExist.Rows[0]["GstNo"].ToString();
            // txtGstNo.Enabled = false;
            ddlGst.Items.Insert(0, "-Select-");
            ddlGst.Items[0].Value = "0";
            dtagentgstNo = dw.GetAllFromQuery("Select GstNo from AgentGstNo where agentname like '" + ddlAgentName.SelectedItem.Text + "%'");
            if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
            {
                for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
                {
                    ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["GstNo"].ToString(), dtagentgstNo.Rows[i]["GstNo"].ToString()));
                }
                ddlGst.SelectedValue = dtGstNAlreadyExist.Rows[0]["GstNo"].ToString();
                //ddlGst.Enabled = false;
            }
        }
        else
        {
            ddlGst.Items.Insert(0, "-Select-");
            ddlGst.Items[0].Value = "0";
            string[] agentsplit = ddlAgentName.SelectedItem.Text.Split('-');
            string agent = agentsplit[0].ToString();
            dtagentgstNo = dw.GetAllFromQuery("Select Gst_No from IP_Agent where agent_name like '" + agent + "%'");
            if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
            {

                for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
                {

                    ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["Gst_No"].ToString(), dtagentgstNo.Rows[i]["Gst_No"].ToString()));
                }


            }
        }


        #endregion End of GstApplicable
    }
    protected void ddlGst_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlGst.SelectedValue != "0")
        {
            txtGstNo.Text = ddlGst.SelectedItem.Text;
            
        }
        else
        {
            txtGstNo.Text = "";
        }
        if (txtGstNo.Text != "")
        {
            DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + ViewState["Airline_Detail_ID"] + "");
            if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
            {
                CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                AgentGstNo = txtGstNo.Text;
                if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                {
                    GstRadioButtonList.SelectedIndex = 0;
                    LoadStax();
                }
                else
                {
                    GstRadioButtonList.SelectedIndex = 1;
                    LoadStax();
                }
            }
        }


    }
    protected void ddlGstStateCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlGstStateCode.SelectedValue != "0" && (txtGstNo.Text == "" && ddlGst.SelectedValue == "0"))
        {

            txtGstNo.Text = ddlGstStateCode.SelectedValue;


        }
        if (txtGstNo.Text != "")
        {
            DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + ViewState["Airline_Detail_ID"] + "");
            if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
            {
                CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                AgentGstNo = txtGstNo.Text;
                if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                {
                    GstRadioButtonList.SelectedIndex = 0;
                    LoadStax();
                }
                else
                {
                    GstRadioButtonList.SelectedIndex = 1;
                    LoadStax();
                }
            }
        }
    }
    public void LoadGstStateCode()
    {
        try
        {
            string strAgent = "select * from GstStateCode order by Statecode";
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand(strAgent, con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlGstStateCode.Items.Insert(0, "- -Select- -");
            ddlGstStateCode.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlGstStateCode.Items.Add(new ListItem(dr["StateCode"].ToString() + "-" + dr["State"].ToString(), dr["StateCode"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
