﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Text;
public partial class Generate_Manifest : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string Entered_By;
    DateTime Entered_On;
    StringBuilder strtable = new StringBuilder();
    
    string fno="";
    string date="";
    string Air_code = "";
    string CITY_ID = "";
    string Flight_Open_Id = "";
    string Air_Detail_Id = "";
    string FLIGHT_DATE = "";
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
        hdnemail.Value=Session["EMailID"].ToString();
        // txtuldno.Attributes.Add("onkeydown", "return uppercase();");
            btnULD.Attributes.Add("onclick", "return checkUlddata('U');return false;");
            btnbulk.Attributes.Add("onclick", "return checkUlddata('B');return false;");
            btnReturn_hnd.Attributes.Add("onclick", "return chkhanddata();return false;");
            if (!IsPostBack)
            {
                FillDetails();
            }
        }
    }
    public void FillDetails()
    {
        try
        {
             Air_code = Request.QueryString["Airline_code"];
             CITY_ID = Request.QueryString["city_id"];
             Flight_Open_Id = Request.QueryString["fid"];
             Air_Detail_Id = Request.QueryString["AID"];
             FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
            date = Request.QueryString["date"];
            fno = Request.QueryString["fno"];
            string PFM_groupid_old = "";
            string PFM_groupid_new = "";
            con = new SqlConnection(strCon);
            con.Open();
            string rowcolor="";
            string status="";
            btnprint.Attributes.Add("onclick", "javascript:window.open('PrintPfm.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes');return false;");
           // com = new SqlCommand("Pfmdetails_getlist", con);
            com = new SqlCommand("GetPfm_Date_New", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FLIGHT_OPEN_ID", SqlDbType.Int).Value = Convert.ToInt32(Flight_Open_Id);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt_Hand = new DataTable();
            da.Fill(dt_Hand);

            com = new SqlCommand("Airline_Name", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FLIGHT_OPEN_ID", SqlDbType.Int).Value = Convert.ToInt32(Flight_Open_Id);
            SqlDataAdapter da1 = new SqlDataAdapter(com);
            DataTable dt_Hand1 = new DataTable();
            da1.Fill(dt_Hand1);
            int k=0;
           
            string package="";
            int TotalPackage=0;
           decimal Grossweight=0;
           decimal VolWeight=0;
           decimal ChWeight = 0;
           decimal TotalGrWt=0;
           decimal TotalVolWt=0;
           decimal TotalChWt = 0;
           int GrandTotal=0;
           decimal GrandTotalGrWt = 0;
           decimal GrandTotalVolWt = 0;
           decimal GrandTotalChWt = 0;
           
            if (dt_Hand.Rows.Count > 0)
            {
               k++;
              
                PFM_groupid_old = dt_Hand.Rows[0]["PFM_Group_ID"].ToString();
                strtable.Append("<div id='print" + PFM_groupid_old + "'  ><table width=100% border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=h1><td colspan=12 align=center class=boldtext>" + dt_Hand1.Rows[0]["Airline_Name"].ToString() + "</td></tr>");
                strtable.Append(@"<tr ><td colspan=11></td><td  align=right nowrap><input type=button name=button value='Print' class=but id='btnprint" + PFM_groupid_old + "' onclick='javascript:printable(this.id);'></td></td></tr>");

                strtable.Append(@"<tr ><td colspan=11></td><td  align=right class=but nowrap >page " + k + "</td></tr>");
                strtable.Append(@"<tr class=h1><td><input id='chkTopicAll' name='checkallmain' type='checkbox' onclick='javascript:AllCheck(this);'/></td><td colspan=11 align=left class=boldtext>Select All</td></tr>");
                strtable.Append(@"<tr class=HeaderStyle1><td></td><td>S.No</td><td>FLT NO :</td><td nowrap>" + dt_Hand.Rows[0]["Flight_No"].ToString() + " </td><td nowrap>DATE : </td><td>" + dt_Hand.Rows[0]["FLIGHT_DATE"].ToString() + "</td><td></td><td></td><td></td><td></td><td>DSTN</td><td>DOHA</td></tr>");
                strtable.Append(@"<tr class=HeaderStyle1><td></td><td></td><td nowrap>Airway Bill No.</td><td>Pcs</td><td>Gr.Wt.(k)</td><td nowrap>Vol.wt.</td><td nowrap>Ch.wt.</td><td nowrap>Commodity</td><td>Part Shipment</td><td nowrap>Dest.</td><td nowrap>Location</td><td nowrap>S.B.No.</td></tr>");
                for (int i = 0; i < dt_Hand.Rows.Count; i++)
                {
                if(dt_Hand.Rows[i]["fullpkg"].ToString()==dt_Hand.Rows[i]["No_of_Packages"].ToString())
                {
                package=dt_Hand.Rows[i]["No_of_Packages"].ToString();
                }
                else
                {
                    package = dt_Hand.Rows[i]["No_of_Packages"].ToString() + "/" + dt_Hand.Rows[i]["fullpkg"].ToString();
                }
                Grossweight =Math.Round(decimal.Parse(dt_Hand.Rows[i]["Gross_Weight"].ToString()) / int.Parse(dt_Hand.Rows[i]["fullpkg"].ToString()) * int.Parse(dt_Hand.Rows[i]["No_of_Packages"].ToString()),2);
                VolWeight = Math.Round( decimal.Parse(dt_Hand.Rows[i]["Volume_Weight"].ToString()) / int.Parse(dt_Hand.Rows[i]["fullpkg"].ToString()) * int.Parse(dt_Hand.Rows[i]["No_of_Packages"].ToString()),2);
                ChWeight = Math.Round(decimal.Parse(dt_Hand.Rows[i]["Charged_Weight"].ToString()) / int.Parse(dt_Hand.Rows[i]["fullpkg"].ToString()) * int.Parse(dt_Hand.Rows[i]["No_of_Packages"].ToString()), 2);
                
                
                
                    PFM_groupid_new = dt_Hand.Rows[i]["PFM_Group_ID"].ToString();
                    
             //       if(dt_Hand.Rows[i]["Manifest_Status"].ToString()==13)
                    rowcolor = dt_Hand.Rows[i]["Manifest_Status"].ToString() == "13" ? " PeachPuff" : "LightBlue";
                    //status = dt_Hand.Rows[i]["Manifest_Status"].ToString() == "13" ? "DISABLED" : ""; 

                    if (PFM_groupid_old != PFM_groupid_new)
                    {
                    k++;
                    strtable.Append(@"<tr><td colspan=3> Total</td><td >" + TotalPackage + "</td><td align=right>" + TotalGrWt.ToString("0.00") + "</td><td align=right>" + TotalVolWt.ToString("0.00") + "</td><td align=right>" + TotalChWt.ToString("0.00") + "</td><td colspan=5 >&nbsp;</td></tr><tr><td colspan=12>&nbsp;</td></tr></table></div><div id='print" + PFM_groupid_new + "' ><table width=100% border=0 id=tdPadding cellspacing=0 cellpadding=0><tr class=h1 ><td colspan=12 align=center class=boldtext nowrap>" + dt_Hand1.Rows[0]["Airline_Name"].ToString() + "</td></tr><tr ><td colspan=11></td><td  align=right ><input type=button name=button value='Print' class=but id='btnprint" + PFM_groupid_new + "' onclick='javascript:printable(this.id);'></td></td></tr><tr><td colspan=11></td><td class=but nowrap>page " + k + "</td></tr>");
                    strtable.Append(@"<tr class=HeaderStyle1><td></td><td>S.No</td><td>FLT NO :</td><td>" + dt_Hand.Rows[0]["Flight_No"].ToString() + " </td><td>DATE : </td><td>" + dt_Hand.Rows[i]["FLIGHT_DATE"].ToString() + "</td><td></td><td></td><td></td><td></td><td>DSTN</td><td>DOHA</td></tr>");
                    strtable.Append(@"<tr class=HeaderStyle1><td></td><td></td><td>Airway Bill No.</td><td>Pcs</td><td>Gr.Wt.(k)</td><td nowrap>Vol.wt.</td><td nowrap>Ch.wt.</td><td>Commodity</td><td>Part Shipment</td><td>Dest.</td><td>Location</td><td>S.B.No.</td></tr>");
                        PFM_groupid_old = PFM_groupid_new;
                        GrandTotal += TotalPackage;
                        GrandTotalGrWt += TotalGrWt;
                        GrandTotalVolWt += TotalVolWt;
                        GrandTotalChWt += TotalChWt;
                        TotalPackage=0;
                        TotalGrWt=0;
                        TotalVolWt=0;
                        TotalChWt = 0;
                    }

                    if (PFM_groupid_old == PFM_groupid_new)
                    {
                        TotalPackage += Convert.ToInt32(dt_Hand.Rows[i]["No_of_Packages"].ToString());
                        TotalGrWt += Grossweight;
                        TotalVolWt += VolWeight;
                        TotalChWt += ChWeight;
                        
                    }
                    
                    if(dt_Hand.Rows[i]["Manifest_Status"].ToString() == "13")
                    {
                        strtable.Append(@"<tr style='background:" + rowcolor + "' ><td nowrap></td><td nowrap> " + (i + 1) + "</td><td nowrap>" + dt_Hand.Rows[i]["AIRWAYBILL_NO"].ToString() + "</td><td nowrap><span id='lblpcgshow" + dt_Hand.Rows[i]["handover_id"].ToString() + " ' >" + package + "</span></td><td nowrap align=right>" + Grossweight.ToString("0.00") + "</td><td align=right nowrap>" + VolWeight.ToString("0.00") + "</td><td align=right nowrap>" + ChWeight.ToString("0.00") + "</td><td nowrap>" + dt_Hand.Rows[i]["Special_Commodity_Name"].ToString() + "</td><td></td><td>" + dt_Hand.Rows[i]["DESTINATION_CODE"].ToString() + "</td><td nowrap>" + dt_Hand.Rows[i]["Location"].ToString() + "</td><td nowrap>" + dt_Hand.Rows[i]["Shipping_Bill_No"].ToString() + "</td></tr>"); 
                    }
                    else
                    {
                        strtable.Append(@"<tr style='background:" + rowcolor + "' ><td nowrap><input id='chkTopicAll" + dt_Hand.Rows[i]["handover_id"].ToString() + "' name='checkall' type='checkbox' onclick='javascript:checkboxcheck(this.id);' value='" + dt_Hand.Rows[i]["handover_id"].ToString() + "' " + status + " /></td><td nowrap>" + (i + 1) + "</td><td nowrap>" + dt_Hand.Rows[i]["AIRWAYBILL_NO"].ToString() + "</td><td nowrap><span id='lblpcgshow" + dt_Hand.Rows[i]["handover_id"].ToString() + " ' >" + package + "</span><span id='lbl" + dt_Hand.Rows[i]["handover_id"].ToString() + "' style='visibility: hidden;' >" + dt_Hand.Rows[i]["No_of_Packages"].ToString() + "</span><span id='lblpid" + dt_Hand.Rows[i]["handover_id"].ToString() + "' style='visibility: hidden;'>" + dt_Hand.Rows[i]["pfm_id"].ToString() + "</span><span id='lblpart" + dt_Hand.Rows[i]["handover_id"].ToString() + "' style='visibility: hidden;'></span></td><td nowrap align=right>" + Grossweight.ToString("0.00") + "</td><td align=right nowrap>" + VolWeight.ToString("0.00") + "</td><td align=right nowrap>" + ChWeight.ToString("0.00") + "</td><td nowrap>" + dt_Hand.Rows[i]["Special_Commodity_Name"].ToString() + "</td><td nowrap><span id=RadioButtonList" + dt_Hand.Rows[i]["handover_id"].ToString() + " class=radioButtonList vertical><input id=RadioButtonListyes" + dt_Hand.Rows[i]["handover_id"].ToString() + " name=RadioButtonList" + dt_Hand.Rows[i]["handover_id"].ToString() + " type=radio onclick='javascript:RadioeventYes(this.id);' value=0 tabindex=0 /><label for=RadioButtonListyes'" + dt_Hand.Rows[i]["handover_id"].ToString() + "'>Yes</label><span><input id=RadioButtonListno" + dt_Hand.Rows[i]["handover_id"].ToString() + " name=RadioButtonList" + dt_Hand.Rows[i]["handover_id"].ToString() + " type=radio onclick='javascript:RadioeventNo(this.id);' value=1 checked tabindex=0 /><label for=RadioButtonListno" + dt_Hand.Rows[i]["handover_id"].ToString() + ">No</label></span></br><input type=text size=5px name=textbox onblur='javascript:showpartpcs(this.id);' id=txt" + dt_Hand.Rows[i]["handover_id"].ToString() + "><span  name=lable id='lblpartpcs" + dt_Hand.Rows[i]["handover_id"].ToString() + "'></span></td><td>" + dt_Hand.Rows[i]["DESTINATION_CODE"].ToString() + "</td><td nowrap>" + dt_Hand.Rows[i]["Location"].ToString() + "</td><td nowrap>" + dt_Hand.Rows[i]["Shipping_Bill_No"].ToString() + "<span  name=lable id='lblfullpkg" + dt_Hand.Rows[i]["handover_id"].ToString() + "' style='visibility: hidden;'>" + dt_Hand.Rows[i]["fullpkg"].ToString() + "</span></td></tr>"); 
                    } 
                }
                GrandTotal += TotalPackage;
                GrandTotalGrWt += TotalGrWt;
                GrandTotalVolWt += TotalVolWt;
                GrandTotalChWt += TotalChWt;
                strtable.Append(@"<tr><td colspan=3> Total</td><td >" + TotalPackage + "</td><td align=right>" + TotalGrWt.ToString("0.00") + "</td><td align=right>" + TotalVolWt.ToString("0.00") + "</td><td align=right>" + TotalChWt.ToString("0.00") + "</td><td colspan=5 >&nbsp;</td></tr><tr><td colspan=12>&nbsp;</td></tr><tr class=FinalTotal><td colspan=3> GrandTotalTotal</td><td >" + GrandTotal + "</td><td align=right>" + GrandTotalGrWt.ToString("0.00") + "</td><td align=right>" + GrandTotalVolWt.ToString("0.00") + "</td><td align=right>" + GrandTotalChWt.ToString("0.00") + "</td><td colspan=5 >&nbsp;</td></tr><tr><td colspan=12>&nbsp;</td></tr></table></div>");
                GrandTotal = 0;
                GrandTotalGrWt = 0;
                GrandTotalVolWt = 0;
                GrandTotalChWt = 0;
                TotalPackage=0;
                TotalGrWt=0;
                TotalVolWt=0;
                TotalChWt = 0;
                lblmanifest.Text = strtable.ToString();
            }
            else
            {
            btnprint.Visible=false;
            btnReturn_hnd.Visible=false;
            btnULD.Visible=false;
            txtuldno.Visible=false;
            btnbulk.Visible=false;
            pnlOperation.Visible = false;
            pnlHandover.Visible = false;
            lblmanifest.Text="No Data for Manifest";
            
            }


        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();


        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnULD_Click(object sender, EventArgs e)
    {
        Air_code = Request.QueryString["Airline_code"];
        CITY_ID = Request.QueryString["city_id"];
        Flight_Open_Id = Request.QueryString["fid"];
        Air_Detail_Id = Request.QueryString["AID"];
        FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
        date = Request.QueryString["date"];
        fno = Request.QueryString["fno"];
        Response.Redirect("Generate_Manifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id); 
   

    }
    protected void btnReturn_hnd_Click(object sender, EventArgs e)
    {
        Air_code = Request.QueryString["Airline_code"];
        CITY_ID = Request.QueryString["city_id"];
        Flight_Open_Id = Request.QueryString["fid"];
        Air_Detail_Id = Request.QueryString["AID"];
        FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
        date = Request.QueryString["date"];
        fno = Request.QueryString["fno"];
        Response.Redirect("Generate_Manifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id); 
    }
    protected void btnbulk_Click(object sender, EventArgs e)
    {
        Air_code = Request.QueryString["Airline_code"];
        CITY_ID = Request.QueryString["city_id"];
        Flight_Open_Id = Request.QueryString["fid"];
        Air_Detail_Id = Request.QueryString["AID"];
        FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
        date = Request.QueryString["date"];
        fno = Request.QueryString["fno"];
        Response.Redirect("Generate_Manifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id); 
    }
}
