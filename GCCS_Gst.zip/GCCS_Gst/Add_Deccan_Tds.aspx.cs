using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;
public partial class Add_Deccan_Tds : System.Web.UI.Page
{
	// Declare public variables here 
	SqlConnection con;
	SqlCommand com;
	SqlCommand cmd;
	string Sno;
	/// <summary>
	/// Making Connection from web.config
	/// </summary>
	string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
	protected void Page_Load(object sender, EventArgs e)
	{
		if (Session["EMailID"] == null)
		{
			Response.Redirect("Login.aspx");
		}
		else
		{
			if (!IsPostBack && Request.QueryString["Sno"] != null)
			{
				ShowAirline();
				btnupdate.Visible = true;
				btnAdd.Visible = false;
				btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
				Sno = Convert.ToString(Request.QueryString["Sno"]);
				string str1 = "select AirlineDetailID,TDSRate,CONVERT(VARCHAR,ValidFrom,103)AS ValidFrom,CONVERT(VARCHAR,ValidTo,103)AS ValidTo from Deccan_TDS where Sno='" + Sno + "'";
				con = new SqlConnection(strCon);
				con.Open();
				com = new SqlCommand(str1, con);
				SqlDataReader dr = com.ExecuteReader();
				dr.Read();
				//string st = dr.FieldCount.ToString();
				ddlAirlineName.SelectedIndex = ddlAirlineName.Items.IndexOf(ddlAirlineName.Items.FindByValue(dr["airlinedetailid"].ToString()));
				ddlAirlineName.Enabled = false;
				txtTds.Text = dr["TDSRate"].ToString();
				txtValidFrom.Text =(dr["ValidFrom"].ToString());
				txtValidto.Text =(dr["ValidTo"].ToString());
				con.Close();
				LblMsg.Visible = false;
			}

			else if (!IsPostBack)
			{
				btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
				btnupdate.Visible = false;
				btnAdd.Visible = true;
				LblMsg.Visible = false;
				ShowAirline();

			}
		}

	}

	public string Rights()
	{

		string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


		con = new SqlConnection(strCon);
		con.Open();
		string Access = "";
		SqlCommand cmd = new SqlCommand(sql_Access, con);

		SqlDataReader dr = cmd.ExecuteReader();
		if (dr.HasRows)
		{
			while (dr.Read())
			{
				Access = dr.GetValue(0).ToString();
			}

		}
		dr.Dispose();
		cmd.Dispose();

		return Access;

	}
	// ---- This Function is used to  bind Airline in dropdown ----
	protected void ShowAirline()
	{
		try
		{
			con = new SqlConnection(strCon);
			con.Open();
			cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where airline_detail_id in (" + Rights() + ") order by airline_name,City_name", con);
			SqlDataReader dr = cmd.ExecuteReader();

			ddlAirlineName.Items.Clear();
			ddlAirlineName.Items.Add(new ListItem("Select Airline"));

			while (dr.Read())
			{
				ddlAirlineName.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["airline_detail_id"])));

			}
			cmd.Dispose();
			dr.Close();
		}
		catch (Exception eror)
		{
			string st = eror.ToString();
		}
		finally
		{
			con.Close();
			cmd.Dispose();

		}

	}

	public void UpdateData()
	{
		ddlAirlineName.Enabled = false;
		con = new SqlConnection(strCon);
		string strupdate = "";
		try
		{
			con.Open();
			strupdate = "update Deccan_TDS  set AIrlinedetailID='" + ddlAirlineName.SelectedValue + "',TdsRate="+txtTds.Text+",ValidFrom='" +FormatDateMM( txtValidFrom.Text) + "',validto='" +FormatDateMM( txtValidto.Text )+ "' where Sno='" + Convert.ToString(Request.QueryString["Sno"]) + "'";

			com = new SqlCommand(strupdate, con);
			com.ExecuteNonQuery();
			con.Close();
			Response.Redirect("Deccan_Tds.aspx");
		}

		catch (SqlException se)
		{
			string err = se.Message;
		}
		finally
		{
			if (con != null && con.State == ConnectionState.Open)
				con.Close();
		}
	}

	protected void btnAdd_Click(object sender, EventArgs e)
	{
		SqlTransaction trans;
		SqlDataAdapter da1;
		string airline_detail_id = ddlAirlineName.SelectedItem.Value;
	
		con = new SqlConnection(strCon);//Making Connection
		string _Check = "";
		_Check = "select * from Deccan_tds where airlinedetailid=" + airline_detail_id;
		da1 = new SqlDataAdapter(_Check, con);
		DataTable dt = new DataTable();
		da1.Fill(dt);
		con.Close();
		string insert1 = string.Empty;
		con = new SqlConnection(strCon);//Making Connection
		try
		{
			if (dt.Rows.Count == 0)
			{

				con.Open();
				trans = con.BeginTransaction();                                                                             // Insert Value in fix_charges table
				insert1 = "insert into Deccan_tds(Airlinedetailid,TdsRate,ValidFrom,ValidTo) values(@Airlinedetailid,@TdsRate,@ValidFrom,@ValidTo)";
				 com = new SqlCommand(insert1, con, trans);
				com.CommandType = CommandType.Text;
				com.Parameters.Add("@Airlinedetailid", SqlDbType.Int).Value = int.Parse(airline_detail_id);
				com.Parameters.Add("@TdsRate", SqlDbType.Decimal).Value =Decimal.Parse( txtTds.Text);

				DateTime dtValidFrom = DateTime.Parse(FormatDateMM(txtValidFrom.Text));
				DateTime dtValidTo = DateTime.Parse(FormatDateMM(txtValidto .Text));
				com.Parameters.Add("@ValidFrom", SqlDbType.DateTime).Value = dtValidFrom;
				com.Parameters.Add("@ValidTo", SqlDbType.DateTime).Value = dtValidTo;
				com.ExecuteNonQuery();
				trans.Commit();
				con.Close();
				Response.Redirect("Deccan_Tds.aspx");
			}
			else
			{
				LblMsg.Visible = true;
				LblMsg.Text = "AirLine alreday exist";
				// string msg = "AirLine_Detail_Id alreday exist";
			}
		}
		catch (Exception ex1)
		{
			string msg = Convert.ToString(ex1);
		}

	}
	protected void btnupdate_Click(object sender, EventArgs e)
	{
		UpdateData();
	}
	protected void btnCancel_Click(object sender, EventArgs e)
	{
		Response.Redirect("deccan_Tds.aspx");
	}
	public string FormatDateMM(string date)
	{

		string[] d = date.Split(new char[] { '/' });

		string strMM = d[0];
		string strDD = d[1];
		string strYYYY = d[2];
		string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
		return strMMDDYYYY;
	}
	public string FormatDateDD(string date)
	{

		string[] d = date.Split(new char[] { '/' });

		string strMM = d[1];
		string strDD = d[0];
		string strYYYY = d[2];
		string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
		return strMMDDYYYY;
	}
}
