using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Agent_Details_CCCSR : System.Web.UI.Page
{
   
   
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    SqlTransaction trans = null;
    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
             Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");
               
                int dt = System.DateTime.Now.Month;
                ddlMonth.Items[dt].Selected = true;
                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();
                ShowAirline();             

            }

        }

    }
    protected void ShowAirline()
    {

        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and (a.airline_id='158' or a.airline_id='147') order by Airline_Name", con);
            dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select Airline");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

            com.Dispose();


        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        string comAdd = null;
        string[] airlineName = ddlAirLine.SelectedItem.Text.Split('-');
        string airline = "A/C " + airlineName[0].ToUpper().ToString();

        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();

        //string strY = DateTime.Today.Year.ToString();
        string strY = ddlyear.SelectedItem.Text.Trim();

        if (rbtnFirstFortn.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }


        }

        //DataTable dt = dw.GetAllFromQuery("select S.AGENT_ID,AGENT_NAME FROM SALES S INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=S.AGENT_ID  where  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  s.freight_type='Collect' AND SALES_TYPE='INV' And (S.AGENT_ID NOT IN(SELECT AGENT_ID FROM CC_CSR_Details WHERE FROM_DATE='" + TextBox1.Text + "' AND TO_DATE='" + TextBox2.Text + "' AND airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + ") )   union SELECT SM.AGENT_ID,AGENT_NAME FROM SALES_DRCR SM INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=SM.AGENT_ID  where (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sm.freight_type='Collect'  AND SALES_TYPE='INV' And (SM.AGENT_ID NOT IN(SELECT AGENT_ID FROM CC_CSR_Details WHERE FROM_DATE='" + TextBox1.Text + "' AND TO_DATE='" + TextBox2.Text + "' AND airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + ")) ORDER BY AGENT_NAME ");

 DataTable dt = dw.GetAllFromQuery("select S.AGENT_ID,AGENT_NAME FROM SALES S INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=S.AGENT_ID  where  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  s.freight_type='Collect' AND SALES_TYPE='INV'  union SELECT SM.AGENT_ID,AGENT_NAME FROM SALES_DRCR SM INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=SM.AGENT_ID  where (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sm.freight_type='Collect'  AND SALES_TYPE='INV' ORDER BY AGENT_NAME ");
        if (dt.Rows.Count > 0)
        {
            GridView2.Visible = true;
            GridView2.DataSource = dt;
            GridView2.DataBind();
         
            btnSubmit.Visible = true;
            btnSubmit.Enabled = true;
            Label1.Visible = false;
        }
        else
        {
            GridView2.DataSource = null;
            GridView2.DataBind();
            btnSubmit.Visible = false;
            Label1.Visible = false;
            //Label1.Visible = true;
            //Label1.Text = "Either No CC Shipment Exist for this fortnight Or Agent is Already Added.";
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();

        //string strY = DateTime.Today.Year.ToString();
        string strY = ddlyear.SelectedItem.Text.Trim();

        if (rbtnFirstFortn.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }


        }
        string strRightsString = "";
        string strQuery_Delete = "";
        string strQuery_Insert = "";
        SqlCommand cmd;
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            trans = con.BeginTransaction();
            strQuery_Delete = "delete from CC_CSR_Details where Airline_Detail_id=" + ddlAirLine.SelectedItem.Value + " and From_Date='" + TextBox1.Text + "' and To_date='" + TextBox2.Text + "'";
            cmd = new SqlCommand(strQuery_Delete, con, trans);
            cmd.ExecuteNonQuery();
            foreach (GridViewRow gv in GridView2.Rows)
            {
                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                if (ChkBxItem.Checked)
                {
                    strRightsString = ((Label)gv.FindControl("lblAID")).Text.ToString();
                    strQuery_Insert = "INSERT INTO CC_CSR_Details (Agent_Id,Airline_Detail_id,From_Date,To_Date) VALUES(" + strRightsString + "," + ddlAirLine.SelectedItem.Value + ",'" + TextBox1.Text + "','" + TextBox2.Text + "')";

                    cmd = new SqlCommand(strQuery_Insert, con, trans);
                    cmd.ExecuteNonQuery();                 

                }
                
            }
            trans.Commit();
            cmd.Dispose();
            con.Close();
            Label1.Text = "Added Successfully.";
            Label1.Visible = true;
            btnSubmit.Visible= false;
            GridView2.Visible = false;
        }
        catch (SqlException se)
        {
            string err = se.Message;

            trans.Rollback();
            Label1.Visible = true;
            Label1.Text = err;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chkheader = new CheckBox();
        chkheader = (CheckBox)GridView2.HeaderRow.FindControl("chkSelectAll");

        foreach (GridViewRow rw in GridView2.Rows)
        {
            CheckBox chkMain = new CheckBox();
            chkMain = (CheckBox)rw.FindControl("chkMain");

            if (chkheader.Checked == true)
            {
                chkMain.Checked = true;


            }

            else
            {
                chkMain.Checked = false;

            }


        }
    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            TextBox TextBox1 = new TextBox();
            TextBox TextBox2 = new TextBox();
            TextBox TextBox3 = new TextBox();

            //string strY = DateTime.Today.Year.ToString();
            string strY = ddlyear.SelectedItem.Text.Trim();

            if (rbtnFirstFortn.Checked == true)
            {
                if (ddlMonth.SelectedItem.Text.Trim() == "January")
                {
                    TextBox1.Text = "01/01/" + strY;
                    TextBox2.Text = "01/15/" + strY;
                    TextBox3.Text = "01/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "February")
                {
                    TextBox1.Text = "02/01/" + strY;
                    TextBox2.Text = "02/15/" + strY;
                    TextBox3.Text = "02/16/" + strY;
                }
                if (ddlMonth.SelectedItem.Text.Trim() == "March")
                {
                    TextBox1.Text = "03/01/" + strY;
                    TextBox2.Text = "03/15/" + strY;
                    TextBox3.Text = "03/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "April")
                {
                    TextBox1.Text = "04/01/" + strY;
                    TextBox2.Text = "04/15/" + strY;
                    TextBox3.Text = "04/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text == "May")
                {
                    TextBox1.Text = "05/01/" + strY;
                    TextBox2.Text = "05/15/" + strY;
                    TextBox3.Text = "05/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "June")
                {
                    TextBox1.Text = "06/01/" + strY;
                    TextBox2.Text = "06/15/" + strY;
                    TextBox3.Text = "06/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "July")
                {
                    TextBox1.Text = "07/01/" + strY;
                    TextBox2.Text = "07/15/" + strY;
                    TextBox3.Text = "07/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "August")
                {
                    TextBox1.Text = "08/01/" + strY;
                    TextBox2.Text = "08/15/" + strY;
                    TextBox3.Text = "08/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "September")
                {
                    TextBox1.Text = "09/01/" + strY;
                    TextBox2.Text = "09/15/" + strY;
                    TextBox3.Text = "09/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "October")
                {
                    TextBox1.Text = "10/01/" + strY;
                    TextBox2.Text = "10/15/" + strY;
                    TextBox3.Text = "10/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "November")
                {
                    TextBox1.Text = "11/01/" + strY;
                    TextBox2.Text = "11/15/" + strY;
                    TextBox3.Text = "11/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "December")
                {
                    TextBox1.Text = "12/01/" + strY;
                    TextBox2.Text = "12/15/" + strY;
                    TextBox3.Text = "12/16/" + strY;
                }
            }

            else if (rbtnSecondFortN.Checked == true)
            {
                if (ddlMonth.SelectedItem.Text.Trim() == "January")
                {
                    TextBox1.Text = "01/16/" + strY;
                    TextBox2.Text = "01/31/" + strY;
                    TextBox3.Text = "02/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "February")
                {
                    TextBox1.Text = "02/16/" + strY;
                    if (DateTime.IsLeapYear(int.Parse(strY)))
                        TextBox2.Text = "02/29/" + strY;
                    else
                    { TextBox2.Text = "02/28/" + strY; }

                    TextBox3.Text = "03/01/" + strY;

                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "March")
                {
                    TextBox1.Text = "03/16/" + strY;
                    TextBox2.Text = "03/31/" + strY;
                    TextBox3.Text = "04/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "April")
                {
                    TextBox1.Text = "04/16/" + strY;
                    TextBox2.Text = "04/30/" + strY;
                    TextBox3.Text = "05/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "May")
                {
                    TextBox1.Text = "05/16/" + strY;
                    TextBox2.Text = "05/31/" + strY;
                    TextBox3.Text = "06/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "June")
                {
                    TextBox1.Text = "06/16/" + strY;
                    TextBox2.Text = "06/30/" + strY;
                    TextBox3.Text = "07/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "July")
                {
                    TextBox1.Text = "07/16/" + strY;
                    TextBox2.Text = "07/31/" + strY;
                    TextBox3.Text = "08/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "August")
                {
                    TextBox1.Text = "08/16/" + strY;
                    TextBox2.Text = "08/31/" + strY;
                    TextBox3.Text = "09/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "September")
                {
                    TextBox1.Text = "09/16/" + strY;
                    TextBox2.Text = "09/30/" + strY;
                    TextBox3.Text = "10/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "October")
                {
                    TextBox1.Text = "10/16/" + strY;
                    TextBox2.Text = "10/31/" + strY;
                    TextBox3.Text = "11/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "November")
                {
                    TextBox1.Text = "11/16/" + strY;
                    TextBox2.Text = "11/30/" + strY;
                    TextBox3.Text = "12/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "December")
                {
                    TextBox1.Text = "12/16/" + strY;
                    TextBox2.Text = "12/31/" + strY;
                    TextBox3.Text = "01/01/" + strY;
                }


            }

            DataTable dt_restrict = dw.GetAllFromQuery("SELECT AGENT_ID FROM CC_CSR_Details WHERE FROM_DATE='" + TextBox1.Text + "' AND TO_DATE='" + TextBox2.Text + "' AND airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "");
            foreach (DataRow gv in dt_restrict.Rows)
            {
                CheckBox chkSelect = (CheckBox)e.Row.FindControl("chkMain");
                Label lblID = (Label)e.Row.FindControl("lblAID");
                if (gv["Agent_ID"].ToString() == lblID.Text.ToString())
                {
                    chkSelect.Checked = true;
                    btnSubmit.Text = "Edit";
                }
            }
        }

    }
}
