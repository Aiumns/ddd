using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//last modify hn mishra.
public partial class Importflightopen_details : System.Web.UI.Page
{
    #region variable declaration
    SqlConnection con;
    SqlDataReader rdr;
     public string strquery;
    SqlCommand cmd;
    SqlDataAdapter sda;
    #endregion 
    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Import Flight Open Details</class>
    /// <description>

    /// </description>
    /// <dependency></dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>4 Dec</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// <modifiedby></modifiedby>
    /// <modifiedOn></modifiedOn>
    /// <changeDescription></changeDescription>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    #region page load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            show();
        
        }

    }
    #endregion
    #region paging
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd.PageIndex = e.NewPageIndex;
        show();

    }
    #endregion
    #region function for show data
    public void show()
    {

        using (con)
        {
            con = new SqlConnection(strCon);
            con.Open();
            strquery = "SELECT dbo.Airline_Master.Airline_Name as AirlineName, Import_Flight_Open.Import_Flight_No,Destination_Master.Destination_Name as origin, City_Master.City_Name as destination ,convert(varchar,Import_Flight_Open.Flight_Date,103) as 'Flight_Date', Import_Flight_Open.IGM_No,convert(varchar,Import_Flight_Open.IGM_Date,103) as 'IGM_Date',convert(varchar,a.Close_Date,103)as CloseDate  FROM  dbo.Airline_Detail INNER JOIN dbo.Airline_Master ON dbo.Airline_Detail.Airline_ID = dbo.Airline_Master.Airline_ID INNER JOIN db_owner.Import_Flight_Open ON dbo.Airline_Detail.Airline_Detail_ID = db_owner.Import_Flight_Open.Airline_Detail_ID INNER JOIN dbo.City_Master ON dbo.Airline_Detail.Belongs_To_City = dbo.City_Master.City_ID AND db_owner.Import_Flight_Open.Import_Destination = dbo.City_Master.City_ID INNER JOIN db_owner.Destination_Master ON db_owner.Import_Flight_Open.Import_Origin = db_owner.Destination_Master.Destination_ID inner join flight_open a on a.Import_Flight_Open_id=Import_Flight_Open.Import_Flight_Open_id";
            cmd = new SqlCommand(strquery, con);
            sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            DataView dview = new DataView(ds.Tables[0]);
            //rdr = cmd.ExecuteReader();
            grd.DataSource = dview;
            grd.DataBind();
            //rdr.Close();
            con.Close();



        }
    }
    #endregion
    #region searching
    protected void Button1_Click(object sender, EventArgs e)
    {
        string search = null;
        con = new SqlConnection(strCon);
        con.Open();
        if (txtsearch.Text  == "")
        {
            show();
        }
        else
        {

            search = "SELECT dbo.Airline_Master.Airline_Name as AirlineName, Import_Flight_Open.Import_Flight_No,Destination_Master.Destination_Name as origin, City_Master.City_Name as destination ,convert(varchar,Import_Flight_Open.Flight_Date,103) as 'Flight_Date', Import_Flight_Open.IGM_No,convert(varchar,Import_Flight_Open.IGM_Date,103) as 'IGM_Date',convert(varchar,a.Close_Date,103)as CloseDate  FROM  dbo.Airline_Detail INNER JOIN dbo.Airline_Master ON dbo.Airline_Detail.Airline_ID = dbo.Airline_Master.Airline_ID INNER JOIN db_owner.Import_Flight_Open ON dbo.Airline_Detail.Airline_Detail_ID = db_owner.Import_Flight_Open.Airline_Detail_ID INNER JOIN dbo.City_Master ON dbo.Airline_Detail.Belongs_To_City = dbo.City_Master.City_ID AND db_owner.Import_Flight_Open.Import_Destination = dbo.City_Master.City_ID INNER JOIN db_owner.Destination_Master ON db_owner.Import_Flight_Open.Import_Origin = db_owner.Destination_Master.Destination_ID inner join flight_open a on a.Import_Flight_Open_id=Import_Flight_Open.Import_Flight_Open_id where "+ddlSearch.SelectedValue.Trim() +" like '" + txtsearch.Text + "'+ '%' ";
            cmd = new SqlCommand(search, con);
            sda = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            sda.Fill(ds1);
            DataView dview = new DataView(ds1.Tables[0]);
            grd.DataSource = dview;
            grd.DataBind();
            con.Close();
        }
    }
    #endregion
}
