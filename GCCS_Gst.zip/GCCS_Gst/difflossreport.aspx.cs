using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class difflossreport : System.Web.UI.Page
{
    
    string lastdate;
    bool flag = true;
    bool flagl = true;
         string firstdate;
    DateTime startdate;
    public string Tables;
    public string str1 = "";
    //string tables = "";
    DateTime enddate;
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    SqlDataAdapter da = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        string currentdate = System.DateTime.Today.ToString();
        string[] datesplit = currentdate.Split('/');
        string day = datesplit[1];
        string month = datesplit[0];
        string year = datesplit[2];
        if (int.Parse(day) > 15)
        {
            lastdate = month + "/16/" + year;
            firstdate = month + "/01/" + year;
            startdate = DateTime.Parse(firstdate);
            enddate = DateTime.Parse(lastdate);

        }
        if (int.Parse(day) <= 15)
        {
            string minusdate = System.DateTime.Today.AddMonths(-1).ToString();
            string[] datesplitt = minusdate.Split('/');
            string day1 = datesplitt[1];
            string month1 = datesplitt[0];
            string year1 = datesplitt[2];
            if ((month1 == "4") || (month1 == "6") || (month1 == "11") || (month1 == "09"))
            {
                lastdate = month1 + "/30/" + year1;
                firstdate = month1 + "/16/" + year1;
                startdate = DateTime.Parse(firstdate);
                enddate = DateTime.Parse(lastdate);

            }
            else
            {
                lastdate = month1 + "/31/" + year1;
                firstdate = month1 + "/16/" + year1;
                startdate = DateTime.Parse(firstdate);
                enddate = DateTime.Parse(lastdate);

            }


        }
        Int64 count = 1;
        string str = "";
        decimal cbm = 0;
        decimal chk = 0;
        decimal Total_gr_wt = 0;
        decimal Total_gr_wt1 = 0;
        decimal gr_wt = 0;
        decimal ch_wt = 0;
        decimal total_ch_wt = 0;
        decimal total_ch_wt1 = 0;
        decimal comAmt = 0;
        decimal freight_amount = 0;
        decimal commission = 0;
        decimal sp_com = 0;
        decimal inc = 0;
        decimal Spot_Rate = 0;
        decimal tariff_rate = 0;
        decimal spot_diff = 0;
        decimal nn_amount = 0;
        decimal comless = 0;
        decimal nn_sold = 0;
        decimal spar = 0;
        decimal diff = 0;
        decimal OR = 0;
        decimal GSAComm_Rate_rate = 0;
        decimal gsa_com = 0;
        decimal freight_total = 0;
        decimal total_fr_wsc_fsc = 0;
        decimal total_fr_wsc_fsc1 = 0;
        decimal total_diff = 0;
        decimal total_diff1 = 0;
        decimal total_gsa = 0;
        decimal total_gsa1 = 0;
        decimal total_OR = 0;
        decimal total_OR1 = 0;
        string wsc = "";
        string fsc = "";
        decimal frieght_applied = 0;
        string remark = "";
        string Principle_Spot_Rate = "";
        int Principle_Min_status = 0;
        string awbno = "";
        decimal spar_rate = 7.5M;
        string Query = "select distinct flight_master.airline_detail_id,airline_name,airline_text_code,airline_code,belongs_to_city,city_code,city_name,city_master.city_id  from flight_open inner join flight_master on flight_open.flight_id=flight_master.flight_id inner join airline_detail on flight_master.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id inner join city_master on airline_detail.belongs_to_city=city_master.city_id where airline_detail.airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ")  order by airline_name";
        DataTable dt_airline = dw.GetAllFromQuery(Query);
        foreach (DataRow drow1 in dt_airline.Rows)
        {
            flag = true;

            string airline_name = drow1["airline_name"].ToString();
            string airline_detail_d = drow1["airline_detail_id"].ToString();
            string from_date = startdate.ToString();
            string to_date = enddate.ToString();
            string city_name = drow1["city_name"].ToString();
            string city_code = drow1["city_id"].ToString();
            try
            {
                //flag = true;
                con = new SqlConnection(strCon);
                con.Open();
                //cmd = new SqlCommand("select Distinct Convert(varchar,Flight_Date,103) as Flight_Date,Flight_master.flight_no from sales s inner join dbo.Agent_Master am on am.Agent_ID=s.Agent_ID inner join Flight_master on s.airline_detail_id=Flight_master.airline_detail_id  where s.airline_detail_id=" + Convert.ToInt64(airline_detail_d) + "and Flight_Date between '" + from_date + "' and '" + to_date + "'and s.status !=12 and City_ID=" + Convert.ToInt64(city_code) + "Order by Flight_Date", con);
                //da = new SqlDataAdapter(cmd);
                //DataSet ds = new DataSet("DateTable");
                //da.Fill(ds, "DateTable");

                //if (ds.Tables[0].Rows.Count > 0)
                //{
                //    Response.Write("<center><b><span style='color: #990033; text-align: center; text-decoration: underline'>" + airline_name + " / " + city_name + "</span></b></center>");
                //}
                //cmd.Dispose();
                cmd = new SqlCommand("select sales_id,Approve_Status,AirWayBill_No,Loss_Remarks,Tariff_Rate,Destination_Code,No_of_Packages,s.DueCarrier_Type,Gross_Weight,Charged_Weight,Special_Rate,principle_amount,Spot_Rate,Freight_Amount,Commission,Special_Commodity_Incentive,Principle_Spot_Rate_Remarks,Principle_Spot_Rate,Agent_Name,War_Surcharges,principle_spot_rate_remarks,Fuel_Surcharges,principle_rate,Principle_Min_status from sales s inner join dbo.Agent_Master am on am.Agent_ID=s.Agent_ID where airline_detail_id=" + Convert.ToInt64(airline_detail_d) + " and City_ID=" + Convert.ToInt64(city_code) + "and status !=12 and Flight_Date between '" + from_date + "' and '" + to_date + "'  order by Flight_Date ", con);
                dr = cmd.ExecuteReader();
               
                if (dr.HasRows)
                {

                    //flag = true;
                    //Tables += @"<Table width=100% align=center border=1 ><tr align=center valign=middle><td class=txtbox><b> " + airline_name + " /" + city_name + "<b></td></tr><tr><td><Table width=100% align=center border=1 ><tr align=center valign=middle class=h5><tr align=center valign=middle class=h5><td><b>S.No</b></td><td><b>Awb No.</b></td><td><b>Dest.</b></td><td><b>PCS</b></td><td><b>PCS</b></td><td><b>PP/CC</b></td><td><b>Gr Wt.</b></td><b>Gr Wt.</b></td><td><b>Ch Wt.</b></td><td><b>CBM</b></td><td><b>Freight</b></td><td><b>Inc IATA</b></td><td><b>Inc(Agent)</b></td><td><b>NN Sold</b></td><td><b>AWB Rate</b></td><td><b>Spar</b></td><td><b>Diff</b></td><td><b >Total Freight Charges including MYC/FSC</b></td><td><b>GSA comm</b></td><td><b>OR</b></td><td><b>Agent</b></td><td><b>Remarks</b></td></tr>";
                    //Response.Write(@"<Table width=100% align=center border=1 >");
                    //Response.Write(@"<tr align=center valign=middle>");


                    //Response.Write(@"<td class=txtbox><b> " + airline_name + " /" + city_name + "<b></td></tr>");
                    //Response.Write(@"<tr><td>");
                    //Response.Write(@"<Table width=100% align=center border=1 >");
                    //Response.Write(@"<tr align=center valign=middle class=h5>");
                    //Response.Write("<td><b>S.No</b></td>");
                    //Response.Write("<td><b>Awb No.</b></td>");
                    //Response.Write("<td><b>Dest.</b></td>");
                    //Response.Write("<td><b>PCS</b></td>");
                    //Response.Write("<td><b>PP/CC</b></td>");
                    //Response.Write("<td><b>Gr Wt.</b></td>");
                    //Response.Write("<td><b>Ch Wt.</b></td>");
                    //Response.Write("<td><b>CBM</b></td>");
                    //Response.Write("<td><b>Freight</b></td>");
                    //Response.Write("<td><b>Inc IATA</b></td>");
                    //Response.Write("<td><b>Inc(Agent)</b></td>");
                    //Response.Write("<td><b>NN Sold</b></td>");
                    //Response.Write("<td><b>AWB Rate</b></td>");
                    //Response.Write("<td><b>Spar</b></td>");
                    //Response.Write("<td><b>Diff</b></td>");
                    //Response.Write("<td><b >Total Freight Charges including MYC/FSC</b></td>");
                    //Response.Write("<td><b>GSA comm</b></td>");
                    //Response.Write("<td><b>OR</b></td>");
                    //Response.Write("<td><b>Agent</b></td>");
                    //Response.Write("<td><b>Remarks</b></td>");
                    //Response.Write("<td></td>");
                    //Response.Write("<td></td>");
                    //Response.Write(@"</tr>");










                    
                    while (dr.Read())
                    {
                        awbno = dr["AirWayBill_No"].ToString();
                        //Response.Write(@"<tr class=text onclick=ChangeColor(this); >");
                        //Response.Write("<td nowrap>" + count + "</td>");
                        //Response.Write("<td nowrap>" + awbno + "</td>");
                        //Response.Write("<td nowrap>" + dr["Destination_Code"].ToString() + "</td>");
                        //Response.Write("<td nowrap align=right>" + dr["No_of_Packages"].ToString() + "</td>");
                        //str = dr["DueCarrier_Type"].ToString();
                        //if (str == "PREPAID")
                        //{
                        //    Response.Write("<td>P</td>");
                        //}
                        //else
                        //{
                        //    Response.Write("<td nowrap>C</td>");
                        //}
                        gr_wt = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                        //Response.Write("<td nowrap align=right>" + gr_wt + "</td>");
                        //Total_gr_wt = Total_gr_wt + gr_wt;
                        ch_wt = Convert.ToDecimal(dr["Charged_Weight"].ToString());

                        //Response.Write("<td nowrap align=right>" + ch_wt + "</td>");
                        //total_ch_wt = total_ch_wt + ch_wt;

                        cbm = Convert.ToDecimal(dr["Charged_Weight"]) / 167;
                        //Response.Write("<td nowrap align=right>" + Math.Round(cbm, 2) + "</td>");
                        freight_amount = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                        Principle_Min_status = Convert.ToInt32(dr["Principle_Min_status"].ToString());
                        remark = dr["principle_spot_rate_remarks"].ToString();

                        Principle_Spot_Rate = dr["Principle_Spot_Rate"].ToString();
                        decimal principle_rate = Convert.ToDecimal(dr["principle_rate"].ToString());
                        if (remark == "Book" || remark == "book")
                        {
                            if (Convert.ToDecimal(Principle_Spot_Rate) > 0)
                            {

                                if (Principle_Min_status == 14)
                                {
                                    frieght_applied = (ch_wt * Convert.ToDecimal(Principle_Spot_Rate));
                                    spar = Convert.ToDecimal(Principle_Spot_Rate);
                                }
                                else
                                {
                                    frieght_applied = Convert.ToDecimal(Principle_Spot_Rate);
                                    spar = Convert.ToDecimal(Principle_Spot_Rate);
                                }
                            }
                            else
                            {
                                if (Principle_Min_status == 14)
                                {
                                    frieght_applied = ch_wt * Convert.ToDecimal(dr["principle_rate"].ToString()) - ((Convert.ToDecimal(Principle_Spot_Rate) * 5) / 100);
                                    spar = Convert.ToDecimal(principle_rate);

                                }
                                else
                                {
                                    frieght_applied = Convert.ToDecimal(dr["principle_rate"].ToString()) - ((Convert.ToDecimal(Principle_Spot_Rate) * 5) / 100);
                                    spar = Convert.ToDecimal(principle_rate);

                                }
                            }
                        }
                        else
                        {

                            if (Convert.ToDecimal(Principle_Spot_Rate) > 0)
                            {

                                if (Principle_Min_status == 14)
                                {
                                    frieght_applied = ch_wt * Convert.ToDecimal(Principle_Spot_Rate);
                                    spar = Convert.ToDecimal(Principle_Spot_Rate);
                                }
                                else
                                {
                                    frieght_applied = Convert.ToDecimal(Principle_Spot_Rate);
                                    spar = Convert.ToDecimal(Principle_Spot_Rate);
                                }
                            }
                            else
                            {
                                if (Principle_Min_status == 14)
                                {

                                    frieght_applied = ch_wt * principle_rate;
                                    spar = Convert.ToDecimal(principle_rate);
                                }
                                else
                                {
                                    // decimal principle_amount = Convert.ToDecimal(dr["principle_amount"].ToString());
                                    //frieght_applied = principle_amount;
                                    frieght_applied = principle_rate;

                                    spar = Convert.ToDecimal(principle_rate);

                                }

                            }
                        }
                        //Response.Write("<td nowrap align=right>" + Math.Round(frieght_applied, 2, MidpointRounding.AwayFromZero) + "</td>");
                        commission = Convert.ToDecimal(dr["Commission"].ToString());

                        //if (commission > 0)
                        //{
                        //    Response.Write("<td nowrap align=right>" + commission + "</td>");
                        //}
                        //else
                        //{
                        //    Response.Write("<td nowrap >Spot</td>");
                        //}
                        chk = Convert.ToDecimal(dr["Special_Commodity_Incentive"].ToString());
                        //if (chk > 0)
                        //{
                        //    Response.Write("<td nowrap align=right>" + chk + "</td>");
                        //}
                        //else
                        //{
                        //    Response.Write("<td>Spot</td>");
                        //}

                        if (commission > 0)
                        {
                            //comm =  ( amt  * commission ) / 100

                            comAmt = freight_amount * commission / 100;

                        }
                        comless = freight_amount - comAmt;

                        if (chk > 0)
                        {
                            //inc = (((amt * onFreight) /100 )*scrInc )/100

                            inc = (comless * chk) / 100;
                        }

                        Spot_Rate = Convert.ToDecimal(dr["Spot_Rate"].ToString());
                        tariff_rate = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                        if (Spot_Rate > 0)
                        {
                            spot_diff = (tariff_rate - Spot_Rate) * ch_wt;
                        }
                        nn_amount = freight_amount - comAmt - inc - spot_diff;
                        if (Principle_Min_status == 13)
                        {
                            nn_sold = nn_amount;
                        }
                        else
                        {
                            nn_sold = nn_amount / ch_wt;
                        }

                        //Response.Write("<td align=right>" + Math.Round(nn_sold, 2, MidpointRounding.AwayFromZero) + "</td>");
                        //Response.Write("<td align=right>" + tariff_rate.ToString() + "</td>");

                        //spar = Convert.ToDecimal(dr["Special_Rate"].ToString());

                        if (awbno.Substring(0, 3) == "023")
                        {

                            spar = spar - ((spar / 100) * spar_rate);

                        }




                        //Response.Write("<td align=right>" + spar + "</td>");
                        diff = (nn_sold - spar);
                        total_diff = total_diff + diff;
                        //if (diff < 0)
                        //{
                        //    Response.Write("<td nowrap align=right class=error>" + Math.Round(diff, 2, MidpointRounding.AwayFromZero) + "</td>");
                        //}
                        //if (diff >= 0)
                        //{
                        //    Response.Write("<td nowrap align=right>" + Math.Round(diff, 2, MidpointRounding.AwayFromZero) + "</td>");
                        //}
                        wsc = "";
                        fsc = "";
                        wsc = dr["War_Surcharges"].ToString();
                        fsc = dr["Fuel_Surcharges"].ToString();
                        if (wsc == "")
                        {
                            wsc = "0";
                        }
                        if (fsc == "")
                        {
                            fsc = "0";
                        }
                        freight_total = frieght_applied + Convert.ToDecimal(wsc) + Convert.ToDecimal(fsc);
                        total_fr_wsc_fsc = total_fr_wsc_fsc + freight_total;

                        //Response.Write("<td nowrap align=right>" + Math.Round(freight_total, 2, MidpointRounding.AwayFromZero) + "</td>");
                        gsa_com = freight_amount * GSAComm_Rate_rate / 100;
                        total_gsa = total_gsa + gsa_com;
                        //Response.Write("<td nowrap align=right>" + gsa_com + "</td>");

                        if (Principle_Min_status == 13)
                        {
                            OR = diff;
                        }
                        else
                        {
                            OR = diff * ch_wt;
                        }
                        total_OR = total_OR + OR;
                        //if (OR >= 0)
                        //{
                        //    Response.Write("<td nowrap align=right>" + Math.Round(OR, 2, MidpointRounding.AwayFromZero) + "</td>");
                        //}
                        //if (OR < 0)
                        //{
                        //    Response.Write("<td nowrap align=right class=error>" + Math.Round(OR, 2, MidpointRounding.AwayFromZero) + "</td>");

                        //}
                        //Response.Write("<td nowrap align=left>" + dr["Agent_Name"].ToString() + "</td>");
                        //string remarks = dr["Principle_Spot_Rate_Remarks"].ToString();
                        //if (remark == "")
                        //{
                        //    Response.Write("<td>&nbsp;</td>");
                        //}
                        //else
                        //{
                        //    Response.Write("<td>" + remark + "</td>");
                        //}
                        //Response.Write(@"</tr>");

                        //count = count + 1;
                       

                        if (diff < 0)
                        {
                            if (flag == true)
                            {
                                //flagl = false;
                                Response.Write(@"<Table width=100% align=center border=1 >");
                                Response.Write(@"<tr align=center valign=middle>");


                                Response.Write(@"<td class=txtbox><b> " + airline_name + " /" + city_name + "<b></td></tr>");
                                Response.Write(@"<tr><td>");
                                Response.Write(@"<Table width=100% align=center border=1 >");
                                Response.Write(@"<tr align=center valign=middle class=h5>");
                                Response.Write("<td><b>S.No</b></td>");
                                Response.Write("<td><b>Awb No.</b></td>");
                                Response.Write("<td><b>Dest.</b></td>");
                                Response.Write("<td><b>PCS</b></td>");
                                Response.Write("<td><b>PP/CC</b></td>");
                                Response.Write("<td><b>Gr Wt.</b></td>");
                                Response.Write("<td><b>Ch Wt.</b></td>");
                                Response.Write("<td><b>CBM</b></td>");
                                Response.Write("<td><b>Freight</b></td>");
                                Response.Write("<td><b>Inc IATA</b></td>");
                                Response.Write("<td><b>Inc(Agent)</b></td>");
                                Response.Write("<td><b>NN Sold</b></td>");
                                Response.Write("<td><b>AWB Rate</b></td>");
                                Response.Write("<td><b>Spar</b></td>");
                                Response.Write("<td><b>Diff</b></td>");
                                Response.Write("<td><b >Total Freight Charges including MYC/FSC</b></td>");
                                Response.Write("<td><b>GSA comm</b></td>");
                                Response.Write("<td><b>OR</b></td>");
                                Response.Write("<td><b>Agent</b></td>");
                                Response.Write("<td><b>Loss Remarks</b></td>");
                                Response.Write("<td></td>");
                                Response.Write("<td></td>");
                                Response.Write(@"</tr>");


                            }
                            else
                            {
                                flag = false;
                            }
                            flag = false;



                          



                            awbno = dr["AirWayBill_No"].ToString();
                            //Tables += "<tr class=text onclick=ChangeColor(this); ><td nowrap>" + count + "</td><td nowrap>" + awbno + "</td><td nowrap>" + dr["Destination_Code"].ToString() + "</td><td nowrap align=right>" + dr["No_of_Packages"].ToString() + "</td>";
                            Response.Write(@"<tr class=text onclick=ChangeColor(this); >");
                            Response.Write("<td nowrap>" + count + "</td>");
                            Response.Write("<td nowrap>" + awbno + "</td>");
                            Response.Write("<td nowrap>" + dr["Destination_Code"].ToString() + "</td>");
                            Response.Write("<td nowrap align=right>" + dr["No_of_Packages"].ToString() + "</td>");

                            str1 = dr["DueCarrier_Type"].ToString();
                            if (str == "PREPAID")
                            {
                                //Tables += "<td>P</td>";
                                Response.Write("<td>P</td>");
                            }
                            else
                            {
                                //Tables += "<td nowrap>C</td>";
                                Response.Write("<td nowrap>C</td>");
                            }
                            gr_wt = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                            //Tables += "<td nowrap align=right>" + gr_wt + "</td>";
                            Response.Write("<td nowrap align=right>" + gr_wt + "</td>");
                            Total_gr_wt1 = Total_gr_wt1 + gr_wt;
                            ch_wt = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                            //Tables += "<td nowrap align=right>" + ch_wt + "</td>";
                            Response.Write("<td nowrap align=right>" + ch_wt + "</td>");
                            total_ch_wt1 = total_ch_wt1 + ch_wt;

                            cbm = Convert.ToDecimal(dr["Charged_Weight"]) / 167;
                            //Tables += "<td nowrap align=right>" + Math.Round(cbm, 2) + "</td>";
                            Response.Write("<td nowrap align=right>" + Math.Round(cbm, 2) + "</td>");
                            freight_amount = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                            Principle_Min_status = Convert.ToInt32(dr["Principle_Min_status"].ToString());
                            remark = dr["principle_spot_rate_remarks"].ToString();

                            Principle_Spot_Rate = dr["Principle_Spot_Rate"].ToString();
                            //decimal principle_rate = Convert.ToDecimal(dr["principle_rate"].ToString());
                            if (remark == "Book" || remark == "book")
                            {
                                if (Convert.ToDecimal(Principle_Spot_Rate) > 0)
                                {

                                    if (Principle_Min_status == 14)
                                    {
                                        frieght_applied = (ch_wt * Convert.ToDecimal(Principle_Spot_Rate));
                                        spar = Convert.ToDecimal(Principle_Spot_Rate);
                                    }
                                    else
                                    {
                                        frieght_applied = Convert.ToDecimal(Principle_Spot_Rate);
                                        spar = Convert.ToDecimal(Principle_Spot_Rate);
                                    }
                                }
                                else
                                {
                                    if (Principle_Min_status == 14)
                                    {
                                        frieght_applied = ch_wt * Convert.ToDecimal(dr["principle_rate"].ToString()) - ((Convert.ToDecimal(Principle_Spot_Rate) * 5) / 100);
                                        spar = Convert.ToDecimal(principle_rate);

                                    }
                                    else
                                    {
                                        frieght_applied = Convert.ToDecimal(dr["principle_rate"].ToString()) - ((Convert.ToDecimal(Principle_Spot_Rate) * 5) / 100);
                                        spar = Convert.ToDecimal(principle_rate);

                                    }
                                }
                            }
                            else
                            {

                                if (Convert.ToDecimal(Principle_Spot_Rate) > 0)
                                {

                                    if (Principle_Min_status == 14)
                                    {
                                        frieght_applied = ch_wt * Convert.ToDecimal(Principle_Spot_Rate);
                                        spar = Convert.ToDecimal(Principle_Spot_Rate);
                                    }
                                    else
                                    {
                                        frieght_applied = Convert.ToDecimal(Principle_Spot_Rate);
                                        spar = Convert.ToDecimal(Principle_Spot_Rate);
                                    }
                                }
                                else
                                {
                                    if (Principle_Min_status == 14)
                                    {

                                        frieght_applied = ch_wt * principle_rate;
                                        spar = Convert.ToDecimal(principle_rate);
                                    }
                                    else
                                    {
                                        // decimal principle_amount = Convert.ToDecimal(dr["principle_amount"].ToString());
                                        //frieght_applied = principle_amount;
                                        frieght_applied = principle_rate;

                                        spar = Convert.ToDecimal(principle_rate);

                                    }

                                }
                            }
                            //Tables += "<td nowrap align=right>" + Math.Round(frieght_applied, 2, MidpointRounding.AwayFromZero) + "</td>";
                            Response.Write("<td nowrap align=right>" + Math.Round(frieght_applied, 2, MidpointRounding.AwayFromZero) + "</td>");
                            commission = Convert.ToDecimal(dr["Commission"].ToString());

                            if (commission > 0)
                            {
                                //Tables += "<td nowrap align=right>" + commission + "</td>";
                                Response.Write("<td nowrap align=right>" + commission + "</td>");
                            }
                            else
                            {
                                //Tables += "<td nowrap >Spot</td>";
                                Response.Write("<td nowrap >Spot</td>");
                            }
                            chk = Convert.ToDecimal(dr["Special_Commodity_Incentive"].ToString());
                            if (chk > 0)
                            {
                                //Tables += "<td nowrap align=right>" + chk + "</td>";
                                Response.Write("<td nowrap align=right>" + chk + "</td>");
                            }
                            else
                            {
                                //Tables += "<td>Spot</td>";
                                Response.Write("<td>Spot</td>");
                            }

                            if (commission > 0)
                            {
                                //comm =  ( amt  * commission ) / 100

                                comAmt = freight_amount * commission / 100;

                            }
                            comless = freight_amount - comAmt;

                            if (chk > 0)
                            {
                                //inc = (((amt * onFreight) /100 )*scrInc )/100

                                inc = (comless * chk) / 100;
                            }

                            Spot_Rate = Convert.ToDecimal(dr["Spot_Rate"].ToString());
                            tariff_rate = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                            if (Spot_Rate > 0)
                            {
                                spot_diff = (tariff_rate - Spot_Rate) * ch_wt;
                            }
                            nn_amount = freight_amount - comAmt - inc - spot_diff;
                            if (Principle_Min_status == 13)
                            {
                                nn_sold = nn_amount;
                            }
                            else
                            {
                                nn_sold = nn_amount / ch_wt;
                            }
                            //Tables += "<td align=right>" + Math.Round(nn_sold, 2, MidpointRounding.AwayFromZero) + "</td>";

                            Response.Write("<td align=right>" + Math.Round(nn_sold, 2, MidpointRounding.AwayFromZero) + "</td>");
                            //Tables += "<td align=right>" + tariff_rate.ToString() + "</td>";
                            Response.Write("<td align=right>" + tariff_rate.ToString() + "</td>");

                            //spar = Convert.ToDecimal(dr["Special_Rate"].ToString());

                            if (awbno.Substring(0, 3) == "023")
                            {

                                spar = spar - ((spar / 100) * spar_rate);

                            }


                            //Tables += "<td align=right>" + spar + "</td>";

                            Response.Write("<td align=right>" + spar + "</td>");
                            diff = (nn_sold - spar);
                            total_diff1 = total_diff1 + diff;
                            if (diff < 0)
                            {
                                //Tables += "<td nowrap align=right class=error>" + Math.Round(diff, 2, MidpointRounding.AwayFromZero) + "</td>";

                                Response.Write("<td nowrap align=right class=error>" + Math.Round(diff, 2, MidpointRounding.AwayFromZero) + "</td>");
                            }
                            if (diff >= 0)
                            {
                                continue;
                                //Tables += "<td nowrap align=right>" + Math.Round(diff, 2, MidpointRounding.AwayFromZero) + "</td>";
                                Response.Write("<td nowrap align=right>" + Math.Round(diff, 2, MidpointRounding.AwayFromZero) + "</td>");
                            }
                            wsc = "";
                            fsc = "";
                            wsc = dr["War_Surcharges"].ToString();
                            fsc = dr["Fuel_Surcharges"].ToString();
                            if (wsc == "")
                            {
                                wsc = "0";
                            }
                            if (fsc == "")
                            {
                                fsc = "0";
                            }
                            freight_total = frieght_applied + Convert.ToDecimal(wsc) + Convert.ToDecimal(fsc);
                            total_fr_wsc_fsc1 = total_fr_wsc_fsc1 + freight_total;
                            Tables += "<td nowrap align=right>" + Math.Round(freight_total, 2, MidpointRounding.AwayFromZero) + "</td>";

                            Response.Write("<td nowrap align=right>" + Math.Round(freight_total, 2, MidpointRounding.AwayFromZero) + "</td>");
                            gsa_com = freight_amount * GSAComm_Rate_rate / 100;
                            total_gsa1 = total_gsa1 + gsa_com;
                            Response.Write("<td nowrap align=right>" + gsa_com + "</td>");

                            if (Principle_Min_status == 13)
                            {
                                OR = diff;
                            }
                            else
                            {
                                OR = diff * ch_wt;
                            }
                            total_OR1 = total_OR1 + OR;
                            if (OR >= 0)
                            {
                                continue;
                                //Tables += "<td nowrap align=right>" + Math.Round(OR, 2, MidpointRounding.AwayFromZero) + "</td>";
                                Response.Write("<td nowrap align=right>" + Math.Round(OR, 2, MidpointRounding.AwayFromZero) + "</td>");
                            }
                            if (OR < 0)
                            {
                                //Tables += "<td nowrap align=right class=error>" + Math.Round(OR, 2, MidpointRounding.AwayFromZero) + "</td>";
                                Response.Write("<td nowrap align=right class=error>" + Math.Round(OR, 2, MidpointRounding.AwayFromZero) + "</td>");

                            }
                            //Tables += "<td nowrap align=left>" + dr["Agent_Name"].ToString() + "</td>";
                            Response.Write("<td nowrap align=left>" + dr["Agent_Name"].ToString() + "</td>");
                            string remarks = dr["Loss_Remarks"].ToString();
                            if (remarks == "")
                            {
                                //Tables += "<td>&nbsp;</td>";
                                Response.Write("<td class=boldtext>&nbsp;</td>");
                            }
                            else
                            {
                                //Tables += "<td>" + remark + "</td>";
                                Response.Write("<td nowrap><b>" + remarks.ToString().Replace("~","'") + "</b></td>");
                            }
                            string stat=dr["Approve_Status"].ToString();
                            if ((stat == "Yes") || (stat == "No"))
                            {
                                Response.Write("<td>&nbsp;&nbsp;</td>");
                                if (stat == "Yes")
                                {
                                    Response.Write("<td><font color=blue></font><b>Approved</b></td>");
                                }
                                if (stat == "No")
                                {
                                    Response.Write("<td class=error><b>Rejected</b></td>");
                                }

                            }
                            else
                            {
                                Response.Write("<td class=boldtext><a href='lossremarks.aspx?sid=" + dr["sales_id"].ToString() + "&amp;air=" + airline_name + "&amp;city=" + city_name + "&amp;dest=" + dr["Destination_Code"].ToString() + "&amp;diff=" + diff + "&amp;awb=" + awbno + "' >Add/Update</a></td>");
                                Response.Write("<td class=boldtext><a href='lossremarks.aspx?sid=" + dr["sales_id"].ToString() + "&amp;air=" + airline_name + "&amp;city=" + city_name + "&amp;dest=" + dr["Destination_Code"].ToString() + "&amp;awb=" + awbno + "' >Approve</a></td>");
                            }
                            //Tables += "</tr>";
                            Response.Write(@"</tr>");

                            //count = count + 1;
                            //cbm = 0;
                            //chk = 0;
                            //gr_wt = 0;
                            //ch_wt = 0;
                            //comAmt = 0;
                            //freight_amount = 0;
                            //commission = 0;
                            //sp_com = 0;
                            //inc = 0;
                            //Spot_Rate = 0;
                            //tariff_rate = 0;
                            //spot_diff = 0;
                            //nn_amount = 0;
                            //comless = 0;
                            //nn_sold = 0;
                            //spar = 0;
                            //freight_total = 0;
                       
                        count = count + 1;
                        cbm = 0;
                        chk = 0;
                        gr_wt = 0;
                        ch_wt = 0;
                        comAmt = 0;
                        freight_amount = 0;
                        commission = 0;
                        sp_com = 0;
                        inc = 0;
                        Spot_Rate = 0;
                        tariff_rate = 0;
                        spot_diff = 0;
                        nn_amount = 0;
                        comless = 0;
                        nn_sold = 0;
                        spar = 0;
                        freight_total = 0;


                        }

                        cbm = 0;
                        chk = 0;
                        gr_wt = 0;
                        ch_wt = 0;
                        comAmt = 0;
                        freight_amount = 0;
                        commission = 0;
                        sp_com = 0;
                        inc = 0;
                        Spot_Rate = 0;
                        tariff_rate = 0;
                        spot_diff = 0;
                        nn_amount = 0;
                        comless = 0;
                        nn_sold = 0;
                        spar = 0;
                        freight_total = 0;
                    }
                    //Tables += "<tr align=center valign=bottom class=h1><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><strong>Total</strong></td><td nowrap align=right><b>" + Total_gr_wt1.ToString() + "</b></td><td align=right><b>" + total_ch_wt1.ToString() + "</b></td><td><b>&nbsp;</b></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td nowrap align=right><b>" + Math.Round(total_diff1, 2, MidpointRounding.AwayFromZero) + "</b></td><td nowrap align=right><b>" + Math.Round(total_fr_wsc_fsc1, 2, MidpointRounding.AwayFromZero) + "</b></td><td nowrap align=right><b>" + Math.Round(total_gsa1, 2, MidpointRounding.AwayFromZero) + "</b></td><td nowrap align=right><b>" + Math.Round(total_OR1, 2, MidpointRounding.AwayFromZero) + "</b></td><td>&nbsp;</td><td>&nbsp;</td></tr></table></td></tr></table><br>";
                   if(flag==false)
                   {
                        Response.Write(@"<tr align=center valign=bottom class=h1>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td><strong>Total</strong></td>");
                        Response.Write("<td nowrap align=right><b>" + Total_gr_wt1.ToString() + "</b></td>");
                        Response.Write("<td align=right><b>" + total_ch_wt1.ToString() + "</b></td>");
                        Response.Write("<td><b>&nbsp;</b></td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td nowrap align=right><b>" + Math.Round(total_diff1, 2, MidpointRounding.AwayFromZero) + "</b></td>");
                        Response.Write("<td nowrap align=right><b>" + Math.Round(total_fr_wsc_fsc1, 2, MidpointRounding.AwayFromZero) + "</b></td>");
                        Response.Write("<td nowrap align=right><b>" + Math.Round(total_gsa1, 2, MidpointRounding.AwayFromZero) + "</b></td>");
                        Response.Write("<td nowrap align=right><b>" + Math.Round(total_OR1, 2, MidpointRounding.AwayFromZero) + "</b></td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write("<td>&nbsp;</td>");
                        Response.Write(@"</tr>");
                        Response.Write(@"</table>");
                        Response.Write(@"</td></tr>");
                        Response.Write(@"</table>");
                        Response.Write("<br>");
                }
                        count = 1;
                        dr.Close();
                        Total_gr_wt1 = 0;
                        total_ch_wt1 = 0;
                        total_fr_wsc_fsc1 = 0;
                        total_diff1 = 0;
                        total_gsa1 = 0;
                        total_OR1 = 0;
                    
                    
                    
                }
                dr.Close();


            }



            catch (Exception eror)
            {

                string st = eror.ToString();
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }




        }
        
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
