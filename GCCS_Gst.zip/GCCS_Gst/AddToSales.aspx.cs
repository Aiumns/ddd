using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AddToSales : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                ShowData();

                if (Session["groupid"].ToString() != "1")
                {
                    grdHandoverDetails.Columns[0].Visible = false;
                }
                else
                {
                    grdHandoverDetails.Columns[0].Visible = true;

                }
            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ShowData();

    }

    protected void btnNoShow_Click(object sender, EventArgs e)
    {

    }
    protected void btnAddToDeal_Click(object sender, EventArgs e)
    {
        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblhnd_ID = (Label)grdRow.FindControl("lblHandoverID");
        string strField1 = lblhnd_ID.Text;
        Response.Redirect("Sales_New.aspx?Handover_ID=" + strField1 + " ");

    }

    protected void btnVoid_Click(object sender, EventArgs e)
    {

    }

    protected void ShowData()
    {
        string searchStr = "";
        searchStr = "select a.handover_id,a.booking_id,a.stock_id,b.AirWayBill_No,c.agent_name,e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.Added_To_Sales=14";

        if (txtSearch.Text != "")
        {
            searchStr = "select a.handover_id,a.booking_id,a.stock_id,b.AirWayBill_No,c.agent_name,e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.Added_To_Sales=14 and " + ddlSerach.SelectedValue + " like '" + txtSearch.Text.Trim() + "%' ";

        }

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            SqlDataAdapter sda = new SqlDataAdapter(searchStr, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            grdHandoverDetails.DataSource = dt;
            grdHandoverDetails.DataBind();
            con.Close();

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    protected void grdHandoverDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdHandoverDetails.PageIndex = e.NewPageIndex;
        ShowData();
    }
    protected void grdHandoverDetails_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
