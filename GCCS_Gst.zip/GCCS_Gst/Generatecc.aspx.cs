using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Generatecc : System.Web.UI.Page
{
    public string page_pop = "";
    string agentName = null;
    string tableAll = null, comName = null;
    string massage = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    static string csrFooter = null;
    DisplayWrap dw = new DisplayWrap();
   

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
                hdnDate.Value = first.ToString();
                Page.Form.Target = "_blank";
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");

                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 1;
                ddlMonth.Items[dt - 1].Selected = true;
                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();
                ShowAirline();
                if (Session["groupid"].ToString() != "5")
                {
                    ddlAirLine.AutoPostBack = true;
                    Pantab.Visible = true;

                }
                else
                {
                    Pantab.Visible = false;
                    ddlAirLine.AutoPostBack = false;
                    lstAgent.Items.Clear();
                    lstAgent.Items.Add(new ListItem(Session["AGENT_NAME"].ToString(), Session["ID"].ToString()));
                    lstAgent.Items[0].Selected = true;

                }

            }

        }

    }

    protected void ShowAirline()
    {

        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ")  order by Airline_Name", con);
            //com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and C.airline_detail_id in (148,147,150,153,154,155,156) order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select Airline Name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));

            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        string agentId = null;
        string bID = null;

        lstAgent.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select airline_detail_id,belongs_to_city,Csr_Footer from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
            dr = com.ExecuteReader();
            if (dr.Read())
            {
                agentId = dr["airline_detail_id"].ToString();
                bID = dr["belongs_to_city"].ToString();
                csrFooter = dr["Csr_Footer"].ToString();
                char ch = (char)System.Windows.Forms.Keys.Return;
                char ch2 = (char)System.Windows.Forms.Keys.Space;
                string ch1 = Convert.ToString(ch);
                string ch3 = Convert.ToString(ch2);
                csrFooter = csrFooter.Replace(ch1, "<br>");
                csrFooter = csrFooter.Replace(ch3, "&nbsp;");
            }
            dr.Dispose();
            com.Dispose();
            com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + agentId + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                lstAgent.Items.Add(new ListItem(dr["agent_name"].ToString(), dr["agent_id"].ToString()));
            }
            if (Session["groupid"].ToString() == "5")
            {
                lstAgent.SelectedIndex = lstAgent.Items.IndexOf(lstAgent.Items.FindByText(Session["AGENT_NAME"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        string comAdd = null;
        string[] airlineName = ddlAirLine.SelectedItem.Text.Split('-');
        string airline = "A/C " + airlineName[0].ToUpper().ToString();

        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();
        string strY = ddlyear.SelectedItem.Text.Trim();

        if (rbtnFirstFortn.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }


        }
        if(airlineName[0]=="MALAYSIAN AIRLINES")
        {
         string VarDate = "08/15/2008";
         if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
         {
             string approveCsr = checkApprove(TextBox1.Text, TextBox2.Text);
             con = new SqlConnection(strCon);
             con.Open();
             string agnetID = "";
             string aID = "";
             string city_id = "";
             if (Session["groupid"].ToString() != "5")
             {
                 for (int k = 0; k < lstAgent.Items.Count; k++)
                 {
                     if (lstAgent.Items[k].Selected == true)
                     {
                         decimal TotChAmount = 0;
                         decimal TotDueCar = 0;
                         decimal TotAgentExp = 0;
                         decimal TotComm = 0;
                         decimal TotDiscount = 0;
                         decimal TotFrAmount = 0;
                         decimal lastTsdsRate = 0;
                         decimal lastSurcharge = 0;
                         decimal Tds_discount = 0;
                         decimal TotTds = 0;
                         decimal EduChrg = 0; decimal Total = 0;
                         decimal GrandTotal = 0;
                         decimal surCharge = 0;

                         string table = null;
                         aID = ddlAirLine.SelectedItem.Value;
                         agnetID = lstAgent.Items[k].Value;
                         agentName = lstAgent.Items[k].Text;
                         con = new SqlConnection(strCon);
                         con.Open();
                         com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);
                        
                         dr = com.ExecuteReader();
                         if (dr.Read())
                         {
                             city_id = dr["City_id"].ToString();
                             com.Dispose();
                             dr.Dispose();
                             com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 comAdd = dr["company_address"].ToString();
                                 comName = dr["company_name"].ToString();
                                 table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                             }
                             com.Dispose();
                             dr.Dispose();
                             com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 string s = dr["agent_address"].ToString();
                                 char ch = (char)System.Windows.Forms.Keys.Return;
                                 char ch2 = (char)System.Windows.Forms.Keys.Space;
                                 string ch1 = Convert.ToString(ch);
                                 string ch3 = Convert.ToString(ch2);
                                 string h = s.Replace(ch1, "<br>");
                                 h = h.Replace(ch3, "&nbsp;");

                                 table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
</div>
<br>";
                             }
                             com.Dispose();
                             dr.Dispose();

                             table += @"<table style=""word-spacing:inherit"" width=""95%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable<br> Frt</th><th >Due <br>Carrier</th><th >Agent <br>Expenses</th><th >Commission</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""10"" align=""center""></td>
</tr><tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                             com = new SqlCommand("mh_cc", con);
                             com.CommandType = CommandType.StoredProcedure;
                             com.Parameters.AddWithValue("agent_id", agnetID);
                             com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                             com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                             com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 lastTsdsRate = 0.0000M;
                                 lastSurcharge = 0.0000M;
                                 string ss = dr["Used_Date"].ToString();
                                 TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2);
                                 TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                  TotComm += decimal.Parse(dr["Commissionable_Amount"].ToString());
                                 TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                 if (dr["tds"].ToString() != "0.0000")
                                     lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                 if (dr["surcharge"].ToString() != "0.0000")
                                     lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                 Tds_discount =Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString())+ decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate) ) / 100);
                                TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                 TotTds += Tds_discount;
                                 surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                 EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                 table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                             }
                             com.Dispose();
                             dr.Dispose();
                             table += @"<tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                             Total = Math.Round(((TotComm + TotDiscount + TotAgentExp) -Math.Ceiling(TotTds) - surCharge - EduChrg), MidpointRounding.AwayFromZero);
                             table += @"<tr > <td colspan=""10""  align=""center""> </td> </tr>";
                             table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount,2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td></tr>";
                             table += @"<tr class=""boldtext""> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext"">	<td colspan=""8"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""></tr>";
                             if (Math.Round(surCharge) != 0)
                                 table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                             table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                                      
                             table += @"<tr class=""boldtext""> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right"" ><img src=""images/line2.gif""></td></tr>";

                             table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                             table += @"<tr> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                             string font = null;
                             GrandTotal = Total;
                             if (Math.Round((Total)) > 0)
                             {
                                 massage = "Total payable To ";
                                 font = "<font color='red'>";
                                 GrandTotal = Math.Round(Total);
                             }


                             table += @"<tr class=""boldtext""><th colspan=""8"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                         }

                         if (GrandTotal > 0)
                             tableAll = tableAll + table;

                         Session["dt"] = tableAll;
                     }
                 }
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                 if (tableAll == "" || tableAll == null)
                     Session["dt"] = mass;
             }
             else if (approveCsr == "notApprove")
             {               
                 decimal TotChAmount = 0;
                 decimal TotAgentExp = 0;
                 decimal TotComm = 0;
                 decimal TotDiscount = 0;
                 decimal TotFrAmount = 0;
                 decimal lastTsdsRate = 0;
                 decimal lastSurcharge = 0;
                 decimal Tds_discount = 0;
                 decimal TotTds = 0;
                 decimal EduChrg = 0;
                 decimal surCharge = 0;

                 string table = null;
                 aID = ddlAirLine.SelectedItem.Value;
                 agnetID = lstAgent.SelectedValue;
                 con = new SqlConnection(strCon);
                 con.Open();

                 com = new SqlCommand("select distinct agent_id from sales where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' and Sales.city_id=" + city_id + " ", con);



                 dr = com.ExecuteReader();
                 if (dr.HasRows)
                 {
                     com.Dispose();
                     dr.Dispose();

                     table += @"<p><font color=""red"" size=""2""> The CSR not Generated for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @".</font><br> The following AWB No are in this period:</p>";

                     table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Commission</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""10"" align=""center""></td>
</tr><tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                     com = new SqlCommand("mh_cc", con);
                     com.CommandType = CommandType.StoredProcedure;
                     com.Parameters.AddWithValue("agent_id", agnetID);
                     com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                     com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                     com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                     dr = com.ExecuteReader();
                     while (dr.Read())
                     {
                         lastTsdsRate = 0.0000M;
                         lastSurcharge = 0.0000M;
                        string ss = dr["Used_Date"].ToString();
                         TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
                         TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                          TotComm += decimal.Parse(dr["Commissionable_Amount"].ToString());
                         TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                         if (dr["tds"].ToString() != "0.0000")
                             lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                         if (dr["surcharge"].ToString() != "0.0000")
                             lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                         Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100);
                          TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                         TotTds += Tds_discount;
                         surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                         EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                         table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                     }
                     com.Dispose();
                     dr.Dispose();
                     table += @"</table>";
                 }

                 tableAll = tableAll + table;
                 Session["dt"] = tableAll;
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                 if (tableAll == "" || tableAll == null)
                     Session["dt"] = mass;

             }
             else
             {

                 for (int k = 0; k < lstAgent.Items.Count; k++)
                 {
                     if (lstAgent.Items[k].Selected == true)
                     {
                         decimal TotChAmount = 0;
                         decimal TotDueCar = 0;
                         decimal TotAgentExp = 0;
                         decimal TotComm = 0;
                         decimal TotDiscount = 0;
                         decimal TotFrAmount = 0;
                         decimal lastTsdsRate = 0;
                         decimal lastSurcharge = 0;
                         decimal Tds_discount = 0;
                         decimal TotTds = 0;
                         decimal EduChrg = 0; decimal Total = 0;
                         decimal GrandTotal = 0;
                         decimal surCharge = 0;

                         string table = null;
                         aID = ddlAirLine.SelectedItem.Value;
                         agnetID = lstAgent.Items[k].Value;
                         agentName = lstAgent.Items[k].Text;
                         con = new SqlConnection(strCon);
                         con.Open();
                         com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);



                         dr = com.ExecuteReader();
                         if (dr.HasRows)
                         {
                             city_id = dr["city_id"].ToString();

                             com.Dispose();
                             dr.Dispose();

                             com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 comAdd = dr["company_address"].ToString();
                                 comName = dr["company_name"].ToString();
                                 table += @"<table   width=""100%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                             }
                             com.Dispose();
                             dr.Dispose();
                             com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);

                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 string s = dr["agent_address"].ToString();
                                 char ch = (char)System.Windows.Forms.Keys.Return;
                                 char ch2 = (char)System.Windows.Forms.Keys.Space;
                                 string ch1 = Convert.ToString(ch);
                                 string ch3 = Convert.ToString(ch2);
                                 string h = s.Replace(ch1, "<br>");
                                 h = h.Replace(ch3, "&nbsp;");

                                 table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                             }
                             com.Dispose();
                             dr.Dispose();

                             table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""10"" align=""center""></td>
</tr><tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                             com = new SqlCommand("mh_cc", con);
                             com.CommandType = CommandType.StoredProcedure;
                             com.Parameters.AddWithValue("agent_id", agnetID);
                             com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                             com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                             com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 lastTsdsRate = 0.0000M;
                                 lastSurcharge = 0.0000M;
                                 string ss = dr["Used_Date"].ToString();
                                 TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
                                 TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                  TotComm += decimal.Parse(dr["Commissionable_Amount"].ToString());
                                 TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                 if (dr["tds"].ToString() != "0.0000")
                                     lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                 if (dr["surcharge"].ToString() != "0.0000")
                                     lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                 Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100); 
                                  TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                 TotTds += Tds_discount;
                                 surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                 EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                 table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                             }
                             com.Dispose();
                             dr.Dispose();
                             table += @"<tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                             Total = Math.Round(((TotDiscount + TotComm + TotAgentExp) - Math.Ceiling(TotTds) - surCharge - EduChrg));
                             table += @"<tr > <td colspan=""10""  align=""center""> </td> </tr>";
                             table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar, MidpointRounding.AwayFromZero) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp; </td></tr>";
                             table += @"<tr class=""boldtext""> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext"">	<td colspan=""8"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""></tr>";
                             if (Math.Round(surCharge) != 0)
                                 table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                   table += @"<tr class=""boldtext""> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right"" colspan=""8"" ><img src=""images/line2.gif""></td></tr>";

                             table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                             table += @"<tr> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                             string font = null;
                             GrandTotal = Total;
                             if (Math.Round((Total)) > 0)
                             {
                                 massage = "Total payable To ";
                                 font = "<font color='red'>";
                                 GrandTotal = Math.Round(Total);
                             }


                             table += @"<tr class=""boldtext""><th colspan=""8"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                         }

                         if (GrandTotal > 0)
                             tableAll = tableAll + table;

                         Session["dt"] = tableAll;
                     }
                 }
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                 if (tableAll == "" || tableAll == null)
                     Session["dt"] = mass;
             }
             Response.Redirect("Csr_mhCC.aspx");
         }
         else
         {
             string approveCsr = checkApprove(TextBox1.Text, TextBox2.Text);

             con = new SqlConnection(strCon);
             con.Open();

             string agnetID = "";
             string aID = "";
             string city_id = "";
             if (Session["groupid"].ToString() != "5")
             {
                 for (int k = 0; k < lstAgent.Items.Count; k++)
                 {
                     if (lstAgent.Items[k].Selected == true)
                     {
                         decimal TotChAmount = 0;
                         decimal TotDueCar = 0;
                         decimal TotAgentExp = 0;
                         decimal TotDiscount = 0;
                         decimal TotFrAmount = 0;
                         decimal lastTsdsRate = 0;
                         decimal lastSurcharge = 0;
                         decimal Tds_discount = 0;
                         decimal TotTds = 0;
                         decimal EduChrg = 0; decimal Total = 0;
                         decimal GrandTotal = 0;
                         decimal surCharge = 0;

                         string table = null;
                         aID = ddlAirLine.SelectedItem.Value;
                         agnetID = lstAgent.Items[k].Value;
                         agentName = lstAgent.Items[k].Text;
                         con = new SqlConnection(strCon);
                         con.Open();
                         com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);
                         dr = com.ExecuteReader();
                         if (dr.Read())
                         {
                             city_id = dr["City_id"].ToString();
                             com.Dispose();
                             dr.Dispose();
                             com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 comAdd = dr["company_address"].ToString();
                                 comName = dr["company_name"].ToString();
                                 table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                             }
                             com.Dispose();
                             dr.Dispose();                             
                             com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 string s = dr["agent_address"].ToString();
                                 char ch = (char)System.Windows.Forms.Keys.Return;
                                 char ch2 = (char)System.Windows.Forms.Keys.Space;
                                 string ch1 = Convert.ToString(ch);
                                 string ch3 = Convert.ToString(ch2);
                                 string h = s.Replace(ch1, "<br>");
                                 h = h.Replace(ch3, "&nbsp;");

                                 table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>          
</div>
<br>";
                             }
                             com.Dispose();
                             dr.Dispose();

                             table += @"<table style=""word-spacing:inherit"" width=""95%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable<br> Frt</th><th >Due <br>Carrier</th><th >Agent <br>Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                             com = new SqlCommand("mh_cc", con);
                             com.CommandType = CommandType.StoredProcedure;
                             com.Parameters.AddWithValue("agent_id", agnetID);
                             com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                             com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                             com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 lastTsdsRate = 0.0000M;
                                 lastSurcharge = 0.0000M;
                                 string ss = dr["Used_Date"].ToString();
                                 TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
                                 TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                 TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                 if (dr["tds"].ToString() != "0.0000")
                                     lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                 if (dr["surcharge"].ToString() != "0.0000")
                                     lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                 Tds_discount = Math.Ceiling((decimal.Parse(dr["MHDiscount"].ToString()) * lastTsdsRate) / 100);
                                  TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                 TotTds += Tds_discount;
                                 surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                 EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                 table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                             }
                             com.Dispose();
                             dr.Dispose();
                             table += @"<tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                             Total = Math.Round((TotDiscount - Math.Ceiling(TotTds) - surCharge - EduChrg), MidpointRounding.AwayFromZero);
                             table += @"<tr > <td colspan=""9""  align=""center""> </td> </tr>";
                             table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td></tr>";
                             table += @"<tr class=""boldtext""> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""7"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""></tr>";
                             if (Math.Round(surCharge) != 0)
                                 table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";
          table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                              table += @"<tr class=""boldtext""> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right"" ><img src=""images/line2.gif""></td></tr>";

                             table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                             table += @"<tr> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                             string font = null;
                             GrandTotal = Total;
                             if (Math.Round((Total)) > 0)
                             {
                                 massage = "Total payable To ";
                                 font = "<font color='red'>";
                                 GrandTotal = Math.Round(Total);
                             }


                             table += @"<tr class=""boldtext""><th colspan=""7"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                         }

                         if (GrandTotal > 0)
                             tableAll = tableAll + table;

                         Session["dt"] = tableAll;
                     }
                 }
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                 if (tableAll == "" || tableAll == null)
                     Session["dt"] = mass;
             }
             else if (approveCsr == "notApprove")
             {               
                 decimal TotChAmount = 0;            
                 decimal TotAgentExp = 0;
                 decimal TotDiscount = 0;
                 decimal TotFrAmount = 0;
                 decimal lastTsdsRate = 0;
                 decimal lastSurcharge = 0;
                 decimal Tds_discount = 0;
                 decimal TotTds = 0;
                 decimal EduChrg = 0;
                 decimal surCharge = 0;

                 string table = null;
                 aID = ddlAirLine.SelectedItem.Value;
                 agnetID = lstAgent.SelectedValue;
                 con = new SqlConnection(strCon);
                 con.Open();

                 com = new SqlCommand("select distinct agent_id from sales where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' and Sales.city_id=" + city_id + " ", con);



                 dr = com.ExecuteReader();
                 if (dr.HasRows)
                 {
                     com.Dispose();
                     dr.Dispose();

                     table += @"<p><font color=""red"" size=""2""> The CSR not Generated for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @".</font><br> The following AWB No are in this period:</p>";

                     table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                     com = new SqlCommand("mh_cc", con);
                     com.CommandType = CommandType.StoredProcedure;
                     com.Parameters.AddWithValue("agent_id", agnetID);
                     com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                     com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                     com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                     dr = com.ExecuteReader();
                     while (dr.Read())
                     {
                         lastTsdsRate = 0.0000M;
                         lastSurcharge = 0.0000M;
                         string ss = dr["Used_Date"].ToString();
                         TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
                         TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                         TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                         if (dr["tds"].ToString() != "0.0000")
                             lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                         if (dr["surcharge"].ToString() != "0.0000")
                             lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                         Tds_discount = Math.Ceiling((decimal.Parse(dr["MHDiscount"].ToString()) * lastTsdsRate) / 100);
                          TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                         TotTds += Tds_discount;
                         surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                         EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                         table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                     }
                     com.Dispose();
                     dr.Dispose();
                     table += @"</table>";
                 }

                 tableAll = tableAll + table;
                 Session["dt"] = tableAll;
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                 if (tableAll == "" || tableAll == null)
                     Session["dt"] = mass;

             }
             else
             {

                 for (int k = 0; k < lstAgent.Items.Count; k++)
                 {
                     if (lstAgent.Items[k].Selected == true)
                     {
                         decimal TotChAmount = 0;
                         decimal TotDueCar = 0;
                         decimal TotAgentExp = 0;                      
                         decimal TotDiscount = 0;
                         decimal TotFrAmount = 0;
                         decimal lastTsdsRate = 0;
                         decimal lastSurcharge = 0;                  
                         decimal Tds_discount = 0;
                         decimal TotTds = 0;
                         decimal EduChrg = 0; decimal Total = 0;
                         decimal GrandTotal = 0;
                         decimal surCharge = 0;

                         string table = null;
                         aID = ddlAirLine.SelectedItem.Value;
                         agnetID = lstAgent.Items[k].Value;
                         agentName = lstAgent.Items[k].Text;
                         con = new SqlConnection(strCon);
                         con.Open();
                         com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);



                         dr = com.ExecuteReader();
                         if (dr.HasRows)
                         {
                             city_id = dr["city_id"].ToString();

                             com.Dispose();
                             dr.Dispose();

                             com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 comAdd = dr["company_address"].ToString();
                                 comName = dr["company_name"].ToString();
                                 table += @"<table   width=""100%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                             }
                             com.Dispose();
                             dr.Dispose();
                             com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);

                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 string s = dr["agent_address"].ToString();
                                 char ch = (char)System.Windows.Forms.Keys.Return;
                                 char ch2 = (char)System.Windows.Forms.Keys.Space;
                                 string ch1 = Convert.ToString(ch);
                                 string ch3 = Convert.ToString(ch2);
                                 string h = s.Replace(ch1, "<br>");
                                 h = h.Replace(ch3, "&nbsp;");

                                 table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                             }
                             com.Dispose();
                             dr.Dispose();

                             table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                             com = new SqlCommand("mh_cc", con);
                             com.CommandType = CommandType.StoredProcedure;
                             com.Parameters.AddWithValue("agent_id", agnetID);
                             com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                             com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                             com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                             dr = com.ExecuteReader();
                             while (dr.Read())
                             {
                                 lastTsdsRate = 0.0000M;
                                 lastSurcharge = 0.0000M;
                                 string ss = dr["Used_Date"].ToString();
                                 TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
                                 TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                 TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                 if (dr["tds"].ToString() != "0.0000")
                                     lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                 if (dr["surcharge"].ToString() != "0.0000")
                                     lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                 Tds_discount = Math.Ceiling((decimal.Parse(dr["MHDiscount"].ToString()) * lastTsdsRate) / 100);
                                  TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                 TotTds += Tds_discount;
                                 surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                 EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                 table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                             }
                             com.Dispose();
                             dr.Dispose();
                             table += @"<tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                             Total = Math.Round((TotDiscount - Math.Ceiling(TotTds) - surCharge - EduChrg));
                             table += @"<tr > <td colspan=""9""  align=""center""> </td> </tr>";
                             table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar, MidpointRounding.AwayFromZero) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp; </td></tr>";
                             table += @"<tr class=""boldtext""> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""7"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""></tr>";

                             if (Math.Round(surCharge) != 0)
                                 table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";
                             table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                            
                             table += @"<tr class=""boldtext""> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right"" colspan=""7"" ><img src=""images/line2.gif""></td></tr>";

                             table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                             table += @"<tr> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                             string font = null;
                             GrandTotal = Total;
                             if (Math.Round((Total)) > 0)
                             {
                                 massage = "Total payable To ";
                                 font = "<font color='red'>";
                                 GrandTotal = Math.Round(Total);
                             }


                             table += @"<tr class=""boldtext""><th colspan=""7"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                         }

                         if (GrandTotal > 0)
                             tableAll = tableAll + table;

                         Session["dt"] = tableAll;
                     }
                 }
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                 if (tableAll == "" || tableAll == null)
                     Session["dt"] = mass;
             }
             Response.Redirect("Csr_mhCC.aspx");
            

         }
            
            
         }
         else if (airlineName[0] == "TURKISH AIRLINES")
         
        {
             string VarDate = "07/31/2008";
             if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
             {
                
                 string approveCsr = checkApprove(TextBox1.Text, TextBox2.Text);

                 con = new SqlConnection(strCon);
                 con.Open();

                 string agnetID = "";
                 string aID = "";
                 string city_id = "";
                 if (Session["groupid"].ToString() != "5")
                 {
                     for (int k = 0; k < lstAgent.Items.Count; k++)
                     {
                         if (lstAgent.Items[k].Selected == true)
                         {
                             decimal TotChAmount = 0;
                             decimal TotDueCar = 0;
                             decimal TotAgentExp = 0;
                             decimal TotComm = 0;
                             decimal TotDiscount = 0;
                             decimal TotFrAmount = 0;
                             decimal lastTsdsRate = 0;
                             decimal lastSurcharge=0;
                             decimal surCharge = 0;
                             decimal Tds_discount = 0;
                             decimal TotTds = 0;
                             decimal EduChrg = 0; decimal Total = 0;
                             decimal GrandTotal = 0;

                             string table = null;
                             aID = ddlAirLine.SelectedItem.Value;
                             agnetID = lstAgent.Items[k].Value;
                             agentName = lstAgent.Items[k].Text;
                             con = new SqlConnection(strCon);
                             con.Open();
                            
                             com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);


                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 city_id = dr["City_id"].ToString();
                                 com.Dispose();
                                 dr.Dispose();
                                
                                 com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     comAdd = dr["company_address"].ToString();
                                     comName = dr["company_name"].ToString();
                                     table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();
                                
                                 com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                                 dr = com.ExecuteReader();
                                 if (dr.Read())
                                 {
                                     string s = dr["agent_address"].ToString();
                                     char ch = (char)System.Windows.Forms.Keys.Return;
                                     char ch2 = (char)System.Windows.Forms.Keys.Space;
                                     string ch1 = Convert.ToString(ch);
                                     string ch3 = Convert.ToString(ch2);
                                     string h = s.Replace(ch1, "<br>");
                                     h = h.Replace(ch3, "&nbsp;");

                                     table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                 table += @"<table style=""word-spacing:inherit"" width=""95%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable<br> Frt</th><th >Due <br>Carrier</th><th >Agent <br>Expenses</th><th >Commission</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                 com = new SqlCommand("TK_CC", con);
                                 com.CommandType = CommandType.StoredProcedure;
                                 com.Parameters.AddWithValue("agent_id", agnetID);
                                 com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                 com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                 com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     lastTsdsRate = 0.0000M;
                                     lastSurcharge = 0.0000M;
                                     string ss = dr["Used_Date"].ToString();
                                     TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
                                    
                                     TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()),MidpointRounding.AwayFromZero);
                                     TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()),MidpointRounding.AwayFromZero);
                                     TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                     if (dr["tds"].ToString() != "0.0000")
                                         lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                      if (dr["surcharge"].ToString() != "0.0000")
                                         lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                     Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100); ;
                                     TotFrAmount += Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()),MidpointRounding.AwayFromZero);
                                     TotTds += Tds_discount;
                                     surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);



                                     table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + decimal.Parse(dr["Freight_Amount"].ToString()) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();
                                 table += @"<tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                 Total = Math.Round(((TotComm + TotDiscount + TotAgentExp) - Math.Ceiling(TotTds) - surCharge - EduChrg), MidpointRounding.AwayFromZero);
                                 table += @"<tr > <td colspan=""10""  align=""center""> </td> </tr>";
                                 table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td></tr>";

                                 
                                 table += @"<tr class=""boldtext""> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext"">	<td colspan=""8"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                 table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                                 table += @"<tr class=""boldtext""></tr>";

                               
                                 if (Math.Round(surCharge) != 0)
                                     table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                                 table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                 
                                

                                 table += @"<tr class=""boldtext""> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right"" ><img src=""images/line2.gif""></td></tr>";

                                 table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                 table += @"<tr> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                 string font = null;
                                 GrandTotal = Total;
                                 if (Math.Round((Total)) > 0)
                                 {
                                     massage = "Total payable To ";
                                     font = "<font color='red'>";
                                     GrandTotal = Math.Round(Total);
                                 }


                                 table += @"<tr class=""boldtext""><th colspan=""8"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                             }

                             if (GrandTotal > 0)
                                 tableAll = tableAll + table;

                             Session["dt"] = tableAll;
                         }
                     }
                     string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     if (tableAll == "" || tableAll == null)
                         Session["dt"] = mass;
                 }
                 else if (approveCsr == "notApprove")
                 {
                    
                     decimal TotChAmount = 0;
                     decimal TotAgentExp = 0;
                     decimal TotComm = 0;
                     decimal TotDiscount = 0;
                     decimal TotFrAmount = 0;
                     decimal lastTsdsRate = 0;
                     decimal Tds_discount = 0;
                     decimal TotTds = 0;
                     decimal EduChrg = 0;
                     decimal lastSurcharge = 0;
                     decimal surCharge = 0;

                     string table = null;
                     aID = ddlAirLine.SelectedItem.Value;
                     agnetID = lstAgent.SelectedValue;
                     con = new SqlConnection(strCon);
                     con.Open();

                     com = new SqlCommand("select distinct agent_id from sales where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect'  ", con);



                     dr = com.ExecuteReader();
                     if (dr.HasRows)
                     {
                        
                         com.Dispose();
                         dr.Dispose();

                         table += @"<p><font color=""red"" size=""2""> The CSR not Generated for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @".</font><br> The following AWB No are in this period:</p>";

                         table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Commission</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                         com = new SqlCommand("TK_CC", con);
                         com.CommandType = CommandType.StoredProcedure;
                         com.Parameters.AddWithValue("agent_id", agnetID);
                         com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                         com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                         com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                         dr = com.ExecuteReader();
                         while (dr.Read())
                         {
                             lastTsdsRate = 0.0000M;
                             lastSurcharge = 0.0000M;
                             string ss = dr["Used_Date"].ToString();
                             TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
                             
                             TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()),MidpointRounding.AwayFromZero);
                             TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()),MidpointRounding.AwayFromZero);
                             TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero); 
                             if (dr["tds"].ToString() != "0.0000")
                                 lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                             if (dr["surcharge"].ToString() != "0.0000")
                                 lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                             Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100);
                             TotFrAmount += Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()),MidpointRounding.AwayFromZero);
                             TotTds += Tds_discount;
                             surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                             EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);



                             table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                         }
                         com.Dispose();
                         dr.Dispose();
                         table += @"</table>";
                     }

                     tableAll = tableAll + table;
                     Session["dt"] = tableAll;
                    
                     string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     if (tableAll == "" || tableAll == null)
                         Session["dt"] = mass;

                 }
                 else
                 {

                     for (int k = 0; k < lstAgent.Items.Count; k++)
                     {
                         if (lstAgent.Items[k].Selected == true)
                         {
                             decimal TotChAmount = 0;
                             decimal TotDueCar = 0;
                             decimal TotAgentExp = 0;
                             decimal TotComm = 0;
                             decimal TotDiscount = 0;
                             decimal TotFrAmount = 0;
                             decimal lastTsdsRate = 0;
                             decimal Tds_discount = 0;
                             decimal TotTds = 0;
                             decimal EduChrg = 0; decimal Total = 0;
                             decimal GrandTotal = 0;

                             decimal lastSurcharge = 0;
                             decimal surCharge = 0;

                             string table = null;
                             aID = ddlAirLine.SelectedItem.Value;
                             agnetID = lstAgent.Items[k].Value;
                             agentName = lstAgent.Items[k].Text;
                             con = new SqlConnection(strCon);
                             con.Open();
                             com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);



                             dr = com.ExecuteReader();
                             if (dr.HasRows)
                             {
                                 city_id = dr["city_id"].ToString();

                                 com.Dispose();
                                 dr.Dispose();

                                 com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     comAdd = dr["company_address"].ToString();
                                     comName = dr["company_name"].ToString();
                                     table += @"<table   width=""100%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();
                                 com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);

                                 dr = com.ExecuteReader();
                                 if (dr.Read())
                                 {
                                     string s = dr["agent_address"].ToString();
                                     char ch = (char)System.Windows.Forms.Keys.Return;
                                     char ch2 = (char)System.Windows.Forms.Keys.Space;
                                     string ch1 = Convert.ToString(ch);
                                     string ch3 = Convert.ToString(ch2);
                                     string h = s.Replace(ch1, "<br>");
                                     h = h.Replace(ch3, "&nbsp;");

                                     table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                 table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Commission</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                                 com = new SqlCommand("TK_CC", con);
                                 com.CommandType = CommandType.StoredProcedure;
                                 com.Parameters.AddWithValue("agent_id", agnetID);
                                 com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                 com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                 com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     lastTsdsRate = 0.0000M;
                                     lastSurcharge = 0.0000M;
                                     string ss = dr["Used_Date"].ToString();
                                     TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()),2);
           
                                     TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                     TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()),MidpointRounding.AwayFromZero);
                                     TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                     if (dr["tds"].ToString() != "0.0000")
                                         lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                     if (dr["surcharge"].ToString() != "0.0000")
                                         lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                     Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100);
                                     TotFrAmount += Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()),MidpointRounding.AwayFromZero);
                                     TotTds += Tds_discount;

                                     surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);



                                     table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Discount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();
                                 table += @"<tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                 Total = Math.Round(((TotAgentExp + TotComm + TotDiscount) - surCharge - Math.Ceiling(TotTds) - EduChrg));
                                 table += @"<tr > <td colspan=""9""  align=""center""> </td> </tr>";
                                 table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar, MidpointRounding.AwayFromZero) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp; </td></tr>";
                                 table += @"<tr class=""boldtext""> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""7"" align=""right""><strong>Agent Expenses</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                 table += @"<tr class=""boldtext""> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""7"" align=""right""><strong>Commission</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                 table += @"<tr class=""boldtext""> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""7"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                 table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                                 table += @"<tr class=""boldtext""></tr>";

                               
                                 if (Math.Round(surCharge) != 0)
                                     table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                                 table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                 

                                 table += @"<tr class=""boldtext""> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right"" colspan=""7"" ><img src=""images/line2.gif""></td></tr>";

                                 table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                 table += @"<tr> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                 string font = null;
                                 GrandTotal = Total;
                                 if (Math.Round((Total)) > 0)
                                 {
                                     massage = "Total payable To ";
                                     font = "<font color='red'>";
                                     GrandTotal = Math.Round(Total);
                                 }


                                 table += @"<tr class=""boldtext""><th colspan=""7"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                             }

                             if (GrandTotal > 0)
                                 tableAll = tableAll + table;

                             Session["dt"] = tableAll;
                         }
                     }
                     string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     if (tableAll == "" || tableAll == null)
                         Session["dt"] = mass;
                 }
                 Response.Redirect("Csr_TKCC.aspx");
                 
             }
             else
             {
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";


                 Session["dt"] = mass;
                 Response.Redirect("Csr_TKCC.aspx");
                 
             }
         }
         else if (airlineName[0].ToString().Trim() == "DECCAN CARGO & EXPRESS LOGISTICS PVT. LTD")
         {
         string approveCsr = checkApprove(TextBox1.Text, TextBox2.Text);
         con = new SqlConnection(strCon);
         con.Open();
         string agnetID = "";
         string aID = "";
         string city_id = "";
         string pr_rem_pp = null;
        //Int64 count = 0;
        decimal sid_pp = 0;
        //decimal pcs;
        decimal vol_wt_pp = 0;
        decimal gr_wt_pp = 0;
        decimal ch_wt_pp = 0; decimal total_ch_wt_pp = 0;
        decimal publish_rate_pp = 0;
        decimal pr_rate_pp = 0;
        decimal pr_spot_rate_pp = 0;
        decimal pr_min_amt_pp = 0;
        decimal pr_amount_pp = 0;
        decimal pr_spcl_amount_pp = 0;
        decimal freight_pp = 0; decimal total_freight_pp = 0;
        int pr_min_status_pp = 0;
        int ag_min_status_pp = 0;
        decimal fsc_pp = 0; decimal total_fsc_pp = 0;
        decimal wsc_pp = 0; decimal total_wsc_pp = 0;
        decimal awbfee_pp = 0; decimal total_awbfee_pp = 0;
        decimal dis_chg_pp = 0;
        decimal aci_fee_pp = 0;
        decimal other_chg_pp = 0; decimal total_other_chg_pp = 0;
        decimal due_carr_pp = 0; decimal total_due_carr_pp = 0;
        decimal awb_f_pp = 0; decimal total_awb_f_pp = 0;
        decimal gsa_comm_rate = 0;
        decimal net_net_rate_pp = 0;
        decimal net_net_frt_pp = 0; decimal total_net_net_frt_pp = 0;
        decimal xray_chg_pp = 0; decimal total_xray_chg_pp = 0;
        decimal Total_Due_PP_row = 0; decimal total_Total_Due_PP_row = 0;
        decimal other_due_chg_pp = 0;
        decimal status_void_pp = 0;
        decimal col_13_pp = 0; decimal total_col_13_pp = 0;
        decimal col_14_pp = 0; decimal total_col_14_pp = 0;
        decimal col_15_pp = 0; decimal total_col_15_pp = 0;
        decimal col_16_pp = 0; decimal total_col_16_pp = 0;
        decimal s_tax = 0;
        decimal due_agent_pp = 0; decimal total_due_agent_pp = 0;
        decimal col_24_pp = 0; decimal total_col_24_pp = 0;
        decimal col_25_pp = 0; decimal total_col_25_pp = 0;
        decimal col_26_pp = 0; decimal total_col_26_pp = 0;
        decimal col_27_pp = 0; decimal total_col_27_pp = 0;
        //START-----------------------CACCULATE THE SERVICE TAX BASED ON AIRLINE WITH ----------------------    
        DataTable dt_stax = dw.GetAllFromQuery("select isnull(service_tax,10.30) as 'service_tax' from fix_charges where airline_detail_id=" + ddlAirLine.SelectedItem.Value);
        s_tax = Convert.ToDecimal(dt_stax.Rows[0]["service_tax"].ToString());
        //-------------------END OF SERVICE TAX CALCULATION ----------------------------------
        //------------END VARIABLES HERE -----------------------------------------
                 if (Session["groupid"].ToString() != "5")
                 {
                     for (int k = 0; k < lstAgent.Items.Count; k++)
                     {
                         if (lstAgent.Items[k].Selected == true)
                         {

                             string table = null;
                             aID = ddlAirLine.SelectedItem.Value;
                             agnetID = lstAgent.Items[k].Value;
                             agentName = lstAgent.Items[k].Text;
                             con = new SqlConnection(strCon);
                             con.Open();
                             com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (flight_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (flight_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);
                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 city_id = dr["City_id"].ToString();
                                 com.Dispose();
                                 dr.Dispose();
                                 com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     comAdd = dr["company_address"].ToString();
                                     comName = dr["company_name"].ToString();
                                     table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                 com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                                 dr = com.ExecuteReader();
                                 if (dr.Read())
                                 {
                                     string s = dr["agent_address"].ToString();
                                     char ch = (char)System.Windows.Forms.Keys.Return;
                                     char ch2 = (char)System.Windows.Forms.Keys.Space;
                                     string ch1 = Convert.ToString(ch);
                                     string ch3 = Convert.ToString(ch2);
                                     string h = s.Replace(ch1, "<br>");
                                     h = h.Replace(ch3, "&nbsp;");

                                     table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                                    table += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0><tr class=h5><td colspan=27 align=center class=boldtext><b><font size=2>CC SHIPMENT</td></tr><tr class=h5><th nowrap>AWBNo</th><th nowrap >Date</th><th nowrap>Origin</th><th nowrap >Dstn</th><th nowrap>PP/CC</th><th nowrap>VolWt</th><th nowrap >GrWt</th><th nowrap>ChgWt</th><th nowrap>AWB<br>RACK<br>RATE</th><th nowrap>NET<br>NET<br>RATE</th><th nowrap>Awb.<br>Freight ON<br>RACK<br>RATES</th><th nowrap>Awb.<br>Freight<br>ON NET<br>NET RATES</th><th nowrap>CARGO<br>SALES AGENT<br>-(COMM +<br>DISCOUNT)</th><th nowrap >CARGO SALES<br>AGENT-COMM<br>(5% on Rack<br>Rate)</th><th nowrap >CARGO<br>SALES<br>AGENT<br>-DISC.</th><th nowrap >SERVICE<br>TAX ON<br>AGENT'S<br>COMMISSION</th><th nowrap >Total Due<br>Carrier</th><th nowrap>Due<br>Agent</th><th nowrap >NET<br>RECEIVABLE<br>BEFORE TDS</th><th nowrap >TDS DEDUCTION<br>ON FREIGHT/DUE CARRIER<br>PAYMENT BY AGENT</th><th nowrap >TDS ON COMM +<br>DISCOUNT<br>FROM AGENT</th><th nowrap >TOTAL RECEIVABLE<brFROM AGENT</th></tr><tr class=h5 align=center><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th><th>8</th><th>9</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th></tr>";
                                 com = new SqlCommand("csr_deccan_CC", con);
                                 com.CommandType = CommandType.StoredProcedure;
                                 com.Parameters.AddWithValue("agent_id", agnetID);
                                 com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                 com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                 com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
 //count = count + 1;
                        sid_pp = Convert.ToDecimal(dr["Sales_ID"].ToString());
                        awb_f_pp = Convert.ToDecimal(dr["awb_f"].ToString());
                        //pcs = Convert.ToDecimal(dr["No_of_Packages"].ToString());
                        vol_wt_pp = Convert.ToDecimal(dr["volume_weight"].ToString());
                        gr_wt_pp = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                        ch_wt_pp = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                        publish_rate_pp = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                        pr_rate_pp = Convert.ToDecimal(dr["Principle_Rate"].ToString());
                        pr_spot_rate_pp = Convert.ToDecimal(dr["Principle_Spot_Rate"]);
                        pr_amount_pp = Convert.ToDecimal(dr["Principle_Amount"].ToString());
                        pr_spcl_amount_pp = Convert.ToDecimal(dr["special_Amount"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Fuel_Surcharges"].ToString());
                        xray_chg_pp = Convert.ToDecimal(dr["Xray_Charges"].ToString());
                        wsc_pp = Convert.ToDecimal(dr["War_Surcharges"].ToString());
                        ag_min_status_pp = Convert.ToInt16(dr["agent_Min_Status"].ToString());
                        pr_min_status_pp = Convert.ToInt16(dr["Principle_Min_Status"].ToString());
                        due_carr_pp = Convert.ToDecimal(dr["Total_DueCarrier"].ToString());
                        due_agent_pp = Convert.ToDecimal(dr["TotalDueAgent_Prepaid"].ToString());
                        awbfee_pp = Convert.ToDecimal(dr["AWB_Fees"].ToString());
                        dis_chg_pp = Convert.ToDecimal(dr["Disbursement_Charges"].ToString());
                        aci_fee_pp = Convert.ToDecimal(dr["total_aci_fees"].ToString());
                        other_due_chg_pp = Convert.ToDecimal(dr["Other_DueCarrier"].ToString());
                        pr_rem_pp = dr["Principle_Spot_Rate_Remarks"].ToString().Trim();
                        status_void_pp = Convert.ToDecimal(dr["status"].ToString().Trim());
                        gsa_comm_rate = Convert.ToDecimal(dr["gsacomm_rate"].ToString().Trim());
                        if (pr_rem_pp != "")
                        {
                            pr_rem_pp = pr_rem_pp;
                        }
                        else
                        {
                            pr_rem_pp = "&nbsp";
                        }
                        due_carr_pp = awb_f_pp + xray_chg_pp + fsc_pp + wsc_pp + other_due_chg_pp;
                        if (pr_spot_rate_pp == 0)
                        {
                            if (pr_min_status_pp == 13)
                            {

                                pr_min_amt_pp = pr_amount_pp;
                            }
                            else
                            {
                                pr_min_amt_pp = pr_rate_pp;
                            }

                        }
                        else
                        {
                            if (pr_min_status_pp == 13)
                            {
                                pr_min_amt_pp = pr_amount_pp;
                            }
                            else
                            {
                                pr_min_amt_pp = pr_spot_rate_pp;
                            }
                        }


                        if (pr_min_status_pp == 13)
                        {
                            if (ag_min_status_pp == 13)
                            {
                                freight_pp = freight_pp;
                            }
                            else
                            {
                                freight_pp = pr_rate_pp * ch_wt_pp;
                            }
                        }
                        else
                        {
                            freight_pp = publish_rate_pp * ch_wt_pp;
                        }
                        net_net_rate_pp = pr_min_amt_pp;
                        net_net_frt_pp = net_net_rate_pp * ch_wt_pp;
                        col_13_pp = freight_pp - net_net_frt_pp;
                        col_14_pp = freight_pp * gsa_comm_rate / 100;
                        col_15_pp = col_13_pp - col_14_pp;
                        col_16_pp = col_14_pp * s_tax / 100;
                        other_chg_pp = dis_chg_pp + aci_fee_pp;
                        if (status_void_pp == 12)
                        {
                            awbfee_pp = 0;
                            awb_f_pp = 0;
                            due_carr_pp = 0;
                            Total_Due_PP_row = 0;
                        }
                        else
                        {
                            awb_f_pp = 150;
                        }
                        Total_Due_PP_row = fsc_pp + awbfee_pp + wsc_pp + xray_chg_pp + other_chg_pp;
                        col_24_pp = freight_pp - col_13_pp - col_16_pp + Total_Due_PP_row;
                        col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                        col_26_pp = (col_13_pp + col_16_pp) * s_tax / 100;
                        col_27_pp = col_24_pp - col_25_pp + col_26_pp;
                        //----------------CALCULATION TOTAL HERE -----------------------------------------------
                        // total_vol_wt_pp = total_vol_wt_pp + vol_wt_pp;
                        //total_gr_wt_pp = total_gr_wt_pp + gr_wt_pp;
                        total_ch_wt_pp = total_ch_wt_pp + Math.Round(ch_wt_pp, 2);
                        total_freight_pp = total_freight_pp + Math.Round(freight_pp, 2);
                        total_net_net_frt_pp = total_net_net_frt_pp + Math.Round(net_net_frt_pp, 2);
                        total_col_13_pp = total_col_13_pp + Math.Round(col_13_pp, 2);
                        total_col_14_pp = total_col_14_pp + Math.Round(col_14_pp, 2);
                        total_col_15_pp = total_col_15_pp + Math.Round(col_15_pp, 2);
                        total_col_16_pp = total_col_16_pp + Math.Round(col_16_pp, 2);
                        total_fsc_pp = total_fsc_pp + Math.Round(fsc_pp, 2);
                        total_awbfee_pp = total_awbfee_pp + Math.Round(awbfee_pp, 2);
                        total_wsc_pp = total_wsc_pp + Math.Round(wsc_pp, 2);
                        total_xray_chg_pp = total_xray_chg_pp + Math.Round(xray_chg_pp, 2);
                        total_other_chg_pp = total_other_chg_pp + Math.Round(other_chg_pp, 2);
                        total_Total_Due_PP_row = total_Total_Due_PP_row + Math.Round(Total_Due_PP_row, 2);
                        total_due_agent_pp = total_due_agent_pp + Math.Round(due_agent_pp, 2);
                        total_col_24_pp = total_col_24_pp + Math.Round(col_24_pp, 2);
                        total_col_25_pp = total_col_25_pp + Math.Round(col_25_pp, 2);
                        total_col_26_pp = total_col_26_pp + Math.Round(col_26_pp, 2);
                        total_col_27_pp = total_col_27_pp + Math.Round(col_27_pp, 2);
                        table += "<tr class=text onclick=ChangeColor(this);><td nowrap>" + dr["AirWayBill_No"] + "</td><td>" + dr["AWB_Date"].ToString() + "</td><td>&nbsp;" + dr["city_Code"].ToString() + "</td><td>&nbsp;" + dr["Destination_Code"].ToString() + "</td><td>CC</td><td align=right>" + Math.Round(vol_wt_pp, 2) + "</td><td align=right>" + Math.Round(gr_wt_pp, 2) + "</td><td align=right>" + Math.Round(ch_wt_pp, 2) + "</td><td align=right>" + Math.Round(publish_rate_pp, 2) + "</td><td align=right><font color=maroon>" + Math.Round(net_net_rate_pp, 2) + "</font></td></td><td align=right>" + Math.Round(freight_pp, 2) + "</td><td align=right>" + Math.Round(net_net_frt_pp, 2) + "</td><td align=right>" + Math.Round(col_13_pp, 2) + "</td><td align=right>" + Math.Round(col_14_pp, 2) + "</td><td align=right>" + Math.Round(col_15_pp, 2) + "</td><td align=right>" + Math.Round(col_16_pp, 2) + "</td><td align=right>" + Total_Due_PP_row + "</td><td align=right>" + due_agent_pp + "</td><td align=right>" + Math.Round(col_24_pp, 2) + "</td><td align=right>" + Math.Round(col_25_pp, 2) + "</td><td align=right>" + Math.Round(col_26_pp, 2) + "</td><td align=right>" + Math.Round(col_27_pp, 2) + "</td></tr>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();
                                 table += "<tr class=boldtext ><td colspan=7>&nbsp;</td><td align=right>" + total_ch_wt_pp + "</td><td colspan=2>&nbsp;</td><td align=right>" + total_freight_pp + "</td><td align=right>" + total_net_net_frt_pp + "</td><td align=right>" + total_col_13_pp + "</td><td align=right>" + total_col_14_pp + "</td><td align=right>" + total_col_15_pp + "</td><td align=right>" + total_col_16_pp + "</td><td align=right>" + total_Total_Due_PP_row + "</td><td align=right>" + total_due_agent_pp + "</td><td align=right>" + total_col_24_pp + "</td><td align=right>" + total_col_25_pp + "</td><td align=right>" + total_col_26_pp + "</td><td align=right>" + total_col_27_pp + "</td></tr></table><br><table width=10% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0 align=left><tr  class=h5><th align=center colspan=2>AGENT CSR SUMMERY(CC)</th></tr><tr><th class=boldtext nowrap align=left>Total Gross Freight collected at rack rates</th><th class=boldtext>" + total_freight_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Commission/discount </th><th class=boldtext>" + total_col_13_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Service tax on Commission / Discount</th><th class=boldtext>" + total_col_16_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Add:Total Due Carrier (CC)</th><th class=boldtext>" + total_Total_Due_PP_row + "</th></tr><tr><th class=boldtext nowrap align=left>Less : TDS on Freight and Due Carrier to be deducted by Agent</th><th class=boldtext>" + total_col_25_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Add : TDS on Commission + Discount to agent</th><th class=boldtext>" + total_col_26_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Total Payable to Agent	</th><th class=boldtext>" + Math.Round(total_col_27_pp, 0) + "</th></tr></table><br><br><br><br><br><br><br><br><br><br><br><br><table></table><br style=page-break-before:always;>";

                             }

                             //if (GrandTotal > 0)
                                 tableAll = tableAll + table;

                             Session["dt"] = tableAll;
                         }
                     }
                     string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     if (tableAll == "" || tableAll == null)
                         Session["dt"] = mass;
                 }
                 else if (approveCsr == "notApprove")
                 {
for (int k = 0; k < lstAgent.Items.Count; k++)
                     {
                         if (lstAgent.Items[k].Selected == true)
                         {

                             string table = null;
                             aID = ddlAirLine.SelectedItem.Value;
                             agnetID = lstAgent.Items[k].Value;
                             agentName = lstAgent.Items[k].Text;
                             con = new SqlConnection(strCon);
                             con.Open();
                             com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (flight_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (flight_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);
                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 city_id = dr["City_id"].ToString();
                                 com.Dispose();
                                 dr.Dispose();
                                 com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     comAdd = dr["company_address"].ToString();
                                     comName = dr["company_name"].ToString();
                                     table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                 com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                                 dr = com.ExecuteReader();
                                 if (dr.Read())
                                 {
                                     string s = dr["agent_address"].ToString();
                                     char ch = (char)System.Windows.Forms.Keys.Return;
                                     char ch2 = (char)System.Windows.Forms.Keys.Space;
                                     string ch1 = Convert.ToString(ch);
                                     string ch3 = Convert.ToString(ch2);
                                     string h = s.Replace(ch1, "<br>");
                                     h = h.Replace(ch3, "&nbsp;");

                                     table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                                    table += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0><tr class=h5><td colspan=27 align=center class=boldtext><b><font size=2>CC SHIPMENT</td></tr><tr class=h5><th nowrap>AWBNo</th><th nowrap >Date</th><th nowrap>Origin</th><th nowrap >Dstn</th><th nowrap>PP/CC</th><th nowrap>VolWt</th><th nowrap >GrWt</th><th nowrap>ChgWt</th><th nowrap>AWB<br>RACK<br>RATE</th><th nowrap>NET<br>NET<br>RATE</th><th nowrap>Awb.<br>Freight ON<br>RACK<br>RATES</th><th nowrap>Awb.<br>Freight<br>ON NET<br>NET RATES</th><th nowrap>CARGO<br>SALES AGENT<br>-(COMM +<br>DISCOUNT)</th><th nowrap >CARGO SALES<br>AGENT-COMM<br>(5% on Rack<br>Rate)</th><th nowrap >CARGO<br>SALES<br>AGENT<br>-DISC.</th><th nowrap >SERVICE<br>TAX ON<br>AGENT'S<br>COMMISSION</th><th nowrap >Total Due<br>Carrier</th><th nowrap>Due<br>Agent</th><th nowrap >NET<br>RECEIVABLE<br>BEFORE TDS</th><th nowrap >TDS DEDUCTION<br>ON FREIGHT/DUE CARRIER<br>PAYMENT BY AGENT</th><th nowrap >TDS ON COMM +<br>DISCOUNT<br>FROM AGENT</th><th nowrap >TOTAL RECEIVABLE<brFROM AGENT</th></tr><tr class=h5 align=center><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th><th>8</th><th>9</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th></tr>";
                                 com = new SqlCommand("csr_deccan_CC", con);
                                 com.CommandType = CommandType.StoredProcedure;
                                 com.Parameters.AddWithValue("agent_id", agnetID);
                                 com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                 com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                 com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
 //count = count + 1;
                        sid_pp = Convert.ToDecimal(dr["Sales_ID"].ToString());
                        awb_f_pp = Convert.ToDecimal(dr["awb_f"].ToString());
                        //pcs = Convert.ToDecimal(dr["No_of_Packages"].ToString());
                        vol_wt_pp = Convert.ToDecimal(dr["volume_weight"].ToString());
                        gr_wt_pp = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                        ch_wt_pp = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                        publish_rate_pp = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                        pr_rate_pp = Convert.ToDecimal(dr["Principle_Rate"].ToString());
                        pr_spot_rate_pp = Convert.ToDecimal(dr["Principle_Spot_Rate"]);
                        pr_amount_pp = Convert.ToDecimal(dr["Principle_Amount"].ToString());
                        pr_spcl_amount_pp = Convert.ToDecimal(dr["special_Amount"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Fuel_Surcharges"].ToString());
                        xray_chg_pp = Convert.ToDecimal(dr["Xray_Charges"].ToString());
                        wsc_pp = Convert.ToDecimal(dr["War_Surcharges"].ToString());
                        ag_min_status_pp = Convert.ToInt16(dr["agent_Min_Status"].ToString());
                        pr_min_status_pp = Convert.ToInt16(dr["Principle_Min_Status"].ToString());
                        due_carr_pp = Convert.ToDecimal(dr["Total_DueCarrier"].ToString());
                        due_agent_pp = Convert.ToDecimal(dr["TotalDueAgent_Prepaid"].ToString());
                        awbfee_pp = Convert.ToDecimal(dr["AWB_Fees"].ToString());
                        dis_chg_pp = Convert.ToDecimal(dr["Disbursement_Charges"].ToString());
                        aci_fee_pp = Convert.ToDecimal(dr["total_aci_fees"].ToString());
                        other_due_chg_pp = Convert.ToDecimal(dr["Other_DueCarrier"].ToString());
                        pr_rem_pp = dr["Principle_Spot_Rate_Remarks"].ToString().Trim();
                        status_void_pp = Convert.ToDecimal(dr["status"].ToString().Trim());
                        gsa_comm_rate = Convert.ToDecimal(dr["gsacomm_rate"].ToString().Trim());
                        if (pr_rem_pp != "")
                        {
                            pr_rem_pp = pr_rem_pp;
                        }
                        else
                        {
                            pr_rem_pp = "&nbsp";
                        }
                        due_carr_pp = awb_f_pp + xray_chg_pp + fsc_pp + wsc_pp + other_due_chg_pp;
                        if (pr_spot_rate_pp == 0)
                        {
                            if (pr_min_status_pp == 13)
                            {

                                pr_min_amt_pp = pr_amount_pp;
                            }
                            else
                            {
                                pr_min_amt_pp = pr_rate_pp;
                            }

                        }
                        else
                        {
                            if (pr_min_status_pp == 13)
                            {
                                pr_min_amt_pp = pr_amount_pp;
                            }
                            else
                            {
                                pr_min_amt_pp = pr_spot_rate_pp;
                            }
                        }


                        if (pr_min_status_pp == 13)
                        {
                            if (ag_min_status_pp == 13)
                            {
                                freight_pp = freight_pp;
                            }
                            else
                            {
                                freight_pp = pr_rate_pp * ch_wt_pp;
                            }
                        }
                        else
                        {
                            freight_pp = publish_rate_pp * ch_wt_pp;
                        }
                        net_net_rate_pp = pr_min_amt_pp - (pr_min_amt_pp * gsa_comm_rate / 100);
                        net_net_frt_pp = net_net_rate_pp * ch_wt_pp;
                        col_13_pp = freight_pp - net_net_frt_pp;
                        col_14_pp = freight_pp * gsa_comm_rate / 100;
                        col_15_pp = col_13_pp - col_14_pp;
                        col_16_pp = col_14_pp * s_tax / 100;
                 
                        other_chg_pp = dis_chg_pp + aci_fee_pp;
                        if (status_void_pp == 12)
                        {
                            awbfee_pp = 0;
                            awb_f_pp = 0;
                            due_carr_pp = 0;
                            Total_Due_PP_row = 0;
                        }
                        else
                        {
                            awb_f_pp = 150;
                        }
                        Total_Due_PP_row = fsc_pp + awbfee_pp + wsc_pp + xray_chg_pp + other_chg_pp;
                        col_24_pp = freight_pp - col_13_pp - col_16_pp + Total_Due_PP_row;
                        col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                        col_26_pp = (col_13_pp + col_16_pp) * s_tax / 100;
                        col_27_pp = col_24_pp - col_25_pp + col_26_pp;
                        //----------------CALCULATION TOTAL HERE -----------------------------------------------
                        // total_vol_wt_pp = total_vol_wt_pp + vol_wt_pp;
                        //total_gr_wt_pp = total_gr_wt_pp + gr_wt_pp;
                        total_ch_wt_pp = total_ch_wt_pp + Math.Round(ch_wt_pp, 2);
                        total_freight_pp = total_freight_pp + Math.Round(freight_pp, 2);
                        total_net_net_frt_pp = total_net_net_frt_pp + Math.Round(net_net_frt_pp, 2);
                        total_col_13_pp = total_col_13_pp + Math.Round(col_13_pp, 2);
                        total_col_14_pp = total_col_14_pp + Math.Round(col_14_pp, 2);
                        total_col_15_pp = total_col_15_pp + Math.Round(col_15_pp, 2);
                        total_col_16_pp = total_col_16_pp + Math.Round(col_16_pp, 2);
                        total_fsc_pp = total_fsc_pp + Math.Round(fsc_pp, 2);
                        total_awbfee_pp = total_awbfee_pp + Math.Round(awbfee_pp, 2);
                        total_wsc_pp = total_wsc_pp + Math.Round(wsc_pp, 2);
                        total_xray_chg_pp = total_xray_chg_pp + Math.Round(xray_chg_pp, 2);
                        total_other_chg_pp = total_other_chg_pp + Math.Round(other_chg_pp, 2);
                        total_Total_Due_PP_row = total_Total_Due_PP_row + Math.Round(Total_Due_PP_row, 2);
                        total_due_agent_pp = total_due_agent_pp + Math.Round(due_agent_pp, 2);
                        total_col_24_pp = total_col_24_pp + Math.Round(col_24_pp, 2);
                        total_col_25_pp = total_col_25_pp + Math.Round(col_25_pp, 2);
                        total_col_26_pp = total_col_26_pp + Math.Round(col_26_pp, 2);
                        total_col_27_pp = total_col_27_pp + Math.Round(col_27_pp, 2);
                        table += "<tr class=text onclick=ChangeColor(this);><td nowrap>" + dr["AirWayBill_No"] + "</td><td>" + dr["AWB_Date"].ToString() + "</td><td>&nbsp;" + dr["city_Code"].ToString() + "</td><td>&nbsp;" + dr["Destination_Code"].ToString() + "</td><td>CC</td><td align=right>" + Math.Round(vol_wt_pp, 2) + "</td><td align=right>" + Math.Round(gr_wt_pp, 2) + "</td><td align=right>" + Math.Round(ch_wt_pp, 2) + "</td><td align=right>" + Math.Round(publish_rate_pp, 2) + "</td><td align=right><font color=maroon>" + Math.Round(net_net_rate_pp, 2) + "</font></td></td><td align=right>" + Math.Round(freight_pp, 2) + "</td><td align=right>" + Math.Round(net_net_frt_pp, 2) + "</td><td align=right>" + Math.Round(col_13_pp, 2) + "</td><td align=right>" + Math.Round(col_14_pp, 2) + "</td><td align=right>" + Math.Round(col_15_pp, 2) + "</td><td align=right>" + Math.Round(col_16_pp, 2) + "</td><td align=right>" + Total_Due_PP_row + "</td><td align=right>" + due_agent_pp + "</td><td align=right>" + Math.Round(col_24_pp, 2) + "</td><td align=right>" + Math.Round(col_25_pp, 2) + "</td><td align=right>" + Math.Round(col_26_pp, 2) + "</td><td align=right>" + Math.Round(col_27_pp, 2) + "</td></tr>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();
                                 table += "<tr class=boldtext ><td colspan=7>&nbsp;</td><td align=right>" + total_ch_wt_pp + "</td><td colspan=2>&nbsp;</td><td align=right>" + total_freight_pp + "</td><td align=right>" + total_net_net_frt_pp + "</td><td align=right>" + total_col_13_pp + "</td><td align=right>" + total_col_14_pp + "</td><td align=right>" + total_col_15_pp + "</td><td align=right>" + total_col_16_pp + "</td><td align=right>" + total_Total_Due_PP_row + "</td><td align=right>" + total_due_agent_pp + "</td><td align=right>" + total_col_24_pp + "</td><td align=right>" + total_col_25_pp + "</td><td align=right>" + total_col_26_pp + "</td><td align=right>" + total_col_27_pp + "</td></tr></table><br><table width=10% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0 align=left><tr  class=h5><th align=center colspan=2>AGENT CSR SUMMERY(CC)</th></tr><tr><th class=boldtext nowrap align=left>Total Gross Freight collected at rack rates</th><th class=boldtext>" + total_freight_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Commission/discount </th><th class=boldtext>" + total_col_13_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Service tax on Commission / Discount</th><th class=boldtext>" + total_col_16_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Add:Total Due Carrier (CC)</th><th class=boldtext>" + total_Total_Due_PP_row + "</th></tr><tr><th class=boldtext nowrap align=left>Less : TDS on Freight and Due Carrier to be deducted by Agent</th><th class=boldtext>" + total_col_25_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Add : TDS on Commission + Discount to agent</th><th class=boldtext>" + total_col_26_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Total Payable to Agent	</th><th class=boldtext>" + Math.Round(total_col_27_pp, 0) + "</th></tr></table><br><br><br><br><br><br><br><br><br><br><br><br><table></table><br style=page-break-before:always;>";

                             }

                             //if (GrandTotal > 0)
                                 tableAll = tableAll + table;

                             Session["dt"] = tableAll;
                         }
                     }
                     string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     if (tableAll == "" || tableAll == null)
                         Session["dt"] = mass;

                 }
                 else
                 {

                     for (int k = 0; k < lstAgent.Items.Count; k++)
                     {
                         if (lstAgent.Items[k].Selected == true)
                         {

                             string table = null;
                             aID = ddlAirLine.SelectedItem.Value;
                             agnetID = lstAgent.Items[k].Value;
                             agentName = lstAgent.Items[k].Text;
                             con = new SqlConnection(strCon);
                             con.Open();
                             com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (flight_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (flight_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);
                             dr = com.ExecuteReader();
                             if (dr.Read())
                             {
                                 city_id = dr["City_id"].ToString();
                                 com.Dispose();
                                 dr.Dispose();
                                 com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     comAdd = dr["company_address"].ToString();
                                     comName = dr["company_name"].ToString();
                                     table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                 com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                                 dr = com.ExecuteReader();
                                 if (dr.Read())
                                 {
                                     string s = dr["agent_address"].ToString();
                                     char ch = (char)System.Windows.Forms.Keys.Return;
                                     char ch2 = (char)System.Windows.Forms.Keys.Space;
                                     string ch1 = Convert.ToString(ch);
                                     string ch3 = Convert.ToString(ch2);
                                     string h = s.Replace(ch1, "<br>");
                                     h = h.Replace(ch3, "&nbsp;");

                                     table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                                 }
                                 com.Dispose();
                                 dr.Dispose();

                                 table += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0><tr class=h5><td colspan=27 align=center class=boldtext><b><font size=2>CC SHIPMENT</td></tr><tr class=h5><th nowrap>AWBNo</th><th nowrap >Date</th><th nowrap>Origin</th><th nowrap >Dstn</th><th nowrap>PP/CC</th><th nowrap>VolWt</th><th nowrap >GrWt</th><th nowrap>ChgWt</th><th nowrap>AWB<br>RACK<br>RATE</th><th nowrap>NET<br>NET<br>RATE</th><th nowrap>Awb.<br>Freight ON<br>RACK<br>RATES</th><th nowrap>Awb.<br>Freight<br>ON NET<br>NET RATES</th><th nowrap>CARGO<br>SALES AGENT<br>-(COMM +<br>DISCOUNT)</th><th nowrap >CARGO SALES<br>AGENT-COMM<br>(5% on Rack<br>Rate)</th><th nowrap >CARGO<br>SALES<br>AGENT<br>-DISC.</th><th nowrap >SERVICE<br>TAX ON<br>AGENT'S<br>COMMISSION</th><th nowrap >Total Due<br>Carrier</th><th nowrap>Due<br>Agent</th><th nowrap >NET<br>RECEIVABLE<br>BEFORE TDS</th><th nowrap >TDS DEDUCTION<br>ON FREIGHT/DUE CARRIER<br>PAYMENT BY AGENT</th><th nowrap >TDS ON COMM +<br>DISCOUNT<br>FROM AGENT</th><th nowrap >TOTAL RECEIVABLE<brFROM AGENT</th></tr><tr class=h5 align=center><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th><th>8</th><th>9</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th></tr>";
                                 com = new SqlCommand("csr_deccan_CC", con);
                                 com.CommandType = CommandType.StoredProcedure;
                                 com.Parameters.AddWithValue("agent_id", agnetID);
                                 com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                 com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                 com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                 dr = com.ExecuteReader();
                                 while (dr.Read())
                                 {
                                     //count = count + 1;
                                     sid_pp = Convert.ToDecimal(dr["Sales_ID"].ToString());
                                     awb_f_pp = Convert.ToDecimal(dr["awb_f"].ToString());
                                     //pcs = Convert.ToDecimal(dr["No_of_Packages"].ToString());
                                     vol_wt_pp = Convert.ToDecimal(dr["volume_weight"].ToString());
                                     gr_wt_pp = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                                     ch_wt_pp = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                                     publish_rate_pp = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                                     fsc_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                                     pr_rate_pp = Convert.ToDecimal(dr["Principle_Rate"].ToString());
                                     pr_spot_rate_pp = Convert.ToDecimal(dr["Principle_Spot_Rate"]);
                                     pr_amount_pp = Convert.ToDecimal(dr["Principle_Amount"].ToString());
                                     pr_spcl_amount_pp = Convert.ToDecimal(dr["special_Amount"].ToString());
                                     fsc_pp = Convert.ToDecimal(dr["Fuel_Surcharges"].ToString());
                                     xray_chg_pp = Convert.ToDecimal(dr["Xray_Charges"].ToString());
                                     wsc_pp = Convert.ToDecimal(dr["War_Surcharges"].ToString());
                                     ag_min_status_pp = Convert.ToInt16(dr["agent_Min_Status"].ToString());
                                     pr_min_status_pp = Convert.ToInt16(dr["Principle_Min_Status"].ToString());
                                     due_carr_pp = Convert.ToDecimal(dr["Total_DueCarrier"].ToString());
                                     due_agent_pp = Convert.ToDecimal(dr["TotalDueAgent_Prepaid"].ToString());
                                     awbfee_pp = Convert.ToDecimal(dr["AWB_Fees"].ToString());
                                     dis_chg_pp = Convert.ToDecimal(dr["Disbursement_Charges"].ToString());
                                     aci_fee_pp = Convert.ToDecimal(dr["total_aci_fees"].ToString());
                                     other_due_chg_pp = Convert.ToDecimal(dr["Other_DueCarrier"].ToString());
                                     pr_rem_pp = dr["Principle_Spot_Rate_Remarks"].ToString().Trim();
                                     status_void_pp = Convert.ToDecimal(dr["status"].ToString().Trim());
                                     gsa_comm_rate = Convert.ToDecimal(dr["gsacomm_rate"].ToString().Trim());
                                     if (pr_rem_pp != "")
                                     {
                                         pr_rem_pp = pr_rem_pp;
                                     }
                                     else
                                     {
                                         pr_rem_pp = "&nbsp";
                                     }
                                     due_carr_pp = awb_f_pp + xray_chg_pp + fsc_pp + wsc_pp + other_due_chg_pp;
                                     if (pr_spot_rate_pp == 0)
                                     {
                                         if (pr_min_status_pp == 13)
                                         {

                                             pr_min_amt_pp = pr_amount_pp;
                                         }
                                         else
                                         {
                                             pr_min_amt_pp = pr_rate_pp;
                                         }

                                     }
                                     else
                                     {
                                         if (pr_min_status_pp == 13)
                                         {
                                             pr_min_amt_pp = pr_amount_pp;
                                         }
                                         else
                                         {
                                             pr_min_amt_pp = pr_spot_rate_pp;
                                         }
                                     }


                                     if (pr_min_status_pp == 13)
                                     {
                                         if (ag_min_status_pp == 13)
                                         {
                                             freight_pp = freight_pp;
                                         }
                                         else
                                         {
                                             freight_pp = pr_rate_pp * ch_wt_pp;
                                         }
                                     }
                                     else
                                     {
                                         freight_pp = publish_rate_pp * ch_wt_pp;
                                     }
                                     net_net_rate_pp = pr_min_amt_pp;
                                     net_net_frt_pp = net_net_rate_pp * ch_wt_pp;
                                     col_13_pp = freight_pp - net_net_frt_pp;
                                     col_14_pp = freight_pp * gsa_comm_rate / 100;
                                     col_15_pp = col_13_pp - col_14_pp;
                                     col_16_pp = col_14_pp * s_tax / 100;
                               
                                     other_chg_pp = dis_chg_pp + aci_fee_pp;
                                     if (status_void_pp == 12)
                                     {
                                         awbfee_pp = 0;
                                         awb_f_pp = 0;
                                         due_carr_pp = 0;
                                         Total_Due_PP_row = 0;
                                     }
                                     else
                                     {
                                         awb_f_pp = 150;
                                     }
                                     Total_Due_PP_row = fsc_pp + awbfee_pp + wsc_pp + xray_chg_pp + other_chg_pp;
                                     col_24_pp = freight_pp - col_13_pp - col_16_pp + Total_Due_PP_row;
                                     col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                                     col_26_pp = (col_13_pp + col_16_pp) * s_tax / 100;
                                     col_27_pp = col_24_pp - col_25_pp + col_26_pp;
                                     //----------------CALCULATION TOTAL HERE -----------------------------------------------
                                     // total_vol_wt_pp = total_vol_wt_pp + vol_wt_pp;
                                     //total_gr_wt_pp = total_gr_wt_pp + gr_wt_pp;
                                     total_ch_wt_pp = total_ch_wt_pp + Math.Round(ch_wt_pp, 2);
                                     total_freight_pp = total_freight_pp + Math.Round(freight_pp, 2);
                                     total_net_net_frt_pp = total_net_net_frt_pp + Math.Round(net_net_frt_pp, 2);
                                     total_col_13_pp = total_col_13_pp + Math.Round(col_13_pp, 2);
                                     total_col_14_pp = total_col_14_pp + Math.Round(col_14_pp, 2);
                                     total_col_15_pp = total_col_15_pp + Math.Round(col_15_pp, 2);
                                     total_col_16_pp = total_col_16_pp + Math.Round(col_16_pp, 2);
                                     total_fsc_pp = total_fsc_pp + Math.Round(fsc_pp, 2);
                                     total_awbfee_pp = total_awbfee_pp + Math.Round(awbfee_pp, 2);
                                     total_wsc_pp = total_wsc_pp + Math.Round(wsc_pp, 2);
                                     total_xray_chg_pp = total_xray_chg_pp + Math.Round(xray_chg_pp, 2);
                                     total_other_chg_pp = total_other_chg_pp + Math.Round(other_chg_pp, 2);
                                     total_Total_Due_PP_row = total_Total_Due_PP_row + Math.Round(Total_Due_PP_row, 2);
                                     total_due_agent_pp = total_due_agent_pp + Math.Round(due_agent_pp, 2);
                                     total_col_24_pp = total_col_24_pp + Math.Round(col_24_pp, 2);
                                     total_col_25_pp = total_col_25_pp + Math.Round(col_25_pp, 2);
                                     total_col_26_pp = total_col_26_pp + Math.Round(col_26_pp, 2);
                                     total_col_27_pp = total_col_27_pp + Math.Round(col_27_pp, 2);
                                     table += "<tr class=text onclick=ChangeColor(this);><td nowrap>" + dr["AirWayBill_No"] + "</td><td>" + dr["AWB_Date"].ToString() + "</td><td>&nbsp;" + dr["city_Code"].ToString() + "</td><td>&nbsp;" + dr["Destination_Code"].ToString() + "</td><td>CC</td><td align=right>" + Math.Round(vol_wt_pp, 2) + "</td><td align=right>" + Math.Round(gr_wt_pp, 2) + "</td><td align=right>" + Math.Round(ch_wt_pp, 2) + "</td><td align=right>" + Math.Round(publish_rate_pp, 2) + "</td><td align=right><font color=maroon>" + Math.Round(net_net_rate_pp, 2) + "</font></td></td><td align=right>" + Math.Round(freight_pp, 2) + "</td><td align=right>" + Math.Round(net_net_frt_pp, 2) + "</td><td align=right>" + Math.Round(col_13_pp, 2) + "</td><td align=right>" + Math.Round(col_14_pp, 2) + "</td><td align=right>" + Math.Round(col_15_pp, 2) + "</td><td align=right>" + Math.Round(col_16_pp, 2) + "</td><td align=right>" + Total_Due_PP_row + "</td><td align=right>" + due_agent_pp + "</td><td align=right>" + Math.Round(col_24_pp, 2) + "</td><td align=right>" + Math.Round(col_25_pp, 2) + "</td><td align=right>" + Math.Round(col_26_pp, 2) + "</td><td align=right>" + Math.Round(col_27_pp, 2) + "</td></tr>";

                                 }
                                 com.Dispose();
                                 dr.Dispose();
                                 table += "<tr class=boldtext ><td colspan=7>&nbsp;</td><td align=right>" + total_ch_wt_pp + "</td><td colspan=2>&nbsp;</td><td align=right>" + total_freight_pp + "</td><td align=right>" + total_net_net_frt_pp + "</td><td align=right>" + total_col_13_pp + "</td><td align=right>" + total_col_14_pp + "</td><td align=right>" + total_col_15_pp + "</td><td align=right>" + total_col_16_pp + "</td><td align=right>" + total_Total_Due_PP_row + "</td><td align=right>" + total_due_agent_pp + "</td><td align=right>" + total_col_24_pp + "</td><td align=right>" + total_col_25_pp + "</td><td align=right>" + total_col_26_pp + "</td><td align=right>" + total_col_27_pp + "</td></tr></table><br><table width=10% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0 align=left><tr  class=h5><th align=center colspan=2>AGENT CSR SUMMERY(CC)</th></tr><tr><th class=boldtext nowrap align=left>Total Gross Freight collected at rack rates</th><th class=boldtext>" + total_freight_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Commission/discount </th><th class=boldtext>" + total_col_13_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Service tax on Commission / Discount</th><th class=boldtext>" + total_col_16_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Add:Total Due Carrier (CC)</th><th class=boldtext>" + total_Total_Due_PP_row + "</th></tr><tr><th class=boldtext nowrap align=left>Less : TDS on Freight and Due Carrier to be deducted by Agent</th><th class=boldtext>" + total_col_25_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Add : TDS on Commission + Discount to agent</th><th class=boldtext>" + total_col_26_pp + "</th></tr><tr><th class=boldtext nowrap align=left>Total Payable to Agent	</th><th class=boldtext>" + Math.Round(total_col_27_pp,0) + "</th></tr></table><br><br><br><br><br><br><br><br><br><br><br><br><table></table><br style=page-break-before:always;>";

                             }

                             //if (GrandTotal > 0)
                             tableAll = tableAll + table;

                             Session["dt"] = tableAll;
                         }
                     }
                     string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     if (tableAll == "" || tableAll == null)
                         Session["dt"] = mass;
                 }
                 Response.Redirect("Csr_TKCC.aspx");
         }
         
         else
        {
            string VarDate = "08/15/2008";
            if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
            {
                string approveCsr = checkApprove(TextBox1.Text, TextBox2.Text);
                con = new SqlConnection(strCon);
                con.Open();
                string agnetID = "";
                string aID = "";
                string city_id = "";
                if (Session["groupid"].ToString() != "5")
                {
                    for (int k = 0; k < lstAgent.Items.Count; k++)
                    {
                        if (lstAgent.Items[k].Selected == true)
                        {
                            decimal TotChAmount = 0;
                            decimal TotDueCar = 0;
                            decimal TotAgentExp = 0;
                            decimal TotComm = 0;
                            decimal TotDiscount = 0;
                            decimal TotFrAmount = 0;
                            decimal lastTsdsRate = 0;
                            decimal lastSurcharge = 0;
                            decimal Tds_discount = 0;
                            decimal TotTds = 0;
                            decimal EduChrg = 0; decimal Total = 0;
                            decimal GrandTotal = 0;
                            decimal surCharge = 0;

                            string table = null;
                            aID = ddlAirLine.SelectedItem.Value;
                            agnetID = lstAgent.Items[k].Value;
                            agentName = lstAgent.Items[k].Text;
                            con = new SqlConnection(strCon);
                            con.Open();
                            com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);

                            dr = com.ExecuteReader();
                            if (dr.Read())
                            {
                                city_id = dr["City_id"].ToString();
                                com.Dispose();
                                dr.Dispose();
                                com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    comAdd = dr["company_address"].ToString();
                                    comName = dr["company_name"].ToString();
                                    table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                                dr = com.ExecuteReader();
                                if (dr.Read())
                                {
                                    string s = dr["agent_address"].ToString();
                                    char ch = (char)System.Windows.Forms.Keys.Return;
                                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                                    string ch1 = Convert.ToString(ch);
                                    string ch3 = Convert.ToString(ch2);
                                    string h = s.Replace(ch1, "<br>");
                                    h = h.Replace(ch3, "&nbsp;");

                                    table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
</div>
<br>";
                                }
                                com.Dispose();
                                dr.Dispose();

                                table += @"<table style=""word-spacing:inherit"" width=""95%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable<br> Frt</th><th >Due <br>Carrier</th><th >Agent <br>Expenses</th><th >Commission</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""10"" align=""center""></td>
</tr><tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                com = new SqlCommand("mh_cc", con);
                                com.CommandType = CommandType.StoredProcedure;
                                com.Parameters.AddWithValue("agent_id", agnetID);
                                com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    lastTsdsRate = 0.0000M;
                                    lastSurcharge = 0.0000M;
                                    string ss = dr["Used_Date"].ToString();
                                    TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2);
                                    TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                    TotComm += decimal.Parse(dr["Commissionable_Amount"].ToString());
                                    TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                    if (dr["tds"].ToString() != "0.0000")
                                        lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                    if (dr["surcharge"].ToString() != "0.0000")
                                        lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                    Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100);
                                    TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                    TotTds += Tds_discount;
                                    surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                table += @"<tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                Total = Math.Round(((TotComm + TotDiscount + TotAgentExp) - Math.Ceiling(TotTds) - surCharge - EduChrg), MidpointRounding.AwayFromZero);
                                table += @"<tr > <td colspan=""10""  align=""center""> </td> </tr>";
                                table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext"">	<td colspan=""8"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""></tr>";
                                if (Math.Round(surCharge) != 0)
                                    table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                                table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                table += @"<tr class=""boldtext""> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right"" ><img src=""images/line2.gif""></td></tr>";

                                table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                table += @"<tr> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                string font = null;
                                GrandTotal = Total;
                                if (Math.Round((Total)) > 0)
                                {
                                    massage = "Total payable To ";
                                    font = "<font color='red'>";
                                    GrandTotal = Math.Round(Total);
                                }


                                table += @"<tr class=""boldtext""><th colspan=""8"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                            }

                            if (GrandTotal > 0)
                                tableAll = tableAll + table;

                            Session["dt"] = tableAll;
                        }
                    }
                    string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    if (tableAll == "" || tableAll == null)
                        Session["dt"] = mass;
                }
                else if (approveCsr == "notApprove")
                {
                    decimal TotChAmount = 0;
                    decimal TotAgentExp = 0;
                    decimal TotComm = 0;
                    decimal TotDiscount = 0;
                    decimal TotFrAmount = 0;
                    decimal lastTsdsRate = 0;
                    decimal lastSurcharge = 0;
                    decimal Tds_discount = 0;
                    decimal TotTds = 0;
                    decimal EduChrg = 0;
                    decimal surCharge = 0;

                    string table = null;
                    aID = ddlAirLine.SelectedItem.Value;
                    agnetID = lstAgent.SelectedValue;
                    con = new SqlConnection(strCon);
                    con.Open();

                    com = new SqlCommand("select distinct agent_id from sales where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' and Sales.city_id=" + city_id + " ", con);



                    dr = com.ExecuteReader();
                    if (dr.HasRows)
                    {
                        com.Dispose();
                        dr.Dispose();

                        table += @"<p><font color=""red"" size=""2""> The CSR not Generated for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @".</font><br> The following AWB No are in this period:</p>";

                        table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Commission</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""10"" align=""center""></td>
</tr><tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                        com = new SqlCommand("mh_cc", con);
                        com.CommandType = CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("agent_id", agnetID);
                        com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                        com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                        com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                        dr = com.ExecuteReader();
                        while (dr.Read())
                        {
                            lastTsdsRate = 0.0000M;
                            lastSurcharge = 0.0000M;
                            string ss = dr["Used_Date"].ToString();
                            TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2);
                            TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                            TotComm += decimal.Parse(dr["Commissionable_Amount"].ToString());
                            TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                            if (dr["tds"].ToString() != "0.0000")
                                lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                            if (dr["surcharge"].ToString() != "0.0000")
                                lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                            Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100);
                            TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                            TotTds += Tds_discount;
                            surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                            EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                        }
                        com.Dispose();
                        dr.Dispose();
                        table += @"</table>";
                    }

                    tableAll = tableAll + table;
                    Session["dt"] = tableAll;
                    string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    if (tableAll == "" || tableAll == null)
                        Session["dt"] = mass;

                }
                else
                {

                    for (int k = 0; k < lstAgent.Items.Count; k++)
                    {
                        if (lstAgent.Items[k].Selected == true)
                        {
                            decimal TotChAmount = 0;
                            decimal TotDueCar = 0;
                            decimal TotAgentExp = 0;
                            decimal TotComm = 0;
                            decimal TotDiscount = 0;
                            decimal TotFrAmount = 0;
                            decimal lastTsdsRate = 0;
                            decimal lastSurcharge = 0;
                            decimal Tds_discount = 0;
                            decimal TotTds = 0;
                            decimal EduChrg = 0; decimal Total = 0;
                            decimal GrandTotal = 0;
                            decimal surCharge = 0;

                            string table = null;
                            aID = ddlAirLine.SelectedItem.Value;
                            agnetID = lstAgent.Items[k].Value;
                            agentName = lstAgent.Items[k].Text;
                            con = new SqlConnection(strCon);
                            con.Open();
                            com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);



                            dr = com.ExecuteReader();
                            if (dr.HasRows)
                            {
                                city_id = dr["city_id"].ToString();

                                com.Dispose();
                                dr.Dispose();

                                com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    comAdd = dr["company_address"].ToString();
                                    comName = dr["company_name"].ToString();
                                    table += @"<table   width=""100%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);

                                dr = com.ExecuteReader();
                                if (dr.Read())
                                {
                                    string s = dr["agent_address"].ToString();
                                    char ch = (char)System.Windows.Forms.Keys.Return;
                                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                                    string ch1 = Convert.ToString(ch);
                                    string ch3 = Convert.ToString(ch2);
                                    string h = s.Replace(ch1, "<br>");
                                    h = h.Replace(ch3, "&nbsp;");

                                    table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                                }
                                com.Dispose();
                                dr.Dispose();

                                table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""10"" align=""center""></td>
</tr><tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                                com = new SqlCommand("mh_cc", con);
                                com.CommandType = CommandType.StoredProcedure;
                                com.Parameters.AddWithValue("agent_id", agnetID);
                                com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    lastTsdsRate = 0.0000M;
                                    lastSurcharge = 0.0000M;
                                    string ss = dr["Used_Date"].ToString();
                                    TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2);
                                    TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                    TotComm += decimal.Parse(dr["Commissionable_Amount"].ToString());
                                    TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                    if (dr["tds"].ToString() != "0.0000")
                                        lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                    if (dr["surcharge"].ToString() != "0.0000")
                                        lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                    Tds_discount = Math.Ceiling((((decimal.Parse(dr["MHDiscount"].ToString()) + decimal.Parse(dr["Commissionable_Amount"].ToString())) * lastTsdsRate)) / 100);
                                    TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                    TotTds += Tds_discount;
                                    surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                table += @"<tr> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                Total = Math.Round(((TotDiscount + TotComm + TotAgentExp) - Math.Ceiling(TotTds) - surCharge - EduChrg));
                                table += @"<tr > <td colspan=""10""  align=""center""> </td> </tr>";
                                table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar, MidpointRounding.AwayFromZero) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp; </td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""10"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm, MidpointRounding.AwayFromZero) + @"</strong></td></tr><tr class=""boldtext"">	<td colspan=""8"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""></tr>";
                                if (Math.Round(surCharge) != 0)
                                    table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right"" colspan=""8"" ><img src=""images/line2.gif""></td></tr>";

                                table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                table += @"<tr> <td colspan=""8"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                string font = null;
                                GrandTotal = Total;
                                if (Math.Round((Total)) > 0)
                                {
                                    massage = "Total payable To ";
                                    font = "<font color='red'>";
                                    GrandTotal = Math.Round(Total);
                                }


                                table += @"<tr class=""boldtext""><th colspan=""8"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                            }

                            if (GrandTotal > 0)
                                tableAll = tableAll + table;

                            Session["dt"] = tableAll;
                        }
                    }
                    string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    if (tableAll == "" || tableAll == null)
                        Session["dt"] = mass;
                }
                Response.Redirect("CSR_CA.aspx");
            }
            else
            {
                string approveCsr = checkApprove(TextBox1.Text, TextBox2.Text);

                con = new SqlConnection(strCon);
                con.Open();

                string agnetID = "";
                string aID = "";
                string city_id = "";
                if (Session["groupid"].ToString() != "5")
                {
                    for (int k = 0; k < lstAgent.Items.Count; k++)
                    {
                        if (lstAgent.Items[k].Selected == true)
                        {
                            decimal TotChAmount = 0;
                            decimal TotDueCar = 0;
                            decimal TotAgentExp = 0;
                            decimal TotDiscount = 0;
                            decimal TotFrAmount = 0;
                            decimal lastTsdsRate = 0;
                            decimal lastSurcharge = 0;
                            decimal Tds_discount = 0;
                            decimal TotTds = 0;
                            decimal EduChrg = 0; decimal Total = 0;
                            decimal GrandTotal = 0;
                            decimal surCharge = 0;

                            string table = null;
                            aID = ddlAirLine.SelectedItem.Value;
                            agnetID = lstAgent.Items[k].Value;
                            agentName = lstAgent.Items[k].Text;
                            con = new SqlConnection(strCon);
                            con.Open();
                            com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);
                            dr = com.ExecuteReader();
                            if (dr.Read())
                            {
                                city_id = dr["City_id"].ToString();
                                com.Dispose();
                                dr.Dispose();
                                com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    comAdd = dr["company_address"].ToString();
                                    comName = dr["company_name"].ToString();
                                    table += @"<table   style=""word-spacing:inherit"" width=""95%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                                dr = com.ExecuteReader();
                                if (dr.Read())
                                {
                                    string s = dr["agent_address"].ToString();
                                    char ch = (char)System.Windows.Forms.Keys.Return;
                                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                                    string ch1 = Convert.ToString(ch);
                                    string ch3 = Convert.ToString(ch2);
                                    string h = s.Replace(ch1, "<br>");
                                    h = h.Replace(ch3, "&nbsp;");

                                    table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>          
</div>
<br>";
                                }
                                com.Dispose();
                                dr.Dispose();

                                table += @"<table style=""word-spacing:inherit"" width=""95%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable<br> Frt</th><th >Due <br>Carrier</th><th >Agent <br>Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                com = new SqlCommand("mh_cc", con);
                                com.CommandType = CommandType.StoredProcedure;
                                com.Parameters.AddWithValue("agent_id", agnetID);
                                com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    lastTsdsRate = 0.0000M;
                                    lastSurcharge = 0.0000M;
                                    string ss = dr["Used_Date"].ToString();
                                    TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2);
                                    TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                    TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                    if (dr["tds"].ToString() != "0.0000")
                                        lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                    if (dr["surcharge"].ToString() != "0.0000")
                                        lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                    Tds_discount = Math.Ceiling((decimal.Parse(dr["MHDiscount"].ToString()) * lastTsdsRate) / 100);
                                    TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                    TotTds += Tds_discount;
                                    surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                    table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                table += @"<tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                Total = Math.Round((TotDiscount - Math.Ceiling(TotTds) - surCharge - EduChrg), MidpointRounding.AwayFromZero);
                                table += @"<tr > <td colspan=""9""  align=""center""> </td> </tr>";
                                table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""7"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""></tr>";
                                if (Math.Round(surCharge) != 0)
                                    table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right"" ><img src=""images/line2.gif""></td></tr>";

                                table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                table += @"<tr> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                string font = null;
                                GrandTotal = Total;
                                if (Math.Round((Total)) > 0)
                                {
                                    massage = "Total payable To ";
                                    font = "<font color='red'>";
                                    GrandTotal = Math.Round(Total);
                                }


                                table += @"<tr class=""boldtext""><th colspan=""7"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                            }

                            if (GrandTotal > 0)
                                tableAll = tableAll + table;

                            Session["dt"] = tableAll;
                        }
                    }
                    string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    if (tableAll == "" || tableAll == null)
                        Session["dt"] = mass;
                }
                else if (approveCsr == "notApprove")
                {
                    decimal TotChAmount = 0;
                    decimal TotAgentExp = 0;
                    decimal TotDiscount = 0;
                    decimal TotFrAmount = 0;
                    decimal lastTsdsRate = 0;
                    decimal lastSurcharge = 0;
                    decimal Tds_discount = 0;
                    decimal TotTds = 0;
                    decimal EduChrg = 0;
                    decimal surCharge = 0;

                    string table = null;
                    aID = ddlAirLine.SelectedItem.Value;
                    agnetID = lstAgent.SelectedValue;
                    con = new SqlConnection(strCon);
                    con.Open();

                    com = new SqlCommand("select distinct agent_id from sales where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' and Sales.city_id=" + city_id + " ", con);



                    dr = com.ExecuteReader();
                    if (dr.HasRows)
                    {
                        com.Dispose();
                        dr.Dispose();

                        table += @"<p><font color=""red"" size=""2""> The CSR not Generated for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @".</font><br> The following AWB No are in this period:</p>";

                        table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                        com = new SqlCommand("mh_cc", con);
                        com.CommandType = CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("agent_id", agnetID);
                        com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                        com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                        com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                        dr = com.ExecuteReader();
                        while (dr.Read())
                        {
                            lastTsdsRate = 0.0000M;
                            lastSurcharge = 0.0000M;
                            string ss = dr["Used_Date"].ToString();
                            TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2);
                            TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                            TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                            if (dr["tds"].ToString() != "0.0000")
                                lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                            if (dr["surcharge"].ToString() != "0.0000")
                                lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                            Tds_discount = Math.Ceiling((decimal.Parse(dr["MHDiscount"].ToString()) * lastTsdsRate) / 100);
                            TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                            TotTds += Tds_discount;
                            surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                            EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                        }
                        com.Dispose();
                        dr.Dispose();
                        table += @"</table>";
                    }

                    tableAll = tableAll + table;
                    Session["dt"] = tableAll;
                    string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    if (tableAll == "" || tableAll == null)
                        Session["dt"] = mass;

                }
                else
                {

                    for (int k = 0; k < lstAgent.Items.Count; k++)
                    {
                        if (lstAgent.Items[k].Selected == true)
                        {
                            decimal TotChAmount = 0;
                            decimal TotDueCar = 0;
                            decimal TotAgentExp = 0;
                            decimal TotDiscount = 0;
                            decimal TotFrAmount = 0;
                            decimal lastTsdsRate = 0;
                            decimal lastSurcharge = 0;
                            decimal Tds_discount = 0;
                            decimal TotTds = 0;
                            decimal EduChrg = 0; decimal Total = 0;
                            decimal GrandTotal = 0;
                            decimal surCharge = 0;

                            string table = null;
                            aID = ddlAirLine.SelectedItem.Value;
                            agnetID = lstAgent.Items[k].Value;
                            agentName = lstAgent.Items[k].Text;
                            con = new SqlConnection(strCon);
                            con.Open();
                            com = new SqlCommand("select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + TextBox1.Text + "'  and  '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect' ", con);



                            dr = com.ExecuteReader();
                            if (dr.HasRows)
                            {
                                city_id = dr["city_id"].ToString();

                                com.Dispose();
                                dr.Dispose();

                                com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    comAdd = dr["company_address"].ToString();
                                    comName = dr["company_name"].ToString();
                                    table += @"<table   width=""100%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Incentive Statement of CC Shipments</font><br><br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</p></td></tr></table>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);

                                dr = com.ExecuteReader();
                                if (dr.Read())
                                {
                                    string s = dr["agent_address"].ToString();
                                    char ch = (char)System.Windows.Forms.Keys.Return;
                                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                                    string ch1 = Convert.ToString(ch);
                                    string ch3 = Convert.ToString(ch2);
                                    string h = s.Replace(ch1, "<br>");
                                    h = h.Replace(ch3, "&nbsp;");

                                    table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>" + h + @"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
                                }
                                com.Dispose();
                                dr.Dispose();

                                table += @"<table width=""100%"" border=""0""><tr class=""h1""><th >Date</th><th >AWB No.</th><th >Dest</th><th >Chrg. Wt</th>  <th >Receivable Frt</th><th >Due Carrier</th><th >Agent Expenses</th><th >Discount</th><th >Remark</th></tr><tr> <td colspan=""9"" align=""center""></td>
</tr><tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";

                                com = new SqlCommand("mh_cc", con);
                                com.CommandType = CommandType.StoredProcedure;
                                com.Parameters.AddWithValue("agent_id", agnetID);
                                com.Parameters.AddWithValue("Airline_Detail_ID", aID);
                                com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));

                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    lastTsdsRate = 0.0000M;
                                    lastSurcharge = 0.0000M;
                                    string ss = dr["Used_Date"].ToString();
                                    TotChAmount += Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2);
                                    TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                                    TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                    if (dr["tds"].ToString() != "0.0000")
                                        lastTsdsRate = decimal.Parse(dr["tds"].ToString());
                                    if (dr["surcharge"].ToString() != "0.0000")
                                        lastSurcharge = decimal.Parse(dr["surcharge"].ToString());
                                    Tds_discount = Math.Ceiling((decimal.Parse(dr["MHDiscount"].ToString()) * lastTsdsRate) / 100);
                                    TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                                    TotTds += Tds_discount;
                                    surCharge += Math.Round((Tds_discount * decimal.Parse(dr["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Tds_discount + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                    table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString()), 2) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + 0 + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["MHDiscount"].ToString())) + @"</td><td>" + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                                }
                                com.Dispose();
                                dr.Dispose();
                                table += @"<tr> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                                Total = Math.Round((TotDiscount - Math.Ceiling(TotTds) - surCharge - EduChrg));
                                table += @"<tr > <td colspan=""9""  align=""center""> </td> </tr>";
                                table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td align=""right"">" + Math.Round(TotChAmount, 2) + @" </td><td align=""right"" >" + Math.Round(TotFrAmount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDueCar, MidpointRounding.AwayFromZero) + @" </td><td align=""right"">" + Math.Round(TotAgentExp, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp; </td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""9"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""7"" align=""right""><strong>Discount</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""></tr>";

                                if (Math.Round(surCharge) != 0)
                                    table += @"<tr class=""boldtext""><td colspan=""8"" align=""right""><strong>Less SurCharge@" + Math.Round(lastSurcharge, 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Less Educational Cess</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                table += @"<tr class=""boldtext""> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right"" colspan=""7"" ><img src=""images/line2.gif""></td></tr>";

                                table += @"<tr class=""boldtext""><td colspan=""7"" align=""right""><strong>Total</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(Total, MidpointRounding.AwayFromZero) + @"</strong></td></tr>";

                                table += @"<tr> <td colspan=""7"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                string font = null;
                                GrandTotal = Total;
                                if (Math.Round((Total)) > 0)
                                {
                                    massage = "Total payable To ";
                                    font = "<font color='red'>";
                                    GrandTotal = Math.Round(Total);
                                }


                                table += @"<tr class=""boldtext""><th colspan=""7"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"" style=""color: red"">INR &nbsp;(" + font + GrandTotal + @")</font></td></tr></table><br><br><br style=""page-break-before:always;""><br><br>";

                            }

                            if (GrandTotal > 0)
                                tableAll = tableAll + table;

                            Session["dt"] = tableAll;
                        }
                    }
                    string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    if (tableAll == "" || tableAll == null)
                        Session["dt"] = mass;
                }
                Response.Redirect("CSR_CA.aspx");


            }


        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    public String CsrTable
    {
        get
        {
            //return textCity.Text;
            Session["dt"] = tableAll;
            return tableAll;
        }
    }
    protected string checkApprove(string dt1, string dt2)
    {
        string s = null;
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("select * from Approved_CSR a inner join CSR_Duration b on a.CSR_Duration_ID=b.CSR_Duration_ID where CSR_Duration1='" + dt1 + "-" + dt2 + "'", con);
        dr = com.ExecuteReader();
        if (dr.Read())
            s = "approve";
        else
            s = "notApprove";

        return s;


    }


    protected void hdnDate_ValueChanged(object sender, EventArgs e)
    {

    }
}
