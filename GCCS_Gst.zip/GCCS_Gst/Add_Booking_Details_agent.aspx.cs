using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Add_Booking_Details_agent : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    decimal ch_wt;
    public string calendarControl = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        lblAWBShortmsg.Visible = false;
        lblAWBmsg.Visible = false;
        lblcreditlimitcheck.Visible = false;
        txtValuationCharge.Attributes.Add("onblur", "Valuation()");
        txtTax.Attributes.Add("onblur", "Tax()");
        ViewState["edit"] = "0";
        ViewState["et"] = "1";
        lblmsg.Visible = false;
        //txtAWBDate.Text = FormatDateDD(DateTime.Now.ToShortDateString());
        if (Session["TariffRate"] != null)
        {
            txtTariffRate.Text = Session["TariffRate"].ToString();
        }
        if (Session["FreightAmount"] != null)
        {
            decimal FA = decimal.Parse(Session["FreightAmount"].ToString());
            FA = Math.Round(FA, 2);
            txtSpAmt.Text = FA.ToString();
        }
        if (Session["SpecialRate"] != null)
        {
            txtSpRate.Text = Session["SpecialRate"].ToString();
        }
        if (Session["SpecialAmount"] != null)
        {
            decimal SA = decimal.Parse(Session["SpecialAmount"].ToString());
            SA = Math.Round(SA, 2);
            txtFreightAmount.Text = SA.ToString();
            lblSpecialAmount.Text = txtFreightAmount.Text;
        }
        //txthandover_date.Text = FormatDateMM(DateTime.Now.ToShortDateString());

        if (Session["AgentName"] != null)
        {
            lblAgent.Text = Session["AgentName"].ToString();
        }
        if (!IsPostBack)
        {
            txtAWBDate.Text = FormatDateDD(DateTime.Now.ToShortDateString());
            txthandover_date.Text = FormatDateMM(DateTime.Now.ToShortDateString());

            MakeTable();
            //Checking For Spot Rate Row Visible or False

            if (Session["groupid"].ToString() == "5")
            {
                lblSpotRate.Text = "Spot Rate Request";
                if (Convert.ToDecimal(Session["VolWt"].ToString()) > Convert.ToDecimal(Session["GrossWt"].ToString()))
                {
                    ch_wt = Convert.ToDecimal(Session["VolWt"].ToString());

                    if (ch_wt >= 500)
                    {
                        Spot_Rate.Visible = true;
                    }
                }
                else
                {
                    ch_wt = Convert.ToDecimal(Session["GrossWt"].ToString());
                    if (ch_wt >= 500)
                    {
                        Spot_Rate.Visible = true;
                    }

                }

            }
            else
            {
                lblSpotRate.Text = "Spot Rate";
                decimal v = Convert.ToDecimal(Session["VolWt"].ToString());
                decimal g = Convert.ToDecimal(Session["GrossWt"].ToString());
                if (Convert.ToDecimal(Session["VolWt"].ToString()) > Convert.ToDecimal(Session["GrossWt"].ToString()))
                {
                    ch_wt = Convert.ToDecimal(Session["VolWt"].ToString());

                    if (ch_wt >= 500)
                    {
                        Spot_Rate.Visible = true;
                    }
                }
                else
                {
                    ch_wt = Convert.ToDecimal(Session["GrossWt"].ToString());
                    if (ch_wt >= 500)
                    {
                        Spot_Rate.Visible = true;
                    }

                }

            }

            DataTable dt = (DataTable)Session["dtOtherCharges"];
            grd.DataSource = dt;
            grd.DataBind();

            //rbRate.SelectedValue = "2";
            txtFlightNo.Text = Session["FlightNo"].ToString();
            // txtFlightDate.Text = "08/11/2007";//Session["FlightDate"].ToString();
            txtFlightDate.Text = Session["FlightDate"].ToString();
            txtCurrency.Text = "INR";
            if (Session["FreightType"] != null && Session["FreightType"].ToString() == "PREPAID")
            {
                txtCGHSCode.Text = "PP";
            }
            if (Session["FreightType"] != null && Session["FreightType"].ToString() == "COLLECT")
            {
                txtCGHSCode.Text = "CC";
            }
            rbFType.SelectedValue = Session["FreightType"].ToString();
            rbDueFreight.SelectedValue = Session["FreightType"].ToString();
            txtCatrage.Text = "0";
            txtValuationCharge.Text = "0";
            txtTax.Text = "0";
            //Session["FlightID"];
            if (Session["AgentID"] != null)
            {
                string AgentID = Session["AgentID"].ToString();
                txtGw.Text = Session["GrossWt"].ToString();
                lblVw.Text = Session["VolWt"].ToString();

                if (decimal.Parse(txtGw.Text) > decimal.Parse(lblVw.Text))
                {
                    txtCw.Text = txtGw.Text;
                }
                else
                {
                    txtCw.Text = lblVw.Text;
                }
                if (Session["Flag"] != null && Session["Flag"].ToString() == "1")
                {
                    if (Session["nextslabChwt"] != null)
                    {
                        txtCw.Text = Session["nextslabChwt"].ToString();
                    }
                }
                DataTable dtDimension = new DataTable();
                if (Session["dtTemp"] != null)
                {
                    dtDimension = (DataTable)Session["dtTemp"];
                }
                int Pieces = 0;
                foreach (DataRow rw in dtDimension.Rows)
                {
                    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                }
                if (Session["Pieces"] != null)
                {
                    txtPieces.Text = Session["Pieces"].ToString();
                }
                else
                {
                    txtPieces.Text = Pieces.ToString();
                }
                DataTable dtAgentName = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + AgentID);
                if (dtAgentName.Rows.Count > 0)
                {
                    lblAgent.Text = dtAgentName.Rows[0]["Agent_Name"].ToString();
                }

            }
            if (Session["booking_enquiry_no"].ToString() != "")
            {
                LoadAWBNo_Neutral();
                ddlAWBNo.SelectedItem.Text = Session["bookin_awb_no"].ToString();
                ddlAWBNo.SelectedValue = Session["bookin_awb_id"].ToString();
                ddlAWBNo.Enabled = false;
            }
            else
            {
                LoadAWBNo();
            }
            LoadShipmentType();
            LoadOrigin();
            LoadCommodity();
            LoadDestination();

            LoadDestination();
            //*******Calculation of Due Carrier**************************

            ddlOrigin.SelectedValue = Session["Origin"].ToString();
            ddlOrigin.Enabled = false;
            ddlDestination.SelectedValue = Session["Destination"].ToString();
            ddlDestination.Enabled = false;
            ddlShipmentType.SelectedValue = Session["ShipmentType"].ToString();
            ddlShipmentType.Enabled = false;
            ddlScr.SelectedValue = Session["Scr"].ToString();
            ddlScr.Enabled = false;
            DueCarrier();
        }
    }
    public void DueCarrier()
    {
        decimal DueCarrier = 0, A = 0, B = 0, C = 0, Gw = 0, Cw = 0, FSC = 0, AWBFee = 0, DisbursmentCharges = 0, ACIFee = 0, Security_Surcharge = 0, Xray = 0;
        if (txtGw.Text != "" && txtCw.Text != "")
        {
            Gw = decimal.Parse(txtGw.Text);
            Cw = decimal.Parse(txtCw.Text);
        }

        DataTable dtCharges = dw.GetAllFromQuery("select FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,DisBursementCharges from Airline_Detail where Airline_Detail_ID=" + Session["AirlineDetailID"].ToString());

        DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + Session["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue + " and Agent_Rate_ID=" + Session["Agent_Rate_ID"].ToString());
        if (dtCharges.Rows.Count > 0)
        {
            if (dtCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Cw * FSC;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Gw * FSC;
                    }
                }
            }
            if (dtCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Cw * Security_Surcharge;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Gw * Security_Surcharge;
                    }
                }
            }
            if (dtCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Cw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Gw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
            }
            ACIFee = decimal.Parse(dtCharges.Rows[0]["ACI_Fees"].ToString());
            DisbursmentCharges = decimal.Parse(dtCharges.Rows[0]["DisBursementCharges"].ToString());
            AWBFee = decimal.Parse(dtCharges.Rows[0]["AWB_Fees"].ToString());

            //ViewState["A"] = A;
            //ViewState["B"] = B;
            //ViewState["C"] = C; 
            A = Math.Round(A, MidpointRounding.AwayFromZero);
            B = Math.Round(B, MidpointRounding.AwayFromZero);
            C = Math.Round(C, MidpointRounding.AwayFromZero);
            txtFSC.Text = A.ToString();
            txtWSC.Text = B.ToString();
            txtXRAY.Text = C.ToString();
            // DueCarrier = A + B + C + decimal.Parse(dtCharges.Rows[0]["AWB_Fees"].ToString()) + decimal.Parse(dtCharges.Rows[0]["ACI_Fees"].ToString()) + decimal.Parse(dtCharges.Rows[0]["DisBursementCharges"].ToString());
        }
        //txtACIFee.Text = ACIFee.ToString();
        txtACIFee.Text = "0";
        ACIFee = Math.Round(ACIFee, MidpointRounding.AwayFromZero);
        Hidden1.Value = ACIFee.ToString();
        // txtDisbursmentCharges.Text = DisbursmentCharges.ToString();
        txtDisbursmentCharges.Text = "0";
        DisbursmentCharges = Math.Round(DisbursmentCharges, MidpointRounding.AwayFromZero);
        Hidden2.Value = DisbursmentCharges.ToString();




        //**** For Catrage Charges***************
        if (ddlOrigin.SelectedValue == "18")
        {
            if (decimal.Parse(txtGw.Text) >= 50)
            {
                txtCatrage.Text = txtGw.Text;
            }
            else
            {
                txtCatrage.Text = "50";
            }
        }
        else
        {
            txtCatrage.Text = "0";
        }
        //****End of Catrage Charges*************




        //txtAWBFee.Text = AWBFee.ToString();
        //**** For AWB Fee***********************
        if (decimal.Parse(txtCw.Text) >= 150)
        {
            decimal C_W_T = Math.Round(decimal.Parse(txtCw.Text), MidpointRounding.AwayFromZero);
            txtAWBFee.Text = C_W_T.ToString();
        }
        else
        {
            txtAWBFee.Text = "150";
        }
        //**** For End ofAWB Fee*****************
        DueCarrier = A + B + C + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text);
        txtDueCarrier.Text = DueCarrier.ToString();
        decimal Charges = A + B + C;
        Hidden3.Value = Charges.ToString();
        // Hidden3.Value = DueCarrier.ToString();
        if (rbDueFreight.SelectedValue == "PREPAID")
        {
            decimal TotalPrepaid = Convert.ToDecimal(DueCarrier.ToString()) + Convert.ToDecimal(txtFreightAmount.Text);
            txtPrepaid.Text = TotalPrepaid.ToString();
            txtCollect.Text = "0";
        }
        else
        {
            decimal TotalCollect = Convert.ToDecimal(DueCarrier.ToString()) + Convert.ToDecimal(txtFreightAmount.Text);
            txtCollect.Text = TotalCollect.ToString();
            txtPrepaid.Text = "0";
        }
    }
    public void LoadDestination()
    {
        try
        {
            string strAgent = "select Destination_ID,Destination_Code,Destination_Name from Destination_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Insert(0, "- -Select- -");
            ddlDestination.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadCommodity()
    {
        try
        {
            string strAgent = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlScr.Items.Insert(0, "- -Select- -");
            ddlScr.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadOrigin()
    {
        try
        {
            string strAgent = "select City_ID,City_Code,City_Name from City_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadShipmentType()
    {
        try
        {
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlShipmentType.Items.Insert(0, "- -Select- -");
            ddlShipmentType.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlShipmentType.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadAWBNo()
    {
        try
        {
            string strAirline = "Select Airline_Code from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + Session["AirlineDetailID"].ToString() + "'";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAirline, con);
            SqlDataReader dr_A = com.ExecuteReader();
            if (dr_A.Read())
            {
                string Airline_Code = dr_A["Airline_Code"].ToString();
                string strAgent = "select Stock_ID,AirWayBill_No from Stock_Master where Status=16 and neutral='N' and substring(AirWayBill_No,1,3)='" + Airline_Code + "' and Agent_ID=" + Session["AgentID"].ToString() + " and City_ID=" + Session["Origin"].ToString();
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(strAgent, con);
                SqlDataReader dr = com.ExecuteReader();
                ddlAWBNo.Items.Insert(0, "- -Select- -");
                ddlAWBNo.Items[0].Value = "0";
                while (dr.Read())
                {
                    ddlAWBNo.Items.Add(new ListItem(dr["AirWayBill_No"].ToString(), dr["Stock_ID"].ToString()));
                }
                con.Close();
            }
            dr_A.Close();
            com.Dispose();
            con.Close();

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadAWBNo_Neutral()
    {
        try
        {
            string strAirline = "Select Airline_Code from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + Session["AirlineDetailID"].ToString() + "'";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAirline, con);
            SqlDataReader dr_A = com.ExecuteReader();
            if (dr_A.Read())
            {
                string Airline_Code = dr_A["Airline_Code"].ToString();
                string strAgent = "select Stock_ID,AirWayBill_No from Stock_Master where Status=16 and neutral='Y' and substring(AirWayBill_No,1,3)='" + Airline_Code + "' and Agent_ID=" + Session["AgentID"].ToString() + " and City_ID=" + Session["Origin"].ToString();
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(strAgent, con);
                SqlDataReader dr = com.ExecuteReader();
                ddlAWBNo.Items.Insert(0, "- -Select- -");
                ddlAWBNo.Items[0].Value = "0";
                while (dr.Read())
                {
                    ddlAWBNo.Items.Add(new ListItem(dr["AirWayBill_No"].ToString(), dr["Stock_ID"].ToString()));
                }
                con.Close();
            }
            dr_A.Close();
            com.Dispose();
            con.Close();

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction tr = con.BeginTransaction();

        string status;
        if (Session["groupid"].ToString() == "5")
        {
            status = "3";
        }
        else
        {
            status = "9";
        }
        DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Booking_Master where Stock_ID=" + ddlAWBNo.SelectedValue + " and status=9");
        if (dtAWBCheck.Rows.Count <= 0)
        {
            decimal check_limit = Convert.ToDecimal(Session["CheckLimit"]);

            decimal Booking_Amount = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueCarrier.Text);
            if (check_limit < Booking_Amount)
            {
                lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
                lblcreditlimitcheck.Visible = true;
            }
            else
            {
                DataTable dtBookingID;
                long BookingID = 0;
                int OtherChargesID = 0;

                try
                {

                    Insert_BookingMaster(tr, con);
                    dtBookingID = dw.GetAllFromQuery("select ident_current('Booking_Master') as BookingID");
                    BookingID = long.Parse(dtBookingID.Rows[0]["BookingID"].ToString());
                    Update_Stock(tr, con, status);
                    // dw.GetAllFromQuery("update Stock_Master set Status=9 where Stock_ID=" + ddlAWBNo.SelectedValue);
                    Update_AWBDate(tr, con);
                    decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(Session["SpecialAmount"]);
                    Used_Limit = Used_Limit + Convert.ToDecimal(Session["UsedLimit"].ToString());

                    //Update_AgentLimit(tr, con, Used_Limit);

                    //dw.GetAllFromQuery("update Agent_Master set Used_Limit=" + Used_Limit + " where Agent_ID=" + Session["AgentID"].ToString());

                    DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                    if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                    {
                        dtOtherChargesID.Rows[0].Delete();
                    }
                    if (dtOtherChargesID.Rows.Count > 0)
                    {
                        Insert_OtherCharges(tr, con, BookingID);
                        dtOtherChargesID = dw.GetAllFromQuery("select ident_current('Other_Charges') as OtherChargesID");
                        OtherChargesID = int.Parse(dtOtherChargesID.Rows[0]["OtherChargesID"].ToString());
                    }


                    Insert_BookingAWB(tr, con, BookingID);

                    DataTable dtTemp = new DataTable();
                    if (Session["dtTemp"] != null)
                    {
                        dtTemp = (DataTable)Session["dtTemp"];
                        if (dtTemp.Rows[0]["SNo"].ToString() == "0")
                        {
                            dtTemp.Rows[0].Delete();
                        }
                    }

                    if (dtBookingID.Rows.Count > 0 && dtTemp.Rows.Count > 0)
                    {
                        Insert_BookingDimesion(tr, con, BookingID);

                    }
                    if (Session["booking_enquiry_no"].ToString() != "")
                    {
                        updatebookingEnquiry(tr, con);

                    }
                    tr.Commit();
                    con.Close();

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    tr.Rollback();
                }
                Response.Redirect("Booking_Details.aspx");
            }//****End of Else**************
        }//end of AWB IF
        else
        {
            lblAWBmsg.Visible = true;
        }

    }
    #region Update_AWBDate
    public void Update_AWBDate(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Stock_Master set Used_Date='" + FormatDateMM(txtAWBDate.Text) + "'" + "  where Stock_ID=" + ddlAWBNo.SelectedValue;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }
    #endregion

    #region Update_AgentLimit
    public void Update_AgentLimit(SqlTransaction tr, SqlConnection con, decimal Used_Limit)
    {
        string update;

        update = "update Agent_Master set Used_Limit=" + Used_Limit + " where Agent_ID=" + Session["AgentID"].ToString();
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion

    #region Update_Stock
    public void Update_Stock(SqlTransaction tr, SqlConnection con, string status)
    {
        string update;

        update = "update Stock_Master set Status='" + status + "'" + "  where Stock_ID=" + ddlAWBNo.SelectedValue;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion
    #region Update_BookingEnquiry
    public void updatebookingEnquiry(SqlTransaction tr, SqlConnection con)
    {
        string updateEnquiry;

        updateEnquiry = "update booking_enquiry set Status='B' where Booking_EnquiryNo='" + Session["booking_enquiry_no"].ToString() + "'";
        SqlCommand com = new SqlCommand(updateEnquiry, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion


    protected void MakeTable()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "Sno";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "FeeName";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "Fee";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "PaymentType";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        DataRow dr = dt.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dt.Rows.Add(dr);
        Session["dtOtherCharges"] = dt;
        ViewState["dtBeginCharges"] = dt;

    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            if (dt.Rows[0]["Sno"].ToString() == "0")
            {
                dt.Rows[0].Delete();
            }
            TextBox txthader = grd.FooterRow.FindControl("txtheader") as TextBox;
            TextBox txtfee = grd.FooterRow.FindControl("txtvalue") as TextBox;
            DropDownList drp = (DropDownList)(grd.FooterRow.FindControl("ddlgrd"));
            string paymenttype = drp.SelectedItem.Text;
            DataRow dr = dt.NewRow();
            dr[1] = txthader.Text;
            dr[2] = txtfee.Text;
            dr[3] = paymenttype;
            dt.Rows.Add(dr);
            Session["dtOtherCharges"] = dt;
            decimal DueAgent = 0, DueAgentP = 0, DueAgentC = 0;
            foreach (DataRow rw in dt.Rows)
            {
                DueAgent = DueAgent + Convert.ToDecimal(rw["Fee"].ToString());
                if (rw["PaymentType"].ToString() == "PREPAID")
                {
                    DueAgentP = DueAgentP + Convert.ToDecimal(rw["Fee"].ToString());
                }
                if (rw["PaymentType"].ToString() == "COLLECT")
                {
                    DueAgentC = DueAgentC + Convert.ToDecimal(rw["Fee"].ToString());
                }
            }
            //****************************************
            txtDueAgentP.Text = DueAgentP.ToString();
            txtDueAgentC.Text = DueAgentC.ToString();
            txtDueAgent.Text = DueAgent.ToString();
            //****************************************

            //******Calculation of Dbcharges****************
            decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text));
            txtDueAgentP.Text = dueP.ToString();
            decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text));
            txtDueAgentC.Text = dueC.ToString();
            decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text));
            txtPrepaid.Text = PP.ToString();
            decimal CC = Math.Round(decimal.Parse(txtCollect.Text));
            txtCollect.Text = CC.ToString();

            if (txtDueAgentC.Text != "0")
            {
                decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                //Taking 10% of Dbcharges*******************
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                {
                    txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                }
                else
                {
                    txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                }
            }
            else
            {
                txtDisbursmentCharges.Text = "0";
            }
            //****End of Dbcharges**************************

            //*****Managing Values After PostBack***********

            decimal ACI = decimal.Parse(Hidden1.Value) * decimal.Parse(txtHouses.Value);
            txtACIFee.Text = ACI.ToString();
            //decimal Due = decimal.Parse(Hidden3.Value) + (ACI - decimal.Parse(Hidden1.Value));
            decimal Result = Convert.ToDecimal(Hidden3.Value) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text);
            txtDueCarrier.Text = Result.ToString();

            //*****End of Manage Values******************

            grd.DataSource = dt;
            grd.DataBind();

            if (rbDueFreight.SelectedValue == "PREPAID")
            {
                decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Total_Prepaid = Total_Prepaid + decimal.Parse(txtFreightAmount.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = txtDueAgentC.Text;
                }
                else
                {
                    decimal Total_Collect = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentC.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = Total_Prepaid.ToString();
                }
            }
            else
            {
                decimal Total_Collect = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentC.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    decimal Total_Prepaid = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentP.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = Total_Collect.ToString();
                }
                else
                {
                    Total_Collect = Total_Collect + decimal.Parse(txtFreightAmount.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = txtDueAgentP.Text;
                }
            }
        }
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int Sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "PREPAID")
                    {
                        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentP.Text = DueAgentP.ToString();
                        txtPrepaid.Text = Prepaid.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "COLLECT")
                    {
                        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentC.Text = DueAgentC.ToString();
                        decimal Collect = decimal.Parse(txtCollect.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtCollect.Text = Collect.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    dt.Rows[e.RowIndex].Delete();

                    //******Calculation of DbCharges*****************
                    decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text));
                    txtDueAgentP.Text = dueP.ToString();
                    decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text));
                    txtDueAgentC.Text = dueC.ToString();
                    decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text));
                    txtPrepaid.Text = PP.ToString();
                    decimal CC = Math.Round(decimal.Parse(txtCollect.Text));
                    txtCollect.Text = CC.ToString();
                    if (txtDueAgentC.Text != "0")
                    {
                        decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                        //Taking 10% of Dbcharges*******************
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                        decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                        if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                        {
                            txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                        }
                        else
                        {
                            txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                        }
                    }
                    else
                    {
                        txtDisbursmentCharges.Text = "0";
                    }
                    //***End of Calculation of DbCharges*****************
                }
                break;
            }
        }//****End of Foreach loop**********

        //**********Calculation of DueCarrier on Update*********
        decimal Result = Convert.ToDecimal(Hidden3.Value) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        if (dt.Rows.Count > 0)
        {
            Session["dtOtherCharges"] = dt;
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            DataTable dtBeginCharges = (DataTable)ViewState["dtBeginCharges"];
            Session["dtOtherCharges"] = dtBeginCharges;
            grd.DataSource = dtBeginCharges;
            grd.DataBind();
        }
    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grd.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
        }
        else
        {
            lblmsg.Visible = false;
            Label edit = (Label)grd.Rows[e.NewEditIndex].FindControl("lblpaymenttype");
            Label txtFee = (Label)grd.Rows[e.NewEditIndex].FindControl("txtvalue");
            ViewState["Fee"] = txtFee.Text;
            ViewState["PaymentMode"] = edit.Text;
            ViewState["edit"] = edit.Text;
            ViewState["et"] = ViewState["edit"];
            grd.EditIndex = e.NewEditIndex;
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            grd.DataSource = dt;
            grd.DataBind();
        }

    }
    protected void grd_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        string strheader = ((TextBox)grd.Rows[e.RowIndex].FindControl("txtheader")).Text;
        //int value =Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        decimal value = Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        DropDownList drp = (DropDownList)(grd.Rows[e.RowIndex].FindControl("ddlgrd"));
        string paymenttype = drp.SelectedItem.Text;

        decimal Fee = Convert.ToDecimal(ViewState["Fee"]);
        string PaymentMode = Convert.ToString(ViewState["PaymentMode"]);

        //********* FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    txtCollect.Text = Collect.ToString();
                }
            }
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    txtPrepaid.Text = Prepaid.ToString();
                }
            }
        }

        //********End of FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "COLLECT")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //}
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "PREPAID")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();

            //    }
            //}

        }

        //************** Calculation Of DbCharges*********

        decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text));
        txtDueAgentP.Text = dueP.ToString();
        decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text));
        txtDueAgentC.Text = dueC.ToString();
        decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text));
        txtPrepaid.Text = PP.ToString();
        decimal CC = Math.Round(decimal.Parse(txtCollect.Text));
        txtCollect.Text = CC.ToString();


        if (txtDueAgentC.Text != "0")
        {
            decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
            //Taking 10% of Dbcharges*******************
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
            decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
            if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
            {
                txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
            }
        }
        else
        {
            txtDisbursmentCharges.Text = "0";
        }

        //********End of Calculation Of DbCharges*********

        //**********Calculation of DueCarrier on Update*********
        decimal Result = Convert.ToDecimal(Hidden3.Value) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == sno.ToString())
            {
                dr[1] = strheader;
                dr[2] = value;
                dr[3] = paymenttype;
            }
        }
        Session["dtOtherCharges"] = dt;
        grd.DataSource = dt;
        grd.EditIndex = -1;
        grd.DataBind();

    }
    protected void grd_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd.EditIndex = -1;
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        grd.DataSource = dt;
        grd.DataBind();
    }
    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (ViewState["edit"].ToString() == ViewState["et"].ToString())
            {
                Label lbl = (Label)e.Row.Cells[3].FindControl("lblpaymenttype");
                DropDownList ddl = (DropDownList)e.Row.Cells[3].FindControl("ddlgrd");
                if (ViewState["edit"].ToString() == "PREPAID")
                {
                    //ddl.SelectedIndex=2;
                }
                else
                {
                    //ddl.SelectedIndex=1;

                }
            }
            if (grd.EditIndex == e.Row.RowIndex)
            {
                //DropDownList ddlGrd = (DropDownList)e.Row.FindControl("ddlgrd");
                //ddlGrd.SelectedItem.Text = ViewState["PaymentMode"].ToString();

                //ddlGrd.Items.Add(new ListItem("PREPAID","PREPAID"));
                //ddlGrd.Items.Add(new ListItem("COLLECT","COLLECT"));
                //ddlGrd.SelectedIndex = ddlGrd.Items.IndexOf(ddlGrd.Items.FindByText((e.Row.c));


            }

        }
    }

    #region Insert_BookingMaster
    public void Insert_BookingMaster(SqlTransaction tr, SqlConnection con)
    {
        string insert;


        insert = "insert into Booking_Master(Flight_Open_ID,Booking_Date,Stock_ID,Special_Commodity_ID,Shipment_ID,City_ID,Destination_ID,Agent_ID,Flight_Date,No_of_Packages,Measurement_Unit,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Agent_Deal_Remarks,Expected_Handover_Date,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Handovered_Status,Status,Entered_By,Entered_On) values(@Flight_Open_ID,@Booking_Date,@Stock_ID,@Special_Commodity_ID,@Shipment_ID,@City_ID,@Destination_ID,@Agent_ID,@Flight_Date,@No_of_Packages,@Measurement_Unit,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Agent_Deal_Remarks,@Expected_Handover_Date,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Handovered_Status,@Status,@Entered_By,@Entered_On)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        //DataTable dtFlightBookingCode = dw.GetAllFromQuery("select Flight_Booking_Code from Flight_Open where Flight_ID=" + FlightID);
        //if (dtFlightBookingCode.Rows.Count > 0)
        //{
        // com.Parameters.Add("@Flight_Booking_Code", SqlDbType.VarChar).Value = dtFlightBookingCode.Rows[0]["Flight_Booking_Code"].ToString();
        // }
        //com.Parameters.AddWithValue("@Booking_Date",FormatDateDD(txtAWBDate.Text));
        // com.Parameters.AddWithValue("@Booking_Date",FormatDateDD(txtAWBDate.Text));
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.VarChar).Value = Session["Flight_Open_Id"].ToString(); //from View
        com.Parameters.Add("@Booking_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        // com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = FlightID;
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = ddlAWBNo.SelectedValue;
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = ddlOrigin.SelectedValue;
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = Session["AgentID"].ToString();
        // com.Parameters.Add("@Booking_Dimension_ID", SqlDbType.Int).Value = txtXRayCharges.Text.Trim();
        //com.Parameters.Add("@Slab_ID", SqlDbType.Int).Value = 3;
        // com.Parameters.AddWithValue("@Flight_Date",DateTime.Now);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = txtPieces.Text;
        com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = Session["Unit"].ToString();
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = txtGw.Text;
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = lblVw.Text;
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = txtCw.Text;
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = txtSpotRate.Text;
        //com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = txtCommission.Text;
        //com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = txtSCRInc.Text;
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtAgentDealRemarks.Text;
        com.Parameters.AddWithValue("@Expected_Handover_Date", FormatDateDD(txthandover_date.Text));
        //com.Parameters.Add("@Expected_Handover_Date", SqlDbType.DateTime).Value = FormatDateDD(txthandover_date.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);

        com.Parameters.Add("@Handovered_Status", SqlDbType.Int).Value = 14;
        string status;
        if (Session["groupid"].ToString() == "5")
        {
            status = "3";
        }
        else
        {
            status = "9";
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = status;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        // com.Parameters.AddWithValue("@Entered_On",DateTime.Now);
        com.ExecuteNonQuery();

    }
    #endregion


    #region  Insert_OtherCharges
    public void Insert_OtherCharges(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string insert;


        if (Session["dtOtherCharges"] != null)
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                insert = "insert into Other_Charges(Booking_ID,AirWayBill_No,Charge_Name,Amount,Prepaid_or_Collect) values(@Booking_ID,@AirWayBill_No,@Charge_Name,@Amount,@Prepaid_or_Collect)";

                SqlCommand com = new SqlCommand(insert, con, tr);
                com.CommandType = CommandType.Text;
                com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
                com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAWBNo.SelectedItem.Text;
                string FeeName = dt.Rows[i]["FeeName"].ToString();
                FeeName = FeeName.Replace("'", "`");
                com.Parameters.Add("@Charge_Name", SqlDbType.VarChar).Value = FeeName;
                com.Parameters.Add("@Amount", SqlDbType.Decimal).Value = dt.Rows[i]["Fee"].ToString();
                com.Parameters.Add("@Prepaid_or_Collect", SqlDbType.VarChar).Value = dt.Rows[i]["PaymentType"].ToString();
                com.ExecuteNonQuery();

            }
        }
    }
    #endregion


    #region Insert_BookingAWB
    public void Insert_BookingAWB(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string insert;

        insert = "insert into Booking_AWB(Booking_ID,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,Handling_Information,Nature_and_Quantity,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,War_Surcharges,Fuel_Surcharges,Xray_Charges) values(@Booking_ID,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@Handling_Information,@Nature_and_Quantity,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = txtCurrency.Text;
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = txtCGHSCode.Text;
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = txtDVCarriage.Text;
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = txtDVCustom.Text;
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = txtHouses.Value;
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = txtHandlingInformation.Text;
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = txtNatureGoods.Text;
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        // com.Parameters.Add("@Total_Amount", SqlDbType.Decimal).Value = txtFreightAmount.Text;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = txtDueAgentP.Text;
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = txtDueAgentC.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = txtDueCarrier.Text;
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = txtPrepaid.Text;
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = txtCollect.Text;
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        DataTable dtLogin = dw.GetAllFromQuery("select Login_Master_ID from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'");

        com.Parameters.Add("@Login_Master_ID", SqlDbType.BigInt).Value = decimal.Parse(dtLogin.Rows[0]["Login_Master_ID"].ToString());
        com.ExecuteNonQuery();

    }
    #endregion


    #region Insert_BookingDimesion
    public void Insert_BookingDimesion(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string insert;
        //con = new SqlConnection(strCon);
        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {
            dtDimension = (DataTable)Session["dtTemp"];

            for (int i = 0; i < dtDimension.Rows.Count; i++)
            {

                insert = "insert into Booking_Dimensions(Booking_ID,No_of_Packages,Length,Breadth,Height,Total) values(@Booking_ID,@No_of_Packages,@Length,@Breadth,@Height,@Total)";

                SqlCommand com = new SqlCommand(insert, con, tr);
                com.CommandType = CommandType.Text;
                com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
                com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
                com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
                com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
                com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
                com.ExecuteNonQuery();
            }
        }
    }
    #endregion

    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void ddlAWBNo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {

    }
    protected void txtACIFee_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction tr = con.BeginTransaction();

        string status;
        if (Session["groupid"].ToString() == "5")
        {
            status = "3";
        }
        else
        {
            status = "9";
        }
        DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Booking_Master where Stock_ID=" + ddlAWBNo.SelectedValue);
        if (dtAWBCheck.Rows.Count <= 0)
        {

            decimal check_limit = Convert.ToDecimal(Session["CheckLimit"]);

            decimal Booking_Amount = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueCarrier.Text);
            if (check_limit < Booking_Amount)
            {
                lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
                lblcreditlimitcheck.Visible = true;
            }
            else
            {
                DataTable dtShortBookingID;
                long ShortBookingID = 0;
                Insert_ShortBookingMaster(tr, con);
                dtShortBookingID = dw.GetAllFromQuery("select ident_current('Booking_Master') as BookingID");
                ShortBookingID = long.Parse(dtShortBookingID.Rows[0]["BookingID"].ToString());
                ViewState["ShortBookingID"] = ShortBookingID;

                Update_Stock(tr, con, status);
                Update_AWBDate(tr, con);
                //dw.GetAllFromQuery("update Stock_Master set Status='" + status + "' where Stock_ID='" + ddlAWBNo.SelectedValue + "'");
                decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(Session["SpecialAmount"]);
                Used_Limit = Used_Limit + Convert.ToDecimal(Session["UsedLimit"].ToString());

                //Update_AgentLimit(tr, con, Used_Limit);

                //dw.GetAllFromQuery("update Agent_Master set Used_Limit="+Used_Limit+" where Agent_ID=" + Session["AgentID"].ToString());          
                Insert_ShortBookingAWB(tr, con, ShortBookingID);

                DataTable dtBookingAWBID = dw.GetAllFromQuery("select ident_current('Booking_AWB') as BookingAWBID");
                string strBookingAWBID = dtBookingAWBID.Rows[0]["BookingAWBID"].ToString();
                ViewState["BookingAWBID"] = strBookingAWBID;

                // Response.Redirect("Booking_Details.aspx");    

                DataTable dtDimension = new DataTable();
                if (Session["dtTemp"] != null)
                {
                    dtDimension = (DataTable)Session["dtTemp"];
                    if (dtDimension.Rows[0]["SNo"].ToString() == "0")
                    {
                        dtDimension.Rows[0].Delete();
                        Session["dtTemp"] = dtDimension;
                    }
                    Insert_BookingDimesion(tr, con, ShortBookingID);
                    DataTable dtBookingDimensionID = dw.GetAllFromQuery("select ident_current('Booking_Dimensions') as BookingDimensionsID");
                    tr.Commit();
                    con.Close();
                    if (dtBookingDimensionID.Rows.Count > 0)
                    {
                        string strBookingDimensionsID = dtBookingDimensionID.Rows[0]["BookingDimensionsID"].ToString();
                        ViewState["BookingDimensionsID"] = strBookingDimensionsID;
                    }
                }
                // Response.Redirect("Booking_Details.aspx");   
                btnUpdate.Visible = true;
                Button1.Visible = false;
                MoreDetails.Visible = true;
                Button4.Visible = false;
                btnSubmit.Enabled = false;
                ddlAWBNo.Enabled = false;
                txtAWBDate.Enabled = false;
                txthandover_date.Enabled = false;
                calendarControl = null;
            }
        }
        else
        {
            lblAWBShortmsg.Visible = true;
        }

    }


    protected void Button4_Click(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        DetailBooking.Visible = true;
    }


    public void Insert_ShortBookingAWB(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string insert;

        insert = "insert into Booking_AWB(Booking_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,Cartridge_Charges,TotalDueAgent_Prepaid,duecarrier_type,TotalDueAgent_Collect,No_of_houses,Total_ACI_Fees,Total_DueCarrier,Total_Prepaid,Total_Collect,War_Surcharges,Fuel_Surcharges,Xray_Charges) values(@Booking_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@Cartridge_Charges,@TotalDueAgent_Prepaid,@duecarrier_type,@TotalDueAgent_Collect,@No_of_houses,@Total_ACI_Fees,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentP.Text);
        com.Parameters.Add("@duecarrier_type", SqlDbType.VarChar).Value = "PREPAID";
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentC.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = 0;
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtDueCarrier.Text);
        if (Session["FreightType"].ToString() == "PREPAID")
        {
            com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = Convert.ToDecimal(Session["SpecialAmount"].ToString()) + decimal.Parse(txtDueCarrier.Text);
        }
        else
        {
            com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = 0;
        }
        if (Session["FreightType"].ToString() == "COLLECT")
        {
            com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = Convert.ToDecimal(Session["SpecialAmount"].ToString()) + decimal.Parse(txtDueCarrier.Text);
        }
        else
        {
            com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = 0;
        }
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        DataTable dtLogin = dw.GetAllFromQuery("select Login_Master_ID from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'");

        com.Parameters.Add("@Login_Master_ID", SqlDbType.BigInt).Value = decimal.Parse(dtLogin.Rows[0]["Login_Master_ID"].ToString());
        com.ExecuteNonQuery();

    }


    public void Insert_ShortBookingMaster(SqlTransaction tr, SqlConnection con)
    {
        string insert;
        decimal Chg_wt;

        //long FlightID = long.Parse(Session["FlightID"].ToString());

        //*************** Inserting Data in Booking_Master Table***************

        insert = "insert into Booking_Master(Flight_Open_ID,Booking_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,City_ID,Destination_ID,Flight_Date,No_of_Packages,Measurement_Unit,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Spot_Rate,Expected_Handover_Date,Status,Handovered_Status,Entered_By,Entered_On) values(@Flight_Open_ID,@Booking_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@City_ID,@Destination_ID,@Flight_Date,@No_of_Packages,@Measurement_Unit,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Spot_Rate,@Expected_Handover_Date,@Status,@Handovered_Status,@Entered_By,@Entered_On)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        decimal id = Convert.ToInt64(Session["Flight_Open_Id"].ToString());
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = Convert.ToInt64(Session["Flight_Open_Id"].ToString());


        com.Parameters.Add("@Booking_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
        //com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = FlightID;
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAWBNo.SelectedValue);//ddlAWBNo.SelectedValue;
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = Convert.ToInt64(Session["AgentID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = Convert.ToInt64(Session["Scr"].ToString()); ;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = Convert.ToInt32(Session["ShipmentType"].ToString());
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = Convert.ToInt32(Session["Origin"].ToString());
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = Convert.ToInt64(Session["Destination"].ToString());

        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(Session["FlightDate"].ToString());


        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = Convert.ToInt32(Session["Pieces"].ToString());
        com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = Session["Unit"].ToString();
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(Session["GrossWt"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(Session["VolWt"].ToString());




        if (Convert.ToDecimal(Session["VolWt"].ToString()) > Convert.ToDecimal(Session["GrossWt"].ToString()))
        {
            Chg_wt = Convert.ToDecimal(Session["VolWt"].ToString());
            //com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(Session["VolWt"].ToString());
        }
        else
        {
            Chg_wt = Convert.ToDecimal(Session["GrossWt"].ToString());
            //com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(Session["GrossWt"].ToString());

        }

        if (Session["Flag"] != null && Session["Flag"].ToString() == "1")
        {
            if (Session["nextslabChwt"] != null)
            {
                Chg_wt = Convert.ToDecimal(Session["nextslabChwt"].ToString());
                //com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(Session["nextslabChwt"].ToString());
            }
        }
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(Chg_wt);
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = Convert.ToDecimal(txtSpotRate.Text);
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = 0;
        string Agent_Deal_Remarks = txtAgentDealRemarks.Text;
        Agent_Deal_Remarks = Agent_Deal_Remarks.Replace("'", "`");
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = Agent_Deal_Remarks;
        com.Parameters.AddWithValue("@Expected_Handover_Date", SqlDbType.DateTime).Value = FormatDateDD(txthandover_date.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = Session["FreightType"].ToString();
        decimal Freight_Amt = Convert.ToDecimal(Session["FreightAmount"].ToString());
        decimal tariff_rate = Freight_Amt / Chg_wt;

        //com.Parameters.Add("@Tariff_Rate", SqlDbType.BigInt).Value = Convert.ToDecimal(Session["TariffRate"].ToString());
        com.Parameters.Add("@Tariff_Rate", SqlDbType.BigInt).Value = Convert.ToDecimal(Session["TariffRate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.BigInt).Value = Convert.ToDecimal(Session["FreightAmount"].ToString());
        com.Parameters.Add("@Special_Rate", SqlDbType.BigInt).Value = Convert.ToDecimal(Session["SpecialRate"]);
        com.Parameters.Add("@Special_Amount", SqlDbType.BigInt).Value = Convert.ToDecimal(Session["SpecialAmount"]);
        if (Session["groupid"].ToString() == "5")
        {
            com.Parameters.Add("@Status", SqlDbType.Int).Value = 3;
        }
        else
        {
            com.Parameters.Add("@Status", SqlDbType.Int).Value = 9;
        }

        com.Parameters.Add("@Handovered_Status", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.ExecuteNonQuery();

    }

    #region Update_BookingMaster
    public void Update_BookingMaster(SqlTransaction tr, SqlConnection con)
    {
        string update;


        //long FlightID = long.Parse(Session["FlightID"].ToString());

        //*************** Inserting Data in Booking_Master Table***************

        update = "update Booking_Master set Flight_Open_ID=@Flight_Open_ID,Booking_Date=@Booking_Date,Stock_ID=@Stock_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_ID=@Shipment_ID,City_ID=@City_ID,Destination_ID=@Destination_ID,Agent_ID=@Agent_ID,Flight_Date=@Flight_Date,No_of_Packages=@No_of_Packages,Measurement_Unit=@Measurement_Unit,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Spot_Rate=@Spot_Rate,Agent_Deal_Remarks=@Agent_Deal_Remarks,Expected_Handover_Date=@Expected_Handover_Date,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Special_Rate=@Special_Rate,Special_Amount=@Special_Amount,Handovered_Status=@Handovered_Status,Status=@Status,Entered_By=@Entered_By,Entered_On=@Entered_On where Booking_ID=@Booking_ID";


        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        //DataTable dtFlightBookingCode = dw.GetAllFromQuery("select Flight_Booking_Code from Flight_Open where Flight_ID=" + FlightID);
        //if (dtFlightBookingCode.Rows.Count > 0)
        //{
        // com.Parameters.Add("@Flight_Booking_Code", SqlDbType.VarChar).Value = dtFlightBookingCode.Rows[0]["Flight_Booking_Code"].ToString();
        // }
        //com.Parameters.AddWithValue("@Booking_Date",FormatDateDD(txtAWBDate.Text));
        // com.Parameters.AddWithValue("@Booking_Date",FormatDateDD(txtAWBDate.Text));
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["ShortBookingID"].ToString());
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.VarChar).Value = Session["Flight_Open_Id"].ToString(); //from View
        com.Parameters.Add("@Booking_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        // com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = FlightID;
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = ddlAWBNo.SelectedValue;
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = ddlOrigin.SelectedValue;
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = Session["AgentID"].ToString();
        // com.Parameters.Add("@Booking_Dimension_ID", SqlDbType.Int).Value = txtXRayCharges.Text.Trim();
        //com.Parameters.Add("@Slab_ID", SqlDbType.Int).Value = 3;
        // com.Parameters.AddWithValue("@Flight_Date",DateTime.Now);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = txtPieces.Text;
        com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = Session["Unit"].ToString();
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = txtGw.Text;
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = lblVw.Text;
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = txtCw.Text;
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = txtSpotRate.Text;
        //com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = txtCommission.Text;
        //com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = txtSCRInc.Text;
        string Agent_Deal_Remarks = txtAgentDealRemarks.Text;
        Agent_Deal_Remarks = Agent_Deal_Remarks.Replace("'", "`");
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = Agent_Deal_Remarks;
        com.Parameters.AddWithValue("@Expected_Handover_Date", FormatDateDD(txthandover_date.Text));
        //com.Parameters.Add("@Expected_Handover_Date", SqlDbType.DateTime).Value = FormatDateDD(txthandover_date.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;

        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);

        com.Parameters.Add("@Handovered_Status", SqlDbType.Int).Value = 14;
        string status;
        if (Session["groupid"].ToString() == "5")
        {
            status = "3";
        }
        else
        {
            status = "9";
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = status;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        // com.Parameters.AddWithValue("@Entered_On",DateTime.Now);
        com.ExecuteNonQuery();

    }
    #endregion


    #region Update_BookingAWB
    public void Update_BookingAWB(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string update;


        update = "update Booking_AWB set Booking_ID=@Booking_ID,Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Currency=@Currency,CHGS_Code=@CHGS_Code,Declared_Carriage_Value=@Declared_Carriage_Value,Declared_Custom_Value=@Declared_Custom_Value,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,Handling_Information=@Handling_Information,Nature_and_Quantity=@Nature_and_Quantity,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges where Booking_AWB_ID=@Booking_AWB_ID";


        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Booking_AWB_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["BookingAWBID"].ToString());
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = txtCurrency.Text;
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = txtCGHSCode.Text;
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = txtDVCarriage.Text;
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = txtDVCustom.Text;
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = txtHouses.Value;
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = txtHandlingInformation.Text;
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = txtNatureGoods.Text;
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        // com.Parameters.Add("@Total_Amount", SqlDbType.Decimal).Value = txtFreightAmount.Text;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = txtDueAgentP.Text;
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = txtDueAgentC.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = txtDueCarrier.Text;
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = txtPrepaid.Text;
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = txtCollect.Text;
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        DataTable dtLogin = dw.GetAllFromQuery("select Login_Master_ID from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'");

        com.Parameters.Add("@Login_Master_ID", SqlDbType.BigInt).Value = decimal.Parse(dtLogin.Rows[0]["Login_Master_ID"].ToString());
        com.ExecuteNonQuery();
    }
    #endregion


    #region Update_BookingDimesion
    public void Update_BookingDimesion(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string update;

        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {
            dtDimension = (DataTable)Session["dtTemp"];

            for (int i = 0; i < dtDimension.Rows.Count; i++)
            {


                update = "update Booking_Dimensions set Booking_ID=@Booking_ID,No_of_Packages=@No_of_Packages,Length=@Length,Breadth=@Breadth,Height=@Height,Total=@Total where Booking_Dimension_ID=@Booking_Dimension_ID";

                SqlCommand com = new SqlCommand(update, con, tr);
                com.CommandType = CommandType.Text;
                com.Parameters.Add("@Booking_Dimension_ID", SqlDbType.Int).Value = BookingID;
                com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
                com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
                com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
                com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
                com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
                com.ExecuteNonQuery();

            }
        }
    }
    #endregion

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction tr = con.BeginTransaction();

        string status;
        if (Session["groupid"].ToString() == "5")
        {
            status = "3";
        }
        else
        {
            status = "9";
        }
        DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Booking_Master where Stock_ID=" + ddlAWBNo.SelectedValue);
        if (dtAWBCheck.Rows.Count > 0)
        {
            decimal check_limit = Convert.ToDecimal(Session["CheckLimit"]);
            decimal Booking_Amount = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueCarrier.Text);
            if (check_limit < Booking_Amount)
            {
                lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
                lblcreditlimitcheck.Visible = true;
            }
            else
            {

                DataTable dtBookingID;
                long BookingID = 0;
                int OtherChargesID = 0;

                try
                {
                    Update_BookingMaster(tr, con);

                    dtBookingID = dw.GetAllFromQuery("select ident_current('Booking_Master') as BookingID");
                    BookingID = long.Parse(dtBookingID.Rows[0]["BookingID"].ToString());
                    decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(Session["SpecialAmount"]);
                    Used_Limit = Used_Limit + Convert.ToDecimal(Session["UsedLimit"].ToString());

                    //Update_AgentLimit(tr, con, Used_Limit);

                    //dw.GetAllFromQuery("update Agent_Master set Used_Limit=" + Used_Limit + " where Agent_ID=" + Session["AgentID"].ToString());

                    Update_AWBDate(tr, con);
                    Update_Stock(tr, con, status);
                    // BookingID = long.Parse(dtBookingID.Rows[0]["BookingID"].ToString());
                    //dw.GetAllFromQuery("update Stock_Master set Status=9 where Stock_ID=" + ddlAWBNo.SelectedValue);

                    DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                    if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                    {
                        dtOtherChargesID.Rows[0].Delete();
                    }
                    if (dtBookingID.Rows.Count > 0 && dtOtherChargesID.Rows.Count > 0)
                    {
                        Insert_OtherCharges(tr, con, BookingID);
                        dtOtherChargesID = dw.GetAllFromQuery("select ident_current('Other_Charges') as OtherChargesID");
                    }

                    if (dtOtherChargesID.Rows.Count > 0)
                    {
                        OtherChargesID = int.Parse(dtOtherChargesID.Rows[0]["OtherChargesID"].ToString());
                    }
                    if (dtBookingID.Rows.Count > 0)
                    {
                        Update_BookingAWB(tr, con, BookingID);
                    }
                    DataTable dtTemp = new DataTable();
                    if (Session["dtTemp"] != null)
                    {
                        dtTemp = (DataTable)Session["dtTemp"];
                        if (dtTemp.Rows.Count > 0)
                        {
                            if (dtTemp.Rows[0]["SNo"].ToString() == "0")
                            {
                                dtTemp.Rows[0].Delete();
                            }
                        }
                    }

                    if (dtBookingID.Rows.Count > 0 && dtTemp.Rows.Count > 0)
                    {
                        Update_BookingDimesion(tr, con, BookingID);

                    }
                    tr.Commit();
                    con.Close();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    tr.Rollback();
                }
                Response.Redirect("Booking_Details.aspx");
            }
        }
        else
        {
            lblAWBmsg.Visible = true;
        }
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        DetailBooking.Visible = true;
        MoreDetails.Visible = false;
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("Booking_Details.aspx");
    }
}
