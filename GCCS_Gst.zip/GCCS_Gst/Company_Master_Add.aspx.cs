using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//Created by Rakhi on 18 Oct 2007

public partial class Company_Master_Add : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataSet ds;
    public int id;
    int Company_ID;
    protected void Page_Load(object sender, EventArgs e)
    {
        //btnadd.Attributes.Add("onclick", "return CheckEmpty()");
        //btnupdate.Attributes.Add("onclick", "return CheckEmpty()");

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack && Request.QueryString["Company_ID"] != null)
            {
                btnupdate.Attributes.Add("onclick", "return CheckEmpty()");
                btnupdate.Visible = true;
                btnadd.Visible = false;
                lblAdd.Visible = false;
                lblUpdate.Visible = true;
                txtCompanyName.Enabled = false;

                FillddlCity();
                FillddlStatus();
                search();
            }
            else if (!Page.IsPostBack) 
            {
               
                btnupdate.Visible = false;
                btnadd.Visible = true;
                lblAdd.Visible = true;
                lblUpdate.Visible = false;
                btnadd.Attributes.Add("onclick", "return CheckEmpty()");
                FillddlCity();
                FillddlStatus();
                //lblHead.Text = "ADD SUBCATEGORY";
                //btnSubmit.Text = "Add";

            }


            //if (!IsPostBack && Request.QueryString["Company_ID"] == null)
            //{
            //    FillddlCity();
            //    FillddlStatus();

            //}

            //else if (!IsPostBack && Request.QueryString["Company_ID"] != null)
            //{
            //    FillddlCity();
            //    FillddlStatus();
            //    search();
            //}

            //if (Request.QueryString["action"] == "e")
            //{
            //    btnadd.Visible = false;   

            //}
            //else
            //{
            //    btnupdate.Visible = false;            
            //}     

        }
    }

    private void FillddlCity()
    {
        con = new SqlConnection(strCon);
        SqlCommand com = new SqlCommand("select * from City_Master ", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        ddlCity.Items.Add("--Select--");
        ddlCity.Items[0].Value = "";
        while (dr.Read())
        {
            ddlCity.Items.Add(new ListItem(dr["City_Name"].ToString(), dr["City_ID"].ToString()));
        }
        dr.Close();
        con.Close();
    }
    private void FillddlStatus()
    {
        con = new SqlConnection(strCon);
        SqlCommand com = new SqlCommand("select * from Status_Master where Status_Name in( 'Active','Inactive') ", con);
        //SqlCommand com = new SqlCommand("select * from Status_Master  ", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        //ddlStatus.Items.Add("--Select--");
        //ddlStatus.Items[0].Value = "";
        while (dr.Read())
        {
            ddlStatus.Items.Add(new ListItem(dr["Status_Name"].ToString(), dr["Status_ID"].ToString()));
        }
        dr.Close();
        con.Close();
    }

    public void Add()
    {
        btnadd.Attributes.Add("onclick", "return CheckEmpty();");
    
        con = new SqlConnection(strCon);
        string str1 = "";
        //Company_ID = Int32.Parse(Request.QueryString["Company_ID"]);
        con.Open();
        string comid = null;
        str1 = "select company_id from company_master where Company_Name='" + txtCompanyName.Text + "'";
        SqlCommand com1 = new SqlCommand(str1, con);
        SqlDataReader dr = com1.ExecuteReader();
        while (dr.Read())
        {
            comid = dr["company_id"].ToString();
        }
        dr.Close();
        con.Close();
        str1 = "select * from company_master where (company_id='" + comid + "' or parent_id='" + comid + "') and city='" + ddlCity.SelectedItem.Value.Trim() + "'";
        //str="select * from Company_Master where  Company_Name='" + txtCompanyName.Text + "' and City='" + ddlCity.SelectedItem.Value.Trim() + "'";
        da = new SqlDataAdapter(str1, con);
        ds = new DataSet();
         da.Fill(ds);
         if (ds.Tables[0].Rows.Count > 0 && comid!=null)
         {
             lblError.Text = " City  ' " + ddlCity.SelectedItem.Text +  " ' Already Exist For Company " + txtCompanyName.Text;
         }
         else
         {

             con = new SqlConnection(strCon);
             string str = "";
             str = "insert into Company_Master(Company_Name,Company_Address,Bank_Name,Bank_Address,Acc_Name,Acc_No,Phone,Company_Fax,Company_Email,TDS_Rate,SurCharge,City,Status) values('" + txtCompanyName.Text + "','" + txtCompanyAddress.Text + "','" + txtBankName.Text + "','" + txtbankaddress.Text + "','" + txtAccountName.Text + "','" + txtAccountNumber.Text + "','" + txtPhone.Text + "','" + txtCompanyFax.Text + "','" + txtCompanyEmail.Text + "','" + txtTDSRate.Text + "','" + txtSurCharge.Text + "','" + ddlCity.SelectedValue.Trim() + "','" + ddlStatus.SelectedValue.Trim() + "')";
             SqlCommand cmd = new SqlCommand(str, con);
             con.Open();
             cmd.ExecuteNonQuery();
             cmd.Dispose();
             con.Close();
             Response.Redirect("Company_Master_Details.aspx");
         }


    }
    public void Update()
    {
        con = new SqlConnection(strCon);
        try
        {
            string str;
            string updateQ = "";
            string name1 = lblName.Text;
            string name2 = txtCompanyName.Text;
            string name3 = lblcity.Text;
            string name4 = ddlCity.Text;
            con = new SqlConnection(strCon);
            int Company_ID = Int32.Parse(Request.QueryString["Company_ID"]);
            if ((String.Compare(name1, name2) == 0) && (String.Compare(name3, name4) == 0))
           {
               updateQ = "update Company_Master set Company_Name='" + txtCompanyName.Text + "', Company_Address='" + txtCompanyAddress.Text + "',Bank_Name = '" + txtBankName.Text + "',Bank_Address='"+ txtbankaddress.Text +"',Acc_Name = '" + txtAccountName.Text + "',Acc_No = '" + txtAccountNumber.Text + "',Phone='" + txtPhone.Text + "',Company_Fax='" + txtCompanyFax.Text + "',Company_Email='" + txtCompanyEmail.Text + "',TDS_Rate=" + txtTDSRate.Text + ",SurCharge=" + txtSurCharge.Text + ",City=" + ddlCity.SelectedValue + ",Status=" + ddlStatus.SelectedValue + " where Company_ID=" + Company_ID + "";
               SqlCommand com = new SqlCommand(updateQ, con);
               con.Open();
               com.ExecuteNonQuery();
               com.Dispose();
               con.Close();
               Response.Redirect("Company_Master_Details.aspx");
            }
            else
            {
                con.Open();
                string comid=null;
                str = "select company_id from company_master where Company_Name='" + txtCompanyName.Text + "'";
                SqlCommand com1 = new SqlCommand(str, con);
                SqlDataReader dr = com1.ExecuteReader();
                while (dr.Read())
                {
                    comid = dr["company_id"].ToString();
                }
                dr.Close();
                con.Close();

                str = "select city from company_master where (company_id='" + comid + "' or parent_id='" + comid + "') and city='" + ddlCity.SelectedItem.Value.Trim() + "'";
                //str="select * from Company_Master where  Company_Name='" + txtCompanyName.Text + "' and City='" + ddlCity.SelectedItem.Value.Trim() + "'";
                da = new SqlDataAdapter(str, con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    lblError.Text = " City  " + ddlCity.SelectedItem.Text + " Already Exist For Company " + txtCompanyName.Text;
                    btnadd.Visible = false;
                    btnupdate.Visible = true;
                    lblAdd.Visible = false;
                    lblUpdate.Visible = true;
                }
                else
                {
                    updateQ = "update Company_Master set Company_Name='" + txtCompanyName.Text + "', Company_Address='" + txtCompanyAddress.Text + "',Bank_Name = '" + txtBankName.Text + "',Bank_Address='" + txtbankaddress.Text + "',Acc_Name = '" + txtAccountName.Text + "',Acc_No = '" + txtAccountNumber.Text + "', Phone='" + txtPhone.Text + "',Company_Fax='" + txtCompanyFax.Text + "',Company_Email='" + txtCompanyEmail.Text + "',TDS_Rate=" + txtTDSRate.Text + ",SurCharge=" + txtSurCharge.Text + ",City=" + ddlCity.SelectedValue + ",Status=" + ddlStatus.SelectedValue + " where Company_ID=" + Company_ID + "";
                    SqlCommand com = new SqlCommand(updateQ, con);
                    con.Open();
                    com.ExecuteNonQuery();
                    com.Dispose();
                    con.Close();
                    Response.Redirect("Company_Master_Details.aspx");

                }
            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    //public void Update()
    //{
    //     string str1 = "";
    //    string updateQ = "";
    //    string name1 = lblName.Text;
    //    string name2 = txtCompanyName.Text;
    //    //string name3 = lblcity.Text;
    //    //string name4 = ddlCity.Text;
    //    con = new SqlConnection(strCon);
    //    int Company_ID = Int32.Parse(Request.QueryString["Company_ID"]);
    //    if (String.Compare(name1, name2) == 0 )
    //    {
    //        str1 = "select * from Company_Master where  Company_Name='" + txtCompanyName.Text + "' and City='" + ddlCity.SelectedItem.Value.Trim() + "'";
    //        da = new SqlDataAdapter(str1, con);
    //        ds = new DataSet();
    //        da.Fill(ds);
    //        if (ds.Tables[0].Rows.Count > 0)
    //        {
    //            lblError.Text = " City  " + ddlCity.SelectedItem.Text + " Already Exist For Company " + txtCompanyName.Text;
    //            btnadd.Visible = false;
    //            btnupdate.Visible = true;
    //            lblAdd.Visible = false;
    //            lblUpdate.Visible = true;
    //        }
    //        else
    //        {
    //             updateQ = "update Company_Master set Company_Name='" + txtCompanyName.Text + "', Company_Address='" + txtCompanyAddress.Text + "',Phone='" + txtPhone.Text + "',Company_Fax='" + txtCompanyFax.Text + "',Company_Email='" + txtCompanyEmail.Text + "',TDS_Rate=" + txtTDSRate.Text + ",SurCharge=" + txtSurCharge.Text + ",City=" + ddlCity.SelectedValue + ",Status=" + ddlStatus.SelectedValue + " where Company_ID=" + Company_ID + "";
    //            SqlCommand com = new SqlCommand(updateQ, con);
    //            con.Open();
    //            com.ExecuteNonQuery();
    //            com.Dispose();
    //            con.Close();
    //            Response.Redirect("Company_Master_Details.aspx");
    //        }
            
               
    //    }
    //    else
    //    {
            
    //        str1 = "select * from Company_Master where  Company_Name='"+txtCompanyName.Text+"' and City='"+ ddlCity.SelectedItem.Value.Trim() +"'";
    //        da = new SqlDataAdapter(str1, con);
    //        ds = new DataSet();
    //        da.Fill(ds);
    //        if (ds.Tables[0].Rows.Count > 0)
    //        {
    //            lblError.Text = "Records already exist";
    //            btnadd.Visible = false;
    //            btnupdate.Visible = true;
    //            lblAdd.Visible = false;
    //            lblUpdate.Visible = true;
    //        }
    //        else
    //        {
    //            updateQ = "update Company_Master set Company_Name='" + txtCompanyName.Text + "',Company_Address='" + txtCompanyAddress.Text + "',Phone='" + txtPhone.Text + "',Company_Fax='" + txtCompanyFax.Text + "',Company_Email='" + txtCompanyEmail.Text + "',TDS_Rate=" + txtTDSRate.Text + ",SurCharge=" + txtSurCharge.Text + ",City=" + ddlCity.SelectedValue + ",Status=" + ddlStatus.SelectedValue + " where Company_ID=" + Company_ID + "";
    //            SqlCommand com = new SqlCommand(updateQ, con);
    //            con.Open();
    //            com.ExecuteNonQuery();
    //            com.Dispose();
    //            con.Close();
    //            Response.Redirect("Company_Master_Details.aspx");
    //        }
    //    }
    //}
      
    
    public void search()
    {
        id = Int32.Parse(Request.QueryString["Company_ID"].ToString());
        con = new SqlConnection(strCon);
        con.Open();
        string strQuery = "select * from company_master where company_Id = '" + id + "'";
        SqlCommand cmd = new SqlCommand(strQuery, con);
        //SqlCommand cmd = new SqlCommand("Company_Master_Search", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //cmd.Parameters.AddWithValue("@Company_ID", id);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                txtCompanyName.Text = dr["Company_name"].ToString();
                lblName.Text = txtCompanyName.Text;
                txtCompanyAddress.Text = dr["Company_Address"].ToString();
                txtBankName.Text = dr["Bank_Name"].ToString();
                txtbankaddress.Text = dr["Bank_Address"].ToString();
                txtAccountName.Text = dr["Acc_Name"].ToString();
                txtAccountNumber.Text = dr["Acc_No"].ToString();
                txtPhone.Text = dr["Phone"].ToString();
                txtCompanyFax.Text = dr["Company_Fax"].ToString();
                txtCompanyEmail.Text = dr["Company_Email"].ToString();
                txtTDSRate.Text = dr["TDS_Rate"].ToString();
                txtSurCharge.Text = dr["SurCharge"].ToString();
                ddlCity.Text = dr["City"].ToString();
                lblcity.Text = ddlCity.Text;
                ddlStatus.Text = dr["Status"].ToString();
                //txtCompanyName.Text = dr.GetValue(0).ToString();
                //lblName.Text = txtCompanyName.Text;
                //txtCompanyAddress.Text = dr.GetValue(1).ToString();
                ////txtBankName.Text
                //txtPhone.Text = dr.GetValue(2).ToString();
                //txtCompanyFax.Text = dr.GetValue(3).ToString();
                //txtCompanyEmail.Text = dr.GetValue(4).ToString();
                //txtTDSRate.Text = dr.GetValue(5).ToString();
                //txtSurCharge.Text = dr.GetValue(6).ToString();
                //ddlCity.Text = dr.GetValue(7).ToString();
                //lblcity.Text = ddlCity.Text;
                //ddlStatus.Text = dr.GetValue(8).ToString();

            }
        }

        con.Close();
        cmd.Dispose();
    }
    //public void clear()
    //{
    //    txtCompanyName.Text = "";
    //    txtCompanyAddress.Text = "";
    //    txtPhone.Text = "";
    //    txtCompanyFax.Text = "";
    //    txtCompanyEmail.Text = "";
    //    txtbankaddress.Text = "";
    //    txtTDSRate.Text = "";
    //    txtSurCharge.Text = "";
    //    ddlCity.SelectedIndex = 0;
    //    ddlStatus.SelectedIndex = 0;


    //}
    protected void btnadd_Click(object sender, EventArgs e)
    {
        Add();
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
         Update();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Company_Master_Details.aspx");
    }

}
