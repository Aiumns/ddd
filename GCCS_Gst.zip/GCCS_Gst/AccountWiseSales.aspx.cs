using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AccountWiseSales : System.Web.UI.Page
{
    // --- Declare Public Variables here ---
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string Table = "";
    string Table2 = "";
    string Table3 = "";
    /// <summary>
    /// Make Connection From Web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string to_month = "";
    string str_AirlineDetailId;
    string strY = "";
    bool year_flag = false;
    int next = 0;
    string from_month = "";


    string SalesPersonID = "";

    string AgentID_ = "";


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            lblDate.Text = FormatDateDD(DateTime.Now.ToShortDateString());
            htmlTableSimple();
        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public void htmlTableSimple()
    {
        string Flightname = Request.QueryString["Flightname"];
        string[] Flight = Flightname.Split(new char[] {','});

        string sales_Person_Id = "";
        string from_date = Request.QueryString["from"];


        SalesPersonID = Request.QueryString["salesPersonID"];

        AgentID_ = Request.QueryString["AgentID"];


        try
        {
            decimal Total_smallAirwaybillCA = 0;
            decimal Total_GreaterAirwaybillCA = 0;
            decimal Total_GreaterChwtCA = 0;
            decimal Total_SmallerChwtCA = 0;
            decimal Total_smallAirwaybillCI = 0;
            decimal Total_GreaterAirwaybillCI = 0;
            decimal Total_GreaterChwtCI = 0;
            decimal Total_SmallerChwtCI = 0;
            decimal Total_smallAirwaybillMH = 0;
            decimal Total_GreaterAirwaybillMH = 0;
            decimal Total_GreaterChwtMH = 0;
            decimal Total_SmallerChwtMH = 0;
            decimal Total_smallAirwaybillTK = 0;
            decimal Total_GreaterAirwaybillTK = 0;
            decimal Total_GreaterChwtTK = 0;
            decimal Total_SmallerChwtTK = 0;
            decimal Total_smallAirwaybillTotal = 0;
            decimal Total_GreaterAirwaybillTotal = 0;
            decimal Total_GreaterChwtTotal = 0;
            decimal Total_SmallerChwtTotal = 0;

            int Sno = 0;

            int ip = 0;

            // Table header create

            decimal TotalsmallAirwaybillCI = 0; decimal TotalGreaterAirwaybillCI = 0; decimal TotalGreaterChwtCI = 0; decimal TotalSmallerChwtCI = 0;


            decimal TotalsmallAirwaybillCA = 0; decimal TotalGreaterAirwaybillCA = 0; decimal TotalGreaterChwtCA = 0; decimal TotalSmallerChwtCA = 0;


            decimal TotalsmallAirwaybillMH = 0; decimal TotalGreaterAirwaybillMH = 0; decimal TotalGreaterChwtMH = 0; decimal TotalSmallerChwtMH = 0;

            decimal TotalsmallAirwaybillTK = 0; decimal TotalGreaterAirwaybillTK = 0; decimal TotalGreaterChwtTK = 0; decimal TotalSmallerChwtTK = 0;

            decimal TotalsmallAirwaybillTotal = 0; decimal TotalGreaterAirwaybillTotal = 0; decimal TotalGreaterChwtTotal = 0; decimal TotalSmallerChwtTotal = 0;

            Table += @"<h5><p align=center>CLUSTER PERFORMANCE REPORT <br>" + FormatDateMM(Request.QueryString["from"]) + " - " + FormatDateMM(Request.QueryString["to"]) + "</p></h5>";
            Table += @"<Table align=center width=80% border=1 cellspacing=0>";
            //Table += @"<tr class=h5 boldtext><td colspan=36>&nbsp;</td></tr>";

            Array myarray = (Array)Flight;

            int ca = Array.BinarySearch(myarray, "CA-DEL");
            int ci = Array.BinarySearch(myarray, "CI-DEL");
            int mh = Array.BinarySearch(myarray, "MH-DEL");
            int tk = Array.BinarySearch(myarray, "TK-DEL");
            //int ca = 0;
            //int mh = 0;
            //int ci = 0;

            //int tk = 0;
            //foreach (string i in myarray)
            //{

            //    if (i.Trim() == "CA-DEL")
            //        ca = 1;
            //    if (i.Trim() == "CI-DELL")
            //        ci = 1;
            //    if (i.Trim() == "MH-DEL")
            //        mh = 1;
            //    if (i.Trim() == "TK-DEL")
            //        tk = 1;

            //}
            Table += @"<tr class=h1 align=left><td colspan=3></td>";
            Table2 += @"<tr class=h5 boldtext><td colspan=3></td>";
            if (ca >=0)
            {
                Table += @"<td colspan=8 align=center>CA-DEL</td>";

                Table2 += @"<td  colspan=4 align=center class=boldtextt nowrap>No oF Awb</td><td colspan=4 align=center class=boldtextt nowrap>Upliftment In Kgs</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";
               
            }
            if (ci >=0)
            {
                Table += @"<td colspan=8 align=center>CI-DEL</td>";
                Table2 += @"<td  colspan=4 align=center class=boldtextt nowrap>No oF Awb</td><td  colspan=4 align=center class=boldtextt nowrap>Upliftment In Kgs</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";
                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

            }
            if (mh >= 0)
            {
                Table += @"<td colspan=8 align=center>MH-DEL</td>";
                Table2 += @"<td  colspan=4 align=center class=boldtextt nowrap>No oF Awb</td><td  colspan=4 align=center class=boldtextt nowrap>Upliftment In Kgs</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";
               

            }
            if (tk >= 0)
            {
                Table += @"<td colspan=8 align=center>TK-DEL</td>";
                Table2 += @"<td  colspan=4 align=center class=boldtextt nowrap>No oF Awb</td><td  colspan=4 align=center class=boldtextt nowrap>Upliftment In Kgs</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";
                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

            }
            
            Table += @"<td colspan=8 align=center>TOTAL</td></tr>";
            Table2 += @"<td  colspan=4 align=center class=boldtextt nowrap>No oF Awb</td><td  colspan=4 align=center class=boldtextt nowrap>Upliftment In Kgs</td></tr>";
            Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

            Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";



            Table = Table + Table2;
            Table += @"<tr class=h1 align=left><td>HEAD</td><td nowrap>AGENT NAME</td><td>MONTH</td>" + Table3 + "</tr>";



            DateTime dt1 = Convert.ToDateTime(FormatDateMM(Request.QueryString["from"].ToString()));
            DateTime dt2 = Convert.ToDateTime(FormatDateMM(Request.QueryString["to"].ToString()));



            //DataTable dtAccountwise = dw.GetAllFromQuery("select user_id from login_master where group_id=8 and user_id is not null");
            DataTable dtAccountwise;

            if (SalesPersonID == "0")
            {
                //dtAccountwise = dw.GetAllFromQuery(" select lm.user_id from login_master lm inner join group_master gm on lm.group_id=gm.group_id inner join user_master um on lm.user_id=um.userId where lm.group_id=8 and um.belongs_to_city=6 and um.userid is not null order by um.full_name");
                dtAccountwise = dw.GetAllFromQuery(" select lm.user_id from login_master lm inner join group_master gm on lm.group_id=gm.group_id inner join user_master um on lm.user_id=um.userId where um.userid IN(39,42,44,57,112,113,135,172) and um.belongs_to_city=6 and um.userid is not null order by um.full_name");
            }
            else
            {
                //dtAccountwise = dw.GetAllFromQuery(" select lm.user_id from login_master lm inner join group_master gm on lm.group_id=gm.group_id inner join user_master um on lm.user_id=um.userId where lm.group_id=8 and um.belongs_to_city=6 and um.userid="+SalesPersonID+" and um.userid is not null order by um.full_name");

                dtAccountwise = dw.GetAllFromQuery(" select lm.user_id from login_master lm inner join group_master gm on lm.group_id=gm.group_id inner join user_master um on lm.user_id=um.userId where um.belongs_to_city=6 and um.userid=" + SalesPersonID + " and um.userid is not null order by um.full_name");


            }
            if (dtAccountwise.Rows.Count > 0)
            {
                //***********User_Id wise or salesperson_Id wise loop***********
                for (int j = 0; j < dtAccountwise.Rows.Count; j++)
                {
                    //DataTable dtUserId = dw.GetAllFromQuery("select user_Id from login_master where Email_ID='" + Session["EMailID"].ToString() + "'");
                    sales_Person_Id = dtAccountwise.Rows[j]["user_id"].ToString();
                    DataTable dtSalesPersonName = new DataTable();


                    dtSalesPersonName = dw.GetAllFromQuery("select full_name from user_master where userid=" + sales_Person_Id + "");
                    //Table += @"<tr><td style='background-color:Pink;' align=left class=text colspan=52 nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + " DETAILS" + @"</td>";



                    //******************MonthWise Loop*****************
                    for (DateTime x = dt1; x < dt2; x = x.AddMonths(1))
                    {

                        string Final_Date = x.ToString();
                        string[] d = Final_Date.Split(new char[] { '/' });
                        string strMM = d[0];
                        string strDD = d[1];
                        string strYYYY = d[2].Substring(0, 4);
                        string month_name = getMonthName(Final_Date);

                        DataTable DtAgent;

                        if (AgentID_ == "0" || AgentID_ == "")
                        {
                            DtAgent = dw.GetAllFromQuery("select agent_id from agentTosalesPerson where sales_person_id=" + sales_Person_Id + " union select agent_id from agentTosalesPerson_History where sales_person_id=" + sales_Person_Id + "");
                        }
                        else
                        {
                            DtAgent = dw.GetAllFromQuery("select agent_id from agentTosalesPerson where sales_person_id=" + sales_Person_Id + " and agent_id=" + AgentID_ + " union select agent_id from agentTosalesPerson_History where sales_person_id=" + sales_Person_Id + " and agent_id=" + AgentID_ + "");
                        }

                        if (DtAgent.Rows.Count > 0)
                        {
                            Table += @"<tr><td style='background-color:Pink;' align=left class=text colspan=52 nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + " DETAILS" + @"</td>";
                            for (int K = 0; K < DtAgent.Rows.Count; K++)
                            {

                                decimal smallAirwaybillCA = 0;
                                decimal GreaterAirwaybillCA = 0;

                                decimal GreaterChwtCA = 0;
                                decimal SmallerChwtCA = 0;

                                decimal smallAirwaybillCI = 0;
                                decimal GreaterAirwaybillCI = 0;
                                decimal GreaterChwtCI = 0;
                                decimal SmallerChwtCI = 0;

                                decimal smallAirwaybillMH = 0;
                                decimal GreaterAirwaybillMH = 0;
                                decimal GreaterChwtMH = 0;
                                decimal SmallerChwtMH = 0;

                                decimal smallAirwaybillTK = 0;
                                decimal GreaterAirwaybillTK = 0;
                                decimal GreaterChwtTK = 0;
                                decimal SmallerChwtTK = 0;

                                decimal smallAirwaybillTotal = 0;
                                decimal GreaterAirwaybillTotal = 0;
                                decimal GreaterChwtTotal = 0;
                                decimal SmallerChwtTotal = 0;

                                DataTable dtAgent_Name = dw.GetAllFromQuery("select agent_name from agent_master where agent_id=" + DtAgent.Rows[K]["agent_id"].ToString() + "");


                                Table += @"<tr><td  align=left class=text nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + @"</td><td align=left class=text nowrap=true>" + dtAgent_Name.Rows[0]["Agent_Name"].ToString() + @"</td><td align=left class=text nowrap=true>" + month_name + "-" + strYYYY + @"</td>";

                                if (ca >= 0)
                                {

                                    //**************For CA*******************

                                    DataTable dtRecord1 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS small_AirWayBill_No,SUM(s.Charged_Weight) AS Small_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight <= 500 AND s.Airline_Detail_ID=151 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND  s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");

                                    if (dtRecord1.Rows.Count > 0)
                                    {
                                        smallAirwaybillCA = Convert.ToDecimal(dtRecord1.Rows[0]["small_AirWayBill_No"].ToString());
                                        SmallerChwtCA = Convert.ToDecimal(dtRecord1.Rows[0]["Small_Charged_Weight"].ToString());
                                    }



                                    DataTable dtRecordG = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS greater_AirWayBill_No,SUM(s.Charged_Weight) AS greater_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight > 500 AND s.Airline_Detail_ID  =151 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND  s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");

                                    if (dtRecordG.Rows.Count > 0)
                                    {
                                        GreaterAirwaybillCA = Convert.ToDecimal(dtRecordG.Rows[0]["greater_AirWayBill_No"].ToString());
                                        GreaterChwtCA = Convert.ToDecimal(dtRecordG.Rows[0]["greater_Charged_Weight"].ToString());
                                    }

                                    TotalGreaterAirwaybillCA += GreaterAirwaybillCA;
                                    TotalsmallAirwaybillCA += smallAirwaybillCA;

                                    TotalGreaterChwtCA += GreaterChwtCA;
                                    TotalSmallerChwtCA += SmallerChwtCA;


                                    //***********Over All Total****************
                                    Total_smallAirwaybillCA += smallAirwaybillCA;
                                    Total_GreaterAirwaybillCA += GreaterAirwaybillCA;

                                    Total_GreaterChwtCA += GreaterChwtCA;
                                    Total_SmallerChwtCA += SmallerChwtCA;

                                    //**************End***********************

                                    Table += "<td colspan=2 align=right class=text>" + GreaterAirwaybillCA + @"</td><td colspan=2 align=right class=text>" + smallAirwaybillCA + @"</td><td colspan=2 align=right class=text>" + GreaterChwtCA + @"</td><td colspan=2 align=right class=text>" + SmallerChwtCA + @"</td>";

                                    //***************End oF CA**********************

                                }
                                if (ci >=0)
                                {

                                    //**************For CI*******************


                                    DataTable dtRecord2 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS small_AirWayBill_No,SUM(s.Charged_Weight) AS Small_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + "  AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight <= 500 AND s.Airline_Detail_ID =149 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");

                                    if (dtRecord2.Rows.Count > 0)
                                    {
                                        smallAirwaybillCI = Convert.ToDecimal(dtRecord2.Rows[0]["small_AirWayBill_No"].ToString());
                                        SmallerChwtCI = Convert.ToDecimal(dtRecord2.Rows[0]["Small_Charged_Weight"].ToString());
                                    }


                                    DataTable dtRecordG2 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS greater_AirWayBill_No,SUM(s.Charged_Weight) AS greater_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight > 500 AND s.Airline_Detail_ID  =149 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND  s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");

                                    if (dtRecordG2.Rows.Count > 0)
                                    {
                                        GreaterAirwaybillCI = Convert.ToDecimal(dtRecordG2.Rows[0]["greater_AirWayBill_No"].ToString());
                                        GreaterChwtCI = Convert.ToDecimal(dtRecordG2.Rows[0]["greater_Charged_Weight"].ToString());
                                    }
                                    TotalGreaterAirwaybillCI += GreaterAirwaybillCI;
                                    TotalsmallAirwaybillCI += smallAirwaybillCI;

                                    TotalGreaterChwtCI += GreaterChwtCI;
                                    TotalSmallerChwtCI += SmallerChwtCI;

                                    //***********Over All Total****************
                                    Total_smallAirwaybillCI += smallAirwaybillCI;
                                    Total_GreaterAirwaybillCI += GreaterAirwaybillCI;
                                            
                                    Total_GreaterChwtCI += GreaterChwtCI;
                                    Total_SmallerChwtCI += SmallerChwtCI;

                                    //**************End***********************

                                    Table += "<td colspan=2 align=right class=text>" + GreaterAirwaybillCI + @"</td><td colspan=2 align=right class=text>" + smallAirwaybillCI + @"</td><td colspan=2 align=right class=text>" + GreaterChwtCI + @"</td><td colspan=2 align=right class=text>" + SmallerChwtCI + @"</td>";

                                    //******************END oF CI*************************

                                }
                                if (mh >= 0)
                                {

                                    //******FOR MH*********************

                                    DataTable dtRecord3 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS small_AirWayBill_No,SUM(s.Charged_Weight) AS Small_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Charged_Weight <= 500 AND s.Airline_Detail_ID  =148 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ")  AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and  s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");



                                    if (dtRecord3.Rows.Count > 0)
                                    {
                                        smallAirwaybillMH = Convert.ToDecimal(dtRecord3.Rows[0]["small_AirWayBill_No"].ToString());
                                        SmallerChwtMH = Convert.ToDecimal(dtRecord3.Rows[0]["Small_Charged_Weight"].ToString());
                                    }




                                    DataTable dtRecordG3 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS greater_AirWayBill_No,SUM(s.Charged_Weight) AS greater_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight > 500 AND s.Airline_Detail_ID  =148 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND   s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");

                                    if (dtRecordG3.Rows.Count > 0)
                                    {
                                        GreaterAirwaybillMH = Convert.ToDecimal(dtRecordG3.Rows[0]["greater_AirWayBill_No"].ToString());
                                        GreaterChwtMH = Convert.ToDecimal(dtRecordG3.Rows[0]["greater_Charged_Weight"].ToString());
                                    }

                                    TotalGreaterAirwaybillMH += GreaterAirwaybillMH;
                                    TotalsmallAirwaybillMH += smallAirwaybillMH;
                                    TotalGreaterChwtMH += GreaterChwtMH;
                                    TotalSmallerChwtMH += SmallerChwtMH;


                                    //***********Over All Total****************
                                    Total_smallAirwaybillMH += smallAirwaybillMH;
                                    Total_GreaterAirwaybillMH += GreaterAirwaybillMH;

                                    Total_GreaterChwtMH += GreaterChwtMH;
                                    Total_SmallerChwtMH += SmallerChwtMH;

                                    //**************End***********************

                                    Table += "<td colspan=2 align=right class=text>" + GreaterAirwaybillMH + @"</td><td colspan=2 align=right class=text>" + smallAirwaybillMH + @"</td><td colspan=2 align=right class=text>" + GreaterChwtMH + @"</td><td colspan=2 align=right class=text>" + SmallerChwtMH + @"</td>";
                                    //******END of MH************************

                                }
                                if (tk >= 0)
                                {
                                    DataTable dtRecord4 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS small_AirWayBill_No,SUM(s.Charged_Weight) AS Small_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Charged_Weight <= 500 AND s.Airline_Detail_ID  =150 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ")  AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and  s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");


                                    if (dtRecord4.Rows.Count > 0)
                                    {
                                        smallAirwaybillTK = Convert.ToDecimal(dtRecord4.Rows[0]["small_AirWayBill_No"].ToString());
                                        SmallerChwtTK = Convert.ToDecimal(dtRecord4.Rows[0]["Small_Charged_Weight"].ToString());
                                    }


                                    DataTable dtRecordG4 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS greater_AirWayBill_No,SUM(s.Charged_Weight) AS greater_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN agentTosalesPerson ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight > 500 AND s.Airline_Detail_ID  =150 AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND   s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");


                                    if (dtRecordG4.Rows.Count > 0)
                                    {
                                        GreaterAirwaybillTK = Convert.ToDecimal(dtRecordG4.Rows[0]["greater_AirWayBill_No"].ToString());
                                        GreaterChwtTK = Convert.ToDecimal(dtRecordG4.Rows[0]["greater_Charged_Weight"].ToString());
                                    }
                                    TotalGreaterAirwaybillTK += GreaterAirwaybillTK;
                                    TotalsmallAirwaybillTK += smallAirwaybillTK;
                                    TotalGreaterChwtTK += GreaterChwtTK;
                                    TotalSmallerChwtTK += SmallerChwtTK;

                                    //***********Over All Total****************
                                    Total_smallAirwaybillTK += smallAirwaybillTK;
                                    Total_GreaterAirwaybillTK += GreaterAirwaybillTK;

                                    Total_GreaterChwtTK += GreaterChwtTK;
                                    Total_SmallerChwtTK += SmallerChwtTK;

                                    //**************End***********************


                                    Table += "<td colspan=2 align=right class=text>" + GreaterAirwaybillTK + @"</td><td colspan=2 align=right class=text>" + smallAirwaybillTK + @"</td><td colspan=2 align=right class=text>" + GreaterChwtTK + @"</td><td colspan=2 align=right class=text>" + SmallerChwtTK + @"</td>";

                                    //******END oF TK********************

                                }
                                //******************For Total**************

                                smallAirwaybillTotal = smallAirwaybillCA + smallAirwaybillCI + smallAirwaybillMH + smallAirwaybillTK;

                                GreaterAirwaybillTotal = GreaterAirwaybillCA + GreaterAirwaybillCI + GreaterAirwaybillMH + GreaterAirwaybillTK;
                                SmallerChwtTotal = SmallerChwtCA + SmallerChwtCI + SmallerChwtMH + SmallerChwtTK;

                                GreaterChwtTotal = GreaterChwtCA + GreaterChwtCI + GreaterChwtMH + GreaterChwtTK;


                                TotalGreaterAirwaybillTotal += GreaterAirwaybillTotal;
                                TotalsmallAirwaybillTotal += smallAirwaybillTotal;
                                TotalGreaterChwtTotal += GreaterChwtTotal;
                                TotalSmallerChwtTotal += SmallerChwtTotal;



                                Total_smallAirwaybillTotal += smallAirwaybillTotal;
                                Total_GreaterAirwaybillTotal += GreaterAirwaybillTotal;
                                Total_GreaterChwtTotal += GreaterChwtTotal;
                                Total_SmallerChwtTotal += SmallerChwtTotal;




                                Table += "<td colspan=2 align=right class=text>" + GreaterAirwaybillTotal + @"</td><td colspan=2 align=right class=text>" + smallAirwaybillTotal + @"</td><td colspan=2 align=right class=text>" + GreaterChwtTotal + @"</td><td colspan=2 align=right class=text>" + SmallerChwtTotal + @"</td>";
                                //******************End oF Total*********


                                //TotalGreaterAirwaybillTotal += GreaterAirwaybillTotal;
                                //TotalsmallAirwaybillTotal += smallAirwaybillTotal;
                                //TotalGreaterChwtTotal += GreaterChwtTotal;
                                //TotalSmallerChwtTotal += SmallerChwtTotal;



                            }
                            Table += @"<tr ><td style='background-color:BlanchedAlmond;' lign=left class=text>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + "</td><td style='background-color:BlanchedAlmond;' align=left class=text>" + month_name + "-" + strYYYY + "  Total" + "</td><td style='background-color:BlanchedAlmond;' align=left class=text>" + month_name + "-" + strYYYY + "</td>";
                            if (ca >= 0)
                            {
                                Table += @"<td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterAirwaybillCA + "</td><td style='background-color:BlanchedAlmond;' colspan=2 align=right class=text>" + TotalsmallAirwaybillCA + "</td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text>" + TotalGreaterChwtCA + "</td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text>" + TotalSmallerChwtCA + "</td>";
                            
                            }
                            if (ci >= 0)
                            {
                                Table += @"<td  colspan=2 style='background-color:BlanchedAlmond;' align=right class=text>" + TotalGreaterAirwaybillCI + "</td><td  colspan=2 style='background-color:BlanchedAlmond;' align=right class=text>" + TotalsmallAirwaybillCI + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterChwtCI + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalSmallerChwtCI + "</td>";
                            }
                            if (mh >= 0)
                            {
                                Table += @"<td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterAirwaybillMH + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalsmallAirwaybillMH + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterChwtMH + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalSmallerChwtMH + "</td>";
                            }
                            if (tk >= 0)
                            {
                                Table += @"<td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterAirwaybillTK + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalsmallAirwaybillTK + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterChwtTK + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalSmallerChwtTK + "</td>";
                            }
                            Table +=@" <td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterAirwaybillTotal + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalsmallAirwaybillTotal + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalGreaterChwtTotal + "</td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text>" + TotalSmallerChwtTotal + "</td></tr>";


                            TotalsmallAirwaybillCI = 0; TotalGreaterAirwaybillCI = 0; TotalGreaterChwtCI = 0; TotalSmallerChwtCI = 0;


                            TotalsmallAirwaybillCA = 0; TotalGreaterAirwaybillCA = 0; TotalGreaterChwtCA = 0; TotalSmallerChwtCA = 0;


                            TotalsmallAirwaybillMH = 0; TotalGreaterAirwaybillMH = 0; TotalGreaterChwtMH = 0; TotalSmallerChwtMH = 0;

                            TotalsmallAirwaybillTK = 0; TotalGreaterAirwaybillTK = 0; TotalGreaterChwtTK = 0; TotalSmallerChwtTK = 0;

                            TotalsmallAirwaybillTotal = 0;
                            TotalGreaterAirwaybillTotal = 0;
                            TotalGreaterChwtTotal = 0;
                            TotalSmallerChwtTotal = 0;

                        }
                        else
                        {
                            //Table += @"<tr ><td colspan=52>No Record Found For:" + dtSalesPersonName.Rows[0]["full_name"].ToString() + "</td></tr>"; 
                            Table += @"<tr><td style='background-color:Pink;' align=left class=text colspan=52 nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + " DETAILS:&nbsp;&nbsp;&nbsp;&nbsp;No  Agent  Found" + @"</td>";
                        }

                    }
                }
                Table += @"<tr><td  style='background-color: Khaki;' colspan=2 align=left class=text>Grand Total</td><td  style='background-color: Khaki;' align=left class=text>&nbsp;</td>";


                if (ca >= 0)
                {
                    Table += @"<td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_GreaterAirwaybillCA + "</td><td  style='background-color: Khaki;' colspan=2 align=right class=text>" + Total_smallAirwaybillCA + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_GreaterChwtCA + "</td><td colspan=2 style='background-color: Khaki;' align=right class=text>" + Total_SmallerChwtCA + "</td>";
                }
                if (ci >= 0)
                {
                    Table += @"<td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_GreaterAirwaybillCI + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_smallAirwaybillCI + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_GreaterChwtCI + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_SmallerChwtCI + "</td>";
                }
                if (mh >= 0)
                {
                    Table += @"<td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_GreaterAirwaybillMH + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_smallAirwaybillMH + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_GreaterChwtMH + "</td><td colspan=2  style='background-color: Khaki;' align=right class=text>" + Total_SmallerChwtMH + "</td>";
                }
                if (tk >= 0)
                {
                    Table += @"<td colspan=2  style='background-color: Khaki;' align=right class=text>" + Total_GreaterAirwaybillTK + "</td><td colspan=2  style='background-color: Khaki;' align=right class=text>" + Total_smallAirwaybillTK + "</td><td colspan=2  style='background-color: Khaki;' align=left class=text>" + Total_GreaterChwtTK + "</td><td colspan=2  style='background-color: Khaki;' align=right class=text>" + Total_SmallerChwtTK + "</td>";
                }

                Table += @"<td colspan=2  style='background-color: Khaki;' align=right class=text>" + Total_GreaterAirwaybillTotal + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_smallAirwaybillTotal + "</td><td colspan=2  style='background-color: Khaki;' align=right class=text>" + Total_GreaterChwtTotal + "</td><td  style='background-color: Khaki;' colspan=2  align=right class=text>" + Total_SmallerChwtTotal + "</td></tr>";
            

                Table += "</Table>";
                Label1.Text = Table;
            }
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
    public string getMonthName(string month)
    {
        string[] mon = month.Split('/');
        string ret_date = "";
        strY = mon[2].Substring(0, 4);
        if (year_flag)
        {
            strY = Convert.ToString(Convert.ToInt16(strY) + 1);
        }
        else
        {
            strY = mon[2];
        }
        switch (Convert.ToInt16(mon[0]))
        {
            case 1:
                ret_date = "January";
                break;
            case 2:
                ret_date = "Febraury";
                break;
            case 3:
                ret_date = "March";
                break;
            case 4:
                ret_date = "April";
                break;
            case 5:
                ret_date = "May";
                break;
            case 6:
                ret_date = "June";
                break;
            case 7:
                ret_date = "July";
                break;
            case 8:
                ret_date = "August";
                break;
            case 9:
                ret_date = "September";
                break;
            case 10:
                ret_date = "October";
                break;
            case 11:
                ret_date = "November";
                break;
            case 12:
                ret_date = "December";
                year_flag = true;
                next = 0;
                from_month = "1";
                break;
        }
        return ret_date;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
