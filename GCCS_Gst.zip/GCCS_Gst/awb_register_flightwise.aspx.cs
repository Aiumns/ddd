using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Net;

public partial class awb_register_flightwise : System.Web.UI.Page
{

    /// <summary>
    /// 
    /// </description>
    /// <createdBy>--------SHAIKH AKHTAR RASOOL--------</createdBy>
    /// <modified by>Shaikh Akhtar Rasool </modified>
    /// <modifiedon>16-01-2008</modifiedon>
    /// </summary>

    
    
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
        {

            //set Hidden field on IP Basis
            if (IPCheck())
            {
                hdnCheckIP.Value = "Internal";
            }
            else
            {
                hdnCheckIP.Value = "Outer";
                //Generate OTP on first call to page
                OTPPwd();
            }
            int dt = System.DateTime.Now.Month;
            ddlMonth.Items[dt - 1].Selected = true;
            int yy = System.DateTime.Now.Year;
            int s = ddlyear.Items.IndexOf(ddlyear.Items.FindByValue(yy.ToString()));
            ddlyear.Items[s].Selected = true;


            try
            {
                con = new SqlConnection(strCon);
                con.Open();
                //cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID", con);



                String airline_access = Session["AIRLINEACCESS"].ToString();
                //DataTable datatable = dw.GetAllFromQuery("select City_Rights from login_master inner join User_Master on login_master.User_ID=User_Master.UserID where Email_ID='" + Session["EMailID"].ToString() + "'");
                //string city_rights = datatable.Rows[0][0].ToString();
                //city_rights = city_rights.Substring(0, city_rights.Length - 1);
                //airline_access = airline_access.Substring(0, airline_access.Length - 1);
                //con = new SqlConnection(strCon);
                //con.Open();
                //cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
                //dr = cmd.ExecuteReader();



                cmd = new SqlCommand("select Flight_ID,Flight_no from flight_master where airline_Detail_id in (" + airline_access + ") and  status=2", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    //ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));


                    ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["Flight_no"]), Convert.ToString(dr["Flight_ID"])));
                }
                cmd.Dispose();
            }
            catch (Exception eror)
            {
                string st = eror.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                con.Close();
                cmd.Dispose();
              
                
            }
        }
    }
    protected void Btnload_Click(object sender, EventArgs e)
    {

        #region IPCheck
        //string IP = GetUserIp();
        //if (IP != "")
        //{
        //    string[] ip_addrs = IP.Split('.');
        //    if (ip_addrs.Length == 4)
        //    {

        //        con = new SqlConnection(strCon);
        //        con.Open();
        //        string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on)VALUES( '" + IP + "','" + DateTime.Now + "')";
        //        com = new SqlCommand(cInsert, con);
        //        com.ExecuteNonQuery();
        //        con.Close();


        //        if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
        //        {
        //        }
        //        else
        //        {
        //            ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact asrao@cargoflash.com');</script>");
        //            return;
        //        }
        //    }
        //    else
        //    {
        //        ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact asrao@cargoflash.com');</script>");
        //        return;
        //    }
        //}
        //else
        //{
        //    ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact asrao@cargoflash.com');</script>");
        //    return;
        //}
        #endregion
        if (hdnCheckIP.Value == "Outer")
        {

            if (hdnOTP.Value == ViewState["currentOtp"].ToString())
            {


            }
            else
            {
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Invalid OTP, Please Check.');</script>");
            }
        }

        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();

        string strY = ddlyear.SelectedItem.Text;

         if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/31/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { 
                    TextBox2.Text = "02/28/" + strY; 
                }
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/31/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/30/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/31/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/30/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/31/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/31/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/30/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/31/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/30/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/31/" + strY;
            }
         DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
        
     Session["from_date"]=TextBox1.Text;
     Session["to_date"] = TextBox2.Text;
     Session["flight_no"] = ddl_airline_city.SelectedItem.Text;
     Session["flight_id"] = ddl_airline_city.SelectedItem.Value;

     ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/awb_register_flightwise.aspx');</script>");
     
    }

    public string GetUserIp()
    {
        string VisitorsIPAddr = string.Empty;
        //Users IP Address.
        if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
        {
            //To get the IP address of the machine and not the proxy
            VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
        }
        else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
        {
            VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
        }
        return VisitorsIPAddr;



    }
    #region Generate Unique One Time Password
    private void OTPPwd()
    {
        string oTP = Convert.ToString(DateTime.Now.Second + 70096 + DateTime.Now.Minute);
        ViewState["currentOtp"] = oTP;

        SendSMS("Your OTP is: " + oTP + " ,Use these 5 digit's code to view the report.");

    }
    #endregion
    #region TO Check IP whether access from outside from office or not
    private Boolean IPCheck()
    {
        #region IPCheck
        string IP = GetUserIp();//"178.1.2.63";
        if (IP != "")
        {
            string[] ip_addrs = IP.Split('.');
            if (ip_addrs.Length == 4)
            {
                string currentPageName = System.IO.Path.GetFileName(Request.Url.AbsolutePath);
                con = new SqlConnection(strCon);
                con.Open();
                string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on,Email_ID,Page_Name)VALUES( '" + IP + "','" + DateTime.Now + "','" + Session["EMailID"].ToString() + "','" + currentPageName + "')";
                com = new SqlCommand(cInsert, con);
                com.ExecuteNonQuery();
                con.Close();


                if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
        #endregion
    }
    #endregion

    #region For Sending Alert on SMS
    public void SendSMS(string fmessage)
    {
        try
        {

            int Status = 0;
            string StatusMessage = "";
            string str = "";
            string pushURL = "http://www.myvaluefirst.com/smpp/sendsms?username=cargoflash&password=cargohtp&to=@mobileno&from=Cargoflash&text=@message";
            pushURL = pushURL.Replace("@message", fmessage);
            pushURL = pushURL.Replace("@mobileno", GetMobileNo());
            // Get HTML data
            WebClient client = new WebClient();
            Stream data = client.OpenRead(pushURL);
            StreamReader reader = new StreamReader(data);
            str = reader.ReadToEnd();
            data.Close();
            if (str.StartsWith("0,"))
                Status = 0;
            else
                Status = 1;
            StatusMessage = str;
            str = StatusMessage.Substring(StatusMessage.IndexOf("Sent") + "Sent".Length + 1).Trim();
        }
        catch (Exception ee)
        {

        }
    }
    #endregion
    private string GetMobileNo()
    {
        string mobileNo = "";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("SELECT Mobile FROM dbo.User_Master WHERE Email='" + Convert.ToString(Session["EMailID"]) + "'", con);
            mobileNo = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
        return mobileNo;
    }
}

