using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Booking_EnquiryDetails : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if(!IsPostBack)
        {            
                htmlUnactive();
        }
    }

    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        dr.Close();
        return Access;
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
    }
    public void htmlUnactive()
    {
        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.
                com = new SqlCommand("SELECT BE.Booking_EnquiryNo as Booking_EnquiryNo,BE.awb_no as awb_no,Be.ccremarks as ccremarks,Ag.Agent_name as Agent_name,AB.Agent_Phone as Agent_phone,BE.Requested_by as Agent_Email,AD.Belongs_to_city as Belongs_to_city,BE.Airline_Detail_Id as Airline_Detail_Id,AM.Airline_name as Airline_name,BE.Dest_code as dest_code,BE.Gross_Weight as Gross_Weight,BE.Volume_Weight,BE.No_of_Packages as No_of_Packages,BE.Commodity as Commodity,convert(varchar,BE.Handover_date,103) as Handover_date,BE.Remarks as Remarks FROM Booking_Enquiry BE Inner join Airline_Detail AD on AD.Airline_detail_id=BE.Airline_Detail_ID inner join Airline_Master AM on Am.Airline_ID=AD.Airline_ID inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join Agent_branch AB on AB.Agent_ID=AG.Agent_ID and ab.belongs_to_city=be.city  where BE.status='U' and AD.Airline_Detail_Id = '" + drx[0].ToString() + "' and AB.Belongs_to_city='" + drx[1].ToString() + "'", con);
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""12"" class=""h1"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h5 boldtext""><td  align=""center"">Update</td><td  align=""center"" nowrap>Agent Name</td><td  align=""center"" nowrap>Phone</td><td  align=""center"">Email</td><td  align=""center""nowrap>DestCode</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Vol Wt.</td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Commodity</td><td  align=""center"" nowrap>HandDate</td><td  align=""center"">Agent Remarks</td></tr></th>";
                    while (dr1.Read())
                    {
                        table += @"<tr><td><a style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px; font-weight:bold;' href='Booking_EnquiryCust.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "'>Update</a></td><td align=left class=text nowrap><a bgcolor=#004040 target=blank onclick=window.open('Booking_enquiryAdd.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "',this.target,'height=200px,width=700px'); return false'>" + dr1["Agent_name"].ToString() + "</a></td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_Phone"].ToString() + @"</td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_email"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Dest_code"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Gross_Weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Volume_weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["No_of_Packages"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["commodity"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Handover_date"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Remarks"].ToString() + @"</td></tr>";
                    }
                }
                else
                {

                    //table += @"<tr><td align=""center"" colspan=""11""></td></tr>";
                }


                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label2.Text = table;

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public void htmlIssued()
    {
        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.
                com = new SqlCommand("SELECT BE.Booking_EnquiryNo as Booking_EnquiryNo,BE.awb_no as awb_no,Be.ccremarks as ccremarks,Ag.Agent_name as Agent_name,AB.Agent_Phone as Agent_phone,BE.Requested_by as Agent_Email,AD.Belongs_to_city as Belongs_to_city,BE.Airline_Detail_Id as Airline_Detail_Id,AM.Airline_name as Airline_name,BE.Dest_code as dest_code,BE.Gross_Weight as Gross_Weight,BE.Volume_Weight,BE.No_of_Packages as No_of_Packages,BE.Commodity as Commodity,convert(varchar,BE.Handover_date,103) as Handover_date,BE.Remarks as Remarks FROM Booking_Enquiry BE Inner join Airline_Detail AD on AD.Airline_detail_id=BE.Airline_Detail_ID inner join Airline_Master AM on Am.Airline_ID=AD.Airline_ID inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join Agent_branch AB on AB.Agent_ID=AG.Agent_ID and ab.belongs_to_city=be.city  where BE.status='I' and AD.Airline_Detail_Id = '" + drx[0].ToString() + "' and AB.Belongs_to_city='" + drx[1].ToString() + "'", con);
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""10"" class=""h1"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h5 boldtext""><td align=""center"">Confirmed Booking</td><td align=""center"">Cancelled AWB</td><td  align=""center"" nowrap>Agent Name</td><td  align=""center"" nowrap>Phone</td><td  align=""center"">Email</td><td  align=""center"" nowrap>AWBNo</td><td  align=""center""nowrap>DestCode</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Vol Wt.</td><td  align=""center"" nowrap>Pcs.</td></tr></th>";
                    while (dr1.Read())
                    {
                        table += @"<tr><td><a style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px; font-weight:bold;' href='booking_Agent.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "'><img src='images/Add.gif'></a></td><td><a target=blank onclick=window.open('Bookingenquiry_Awbcancell.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "',this.target,'height=200px,width=700px'); return false'><img src='images/cross.gif'></a></td><td align=left class=text nowrap><a target=blank onclick=window.open('Booking_enquiryAdd.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "',this.target,'height=200px,width=700px'); return false'>" + dr1["Agent_name"].ToString() + "</a></td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_Phone"].ToString() + @"</td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_email"].ToString() + @"</td><td align=left class=text nowrap>&nbsp;" + dr1["Awb_No"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Dest_code"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Gross_Weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Volume_weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["No_of_Packages"].ToString() + @"</td></tr>";
                    }
                }
                else
                {

                    //table += @"<tr><td align=""center"" colspan=""11""></td></tr>";
                }


                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label2.Text = table;

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public void htmlAccepted()
    {
        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.
                com = new SqlCommand("SELECT BE.Booking_EnquiryNo as Booking_EnquiryNo,BE.awb_no as awb_no,Be.ccremarks as ccremarks,Ag.Agent_name as Agent_name,AB.Agent_Phone as Agent_phone,BE.Requested_by as Agent_Email,AD.Belongs_to_city as Belongs_to_city,BE.Airline_Detail_Id as Airline_Detail_Id,AM.Airline_name as Airline_name,BE.Dest_code as dest_code,BE.Gross_Weight as Gross_Weight,BE.Volume_Weight,BE.No_of_Packages as No_of_Packages,BE.Commodity as Commodity,convert(varchar,BE.Handover_date,103) as Handover_date,BE.Remarks as Remarks FROM Booking_Enquiry BE Inner join Airline_Detail AD on AD.Airline_detail_id=BE.Airline_Detail_ID inner join Airline_Master AM on Am.Airline_ID=AD.Airline_ID inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join Agent_branch AB on AB.Agent_ID=AG.Agent_ID and ab.belongs_to_city=be.city  where BE.status='B' and AD.Airline_Detail_Id = '" + drx[0].ToString() + "' and AB.Belongs_to_city='" + drx[1].ToString() + "'", con);
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""14"" class=""h1"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h5 boldtext""><td  align=""center"" nowrap>Agent Name</td><td  align=""center"" nowrap>Phone</td><td  align=""center"">Email</td><td  align=""center"" nowrap>AWBNo</td><td  align=""center""nowrap>DestCode</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Vol Wt.</td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Commodity</td><td  align=""center"" nowrap>HandDate</td><td  align=""center"">Agent Remarks</td><td  align=""center"" nowrap>CC Remarks</td></tr></th>";
                    while (dr1.Read())
                    {
                        table += @"<tr><td align=left class=text nowrap><a target=blank onclick=window.open('Booking_enquiryAdd.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "',this.target,'height=200px,width=700px'); return false'>" + dr1["Agent_name"].ToString() + "</a></td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_Phone"].ToString() + @"</td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_email"].ToString() + @"</td><td align=left class=text nowrap>&nbsp;" + dr1["Awb_No"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Dest_code"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Gross_Weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Volume_weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["No_of_Packages"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["commodity"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Handover_date"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Remarks"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["ccremarks"].ToString() + @"</td></tr>";
                    }
                }
                else
                {

                    //table += @"<tr><td align=""center"" colspan=""11""></td></tr>";
                }


                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label2.Text = table;

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public void htmlCancel()
    {
        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.
                com = new SqlCommand("SELECT BE.Booking_EnquiryNo as Booking_EnquiryNo,BE.awb_no as awb_no,Be.ccremarks as ccremarks,Ag.Agent_name as Agent_name,AB.Agent_Phone as Agent_phone,BE.Requested_by as Agent_Email,AD.Belongs_to_city as Belongs_to_city,BE.Airline_Detail_Id as Airline_Detail_Id,AM.Airline_name as Airline_name,BE.Dest_code as dest_code,BE.Gross_Weight as Gross_Weight,BE.Volume_Weight,BE.No_of_Packages as No_of_Packages,BE.Commodity as Commodity,convert(varchar,BE.Handover_date,103) as Handover_date,BE.Remarks as Remarks FROM Booking_Enquiry BE Inner join Airline_Detail AD on AD.Airline_detail_id=BE.Airline_Detail_ID inner join Airline_Master AM on Am.Airline_ID=AD.Airline_ID inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join Agent_branch AB on AB.Agent_ID=AG.Agent_ID and ab.belongs_to_city=be.city  where BE.status='C' and AD.Airline_Detail_Id = '" + drx[0].ToString() + "' and AB.Belongs_to_city='" + drx[1].ToString() + "'", con);
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""14"" class=""h1"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h5 boldtext""><td  align=""center"" nowrap>Agent Name</td><td  align=""center"" nowrap>Phone</td><td  align=""center"">Email</td><td  align=""center"" nowrap>AWBNo</td><td  align=""center""nowrap>DestCode</td><td  align=""center"" nowrap>Gwt.</td><td  align=""center"" nowrap>Vol Wt.</td><td  align=""center"" nowrap>Pcs.</td><td  align=""center"" nowrap>Commodity</td><td  align=""center"" nowrap>HandDate</td><td  align=""center"">Agent Remarks</td><td  align=""center"" nowrap>CC Remarks</td><td  align=""center"">Update</td></tr></th>";
                    while (dr1.Read())
                    {
                        table += @"<tr><td align=left class=text nowrap><a target=blank bgcolor=#000055  onclick=window.open('Booking_enquiryAdd.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "',this.target,'height=200px,width=700px'); return false'>" + dr1["Agent_name"].ToString() + "</a></td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_Phone"].ToString() + @"</td><td align=left class=text nowrap>&nbsp;" + dr1["Agent_email"].ToString() + @"</td><td align=left class=text nowrap>&nbsp;" + dr1["Awb_No"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Dest_code"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Gross_Weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Volume_weight"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["No_of_Packages"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["commodity"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Handover_date"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Remarks"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["ccremarks"].ToString() + @"</td><td><a style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px; font-weight:bold;' href='Booking_EnquiryCust.aspx?sno=" + dr1["Booking_EnquiryNo"].ToString() + "'>Update</a></td></tr>";
                    }
                }
                else
                {

                    //table += @"<tr><td align=""center"" colspan=""11""></td></tr>";
                }


                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label2.Text = table;

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    protected void Modify(object sender, CommandEventArgs e)
    {

    }
    protected void lnkunactive_Click(object sender, EventArgs e)
    {
        htmlUnactive();
    }
    protected void lnkBookingAccepted_Click(object sender, EventArgs e)
    {
        htmlAccepted();
    }
    protected void lnkBookingCan_Click(object sender, EventArgs e)
    {
        htmlCancel();
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        htmlIssued();  
    }
}
