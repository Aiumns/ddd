using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CCShipmentDetails : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    DataTable dt;
    SqlDataReader dr = null;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                ShowAirline();
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");

                txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
                txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");

            }

        }

    }
    protected void ShowAirline()
    {

        ddlAirlineCode.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'('+A.Airline_Code+')/'+B.city_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineCode.Items.Add("All Assigned Airlines");
            ddlAirlineCode.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAirlineCode.Items.Add(new ListItem(dr["airline"].ToString(), Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"])));

            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string date_from = txtValidFrom.Text;
        string date_to = txtValidTo.Text;
        //string Month = ddlMonth.SelectedItem.Value;
        //string Year = ddlyear.SelectedItem.Text;
        //string FortNight = "";
        Session["airline_d_id"] = ddlAirlineCode.SelectedItem.Value;
        //if (rbtnFirstFortn.Checked)
        //{
        //    FortNight = "1";
        //}
        //if (rbtnSecondFortN.Checked)
        //{
        //    FortNight = "2";
        //}
        string URL_ = "CCShipmentDetails_Show.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("date_from", date_from), new Pair("date_to", date_to));
        ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open( '" + URL_ + "');</script>");

    }
}
