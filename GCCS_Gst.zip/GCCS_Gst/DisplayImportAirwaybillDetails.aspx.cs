using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class DisplayImportAirwaybillDetails : System.Web.UI.Page
{
    // --- Declare Public Variables here ---
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string Table = "";
    string table1 = "";
    /// <summary>
    /// Make Connection From Web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            showRecord();
            htmlTableSimple();
        }
    }
    public void htmlTableSimple()
    {
       
        string from_date = Request.QueryString["from"];
        string to_date = Request.QueryString["to"];
      
        try
        {
            int Sno = 0;

            int ip = 0;
            int pcs=0;
            string Gross_Weight = "";
            string Hawb = "";
            decimal Total_Hawb = 0;
            string DO_Amount = "";
            decimal Total_DO_Amount = 0;
            decimal Total_Gross_Weight = 0;

            // Table header create

            Table += @"<h5><p align=center>AWB Details</p></h5>";
           
            Table += @"<Table align=center width=80% border=1 cellspacing=0>";

            con = new SqlConnection(strCon);
            con.Open();



            com = new SqlCommand("Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,case when part_pcs > 0 then part_pcs+'/'+pcs else isnull(pcs,0) end as No_0fpcs,case when part_pcs > 0 then part_pcs else isnull(pcs,0) end as PcsTotal from Import_Flight_AWB where import_flight_id=" + Request.QueryString["Import_Flight_ID"] + "AND status not in ('DO Generated','Void')", con);

            if (Session["Airline_detail_Id"].ToString() == "151" || Session["Airline_detail_Id"].ToString() == "157" || Session["Airline_detail_Id"].ToString() == "161" || Session["Airline_detail_Id"].ToString() == "165" || Session["Airline_detail_Id"].ToString() == "158" || Session["Airline_detail_Id"].ToString() == "159" || Session["Airline_detail_Id"].ToString() == "160")
            {
                Table += @"<tr class=h1 align=left><th>Sno</th><th>Awb No.</th><th>Pcs</th><th>Gross wt.</th><th>Origin</th><th>Dest</th><th nowrap=true>Frt Type</th><th>Commodity</th><th nowrap=true>HAWB</th><th>Consignee</th><th>Notify</th></tr>";
            }
            else
            {
                Table += @"<tr class=h1 align=left><th>Sno</th><th>Awb No.</th><th>Pcs</th><th>Gross wt.</th><th>Origin</th><th>Dest</th><th nowrap=true>Frt Type</th><th>Commodity</th><th nowrap=true>HAWB</th><th>Consignee</th><th nowrap=true>DO Amt.</th><th>Notify</th></tr>";
            }
            SqlDataReader dr1 = com.ExecuteReader();


            if (dr1.HasRows)
            {


                while (dr1.Read())
                {
                    ip = ip + 1;
                    DataTable DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + "");
                    decimal Allvalue = 0;
                    decimal total = 0;
                    if (DtImportChargesHeads.Rows.Count > 0)
                    {
                        int i;
                        for (i = 0; i < DtImportChargesHeads.Rows.Count; i++)
                        {
                            if (DtImportChargesHeads.Rows[i]["ForEach"].ToString() == "Y")
                            {
                                Allvalue = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) * decimal.Parse(dr1["No_of_Houses"].ToString());
                            }
                            else
                            {
                                Allvalue = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                            }
                            total += Allvalue;
                        }
                    }


                    //******Added on 24 feb 2011 logic: If part_Shipment OR Duble Awb exixt in import_Fight_Awb Table then DO Amount of 2nd Awb is Zero(becoz payment has alreday been collected on first Reciept No of Ist AwbNo)******
                    DataTable dtAwbexist = dw.GetAllFromQuery("select import_awb_no ,import_awb_id,D0_Generate_Status,Import_flight_id from import_flight_awb where import_awb_no='" + dr1["import_awb_no"].ToString() + "'");
                    //if (dtAwbexist.Rows.Count > 1)
                    //{
                    //    for (int b = 0; b < dtAwbexist.Rows.Count; b++)
                    //    {
                    //        if (dtAwbexist.Rows[b]["D0_Generate_Status"].ToString() != "YES")
                    //        {
                    //            if (dtAwbexist.Rows[b]["Import_flight_id"].ToString() == Request.QueryString["Import_Flight_ID"])
                    //            {
                    //                total = 0;
                    //            }

                    //        }
                    //    }
                    //}
                    //*************END*************************

                    //****************Added on 24 feb 2011: IN Case Of  FOC Shipment: DO  Amount=0**************
                    if (dr1["shipment_type"].ToString() == "F")
                    {
                        total = 0;
                    }
                    //*************END*************************








                    if (Session["Airline_detail_Id"].ToString() == "151" || Session["Airline_detail_Id"].ToString() == "157" || Session["Airline_detail_Id"].ToString() == "161" || Session["Airline_detail_Id"].ToString() == "165" || Session["Airline_detail_Id"].ToString() == "158" || Session["Airline_detail_Id"].ToString() == "159" || Session["Airline_detail_Id"].ToString() == "160")
                    {
                        Table += @"<tr><td align=left class=text nowrap=true>&nbsp;" + ip + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["import_awb_no"].ToString() + @"</td><td align=right class=text nowrap=true>&nbsp;" + dr1["No_0fpcs"].ToString() + @"</td><td align=right class=text nowrap=true>" + dr1["Gross_Weight"].ToString() + @"</td><td align=left class=text>&nbsp;" + dr1["Origin"].ToString() + @"</td><td align=left class=text>&nbsp;" + dr1["Destination"].ToString() + @"</td><td align=left class=text nowrap=true>" + dr1["Freight_Type"].ToString() + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["Commodity"].ToString() + @"</td><td align=center class=text nowrap=true>&nbsp;" + dr1["No_of_Houses"].ToString() + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["Agent_Name"].ToString() + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["notify"].ToString() + @"</td></tr>";
                    }
                    else
                    {
                        Table += @"<tr><td align=left class=text nowrap=true>&nbsp;" + ip + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["import_awb_no"].ToString() + @"</td><td align=right class=text nowrap=true>&nbsp;" + dr1["No_0fpcs"].ToString() + @"</td><td align=right class=text nowrap=true>" + dr1["Gross_Weight"].ToString() + @"</td><td align=left class=text>&nbsp;" + dr1["Origin"].ToString() + @"</td><td align=left class=text>&nbsp;" + dr1["Destination"].ToString() + @"</td><td align=left class=text nowrap=true>" + dr1["Freight_Type"].ToString() + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["Commodity"].ToString() + @"</td><td align=center class=text nowrap=true>&nbsp;" + dr1["No_of_Houses"].ToString() + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["Agent_Name"].ToString() + @"</td><td align=right class=text nowrap=true>&nbsp;" + total.ToString() + @"</td><td align=left class=text nowrap=true>&nbsp;" + dr1["notify"].ToString() + @"</td></tr>";
                    }
                    Hawb = dr1["No_of_Houses"].ToString();
                    Total_Hawb = Total_Hawb + (decimal.Parse(Hawb));
                    DO_Amount = total.ToString();
                    Total_DO_Amount = Total_DO_Amount + (decimal.Parse(DO_Amount));
                    Gross_Weight = dr1["Gross_Weight"].ToString();
                    Total_Gross_Weight = Total_Gross_Weight + (decimal.Parse(Gross_Weight));

                    pcs += int.Parse(dr1["PcsTotal"].ToString());
                    Sno = Sno + 1;

                }
                Table += @"<tr class=h1>";

                Table += @"<td align=center><b>"+Sno+"</b></td>";
               
                Table += @"<td  align=center><b>&nbsp;Total</b></td>";
                Table += @"<td  align=right><b>" + pcs + "</b></td>";
                Table += @"<td align=right><b>&nbsp;" + Convert.ToDecimal(Total_Gross_Weight).ToString("#,##0.00") + "</b></td>";
                Table += @"<td colspan=4 align=right><b>&nbsp;</b></td>";
                Table += @"<td  align=center><b>&nbsp;" + Total_Hawb + "</b></td>";
                Table += @"<td  align=right><b>&nbsp;</b></td>";
                if (Session["Airline_detail_Id"].ToString() == "151" || Session["Airline_detail_Id"].ToString() == "157" || Session["Airline_detail_Id"].ToString() == "161" || Session["Airline_detail_Id"].ToString() == "165" || Session["Airline_detail_Id"].ToString() == "158" || Session["Airline_detail_Id"].ToString() == "159" || Session["Airline_detail_Id"].ToString() == "160")
                {
                   
                }
                else
                {
                    Table += @"<td align=right><b>&nbsp;" + Convert.ToDecimal(Total_DO_Amount).ToString("#,##0.00") + "</b></td>";
                }
                Table += @"<td align=right><b>&nbsp;</td>";

                Table += @"</tr></Table>";
                Label1.Text = Table;


            }

            else
            {
                Table += @"<Table align=center width=80% border=1><tr>&nbsp;<center><span class=error><b>No Record Found</b></span></center></tr></Table>";
                Label1.Text = Table;
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
    public void showRecord()
    {
        decimal Import_Flight_ID = Convert.ToDecimal(Request["Import_Flight_ID"].ToString().Trim());
        Session["FltID"] = Import_Flight_ID.ToString();
        DataTable Detail_Flight = dw.GetAllFromQuery("select Airline_Detail_ID,Import_Flight_No,convert(varchar,Import_Flight_Date,103) as Import_Flight_Date ,IGM_No,Flight_Status_Check,Reg_No,_Action from Import_Flights where Import_Flight_ID='" + Request.QueryString["Import_Flight_ID"] + "'");
        table1 += @"<h5><p align=center>Flight Details</p></h5>";
        table1 += @"<table width=80% align=center border=1><tr><td align=center class=h5 colspan=6><h4>Import AWB </h4></td></tr><tr><td class=boldtext >Flight No</td><td class=text>" + Detail_Flight.Rows[0]["Import_Flight_No"].ToString() + "</td><td class=boldtext >Date</td><td class=text >" + Detail_Flight.Rows[0]["Import_Flight_Date"].ToString() + "</td><td class=boldtext >I.G.M </td><td class=text >" + Detail_Flight.Rows[0]["IGM_No"].ToString() + "</td></tr><tr><td class=boldtext >Reg No</td><td class=text>&nbsp;" + Detail_Flight.Rows[0]["Reg_No"].ToString() + "</td></td><td class=boldtext >Flight Check Status</td><td class=text>&nbsp;" + Detail_Flight.Rows[0]["Flight_Status_Check"].ToString() + "</td><td class=boldtext >Actions</td><td class=text>&nbsp;" + Detail_Flight.Rows[0]["_Action"].ToString() + "</td></tr></table>";

        lblshow.Text = table1;

    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
