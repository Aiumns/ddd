using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Add_Import_Agents : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    string Import_Agent_ID;
    SqlTransaction trans = null;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
        
            if (!IsPostBack && Request.QueryString["import_Agent_ID"] != null)
            {
                FillCity();
                lbladd.Visible = false;
                lblupdate.Visible = true;
                btnupdate.Visible = true;
                btnAdd.Visible = false;
                btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                Import_Agent_ID = Convert.ToString(Request.QueryString["import_Agent_ID"]);
                string str1 = "select Import_Agent_Name,Import_credit_limit,City_Code,Import_Agent_City,Import_Agent_Email,Agent_Contactno,Agent_Phone,Agent_Address from Import_Agent_Master IM inner join City_master CM on  IM.Import_Agent_City=CM.City_ID where Import_Agent_ID='" + Import_Agent_ID + "' order by Import_Agent_Name";
                con = new SqlConnection(strCon);
                con.Open();

                com = new SqlCommand(str1, con);
                SqlDataReader dr = com.ExecuteReader();
                dr.Read();

                txtagname.Text = dr["Import_Agent_Name"].ToString();
               
                ddlcity.SelectedIndex = ddlcity.Items.IndexOf(ddlcity.Items.FindByValue(dr["Import_Agent_City"].ToString()));
                txtemail.Text = dr["Import_Agent_Email"].ToString();
                txtaddress.Text = dr["Agent_Address"].ToString();
                  txtmobno.Text= dr["Agent_Contactno"].ToString();
                  txtphoneno.Text = dr["Agent_Phone"].ToString();
                txtCreditLimit.Text = dr["Import_credit_limit"].ToString();
                con.Close();

            }
            else if (!IsPostBack)
            {
                FillCity();
                btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
                lbladd.Visible = true;
                lblupdate.Visible = false;
                btnupdate.Visible = false;
                btnAdd.Visible = true;

            }
        }

    }

    public void FillCity()
    {
 
        con = new SqlConnection(strCon);
        com = new SqlCommand("select City_code ,City_Name,city_id from city_master ", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        ddlcity.DataSource = dr;
        ddlcity.DataTextField = "City_code";
        ddlcity.DataValueField = "city_id";
        ddlcity.DataBind();
        con.Close();
        com.Dispose();
        ddlcity.Items.Insert(0, new ListItem("Select City", "-1"));
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_Import_Agents.aspx");
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        
        con = new SqlConnection(strCon);
        string stradd = "";
        try
        {
            stradd = "select * from Import_Agent_master where Import_Agent_Name='" +txtagname.Text.Trim()+ "'";
            con.Open();
            da = new SqlDataAdapter(stradd, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblError.Visible = true;
                lblError.Text = " Records already exists.";
            }
            else
            {
                string stradd1 = "insert into  Import_Agent_master(Import_Agent_Name,Import_agent_city,import_agent_email,import_credit_limit,Agent_address,agent_phone,Agent_Contactno,Entered_By,Entered_On) values('" + txtagname.Text.Trim() + "','" + ddlcity.SelectedItem.Value + "','" + txtemail.Text + "','" + txtCreditLimit.Text.Trim() + "','" + txtaddress.Text.Trim() + "','" + txtphoneno.Text.Trim() + "','" + txtmobno.Text.Trim() + "','" + Session["EMailID"].ToString() + "','" + DateTime.Now + "')";
                con.Open();
                com = new SqlCommand(stradd1, con);
                com.ExecuteNonQuery();
                com.Dispose();
                con.Close();
                Response.Redirect("View_Import_Agents.aspx");

            }

        }

        catch (SqlException err)
        {
            string msg = err.ToString();

        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        string strupdate = "";
        try
        {
            strupdate = "select * from Import_Agent_master where Import_Agent_Name='" + txtagname.Text.Trim() + "'";
            con.Open();
            da = new SqlDataAdapter(strupdate, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count <= 1)
            {

                try
                {
                    con.Open();
                    string strupdate1 = "update Import_Agent_Master  set Import_Agent_Name='" + txtagname.Text.Trim() + "',Import_agent_city='" + ddlcity.SelectedItem.Value + "',import_agent_email='" + txtemail.Text.Trim() + "',import_credit_limit='" + txtCreditLimit.Text + "',Agent_address='" + txtaddress.Text.Trim() + "',agent_phone='" + txtphoneno.Text.Trim() + "',agent_contactno='" + txtmobno.Text.Trim() + "',Last_Modified_By='" + Session["EMailID"].ToString() + "',Last_Modified_On='" + DateTime.Now + "' where Import_Agent_ID='" + Convert.ToString(Request.QueryString["Import_Agent_ID"]) + "'";
                    com = new SqlCommand(strupdate1, con);
                    com.ExecuteNonQuery();
                    con.Close();
                    Response.Redirect("View_Import_Agents.aspx");
                }
                catch (SqlException se)
                {
                    string err = se.Message;
                    lblError.Text = err;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            else
            {

                lblError.Text = " Record already exists.";
                btnAdd.Visible = false;
                btnupdate.Visible = true;
            }

        }

        catch (SqlException err)
        {
            string msg = err.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
                con.Close();
        }

    }
}
