using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AddSms_Deatails : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    SqlTransaction tr = null;
    DisplayWrap dw = new DisplayWrap();
    string tt;
    string mm;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnAdd.Visible = true;
            if (!IsPostBack)
            {
                btnAdd.Attributes.Add("onclick", "return CheckEmpty() ");
                ShowData();
                ddlairline();
                ddlgtype();
                fillstatus();
                btnCancel.Visible = false;
                btnUpdate.Visible = false;


            }
        

        }

    }
    public void ddlgtype()
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand();
        com.CommandText = "select Group_Name,Group_ID from Group_Master order by Group_Name ";
        com.Connection = con;
        com.Connection.Open();
        ddlGrname.DataTextField = "Group_Name";
        ddlGrname.DataValueField = "Group_ID";

        SqlDataReader rdr = com.ExecuteReader();
        ddlGrname.DataSource = rdr;
        ddlGrname.DataBind();
        ddlGrname.Items.Insert(0, "- -Select- -");
        rdr.Close();
        com.Connection.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       //btnAdd.Attributes.Add("onclick", "return  CheckEmpty()");
        InsertData();
    }
    protected void InsertData()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
           
                com = new SqlCommand("select SmsID,NameOfPerson,GroupName,CellNo,Airline_Access from SMS_Master where NameOfPerson='"+txtNameofperson.Text+"' and GroupName='"+ddlGrname.SelectedItem.Text+"'",con);
                SqlDataReader dri = com.ExecuteReader();
                if (dri.Read())
                {
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                    lblMsg.Text = "User Already Exists";
                    dri.Close();
                }
else
                {
                    com = new SqlCommand("insert into SMS_Master(NameOfPerson,GroupName,CellNo,Airline_Access,Status) values(@NameOfPerson,@GroupName,@CellNo,@Airline_Access,@Status)", con);
                com.Parameters.Add("@NameOfPerson", SqlDbType.VarChar).Value = txtNameofperson.Text;
                com.Parameters.Add("@GroupName", SqlDbType.VarChar).Value = ddlGrname.SelectedItem.Text;
                com.Parameters.Add("@CellNo", SqlDbType.VarChar).Value = "+91"+txtmno.Text;
                foreach (int i in lstAirlineaccess.GetSelectedIndices())    // values store in listbox
                {
                    if (lstAirlineaccess.Items[i].Selected)
                    {
                        tt = lstAirlineaccess.Items[i].Value + ",";
                        mm = mm + tt;

                    }
                }
                mm = mm.Remove(mm.LastIndexOf(","));
                com.Parameters.Add("@Airline_Access", SqlDbType.VarChar).Value = mm;
                com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlstatus.SelectedItem.Value;
                dri.Close();
                com.ExecuteNonQuery();
                com.Dispose();              
                con.Close();
                lblMsg.ForeColor = System.Drawing.Color.Blue;
                lblMsg.Text = "User Added Successfully";
                ShowData();
            }


        }

        catch (SqlException se)
        {
            string err = se.Message;
            //Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            //Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void ShowData()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            SqlDataAdapter sda = new SqlDataAdapter("select smsID,NameofPerson,GroupName,cellno,Airline_access from sms_master", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            grdsms.DataSource = dt;
            grdsms.DataBind();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
            //Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            //Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnDelete_ExchaneRate(object sender, EventArgs e)
    {

        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblID = (Label)grdRow.FindControl("lblID");

        try
        {
            SqlConnection con1 = new SqlConnection(strCon);
            con1.Open();

            SqlCommand com1 = new SqlCommand("select smsID,NameofPerson,GroupName,cellno,Airline_access,status from sms_master where smsID=" + lblID.Text.Trim() + " ", con1);
            dr = com1.ExecuteReader();
            if (dr.Read())
            {
                con = new SqlConnection(strCon);
                con.Open();
                tr = con.BeginTransaction();

                com = new SqlCommand("insert into Sms_History(smsID,NameOfPerson,GroupName,CellNo,Airline_Access,status) values(@smsID,@NameOfPerson,@GroupName,@CellNo,@Airline_Access,@status) ", con, tr);
                com.Parameters.Add("@smsID", SqlDbType.Int).Value = int.Parse(dr["smsID"].ToString());
                com.Parameters.Add("@NameOfPerson", SqlDbType.VarChar).Value = dr["NameOfPerson"].ToString();
                com.Parameters.Add("@GroupName", SqlDbType.VarChar).Value = dr["GroupName"].ToString();
                com.Parameters.Add("@CellNo", SqlDbType.BigInt).Value = dr["CellNo"].ToString();
                com.Parameters.Add("@Airline_Access", SqlDbType.VarChar).Value = dr["Airline_access"].ToString();
                com.Parameters.Add("@Status", SqlDbType.Int).Value = dr["status"].ToString();
                com.ExecuteNonQuery();

                com.Dispose();

                com = new SqlCommand("delete from SMS_Master where smsID=" + lblID.Text.Trim() + " ", con, tr);
                com.ExecuteNonQuery();
                tr.Commit();
                dr.Close();
                con.Close();
            }
            con1.Close();

            ShowData();

        }
        catch (SqlException se)
        {
            string err = se.Message;
            tr.Rollback();
            //Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            tr.Rollback();
            //Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }



    }

    protected void OnClick_btnModify(object sender, EventArgs e)
    {
        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblID = (Label)grdRow.FindControl("lblID");
        con = new SqlConnection(strCon);
          con.Open();
        try
        {
            com = new SqlCommand("select Group_ID,smsID,NameOfPerson,CellNo,Airline_Access,status from SMS_Master inner join group_master on group_master.group_name=sms_master.groupname where smsID=" + lblID.Text.Trim() + " ", con);
            dr = com.ExecuteReader();
            if (dr.Read())
            {
                ddlGrname.SelectedValue = dr["Group_ID"].ToString();
                ddlstatus.SelectedItem.Value = dr["status"].ToString();
                txtNameofperson.Text = dr["NameOfPerson"].ToString();
                txtmno.Text = dr["CellNo"].ToString().Substring(3, 10);
                HiddenField1.Value = dr["smsID"].ToString();
                hdnperson.Value = dr["NameOfPerson"].ToString();
                hdnmob.Value = dr["CellNo"].ToString();
                string strAirlineAccess = dr["Airline_Access"].ToString();
                string[] arrAirline = strAirlineAccess.Split(new char[] { ',' });


                for (int j = 0; j < arrAirline.Length; j++)
                {
                    for (int i = 0; i <= (lstAirlineaccess.Items.Count - 1); i++)
                    {
                        if (lstAirlineaccess.Items[i].Value == arrAirline[j])
                        {
                            lstAirlineaccess.Items[i].Selected = true;
                        }
                    }
                }
           

            }
            dr.Close();
            con.Close();
            Button btn = (Button)grdRow.FindControl("btnModify");
            grdsms.Columns[5].Visible = false;
            grdsms.Columns[6].Visible = false;
            btnAdd.Visible = false;
            btnUpdate.Visible = true;
            btnCancel.Visible = true;

        }
        catch (SqlException se)
        {
            string err = se.Message;
            //Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            //Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    private void fillstatus()
    {
        con = new SqlConnection(strCon);
        try
        {
            string strQuery = "";
            strQuery = " select * from Status_Master where Status_Name in ('Active','Inactive')";
            con.Open();
            com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlstatus.Items.Clear();
            while (dr.Read())
            {

                ddlstatus.Items.Add(new ListItem(dr["Status_Name"].ToString(), dr["Status_ID"].ToString()));


            }
            con.Close();
            dr.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    public void ddlairline()
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand();
        com.CommandText = "select cm.City_Code + ',' + space(2) + am.airline_name + '-'+ am.airline_code as code, ad.airline_detail_id  from airline_master as am inner join airline_detail as ad on am.airline_id=ad.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City";
        com.Connection = con;
        com.Connection.Open();
        lstAirlineaccess.DataTextField = "code";
        lstAirlineaccess.DataValueField = "airline_detail_id";
        SqlDataReader rdr = com.ExecuteReader();
        lstAirlineaccess.DataSource = rdr;
        lstAirlineaccess.DataBind();
        //ListBox2.Items.Insert(0, "Select Airline");
        rdr.Close();
        com.Connection.Close();



    }

    protected void gvExchangeRate_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button db = (Button)e.Row.Cells[6].FindControl("btnDelete");
            db.OnClientClick = string.Format("javascript: return confirm('Are you certain, you want to delete ?');");
            Label lblAccess = (Label)e.Row.Cells[4].FindControl("Label2");
            string Airline_Access = lblAccess.Text;

            string[] a = Airline_Access.Split(',');
            string str = string.Empty;

            for (int i = 0; i < a.Length; i++)
            {   // CREATING DATATABLE FOR Airline Name From Airline Master
                DataTable dtAccess = dw.GetAllFromQuery("select am.Airline_Code,am.Airline_Name,am.Airline_text_code,ad.Airline_detail_ID,cm.city_code from airline_master am  inner join airline_detail ad on am.airline_id=ad.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City where Airline_detail_ID=" + a.GetValue(i).ToString() + " order by cm.city_code desc");
                if (dtAccess.Rows.Count > 0)
                {
                    // STRING CONCATENATION

                    str = str + dtAccess.Rows[0]["Airline_text_code"].ToString().Trim() + "- " + dtAccess.Rows[0]["city_code"].ToString().Trim() + ",&nbsp&nbsp</hr>";
                }


            }
            str = str.Remove(str.LastIndexOf(","));
            e.Row.Cells[4].Text = str;




        }

    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddSms_Deatails.aspx");
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        btnAdd.Visible=false;
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            com = new SqlCommand("select SmsID,NameOfPerson,GroupName,CellNo,Airline_Access from SMS_Master where NameOfPerson='" + txtNameofperson.Text + "' and GroupName='" + ddlGrname.SelectedItem.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count>=1)
            {
                lblMsg.ForeColor = System.Drawing.Color.Red;
                lblMsg.Text = "User Already Exists";
                //dri.Close();
            }
            else
            {
                com = new SqlCommand("update SMS_Master set NameOfPerson=@NameOfPerson,GroupName=@GroupName,CellNo=@CellNo,Airline_Access=@Airline_Access,status=@status where smsID=" + HiddenField1.Value + " ", con);
                com.Parameters.Add("@NameOfPerson", SqlDbType.VarChar).Value = txtNameofperson.Text;
                com.Parameters.Add("@GroupName", SqlDbType.VarChar).Value = ddlGrname.SelectedItem.Text;
                com.Parameters.Add("@CellNo", SqlDbType.VarChar).Value = txtmno.Text;
                foreach (int i in lstAirlineaccess.GetSelectedIndices())    // values store in listbox
                {
                    if (lstAirlineaccess.Items[i].Selected)
                    {
                        tt = lstAirlineaccess.Items[i].Value + ",";
                        mm = mm + tt;

                    }
                }
                mm = mm.Remove(mm.LastIndexOf(","));
                com.Parameters.Add("@Airline_Access", SqlDbType.VarChar).Value = mm;
                com.Parameters.Add("@status", SqlDbType.Int).Value = ddlstatus.SelectedItem.Value;
                com.ExecuteNonQuery();
                com.Dispose();


                con.Close();
                lblMsg.ForeColor = System.Drawing.Color.Blue;
                lblMsg.Text = "User modified Successfully";
                ShowData();
            }


        }

        catch (SqlException se)
        {
            string err = se.Message;
            //Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            //Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

        Response.Redirect("AddSms_Deatails.aspx");
    

    }
    protected void gvExchangeRate_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdsms.PageIndex = e.NewPageIndex;
        ShowData();


    }
}
