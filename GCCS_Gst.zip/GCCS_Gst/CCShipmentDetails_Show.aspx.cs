using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CCShipmentDetails_Show : System.Web.UI.Page
{
    string from_date;
    string to_date;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
       
        string[] airline_d_id = Session["airline_d_id"].ToString().Split(',');
        decimal Ch_wt = 0;
        decimal Total_Ch_wt = 0;


        from_date = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "date_from");
        to_date = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "date_to");
        Label1.Text = "<table width=100% cellpadding=1 cellspacing=1 align=center class=boldtext><tr align=center class=text><th><u>CCShipment Details</u></th></tr><tr><th><u>" + from_date + " - " + to_date + "</u></th></tr></table>";
        string Table1 = "";
        string Query = "";
        if (airline_d_id[0] == "0")
        {
            Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ") order by airline_name";
        }
        else
        {
            Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + airline_d_id[0].ToString() + ") order by airline_name";
        }

        Int32 count = 1;
        DataTable dt = dw.GetAllFromQuery(Query);
        foreach (DataRow drow in dt.Rows)
        {
            Table1 += "<table width=100% border=1 align=center cellpadding=0 cellspacing=0 class=text><tr class=h5><th colspan=10  align=center>" + drow["airline_code"].ToString() + "-" + drow["airline_name"].ToString() + "-" + drow["city_code"].ToString() + "</td></tr><tr class=h5><th  align=center>Agent Name</th><th  align=center>AWB No</th><th  align=center>AWB Date </td><th  align=center>Origin</th><th  align=center>Dstn</th><th align=center>Ch Wt</th><th  align=center>Flight Date </th><th  align=center>Flight No</th></tr>";
            Query = "select AM.Agent_Name as Agent_Name,SM.Airwaybill_No as Airwaybill_No,BM.Booking_Date as Bdate,convert(varchar,BM.Booking_Date,103) as Awb_Date,CM.City_Code as City_Code,DM.Destination_Code as  Destination_Code,BM.Charged_Weight as ch_wt,convert(varchar,BM.Flight_Date,103) as Flight_Date,FM.Flight_No as  Flight_No from Booking_Master BM inner join Stock_Master SM on BM.Stock_ID=SM.Stock_ID inner Join Agent_Master AM on AM.Agent_ID=BM.Agent_ID inner join City_Master CM on CM.City_ID=BM.City_ID inner join Destination_Master DM on DM.Destination_ID=BM.Destination_ID inner join  Flight_Open FO on FO.Flight_Open_ID=BM.FLight_Open_ID inner join Flight_Master FM on FM.FLight_ID=FO.Flight_ID where (bm.Status=9 or bm.Status=3) and FM.airline_detail_id=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + "  and BM.Booking_Date between '" + FormatDateDD(from_date) + "' and '" + FormatDateDD(to_date) + "' and BM.Freight_type='COLLECT' ORDER BY AM.AGENT_NAME";

            DataTable dt_cal = dw.GetAllFromQuery(Query);

            if (dt_cal.Rows.Count > 0)
            {

                foreach (DataRow dro in dt_cal.Rows)
                {
                    Ch_wt = Convert.ToDecimal(dro["Ch_wt"].ToString());
                    Total_Ch_wt = Total_Ch_wt + Ch_wt;

                    Table1 += "<tr class=text><td  align=left class=boldtext>" + dro["Agent_Name"].ToString() + "</td><td  align=left class=text>" + dro["Airwaybill_No"].ToString() + "</td><td  align=left class=text>" + dro["AWb_Date"].ToString() + "</td><td  align=left class=text>" + dro["City_Code"].ToString() + "</td><td  align=left class=text>" + dro["Destination_Code"].ToString() + "</td><td  align=right class=text>" + dro["Ch_wt"].ToString() + "</td><td  align=left class=text nowrap> " + dro["Flight_Date"].ToString() + " </td><td  align=left class=text>" + dro["Flight_No"].ToString() + "</td></tr>";


                }
            }
            else
            {
                Table1 += "<tr class=text><td  align=center colspan=8 class=error>NO RECORD FOUND FOR THIS AIRLINE</td></tr>";
            }
            Table1 += "<tr  class=h1><td  align=right colspan=5 class=boldtext>Total</td><td  align=right class=boldtext nowrap> " + Total_Ch_wt + " </td><td  align=left class=boldtext> </td><td  align=left class=boldtext> </td></tr>";
            Total_Ch_wt = 0;
            Table1 += "</table><br>";
        }
        Label2.Text += Table1;

    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateDD(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
