﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Browse_Manifest_FLight : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    DisplayWrap dw = new DisplayWrap();
    string table2 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                ShowAirline();
                FillDataGv();

            }
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        FillDataGv();

    }

    protected void FillDataGv()
    {
       
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            string AirlineDetailID = "";
            string AirlineDetailIDTem = "";
            com = new SqlCommand("Get_Manifest_Data", con);
            com.CommandType=CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID",SqlDbType.Int).Value=int.Parse(ddlAirlineCity.SelectedValue);
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {

                while (dr.Read())
                {
                    string ss = @"  ""  ";
                    //string status = dr["status_name"].ToString();
                    
                    
                    string finalise = @"<a id=""yy"" href=""CreateFInaliseMAnifest.aspx?fno=" + dr["Flight_No"].ToString() + "&city_id=" + dr["city_id"].ToString() + "&date=" + dr["FLIGHT_DATE"].ToString() + "&Airline_code=" + dr["Airline_code"].ToString() + "&fid=" + dr["Flight_Open_ID"].ToString() + "&AID=" + dr["Airline_Detail_ID"].ToString() + @""" class=""boldtext"" align=center class =""but"">Pre Manifest</a>";
                    string color = "";

                    AirlineDetailIDTem = dr["Airline_Detail_ID"].ToString();
                    if (AirlineDetailID == dr["Airline_Detail_ID"].ToString())
                    {

                        table2 += @"<tr " + color + @"><td nowrap>" + dr["Flight_No"].ToString() + @"</td><td align=center>" + dr["FLIGHT_DATE"].ToString() + @"</td><td align=center>" + dr["flight_time"].ToString() + @"</td><td align=center>" + dr["AIRWAYBILL_NO"].ToString() + @"</td><td>" + finalise + "</td> </tr>";
                    }
                    else
                    {
                        table2 += @"<table class=""text"" width=""100%"" align=""center"" border=""1"">";


                        table2 += @"<tr align=""center""><td colspan=""9""  class=""h1 boldtext"">" + dr["airlineName"].ToString() + @"</td><tr>";


                        table2 += @"<tr align=""center""><td nowrap class=""h1 boldtext"">Flt No </td><td class=""h1  boldtext"">Flt Date </td><td class=""h1 boldtext"">Flt Time</td><td class=""h1 boldtext"">Total Shipment</td><td class=""h1 boldtext"">Manifest Details</td></tr>";


                        table2 += @"<tr " + color + @"><td nowrap>" + dr["Flight_No"].ToString() + @"</td><td align=center>" + dr["FLIGHT_DATE"].ToString() + @"</td><td align=center>" + dr["flight_time"].ToString() + @"</td><td align=center>" + dr["AIRWAYBILL_NO"].ToString() + @"</td><td width=20%>" + finalise + @"</td></tr>";
                        AirlineDetailID = dr["Airline_Detail_ID"].ToString();

                    }


                }
                table2 += @"</table>";
                Label1.Text = table2;
            }
            else
            {
                Label1.CssClass = "boldtext";
                Label1.Text = "No Flight Added To PFM";



            }


        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    protected void ShowAirline()
    {

        ddlAirlineCity.Items.Clear();

        con = new SqlConnection(strcon);
        con.Open();
        try
        {
            // com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and a.airline_id in (" + Session["AIRLINEACCESS"].ToString().Substring(0, +Session["AIRLINEACCESS"].ToString().Length - 1) + ") order by Airline_Name", con);
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineCity.Items.Add("Select airline name");
            ddlAirlineCity.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAirlineCity.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
}
