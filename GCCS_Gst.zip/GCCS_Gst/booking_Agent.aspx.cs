using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Xml;
using System.Text;
using System.IO;

public partial class booking_Agent : System.Web.UI.Page
{
    BLWrap bw = new BLWrap();
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string Access;
    string Arl_Access;
    string all_airlines;
    string Fill_Airline;
    string total_airlines;
    int NA = 0;
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        ddlAgentName.Focus();
        lblmsg.Visible = false;
        lblm.Visible = false;
        RateGrid.Visible = false;
        lblMessage.Visible = false;
        txtGrossWt.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
        txtVolWt.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
        txtChWt.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
        txtPieces.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        else if (!IsPostBack && Request.QueryString["sno"].ToString() != "")
        {
            Session["booking_enquiry_no"] = Request.QueryString["sno"].ToString();
            CheckBox1.Checked = true;
            txtDepDate.Text = FormatDateMM(DateTime.Now.ToShortDateString());
            DataTable dtGroupID = dw.GetAllFromQuery("SELECT * from booking_enquiry  where Booking_enquiryno='" + Request.QueryString["sno"].ToString() + "'");
            if (dtGroupID.Rows.Count > 0)
            {
                DataTable dtAgent = dw.GetAllFromQuery("SELECT Agent_ID,city from booking_enquiry  where Booking_enquiryno='" + Request.QueryString["sno"].ToString() + "'");
                rbCal.SelectedValue = "Cm";
                rbFreightType.SelectedValue = "PREPAID";
                LoadACS();
                if (dtAgent.Rows.Count > 0)
                {
                    ddlAgentName.SelectedValue = dtAgent.Rows[0]["Agent_ID"].ToString();
                    LoadUserOrigin();
                    ddlOrigin.SelectedValue = dtAgent.Rows[0]["city"].ToString();
                    ddlAgentName.Enabled = false;
                    ddlOrigin.Enabled = false;
                    DataTable dtLimit = dw.GetAllFromQuery("select Agent_ID,Credit_Limit,isnull(Used_Limit,0) as Used_Limit,(Credit_Limit-isnull(Used_Limit,0)+isnull(Amount_Paid,0))as Unused_Limit from Agent_Branch  where Agent_ID=" + ddlAgentName.SelectedValue + " and Belongs_To_City=" + ddlOrigin.SelectedValue);
                    if (dtLimit.Rows.Count > 0)
                    {
                        lblCreditLimit.Text = dtLimit.Rows[0]["Credit_Limit"].ToString();
                        decimal used = decimal.Parse(dtLimit.Rows[0]["Used_Limit"].ToString());
                        used = Math.Round(used);
                        lblUsed.Text = used.ToString();
                        Session["UsedLimit"] = used.ToString();
                        decimal Unused = decimal.Parse(dtLimit.Rows[0]["Unused_Limit"].ToString());
                        Unused = Math.Round(Unused);
                        lblRemaining.Text = Unused.ToString();
                    }
                }
                decimal credit_limit = decimal.Parse(lblRemaining.Text);
                if (credit_limit > 0)
                {
                    Flight_Details.Visible = true;
                }
                else
                {
                    Flight_Details.Visible = false;
                    lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
                    lblcreditlimitcheck.Visible = true;
                }
                UserAirlineNamePlusCode();
                ddlAirline.SelectedValue = dtGroupID.Rows[0]["Airline_detail_id"].ToString();
                ddlAirline.Enabled = false;
                ddlAgentName.Enabled = false;
                Label1.Visible = false;
                DataTable dtAirlineCode = dw.GetAllFromQuery("Select Airline_Code from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + dtGroupID.Rows[0]["Airline_detail_id"] + "'");
                DataTable dtAWbNo = new DataTable();
                if (dtAirlineCode.Rows.Count > 0)
                {
                    string Airline_Code = dtAirlineCode.Rows[0]["Airline_Code"].ToString();
                    dtAWbNo = dw.GetAllFromQuery("select Stock_ID,be.Awb_no as AirWayBill_No from Stock_Master sm  inner join booking_enquiry be on sm.AirWayBill_No=be.awb_no where sm.Status=16 and neutral='Y' and substring(Awb_no,1,3)='" + Airline_Code + "' and be.Agent_ID=" + ddlAgentName.SelectedValue + " and City_ID=" + ddlOrigin.SelectedValue);
                }
                if (dtAWbNo.Rows.Count > 0)
                {
                    Session["bookin_awb_no"] = dtAWbNo.Rows[0]["AirWayBill_No"].ToString();
                    Session["bookin_awb_id"] = dtAWbNo.Rows[0]["Stock_ID"].ToString();
                    LoadDestination();
                    DataTable dtdestcode = dw.GetAllFromQuery("select distinct destination_id from destination_master where destination_code='" + dtGroupID.Rows[0]["dest_code"].ToString() + "'");
                    ddlDestination.SelectedValue = dtdestcode.Rows[0]["destination_id"].ToString();
                    //ddlDestination.Enabled = false;
                }
                else
                {
                    ddlDestination.Items.Clear();
                    ddlDestination.Items.Insert(0, "- -Select- -");
                    ddlDestination.Items[0].Value = "0";
                    Label1.Visible = true;
                }
                txtGrossWt.Value = dtGroupID.Rows[0]["gross_weight"].ToString();
                txtVolWt.Value = dtGroupID.Rows[0]["volume_weight"].ToString();
                if (Convert.ToDecimal(txtGrossWt.Value) > Convert.ToDecimal(txtVolWt.Value))
                {
                    txtChWt.Value = txtGrossWt.Value;
                }
                else
                {
                    txtChWt.Value = txtVolWt.Value;
                }
                txtPieces.Value = dtGroupID.Rows[0]["no_of_packages"].ToString();
                //AirlineNamePlusCode();
                maketable();
                grdCal.DataSource = (DataTable)Session["dtTemp"];
                grdCal.DataBind();
            }
        }
        else
        {
            if (!IsPostBack)
            {
                CheckBox1.Checked = true;
                txtDepDate.Text = FormatDateMM(DateTime.Now.ToShortDateString());
                DataTable dtGroupID = dw.GetAllFromQuery("select Group_ID from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'");

                if (dtGroupID.Rows.Count > 0 && dtGroupID.Rows[0]["Group_ID"].ToString() == "5")
                {
                    DataTable dtAgent = dw.GetAllFromQuery("SELECT Agent_ID,Belongs_To_City from Agent_Branch where Agent_Branch_ID=(select Agent_ID as AgentBranchID  from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "')");
                    rbCal.SelectedValue = "Cm";
                    rbFreightType.SelectedValue = "PREPAID";
                    LoadACS();

                    if (dtAgent.Rows.Count > 0)
                    {
                        ddlAgentName.SelectedValue = dtAgent.Rows[0]["Agent_ID"].ToString();
                        LoadUserOrigin();
                        ddlOrigin.SelectedValue = dtAgent.Rows[0]["Belongs_To_City"].ToString();
                        ddlAgentName.Enabled = false;
                        ddlOrigin.Enabled = false;

                        DataTable dtLimit = dw.GetAllFromQuery("select Agent_ID,Credit_Limit,isnull(Used_Limit,0) as Used_Limit,(Credit_Limit-isnull(Used_Limit,0)+isnull(Amount_Paid,0))as Unused_Limit from Agent_Branch  where Agent_ID=" + ddlAgentName.SelectedValue + " and Belongs_To_City=" + ddlOrigin.SelectedValue);

                        if (dtLimit.Rows.Count > 0)
                        {
                            lblCreditLimit.Text = dtLimit.Rows[0]["Credit_Limit"].ToString();
                            decimal used = decimal.Parse(dtLimit.Rows[0]["Used_Limit"].ToString());
                            used = Math.Round(used);
                            lblUsed.Text = used.ToString();
                            Session["UsedLimit"] = used.ToString();
                            decimal Unused = decimal.Parse(dtLimit.Rows[0]["Unused_Limit"].ToString());
                            Unused = Math.Round(Unused);
                            lblRemaining.Text = Unused.ToString();
                        }
                    }
                    decimal credit_limit = decimal.Parse(lblRemaining.Text);

                    if (credit_limit > 0)
                    {
                        Flight_Details.Visible = true;
                    }
                    else
                    {
                        Flight_Details.Visible = false;
                        lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
                        lblcreditlimitcheck.Visible = true;
                    }
                    AirlineNamePlusCode();
                    maketable();
                    grdCal.DataSource = (DataTable)Session["dtTemp"];
                    grdCal.DataBind();
                }
                else//For Other Users
                {
                    ddlAgentName.AutoPostBack = true;
                    ddlOrigin.AutoPostBack = true;
                    rbCal.SelectedValue = "Cm";
                    rbFreightType.SelectedValue = "PREPAID";
                    LoadACS();
                    maketable();
                    grdCal.DataSource = (DataTable)Session["dtTemp"];
                    grdCal.DataBind();
                }
            }//if of Postback

        }//Else Waalaa

    }//Page load Event

    public DataSet ConvertXMLToDataSet(StringBuilder xmlData)
    {
        StringReader stream = null;
        XmlTextReader reader = null;
        try
        {
            string s1 = @"<?xml version=""1.0"" encoding=""UTF-8""?><tabledata xmlns:sql=""urn:schemas-microsoft-com:xml-sql"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">";
            string s2 = @"</tabledata>";
            DataSet xmlDS = new DataSet();
            stream = new StringReader(s1 + xmlData.ToString() + s2);
            reader = new XmlTextReader(stream);
            xmlDS.ReadXml(reader);
            return xmlDS;
        }
        catch
        {
            return null;
        }
        finally
        {
            if (reader != null) reader.Close();
        }
    }

    public void LoadACS()
    {
        try
        {
            con = new SqlConnection(strCon);
            com = new SqlCommand("LOADACS", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            StringBuilder xmlData = new StringBuilder(dt.Rows[0]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlAgentName, "Agent_Master", "Agent_Name", "Agent_ID");
            xmlData = new StringBuilder(dt.Rows[1]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlScr, "Special_Commodity_Master", "Special_Commodity_Name", "Special_Commodity_ID");

            xmlData = new StringBuilder(dt.Rows[2]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlShipmentType, "Shipment_Master", "Shipment_Name", "Shipment_ID");
            ddlScr.SelectedValue = "35";
            ddlShipmentType.SelectedValue = "8";
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void maketable()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Length";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Width";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Height";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Pieces";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume Wt";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);
        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
        ViewState["dtBeginCharges"] = dtTemp;
    }

    public void LoadAgentName()
    {
        try
        {
            string strAgent = "select Agent_ID,Agent_Name from Agent_Master  order by Agent_Name asc";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAgentName.Items.Insert(0, "- -Select- -");
            ddlAgentName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAgentName.Items.Add(new ListItem(dr["Agent_Name"].ToString(), dr["Agent_ID"].ToString()));

            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadCommodity()
    {
        try
        {
            string strAgent = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlScr.Items.Insert(0, "- -Select- -");
            //ddlScr.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            ddlScr.SelectedValue = "33";

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadOrigin()
    {
        try
        {
            string strAgent = "select City_ID,City_Code,City_Name from City_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadUserOrigin()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("LOAD_ORIGIN", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);

            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Clear();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadUserDestination()
    {
        try
        {
            //DataTable dtDestinationID = dw.GetAllFromQuery("Select Destination as DestinationID  from Flight_Master where Airline_Detail_ID in(Select Airline_Detail_ID from Airline_Detail where Belongs_To_City=" + ddlOrigin.SelectedValue + ")");
            //string strDestinationID = string.Empty;
            //if (dtDestinationID.Rows.Count > 0)
            //{
            //    foreach (DataRow rw in dtDestinationID.Rows)
            //    {
            //        strDestinationID = strDestinationID + rw["DestinationID"].ToString() + ",";
            //    }
            //}
            //strDestinationID = strDestinationID.Remove(strDestinationID.LastIndexOf(','));
            string strAgent = "select distinct d.Destination_Name,d.Destination_ID,d.Destination_Code from Destination_Master d inner join Agent_Rate_Master a on a.Destination=d.Destination_ID order by d.Destination_Code";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Insert(0, "- -Select- -");
            ddlDestination.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadDestination()
    {
        try
        {

            string strAgent = "";
            strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + ddlAirline.SelectedValue + " order by dm.Destination_Code";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Clear();
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadShipmentType()
    {
        try
        {
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlShipmentType.Items.Insert(0, "- -Select- -");
            //ddlShipmentType.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlShipmentType.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            ddlShipmentType.SelectedValue = "8";
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ViewState["AgentRateID"] = null;
        Session["SlabID"] = null;
        Session["NextSlabID"] = null;
        Session["nextslabChwt"] = null;
        ViewState["BeneficialPriceValue"] = null;
        ViewState["Min"] = null;
        Session["VolWt"] = null;
        Session["GrossWt"] = null;
        Session["TariffRate"] = null;
        Session["FreightAmount"] = null;
        Session["SpecialRate"] = null;
        Session["SpecialAmount"] = null;
        Session["Pieces"] = null;
        Session["AgentName"] = null;
        // Session["dtTemp"] = null;
        Session["FreightType"] = null;
        Session["FlightNo"] = null;
        Session["ShipmentType"] = null;
        Session["Scr"] = null;
        Session["Flag"] = null;
        Session["Origin"] = null;
        Session["Destination"] = null;
        Session["AirlineDetailID"] = null;
        Session["FlightDate"] = null;
        Session["FlightID"] = null;
        Session["Unit"] = null;

        //************************************************************* 
        RateGrid.Visible = true;

        con = new SqlConnection(strCon);
        com = new SqlCommand("RATE_SEARCH", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Origin", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        com.Parameters.Add("@Destination", SqlDbType.BigInt).Value = long.Parse(ddlDestination.SelectedValue);
        com.Parameters.Add("@FlightDate", SqlDbType.DateTime).Value = FormatDateDD(txtDepDate.Text);
        com.Parameters.Add("@AirlineDetailID", SqlDbType.Int).Value = int.Parse(ddlAirline.SelectedValue);
        com.Parameters.Add("@ShipmentID", SqlDbType.Int).Value = int.Parse(ddlShipmentType.SelectedValue);
        com.Parameters.Add("@Gw", SqlDbType.Decimal).Value = decimal.Parse(txtGrossWt.Value);
        com.Parameters.Add("@Chwt", SqlDbType.Decimal).Value = decimal.Parse(txtChWt.Value);
        com.Parameters.Add("@Flightdays", SqlDbType.Int).Value = int.Parse(txtFlightDays.Value);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);

        //****************************************************************
        if (dt.Columns.Count != 1)
        {
            if (dt.Rows.Count > 0)
            {
                ViewState["AgentRateID"] = long.Parse(dt.Rows[0]["AgentRateID"].ToString());
                Session["Agent_Rate_ID"] = long.Parse(dt.Rows[0]["AgentRateID"].ToString());
                Session["SlabID"] = int.Parse(dt.Rows[0]["SlabID"].ToString());
                Session["NextSlabID"] = int.Parse(dt.Rows[0]["NextSlabID"].ToString());
                Session["nextslabChwt"] = decimal.Parse(dt.Rows[0]["NextSlabChwt"].ToString());
                ViewState["BeneficialPriceValue"] = decimal.Parse(dt.Rows[0]["BeneficialPriceValue"].ToString());
                decimal Min = decimal.Parse(dt.Rows[0]["Min"].ToString());
                Min = Math.Round(Min);
                ViewState["Min"] = Min.ToString();

                //****************************************************************

                decimal DueCarrier = 0, A = 0, B = 0, C = 0, AWBFee = 0, DisbursmentCharges = 0, ACIFee = 0;

                A = decimal.Parse(dt.Rows[0]["A"].ToString());
                B = decimal.Parse(dt.Rows[0]["B"].ToString());
                C = decimal.Parse(dt.Rows[0]["C"].ToString());
                AWBFee = decimal.Parse(dt.Rows[0]["AWB_Fees"].ToString());
                ACIFee = decimal.Parse(dt.Rows[0]["ACI_Fees"].ToString());
                DisbursmentCharges = decimal.Parse(dt.Rows[0]["DisBursementCharges"].ToString());

                if (rbFreightType.SelectedValue == "COLLECT")
                {
                    DisbursmentCharges = DisbursmentCharges;
                }
                else
                {
                    DisbursmentCharges = 0;
                }
                //**** For AWB Fee***********************
                if (decimal.Parse(txtChWt.Value) >= 150)
                {
                    AWBFee = decimal.Parse(txtChWt.Value);
                }
                else
                {
                    AWBFee = 150;
                }
                //**** For End ofAWB Fee*****************

                //**** For Catrage Charges***************
                decimal Catrage = 0;
                if (ddlOrigin.SelectedValue == "18")
                {
                    if (decimal.Parse(txtGrossWt.Value) >= 50)
                    {
                        Catrage = decimal.Parse(txtGrossWt.Value);
                    }
                    else
                    {
                        Catrage = 50;
                    }
                }
                else
                {
                    Catrage = 0;
                }
                //****End of Catrage Charges*************

                DueCarrier = A + B + C + ACIFee + DisbursmentCharges + AWBFee + Catrage;
                Hidden1.Value = DueCarrier.ToString();
                msg.Visible = false;
                RateGrid.DataSource = dt;
                RateGrid.DataBind();
                if (NA == 0)
                {
                    RateGrid.Columns[9].Visible = false;
                }
                else
                {
                    RateGrid.Columns[9].Visible = true;
                }
            }
            else
            {
                CheckBox1.Visible = false;
                RateGrid.DataSource = null;
                RateGrid.DataBind();
                msg.Visible = true;
                msg.Text = "Flight not found";
            }
        }
        else
        {
            CheckBox1.Visible = false;
            RateGrid.DataSource = null;
            RateGrid.DataBind();
            msg.Visible = true;
            msg.Text = "Rates not found";
        }

    }
    protected void RateGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            bool disC = true;
            bool disOnMin = true;
            bool MinCheck = true;
            //decimal TariffRate=decimal.Parse(e.Row.Cells[5].Text);
            decimal TotalPayableAmount = decimal.Parse(e.Row.Cells[6].Text) * decimal.Parse(txtChWt.Value);
            decimal Min = decimal.Parse(ViewState["Min"].ToString());
            decimal TariffRate = decimal.Parse(e.Row.Cells[6].Text);
            if (TotalPayableAmount > Min)
            {
                decimal TPA = Math.Round(TotalPayableAmount, 2);
                e.Row.Cells[7].Text = TPA.ToString();
            }
            else//Minimum Case
            {
                MinCheck = false;
                decimal Minimum = Math.Round(Min, 2);
                e.Row.Cells[7].Text = Minimum.ToString();
                e.Row.Cells[6].Text = Minimum.ToString();//change bye Rajinder

                string flight_openid = e.Row.Cells[12].Text;
                //******************Minimum pe Discount******************

                con = new SqlConnection(strCon);
                com = new SqlCommand("MIN_RATE", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Origin", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
                com.Parameters.Add("@Destination", SqlDbType.BigInt).Value = long.Parse(ddlDestination.SelectedValue);
                com.Parameters.Add("@FlightDate", SqlDbType.DateTime).Value = FormatDateDD(txtDepDate.Text);
                com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ddlAirline.SelectedValue);
                com.Parameters.Add("@Agent_Rate_ID", SqlDbType.Int).Value = Convert.ToInt64(ViewState["AgentRateID"]);

                com.Parameters.Add("@AgentSlabID", SqlDbType.Int).Value = Convert.ToInt32(Session["SlabID"]);

                com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(ddlShipmentType.SelectedValue);
                com.Parameters.Add("@Flightdays", SqlDbType.Int).Value = int.Parse(txtFlightDays.Value);
                com.Parameters.Add("@Flight_Open_Id", SqlDbType.BigInt).Value = long.Parse(flight_openid);

                SqlDataAdapter da = new SqlDataAdapter(com);
                DataTable dt_Min_Rate = new DataTable();
                da.Fill(dt_Min_Rate);
                if (dt_Min_Rate.Rows.Count > 0)
                {
                    disOnMin = false;

                    e.Row.Cells[11].Text = dt_Min_Rate.Rows[0]["Prefix_Name"].ToString();
                    e.Row.Cells[8].Text = dt_Min_Rate.Rows[0]["DiscountedRate"].ToString();
                    e.Row.Cells[9].Text = dt_Min_Rate.Rows[0]["DiscountedRate"].ToString();
                }

            }

            //decimal TariffRate = decimal.Parse(e.Row.Cells[6].Text);
            decimal nextslabrate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) * Convert.ToDecimal(Session["nextslabChwt"]);
            Session["nextslabrate"] = nextslabrate;
            decimal freightamount = decimal.Parse(e.Row.Cells[7].Text);

            //if (Convert.ToDecimal(ViewState["BeneficialPriceValue"]) >= TariffRate)

            //******When nextSlab is not Exist In case of AirlineSlab not Exist***********
            if (ViewState["BeneficialPriceValue"] == null && Session["nextslabChwt"] == null)
            {
                e.Row.Cells[10].Text = "NA";
                CheckBox1.Visible = false;
                lblMessage.Visible = false;
            }
            if (nextslabrate >= freightamount)
            {
                e.Row.Cells[10].Text = "NA";
                CheckBox1.Visible = false;
                lblMessage.Visible = false;
            }
            else
            {
                if (nextslabrate != 0)
                {
                    NA = 1;
                    Session["Flag"] = "1";
                    lblMessage.Visible = true;
                    CheckBox1.Visible = true;
                    lblMessage.Text = "**Your Shipment is Appicable for the next Slab of " + Session["nextslabChwt"].ToString() + " Kg. Pls change the chargeable weight to check the special amt otherwise system will   automatically change the chargeable weight to " + Session["nextslabChwt"].ToString() + " Kg";

                    e.Row.Cells[10].Text = ViewState["BeneficialPriceValue"].ToString();
                    decimal strNextSlabRate = decimal.Parse(e.Row.Cells[10].Text) * Convert.ToDecimal(Session["nextslabChwt"]);
                    //decimal strNextSlabRate =decimal.Parse(e.Row.Cells[10].Text) * decimal.Parse(txtChWt.Value);
                    e.Row.Cells[10].Text = strNextSlabRate.ToString();
                }
                else
                {
                    CheckBox1.Visible = false;
                    lblMessage.Visible = false;
                    e.Row.Cells[10].Text = "NA";
                }
            }
            //if (MinCheck == false && disOnMin == false)//Minimum ke case main Can not enter in these Prefix
            //{
            if (e.Row.Cells[11].Text.Trim() == "-")
            {
                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //     e.Row.Cells[7].Text="0";
                //     e.Row.Cells[8].Text="0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) - decimal.Parse(e.Row.Cells[9].Text);
                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                //DiscountedRate = Math.Round(DiscountedRate, 2);

                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt=decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChWt.Value), 2));
                }
                else
                {
                    if (disOnMin == true)
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        // e.Row.Cells[9].Text = Min_rate.ToString(); //Change By Rajinder
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder

                    }
                    else
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }

                }
                //e.Row.Cells[9].Text = DiscountedRate.ToString();
                //}
            }

            if (e.Row.Cells[11].Text.Trim() == "+")
            {

                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //    e.Row.Cells[7].Text = "0";
                //    e.Row.Cells[8].Text = "0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) + decimal.Parse(e.Row.Cells[9].Text);

                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                //DiscountedRate = Math.Round(DiscountedRate, 2);
                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt = decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChWt.Value), 2));
                }
                else
                {
                    if (disOnMin == true)
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        //e.Row.Cells[9].Text = Min_rate.ToString();//Change By Rajinder
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder

                    }
                    else
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }

                }

                //e.Row.Cells[9].Text = DiscountedRate.ToString();
                //}
            }
            if (e.Row.Cells[11].Text.Trim() == "%")
            {
                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //    e.Row.Cells[7].Text = "0";
                //    e.Row.Cells[8].Text = "0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) * decimal.Parse(e.Row.Cells[9].Text);
                DiscountedRate = DiscountedRate / 100;
                // e.Row.Cells[8].Text = DiscountedRate.ToString();
                DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) - DiscountedRate;
                DiscountedRate = Math.Round(DiscountedRate, 2);
                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt = decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChWt.Value), 2));
                }
                else
                {
                    if (disOnMin == true)  // Minimum Case Discount Not Issue
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder
                    }
                    else// Minimum Case Discount Issue
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }
                }

                //}
                // }
            }//*****End of MinCheck True and DisonMin true*********
            if (disC == true)
            {
                e.Row.Cells[9].Text = e.Row.Cells[7].Text;//Change By Rajinder
                e.Row.Cells[8].Text = e.Row.Cells[6].Text;//Change By Rajinder
            }
            //checking for discounting rate to min rate

            //decimal d_rate = decimal.Parse(e.Row.Cells[9].Text);
            //if (drate)
            //{
            //    if (drate > Min)
            //    {
            //        e.Row.Cells[9].Text = d_rate;
            //    }
            //    else
            //    { 
            //         decimal Min_rate = Math.Round(Min, 2);
            //         e.Row.Cells[9].Text = Min_rate;
            //    }
            //}

            //******************************************************
            //e.Row.Cells[11].Visible = false;

            //*********Time Field***************
            // e.Row.Cells[].Text

            //***********City and Destination***********
            int CityID = Convert.ToInt32(e.Row.Cells[4].Text);
            long DestinationID = Convert.ToInt64(e.Row.Cells[5].Text);
            DataTable dtCity = dw.GetAllFromQuery("select City_Name,City_Code from City_Master where City_ID=" + CityID);
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Name,Destination_Code from Destination_Master where Destination_ID=" + DestinationID);
            if (dtCity.Rows.Count > 0)
            {
                e.Row.Cells[4].Text = dtCity.Rows[0]["City_Code"].ToString();
            }
            if (dtDestination.Rows.Count > 0)
            {
                e.Row.Cells[5].Text = dtDestination.Rows[0]["Destination_Code"].ToString();
            }
        }
        e.Row.Cells[11].Visible = false;
        e.Row.Cells[12].Visible = false;//10:08 prefix name
    }
    protected void RateGrid_SelectedIndexChanged(object sender, EventArgs e)
    {

        DataTable dtAirlineCode = dw.GetAllFromQuery("Select Airline_Code from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + ddlAirline.SelectedValue + "'");
        DataTable dtAWbNo = new DataTable();
        if (dtAirlineCode.Rows.Count > 0)
        {
            string Airline_Code = dtAirlineCode.Rows[0]["Airline_Code"].ToString();
            dtAWbNo = dw.GetAllFromQuery("select Stock_ID,AirWayBill_No from Stock_Master where Status=16 and substring(AirWayBill_No,1,3)='" + Airline_Code + "' and Agent_ID=" + ddlAgentName.SelectedValue + " and City_ID=" + ddlOrigin.SelectedValue);
        }
        if (dtAWbNo.Rows.Count > 0)
        {
            GridViewRow gvr = RateGrid.SelectedRow;
            decimal check_limit = decimal.Parse(lblRemaining.Text);
            Session["CheckLimit"] = check_limit;
            long FlightID = Convert.ToInt64(RateGrid.SelectedDataKey.Value);
            Session["Flight_Open_Id"] = gvr.Cells[12].Text;
            Session["FreightType"] = rbFreightType.SelectedValue;
            Session["Origin"] = ddlOrigin.SelectedValue;
            Session["Destination"] = ddlDestination.SelectedValue;
            Session["ShipmentType"] = ddlShipmentType.SelectedValue;
            Session["Scr"] = ddlScr.SelectedValue;
            Session["AirlineDetailID"] = ddlAirline.SelectedValue;
            Session["FlightNo"] = RateGrid.SelectedRow.Cells[1].Text;
            Session["FlightDate"] = ((Label)RateGrid.SelectedRow.Cells[2].FindControl("FltDate")).Text;
            Session["FlightID"] = FlightID;
            Session["AgentID"] = ddlAgentName.SelectedValue;
            Session["GrossWt"] = txtGrossWt.Value;
            Session["VolWt"] = txtVolWt.Value;
            Session["Pieces"] = txtPieces.Value;
            Session["Unit"] = rbCal.SelectedValue;
            Session["AgentName"] = ddlAgentName.SelectedItem.Text;

            if (gvr.Cells[10].Text == "NA")
            {
                decimal Tariff = decimal.Parse(gvr.Cells[6].Text);
                Tariff = Math.Round(Tariff);
                Session["TariffRate"] = Tariff;
                decimal FreightAmount = decimal.Parse(gvr.Cells[7].Text);
                FreightAmount = Math.Round(FreightAmount);
                Session["FreightAmount"] = FreightAmount;

                decimal SpecialRate = decimal.Parse(gvr.Cells[8].Text);
                SpecialRate = Math.Round(SpecialRate);
                Session["SpecialRate"] = SpecialRate;
                decimal SpecialAmount = decimal.Parse(gvr.Cells[9].Text);
                SpecialAmount = Math.Round(SpecialAmount);
                Session["SpecialAmount"] = SpecialAmount;
            }
            else
            {
                if (CheckBox1.Checked == true)
                {

                    Session["TariffRate"] = ViewState["BeneficialPriceValue"];
                    Session["FreightAmount"] = Session["nextslabrate"];
                    DataTable dtnextSlabDiscount = dw.GetAllFromQuery("select * from nextSlabDiscount where Flight_ID=" + FlightID + " and Flight_Open_ID=" + gvr.Cells[12].Text + " and Slab_ID=" + Convert.ToString(Session["NextSlabID"]) + " and Destination_ID=" + ddlDestination.SelectedValue);
                    if (dtnextSlabDiscount.Rows.Count > 0)
                    {
                        if (dtnextSlabDiscount.Rows[0]["Prefix_Name"].ToString().Trim() == "-")
                        {
                            decimal DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) - decimal.Parse(dtnextSlabDiscount.Rows[0]["Price_Value"].ToString());
                            DiscountedRate = Math.Round(DiscountedRate);
                            Session["SpecialRate"] = DiscountedRate.ToString();
                            decimal SpecialAmount = DiscountedRate * Convert.ToDecimal(Session["nextslabChwt"]);
                            SpecialAmount = Math.Round(SpecialAmount);
                            Session["SpecialAmount"] = SpecialAmount.ToString();
                        }
                        if (dtnextSlabDiscount.Rows[0]["Prefix_Name"].ToString().Trim() == "+")
                        {
                            decimal DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) + decimal.Parse(dtnextSlabDiscount.Rows[0]["Price_Value"].ToString());
                            DiscountedRate = Math.Round(DiscountedRate);
                            Session["SpecialRate"] = DiscountedRate.ToString();
                            decimal SpecialAmount = DiscountedRate * Convert.ToDecimal(Session["nextslabChwt"]);
                            SpecialAmount = Math.Round(SpecialAmount);
                            Session["SpecialAmount"] = SpecialAmount.ToString();
                        }
                        if (dtnextSlabDiscount.Rows[0]["Prefix_Name"].ToString().Trim() == "%")
                        {
                            decimal DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) * decimal.Parse(dtnextSlabDiscount.Rows[0]["Price_Value"].ToString());
                            DiscountedRate = DiscountedRate / 100;
                            DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) - DiscountedRate;
                            DiscountedRate = Math.Round(DiscountedRate);
                            Session["SpecialRate"] = DiscountedRate.ToString();
                            decimal SpecialAmount = DiscountedRate * Convert.ToDecimal(Session["nextslabChwt"]);
                            SpecialAmount = Math.Round(SpecialAmount);
                            Session["SpecialAmount"] = SpecialAmount.ToString();
                        }
                    }

                    else
                    {
                        Session["TariffRate"] = ViewState["BeneficialPriceValue"];
                        Session["FreightAmount"] = Session["nextslabrate"];
                        Session["SpecialRate"] = ViewState["BeneficialPriceValue"];
                        Session["SpecialAmount"] = Session["nextslabrate"];

                    }
                }
                else
                {
                    Session["Flag"] = null;
                    decimal Tariff = decimal.Parse(gvr.Cells[6].Text);
                    Tariff = Math.Round(Tariff);
                    Session["TariffRate"] = Tariff;
                    decimal FreightAmount = decimal.Parse(gvr.Cells[7].Text);
                    FreightAmount = Math.Round(FreightAmount);
                    Session["FreightAmount"] = FreightAmount;

                    decimal SpecialRate = decimal.Parse(gvr.Cells[8].Text);
                    SpecialRate = Math.Round(SpecialRate);
                    Session["SpecialRate"] = SpecialRate;
                    decimal SpecialAmount = decimal.Parse(gvr.Cells[9].Text);
                    SpecialAmount = Math.Round(SpecialAmount);
                    Session["SpecialAmount"] = SpecialAmount;
                }
            }
            decimal Booking_Amount = Convert.ToDecimal(Session["FreightAmount"]) + decimal.Parse(Hidden1.Value);
            if (check_limit < Booking_Amount)
            {
                Flight_Details.Visible = false;
                lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
                lblcreditlimitcheck.Visible = true;
            }
            else
            {
                Response.Redirect("Add_Booking_Details_agent.aspx");
            }

        }
        else
        {
            lblm.Visible = true;
            CheckBox1.Visible = false;
        }
    }
    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
        }
        else
        {
            lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }

    }
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                int Pieces = 0;
                decimal VoulmeWt = 0;
                foreach (DataRow rw in dt.Rows)
                {
                    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                }
                str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                txtPieces.Value = Pieces.ToString();
                if (txtGrossWt.Value != "")
                {
                    txtVolWt.Value = VoulmeWt.ToString();
                    if (decimal.Parse(txtGrossWt.Value) > VoulmeWt)
                    {
                        txtChWt.Value = txtGrossWt.Value;
                    }
                    else
                    {
                        txtChWt.Value = VoulmeWt.ToString();
                    }
                }
                else
                {
                    txtVolWt.Value = VoulmeWt.ToString();
                }
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
        }
        else
        {
            DataTable dtBeginCharges = (DataTable)ViewState["dtBeginCharges"];
            Session["dtTemp"] = dtBeginCharges;
            grdCal.DataSource = dtBeginCharges;
            grdCal.DataBind();
        }


    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        //string [] Key = {"SNo"}; 
        //grdCal.DataKeyNames = Key;
        //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames
        // int SNo = Convert.ToInt16(((TextBox)grdCal.FindControl("txtSNo")).Text);
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        decimal L = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text);
        decimal W = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtw")).Text);
        decimal H = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txth")).Text);
        decimal P = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtp")).Text);
        // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

        // Calculatin Volume Wait
        decimal Volume_Wt;

        if (rbCal.SelectedValue == "Cm")
        {
            Volume_Wt = (L * W * H * P) / 6000;
        }
        else
        {
            Volume_Wt = (L * W * H * P) / 366;

        }
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = Math.Round(Volume_Wt, 3);
            }
        }

        //txtVolWt.Value = Convert.ToString(Math.Round(Volume_Wt, 2));
        if (txtGrossWt.Value != "")
        {
            Volume_Wt = Math.Round(Volume_Wt, 3);
            txtVolWt.Value = Volume_Wt.ToString();
            if (decimal.Parse(txtGrossWt.Value) > Volume_Wt)
            {
                txtChWt.Value = txtGrossWt.Value;
            }
            else
            {
                Volume_Wt = Math.Round(Volume_Wt, 3);
                txtChWt.Value = Volume_Wt.ToString();
            }
        }
        else
        {
            Volume_Wt = Math.Round(Volume_Wt, 3);
            txtVolWt.Value = Volume_Wt.ToString();
        }
        //ViewState["Volume_Wt"] = Convert.ToString(Math.Round(Volume_Wt, 2));
        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();

        int Pieces = 0;
        decimal VoulmeWt = 0;
        foreach (DataRow rw in dt.Rows)
        {
            Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
            VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
        }
        string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
        txtPieces.Value = Pieces.ToString();
        VoulmeWt = Math.Round(VoulmeWt, 3);
        txtVolWt.Value = VoulmeWt.ToString();
        ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
    public void UserAirlineNamePlusCode()
    {
        try
        {
            //string strQuery = "";
            //string Airline_Access = Rights();


            //strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City where b.Airline_Detail_ID in" + "(" + Airline_Access + ") and Belongs_To_City =" + ddlOrigin.SelectedValue;


            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("LOAD_AIRLINE", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Belongs_To_City", SqlDbType.Int).Value = long.Parse(ddlOrigin.SelectedValue);
            com.Parameters.Add("@agent_id", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirline.Items.Clear();
            ddlAirline.Items.Insert(0, "- -Select- -");
            ddlAirline.Items[0].Value = "0";

            while (dr.Read())
            {

                ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));
                //total_airlines = total_airlines + dr["Airline_Detail_ID"].ToString()+",";

            }
            //all_airlines = total_airlines;
            //int len_airline = all_airlines.Length;
            //Fill_Airline = all_airlines.Substring(0, (len_airline-1));
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Agent_Master a inner join Agent_Branch b on a.Agent_ID=b.agent_id inner join login_master c on b.Agent_Branch_ID=c.Agent_ID where a.agent_id=" + ddlAgentName.SelectedValue + " and  b.Belongs_To_City=" + ddlOrigin.SelectedValue;

        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("RIGHTS", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Belongs_To_City", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        com.Parameters.Add("@agent_id", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        SqlDataReader dr = com.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        con.Close();
        return Access;
    }
    public void AirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            //strQuery = "Select Airline_Detail_ID,Airline_ID,Belongs_To_City from Airline_Detail where Belongs_To_City=" + ddlOrigin.SelectedValue;

            DataTable dtAirlineAccess = dw.GetAllFromQuery("select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'");
            string str = "";
            if (dtAirlineAccess.Rows.Count > 0)
            {
                str = dtAirlineAccess.Rows[0]["Airline_Access"].ToString();
            }
            //str = str.Remove(str.LastIndexOf(','));
            //-----------------Updated By Megha--------------//
            strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City where b.Airline_Detail_id in" + "(" + str + ") and Belongs_To_City =" + ddlOrigin.SelectedValue + "and b.Status=2";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirline.Items.Clear();
            ddlAirline.Items.Insert(0, "- -Select- -");
            ddlAirline.Items[0].Value = "0";

            while (dr.Read())
            {

                ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));
                total_airlines = total_airlines + dr["Airline_Detail_ID"].ToString() + ",";

            }
            all_airlines = total_airlines;
            int len_airline = all_airlines.Length;
            Fill_Airline = all_airlines.Substring(0, (len_airline - 1));

            con.Close();




            //---------------------//

            //strQuery = "select Airline_Detail_ID,Belongs_To_City,Airline_ID from Airline_Detail where Airline_ID in(" + str + ")";

            //con = new SqlConnection(strCon);
            //con.Open();
            //SqlCommand com = new SqlCommand(strQuery, con);
            //SqlDataReader dr = com.ExecuteReader();
            ////ddlAirline.Items.Insert(0, "- - Select - -");
            ////ddlAirline.Items[0].Value = "0";
            //ddlAirline.Items.Clear();
            //while (dr.Read())
            //{
            //    DataTable dtAirlineName = dw.GetAllFromQuery(" select Airline_Name from Airline_Master where Airline_ID=" + dr["Airline_ID"].ToString());
            //    DataTable dtCity = dw.GetAllFromQuery("select City_Name from City_Master where City_ID=" + dr["Belongs_To_City"].ToString());
            //    ddlAirline.Items.Add(new ListItem(dtAirlineName.Rows[0]["Airline_Name"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString(), dr["Airline_Detail_ID"].ToString()));
            //    //ddlAirline.Items.Add(new ListItem(dtAirlineName.Rows[0]["Airline_Name"].ToString() , dr["Airline_Detail_ID"].ToString()));
            //}
            //con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();
                //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames

                decimal L = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtl")).Text);
                decimal W = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtw")).Text);
                decimal H = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txth")).Text);
                decimal P = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);
                // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

                // Calculatin Volume Wait
                decimal Volume_Wt;
                if (rbCal.SelectedValue == "Cm")
                {
                    Volume_Wt = (L * W * H * P) / 6000;
                }
                else
                {
                    Volume_Wt = (L * W * H * P) / 366;
                }


                //Prepare the Insert Command of the DataSource control
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = Math.Round(Volume_Wt, 3);
                dt.Rows.Add(dr);
                int Pieces = 0;
                decimal VoulmeWt = 0;
                foreach (DataRow rw in dt.Rows)
                {
                    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                }
                string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                txtPieces.Value = Pieces.ToString();
                if (txtGrossWt.Value != "")
                {
                    VoulmeWt = Math.Round(VoulmeWt, 3);
                    txtVolWt.Value = VoulmeWt.ToString();
                    if (decimal.Parse(txtGrossWt.Value) > VoulmeWt)
                    {
                        txtChWt.Value = txtGrossWt.Value;
                    }
                    else
                    {
                        VoulmeWt = Math.Round(VoulmeWt, 3);
                        txtChWt.Value = VoulmeWt.ToString();
                    }
                }
                else
                {
                    VoulmeWt = Math.Round(VoulmeWt, 3);
                    txtVolWt.Value = VoulmeWt.ToString();
                }

                //ViewState["Volume_Wt"]=VoulmeWt.ToString();
                Session["dtTemp"] = dt;
                grdCal.DataSource = dt;
                grdCal.DataBind();
                ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;

                //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Order added successfully');</script>");
                //string s1 = "SELECT Fltno,hh,mm,fltdate,id FROM ac_fltDetails_tran ORDER BY fltno";
                //AccessDataSource1.SelectCommand = s1;


                //GridViewRow gv = GridView2.Rows[0];
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;

                //fill();


            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }
    protected void lnkCal_Click(object sender, EventArgs e)
    {
        grdCal.Visible = true;
        rbCal.Visible = true;
    }
    protected void grdCal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlAirline_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label1.Visible = false;
        DataTable dtAirlineCode = dw.GetAllFromQuery("Select Airline_Code from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + ddlAirline.SelectedValue + "'");
        DataTable dtAWbNo = new DataTable();
        if (dtAirlineCode.Rows.Count > 0)
        {
            string Airline_Code = dtAirlineCode.Rows[0]["Airline_Code"].ToString();
            dtAWbNo = dw.GetAllFromQuery("select Stock_ID,AirWayBill_No from Stock_Master where Status=16 and substring(AirWayBill_No,1,3)='" + Airline_Code + "' and Agent_ID=" + ddlAgentName.SelectedValue + " and City_ID=" + ddlOrigin.SelectedValue);
        }
        if (dtAWbNo.Rows.Count > 0)
        {
            LoadDestination();
        }
        else
        {
            ddlDestination.Items.Clear();
            ddlDestination.Items.Insert(0, "- -Select- -");
            ddlDestination.Items[0].Value = "0";
            Label1.Visible = true;
        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void ddlAgentName_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label1.Visible = false;
        lblCreditLimit.Text = "";
        lblRemaining.Text = "";
        lblUsed.Text = "";
        if (ddlAgentName.SelectedValue == "0")
        {
            ddlOrigin.Items.Clear();
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
        }
        else
        {
            ddlOrigin.Items.Clear();
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
            LoadUserOrigin();
        }
        //DataTable dtCreditLimit = dw.GetAllFromQuery("select Credit_Limit from Agent_Master where Agent_ID=" + ddlAgentName.SelectedValue);
        //if (dtCreditLimit.Rows.Count > 0)
        //{
        //    lblCreditLimit.Text = dtCreditLimit.Rows[0]["Credit_Limit"].ToString();
        //}
        //DataTable dtLimit = dw.GetAllFromQuery(" select   a.Agent_ID,a.Credit_Limit as Credit_Limit ,sum(bw.Total_DueCarrier) as Total_DueCarrier,sum(b.Special_Amount) as Special_Amount,(sum(bw.Total_DueCarrier)+sum(b.Special_Amount)) as Used_Limit,(a.Credit_Limit-(sum(bw.Total_DueCarrier)+sum(b.Special_Amount))) as Unused_Limit from Agent_Master a inner join Stock_Master s on a.Agent_ID=s.Agent_ID inner join Booking_Master b on s.Stock_ID=b.Stock_ID inner join Booking_AWB bw on b.Booking_ID=bw.Booking_ID where a.Agent_ID=" + ddlAgentName.SelectedValue + " group by a.Agent_ID,a.Credit_Limit");
        //DataTable dtLimit = dw.GetAllFromQuery("select  a.Agent_ID,a.Credit_Limit as Credit_Limit,sum(bw.Total_DueCarrier) as Total_DueCarrier,sum(b.Special_Amount) as Special_Amount,(sum(bw.Total_DueCarrier)+sum(b.Special_Amount)) as Used_Limit,isnull(a.Amount_Paid,0) as Amount_Paid,(a.Credit_Limit-(sum(bw.Total_DueCarrier)+sum(b.Special_Amount))) as Unused_Limit from Agent_Master a inner join Stock_Master s on a.Agent_ID=s.Agent_ID inner join Booking_Master b on s.Stock_ID=b.Stock_ID inner join Booking_AWB bw on b.Booking_ID=bw.Booking_ID where a.Agent_ID=" + ddlAgentName.SelectedValue + " group by a.Agent_ID,a.Credit_Limit,a.Amount_Paid");
        //***********       BEfore Changes      **********************************************
        //DataTable dtLimit = dw.GetAllFromQuery("select Agent_ID,Credit_Limit,isnull(Used_Limit,0) as Used_Limit,(Credit_Limit-isnull(Used_Limit,0)+isnull(Amount_Paid,0))as Unused_Limit from Agent_Master  where Agent_ID=" + ddlAgentName.SelectedValue);
        //if (dtLimit.Rows.Count > 0)
        //{
        //    lblCreditLimit.Text = dtLimit.Rows[0]["Credit_Limit"].ToString();
        //    //decimal Credit = decimal.Parse(dtLimit.Rows[0]["Credit_Limit"].ToString());
        //    decimal used = decimal.Parse(dtLimit.Rows[0]["Used_Limit"].ToString());
        //    used = Math.Round(used);
        //    //decimal AmounPaid = decimal.Parse(dtLimit.Rows[0]["Amount_Paid"].ToString());
        //    //used=used - AmounPaid;
        //    decimal Remaining = decimal.Parse(dtLimit.Rows[0]["Unused_Limit"].ToString());
        //    Remaining = Math.Round(Remaining);
        //    lblUsed.Text = used.ToString();
        //    Session["UsedLimit"] = used.ToString();
        //    lblRemaining.Text = Remaining.ToString();
        //}
        ////else
        ////{
        ////    Session["UsedLimit"] = 0;
        ////    lblUsed.Text = "0";
        ////    lblRemaining.Text = lblCreditLimit.Text;
        ////}
        //decimal credit_limit = decimal.Parse(lblRemaining.Text);
        //if (credit_limit > 0)
        //{
        //    Flight_Details.Visible = true;
        //    lblcreditlimitcheck.Visible = false;
        //}
        //else
        //{
        //    Flight_Details.Visible = false;
        //    lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
        //    lblcreditlimitcheck.Visible = true;
        //}
    }
    protected void ddlOrigin_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOrigin.SelectedValue == "0")
        {
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
        }
        else
        {
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
            UserAirlineNamePlusCode();
            //LoadDestination();
        }
        //********* After Changes Credit Limt **************************
        DataTable dtLimit = dw.GetAllFromQuery("select Agent_ID,Credit_Limit,isnull(Used_Limit,0) as Used_Limit,(Credit_Limit-isnull(Used_Limit,0)+isnull(Amount_Paid,0))as Unused_Limit from Agent_Branch  where Agent_ID=" + ddlAgentName.SelectedValue + " and Belongs_To_City=" + ddlOrigin.SelectedValue);


        if (dtLimit.Rows.Count > 0)
        {
            lblCreditLimit.Text = dtLimit.Rows[0]["Credit_Limit"].ToString();
            //decimal Credit = decimal.Parse(dtLimit.Rows[0]["Credit_Limit"].ToString());
            decimal used = decimal.Parse(dtLimit.Rows[0]["Used_Limit"].ToString());
            used = Math.Round(used);
            //decimal AmounPaid = decimal.Parse(dtLimit.Rows[0]["Amount_Paid"].ToString());
            //used=used - AmounPaid;
            decimal Remaining = decimal.Parse(dtLimit.Rows[0]["Unused_Limit"].ToString());
            Remaining = Math.Round(Remaining);
            lblUsed.Text = used.ToString();
            Session["UsedLimit"] = used.ToString();

            lblRemaining.Text = Remaining.ToString();
        }
        //else
        //{
        //    Session["UsedLimit"] = 0;
        //    lblUsed.Text = "0";
        //    lblRemaining.Text = lblCreditLimit.Text;
        //}

        decimal credit_limit = decimal.Parse(lblRemaining.Text);

        if (credit_limit > 0)
        {
            Flight_Details.Visible = true;
            lblcreditlimitcheck.Visible = false;
        }
        else
        {
            Flight_Details.Visible = false;
            lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
            lblcreditlimitcheck.Visible = true;
        }


    }
    public string AirlineName_Access()
    {

        string str = "";
        string Airline_Access = Rights();


        str = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City where b.Airline_Detail_ID in" + "(" + Airline_Access + ") and Belongs_To_City =" + ddlOrigin.SelectedValue;


        //strQuery = "select a.Airline_Name,ad.Airline_Detail_ID,c.City_Name from Airline_Master a inner join Airline_Detail ad on a.Airline_ID=ad.Airline_ID inner join City_Master c on c.City_ID=ad.Belongs_To_City order by a.Airline_Name ";

        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand(str, con);
        SqlDataReader dr = com.ExecuteReader();
        while (dr.Read())
        {


            total_airlines = total_airlines + dr["Airline_Detail_ID"].ToString() + ",";

        }
        //all_airlines = total_airlines;

        //int len_airline = all_airlines.Length;
        //Fill_Airline = all_airlines.Substring(0, (len_airline - 1));
        if (total_airlines == null)
        {
            lblAirlineCheck.Text = "No Airline Exist.";
            Fill_Airline = "";
            return Fill_Airline;
        }
        else
        {
            Fill_Airline = total_airlines.Remove(total_airlines.IndexOf(','));
            return Fill_Airline;

        }
        con.Close();
        //ViewState["Fill_Airline"] = Fill_Airline;



    }
    public void DueCarrier()
    {
        decimal DueCarrier = 0, A = 0, B = 0, C = 0, Gw = 0, Cw = 0, FSC = 0, AWBFee = 0, DisbursmentCharges = 0, ACIFee = 0, Security_Surcharge = 0, Xray = 0;
        if (txtGrossWt.Value != "" && txtChWt.Value != "")
        {
            Gw = decimal.Parse(txtGrossWt.Value);
            Cw = decimal.Parse(txtChWt.Value);
        }
        DataTable dtCharges = dw.GetAllFromQuery("select FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,DisBursementCharges from Airline_Detail where Airline_Detail_ID=" + ddlAirline.SelectedValue);

        DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ddlAirline.SelectedValue + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue + " and Agent_Rate_ID=" + Session["Agent_Rate_ID"].ToString());

        //DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ddlAirline.SelectedValue);
        if (dtCharges.Rows.Count > 0)
        {
            if (dtCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Cw * FSC;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Gw * FSC;
                    }
                }
            }
            if (dtCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Cw * Security_Surcharge;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Gw * Security_Surcharge;
                    }
                }
            }
            if (dtCharges.Rows[0]["XRayCharge_Charged"].ToString().Trim() == "13")
            {
                if (dtCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Cw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Gw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
            }
            ACIFee = decimal.Parse(dtCharges.Rows[0]["ACI_Fees"].ToString());
            //DisbursmentCharges = decimal.Parse(dtCharges.Rows[0]["DisBursementCharges"].ToString());
            if (rbFreightType.SelectedValue == "COLLECT")
            {
                DisbursmentCharges = decimal.Parse(dtCharges.Rows[0]["DisBursementCharges"].ToString());
            }
            else
            {
                DisbursmentCharges = 0;
            }

            AWBFee = decimal.Parse(dtCharges.Rows[0]["AWB_Fees"].ToString());
            //**** For AWB Fee***********************
            if (decimal.Parse(txtChWt.Value) >= 150)
            {
                AWBFee = decimal.Parse(txtChWt.Value);
            }
            else
            {
                AWBFee = 150;
            }
            //**** For End ofAWB Fee*****************

            //**** For Catrage Charges***************
            decimal Catrage = 0;
            if (ddlOrigin.SelectedValue == "18")
            {
                if (decimal.Parse(txtGrossWt.Value) >= 50)
                {
                    Catrage = decimal.Parse(txtGrossWt.Value);
                }
                else
                {
                    Catrage = 50;
                }
            }
            else
            {
                Catrage = 0;
            }
            //****End of Catrage Charges*************

            DueCarrier = A + B + C + ACIFee + DisbursmentCharges + AWBFee + Catrage;
            Hidden1.Value = DueCarrier.ToString();


        }
    }
    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {


            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");


        }

    }
}
