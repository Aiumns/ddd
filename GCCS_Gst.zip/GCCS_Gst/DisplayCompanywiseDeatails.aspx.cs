﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Text;
using System.IO;

public partial class DisplayCompanywiseDeatails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblTable.Text = Session["CompanyWiseAgentDetails"].ToString();
    }
    protected void btnexcel_Click(object sender, EventArgs e)
    {
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=DisplayCompanywiseDeatails.xls");
        Response.ContentType = "application/vnd.ms-excel";
        StringWriter sw1 = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(sw1);
        div1.RenderControl(htw);
        FileInfo fi = new FileInfo(Server.MapPath("~/include/Table.css"));
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        StreamReader sr = fi.OpenText();
        while (sr.Peek() >= 0)
            sb.Append(sr.ReadLine());
        sr.Close();
        Response.Write("<html><head><style type='text/css' rel='stylesheet'>" + sb.ToString() + "</style><head>" + sw1.ToString() + "</html>");
        Response.Write(sw1.ToString());
        Response.End();

    }
}
