using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class DisplayImport_agent_master : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
   
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Search();
        }

    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ = null;
            if (txt_search.Text == "")
            {
                selectQ = "select Import_Agent_ID,Import_Agent_Name,city_master.City_Name as Import_Agent_City ,Import_Agent_Email,Import_Credit_Limit,Agent_Address,Agent_Phone,Agent_Contactno from import_agent_master inner join city_master on import_agent_master.Import_Agent_City=city_master.city_id";
            }

            else
            {
                selectQ = "select Import_Agent_ID,Import_Agent_Name,city_master.City_Name as Import_Agent_City ,Import_Agent_Email,Import_Credit_Limit,Agent_Address,Agent_Phone,Agent_Contactno from import_agent_master inner join city_master on import_agent_master.Import_Agent_City=city_master.city_id where Import_Agent_Name like '" + txt_search.Text + "%' order by Import_Agent_Name";
            }
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdImportAgent.DataSource = dt;
            grdImportAgent.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void Modify(object sender, CommandEventArgs e)
    {
        Response.Redirect("Import_agent_master.aspx?ID=" + e.CommandName);
    }

    protected void lnkImportAgent_Click(object sender, EventArgs e)
    {
        Response.Redirect("Import_agent_master.aspx?ID=");
    }
    protected void grdTrucker_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdImportAgent.PageIndex = e.NewPageIndex;
        Search();
    }
}
