﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class AssignAgentByCluster : System.Web.UI.Page
{
    //string Agent = "";
    string ClusterID = "";
    int Sid;
    //string CityDest = "";
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

        btnsubmit.Attributes.Add("onclick", "return checkgridcontrols();return false;");

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                FillCluster();

                txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
                btnsubmit.Visible = false;
                btnCancel.Visible = false;

               // ddlCluster.SelectedIndex = 0;
                ////}
            }
        }
    }
    protected void FillCluster()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            cmd = new SqlCommand("DECLARE @clusterid VARCHAR(50) SET @clusterid =(select Cluster_ID FROM dbo.Login_Master WHERE Email_ID ='" + Session["EMailID"] + "') SELECT Cluster_id,Cluster_Name FROM db_owner.Cluster_master WHERE Cluster_id IN ( SELECT value FROM String_to_Int(@clusterid))", con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlCluster.Items.Clear();
            ddlCluster.Items.Insert(0, "- -Select- -");
            ddlCluster.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlCluster.Items.Add(new ListItem(dr["Cluster_Name"].ToString(), dr["Cluster_id"].ToString()));
            }
            con.Close();
           // ddlCluster.SelectedValue = "0";


        }

        catch
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }

    protected void ddlCluster_SelectedIndexChanged(object sender, EventArgs e)
    {

        
        GridView1.Visible = true;
        //lblmessage.Visible = false;
        ClusterID = ddlCluster.SelectedValue;
        btnCancel.Visible = true;
        con = new SqlConnection(strCon);
        con.Open();
      
       // string StrAgent = "SELECT am.agent_id,ab.agent_address,am.agent_name,ab.agent_branch_id,ab.Belongs_To_City FROM dbo.Login_Master lm INNER JOIN db_owner.Agent_Branch ab  ON lm.Agent_ID = ab.Agent_Branch_ID INNER JOIN dbo.Agent_Master am ON ab.Agent_ID = am.Agent_ID INNER JOIN db_owner.Cluster_master cm  ON ab.Belongs_To_City =cm.Cluster_City WHERE cm.Cluster_id=" + ClusterID + "";


        cmd = new SqlCommand("GetAgentList_Cluster", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Cluster_id", SqlDbType.Int).Value = Convert.ToInt32(ClusterID);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
        sda.Dispose();
        con.Close();

        foreach (GridViewRow gv in GridView1.Rows)
        {

            DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");

            //string strSalesPerson = "SELECT lm.User_ID,um.Full_Name  FROM dbo.Login_Master lm INNER JOIN dbo.User_Master um ON lm.User_ID=um.UserID WHERE lm.Cluster_ID=" + ClusterID + "";


            string strSalesPerson = "SELECT lm.User_ID,um.Full_Name  FROM dbo.Login_Master lm INNER JOIN dbo.User_Master um ON lm.User_ID=um.UserID WHERE ','+lm.Cluster_ID+',' LIKE ('%" + ddlCluster.SelectedValue + "%')";


            con.Open();
            SqlCommand cmdiner = new SqlCommand(strSalesPerson, con);
            SqlDataReader dr;
            dr = cmdiner.ExecuteReader();
            ddlSalesPerson.Items.Clear();
            ddlSalesPerson.Items.Insert(0, "- -Select- -");
            ddlSalesPerson.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlSalesPerson.Items.Add(new ListItem(dr["Full_Name"].ToString(), dr["User_ID"].ToString()));
            }
            con.Close();
            Label lblAID = (Label)gv.FindControl("lblAgentID");
            int agentid = Convert.ToInt32(lblAID.Text);
            string strbind = "select sales_person_id from AgentToSalesPerson_Cluster where agent_id=" + agentid + " and Cluster_Id="+ClusterID+"";
            SqlDataAdapter sdb = new SqlDataAdapter(strbind, con);
            DataTable dt2 = new DataTable();
            sdb.Fill(dt2);
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            if (dt2.Rows.Count > 0)
            {

                ChkBxItem.Checked = true;
                ddlSalesPerson.SelectedValue = dt2.Rows[0]["sales_person_id"].ToString();
            }
            ChkBxItem.Attributes.Add("onclick", " resetdropdownlist();");

        }

        btnsubmit.Visible = true;
    }


    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        try
        {
            foreach (GridViewRow gv in GridView1.Rows)
            {
                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");
                Sid = Convert.ToInt32(ddlSalesPerson.SelectedValue);
                Label lblAID = (Label)gv.FindControl("lblAgentID");
                int agentid = Convert.ToInt32(lblAID.Text);
                int i = check(agentid);
                if (i == 0)
                {
                    if (ChkBxItem.Checked)
                    {
                        //**** Insert Into AgentToSalesPersonCluster ****///
                        string insertQ = "";
                        DateTime effected = Convert.ToDateTime(FormatDateMM(txtValidFrom.Text));
                        insertQ = "insert into AgentToSalesPerson_Cluster(Sales_Person_Id,Agent_Id,Cluster_Id,Entered_By,Entered_On)values(@Sales_Person_Id,@Agent_Id,@Cluster_Id,@Entered_By,@Entered_On)";
                        cmd = new SqlCommand(insertQ, con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@Sales_Person_Id", Sid);
                        cmd.Parameters.AddWithValue("@Agent_Id", int.Parse(lblAID.Text));
                        cmd.Parameters.AddWithValue("@Cluster_Id", int.Parse(ddlCluster.SelectedItem.Value));
                        cmd.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());
                        cmd.Parameters.AddWithValue("@Entered_On", DateTime.Now.ToShortDateString());
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                else
                {
                    //////// For update and delete/////////
                    if (ChkBxItem.Checked)
                    {
                        ////// update the data BY CALLING PROCEDURE UPDATETO SALES ////////
                        ///// /UPDATE AGENTTOSALESPERSONCLuster AND SEND THE PREVIOUS DATA TO AGENTTOSALESPERSONCluster_HISTOEY/////////////////////
                        DateTime effected = Convert.ToDateTime(FormatDateMM(txtValidFrom.Text));
                        if (Sid != Convert.ToInt32(Session["Ssid"].ToString()))
                        {
                            SqlCommand cmd = new SqlCommand("UpdateAgentToSalesCluster", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            con.Open();
                            cmd.Parameters.AddWithValue("@agent_id", agentid);
                            cmd.Parameters.AddWithValue("@Sales_Person_Id", Sid);
                            cmd.Parameters.AddWithValue("@Cluster_Id", int.Parse(ddlCluster.SelectedItem.Value));
                            cmd.Parameters.AddWithValue("@Last_Updated_By", Session["EMailID"].ToString());
                            cmd.Parameters.AddWithValue("@Last_Updated_On", DateTime.Now.ToShortDateString());
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                    else
                    {
                        ////  delete the data from AgentToSalesCluster//////
                        //call procedure DeleteAgentToSalesCluster
                        SqlCommand cmd2 = new SqlCommand("DeleteAgentToSalesCluster", con);
                        cmd2.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        cmd2.Parameters.AddWithValue("@agent_id", agentid);
                        cmd2.Parameters.AddWithValue("@Cluster_Id", int.Parse(ddlCluster.SelectedItem.Value));
                        cmd2.Parameters.AddWithValue("@Entered_by", Session["EMailID"].ToString());
                        cmd2.Parameters.AddWithValue("@Effective_To", DateTime.Now.ToShortDateString());
                        cmd2.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        string strScript = "alert('Saved Successfully.');location.replace('AssignAgentByCluster.aspx');";
        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
    }
    public int check(int aid)
    {
        con = new SqlConnection(strCon);
        string strcmdcheck = "select sales_person_id from AgentToSalesPerson_Cluster where Agent_Id=" + aid + " and Cluster_Id=" + ddlCluster.SelectedValue + "";
        con.Open();
        cmd = new SqlCommand(strcmdcheck, con);
        SqlDataAdapter sdac = new SqlDataAdapter(strcmdcheck, con);

        DataTable dtc = new DataTable();
        sdac.Fill(dtc);

        if (dtc.Rows.Count > 0)
        {
            Session["Ssid"] = dtc.Rows[0]["sales_person_id"].ToString();
            con.Close();
            return 1;

        }
        else
        {
            con.Close();
            return 0;

        }


    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AssignAgentByCluster.aspx");
    }

    //public bool validatepage()
    //{
    //    bool returnval=true;
    //        foreach (GridViewRow gv in GridView1.Rows)
    //        {
    //            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
    //            DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");

    //            Sid = Convert.ToInt32(ddlSalesPerson.SelectedValue);
    //            if ((ChkBxItem.Checked && Sid > 0) || (!ChkBxItem.Checked && Sid == 0))
    //                returnval= true;
    //            else
    //            {
    //                returnval= false;
    //                break;
    //            }
    //        }
    //        return returnval;
    //}

    
}
