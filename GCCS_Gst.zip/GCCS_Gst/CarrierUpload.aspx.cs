﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Data;
using System.Data.OleDb;
using System.Data.Common;
using System.Linq;
public partial class CarrierUpload : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    int bit = 0;

    // bool flag = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        #region comnt
        //List<Class1> emplst = new List<Class1>();
        //emplst.Add(new Class1()
        //{
        //    EmpID = 1,
        //    EmpName = "Sourabh",
        //    EmpSalary = 50000,
        //    Dept = "HR"
        //});
        //emplst.Add(new Class1()
        //{
        //    EmpID = 2,
        //    EmpName = "Shaili",
        //    EmpSalary = 60000,
        //    Dept = "IT"
        //});
        //emplst.Add(new Class1()
        //{
        //    EmpID = 3,
        //    EmpName = "Saloni",
        //    EmpSalary = 55000,
        //    Dept = "HR"
        //});
        ////var filter = from r in lst  orderby r.Dept  group e by  into grp select new { key = grp.Key, cnt = grp.Count() };
        //string strvar = string.Empty;
        ////query syntax
        //var filter = from ss in emplst orderby ss.Dept group ss by ss.Dept into grp select new { ddpt = grp.Key, ddptcount = grp.Count() };      
        ////lamda expression 
        //var aaaa = from dd in emplst.GroupBy(dd => dd.Dept) select new { ddpt = dd.Key, ddptcount = dd.Count() };
        //foreach (var aa in aaaa)
        //{
        //    strvar += "deptname  " + aa.ddpt + "  Noofdept  " + aa.ddptcount  +"</br>";
        //}
        #endregion   
        
        if(!IsPostBack)
         {
            //FileUpload1.PostedFile.InputStream.Dispose(); 
         }
        else 
         {
            //FileUpload1.PostedFile.InputStream.Dispose();    
         }
    }
    protected void btnSample_Click(object sender, EventArgs e)
    {
        // if you have Excel 2007 uncomment this line of code
        // string excelConnectionString =string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties=Excel 8.0",path);
        int successval = 0;      
        string ExcelContentType = "application/vnd.ms-excel";
        string Excel2010ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        // string strdt = "23/01/2019";
        // DateTime Updatedondt = DateTime.Parse(strdt.ToString());            
        if (FileUpload1.HasFile)
            {
                //Check the Content Type of the file
                if (FileUpload1.PostedFile.ContentType == ExcelContentType || FileUpload1.PostedFile.ContentType == Excel2010ContentType)
                {
                    try
                    {
                        //Save file pathhttp://localhost:51585/Cfi.App.Pace.WebUI/Cargo/Excel/
                        string path = string.Concat(Server.MapPath("~/Sample/"), FileUpload1.FileName);                        
                        //Save File as Temp then you can delete it if you want
                        FileUpload1.SaveAs(path);
                        //string path = @"C:\Users\Johnney\Desktop\ExcelData.xls";
                        //For Office Excel 2010  please take a look to the followng link  http://social.msdn.microsoft.com/Forums/en-US/exceldev/thread/0f03c2de-3ee2-475f-b6a2-f4efb97de302/#ae1e6748-297d-4c6e-8f1e-8108f438e62e
                        string excelConnectionString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=Excel 8.0", path);
                        //Create Connection to Excel Workbook
                        using (OleDbConnection connection = new OleDbConnection(excelConnectionString))
                        {
                            connection.Open();
                            string sheet1 = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
                            DataTable dtExcelData = new DataTable();
                            using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheet1 + "]", connection))
                            {
                                oda.Fill(dtExcelData);
                            }
                            connection.Close();
                            using (SqlConnection sqlCon = new SqlConnection(strCon))
                            {
                                sqlCon.Open();
                                //com = new SqlCommand("SP_AKMYEAST_BulkStockAdd", sqlCon);
                                com = new SqlCommand("SP_CarrierSheet_Uploading", sqlCon);
                                com.CommandType = CommandType.StoredProcedure;
                                com.Parameters.Add("@Type_Carrier_Upload", SqlDbType.Structured).Value = dtExcelData;
                                successval = com.ExecuteNonQuery();
                                if (successval > 0)
                                {
                                    FileUpload1.PostedFile.InputStream.Dispose();
                                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "OpenWindow", "alert('Data Uploaded successfully');", true);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //Label1.Text = ex.Message;
                    }
                }           
        }
    }    
}