using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class Browse_PFM_Details : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string Entered_By;
    DateTime Entered_On;
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            if (!IsPostBack)
            {

               // btnTransferFlight.Attributes.Add("onclick", "return CheckEmpty_ddl();");
                FillGrid();
                //FillGvPFM();
              FillGvFINALPFM();
              // LoadOpenFlight();
                string Air_Detail_Id = Request.QueryString["AID"];
                DataTable dt_Air = dw.GetAllFromQuery("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID ='" + Air_Detail_Id + "' order by Airline_Name");
                if (dt_Air.Rows.Count > 0)
                {
                    lblAirline.Text = dt_Air.Rows[0]["Airline"].ToString();
                    lblFNo.Text = "["+Request.QueryString["fno"]+"]-";
                    lblFdate.Text = "[" + Request.QueryString["date"] + "]";
                }
                if (Request.QueryString["State"] != null)
                {
                    if (Request.QueryString["State"].ToString() == "Added")
                    {
                        lblMsg.Text = "Added Successfully";
                    }
                    else if (Request.QueryString["State"].ToString() == "Updated")
                    {
                        lblMsg.Text = "Updated Successfully";
                    }

                    else
                    {
                        lblMsg.Text = "";
                    }
                }
            }
        }
    }

   
    public void FillGrid()
    {
        try
        {

            string Air_code = Request.QueryString["Airline_code"];
            string CITY_ID = Request.QueryString["city_id"];
            string Flight_Open_Id = Request.QueryString["fid"];
            string Air_Detail_Id = Request.QueryString["AID"];
            string FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");

            //string strAgent = "SELECT BM.BOOKING_ID,SM.AIRWAYBILL_NO FROM BOOKING_MASTER BM INNER JOIN STOCK_MASTER SM ON BM.STOCK_ID=SM.STOCK_ID WHERE (SM.STATUS=3 OR SM.STATUS=9) AND SUBSTRING(SM.AIRWAYBILL_NO,1,3)='" + Air_code + "' AND SM.CITY_ID=" + CITY_ID + " AND BM.FLIGHT_DATE>='" + FLIGHT_DATE + "'";  

            //string strAgent = "SELECT p.handover_id,P.PFM_ID,(cast(P.PFM_ID as varchar(max))+'-'+ cast(p.handover_id as varchar(max)))as PFMID,P.Flight_Open_ID, P.AIRWAYBILL_NO,P.Flight_No,P.Airline_Detail_ID,P.FLIGHT_DATE,P.NO_OF_PACKAGES,P.GROSS_WEIGHT,P.VOLUME_WEIGHT,D.DESTINATION_CODE,P.Location,P.Shipping_Bill_No,P.Location_Date FROM PFM P inner join handover hm on hm.handover_id=p.handover_id inner join destination_master d on P.destination_ID=d.destination_id  WHERE P.FLIGHT_OPEN_ID=" + Request.QueryString["fid"] + " and hm.pfm_status=13 AND MANIFEST_STATUS=14 order by P.AIRWAYBILL_NO ";

            //string strAgent = "SELECT Part_Shipment_Status,HM.HANDOVER_ID,(cast(P.PFM_ID as varchar(max))+'-'+ cast(p.handover_id as varchar(max)))as PFMID,HM.STOCK_ID ,SM.AIRWAYBILL_NO,HM.No_of_Packages as Total_PCS,HM.Gross_Weight as Total_GWT,HM.Volume_Weight as Total_VWT,CASE WHEN Part_Shipment_Status=13 THEN (CAST(ISNULL(HM.No_of_Packages -(SELECT SUM(PD.No_of_Packages) FROM Partial_Shipment_Details PD WHERE PD.Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0) AS VARCHAR(MAX))+'/'+CAST(HM.No_of_Packages AS VARCHAR(MAX))) ELSE CAST(HM.No_of_Packages AS VARCHAR(MAX)) END AS 'No_of_Packages',CASE WHEN Part_Shipment_Status=13 THEN CAST(ISNULL(HM.Gross_Weight -(SELECT SUM(Gross_Weight) FROM Partial_Shipment_Details  WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0)AS VARCHAR(MAX))+'/'+CAST(HM.Gross_Weight AS VARCHAR(MAX))ELSE CAST(HM.Gross_Weight AS VARCHAR(MAX)) END AS Gross_Weight,CASE WHEN Part_Shipment_Status=13 THEN CAST(ISNULL(HM.Volume_Weight -(SELECT SUM(Volume_Weight) FROM Partial_Shipment_Details WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0) AS VARCHAR(MAX))+'/'+CAST(HM.Volume_Weight AS VARCHAR(MAX))ELSE CAST(HM.Volume_Weight AS VARCHAR(MAX)) END AS Volume_Weight,Destination_CODE ,FM.FLIGHT_NO,convert(varchar,HM.FLIGHT_DATE,103) as FLIGHT_DATE,P.Location,P.Shipping_Bill_No,P.Location_Date  FROM Handover HM INNER JOIN PFM P ON P.HANDOVER_ID=HM.HANDOVER_ID INNER JOIN FLIGHT_OPEN FO ON HM.FLIGHT_OPEN_ID=FO.FLIGHT_OPEN_ID INNER JOIN FLIGHT_MASTER FM ON FM.FLIGHT_ID=FO.FLIGHT_ID INNER JOIN STOCK_MASTER SM ON HM.STOCK_ID=SM.STOCK_ID INNER JOIN DESTINATION_MASTER DM ON HM.DESTINATION_ID=DM.Destination_ID WHERE P.FLIGHT_OPEN_ID=" + Request.QueryString["fid"] + "and (SM.STATUS=10)  and hm.pfm_status=13   AND (Unshipped_PCS IS NULL OR Unshipped_PCS>0 or  MANIFEST_STATUS=14 ) order by Part_Shipment_Status, SM.AIRWAYBILL_NO";

            string strAgent = "SELECT Part_Shipment_Status,p.handover_id,P.PFM_ID,(cast(P.PFM_ID as varchar(max))+'-'+ cast(p.handover_id as varchar(max)))as PFMID,P.Flight_Open_ID, CASE WHEN Part_Shipment_Status=13 THEN P.AIRWAYBILL_NO+'<span style=color:Red;font-family:Verdana;font-size:large;>P</span>' ELSE P.AIRWAYBILL_NO END AS AIRWAYBILL_NO,P.Flight_No,P.Airline_Detail_ID,P.FLIGHT_DATE,CASE WHEN Part_Shipment_Status=13 THEN ISNULL(HM.No_of_Packages -(SELECT SUM(No_of_Packages) FROM Partial_Shipment_Details WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0) ELSE HM.No_of_Packages END AS No_of_Packages,CASE WHEN Part_Shipment_Status=13 THEN ISNULL(HM.Gross_Weight -(SELECT SUM(Gross_Weight) FROM Partial_Shipment_Details WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0)ELSE HM.Gross_Weight END AS Gross_Weight,CASE WHEN Part_Shipment_Status=13 THEN ISNULL(HM.Volume_Weight -(SELECT SUM(Volume_Weight) FROM Partial_Shipment_Details WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0)ELSE HM.Volume_Weight END AS Volume_Weight,DM.DESTINATION_CODE,P.Location,P.Shipping_Bill_No,P.Location_Date  FROM Handover HM INNER JOIN PFM P ON P.HANDOVER_ID=HM.HANDOVER_ID INNER JOIN FLIGHT_OPEN FO ON HM.FLIGHT_OPEN_ID=FO.FLIGHT_OPEN_ID INNER JOIN FLIGHT_MASTER FM ON FM.FLIGHT_ID=FO.FLIGHT_ID INNER JOIN STOCK_MASTER SM ON HM.STOCK_ID=SM.STOCK_ID INNER JOIN DESTINATION_MASTER DM ON HM.DESTINATION_ID=DM.Destination_ID WHERE P.FLIGHT_OPEN_ID=" + Request.QueryString["fid"] + "and (SM.STATUS=10)  and hm.pfm_status=13   AND (Unshipped_PCS IS NULL OR Unshipped_PCS>0 )and   MANIFEST_STATUS=14 order by Part_Shipment_Status, SM.AIRWAYBILL_NO";
            
            DataTable dt_Hand = dw.GetAllFromQuery(strAgent);
            if (dt_Hand.Rows.Count > 0)
            {
                GridView1.DataSource = dt_Hand;
                GridView1.DataBind();
           

                 foreach (GridViewRow gv in GridView1.Rows)
                    {
                        DropDownList ddlflight = (DropDownList)gv.FindControl("ddltransferFlt");
                

                strAgent = "select Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_Code as origin,d.destination_Code as destination,b.Capacity,convert(Varchar,a.Flight_Date,103)as Flight_Date,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate,s.status_name ,a.Flight_Open_ID,a.Import_Flight_Open_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id inner join status_master s on a.status=s.status_ID and b.airline_detail_id='" + Request.QueryString["AID"] + "' and a.flight_date>='" + DateTime.Parse(DateTime.Now.ToShortDateString()) + "' and b.status=2 order by a.Flight_Date desc";

                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(strAgent, con);
                SqlDataReader dr = com.ExecuteReader();
                ddlflight.Items.Clear();
                ddlflight.Items.Insert(0, "- -Select- -");
                ddlflight.Items[0].Value = "0";
               
                while (dr.Read())
                {
                    ddlflight.Items.Add(new ListItem(dr["flight_No"].ToString() + ":" + dr["Flight_date"].ToString(), dr["Flight_Open_id"].ToString()));
                }
                con.Close();

                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkmodify");
                
                ChkBxItem.Attributes.Add("onclick", " returntohand(this.id);");
                CheckBox chkmain = (CheckBox)gv.FindControl("chkMain");
                chkmain.Attributes.Add("onclick", " resetdropdownlist(this.id);");
                RadioButtonList rd = (RadioButtonList)gv.FindControl("rdnBut");
                rd.Attributes.Add("onclick", "resetddlflighttrans(this.id);");
                TextBox TxtP = (TextBox)gv.FindControl("TxtP");
                TxtP.Attributes.Add("onblur", "setlblTxtPvalue(this.id);");
                chkmain.Checked = true;
                 }
              
               
              
            }
            else
            {
                
                GridView1.DataSource = null;
                GridView1.DataBind();
                BtnSave.Visible = false;
                //ddltransferFlt.Visible = false;
                //lblFlight.Visible = false;
                //btnTransferFlight.Visible = false;
                
                //lblEmpty.Text = "No Data Found.";
                //lblEmpty.CssClass = "boldtext";
            }
            
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();             
                   
             
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void FillGvFINALPFM()
    {
        try
        {

            string Air_code = Request.QueryString["Airline_code"];
            string CITY_ID = Request.QueryString["city_id"];
            string Flight_Open_Id = Request.QueryString["fid"];
            string Air_Detail_Id = Request.QueryString["AID"];
            string FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");

            //string strAgent = "SELECT BM.BOOKING_ID,SM.AIRWAYBILL_NO FROM BOOKING_MASTER BM INNER JOIN STOCK_MASTER SM ON BM.STOCK_ID=SM.STOCK_ID WHERE (SM.STATUS=3 OR SM.STATUS=9) AND SUBSTRING(SM.AIRWAYBILL_NO,1,3)='" + Air_code + "' AND SM.CITY_ID=" + CITY_ID + " AND BM.FLIGHT_DATE>='" + FLIGHT_DATE + "'";  






            string strAgent = "SELECT SUBSTRING(P.AIRWAYBILL_NO,5,20)AS AIRWAYBILL_NO,P.NO_OF_PACKAGES,P.NATURE_AND_QUANTITY,P.GROSS_WEIGHT,DESTINATION_CODE,P.Location,P.Shipping_Bill_No,P.Location_Date FROM  PFM P  INNER JOIN DESTINATION_MASTER DM ON P.DESTINATION_ID=DM.DESTINATION_ID WHERE Manifest_Status=13 AND P.Flight_Open_ID=" + Flight_Open_Id + " order by P.AIRWAYBILL_NO desc";

                    DataTable dt_GVPFM = dw.GetAllFromQuery(strAgent);
                    if (dt_GVPFM.Rows.Count > 0)
                    {
                        int Total_PCS = 0;
                           string Table = "";
                Table += @"<Table width=100% align=center border=1  cellpadding=1>";
                Table += @"<tr style='background-color: aqua; text-align: center' class=h5>";
                //Table += @"<td  style='text-align:left;' class=boldtext colspan=9> <a href='./Reports/Print_PFM.aspx?fid=" + Flight_Open_Id + "&AID=" + Request.QueryString["AID"] + "&city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fno=" + Request.QueryString["fno"] + "&date=" + Request.QueryString["date"] + "&GID=" + PFM_GROUP_ID + "'  target=_blank>a</a></td>";

                Table += @"</tr>";
                Table += @"<tr style='background-color: aqua; text-align: center' class=h5>";
                Table += @"<td  style='text-align:center;' class=boldtext>AWB NO.</td>";
                Table += @"<td  style='text-align:center;' class=boldtext>PCS</td>";
                Table += @"<td  style='text-align:center;' class=boldtext>On Hand Comm</td>";
                Table += @" <td  style='text-align:center;' class=boldtext>Gross Wt(Kilos)</td>";

                Table += @"<td  style='text-align:center;' class=boldtext>Final Dest.</td>";
                Table += @"<td  style='text-align:center;' class=boldtext>SBNo</td>";
                Table += @"<td  style='text-align:center;' class=boldtext>Loc</td>";
                
                Table += @"</tr>";
                       
                        for (int j = 0; j < dt_GVPFM.Rows.Count; j++)
                        {
                            Table += @"<tr >";
                            Table += @"<td  style='text-align:center;' width=10% class=text>" + dt_GVPFM.Rows[j]["AirWayBill_No"].ToString() + "&nbsp;</td>";
                            Table += @"<td  style='text-align:right;' width=5% class=text>" + dt_GVPFM.Rows[j]["No_of_Packages"].ToString() + "&nbsp;</td>";

                            Table += @"<td  style='text-align:center;' width=10% class=text>" + dt_GVPFM.Rows[j]["Nature_and_Quantity"].ToString() + "&nbsp;</td>";
                            Table += @"<td  style='text-align:right;' width=7% class=text>" + dt_GVPFM.Rows[j]["Gross_Weight"].ToString() + " &nbsp;</td>";
                          
                            Table += @" <td  style='text-align:center;' width=5% class=text>" + dt_GVPFM.Rows[j]["Destination_CODE"].ToString() + "&nbsp;</td>";

                            Table += @" <td  style='text-align:center;' width=5% class=text>" + dt_GVPFM.Rows[j]["Shipping_Bill_No"].ToString() + "&nbsp;</td>";
                            Table += @" <td  style='text-align:center;' width=5% class=text>" + dt_GVPFM.Rows[j]["Location"].ToString() + "&nbsp;</td>";
                            Table += @"</tr>";
                            Total_PCS = Total_PCS +int.Parse(dt_GVPFM.Rows[j]["No_of_Packages"].ToString());

                        }
                        Table += @"<tr >";
                        Table += @"<td  style='text-align:center;' width=10% class=boldtext>&nbsp;</td>";
                        Table += @"<td  style='text-align:right;' width=5% class=boldtext>" + Total_PCS + "</td>";

                        Table += @"<td  style='text-align:center;' width=10% class=boldtext>&nbsp;</td>";
                        Table += @"<td  style='text-align:right;' width=7% class=boldtext> &nbsp;</td>";

                        Table += @" <td  style='text-align:center;' width=5% class=boldtext>&nbsp;</td>";

                        Table += @"<td  style='text-align:right;' width=7% class=boldtext> &nbsp;</td>";

                        Table += @" <td  style='text-align:center;' width=5% class=boldtext>&nbsp;</td>";
                        Table += @"</tr>";
                        Table += @"</table>";
                        lblPFM.Text = Table;
                    }

                 
           
               
       

            else
            {
                lnkPrint.Visible = false;
                lblPFM.Text = "No AWB Added To Manifest";
                lblPFM.CssClass = "boldtext";
            }

            //con = new SqlConnection(strCon);
            //con.Open();
            //com = new SqlCommand(strAgent, con);
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataSet ds = new DataSet();
            //da.Fill(ds);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    lnkPnt.Visible = true;
            //}
            //else
            //{
            //    lnkPnt.Visible = false;
            //}

            //GvPfm.DataSource = ds;
            //GvPfm.DataBind();


        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    protected void Modify(object sender, CommandEventArgs e)
    {
        string Hand_id = e.CommandName;
        string[] PFMID = Hand_id.Split('-');
        Entered_By = Session["EMailID"].ToString();
        Entered_On = DateTime.Now;
        using (con)
        {
            string strQuery = "";
            SqlCommand cmd;
            con = new SqlConnection(strCon);
            con.Open();
            SqlTransaction tr = con.BeginTransaction();
            try
            {
                DataTable dt = dw.GetAllFromQuery("Select Part_Shipment_Status FROM HANDOVER Where Handover_ID=" + PFMID[1] + "");
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["Part_Shipment_Status"].ToString() == "13")
                    {
                        strQuery = "Update HANDOVER SET PFM_Status=31,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + PFMID[1] + "";
                        cmd = new SqlCommand(strQuery, con, tr);
                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        strQuery = "Update PFM SET PFM_Group_ID=null, Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + PFMID[1] + "";
                        cmd = new SqlCommand(strQuery, con, tr);
                        cmd.ExecuteNonQuery();

                        //*************************************************************************//
                        strQuery = "Update HANDOVER SET PFM_Status=31,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + PFMID[1] + "";
                        cmd = new SqlCommand(strQuery, con, tr);

                        cmd.ExecuteNonQuery();
                    }
                }

                tr.Commit();
                lblMsg.Visible = true;
                lblMsg.Text = "AWB successfully added to On Hand";
                FillGrid();
                FillGvFINALPFM();
            }
            catch (Exception Ex)
            {
                Response.Write(Ex.Message);
                tr.Rollback();
            }

        }


    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        string fid = Request.QueryString["fid"];
        string CITY_ID = Request.QueryString["city_id"];
        string Air_code = Request.QueryString["Airline_code"];
        string FDATE = Request.QueryString["date"];
        Response.Redirect("Add_To_PFM.aspx?Action=add&fid=" + fid + "&AID=" + Request.QueryString["AID"] + "&city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fno=" + Request.QueryString["fno"] + "&date=" + FDATE);
    }
    protected void lnkPrint_Click(object sender, EventArgs e)
    {
        string fid = Request.QueryString["fid"];
        string CITY_ID = Request.QueryString["city_id"];
        string Air_code = Request.QueryString["Airline_code"];
        string FDATE = Request.QueryString["date"];
        string Air_Detail_Id = Request.QueryString["AID"];       
     
        string url = "Print_FinalManifest.aspx?fid=" + fid + "&AID=" + Request.QueryString["AID"] + "&city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fno=" + Request.QueryString["fno"] + "&date=" + FDATE + "";
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
       

        long Part_Shipment_ID =0;
        string strRightsString = "";
        string strQuery = "";
        Entered_By = Session["EMailID"].ToString();
       Entered_On = DateTime.Now;
       foreach (GridViewRow gv in GridView1.Rows)
       {
           CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
           CheckBox chkmodify = (CheckBox)gv.FindControl("chkmodify");

           if (ChkBxItem.Checked)
           {
               strRightsString = ((Label)gv.FindControl("lblHID")).Text.ToString();
               string Date = ConvertDate1(Request.QueryString["date"]);
               using (con)
               {
                   SqlCommand cmd;
                   con = new SqlConnection(strCon);
                   con.Open();
                   SqlTransaction tr = con.BeginTransaction();

                   try
                   {
                       RadioButtonList rd = (RadioButtonList)gv.FindControl("rdnBut");
                       if (rd.SelectedItem.Value == "1")
                       {
                           int Total_PACKAGES = int.Parse(((Label)gv.FindControl("lblPCs")).Text.ToString());
                           int Current_PACKAGES = 0;
                           if (((TextBox)gv.FindControl("TxtP")).Text.ToString() == "")
                           {
                               lblMsg.Text = "Pcs Should Not be blank in Partial shipment";
                               break;
                           }
                           else
                           {
                               Current_PACKAGES = int.Parse(((TextBox)gv.FindControl("TxtP")).Text.ToString());
                           }
                           DataTable dt = dw.GetAllFromQuery("SELECT  No_of_Packages,CASE WHEN No_of_Packages=0 THEN 0 ELSE cast((Gross_Weight/No_of_Packages) as decimal(18,0)) END AS Grwt_1Pc,CASE WHEN No_of_Packages=0 THEN 0 ELSE CAST((Volume_Weight/No_of_Packages) AS DECIMAL(18,0)) END as Vwt_1Pc,UNSHIPPED_PCS,Flight_Open_ID,Stock_ID,Destination_ID FROM HANDOVER WHERE HANDOVER_ID=" + strRightsString + "");
                           if (dt.Rows.Count > 0)
                           {
                               decimal Current_Grwt = decimal.Parse(dt.Rows[0]["Grwt_1Pc"].ToString()) * Current_PACKAGES;
                               decimal Current_Vwt = decimal.Parse(dt.Rows[0]["Vwt_1Pc"].ToString()) * Current_PACKAGES;

                               if (dt.Rows[0]["UNSHIPPED_PCS"].ToString() == null || dt.Rows[0]["UNSHIPPED_PCS"].ToString() == "")
                               {
                                   using (con)
                                   {

                                       int Unshipped = Total_PACKAGES - Current_PACKAGES;
                                       strQuery = "INSERT INTO Partial_Shipment_Details(Handover_Id,Flight_Open_ID,Stock_ID,Destination_ID,No_of_Packages,Gross_Weight,Volume_Weight,Entered_By, Entered_On)VALUES(" + strRightsString + "," + dt.Rows[0]["Flight_Open_ID"].ToString() + "," + dt.Rows[0]["Stock_ID"].ToString() + "," + dt.Rows[0]["Destination_ID"].ToString() + "," + Current_PACKAGES + "," + Current_Grwt + "," + Current_Vwt + ",'" + Entered_By + "','" + Entered_On + "')";

                                       cmd = new SqlCommand(strQuery, con, tr);
                                       cmd.ExecuteNonQuery();
                                       //*************************************************************************//

                                       DataTable dtIDENT = dw.GetAllFromQuery("select ident_current('Partial_Shipment_Details') as Part_Shipment_ID");
                                       Part_Shipment_ID = long.Parse(dtIDENT.Rows[0]["Part_Shipment_ID"].ToString());

                                       strQuery = "Update PFM SET Manifest_Status=13 ,Part_Shipment_ID=" + Part_Shipment_ID + ",NO_OF_PACKAGES=" + Current_PACKAGES + " ,Gross_Weight=" + Current_Grwt + ",Volume_Weight=" + Current_Vwt + " ,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                                       cmd = new SqlCommand(strQuery, con, tr);
                                       cmd.ExecuteNonQuery();

                                       //*************************************************************************//
                                       strQuery = "Update HANDOVER SET UNSHIPPED_PCS=" + Unshipped + ",Part_Shipment_Status=13,PFM_Status=31,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                                       cmd = new SqlCommand(strQuery, con, tr);

                                       cmd.ExecuteNonQuery();


                                       tr.Commit();
                                   }
                               }
                               else
                               {
                                   DataTable dt_PFM = dw.GetAllFromQuery("SELECT Flight_No,Flight_Date,Stock_ID,Destination_ID,Airline_Detail_ID,PFM_Group_ID,AirWayBill_No,Nature_and_Quantity,Location,Shipping_Bill_No,Location_Date,Manifest_Status,Entered_By,Entered_Date,Last_Modified_By,Last_Modified_On FROM PFM WHERE HANDOVER_ID=" + strRightsString + "");
                                   if (dt_PFM.Rows.Count > 0)
                                   {
                                       using (con)
                                       {
                                           int UnPCS = int.Parse(dt.Rows[0]["UNSHIPPED_PCS"].ToString()) - Current_PACKAGES;

                                           strQuery = "INSERT INTO Partial_Shipment_Details(Handover_Id,Flight_Open_ID,Stock_ID,Destination_ID,No_of_Packages,Gross_Weight,Volume_Weight,Entered_By, Entered_On)VALUES(" + strRightsString + "," + dt.Rows[0]["Flight_Open_ID"].ToString() + "," + dt.Rows[0]["Stock_ID"].ToString() + "," + dt.Rows[0]["Destination_ID"].ToString() + "," + Current_PACKAGES + "," + Current_Grwt + "," + Current_Vwt + ",'" + Entered_By + "','" + Entered_On + "')";

                                           cmd = new SqlCommand(strQuery, con, tr);
                                           cmd.ExecuteNonQuery();
                                           //*************************************************************************//
                                           //strQuery = "INSERT INTO PFM (Handover_ID,Flight_Open_ID,Flight_No,Flight_Date,Stock_ID,Destination_ID,Airline_Detail_ID,PFM_Group_ID,AirWayBill_No,No_of_Packages,Gross_Weight,Volume_Weight,Nature_and_Quantity,Location,Shipping_Bill_No,Location_Date,Manifest_Status,Entered_By,Entered_Date) VALUES(" + strRightsString + "," + Request.QueryString["fid"] + ",'" + Request.QueryString["fno"] + "','" + Date + "'," + dt_PFM.Rows[0]["Stock_ID"].ToString() + "," + dt_PFM.Rows[0]["Destination_ID"].ToString() + "," + dt_PFM.Rows[0]["Airline_Detail_ID"].ToString() + "," + Convert.ToString(dt_PFM.Rows[0]["PFM_Group_ID"]) + ",'" + dt_PFM.Rows[0]["AirWayBill_No"].ToString() + "'," + Current_PACKAGES + "," + Current_Grwt + "," + Current_Vwt + ",'" + Convert.ToString(dt_PFM.Rows[0]["Nature_and_Quantity"]) + "','" + Convert.ToString(dt_PFM.Rows[0]["Location"]) + "','" + Convert.ToString(dt_PFM.Rows[0]["Shipping_Bill_No"]) + "','" + Convert.ToString(dt_PFM.Rows[0]["Location_Date"]) + "',13,'" + Entered_By + "','" + Entered_On + "')";
                                           DataTable dtIDENT = dw.GetAllFromQuery("select ident_current('Partial_Shipment_Details') as Part_Shipment_ID");
                                           Part_Shipment_ID = long.Parse(dtIDENT.Rows[0]["Part_Shipment_ID"].ToString());

                                           strQuery = "Update PFM SET Manifest_Status=13 ,Part_Shipment_ID=" + Part_Shipment_ID + ",NO_OF_PACKAGES=" + Current_PACKAGES + " ,Gross_Weight=" + Current_Grwt + ",Volume_Weight=" + Current_Vwt + " ,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                                           cmd = new SqlCommand(strQuery, con, tr);
                                           cmd.ExecuteNonQuery();

                                           
                                           //*************************************************************************//
                                           if (UnPCS > 0)
                                           {
                                               strQuery = "Update HANDOVER SET UNSHIPPED_PCS=" + UnPCS + ",PFM_Status=31,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                                             
                                           }
                                           else
                                           {
                                               strQuery = "Update HANDOVER SET UNSHIPPED_PCS=" + UnPCS + ",Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                                               

                                             
                                           }
                                           cmd = new SqlCommand(strQuery, con, tr);

                                           cmd.ExecuteNonQuery();
                                           
                                           tr.Commit();
                                       }

                                   }
                               }
                           }


                       }
                       else
                       {


                           using (con)
                           {


                               strQuery = "Update Handover SET Unshipped_PCS=0,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "'  Where Handover_ID=" + strRightsString + "";
                               cmd = new SqlCommand(strQuery, con, tr);

                               cmd.ExecuteNonQuery();


                               strQuery = "Update PFM SET Manifest_Status=13,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                               cmd = new SqlCommand(strQuery, con, tr);

                               cmd.ExecuteNonQuery();
                               tr.Commit();

                           }
                       }


                       lnkPrint.Visible = true;
                       FillGrid();
                       FillGvFINALPFM();
                   }
                   catch (SqlException ex)
                   {
                       Response.Write(ex.Message);
                       tr.Rollback();
                   }
                   finally
                   {
                       if (con != null && con.State == ConnectionState.Open)
                           con.Close();
                   }


               }


           }
           else
           {
               strRightsString = ((Label)gv.FindControl("lblHID")).Text.ToString();
               string Date = ConvertDate1(Request.QueryString["date"]);
               using (con)
               {
                   SqlCommand cmd;
                   con = new SqlConnection(strCon);
                   con.Open();
                   SqlTransaction tr = con.BeginTransaction();
                   try
                   {
                       DataTable dt = dw.GetAllFromQuery("Select Part_Shipment_Status FROM HANDOVER Where Handover_ID=" + strRightsString + "");
                       if (dt.Rows.Count > 0)
                       {
                           if (dt.Rows[0]["Part_Shipment_Status"].ToString() == "13")
                           {
                               strQuery = "Update HANDOVER SET PFM_Status=31,Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                               cmd = new SqlCommand(strQuery, con, tr);
                               cmd.ExecuteNonQuery();
                           }
                           else
                           {
                               strQuery = "INSERT INTO PFM_History SELECT * FROM pfm WHERE Handover_ID="+ strRightsString + "";
                               cmd = new SqlCommand(strQuery, con, tr);
                               cmd.ExecuteNonQuery();

                               strQuery = "delete from pfm Where Handover_ID=" + strRightsString + "";
                               cmd = new SqlCommand(strQuery, con, tr);
                               cmd.ExecuteNonQuery();

                               //*************************************************************************//
                               DropDownList ddltransferFlt = (DropDownList)gv.FindControl("ddltransferFlt");
                               string[] fltDate = ddltransferFlt.SelectedItem.Text.Split(':');

                               string Flight_date = FormatDateMM(fltDate[1].ToString());
                               string flightno = fltDate[0].ToString();
                               string fltOpenID = ddltransferFlt.SelectedValue;

                               strQuery = "Update HANDOVER SET PFM_Status=31, flight_open_id='" + fltOpenID + "', flight_date='" + Flight_date + "', Last_Modified_By='" + Entered_By + "',Last_Modified_On='" + Entered_On + "' Where Handover_ID=" + strRightsString + "";
                               cmd = new SqlCommand(strQuery, con, tr);

                               cmd.ExecuteNonQuery();
                           }
                       }

                       tr.Commit();
                       lblMsg.Visible = true;
                       lblMsg.Text = "AWB successfully added to On Hand";
                       FillGrid();
                       FillGvFINALPFM();



                   }

                   catch (SqlException ex)
                   {
                       Response.Write(ex.Message);
                       tr.Rollback();
                   }
                   finally
                   {
                       if (con != null && con.State == ConnectionState.Open)
                           con.Close();
                   }
               }
           
           
           }




       }
                               
                                        
        
    }

    //protected void rdnBut_SelectedIndexChanged(object sender, EventArgs e)
    //{

    //    RadioButtonList rb = new RadioButtonList();
    //    rb = (RadioButtonList)sender;
    //  string test=  rb.SelectedItem.Value;
    //  string  sRbText = rb.Text;
    //  if (rb.Text == "1")
    //  {
    //      GridView1.Columns[10].Visible = true;

    //  }
    //  else
    //  {
    //      GridView1.Columns[10].Visible = false;
    //  }
        
     
     
    //}
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
       
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            
            //LinkButton db = (LinkButton)e.Row.Cells[11].FindControl("lblModify");
            //db.OnClientClick = string.Format("javascript: return confirm('Are you Sure, you want to return back this AWB in On Hand ?');");
            //Label lb = (Label)e.Row.Cells[12].FindControl("PartShpStatus");
            
        }
        
    }

    //protected void btnTransferFlight_Click(object sender, EventArgs e)
    //{
    //    string AwbNo = "";
    //    foreach (GridViewRow gv in GridView1.Rows)
    //    {
    //        CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
    //        Label lblairwaybill = (Label)gv.FindControl("lblhand");

    //        if (ChkBxItem.Checked)
    //        {
    //            AwbNo+="'"+ lblairwaybill.Text+"'"+',';
    //        }


    //    }




    //    if (AwbNo == "")
    //    {
    //        string strScript = "alert('Please Check shipment to transfer.');";

    //        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
    //    }


    //    else if (ddltransferFlt.SelectedValue == "- -Select- -")
    //    {
    //        string strScript1 = "alert('Please select flight to transfer.');";

    //        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox2", strScript1, true);
    //    }
    //    else
    //    {
    //        string Booking_id = "";
    //        //string AwbNo = "";
    //        //awbno = awbno.TrimEnd(',');
    //        //string[] awbNos = awbno.Split(',');
    //        //foreach (string str in awbNos)
    //        //{
    //        //    AwbNo += "'" + str + "'" + ",";
    //        //}
    //        AwbNo = AwbNo.TrimEnd(',');
    //        //AwbNo = AwbNo.Replace("'on',", "");
    //        // AirwayBill_No += "'" + dr["airwaybill_no"].ToString() + "'" + ",";

    //        string[] fltDate = ddltransferFlt.SelectedItem.Text.Split(':');
    //        string Flight_date = FormatDateMM(fltDate[1].ToString());
    //        string fltOpenID = ddltransferFlt.SelectedValue;
    //        DataTable dtBooking_id = dw.GetAllFromQuery("select b.stock_id,Booking_id from booking_master b inner join stock_master sm on b.stock_id=sm.stock_id where sm.airwaybill_no in (" + AwbNo + ")");
    //        if (dtBooking_id.Rows.Count > 0)
    //        {
    //            for (int i = 0; i < dtBooking_id.Rows.Count; i++)
    //            {
    //                Booking_id += dtBooking_id.Rows[i]["Booking_id"].ToString() + ",";
    //            }
    //            Booking_id = Booking_id.TrimEnd(',');

    //            //***************Update In booking_master table********************

    //            SqlCommand com;
    //            con = new SqlConnection(strCon);
    //            con.Open();
    //            com = new SqlCommand("update booking_master set flight_open_id='" + fltOpenID + "', flight_date='" + Flight_date + "' where booking_id in (" + Booking_id + ")", con);

    //            com.ExecuteNonQuery();
    //            con.Close();



    //            //***************Update In Handover table********************
    //            con = new SqlConnection(strCon);
    //            con.Open();
    //            com = new SqlCommand("update handover set flight_open_id='" + fltOpenID + "', flight_date='" + Flight_date + "' where booking_id in (" + Booking_id + ")", con);

    //            com.ExecuteNonQuery();
    //            con.Close();


    //            //***************Update In PFM table********************
    //            DataTable dtHandover = dw.GetAllFromQuery("select handover_Id from handover where stock_id=" + dtBooking_id.Rows[0]["stock_id"].ToString() + "");


    //            DataTable dtFlight = dw.GetAllFromQuery("select fm.flight_No,fm.flight_id,fm.Airline_Detail_Id from flight_master fm inner join flight_open fo on fm.flight_id=fo.flight_id  where fo.flight_open_id=" + fltOpenID + "");

    //            con = new SqlConnection(strCon);
    //            con.Open();
    //            com = new SqlCommand("update pfm set flight_open_id='" + fltOpenID + "', flight_date='" + Flight_date + "',flight_no='" + dtFlight.Rows[0]["flight_No"].ToString() + "',Airline_Detail_Id=" + dtFlight.Rows[0]["Airline_Detail_Id"].ToString() + " where Handover_id in (" + dtHandover.Rows[0]["handover_Id"].ToString() + ")", con);

    //            com.ExecuteNonQuery();
    //            con.Close();

    //            string strScript3 = "alert('Flight transfered successfully.');location.replace('Browse_PFM_Details.aspx');";

    //            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBx", strScript3, true);
    //            // Response.Redirect("FlightTo_PFM.aspx");
    //        }

    //    }
    //}

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    //public void LoadOpenFlight()
    //{
    //    try
    //    {


    //        foreach (GridViewRow gv in GridView1)
    //        {
    //            string strAgent = "";

    //            strAgent = "select Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_Code as origin,d.destination_Code as destination,b.Capacity,convert(Varchar,a.Flight_Date,103)as Flight_Date,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate,s.status_name ,a.Flight_Open_ID,a.Import_Flight_Open_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id inner join status_master s on a.status=s.status_ID and b.airline_detail_id='" + Request.QueryString["AID"] + "' and a.flight_date>='" + DateTime.Parse(DateTime.Now.AddDays(-7).ToShortDateString()) + "' and b.status=2 order by a.Flight_Date desc";

    //            con = new SqlConnection(strCon);
    //            con.Open();
    //            com = new SqlCommand(strAgent, con);
    //            SqlDataReader dr = com.ExecuteReader();
    //            ddltransferFlt.Items.Clear();
    //            ddltransferFlt.Items.Insert(0, "- -Select- -");
    //            //ddlDestination.Items.Insert(0, "- -Select- -");
    //            //ddlDestination.Items[0].Value = "0";
    //            while (dr.Read())
    //            {
    //                ddltransferFlt.Items.Add(new ListItem(dr["flight_No"].ToString() + ":" + dr["Flight_date"].ToString(), dr["Flight_Open_id"].ToString()));
    //            }
    //            con.Close();
    //        }
    //    }
    //    catch (SqlException sqe)
    //    {
    //        string err = sqe.ToString();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }
    //}


}




