using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CPP_FinancialYr : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            btnSearch.Attributes.Add("onclick", "return EmptyCheck()");
            LoadFinancialYear();
            LoadOrigin();

        }
    }

    public void LoadFinancialYear()
    {
        string FinancialYear = String.Empty;

        string CSR_Date = (DateTime.Now.ToShortDateString());

        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[1];
        string strMM = d[0];
        string strYYYY = d[2];

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            ddlFinancialYear.Items.Insert(0, "--Select--");
            ddlFinancialYear.Items[0].Value = "0-0";
            int FYF = 0;
            int FYL = 0;
            FinancialYearFirst = DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = LastYear.ToString();
            FinancialYear = FinancialYearFirst.ToString() + "-" + FinancialYearLast.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);

            FYF = int.Parse(FinancialYearFirst) - 1;
            FYL = int.Parse(FinancialYearLast) - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);

            FYF = FYF - 1;
            FYL = FYL - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);

        }
        else
        {
            ddlFinancialYear.Items.Insert(0, "--Select--");
            ddlFinancialYear.Items[0].Value = "0-0";
            int FYF = 0;
            int FYL = 0;
            FinancialYearLast = DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = LastYear.ToString();
            FinancialYear = FinancialYearFirst.ToString() + "-" + FinancialYearLast.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);


            FYF = int.Parse(FinancialYearFirst) - 1;
            FYL = int.Parse(FinancialYearLast) - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);

            FYF = FYF - 1;
            FYL = FYL - 1;
            FinancialYear = FYF.ToString() + "-" + FYL.ToString();
            ddlFinancialYear.Items.Add(FinancialYear);



        }



    }
    public void LoadOrigin()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select City_ID,City_Code,City_name from City_Master where city_ID in(SELECT DISTINCT CITYID FROM CPP_AgentwiseTotal )", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Clear();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnSearch_Click1(object sender, EventArgs e)
    {
        string[] ddlfnArray = ddlFinancialYear.SelectedItem.Value.Split('-');
        string v_from = "04/01/" + ddlfnArray[0];
        string v_To = "03/31/" + ddlfnArray[1];
        string[] ddlcity_text = ddlOrigin.SelectedItem.Text.Split('-');
        string city_text = ddlcity_text[1];
        string city_value = ddlOrigin.SelectedItem.Value;
        Session["v_from"] = v_from.ToString();
        Session["v_to"] = v_To.ToString();
        Session["city_text"] = city_text.ToString();
        Session["city_value"] = city_value.ToString();
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/CPP_FinancialYRReport.aspx');</script>");
    }
}
