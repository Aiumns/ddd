﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Xml.Schema;

public partial class CsrXml : System.Web.UI.Page
{
    string CityAsStateCode = "DELHI";
    public string page_pop = "";
    string agentName = null;
    string tableAll = "", comName = null;
    string massage = null;
    string city_id = null;
    string tableCSr = "";
    string tableTdsMsg = "";
    string tableTdsExemptedMsg = "";
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string VchType = "";
    string Bill_type = "";
    string Narration = "";

    #region Gst applicable from 01 july 2017
    string CompGstNo = "07";
    string AgentGstNo = "08";

    #endregion end of Gst Applicable

    public string html = "";

    int count = 0;
    decimal TotDr = 0;
    decimal TotCr = 0;
    string companyname = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        #region  Page Load
        DataTable dt = new DataTable();
        if (!Page.IsPostBack)
        {
            #region !ispostback
            if (Session["EMailID"] == null)
            {
                Response.Redirect("./Login.aspx");
            }

            string DateWise = "flight_date";
            string airline_name_city_value = Session["Airline_Detail_id_Tally"].ToString();
            DataTable dtCitycode = dw.GetAllFromQuery("Select City_Code from City_master cm inner join Airline_detail ad on cm.city_id=ad.belongs_to_city where ad.airline_detail_id=" + airline_name_city_value + "");
            DataTable dtAirlineTextname = dw.GetAllFromQuery("Select Airline_name from Airline_Master am inner join Airline_Detail ad on am.airline_id=ad.airline_id where ad.Airline_Detail_id=" + airline_name_city_value + "");
            string airline_name_city_text = dtAirlineTextname.Rows[0]["Airline_name"].ToString();



            ///////////Start:********************Modify Ny Hemant Sharma on 23 July 2014 for Additon of CIN NO**************************/////////
          
                #region Fetching of Airline ID
            string AID = "";
            SqlConnection con1 = new SqlConnection(strCon);
            DataTable dt_AID = dw.GetAllFromQuery("SELECT  Airline_ID FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + airline_name_city_value + "");
            if (dt_AID.Rows.Count > 0)
            {
                AID = dt_AID.Rows[0]["Airline_ID"].ToString();
            }

            #endregion

            ///////////End:********************Modify Ny Hemant Sharma on 23 July 2014 for Additon of CIN NO**************************/////////
            if (airline_name_city_value == "150" || airline_name_city_value == "153" || airline_name_city_value == "163" || airline_name_city_value == "166")
            {
                DateWise = "awb_date";
            }

            string agent_selected_idCSr = "";
            string agent_selected_nameCSr = "";

            DataTable dtagent = dw.GetAllFromQuery("select distinct s.Agent_id,agent_name from sales s inner join agent_master am on s.agent_id=am.agent_id where (" + DateWise + " between '" + Session["From_Tally"] + "'  and  '" + Session["To_Tally"] + "') and airline_detail_id=" + airline_name_city_value + " order by am.Agent_name");
            for (int i = 0; i < dtagent.Rows.Count; i++)
            {

                agent_selected_idCSr = agent_selected_idCSr + dtagent.Rows[i]["Agent_id"] + "~";
                agent_selected_nameCSr = agent_selected_nameCSr + dtagent.Rows[i]["Agent_name"] + "~";

            }


            string[] agent_selected_id = agent_selected_idCSr.Split('~');
            string[] agent_selected_name = agent_selected_nameCSr.Split('~');
            string from_date = Session["From_Tally"].ToString();
            string to_date = Session["To_Tally"].ToString();


            //Gst Approved csr date

            string[] startDate = from_date.Split('/');
            string created_date = DateTime.Now.ToString("dd/MM/yyyy");
            if (int.Parse(startDate[1].ToString()) <= 15)
            {
                created_date = "25/" + startDate[0].ToString() + "/" + startDate[2].ToString();
            }
            else
            {
                if (startDate[0].ToString() == "12")
                {
                    created_date = "10/01/" + (int.Parse(startDate[2].ToString()) + 1);
                }
                else
                {
                    created_date = "10/" + (int.Parse(startDate[0].ToString()) + 1) + "/" + startDate[2].ToString();
                }
            }

            //end of Gst Approved csr date


            ////string rdbtn = Session["rdbtn1"].ToString();
            ////string csrFooter = Session["csr_footer"].ToString();
            string comAdd = null;
            ////string airline = "A/C " + airline_name_city_text.ToUpper().ToString();
            string agnetID = "";

            // CHECK FOR FINANCIAL YEAR
            string sCurrentDate = from_date.ToString();
            DateTime curDate = DateTime.Parse(sCurrentDate);
            string sFinYear = "";
            if (curDate.Month <= 3)
            {
                int startYr = curDate.Year - 1;
                sFinYear = "01/04/" + startYr.ToString() + "-" + DateTime.Parse(from_date).AddDays(-1).ToString("dd/MM/yyyy");
            }
            else
            {
                int endYr = curDate.Year + 1;
                sFinYear = "01/04/" + curDate.Year + "-" + DateTime.Parse(from_date).AddDays(-1).ToString("dd/MM/yyyy");
            }

            string FinancialYear = sFinYear;

            if (Session["groupid"].ToString() != "5")
            {

                //*********** XML Generation*********************

                  #region xml generation
                string xmlString;
                StringWriter sw = new StringWriter();
                XmlTextWriter xw = new XmlTextWriter(sw);
                //XmlWriterSettings setting = new XmlWriterSettings();
                //setting.Indent = true;
                //setting.IndentChars = ("\t");
                //setting.OmitXmlDeclaration = true;
                xw.Formatting = Formatting.Indented;
                xw.WriteStartDocument();

                //************Static Xml Start******************

                xw.WriteStartElement("ENVELOPE");                    //ENVELOPE Starts
                xw.WriteStartElement("HEADER");                    //HEADER Starts
                xw.WriteElementString("TALLYREQUEST", "Import Data");
                xw.WriteEndElement();                        //Header Ends
                xw.WriteStartElement("BODY");                    //Body Starts
                xw.WriteStartElement("IMPORTDATA");                    //DATA Starts
                xw.WriteStartElement("REQUESTDESC");
                xw.WriteElementString("REPORTNAME", "All Masters");
                DataTable dtmcity = dw.GetAllFromQuery("select belongs_to_city as City from Airline_Detail where Airline_Detail_id=" + airline_name_city_value);
                DataTable dtCompNm = dw.GetAllFromQuery("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + dtmcity.Rows[0]["City"].ToString() + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + dtmcity.Rows[0]["City"].ToString() + ")) and city=" + dtmcity.Rows[0]["City"].ToString() + "");
                if (dtCompNm.Rows.Count > 0)
                {
                    string comName = dtCompNm.Rows[0]["company_name"].ToString();
                    companyname = comName;
                    xw.WriteStartElement("STATICVARIABLES");
                    xw.WriteElementString("SVCURRENTCOMPANY", companyname + "-" + airline_name_city_text);
                    xw.WriteEndElement();
                    xw.WriteEndElement();
                    xw.WriteStartElement("REQUESTDATA");
                    
                }

                //**********Static Xml End***************
                for (int k = 0; k < agent_selected_id.Length - 1; k++)
                {                   
                    #region For Loop
                    string sTyep = "";
                    string GSTNO = "";
                    string InvoiceNoAgent = "";
                    decimal CGST = 9;
                    decimal SGST = 9;
                    decimal IGST = 18;

                    decimal TotalCGST = 9;
                    decimal TotalSGST = 9;
                    decimal TotalIGST = 18;
                    decimal TotalGst = 0;

                    decimal TotChAmount = 0;
                    decimal TotDueCar = 0;
                    decimal TotTax = 0;
                    decimal TotValuationCharges = 0;
                    decimal TotAgentExp = 0;
                    decimal TotComm = 0;
                    decimal TotDiscount = 0;
                    decimal TotFrAmount = 0;
                    decimal TotFrAmountCC = 0;
                    decimal TotTds = 0;
                    decimal EduChrg = 0; decimal Total = 0;
                    decimal surCharge = 0;
                    decimal GrandTotal = 0;
                    string lastSurcharge = "0.0000", lastTsdsRate = "0.0000", lastedcess = "0.00";

                    string table = null, table_image = null, table_note = null;
                    agnetID = agent_selected_id[k];
                    agentName = agent_selected_name[k];
                    con = new SqlConnection(strCon);
                    con.Open();

                    string sql_query = "";
                    if (airline_name_city_text.ToString() == "CHINA AIRLINES")
                    {
                        ////////sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                        sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";

                    }
                    else
                    {
                        //////////sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                        sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                    }
                    com = new SqlCommand(sql_query, con);
                    dr = com.ExecuteReader();

                    if (dr.Read())
                    {
                        #region read datareader
                        string csrso = "";
                        string csr = "";
                        city_id = dr["City_ID"].ToString();
                        DataTable dtcity = dw.GetAllFromQuery("Select City_name from City_Master where City_id=" + city_id + "");
                        if (dtcity.Rows.Count > 0 && dtcity != null)
                        {
                            if (dtcity.Rows[0]["City_name"] != "")
                            {
                                CityAsStateCode = dtcity.Rows[0]["City_name"].ToString();
                            }
                        }
                        csrso = dr["csr_sno"].ToString();
                        csr = dr["csr_no"].ToString();
                        com.Dispose();
                        dr.Dispose();
                        com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                        dr = com.ExecuteReader();
                        while (dr.Read())
                        {
                            #region while loop
                            comAdd = dr["company_address"].ToString();
                            string s = dr["company_address"].ToString();
                            char ch = (char)System.Windows.Forms.Keys.Return;
                            char ch2 = (char)System.Windows.Forms.Keys.Space;
                            string ch1 = Convert.ToString(ch);
                            string ch3 = Convert.ToString(ch2);
                            string h = s.Replace(ch1, "<br>");
                            h = h.Replace(ch3, "&nbsp;");
                            if (airline_name_city_value.Trim() == "152")
                            {
                                if (h.Contains("11005"))
                                {
                                    string[] h1 = h.Split('5');
                                    h = h1[0].ToString() + "5";
                                }
                            }

                            comName = dr["company_name"].ToString();
                            companyname = comName;
                            //////xw.WriteStartElement("STATICVARIABLES");
                            //////xw.WriteElementString("SVCURRENTCOMPANY", companyname+"-"+airline_name_city_text);
                            //////xw.WriteEndElement();
                            //////xw.WriteEndElement();
                            //////xw.WriteStartElement("REQUESTDATA");
                            #region Gst CompanyGstNo
                            DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + airline_name_city_value + "");
                            if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
                            {
                                CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                            }
                            if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                            {
                                ////table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr ><td  width=""75%"" align=""center""></td><td   align=""left""><font size=""2""><b>Invoice Date: " + created_date + "</b></font></td></tr></table><br>";
                                ////table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font><br><font size=""1"">GST NO:" + CompGstNo + "</font></p></td></tr></table><br>";
                            }
                            else
                            {
                                ////table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";
                            }
                            #endregion end of Gst CompanyGstNo

                            #endregion
                        }
                        com.Dispose();
                        dr.Dispose();
                        com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                        dr = com.ExecuteReader();
                        if (dr.Read())
                        {
                            string s = dr["agent_address"].ToString();
                            s = s.Replace("\r\n", "");
                            s = s.Replace(",", ", ");
                            char ch = (char)System.Windows.Forms.Keys.Return;
                            char ch2 = (char)System.Windows.Forms.Keys.Space;
                            string ch1 = Convert.ToString(ch);
                            string ch3 = Convert.ToString(ch2);
                            string h = s.Replace(ch1, "<br>");
                            h = h.Replace(ch3, "&nbsp;");
                            if (AID == "160")
                            {
                                table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>CIN NO.U74899DL1993PTC052734</td></tr></table>";
                            }
                            /////// table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</td></tr></table>";
                            //***************Added on 21 may 2014 Invoice_No**************//
                            #region Gst No for Agent

                            string Invoice_No = "";


                            DataTable dtInvoiceNo = dw.GetAllFromQuery("select max(GstInvNo) as GstInvNo,max(csr_sno)as csr_sno,max(GstAddress) as GstAddress from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                            if (dtInvoiceNo.Rows.Count > 0)
                            {
                                #region Using Csr_Sno from Sales table i/o InvoiceNo from Invoice Table
                                ////////Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                                /////DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix +'/'+Fin_Year)as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoicesno"].ToString() + " ");


                                if (dtInvoiceNo.Rows[0]["GstAddress"].ToString() != "")
                                {
                                    s = dtInvoiceNo.Rows[0]["GstAddress"].ToString();
                                    s = s.Replace("\r\n", "");
                                    s = s.Replace(",", ", ");
                                    ch = (char)System.Windows.Forms.Keys.Return;
                                    ch2 = (char)System.Windows.Forms.Keys.Space;
                                    ch1 = Convert.ToString(ch);
                                    ch3 = Convert.ToString(ch2);
                                    h = s.Replace(ch1, "<br>");
                                    h = h.Replace(ch3, "&nbsp;");
                                }




                                string Flight_date = to_date;
                                string[] dateSplit = Flight_date.Split('/');
                                string Month = dateSplit[1].ToString();
                                string Year = dateSplit[2].ToString();
                                string Date1 = dateSplit[0].ToString();
                                ////string currentdate = Month + "/" + Date1 + "/" + Year;
                                string currentdate = Date1 + "/" + Month + "/" + Year;
                                string FinYear = Year.Substring(2, 2);
                                //// string dateCurrent = DateTime.Now.ToShortDateString();

                                /////DateTime CurrDate = DateTime.Now;
                                DateTime CurrDate = DateTime.Parse(currentdate);
                                string DateFinancial = "4/1/20" + FinYear + "";
                                DateTime FinanciaDate = DateTime.Parse(DateFinancial);

                                ////***********updated on 04 Aug 2017 : Invoice No must be sort of 16 digit


                                if (CurrDate < FinanciaDate)
                                {
                                    FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                                }
                                else
                                {
                                    FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                                }


                                DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix + substring(Fin_Year,3,5))as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND Fin_Year='" + FinYear + "'");

                                if (dtInvoice.Rows.Count > 0)
                                {
                                    ///////Updated on 30 May 2017
                                    ////Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();
                                    if (DateTime.Parse(to_date) < DateTime.Parse("08/01/2017"))
                                    {
                                        Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["CSr_Sno"].ToString();
                                    }
                                    else
                                    {
                                        Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["GstInvNo"].ToString();
                                    }
                                    InvoiceNoAgent = Invoice_No;
                                }

                                ////////End of Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                                #endregion

                            }

                            DataTable dtAgentGstNo = dw.GetAllFromQuery("select top 1 (case when gstno is null then Statecode else gstno end) as GstNo from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                            if (dtAgentGstNo != null && dtAgentGstNo.Rows.Count > 0)
                            {
                                if (dtAgentGstNo.Rows[0]["GstNo"].ToString() != "")
                                    AgentGstNo = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                                GSTNO = AgentGstNo;
                            }

                            #region Palce of Delivery and State code
                            string stateCode = CityAsStateCode;
                            DataTable CityCode = dw.GetAllFromQuery("select city_name from city_master where city_id=" + city_id + "");
                            stateCode = CityCode.Rows[0]["city_name"].ToString();
                            DataTable gststateCode = dw.GetAllFromQuery("select state from GstStateCode where stateCode='" + AgentGstNo.Substring(0, 2) + "'");
                            if (gststateCode != null && gststateCode.Rows.Count > 0)
                            {
                                if (gststateCode.Rows[0]["state"].ToString() != "")
                                    stateCode = gststateCode.Rows[0]["state"].ToString();
                            }

                            #endregion end of Palce of Delivery and State code


                            if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                            {
                                table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<br><b>IATA Code:</b>;&nbsp;" + dr["IATA_Code"].ToString() + @"<br><b>INVOICE No:</b>&nbsp;" + Invoice_No + @"<br><b>GST NO:</b>&nbsp;" + AgentGstNo + "<br/><b>State Code:" + stateCode + "<b><br/><b>Place Of Supply: " + stateCode + "<b><br/><b>HSN Code:&nbsp;996531</b><br><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                            }
                            else
                            {
                                table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code: &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b><br/><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                            }
                            //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************

                            #endregion End of Gst No for Agent
                        }
                        com.Dispose();
                        dr.Dispose();

                        #region 
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""100%"" ><tr ><td  width=""100%"" align=""center""><font size=""2""><b><u>TAX INVOICE</u></b></font></td></tr></table><br>";
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"" border=""0"" cellpadding=""2"" 
                                                            cellspacing=""0""><tr class=""h5 boldtext"">
                                <th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th>
                                <th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th>
                                <th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th>
                                <th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th></tr><tr>
                                <th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr><tr>
                                <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""1""></td>
                                </tr>";
                        }
                        else
                        {
                            ////table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""100%"" ><tr ><td  width=""100%"" align=""center""><font size=""2""><b><u>TAX INVOICE</u></b></font></td></tr></table><br>";
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%""
                                border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th>
                                <th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th>
                                <rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th>
                                <th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th>
                                </tr><tr><th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr>
                                <tr><td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""1""></td>
                                </tr>";
                        }
                        //com = new SqlCommand("CSRsort", con);
                        if (airline_name_city_text.ToString() == "CHINA AIRLINES")
                        {
                            ////com = new SqlCommand("CSR_SORT_CHINA", con);
                            com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                            ////com = new SqlCommand("CSR_SORT_CHINA_Temp_TESTProc", con);
                        }
                        else if (airline_name_city_text.ToString() == "MALAYSIAN AIRLINES")
                        {
                            if (from_date == "04/1/2008" && to_date == "04/15/2008")
                            {
                                //////com = new SqlCommand("CSRsort", con);
                                com = new SqlCommand("CSRsort_Temp", con);
                                ////////com = new SqlCommand("csrsort_Temp_TESTPROC", con);
                            }
                            else
                            {
                                ////com = new SqlCommand("CSR_SORT_CHINA", con);
                                com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                                /////////com = new SqlCommand("CSR_SORT_CHINA_Temp_TESTProc", con);
                            }
                        }
                        else
                        {
                            //////com = new SqlCommand("CSRsort", con);
                            if (airline_name_city_value == "158" || airline_name_city_value == "159")
                            {
                                if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                                    com = new SqlCommand("csrsort_Temp", con);
                                else
                                    com = new SqlCommand("csrsort_Temp_KEIATA", con);
                            }
                            else
                            {
                                com = new SqlCommand("csrsort_Temp", con);
                            }

                            ////com = new SqlCommand("csrsort_Temp_TESTPROC", con);
                        }

                        com.CommandType = CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("agent_id", agnetID);
                        com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                        com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                        com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                        // com.Parameters.AddWithValue("DateWise", DateWise);
                        ////DataTable dt = new DataTable();
                        dr = com.ExecuteReader();
                        ///////dt.Load(dr);
                        string VarDate = "07/31/2008";
                        string MH_Period = "08/15/2008";
                        int p = 0;

                        #endregion

                        while (dr.Read())
                        {
                            #region while loop
                            p++;

                            decimal discount = 0;
                            if (dr["AirwayBill_No"].ToString() == "235-70456945")
                            {
                            }
                            //lastTsdsRate = "0.0000";
                            //lastSurcharge = "0.0000";
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    discount = 0;
                                    TotDiscount += 0;
                                    TotComm += 0;
                                    TotAgentExp += 0;

                                }
                                else
                                {
                                    discount = 0;
                                    TotDiscount += 0;
                                    TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    discount = 0;
                                    TotDiscount += 0;
                                    TotComm += 0;
                                    TotAgentExp += 0;
                                }
                                else
                                {
                                    discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    ////////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    //****************Added On 02 dec 2011***************
                                    if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                                    {
                                        DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                        if (dtMinCheck.Rows.Count > 0)
                                        {
                                            if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                            {
                                                TotDiscount += 0;
                                                TotComm += 0;
                                            }

                                            else
                                            {
                                                TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                    //**********************End Of 02 Dec*****************************
                                    //////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                ////////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                //****************Added On 02 dec 2011***************
                                if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                                {
                                    DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                    if (dtMinCheck.Rows.Count > 0)
                                    {
                                        if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                        {
                                            TotDiscount += 0;
                                            TotComm += 0;
                                        }
                                        else
                                        {
                                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                            TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                }

                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }

                                //**********************End Of 02 Dec*****************************
                                //////////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }

                            string ss = dr["Used_Date"].ToString();
                            TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                            TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                            TotValuationCharges += Math.Round(decimal.Parse(dr["Valuation_Charge"].ToString()), MidpointRounding.AwayFromZero);

                            //TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                            ////decimal TotTdsss = Math.Round(decimal.Parse(dr["ONLY_TDS"].ToString()), MidpointRounding.AwayFromZero);
                            decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));

                            if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                            {
                                 #region
                                if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -= 0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }

                                }
                                else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -= 0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                                #endregion
                            }
                            else
                            {
                                #region else part
                                if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                                #endregion
                            }

                            #region mislenious if condition
                            if (dr["tds"].ToString() != "0.0000")
                                lastTsdsRate = dr["tds"].ToString();

                            if (dr["surcharge"].ToString() != "0.0000")
                                lastSurcharge = dr["surcharge"].ToString();

                            if (dr["Education_Cess"].ToString() != "0.0000")
                                lastedcess = dr["Education_Cess"].ToString();

                            string amountPP = null;
                            string amountCC = null;
                            if (dr["Freight_type"].ToString() == "COLLECT")
                            {
                                amountPP = "0";
                                amountCC = dr["Freight_Amount"].ToString();
                                TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                            }
                            else
                            {
                                amountPP = dr["Freight_Amount"].ToString();
                                amountCC = "0";
                                TotFrAmount += Math.Round(decimal.Parse(amountPP));
                            }
                            string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();

                            decimal Comm_Amnt = 0;
                            decimal Agent_Ex = 0;

                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    Comm_Amnt = 0;
                                    Agent_Ex = 0;
                                }
                                else
                                {
                                    Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    Comm_Amnt = 0;
                                    Agent_Ex = 0;
                                }
                                else
                                {
                                    Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                                }
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }

                            //**************************Added On 02 Dec 2011**********************
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                            {
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        discount = 0;
                                        Comm_Amnt = 0;
                                    }
                                }
                            }
                            //**********************End on 02 Dec 2011***********************


                            if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                            {
                                table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Agent_Ex + @"</td><td align=""right"">" + (discount + Comm_Amnt) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                            }
                            else
                            {
                                table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Agent_Ex + @"</td><td align=""right"">" + Comm_Amnt + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                            }

                             sTyep = dr["Sales_Type"].ToString();
                            #endregion

                            #endregion
                        }

                        //lastTsdsRate = "0";

                        com.Dispose();
                        dr.Dispose();

                        #region  html table
                        table += @"<tr> <td colspan=""11"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""1""></td></tr>";

                        //////Total =Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm)),MidpointRounding.AwayFromZero);


                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);

                        table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + Math.Round((TotDiscount + TotComm), MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                        }
                        else
                        {
                            table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                        }

                        table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""1""> </td></tr><tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";


                        #region Gst Applicable from 01Jul2017
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                            {
                                IGST = 0;
                                if (airline_name_city_value == "158" || airline_name_city_value == "159")
                                {
                                    TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                                }
                                else
                                {
                                    TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm)) * IGST / 100);
                                }
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;

                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                                /////Collect Shipment case
                                if (Total < 0)
                                {
                                    if (airline_name_city_value == "158" || airline_name_city_value == "159")
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                    }
                                    else
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount + TotComm)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount + TotComm)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount + TotComm)) * IGST / 100);
                                    }
                                    TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                                    if (TotFrAmountCC > 0)
                                    {
                                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }
                            else
                            {
                                CGST = 0;
                                SGST = 0;
                                if (airline_name_city_value == "158" || airline_name_city_value == "159")
                                {
                                    TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                                }
                                else
                                {
                                    TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm)) * IGST / 100);
                                }
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;

                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                                /////Collect Shipment case
                                if (Total < 0)
                                {
                                    if (airline_name_city_value == "158" || airline_name_city_value == "159")
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                    }
                                    else
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount + TotComm)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount + TotComm)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount + TotComm)) * IGST / 100);
                                    }
                                    TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                    if (TotFrAmountCC > 0)
                                    {
                                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }

                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round((TotDiscount + TotComm)) + @"</strong></td></tr>";
                            table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                            if (TotFrAmountCC > 0)
                            {
                                table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm))) + @"</strong></td></tr>";
                            }

                            else
                            {
                                table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount + TotComm))) + @"</strong></td></tr>";
                            }
                            table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                            if (TotFrAmountCC > 0)
                            {
                                ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>CGST @" + CGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalCGST + @"</strong></td></tr>";
                                ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>SGST @" + SGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalSGST + @"</strong></td></tr>";
                                ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>IGST @" + IGST + @"% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalIGST + @"</strong></td></tr>";
                                ////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total GST@18% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalGst + @"</strong></td></tr>";
                                ////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                            }
                            else
                            {
                                table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>CGST @" + CGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalCGST + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>SGST @" + SGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalSGST + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>IGST @" + IGST + @"% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalIGST + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                                table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total GST@18% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalGst + @"</strong></td></tr>";
                                table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                            }

                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";


                        }

                        #endregion End of Gst Applicable


                    
                        table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            if (TotFrAmountCC > 0)
                            {
                                table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";
                            }
                            else
                            {
                                table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total (Inc Gst)</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";
                            }
                        }
                        else
                            table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";

                        if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                            table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Agent TDS on Discount@" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";


                        if (Math.Round(surCharge) != 0)
                            table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";


                        Decimal Debit_Surcharge = 0;
                        DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");

                        if (dt_Sur.Rows.Count > 0)
                        {
                            Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                                EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                            else
                                EduChrg = Math.Round((((surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                            table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge For the Period  (" + FinancialYear + @") </strong></td><td colspan=""2"" align=""right""><strong>" + Debit_Surcharge + @"</strong></td></tr>";

                        }
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                        string font = null;
                        if (airline_name_city_value == "158" || airline_name_city_value == "159")
                        {
                            GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                        }
                        else
                        {
                            if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                                GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                            else
                                GrandTotal = Total + EduChrg + surCharge + Debit_Surcharge;
                        }
                        if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)) < 0)
                        {
                            massage = "Total Payable To";
                            font = "<font color='red'>";
                            if (airline_name_city_value == "158" || airline_name_city_value == "159")
                            {
                                GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                            }
                            else
                            {
                                if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                                    GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                                else
                                    GrandTotal = Math.Abs(Math.Round((Total + EduChrg + surCharge + Debit_Surcharge)));
                            }
                        }
                        else
                        {
                            massage = "Total Receivable From";
                            font = "<font class='text'>";
                            if (airline_name_city_value == "158" || airline_name_city_value == "159")
                            {
                                GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge));
                            }

                            else
                            {
                                if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                                    GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge));
                                else
                                    GrandTotal = Math.Round((Total + EduChrg + surCharge + Debit_Surcharge));
                            }
                        }

                        if (airline_name_city_value == "168")
                        {
                            table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"">USD &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                        }
                        else
                        {
                            table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right""><img src=""images/rs.gif""> &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                        }

                        if (table != null)
                        {
                            tableAll = tableAll + (table + table_image) + tableTdsMsg + tableTdsExemptedMsg + tableCSr + table_note;
                        }

                        count = count + 1;
                            #endregion

                        ///////*************XML Region Start in Loop*******************

                        #region calculation
                        string Curr_id = string.Empty;

                        string VchType = "";
                        string Bill_type = "";
                        decimal tot_cr = 0;
                        decimal tot_dr = 0;
                        string Curr_id1 = "";
                        string Agent_expenses = "";
                        string Amount="";


                        string datefrom = from_date;
                        string dateTo = to_date;
                        string[] df = datefrom.Split(' ');
                        DateTime df1 = Convert.ToDateTime(df[0].ToString());
                        datefrom = df1.ToString("dd-MMM-yyyy");

                        string[] dto = dateTo.Split(' ');
                        DateTime df2 = Convert.ToDateTime(dto[0].ToString());
                        dateTo = df2.ToString("dd-MMM-yyyy");

                        string fdate = df1.ToString("dd-MM-yy").Replace("-", "");
                        string todate = df2.ToString("dd-MM-yy").Replace("-", "");
                        Narration = "CSR for the period " + datefrom + " - " + datefrom;
                        string Date_XML = Session["Date_Xml"].ToString();
                        string[] dtxml = Date_XML.Split('/');
                        string Xmld = dtxml[0].ToString();
                        string Xmlm = dtxml[1].ToString();
                        string Xmly = dtxml[2].ToString();
                        Date_XML = Xmly + Xmlm + Xmld;

                        VchType = "Sales";
                        Bill_type = "CSR from" + from_date + " - " + to_date; //Should convert into DD/mm/YYYY.
                        ////Narration = "CSR for the period " + from_date.ToString("dd-MMM-yyyy") +" - " + to_date;
                        string RefNo = "";
                        string[] todatefrtnight = to_date.Split('/');
                        string tod = todatefrtnight[1].ToString();
                        string toM = todatefrtnight[0].ToString();
                        string toY = todatefrtnight[2].ToString();
                        DataTable dtMonth = new DataTable();
                        string M = "";
                        if (toM == "1" || toM == "01")
                        {
                            M = "Jan";
                        }
                        else if (toM == "2" || toM == "02")
                        {
                            M = "Feb";
                        }
                        else if (toM == "3" || toM == "03")
                        {
                            M = "Mar";
                        }
                        else if (toM == "4" || toM == "04")
                        {
                            M = "Apr";
                        }
                        else if (toM == "5" || toM == "05")
                        {
                            M = "May";
                        }
                        else if (toM == "6" || toM == "06")
                        {
                            M = "Jun";
                        }
                        else if (toM == "7" || toM == "07")
                        {
                            M = "Jul";
                        }
                        else if (toM == "8" || toM == "08")
                        {
                            M = "Aug";
                        }
                        else if (toM == "9" || toM == "09")
                        {
                            M = "Sep";
                        }
                        else if (toM == "10")
                        {
                            M = "Oct";
                        }
                        else if (toM == "11")
                        {
                            M = "Nov";
                        }
                        else if (toM == "12")
                        {
                            M = "Dec";
                        }
                        if (int.Parse(tod) <= 15)
                        {  
                            RefNo = "1st Fortnight of Month " + M;
                        }

                        else if (int.Parse(tod) > 15 && int.Parse(tod) <= 31)
                        {
                            dtMonth = dw.GetAllFromQuery("select CONVERT(varchar(3), " + DateTime.Parse(to_date) + ", 100) as Month");
                            RefNo = "2nd Fortnight of Month " +M;
                        }
                        #endregion

                        #region Condition for Sales, Debit note and credit note

                        ////if (TotFrAmount > 0)
                        ////{
                        ////    if (sTyep == "INV")
                        ////    {
                        ////        VchType = "Sales";
                        ////        Bill_type = "CSR from" + datefrom + " - " + dateTo;
                        ////        Narration = "CSR for the period " + datefrom + " - " + dateTo;
                        ////    }
                        ////    else
                        ////    {
                        ////        VchType = "Debite Note";
                        ////        Bill_type = "Debit Note from" + datefrom + " - " + dateTo;
                        ////        Narration = "Debit Note for the period " + datefrom + " - " + dateTo;
                        ////    }
                        ////}
                        ////else
                        ////{
                        ////    VchType = "Credit Note";
                        ////    Bill_type = "Credit Note" + datefrom + " - " + dateTo;
                        ////    Narration = "Credit Note for the period " + datefrom + " - " + dateTo;
                        ////}

                        #endregion Condition for Sales, Debit note and credit note

                        #region Condition for Sales, Debit note and credit note


                        ////////string VchType = "";
                        ////////string Bill_type = "";
                        ////////decimal tot_cr = 0;
                        ////////decimal tot_dr = 0;
                        ////////string Curr_id1 = "";
                        ////////string Agent_expenses = "";
                        //////Condition

                        ////////decimal Curr_Frght_Amt = decimal.Parse(dtXml.Rows[i]["Freight_Amount_PP"].ToString()) + decimal.Parse(dtXml.Rows[i]["Total_DueCarrier"].ToString()) - decimal.Parse(dtXml.Rows[i]["Incentive_Amount"].ToString());
                        ////decimal Curr_Frght_Amt = TotFrAmount + TotDueCar;
                        ////////decimal Curr_Frght_Amt = DiscountonNfreight;

                        ////if (Curr_Frght_Amt > 0)
                        ////{
                        ////    Curr_id1 = "CR";
                        ////}
                        ////else
                        ////{
                        ////    Curr_id1 = "DR";
                        ////}
                        ////if (airline_name_city_value == "158" || airline_name_city_value == "159")
                        ////{
                        ////    if (TotTds > 0)
                        ////    {
                        ////        if (sTyep == "INV")
                        ////        {
                        ////            VchType = "Sales";
                        ////            Bill_type = "CSR from" + datefrom + " - " + dateTo;
                        ////            Narration = "CSR for the period " + datefrom + " - " + dateTo;
                        ////        }
                        ////        else
                        ////        {
                        ////            VchType = "Debite Note";
                        ////            Bill_type = "Debit Note from" + datefrom + " - " + dateTo;
                        ////            Narration = "Debit Note for the period " + datefrom + " - " + dateTo;
                        ////        }

                        ////    }

                        ////    else
                        ////    {
                        ////        VchType = "Credit Note";
                        ////        Bill_type = "Credit Note" + datefrom + " - " + dateTo;
                        ////        Narration = "Credit Note for the period " + datefrom + " - " + dateTo;
                        ////    }
                        ////}

                        ////else
                        ////{
                        ////    if (TotFrAmount > 0)
                        ////    {
                        ////        if (sTyep == "INV")
                        ////        {
                        ////            VchType = "Sales";
                        ////            Bill_type = "CSR from" + datefrom + " - " + dateTo;
                        ////            Narration = "CSR for the period " + datefrom + " - " + dateTo;
                        ////        }
                        ////        else
                        ////        {
                        ////            VchType = "Debite Note";
                        ////            Bill_type = "Debit Note from" + datefrom + " - " + dateTo;
                        ////            Narration = "Debit Note for the period " + datefrom + " - " + dateTo;
                        ////        }
                        ////    }
                        ////    else
                        ////    {
                        ////        VchType = "Credit Note";
                        ////        Bill_type = "Credit Note" + datefrom + " - " + dateTo;
                        ////        Narration = "Credit Note for the period " + datefrom + " - " + dateTo;
                        ////    }
                        ////}

                        ////if (airline_name_city_value == "158" || airline_name_city_value == "159")
                        ////{
                        ////    if (TotTds > 0)
                        ////    {
                        ////        Curr_id = "DR";
                        ////        tot_dr = tot_dr + Math.Round(TotTds, 2);
                        ////        Amount = "-" + TotTds.ToString();
                        ////        if (Curr_id1 == "CR")
                        ////        {
                        ////            TotFrAmount = Curr_Frght_Amt;
                        ////        }
                        ////        else
                        ////        {
                        ////            TotFrAmount = decimal.Parse("-") + Curr_Frght_Amt;
                        ////        }
                        ////        TotComm = decimal.Parse("-") + TotComm;
                        ////        TotDiscount = decimal.Parse("-") + TotDiscount;
                        ////        if (Curr_id1 == "CR")
                        ////        {
                        ////            tot_cr = tot_cr + Math.Round(Curr_Frght_Amt, 2);
                        ////            //Amount = "-"+dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                        ////            //Frgt_Amount = "-" + Curr_Frght_Amt.ToString();
                        ////            //Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                        ////        }
                        ////        else
                        ////        {
                        ////            tot_dr = tot_dr + Math.Round(Curr_Frght_Amt, 2);
                        ////        }

                        ////        tot_dr = tot_dr + Math.Round(TotComm, 2);
                        ////    }
                        ////    else
                        ////    {

                        ////        tot_dr = tot_dr + Math.Round(TotComm, 2);
                        ////        //Iata_Amount = "-" + dtXml.Rows[i]["Iata_Commission"].ToString();
                        ////        ////TotComm = TotComm;
                        ////        ////TotDiscount = TotDiscount;
                        ////        Curr_id = "CR";

                        ////        if (Curr_id1 == "CR")
                        ////        {
                        ////            tot_cr = tot_cr + Math.Round(Curr_Frght_Amt, 2);
                        ////            //Amount = "-" + dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                        ////            ////Frgt_Amount = Curr_Frght_Amt.ToString();
                        ////            //Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                        ////        }
                        ////        else
                        ////        {
                        ////            TotFrAmount = decimal.Parse("-") + Curr_Frght_Amt;
                        ////            tot_dr = tot_dr + Math.Round(Curr_Frght_Amt, 2);
                        ////        }
                        ////        if (Curr_id == "CR")
                        ////        {
                        ////            Amount = "-" + TotTds.ToString();

                        ////        }
                        ////        else
                        ////        {
                        ////            Amount = TotTds.ToString();
                        ////        }
                        ////        tot_cr = tot_cr + Math.Round(TotTds, 2);
                        ////    }
                        ////}
                        ////else
                        ////{
                        ////    if (TotFrAmount > 0)
                        ////    {
                        ////        Curr_id = "DR";
                        ////        tot_dr = tot_dr + Math.Round(TotTds, 2);
                        ////        Amount = "-" + TotTds.ToString();
                        ////        if (Curr_id1 == "CR")
                        ////        {
                        ////            TotFrAmount = Curr_Frght_Amt;
                        ////        }
                        ////        else
                        ////        {
                        ////            TotFrAmount = decimal.Parse("-") + Curr_Frght_Amt;
                        ////        }
                        ////        //////TotComm = decimal.Parse("-") + TotComm;  //-case
                        ////        /////TotDiscount = decimal.Parse("-") + TotDiscount;   //-case
                        ////        if (Curr_id1 == "CR")
                        ////        {
                        ////            tot_cr = tot_cr + Math.Round(Curr_Frght_Amt, 2);
                        ////            //Amount = "-"+dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                        ////            //Frgt_Amount = "-" + Curr_Frght_Amt.ToString();
                        ////            //Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                        ////        }
                        ////        else
                        ////        {
                        ////            tot_dr = tot_dr + Math.Round(Curr_Frght_Amt, 2);
                        ////        }

                        ////        tot_dr = tot_dr + Math.Round(TotComm, 2);
                        ////    }
                        ////    else
                        ////    {

                        ////        tot_dr = tot_dr + Math.Round(TotComm, 2);
                        ////        //Iata_Amount = "-" + dtXml.Rows[i]["Iata_Commission"].ToString();
                        ////        ////TotComm = TotComm;
                        ////        ////TotDiscount = TotDiscount;
                        ////        Curr_id = "CR";

                        ////        if (Curr_id1 == "CR")
                        ////        {
                        ////            tot_cr = tot_cr + Math.Round(Curr_Frght_Amt, 2);
                        ////            //Amount = "-" + dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                        ////            ////Frgt_Amount = Curr_Frght_Amt.ToString();
                        ////            //Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                        ////        }
                        ////        else
                        ////        {
                        ////            //////TotFrAmount = decimal.Parse("-") + Curr_Frght_Amt;  //-case
                        ////            tot_dr = tot_dr + Math.Round(Curr_Frght_Amt, 2);
                        ////        }
                        ////        if (Curr_id == "CR")
                        ////        {
                        ////            Amount = "-" + TotTds.ToString();

                        ////        }
                        ////        else
                        ////        {
                        ////            Amount = TotTds.ToString();
                        ////        }
                        ////        tot_cr = tot_cr + Math.Round(TotTds, 2);
                        ////    }
                        ////}
                        ////////Agent Expense
                        //////if (decimal.Parse(dtXml.Rows[i]["Agent_Expenses"].ToString()) > 0)
                        //////{
                        //////    Agent_expenses = "-" + dtXml.Rows[i]["Agent_Expenses"].ToString();
                        //////    tot_dr = tot_dr + Math.Round(decimal.Parse(dtXml.Rows[i]["Agent_Expenses"].ToString()), 2);
                        //////}

                        ////////end of Agent Expense
                        ////// Tds_Amount
                        ////if (airline_name_city_value == "158" || airline_name_city_value == "159")
                        ////{
                        ////    if (TotTds > 0)
                        ////    {
                        ////        ////Tds_Amount = dtXml.Rows[i]["Tds_Amount"].ToString();
                        ////        tot_cr = tot_cr + Math.Round(TotTds, 2);

                        ////    }
                        ////    else
                        ////    {
                        ////        ////Tds_Amount = "-" + dtXml.Rows[i]["Tds_Amount"].ToString();
                        ////        tot_dr = tot_dr + Math.Round(TotTds, 2);
                        ////    }
                        ////}

                        ////else
                        ////{
                        ////    if (TotFrAmount > 0)
                        ////    {
                        ////        ////Tds_Amount = dtXml.Rows[i]["Tds_Amount"].ToString();
                        ////        tot_cr = tot_cr + Math.Round(TotTds, 2);

                        ////    }
                        ////    else
                        ////    {
                        ////        ////Tds_Amount = "-" + dtXml.Rows[i]["Tds_Amount"].ToString();
                        ////        tot_dr = tot_dr + Math.Round(TotTds, 2);
                        ////    }
                        ////}
                       #endregion

                        // start loop
                        xw.WriteStartElement("TALLYMESSAGE", "TallyUDF");
                        xw.WriteStartElement("VOUCHER");
                        xw.WriteStartAttribute("REMOTEID", "e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60");
                        //xw.WriteStartAttribute("REMOTEID", "");
                        xw.WriteStartAttribute("VCHTYPE", VchType);
                        xw.WriteStartAttribute("ACTION", "Create");
                        xw.WriteEndAttribute();
                        xw.WriteElementString("DATE", Date_XML);
                        //xw.WriteElementString("GUID", "e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60");
                        xw.WriteElementString("GUID", "");
                        xw.WriteElementString("NARRATION", "");
                        //xw.WriteElementString("VOUCHERTYPENAME", "Sales");

                        if (VchType == "Credit Note")
                        {
                            xw.WriteElementString("VOUCHERTYPENAME", "Credit");
                        }
                        else
                        {
                            xw.WriteElementString("VOUCHERTYPENAME", "Sales");
                        }

                        #region
                        xw.WriteElementString("VOUCHERNUMBER", InvoiceNoAgent);
                        xw.WriteElementString("PARTYLEDGERNAME", agentName);
                        xw.WriteElementString("CSTFORMISSUETYPE", "");
                        xw.WriteElementString("CSTFORMRECVTYPE ", "");
                        xw.WriteElementString("FBTPAYMENTTYPE", "Default");
                        xw.WriteElementString("VCHGSTCLASS", "");
                        xw.WriteElementString("ENTEREDBY", "Rawat");
                        xw.WriteElementString("DIFFACTUALQTY", "No");

                        xw.WriteElementString("AUDITED", "No");
                        xw.WriteElementString("FORJOBCOSTING", "No");
                        xw.WriteElementString("ISOPTIONAL", "No");

                        xw.WriteElementString("EFFECTIVEDATE", Date_XML); //Should mentioned effective date from first page in string format

                        xw.WriteElementString("USEFORINTEREST", "No");
                        xw.WriteElementString("USEFORGAINLOSS", "No");
                        xw.WriteElementString("USEFORGODOWNTRANSFER", "No");

                        xw.WriteElementString("USEFORCOMPOUND", "No");
                        string AuditId = Convert.ToString(count);
                        xw.WriteElementString("ALTERID", "");
                        
                        xw.WriteElementString("EXCISEOPENING", "No");

                        xw.WriteElementString("ISCANCELLED", "No");
                        xw.WriteElementString("HASCASHFLOW", "No");
                        xw.WriteElementString("ISPOSTDATED", "No");
                        xw.WriteElementString("USETRACKINGNUMBER", "No");

                        xw.WriteElementString("ISINVOICE", "No");

                        xw.WriteElementString("MFGJOURNAL", "No");

                        xw.WriteElementString("HASDISCOUNTS", "No");

                        xw.WriteElementString("ASPAYSLIP", "No");

                        xw.WriteElementString("ISDELETED", "No");
                        //  xw.WriteEndElement();
                        xw.WriteElementString("ASORIGINAL", "Yes");
                        //  xw.WriteEndElement();

                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", agentName);

                        xw.WriteElementString("GSTCLASS", "");

                        xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");

                        xw.WriteElementString("LEDGERFROMITEM", "No");

                        xw.WriteElementString("REMOVEZEROENTRIES", "No");

                        xw.WriteElementString("ISPARTYLEDGER", "Yes");

                        xw.WriteElementString("AMOUNT", GrandTotal.ToString());

                        xw.WriteStartElement("BILLALLOCATIONS.LIST");
                        xw.WriteElementString("NAME", InvoiceNoAgent);

                        xw.WriteElementString("BILLCREDITPERIOD", "30 days");

                        xw.WriteElementString("BILLTYPE", RefNo);

                        xw.WriteElementString("AMOUNT", GrandTotal.ToString());

                        xw.WriteEndElement();
                        xw.WriteEndElement();


                        //**GST NO*****
                        ////xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        ////xw.WriteElementString("LEDGERNAME", "GST NO");
                        ////xw.WriteElementString("GSTCLASS ", "");
                        ////xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        ////xw.WriteElementString("LEDGERFROMITEM", "No");
                        ////xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        ////xw.WriteElementString("ISPARTYLEDGER", "No");
                        ////xw.WriteElementString("NO", GSTNO);
                        ////xw.WriteEndElement();


                        //**INVOICE NO*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "INVOICE NO");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("NO", InvoiceNoAgent);
                        xw.WriteEndElement();


                        ////**IATA Commssion*****
                        //xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        //xw.WriteElementString("LEDGERNAME", "IATA Commission");
                        //xw.WriteElementString("GSTCLASS ", "");
                        //xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        //xw.WriteElementString("LEDGERFROMITEM", "No");
                        //xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        //xw.WriteElementString("ISPARTYLEDGER", "No");
                        //xw.WriteElementString("AMOUNT", Iata_Amount);
                        //xw.WriteEndElement();

                        #endregion

                        //*******Agent Expense************
                        if(Math.Round(TotAgentExp) > 0)
                          {
                            decimal tot_dr3 = 0;
                            string Agent_expenses1 = "-" + Math.Round(TotAgentExp);
                            tot_dr3 = tot_dr3 + Math.Round(TotAgentExp);
                            //**Agent Expense*****
                            xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                            xw.WriteElementString("LEDGERNAME", "AGENT Expenses");
                            xw.WriteElementString("GSTCLASS ", "");
                            xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                            xw.WriteElementString("LEDGERFROMITEM", "No");
                            xw.WriteElementString("REMOVEZEROENTRIES", "No");
                            xw.WriteElementString("ISPARTYLEDGER", "No");
                            xw.WriteElementString("AMOUNT", Agent_expenses1);
                            xw.WriteEndElement();
                          }
                        //end of Agent Expense
                        string Freight = "FREIGHT";
                        if (TotalIGST > 0)
                        {
                            Freight = "FREIGHT INTERSTATE";
                        }

                        //**FREIGHT A/C*****
                        if (airline_name_city_value == "158" || airline_name_city_value == "159")
                        {
                            #region
                            xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                            xw.WriteElementString("LEDGERNAME", Freight);
                            xw.WriteElementString("GSTCLASS ", "");
                            xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                            xw.WriteElementString("LEDGERFROMITEM", "No");
                            xw.WriteElementString("REMOVEZEROENTRIES", "No");
                            xw.WriteElementString("ISPARTYLEDGER", "No");
                            xw.WriteElementString("AMOUNT", Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount)), MidpointRounding.AwayFromZero).ToString());
                            xw.WriteEndElement();

                            //**IATA Commssion*****
                            xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                            xw.WriteElementString("LEDGERNAME", "IATA COMMISSION");
                            xw.WriteElementString("GSTCLASS ", "");
                            xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                            xw.WriteElementString("LEDGERFROMITEM", "No");
                            xw.WriteElementString("REMOVEZEROENTRIES", "No");
                            xw.WriteElementString("ISPARTYLEDGER", "No");
                            xw.WriteElementString("AMOUNT", TotComm.ToString());
                            xw.WriteEndElement();

                            //**Tds Commission*****
                            xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                            xw.WriteElementString("LEDGERNAME", "TDS - COMMISSION");
                            xw.WriteElementString("GSTCLASS ", "");
                            xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                            xw.WriteElementString("LEDGERFROMITEM", "No");
                            xw.WriteElementString("REMOVEZEROENTRIES", "No");
                            xw.WriteElementString("ISPARTYLEDGER", "No");
                            xw.WriteElementString("AMOUNT", TotTds.ToString());
                            xw.WriteEndElement();
                            //**Discount*****
                            ////xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                            ////xw.WriteElementString("LEDGERNAME", "DISCOUNT on Freight");
                            ////xw.WriteElementString("GSTCLASS ", "");
                            ////xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                            ////xw.WriteElementString("LEDGERFROMITEM", "No");
                            ////xw.WriteElementString("REMOVEZEROENTRIES", "No");
                            ////xw.WriteElementString("ISPARTYLEDGER", "No");
                            ////xw.WriteElementString("AMOUNT", TotDiscount.ToString());
                            ////xw.WriteEndElement();
                            #endregion
                        }
                        else
                        {
                            #region else part
                            xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                            xw.WriteElementString("LEDGERNAME", Freight);
                            xw.WriteElementString("GSTCLASS ", "");
                            xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                            xw.WriteElementString("LEDGERFROMITEM", "No");
                            xw.WriteElementString("REMOVEZEROENTRIES", "No");
                            xw.WriteElementString("ISPARTYLEDGER", "No");
                            xw.WriteElementString("AMOUNT", Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero).ToString());
                            xw.WriteEndElement();
                            #endregion else part 1
                        }

                        #region
                        //**CGST*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "CGST PAYABLE");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "No");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", TotalCGST.ToString());
                        xw.WriteEndElement();

                        //**SGST*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "SGST PAYABLE");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "No");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", TotalSGST.ToString());
                        xw.WriteEndElement();

                        //**IGST*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "IGST PAYABLE");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "No");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", TotalIGST.ToString());
                        xw.WriteEndElement();

                        //In Last
                        xw.WriteEndElement();
                        xw.WriteEndElement();
                        //End loop
                        TotDr = TotDiscount + TotComm + GrandTotal;
                        TotCr = TotFrAmount + TotDueCar + TotalGst;
                        if (TotCr == TotDr)
                        {
                            html += @"<tr style='font-size:smaller;font-family: inherit;'><td colspan=4>'Sales-" + dtCitycode.Rows[0]["City_Code"].ToString() + "::::Tot DR:'" + TotDr + "','-::::-Tot CR:' '" + TotCr + "'</td></tr>";
                        }
                        else
                        {
                            html += @"<tr style='font-size:smaller;font-family: inherit;'><td colspan=4>'Sales-" + dtCitycode.Rows[0]["City_Code"].ToString() + "::::Tot DR:'" + TotDr + "','-::::-Tot CR:' '" + TotCr + "'<b style='font-size:12px;font-family:Arial;background-color: red;margin-left: 44px;'>Error (Amount not matched)...pls check..</b></td></tr>";
                        }
                        #endregion

                        #endregion read datareader
                    }
                    #endregion
                }

                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.Close();
                xmlString = sw.ToString();
                xmlString = xmlString.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "");
                //xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Sales\" xmlns:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER REMOTEID=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\" VCHTYPE=\"Sales\" ACTION=\"Create\">");
                xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Sales\" xmlns:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER REMOTEID=\"\" VCHTYPE=\"Sales\" ACTION=\"Create\">");
                //xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Credit Note\" xmlns:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Credit Note\" xmlns:d6p1=\"\">");
                xmlString = xmlString.Replace("xmlns", "xmlns:UDF");
                xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:UDF:d6p3=\"Create\" xmlns:UDF:d6p2=\"Credit Note\" xmlns:UDF:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER REMOTEID=\"\" VCHTYPE=\"Credit Note\" ACTION=\"Create\">");
                Session["xml"] = xmlString;

                ////**** Opening in New Window*****
                //ScriptManager.RegisterStartupScript(this, GetType(), "key", "window.open('xml.aspx','_blank','location=0,toolbar=0,titlebar=0,menubar=0,resizable=1,scrollbars=1,status=1');", true);
                //**** End *****
                //////*********Opening and saving File with Pop-Up

                XmlDataDocument empDoc = new XmlDataDocument();
                Response.ContentType = "text/xml";
                Response.AppendHeader("Content-Disposition", "attachment; filename="+airline_name_city_text+"_"+CityAsStateCode+".xml");
                Response.Write(xmlString);
                Response.End();

                #endregion

                //***End**
              
             
            }
            #endregion
        }
        #endregion
    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    public string ConvertDateFormat(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    public string ConvertDateFormat1(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }
}
