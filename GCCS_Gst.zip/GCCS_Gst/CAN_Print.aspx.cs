using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CAN_Print : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string Airline_Name = "";
    string Airline_Address = "";
    string import_flight_id;
    string import_awb_id;
    decimal cartingcharges = 0;
    string DelAiraddress = "";
    decimal DataProcessingFee = 0;
    decimal CommunicationFee = 0;
    decimal MAWB = 0;
    decimal STAXRATE = 0;
    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
    decimal SBCessRATE = 0;
    decimal KKCessRATE = 0;
    decimal Weight = 0;
    decimal HAWB = 0;
    decimal MawbKEmum = 0;
    DataTable DtImportChargesHeads = new DataTable();

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }


        if (!IsPostBack)
        {

            DataTable dtstax = new DataTable();
            DataTable dtAirlineAddress = new DataTable();
            string AwbId = Request.QueryString["AWBid"];

            //***************Airline Name And Address on 26 July 2010************Start************
            DataTable dtAirlineDetailID = new DataTable();
            dtAirlineDetailID = dw.GetAllFromQuery("SELECT ift.Airline_Detail_ID,ad.Belongs_To_City,ift.Import_Flight_No FROM db_owner.Import_Flights ift INNER JOIN dbo.Airline_Detail ad ON ift.Airline_Detail_ID = ad.Airline_Detail_ID  where import_flight_id='" + Request.QueryString["Import_Flight_ID"] + "'");

            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************

            ////dtstax = dw.GetAllFromQuery("SELECT isnull(Stax,0) as Stax,isnull(SB_Cess,0) as SB_Cess FROM db_owner.Airlinewise_TDS WHERE Airline_Detail_ID=" + dtAirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString() + "and  GETDATE() BETWEEN Valid_From AND Valid_To");
            dtstax = dw.GetAllFromQuery("SELECT isnull(Stax,0) as Stax,isnull(SB_Cess,0) as SB_Cess,isnull(KK_Cess,0) as KK_Cess FROM db_owner.Airlinewise_TDS WHERE Airline_Detail_ID=" + dtAirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString() + "and  GETDATE() BETWEEN Valid_From AND Valid_To");
            STAXRATE = decimal.Parse(dtstax.Rows[0]["Stax"].ToString());
            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            SBCessRATE = decimal.Parse(dtstax.Rows[0]["SB_Cess"].ToString());
            KKCessRATE = decimal.Parse(dtstax.Rows[0]["KK_Cess"].ToString());
            if (dtAirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString() == "147")
            {
                Label20.Visible = false;
                lblMumPan.Visible = true;
                trmum.Visible = true;
                del.Visible = false;
                mum.Visible = true;
                Label16.Text = "We have pleasure in advising you that the above mentioned shipment has arrived address to you and has been deposited with  MIAPL Mumbai 400099";
                Label26.Text = "In case goods not cleared within 72 hours of arrival, MIAPL will charge demurrage.";
            }
            else if (dtAirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString() == "153")
            {
                Label20.Visible = false;
                lblMumPan.Visible = true;
                trMUM2.Visible = true;
                del.Visible = false;
                mum.Visible = true;
                Label16.Text = "We have pleasure in advising you that the above mentioned shipment has arrived address to you and has been deposited with  MIAPL Mumbai 400099";
                Label26.Text = "In case goods not cleared within 72 hours of arrival, MIAPL will charge demurrage.";
            }


            else if (dtAirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString() == "159")
            {
                Label20.Visible = false;
                lblMumPan.Visible = true;
                trmum.Visible = true;
                del.Visible = false;
                mum.Visible = true;
                Label16.Text = "We have pleasure in advising you that the above mentioned shipment has arrived address to you and has been deposited with  Air India, Mumbai 400099.";
                Label26.Text = "In case goods not cleared within 72 hours of arrival, Air India will charge demurrage.";
            }



            if (dtAirlineDetailID.Rows.Count > 0)
            {

                dtAirlineAddress = dw.GetAllFromQuery("Select am.airline_name,imp.Office_Address,imp.Airport_Address from import_charges_fee imp inner join airline_detail ad on imp.airline_detail_id=ad.airline_detail_id inner join airline_master am on ad.airline_id=am.airline_id where imp.Airline_detail_id='" + dtAirlineDetailID.Rows[0]["Airline_detail_id"] + "'");

            }
            Airline_Name = dtAirlineAddress.Rows[0]["airline_name"].ToString();
            Airline_Address = dtAirlineAddress.Rows[0]["Office_Address"].ToString();
            DelAiraddress = dtAirlineAddress.Rows[0]["Airport_Address"].ToString();
            if (Airline_Name == "MALAYSIAN AIRLINES")
            {
                Airline_Name = "MALAYSIA AIRLINES";

            }
            lblAirline_Address.Text = Airline_Address;

            if (dtAirlineDetailID.Rows[0]["Airline_detail_id"].ToString() == "159" || dtAirlineDetailID.Rows[0]["Airline_detail_id"].ToString() == "160")
                Airlinelogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
            if (dtAirlineDetailID.Rows[0]["Airline_detail_id"].ToString() == "150" || dtAirlineDetailID.Rows[0]["Airline_detail_id"].ToString() == "153")
                Airlinelogo.ImageUrl = Page.ResolveUrl("./images/THY_Logo_2011-(1).jpg");
            if (dtAirlineDetailID.Rows[0]["Airline_detail_id"].ToString() == "148")
                Airlinelogo.ImageUrl = Page.ResolveUrl("./images/malaysia-airlines.jpg");

            if (dtAirlineDetailID.Rows[0]["Airline_detail_id"].ToString() == "147")
            {
                lblShfrom.Visible = true;
                lblShipper.Visible = true;
                //lblAirline_Name.Visible = false;
                Airlinelogo.ImageUrl = Page.ResolveUrl("./images/mascar_logo.gif");
            }
            if (dtAirlineDetailID.Rows[0]["Airline_detail_id"].ToString() == "158")
            {
                // lblAirline_Name.Visible = false;
                if (dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "HY-9395" || dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "KE-9307" || dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "KE-0481" || dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "KE-481")
                {
                    Airlinelogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
                }
                else
                {
                    lblAirline_Address.Text = DelAiraddress;
                    lblDeladdress.Visible = true;
                    lblDeladdress.Text = "[For delivery order kindly visit the following address: Korean Air," + Airline_Address + " ]";
                    Airlinelogo.ImageUrl = Page.ResolveUrl("./images/uzbekistan.jpg");
                }
            }
            if (lblDeladdress.Text.Contains("Tel"))
                lblDeladdress.Text = lblDeladdress.Text.Replace("Tel", "<br> Tel");
            if (lblDeladdress.Text.Contains("TEL"))
                lblDeladdress.Text = lblDeladdress.Text.Replace("TEL", "<br> TEL");
            if (lblAirline_Address.Text.Contains("Tel"))
                lblAirline_Address.Text = lblAirline_Address.Text.Replace("Tel", "<br> Tel");
            if (lblAirline_Address.Text.Contains("TEL"))
                lblAirline_Address.Text = lblAirline_Address.Text.Replace("TEL", "<br> TEL");
            if (dtAirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString() == "158")
            {
                if (dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "HY-9395" || dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "KE-9307" || dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "KE-0481" || dtAirlineDetailID.Rows[0]["Import_Flight_No"].ToString() == "KE-481")
                {
                    Label17.Text = "In case of personal effects / household goods please bring (or send) your passport in original. If goods  are being cleared by an authorized representative then the representative should have a letter of authority in his name on non judicial stamp of Rs.10/- duly notarized (two original copies addressed to " + Airline_Name + "  and customs).";

                    Label25.Text = "No responsibility will be undertaken by " + Airline_Name + "  in the case of late receipt of this notice due to postal delays.";

                    Label28.Text = "(" + Airline_Name + " cargo)";
                }
                else
                {
                    Label17.Text = "In case of personal effects / household goods please bring (or send) your passport in original. If goods  are being cleared by an authorized representative then the representative should have a letter of authority in his name on non judicial stamp of Rs.10/- duly notarized (two original copies addressed to Uzbekistan Airways and customs).";

                    Label25.Text = "No responsibility will be undertaken by Uzbekistan Airways in the case of late receipt of this notice due to postal delays.";

                    Label28.Text = "(Uzbekistan Airways)";
                }

            }
            else
            {

                Label17.Text = "In case of personal effects / household goods please bring (or send) your passport in original. If goods  are being cleared by an authorized representative then the representative should have a letter of authority in his name on non judicial stamp of Rs.10/- duly notarized (two original copies addressed to " + Airline_Name + " cargo and customs).";

                Label25.Text = "No responsibility will be undertaken by " + Airline_Name + " cargo in the case of late receipt of this notice due to postal delays.";

                Label28.Text = "(" + Airline_Name + " cargo)";
            }

            //****End of Airline Address*********************************

            string AwbNo = Request.QueryString["AwbNo"];
            string FlightId = Request.QueryString["FlightID"];
            DataTable dtIFAReminderDate1 = new DataTable();
            dtIFAReminderDate1 = dw.GetAllFromQuery("Select CONVERT(VARCHAR,Reminder2Date,100)as Reminder2Date from Import_Flight_AWB where import_awb_id='" + AwbId + "'");

            DataTable dtIFAReminderDate2 = new DataTable();
            dtIFAReminderDate2 = dw.GetAllFromQuery("Select CONVERT(VARCHAR,Reminder3Date,100)as Reminder3Date from Import_Flight_AWB where import_awb_id='" + AwbId + "'");
            if (Request.QueryString["Reminder1Date"] != null && Convert.ToString(dtIFAReminderDate1.Rows[0]["Reminder2Date"]) == "")
            {
                DataTable dtIFAReminderDate = new DataTable();
                dtIFAReminderDate = dw.GetAllFromQuery("Select CONVERT(VARCHAR,Reminder1Date,100)as Reminder1Date from Import_Flight_AWB where import_awb_id='" + AwbId + "'");
                string Reminder2Date = Convert.ToString(DateTime.Now);

                con = new SqlConnection(strCon);
                con.Open();
                //com = new SqlCommand("update Import_Flight_AWB set Reminder2Date='" + FormatDateMM(Reminder2Date) + "' where import_awb_id='" + AwbId + "'", con);

                com = new SqlCommand("update Import_Flight_AWB set Reminder2Date='" + Reminder2Date + "' where import_awb_id='" + AwbId + "'", con);


                com.ExecuteNonQuery();
                con.Close();

                lblDate.Text = dtIFAReminderDate.Rows[0]["Reminder1Date"].ToString();

                //DD

                import_flight_id = Convert.ToString(Request.QueryString["import_flight_id"]);
                import_awb_id = Convert.ToString(Request.QueryString["AWBid"]);
                DataTable dt_show = dw.GetAllFromQuery("select ISNULL(a.Tds_Cut_By_Agent,0) AS Tds_cut, CASE WHEN a.Agent_Name <>'' THEN a.Agent_Name ELSE a.Consignee_Name  END AS Agent_Name,isnull(a.mawbdo_chgs,0) as Mawbdo_chgs,a.rotation_no,a.origin,isnull(a.Freight_chgs,0)as Freight_chgs,isnull(a.part_pcs,0) as part_pcs,isnull(a.charged_weight,0) as charged_weight,A.PCS,isnull(a.Gross_weight,0) as Gross_weight,a.import_awb_no,a.import_flight_id,a.import_awb_id,a.notify,convert(char,b.import_flight_date,103)as date,b.igm_no,b.import_flight_no,CONVERT(VARCHAR,a.Reminder1Date,100)as Reminder1Date,CONVERT(VARCHAR,a.Reminder2Date,100)as Reminder2Date,CONVERT(VARCHAR,a.Reminder3Date,100)as Reminder3Date,a.shipment_type,a.No_of_Houses,a.Hawbdo_chgs,a.commodity,a.freight_type,a.Consignee_Address,a.Shipper_Name from Import_Flight_AWB a inner join Import_Flights b on a.import_flight_id=b.import_flight_id where a.import_flight_id='" + import_flight_id + "' and a.import_awb_id='" + import_awb_id + "'");
                lblName.Text = dt_show.Rows[0]["agent_name"].ToString();
                lblNotify.Text = dt_show.Rows[0]["notify"].ToString();
                lblContents.Text = dt_show.Rows[0]["commodity"].ToString();
                lblconaddress.Text = dt_show.Rows[0]["Consignee_Address"].ToString();
                lblShipper.Text = dt_show.Rows[0]["Shipper_Name"].ToString();
                Weight = decimal.Parse(dt_show.Rows[0]["charged_weight"].ToString()) >= decimal.Parse(dt_show.Rows[0]["Gross_weight"].ToString()) ? decimal.Parse(dt_show.Rows[0]["charged_weight"].ToString()) : decimal.Parse(dt_show.Rows[0]["Gross_weight"].ToString());

                if (lblContents.Text == "Console")
                {
                    lblContents.Text = "Consol";
                }
                if (lblNotify.Text == "")
                {
                    Label10.Visible = false;
                    lblNotify.Visible = false;
                }

                lblawbno.Text = dt_show.Rows[0]["import_awb_no"].ToString();
                lblIgmno.Text = dt_show.Rows[0]["igm_no"].ToString();
                lblRotationno.Text = dt_show.Rows[0]["rotation_no"].ToString();
                lblFreightchrs.Text = dt_show.Rows[0]["Freight_chgs"].ToString();
                if (dt_show.Rows[0]["freight_type"].ToString() == "PP")
                {
                    lblFreightchrs.Text = "PP";
                }
                else if (dt_show.Rows[0]["freight_type"].ToString() == "CC")
                {
                    lblFreightchrs.Text = "CC";
                }
                if (dt_show.Rows[0]["part_pcs"].ToString() == "" || dt_show.Rows[0]["part_pcs"].ToString() == "0")
                {
                    lblNoOFPcs.Text = dt_show.Rows[0]["PCS"].ToString() + " / " + dt_show.Rows[0]["Gross_weight"].ToString();
                }
                else
                {
                    lblNoOFPcs.Text = "(" + dt_show.Rows[0]["part_pcs"].ToString() + "/" + dt_show.Rows[0]["PCS"].ToString() + ") / " + dt_show.Rows[0]["Gross_weight"].ToString();
                }
                lblArrivalfltNo.Text = dt_show.Rows[0]["import_flight_no"].ToString() + " / " + dt_show.Rows[0]["date"].ToString();
                lblFrom.Text = dt_show.Rows[0]["origin"].ToString();

                //**********DO Charges***************


                if (Session["Airline_detail_Id"].ToString() == "159" && dt_show.Rows[0]["shipment_type"].ToString() == "C")
                    DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + " and ChargeHeadName NOT IN ('Carting','CommunicationFee')");
                else
                    DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + "");
                decimal Allvalue = 0;
                decimal total = 0;
                if (DtImportChargesHeads.Rows.Count > 0)
                {
                    int i;
                    for (i = 0; i < DtImportChargesHeads.Rows.Count; i++)
                    {
                        if (DtImportChargesHeads.Rows[i]["ForEach"].ToString() == "Y")
                        {
                            HAWB = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) * decimal.Parse(dt_show.Rows[0]["No_of_Houses"].ToString());
                            Allvalue = HAWB;
                        }
                        else if (DtImportChargesHeads.Rows[i]["ChargeHeadName"].ToString() == "Carting")
                        {

                            cartingcharges = decimal.Parse(DtImportChargesHeads.Rows[i]["ForEachValue"].ToString()) * Weight > decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) ? decimal.Parse(DtImportChargesHeads.Rows[i]["ForEachValue"].ToString()) * Weight : decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                            Allvalue = cartingcharges;
                        }
                        else if (DtImportChargesHeads.Rows[i]["ChargeHeadName"].ToString() == "MAWB")
                        {
                            if (Session["Airline_detail_Id"].ToString() == "159")
                            {
                                MawbKEmum = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                ////MAWB = Math.Floor(decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBCessRATE)) / 100)));
                                MAWB = Math.Floor(decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBCessRATE) + Convert.ToDecimal(KKCessRATE)) / 100)));
                                Allvalue = MAWB;
                            }
                            else
                            {
                                MAWB = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                                Allvalue = MAWB;
                            }
                        }
                        else
                        {
                            Allvalue = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                        }
                        total += Allvalue;
                    }

                    if (Session["Airline_detail_Id"].ToString() == "159")
                    {
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ////total += Math.Ceiling(total * (STAXRATE+SBCessRATE) / 100);

                        //Gst
                        ////total += Math.Ceiling(total * (STAXRATE + SBCessRATE + KKCessRATE) / 100);
                        total += Math.Ceiling(total * (STAXRATE + SBCessRATE) / 100);
                        //  total += Math.Ceiling((MawbKEmum + cartingcharges) * STAXRATE / 100);
                       // total += 1 + Math.Ceiling(MawbKEmum + cartingcharges) - Math.Ceiling((MawbKEmum + cartingcharges) / (1 + STAXRATE / 100));
                    }
                    if (Session["Airline_detail_Id"].ToString() == "147" || Session["Airline_detail_Id"].ToString() == "153")
                    {
                        ////total += Math.Ceiling((MAWB + HAWB + cartingcharges) * (STAXRATE+SBCessRATE) / 100);

                        //Gst

                        //////total += Math.Ceiling((MAWB + HAWB + cartingcharges) * (STAXRATE + SBCessRATE + KKCessRATE) / 100);
                        total += Math.Ceiling((MAWB + HAWB + cartingcharges) * (STAXRATE + SBCessRATE) / 100);

                    }
                    //    total = total - cartingcharges;
                    //    total = total - DataProcessingFee;
                    //    total = total - CommunicationFee;
                    //    total = total - MAWB;
                    //    total = total - decimal.Parse(dt_show.Rows[0]["Tds_cut"].ToString());
                    //    DataTable dtcharge = dw.GetAllFromQuery("SELECT ChargeRate,ChargeAmount,ChargeName  FROM db_owner.ImportFlightAwb_Trans WHERE ImportAwbID=" + AwbId + " AND ChargeName !='HAWB'");
                    //    if (dtcharge.Rows.Count > 0)
                    //    {
                    //        for (int k = 0; k < dtcharge.Rows.Count; k++)
                    //        {
                    //            if (dtcharge.Rows[k]["ChargeName"].ToString() == "StaxRate")
                    //            {
                    //                STAXRATE = decimal.Parse(dtcharge.Rows[k]["ChargeRate"].ToString());
                    //            }
                    //        }
                    //        for (int j = 0; j < dtcharge.Rows.Count; j++)
                    //        {                            


                    //            if (dtcharge.Rows[i]["ChargeName"].ToString() == "MAWB" && Session["Airline_detail_Id"].ToString() == "159")
                    //            total +=   Math.Floor(decimal.Parse(dtcharge.Rows[j]["ChargeAmount"].ToString()) / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))); 
                    //            else
                    //            total += decimal.Parse(dtcharge.Rows[j]["ChargeAmount"].ToString());



                    //        }



                    //    }


                    //}
                    if (Session["Airline_detail_Id"].ToString() == "159" || Session["Airline_detail_Id"].ToString() == "147" || Session["Airline_detail_Id"].ToString() == "153")
                        total = total - decimal.Parse(dt_show.Rows[0]["Tds_cut"].ToString());
                }
                //*****************Added on 23 Mar 2011******************
                if (dt_show.Rows[0]["shipment_type"].ToString() == "F")
                {
                    total = 0;
                }
                //*****************End***********************************

                lblDOcharges.Text = Math.Round(total).ToString();

                //**********End of DO Charges***************

                //lblmasterbill.Text = dt_show.Rows[0]["Mawbdo_chgs"].ToString();

                lblReminder2TwoDate.Text = dt_show.Rows[0]["Reminder2Date"].ToString();
                lblReminder1Date.Text = dt_show.Rows[0]["Reminder1Date"].ToString();
                lblReminder3Date.Text = dt_show.Rows[0]["Reminder3Date"].ToString();

                //End

            }
            else if (Request.QueryString["Reminder2Date"] != null && Convert.ToString(dtIFAReminderDate2.Rows[0]["Reminder3Date"]) == "")
            {
                string Reminder3Date = Convert.ToString(DateTime.Now);
                DataTable dtIFAReminderDate = new DataTable();
                dtIFAReminderDate = dw.GetAllFromQuery("Select CONVERT(VARCHAR,Reminder1Date,100)as Reminder1Date from Import_Flight_AWB where import_awb_id='" + AwbId + "'");
                con = new SqlConnection(strCon);
                con.Open();
                //com = new SqlCommand("update Import_Flight_AWB set Reminder3Date='" + FormatDateMM(Reminder3Date) + "' where import_awb_id='" + AwbId + "'", con);
                com = new SqlCommand("update Import_Flight_AWB set Reminder3Date='" + Reminder3Date + "' where import_awb_id='" + AwbId + "'", con);
                com.ExecuteNonQuery();
                con.Close();
                lblDate.Text = dtIFAReminderDate.Rows[0]["Reminder1Date"].ToString();
                //DD
                import_flight_id = Convert.ToString(Request.QueryString["import_flight_id"]);
                import_awb_id = Convert.ToString(Request.QueryString["AWBid"]);
                //DataTable dt_show = dw.GetAllFromQuery("select a.agent_name,isnull(a.mawbdo_chgs,0) as Mawbdo_chgs,a.rotation_no,a.origin,isnull(a.Freight_chgs,0)as Freight_chgs,isnull(a.part_pcs,0) as part_pcs,a.charged_weight,a.import_awb_no,a.import_flight_id,a.import_awb_id,a.notify,convert(char,b.import_flight_date,103)as date,b.igm_no,b.import_flight_no,CONVERT(VARCHAR,a.Reminder1Date,100)as Reminder1Date,CONVERT(VARCHAR,a.Reminder2Date,100)as Reminder2Date,CONVERT(VARCHAR,a.Reminder3Date,100)as Reminder3Date,a.shipment_type,a.No_of_Houses,a.Hawbdo_chgs   from Import_Flight_AWB a inner join Import_Flights b on a.import_flight_id=b.import_flight_id where a.import_flight_id='" + import_flight_id + "' and a.import_awb_id='" + import_awb_id + "'");

                DataTable dt_show = dw.GetAllFromQuery("select ISNULL(a.Tds_Cut_By_Agent,0) AS Tds_cut, CASE WHEN a.Agent_Name <>'' THEN a.Agent_Name ELSE a.Consignee_Name  END AS Agent_Name ,isnull(a.mawbdo_chgs,0) as Mawbdo_chgs,a.rotation_no,a.origin,isnull(a.Freight_chgs,0)as Freight_chgs,isnull(a.part_pcs,0) as part_pcs,a.charged_weight,A.PCS,isnull(a.Gross_weight,0) as Gross_weight,a.import_awb_no,a.import_flight_id,a.import_awb_id,a.notify,convert(char,b.import_flight_date,103)as date,b.igm_no,b.import_flight_no,CONVERT(VARCHAR,a.Reminder1Date,100)as Reminder1Date,CONVERT(VARCHAR,a.Reminder2Date,100)as Reminder2Date,CONVERT(VARCHAR,a.Reminder3Date,100)as Reminder3Date,a.shipment_type,a.No_of_Houses,a.Hawbdo_chgs,a.commodity, a.freight_type,a.Consignee_Address,a.Shipper_Name  from Import_Flight_AWB a inner join Import_Flights b on a.import_flight_id=b.import_flight_id where a.import_flight_id='" + import_flight_id + "' and a.import_awb_id='" + import_awb_id + "'");

                lblName.Text = dt_show.Rows[0]["agent_name"].ToString();
                lblNotify.Text = dt_show.Rows[0]["notify"].ToString();
                lblContents.Text = dt_show.Rows[0]["commodity"].ToString();
                lblconaddress.Text = dt_show.Rows[0]["Consignee_Address"].ToString();
                lblShipper.Text = dt_show.Rows[0]["Shipper_Name"].ToString();
                Weight = decimal.Parse(dt_show.Rows[0]["charged_weight"].ToString()) >= decimal.Parse(dt_show.Rows[0]["Gross_weight"].ToString()) ? decimal.Parse(dt_show.Rows[0]["charged_weight"].ToString()) : decimal.Parse(dt_show.Rows[0]["Gross_weight"].ToString());
                if (lblContents.Text == "Console")
                {
                    lblContents.Text = "Consol";
                }
                if (lblNotify.Text == "")
                {
                    Label10.Visible = false;
                    lblNotify.Visible = false;
                }
                lblawbno.Text = dt_show.Rows[0]["import_awb_no"].ToString();
                lblIgmno.Text = dt_show.Rows[0]["igm_no"].ToString();
                lblRotationno.Text = dt_show.Rows[0]["rotation_no"].ToString();
                lblFreightchrs.Text = dt_show.Rows[0]["Freight_chgs"].ToString();
                if (dt_show.Rows[0]["freight_type"].ToString() == "PP")
                {
                    lblFreightchrs.Text = "PP";
                }
                else if (dt_show.Rows[0]["freight_type"].ToString() == "CC")
                {
                    lblFreightchrs.Text = "CC";
                }
                if (dt_show.Rows[0]["part_pcs"].ToString() == "" || dt_show.Rows[0]["part_pcs"].ToString() == "0")
                {
                    lblNoOFPcs.Text = dt_show.Rows[0]["PCS"].ToString() + " / " + dt_show.Rows[0]["Gross_weight"].ToString();
                }
                else
                {
                    lblNoOFPcs.Text = "(" + dt_show.Rows[0]["part_pcs"].ToString() + "/" + dt_show.Rows[0]["PCS"].ToString() + ") / " + dt_show.Rows[0]["Gross_weight"].ToString();
                }


                lblArrivalfltNo.Text = dt_show.Rows[0]["import_flight_no"].ToString() + " / " + dt_show.Rows[0]["date"].ToString();
                lblFrom.Text = dt_show.Rows[0]["origin"].ToString();


                if (Session["Airline_detail_Id"].ToString() == "159" && dt_show.Rows[0]["shipment_type"].ToString() == "C")
                    DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + " and ChargeHeadName NOT IN ('Carting','CommunicationFee')");
                else
                    DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + "");
                decimal Allvalue = 0;
                decimal total = 0;
                if (DtImportChargesHeads.Rows.Count > 0)
                {
                    int i;
                    for (i = 0; i < DtImportChargesHeads.Rows.Count; i++)
                    {
                        if (DtImportChargesHeads.Rows[i]["ForEach"].ToString() == "Y")
                        {
                            HAWB = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) *

decimal.Parse(dt_show.Rows[0]["No_of_Houses"].ToString());
                            Allvalue = HAWB;


                        }
                        else if (DtImportChargesHeads.Rows[i]["ChargeHeadName"].ToString() == "Carting")
                        {

                            cartingcharges = decimal.Parse(DtImportChargesHeads.Rows[i]["ForEachValue"].ToString()) * Weight

> decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) ?

decimal.Parse(DtImportChargesHeads.Rows[i]["ForEachValue"].ToString()) * Weight :

decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                            Allvalue = cartingcharges;


                        }
                        else if (DtImportChargesHeads.Rows[i]["ChargeHeadName"].ToString() == "MAWB")
                        {

                            if (Session["Airline_detail_Id"].ToString() == "159")
                            {
                                MawbKEmum = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
////                                MAWB = Math.Floor(decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) /

////(1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBCessRATE)) / 100)));

                                // Gst


////                                MAWB = Math.Floor(decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) /

////(1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBCessRATE) + Convert.ToDecimal(KKCessRATE)) / 100)));

                                MAWB = Math.Floor(decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) /

(1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBCessRATE)) / 100)));

                                Allvalue = MAWB;
                            }
                            else
                            {
                                MAWB = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                                Allvalue = MAWB;
                            }
                        }
                        else
                        {
                            Allvalue = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                        }


                        total += Allvalue;
                    }

                    if (Session["Airline_detail_Id"].ToString() == "159")
                    {
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ////total += Math.Ceiling(total * (STAXRATE+SBCessRATE) / 100);
                        total += Math.Ceiling(total * (STAXRATE + SBCessRATE + KKCessRATE) / 100);
                        // total += Math.Ceiling((MAWB + cartingcharges) * STAXRATE / 100);
                       // total += 1 + Math.Ceiling(MawbKEmum + cartingcharges) - Math.Ceiling((MawbKEmum + cartingcharges) / (1 + STAXRATE / 100));


                    }

                    if (Session["Airline_detail_Id"].ToString() == "147" || Session["Airline_detail_Id"].ToString() == "153")
                    {
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************

                        ////total += Math.Ceiling((MAWB + HAWB + cartingcharges) * (STAXRATE+SBCessRATE) / 100);
                        total += Math.Ceiling((MAWB + HAWB + cartingcharges) * (STAXRATE + SBCessRATE + KKCessRATE) / 100);

                    }
                    if (Session["Airline_detail_Id"].ToString() == "159" || Session["Airline_detail_Id"].ToString() == "147" || Session["Airline_detail_Id"].ToString() == "153")
                        total = total - decimal.Parse(dt_show.Rows[0]["Tds_cut"].ToString());


                    //if (Session["Airline_detail_Id"].ToString() == "159")
                    //    total = total - decimal.Parse(dt_show.Rows[0]["Tds_cut"].ToString());

                }
                //*****************Added on 23 Mar 2011******************
                if (dt_show.Rows[0]["shipment_type"].ToString() == "F")
                {
                    total = 0;
                }
                //*****************End***********************************
                lblDOcharges.Text = Math.Round(total).ToString();

                //**********End of DO Charges***************


                //lblmasterbill.Text = dt_show.Rows[0]["Mawbdo_chgs"].ToString();

                lblReminder3Date.Text = dt_show.Rows[0]["Reminder3Date"].ToString();
                lblReminder1Date.Text = dt_show.Rows[0]["Reminder1Date"].ToString();
                lblReminder2TwoDate.Text = dt_show.Rows[0]["Reminder2Date"].ToString();

                //End
            }

            else
            {
                DataTable dtIFAReminderDate_1 = new DataTable();
                dtIFAReminderDate_1 = dw.GetAllFromQuery("Select CONVERT(VARCHAR,Reminder1Date,100)as Reminder1Date from Import_Flight_AWB where import_awb_id='" + AwbId + "'");
                if (dtIFAReminderDate_1 != null && dtIFAReminderDate_1.Rows.Count > 0 && Convert.ToString(dtIFAReminderDate_1.Rows[0]["Reminder1Date"]) != "")
                {
                    lblDate.Text = dtIFAReminderDate_1.Rows[0]["Reminder1Date"].ToString();
                    lblReminder1Date.Text = dtIFAReminderDate_1.Rows[0]["Reminder1Date"].ToString();
                }
                else
                {
                    //string Reminder1Date = Convert.ToString(DateTime.Now.ToString("R"));
                    //string Reminder1Date = System.DateTime.Now.Date.ToString("MM/dd/yyyy");

                    string Reminder1Date = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");


                    //string _Remind1Date = FormatDateMM(Reminder1Date);
                    string _Remind1Date = Reminder1Date;
                    con = new SqlConnection(strCon);
                    con.Open();

                    //com = new SqlCommand("update Import_Flight_AWB set Reminder1Date='" + FormatDateMM(Reminder1Date) + "' where import_awb_id='" + AwbId + "'", con);

                    com = new SqlCommand("update Import_Flight_AWB set Reminder1Date='" + Reminder1Date + "' where import_awb_id='" + AwbId + "'", con);
                    com.ExecuteNonQuery();
                    con.Close();

                    //lblDate.Text = Reminder1Date;
                    //lblReminder1Date.Text = Reminder1Date;

                    lblDate.Text = _Remind1Date;
                    lblReminder1Date.Text = _Remind1Date;

                }

                //string Reminder1Date = Convert.ToString(DateTime.Now);

                //con = new SqlConnection(strCon);
                //con.Open();

                //com = new SqlCommand("update Import_Flight_AWB set Reminder1Date='" + FormatDateMM(Reminder1Date) + "' where import_awb_id='" + AwbId + "'", con);
                //com.ExecuteNonQuery();
                //con.Close();

                //lblDate.Text = System.DateTime.Now.ToString("dd/MM/yyyy");
                import_flight_id = Convert.ToString(Request.QueryString["import_flight_id"]);
                import_awb_id = Convert.ToString(Request.QueryString["AWBid"]);
                DataTable dt_show = dw.GetAllFromQuery("select ISNULL(a.Tds_Cut_By_Agent,0) AS Tds_cut, CASE WHEN a.Agent_Name <>'' THEN a.Agent_Name ELSE a.Consignee_Name  END AS Agent_Name,isnull(a.mawbdo_chgs,0) as Mawbdo_chgs,a.rotation_no,a.origin,isnull(a.Freight_chgs,0)as Freight_chgs,isnull(a.part_pcs,0) as part_pcs,a.charged_weight,A.PCS,isnull(a.Gross_weight,0) as Gross_weight,a.import_awb_no,a.import_flight_id,a.import_awb_id,a.notify,convert(char,b.import_flight_date,103)as date,b.igm_no,b.import_flight_no,CONVERT(VARCHAR,a.Reminder1Date,100)as Reminder1Date,CONVERT(VARCHAR,a.Reminder2Date,100)as Reminder2Date,CONVERT(VARCHAR,a.Reminder3Date,100)as Reminder3Date,a.shipment_type,a.No_of_Houses,a.Hawbdo_chgs,a.commodity,a.freight_type,a.Consignee_Address,a.Shipper_Name   from Import_Flight_AWB a inner join Import_Flights b on a.import_flight_id=b.import_flight_id where a.import_flight_id='" + import_flight_id + "' and a.import_awb_id='" + import_awb_id + "'");
                lblName.Text = dt_show.Rows[0]["agent_name"].ToString();
                lblNotify.Text = dt_show.Rows[0]["notify"].ToString();
                lblContents.Text = dt_show.Rows[0]["commodity"].ToString();
                lblconaddress.Text = dt_show.Rows[0]["Consignee_Address"].ToString();
                lblShipper.Text = dt_show.Rows[0]["Shipper_Name"].ToString();
                Weight = decimal.Parse(dt_show.Rows[0]["charged_weight"].ToString()) >= decimal.Parse(dt_show.Rows[0]["Gross_weight"].ToString()) ? decimal.Parse(dt_show.Rows[0]["charged_weight"].ToString()) : decimal.Parse(dt_show.Rows[0]["Gross_weight"].ToString());
                if (lblContents.Text == "Console")
                {
                    lblContents.Text = "Consol";
                }
                if (lblNotify.Text == "")
                {
                    Label10.Visible = false;
                    lblNotify.Visible = false;
                }
                lblawbno.Text = dt_show.Rows[0]["import_awb_no"].ToString();
                lblIgmno.Text = dt_show.Rows[0]["igm_no"].ToString();
                lblRotationno.Text = dt_show.Rows[0]["rotation_no"].ToString();
                lblFreightchrs.Text = dt_show.Rows[0]["Freight_chgs"].ToString();
                if (dt_show.Rows[0]["freight_type"].ToString() == "PP")
                {
                    lblFreightchrs.Text = "PP";
                }
                else if (dt_show.Rows[0]["freight_type"].ToString() == "CC")
                {
                    lblFreightchrs.Text = "CC";
                }



                if (dt_show.Rows[0]["part_pcs"].ToString() == "" || dt_show.Rows[0]["part_pcs"].ToString() == "0")
                {
                    lblNoOFPcs.Text = dt_show.Rows[0]["PCS"].ToString() + " / " + dt_show.Rows[0]["Gross_weight"].ToString();
                }
                else
                {
                    lblNoOFPcs.Text = "(" + dt_show.Rows[0]["part_pcs"].ToString() + "/" + dt_show.Rows[0]["PCS"].ToString() + ") / " + dt_show.Rows[0]["Gross_weight"].ToString();
                }



                lblArrivalfltNo.Text = dt_show.Rows[0]["import_flight_no"].ToString() + " / " + dt_show.Rows[0]["date"].ToString();
                lblFrom.Text = dt_show.Rows[0]["origin"].ToString();


                if (Session["Airline_detail_Id"].ToString() == "159" && dt_show.Rows[0]["shipment_type"].ToString() == "C")
                    DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + " and ChargeHeadName NOT IN ('Carting','CommunicationFee')");
                else
                    DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + "");
                decimal Allvalue = 0;
                decimal total = 0;
                if (DtImportChargesHeads.Rows.Count > 0)
                {
                    int i;
                    for (i = 0; i < DtImportChargesHeads.Rows.Count; i++)
                    {
                        if (DtImportChargesHeads.Rows[i]["ForEach"].ToString() == "Y")
                        {
                            HAWB = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) *

decimal.Parse(dt_show.Rows[0]["No_of_Houses"].ToString());
                            Allvalue = HAWB;
                        }
                        else if (DtImportChargesHeads.Rows[i]["ChargeHeadName"].ToString() == "Carting")
                        {

                            cartingcharges = decimal.Parse(DtImportChargesHeads.Rows[i]["ForEachValue"].ToString()) * Weight

> decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) ?

decimal.Parse(DtImportChargesHeads.Rows[i]["ForEachValue"].ToString()) * Weight :

decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                            Allvalue = cartingcharges;
                        }
                        else if (DtImportChargesHeads.Rows[i]["ChargeHeadName"].ToString() == "MAWB")
                        {
                            if (Session["Airline_detail_Id"].ToString() == "159")
                            {
                                MawbKEmum = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
////                                MAWB = Math.Floor(decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) /

////(1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBCessRATE)) / 100)));

                                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                MAWB = Math.Floor(decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString()) /

(1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBCessRATE) + Convert.ToDecimal(KKCessRATE)) / 100)));

                                Allvalue = MAWB;
                            }
                            else
                            {
                                MAWB = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                                Allvalue = MAWB;
                            }
                        }

                        else
                        {
                            Allvalue = decimal.Parse(DtImportChargesHeads.Rows[i]["defaultValue"].ToString());
                        }

                        total += Allvalue;
                    }
                    if (Session["Airline_detail_Id"].ToString() == "159")
                    {
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************

                        ////total +=Math.Ceiling(total* (STAXRATE+SBCessRATE) / 100);

                        total += Math.Ceiling(total * (STAXRATE + SBCessRATE + KKCessRATE) / 100);

                        //total += 1 + Math.Ceiling(MawbKEmum + cartingcharges) - Math.Ceiling((MawbKEmum + cartingcharges) / (1 + STAXRATE / 100));

                    }

                    if (Session["Airline_detail_Id"].ToString() == "147" || Session["Airline_detail_Id"].ToString() == "153")
                    {
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ////total += Math.Ceiling((MAWB + HAWB + cartingcharges) * (STAXRATE+SBCessRATE) / 100);
                        total += Math.Ceiling((MAWB + HAWB + cartingcharges) * (STAXRATE + SBCessRATE + KKCessRATE) / 100);

                    }
                    if (Session["Airline_detail_Id"].ToString() == "159" || Session["Airline_detail_Id"].ToString() == "147" || Session["Airline_detail_Id"].ToString() == "153")
                        total = total - decimal.Parse(dt_show.Rows[0]["Tds_cut"].ToString());


                }
                //if (Session["Airline_detail_Id"].ToString() == "159")
                //    total = total - decimal.Parse(dt_show.Rows[0]["Tds_cut"].ToString());


                //*****************Added on 23 Mar 2011******************
                if (dt_show.Rows[0]["shipment_type"].ToString() == "F")
                {
                    total = 0;
                }
                //*****************End***********************************
                lblDOcharges.Text = Math.Round(total).ToString();
                //**********End of DO Charges***************

                //lblmasterbill.Text = dt_show.Rows[0]["Mawbdo_chgs"].ToString();
                //lblReminder1Date.Text = dt_show.Rows[0]["Reminder1Date"].ToString();

                lblReminder2TwoDate.Text = dt_show.Rows[0]["Reminder2Date"].ToString();
                lblReminder3Date.Text = dt_show.Rows[0]["Reminder3Date"].ToString();
            }
        }
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
