﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AllStationClusterwiseReport : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string Table = "";
    string Table2 = "";
    string Table3 = "";
    /// <summary>
    /// Make Connection From Web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string to_month = "";
    string str_AirlineDetailId;
    string strY = "";
    bool year_flag = false;
    int next = 0;
    string from_month = "";


    string SalesPersonID = "";

    string AgentID_ = "";


    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            lblDate.Text = FormatDateDD(DateTime.Now.ToShortDateString());
            htmlTableSimple();
        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public void htmlTableSimple()
    {
        string Flightname = Request.QueryString["Flightname"];
        string[] Flight = Flightname.Split(new char[] { ',' });

        int colspan = (4 * (Flight.Length + 1)) * 4 + 3;

        Hashtable small = new Hashtable();
        Hashtable greater = new Hashtable();
        Hashtable smallshipment = new Hashtable();
        Hashtable greatershipment = new Hashtable();

        string sales_Person_Id = "";
        string from_date = Request.QueryString["from"];


        SalesPersonID = Request.QueryString["salesPersonID"];

        AgentID_ = Request.QueryString["AgentID"];


        try
        {
            decimal Total_smallAirwaybillCA = 0;
            decimal Total_GreaterAirwaybillCA = 0;
            decimal Total_GreaterChwtCA = 0;
            decimal Total_SmallerChwtCA = 0;

            decimal Total_smallAirwaybillTotal = 0;
            decimal Total_GreaterAirwaybillTotal = 0;
            decimal Total_GreaterChwtTotal = 0;
            decimal Total_SmallerChwtTotal = 0;

            decimal Total_smallRevenue = 0;
            decimal Total_GreaterRevenue = 0;
            decimal Total_GreaterYield = 0;
            decimal Total_SmallerYield = 0;

            decimal GDTotal_smallRevenue = 0;
            decimal GDTotal_GreaterRevenue = 0;
            decimal GDTotal_GreaterYield = 0;
            decimal GDTotal_SmallerYield = 0;
                       
            int Sno = 0;

            int ip = 0;

            // Table header create



            decimal TotalsmallAirwaybillCA = 0; decimal TotalGreaterAirwaybillCA = 0; decimal TotalGreaterChwtCA = 0; decimal TotalSmallerChwtCA = 0;




            decimal TotalsmallAirwaybillTotal = 0; decimal TotalGreaterAirwaybillTotal = 0; decimal TotalGreaterChwtTotal = 0; decimal TotalSmallerChwtTotal = 0;


            decimal TotalsmallRevenu = 0; decimal TotalGreaterRevenu = 0; decimal TotalGreaterYield = 0; decimal TotalSmallerYield = 0;




            decimal GDTotalsmallRevenu = 0; decimal GDTotalGreaterRevenu = 0; decimal GDTotalGreaterYield = 0; decimal GDTotalSmallerYield = 0;


            Table += @"<h5><p align=center>CLUSTER PERFORMANCE REPORT <br>" + FormatDateMM(Request.QueryString["from"]) + " - " + FormatDateMM(Request.QueryString["to"]) + "</p></h5>";
            Table += @"<Table align=center width=80% border=1 cellspacing=0>";

            Table += @"<tr class=h1 align=left><td colspan=3></td>";
            Table2 += @"<tr class=h5 boldtext><td colspan=3></td>";



            for (int i = 0; i < Flight.Length; i++)
            {

                DataTable dt = dw.GetAllFromQuery("SELECT ad.Airline_Detail_ID,(am.Airline_Text_Code+'-'+cm.City_Code) AS FlightName  FROM dbo.Airline_Detail ad INNER JOIN dbo.Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN dbo.City_Master cm ON ad.Belongs_To_City=cm.City_ID INNER JOIN db_owner.Cluster_master cms ON cms.Cluster_City=cm.City_ID where ad.Airline_Detail_ID=" + Flight[i] + "");



                Table += @"<td colspan=16 align=center>" + dt.Rows[0]["FlightName"].ToString() + "</td>";

                Table2 += @"<td  colspan=4 align=center class=boldtextt nowrap>No oF Awb</td><td colspan=4 align=center class=boldtextt nowrap>Upliftment In Kgs</td><td colspan=4 align=center class=boldtextt nowrap> Yield</td><td colspan=4 align=center class=boldtextt nowrap>Selling Revenue</td>";



                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

                Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";
            }




            Table += @"<td colspan=16 align=center>TOTAL</td></tr>";
            Table2 += @"<td  colspan=4 align=center class=boldtextt nowrap>No oF Awb</td><td  colspan=4 align=center class=boldtextt nowrap>Upliftment In Kgs</td><td colspan=4 align=center class=boldtextt nowrap>Yeild</td><td colspan=4 align=center class=boldtextt nowrap>Selling Revenue</td></tr>";
            Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

            Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";
            Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";

            Table3 += @"<td colspan=2 align=center class=boldtextt nowrap>Greater</td><td colspan=2 align=center class=boldtextt nowrap>Small</td>";



            Table = Table + Table2;
            Table += @"<tr class=h1 align=left><td>HEAD</td><td nowrap>AGENT NAME</td><td>MONTH</td>" + Table3 + "</tr>";



            DateTime dt1 = Convert.ToDateTime(FormatDateMM(Request.QueryString["from"].ToString()));
            DateTime dt2 = Convert.ToDateTime(FormatDateMM(Request.QueryString["to"].ToString()));




            DataTable dtAccountwise;

            if (SalesPersonID == "0")
            {

                dtAccountwise = dw.GetAllFromQuery(" select lm.user_id from login_master lm inner join group_master gm on lm.group_id=gm.group_id inner join user_master um on lm.user_id=um.userId where um.userid IN(39,42,44,57,112,113,135,172)  and um.userid is not null order by um.full_name");
            }
            else
            {


                dtAccountwise = dw.GetAllFromQuery(" select lm.user_id from login_master lm inner join group_master gm on lm.group_id=gm.group_id inner join user_master um on lm.user_id=um.userId where  um.userid=" + SalesPersonID + " and um.userid is not null order by um.full_name");


            }
            if (dtAccountwise.Rows.Count > 0)
            {
                //***********User_Id wise or salesperson_Id wise loop***********
                for (int j = 0; j < dtAccountwise.Rows.Count; j++)
                {
                    //DataTable dtUserId = dw.GetAllFromQuery("select user_Id from login_master where Email_ID='" + Session["EMailID"].ToString() + "'");
                    sales_Person_Id = dtAccountwise.Rows[j]["user_id"].ToString();
                    DataTable dtSalesPersonName = new DataTable();


                    dtSalesPersonName = dw.GetAllFromQuery("select full_name from user_master where userid=" + sales_Person_Id + "");
                    //Table += @"<tr><td style='background-color:Pink;' align=left class=text colspan=52 nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + " DETAILS" + @"</td>";



                    //******************MonthWise Loop*****************
                    for (DateTime x = dt1; x < dt2; x = x.AddMonths(1))
                    {

                        string Final_Date = x.ToString();
                        string[] d = Final_Date.Split(new char[] { '/' });
                        string strMM = d[0];
                        string strDD = d[1];
                        string strYYYY = d[2].Substring(0, 4);
                        string month_name = getMonthName(Final_Date);

                        DataTable DtAgent;

                        if (AgentID_ == "0" || AgentID_ == "")
                        {
                            DtAgent = dw.GetAllFromQuery("select agent_id from AgentToSalesPerson_Cluster where sales_person_id=" + sales_Person_Id + " ");
                        }
                        else
                        {
                            DtAgent = dw.GetAllFromQuery("select agent_id from AgentToSalesPerson_Cluster where sales_person_id=" + sales_Person_Id + " and agent_id=" + AgentID_ + " ");
                        }

                        if (DtAgent.Rows.Count > 0)
                        {
                            Table += @"<tr><td style='background-color:Pink;' align=left class=text colspan='" + colspan + "' nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + " DETAILS" + @"</td>";
                            for (int K = 0; K < DtAgent.Rows.Count; K++)
                            {

                                decimal smallAirwaybillCA = 0;
                                decimal GreaterAirwaybillCA = 0;

                                decimal GreaterChwtCA = 0;
                                decimal SmallerChwtCA = 0;

                                decimal smallAirwaybillTotal = 0;
                                decimal GreaterAirwaybillTotal = 0;
                                decimal GreaterChwtTotal = 0;
                                decimal SmallerChwtTotal = 0;

                                decimal smallAirwaybillYield = 0;
                                decimal GreaterAirwaybillYield = 0;

                                decimal smallAirwaybillRevenue = 0;
                                decimal GreaterAirwaybillRevenue = 0;

                                decimal smallAirwaybillRevenueTotal = 0;
                                decimal GreaterAirwaybillRevenuellTotal = 0;
                                decimal smallAirwaybillYieldTotal = 0;
                                decimal GreaterAirwaybillYieldTotal = 0;

                                DataTable dtAgent_Name = dw.GetAllFromQuery("select agent_name from agent_master where agent_id=" + DtAgent.Rows[K]["agent_id"].ToString() + "");


                                Table += @"<tr><td  align=left class=text nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + @"</td><td align=left class=text nowrap=true>" + dtAgent_Name.Rows[0]["Agent_Name"].ToString() + @"</td><td align=left class=text nowrap=true>" + month_name + "-" + strYYYY + @"</td>";
                                for (int k = 0; k < Flight.Length; k++)
                                {



                                    ///////********************* For revenue and yield for small shipment ***************////////
                                    SqlCommand com_csr = new SqlCommand("DETAIL_CM1_AGENT_WISE_RevenueReport_small", con);
                                    con.Open();
                                    com_csr.CommandType = CommandType.StoredProcedure;

                                    com_csr.Parameters.AddWithValue("Agent_Id", DtAgent.Rows[K]["agent_id"].ToString());
                                    com_csr.Parameters.AddWithValue("Airline_Detail_ID", Flight[k]);

                                    com_csr.Parameters.AddWithValue("FROM_DATE", FormatDateMM(Request.QueryString["from"].ToString()));
                                    com_csr.Parameters.AddWithValue("TO_DATE", FormatDateMM(Request.QueryString["to"].ToString()));


                                    SqlDataAdapter sdaSmallRevenue = new SqlDataAdapter(com_csr);
                                    DataTable dtSmallRevenue = new DataTable();
                                    sdaSmallRevenue.Fill(dtSmallRevenue);
                                    con.Close();

                                    if (dtSmallRevenue.Rows.Count > 0)
                                    {
                                        smallAirwaybillYield =Math.Round( Convert.ToDecimal(dtSmallRevenue.Compute("sum(Revenu)", "")) / Convert.ToDecimal(dtSmallRevenue.Compute("sum(charged_weight)", "")),2);
                                        smallAirwaybillRevenue = Math.Round(Convert.ToDecimal(dtSmallRevenue.Compute("sum(Revenu)", "")),2);

                                    
                                    }
                                                                        
                                    ///////********************* For revenue and yield for small shipment ***************////////
                                    com_csr.Dispose();

                                    ///////********************* For revenue and yield for small shipment ***************////////
                                     com_csr = new SqlCommand("DETAIL_CM1_AGENT_WISE_RevenueReport_Big", con);
                                     con.Open();
                                    com_csr.CommandType = CommandType.StoredProcedure;

                                    com_csr.Parameters.AddWithValue("Agent_Id", DtAgent.Rows[K]["agent_id"].ToString());
                                    com_csr.Parameters.AddWithValue("Airline_Detail_ID", Flight[k]);

                                    com_csr.Parameters.AddWithValue("FROM_DATE", FormatDateMM(Request.QueryString["from"].ToString()));
                                    com_csr.Parameters.AddWithValue("TO_DATE", FormatDateMM(Request.QueryString["to"].ToString()));


                                    SqlDataAdapter sdaBIGRevenue = new SqlDataAdapter(com_csr);
                                    DataTable dtBIGRevenue = new DataTable();
                                   
                                    sdaBIGRevenue.Fill(dtBIGRevenue);
                                    con.Close();
                                    if (dtBIGRevenue.Rows.Count > 0)
                                    {
                                        GreaterAirwaybillYield = Math.Round( Convert.ToDecimal(dtBIGRevenue.Compute("sum(Revenu)", "")) / Convert.ToDecimal(dtBIGRevenue.Compute("sum(charged_weight)", "")),2);
                                        GreaterAirwaybillRevenue =Math.Round( Convert.ToDecimal(dtBIGRevenue.Compute("sum(Revenu)", "")),2);
                                    
                                    }
                                   

                                    ///////********************* For revenue and yield for small shipment ***************////////








                                    DataTable dtRecord1 = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS small_AirWayBill_No,SUM(s.Charged_Weight) AS Small_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN AgentToSalesPerson_Cluster ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight <= 500 AND s.Airline_Detail_ID=" + Flight[k] + " AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND  s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");

                                    if (dtRecord1.Rows.Count > 0)
                                    {
                                        smallAirwaybillCA = Convert.ToDecimal(dtRecord1.Rows[0]["small_AirWayBill_No"].ToString());
                                        SmallerChwtCA = Convert.ToDecimal(dtRecord1.Rows[0]["Small_Charged_Weight"].ToString());
                                    }



                                    DataTable dtRecordG = dw.GetAllFromQuery("select COUNT(s.AirWayBill_No) AS greater_AirWayBill_No,SUM(s.Charged_Weight) AS greater_Charged_Weight,s.Airline_Detail_ID AS Airline_Detail_Id,  am.Agent_Name AS Agent_Name,am.Agent_ID   FROM sales s INNER JOIN AgentToSalesPerson_Cluster ATP ON s.Agent_ID = ATP.Agent_ID INNER JOIN Airline_Detail ad ON s.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN Agent_Master am ON  s.Agent_ID = am.Agent_ID WHERE ATP.sales_person_id =" + sales_Person_Id + " AND s.Agent_Id=" + DtAgent.Rows[K]["agent_id"].ToString() + " and s.Charged_Weight > 500 AND s.Airline_Detail_ID  =" + Flight[k] + " AND (MONTH(s.FLIGHT_DATE)=" + strMM + ") AND  s.FLIGHT_DATE >= '" + FormatDateMM(Request.QueryString["from"].ToString()) + "' AND  s.FLIGHT_DATE <='" + FormatDateMM(Request.QueryString["to"].ToString()) + "' GROUP BY s.Airline_Detail_ID, am.Agent_Name, am.Agent_ID");

                                    if (dtRecordG.Rows.Count > 0)
                                    {
                                        GreaterAirwaybillCA = Convert.ToDecimal(dtRecordG.Rows[0]["greater_AirWayBill_No"].ToString());
                                        GreaterChwtCA = Convert.ToDecimal(dtRecordG.Rows[0]["greater_Charged_Weight"].ToString());
                                    }


                                    TotalGreaterAirwaybillCA += GreaterAirwaybillCA;
                                    TotalsmallAirwaybillCA += smallAirwaybillCA;

                                    TotalGreaterChwtCA += GreaterChwtCA;
                                    TotalSmallerChwtCA += SmallerChwtCA;



                                    TotalGreaterYield += GreaterAirwaybillYield;
                                    TotalSmallerYield += smallAirwaybillYield;

                                    TotalGreaterRevenu += GreaterAirwaybillRevenue;
                                    TotalsmallRevenu += smallAirwaybillRevenue;


                                    //***********Over All Total****************
                                    Total_smallAirwaybillCA += smallAirwaybillCA;
                                    Total_GreaterAirwaybillCA += GreaterAirwaybillCA;

                                    Total_GreaterChwtCA += GreaterChwtCA;
                                    Total_SmallerChwtCA += SmallerChwtCA;


////
                                    Total_SmallerYield += smallAirwaybillYield;
                                    Total_GreaterYield += GreaterAirwaybillYield;

                                    Total_GreaterRevenue += GreaterAirwaybillRevenue;
                                    Total_smallRevenue += smallAirwaybillRevenue;

                                    //**************End***********************

                                    Table += "<td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "gaw'>" + GreaterAirwaybillCA + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "saw'>" + smallAirwaybillCA + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "gcw'>" + GreaterChwtCA + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "scw'>" + SmallerChwtCA + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "gay'>" + GreaterAirwaybillYield + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "say'>" + smallAirwaybillYield + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "gar'>" + GreaterAirwaybillRevenue + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + Flight[k] + "sar'>" + smallAirwaybillRevenue + @"</td>";

                                    smallAirwaybillTotal += smallAirwaybillCA;

                                    GreaterAirwaybillTotal += GreaterAirwaybillCA;
                                    SmallerChwtTotal += SmallerChwtCA;

                                    GreaterChwtTotal += GreaterChwtCA;


                                    /////////////////// ************new************/////////////////
                                    smallAirwaybillRevenueTotal += smallAirwaybillRevenue;
                                    GreaterAirwaybillRevenuellTotal += GreaterAirwaybillRevenue;
                                  
                                   

                                    /////////////////************end new************/////////////////


                                    TotalGreaterAirwaybillTotal += GreaterAirwaybillTotal;
                                    TotalsmallAirwaybillTotal += smallAirwaybillTotal;
                                    TotalGreaterChwtTotal += GreaterChwtTotal;
                                    TotalSmallerChwtTotal += SmallerChwtTotal;
                                    /////////////////////////************new************///////////////////

                                    
                                    GDTotalGreaterRevenu += GreaterAirwaybillRevenuellTotal;
                                    GDTotalsmallRevenu += smallAirwaybillRevenueTotal;
                                    GDTotalSmallerYield += smallAirwaybillYieldTotal;
                                    GDTotalGreaterYield += GreaterAirwaybillYieldTotal;

                                    ////////////////////////************end new************///////////////////////



                                    Total_smallAirwaybillTotal += smallAirwaybillTotal;
                                    Total_GreaterAirwaybillTotal += GreaterAirwaybillTotal;
                                    Total_GreaterChwtTotal += GreaterChwtTotal;
                                    Total_SmallerChwtTotal += SmallerChwtTotal;
                                    ////////////////////////************new************////////////////////////
                                    GDTotal_GreaterRevenue += GreaterAirwaybillRevenuellTotal;
                                    GDTotal_smallRevenue += smallAirwaybillRevenueTotal;
                                    GDTotal_GreaterYield += GreaterAirwaybillYieldTotal;
                                    GDTotal_SmallerYield += smallAirwaybillYieldTotal;

                                    
                                    ////////////////////////***********end *new************//////////////////////




                                    smallAirwaybillCA = 0;
                                    SmallerChwtCA = 0;
                                    GreaterAirwaybillCA = 0;

                                    GreaterChwtCA = 0;
                                    smallAirwaybillRevenue = 0;
                                    GreaterAirwaybillRevenue = 0;
                                    smallAirwaybillYield = 0;
                                    GreaterAirwaybillYield = 0;

                                }

                                GreaterAirwaybillYieldTotal =  GreaterChwtTotal==0?0: GreaterAirwaybillRevenuellTotal / GreaterChwtTotal;

                                smallAirwaybillYieldTotal = SmallerChwtTotal==0?0: smallAirwaybillRevenueTotal/SmallerChwtTotal;

                                Table += "<td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "Gawb'>" + GreaterAirwaybillTotal + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "Sawb'>" + smallAirwaybillTotal + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "gcwTC'>" + GreaterChwtTotal + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "scwTC'>" + SmallerChwtTotal + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "gayTC'>" + Math.Round(GreaterAirwaybillYieldTotal,2) + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "sayTC'>" + Math.Round(smallAirwaybillYieldTotal,2) + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "garTC'>" + GreaterAirwaybillRevenuellTotal + @"</td><td colspan=2 align=right class=text idx='" + sales_Person_Id + month_name + strYYYY + "sarTC'>" + smallAirwaybillRevenueTotal + @"</td>";
                                GreaterAirwaybillTotal = 0;
                                GreaterChwtTotal = 0;
                                smallAirwaybillTotal = 0;
                                SmallerChwtTotal = 0;
                                smallAirwaybillRevenueTotal = 0;
                                GreaterAirwaybillRevenuellTotal = 0;
                                GreaterAirwaybillYieldTotal = 0;
                                smallAirwaybillYieldTotal = 0;



                            }
                            Table += @"<tr ><td style='background-color:BlanchedAlmond;' lign=left class=text>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + "</td><td style='background-color:BlanchedAlmond;' align=left class=text>" + month_name + "-" + strYYYY + "  Total" + "</td><td style='background-color:BlanchedAlmond;' align=left class=text>" + month_name + "-" + strYYYY + "</td>";


                            for (int i = 0; i < Flight.Length; i++)
                            {
                                Table += @"<td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "gaw'></span></td><td style='background-color:BlanchedAlmond;' colspan=2 align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "saw'></span></td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "gcw'></span></td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "scw'></span></td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "gay'></span></td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "say'></span></td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "gar'></span></td><td colspan=2 style='background-color:BlanchedAlmond;' align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + Flight[i] + "sar'></span></td>";

                            }

                            Table += @" <td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "Gawb'></span></td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "Sawb'></span></td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "gcwTC'></span></td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "scwTC'></span></td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "gayTC'></span></td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "sayTC'></span></td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "garTC'></span></td><td style='background-color:BlanchedAlmond;' colspan=2  align=right class=text><span tsv='" + sales_Person_Id + month_name + strYYYY + "sarTC'></span></td></tr>";
                            TotalsmallAirwaybillCA = 0; TotalGreaterAirwaybillCA = 0; TotalGreaterChwtCA = 0; TotalSmallerChwtCA = 0;
                            TotalSmallerYield = 0; TotalGreaterYield = 0; TotalGreaterRevenu = 0; TotalsmallRevenu = 0;


                            TotalsmallAirwaybillTotal = 0;
                            TotalGreaterAirwaybillTotal = 0;
                            TotalGreaterChwtTotal = 0;
                            TotalSmallerChwtTotal = 0;

                            GDTotalGreaterRevenu = 0;
                            GDTotalGreaterYield = 0;
                            GDTotalSmallerYield = 0;
                            GDTotalsmallRevenu = 0;

                        }
                        else
                        {
                            //Table += @"<tr ><td colspan=52>No Record Found For:" + dtSalesPersonName.Rows[0]["full_name"].ToString() + "</td></tr>"; 
                            Table += @"<tr><td style='background-color:Pink;' align=left class=text colspan=52 nowrap=true>" + dtSalesPersonName.Rows[0]["full_name"].ToString() + " DETAILS:&nbsp;&nbsp;&nbsp;&nbsp;No  Agent  Found" + @"</td>";
                        }

                    }
                }
                Table += @"<tr><td  style='background-color: Khaki;' colspan=2 align=left class=text>Grand Total</td><td  style='background-color: Khaki;' align=left class=text>&nbsp;</td>";

                for (int i = 0; i < Flight.Length; i++)
                {
                    Table += @"<td  style='background-color: Khaki;' colspan=2  align=right class=text ><span gtsv='" + Flight[i] + "gaw'></span></td><td  style='background-color: Khaki;' colspan=2 align=right class=text><span gtsv='" + Flight[i] + "saw'></span></td><td  style='background-color: Khaki;' colspan=2  align=right class=text><span gtsv='" + Flight[i] + "gcw'></span></td><td colspan=2 style='background-color: Khaki;' align=right class=text><span gtsv='" + Flight[i] + "scw'></span></td><td colspan=2 style='background-color: Khaki;' align=right class=text><span gtsv='" + Flight[i] + "gay'></span></td><td colspan=2 style='background-color: Khaki;' align=right class=text><span gtsv='" + Flight[i] + "say'></span></td><td colspan=2 style='background-color: Khaki;' align=right class=text><span gtsv='" + Flight[i] + "gar'></span></td><td colspan=2 style='background-color: Khaki;' align=right class=text><span gtsv='" + Flight[i] + "sar'></span></td>";

                }



                Table += @"<td colspan=2  style='background-color: Khaki;' align=right class=text><span gtsv='Gawb'></span></td><td  style='background-color: Khaki;' colspan=2  align=right class=text><span gtsv='Sawb'></span></td><td colspan=2  style='background-color: Khaki;' align=right class=text><span gtsv='gcwTC'></span></td><td  style='background-color: Khaki;' colspan=2  align=right class=text><span gtsv='scwTC'></span></td><td  style='background-color: Khaki;' colspan=2  align=right class=text><span gtsv='gayTC'></span></td><td  style='background-color: Khaki;' colspan=2  align=right class=text><span gtsv='sayTC'></span></td><td  style='background-color: Khaki;' colspan=2  align=right class=text><span gtsv='garTC'></span></td><td  style='background-color: Khaki;' colspan=2  align=right class=text><span gtsv='sarTC'></span></td></tr>";


                Table += "</Table>";
                Label1.Text = Table;
            }
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
    public string getMonthName(string month)
    {
        string[] mon = month.Split('/');
        string ret_date = "";
        strY = mon[2].Substring(0, 4);
        if (year_flag)
        {
            strY = Convert.ToString(Convert.ToInt16(strY) + 1);
        }
        else
        {
            strY = mon[2];
        }
        switch (Convert.ToInt16(mon[0]))
        {
            case 1:
                ret_date = "January";
                break;
            case 2:
                ret_date = "Febraury";
                break;
            case 3:
                ret_date = "March";
                break;
            case 4:
                ret_date = "April";
                break;
            case 5:
                ret_date = "May";
                break;
            case 6:
                ret_date = "June";
                break;
            case 7:
                ret_date = "July";
                break;
            case 8:
                ret_date = "August";
                break;
            case 9:
                ret_date = "September";
                break;
            case 10:
                ret_date = "October";
                break;
            case 11:
                ret_date = "November";
                break;
            case 12:
                ret_date = "December";
                year_flag = true;
                next = 0;
                from_month = "1";
                break;
        }
        return ret_date;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
