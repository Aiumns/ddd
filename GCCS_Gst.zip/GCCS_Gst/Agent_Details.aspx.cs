using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Agent_Details : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            AgentDetails();
        }
    }
    public void AgentDetails()
    {
        try
        {
            // table header create
            con = new SqlConnection(strCon);
            con.Open();

            //com = new SqlCommand("select distinct City_id,City_Code,City_Name from City_Master CM inner join Agent_Branch AB on AB.Belongs_to_city=CM.City_ID", con);

            com = new SqlCommand("Getcity_Acess", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            int ip = 1;
            int count = 0;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.
                //if (txtAgentName.Text == "")
                //{
                //com = new SqlCommand("SELECT AM.Agent_Name,LM.Email_ID,LM.Login_Password FROM Agent_Master AM INNER JOIN Agent_Branch AB ON AM.Agent_ID = AB.Agent_ID INNER JOIN Login_Master LM ON AB.Agent_Branch_ID = LM.Agent_ID  where AB.Belongs_To_City='" + drx[0].ToString() + "' ORDER BY AM.Agent_Name " , con);
                //}
                //else
                //{
                //    com = new SqlCommand("SELECT AM.Agent_Name,LM.Email_ID,LM.Login_Password FROM Agent_Master AM INNER JOIN Agent_Branch AB ON AM.Agent_ID = AB.Agent_ID INNER JOIN Login_Master LM ON AB.Agent_Branch_ID = LM.Agent_ID  where AB.Belongs_To_City='" + drx[0].ToString() + "' and AM.Agent_Name like '"+txtAgentName.Text.Trim()+"%'  ORDER BY AM.Agent_Name ", con);
                //}

                com = new SqlCommand("GetAgentListCityWise", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@City_Id", SqlDbType.Int).Value = Convert.ToInt32(drx[0].ToString());
                com.Parameters.Add("@Agent_Name", SqlDbType.VarChar).Value = txtAgentName.Text;
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    

                    table += @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle1><td align=center colspan=6 >" + drx[2].ToString() + "(" + drx[1].ToString() + ")" + @"</th></tr><tr class=HeaderStyle2><td  align=""center"" nowrap>SNo</td><td  align=""center"" nowrap>Agnet Name</td><td  align=""center"" nowrap>Upliftment City</td><td  align=""center"" nowrap>Email ID</td><td  align=""center"" nowrap>Password</td><td  align=""center"" nowrap>Status</td></tr></th>";
                    while (dr1.Read())
                    {
                        count++;
                        if (dr1["Status_Name"].ToString() == "Active")
                        {
                            table += @"<tr ><td align=left class=text>" + count + @"</td><td align=left class=text>" + dr1["Agent_Name"].ToString() + @"</td><td align=left class=text>" + dr1["City_Name"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Email_ID"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Login_Password"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Status_Name"].ToString() + @"</td></tr>";
                        }
                        else
                        {
                            table += @"<tr ><td align=left class=error>" + count + @"</td><td align=left class=error>" + dr1["Agent_Name"].ToString() + @"</td><td align=left class=error>" + dr1["City_Name"].ToString() + @"</td><td align=""left"" class=error>" + dr1["Email_ID"].ToString() + @"</td><td align=""left"" class=error>" + dr1["Login_Password"].ToString() + @"</td><td align=""left"" class=error>" + dr1["Status_Name"].ToString() + @"</td></tr>";
                        }
                    }
                }
                else
                {

                    //table += @"<tr><td align=""center"" colspan=""11""></td></tr>";
                }


                dr1.Close();
                ip = ip + 1;
                count = 0;
                table += @"<br>";
            }
            table += @"</table>";
            Label1.Text = table;

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {

    }
}
