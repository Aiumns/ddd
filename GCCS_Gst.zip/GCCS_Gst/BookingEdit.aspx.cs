using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Booking_Edit : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    public string calendarControl = "";
    int NA = 0;
    bool Flag = false;
    protected void Page_Load(object sender, EventArgs e)
    {


        HtmlGenericControl body = (HtmlGenericControl)Page.Master.FindControl("MyBody");

        body.Attributes.Add("onload", "Change()");


        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            /////LoadGstStateCode();
            txtValuationCharge.Attributes.Add("onblur", "Valuation()");
            txtTax.Attributes.Add("onblur", "Tax()");
            ViewState["edit"] = "0";
            ViewState["et"] = "1";
            lblmsg.Visible = false;



            if (!IsPostBack)
            {

                //string BookingID=Request.QueryString["Booking_ID"];
                //MakeTableCharges();
                //MakeTableDimension();
                //if (Session["groupid"].ToString() == "5")
                //{
                //    lblSpotRate.Text = "Spot Rate Request";
                //    if (Convert.ToDecimal(txtVolWt.Value) > Convert.ToDecimal(txtGrossWt.Value))
                //    {
                //        ch_wt = Convert.ToDecimal(txtVolWt.Value);

                //        if (ch_wt >= 500)
                //        {
                //            Spot_Rate.Visible = true;
                //        }
                //    }
                //    else
                //    {
                //        ch_wt = Convert.ToDecimal(txtGrossWt.Value);
                //        if (ch_wt >= 500)
                //        {
                //            Spot_Rate.Visible = true;
                //        }

                //    }

                //}
                //else
                //{
                //    lblSpotRate.Text = "Spot Rate";
                //    decimal v = Convert.ToDecimal(txtVolWt.Value);
                //    decimal g = Convert.ToDecimal(txtGrossWt.Value);
                //    if (Convert.ToDecimal(txtVolWt.Value) > Convert.ToDecimal(txtGrossWt.Value))
                //    {
                //        ch_wt = Convert.ToDecimal(txtVolWt.Value);

                //        if (ch_wt >= 500)
                //        {
                //            Spot_Rate.Visible = true;
                //        }
                //    }
                //    else
                //    {
                //        ch_wt = Convert.ToDecimal(txtGrossWt.Value);
                //        if (ch_wt >= 500)
                //        {
                //            Spot_Rate.Visible = true;
                //        }

                //    }

                //}

                FillAllFields();
                DueCarrier();
            }
        }
    }
    public void DueCarrier()
    {
        decimal A = 0, B = 0, C = 0, Gw = 0, Cw = 0, FSC = 0, AWBFee = 0, DisbursmentCharges = 0, ACIFee = 0, Security_Surcharge = 0, Xray = 0;
        if (txtGrossWt.Value != "" && txtChWt.Value != "")
        {
            Gw = decimal.Parse(txtGrossWt.Value);
            Cw = decimal.Parse(txtChWt.Value);
        }

        DataTable dtCharges = dw.GetAllFromQuery("select FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,DisBursementCharges from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());


        DataTable dtAgentRateID = dw.GetAllFromQuery("select Agent_Rate_ID from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and Destination=" + ddlDestination.SelectedValue + " and Shipment_ID=" + ddlShipmentType.SelectedValue + " and Status=2 and valid_from <= '" + FormatDateDD(txtFlightDate.Text) + "' and valid_to >= '" + FormatDateDD(txtFlightDate.Text) + "'");
        long AgentRateID = 0;
        DataTable dtChargesDetails = new DataTable();
        if (dtAgentRateID.Rows.Count > 0)
        {

            dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue + " and Agent_Rate_ID=" + long.Parse(dtAgentRateID.Rows[0]["Agent_Rate_ID"].ToString()));
        }
        if (dtCharges.Rows.Count > 0)
        {
            if (dtCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Cw * FSC;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Gw * FSC;
                    }
                }
            }
            if (dtCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Cw * Security_Surcharge;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Gw * Security_Surcharge;
                    }
                }
            }
            if (dtCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Cw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Gw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
            }
            ACIFee = decimal.Parse(dtCharges.Rows[0]["ACI_Fees"].ToString());
            DisbursmentCharges = decimal.Parse(dtCharges.Rows[0]["DisBursementCharges"].ToString());
            AWBFee = decimal.Parse(dtCharges.Rows[0]["AWB_Fees"].ToString());


            Hidden1.Value = ACIFee.ToString();
            // txtDisbursmentCharges.Text = DisbursmentCharges.ToString();
            Hidden2.Value = DisbursmentCharges.ToString();
            decimal Charges = A + B + C;
            Hidden3.Value = Charges.ToString();
            //txtAWBFee.Text = AWBFee.ToString();
            //**** For AWB Fee***********************
            if (decimal.Parse(txtChWt.Value) >= 150)
            {
                decimal C_W_T = Math.Round(decimal.Parse(txtChWt.Value), MidpointRounding.AwayFromZero);
                txtAWBFee.Text = C_W_T.ToString();
            }
            else
            {
                txtAWBFee.Text = "150";
            }

        }
    }
    public void fillOtherCharges(string bookingId)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "select * from Other_Charges where booking_Id = '" + bookingId + "'";
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = MakeTableCharges();
        dt.Rows[0].Delete();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            dw = dt.NewRow();
            dw[0] = i++;

            string amount = dr["Amount"].ToString();
            decimal amt = System.Math.Round(decimal.Parse(amount), MidpointRounding.AwayFromZero);
            dw[1] = dr["Charge_Name"].ToString();
            dw[2] = amt;
            dw[3] = dr["Prepaid_or_Collect"].ToString();

            dt.Rows.Add(dw);

        }
        Session["dtOtherCharges"] = dt;
        if (dt.Rows.Count > 0)
        {
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            grd.DataSource = MakeTableCharges();
            grd.DataBind();
        }
        con.Close();

    }
    public void fillVolumeDimension(string bookingId)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "select * from Booking_Dimensions where booking_Id = '" + bookingId + "'";
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = MakeTableDimension();
        dt.Rows[0].Delete();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            dw = dt.NewRow();
            dw[0] = i++;

            string len = dr["Length"].ToString();
            string width = dr["Breadth"].ToString();
            string Height = dr["Height"].ToString();

            decimal l = System.Math.Round(decimal.Parse(len), MidpointRounding.AwayFromZero);
            decimal w = System.Math.Round(decimal.Parse(width), MidpointRounding.AwayFromZero);
            decimal h = System.Math.Round(decimal.Parse(Height), MidpointRounding.AwayFromZero);

            dw[1] = l;
            dw[2] = w;
            dw[3] = h;
            dw[4] = dr["No_of_Packages"].ToString();
            dw[5] = dr["Total"].ToString();

            dt.Rows.Add(dw);

        }
        Session["dtTemp"] = dt;
        if (dt.Rows.Count > 0)
        {
            grdCal.DataSource = dt;
            grdCal.DataBind();
        }
        else
        {
            grdCal.DataSource = MakeTableDimension();
            grdCal.DataBind();
        }
        con.Close();
    }
    public DataTable MakeTableDimension()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Length";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Width";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Height";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Pieces";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume Wt";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);
        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dtTemp.Rows.Add(dr);
        ViewState["dtDimension"] = dtTemp;
        return dtTemp;
        //Session["dtTemp"] = dtTemp;

    }
    protected DataTable MakeTableCharges()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "Sno";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "FeeName";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "Fee";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "PaymentType";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        DataRow dr = dt.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dt.Rows.Add(dr);

        return dt;
        //Session["dtOtherCharges"] = dt;
        //ViewState["dtBeginCharges"] = dt;
    }
    public void FillAllFields()
    {
        string BookingID = "";
        if (Request.QueryString != null)
        {
            BookingID = Request.QueryString["Booking_ID"];
        }
        con = new SqlConnection(strCon);
        com = new SqlCommand("[SHOW_BOOKING_EDIT]", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@BookingID", SqlDbType.BigInt).Value = long.Parse(BookingID);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dtBookingEdit = new DataTable();
        da.Fill(dtBookingEdit);

        ViewState["dtBookingEdit"] = dtBookingEdit;
        if (dtBookingEdit.Rows.Count > 0)
        {

            #region Gst
            ////txtGstNo.Text = dtBookingEdit.Rows[0]["GstNo"].ToString();
            ////txtGstAddr.Text = dtBookingEdit.Rows[0]["GstAdress"].ToString();
            ////ddlGstStateCode.SelectedValue = dtBookingEdit.Rows[0]["statecode"].ToString();
            ////ddlGst.SelectedValue = dtBookingEdit.Rows[0]["GstNo"].ToString();
            #endregion end of Gst



            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select Used_Date,AirWayBill_No from stock_Master where Stock_ID=" + dtBookingEdit.Rows[0]["Stock_ID"].ToString());

            long Agent_ID = long.Parse(dtBookingEdit.Rows[0]["Agent_ID"].ToString());
            ViewState["Agent_ID"] = Agent_ID;

            if (dtAirWayBillNo.Rows.Count > 0)
            {
                txtAWBNO.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
                string AirlineCode = txtAWBNO.Text.Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Airline_ID=" + AirlineID.Rows[0]["Airline_ID"].ToString() + " and Belongs_To_City=" + dtBookingEdit.Rows[0]["City_ID"].ToString());
                long City_ID = long.Parse(dtBookingEdit.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    ViewState["AirlineDetailID"] = AirlineDetailID;
                }
            }
            LoadShipmentType();
            LoadCommodity();
            LoadDestination();
            //txtAWBDate.Text = FormatDateDD(DateTime.Now.ToShortDateString());
            DateTime AWBD = DateTime.Parse(dtAirWayBillNo.Rows[0]["Used_Date"].ToString());
            txtAWBDate.Text = AWBD.ToString("dd/MM/yyyy");
            decimal TariffR = decimal.Parse(dtBookingEdit.Rows[0]["Tariff_Rate"].ToString());
            TariffR = Math.Round(TariffR, MidpointRounding.AwayFromZero);
            txtTariffRate.Text = TariffR.ToString();
            decimal FA = decimal.Parse(dtBookingEdit.Rows[0]["Freight_Amount"].ToString());
            FA = Math.Round(FA, MidpointRounding.AwayFromZero);
            txtSpAmt.Text = FA.ToString();
            decimal SR = decimal.Parse(dtBookingEdit.Rows[0]["Special_Rate"].ToString());
            SR = Math.Round(SR, MidpointRounding.AwayFromZero);
            txtSpRate.Text = SR.ToString();
            decimal SA = decimal.Parse(dtBookingEdit.Rows[0]["Special_Amount"].ToString());
            SA = Math.Round(SA, MidpointRounding.AwayFromZero);
            txtFreightAmount.Text = SA.ToString();
            lblSpecialAmount.Text = txtFreightAmount.Text;
            DateTime HandOverDate = Convert.ToDateTime(dtBookingEdit.Rows[0]["Expected_Handover_Date"].ToString());

            txthandover_date.Text = FormatDateDD(HandOverDate.ToShortDateString());
            DataTable dtAgentName = dw.GetAllFromQuery("Select Agent_Name from Agent_Master where Agent_ID=" + ViewState["Agent_ID"].ToString());
            if (dtAgentName.Rows.Count > 0)
            {
                lblAgent.Text = dtAgentName.Rows[0]["Agent_Name"].ToString();
            }
            //****Binding Dimension Grid***********
            DataTable dtBookingDimension = dw.GetAllFromQuery("select * from Booking_Dimensions where Booking_ID=" + BookingID);
            fillVolumeDimension(BookingID);


            //****End of Binding Dimension Grid*******

            //****Binding OtherCharges Grid***********
            fillOtherCharges(BookingID);
            //****End Binding OtherCharges Grid***********
            ViewState["Flight_Open_ID"] = dtBookingEdit.Rows[0]["Flight_Open_ID"].ToString(); ;
            txtShipper.Text = dtBookingEdit.Rows[0]["Shipper_Name"].ToString();
            txtShipperAddress.Text = dtBookingEdit.Rows[0]["Shipper_Address"].ToString();
            txtConsignee.Text = dtBookingEdit.Rows[0]["Consignee_Name"].ToString();
            txtConsigneeAddress.Text = dtBookingEdit.Rows[0]["Consignee_Address"].ToString();
            txtDVCustom.Text = dtBookingEdit.Rows[0]["Declared_Custom_Value"].ToString();
            txtDVCarriage.Text = dtBookingEdit.Rows[0]["Declared_Carriage_Value"].ToString();
            txtCurrency.Text = dtBookingEdit.Rows[0]["Currency"].ToString();
            txtCGHSCode.Text = dtBookingEdit.Rows[0]["CHGS_Code"].ToString();
            txtHandlingInformation.Text = dtBookingEdit.Rows[0]["Handling_Information"].ToString();
            txtNatureGoods.Text = dtBookingEdit.Rows[0]["Nature_and_Quantity"].ToString();
            txtAgentDealRemarks.Text = dtBookingEdit.Rows[0]["Agent_Deal_Remarks"].ToString();
            rbCal.SelectedValue = dtBookingEdit.Rows[0]["Measurement_Unit"].ToString();
            decimal gw = decimal.Parse(dtBookingEdit.Rows[0]["Gross_Weight"].ToString());
            //gw = Math.Round(gw);
            txtGrossWt.Value = gw.ToString();
            txtHgw.Value = gw.ToString();
            decimal cw = decimal.Parse(dtBookingEdit.Rows[0]["Charged_Weight"].ToString());
            //cw = Math.Round(cw);
            txtChWt.Value = cw.ToString();
            txtHcw.Value = cw.ToString();
            decimal spot_rate = decimal.Parse(dtBookingEdit.Rows[0]["Spot_Rate"].ToString());
            ViewState["Spot_Rate"] = decimal.Parse(dtBookingEdit.Rows[0]["Spot_Rate"].ToString());
            //gw = Math.Round(gw);
            txtSpotRate.Text = spot_rate.ToString();
            decimal vw = decimal.Parse(dtBookingEdit.Rows[0]["Volume_Weight"].ToString());
            //vw = Math.Round(vw);
            txtVolWt.Value = vw.ToString();
            txtHvw.Value = vw.ToString();

            txtPieces.Value = dtBookingEdit.Rows[0]["No_of_Packages"].ToString();

            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtBookingEdit.Rows[0]["Flight_Open_ID"].ToString());
            if (dtFlight.Rows.Count > 0)
            {
                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

                if (dtFlightNo.Rows.Count > 0)
                {
                    txtFlightNo.Text = dtFlightNo.Rows[0]["Flight_No"].ToString();
                }
                DateTime FlightDate = Convert.ToDateTime(dtFlight.Rows[0]["Flight_Date"].ToString());
                txtFlightDate.Text = FormatDateDD(FlightDate.ToShortDateString());
            }

            rbFType.SelectedValue = dtBookingEdit.Rows[0]["Freight_Type"].ToString();
            rbDueFreight.SelectedValue = dtBookingEdit.Rows[0]["DueCarrier_Type"].ToString();

            //***Charges For DueCarrier and Due Agent**********
            decimal FS = decimal.Parse(dtBookingEdit.Rows[0]["Fuel_Surcharges"].ToString());
            FS = Math.Round(FS, MidpointRounding.AwayFromZero);
            txtFSC.Text = FS.ToString();
            decimal WS = decimal.Parse(dtBookingEdit.Rows[0]["War_Surcharges"].ToString());
            WS = Math.Round(WS, MidpointRounding.AwayFromZero);
            txtWSC.Text = WS.ToString();
            decimal XR = decimal.Parse(dtBookingEdit.Rows[0]["Xray_Charges"].ToString());
            XR = Math.Round(XR, MidpointRounding.AwayFromZero);
            txtXRAY.Text = XR.ToString();
            txtHouses.Value = dtBookingEdit.Rows[0]["No_of_houses"].ToString();
            decimal ACI = decimal.Parse(dtBookingEdit.Rows[0]["Total_ACI_Fees"].ToString());
            ACI = Math.Round(ACI, MidpointRounding.AwayFromZero);
            txtACIFee.Text = ACI.ToString();
            decimal AWB = decimal.Parse(dtBookingEdit.Rows[0]["AWB_Fees"].ToString());
            AWB = Math.Round(AWB, MidpointRounding.AwayFromZero);
            txtAWBFee.Text = AWB.ToString();
            decimal DB = decimal.Parse(dtBookingEdit.Rows[0]["Disbursement_Charges"].ToString());
            DB = Math.Round(DB, MidpointRounding.AwayFromZero);
            txtDisbursmentCharges.Text = DB.ToString();
            decimal Dmcharges = decimal.Parse(dtBookingEdit.Rows[0]["DMCharges"].ToString());
            Dmcharges =Math.Round( Dmcharges,MidpointRounding.AwayFromZero);
            txtDmcharges.Text = Dmcharges.ToString();
            decimal DC = decimal.Parse(dtBookingEdit.Rows[0]["Total_DueCarrier"].ToString());
            DC = Math.Round(DC, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = DC.ToString();
            //Hidden3.Value = txtDueCarrier.Text;
            decimal DueP = decimal.Parse(dtBookingEdit.Rows[0]["TotalDueAgent_Prepaid"].ToString());
            DueP = Math.Round(DueP, MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = DueP.ToString();
            decimal DueC = decimal.Parse(dtBookingEdit.Rows[0]["TotalDueAgent_Collect"].ToString());
            DueC = Math.Round(DueC, MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = DueC.ToString();
            if (txtDueAgentP.Text != "" && txtDueAgentC.Text != "")
            {
                decimal DueAgent = decimal.Parse(txtDueAgentP.Text) + decimal.Parse(txtDueAgentC.Text);
                DueAgent = Math.Round(DueAgent, MidpointRounding.AwayFromZero);
                txtDueAgent.Text = DueAgent.ToString();
            }
            decimal TP = decimal.Parse(dtBookingEdit.Rows[0]["Total_Prepaid"].ToString());
            TP = Math.Round(TP, MidpointRounding.AwayFromZero);
            txtPrepaid.Text = TP.ToString();
            decimal TC = decimal.Parse(dtBookingEdit.Rows[0]["Total_Collect"].ToString());
            TC = Math.Round(TC, MidpointRounding.AwayFromZero);
            txtCollect.Text = TC.ToString();
            decimal Cat = decimal.Parse(dtBookingEdit.Rows[0]["Cartridge_Charges"].ToString());
            Cat = Math.Round(Cat, MidpointRounding.AwayFromZero);
            txtCatrage.Text = Cat.ToString();
            decimal VC = decimal.Parse(dtBookingEdit.Rows[0]["Valuation_Charge"].ToString());
            VC = Math.Round(VC, MidpointRounding.AwayFromZero);
            txtValuationCharge.Text = VC.ToString();
            decimal TX = decimal.Parse(dtBookingEdit.Rows[0]["Tax"].ToString());
            TX = Math.Round(TX, MidpointRounding.AwayFromZero);
            txtTax.Text = TX.ToString();
            //***End Charges For DueCarrier and Due Agent**********
            txtAdhocRate.Text = dtBookingEdit.Rows[0]["Adhoc_Rate"].ToString() == "" ? "0" : dtBookingEdit.Rows[0]["Adhoc_Rate"].ToString();

            DataTable dtCity = dw.GetAllFromQuery("select City_Code,City_Name from City_Master where City_ID=" + dtBookingEdit.Rows[0]["City_ID"].ToString());
            if (dtCity.Rows.Count > 0)
            {
                txtOrigin.Text = dtCity.Rows[0]["City_Code"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString();
            }
            ddlDestination.SelectedValue = dtBookingEdit.Rows[0]["Destination_ID"].ToString();

            ddlShipmentType.SelectedValue = dtBookingEdit.Rows[0]["Shipment_ID"].ToString();
            ddlScr.SelectedValue = dtBookingEdit.Rows[0]["Special_Commodity_ID"].ToString();
        }
    }
    public void LoadDestination()
    {
        try
        {
            string strAgent = "";
            strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString();
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Clear();
            //ddlDestination.Items.Insert(0, "- -Select- -");
            //ddlDestination.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadCommodity()
    {
        try
        {
            string strAgent = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlScr.Items.Insert(0, "- -Select- -");
            ddlScr.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadShipmentType()
    {
        try
        {
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlShipmentType.Items.Insert(0, "- -Select- -");
            ddlShipmentType.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlShipmentType.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction tr = con.BeginTransaction();

        long BookingID = 0;
        if (Request.QueryString != null)
        {
            BookingID = long.Parse(Request.QueryString["Booking_ID"]);
        }
        //DataTable dtLimit = dw.GetAllFromQuery("select  a.Agent_ID,a.Credit_Limit as Credit_Limit,sum(bw.Total_DueCarrier) as Total_DueCarrier,sum(b.Special_Amount) as Special_Amount,(sum(bw.Total_DueCarrier)+sum(b.Special_Amount)) as Used_Limit,isnull(a.Amount_Paid,0) as Amount_Paid,(a.Credit_Limit-(sum(bw.Total_DueCarrier)+sum(b.Special_Amount))) as Unused_Limit from Agent_Master a inner join Stock_Master s on a.Agent_ID=s.Agent_ID inner join Booking_Master b on s.Stock_ID=b.Stock_ID inner join Booking_AWB bw on b.Booking_ID=bw.Booking_ID where a.Agent_ID=" + ViewState["Agent_ID"].ToString() + " group by a.Agent_ID,a.Credit_Limit,a.Amount_Paid");
        //decimal check_limit = 0;
        //if (dtLimit.Rows.Count > 0)
        //{
        //    decimal Credit = decimal.Parse(dtLimit.Rows[0]["Credit_Limit"].ToString());
        //    decimal used = decimal.Parse(dtLimit.Rows[0]["Used_Limit"].ToString());
        //    decimal AmounPaid = decimal.Parse(dtLimit.Rows[0]["Amount_Paid"].ToString());
        //    used = used - AmounPaid;
        //    check_limit = Credit - used + AmounPaid;

        //}
        DataTable dtLimit = dw.GetAllFromQuery("select Agent_ID,Credit_Limit,isnull(Used_Limit,0) as Used_Limit,(Credit_Limit-isnull(Used_Limit,0)+isnull(Amount_Paid,0))as Unused_Limit from Agent_Branch  where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString());
        decimal check_limit = 0;
        if (dtLimit.Rows.Count > 0)
        {
            check_limit = decimal.Parse(dtLimit.Rows[0]["Unused_Limit"].ToString());
        }
        //********************Added On 8 Apr 2011 :Offline Case**************
        else
        {
            DataTable dtOfflineCity = dw.GetAllFromQuery("select offline_cityId from booking_master where booking_id=" + BookingID + "");
            if (dtOfflineCity.Rows.Count > 0)
            {
                dtLimit = dw.GetAllFromQuery("select Agent_ID,Credit_Limit,isnull(Used_Limit,0) as Used_Limit,(Credit_Limit-isnull(Used_Limit,0)+isnull(Amount_Paid,0))as Unused_Limit from Agent_Branch  where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtOfflineCity.Rows[0]["offline_cityId"].ToString());
                if (dtLimit.Rows.Count > 0)
                {
                    check_limit = decimal.Parse(dtLimit.Rows[0]["Unused_Limit"].ToString());
                }
                else
                {
                    dtLimit = dw.GetAllFromQuery("select Agent_ID,Credit_Limit,isnull(Used_Limit,0) as Used_Limit,(Credit_Limit-isnull(Used_Limit,0)+isnull(Amount_Paid,0))as Unused_Limit from Agent_Branch  where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtOfflineCity.Rows[0]["offline_cityId"].ToString());
                    if (dtLimit.Rows.Count > 0)
                    {
                        check_limit = decimal.Parse(dtLimit.Rows[0]["Unused_Limit"].ToString());
                    }
                }
            }
        }
        //*******************End Of Offline*********************************************
        decimal Booking_Amount = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueCarrier.Text);
        if (check_limit < Booking_Amount)
        {
            lblcreditlimitcheck.Text = "Your Credit Limit Is Not Sufficient For Booking...";
            lblcreditlimitcheck.Visible = true;
        }
        else
        {
            try
            {
                //DataTable dtSearch=dw.GetAllFromQuery("SELECT Destination_ID, Gross_Weight, Volume_Weight, Charged_Weight, Shipment_ID FROM  Booking_Master where Booking_ID="+BookingID);
                //if (dtSearch.Rows[0]["Destination_ID"].ToString() == ddlDestination.SelectedValue && dtSearch.Rows[0]["Shipment_ID"].ToString() == ddlShipmentType.SelectedValue && dtSearch.Rows[0]["Gross_Weight"].ToString() == txtGrossWt.Value && dtSearch.Rows[0]["Volume_Weight"].ToString() == txtVolWt.Value && dtSearch.Rows[0]["Charged_Weight"].ToString() == txtChWt.Value)
                //{

                int OtherChargesID = 0;

                Update_BookingMaster(tr, con);
                Update_AWBDate(tr, con);
                // dtBookingID = dw.GetAllFromQuery("select ident_current('Booking_Master') as BookingID");
                //if (Request.QueryString != null)
                //{
                //    BookingID = long.Parse(Request.QueryString["Booking_ID"]);
                Insert_BookingHistory(BookingID, tr, con);
                InsertBookingDimesionHistory(BookingID, tr, con);
                decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtSpAmt.Text);
                //  Used_Limit = Used_Limit + Convert.ToDecimal(Session["UsedLimit"].ToString());
                //  dw.GetAllFromQuery("update Agent_Master set Used_Limit=" + Used_Limit + " where Agent_ID=" + ViewState["Agent_ID"].ToString());
                //}
                DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                if (dtOtherChargesID.Rows.Count > 0)
                {
                    if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                    {
                        dtOtherChargesID.Rows[0].Delete();
                    }
                }
                //if (dtOtherChargesID.Rows.Count > 0)
                //{
                Update_OtherCharges(BookingID, tr, con);
                dtOtherChargesID = dw.GetAllFromQuery("select ident_current('Other_Charges') as OtherChargesID");
                //}

                if (dtOtherChargesID.Rows.Count > 0)
                {
                    OtherChargesID = int.Parse(dtOtherChargesID.Rows[0]["OtherChargesID"].ToString());
                }
                Update_BookingAWB(BookingID, tr, con);
                DataTable dtTemp = new DataTable();
                if (Session["dtTemp"] != null)
                {
                    dtTemp = (DataTable)Session["dtTemp"];
                    if (dtTemp.Rows.Count > 0)
                    {
                        if (dtTemp.Rows[0]["SNo"].ToString() == "0")
                        {
                            dtTemp.Rows[0].Delete();
                        }
                    }
                }

                if (dtTemp.Rows.Count > 0)
                {
                    Update_BookingDimesion(BookingID, tr, con);

                }

                tr.Commit();
                //con.Close();
             //   Response.Redirect("Booking_Details.aspx");

                //}
                //else
                //{
                //    lblSearchFlight.Visible = true;
                //    lblSearchFlight.Text = "Pls search and select Flight";
                // }
                // }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                tr.Rollback();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
               Response.Redirect("Booking_Details.aspx");
            }
        }
    }
    #region Update_AWBDate
    public void Update_AWBDate(SqlTransaction tr, SqlConnection con)
    {
        string update;
        //con = new SqlConnection(strCon);
        //con.Open();
        DataTable dtstock = dw.GetAllFromQuery("select stock_ID from Stock_Master where AirWayBill_No='" + txtAWBNO.Text + "'");
        update = "update Stock_Master set Used_Date='" + FormatDateMM(txtAWBDate.Text) + "'" + "  where Stock_ID=" + dtstock.Rows[0]["stock_ID"].ToString();
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
        //con.Close();
        com.Dispose();
    }
    #endregion

    #region InsertBookingDimesionHistory
    public void InsertBookingDimesionHistory(long BookingID, SqlTransaction tr, SqlConnection con)
    {
        string insert;

        //con = new SqlConnection(strCon);
        //con.Open();
        DataTable dtDimension = new DataTable();

        dtDimension = dw.GetAllFromQuery("select * from Booking_Dimensions where Booking_ID=" + BookingID);

        for (int i = 0; i < dtDimension.Rows.Count; i++)
        {
            insert = "insert into Booking_Dimensions_History(AirWayBill_No,No_of_Packages,Length,Breadth,Height,Total) values(@AirWayBill_No,@No_of_Packages,@Length,@Breadth,@Height,@Total)";

            SqlCommand com = new SqlCommand(insert, con, tr);
            com.CommandType = CommandType.Text;
            com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text;
            com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["No_of_Packages"].ToString();
            com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
            com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Breadth"].ToString();
            com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
            com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Total"].ToString();
            com.ExecuteNonQuery();
        }
    }
    #endregion

    #region Insert_BookingHistory
    public void Insert_BookingHistory(long BookingID, SqlTransaction tr, SqlConnection con)
    {
        string insert;

        //con = new SqlConnection(strCon);
        //con.Open();
        insert = "insert into Booking_History(Booking_ID,Booking_Date,AirWayBill_No,Airline_Name,Flight_No,Origin,Destination,Agent_Code,Special_Commodity_Name,Shipment_Name,Flight_Date,No_of_Packages,Measurement_Unit,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Agent_Deal_Remarks,Expected_Handover_Date,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Handovered_Status,Status,Entered_By,Entered_On) values(@Booking_ID,@Booking_Date,@AirWayBill_No,@Airline_Name,@Flight_No,@Origin,@Destination,@Agent_Code,@Special_Commodity_Name,@Shipment_Name,@Flight_Date,@No_of_Packages,@Measurement_Unit,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Agent_Deal_Remarks,@Expected_Handover_Date,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Handovered_Status,@Status,@Entered_By,@Entered_On)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        DataTable dtBookingEdit = (DataTable)ViewState["dtBookingEdit"];
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID; //from View
        com.Parameters.Add("@Booking_Date", SqlDbType.DateTime).Value = dtBookingEdit.Rows[0]["Booking_Date"].ToString();
        //////DataTable dtAWBNo=dw.GetAllFromQuery("select AirWayBill_No from Stock_Master where Stock_ID="+dtBookingEdit.Rows[0]["Stock_ID"].ToString());
        //////com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = dtAWBNo.Rows[0]["AirWayBill_No"].ToString();
        //////string AirlineCode=dtAWBNo.Rows[0]["AirWayBill_No"].ToString().Substring(0,3);

        ////DataTable dtAWBNo = dw.GetAllFromQuery("select AirWayBill_No from Stock_Master where Stock_ID=" + dtBookingEdit.Rows[0]["Stock_ID"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text;
        string AirlineCode = txtAWBNO.Text.Substring(0, 3);
        DataTable dtAirline = dw.GetAllFromQuery("select Airline_Name from airline_Master where Airline_Code=" + AirlineCode);
        com.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = dtAirline.Rows[0]["Airline_Name"].ToString();
        DataTable dtFlightNo = dw.GetAllFromQuery("select fm.Flight_No from Flight_Master fm inner join Flight_Open fo on fm.Flight_ID=fo.Flight_ID where fo.Flight_Open_ID=" + dtBookingEdit.Rows[0]["Flight_Open_ID"].ToString());

        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = dtFlightNo.Rows[0]["Flight_No"].ToString();
        com.Parameters.Add("@Origin", SqlDbType.VarChar).Value = txtOrigin.Text.Substring(0, 3);
        DataTable dtDestinationCode = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_ID=" + dtBookingEdit.Rows[0]["Destination_ID"].ToString());
        com.Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtDestinationCode.Rows[0]["Destination_Code"].ToString();

        DataTable dtAgentCode = dw.GetAllFromQuery("select Agent_Code from Agent_Master where Agent_ID=" + dtBookingEdit.Rows[0]["Agent_ID"].ToString());
        com.Parameters.Add("@Agent_Code", SqlDbType.VarChar).Value = dtAgentCode.Rows[0]["Agent_Code"].ToString();
        DataTable dtSCN = dw.GetAllFromQuery("select Special_Commodity_Name from Special_Commodity_Master where Special_Commodity_ID=" + dtBookingEdit.Rows[0]["Special_Commodity_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_Name", SqlDbType.VarChar).Value = dtSCN.Rows[0]["Special_Commodity_Name"].ToString();
        DataTable dtS = dw.GetAllFromQuery("select Shipment_Name from Shipment_Master where Shipment_ID=" + dtBookingEdit.Rows[0]["Shipment_ID"].ToString());
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtS.Rows[0]["Shipment_Name"].ToString();

        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = dtBookingEdit.Rows[0]["Flight_Date"].ToString();
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtBookingEdit.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = dtBookingEdit.Rows[0]["Measurement_Unit"].ToString();
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Charged_Weight"].ToString());
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Spot_Rate"].ToString());
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = dtBookingEdit.Rows[0]["Agent_Deal_Remarks"].ToString();
        com.Parameters.Add("@Expected_Handover_Date", SqlDbType.DateTime).Value = dtBookingEdit.Rows[0]["Expected_Handover_Date"].ToString();
        //com.Parameters.Add("@Expected_Handover_Date", SqlDbType.DateTime).Value = FormatDateDD(txthandover_date.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtBookingEdit.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Freight_Amount"].ToString());
        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Special_Rate"].ToString());
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtBookingEdit.Rows[0]["Special_Amount"].ToString());

        com.Parameters.Add("@Handovered_Status", SqlDbType.Int).Value = 14;
        string status;
        if (Session["groupid"].ToString() == "5")
        {
            status = "3";
        }
        else
        {
            status = "9";
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = status;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        // com.Parameters.AddWithValue("@Entered_On",DateTime.Now);
        com.ExecuteNonQuery();

    }
    #endregion

    #region Update_BookingMaster
    public void Update_BookingMaster(SqlTransaction tr, SqlConnection con)
    {
        string update;
        long BookingID = 0;
        //con = new SqlConnection(strCon);
        if (Request.QueryString != null)
        {
            BookingID = long.Parse(Request.QueryString["Booking_ID"]);
        }


        try
        {
            //con.Open();

            //*************** Inserting Data in Booking_Master Table***************

            update = "update Booking_Master set Flight_Open_ID=@Flight_Open_ID,Booking_Date=@Booking_Date,Stock_ID=@Stock_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_ID=@Shipment_ID,City_ID=@City_ID,Destination_ID=@Destination_ID,Agent_ID=@Agent_ID,Flight_Date=@Flight_Date,No_of_Packages=@No_of_Packages,Measurement_Unit=@Measurement_Unit,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Spot_Rate=@Spot_Rate,Agent_Deal_Remarks=@Agent_Deal_Remarks,Expected_Handover_Date=@Expected_Handover_Date,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Special_Rate=@Special_Rate,Special_Amount=@Special_Amount,Handovered_Status=@Handovered_Status,Status=@Status,Entered_By=@Entered_By,Entered_On=@Entered_On,Adhoc_Rate=@Adhoc_Rate where Booking_ID=@Booking_ID";


            SqlCommand com = new SqlCommand(update, con, tr);
            com.CommandType = CommandType.Text;
            //DataTable dtFlightBookingCode = dw.GetAllFromQuery("select Flight_Booking_Code from Flight_Open where Flight_ID=" + FlightID);
            //if (dtFlightBookingCode.Rows.Count > 0)
            //{
            // com.Parameters.Add("@Flight_Booking_Code", SqlDbType.VarChar).Value = dtFlightBookingCode.Rows[0]["Flight_Booking_Code"].ToString();
            // }
            //com.Parameters.AddWithValue("@Booking_Date",FormatDateDD(txtAWBDate.Text));
            // com.Parameters.AddWithValue("@Booking_Date",FormatDateDD(txtAWBDate.Text));
            com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["Flight_Open_ID"].ToString());
            com.Parameters.Add("@Booking_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
            // com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = FlightID;

            DataTable dtStockID = dw.GetAllFromQuery("select Stock_ID from Stock_Master where AirWayBill_No='" + txtAWBNO.Text.Trim() + "'");
            if (dtStockID.Rows.Count > 0)
            {
                com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = dtStockID.Rows[0]["Stock_ID"].ToString();
            }
            com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
            com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
            com.Parameters.Add("@City_ID", SqlDbType.Int).Value = ViewState["City_ID"].ToString();
            com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
            com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["Agent_ID"].ToString());
            // com.Parameters.Add("@Booking_Dimension_ID", SqlDbType.Int).Value = txtXRayCharges.Text.Trim();
            //com.Parameters.Add("@Slab_ID", SqlDbType.Int).Value = 3;
            // com.Parameters.AddWithValue("@Flight_Date",DateTime.Now);
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);
            com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = txtPieces.Value;
            com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = rbCal.SelectedValue;
            com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = txtGrossWt.Value;
            com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = txtVolWt.Value;
            com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = txtChWt.Value;
            com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = txtSpotRate.Text;
            //com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = txtCommission.Text;
            //com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = txtSCRInc.Text;
            com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtAgentDealRemarks.Text;
            com.Parameters.AddWithValue("@Expected_Handover_Date", FormatDateDD(txthandover_date.Text));
            //com.Parameters.Add("@Expected_Handover_Date", SqlDbType.DateTime).Value = FormatDateDD(txthandover_date.Text);
            com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;

            com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
            com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);

            com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
            com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);

            com.Parameters.Add("@Handovered_Status", SqlDbType.Int).Value = 14;
            string status;
            if (Session["groupid"].ToString() == "5")
            {
                status = "3";
            }
            else
            {
                status = "9";
            }
            com.Parameters.Add("@Status", SqlDbType.Int).Value = status;
            com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
            com.Parameters.Add("@Adhoc_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtAdhocRate.Text);
            com.ExecuteNonQuery();
            //con.Close();
            //com.Connection.Close();
            //com.Dispose();
        }
        catch (SqlException sqlex)
        {
            //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");

        }
        finally
        {
            //if (con != null && con.State == ConnectionState.Open)
            //    con.Close();

        }
    }
    #endregion

    #region Update_BookingAWB
    public void Update_BookingAWB(long BookingID, SqlTransaction tr, SqlConnection con)
    {
        string update;
        long Booking_ID = 0;
        //con = new SqlConnection(strCon);
        try
        {
            //con.Open();

            update = "update Booking_AWB set Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Currency=@Currency,CHGS_Code=@CHGS_Code,Declared_Carriage_Value=@Declared_Carriage_Value,Declared_Custom_Value=@Declared_Custom_Value,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,Handling_Information=@Handling_Information,Nature_and_Quantity=@Nature_and_Quantity,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges,DMCharges=@DMCharges where Booking_ID=@Booking_ID";


            SqlCommand com = new SqlCommand(update, con, tr);
            com.CommandType = CommandType.Text;
            if (Request.QueryString != null)
            {
                Booking_ID = long.Parse(Request.QueryString["Booking_ID"]);
            }

            com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = Booking_ID;
            com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
            com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
            com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
            com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
            com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = txtCurrency.Text;
            com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = txtCGHSCode.Text;
            com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = txtDVCarriage.Text;
            com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = txtDVCustom.Text;
            com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
            com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
            com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
            com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = txtHouses.Value;
            com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
            com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
            com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = txtHandlingInformation.Text;
            com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = txtNatureGoods.Text;
            com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
            // com.Parameters.Add("@Total_Amount", SqlDbType.Decimal).Value = txtFreightAmount.Text;
            com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = txtDueAgentP.Text;
            com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = txtDueAgentC.Text;
            com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = txtDueCarrier.Text;
            com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = txtPrepaid.Text;
            com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = txtCollect.Text;
            com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
            com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
            com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
            com.Parameters.Add("@DMCharges", SqlDbType.Decimal).Value = decimal.Parse(txtDmcharges.Text);
            DataTable dtLogin = dw.GetAllFromQuery("select Login_Master_ID from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'");

            com.Parameters.Add("@Login_Master_ID", SqlDbType.BigInt).Value = decimal.Parse(dtLogin.Rows[0]["Login_Master_ID"].ToString());
            com.ExecuteNonQuery();
            //con.Close();
            //com.Dispose();
        }
        catch (SqlException sqlex)
        {
            //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            //if (con != null && con.State == ConnectionState.Open)
            //    con.Close();

        }
    }
    #endregion

    #region DeleteOldDimension
    public void DeleteOldDimension(long BookingID)
    {
        dw.GetAllFromQuery("delete from Booking_Dimensions where Booking_ID=" + BookingID);
    }
    #endregion

    #region Update_BookingDimesion
    public void Update_BookingDimesion(long BookingID, SqlTransaction tr, SqlConnection con)
    {
        string insert;
        // con = new SqlConnection(strCon);
        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {
            dtDimension = (DataTable)Session["dtTemp"];

            DeleteOldDimension(BookingID);

            for (int i = 0; i < dtDimension.Rows.Count; i++)
                try
                {
                    //con.Open();
                    //dw.GetAllFromQuery("delete from Booking_Dimensions where Booking_ID=" + BookingID);
                    insert = "insert into Booking_Dimensions(Booking_ID,No_of_Packages,Length,Breadth,Height,Total) values(@Booking_ID,@No_of_Packages,@Length,@Breadth,@Height,@Total)";

                    SqlCommand com = new SqlCommand(insert, con, tr);
                    com.CommandType = CommandType.Text;
                    com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
                    com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
                    com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
                    com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
                    com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
                    com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
                    com.ExecuteNonQuery();
                    //con.Close();
                    //com.Dispose();
                }
                catch (SqlException sqlex)
                {
                    //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
                }
                finally
                {
                    //if (con != null && con.State == ConnectionState.Open)
                    //    con.Close();
                }
        }
    }
    #endregion

    #region DeleteOldDimension
    public void DeleteOtherCharges(long BookingID)
    {
        dw.GetAllFromQuery("delete from Other_Charges where Booking_ID=" + BookingID);
    }
    #endregion

    #region Update_OtherCharges
    public void Update_OtherCharges(long BookingID, SqlTransaction tr, SqlConnection con)
    {
        string insert;
        //con = new SqlConnection(strCon);
        DeleteOtherCharges(BookingID);
        if (Session["dtOtherCharges"] != null)
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                try
                {
                    //con.Open();

                    insert = "insert into Other_Charges(Booking_ID,AirWayBill_No,Charge_Name,Amount,Prepaid_or_Collect) values(@Booking_ID,@AirWayBill_No,@Charge_Name,@Amount,@Prepaid_or_Collect)";

                    SqlCommand com = new SqlCommand(insert, con, tr);
                    com.CommandType = CommandType.Text;
                    com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
                    com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text;
                    com.Parameters.Add("@Charge_Name", SqlDbType.VarChar).Value = dt.Rows[i]["FeeName"].ToString();
                    com.Parameters.Add("@Amount", SqlDbType.Decimal).Value = dt.Rows[i]["Fee"].ToString();
                    com.Parameters.Add("@Prepaid_or_Collect", SqlDbType.VarChar).Value = dt.Rows[i]["PaymentType"].ToString();
                    com.ExecuteNonQuery();
                    //con.Close();
                    //com.Connection.Close();
                }
                catch (SqlException sqlex)
                {
                    //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
                }
                finally
                {
                    //if (con != null && con.State == ConnectionState.Open)
                    //    con.Close();
                }
            }
        }
    }
    #endregion

    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["Sno"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
            }
            TextBox txthader = grd.FooterRow.FindControl("txtheader") as TextBox;
            TextBox txtfee = grd.FooterRow.FindControl("txtvalue") as TextBox;
            DropDownList drp = (DropDownList)(grd.FooterRow.FindControl("ddlgrd"));
            string paymenttype = drp.SelectedItem.Text;
            DataRow dr = dt.NewRow();
            dr[1] = txthader.Text;
            dr[2] = txtfee.Text;
            dr[3] = paymenttype;
            dt.Rows.Add(dr);
            Session["dtOtherCharges"] = dt;
            decimal DueAgent = 0, DueAgentP = 0, DueAgentC = 0;
            foreach (DataRow rw in dt.Rows)
            {
                DueAgent = DueAgent + Convert.ToDecimal(rw["Fee"].ToString());
                if (rw["PaymentType"].ToString() == "PREPAID")
                {
                    DueAgentP = DueAgentP + Convert.ToDecimal(rw["Fee"].ToString());
                }
                if (rw["PaymentType"].ToString() == "COLLECT")
                {
                    DueAgentC = DueAgentC + Convert.ToDecimal(rw["Fee"].ToString());
                }
            }
            //****************************************
            txtDueAgentP.Text = DueAgentP.ToString();
            txtDueAgentC.Text = DueAgentC.ToString();
            txtDueAgent.Text = DueAgent.ToString();
            //****************************************

            //******Calculation of Dbcharges****************
            decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = dueP.ToString();
            decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = dueC.ToString();
            decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
            txtPrepaid.Text = PP.ToString();
            decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
            txtCollect.Text = CC.ToString();
            if (txtDueAgentC.Text != "0")
            {
                decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                //Taking 10% of Dbcharges*******************
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                {
                    txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                }
                else
                {
                    txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                }
            }
            else
            {
                txtDisbursmentCharges.Text = "0";
            }
            //****End of Dbcharges**************************

            //*****Managing Values After PostBack***********

            decimal ACI = decimal.Parse(Hidden1.Value) * decimal.Parse(txtHouses.Value);
            txtACIFee.Text = ACI.ToString();
            //decimal Due = decimal.Parse(Hidden3.Value) + (ACI - decimal.Parse(Hidden1.Value));
            decimal Result = Convert.ToDecimal(Hidden3.Value) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text)+decimal.Parse(txtDmcharges.Text);
            Result = Math.Round(Result, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = Result.ToString();

            //*****End of Manage Values******************

            grd.DataSource = dt;
            grd.DataBind();

            if (rbDueFreight.SelectedValue == "PREPAID")
            {
                decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Total_Prepaid = Total_Prepaid + decimal.Parse(txtFreightAmount.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = txtDueAgentC.Text;
                }
                else
                {
                    decimal Total_Collect = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentC.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = Total_Prepaid.ToString();
                }
            }
            else
            {
                decimal Total_Collect = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentC.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    decimal Total_Prepaid = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentP.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = Total_Collect.ToString();
                }
                else
                {
                    Total_Collect = Total_Collect + decimal.Parse(txtFreightAmount.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = txtDueAgentP.Text;
                }
            }
        }
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int Sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "PREPAID")
                    {
                        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentP.Text = DueAgentP.ToString();
                        txtPrepaid.Text = Prepaid.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "COLLECT")
                    {
                        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentC.Text = DueAgentC.ToString();
                        decimal Collect = decimal.Parse(txtCollect.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtCollect.Text = Collect.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    dt.Rows[e.RowIndex].Delete();

                    //******Calculation of DbCharges*****************
                    decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = dueP.ToString();
                    decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = dueC.ToString();
                    decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = PP.ToString();
                    decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
                    txtCollect.Text = CC.ToString();
                    if (txtDueAgentC.Text != "0")
                    {
                        decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                        //Taking 10% of Dbcharges*******************
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                        decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                        if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                        {
                            txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                        }
                        else
                        {
                            txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                        }
                    }
                    else
                    {
                        txtDisbursmentCharges.Text = "0";
                    }
                    //***End of Calculation of DbCharges*****************
                }
                break;
            }
        }//****End of Foreach loop**********

        //**********Calculation of DueCarrier on Update*********
        decimal Result = Convert.ToDecimal(Hidden3.Value) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtDmcharges.Text);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        if (dt.Rows.Count > 0)
        {
            Session["dtOtherCharges"] = dt;
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            DataTable dtBeginCharges = MakeTableCharges();
            Session["dtOtherCharges"] = dtBeginCharges;
            grd.DataSource = dtBeginCharges;
            grd.DataBind();
        }
    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grd.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
        }
        else
        {
            lblmsg.Visible = false;
            Label edit = (Label)grd.Rows[e.NewEditIndex].FindControl("lblpaymenttype");
            Label txtFee = (Label)grd.Rows[e.NewEditIndex].FindControl("txtvalue");
            ViewState["Fee"] = txtFee.Text;
            ViewState["PaymentMode"] = edit.Text;
            ViewState["edit"] = edit.Text;
            ViewState["et"] = ViewState["edit"];
            grd.EditIndex = e.NewEditIndex;
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            grd.DataSource = dt;
            grd.DataBind();
        }

    }
    protected void grd_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        string strheader = ((TextBox)grd.Rows[e.RowIndex].FindControl("txtheader")).Text;
        //int value =Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        decimal value = Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        DropDownList drp = (DropDownList)(grd.Rows[e.RowIndex].FindControl("ddlgrd"));
        string paymenttype = drp.SelectedItem.Text;

        decimal Fee = Convert.ToDecimal(ViewState["Fee"]);
        string PaymentMode = Convert.ToString(ViewState["PaymentMode"]);

        //********* FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    txtCollect.Text = Collect.ToString();
                }
            }
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    txtPrepaid.Text = Prepaid.ToString();
                }
            }
        }

        //********End of FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "COLLECT")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //}
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "PREPAID")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();

            //    }
            //}

        }

        //************** Calculation Of DbCharges*********
        decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
        txtDueAgentP.Text = dueP.ToString();
        decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
        txtDueAgentC.Text = dueC.ToString();
        decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
        txtPrepaid.Text = PP.ToString();
        decimal CC = Math.Round(decimal.Parse(txtCollect.Text));
        txtCollect.Text = CC.ToString();
        if (txtDueAgentC.Text != "0")
        {
            decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
            //Taking 10% of Dbcharges*******************
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
            decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
            if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
            {
                txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
            }
        }
        else
        {
            txtDisbursmentCharges.Text = "0";
        }

        //********End of Calculation Of DbCharges*********

        //**********Calculation of DueCarrier on Update*********
        decimal Result = Convert.ToDecimal(Hidden3.Value) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtDmcharges.Text);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == sno.ToString())
            {
                dr[1] = strheader;
                dr[2] = value;
                dr[3] = paymenttype;
            }
        }
        Session["dtOtherCharges"] = dt;
        grd.DataSource = dt;
        grd.EditIndex = -1;
        grd.DataBind();


    }
    protected void grd_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd.EditIndex = -1;
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        grd.DataSource = dt;
        grd.DataBind();
    }
    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (ViewState["edit"].ToString() == ViewState["et"].ToString())
            {
                Label lbl = (Label)e.Row.Cells[3].FindControl("lblpaymenttype");
                DropDownList ddl = (DropDownList)e.Row.Cells[3].FindControl("ddlgrd");
                if (ViewState["edit"].ToString() == "PREPAID")
                {
                    //ddl.SelectedIndex=2;
                }
                else
                {
                    //ddl.SelectedIndex=1;

                }
            }
            if (grd.EditIndex == e.Row.RowIndex)
            {
                //DropDownList ddlGrd = (DropDownList)e.Row.FindControl("ddlgrd");
                //ddlGrd.SelectedItem.Text = ViewState["PaymentMode"].ToString();

                //ddlGrd.Items.Add(new ListItem("PREPAID","PREPAID"));
                //ddlGrd.Items.Add(new ListItem("COLLECT","COLLECT"));
                //ddlGrd.SelectedIndex = ddlGrd.Items.IndexOf(ddlGrd.Items.FindByText((e.Row.c));

            }

        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("Booking_Details.aspx");
    }
    protected void btnSearch_Click1(object sender, EventArgs e)
    {
        //RateGrid.SelectedRowStyle.BackColor = System.Drawing.Color.Red;
        //RateGrid.SelectedRowStyle =
        //lblserver.Text = "Now Please Select the Flight to Modify Booking ";
        DateTime dts = Convert.ToDateTime(FormatDateDD(txtFlightDate.Text.Trim()));
        if (int.Parse(txtFlightDays.Value) < 0)
        {

            dts = dts.AddDays(int.Parse(txtFlightDays.Value));

        }



        lblserver.Visible = true;
        CheckBox1.Visible = false;
        lblMessage.Visible = false;
        Button1.Enabled = false;
        ViewState["AgentRateID"] = null;
        ViewState["SlabID"] = null;
        ViewState["NextSlabID"] = null;
        ViewState["nextslabChwt"] = null;
        ViewState["BeneficialPriceValue"] = null;
        ViewState["Min"] = null;
        ViewState["nextslabrate"] = null;

        RateGrid.SelectedRowStyle.BackColor = System.Drawing.Color.LightGray;//#E6E5E5

        RateGrid.Visible = true;

        con = new SqlConnection(strCon);
        com = new SqlCommand("[BOOKING_EDIT_RATE]", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Origin", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        com.Parameters.Add("@Destination", SqlDbType.BigInt).Value = long.Parse(ddlDestination.SelectedValue);
        com.Parameters.Add("@FlightDate", SqlDbType.DateTime).Value = dts.ToString();
        com.Parameters.Add("@AirlineDetailID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@ShipmentID", SqlDbType.Int).Value = int.Parse(ddlShipmentType.SelectedValue);
        com.Parameters.Add("@Gw", SqlDbType.Decimal).Value = decimal.Parse(txtGrossWt.Value);
        com.Parameters.Add("@Chwt", SqlDbType.Decimal).Value = decimal.Parse(txtChWt.Value);
        com.Parameters.Add("@Flightdays", SqlDbType.Int).Value = Math.Abs(int.Parse(txtFlightDays.Value));
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);

        //****************************************************************
        if (dt.Columns.Count != 1)
        {
            if (dt.Rows.Count > 0)
            {
                ViewState["AgentRateID"] = long.Parse(dt.Rows[0]["AgentRateID"].ToString());
                ViewState["SlabID"] = int.Parse(dt.Rows[0]["SlabID"].ToString());
                ViewState["NextSlabID"] = int.Parse(dt.Rows[0]["NextSlabID"].ToString());
                ViewState["nextslabChwt"] = decimal.Parse(dt.Rows[0]["NextSlabChwt"].ToString());
                ViewState["BeneficialPriceValue"] = decimal.Parse(dt.Rows[0]["BeneficialPriceValue"].ToString());
                decimal Min = decimal.Parse(dt.Rows[0]["Min"].ToString());
                Min = Math.Round(Min, MidpointRounding.AwayFromZero);
                ViewState["Min"] = Min.ToString();

                msg.Visible = false;
                RateGrid.DataSource = dt;
                RateGrid.DataBind();
                if (NA == 0)
                {
                    RateGrid.Columns[9].Visible = false;
                }
                else
                {
                    RateGrid.Columns[9].Visible = true;
                }
            }
            else
            {
                RateGrid.DataSource = null;
                RateGrid.DataBind();
                msg.Visible = true;
                msg.Text = "Flight not found";
            }
        }
        else
        {
            RateGrid.DataSource = null;
            RateGrid.DataBind();
            msg.Visible = true;
            msg.Text = "Rates not found";
        }


    }
    protected void RateGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            bool disC = true;

            bool disOnMin = true;
            bool MinCheck = true;
            //decimal TariffRate=decimal.Parse(e.Row.Cells[5].Text);
            decimal TotalPayableAmount = decimal.Parse(e.Row.Cells[6].Text) * decimal.Parse(txtChWt.Value);
            decimal Min = decimal.Parse(ViewState["Min"].ToString());
            decimal TariffRate = decimal.Parse(e.Row.Cells[6].Text);
            if (TotalPayableAmount > Min)
            {
                decimal TPA = Math.Round(TotalPayableAmount, 2);
                e.Row.Cells[7].Text = TPA.ToString();
            }
            else//Minimum Case
            {
                MinCheck = false;
                decimal Minimum = Math.Round(Min, 2);
                e.Row.Cells[7].Text = Minimum.ToString();
                e.Row.Cells[6].Text = Minimum.ToString();//change bye Rajinder

                string flight_openid = e.Row.Cells[12].Text;
                //******************Minimum pe Discount******************

                con = new SqlConnection(strCon);
                com = new SqlCommand("[EDIT_MIN_RATE]", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Origin", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
                com.Parameters.Add("@Destination", SqlDbType.BigInt).Value = long.Parse(ddlDestination.SelectedValue);
                com.Parameters.Add("@FlightDate", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);
                com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
                com.Parameters.Add("@Agent_Rate_ID", SqlDbType.Int).Value = Convert.ToInt64(ViewState["AgentRateID"]);

                com.Parameters.Add("@AgentSlabID", SqlDbType.Int).Value = Convert.ToInt32(ViewState["SlabID"]);

                com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(ddlShipmentType.SelectedValue);
                com.Parameters.Add("@Flightdays", SqlDbType.Int).Value = int.Parse(txtFlightDays.Value);
                com.Parameters.Add("@Flight_Open_Id", SqlDbType.BigInt).Value = long.Parse(flight_openid);

                SqlDataAdapter da = new SqlDataAdapter(com);
                DataTable dt_Min_Rate = new DataTable();
                da.Fill(dt_Min_Rate);

                if (dt_Min_Rate.Rows.Count > 0)
                {
                    disOnMin = false;

                    e.Row.Cells[11].Text = dt_Min_Rate.Rows[0]["Prefix_Name"].ToString();
                    e.Row.Cells[8].Text = dt_Min_Rate.Rows[0]["DiscountedRate"].ToString();
                    e.Row.Cells[9].Text = dt_Min_Rate.Rows[0]["DiscountedRate"].ToString();
                }

            }

            //decimal TariffRate = decimal.Parse(e.Row.Cells[6].Text);
            decimal nextslabrate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) * Convert.ToDecimal(ViewState["nextslabChwt"]);
            ViewState["nextslabrate"] = nextslabrate;
            decimal freightamount = decimal.Parse(e.Row.Cells[7].Text);

            //if (Convert.ToDecimal(ViewState["BeneficialPriceValue"]) >= TariffRate)

            //******When nextSlab is not Exist In case of AirlineSlab not Exist***********
            if (ViewState["BeneficialPriceValue"] == null && ViewState["nextslabChwt"] == null)
            {
                e.Row.Cells[10].Text = "NA";
                lblMessage.Visible = false;
            }
            if (nextslabrate >= freightamount)
            {
                e.Row.Cells[10].Text = "NA";
                lblMessage.Visible = false;
            }
            else
            {
                if (nextslabrate != 0)
                {
                    NA = 1;
                    ViewState["Flag"] = "1";
                    //lblMessage.Visible = true;
                    //CheckBox1.Visible = true;
                    lblMessage.Text = "**Your Shipment is Appicable for the next Slab of " + ViewState["nextslabChwt"].ToString() + " Kg. Pls change the chargeable weight to check the special amt otherwise system will   automatically change the chargeable weight to " + ViewState["nextslabChwt"].ToString() + " Kg";

                    e.Row.Cells[10].Text = ViewState["BeneficialPriceValue"].ToString();
                    decimal strNextSlabRate = decimal.Parse(e.Row.Cells[10].Text) * Convert.ToDecimal(ViewState["nextslabChwt"]);
                    //decimal strNextSlabRate =decimal.Parse(e.Row.Cells[10].Text) * decimal.Parse(txtChWt.Value);
                    e.Row.Cells[10].Text = strNextSlabRate.ToString();
                }
                else
                {
                    lblMessage.Visible = false;
                    e.Row.Cells[10].Text = "NA";
                }
            }
            //if (MinCheck == false && disOnMin == false)//Minimum ke case main Can not enter in these Prefix
            //{
            if (e.Row.Cells[11].Text.Trim() == "-")
            {
                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //     e.Row.Cells[7].Text="0";
                //     e.Row.Cells[8].Text="0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) - decimal.Parse(e.Row.Cells[9].Text);
                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                //DiscountedRate = Math.Round(DiscountedRate, 2);

                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt=decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChWt.Value), 2));
                }
                else
                {
                    if (disOnMin == true)
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        // e.Row.Cells[9].Text = Min_rate.ToString(); //Change By Rajinder
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder

                    }
                    else
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }

                }
                //e.Row.Cells[9].Text = DiscountedRate.ToString();
                //}
            }

            if (e.Row.Cells[11].Text.Trim() == "+")
            {

                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //    e.Row.Cells[7].Text = "0";
                //    e.Row.Cells[8].Text = "0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) + decimal.Parse(e.Row.Cells[9].Text);

                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                //DiscountedRate = Math.Round(DiscountedRate, 2);
                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt = decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChWt.Value), 2));
                }
                else
                {
                    if (disOnMin == true)
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        //e.Row.Cells[9].Text = Min_rate.ToString();//Change By Rajinder
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder

                    }
                    else
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }

                }

                //e.Row.Cells[9].Text = DiscountedRate.ToString();
                //}
            }
            if (e.Row.Cells[11].Text.Trim() == "%")
            {
                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //    e.Row.Cells[7].Text = "0";
                //    e.Row.Cells[8].Text = "0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) * decimal.Parse(e.Row.Cells[9].Text);
                DiscountedRate = DiscountedRate / 100;
                // e.Row.Cells[8].Text = DiscountedRate.ToString();
                DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) - DiscountedRate;
                DiscountedRate = Math.Round(DiscountedRate, 2);
                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt = decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChWt.Value), 2));
                }
                else
                {
                    if (disOnMin == true)  // Minimum Case Discount Not Issue
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder
                    }
                    else// Minimum Case Discount Issue
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }
                }

                //}
                // }
            }//*****End of MinCheck True and DisonMin true*********
            if (disC == true)
            {
                e.Row.Cells[9].Text = e.Row.Cells[7].Text;//Change By Rajinder
                e.Row.Cells[8].Text = e.Row.Cells[6].Text;//Change By Rajinder
            }
            //checking for discounting rate to min rate

            //decimal d_rate = decimal.Parse(e.Row.Cells[9].Text);
            //if (drate)
            //{
            //    if (drate > Min)
            //    {
            //        e.Row.Cells[9].Text = d_rate;
            //    }
            //    else
            //    { 
            //         decimal Min_rate = Math.Round(Min, 2);
            //         e.Row.Cells[9].Text = Min_rate;
            //    }
            //}

            //******************************************************
            //e.Row.Cells[11].Visible = false;

            //*********Time Field***************
            // e.Row.Cells[].Text

            //***********City and Destination***********
            int CityID = Convert.ToInt32(e.Row.Cells[4].Text);
            long DestinationID = Convert.ToInt64(e.Row.Cells[5].Text);
            DataTable dtCity = dw.GetAllFromQuery("select City_Name,City_Code from City_Master where City_ID=" + ViewState["City_ID"].ToString());
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Name,Destination_Code from Destination_Master where Destination_ID=" + DestinationID);
            if (dtCity.Rows.Count > 0)
            {
                e.Row.Cells[4].Text = dtCity.Rows[0]["City_Code"].ToString();
            }
            if (dtDestination.Rows.Count > 0)
            {
                e.Row.Cells[5].Text = dtDestination.Rows[0]["Destination_Code"].ToString();
            }
        }
        e.Row.Cells[11].Visible = false;
        e.Row.Cells[12].Visible = false;//10:08 prefix name
    }
    protected void RateGrid_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblserver.Visible = false;
        lblNextSlab.Visible = false;
        Button1.Enabled = true;
        Flag = true;
        //DueCarrierSelect();
        DataTable dtAirlineCode = dw.GetAllFromQuery("Select Airline_Code from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'");
        DataTable dtAWbNo = new DataTable();
        if (dtAirlineCode.Rows.Count > 0)
        {
            string Airline_Code = dtAirlineCode.Rows[0]["Airline_Code"].ToString();
            dtAWbNo = dw.GetAllFromQuery("select Stock_ID,AirWayBill_No from Stock_Master where Status=16 and substring(AirWayBill_No,1,3)='" + Airline_Code + "' and Agent_ID=" + ViewState["Agent_ID"].ToString());
        }
        //if (dtAWbNo.Rows.Count > 0)
        //{
        GridViewRow gvr = RateGrid.SelectedRow;

        long FlightID = Convert.ToInt64(RateGrid.SelectedDataKey.Value);

        ViewState["Flight_Open_ID"] = gvr.Cells[12].Text;
        decimal Tr = decimal.Parse(gvr.Cells[6].Text);
        Tr = Math.Round(Tr, MidpointRounding.AwayFromZero);
        gvr.Cells[6].Text = Tr.ToString();
        decimal Sa = decimal.Parse(gvr.Cells[7].Text);
        Sa = Math.Round(Sa, MidpointRounding.AwayFromZero);
        gvr.Cells[7].Text = Sa.ToString();
        decimal Sr = decimal.Parse(gvr.Cells[8].Text);
        Sr = Math.Round(Sr, MidpointRounding.AwayFromZero);
        gvr.Cells[8].Text = Sr.ToString();
        decimal Fa = decimal.Parse(gvr.Cells[9].Text);
        Fa = Math.Round(Fa, MidpointRounding.AwayFromZero);
        gvr.Cells[9].Text = Fa.ToString();

        if (gvr.Cells[10].Text == "NA")
        {
            txtTariffRate.Text = gvr.Cells[6].Text;
            txtSpAmt.Text = gvr.Cells[7].Text;
            txtSpRate.Text = gvr.Cells[8].Text;
            txtFreightAmount.Text = gvr.Cells[9].Text;
            lblSpecialAmount.Text = txtFreightAmount.Text;
            txtFlightDate.Text = ((Label)RateGrid.SelectedRow.Cells[2].FindControl("FltDate")).Text;
            txtFlightNo.Text = gvr.Cells[1].Text;
        }
        else
        {
            txtChWt.Value = ViewState["nextslabChwt"].ToString();
            CheckBox1.Checked = true;
            lblMessage.Visible = true;
            CheckBox1.Visible = true;

            txtFlightNo.Text = gvr.Cells[1].Text;
            txtFlightDate.Text = ((Label)RateGrid.SelectedRow.Cells[2].FindControl("FltDate")).Text;
            txtTariffRate.Text = ViewState["BeneficialPriceValue"].ToString();
            txtSpAmt.Text = ViewState["nextslabrate"].ToString();
            DataTable dtnextSlabDiscount = dw.GetAllFromQuery("select * from nextSlabDiscount where Flight_ID=" + FlightID + " and Flight_Open_ID=" + gvr.Cells[12].Text + " and Slab_ID=" + Convert.ToString(Session["NextSlabID"]) + " and Destination_ID=" + ddlDestination.SelectedValue);
            if (dtnextSlabDiscount.Rows.Count > 0)
            {
                if (dtnextSlabDiscount.Rows[0]["Prefix_Name"].ToString().Trim() == "-")
                {
                    decimal DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) - decimal.Parse(dtnextSlabDiscount.Rows[0]["Price_Value"].ToString());
                    DiscountedRate = Math.Round(DiscountedRate, 2);
                    txtSpRate.Text = DiscountedRate.ToString();
                    decimal SpecialAmount = DiscountedRate * Convert.ToDecimal(Session["nextslabChwt"]);
                    SpecialAmount = Math.Round(SpecialAmount, 2);
                    txtFreightAmount.Text = SpecialAmount.ToString();
                    lblSpecialAmount.Text = txtFreightAmount.Text;
                }
                if (dtnextSlabDiscount.Rows[0]["Prefix_Name"].ToString().Trim() == "+")
                {
                    decimal DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) + decimal.Parse(dtnextSlabDiscount.Rows[0]["Price_Value"].ToString());
                    DiscountedRate = Math.Round(DiscountedRate, 2);
                    txtSpRate.Text = DiscountedRate.ToString();
                    decimal SpecialAmount = DiscountedRate * Convert.ToDecimal(ViewState["nextslabChwt"]);
                    SpecialAmount = Math.Round(SpecialAmount, 2);
                    txtFreightAmount.Text = SpecialAmount.ToString();
                    lblSpecialAmount.Text = txtFreightAmount.Text;
                }
                if (dtnextSlabDiscount.Rows[0]["Prefix_Name"].ToString().Trim() == "%")
                {
                    decimal DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) * decimal.Parse(dtnextSlabDiscount.Rows[0]["Price_Value"].ToString());
                    DiscountedRate = DiscountedRate / 100;
                    DiscountedRate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) - DiscountedRate;
                    DiscountedRate = Math.Round(DiscountedRate, 2);
                    txtSpRate.Text = DiscountedRate.ToString();
                    decimal SpecialAmount = DiscountedRate * Convert.ToDecimal(ViewState["nextslabChwt"]);
                    SpecialAmount = Math.Round(SpecialAmount, 2);
                    txtFreightAmount.Text = SpecialAmount.ToString();
                    lblSpecialAmount.Text = txtFreightAmount.Text;
                }
            }

            else
            {
                txtTariffRate.Text = ViewState["BeneficialPriceValue"].ToString();
                txtSpAmt.Text = ViewState["nextslabrate"].ToString();
                txtSpRate.Text = ViewState["BeneficialPriceValue"].ToString();
                txtFreightAmount.Text = ViewState["nextslabrate"].ToString();
                lblSpecialAmount.Text = txtFreightAmount.Text;

            }
        }

        DueCarrierSelect();
        decimal Booking_Amount = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueCarrier.Text);

        //}
        //else
        //{
        //    lblm.Visible = true;
        //}
    }
    public void DueCarrierSelect()
    {
        decimal A = 0, B = 0, C = 0, Gw = 0, Cw = 0, FSC = 0, AWBFee = 0, DisbursmentCharges = 0, ACIFee = 0, Security_Surcharge = 0, Xray = 0;
        if (txtGrossWt.Value != "" && txtChWt.Value != "")
        {
            Gw = decimal.Parse(txtGrossWt.Value);
            Cw = decimal.Parse(txtChWt.Value);
        }

        DataTable dtCharges = dw.GetAllFromQuery("select FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,DisBursementCharges from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());


        DataTable dtAgentRateID = dw.GetAllFromQuery("select Agent_Rate_ID from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and Destination=" + ddlDestination.SelectedValue + " and Shipment_ID=" + ddlShipmentType.SelectedValue + " and Status=2 and valid_from <= '" + FormatDateDD(txtFlightDate.Text) + "' and valid_to >= '" + FormatDateDD(txtFlightDate.Text) + "'");
        long AgentRateID = 0;
        DataTable dtChargesDetails = new DataTable();
        if (dtAgentRateID.Rows.Count > 0)
        {

            dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue + " and Agent_Rate_ID=" + long.Parse(dtAgentRateID.Rows[0]["Agent_Rate_ID"].ToString()));
        }
        if (dtCharges.Rows.Count > 0)
        {
            if (dtCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Cw * FSC;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Gw * FSC;
                    }
                }
            }
            if (dtCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Cw * Security_Surcharge;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Gw * Security_Surcharge;
                    }
                }
            }
            if (dtCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Cw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Gw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
            }
            A = Math.Round(A, MidpointRounding.AwayFromZero);
            B = Math.Round(B, MidpointRounding.AwayFromZero);
            C = Math.Round(C, MidpointRounding.AwayFromZero);
            txtFSC.Text = A.ToString();
            txtWSC.Text = B.ToString();
            txtXRAY.Text = C.ToString();
            DataTable dtOrigin = dw.GetAllFromQuery("select City_ID from City_Master where City_Code='" + txtOrigin.Text.Substring(0, 3) + "'");

            //**** For Catrage Charges***************
            if (dtOrigin.Rows[0]["City_ID"].ToString() == "18")
            {
                if (decimal.Parse(txtGrossWt.Value) >= 50)
                {
                    txtCatrage.Text = txtGrossWt.Value;
                }
                else
                {
                    txtCatrage.Text = "50";
                }
            }
            else
            {
                txtCatrage.Text = "0";
            }
            //****End of Catrage Charges*************


            //**** For AWB Fee***********************
            if (decimal.Parse(txtChWt.Value) >= 150)
            {
                txtAWBFee.Text = txtChWt.Value;
            }
            else
            {
                txtAWBFee.Text = "150";
            }
            //**** For End ofAWB Fee*****************
            decimal TotalDueCarrier = A + B + C + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtDmcharges.Text);
            TotalDueCarrier = Math.Round(TotalDueCarrier, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = TotalDueCarrier.ToString();

            if (rbDueFreight.SelectedValue == "PREPAID")
            {
                decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Total_Prepaid = Total_Prepaid + decimal.Parse(txtFreightAmount.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = txtDueAgentC.Text;
                }
                else
                {
                    decimal Total_Collect = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentC.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = Total_Prepaid.ToString();
                }
            }
            else
            {
                decimal Total_Collect = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentC.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    decimal Total_Prepaid = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentP.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = Total_Collect.ToString();
                }
                else
                {
                    Total_Collect = Total_Collect + decimal.Parse(txtFreightAmount.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = txtDueAgentP.Text;
                }
            }
        }
    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                lblserver.Visible = true;
                Button1.Enabled = false;
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["SNo"].ToString() == "0")
                    {
                        dt.Rows[0].Delete();
                    }
                }
                DataRow dr = dt.NewRow();
                //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames

                decimal L = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtl")).Text);
                decimal W = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtw")).Text);
                decimal H = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txth")).Text);
                decimal P = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);
                // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

                // Calculatin Volume Wait
                decimal Volume_Wt;
                if (rbCal.SelectedValue == "Cm")
                {
                    Volume_Wt = (L * W * H * P) / 6000;
                }
                else
                {
                    Volume_Wt = (L * W * H * P) / 366;
                }


                //Prepare the Insert Command of the DataSource control
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = Math.Round(Volume_Wt, 3);
                dt.Rows.Add(dr);
                int Pieces = 0;
                decimal VoulmeWt = 0;
                foreach (DataRow rw in dt.Rows)
                {
                    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                }
                string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                txtPieces.Value = Pieces.ToString();
                if (txtGrossWt.Value != "")
                {
                    VoulmeWt = Math.Round(VoulmeWt, 3);
                    txtVolWt.Value = VoulmeWt.ToString();
                    if (decimal.Parse(txtGrossWt.Value) > VoulmeWt)
                    {
                        decimal Gw = Math.Round(decimal.Parse(txtGrossWt.Value), 3);
                        txtChWt.Value = Gw.ToString();
                    }
                    else
                    {
                        VoulmeWt = Math.Round(VoulmeWt, 3);
                        txtChWt.Value = VoulmeWt.ToString();
                    }
                }
                else
                {
                    VoulmeWt = Math.Round(VoulmeWt, 3);
                    txtVolWt.Value = VoulmeWt.ToString();
                }

                //ViewState["Volume_Wt"]=VoulmeWt.ToString();
                Session["dtTemp"] = dt;
                grdCal.DataSource = dt;
                grdCal.DataBind();
                ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;

                //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Order added successfully');</script>");
                //string s1 = "SELECT Fltno,hh,mm,fltdate,id FROM ac_fltDetails_tran ORDER BY fltno";
                //AccessDataSource1.SelectCommand = s1;


                //GridViewRow gv = GridView2.Rows[0];
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;

                //fill();


            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }
    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {


            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");


        }
    }
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblserver.Visible = true;
        Button1.Enabled = false;
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                int Pieces = 0;
                decimal VoulmeWt = 0;
                foreach (DataRow rw in dt.Rows)
                {
                    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                }
                str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                txtPieces.Value = Pieces.ToString();
                VoulmeWt = Math.Round(VoulmeWt, 3);
                if (txtGrossWt.Value != "")
                {
                    txtVolWt.Value = VoulmeWt.ToString();
                    decimal gw = decimal.Parse(txtGrossWt.Value);
                    gw = Math.Round(gw, 3);
                    txtGrossWt.Value = gw.ToString();
                    if (decimal.Parse(txtGrossWt.Value) > VoulmeWt)
                    {
                        txtChWt.Value = txtGrossWt.Value;
                    }
                    else
                    {
                        txtChWt.Value = VoulmeWt.ToString();
                    }
                }
                else
                {
                    txtVolWt.Value = VoulmeWt.ToString();
                }
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
        }
        else
        {
            //DataTable dtBeginDimension = (DataTable)ViewState["dtDimension"];
            DataTable dtBeginDimension = MakeTableDimension();
            Session["dtTemp"] = dtBeginDimension;
            grdCal.DataSource = dtBeginDimension;
            grdCal.DataBind();
        }


    }
    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
        }
        else
        {
            lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        lblserver.Visible = true;
        Button1.Enabled = false;
        DataTable dt = (DataTable)Session["dtTemp"];
        //string [] Key = {"SNo"}; 
        //grdCal.DataKeyNames = Key;
        //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames
        // int SNo = Convert.ToInt16(((TextBox)grdCal.FindControl("txtSNo")).Text);
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        decimal L = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text);
        decimal W = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtw")).Text);
        decimal H = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txth")).Text);
        decimal P = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtp")).Text);
        // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

        // Calculatin Volume Wait
        decimal Volume_Wt;

        if (rbCal.SelectedValue == "Cm")
        {
            Volume_Wt = (L * W * H * P) / 6000;
        }
        else
        {
            Volume_Wt = (L * W * H * P) / 366;

        }
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = Math.Round(Volume_Wt, 3);
            }
        }

        int Pieces = 0;
        decimal VoulmeWt = 0;
        foreach (DataRow rw in dt.Rows)
        {
            Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
            VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
        }
        string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
        txtPieces.Value = Pieces.ToString();
        txtVolWt.Value = VoulmeWt.ToString();
        Volume_Wt = VoulmeWt;
        //txtVolWt.Value = Convert.ToString(Math.Round(Volume_Wt, 2));

        if (txtGrossWt.Value != "")
        {
            Volume_Wt = Math.Round(Volume_Wt, 3);
            txtVolWt.Value = Volume_Wt.ToString();
            decimal gw = decimal.Parse(txtGrossWt.Value);
            gw = Math.Round(gw, 3);
            txtGrossWt.Value = gw.ToString();
            if (decimal.Parse(txtGrossWt.Value) > Volume_Wt)
            {
                txtChWt.Value = txtGrossWt.Value;
            }
            else
            {
                txtChWt.Value = Volume_Wt.ToString();
            }
        }
        else
        {
            Volume_Wt = Math.Round(Volume_Wt, 3);
            txtVolWt.Value = Volume_Wt.ToString();
        }
        //ViewState["Volume_Wt"] = Convert.ToString(Math.Round(Volume_Wt, 2));
        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();
        ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        // txtChWt.Value= ViewState["nextslabChwt"].ToString();

        GridViewRow gvr = RateGrid.SelectedRow;
        if (gvr != null)
        {
            txtTariffRate.Text = gvr.Cells[6].Text;
            txtSpAmt.Text = gvr.Cells[7].Text;
            txtSpRate.Text = gvr.Cells[8].Text;
            txtFreightAmount.Text = gvr.Cells[9].Text;
            lblSpecialAmount.Text = txtFreightAmount.Text;
            lblMessage.Visible = false;
            CheckBox1.Visible = false;
            if (Convert.ToDecimal(txtVolWt.Value) > Convert.ToDecimal(txtGrossWt.Value))
            {
                txtChWt.Value = txtVolWt.Value;

            }
            else
            {
                txtChWt.Value = txtGrossWt.Value;
            }
        }
        else
        {
            lblNextSlab.Visible = true;
        }
        // DueCarrierSelect();
    }

    //public void LoadGstStateCode()
    //{
    //    try
    //    {
    //        string strAgent = "select * from GstStateCode order by Statecode";
    //        con = new SqlConnection(strCon);
    //        con.Open();
    //        com = new SqlCommand(strAgent, con);
    //        SqlDataReader dr = com.ExecuteReader();
    //        ddlGstStateCode.Items.Insert(0, "- -Select- -");
    //        ddlGstStateCode.Items[0].Value = "0";
    //        while (dr.Read())
    //        {
    //            ddlGstStateCode.Items.Add(new ListItem(dr["StateCode"].ToString() + "-" + dr["State"].ToString(), dr["StateCode"].ToString()));
    //        }
    //        con.Close();
    //    }
    //    catch (SqlException sqe)
    //    {
    //        string err = sqe.ToString();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }
    //}

    //protected void ddlGst_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (ddlGst.SelectedValue != "0")
    //    {
    //        txtGstNo.Text = ddlGst.SelectedItem.Text;
    //        txtGstAddr.Text = ddlGst.SelectedItem.Text;
    //    }
    //    else
    //    {
    //        txtGstNo.Text = "";

    //    }
    //}
    //protected void ddlGstStateCode_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (ddlGstStateCode.SelectedValue != "0" && (txtGstNo.Text == "" && ddlGst.SelectedValue == "0"))
    //    {

    //        txtGstNo.Text = ddlGstStateCode.SelectedValue;

    //        txtGstAddr.Text = ddlGstStateCode.SelectedItem.Text;
    //    }
    //    if (txtGstNo.Text == "00" || txtGstNo.Text == "0")
    //    {
    //        txtGstNo.Text = ddlGstStateCode.SelectedValue;

    //        txtGstAddr.Text = ddlGstStateCode.SelectedItem.Text;
    //    }
    //}
}