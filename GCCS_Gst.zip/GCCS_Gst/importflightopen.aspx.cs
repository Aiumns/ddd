using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
// last modify by hn mishra on dataed 5/04/2008
public partial class importflightopen : System.Web.UI.Page
{
    #region Variable declaration
    SqlConnection con;
    bool checkid = false;
    public string insertvalue = "";
    SqlCommand com;
    SqlDataReader rdr;
    SqlTransaction tr;
     public string zero;
    public string firsttwoalfa = "";
    int originid;
    int destinationid;
    public string date = null, cdate = null;
    public string strquery = "";
    public string accuratefid = null;
    public string insertfid = null;
    public String flight_id = null;
    public String origin = null;
    public string strLen = "";
    public string strLen1 = "";
#endregion
    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Import Flight Open</class>
    /// <description>
    
    /// </description>
    /// <dependency></dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>28 Nov</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// <modifiedby></modifiedby>
    /// <modifiedOn></modifiedOn>
    /// <changeDescription></changeDescription>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;//Getting Connection String For Web.config File.
    #region coding on pageload
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {

                ShowAirline();//function for binding airline name with city.
            }
            if (!Page.IsPostBack && Request.QueryString["fno"] != null && Request.QueryString["org"] != null && Request.QueryString["date"] != null && Request.QueryString["cdate"] != null)// fetching querystirng with pageload
            {

                date = Request.QueryString["date"].ToString();
                txtorigin.Text = Request.QueryString["Dest"].ToString();
                flightid();// function for feching flight id from flightopenshow.aspx with minues one value.
                origin = Request.QueryString["org"].ToString();
                strLen = "<script>var FillDest =new Array(" + Dest() + ")</script>";//variable assing for using javascript for origin.
                txtdestn.Text = origin;//assign value from origin after fetching from querysting 
                txtflightdate.Text = date;
                cdate = Request.QueryString["cdate"].ToString();// assign date after fetching from querysting
                txtclosedate.Text = cdate;
                txtigmdate.Text = DateTime.Now.ToString("dd/MM/yyyy");

            }
        }
    }
    #endregion 
    #region function for bind ddlairline name with airline name and city
    
    public void ShowAirline()// function for bind ddlairline 
    {
        flightid();
        origin = Request.QueryString["org"].ToString();//fetching origin from query string
        con = new SqlConnection(strCon);
        try
        {

            string strQuery = "";


            strQuery = "SELECT dbo.Airline_Master.Airline_Name,dbo.City_Master.City_Name ,dbo.Airline_Detail.Airline_detail_id FROM dbo.Airline_Detail INNER JOIN dbo.Airline_Master ON dbo.Airline_Detail.Airline_ID = dbo.Airline_Master.Airline_ID INNER JOIN dbo.City_Master ON dbo.Airline_Detail.Belongs_To_City = dbo.City_Master.City_ID where Airline_Master.Airline_Text_Code='" + firsttwoalfa + "' and City_Master.City_CODE='"+origin+"'";

            con.Open();
            com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlairline.Items.Clear();
            //ddlairline.Items.Insert(0,"--Select Airline--");
            //ddlairline.Items[0].Value = "0";
            while (dr.Read())
            {

                ddlairline.Items.Add(new ListItem(dr["Airline_Name"].ToString()  , dr["Airline_Detail_Id"].ToString()));


            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    #endregion
    #region function for binding textbox with pop up destn name as origin for this page thr js.
    public string Dest()// function for binding textbox with pop up destn name as origin for this page thr js.
    
    {
        string strTemp = "";
        con = new SqlConnection(strCon);
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString);
        try
        {
            string selectGroupName = "SELECT * FROM Destination_Master";
            com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")

                    strTemp = "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";
                else

                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }
    #endregion
    #region coding on btnsubmit
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        checkexit();
        if (checkid == true)
        {
            Label1.Visible = true;
            Label1.Text = " Record given by you is Already Exists";

        }
        else
        {
            using (con)
            {

                flight_id = Request.QueryString["fno"].ToString();
                string firsttwoalfa = flight_id.Substring(0, flight_id.IndexOf("-"));
                accuratefid = flight_id.Substring(flight_id.IndexOf("-") + 1);
                //int flightno = flight_id.LastIndexOf("-");
                //string firsttwodigitfid = flight_id.Substring(0, flightno);
                //accuratefid = flight_id.Substring(flightno + 1);
                int lengthaccurateid = accuratefid.Length;
                int minusfid = int.Parse(accuratefid) - 1;
                string withoutint = Convert.ToString(minusfid);
                int afterminus = withoutint.Length;
                //int afterminus = int.Parse(mm);
                int check = lengthaccurateid - afterminus;
                if (check > 0)
                {
                    for (int i = 0; i < check; i++)
                    {
                        zero = zero + "0";
                    }
                    insertfid = zero + minusfid;
                }
                if (check == 0)
                {
                    insertfid = withoutint;
                }
                //insertfid = firsttwodigitfid + "-" + minusfid.ToString();




                //txtflightno.Text = insertfid;
                Label2.Visible = true;
                Label2.Text = firsttwoalfa + "-";
                insertvalue = Label2.Text + insertfid;

                con = new SqlConnection(strCon);
                con.Open();
                tr = con.BeginTransaction();
                strquery = "select City_ID from City_Master where City_Code='" + txtdestn.Text + "'";
                com = new SqlCommand(strquery, con,tr);
                SqlDataReader rdr = com.ExecuteReader();
                rdr.Read();
                string destnid = rdr["City_ID"].ToString();
                destinationid = int.Parse(destnid);
                rdr.Close();
                string origin = txtorigin.Text;
                string trueorigin = origin.Substring(0, 3);
                strquery = "select Destination_ID from Destination_Master where Destination_code='" + trueorigin + "'";
                com = new SqlCommand(strquery, con,tr);
                SqlDataReader rdr1 = com.ExecuteReader();
                rdr1.Read();
                string orgid = rdr1["Destination_ID"].ToString();
                originid = int.Parse(orgid);
                rdr1.Close();
                strquery = "insert into db_owner.Import_Flight_Open(Airline_Detail_ID,Import_Flight_No,Import_Origin,Import_Destination,Flight_Date,IGM_No,IGM_Date,Flight_Close_Date,RegNo,Flight_Status_Check,Entered_By,Entered_On)values(@Airline_Detail_ID,@Import_Flight_No,@Import_Origin,@Import_Destination,@Flight_Date,@IGM_No,@IGM_Date,@Flight_Close_Date,@RegNo,@Flight_Status_Check,@Entered_By,@Entered_On)";
                com = new SqlCommand(strquery, con,tr);
                com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = ddlairline.SelectedValue;
                com.Parameters.Add("@Import_Flight_No", SqlDbType.VarChar, 50).Value = insertvalue;
                com.Parameters.Add("@Import_Origin", SqlDbType.BigInt).Value = originid;
                com.Parameters.Add("@Import_Destination", SqlDbType.Int).Value = destinationid;
                com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = ConvertDate(txtflightdate.Text);
                com.Parameters.Add("@IGM_No", SqlDbType.VarChar, 50).Value = txtigmno.Text;
                com.Parameters.Add("@IGM_Date", SqlDbType.DateTime).Value = ConvertDate(txtigmdate.Text);
                com.Parameters.Add("@Flight_Close_Date", SqlDbType.DateTime).Value = ConvertDate(txtclosedate.Text);
                com.Parameters.Add("@RegNo", SqlDbType.VarChar, 50).Value = txtRegNo.Text;
                com.Parameters.Add("@Flight_Status_Check", SqlDbType.VarChar,50).Value = rdfltStatus.SelectedItem.Text;
                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                try
                {
                    int ident =0;
                    com.ExecuteNonQuery();
                    com.Dispose();
                    com = new SqlCommand("select ident_current('Import_Flight_Open')", con,tr);
                    SqlDataReader dr2 = com.ExecuteReader();
                    if (dr2.Read())
                    {
                      ident =int.Parse(dr2[0].ToString());
                    }
                        dr2.Dispose();
                        com.Dispose();
                        com = new SqlCommand("update flight_open set Import_Flight_Open_ID=" + ident + " where Flight_Open_ID=" +Request.QueryString["fid"]+" ", con,tr);
                        com.ExecuteNonQuery();
                        tr.Commit();
                        com.Dispose();
                        dr2.Dispose();
                        con.Close();                  

                    Label1.Visible = true;
                    Label1.Text = "Record Added Successfully";
                    flightopen.Visible = false;
                    Button4.Visible = true;

                    
                }
                catch (SqlException ee)
                {

                    Response.Write("sql error" + ee.Message);
                    tr.Rollback();

                }

            }




        }
    }
    #endregion
    #region function for convert date in true format
    string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
#endregion 
    #region coding on reset button
    protected void Button3_Click(object sender, EventArgs e)
    {
        flightid();
        Label1.Visible = false;
        ddlairline.SelectedIndex = 0;
        txtflightno.Text = insertfid;
        txtorigin.Text = "";
        txtdestn.Text = origin;
        txtflightdate.Text = date;
        txtigmdate.Text=DateTime.Now.ToString("dd/MM/yyyy");
        txtigmno.Text = "";

    }
    #endregion
    #region function for getting flight id with minus-1 after fetching it value from querysting.
    public void flightid()
    {
        flight_id = Request.QueryString["fno"].ToString();
         firsttwoalfa=flight_id.Substring(0,flight_id.IndexOf("-"));
        accuratefid = flight_id.Substring(flight_id.IndexOf("-") + 1);
        //int flightno = flight_id.LastIndexOf("-");
        //string firsttwodigitfid = flight_id.Substring(0, flightno);
        //accuratefid = flight_id.Substring(flightno + 1);
        int lengthaccurateid = accuratefid.Length;
        int minusfid = int.Parse(accuratefid) - 1;
        string withoutint = Convert.ToString(minusfid);
        int afterminus = withoutint.Length;
        //int afterminus = int.Parse(mm);
        int check = lengthaccurateid - afterminus;
        zero = null;
        if (check > 0)
        {
           
            for (int i = 0; i < check; i++)
            { 
                zero = zero + "0";
            }
            insertfid =  zero + minusfid;
        }
        if (check == 0)
        {
            insertfid =  withoutint;
        }
        //insertfid = firsttwodigitfid + "-" + minusfid.ToString();




        txtflightno.Text = insertfid;
        Label2.Visible = true;
        Label2.Text =firsttwoalfa + "-";
        insertvalue = Label2.Text + insertfid;
        //con = newSqlConnection(strCon);
        //con.Open();
        //strquery = "select Airline_ID,Airline_Name +";


    }
    #endregion
    public bool checkexit()
    {
        using (con)
        {
            con = new SqlConnection(strCon);
            con.Open();
            flightid();
            origin = Request.QueryString["org"].ToString();//fetching origin from query string
            //string origin = txtorigin.Text;
            strquery = "select City_ID from City_Master where City_Code='" + origin  + "'";
            com = new SqlCommand(strquery, con);
            SqlDataReader rdr = com.ExecuteReader();
            rdr.Read();
            string destnid = rdr["City_ID"].ToString();
            destinationid = int.Parse(destnid);
            rdr.Close();
             date = Request.QueryString["date"].ToString();//fetching date from query string


             strquery = "select * from db_owner.Import_Flight_Open where Import_Flight_No='" + insertvalue + "' and Flight_Date='" + ConvertDate(date) + "' and Import_Destination='" + destinationid + "'";
            com = new SqlCommand(strquery, con);
            rdr = com.ExecuteReader();
            if (rdr.HasRows == true)
            {
                checkid = true;
            }
            rdr.Close();
            return checkid;
            
        
        
        }
    
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowImportFlight_Open.aspx");
    }
}
