﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Xml;
using System.Text;
using System.IO;


public partial class HAWB_ADD : System.Web.UI.UserControl
{
    SqlConnection con;
    SqlCommand com;
    DataSet ds;
    DisplayWrap dw = new DisplayWrap();
    DataTable dt = new DataTable();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    private string Stockid;

    public string Stockid1
    {
        get { return Stockid; }
        set { Stockid = value; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand();

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            if (!IsPostBack)
            {
                maketable();
                DataTable dtCheck_MAWB = dw.GetAllFromQuery("SELECT * FROM db_owner.HAWB_Details WHERE Stock_id=" + Convert.ToInt32(Stockid) + "");
                if (dtCheck_MAWB.Rows.Count > 0)
                {
                    FillHAWBDATA();

                }
                else
                {

                    pnlHAWB.Visible = true;


                    grdcal1.DataSource = (DataTable)Session["dtHAWB"];
                    grdcal1.DataBind();
                }


            }
            //////else
            //////{
            //////    grdcal1.DataSource = (DataTable)Session["dtHAWB"];
            //////    grdcal1.DataBind();

            //////}
        }
        
    }

    
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        DataTable dtCheck_MAWB = dw.GetAllFromQuery("SELECT * FROM db_owner.HAWB_Details WHERE Stock_id=" + Convert.ToInt32(Stockid) + "");
        if (dtCheck_MAWB.Rows.Count > 0)
        {


        }
        else
        {
            con.Open();
            try
            {
                foreach (GridViewRow gv in grdcal1.Rows)
                {
                    com = new SqlCommand("Insert_HAWB_Details", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = Convert.ToInt32(ViewState["Stockid"].ToString());
                    com.Parameters.Add("@Hawb_No", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblHawbNo")).Text;
                    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblGwt")).Text);
                    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblVWT")).Text);
                    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblCWT")).Text);
                    com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblNature")).Text;
                    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperName")).Text;
                    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperAdd")).Text;
                    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee")).Text;
                    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee_Address")).Text;
                    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                    com.ExecuteNonQuery();

                }
                con.Close();
                //////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Data saved successfully." + "');</script>");
                //////Response.Redirect("ViewHAWB_Details.aspx");



                //string strScript = "alert('Data saved successfully.');location.replace('ViewHAWB_Details.aspx');";

                //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);


                ////maketable();
                ////grdcal1.DataSource = (DataTable)Session["dtHAWB"];
                ////grdcal1.DataBind();
            }
            catch (Exception ex)
            {
                string msg = ex.ToString();
                string strScript = "alert('" + msg + "');";

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox2", strScript, true);

                /////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + msg + "');</script>");

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

        }

    }

    public void maketable()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "HAWB_NO";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Gross_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Charged_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Nature_and_Quantity";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Shipper_Name";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Shipper_Address";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Consignee_Name";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Consignee_Address";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);
        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "";
        dr[6] = "";
        dr[7] = "";
        dr[8] = "";
        dr[9] = "";

        dtTemp.Rows.Add(dr);
        Session["dtHAWB"] = dtTemp;

    }



    public DataTable maketablehawb()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "HAWB_NO";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Gross_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Charged_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Nature_and_Quantity";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Shipper_Name";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Shipper_Address";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Consignee_Name";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Consignee_Address";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);
        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "";
        dr[6] = "";
        dr[7] = "";
        dr[8] = "";
        dr[9] = "";

        dtTemp.Rows.Add(dr);
        return dtTemp;
        
    }

    protected void grdcal1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void grdcal1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdcal1.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            // lblmsg.Visible = true;
        }
        else
        {
            // lblmsg.Visible = false;
            grdcal1.EditIndex = e.NewEditIndex;
            grdcal1.DataSource = (DataTable)Session["dtHAWB"];
            grdcal1.DataBind();
        }

    }
    protected void grdcal1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        DataTable dt = (DataTable)Session["dtHAWB"];
        int Sno = Convert.ToInt32(grdcal1.DataKeys[e.RowIndex].Value);

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                break;
            }
        }
        if (dt.Rows.Count == 0)
        {
            maketable();
            dt = (DataTable)Session["dtHAWB"];
        }
        else
        {
            Session["dtHAWB"] = dt;
        }
        grdcal1.DataSource = dt;
        grdcal1.DataBind();
    }
    protected void grdcal1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        DataTable dt = (DataTable)Session["dtHAWB"];
        int SNo = Convert.ToInt16(grdcal1.DataKeys[e.RowIndex].Value);

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {

                dr[1] = ((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtHawbNo")).Text;
                dr[2] = Convert.ToDecimal(((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtGwt")).Text);
                dr[3] = Convert.ToDecimal(((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtVWT")).Text);
                dr[4] = Convert.ToDecimal(((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtCWT")).Text);
                dr[5] = ((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtNature")).Text;
                dr[6] = ((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtShiperName")).Text;
                dr[7] = ((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtShiperAdd")).Text;
                dr[8] = ((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtConsignee")).Text;
                dr[9] = ((TextBox)grdcal1.Rows[e.RowIndex].FindControl("txtConsignee_Address")).Text;
            }
        }

        Session["dtHAWB"] = dt;
        grdcal1.EditIndex = -1;
        grdcal1.DataSource = dt;
        grdcal1.DataBind();


    }
    protected void grdcal1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdcal1.EditIndex = -1;
        grdcal1.DataSource = (DataTable)Session["dtHAWB"];
        grdcal1.DataBind();
    }

    protected void grdcal1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {

                DataTable dt = (DataTable)Session["dtHAWB"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();


                dr[1] = ((TextBox)grdcal1.FooterRow.FindControl("txtHawbNo")).Text;
                dr[2] = Convert.ToDecimal(((TextBox)grdcal1.FooterRow.FindControl("txtGwt")).Text);
                dr[3] = Convert.ToDecimal(((TextBox)grdcal1.FooterRow.FindControl("txtVWT")).Text);
                dr[4] = Convert.ToDecimal(((TextBox)grdcal1.FooterRow.FindControl("txtCWT")).Text);
                dr[5] = ((TextBox)grdcal1.FooterRow.FindControl("txtNature")).Text;
                dr[6] = ((TextBox)grdcal1.FooterRow.FindControl("txtShiperName")).Text;
                dr[7] = ((TextBox)grdcal1.FooterRow.FindControl("txtShiperAdd")).Text;
                dr[8] = ((TextBox)grdcal1.FooterRow.FindControl("txtConsignee")).Text;
                dr[9] = ((TextBox)grdcal1.FooterRow.FindControl("txtConsignee_Address")).Text;

                dt.Rows.Add(dr);
                Session["dtHAWB"] = dt;
                grdcal1.DataSource = dt;
                grdcal1.DataBind();
            }
            catch (Exception ex)
            {
            }
        }
    }


    protected void grdcal1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }



    protected void FillHAWBDATA()
    {



        com = new SqlCommand("Get_HAWB_Details_Update", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = Convert.ToInt32(Stockid);
        SqlDataAdapter sda = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            pnlHAWB.Visible = true;


            DataTable dttemp = (DataTable)Session["dtHAWB"];

            if (dttemp.Rows[0][0].ToString() == "0")
            {
                dttemp.Rows[0].Delete();
            }


            for (int k = 0; k < dt.Rows.Count; k++)
            {

                DataRow dr = dttemp.NewRow();
                dr[1] = dt.Rows[k]["Hawb_No"].ToString();
                dr[2] = dt.Rows[k]["Gross_Weight"].ToString();
                dr[3] = dt.Rows[k]["Volume_Weight"].ToString();
                dr[4] = dt.Rows[k]["Charged_Weight"].ToString();
                dr[5] = dt.Rows[k]["Nature_and_Quantity"].ToString();
                dr[6] = dt.Rows[k]["Shipper_Name"].ToString();
                dr[7] = dt.Rows[k]["Shipper_Address"].ToString();
                dr[8] = dt.Rows[k]["Consignee_Name"].ToString();
                dr[9] = dt.Rows[k]["Consignee_Address"].ToString();

                dttemp.Rows.Add(dr);

            }
            Session["dtHAWB"] = dttemp;
            grdcal1.DataSource = dttemp;
            grdcal1.DataBind();
        }

    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {

        try
        {

            MoveToHistory();
            con.Open();
            foreach (GridViewRow gv in grdcal1.Rows)
            {
                com = new SqlCommand("Insert_HAWB_Details", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = Convert.ToInt32(Request.QueryString["Stock_ID"].ToString());
                com.Parameters.Add("@Hawb_No", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblHawbNo")).Text;
                com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblGwt")).Text);
                com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblVWT")).Text);
                com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblCWT")).Text);
                com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblNature")).Text;
                com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperName")).Text;
                com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperAdd")).Text;
                com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee")).Text;
                com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee_Address")).Text;
                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                com.ExecuteNonQuery();
            }
            con.Close();
            string strScript = "alert('Data updated successfully.');location.replace('ViewHAWB_Details.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox1", strScript, true);
            //////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Data updated successfully." + "');</script>");
            //////Response.Redirect("ViewHAWB_Details.aspx");
            ////maketable();
            ////grdcal1.DataSource = (DataTable)Session["dtHAWB"];
            ////grdcal1.DataBind();
        }
        catch (Exception ex)
        {
            string msg = ex.ToString();
            string strScript = "alert('" + msg + "');";
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox3", strScript, true);


            ////// ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + msg + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }


    protected void MoveToHistory()
    {
        con.Open();
        com = new SqlCommand("MOVE_HAWb_History", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["Stock_ID"].ToString());
        com.ExecuteNonQuery();
        con.Close();
    }
    public void InsertData(DataTable dt,string Stock_id)
    
    {
        DataTable dttemp = new DataTable();

       dttemp= maketablehawb();

     //  FillHAWBDATA();
     //  grdcal1.DataSource = dttemp;
     //  grdcal1.DataBind();


        if (dttemp.Rows[0][0].ToString() == "0")
        {
            dttemp.Rows[0].Delete();
        }


        for (int k = 0; k < dt.Rows.Count; k++)
        {

            DataRow dr = dttemp.NewRow();
            dr[1] = dt.Rows[k]["Hawb_No"].ToString();
            dr[2] = dt.Rows[k]["Gross_Weight"].ToString();
            dr[3] = dt.Rows[k]["Volume_Weight"].ToString();
            dr[4] = dt.Rows[k]["Charged_Weight"].ToString();
            dr[5] = dt.Rows[k]["Nature_and_Quantity"].ToString();
            dr[6] = dt.Rows[k]["Shipper_Name"].ToString();
            dr[7] = dt.Rows[k]["Shipper_Address"].ToString();
            dr[8] = dt.Rows[k]["Consignee_Name"].ToString();
            dr[9] = dt.Rows[k]["Consignee_Address"].ToString();

            dttemp.Rows.Add(dr);

        }
        ////Session["dtHAWB"] = dttemp;


      //  GridView grdcal1 = new GridView();

        grdcal1.DataSource = dttemp;
        grdcal1.DataBind();

       
       // DataTable dtShipper = dt;
       // grdcal1.DataSource =(DataTable) dtShipper;
       //grdcal1.DataBind();



        DataTable dtCheck_MAWB = dw.GetAllFromQuery("SELECT * FROM db_owner.HAWB_Details WHERE Stock_id=" + Convert.ToInt32(Stock_id) + "");
        if (dtCheck_MAWB.Rows.Count > 0)
        {
            MoveToHistory();

        }
        con = new SqlConnection(strCon);
            con.Open();
            try
            {
                foreach (GridViewRow gv in grdcal1.Rows)
                {
                    com = new SqlCommand("Insert_HAWB_Details", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = Convert.ToInt32(Stock_id);
                    com.Parameters.Add("@Hawb_No", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblHawbNo")).Text;
                    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblGwt")).Text);
                    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblVWT")).Text);
                    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblCWT")).Text);
                    com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblNature")).Text;
                    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperName")).Text;
                    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperAdd")).Text;
                    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee")).Text;
                    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee_Address")).Text;
                    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                    com.ExecuteNonQuery();

                }
                con.Close();
                //////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Data saved successfully." + "');</script>");
                //////Response.Redirect("ViewHAWB_Details.aspx");



                //string strScript = "alert('Data saved successfully.');location.replace('ViewHAWB_Details.aspx');";

                //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);


                ////maketable();
                ////grdcal1.DataSource = (DataTable)Session["dtHAWB"];
                ////grdcal1.DataBind();
            }
            catch (Exception ex)
            {
                string msg = ex.ToString();
                string strScript = "alert('" + msg + "');";

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox2", strScript, true);

                /////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + msg + "');</script>");

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

        
    
    
    }

}
