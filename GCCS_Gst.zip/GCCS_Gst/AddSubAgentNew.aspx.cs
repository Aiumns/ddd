﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class AddSubAgentNew : System.Web.UI.Page
{
    /// <summary>
    /// <class>Add New Agent</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>-------SAROJ KUMAR GUPTA------------</createdBy>
    /// <createdOn>---Oct 17 OCT 2007--------</createdOn>
    /// <modifications>
    /// <modificat
    /// <changeDescription></changeDescription>
    /// <modifiedBy>-------SAROJ KUMAR GUPTA-----</modifiedBy>
    /// <modifiedOn> 18,19,22 OCT 2007</modifiedOn>
    /// <modifiedBy>--------RAKHI on 11 Dec---------</modifiedBy>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand com;
    DataSet ds;
  
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  // ConnectionString

    protected void Page_Load(object sender, EventArgs e)
    {
        btnSubmit.Attributes.Add("onclick", "return CheckEmpty()");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                LoadOrigin();

                if (Request.QueryString.Count > 0)
                {
                    if (Request.QueryString["SubAgntID"].ToString() != null)
                    {

                        btnSubmit.Text = "Update";
                        con = new SqlConnection(strCon);
                        con.Open();
                        com = new SqlCommand("GetSubagent_Details", con);
                        com.CommandType = CommandType.StoredProcedure;
                        com.Parameters.Add("@SubAgentID", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["SubAgntID"].ToString());
                        SqlDataAdapter da = new SqlDataAdapter(com);
                        DataTable dtSubAgent = new DataTable();
                        da.Fill(dtSubAgent);
                        con.Close();
                        //DataTable dtSubAgent = dw.GetAllFromQuery("select * from SubAgent_Master where SubAgentID=" + Request.QueryString["SubAgntID"].ToString() + "");
                        if (dtSubAgent.Rows.Count > 0)
                        {
                            txtSubAgentName.Text = dtSubAgent.Rows[0]["SubAgentName"].ToString();
                            txtEmail.Enabled = false;
                            txtEmail.Text = dtSubAgent.Rows[0]["EmailId"].ToString();
                            LoadOrigin();
                            ddlSubAgentcity.SelectedValue = dtSubAgent.Rows[0]["CityId"].ToString();
                            txtSubAgentAddress.Text = dtSubAgent.Rows[0]["SubAgentAddress"].ToString();
                            txtContactNo.Text = dtSubAgent.Rows[0]["ContactNo"].ToString();
                            txtPassword.Text = dtSubAgent.Rows[0]["Password"].ToString();
                            txtPassword.TextMode = TextBoxMode.SingleLine;
                            txtMobileNo.Text = dtSubAgent.Rows[0]["MobileNo"].ToString();
                          //  txtConcernNo.Text = dtSubAgent.Rows[0]["ConcernPerson_MobileNo"].ToString();
                            txtConserName.Text = dtSubAgent.Rows[0]["ConcernPerson"].ToString();
                        }

                    }
                }
            }
        }
       
    }

   
    //public void CityName()
    //{
    //    con = new SqlConnection(strCon);
    //    con.Open();
    //    com = new SqlCommand("Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master order by city_code", con);
    //    da = new SqlDataAdapter(com);
    //    ds = new DataSet();
    //    da.Fill(ds);
    //    ddlSubAgentcity.DataSource = ds;
    //    ddlSubAgentcity.DataTextField = "CodeName";
    //    ddlSubAgentcity.DataValueField = "City_ID";
    //    ddlSubAgentcity.DataBind();
    //    ddlSubAgentcity.Items.Insert(0, new ListItem("--Select--", "0"));

      
    //    con.Close();
    //}
    public void LoadOrigin()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("Get_Origin_Voucher", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            //com = new SqlCommand("select City_ID,City_Code,City_name from City_Master where city_ID in(SELECT DISTINCT CITYID FROM CPP_AgentwiseTotal )", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlSubAgentcity.Items.Clear();
            ddlSubAgentcity.Items.Insert(0, "- -Select- -");
            ddlSubAgentcity.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlSubAgentcity.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
  
    
   
    public void FillData()      // insert Data in All Table
    {

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            if (Request.QueryString.Count > 0)
            {
                if (Request.QueryString["SubAgntID"].ToString() != null)
                {
                    com = new SqlCommand("Update_SuAgentDetails", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.Add("@SubAgentName", SqlDbType.VarChar).Value = txtSubAgentName.Text;
                    com.Parameters.Add("@EmailId", SqlDbType.VarChar).Value = txtEmail.Text;
                    com.Parameters.Add("@Password", SqlDbType.VarChar).Value = txtPassword.Text;
                    com.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = txtMobileNo.Text;
                    com.Parameters.Add("@ContactNo", SqlDbType.VarChar).Value = txtContactNo.Text;
                    com.Parameters.Add("@CityId", SqlDbType.Int).Value = int.Parse(ddlSubAgentcity.SelectedValue);
                    com.Parameters.Add("@SubAgentAddress", SqlDbType.VarChar).Value = txtSubAgentAddress.Text;
                    com.Parameters.Add("@LastUpdated_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                    com.Parameters.Add("@LastUpdated_On", SqlDbType.DateTime).Value = DateTime.Now.ToString();

                    com.Parameters.Add("@SubAgentID", SqlDbType.VarChar).Value = Request.QueryString["SubAgntID"].ToString();
                    com.Parameters.Add("@ConcernPerson", SqlDbType.VarChar).Value = txtConserName.Text;
                    com.Parameters.Add("@ConcernPerson_MobileNo ", SqlDbType.VarChar).Value = txtMobileNo.Text;


                    com.ExecuteNonQuery();
                    con.Close();
                  
                    string strScriptUPt = "alert('SubAgent Updated Successfully.');location.replace('ViewSubAgent.aspx');";

                    ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScriptUPt, true);
                }
            }
            else
            {
                com = new SqlCommand("CheckMailID", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@EmailId", SqlDbType.VarChar).Value = txtEmail.Text;
                SqlDataReader dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    string strScript = "alert('EmailID Already Exist');";

                    ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
                   
                    return;
                    

                }
                else
                {

                    dr.Close();

                    com = new SqlCommand("Insert_SuAgentDetails", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.Add("@SubAgentName", SqlDbType.VarChar).Value = txtSubAgentName.Text;
                    com.Parameters.Add("@EmailId", SqlDbType.VarChar).Value = txtEmail.Text;
                    com.Parameters.Add("@Password", SqlDbType.VarChar).Value = txtPassword.Text;
                    com.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = txtMobileNo.Text;
                    com.Parameters.Add("@ContactNo", SqlDbType.VarChar).Value = txtContactNo.Text;
                    com.Parameters.Add("@CityId", SqlDbType.Int).Value = int.Parse(ddlSubAgentcity.SelectedValue);
                    com.Parameters.Add("@SubAgentAddress", SqlDbType.VarChar).Value = txtSubAgentAddress.Text;
                    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                    com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now.ToString();
                    com.Parameters.Add("@ConcernPerson", SqlDbType.VarChar).Value = txtConserName.Text;
                    com.Parameters.Add("@ConcernPerson_MobileNo ", SqlDbType.VarChar).Value = txtMobileNo.Text;

                    com.ExecuteNonQuery();
                }
                con.Close();
            }
            
        }
        catch (SqlException se)
        {
            string err = se.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
           

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        string strScriptAdd = "alert('SubAgent Added Successfully.');location.replace('ViewSubAgent.aspx');";

        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScriptAdd, true);

        //Response.Redirect("ViewSubAgent.aspx");
    }



    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        FillData();
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewSubAgent.aspx");
    }
}
