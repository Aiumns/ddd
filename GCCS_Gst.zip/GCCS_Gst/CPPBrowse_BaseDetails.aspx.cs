using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CPPBrowse_BaseDetails : System.Web.UI.Page
{
    string[] Sdate;
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {
           // Page.Form.Target = "_blank";

            //txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            //Sdate = txtValidFrom.Text.Split('/');
            //string month = Sdate[1];
            //string year = Sdate[2];
            //if (Sdate[1] == "01" || Sdate[1] == "02" || Sdate[1] == "03")
            //{
            //    int yy = int.Parse(year);
            //    string destdata = "31/03/" + yy.ToString();
            //    txtValidTo.Text = destdata;
            //}
            //if (Sdate[1] == "04" || Sdate[1] == "05" || Sdate[1] == "06" || Sdate[1] == "07" || Sdate[1] == "08" || Sdate[1] == "09" || Sdate[1] == "10" || Sdate[1] == "11" || Sdate[1] == "12")
            //{
            //    int yy = int.Parse(year) + 1;
            //    string destdata = "31/03/" + yy.ToString();
            //    txtValidTo.Text = destdata;
            //}
            Search();
        }
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ = null;
            if (txtValidFrom.Text == "" && txtValidTo.Text == "")
            {
                selectQ = "select distinct Convert(varchar,startdate,103) as startdate,Convert(varchar,enddate,103) as enddate from CPP_Base ";
            }

            else
            {
                selectQ = "select distinct Convert(varchar,startdate,103) as startdate,Convert(varchar,enddate,103) as enddate from CPP_Base where '" + FormatDateMM(txtValidFrom.Text) + "' between startDate and EndDate or '" + FormatDateMM(txtValidTo.Text) + "' between startDate and EndDate  order by startdate";
            }
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdCpp.DataSource = dt;
            grdCpp.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnBrowse_Click(object sender, EventArgs e)
    {
        Search();
        //string strStartDate = txtValidFrom.Text;
        //string strEndDate = txtValidTo.Text;
        //Session["StartDate"] = strStartDate;
        //Session["EndDate"] = strEndDate;
        //Response.Redirect("Cpp_BaseDetails.aspx");

    }
    protected void grdCpp_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdCpp.PageIndex = e.NewPageIndex;
        Search();
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("CPP_BaseDetails.aspx?startDate=s&enddate=e");
    }
}
