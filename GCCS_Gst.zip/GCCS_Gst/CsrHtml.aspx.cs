using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class CsrHtml : System.Web.UI.Page
{

    string agentName = null, lastTsdsRate = null;
    string tableAll = null, comName = null;
    string massage = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    decimal TotChAmount = 0;
    decimal TotDueCar = 0;
    decimal TotTax = 0;
    decimal TotAgentExp = 0;
    decimal TotComm = 0;
    decimal TotDiscount = 0;
    decimal TotFrAmount = 0;
    decimal TotFrAmountCC = 0;
    decimal TotTds = 0;
    decimal EduChrg = 0; decimal Total = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["EMailID"] == null)
        {
            // Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                //RadioButton2.Attributes.Add("onClick", "javascript :alert('heloo')");
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");

                int dt = System.DateTime.Now.Month;
                ddlMonth.Items[dt - 1].Selected = true;
                int yy = System.DateTime.Now.Year;
                int s = ddlyear.Items.IndexOf(ddlyear.Items.FindByValue(yy.ToString()));
                ddlyear.Items[s].Selected = true;
                ShowAirline();
                if (Session["groupid"].ToString() == "1")
                {
                    ddlAirLine.AutoPostBack = true;
                    Pantab.Visible = true;

                }
                else
                {
                    Pantab.Visible = false;
                    ddlAirLine.AutoPostBack = false;

                }
               
            }

        }

    }

    protected void ShowAirline()
    {

        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and a.airline_id in (" + Session["AIRLINEACCESS"].ToString().Substring(0, +Session["AIRLINEACCESS"].ToString().Length - 1) + ") order by Airline_Name", con);
            dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select airline name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            com.Dispose();
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        string agentId = null;
        string bID = null;

        lstAgent.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
            dr = com.ExecuteReader();
            if (dr.Read())
            {
                agentId = dr["airline_id"].ToString();
                bID = dr["belongs_to_city"].ToString();
            }
            dr.Dispose();
            com.Dispose();
            com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + agentId + "%') and a.Belongs_To_City=" + bID + " ", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                lstAgent.Items.Add(new ListItem(dr["agent_name"].ToString(), dr["agent_id"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string comAdd = null;
        string[] airlineName = ddlAirLine.SelectedItem.Text.Split('-');
        string airline = "A/C " + airlineName[0].ToUpper().ToString();

        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();

        string strY = DateTime.Today.Year.ToString();

        if (rbtnFirstFortn.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }


        }
        string agnetID = "";

        for (int k = 0; k < lstAgent.Items.Count; k++)
        {
            if (lstAgent.Items[k].Selected == true)
            {
                string table = null;
                agnetID = lstAgent.Items[k].Value;
                agentName = lstAgent.Items[k].Text;
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("select * from company_master where company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " )", con);
        SqlDataReader dr = com.ExecuteReader();
        while (dr.Read())
        {
            comAdd = dr["company_name"].ToString();
            comName = dr["company_name"].ToString();
            table += @"<table   width=""100%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><BR>" + airline + @"<br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br><font size=""2"">Cargo Sales Report </font><br><br>From " + TextBox1.Text + " To " + TextBox2.Text + @"</p></td></tr></table>"; 
        
        }
        com.Dispose();
        dr.Dispose();
        com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " ", con);
        dr = com.ExecuteReader();
        if (dr.Read())
        {           
            string s = dr["agent_address"].ToString();
            char ch = (char) System.Windows.Forms.Keys.Return;
            char ch2 = (char)System.Windows.Forms.Keys.Space;
            string ch1 = Convert.ToString(ch);
            string ch3 = Convert.ToString(ch2);
            string h= s.Replace(ch1,"<br>");
            h = h.Replace(ch3, "&nbsp;");           
           
           table += @"<div width=""20""  class=""boldtext"" align=""left""><strong>" + agentName + @"<br>"+h +@"<br><br><strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
          


</div>
<br>";
        }
        com.Dispose();
        dr.Dispose();

        table += @"<table width=""100%"" border=""0""><tr class=""h1""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"">Freight</th><th rowspan=""2"">Due Carrier</th><th colspan=""2"">TXC</th><th rowspan=""2"">Agent Expenses</th>	<th rowspan=""2"">Comm.</th><th rowspan=""2"">Discount</th>	<th rowspan=""2"">Remark</th></tr><tr class=""h1"">  <th  class=""h1"">PP</th  class=""h1"">  <th  class=""h1"">CC</th>  <th  class=""h1"">PP</th>  <th  class=""h1"">CC</th></tr><tr class=""h1""> <td colspan=""13"" align=""center""  class=""h1""> </td></tr><tr> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td>
</tr>"; 
            com = new SqlCommand("Newcsr", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("agent_id", agnetID);
            com.Parameters.AddWithValue("FROM_DATE",DateTime.Parse(TextBox1.Text));
            com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
               
             dr = com.ExecuteReader();
            // if (dr.Read())
//                 table += @"<strong>" + dr["agent_name"].ToString() + @"</strong><br>" + dr["agent_address"].ToString() + @"
//<strong>IATA Code&nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</strong>
//
//<br><br>";
                 
            while (dr.Read())
            {
                string ss = dr["Used_Date"].ToString();
               TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
               TotDueCar += decimal.Parse(dr["Total_DueCarrier"].ToString());
               TotTax += decimal.Parse(dr["Tax"].ToString());
                TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());
                TotComm += decimal.Parse(dr["Commissionable_Amount"].ToString());
                TotDiscount += decimal.Parse(dr["Discount"].ToString());
               // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                TotTds += decimal.Parse(dr["TDS_Amount"].ToString());
                EduChrg += (decimal.Parse(dr["TDS_Amount"].ToString()) * decimal.Parse(dr["Education_Cess"].ToString())) / 100;
                lastTsdsRate = dr["tds"].ToString();

                string amountPP = null;
                string amountCC = null;
                if (dr["Freight_type"].ToString() == "COLLECT")
                {
                    amountPP = "0";
                    amountCC = dr["Freight_Amount"].ToString();
                    TotFrAmountCC +=decimal.Parse(amountCC);
                    
                }
                else
                {
                    amountPP = dr["Freight_Amount"].ToString();
                    amountCC = "0";
                    TotFrAmount +=decimal.Parse(amountPP);
                }
                string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                if (RadioButton1.Checked == true)
                    remarks = "void";


                table += @"<tr class=""text""><td>" + dr["Used_Date"].ToString() + @"</td><td>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td>" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString())) + @"</td><td>" + Math.Round(decimal.Parse(amountPP)) + @"</td><td>" + Math.Round(decimal.Parse(amountCC)) + @"</td><td>" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td>" + Math.Round(decimal.Parse(dr["Tax"].ToString())) + @"</td><td> 0 </td><td>" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td>" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString())) + @"</td><td>" + Math.Round(decimal.Parse(dr["Discount"].ToString())) + @"</td><td>" + remarks + @"</td><td></tr>";
                
            }
            table += @"<tr> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
            com.Dispose();
            dr.Dispose();

                    Total=Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp +TotDiscount+TotComm)),2);
                    table += @"<tr > <td colspan=""13"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td> </td><td> </td><td> </td><td>" + Math.Round(TotChAmount) + @" </td><td>" + Math.Round(TotFrAmount) + @" </td><td>" +Math.Round(TotFrAmountCC) + @"</td><td>" + Math.Round(TotDueCar) + @" </td><td>" + Math.Round(TotTax) + @"</td><td>" + 0 + @" </td><td>" + Math.Round(TotAgentExp) + @"</td><td>" + Math.Round(TotComm) + @" </td><td>" + Math.Round(TotDiscount) + @"</td><td>&nbsp; </td></tr>";
            table += @"<tr class=""boldtext""> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
            table += @"<tr class=""boldtext""><td colspan=""11"" align=""right""><strong>Add Due Carrier</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";
            table += @"<tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax )+ @"</strong></td></tr>";

            table += @"<tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

            table += @"<tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

            table += @"<tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

            table += @"<tr class=""boldtext""> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

            table += @"<tr class=""boldtext""><td colspan=""8"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" +Math.Round(Total) + @"</strong></th></tr>";

            table += @"<tr class=""boldtext""><td colspan=""11"" align=""right""><strong>Add TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
            table += @"<tr class=""boldtext""><td colspan=""11"" align=""right""><strong>Add EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

           table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
           //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                string font=null;
           if (Math.Round((Total +Math.Ceiling(TotTds) + EduChrg)) < 0)
           { massage = "Total payable from";
               font="<font color='red'>";
           }
           else
           {
               massage = "Total Receivable from";
               font="<font class='text'>";
           }


           table += @"<tr class=""boldtext""><th colspan=""11"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"">INR &nbsp;" + font + Math.Round((Total + Math.Ceiling(TotTds) + EduChrg)) + @"</font></td></tr>";

           table += @"<tr align=""left"" class=""text""> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""13""><hr><font size=""1"">Please make payment in favour of <strong>" + comName + @"," + airline + @"<br></strong>Service Tax Registration No : AADCA8499BST003, PAN : AADCA8499B	<br><B>Please deduct the TDS @0.75%+S.C.+E.C. u/s 194C as per exemption cert. no. ACIT/Circle 49(1)/197/2007-08/31 issued by the Income Tax Deptt applicable w.e.f.01/04/2007 to 31/03/2008 (Pls ensure your company/firm name in the cert. before deducting at lower rate).</b>	<br> </FONT></td></tr></table><br><br>";
                 

           // Label1.Text = table;
            tableAll = tableAll + table;
           
        //}

        }
       // tableAll = tableAll + table;
        
    }

    }
    
    public String CsrTable
    {
        get
        {
            //return textCity.Text;
            return tableAll;
        }
    }
     
}
