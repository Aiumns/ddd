using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
public partial class Expire_Cpp : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {
            //Btnload.Attributes.Add("onclick", "return CheckEmpty();");
        }

    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("Expire_Cpp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ExpiryDate", SqlDbType.DateTime).Value = FormatDateDD(txtExpiryDate.Text);
            int q = cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            if (q >0)
            {
              
                lblMsg.Text = "Cpp Expired successfully";
                lblMsg.ForeColor = System.Drawing.Color.Red;
                lblMsg.CssClass = "text";
              //  txtExpiryDate.Text = "";
                Response.Redirect("Expire_Cpp.aspx");

            }
            

        }
        catch (Exception eror)
        {
            string st = eror.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
            cmd.Dispose();
            
        }

    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

}
