using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
/// <summary>
/// Created By Ajeet On Dated 12 Oct 2007
/// Updating By Ajeet On Dated 15 Oct 2007,Due To Change in Tamplete.
/// </summary>

public partial class AddCommodityDetails : System.Web.UI.Page
{
    SqlConnection con;//for connection  
    SqlCommand cmd;//for command
    SqlDataReader dr;//for record set

    bool condt = false;//for checking code existance.
    protected string strHead = null;//For Making Head String

    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;//getting connection string from web.config file.

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["CommoCode"] != null)//checking for modify or add new
                {
                    btnupdate.Attributes.Add("onclick", "return CheckEmpty()");
                    //when Modify button press this block execute      
                    strHead = "Edit Commodity";//Providing Heading For page     
                    btnupdate.Text = "Update";
                    btnadd.Visible = false;//making add button visiblity false            
                    selectData();//function for filling required data to the textboxes
                    Session["strCode"] = txtCode.Text;//For Preserving Previous Value
                }
                else
                {
                    btnadd.Attributes.Add("onclick", "return CheckEmpty()");
                    //when add button pressed this part execute.
                    strHead = "Add Commodity";
                    btnadd.Text = "Add";
                    btnupdate.Visible = false;//making update button visiblity false.
                }
            }
        }
    }

    //function for getting required data to textboxes.
    public void selectData()
    {

        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            string commCd = Convert.ToString(Request.QueryString["CommoCode"]);//Getting code for which value is to be modified.
            cmd = new SqlCommand("Select * From Special_Commodity_Master Where Special_Commodity_Code='" + commCd + "'", con);//selecting records from database.

            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);//getting records set

            if (dr.Read())
            {
                //filling values
                txtCode.Text = dr["Special_Commodity_Code"].ToString();
                txtHandlingCode.Text = dr["SCR_Handling_Code"].ToString();
                txtName.Text = dr["Special_Commodity_Name"].ToString();
            }
        }

        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Special_Commodity.aspx");
    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);

        if (!codeCheck())//checking for existance of code
        {//if code not exist this part is executed
            try
            {
                con.Open();
                string strInsert = "Insert into Special_Commodity_Master values('" + txtCode.Text + "','" + txtName.Text + "','" + txtHandlingCode.Text + "')";//onserting values to the database.
                cmd = new SqlCommand(strInsert, con);
                cmd.ExecuteNonQuery();
                con.Close();
                cmd.Connection.Close();

                Response.Redirect("Special_Commodity.aspx");//after adding values send back to calling page.
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            }
        }
        else
        {
            //other wise this part is executed
            lblCode.Text = "Entered Code Is Already Exist....";
            txtCode.Text = "";
            txtCode.Focus();
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            string strUpdate = "Update Special_Commodity_Master SET Special_Commodity_Code='" + txtCode.Text + "' ,Special_Commodity_Name='" + txtName.Text + "', SCR_Handling_Code='" + txtHandlingCode.Text + "'  Where Special_Commodity_Code='" + Session["strCode"].ToString() + "'";
            cmd = new SqlCommand(strUpdate, con);
            cmd.ExecuteNonQuery();
            con.Close();
            cmd.Connection.Close();
            Session["strCode"] = "";
            Response.Redirect("Special_Commodity.aspx");

        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    //this function is used for the purpose of checking existance of code in data base.
    public bool codeCheck()
    {
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            cmd = new SqlCommand("Select Special_Commodity_Code From Special_Commodity_Master Where Special_Commodity_Code='" + txtCode.Text +
"'", con);

            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

            if (dr.Read())
            {
                condt = true;
            }
            else
                condt = false;
            dr.Close();
            con.Close();

        }

        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
        return condt;
    }
}
