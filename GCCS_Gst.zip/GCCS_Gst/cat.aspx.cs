using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

public partial class cat : System.Web.UI.Page
{
    public int sno = 1;
    //string strCon = ConfigurationManager.AppSettings["CN"];
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand("Select category from ImageGallery where category='" + txtcategory.Text + "'", con);
        SqlDataReader dr = com.ExecuteReader();

        if (dr.Read())
        {
            dr.Close();
            com.Dispose();
            con.Close();
            lblerror.Visible = true;
            lblerror.Text = "Category Name already exists, Please try other Category..";
            return;
        }
        dr.Close();
        com.Dispose();

        if (FileUpload1.PostedFile != null
       && FileUpload1.PostedFile.FileName != "")
        {

            byte[] myimage = new byte[FileUpload1.PostedFile.ContentLength];
            HttpPostedFile Image = FileUpload1.PostedFile;
            Image.InputStream.Read(myimage, 0, (int)FileUpload1.PostedFile.ContentLength);

            SqlConnection myConnection = new SqlConnection(strCon);

            SqlCommand storeimage = new SqlCommand("INSERT INTO ImageGallery "
                + "(Image_Content, Image_Type, Image_Size,category,active) "
                + " values (@image, @imagetype, @imagesize,@category,@active)", myConnection);
            storeimage.Parameters.Add("@image", SqlDbType.Binary, myimage.Length).Value = myimage;
            storeimage.Parameters.Add("@imagetype", SqlDbType.VarChar, 100).Value
            = FileUpload1.PostedFile.ContentType;
            storeimage.Parameters.Add("@imagesize", SqlDbType.BigInt, 99999).Value
            = FileUpload1.PostedFile.ContentLength;
            storeimage.Parameters.Add("@category", SqlDbType.VarChar, 100).Value = txtcategory.Text;
            storeimage.Parameters.Add("@active", SqlDbType.VarChar, 5).Value = cmbactive.SelectedValue.ToString();
            //      storeimage.Parameters.Add("@added_at", SqlDbType.Date).Value = System.DateTime.Now.ToString();
            myConnection.Open();
            storeimage.ExecuteNonQuery();
            myConnection.Close();
        }
        txtcategory.Text = "";

    }
}
