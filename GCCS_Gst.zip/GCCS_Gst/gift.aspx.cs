using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;
public partial class gift : System.Web.UI.Page
{
    //string strCon = ConfigurationManager.AppSettings["CN"];
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        DataList1.DataSource = FetchAllImagesInfo();
        DataList1.DataBind();
    }

    public DataTable FetchAllImagesInfo()
    {
        string sql = "Select * from tbimage where category='gift' order by cpp_required asc";
        SqlDataAdapter da = new SqlDataAdapter(sql, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

}
