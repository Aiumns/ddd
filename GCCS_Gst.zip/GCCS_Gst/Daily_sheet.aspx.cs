using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Daily_sheet : System.Web.UI.Page
{
    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Daily sheet report</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>28 march 08</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// <modifiedby></modifiedby>
    /// <modifiedOn></modifiedOn>
    /// <changeDescription></changeDescription>
    /// </modification>
        /// </modifications> 
    /// </summary> 
    ///
    #endregion
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string[] airlinesplit;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
     protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
        {

            DateTime DTM;
            DTM = DateTime.Now.AddMonths(6);

            txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            
            ShowAirline();
        }
    }
    protected void ShowAirline()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where airline_detail_id in (" + Rights() + ") order by airline_name,City_name", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));

            }
            cmd.Dispose();
        }
        catch (Exception eror)
        {
            string st = eror.ToString();
        }
        finally
        {
            con.Close();
            cmd.Dispose();
            dr.Close();
        }

    }
        protected void Btnload_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            //airlinesplit = ddl_airline_city.SelectedItem.Value.Split(',');

            //string[] airline_name_city_text = ddl_airline_city.SelectedItem.Text.Split('/');
            //string[] airline_name_city_value = ddl_airline_city.SelectedItem.Value.Split(',');
            //string flight_no = ddlflightno.SelectedItem.Text;
            string date_from = txtValidFrom.Text;
            if (ddl_airline_city.SelectedItem.Value == "0,0")
            {

                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Please Choose Airline/City.');</script>");
            }
          
           
            //  string airline_name_city_value=
            Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
            Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
            Session["flight_no"] = ddlflightno.SelectedItem.Text;
            Session["from_date"] = date_from;
            //Session["to_date"] = date_to;
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/daily_report.aspx');</script>");

        }   

    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        dr.Dispose();
        cmd.Dispose();

        return Access;

    }
    protected void ddl_airline_city_SelectedIndexChanged(object sender, EventArgs e)
    {

        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand("select Flight_No from Flight_master where Airline_Detail_ID="+airlinesplit[1], con);
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            ddlflightno.Items.Add(new ListItem(Convert.ToString(dr["Flight_No"]), Convert.ToString(dr["Flight_ID"])));
        
        }
        con.Close();
    }
    protected void flightno(object sender, EventArgs e)
    {
        string[] ddlfl = ddl_airline_city.SelectedValue.Split(',');
        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand("select Flight_No,Flight_ID from Flight_master where Airline_Detail_ID=" + ddlfl[1], con);
        dr = cmd.ExecuteReader();
        ddlflightno.Items.Clear();
        while (dr.Read())
        {
            ddlflightno.Items.Add(new ListItem(Convert.ToString(dr["Flight_No"]), Convert.ToString(dr["Flight_ID"])));

        }
        con.Close();
    }
}

