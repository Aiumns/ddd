using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
///This Page is Design & Coding By Alok Date:23.06.2008
/// </summary>

public partial class CrDrNote_Show : System.Web.UI.Page
{
    //Declare Public Variables here
    SqlConnection con = null;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null;
    string sort = null;
    string groupId = null;
    string agent_branch_id = null;
    //Make connection from web.config
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
           
                CSRShow();
        }
    }
    public string Rights()
    {
        string Access = "";
        try
        {
            string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


            con = new SqlConnection(strCon);
            con.Open();

            SqlCommand cmd = new SqlCommand(sql_Access, con);

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Access = dr["Airline_Access"].ToString();
                }

            }
            dr.Dispose();
            con.Close();
            cmd.Dispose();

        }
        catch (Exception ee)
        {
            ee.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
        return Access;

    }
    public void CSRShow()
    {

        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.
                if (txtsearch.Text == "")
                {

                    com = new SqlCommand("select sdr.sales_detail_id as sales_detail_id,s.sales_id as sales_id,am.agent_id as agent_id,s.Airline_detail_id as Airline_detail_id,s.city_id as city_id,s.sales_type as sales_type,am.agent_name as agent_name,sdr.airwaybill_no as airwaybill_no,convert(varchar,s.csr_date,103) as csr_date,s.destination_code as destination_code,s.charged_weight as charged_weight,sdr.entered_by as entered_by,convert(varchar,sdr.entered_on,106)  as entered_on from sales_drcr sdr inner join Agent_master am on sdr.agent_id=am.agent_id inner join sales S on s.sales_id=sdr.sales_id where sdr.sales_type in ('CRDR') and s.Airline_detail_id='" + drx[0].ToString() + "' and s.city_id='" + drx[1].ToString() + "' order by entered_on ", con);

                }
                else
                {

                    if (ddl.SelectedValue == "0")
                    {
                        com = new SqlCommand("select sdr.sales_detail_id as sales_detail_id,s.sales_id as sales_id,am.agent_id as agent_id,s.Airline_detail_id as Airline_detail_id,s.city_id as city_id,s.sales_type as sales_type,am.agent_name as agent_name,sdr.airwaybill_no as airwaybill_no,convert(varchar,s.csr_date,103) as csr_date,s.destination_code as destination_code,s.charged_weight as charged_weight,sdr.entered_by as entered_by,convert(varchar,sdr.entered_on,106) as entered_on from sales_drcr sdr inner join Agent_master am on sdr.agent_id=am.agent_id inner join sales S on s.sales_id=sdr.sales_id where s.sales_type in ('CRDR') and s.Airline_detail_id='" + drx[0].ToString() + "' and s.city_id='" + drx[1].ToString() + "' and sdr.AirWayBill_No like " + "'%" + txtsearch.Text + "%'  order by entered_on ", con);

                    }
                    if (ddl.SelectedValue == "1")
                    {
                        com = new SqlCommand("select sdr.sales_detail_id as sales_detail_id,s.sales_id as sales_id,am.agent_id as agent_id,s.Airline_detail_id as Airline_detail_id,s.city_id as city_id,s.sales_type as sales_type,am.agent_name as agent_name,sdr.airwaybill_no as airwaybill_no,convert(varchar,s.csr_date,103) as csr_date,s.destination_code as destination_code,s.charged_weight as charged_weight,sdr.entered_by as entered_by,convert(varchar,sdr.entered_on,106)  as entered_on from sales_drcr sdr inner join Agent_master am on sdr.agent_id=am.agent_id inner join sales S on s.sales_id=sdr.sales_id where s.sales_type in ('CRDR') and s.Airline_detail_id='" + drx[0].ToString() + "' and s.city_id='" + drx[1].ToString() + "' and am.Agent_Name like " + "'" + txtsearch.Text + "%' order by entered_on", con);

                    }
                }

                SqlDataReader dr1 = com.ExecuteReader();

                if (dr1.HasRows)
                {
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td align=""center"" nowrap >View</td><td  align=""center"" nowrap>Awb No.</td><td  align=""center"" nowrap>Agent Name</td><td align=""center"" nowrap >CR/DR date</td><td  align=""center"" nowrap>Dstn</td><td align=""center"" nowrap>Chg Wt.</td><td align=""center"" nowrap>Created by</td><td align=""center"" nowrap>Created Date</td></tr>
";
                    while (dr1.Read())
                    {
                        string strtype = "show";
                        string url_generate = "crdr_generate.aspx?Report=" + strtype + "&amp;sdid=" + dr1["sales_detail_id"].ToString() + "&amp;sid=" + dr1["sales_id"].ToString();
                        table += @"<tr><td align=left class=boldtext><a href=" + url_generate + " class=boldtext target=_blank>View</a></td><td align=left nowrap class=text>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=""left"" class=text >" + dr1["agent_name"].ToString() + @"</td><td align=""left"" class=text >" + dr1["csr_date"].ToString() + @"</td><td align=""right"" class=text>" + dr1["destination_code"].ToString() + @"</td><td align=""right"" class=text>" + dr1["Charged_Weight"].ToString() + @"</td><td align=""left"" class=text>" + dr1["entered_by"].ToString() + @"</td><td align=""left"" class=text>" + dr1["entered_on"].ToString() + @"</td></tr>";

                    }
                }
                else
                {

                }

                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
    protected void btnsearch_Click1(object sender, EventArgs e)
    {

    }
}
