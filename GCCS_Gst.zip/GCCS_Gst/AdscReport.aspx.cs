using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//hn mishra
public partial class AdscReport : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr;
    SqlDataReader dr1;
    string table = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnGen.Attributes.Add("Onclick", "return checkAirline();");
            if (!IsPostBack)
            {               
                ShowAirline();
            }
        }

    }
    protected void btnGen_Click(object sender, EventArgs e)
    {
        FillASDC();
    }
    protected void ShowAirline()
    {
        ddlAirline.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
           com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirline.Items.Add("Select airline name");
            ddlAirline.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirline.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void FillASDC()
    {
        string cityId = null;
        string airlineId = null;
        string airline_Code = null;
        DateTime dt1 = DateTime.Parse(ConvertDate1(txtDateFrom.Text));
        DateTime dt2 = DateTime.Parse(ConvertDate1(txtDateTo.Text));
        table = @"<p align=""center"" style=""font-size:large;""  ><span style=""color: #cc3300"">                ADSC Report<br>For<br>"+ddlAirline.SelectedItem.Text+@"<br>" + txtDateFrom.Text + " - " +                     txtDateTo.Text + @"</span></p>";
        table += @"<table class=""text"" align=""center"" border=""1""><tr> <th>S.No.</th> <th>DESCRIPTION OF DOCUMENTS</th><th>IATA CODE</th>	<th>AWB NOS </th>	<th>ISSUE DT</th><th>TOTAL</th> </tr><tr>";
       
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select  a.airline_detail_id,a.airline_id,a.Belongs_to_city,b.airline_Code from airline_detail a inner join airline_master b on b.airline_id=a.airline_id where  airline_detail_id='" + ddlAirline.SelectedValue.Trim() + "'", con);
            dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    airlineId = dr["airline_detail_id"].ToString();
                    airline_Code = dr["airline_Code"].ToString();
                    cityId = dr["Belongs_to_city"].ToString();
                }
            }
            dr.Dispose();
            com.Dispose();

            com = new SqlCommand("select a.agent_id,b.agent_name,b.IATA_code from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + airlineId + "%') and a.Belongs_To_City=" + cityId + " order by agent_name ", con);
            dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                int sno = 0;
                int Gtotal = 0;
                while (dr.Read())
                {
                    string sd = null;
                    int openstk = 0;
                    int stkrecd = 0;
                    int stkissue = 0;
                    int stkclossing = 0;
                    int count2 = 0;
                  // if(dr["agent_id"].ToString()=="481")
                    //   sd="";
                    //sno += 1;
                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();

                    SqlCommand com1 = new SqlCommand("select AirWayBill_No ,Receipt_LotNo,convert(varchar,Issue_Date,103) as Date from Stock_master where agent_id='" + dr["agent_id"].ToString() + "' and( Issue_Date <='" + dt2 + "' AND (Used_Date>'" + dt2 + "' OR Used_Date IS NULL)) and City_id='" + cityId + "' and substring(AirWayBill_No,0,4)='" + airline_Code + "'  union select AirWayBill_No ,Receipt_LotNo,convert(varchar,Issue_Date,103) as Date from Stock_master where agent_id='" + dr["agent_id"].ToString() + "' and(Issue_Date <='" + dt2 + "' AND (Used_Date<'" + dt2 + "' and status not in (11,12))) and City_id='" + cityId + "' and substring(AirWayBill_No,0,4)='" + airline_Code + "' ", con1);
                    dr1 = com1.ExecuteReader();
                    DataTable dt5 = new DataTable();
                    dt5.Load(dr1);
                    count2 = dt5.Rows.Count;
                    com1.Dispose();
                    dr1.Dispose();

                    if(count2>0)
                    {
                        sno += 1;

                    table += @"<td>" + sno + @"</td> <td align=""left"" >" + dr["agent_name"].ToString().ToUpper() + @"</td><td>" + dr["IATA_code"].ToString().ToUpper() + @"";

                    dr1.Dispose();
                    com1.Dispose(); 
                    int S = 0;
                    int count = 0;
                    table += @"&nbsp;</td>";

                    com1 = new SqlCommand("select AirWayBill_No ,Receipt_LotNo,convert(varchar,Issue_Date,103) as Date from Stock_master where agent_id='" + dr["agent_id"].ToString() + "' and( Issue_Date <='" + dt2 + "' AND (Used_Date>'" + dt2 + "' OR Used_Date IS NULL)) and City_id='" + cityId + "' and substring(AirWayBill_No,0,4)='" + airline_Code + "'  union select AirWayBill_No ,Receipt_LotNo,convert(varchar,Issue_Date,103) as Date from Stock_master where agent_id='" + dr["agent_id"].ToString() + "' and(Issue_Date <='" + dt2 + "' AND (Used_Date<'" + dt2 + "' and status not in (11,12))) and City_id='" + cityId + "' and substring(AirWayBill_No,0,4)='" + airline_Code + "' ", con1);
                        dr1 = com1.ExecuteReader();
                        //string tb = @"<table>";
                        //while (dr1.Read())
                        //{
                            //    tb += @"<tr><td nowrap>" + dr1["AirWayBill_No"].ToString() + @"</td>";
                            //    tb += @"<td nowrap>" + dr1["Date"].ToString() + @"</td></tr>";
                            //    count = count + 1;

                            //}
                            //tb += @"</table>";
                            //table += @"<td nowrap>" + tb + @"</td>";
                            //table += @"<td nowrap>" + count + @"</td></tr>";
                            //foreach(DataRow hh in dt.Columns[0].ro)
                            while (dr1.Read())
                            {
                              if (S == 1)
                                {
                                    if (count2  == count)
                                    {
                                       table += @"<td colspan=""3"">&nbsp;</td><td nowrap>&nbsp;" + dr1["AirWayBill_No"].ToString() + @"</td>";

                                       table += @"<td nowrap>&nbsp;" + dr1["Date"].ToString() + @"</td><td align=""right"" nowrap rowspan=""" + count2 + @">" + count2 + @"</td></tr>";
                                    }
                                    else
                                    {
                                        table += @"<td colspan=""3"">&nbsp;</td><td nowrap>&nbsp;" + dr1["AirWayBill_No"].ToString() + @"</td>";

                                        table += @"<td nowrap>" + dr1["Date"].ToString() + @"</td></tr><tr>";

                                    }


                                }
                                else
                                {
                                    S = 1;

                                    table += @"<td nowrap>&nbsp;" + dr1["AirWayBill_No"].ToString() + @"</td>";

                                    table += @"<td nowrap>&nbsp;" + dr1["Date"].ToString() + @"</td><td  align=""right""  rowspan=""" + count2 + @""">" + count2 + @"</td></tr><tr>";


                                  
                                }

                                count = count + 1;
                                Gtotal = Gtotal + 1;

                            }
                        //    table = @"<tr><td colspan=2> Total  </td><td> 9999</td> </tr></table>";
                            
                }    
                }
                table += @"<tr><td colspan=5> Total  </td><td>" + Gtotal + @"</td> </tr></table>";
               
            }
           
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Session["adscdt"] = table; 
      ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open      ('AsdcGen.aspx');</script>");
    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
}
