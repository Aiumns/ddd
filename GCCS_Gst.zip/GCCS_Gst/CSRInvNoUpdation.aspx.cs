﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
public partial class CSRInvNoUpdation : System.Web.UI.Page
{
    public string page_pop = "";
    static string csrFooter = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    SqlTransaction sqlTran; 

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
                hdnDate.Value = first.ToString();

                Page.Form.Target = "_blank";
                ////rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                ////rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");

                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();

                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 1;
                ddlMonth.Items[dt - 1].Selected = true;

                ShowAirline();
                if (Session["groupid"].ToString() != "5")
                {
                    ddlAirLine.AutoPostBack = true;
                    
                }
                else
                {
                   
                    ddlAirLine.AutoPostBack = false;
                   
                }
            }
        }
    }

    protected void ShowAirline()
    {
        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select airline name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            com.Dispose();
            con.Close();
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        ////rbtnDSelect.Checked = true;
        ////rbtnSelectAll.Checked = false;
        string agentId = null;
        string bID = null;

        ////lstAgent.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select airline_id,belongs_to_city,Csr_Footer from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
            dr = com.ExecuteReader();
            if (dr.Read())
            {
                agentId = dr["airline_id"].ToString();
                bID = dr["belongs_to_city"].ToString();


                csrFooter = dr["Csr_Footer"].ToString();
                char ch = (char)System.Windows.Forms.Keys.Return;
                char ch2 = (char)System.Windows.Forms.Keys.Space;
                string ch1 = Convert.ToString(ch);
                string ch3 = Convert.ToString(ch2);
                csrFooter = csrFooter.Replace(ch1, "<br>");
                csrFooter = csrFooter.Replace(ch3, "&nbsp;");
            }
            dr.Dispose();
            com.Dispose();
            ////////com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);

            //*************Added On 28 Mar 2011 For offline city (Agent) case****************

            if (Session["groupid"].ToString() == "55")
            {
                DataTable dtOflineSalePerson = dw.GetAllFromQuery("select Belongs_To_City from user_master where email='" + Session["EMailID"].ToString() + "'");
                if (dtOflineSalePerson.Rows.Count > 0)
                {


                    com = new SqlCommand("select DISTINCT b.agent_name,a.agent_id from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.offline_city=" + dtOflineSalePerson.Rows[0]["Belongs_To_City"].ToString() + " order by b.agent_name ", con);
                }

            }
            else if (Session["groupid"].ToString() == "60")
            {
                com = new SqlCommand("select DISTINCT b.agent_name,a.agent_id from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and b.Offline_Agent='Y' order by b.agent_name ", con);


            }
            else
            {

                com = new SqlCommand("select DISTINCT b.agent_name,a.agent_id from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%')  order by b.agent_name ", con);
            }

            //*******************End***********************************

            dr = com.ExecuteReader();
           
            dr.Close();
            com.Dispose();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }


    }


    public string GetUserIp()
    {
        string VisitorsIPAddr = string.Empty;
        //Users IP Address.
        if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
        {
            //To get the IP address of the machine and not the proxy
            VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
        }
        else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
        {
            VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
        }
        return VisitorsIPAddr;



    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            string startDate = ddlMonth.SelectedValue + "/" + ((rbtnFirstFortn.Checked == true) ? "1" : "16") + "/" + ddlyear.SelectedValue;

            string endDate = ddlMonth.SelectedValue + "/" + ((rbtnFirstFortn.Checked == true) ? "15" : (Convert.ToDateTime(ddlMonth.SelectedValue + "/1/" + ddlyear.SelectedValue).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + ddlyear.SelectedValue;

            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            if (Convert.ToDateTime(startDate) < first)
            {
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Live data available for limited period, please contact your sales representative for further details.');</script>");
                return;

            }

            string strAID = "";
            DataTable dt_airlineID = dw.GetAllFromQuery("select Airline_id from Airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "");
            if (dt_airlineID.Rows.Count > 0)
            {
                strAID = dt_airlineID.Rows[0]["Airline_id"].ToString();
            }

            TextBox TextBox1 = new TextBox();
            TextBox TextBox2 = new TextBox();

            TextBox1.Text = startDate;
            TextBox2.Text = endDate;

            Session["AIRDetailID"] = ddlAirLine.SelectedValue.Trim();
            Session["airline_name"] = ddlAirLine.SelectedItem.Text;
            Session["airline_value"] = ddlAirLine.SelectedItem.Value;
            Session["from_date"] = startDate;
            Session["to_date"] = endDate;

            string[] dateto = endDate.Split('/');
            string ToD = dateto[1].ToString();
            string ToM = dateto[0].ToString();





            string CurrDateofMonth = DateTime.Now.ToString();
            string[] CurdateSplit = CurrDateofMonth.Split('/');
            ////***********updated on 04 Aug 2017 : Invoice No must be sort of 16 digit

            

            ////***********updated on 04 Aug 2017 : Invoice No must be sort of 16 digit
            ///////////if ((int.Parse(CurdateSplit[1].ToString()) >= 20 && int.Parse(CurdateSplit[1].ToString()) <= 25) || (int.Parse(CurdateSplit[1].ToString()) >= 05 && int.Parse(CurdateSplit[1].ToString()) <= 10))
            ////if (((int.Parse(CurdateSplit[1].ToString()) >= 20 && int.Parse(CurdateSplit[1].ToString()) <= 25) && int.Parse(ToD) <= 15) || ((int.Parse(CurdateSplit[1].ToString()) >= 05 && int.Parse(CurdateSplit[1].ToString()) <= 10) && (int.Parse(ToD) >= 16 && int.Parse(ToD) <= 31)))
            ////{
           
            //************************Check where CSR for Entered Fortnoght is Approved Or Not**************************
            ////DataTable dtCsrApproved = dw.GetAllFromQuery("Select * from Csr_Details where csr_from='" + startDate + "' and csr_to='" + endDate + "' and Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and csr_detail_id is not null");
            ////if (dtCsrApproved.Rows.Count > 0 && dtCsrApproved.Rows[0][1].ToString() != null)
            ////{
                #region Check Distinct Agent
                DataTable dtAgent = dw.GetAllFromQuery("select distinct s.agent_id,am.agent_name as agent from sales s  inner join agent_master am on s.agent_id=am.agent_id where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and flight_date between '" + startDate + "' and '" + endDate + "' order by agent_name ");
                if (dtAgent.Rows.Count > 0 && dtAgent.Rows[0][1].ToString() != null)
                {
                    //One by one agent CsrInvoiceNo Updation
                    for (int i = 0; i < dtAgent.Rows.Count; i++)
                    {


                        //Data check for Agent on that period
                        /////DataTable dtAgentInvoiceNo = dw.GetAllFromQuery("select max(csr_sno) from sales where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and flight_date between '" + LastMStartDate + "' and '" + LastMEndDate + "'");

                        DataTable dtAgentInvoiceNo = dw.GetAllFromQuery("select GstInvNo from sales where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and flight_date between '" + startDate + "' and '" + endDate + "' and agent_id=" + dtAgent.Rows[i]["Agent_id"] + " and GstInvNo is not null");

                        //If data found for Agent
                        if (dtAgentInvoiceNo.Rows.Count > 0 && dtAgentInvoiceNo.Rows[0]["GstInvNo"].ToString() != null)
                        {
                            int invNo = int.Parse(dtAgentInvoiceNo.Rows[0]["GstInvNo"].ToString());
                            string update;

                            con = new SqlConnection(strCon);
                            con.Open();
                            //sqlTran = con.BeginTransaction();

                            update = "update sales set GstInvNo=" + invNo + " where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and flight_date between '" + startDate + "' and '" + endDate + "' and agent_id=" + dtAgent.Rows[i]["Agent_id"] + "";
                            SqlCommand com = new SqlCommand(update, con);
                            //com.Transaction = sqlTran;
                            com.CommandType = CommandType.Text;
                            com.ExecuteNonQuery();
                            con.Close();


                            ////con = new SqlConnection(strCon);
                            ////con.Open();
                            ////update = "update Csr_Details set GstInvNo=" + invNo + " where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and Csr_From='" + startDate + "' and csr_To='" + endDate + "' and agent_id=" + dtAgent.Rows[i]["Agent_id"] + "";
                            ////com = new SqlCommand(update, con);
                            ////com.CommandType = CommandType.Text;
                            ////com.ExecuteNonQuery();
                            ////con.Close();
                            // Commit the transaction.
                            //sqlTran.Commit();

                        }
                        //If data not found for Agent
                        else
                        {
                            //set Period for Financial Year for that Airline


                            string[] d = endDate.Split(new char[] { '/' });
                            string strDD = d[0];
                            string strMM = d[1];
                            string strYYYY = d[2];
                            string First = "";
                            string Last = "";

                            string FinancialYearLast = string.Empty;
                            int LastYear = 0;
                            string FinancialYearFirst = string.Empty;
                            if (int.Parse(strMM) > 3)
                            {
                                FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
                                LastYear = (DateTime.Now.Year + 1);
                                FinancialYearLast = "03/31/" + LastYear.ToString();
                            }
                            else
                            {
                                FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
                                LastYear = (DateTime.Now.Year - 1);
                                FinancialYearFirst = "04/01/" + LastYear.ToString();
                            }

                            if (int.Parse(strDD) <= 15)
                            {
                                First = "01/" + strMM + "/" + strYYYY;
                                Last = "15/" + strMM + "/" + strYYYY;
                            }
                            else
                            {
                                First = "16/" + strMM + "/" + strYYYY;
                                DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
                                string LastDate = Date.Day.ToString();
                                Last = LastDate + "/" + strMM + "/" + strYYYY;
                            }

                            DataTable dtMaxFinYAirlineInvNo = dw.GetAllFromQuery("select isnull(max(GstInvNo),0)as GstInvNo from sales where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and flight_date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "' and GstInvNo is not null");
                            if (dtMaxFinYAirlineInvNo.Rows.Count > 0 && dtMaxFinYAirlineInvNo.Rows[0]["GstInvNo"].ToString() != null)
                            {
                                int invNo = int.Parse(dtMaxFinYAirlineInvNo.Rows[0]["GstInvNo"].ToString()) + 1;

                                string update;
                                con = new SqlConnection(strCon);
                                con.Open();
                                //sqlTran = con.BeginTransaction();

                                update = "update sales set GstInvNo=" + invNo + " where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and flight_date between '" + startDate + "' and '" + endDate + "' and agent_id=" + dtAgent.Rows[i]["Agent_id"] + "";
                                SqlCommand com = new SqlCommand(update, con);
                                // com.Transaction = sqlTran;
                                com.CommandType = CommandType.Text;
                                com.ExecuteNonQuery();
                                con.Close();


                                //////con = new SqlConnection(strCon);
                                //////con.Open();
                                //////update = "update Csr_Details set GstInvNo=" + invNo + " where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and Csr_From='" + startDate + "' and csr_To='" + endDate + "' and agent_id=" + dtAgent.Rows[i]["Agent_id"] + "";
                                //////com = new SqlCommand(update, con);
                                //////com.CommandType = CommandType.Text;
                                //////com.ExecuteNonQuery();
                                //////con.Close();
                                // Commit the transaction.
                                //sqlTran.Commit();
                            }
                            else
                            {
                                int invNo = 1;
                                string update;
                                con = new SqlConnection(strCon);
                                con.Open();
                                // sqlTran = con.BeginTransaction();
                                update = "update sales set GstInvNo=" + invNo + " where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and flight_date between '" + startDate + "' and '" + endDate + "' and agent_id=" + dtAgent.Rows[i]["Agent_id"] + "";
                                SqlCommand com = new SqlCommand(update, con);
                                //com.Transaction = sqlTran;
                                com.CommandType = CommandType.Text;
                                com.ExecuteNonQuery();
                                con.Close();


                                //////con = new SqlConnection(strCon);
                                //////con.Open();
                                //////update = "update Csr_Details set GstInvNo=" + invNo + " where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and Csr_From='" + startDate + "' and csr_To='" + endDate + "' and agent_id=" + dtAgent.Rows[i]["Agent_id"] + "";
                                //////com = new SqlCommand(update, con);
                                //////com.CommandType = CommandType.Text;
                                //////com.ExecuteNonQuery();
                                //////con.Close();
                                // Commit the transaction.
                                //sqlTran.Commit();
                            }
                        }
                    }
                }
                #endregion

                ClientScript.RegisterStartupScript(GetType(), "MessageAlertGStNoUpdated", "<SCRIPT LANGUAGE='javascript'>alert('INVOICE NO updated successfully.');</script>");
            ////}

            ////else
            ////{
            ////    ClientScript.RegisterStartupScript(GetType(), "MessageAlertGStNo1Updated", "<SCRIPT LANGUAGE='javascript'>alert('You are not Authorise Invoice No Updation in this Period.');</script>");
            ////}
        }


        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
            //sqlTran.Rollback();
            ClientScript.RegisterStartupScript(GetType(), "MessageAlertGStNoUpdated", "<SCRIPT LANGUAGE='javascript'>alert('" + err + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
}
