using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AmendmentReq_Sales : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                DisApp.Visible = true;
                ChAmt.Visible = true;
               
                if (Request.QueryString.Count > 0)
                {
                    ShowAmendmentRequest();
                }
            }
        }

    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.Items[0].Selected == true)
        {
            DisApp.Visible = false;           
            Button1.ValidationGroup = "appro";
        }
        else
        {
            DisApp.Visible = true;            
            Button1.ValidationGroup = "Disappro";
        }

    }   
    protected void ShowAmendmentRequest()
    {
        if (Request.QueryString.Count > 0)
        {
            string query = "select e.Airline_Name+'-'+f.City_Name as Airline ,C.Airline_Detail_ID,am.agent_name,Convert(varchar,a.Rcd_Amt_UpdatedDate,103) as Rcd_Amt_UpdatedDate ,a.* from  Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID  inner join agent_master am on am.agent_ID=b.agent_ID inner join Airline_Detail C on C.Airline_Detail_ID=a.Airline_Detail_ID inner join Airline_Master e on e.Airline_ID=C.Airline_ID inner join City_Master f on f.City_ID=C.Belongs_To_City where a.SNo=" + Request.QueryString[0].ToString();

            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                com = new SqlCommand(query, con);
                SqlDataReader dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    if (Request.QueryString.Count>0)
                    {
                        DisApp.Visible = false;                      
                        lblAmendmentChAmt.Visible = true;
                        lblSep1.Visible = true;
                        txtNewChAmt.Visible = true;

                        while (dr.Read())
                        {
                            lblAgent.Text = dr["agent_name"].ToString();
                            lblAirLine.Text = dr["Airline"].ToString();
                            lblAWBNo.Text = dr["AWBNo"].ToString();
                            lblRequest.Text = dr["Request"].ToString();
                            txtRemarks.Text = dr["Remarks"].ToString();
                            TextBox1.Text = dr["Chargeable_Amount"].ToString();
                            txtNewChAmt.Text = dr["AmendmentChAmt"].ToString();
                        }
                   }
                }
            }
            catch (SqlException ex)
            {
                string strer = ex.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int result = 0;
        string query = "";
        if (RadioButtonList1.Items[0].Selected == true)
        {
            query = "update Collection_Charges set Chargeable_Amount=" + txtNewChAmt.Text + ",Ch_Amt_UpdatedBy='" + Session["EMailID"].ToString() + "',Status='Approved for action,payment pending',Ch_Amt_UpdatedDate='" + DateTime.Today + "',AmendmentChAmt='" + txtNewChAmt.Text + "' where SNo=" + Request.QueryString[0].ToString();
        }
        else
        {
            query = "update Collection_Charges set Chargeable_Amount='0',Ch_Amt_UpdatedBy='" + Session["EMailID"].ToString() + "',Status='Request rejected',DisAppRemarks='" + txtDisRmks.Text + "' where SNo=" + Request.QueryString[0].ToString();
        }

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand(query, con);
            result = com.ExecuteNonQuery();
            if (result == 1)
            {
                //lblMsg.Text = "Amendment request has been approved.";
                Response.Redirect("ViewAmendmentReq_Sales.aspx");

            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
}
