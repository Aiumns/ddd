using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Approve_CSR_Details_Delete : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    #region Variables Declaration

    // Declare public variables here 
    SqlDataReader dr = null;
    SqlConnection con;
    SqlCommand com;
    SqlTransaction trans = null;
    string str_AirlineDetailId;
    int CSR_Duration_ID;
    string strQueryString_Period;
    DateTime FROM_DATE;
    DateTime TO_DATE;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            str_AirlineDetailId = "";
            strQueryString_Period = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "Duration");
            string[] ARR_DATE = strQueryString_Period.Split('-');

            FROM_DATE = DateTime.Parse(ARR_DATE[0].ToString());
            TO_DATE = DateTime.Parse(ARR_DATE[1].ToString());


            str_AirlineDetailId = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "AirlineDetailId");
            //FINDING CSR DURATION IN DD/MM/YY FORMAT
            string csr_d = strQueryString_Period;
            string[] arr_csr = csr_d.Split('-');
            string First_Fort = arr_csr[0];
            string Sec_Fort = arr_csr[1];
            string[] Arr_First_Fort = First_Fort.Split('/');
            string MM = Arr_First_Fort[0];
            string DD = Arr_First_Fort[1];
            string yy = Arr_First_Fort[2];
            string DDMMYYYY = DD + "/" + MM + "/" + yy;

            string[] Arr_Sec_Fort = Sec_Fort.Split('/');
            string strMM = Arr_Sec_Fort[0];
            string strDD = Arr_Sec_Fort[1];
            string stryy = Arr_Sec_Fort[2];
            string strDDMMYYYY = strDD + "/" + strMM + "/" + stryy;

            string Final_CSR_Duration = DDMMYYYY + "-" + strDDMMYYYY;
            lblperiod.Text = Final_CSR_Duration;
            AirlineCode();


            con.Open();
            string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID,a.CSR_SNo FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND (csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "')  order by AM.AGENT_NAME  ";
            com = new SqlCommand(SqlQuery, con);

            dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = MakeTable();

                while (dr.Read())
                {
                    decimal TotChAmount = 0;
                    decimal TotDueCar = 0;
                    decimal TotTax = 0;
                    decimal TotAgentExp = 0;
                    decimal TotComm = 0;
                    decimal TotDiscount = 0;
                    decimal TotFrAmount = 0;
                    decimal TotFrAmountCC = 0;
                    decimal TotTds = 0;
                    decimal EduChrg = 0; decimal Total = 0;
                    decimal GrandTotal = 0;
                    //decimal TAX_AMOUNT = 0;
                    //decimal Only_TDS=0;
                    decimal surCharge = 0;

                    string lastTsdsRate = null;
                    string agnetID = dr["AGENT_ID"].ToString();
                    string Agent_name = dr["Agent_name"].ToString();
                    string Agent_Code = dr["Agent_Code"].ToString();
                    string CSR_SNo = dr["CSR_SNo"].ToString();

                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand com_csr = new SqlCommand("CSRsort", con1);
                    com_csr.CommandType = CommandType.StoredProcedure;
                    com_csr.Parameters.AddWithValue("agent_id", agnetID);
                    com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
                    com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
                    com_csr.Parameters.AddWithValue("Airline_Detail_ID", str_AirlineDetailId);

                    SqlDataReader dr_csr = com_csr.ExecuteReader();

                    while (dr_csr.Read())
                    {
                        TotChAmount += decimal.Parse(dr_csr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotAgentExp += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                        {
                            TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                            surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()))) * (decimal.Parse(dr_csr["Education_Cess"].ToString()))) / 100), MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                            surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()))) * (decimal.Parse(dr_csr["Education_Cess"].ToString()))) / 100), MidpointRounding.AwayFromZero);

                        }
                        lastTsdsRate = dr_csr["tds"].ToString();
                        string amountPP = null;
                        string amountCC = null;
                        if (dr_csr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr_csr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            amountPP = dr_csr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
                        }




                    }
                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge), MidpointRounding.AwayFromZero);

                    dr_csr.Dispose();
                    com_csr.Dispose();
                    con1.Close();
                    if (GrandTotal != 0)
                    {
                        DataRow dw = dt.NewRow();
                        dw[0] = CSR_SNo;
                        dw[1] = Agent_name;
                        dw[2] = GrandTotal;



                        dt.Rows.Add(dw);
                    }
                }
                if (dt.Rows.Count > 0)
                {

                    grdCSR.DataSource = dt;
                    grdCSR.DataBind();

                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    lblmsg.Text = "No Csr generated for the above period";
                    Button1.Visible = false;


                }

            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = "No Csr generated for the above period";
                Button1.Visible = false;


            }
            dr.Dispose();
            com.Dispose();
            con.Close();
        }


    }



    public DataTable MakeTable()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "CSR No";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = "Agent";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = "AmountRec/Payable";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        return dt;

    }
    public void AirlineCode()
    {
        try
        {
            string strQuery = "";

            if (str_AirlineDetailId != "")
            {
                strQuery = "select Airline_Code  from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + str_AirlineDetailId + "' ";


                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand com = new SqlCommand(strQuery, con);
                SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    lblairlinecode.Text = dr["Airline_Code"].ToString();
                }
                con.Close();
                com.Dispose();
                dr.Close();
            }
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    protected void grdCSR_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string strQuery = "";


        strQuery = "SELECT CSR_Duration_ID FROM CSR_Duration WHERE CSR_Duration='" + strQueryString_Period + "' ";


        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand(strQuery, con);
        SqlDataReader dr = com.ExecuteReader();
        if (dr.Read())
        {
            CSR_Duration_ID = int.Parse(dr["CSR_Duration_ID"].ToString());
        }
        con.Close();
        com.Dispose();
        dr.Close();

        Delete_Approve_CSR();
    }


    public void Delete_Approve_CSR()
    {
        try
        {
                    con.Open();
                    trans = con.BeginTransaction(); 
                    SqlConnection con_str = new SqlConnection(strCon);
                    // Update Sales
                    string strupdate = "update sales set approved_for_csr=29,csr_no=NULL WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND (csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "') ";
                        com = new SqlCommand(strupdate, con, trans);
                        com.ExecuteNonQuery();

                        // Delete CSR Details
                        string del = "Delete  from CSR_Details where Airline_Detail_ID='" + str_AirlineDetailId + "' AND csr_from='" + FROM_DATE + "' AND csr_to='" + TO_DATE + "' "; 
                        com = new SqlCommand(del, con, trans);
                        com.ExecuteNonQuery();

                // Delete records From Approved CSR
                        string Approve_csr_delete = "Delete  from Approved_CSR where Airline_Detail_ID='" + str_AirlineDetailId + "' AND CSR_Duration_ID='" + CSR_Duration_ID + "' ";
                        com = new SqlCommand(Approve_csr_delete, con, trans);
                        com.ExecuteNonQuery();
                        trans.Commit();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Delete Approved CSR SuccessFully!!";
                    Button1.Visible = false;
                    con.Close();

        }

        catch (SqlException sqe)
        {
            trans.Rollback();
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
   
    protected void grdCSR_RowCreated(object sender, GridViewRowEventArgs e)
    {

    }
    protected void grdCSR_RowDataBound1(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {



            double Amount = double.Parse(e.Row.Cells[2].Text);



            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;


            if (Amount < 0)
            {

                e.Row.Cells[2].ForeColor = System.Drawing.Color.Red;
                double Payable_Amount = Math.Abs(Amount);
                e.Row.Cells[2].Text = Payable_Amount.ToString();
            }



        }
    }
}
