using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class APSHandover : System.Web.UI.Page
{
    //Declare Public Variables here
    SqlConnection con = null;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null, table1 = null;
    string sort = null;
    string groupId = null;
    string agent_branch_id = null;
    public string strAwbsearch = "";
    SqlDataAdapter da;
    //Make connection from web.config
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        else
        {
            btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");
            strAwbsearch = "<script>var FillAwbNo=new Array(" + getAwb() + ")</script>";
            groupId = Session["groupid"].ToString();
            agent_branch_id = Session["ID"].ToString();
            if (!IsPostBack && Request.QueryString["id"] != null)
            {
                lblmsg.Visible = true;
                lblmsg.Text = " AirWayBill No '" + Request.QueryString["id"] + "' Has been HandOver SuccessFully ";
                Bookingdetails();
                handdetails();

            }
            else
            {
                Bookingdetails();
                handdetails();
            }

        }
    }
    public string getAwb()
    {
        string strAwbno = "";
        string city_id = "";
        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataReader dr1 = com.ExecuteReader();
            if (dr1.Read())
            {
                city_id = dr1["belongs_to_city"].ToString();
            }
            dr1.Dispose();
            com = new SqlCommand("SELECT bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where(bm.Status=9 or bm.Status=3) and ad.Airline_detail_id in (" + strAirline_Access + ") and ad.belongs_to_city='" + city_id + "' ", con);


            SqlDataReader dr = com.ExecuteReader();

            while (dr.Read())
            {

                if (strAwbno == "")
                    strAwbno = "'" + Convert.ToString(dr["AirWayBill_No"]).ToString().ToUpper().Trim() + "'";
                else
                    strAwbno = strAwbno + "," + "'" + Convert.ToString(dr["AirWayBill_No"]).ToString().ToUpper().Trim() + "'";

            }
            dr1.Close();
            com.Dispose();
            con.Close();


        }

        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
        return strAwbno;

    }

    public void Bookingdetails()
    {
        if (groupId != "")
        {
            if (Request.QueryString["awb_no"] != null)
            {
                sort = "sm.AirWayBill_No";
            }
            else if (Request.QueryString["agent"] != null)
            {
                sort = "am.Agent_Name";
            }
            else if (Request.QueryString["flt"] != null)
            {
                sort = "fm.Flight_No";
            }
            else if (Request.QueryString["fltd"] != null)
            {
                sort = "bm.Flight_Date";
            }
            else if (Request.QueryString["dst"] != null)
            {
                sort = "dm.Destination_Code";
            }
            else
            {
                sort = "bm.Flight_Date,fm.Flight_No,am.Agent_Name";
            }

            ShowBooking();


        }
        else
        {
            Label1.Text = "No Records Found";
        }
    }
    public void handdetails()
    {

        if (groupId != "")
        {
            if (Request.QueryString["awb_no"] != null)
            {
                sort = "b.AirWayBill_No";
            }
            else if (Request.QueryString["agent"] != null)
            {
                sort = "c.agent_name";
            }
            else if (Request.QueryString["flt"] != null)
            {
                sort = "e.flight_No";
            }
            else if (Request.QueryString["fltd"] != null)
            {
                sort = "d.flight_Date";
            }
            else if (Request.QueryString["dst"] != null)
            {
                sort = "g.destination_code";
            }
            else
            {
                sort = "d.flight_Date ,Flight_no,Agent_name";
            }
            ShowHandover();
        }
        else
        {
            lblhandove.Text = "No Records Found";

        }
    }
    public string Rights()
    {
        string Access = "";
        try
        {
            string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


            con = new SqlConnection(strCon);
            con.Open();

            SqlCommand cmd = new SqlCommand(sql_Access, con);

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Access = dr["Airline_Access"].ToString();
                }

            }
            dr.Dispose();
            con.Close();
            cmd.Dispose();

        }
        catch (Exception ee)
        {
            ee.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
        return Access;

    }
    public void ShowBooking()
    {
        try
        {
            // table header create
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.


                com = new SqlCommand("SELECT bm.Booking_ID,sm.AirWayBill_No, am.Agent_Name,fm.Flight_No, convert(varchar,bm.Flight_Date,103) as 'Flight_Date',bm.Flight_Date as 'fldate',dm.Destination_Code, bm.No_of_Packages, alm.Airline_Name, bm.Gross_Weight, bm.Charged_Weight, cm.City_Code FROM City_Master cm INNER JOIN Booking_Master bm ON cm.City_ID = bm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Airline_Master alm INNER JOIN Airline_Detail ad ON alm.Airline_ID = ad.Airline_ID INNER JOIN Flight_Master fm ON ad.Airline_Detail_ID = fm.Airline_Detail_ID AND ad.Airline_Detail_ID = fm.Airline_Detail_ID ON fo.Flight_ID = fm.Flight_ID AND fo.Flight_ID = fm.Flight_ID where(bm.Status=9 or bm.Status=3) and ad.Airline_detail_id='" + drx[0].ToString() + "' and ad.belongs_to_city='" + drx[1].ToString() + "' order by " + sort + " ", con);


                SqlDataReader dr1 = com.ExecuteReader();

                if (dr1.HasRows)
                {
                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?awb_no=awb_no'>Awb No.</a></td><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?agent=agent'>Agent Name</a></td><td align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?flt=flt'>Flight No</a></td><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?fltd=fltd'>Flight Date</a></td><td align=""center"" nowrap>Origin</td><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?dst=dst'>Dstn</a></td><td align=""center"" nowrap>Pcs.</td><td align=""center"" nowrap>Gwt.</td><td align=""center"" nowrap>Chg Wt.</td></tr>
";
                    while (dr1.Read())
                    {

                        //string url_noshow = "Booking_NoShow.aspx?Airwaybill_no=" + dr1["Airwaybill_no"] + "&amp;Booking_id=" + dr1["Booking_id"];

                        table += @"<tr><td align=left nowrap class=text><a href=AspHandover_Details.aspx?Airwaybill_no=" + dr1["AirWayBill_No"].ToString() + " class=boldtext>" + dr1["AirWayBill_No"].ToString() + @"</a></td><td align=""left"" class=text >" + dr1["agent_name"].ToString() + @"</td><td align=""left"" class=text nowrap>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_Date"].ToString() + @"</td><td align=""left"" class=text>" + dr1["city_code"].ToString() + @"</td><td align=""right"" class=text>" + dr1["destination_code"].ToString() + @"</td><td align=""right"" class=text>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""right"" class=text>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""right"" class=text>" + dr1["Charged_Weight"].ToString() + @"</td></tr>";

                    }
                }
                else
                {
                    //table += @"<table table width=""100%"" id=""Table1"" border=""0"">";

                }

                //table += @"<tr></tr></table>";
                dr1.Close();
                ip = ip + 1;
            }
            table += @"</table>";
            Label1.Text = table;


        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
    public void ShowHandover()
    {
        try
        {
            // table header create
            int i = 0;
            string strAirline_Access = Rights();
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select Airline_detail_id,belongs_to_city,Airline_Name,Airline_Code,City_Name,city_code from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join city_Master cm on ad.Belongs_To_City=cm.City_ID where am.status=2 and Airline_Detail_ID in(" + strAirline_Access + ") order by am.airline_name", con);

            int ip = 1;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                com = new SqlCommand("select a.handover_id,a.booking_id,c.Agent_id as 'Agent_id',(case when a.Add_to_Deal='13' then 'Deal' else 'NoDeal' end ) as Add_to_Deal,(case when a.Added_to_Sales='11' then 'Sales' else 'NoSale' end ) as Added_to_Sales ,a.stock_id,b.AirWayBill_No,c.agent_name as 'agent_name',e.flight_No,convert(varchar,d.flight_Date,103) as flight_Date,f.city_code,g.destination_code,a.No_Of_packages,a.Gross_Weight,a.Charged_Weight from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.added_to_sales='14' and f.city_id='" + drx[1].ToString() + "' and AirWayBill_No like '" + drx[3].ToString() + "%' order by " + sort + "", con);
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    table1 += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""20"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "-" + drx[3].ToString() + "(" + drx[5].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?awb_no=awb_no'>Awb No.</a></td><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?agent=agent'>Agent Name</a></td><td align=""center""nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?flt=flt'>Flight No</a></td><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?fltd=fltd'>Flight Date</a></td><td align=""center"" nowrap>Origin</td><td align=""center"" nowrap><a style='text-decoration:underline;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px;' href='APSHandover.aspx?dst=dst'>Dstn</a></td><td align=""center"" nowrap>Pcs.</td><td align=""center"" nowrap>Gwt.</td><td align=""center"" nowrap>Chg Wt.</td><td align=""center"" nowrap>View</td></tr></th>";
                    while (dr1.Read())
                    {
                        table1 += @"<tr><td align=left class=text><a href=AspHandover_Details.aspx?Airwaybill_no=" + dr1["AirWayBill_No"].ToString()+"&st=U target=newwindow class=boldtext>" + dr1["AirWayBill_No"].ToString() + @"</a></td><td align=""left"" class=text>" + dr1["agent_name"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_No"].ToString() + @"</td><td align=""left"" class=text>" + dr1["flight_Date"].ToString() + @"</td><td align=""left"" class=text>" + dr1["city_code"].ToString() + @"</td><td align=""left"" class=text>" + dr1["destination_code"].ToString() + @"</td><td align=""left"" class=text>" + dr1["No_Of_packages"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Gross_Weight"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Charged_Weight"].ToString() + @"</td><td align=""center"" nowrap class=boldtext><a href=AspHandover_Details.aspx?Airwaybill_no=" + dr1["AirWayBill_No"].ToString() + "&st=H>Print Details</a></td></tr>";
                    }
                }
                else
                {

                    //table += @"<tr><td align=""center"" colspan=""11""></td></tr>";
                }


                dr1.Close();
                ip = ip + 1;
            }
            table1 += @"</table>";
            lblhandove.Text = table1;
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");
        con = new SqlConnection(strCon);
        string stradd = "";
        try
        {

            stradd = "select * from stock_master where status in (9,3) and airwaybill_no='" + txtAwbno.Text + "'";
            con.Open();
            da = new SqlDataAdapter(stradd, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count <= 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Records Not Found";



            }
            else
            {
                string url_show = "AspHandover_Details.aspx?Airwaybill_no=" + txtAwbno.Text + "";
                Response.Redirect(url_show);
            }

        }

        catch (SqlException err)
        {
            string msg = err.ToString();

        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
                con.Close();
        }

    }

}
