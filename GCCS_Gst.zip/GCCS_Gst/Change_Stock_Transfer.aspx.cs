﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Drawing;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//-----------------------------------------------------------------------------------------------------
public partial class Change_Stock_Transfer : System.Web.UI.Page
    {
    //-----------------------------------------------------------------------------------------------------
    #region variable declaration
    //-----------------------------------------------------------------------------------------------------
    string Agentid;
    Int64 conn;
    string cityid;
    string cityname;
    string[] airlinecode;
    int z;
    string recieptdate;
    string updateairlineaccess;
    string Airlineaccess;
    string Receiptlotno;
    string s;
    bool airlinea = false;
    SqlTransaction trans;
    string issueawb;
    string strquery;
    SqlCommand cmd;
    SqlDataReader rdr;
    SqlConnection con;
    SqlDataAdapter sda;
    string[] strCityAirline = null;
    string[] strCityAgent = null;
    string[] strAirlineAccesss = null;
    DisplayWrap dw = new DisplayWrap();
    int ss;
    bool AWB = false;
    //-----------------------------------------------------------------------------------------------------
    #endregion
    //-----------------------------------------------------------------------------------------------------
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    //-----------------------------------------------------------------------------------------------------
    protected void Page_Load(object sender, EventArgs e)
        {
        if (Session["EMailID"] == null)
            {
            Response.Redirect("Login.aspx");
            }
        else
            {
            btnissue.Attributes.Add("onclick", "return awbstartingno()");
            if (!IsPostBack)
                {
                ddlfillairlinecode();
                }
            }
        }
    //-----------------------------------------------------------------------------------------------------
    #region to bind airlinecode in dropdown list
    //-----------------------------------------------------------------------------------------------------
    //-----------------------------------------------------------------------------------------------------
    protected void ddlfillairlinecode()
        {
        using (con)
            {
            con = new SqlConnection(strCon);
            con.Open();
            try
                {
                strquery = " select Airline_Access from dbo.Login_Master where Email_ID='" + Session["EMailID"] + "'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                rdr.Read();
                string airline_access = rdr["Airline_Access"].ToString();
                rdr.Close();
                ddlAirlinecode.Items.Insert(0, "--Select--");
                ddlAirlinecode.Items[0].Value = "0";
                strquery = "select  am.Airline_Code,am.airline_name,cm.City_Code,ad.Airline_Detail_ID,cm.City_ID from dbo.Airline_Master as am inner join airline_detail as ad on ad.airline_id=am.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City where ad.Airline_Detail_ID in (" + airline_access + ")  and am.status='2' order by am.Airline_Code asc";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                    ddlAirlinecode.Items.Add(new ListItem(rdr["airline_code"].ToString() + '-' + rdr["Airline_name"].ToString() + ',' + rdr["City_Code"].ToString(), rdr["City_ID"].ToString() + "-" + rdr["Airline_Detail_ID"].ToString()));
                rdr.Close();
                }
            catch (SqlException ee)
                {
                Response.Write("sql error" + ee.Message);
                }
            }
        }
    //-----------------------------------------------------------------------------------------------------
    #endregion
    //-----------------------------------------------------------------------------------------------------
    //-----------------------------------------------------------------------------------------------------
    protected void airlindecodesindexchanged(object sender, EventArgs e)
        {
        Fillcity();
        topawbno();
        }
    //-----------------------------------------------------------------------------------------------------
    public void Fillcity()
        {
        string airlinetext = ddlAirlinecode.SelectedItem.Text.ToString();
        string[] citycode = airlinetext.Split(',');
        string[] airlinecode = citycode[0].Split('-');
        strquery = "select city_id, city_name from city_master where city_code='" + citycode[1] + "'";
        DataTable dt = dw.GetAllFromQuery(strquery);
        if (dt.Rows.Count > 0)
            {
            for (int j = 0; j < dt.Rows.Count; j++)
                {
                cityid = dt.Rows[j]["city_id"].ToString();
                cityname = dt.Rows[j]["city_name"].ToString();
                }
            }
        Session["cityid"] = cityid;
        Session["airlinecode"] = airlinecode[0];
        ddlChng_city.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        strquery = "SELECT DISTINCT cm.City_ID,cm.City_Code FROM dbo.City_Master cm INNER JOIN dbo.Airline_Detail AS AD ON AD.Belongs_To_City=cm.City_ID INNER JOIN dbo.Airline_Master AS AM ON AM.Airline_ID = AD.Airline_ID WHERE am.Airline_Code='" + airlinecode[0] + "'AND City_ID NOT IN (" + cityid + ") ORDER BY cm.City_Code";
        cmd = new SqlCommand(strquery, con);
        ddlChng_city.Items.Insert(0, "--Select--");
        ddlChng_city.Items[0].Value = "0";
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            {
            ddlChng_city.Items.Add(new ListItem(dr["City_Code"].ToString(), dr["City_ID"].ToString()));
            }
        dr.Close();
        }
    //-----------------------------------------------------------------------------------------------------
    public void topawbno()
        {
        lstAWB.Items.Clear();
        using (con)
            {
            if (ddlAirlinecode.SelectedIndex == 0)
                {
                lstAWB.Items.Clear();
                //CheckBox1.Enabled = false;
                lbllt.Text = null;
                lblst.Text = null;
                }
            else
                {
                con = new SqlConnection(strCon);
                con.Open();
                try
                    {
                    string airlinetext = ddlAirlinecode.SelectedItem.Text.ToString();
                    string[] citycode = airlinetext.Split(',');
                    string[] airlinecode = citycode[0].Split('-');
                    strquery = "select city_id, city_name from city_master where city_code='" + citycode[1] + "'";
                    cmd = new SqlCommand(strquery, con);
                    rdr = cmd.ExecuteReader();
                    rdr.Read();
                    cityid = rdr["city_id"].ToString();
                    cityname = rdr["city_name"].ToString();
                    Session["cityid"] = cityid;
                    Session["airlinecode"] = airlinecode[0];
                    rdr.Close();
                    strquery = " select  AirWayBill_No from stock_master where City_ID='" + cityid + "' and AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8' or status='17') ";
                    cmd = new SqlCommand(strquery, con);
                    rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                        {
                        while (rdr.Read())
                            {
                            lstAWB.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                            }
                        for (int x = 0; x < lstAWB.Items.Count; x++)
                            {
                            lstAWB.Items[x].Selected = true;
                            }
                        //CheckBox1.Enabled = true;
                        //CheckBox1.Checked = true;
                        lblerrlistbox.Visible = false;
                        lblst.Visible = true;
                        lbllt.Visible = true;
                        lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                        lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
                        }
                    else
                        {
                        lblst.Visible = false;
                        lbllt.Visible = false;
                        lblerrlistbox.Visible = true;
                        lblerrlistbox.Text = "No AWBNo found for Transfer";
                        //CheckBox1.Enabled = false;
                        }
                    //txtAWB.Text = "";
                   // txtAWBN.Text = "";
                    rdr.Close();
                    }
                catch (SqlException ee)
                    {
                    Response.Write("sql error" + ee.Message);
                    }
                }
            }
        }
    //-----------------------------------------------------------------------------------------------------
    //protected void Button3_Click(object sender, EventArgs e)
    //    {
    //    lstAWB.Items.Clear();
    //    lbllt.Text = "";
    //    lblst.Text = "";
    //    Label3.Text = "";
    //    if (!(txtAWB.Text == "") && !(txtAWBN.Text == ""))
    //        {
    //        using (con)
    //            {
    //            con = new SqlConnection(strCon);
    //            con.Open();
    //            cityid = Session["cityid"].ToString();
    //            string a = cityid;
    //            try
    //                {
    //                strquery = "select  AirWayBill_No,status from stock_master where Receipt_LotNo=( select  Receipt_LotNo from stock_master where City_ID='" + cityid + "' and AirWayBill_No like  '%" + Session["airlinecode"].ToString() + "-" + txtAWB.Text + "') and (Status='8' or status='17')  ORDER BY dbo.Stock_Master.AirWayBill_No";
    //                cmd = new SqlCommand(strquery, con);
    //                lstAWB.DataTextField = "AirWayBill_No";
    //                rdr = cmd.ExecuteReader();
    //                int count = int.Parse(txtAWBN.Text);
    //                if (rdr.HasRows)
    //                    {
    //                    conn = 0;
    //                    while (rdr.Read())
    //                        {
    //                        decimal m = decimal.Parse(rdr["AirWayBill_No"].ToString().Substring(4));
    //                        decimal p = decimal.Parse(txtAWB.Text);
    //                        string sts = rdr["status"].ToString();
    //                        if (decimal.Parse(rdr["AirWayBill_No"].ToString().Substring(4)) >= decimal.Parse(txtAWB.Text))
    //                            {
    //                            if (count != 0)
    //                                {
    //                                lstAWB.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
    //                                lblst.Visible = true;
    //                                lbllt.Visible = true;
    //                                lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
    //                                lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
    //                                count--;
    //                                }
    //                            }
    //                        }
    //                    lblerrlistbox.Visible = false;
    //                    for (int q = 0; q < lstAWB.Items.Count; q++)
    //                        {
    //                        lstAWB.Items[q].Selected = true;
    //                        }
    //                    CheckBox1.Enabled = true;
    //                    CheckBox1.Checked = true;
    //                    lblerrlistbox.Visible = false;
    //                    if (Convert.ToInt16(txtAWBN.Text) > (lstAWB.Items.Count))
    //                        {
    //                        lblerrlistbox.Visible = true;
    //                        lblerrlistbox.Text = "Only" + "  " + lstAWB.Items.Count + " " + " " + " AWBNo.(s) are Available. ";
    //                        }
    //                    }
    //                else
    //                    {
    //                    lblerrlistbox.Visible = true;
    //                    lblerrlistbox.Text = "No AWBNo. Found";
    //                    CheckBox1.Enabled = false;
    //                    lblst.Visible = false;
    //                    lbllt.Visible = false;
    //                    }
    //                rdr.Close();
    //                }
    //            catch (SqlException ee)
    //                {
    //                Response.Write("sql error" + ee.Message);
    //                }
    //            }
    //        }
    //    if ((txtAWB.Text == "") && (txtAWBN.Text == ""))
    //        {
    //        lblerrlistbox.Visible = false;
    //        con = new SqlConnection(strCon);
    //        con.Open();
    //        strquery = " select top 10 AirWayBill_No,status from stock_master where City_ID='" + cityid + "' and AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8'  or status='17')";
    //        cmd = new SqlCommand(strquery, con);
    //        rdr = cmd.ExecuteReader();
    //        if (rdr.HasRows)
    //            {
    //            while (rdr.Read())
    //                {
    //                lstAWB.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
    //                lblst.Visible = true;
    //                lbllt.Visible = true;
    //                lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
    //                lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
    //                }
    //            lblerrlistbox.Visible = false;
    //            for (int q = 0; q < lstAWB.Items.Count; q++)
    //                {
    //                lstAWB.Items[q].Selected = true;
    //                }
    //            CheckBox1.Enabled = true;
    //            CheckBox1.Checked = true;
    //            }
    //        else
    //            {
    //            lblerrlistbox.Visible = true;
    //            lblerrlistbox.Text = "No AWBNo. Found.";
    //            CheckBox1.Enabled = false;
    //            }
    //        rdr.Close();
    //        }
    //    }
    //-----------------------------------------------------------------------------------------------------
    //protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    //    {
    //    if (CheckBox1.Checked == true)
    //        {
    //        for (int q = 0; q < lstAWB.Items.Count; q++)
    //            {
    //            lstAWB.Items[q].Selected = true;
    //            }
    //        }
    //    else
    //        {
    //        for (int q = 0; q < lstAWB.Items.Count; q++)
    //            {
    //            lstAWB.Items[q].Selected = false;
    //            }
    //        lstAWB.Items[0].Selected = true;
    //        }
    //    }
    //-----------------------------------------------------------------------------------------------------
    protected void btnissue_Click(object sender, EventArgs e)
        {
        try
            {
            con = new SqlConnection(strCon);
            for (int i = 0; i < lstAWB.Items.Count; i++)
                {
                if (lstAWB.Items[i].Selected == true)
                    {
                    con.Open();
                    cmd = new SqlCommand("UPDATE dbo.Stock_Master SET City_ID=" + ddlChng_city.SelectedValue + "  WHERE AirWayBill_No IN ('" + lstAWB.Items[i] + "')", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Label3.Visible = false;
                    }
                }
            }
        catch (SqlException ex)
            {
            // Response.Write(ex.Message);
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", ex.Message, true);
            }
        Response.Redirect("Change_Stock_Transfer.aspx");
        }
    }
