﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using System.Windows.Forms;

public partial class CSrGen_KEIATA_Pdf : System.Web.UI.Page
{
    string CityAsStateCode = "DELHI";
    public string page_pop = "";
    string agentName = null;
    string tableAll = "", comName = null;
    string massage = null;
    string city_id = null;
    string tableCSr = "";
    string tableTdsMsg = "";
    string tableTdsExemptedMsg = "";
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();

    #region Gst applicable from 01 july 2017
    string CompGstNo = "07";
    string AgentGstNo = "08";
    //////decimal CGST = 9;
    //////decimal SGST = 9;
    //////decimal IGST = 18;

    //////decimal TotalCGST = 9;
    //////decimal TotalSGST = 9;
    //////decimal TotalIGST = 18;
    //////decimal TotalGst = 0;
    #endregion end of Gst Applicable
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        string DateWise = "flight_date";
        string[] airline_name_city_text = Session["airline_name"].ToString().Split('-');
        string airline_name_city_value = Session["airline_value"].ToString();
        #region Fetching of Airline ID
        string AID = "";
        SqlConnection con1 = new SqlConnection(strCon);
        DataTable dt_AID = dw.GetAllFromQuery("SELECT  Airline_ID FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + airline_name_city_value + "");
        if (dt_AID.Rows.Count > 0)
        {
            AID = dt_AID.Rows[0]["Airline_ID"].ToString();
        }

        #endregion

        if (airline_name_city_value == "150" || airline_name_city_value == "153" || airline_name_city_value == "163" || airline_name_city_value == "166")
        {
            DateWise = "awb_date";
        }
        string[] agent_selected_id = Session["Agent_List_value"].ToString().Split('~');
        string[] agent_selected_name = Session["Agent_list_Text"].ToString().Split('~');
        string from_date = Session["from_date"].ToString().Trim();
        string to_date = Session["to_date"].ToString().Trim();
        string rdbtn = Session["rdbtn1"].ToString();
        string csrFooter = Session["csr_footer"].ToString();
        string comAdd = null;
        string airline = "A/C " + airline_name_city_text[0].ToUpper().ToString();
        string agnetID = "";
        string approveCsr = checkApprove(from_date, to_date);
        // CHECK FOR FINANCIAL YEAR
        string sCurrentDate = from_date.ToString();
        DateTime curDate = DateTime.Parse(sCurrentDate);
        string sFinYear = "";
        if (curDate.Month <= 3)
        {
            int startYr = curDate.Year - 1;
            sFinYear = "01/04/" + startYr.ToString() + "-" + DateTime.Parse(from_date).AddDays(-1).ToString("dd/MM/yyyy");
        }
        else
        {
            int endYr = curDate.Year + 1;
            sFinYear = "01/04/" + curDate.Year + "-" + DateTime.Parse(from_date).AddDays(-1).ToString("dd/MM/yyyy");
        }

        string FinancialYear = sFinYear;



        //Gst Approved csr date

        string[] startDate = from_date.Split('/');
        string created_date = DateTime.Now.ToString("dd/MM/yyyy");
        if (int.Parse(startDate[1].ToString()) <= 15)
        {
            created_date = "25/" + startDate[0].ToString() + "/" + startDate[2].ToString();
        }
        else
        {
            if (startDate[0].ToString() == "12")
            {
                created_date = "10/01/" + (int.Parse(startDate[2].ToString()) + 1);
            }
            else
            {
                created_date = "10/" + (int.Parse(startDate[0].ToString()) + 1) + "/" + startDate[2].ToString();
            }
        }

        //end of Gst Approved csr date



        if (Session["groupid"].ToString() != "5")
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                decimal CGST = 9;
                decimal SGST = 9;
                decimal IGST = 18;

                decimal TotalCGST = 9;
                decimal TotalSGST = 9;
                decimal TotalIGST = 18;
                decimal TotalGst = 0;

                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotValuationCharges = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;
                string lastSurcharge = "0.0000", lastTsdsRate = "0.0000", lastedcess = "0.00";

                string table = null, table_image = null, table_note = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";

                }
                else
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();

                    DataTable dtcity = dw.GetAllFromQuery("Select City_name from City_Master where City_id=" + city_id + "");
                    if (dtcity.Rows.Count > 0 && dtcity != null)
                    {
                        if (dtcity.Rows[0]["City_name"] != "")
                        {
                            CityAsStateCode = dtcity.Rows[0]["City_name"].ToString();
                        }
                    }


                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (airline_name_city_value.Trim() == "152")
                        {
                            if (h.Contains("11005"))
                            {
                                string[] h1 = h.Split('5');
                                h = h1[0].ToString() + "5";
                            }
                        }
                        comName = dr["company_name"].ToString();
                        #region Gst CompanyGstNo
                        DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + airline_name_city_value + "");
                        if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
                        {
                            CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                        }
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr ><td  width=""75%"" align=""center""></td><td   align=""left""><font size=""2""><b>Invoice Date: " + created_date + "</b></font></td></tr></table><br>";
                            /////table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font><br><font size=""1"">GST NO:" + CompGstNo + "</font></p></td></tr></table><br>";
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src='http://systems.cargoflash.com/images/gclogo_new.gif'</td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font><br><font size=""1"">GST NO:" + CompGstNo + "</font></p></td></tr></table><br>";
                        }
                        else
                        {
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";
                        }
                        #endregion end of Gst CompanyGstNo
                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        s = s.Replace("\r\n", "");
                        s = s.Replace(",", ", ");
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (AID == "160")
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>CIN NO.U74899DL1993PTC052734</td></tr></table>";
                        }
                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************
                        /////table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:10px;"">" + agentName + @"</b><br>" + h + @"<br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</br><b><br><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        #region Gst No for Agent

                        string Invoice_No = "";


                        DataTable dtInvoiceNo = dw.GetAllFromQuery("select max(GstInvNo) as GstInvNo,max(invoice_no) as invoice_no,MAX(Invoice_SNO) AS invoicesno,max(csr_sno)as csr_sno,max(GstAddress) as GstAddress from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                        if (dtInvoiceNo.Rows.Count > 0)
                        {
                            #region Using Csr_Sno from Sales table i/o InvoiceNo from Invoice Table
                            ////////Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                            /////DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix +'/'+Fin_Year)as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoicesno"].ToString() + " ");


                            if (dtInvoiceNo.Rows[0]["GstAddress"].ToString() != "")
                            {
                                s = dtInvoiceNo.Rows[0]["GstAddress"].ToString();
                                s = s.Replace("\r\n", "");
                                s = s.Replace(",", ", ");
                                ch = (char)System.Windows.Forms.Keys.Return;
                                ch2 = (char)System.Windows.Forms.Keys.Space;
                                ch1 = Convert.ToString(ch);
                                ch3 = Convert.ToString(ch2);
                                h = s.Replace(ch1, "<br>");
                                h = h.Replace(ch3, "&nbsp;");
                            }




                            string Flight_date = to_date;
                            string[] dateSplit = Flight_date.Split('/');
                            string Month = dateSplit[1].ToString();
                            string Year = dateSplit[2].ToString();
                            string Date1 = dateSplit[0].ToString();
                            ////string currentdate = Month + "/" + Date1 + "/" + Year;
                            string currentdate = Date1 + "/" + Month + "/" + Year;
                            string FinYear = Year.Substring(2, 2);
                            //// string dateCurrent = DateTime.Now.ToShortDateString();

                            /////DateTime CurrDate = DateTime.Now;
                            DateTime CurrDate = DateTime.Parse(currentdate);
                            string DateFinancial = "4/1/20" + FinYear + "";
                            DateTime FinanciaDate = DateTime.Parse(DateFinancial);


                            if (CurrDate < FinanciaDate)
                            {
                                FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            }
                            else
                            {
                                FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            }

                            //////if (CurrDate < FinanciaDate)
                            //////{
                            //////    FinYear =  Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            //////}
                            //////else
                            //////{
                            //////    FinYear = FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            //////}
                            //*********************End***************************************************************

                            DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix + substring(Fin_Year,3,5))as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND Fin_Year='" + FinYear + "'");

                            if (dtInvoice.Rows.Count > 0)
                            {
                                ///////Updated on 30 May 2017
                                ////Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();


                                if (DateTime.Parse(to_date) < DateTime.Parse("08/01/2017"))
                                {
                                    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["CSr_Sno"].ToString();
                                }
                                else
                                {
                                    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["GstInvNo"].ToString();
                                }
                            }

                            ////////End of Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                            #endregion

                            #region Picking Invoice_No from Invoice table i/o Csr_Sno from sales table
                            //DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix +'/'+Fin_Year)as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoicesno"].ToString() + " ");
                            //if (dtInvoice.Rows.Count > 0)
                            //{
                            //    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();
                            //}
                            #endregion
                        }

                        //******************end**************************************//
                        //table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table><br>";
                        ////table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h3>INVOICE No: &nbsp;&nbsp;&nbsp;" + Invoice_No + @"</h3></b></td></tr></table><br>";
                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        DataTable dtAgentGstNo = dw.GetAllFromQuery("select top 1 (case when gstno is null then Statecode else gstno end) as GstNo from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                        if (dtAgentGstNo != null && dtAgentGstNo.Rows.Count > 0)
                        {
                            if (dtAgentGstNo.Rows[0]["GstNo"].ToString() != "")
                                AgentGstNo = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                        }

                        #region Palce of Delivery and State code
                        string stateCode = CityAsStateCode;
                        DataTable CityCode = dw.GetAllFromQuery("select city_name from city_master where city_id=" + city_id + "");
                        stateCode = CityCode.Rows[0]["city_name"].ToString();
                        DataTable gststateCode = dw.GetAllFromQuery("select state from GstStateCode where stateCode='" + AgentGstNo.Substring(0, 2) + "'");
                        if (gststateCode != null && gststateCode.Rows.Count > 0)
                        {
                            if (gststateCode.Rows[0]["state"].ToString() != "")
                                stateCode = gststateCode.Rows[0]["state"].ToString();
                        }

                        #endregion end of Palce of Delivery and State code


                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<br><b>IATA Code:</b>;&nbsp;" + dr["IATA_Code"].ToString() + @"<br><b>INVOICE No:</b>&nbsp;" + Invoice_No + @"<br><b>GST NO:</b>&nbsp;" + AgentGstNo + "<br/><b>State Code:" + stateCode + "<b><br/><b>Place Of Supply: " + stateCode + "<b><br/><b>HSN Code:&nbsp;996531</b><br><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        }
                        else
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code: &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b><br/><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        }
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        #endregion End of Gst No for Agent
                    }
                    com.Dispose();
                    dr.Dispose();
                    //=========================================Add By :Pradeep Sharma For Tabel Heading=====================================
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<table  border=0 align=center style='word-spacing:inherit width=100%;' ><tr ><td  width=100% align=center><font size=2><b><u>TAX INVOICE</u></b></font></td></tr></table><br>";
                        table += @"<table width=95%  ><tr ><td style='font-size:8px;height:5px;' >Date</td><td style='font-size:8px;height:5px;'>AWB No.</td>";
                        table += @"<td style='font-size:8px;height:5px;'  >Dest</td><td style='font-size:8px;height:5px;'  >Chrg. Wt</td><td style='font-size:8px;height:5px;'  colspan=2 
align=center>Freight</td><td style='font-size:8px;height:5px;'  align=center 
>Due Carrier</td>
<td style='font-size:8px;height:5px;'  align=left >Agent Expenses</td> 
<td  style='font-size:8px;height:5px;'  align=center >Comm.</td> 
<td  style='font-size:8px;height:5px;'  align=center >Discount</td> 
<td  style='font-size:8px;height:5px;'  align=center >Remark</td></tr>
<tr  style='height:5px;'>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >PP</td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >CC</td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
</tr>";
                        //////table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>";
                    }
                    else
                    {

                        table += @"<table width=95%  ><tr ><td style='font-size:8px;height:5px;' >Date</td><td style='font-size:8px;height:5px;'>AWB No.</td>";
                        table += @"<td style='font-size:8px;height:5px;'  >Dest</td><td style='font-size:8px;height:5px;'  >Chrg. Wt</td><td style='font-size:8px;height:5px;'  colspan=2 
align=center>Freight</td><td style='font-size:8px;height:5px;'  align=center 
>Due Carrier</td>
<td style='font-size:8px;height:5px;'  align=left >Agent Expenses</td> 
<td  style='font-size:8px;height:5px;'  align=center >Comm.</td> 
<td  style='font-size:8px;height:5px;'  align=center >Discount</td> 
<td  style='font-size:8px;height:5px;'  align=center >Remark</td></tr>
<tr  style='height:5px;'>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >PP</td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >CC</td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
</tr>";
                        //////table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>";
                    }
                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (from_date == "04/1/2008" && to_date == "04/15/2008")
                        {

                            com = new SqlCommand("CSRsort_Temp", con);
                        }
                        else
                        {
                            com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                        }

                    }

                    if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                        com = new SqlCommand("csrsort_Temp", con);
                    else
                        com = new SqlCommand("csrsort_Temp_KEIATA", con);

                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    string VarDate = "07/31/2008";
                    string MH_Period = "08/15/2008";
                    int p = 0;

                    while (dr.Read())
                    {
                        p++;
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString() == "235-70456945")
                        {
                        }
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;

                            }
                            else
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                //****************Added On 02 dec 2011***************
                                if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                                {
                                    DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                    if (dtMinCheck.Rows.Count > 0)
                                    {
                                        if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                        {
                                            TotDiscount += 0;
                                            TotComm += 0;
                                        }

                                        else
                                        {
                                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                            TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                }
                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                //**********************End Of 02 Dec*****************************                              
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            //****************Added On 02 dec 2011***************
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                            {
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }
                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }

                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            }

                            //**********************End Of 02 Dec*****************************                          
                            TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotValuationCharges += Math.Round(decimal.Parse(dr["Valuation_Charge"].ToString()), MidpointRounding.AwayFromZero);
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }

                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }
                        else
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }



                        }
                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();

                        if (dr["Education_Cess"].ToString() != "0.0000")
                            lastedcess = dr["Education_Cess"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        if (rdbtn == "No")
                        {
                            remarks = "";
                        }
                        else
                        {
                            remarks = remarks;
                        }
                        decimal Comm_Amnt = 0;
                        decimal Agent_Ex = 0;

                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else
                        {
                            Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        }

                        //**************************Added On 02 Dec 2011**********************
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                        {
                            DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                            if (dtMinCheck.Rows.Count > 0)
                            {
                                if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                {
                                    discount = 0;
                                    Comm_Amnt = 0;
                                }
                            }
                        }
                        //**********************End on 02 Dec 2011***********************
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            ///////table += @"<tr class=""boldtext""> <td colspan=""6"" align=""center""><hr size=1 width=100% /> </td></tr>";
                            //table += @"<tr class=""boldtext""><td style='font-size:8px;height:5px;' >" + dr["Used_Date"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap>" + dr["Destination_Code"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""left"">" + dr["Charged_Weight"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td  style='font-size:8px;height:5px;'align=""center"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Agent_Ex + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (discount + Comm_Amnt) + @"</td><td  style='font-size:8px;height:5px;'>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                            table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>";
                            table += @"<tr class=""boldtext""><td style='font-size:8px;height:5px;' >" + dr["Used_Date"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap>" + dr["Destination_Code"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""left"">" + dr["Charged_Weight"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td  style='font-size:8px;height:5px;'align=""center"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Agent_Ex + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Comm_Amnt + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (discount) + @"</td><td  style='font-size:8px;height:5px;'>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
 
                        }
                        else
                        {
                            table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>";
                            table += @"<tr class=""boldtext""><td style='font-size:8px;height:5px;' >" + dr["Used_Date"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap>" + dr["Destination_Code"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""left"">" + dr["Charged_Weight"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td  style='font-size:8px;height:5px;'align=""center"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Agent_Ex + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Comm_Amnt + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (discount) + @"</td><td  style='font-size:8px;height:5px;'>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                        }
                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""left""><hr size=1 width=100% /></td></tr>";
                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero); table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";

                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""boldtext""><td  style='font-size:8px;height:5px;' colspan=""3"">&nbsp;</td><td  style='font-size:8px;height:5px;' align=""left"">" + TotChAmount + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotFrAmount) + @" </td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(TotFrAmountCC) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDueCar) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotAgentExp) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (TotComm) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td  style='font-size:8px;height:5px;' colspan=""3"">&nbsp;</td><td  style='font-size:8px;height:5px;' align=""left"">" + TotChAmount + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotFrAmount) + @" </td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(TotFrAmountCC) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDueCar) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotAgentExp) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (TotComm) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    }

                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>

<tr class=""boldtext"">	<td style='font-size:10px;height:5px;' colspan=""09"" align=""right"">Total Freight</td>	<td  style='font-size:8px;height:5px;' colspan=""2"" align=""right"">" + Math.Round(TotFrAmount) + @"</td></tr>";
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add Due Carrier</td><td   style='font-size:8px;height:5px;'colspan=""2"" align=""right"">" + Math.Round(TotDueCar) + @"</td></tr>";

                    #region Gst Applicable from 01Jul2017
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                        {
                            IGST = 0;
                            TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                            TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                            TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                            TotalGst = TotalCGST + TotalSGST + TotalIGST;

                            Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            /////Collect Shipment case
                            if (Total < 0)
                            {
                                TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            CGST = 0;
                            SGST = 0;
                            TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                            TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                            TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                            TotalGst = TotalCGST + TotalSGST + TotalIGST;

                            Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            /////Collect Shipment case
                            if (Total < 0)
                            {
                                TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            }
                        }

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round((TotDiscount)) + @"</strong></td></tr>";
                        ////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        if (TotFrAmount == 0 && TotFrAmountCC > 0)
                        {
                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount))) + @"</strong></td></tr>";
                        }

                        else
                        {
                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount))) + @"</strong></td></tr>";
                        }
                        ///////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>CGST @" + CGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalCGST + @"</strong></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>SGST @" + SGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalSGST + @"</strong></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>IGST @" + IGST + @"% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalIGST + @"</strong></td></tr>";
                        //////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total GST@18% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalGst + @"</strong></td></tr>";
                        /////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        ////table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                        //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                        ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                        //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                        ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    }
                    #endregion End of Gst Applicable

                    ///////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right"">Total (Inc Gst)</td><th colspan=""2"" align=""right"">" + Math.Round(Total) + @"</th></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right"">Total</td><th colspan=""2"" align=""right"">" + Math.Round(Total) + @"</th></tr>";
                    }
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;'  colspan=""9"" align=""right"">Add Agent TDS on IATA@" + lastTsdsRate + @"% </td><td colspan=""2"" align=""right"">" + Math.Ceiling(TotTds) + @"</td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;'   colspan=""9"" align=""right"">Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </td><td colspan=""2"" align=""right"">" + Math.Round(surCharge) + @"</td></tr>";


                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");

                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add SurCharge For the Period  (" + FinancialYear + @") </td><td colspan=""2"" align=""right"">" + Debit_Surcharge + @"</td></tr>";

                    }
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add EDUCATIONAL CESS</td><td colspan=""2"" align=""right"">" + Math.Round(EduChrg) + @"</td></tr>";

                    table += @"<tr> <td  colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge));
                    }

                    //<img src=""images/rs.gif""> &nbsp;
                    table += @"<tr class=""boldtext""><th colspan=""9"" align=""right"">" + massage + @" " + " " + agentName + @" </td><th colspan=""2"" align=""right"">" + font + GrandTotal + @"</font></td></tr>";
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCppPoints,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM dbo.CPP_Details WHERE CityID='" + city_id + "' and AgentID='" + agnetID + "' AND ExpiryDate>GETDATE() group by AgentID ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("P.A.N."))
                        {
                            int i = csrFooter.IndexOf("Please&nbsp;intimate");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    //csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                        }
                        if (csrFtr != "")
                        {
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }
                        else
                        {
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }

                    }
                    else
                    {

                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("Service&nbsp;Tax"))
                        {
                            int i = csrFooter.IndexOf("Service&nbsp;Tax");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                            //csrFtr = csrFtr.Replace(",.", ".");
                        }
                        if (airline_name_city_value == "147" || airline_name_city_value == "148" || airline_name_city_value == "158" || airline_name_city_value == "159" || airline_name_city_value == "160" || airline_name_city_value == "163" || airline_name_city_value == "157" || airline_name_city_value == "161" || airline_name_city_value == "165" || airline_name_city_value == "151" || airline_name_city_value == "166" || airline_name_city_value == "167")
                        {
                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Acumen Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.  Please deduct the TDS @1.50% U/S 194C as per exemption certificate no. 197/AADCA8499B/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 30/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ACUMEN OVERSEAS PVT LTD</b>"", Pan No. AADCA8499B, Tan No. DELA06791B, Service Tax No. AADCA8499BST004</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion

                        }
                        else
                        {

                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Ascent Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.Please deduct the TDS @1% U/S 194C as per exemption certificate no. 197/AACCA7284R/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 29/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with ascent air pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ASCENT AIR PVT LTD</b>""</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion
                        }
                    }

                    if (p < 7)
                    {


                    }

                    if ((from_date == "07/1/2008" && to_date == "07/15/2008") || (from_date == "07/16/2008" && to_date == "07/31/2008"))
                    {
                        table_note = @"<table><tr class=""boldtext"" align=""left""><th>Please Note :- We will not be sending CSR from next time onwards through courier.You can check the same in your account at <a class=""link"" href=""http://groupconcorde.com"" target=""blank"">http://www.groupconcorde.com</a>. For Queries/Login details please contact our sales team.</th></tr></table><br style=""page-break-before:always;"">";
                    }
                    else
                    {
                        table_note = @"<br style=""page-break-before:always;"">";
                    }
                    //***************Added on  12 Nov 2010
                    //**************************Added on 08 Dec 2016: Systems Generated Invoice:***************
                    if (approveCsr == "approve")
                    {
                        if ((airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165") || (airline_name_city_value == "163") || (airline_name_city_value == "166") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160"))
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Acumen.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        else if (airline_name_city_value == "149" || airline_name_city_value == "164")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Ascent.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                        else if (airline_name_city_value == "152" || airline_name_city_value == "162")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }

                    }
                    else
                    {
                        if ((airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165") || (airline_name_city_value == "163") || (airline_name_city_value == "166") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160"))
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Acumen.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        else if (airline_name_city_value == "149" || airline_name_city_value == "164")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Ascent.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                        else if (airline_name_city_value == "152" || airline_name_city_value == "162")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                    }
                    //***************************End of added on 08 Dec 2016**************************************************


                    //==========================================**************Msg Added on  26 april 2012 **********************======================//
                    if (airline_name_city_text[0].ToString() != "FEDEX AIR CARGO")
                    {
                        if ((airline_name_city_value == "148") || (airline_name_city_value == "147") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160") || (airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165"))
                        {
                        }
                        else
                        { }
                    }
                    else
                    {

                        if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                        {
                            if (airline_name_city_value == "152")
                            {
                            }

                        }
                        else
                        {
                            tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 07px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::We have received TDS Exemption Certificate @0.50% for FY 2012-13 w.e.f from 10th May'12 and please collect the same.:::::</marquee></td></tr></table>";

                        }
                    }
                    //=====================================================end =========================
                    //*************Added On 26 Apr 2011***************Msg To Agent*********
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                    }
                    else
                    {
                        ////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 05px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment:::::</marquee></td></tr></table>";
                    }
                    DataTable dtAirlineDetail_IdAccumen = dw.GetAllFromQuery("select * from Airline_detail where company_id=106");
                    string AirLineDetailId_Accumen = "";
                    if (dtAirlineDetail_IdAccumen.Rows.Count > 0)
                    {
                        for (int j = 0; j < dtAirlineDetail_IdAccumen.Rows.Count; j++)
                        {
                            AirLineDetailId_Accumen += dtAirlineDetail_IdAccumen.Rows[j]["airline_detail_id"].ToString() + ",";
                        }
                        AirLineDetailId_Accumen = AirLineDetailId_Accumen.TrimEnd(',');
                        if (AirLineDetailId_Accumen.Contains(airline_name_city_value))
                        {
                            //     tableTdsExemptedMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><font size=1px><b>We have received TDS Exemption Certificate from IT Dept for the FY 2011-12 @ 1%. Please deduct the TDS accordingly.</b></font></td></tr></table>";
                        }
                    }
                }
                //*****************************Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                string footerLine = "<table align=center width=70%><tr><td colspan=2><b><font size=2px>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                //*****************************End of Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                if (table != null)
                    tableAll = tableAll + (table + table_image) + tableTdsMsg + tableTdsExemptedMsg + tableCSr + table_note;
                //************End******************************************************   

                Label2.Text = tableAll;
                tableCSr = "";
                tableTdsMsg = "";
                tableTdsExemptedMsg = "";
                //}

            }

            string mass = @"<p><font color=""red"" size=""3"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label2.Text = mass;

        }
        else if (approveCsr == "notApprove")
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                decimal CGST = 9;
                decimal SGST = 9;
                decimal IGST = 18;

                decimal TotalCGST = 9;
                decimal TotalSGST = 9;
                decimal TotalIGST = 18;
                decimal TotalGst = 0;

                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotValuationCharges = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;
                string lastSurcharge = "0.0000", lastTsdsRate = "0.0000", lastedcess = "0.00";

                string table = null, table_image = null, table_note = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";

                }
                else
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();

                    DataTable dtcity = dw.GetAllFromQuery("Select City_name from City_Master where City_id=" + city_id + "");
                    if (dtcity.Rows.Count > 0 && dtcity != null)
                    {
                        if (dtcity.Rows[0]["City_name"] != "")
                        {
                            CityAsStateCode = dtcity.Rows[0]["City_name"].ToString();
                        }
                    }


                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (airline_name_city_value.Trim() == "152")
                        {
                            if (h.Contains("11005"))
                            {
                                string[] h1 = h.Split('5');
                                h = h1[0].ToString() + "5";
                            }
                        }
                        comName = dr["company_name"].ToString();
                        #region Gst CompanyGstNo
                        DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + airline_name_city_value + "");
                        if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
                        {
                            CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                        }
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr ><td  width=""75%"" align=""center""></td><td   align=""left""><font size=""2""><b>Invoice Date: " + created_date + "</b></font></td></tr></table><br>";
                            /////table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font><br><font size=""1"">GST NO:" + CompGstNo + "</font></p></td></tr></table><br>";
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src='http://pace1.cargoflash.com/ak-in/images/gclogo_new.gif'</td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font><br><font size=""1"">GST NO:" + CompGstNo + "</font></p></td></tr></table><br>";
                        }
                        else
                        {
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";
                        }
                        #endregion end of Gst CompanyGstNo
                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        s = s.Replace("\r\n", "");
                        s = s.Replace(",", ", ");
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (AID == "160")
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>CIN NO.U74899DL1993PTC052734</td></tr></table>";
                        }
                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************
                        /////table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:10px;"">" + agentName + @"</b><br>" + h + @"<br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</br><b><br><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        #region Gst No for Agent

                        string Invoice_No = "";


                        DataTable dtInvoiceNo = dw.GetAllFromQuery("select  max(GstInvNo) as GstInvNo,max(invoice_no) as invoice_no,MAX(Invoice_SNO) AS invoicesno,max(csr_sno)as csr_sno,max(GstAddress) as GstAddress from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                        if (dtInvoiceNo.Rows.Count > 0)
                        {
                            #region Using Csr_Sno from Sales table i/o InvoiceNo from Invoice Table
                            ////////Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                            /////DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix +'/'+Fin_Year)as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoicesno"].ToString() + " ");


                            if (dtInvoiceNo.Rows[0]["GstAddress"].ToString() != "")
                            {
                                s = dtInvoiceNo.Rows[0]["GstAddress"].ToString();
                                s = s.Replace("\r\n", "");
                                s = s.Replace(",", ", ");
                                ch = (char)System.Windows.Forms.Keys.Return;
                                ch2 = (char)System.Windows.Forms.Keys.Space;
                                ch1 = Convert.ToString(ch);
                                ch3 = Convert.ToString(ch2);
                                h = s.Replace(ch1, "<br>");
                                h = h.Replace(ch3, "&nbsp;");
                            }




                            string Flight_date = to_date;
                            string[] dateSplit = Flight_date.Split('/');
                            string Month = dateSplit[1].ToString();
                            string Year = dateSplit[2].ToString();
                            string Date1 = dateSplit[0].ToString();
                            ////string currentdate = Month + "/" + Date1 + "/" + Year;
                            string currentdate = Date1 + "/" + Month + "/" + Year;
                            string FinYear = Year.Substring(2, 2);
                            //// string dateCurrent = DateTime.Now.ToShortDateString();

                            /////DateTime CurrDate = DateTime.Now;
                            DateTime CurrDate = DateTime.Parse(currentdate);
                            string DateFinancial = "4/1/20" + FinYear + "";
                            DateTime FinanciaDate = DateTime.Parse(DateFinancial);


                            if (CurrDate < FinanciaDate)
                            {
                                FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            }
                            else
                            {
                                FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            }
                            ////if (CurrDate < FinanciaDate)
                            ////{
                            ////    FinYear = Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            ////}
                            ////else
                            ////{
                            ////    FinYear = FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            ////}
                            //*********************End***************************************************************

                            DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix + substring(Fin_Year,3,5))as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND Fin_Year='" + FinYear + "'");

                            if (dtInvoice.Rows.Count > 0)
                            {
                                ///////Updated on 30 May 2017
                                ////Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();

                                if (DateTime.Parse(to_date) < DateTime.Parse("08/01/2017"))
                                {
                                    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["CSr_Sno"].ToString();
                                }
                                else
                                {
                                    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["GstInvNo"].ToString();
                                }
                            }

                            ////////End of Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                            #endregion

                            #region Picking Invoice_No from Invoice table i/o Csr_Sno from sales table
                            //DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix +'/'+Fin_Year)as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoicesno"].ToString() + " ");
                            //if (dtInvoice.Rows.Count > 0)
                            //{
                            //    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();
                            //}
                            #endregion
                        }

                        //******************end**************************************//
                        //table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table><br>";
                        ////table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h3>INVOICE No: &nbsp;&nbsp;&nbsp;" + Invoice_No + @"</h3></b></td></tr></table><br>";
                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        DataTable dtAgentGstNo = dw.GetAllFromQuery("select top 1 (case when gstno is null then Statecode else gstno end) as GstNo from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                        if (dtAgentGstNo != null && dtAgentGstNo.Rows.Count > 0)
                        {
                            if (dtAgentGstNo.Rows[0]["GstNo"].ToString() != "")
                                AgentGstNo = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                        }

                        #region Palce of Delivery and State code
                        string stateCode = CityAsStateCode;
                        DataTable CityCode = dw.GetAllFromQuery("select city_name from city_master where city_id=" + city_id + "");
                        stateCode = CityCode.Rows[0]["city_name"].ToString();
                        DataTable gststateCode = dw.GetAllFromQuery("select state from GstStateCode where stateCode='" + AgentGstNo.Substring(0, 2) + "'");
                        if (gststateCode != null && gststateCode.Rows.Count > 0)
                        {
                            if (gststateCode.Rows[0]["state"].ToString() != "")
                                stateCode = gststateCode.Rows[0]["state"].ToString();
                        }

                        #endregion end of Palce of Delivery and State code


                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<br><b>IATA Code:</b>;&nbsp;" + dr["IATA_Code"].ToString() + @"<br><b>INVOICE No:</b>&nbsp;" + Invoice_No + @"<br><b>GST NO:</b>&nbsp;" + AgentGstNo + "<br/><b>State Code:" + stateCode + "<b><br/><b>Place Of Supply: " + stateCode + "<b><br/><b>HSN Code:&nbsp;996531</b><br><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        }
                        else
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code: &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b><br/><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        }
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        #endregion End of Gst No for Agent
                    }
                    com.Dispose();
                    dr.Dispose();
                    //=========================================Add By :Pradeep Sharma For Tabel Heading=====================================
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<table  border=0 align=center style='word-spacing:inherit width=100%;' ><tr ><td  width=100% align=center><font size=2><b><u>TAX INVOICE</u></b></font></td></tr></table><br>";
                        table += @"<table width=95%  ><tr ><td style='font-size:8px;height:5px;' >Date</td><td style='font-size:8px;height:5px;'>AWB No.</td>";
                        table += @"<td style='font-size:8px;height:5px;'  >Dest</td><td style='font-size:8px;height:5px;'  >Chrg. Wt</td><td style='font-size:8px;height:5px;'  colspan=2 
align=center>Freight</td><td style='font-size:8px;height:5px;'  align=center 
>Due Carrier</td>
<td style='font-size:8px;height:5px;'  align=left >Agent Expenses</td> 
<td  style='font-size:8px;height:5px;'  align=center >Comm.</td> 
<td  style='font-size:8px;height:5px;'  align=center >Discount</td> 
<td  style='font-size:8px;height:5px;'  align=center >Remark</td></tr>
<tr  style='height:5px;'>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >PP</td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >CC</td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
</tr>";
                    }
                    else
                    {

                        table += @"<table width=95%  ><tr ><td style='font-size:8px;height:5px;' >Date</td><td style='font-size:8px;height:5px;'>AWB No.</td>";
                        table += @"<td style='font-size:8px;height:5px;'  >Dest</td><td style='font-size:8px;height:5px;'  >Chrg. Wt</td><td style='font-size:8px;height:5px;'  colspan=2 
align=center>Freight</td><td style='font-size:8px;height:5px;'  align=center 
>Due Carrier</td>
<td style='font-size:8px;height:5px;'  align=left >Agent Expenses</td> 
<td  style='font-size:8px;height:5px;'  align=center >Comm.</td> 
<td  style='font-size:8px;height:5px;'  align=center >Discount</td> 
<td  style='font-size:8px;height:5px;'  align=center >Remark</td></tr>
<tr  style='height:5px;'>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >PP</td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >CC</td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
</tr>";
                        table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>";
                    }
                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (from_date == "04/1/2008" && to_date == "04/15/2008")
                        {

                            com = new SqlCommand("CSRsort_Temp", con);
                        }
                        else
                        {
                            com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                        }

                    }
                    if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                        com = new SqlCommand("csrsort_Temp", con);
                    else
                        com = new SqlCommand("csrsort_Temp_KEIATA", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    string VarDate = "07/31/2008";
                    string MH_Period = "08/15/2008";
                    int p = 0;

                    while (dr.Read())
                    {
                        p++;
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString() == "235-70456945")
                        {
                        }
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;

                            }
                            else
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                //****************Added On 02 dec 2011***************
                                if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                                {
                                    DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                    if (dtMinCheck.Rows.Count > 0)
                                    {
                                        if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                        {
                                            TotDiscount += 0;
                                            TotComm += 0;
                                        }

                                        else
                                        {
                                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                            TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                }
                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                //**********************End Of 02 Dec*****************************                              
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            //****************Added On 02 dec 2011***************
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                            {
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }
                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }

                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            }

                            //**********************End Of 02 Dec*****************************                          
                            TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotValuationCharges += Math.Round(decimal.Parse(dr["Valuation_Charge"].ToString()), MidpointRounding.AwayFromZero);
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }

                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }
                        else
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }



                        }
                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();

                        if (dr["Education_Cess"].ToString() != "0.0000")
                            lastedcess = dr["Education_Cess"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        if (rdbtn == "No")
                        {
                            remarks = "";
                        }
                        else
                        {
                            remarks = remarks;
                        }
                        decimal Comm_Amnt = 0;
                        decimal Agent_Ex = 0;

                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else
                        {
                            Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        }

                        //**************************Added On 02 Dec 2011**********************
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                        {
                            DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                            if (dtMinCheck.Rows.Count > 0)
                            {
                                if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                {
                                    discount = 0;
                                    Comm_Amnt = 0;
                                }
                            }
                        }
                        //**********************End on 02 Dec 2011***********************
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<tr class=""boldtext""><td style='font-size:8px;height:5px;' >" + dr["Used_Date"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap>" + dr["Destination_Code"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""left"">" + dr["Charged_Weight"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td  style='font-size:8px;height:5px;'align=""center"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Agent_Ex + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (discount + Comm_Amnt) + @"</td><td  style='font-size:8px;height:5px;'>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                        }
                        else
                        {
                            table += @"<tr class=""boldtext""><td style='font-size:8px;height:5px;' >" + dr["Used_Date"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap>" + dr["Destination_Code"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""left"">" + dr["Charged_Weight"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td  style='font-size:8px;height:5px;'align=""center"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Agent_Ex + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Comm_Amnt + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (discount) + @"</td><td  style='font-size:8px;height:5px;'>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                        }
                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""left""><hr size=1 width=100% /></td></tr>";
                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero); table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";

                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""boldtext""><td  style='font-size:8px;height:5px;' colspan=""3"">&nbsp;</td><td  style='font-size:8px;height:5px;' align=""left"">" + TotChAmount + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotFrAmount) + @" </td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(TotFrAmountCC) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDueCar) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotAgentExp) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round((TotDiscount + TotComm), MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td  style='font-size:8px;height:5px;' colspan=""3"">&nbsp;</td><td  style='font-size:8px;height:5px;' align=""left"">" + TotChAmount + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotFrAmount) + @" </td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(TotFrAmountCC) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDueCar) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotAgentExp) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (TotComm) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    }

                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>

<tr class=""boldtext"">	<td style='font-size:10px;height:5px;' colspan=""09"" align=""right"">Total Freight</td>	<td  style='font-size:8px;height:5px;' colspan=""2"" align=""right"">" + Math.Round(TotFrAmount) + @"</td></tr>";
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add Due Carrier</td><td   style='font-size:8px;height:5px;'colspan=""2"" align=""right"">" + Math.Round(TotDueCar) + @"</td></tr>";

                    #region Gst Applicable from 01Jul2017
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                        {
                            IGST = 0;
                            TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                            TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                            TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                            TotalGst = TotalCGST + TotalSGST + TotalIGST;

                            Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            /////Collect Shipment case
                            if (Total < 0)
                            {
                                TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            CGST = 0;
                            SGST = 0;
                            TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                            TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                            TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                            TotalGst = TotalCGST + TotalSGST + TotalIGST;

                            Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            /////Collect Shipment case
                            if (Total < 0)
                            {
                                TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            }
                        }

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round((TotDiscount)) + @"</strong></td></tr>";
                        ////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        if (TotFrAmount == 0 && TotFrAmountCC > 0)
                        {
                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount))) + @"</strong></td></tr>";
                        }

                        else
                        {
                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount))) + @"</strong></td></tr>";
                        }
                        ///////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>CGST @" + CGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalCGST + @"</strong></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>SGST @" + SGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalSGST + @"</strong></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>IGST @" + IGST + @"% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalIGST + @"</strong></td></tr>";
                        //////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total GST@18% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalGst + @"</strong></td></tr>";
                        /////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        ////table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                        //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                        ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                        //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                        ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    }
                    #endregion End of Gst Applicable

                    ///////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right"">Total (Inc Gst)</td><th colspan=""2"" align=""right"">" + Math.Round(Total) + @"</th></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right"">Total</td><th colspan=""2"" align=""right"">" + Math.Round(Total) + @"</th></tr>";
                    }
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;'  colspan=""9"" align=""right"">Add Agent TDS on IATA@" + lastTsdsRate + @"% </td><td colspan=""2"" align=""right"">" + Math.Ceiling(TotTds) + @"</td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;'   colspan=""9"" align=""right"">Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </td><td colspan=""2"" align=""right"">" + Math.Round(surCharge) + @"</td></tr>";


                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");

                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add SurCharge For the Period  (" + FinancialYear + @") </td><td colspan=""2"" align=""right"">" + Debit_Surcharge + @"</td></tr>";

                    }
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add EDUCATIONAL CESS</td><td colspan=""2"" align=""right"">" + Math.Round(EduChrg) + @"</td></tr>";

                    table += @"<tr> <td  colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge));
                    }

                    //<img src=""images/rs.gif""> &nbsp;
                    table += @"<tr class=""boldtext""><th colspan=""9"" align=""right"">" + massage + @" " + " " + agentName + @" </td><th colspan=""2"" align=""right"">" + font + GrandTotal + @"</font></td></tr>";
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCppPoints,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM dbo.CPP_Details WHERE CityID='" + city_id + "' and AgentID='" + agnetID + "' AND ExpiryDate>GETDATE() group by AgentID ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("P.A.N."))
                        {
                            int i = csrFooter.IndexOf("Please&nbsp;intimate");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    //csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                        }
                        if (csrFtr != "")
                        {
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }
                        else
                        {
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }

                    }
                    else
                    {

                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("Service&nbsp;Tax"))
                        {
                            int i = csrFooter.IndexOf("Service&nbsp;Tax");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                            //csrFtr = csrFtr.Replace(",.", ".");
                        }
                        if (airline_name_city_value == "147" || airline_name_city_value == "148" || airline_name_city_value == "158" || airline_name_city_value == "159" || airline_name_city_value == "160" || airline_name_city_value == "163" || airline_name_city_value == "157" || airline_name_city_value == "161" || airline_name_city_value == "165" || airline_name_city_value == "151" || airline_name_city_value == "166" || airline_name_city_value == "167")
                        {
                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Acumen Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.  Please deduct the TDS @1.50% U/S 194C as per exemption certificate no. 197/AADCA8499B/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 30/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ACUMEN OVERSEAS PVT LTD</b>"", Pan No. AADCA8499B, Tan No. DELA06791B, Service Tax No. AADCA8499BST004</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion

                        }
                        else
                        {

                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Ascent Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.Please deduct the TDS @1% U/S 194C as per exemption certificate no. 197/AACCA7284R/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 29/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with ascent air pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ASCENT AIR PVT LTD</b>""</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion
                        }
                    }

                    if (p < 7)
                    {


                    }

                    if ((from_date == "07/1/2008" && to_date == "07/15/2008") || (from_date == "07/16/2008" && to_date == "07/31/2008"))
                    {
                        table_note = @"<table><tr class=""boldtext"" align=""left""><th>Please Note :- We will not be sending CSR from next time onwards through courier.You can check the same in your account at <a class=""link"" href=""http://groupconcorde.com"" target=""blank"">http://www.groupconcorde.com</a>. For Queries/Login details please contact our sales team.</th></tr></table><br style=""page-break-before:always;"">";
                    }
                    else
                    {
                        table_note = @"<br style=""page-break-before:always;"">";
                    }
                    //***************Added on  12 Nov 2010
                    //**************************Added on 08 Dec 2016: Systems Generated Invoice:***************
                    if (approveCsr == "approve")
                    {
                        if ((airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165") || (airline_name_city_value == "163") || (airline_name_city_value == "166") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160"))
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Acumen.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        else if (airline_name_city_value == "149" || airline_name_city_value == "164")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Ascent.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                        else if (airline_name_city_value == "152" || airline_name_city_value == "162")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }

                    }
                    else
                    {
                        if ((airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165") || (airline_name_city_value == "163") || (airline_name_city_value == "166") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160"))
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Acumen.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        else if (airline_name_city_value == "149" || airline_name_city_value == "164")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Ascent.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                        else if (airline_name_city_value == "152" || airline_name_city_value == "162")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                    }
                    //***************************End of added on 08 Dec 2016**************************************************


                    //==========================================**************Msg Added on  26 april 2012 **********************======================//
                    if (airline_name_city_text[0].ToString() != "FEDEX AIR CARGO")
                    {
                        if ((airline_name_city_value == "148") || (airline_name_city_value == "147") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160") || (airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165"))
                        {
                        }
                        else
                        { }
                    }
                    else
                    {

                        if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                        {
                            if (airline_name_city_value == "152")
                            {
                            }

                        }
                        else
                        {
                            tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 07px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::We have received TDS Exemption Certificate @0.50% for FY 2012-13 w.e.f from 10th May'12 and please collect the same.:::::</marquee></td></tr></table>";

                        }
                    }
                    //=====================================================end =========================
                    //*************Added On 26 Apr 2011***************Msg To Agent*********
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                    }
                    else
                    {
                        ////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 05px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment:::::</marquee></td></tr></table>";
                    }
                    DataTable dtAirlineDetail_IdAccumen = dw.GetAllFromQuery("select * from Airline_detail where company_id=106");
                    string AirLineDetailId_Accumen = "";
                    if (dtAirlineDetail_IdAccumen.Rows.Count > 0)
                    {
                        for (int j = 0; j < dtAirlineDetail_IdAccumen.Rows.Count; j++)
                        {
                            AirLineDetailId_Accumen += dtAirlineDetail_IdAccumen.Rows[j]["airline_detail_id"].ToString() + ",";
                        }
                        AirLineDetailId_Accumen = AirLineDetailId_Accumen.TrimEnd(',');
                        if (AirLineDetailId_Accumen.Contains(airline_name_city_value))
                        {
                            //     tableTdsExemptedMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><font size=1px><b>We have received TDS Exemption Certificate from IT Dept for the FY 2011-12 @ 1%. Please deduct the TDS accordingly.</b></font></td></tr></table>";
                        }
                    }
                }
                //*****************************Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                string footerLine = "<table align=center width=70%><tr><td colspan=2><b><font size=2px>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                //*****************************End of Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                if (table != null)
                    tableAll = tableAll + (table + table_image) + tableTdsMsg + tableTdsExemptedMsg + tableCSr + table_note;
                //************End******************************************************   

                Label2.Text = tableAll;
                tableCSr = "";
                tableTdsMsg = "";
                tableTdsExemptedMsg = "";
                //}

            }

            string mass = @"<p><font color=""red"" size=""2"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label2.Text = mass;


        }
        else
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                decimal CGST = 9;
                decimal SGST = 9;
                decimal IGST = 18;

                decimal TotalCGST = 9;
                decimal TotalSGST = 9;
                decimal TotalIGST = 18;
                decimal TotalGst = 0;

                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotValuationCharges = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;
                string lastSurcharge = "0.0000", lastTsdsRate = "0.0000", lastedcess = "0.00";

                string table = null, table_image = null, table_note = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";

                }
                else
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();

                    DataTable dtcity = dw.GetAllFromQuery("Select City_name from City_Master where City_id=" + city_id + "");
                    if (dtcity.Rows.Count > 0 && dtcity != null)
                    {
                        if (dtcity.Rows[0]["City_name"] != "")
                        {
                            CityAsStateCode = dtcity.Rows[0]["City_name"].ToString();
                        }
                    }


                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (airline_name_city_value.Trim() == "152")
                        {
                            if (h.Contains("11005"))
                            {
                                string[] h1 = h.Split('5');
                                h = h1[0].ToString() + "5";
                            }
                        }
                        comName = dr["company_name"].ToString();
                        #region Gst CompanyGstNo
                        DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + airline_name_city_value + "");
                        if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
                        {
                            CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                        }
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr ><td  width=""75%"" align=""center""></td><td   align=""left""><font size=""2""><b>Invoice Date: " + created_date + "</b></font></td></tr></table><br>";
                            /////table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font><br><font size=""1"">GST NO:" + CompGstNo + "</font></p></td></tr></table><br>";
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src='http://pace1.cargoflash.com/ak-in/images/gclogo_new.gif'</td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font><br><font size=""1"">GST NO:" + CompGstNo + "</font></p></td></tr></table><br>";
                        }
                        else
                        {
                            table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";
                        }
                        #endregion end of Gst CompanyGstNo
                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        s = s.Replace("\r\n", "");
                        s = s.Replace(",", ", ");
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (AID == "160")
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>CIN NO.U74899DL1993PTC052734</td></tr></table>";
                        }
                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************
                        /////table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:10px;"">" + agentName + @"</b><br>" + h + @"<br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</br><b><br><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        #region Gst No for Agent

                        string Invoice_No = "";


                        DataTable dtInvoiceNo = dw.GetAllFromQuery("select max(GstInvNo) as GstInvNo,max(invoice_no) as invoice_no,MAX(Invoice_SNO) AS invoicesno,max(csr_sno)as csr_sno,max(GstAddress) as GstAddress from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                        if (dtInvoiceNo.Rows.Count > 0)
                        {
                            #region Using Csr_Sno from Sales table i/o InvoiceNo from Invoice Table
                            ////////Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                            /////DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix +'/'+Fin_Year)as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoicesno"].ToString() + " ");


                            if (dtInvoiceNo.Rows[0]["GstAddress"].ToString() != "")
                            {
                                s = dtInvoiceNo.Rows[0]["GstAddress"].ToString();
                                s = s.Replace("\r\n", "");
                                s = s.Replace(",", ", ");
                                ch = (char)System.Windows.Forms.Keys.Return;
                                ch2 = (char)System.Windows.Forms.Keys.Space;
                                ch1 = Convert.ToString(ch);
                                ch3 = Convert.ToString(ch2);
                                h = s.Replace(ch1, "<br>");
                                h = h.Replace(ch3, "&nbsp;");
                            }




                            string Flight_date = to_date;
                            string[] dateSplit = Flight_date.Split('/');
                            string Month = dateSplit[1].ToString();
                            string Year = dateSplit[2].ToString();
                            string Date1 = dateSplit[0].ToString();
                            ////string currentdate = Month + "/" + Date1 + "/" + Year;
                            string currentdate = Date1 + "/" + Month + "/" + Year;
                            string FinYear = Year.Substring(2, 2);
                            //// string dateCurrent = DateTime.Now.ToShortDateString();

                            /////DateTime CurrDate = DateTime.Now;
                            DateTime CurrDate = DateTime.Parse(currentdate);
                            string DateFinancial = "4/1/20" + FinYear + "";
                            DateTime FinanciaDate = DateTime.Parse(DateFinancial);


                            if (CurrDate < FinanciaDate)
                            {
                                FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            }
                            else
                            {
                                FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            }

                            ////if (CurrDate < FinanciaDate)
                            ////{
                            ////    FinYear = Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            ////}
                            ////else
                            ////{
                            ////    FinYear = FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            ////}
                            //*********************End***************************************************************

                            DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix + substring(Fin_Year,3,5))as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND Fin_Year='" + FinYear + "'");

                            if (dtInvoice.Rows.Count > 0)
                            {
                                ///////Updated on 30 May 2017
                                ////Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();

                                if (DateTime.Parse(to_date) < DateTime.Parse("08/01/2017"))
                                {
                                    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["CSr_Sno"].ToString();
                                }
                                else
                                {
                                    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["GstInvNo"].ToString();
                                }
                            }

                            ////////End of Updated on 30 May 2017 : Invoice No is Csr_Sno from sales table i/o Invoice_Sno table
                            #endregion

                            #region Picking Invoice_No from Invoice table i/o Csr_Sno from sales table
                            //DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix +'/'+Fin_Year)as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + airline_name_city_value + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoicesno"].ToString() + " ");
                            //if (dtInvoice.Rows.Count > 0)
                            //{
                            //    Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();
                            //}
                            #endregion
                        }

                        //******************end**************************************//
                        //table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table><br>";
                        ////table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h3>INVOICE No: &nbsp;&nbsp;&nbsp;" + Invoice_No + @"</h3></b></td></tr></table><br>";
                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        DataTable dtAgentGstNo = dw.GetAllFromQuery("select top 1 (case when gstno is null then Statecode else gstno end) as GstNo from sales where csr_date between '" + from_date + "' and '" + to_date + "' and agent_id=" + agnetID + " and airline_detail_Id=" + airline_name_city_value + "");
                        if (dtAgentGstNo != null && dtAgentGstNo.Rows.Count > 0)
                        {
                            if (dtAgentGstNo.Rows[0]["GstNo"].ToString() != "")
                                AgentGstNo = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                        }

                        #region Palce of Delivery and State code
                        string stateCode = CityAsStateCode;
                        DataTable CityCode = dw.GetAllFromQuery("select city_name from city_master where city_id=" + city_id + "");
                        stateCode = CityCode.Rows[0]["city_name"].ToString();
                        DataTable gststateCode = dw.GetAllFromQuery("select state from GstStateCode where stateCode='" + AgentGstNo.Substring(0, 2) + "'");
                        if (gststateCode != null && gststateCode.Rows.Count > 0)
                        {
                            if (gststateCode.Rows[0]["state"].ToString() != "")
                                stateCode = gststateCode.Rows[0]["state"].ToString();
                        }

                        #endregion end of Palce of Delivery and State code


                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<br><b>IATA Code:</b>;&nbsp;" + dr["IATA_Code"].ToString() + @"<br><b>INVOICE No:</b>&nbsp;" + Invoice_No + @"<br><b>GST NO:</b>&nbsp;" + AgentGstNo + "<br/><b>State Code:" + stateCode + "<b><br/><b>Place Of Supply: " + stateCode + "<b><br/><b>HSN Code:&nbsp;996531</b><br><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        }
                        else
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code: &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b><br/><b><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        }
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************

                        #endregion End of Gst No for Agent
                    }
                    com.Dispose();
                    dr.Dispose();
                    //=========================================Add By :Pradeep Sharma For Tabel Heading=====================================
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<table  border=0 align=center style='word-spacing:inherit width=100%;' ><tr ><td  width=100% align=center><font size=2><b><u>TAX INVOICE</u></b></font></td></tr></table><br>";
                        table += @"<table width=95%  ><tr ><td style='font-size:8px;height:5px;' >Date</td><td style='font-size:8px;height:5px;'>AWB No.</td>";
                        table += @"<td style='font-size:8px;height:5px;'  >Dest</td><td style='font-size:8px;height:5px;'  >Chrg. Wt</td><td style='font-size:8px;height:5px;'  colspan=2 
align=center>Freight</td><td style='font-size:8px;height:5px;'  align=center 
>Due Carrier</td>
<td style='font-size:8px;height:5px;'  align=left >Agent Expenses</td> 
<td  style='font-size:8px;height:5px;'  align=center >Comm.</td> 
<td  style='font-size:8px;height:5px;'  align=center >Discount</td> 
<td  style='font-size:8px;height:5px;'  align=center >Remark</td></tr>
<tr  style='height:5px;'>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >PP</td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >CC</td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
</tr>";
                    }
                    else
                    {

                        table += @"<table width=95%  ><tr ><td style='font-size:8px;height:5px;' >Date</td><td style='font-size:8px;height:5px;'>AWB No.</td>";
                        table += @"<td style='font-size:8px;height:5px;'  >Dest</td><td style='font-size:8px;height:5px;'  >Chrg. Wt</td><td style='font-size:8px;height:5px;'  colspan=2 
align=center>Freight</td><td style='font-size:8px;height:5px;'  align=center 
>Due Carrier</td>
<td style='font-size:8px;height:5px;'  align=left >Agent Expenses</td> 
<td  style='font-size:8px;height:5px;'  align=center >Comm.</td> 
<td  style='font-size:8px;height:5px;'  align=center >Discount</td> 
<td  style='font-size:8px;height:5px;'  align=center >Remark</td></tr>
<tr  style='height:5px;'>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >PP</td>
<td   align=center style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;;height:5px;' align=""center"" >CC</td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
<td style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:8px; color:#000000;' ></td>
</tr>";
                        table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>";
                    }
                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (from_date == "04/1/2008" && to_date == "04/15/2008")
                        {

                            com = new SqlCommand("CSRsort_Temp", con);
                        }
                        else
                        {
                            com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                        }

                    }
                    if (DateTime.Parse(to_date) <= DateTime.Parse("07/15/2017"))
                        com = new SqlCommand("csrsort_Temp", con);
                    else
                        com = new SqlCommand("csrsort_Temp_KEIATA", con);

                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    string VarDate = "07/31/2008";
                    string MH_Period = "08/15/2008";
                    int p = 0;

                    while (dr.Read())
                    {
                        p++;
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString() == "235-70456945")
                        {
                        }
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;

                            }
                            else
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                //****************Added On 02 dec 2011***************
                                if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                                {
                                    DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                    if (dtMinCheck.Rows.Count > 0)
                                    {
                                        if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                        {
                                            TotDiscount += 0;
                                            TotComm += 0;
                                        }

                                        else
                                        {
                                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                            TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                }
                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                //**********************End Of 02 Dec*****************************                              
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            //****************Added On 02 dec 2011***************
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                            {
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }
                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }

                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            }

                            //**********************End Of 02 Dec*****************************                          
                            TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotValuationCharges += Math.Round(decimal.Parse(dr["Valuation_Charge"].ToString()), MidpointRounding.AwayFromZero);
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }

                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }
                        else
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }



                        }
                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();

                        if (dr["Education_Cess"].ToString() != "0.0000")
                            lastedcess = dr["Education_Cess"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        if (rdbtn == "No")
                        {
                            remarks = "";
                        }
                        else
                        {
                            remarks = remarks;
                        }
                        decimal Comm_Amnt = 0;
                        decimal Agent_Ex = 0;

                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else
                        {
                            Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        }

                        //**************************Added On 02 Dec 2011**********************
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                        {
                            DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                            if (dtMinCheck.Rows.Count > 0)
                            {
                                if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                {
                                    discount = 0;
                                    Comm_Amnt = 0;
                                }
                            }
                        }
                        //**********************End on 02 Dec 2011***********************
                        if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                        {
                            table += @"<tr class=""boldtext""><td style='font-size:8px;height:5px;' >" + dr["Used_Date"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap>" + dr["Destination_Code"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""left"">" + dr["Charged_Weight"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td  style='font-size:8px;height:5px;'align=""center"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Agent_Ex + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (discount + Comm_Amnt) + @"</td><td  style='font-size:8px;height:5px;'>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                        }
                        else
                        {
                            table += @"<tr class=""boldtext""><td style='font-size:8px;height:5px;' >" + dr["Used_Date"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td  style='font-size:8px;height:5px;' nowrap>" + dr["Destination_Code"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""left"">" + dr["Charged_Weight"].ToString() + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td  style='font-size:8px;height:5px;'align=""center"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Agent_Ex + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Comm_Amnt + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (discount) + @"</td><td  style='font-size:8px;height:5px;'>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                        }
                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""left""><hr size=1 width=100% /></td></tr>";
                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero); table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";

                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""boldtext""><td  style='font-size:8px;height:5px;' colspan=""3"">&nbsp;</td><td  style='font-size:8px;height:5px;' align=""left"">" + TotChAmount + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotFrAmount) + @" </td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(TotFrAmountCC) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDueCar) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotAgentExp) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round((TotDiscount + TotComm), MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td  style='font-size:8px;height:5px;' colspan=""3"">&nbsp;</td><td  style='font-size:8px;height:5px;' align=""left"">" + TotChAmount + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotFrAmount) + @" </td><td  style='font-size:8px;height:5px;' align=""center"" >" + Math.Round(TotFrAmountCC) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDueCar) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotAgentExp) + @"</td><td  style='font-size:8px;height:5px;' align=""center"">" + (TotComm) + @" </td><td  style='font-size:8px;height:5px;' align=""center"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    }

                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><hr size=1 width=100% /> </td></tr>

<tr class=""boldtext"">	<td style='font-size:10px;height:5px;' colspan=""09"" align=""right"">Total Freight</td>	<td  style='font-size:8px;height:5px;' colspan=""2"" align=""right"">" + Math.Round(TotFrAmount) + @"</td></tr>";
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add Due Carrier</td><td   style='font-size:8px;height:5px;'colspan=""2"" align=""right"">" + Math.Round(TotDueCar) + @"</td></tr>";

                    #region Gst Applicable from 01Jul2017
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                        {
                            IGST = 0;
                            TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                            TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                            TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                            TotalGst = TotalCGST + TotalSGST + TotalIGST;

                            Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            /////Collect Shipment case
                            if (Total < 0)
                            {
                                TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            CGST = 0;
                            SGST = 0;
                            TotalCGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * CGST / 100);
                            TotalSGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * SGST / 100);
                            TotalIGST = Math.Ceiling(((TotFrAmount + TotDueCar) - (TotDiscount)) * IGST / 100);
                            TotalGst = TotalCGST + TotalSGST + TotalIGST;

                            Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            /////Collect Shipment case
                            if (Total < 0)
                            {
                                TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * CGST / 100);
                                TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * SGST / 100);
                                TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + TotDueCar) - (TotDiscount)) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges + TotalGst) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                            }
                        }

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round((TotDiscount)) + @"</strong></td></tr>";
                        ////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        if (TotFrAmount == 0 && TotFrAmountCC > 0)
                        {
                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount))) + @"</strong></td></tr>";
                        }

                        else
                        {
                            table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total Amt</strong><td colspan=""2"" align=""right""><strong>" + Math.Round(((TotFrAmount + TotDueCar) - (TotDiscount))) + @"</strong></td></tr>";
                        }
                        ///////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>CGST @" + CGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalCGST + @"</strong></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>SGST @" + SGST + @"% -T4(100%)</strong></td><td colspan=""2"" align=""right""><strong>" + TotalSGST + @"</strong></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>IGST @" + IGST + @"% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalIGST + @"</strong></td></tr>";
                        //////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Total GST@18% -T4(100%)</strong><td colspan=""2"" align=""right""><strong>" + TotalGst + @"</strong></td></tr>";
                        /////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                        table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                        ////table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                        //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                        ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                        //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                        ////table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                        table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    }
                    #endregion End of Gst Applicable

                    ///////table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100%/></td></tr>";
                    if (DateTime.Parse(to_date) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right"">Total (Inc Gst)</td><th colspan=""2"" align=""right"">" + Math.Round(Total) + @"</th></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right"">Total</td><th colspan=""2"" align=""right"">" + Math.Round(Total) + @"</th></tr>";
                    }
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;'  colspan=""9"" align=""right"">Add Agent TDS on IATA@" + lastTsdsRate + @"% </td><td colspan=""2"" align=""right"">" + Math.Ceiling(TotTds) + @"</td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;'   colspan=""9"" align=""right"">Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </td><td colspan=""2"" align=""right"">" + Math.Round(surCharge) + @"</td></tr>";


                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");

                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                        table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add SurCharge For the Period  (" + FinancialYear + @") </td><td colspan=""2"" align=""right"">" + Debit_Surcharge + @"</td></tr>";

                    }
                    table += @"<tr class=""boldtext""><td style='font-size:10px;height:5px;' colspan=""9"" align=""right"">Add EDUCATIONAL CESS</td><td colspan=""2"" align=""right"">" + Math.Round(EduChrg) + @"</td></tr>";

                    table += @"<tr> <td  colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge));
                    }

                    //<img src=""images/rs.gif""> &nbsp;
                    table += @"<tr class=""boldtext""><th colspan=""9"" align=""right"">" + massage + @" " + " " + agentName + @" </td><th colspan=""2"" align=""right"">" + font + GrandTotal + @"</font></td></tr>";
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCppPoints,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM dbo.CPP_Details WHERE CityID='" + city_id + "' and AgentID='" + agnetID + "' AND ExpiryDate>GETDATE() group by AgentID ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("P.A.N."))
                        {
                            int i = csrFooter.IndexOf("Please&nbsp;intimate");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    //csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                        }
                        if (csrFtr != "")
                        {
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }
                        else
                        {
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }

                    }
                    else
                    {

                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("Service&nbsp;Tax"))
                        {
                            int i = csrFooter.IndexOf("Service&nbsp;Tax");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                            //csrFtr = csrFtr.Replace(",.", ".");
                        }
                        if (airline_name_city_value == "147" || airline_name_city_value == "148" || airline_name_city_value == "158" || airline_name_city_value == "159" || airline_name_city_value == "160" || airline_name_city_value == "163" || airline_name_city_value == "157" || airline_name_city_value == "161" || airline_name_city_value == "165" || airline_name_city_value == "151" || airline_name_city_value == "166" || airline_name_city_value == "167")
                        {
                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Acumen Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.  Please deduct the TDS @1.50% U/S 194C as per exemption certificate no. 197/AADCA8499B/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 30/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ACUMEN OVERSEAS PVT LTD</b>"", Pan No. AADCA8499B, Tan No. DELA06791B, Service Tax No. AADCA8499BST004</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion

                        }
                        else
                        {

                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Ascent Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.Please deduct the TDS @1% U/S 194C as per exemption certificate no. 197/AACCA7284R/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 29/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><hr size=1 width=100% /></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with ascent air pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ASCENT AIR PVT LTD</b>""</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion
                        }
                    }

                    if (p < 7)
                    {


                    }

                    if ((from_date == "07/1/2008" && to_date == "07/15/2008") || (from_date == "07/16/2008" && to_date == "07/31/2008"))
                    {
                        table_note = @"<table><tr class=""boldtext"" align=""left""><th>Please Note :- We will not be sending CSR from next time onwards through courier.You can check the same in your account at <a class=""link"" href=""http://groupconcorde.com"" target=""blank"">http://www.groupconcorde.com</a>. For Queries/Login details please contact our sales team.</th></tr></table><br style=""page-break-before:always;"">";
                    }
                    else
                    {
                        table_note = @"<br style=""page-break-before:always;"">";
                    }
                    //***************Added on  12 Nov 2010
                    //**************************Added on 08 Dec 2016: Systems Generated Invoice:***************
                    if (approveCsr == "approve")
                    {
                        if ((airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165") || (airline_name_city_value == "163") || (airline_name_city_value == "166") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160"))
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Acumen.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        else if (airline_name_city_value == "149" || airline_name_city_value == "164")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Ascent.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                        else if (airline_name_city_value == "152" || airline_name_city_value == "162")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }

                    }
                    else
                    {
                        if ((airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165") || (airline_name_city_value == "163") || (airline_name_city_value == "166") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160"))
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Acumen.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        else if (airline_name_city_value == "149" || airline_name_city_value == "164")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/Ascent.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                        else if (airline_name_city_value == "152" || airline_name_city_value == "162")
                        {
                            tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR NOT Approved.</font><Blink></td></tr></table><table width=100% border=0><tr class=heading><td width=25% align=right><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'></td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table>";
                        }
                    }
                    //***************************End of added on 08 Dec 2016**************************************************


                    //==========================================**************Msg Added on  26 april 2012 **********************======================//
                    if (airline_name_city_text[0].ToString() != "FEDEX AIR CARGO")
                    {
                        if ((airline_name_city_value == "148") || (airline_name_city_value == "147") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160") || (airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165"))
                        {
                        }
                        else
                        { }
                    }
                    else
                    {

                        if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                        {
                            if (airline_name_city_value == "152")
                            {
                            }

                        }
                        else
                        {
                            tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 07px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::We have received TDS Exemption Certificate @0.50% for FY 2012-13 w.e.f from 10th May'12 and please collect the same.:::::</marquee></td></tr></table>";

                        }
                    }
                    //=====================================================end =========================
                    //*************Added On 26 Apr 2011***************Msg To Agent*********
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                    }
                    else
                    {
                        ////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 05px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment:::::</marquee></td></tr></table>";
                    }
                    DataTable dtAirlineDetail_IdAccumen = dw.GetAllFromQuery("select * from Airline_detail where company_id=106");
                    string AirLineDetailId_Accumen = "";
                    if (dtAirlineDetail_IdAccumen.Rows.Count > 0)
                    {
                        for (int j = 0; j < dtAirlineDetail_IdAccumen.Rows.Count; j++)
                        {
                            AirLineDetailId_Accumen += dtAirlineDetail_IdAccumen.Rows[j]["airline_detail_id"].ToString() + ",";
                        }
                        AirLineDetailId_Accumen = AirLineDetailId_Accumen.TrimEnd(',');
                        if (AirLineDetailId_Accumen.Contains(airline_name_city_value))
                        {
                            //     tableTdsExemptedMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><font size=1px><b>We have received TDS Exemption Certificate from IT Dept for the FY 2011-12 @ 1%. Please deduct the TDS accordingly.</b></font></td></tr></table>";
                        }
                    }
                }
                //*****************************Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                string footerLine = "<table align=center width=70%><tr><td colspan=2><b><font size=2px>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                //*****************************End of Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                if (table != null)
                    tableAll = tableAll + (table + table_image) + tableTdsMsg + tableTdsExemptedMsg + tableCSr + table_note;
                //************End******************************************************   

                Label2.Text = tableAll;
                tableCSr = "";
                tableTdsMsg = "";
                tableTdsExemptedMsg = "";
                //}

            }
            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";
            if (tableAll == "" || tableAll == null)
                Label2.Text = mass;
        }
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=CSR.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        Label2.RenderControl(hw);
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 0f, 0f, 0f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        iTextSharp.text.Table tbl = new iTextSharp.text.Table(1, 4);
        tbl.Cellpadding = 0;
        tbl.Cellspacing = 0;
        tbl.BorderColor = Color.WHITE;
        tbl.Alignment = Element.ALIGN_LEFT;
        tbl.Width = 100f;
        pdfDoc.SetMargins(0f, 0f, 0f, 0f);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        pdfDoc.Add(tbl);
        htmlparser.Parse(sr);
        pdfDoc.Close();



    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat1(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }
    protected string checkApprove(string dt1, string dt2)
    {
        string s = null;
        con = new SqlConnection(strCon);
        con.Open();

        com = new SqlCommand("select * from Approved_CSR a inner join CSR_Duration b on a.CSR_Duration_ID=b.CSR_Duration_ID where CSR_Duration1='" + ConvertDateFormat1(dt1.Trim()) + "-" + ConvertDateFormat1(dt2.Trim()) + "' and a.airline_detail_id=" + Session["AIRDetailID"].ToString() + "", con);
        dr = com.ExecuteReader();
        if (dr.Read())
            s = "approve";
        else
            s = "notApprove";

        return s;


    }
    protected void btnPDF_Click(object sender, EventArgs e)
    {
        //Response.ContentType = "application/pdf";
        //Response.AddHeader("content-disposition", "attachment;filename=CSR.pdf");
        //Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //StringWriter sw = new StringWriter();
        //HtmlTextWriter hw = new HtmlTextWriter(sw);
        //Label2.RenderControl(hw);
        //StringReader sr = new StringReader(sw.ToString());
        //Document pdfDoc = new Document(PageSize.A4, 0f, 0f, 0f, 0f);
        //HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        //iTextSharp.text.Table tbl = new iTextSharp.text.Table(1, 4);
        //tbl.Cellpadding = 0;
        //tbl.Cellspacing = 0;
        //tbl.BorderColor = Color.WHITE;
        //tbl.Alignment = Element.ALIGN_LEFT;
        //tbl.Width = 100f;
        //pdfDoc.SetMargins(0f, 0f, 0f, 0f);
        //PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        //pdfDoc.Open();
        //pdfDoc.Add(tbl);
        //htmlparser.Parse(sr);
        //pdfDoc.Close();

    }

}
