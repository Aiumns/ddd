using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CppRedeemDetailView : System.Web.UI.Page
{
    SqlConnection con = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        else if (!IsPostBack)
        {
            Page.Form.Target = "_blank";
            GetCPP();
        }
    }
    public void GetCPP()
    {
        string Tables = "";
        string Query = "";
        Query = @"select distinct CM.CITY_ID,CM.CITY_NAME from  cpp_agentwisetotal CQ INNER JOIN CITY_MASTER CM ON CM.CITY_ID=CQ.CITYID  order by CM.CITY_ID  ";

        DataTable dt_airline = dw.GetAllFromQuery(Query);
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            for (int i = 0; i < dt_airline.Rows.Count; ++i)
            {
                string CITY_ID = dt_airline.Rows[i]["CITY_ID"].ToString();
                string CITY_NAME = dt_airline.Rows[i]["CITY_NAME"].ToString();
                decimal total_redeem_cpp = 0;
                decimal Total_CPP = 0;
                decimal TotalBalance_CPP = 0;
                //decimal total_tonnage = 0;
                //decimal avg_ton = 0;
                SqlConnection con1 = new SqlConnection(strCon);
                con1.Open();
                SqlCommand com_csr = new SqlCommand("SELECT distinct AGENT_NAME,CQ.AGENTID as AGENTID,sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP,(sum(ISNULL(TotalCPP,0))-sum(ISNULL(RedeemedCPP,0))) as balance_CPP FROM cpp_agentwisetotal CQ INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=CQ.AGENTID  WHERE Expirydate>=GETDATE() AND CITYID=" + CITY_ID + "  group by AGENT_NAME,CQ.AGENTID  ORDER BY TotalCPP DESC ", con1);

                //SqlCommand com_csr = new SqlCommand("SELECT distinct AGENT_NAME,CQ.AGENTID as AGENTID,sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP,(sum(ISNULL(TotalCPP,0))-sum(ISNULL(RedeemedCPP,0))) as balance_CPP,(SELECT top 1 sum(ISNULL(TotalCPP,0)) AS TotalCPP FROM cpp_agentwisetotal CQ INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=CQ.AGENTID  AND CITYID=" + CITY_ID + "   group by AGENT_NAME,CQ.AGENTID ORDER BY TotalCPP DESC) as 'TotalCPP_New' FROM cpp_agentwisetotal CQ INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=CQ.AGENTID  WHERE Expirydate>=GETDATE() AND CITYID=" + CITY_ID + "  group by AGENT_NAME,CQ.AGENTID  ORDER BY TotalCPP DESC ", con1);


                SqlDataReader dr_CPP = com_csr.ExecuteReader();
                //SqlDataReader dr_CPP1 = com_csr1.ExecuteReader();
                if (dr_CPP.HasRows)
                {
                    int COUNT = 0;

                    Tables += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0>";
                    Tables += "<tr><td class=boldtext align=center COLSPAN=5><h5>" + CITY_NAME + " - period up to " + DateTime.Now.ToString("dd/MM/yyyy") + "</h5></td></tr>";
                    Tables += "<tr class=h5 Style='background-color: Lavender' align=center><th>S.No</th><th>Agent Name</th><th>Total CPP</th><th><table><tr width=100%><th align=left width=15%>Redeemed CPP</th><th align=center width=20%>MobNo</th><th align=center width=40%>Remarks</th><th align=center width=25%>Status</th></tr></table></th><th>Balance CPP</th></tr>";
                    while (dr_CPP.Read())
                    {
                        if (dr_CPP["RedeemedCPP"].ToString() != "0.00")
                        {
                            DataTable dt_red = dw.GetAllFromQuery("SELECT Redeemed_CPP,gift_send_to,gift_send_to_phone_no,remarks,status from redeem_cppNew where agent_id=" + dr_CPP["AGENTID"].ToString() + " and city_id=" + CITY_ID + "");
                            DataTable dt_alltotal = dw.GetAllFromQuery("SELECT top 1 sum(ISNULL(TotalCPP,0)) AS TotalCPPNew FROM cpp_agentwisetotal CQ INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=CQ.AGENTID  AND CITYID=" + CITY_ID + " and agentid=" + dr_CPP["AGENTID"].ToString() + "   group by AGENT_NAME,CQ.AGENTID");
                            COUNT++;
                            Tables += "<tr onclick=ChangeColor(this);>";
                            Tables += "<td>" + COUNT + "</td>";
                            Tables += "<td align=left>" + dr_CPP["AGENT_NAME"].ToString() + "</td>";
                            Tables += "<td align=right>" + dt_alltotal.Rows[0]["TotalCPPNew"].ToString() + "</td>";
                            Tables += "<td><table width=100% border=1 bordercolor=lightblue frame=void cellpadding=0 cellspacing=0 >";
                            if (dt_red.Rows.Count > 0)
                            {
                                foreach (DataRow drow in dt_red.Rows)
                                {
                                    Tables += "<tr width=100%><td align=left width=15% nowrap>&nbsp;" + drow["Redeemed_CPP"].ToString() + "</td><td align=left width=20% nowrap>&nbsp;" + drow["gift_send_to_phone_no"].ToString() + "</td><td align=left width=40%>&nbsp;" + drow["remarks"].ToString() + "</td><td align=left width=25%>&nbsp;" + drow["status"].ToString() + "</td></tr>";
                                }
                                Tables += "</td></table>";
                                Tables += "<td align=right>" + dr_CPP["balance_CPP"].ToString() + "</td>";
                                Tables += "</tr>";
                                total_redeem_cpp = total_redeem_cpp + decimal.Parse(dr_CPP["RedeemedCPP"].ToString());
                                Total_CPP = Total_CPP + decimal.Parse(dt_alltotal.Rows[0]["TotalCPPNew"].ToString());
                                TotalBalance_CPP = TotalBalance_CPP + decimal.Parse(dr_CPP["balance_CPP"].ToString());
                            }
                        }
                    }
                    Tables += " <tr>";
                    Tables += "<th colspan=2>Total " + CITY_NAME + "</th>";
                    Tables += "<th align=right>" + Total_CPP + "</th>";
                    Tables += "<th align=left>" + total_redeem_cpp + "</th>";
                    Tables += "<th align=right>" + TotalBalance_CPP + "</th>";
                    Tables += "</tr>";
                    Tables += "</TABLE><br><br style=page-break-before:always;>";
                }


            }
            if (Tables == "")
            {
                Label1.Text = "No Records Found";
                Label1.CssClass = "boldtext";
            }
            else
            {
                Label1.CssClass = "text";
                Label1.Text = Tables;
            }

        }
        catch (Exception)
        {

        }




    }
}
