﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Collections.Generic;   
public partial class DO_Print_Gst_updated: System.Web.UI.Page
{
    decimal KE_MUM_Tds = 0;
    decimal KE_MUM_frt = 0;
    bool flagtable = true;
    //Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string Import_AWB_ID;
    decimal Stax = 0;

    //****************Updated On 03 May2016: KKCess tax Apply system*****************
    decimal SBcess = 0;
    decimal KKcess = 0;
    decimal mawcharge = 0;
    string table = null;
    decimal cartingcharges = 0;
    string CompAddress = "";

    #region Gst newly Added
    decimal GSTDoCharges = 0;
    decimal IGSTChargs = 0;
    decimal SGSTChargs = 0;
    decimal CGSTChargs = 0;
    decimal totalTds = 0;
    #endregion Gst newly Added

    string strAirline_name = "", awbno = "", flt_no = "", import_rotation_No = "", arr_flight_date = "", contents = "", from = "", to = "", notify = "", IGMNo = "", pay_amt = "", straddress = "", issue_date = "", recipt_no = "", MawbDo_Chgs = "0", HawbDo_Chgs = "0", no_of_Houses = "", payment_mode = "", flight_date = "", part_pcs = "", HAWBChrg = "0", STAXRATE = "0", SBcessRATE = "0", KKcessRATE = "0", Airportadress = "";
    decimal pcs = 0, frt_chgs = 0, total = 0;
    string OldAwb_ReciptNo = "";
    bool Flag = false;

    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    /// 

    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    string AIrwayBill_No = "";
    string Airline_id = "";
    int city_id = 0;
    string FlightNo = "";
    string CompGstNo = "07";
    string AgentGstNo = "08";
    string StaxNo = "";
    //string addrs = string.Empty;
    string[] strArr = null;
    DataTable BankConsigneeStatus;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["airline_id"] != null)
            {
                lblTds.Text = "0";                
                /////DataTable dtcheckAwbexist = dw.GetAllFromQuery("select Import_Awb_No,Payment_Mode,ia.Airline_Detail_Id,ad.Belongs_To_City,iflight.Import_Flight_No from db_owner.Import_Flight_AWB ia INNER JOIN dbo.Airline_Detail ad ON ad.Airline_Detail_ID =ia.Airline_Detail_Id INNER JOIN db_owner.Import_Flights iflight ON ia.Import_Flight_ID = iflight.Import_Flight_ID  where Import_Awb_Id=" + Request.QueryString["AWBID"] + "");             
                DataTable dtcheckAwbexist = dw.GetAllFromQuery("select * from Import_Charges_fee Impfee inner join ImportChargesHeads Imphead on Impfee.airline_detail_id=Imphead.airline_detail_id where Imphead.airline_detail_id=" + Request.QueryString["airline_id"] + "");
                //From Prepaid Collect Query Bellow This One
                //BankConsigneeStatus = dw.GetAllFromQuery("select  Freight_Type,BankConsigneeStatus,Import_AWB_No,isnull(No_of_Houses,0)as No_of_Houses,HawbDo_Chgs,MawbDo_Chgs,shipment_type,Charged_Weight from import_flight_awb where Import_Awb_Id=" + Request.QueryString["AWBID"].ToString().Trim() + "");
                //BankConsigneeStatus = dw.GetAllFromQuery("select  Freight_Type,BankConsigneeStatus,Import_AWB_No,isnull(No_of_Houses,0)as No_of_Houses,HawbDo_Chgs,MawbDo_Chgs,shipment_type,Charged_Weight from import_flight_awb where Airline_Detail_Id=" + Request.QueryString["airline_id"] + "");
                //Airline_id = dtcheckAwbexist.Rows[0]["Airline_Detail_Id"].ToString();               
                if (dtcheckAwbexist.Rows.Count > 0)
                {
                    Airline_id = dtcheckAwbexist.Rows[0]["Airline_Detail_Id"].ToString();
                    strArr = Convert.ToString(Session["airline_city_text"]).Split('-');
                    strAirline_name = strArr[0];
                    if (Airline_id == "147" || Airline_id == "153" || Airline_id == "160" || Airline_id == "165" || Airline_id == "169")
                    {
                        MAWBid.Visible = true;
                        HAWBid.Visible = true;
                        Cartingid.Visible = true;
                    }
                    else if (Airline_id == "148" || Airline_id == "150" || Airline_id == "151" || Airline_id == "152" || Airline_id == "158")
                    {
                        MAWBid.Visible = true;
                        HAWBid.Visible = true;
                        Cartingid.Visible = false;
                    }
                    else if (Airline_id == "159")
                    {
                        MAWBid.Visible = true;
                        HAWBid.Visible = true;
                        Cartingid.Visible = true;
                        DataProcessingFeeid.Visible = true;
                        CommunicationFeeid.Visible = true;
                    }
                    else
                    {
                        Tr1.Visible = false;
                    }
                    city_id = Convert.ToInt32(dtcheckAwbexist.Rows[0]["City_ID"].ToString());
                    if (city_id == 6)
                    {
                        #region trmum.Visible = false; trchennai.Visible = false;trdel.Visible = true;
                        trdel.Visible = true;
                        trmum.Visible = false;
                        trchennai.Visible = false;
                        #endregion
                    }
                    else if (city_id == 18)
                    {
                        //comming
                        #region  trchennai.Visible = false; trdel.Visible = false; trmum.Visible = true;
                        trchennai.Visible = false;
                        trdel.Visible = false;
                        trmum.Visible = true;
                        #endregion
                    }
                    else
                    {
                        #region  trdel.Visible = false; trmum.Visible = false; trchennai.Visible = true;
                        trdel.Visible = false;
                        trmum.Visible = false;
                        trchennai.Visible = true;
                        #endregion
                    }

                    ////if (lblAddress.Text.Contains("GST NO"))
                    ////{
                    ////    int i = lblAddress.Text.IndexOf(",GST NO");
                    ////    StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                    ////    addrs = lblAddress.Text.Replace(StaxNo, ".");
                    ////    addrs = addrs.Replace(",.", ".");
                    ////    //lblAddress1.Text = addrs;
                    ////    lblAddress.Text = addrs;
                    ////}

                    string addrs = "";

                    //if (Airline_id == "158")
                    //{
                    //    if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                    //    {
                    //        lblAddress.Text = straddress.ToString();
                    //        lblAddress1.Text = straddress.ToString();
                    //    }
                    //    else
                    //    {
                    //        lblAddress.Text = straddress.ToString();
                    //        lblAddress1.Text = Airportadress.ToString();
                    //    }
                    //}
                    //else
                    //{
                    //    lblAddress.Text = straddress.ToString();
                    //    lblAddress1.Text = straddress.ToString();
                    //}

                    if (lblAddress.Text.Contains("GST NO"))
                    {
                        int i = lblAddress.Text.IndexOf(",GST NO");
                        StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                        addrs = lblAddress.Text.Replace(StaxNo, ".");
                        addrs = addrs.Replace(",.", ".");
                        //lblAddress1.Text = addrs;
                        lblAddress.Text = addrs;
                    }
                    else
                    {
                        //lblAddress1.Text = straddress.ToString();
                        lblAddress.Text = straddress.ToString();
                    }
                    //if (lblAddress1.Text.Contains("GST NO"))
                    //{
                    //    int i = lblAddress1.Text.IndexOf(",GST NO");
                    //    StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
                    //    addrs = lblAddress1.Text.Replace(StaxNo, ".");
                    //    addrs = addrs.Replace(",.", ".");
                    //    lblAddress1.Text = addrs;
                    //    //lblAddress.Text = addrs;
                    //}
                    //else
                    //{
                    //    if (Airline_id == "158")
                    //        if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                    //            lblAddress1.Text = straddress.ToString();
                    //        else
                    //            lblAddress1.Text = Airportadress.ToString();
                    //    else
                    //        lblAddress1.Text = straddress.ToString();
                    //}
                    if (lblAddress1.Text.Contains("Tel"))
                        lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
                    if (lblAddress1.Text.Contains("TEL"))
                        lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
                    if (lblAddress.Text.Contains("Tel"))
                        lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
                    if (lblAddress.Text.Contains("TEL"))
                        lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
                    if (lblAddress1.Text.Contains("Fax"))
                        lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
                    if (lblAddress1.Text.Contains("FAX"))
                        lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
                    if (lblAddress.Text.Contains("Fax"))
                        lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
                    if (lblAddress.Text.Contains("FAX"))
                        lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");
                    //if (payment_mode == "1")
                    //{
                    //    lblCheque.Visible = false;
                    //    lblCash.Text = "in Cash";
                    //}
                    //else if (payment_mode == "2")
                    //{
                    //    lblCash.Visible = false;
                    //    lblCheque.Text = "in by Cheque. Cheque No:, Bank:Date:";
                    //}
                    if (strAirline_name == "MALAYSIA AIRLINES")
                    {
                        lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                    }
                    else if (strAirline_name == "TURKISH AIRLINES")
                    {
                        lblAirlineStax.Text = "Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                    }
                    else if (strAirline_name == "AIR CHINA")
                    {
                        lblAirlineStax.Text = "Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                    }
                    else if (strAirline_name == "KOREAN AIRLINES")
                    {
                        lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                    }
                    else if (strAirline_name == "MEGA MALDIVES AIRLINES")
                    {
                        lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                    }
                    else
                    {
                        lblAirlineStax.Text = "Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                    }
                    lblairlinename.Text = strAirline_name.ToString();
                    if (Airline_id == "158")
                    {
                        if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                        {
                            lblAirlineNme.Text = "KOREAN AIR";
                            lblheadairlinename.Text = "KOREAN AIR";
                        }
                        else
                        {
                            lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                            lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                        }
                    }
                    else if (Airline_id == "159")
                    {
                        if (FlightNo == "HY-127")
                        {
                            lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                            lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                            lblairlinename.Text = "UZBEKISTAN AIRWAYS";
                        }
                        else
                        {
                            lblAirlineNme.Text = "KOREAN AIR";
                            lblheadairlinename.Text = "KOREAN AIR";
                            lblairlinename.Text = "KOREAN AIR";
                        }
                    }
                    else
                    {
                        lblAirlineNme.Text = strAirline_name.ToString();
                        lblheadairlinename.Text = strAirline_name.ToString();
                    }
                    lblairlinename.Text = strAirline_name.ToString();
                    if (Airline_id == "158")
                    {
                        if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                        {
                            lblAirlineNme.Text = "KOREAN AIR";
                            lblheadairlinename.Text = "KOREAN AIR";
                        }
                        else
                        {
                            lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                            lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                        }
                    }
                    else if (Airline_id == "159")
                    {
                        if (FlightNo == "HY-127")
                        {
                            lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                            lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                            lblairlinename.Text = "UZBEKISTAN AIRWAYS";
                        }
                        else
                        {
                            lblAirlineNme.Text = "KOREAN AIR";
                            lblheadairlinename.Text = "KOREAN AIR";
                            lblairlinename.Text = "KOREAN AIR";
                        }
                    }
                    else
                    {
                        lblAirlineNme.Text = strAirline_name.ToString();
                        lblheadairlinename.Text = strAirline_name.ToString();
                    }
                }
                else
                { 
                                   
                }
            }
        }
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetListOrigin(string prefixText)
     {
        using (SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString))
        {
            sqlconn.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT destination_name,destination_id,destination_code FROM destination_master where destination_name like '" + prefixText + "%' ", sqlconn);
            // cmd.Parameters.AddWithValue("@Destinationname", prefixText);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<string> CountryNames = new List<string>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                CountryNames.Add(dt.Rows[i]["destination_name"].ToString() + "-" + dt.Rows[i]["destination_code"].ToString());
            }
            return CountryNames;
        }
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetListDestination(string prefixText)
    {
        using (SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString))
        {
            sqlconn.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT destination_name,destination_id,destination_code FROM destination_master where destination_name like '" + prefixText + "%' ", sqlconn);
            // cmd.Parameters.AddWithValue("@Destinationname", prefixText);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<string> CountryNames = new List<string>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                CountryNames.Add(dt.Rows[i]["destination_name"].ToString() + "-" + dt.Rows[i]["destination_code"].ToString());
            }
            return CountryNames;
        }
    }

    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "C")
        {

            //txtcommodity.Text = "Console";
            //txtAgentname.Visible = false;
            //hiddenTargetControlForModalPopup33.Visible = true;
            //ddlAgent.Visible = true;
            //ddlGst.Visible = true;
            //txtHouses.ReadOnly = false;
            //txtHouses.Text = "";
        }
        else
        {
            //txtcommodity.Text = "";
            //txtAgentname.Visible = true;
            //hiddenTargetControlForModalPopup33.Visible = false;
            //ddlAgent.Visible = false;
            //ddlGst.Visible = false;
            //txtHouses.Text = "0";
            //txtHouses.ReadOnly = true;
        }
      //  txtConsigneeAddress.Text = "";
    }

    protected void RbuttonDO_SelectedIndexChanged(object sender, EventArgs e)
    {       
        if (RdbtnList.SelectedItem.Text != "Cash")
        {          
            DataTable dt = dw.GetAllFromQuery("select isnull(Stax,0) as Stax from Airlinewise_TDS where Airline_Detail_Id=" + Session["Airline_detail_Id"].ToString() + " and GETDATE() BETWEEN Valid_From AND Valid_To");
            //Trchecqueno.Visible = true;
            //Trchecqueno2.Visible = true;
            //Trchecqueno3.Visible = true;
            //TrCash.Visible = false;
        }
        else
        {
            //Trchecqueno.Visible = false;
            //Trchecqueno2.Visible = false;
            //Trchecqueno3.Visible = false;
            //TrCash.Visible = true;
        }    
    }

    public string IntegerToWords(long inputNum)
    {
        int dig1, dig2, dig3, level = 0, lasttwo, threeDigits;
        string retval = "";
        string x = "";
        string[] ones ={
                    "zero",
                    "one",
                    "two",
                    "three",
                    "four",
                    "five",
                    "six",
                    "seven",
                    "eight",
                    "nine",
                    "ten",
                    "eleven",
                    "twelve",
                    "thirteen",
                    "fourteen",
                    "fifteen",
                    "sixteen",
                    "seventeen",
                    "eighteen",
                    "nineteen"
                     };
        string[] tens ={
                "zero",
                "ten",
                "twenty",
                "thirty",
                "forty",
                "fifty",
                "sixty",
                "seventy",
                "eighty",
                "ninety"
               };
        string[] thou ={
                "",
                "thousand",
                "million",
                "billion",
                "trillion",
                "quadrillion",
                "quintillion"
                      };

        bool isNegative = false;
        if (inputNum < 0)
        {
            isNegative = true;
            inputNum *= -1;
        }

        if (inputNum == 0)
            return ("zero");

        string s = inputNum.ToString();

        while (s.Length > 0)
        {
            // Get the three rightmost characters
            x = (s.Length < 3) ? s : s.Substring(s.Length - 3, 3);

            // Separate the three digits
            threeDigits = int.Parse(x);
            lasttwo = threeDigits % 100;
            dig1 = threeDigits / 100;
            dig2 = lasttwo / 10;
            dig3 = (threeDigits % 10);

            // append a "thousand" where appropriate
            if (level > 0 && dig1 + dig2 + dig3 > 0)
            {
                retval = thou[level] + " " + retval;
                retval = retval.Trim();
            }

            // check that the last two digits is not a zero
            if (lasttwo > 0)
            {
                if (lasttwo < 20) // if less than 20, use "ones" only
                    retval = ones[lasttwo] + " " + retval;
                else // otherwise, use both "tens" and "ones" array
                    retval = tens[dig2] + " " + ones[dig3] + " " + retval;
            }

            // if a hundreds part is there, translate it
            if (dig1 > 0)
                retval = ones[dig1] + " hundred " + retval;

            s = (s.Length - 3) > 0 ? s.Substring(0, s.Length - 3) : "";
            level++;
        }

        while (retval.IndexOf(" ") > 0)
            retval = retval.Replace(" ", " ");

        retval = retval.Trim();

        if (isNegative)
            retval = "negative " + retval;

        return (retval);
    }

    //-------------------------CODE TO CONVERT FROM DIGIT TO WORDS----BY: DHIRAJ GAUTAM----------------
    public static String changeNumericToWords(double numb)
    {
        String num = numb.ToString();
        return changeToWords(num, false);
    }

    public static String changeCurrencyToWords(String numb)
    {
        return changeToWords(numb, true);
    }

    public static String changeNumericToWords(String numb)
    {
        return changeToWords(numb, false);
    }

    public static String changeCurrencyToWords(double numb)
    { return changeToWords(numb.ToString(), true); }

    private static String changeToWords(String numb, bool isCurrency)
    {
        String val = "", wholeNo = numb, points = "", andStr = "", pointStr = "";
        String endStr = (isCurrency) ? ("Only") : ("");
        try
        {
            int decimalPlace = numb.IndexOf(".");
            if (decimalPlace > 0)
            {
                wholeNo = numb.Substring(0, decimalPlace);
                points = numb.Substring(decimalPlace + 1);
                if (Convert.ToInt32(points) > 0)
                {
                    andStr = (isCurrency) ? ("and") : ("point");// just to separate whole numbers from points/centsendStr = (isCurrency) ? ("Cents "+endStr) : ("");pointStr = translateCents(points);
                }
            }
            val = String.Format("{0} {1}{2} {3}", translateWholeNumber(wholeNo).Trim(), andStr, pointStr, endStr);
        }
        catch
        { ;}
        return val;
    }

    private static String translateWholeNumber(String number)
    {
        string word = "";
        try
        {
            bool beginsZero = false;//tests for 0XXbool 
            bool isDone = false;//test if already translateddouble 
            double dblAmt = (Convert.ToDouble(number));
            //if ((dblAmt > 0) && number.StartsWith("0"))
            if (dblAmt > 0)
            {
                //test for zero or digit zero in a nuemric
                beginsZero = number.StartsWith("0");
                int numDigits = number.Length;
                int pos = 0;//store digit grouping
                String place = "";//digit grouping name:hundres,thousand,etc...
                switch (numDigits)
                {
                    case 1://ones' range
                        word = ones(number);
                        isDone = true; break;
                    case 2://tens'  range
                        word = tens(number);
                        isDone = true; break;
                    case 3://hundreds' range
                        pos = (numDigits % 3) + 1;
                        place = " Hundred "; break;
                    case 4://thousands'  range
                    case 5:
                    case 6: pos = (numDigits % 4) + 1;
                        place = " Thousand ";
                        break;
                    case 7://millions' range
                    case 8:
                    case 9:
                        pos = (numDigits % 7) + 1;
                        place = " Million ";
                        break;
                    case 10://Billions's range
                        pos = (numDigits % 10) + 1;
                        place = " Billion ";
                        break;//add extra case options for anything above Billion...
                    default: isDone = true;
                        break;
                }
                if (!isDone)
                {
                    //if transalation is not done, continue...(Recursion comes in now!!)
                    word = translateWholeNumber(number.Substring(0, pos)) + place + translateWholeNumber(number.Substring(pos));
                    //check for trailing zeros
                    if (beginsZero) word = " and " + word.Trim();
                }
                //ignore digit grouping names
                if (word.Trim().Equals(place.Trim()))
                    word = "";
            }
        }
        catch
        { ;}
        return word.Trim();
    }

    private static String tens(String digit)
    {
        int digt = Convert.ToInt32(digit);
        String name = null;
        switch (digt)
        {
            case 10: name = "Ten";
                break;
            case 11: name = "Eleven";
                break;
            case 12: name = "Twelve";
                break;
            case 13: name = "Thirteen";
                break;
            case 14: name = "Fourteen";
                break;
            case 15: name = "Fifteen";
                break;
            case 16: name = "Sixteen";
                break;
            case 17: name = "Seventeen";
                break;
            case 18: name = "Eighteen";
                break;
            case 19: name = "Nineteen";
                break;
            case 20: name = "Twenty";
                break;
            case 30: name = "Thirty";
                break;
            case 40: name = "Fourty";
                break;
            case 50: name = "Fifty";
                break;
            case 60: name = "Sixty";
                break;
            case 70: name = "Seventy";
                break;
            case 80: name = "Eighty";
                break;
            case 90: name = "Ninety";
                break;
            default: if (digt > 0)
                {
                    name = tens(digit.Substring(0, 1) + "0") + " " + ones(digit.Substring(1));
                }
                break;
        }
        return name;
    }

    private static String ones(String digit)
    {
        int digt = Convert.ToInt32(digit);
        String name = "";
        switch (digt)
        {
            case 1: name = "One";
                break;
            case 2: name = "Two";
                break;
            case 3: name = "Three";
                break;
            case 4: name = "Four";
                break;
            case 5: name = "Five";
                break;
            case 6: name = "Six";
                break;
            case 7: name = "Seven";
                break;
            case 8: name = "Eight";
                break;
            case 9: name = "Nine";
                break;
        }
        return name;
    }

    private static String translateCents(String cents)
    {
        String cts = "", digit = "", engOne = "";
        for (int i = 0; i < cents.Length; i++)
        {
            digit = cents[i].ToString();
            if (digit.Equals("0"))
            {
                engOne = "Zero";
            }
            else
            {
                engOne = ones(digit);
            }
            cts += " " + engOne;
        }
        return cts;
    }

    //-------------------------END OF CODE TO CONVERT FROM DIGIT TO WORDS----------------
    public void Display()
    {
        lblAddress1.Visible = true;
        lblAddress.Visible = true;
        string strInclusive = string.Empty;
        Import_AWB_ID = Convert.ToString(Request.QueryString["AWBID"]);
        DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFA.GstAddress, IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,IFA.PCS,IFA.Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");
        //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  
        DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + Request.QueryString["AWBID"].ToString() + "'");
        string table = "";
        string StaxNo = "";
        issue_date = dt.Rows[0]["issue_date"].ToString();
        straddress = dt.Rows[0]["office_address"].ToString();
        Airportadress = dt.Rows[0]["Airport_Address"].ToString();
        payment_mode = dt.Rows[0]["payment_mode"].ToString();
        flight_date = dt.Rows[0]["import_flight_Date"].ToString();
        part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
        decimal ServiceTax = 0;
        ServiceTax = decimal.Parse(STAXRATE);
        //if (part_pcs == "" || part_pcs == "0")
        //{
        //    lblPartPsc.Visible = false;
        //    lblPartPsc.Text = "";
        //    lblpppsc.Visible = false;
        //    lblpppsc.Text = "";
        //}
        //else
        //{
        //    lblPartPsc.Visible = true; ;
        //    lblPartPsc.Text = part_pcs;
        //    lblpppsc.Visible = true;
        //    lblpppsc.Text = "/";
        //}
        //*****************Added On 1 feb 2011********************
       
        //*****************END********************
        strAirline_name = dt.Rows[0]["Airline_Name"].ToString();
        if (strAirline_name == "MALAYSIAN AIRLINES")
        {
            strAirline_name = "MALAYSIA AIRLINES";
        }     
        contents = dt.Rows[0]["commodity"].ToString();
        if (contents == "Console")
        {
            contents = "Consol";
        }
        to = dt.Rows[0]["Consignee_Name"].ToString();
        if (to == "")
        {
            to = dt.Rows[0]["Agent_Name"].ToString();
        }
        if (Airline_id == "147" || Airline_id == "153")
        {
            to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
        }
        if (dt.Rows[0]["GstNo"].ToString() != "")
        {
            string placeOfDelivery = "DELHI";
            string GstAddress = placeOfDelivery;
            if (dt.Rows[0]["GstAddress"].ToString() != "")
            {
                GstAddress = dt.Rows[0]["GstAddress"].ToString();
            }
            DataTable dtdeliveryplace = dw.GetAllFromQuery("Select state from gststateCode where statecode=" + dt.Rows[0]["GstNo"].ToString().Substring(0, 2) + "");
            if (dtdeliveryplace.Rows != null && dtdeliveryplace.Rows.Count > 0)
            {
                #region if condition
                if (dtdeliveryplace.Rows[0]["state"].ToString() == "" || dtdeliveryplace.Rows[0]["state"].ToString() == null)
                {
                    placeOfDelivery = dt.Rows[0]["GstNo"].ToString();
                    if (dt.Rows[0]["GstAddress"].ToString() == "")
                    {
                        GstAddress = placeOfDelivery;
                    }
                }
                else
                {
                    placeOfDelivery = dtdeliveryplace.Rows[0]["state"].ToString();
                    if (dt.Rows[0]["GstAddress"].ToString() == "")
                    {
                        GstAddress = placeOfDelivery;
                    }
                }
                //////to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                #endregion
            }
            else
            {
                //// to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
            }
        }
        from = dt.Rows[0]["Shipper_Name"].ToString();
        notify = dt.Rows[0]["Notify"].ToString();
      
        //************END**********************************************
        string addrs = "";
        if (Airline_id == "158")
        {
            //if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
            //{
            //    lblAddress.Text = straddress.ToString();
            //    lblAddress1.Text = straddress.ToString();
            //}
            //else
            //{
            //    lblAddress.Text = straddress.ToString();
            //    lblAddress1.Text = Airportadress.ToString();
            //}
        }
        else
        {
            lblAddress.Text = straddress.ToString();
            lblAddress1.Text = straddress.ToString();
        }


        if (lblAddress.Text.Contains("GST NO"))
        {
            int i = lblAddress.Text.IndexOf(",GST NO");
            StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
            addrs = lblAddress.Text.Replace(StaxNo, ".");
            addrs = addrs.Replace(",.", ".");
            //lblAddress1.Text = addrs;
            lblAddress.Text = addrs;
        }
        else
        {
            // lblAddress1.Text = straddress.ToString();
            lblAddress.Text = straddress.ToString();
        }
        //if (lblAddress1.Text.Contains("GST NO"))
        //{
        //    int i = lblAddress1.Text.IndexOf(",GST NO");
        //    StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
        //    addrs = lblAddress1.Text.Replace(StaxNo, ".");
        //    addrs = addrs.Replace(",.", ".");
        //    lblAddress1.Text = addrs;
        //    //lblAddress.Text = addrs;
        //}
        //else
        //{
        //    if (Airline_id == "158")
        //        if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
        //            lblAddress1.Text = straddress.ToString();
        //        else
        //            lblAddress1.Text = Airportadress.ToString();
        //    else
        //        lblAddress1.Text = straddress.ToString();
        //}
        if (lblAddress1.Text.Contains("Tel"))
            lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
        if (lblAddress1.Text.Contains("TEL"))
            lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
        if (lblAddress.Text.Contains("Tel"))
            lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
        if (lblAddress.Text.Contains("TEL"))
            lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
        if (lblAddress1.Text.Contains("Fax"))
            lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
        if (lblAddress1.Text.Contains("FAX"))
            lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
        if (lblAddress.Text.Contains("Fax"))
            lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
        if (lblAddress.Text.Contains("FAX"))
            lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");

        //lblAddress.Text = straddress.ToString();
        //if (lblAddress.Text.Contains("S.TAX NO"))
        //{
        //    int i = lblAddress.Text.IndexOf(",S.TAX NO");
        //    StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
        //    addrs = lblAddress.Text.Replace(StaxNo, ".");
        //    addrs = addrs.Replace(",.", ".");
        //    lblAddress1.Text = addrs;
        //    lblAddress.Text = addrs;
        //}
        //else
        //{
        //    lblAddress1.Text = straddress.ToString();
        //    lblAddress.Text = straddress.ToString();
        //}

        //if (payment_mode == "1")
        //{
        //    lblCheque.Visible = false;
        //    lblCash.Text = "in Cash";
        //}
        //else if (payment_mode == "2")
        //{
        //    lblCash.Visible = false;
        //    //lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
        //    lblCheque.Text = "in by Cheque.  Cheque No: , Bank:  Date:";
        //}
        if (strAirline_name == "MALAYSIA AIRLINES")
        {
            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
        }
        else if (strAirline_name == "TURKISH AIRLINES")
        {
            lblAirlineStax.Text = "Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
        }

        else if (strAirline_name == "AIR CHINA")
        {
            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
        }
        else if (strAirline_name == "KOREAN AIRLINES")
        {
            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
        }

        else if (strAirline_name == "MEGA MALDIVES AIRLINES")
        {
            lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
        }
        else
        {
            lblAirlineStax.Text = "Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
        }

        lblairlinename.Text = strAirline_name.ToString();
        if (Airline_id == "158")
        {
            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
            {
                lblAirlineNme.Text = "KOREAN AIR";
                lblheadairlinename.Text = "KOREAN AIR";
            }
            else
            {
                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
            }
        }
        else if (Airline_id == "159")
        {
            if (FlightNo == "HY-127")
            {
                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                lblairlinename.Text = "UZBEKISTAN AIRWAYS";
            }
            else
            {
                lblAirlineNme.Text = "KOREAN AIR";
                lblheadairlinename.Text = "KOREAN AIR";
                lblairlinename.Text = "KOREAN AIR";
            }

        }
        else
        {
            lblAirlineNme.Text = strAirline_name.ToString();
            lblheadairlinename.Text = strAirline_name.ToString();
        }
        //lblAwbno.Text = awbno.ToString();
        //lblPcs.Text = pcs.ToString();
        //////////lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");

        ////****************Added On 01_Mach_2011******
        //lblDate.Text = issue_date;
        ////***************End*************

        //lblcommdy.Text = contents.ToString();
        //lblFlightno.Text = flt_no.ToString();
        //lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();

        //lbligmnr.Text = IGMNo.ToString();
        ////lblAwb2.Text = awbno.ToString();
        //lbldate2.Text = issue_date.ToString();
        //lblFlitno2.Text = flt_no.ToString();
        lblAirlinemame3.Text = strAirline_name.ToString();
        if (Airline_id == "147")
        {
            //lblch.Visible = true;
            //lblchwt.Visible = true;
            //lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
            lblAirlinemame3.Text = "MASkargo";
            lblAirlineNme.Text = "MASkargo";
        }
        else if (Airline_id == "153")
        {
            //lblch.Visible = true;
            //lblchwt.Visible = true;
            //lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
            ////lblAirlinemame3.Text = "MASkargo";
            ////lblAirlineNme.Text = "MASkargo";
        }

        if (Airline_id == "159")
        {
            lblAirlinemame3.Text = "KOREAN AIR";
        }
        //******************Added On 1 feb 2011*********************
        //if (dt.Rows[0]["freight_Type"].ToString() == "CC")
        //{
        //    TrFreightChrgsCC.Visible = true;
        //    if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0.00")
        //    {
        //        lblDOFrtChr.Text = "0";
        //        TrFreightChrgsCC.Visible = false;
        //    }
        //    else
        //    {
        //        TrFreightChrgsCC.Visible = true;
        //        lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
        //        total += Convert.ToDecimal(dt.Rows[0]["Total_Collection_CC"]);
        //    }
        //}
        ////****************************End*********************************************
        //decimal _Amount_Received = 0;
        //decimal _Amount_ReceivedSBCess = 0;
        //decimal _Amount_ReceivedKKCess = 0;
        ////*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  
        //for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
        //{
        //    if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
        //    {
        //        _Amount_Received = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());

        //    }
        //    if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
        //    {
        //        _Amount_ReceivedSBCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
        //    }
        //    //****************Updated On 03 May2016: KKCess tax Apply system*****************
        //    if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
        //    {
        //        _Amount_ReceivedKKCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
        //    }
        //}
        //decimal _TDSCutByAgent = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());
        ////decimal f = d+1000;
        //decimal f = d + Convert.ToDecimal(MawbDo_Chgs);
        ////decimal Tds=9.75;
        //decimal _Amount = 0;
        //_Amount = Convert.ToInt64(f);

        //string TD_S = "";
        //string TD_S1 = "";

        //string Total_ = "";
        //if (Airline_id == "159")
        //{
        //    ////if (_Amount_Received != 0)
        //    ////{
        //        //****************Updated On 03 May2016: KKCess tax Apply system*****************
        //        ////decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
        //        decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));

        //        total = total - mawcharge + _Amount_Received + charge;
        //   ////// }
        //}

        // lblMaster.Text = MawbDo_Chgs.ToString();
        //if (_TDSCutByAgent > 0 || ServiceTax > 0)
        //{
        //    if (_TDSCutByAgent > 0)
        //    {

        //        string TD = Convert.ToString(Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
        //        TD_S = Convert.ToDecimal(TD).ToString("#,##0.00");

        //        //////string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
        //        ////string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
        //        string A = Convert.ToString(total);


        //        decimal AM = 0;
        //        AM = decimal.Parse(A);
        //        Total_ = Convert.ToDecimal(A).ToString("#,##0.00");
                
        //        //lblfreight.Text = Total_;
        //        if (Airline_id == "159")
        //        {
        //            lblBreakupTotal.Text = Convert.ToString(total); 
        //            lblRecivedAmt.Text = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
        //            Label1.Text = lblRecivedAmt.Text;
        //            Label6.Visible = false;
        //        }
        //        _Amount = decimal.Parse(lblfreight.Text);
        //    }
        ////****************** Service Tax Logic on 16 Aug 2010 *****************
        ////else
        ////{

        ////    //lblfreight.Text = total.ToString();
        ////    if (Airline_id == "159")
        ////    {
        ////        lblBreakupTotal.Text = lblfreight.Text;
        ////        lblRecivedAmt.Text = lblfreight.Text;
        ////        Label1.Text = lblRecivedAmt.Text;
        ////        Label6.Visible = false;
        ////    }
        ////    _Amount = decimal.Parse(lblfreight.Text);
        ////}
        //}
        //else
        //{
        //    string _F = "";
        //    if (dt.Rows[0]["freight_Type"].ToString() == "CC")
        //    {
        //        _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue) + decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString()));
        //    }
        //    else
        //    {
        //        _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue));
        //    }
        //   // lblfreight.Text = Convert.ToDecimal(_F).ToString("#,##0.00");
        //    if (Airline_id == "159")
        //    {
        //        //lblfreight.Text = total.ToString();
        //        lblRecivedAmt.Text = lblfreight.Text;
        //        lblBreakupTotal.Text = lblRecivedAmt.Text;
               
        //        Label1.Text = lblRecivedAmt.Text;
        //        Label6.Visible = false;
        //    }
        //    //_Amount = f;
        //    _Amount = decimal.Parse(lblfreight.Text);
        //}
        ////Label1.Text = lblfreight.Text;
        //lblSno.Text = recipt_no.ToString();
        //lblSnomum.Text = recipt_no.ToString();
        //lblSnochennai.Text = recipt_no.ToString();
        //lblSno2.Text = recipt_no.ToString();
        //lblName.Text = to.ToString();
        //lblName2.Text = to.ToString();
        //Sno.Text = recipt_no.ToString();
        //string englishTranslation = "";
        //string englishTranslationDecimalPart = "";
        ////string englishTranslation = changeNumericToWords(Convert.ToDouble(f));
        ////********** Function Translation of Number figure TO Words******************
        //string Amt = _Amount.ToString();
        //string AmtDecimal = "";
        //string AmountCombined = "";

        //*********Decimal Logic****************

        //***** Shipment Type is FOC Case**********//
        //if (dt.Rows[0]["shipment_type"].ToString() == "F")
        //{
        //    _Amount = 0;
        //    lblfreight.Text = "0.00";
        //    lblAmount.Text = "Zero";
        //    lblRecivedAmt.Text = "0.00";
        //    englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));

        //}
        //else
        //{
        //    //////englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
        //    englishTranslation = changeNumericToWords(Convert.ToDouble(lblRecivedAmt.Text));
        //    lblAmount.Text = englishTranslation;
        //}
        //englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));

        ////lblFlightDate.Text = flight_date.ToString();
        //DateTime fltdate = DateTime.Parse(flight_date);
        //lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");

        ////lblFltDateAirline.Text = flight_date.ToString();
        //DateTime fltdate2 = DateTime.Parse(flight_date);
        //lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");
    }

    protected void ChkStatus_CheckedChanged(object sender, EventArgs e)
    { 
           
    }

   public void CleerText()
    {
        txtDate.Text = txtdate2.Text = txtDoAmountReceived.Text = txtDoCharge.Text = txtDst.Text = txtFlightDate.Text = txtFlitno2.Text = txtGstAddress.Text = string.Empty;
        txtGstAddressdd.Text = txtGstNo.Text = txtIGST.Text = txtInvoiceNo.Text = txtNotifyDovalue.Text = txtOrigin.Text = txtpartpcs.Text = txtpcs.Text = string.Empty;
        txtpcs.Text = txtSGST.Text = txtValidFrom.Text = txtAgentName.Text = lblFlightno.Text = lbligmnr.Text = txtcommdy.Text = txtChrgsValue1.Text = string.Empty;
        txtCGST.Text = lblBreakupTotal.Text = lblTds.Text = txtRecivedAmt.Text = lblAirlinemame3.Text = txtChrgsValue0.Text = txtWt.Text = string.Empty;
    }

    protected void Btnload_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            //com = new SqlCommand("insert into import_agent_master(Import_Agent_Name,Import_Agent_City,Import_Agent_Email,Import_Credit_Limit,Agent_Address,Agent_Phone,Agent_Contactno,Entered_By,Entered_On) values(@Import_Agent_Name,@Import_Agent_City,@Import_Agent_Email,@Import_Credit_Limit,@Agent_Address,@Agent_Phone,@Agent_Contactno,@Entered_By,@Entered_On)", con);
            //com = new SqlCommand("insert into Import_flight_awb_Mann(Airline_Detail_Id,pcs,Origin,Destination,Gross_Weight,Freight_Type,shipment_type,Commodity,Notify,Remarks,MAWBDO_chgs,HAWBDO_chgs,Amount_Received,Payment_Mode,Recipt_No,Status,Consignee_Address,GstNo,GstAddress,Agent_Name,Entered_By,Entered_On) values(@Import_Agent_Name,@Import_Agent_City,@Import_Agent_Email,@Import_Credit_Limit,@Agent_Address,@Agent_Phone,@Agent_Contactno,@Entered_By,@Entered_On)", con);
            com = new SqlCommand("InsertImportFlightawb_jj_temp", con);
            com.CommandType = CommandType.StoredProcedure; 
            //DateTime dt = DateTime.Parse(txtDate.Text.ToString(), new CultureInfo("en-CA"));
            com.Parameters.Add("@Airline_Detail_Id", SqlDbType.Int).Value = int.Parse(Request.QueryString["airline_id"]);
            com.Parameters.Add("@Import_AWB_No", SqlDbType.VarChar).Value = Convert.ToString((lblFlightno.Text + "/" + txtDate.Text));
            com.Parameters.Add("@Import_Flight_ID", SqlDbType.Int).Value = int.Parse(Request.QueryString["airline_id"]);
            //com.Parameters.Add("@Import_AWB_Date", SqlDbType.DateTime).Value = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //com.Parameters.Add("@SourceID", SqlDbType.Int).Value = int.Parse(txtOrigin.Text);            
            com.Parameters.Add("@pcs", SqlDbType.Int).Value = int.Parse(txtpcs.Text);
            com.Parameters.Add("@Part_pcs", SqlDbType.Int).Value = int.Parse(txtpartpcs.Text);          
            com.Parameters.Add("@Gross_Weight", SqlDbType.Int).Value = int.Parse(txtWt.Text);
            com.Parameters.Add("@Charged_Weight", SqlDbType.Int).Value = int.Parse(txtWt.Text);
            com.Parameters.Add("@Origin", SqlDbType.VarChar).Value = Convert.ToString(txtOrigin.Text).Contains("-") ? Convert.ToString(txtOrigin.Text).Split('-')[1] : Convert.ToString(txtOrigin.Text);
            com.Parameters.Add("@Destination", SqlDbType.VarChar).Value = Convert.ToString(txtDst.Text).Contains("-") ? Convert.ToString(txtDst.Text).Split('-')[1] : Convert.ToString(txtDst.Text);
            com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = ddlFreight.SelectedItem.Text;
            com.Parameters.Add("@shipment_type", SqlDbType.VarChar).Value = RadioButtonList1.SelectedItem.Text;
            com.Parameters.Add("@Commodity", SqlDbType.VarChar).Value = txtcommdy.Text;           
            com.Parameters.Add("@Notify", SqlDbType.VarChar).Value = txtNotifyDovalue.Text;
            //com.Parameters.Add("@Agent_Name", SqlDbType.VarChar).Value = "jj";
            com.Parameters.Add("@Agent_Name", SqlDbType.VarChar).Value = txtAgentName.Text;
            com.Parameters.Add("@Agent_Address", SqlDbType.VarChar).Value = txtGstAddress.Text;
            com.Parameters.Add("@MAWBDO_chgs", SqlDbType.Int).Value = int.Parse(txtChrgsValue0.Text);
            com.Parameters.Add("@HAWBDO_chgs", SqlDbType.Int).Value = int.Parse(txtChrgsValue1.Text);
            com.Parameters.Add("@Amount_Receivable", SqlDbType.Int).Value = int.Parse(txtRecivedAmt.Text);
            com.Parameters.Add("@DO_Amount_Received", SqlDbType.Int).Value = int.Parse(txtDoAmountReceived.Text);
            com.Parameters.Add("@Amount_Received", SqlDbType.VarChar).Value = txtRecivedAmt.Text;
            com.Parameters.Add("@Payment_Mode", SqlDbType.VarChar).Value = RdbtnList.SelectedItem.Text;
            com.Parameters.Add("@Recipt_No", SqlDbType.VarChar).Value = txtInvoiceNo.Text;
            com.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = txtGstNo.Text;
           // com.Parameters.Add("@GstAddress", SqlDbType.VarChar).Value = txtGstAddress.Text;
            //SqlParameter outputParam = com.Parameters.Add("@returnout", SqlDbType.VarChar);
            //outputParam.Direction = ParameterDirection.Output;
            SqlParameter parm3 = new SqlParameter("@returnout", SqlDbType.Int);
            parm3.Direction = ParameterDirection.Output;            
            com.Parameters.Add(parm3);
            //Trans Table Insert After Complition
            //com.Parameters.Add("@ImportAwbID", SqlDbType.VarChar).Value = RdbtnList.SelectedItem.Text;
            //jj by just
            com.Parameters.Add("@ChargeName", SqlDbType.VarChar).Value = lblAirlinemame3.Text;
            com.Parameters.Add("@Quantity", SqlDbType.Int).Value = int.Parse(txtpartpcs.Text);
            com.Parameters.Add("@ChargeRate", SqlDbType.Int).Value = int.Parse(txtpartpcs.Text);
            com.Parameters.Add("@ChargeAmount", SqlDbType.Int).Value = int.Parse(txtRecivedAmt.Text);            
            //com.Parameters.Add("@IgmNo", SqlDbType.VarChar).Value = txtChrgsValue0.Text;
            //com.Parameters.Add("@PackageArrivedat", SqlDbType.VarChar).Value = RdbtnList.SelectedItem.Text;
            //com.Parameters.Add("@Import_Credit_Limit", SqlDbType.Decimal).Value = decimal.Parse(txtCreditLimit.Text.ToString());
            //com.Parameters.Add("@Import_Credit_Limit", SqlDbType.Decimal).Value = (txtCreditLimit.Text.Trim() == "" ? 0 : decimal.Parse(txtCreditLimit.Text.Trim()));        
            //com.Parameters.Add("@Agent_Name", SqlDbType.VarChar).Value = "jj";
            //com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
             com.ExecuteNonQuery();
             string str = Convert.ToString(com.Parameters["@returnout"].Value);
             if (str != "101")
             {
                 CleerText();
                 ScriptManager.RegisterStartupScript(this, GetType(), "AlertKey", "alert('Insert Success');", true);                 
             }
             else
             {

             }
             con.Dispose();        
            //LoadAgent();
            //txtConsigneeAddress.Text = txtAddress.Text;
            //ddlAgent.SelectedIndex = ddlAgent.Items.IndexOf(ddlAgent.Items.FindByText(txtImportAgentname.Text));
        }
        catch (SqlException se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        catch (Exception se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
