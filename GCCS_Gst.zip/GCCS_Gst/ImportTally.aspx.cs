using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 
public partial class ImportTally : System.Web.UI.Page
{
    int airline_det_id = 0;
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    SqlTransaction tran ;

    bool flag = false;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string strCon1 = ConfigurationManager.ConnectionStrings["Tally"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }


        btnLoad.Attributes.Add("onclick", "return CheckEmpty_ddl();");

        if (!IsPostBack)
        {
            try
            {
                String airline_access = Session["AIRLINEACCESS"].ToString();
                // airline_access = airline_access.Substring(0, airline_access.Length - 1);
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("select airline_name,airline_text_code,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["airline_text_code"]) + "," + Convert.ToString(dr["Airline_name"]))));
                }
                cmd.Dispose();
                dr.Close();
             }
            catch (Exception eror)
            {
                string st = eror.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
                
            }
        }

    }
    protected void btnLoad_Click(object sender, EventArgs e)
    {
        string Table_show = "";
        string[] airline_city = ddl_airline_city.SelectedValue.ToString().Split(',');
        string[] date = DropDownList2.SelectedItem.Text.Split('-');
        string from = FormatDateMM(date[0]);
        string to = FormatDateMM(date[1]);
        string company_name = "";
        string airline_text_code = "";
        string airline_name = "";
        string curr_id = "";
        string ID_type = "";
        decimal total_DR = 0;
        decimal total_CR = 0;
        string vocherDate = FormatDateMM(txtValidFrom.Text);
        airline_det_id = Convert.ToInt32(airline_city[1]);
        string table = "";
        string display = "";
        int count = 1;
        int page = 0;
        //*********unused******************
        string VchNo = "";
        //VchNo= altxtcd&"/"&agentcd&"/"&DateFormat(from,"ddmmyy")&"-"&DateFormat(to,"ddmmyy")
        
        string bill_type = "";
        //bill_type=altxtcd&" CSR #DateFormat(from,'dd-mmm-yyyy')# - #DateFormat(to,'dd-mmm-yyyy')#
      
        string narration = "";
        //narration="CSR for the period #DateFormat(from,'dd-mmm-yyyy')# - #DateFormat(to,'dd-mmm-yyyy')#
      
        decimal curr_frt_amt = 0;
        //curr_frt_amt=total_freight_pp+total_dueCarrier-tot_frt_diff
        //*********unused******************
        Label2.Text = "";
        Label2.Text = "";
        string query = "select CSR_SNo,CSR_No,CSR_Detail_ID,Amount_Including_TDS,Agent_ID,Agent_Code,Agent_Name,Agent_Address,Freight_Amount_PP as Freight_Amount,Total_DueCarrier,Freight_Diff_Amount,Agent_Expenses,IATA_Commission,Amount_Excluding_TDS,TDS_Rate,Surcharge_Rate,Surcharge_Rate,Education_Cess_Rate,TDS_Amount,Surcharge_Amount,Incentive_Amount,Education_Cess_Amount,Amount_Including_TDS,Paid_Status,Short_Excess_Amount from csr_details where airline_detail_id=" + airline_det_id + " and csr_from='" + from + "' and csr_to='" + to + "'and tally_transfer_status=14 order by Agent_name";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            tran = con.BeginTransaction(); 
            cmd = new SqlCommand(query, con,tran);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet("Table1");
            da.Fill(ds);
            cmd.Dispose();
            foreach (DataRow drow in ds.Tables[0].Rows)
            {
                page++; ;
                query = "select Company_name,airline_name,airline_text_code from company_master inner join airline_master on airline_master.company_id=company_master.company_id inner join airline_detail on airline_detail.airline_id=airline_master.airline_id  where airline_detail_id=" + airline_det_id + "";
                cmd = new SqlCommand(query, con, tran);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    company_name = dr["Company_name"].ToString().Replace("&","AND") ;
                    airline_text_code = dr["airline_text_code"].ToString();
                    airline_name = dr["airline_name"].ToString();
                }
                dr.Close();
                cmd.Dispose();
               
                string[] from1 = from.Split('/');
                string[] to1=to.Split('/');

                string from2 = from1[1] + from1[0] + from1[2].Substring(2,2)  ;
                string to2 =to1[1]+to1[0]+to1[2].Substring(2,2) ;

                VchNo = airline_text_code + "/" + drow["Agent_Code"].ToString() + "/" + from2 + "-" + to2;
                
                bill_type = airline_text_code + " CSR " + getMonthName(from) + " - " + getMonthName(to);

                narration = "CSR for the period " + getMonthName(from) + " - " + getMonthName(to);
                curr_frt_amt = Convert.ToDecimal(drow["Freight_Amount"].ToString()) + Convert.ToDecimal(drow["Total_DueCarrier"].ToString()) - Convert.ToDecimal(drow["Incentive_Amount"].ToString());

                if (curr_frt_amt > 0)
                {
                    ID_type = "CR";
                }
               
                else
                {
                    ID_type = "DR";
                }
                if (Convert.ToDecimal(drow["Amount_Including_TDS"].ToString()) > 0)
                {
                    curr_id = "DR";

                    query = @"insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','" + vocherDate + "','" + drow["Agent_Name"].ToString().Replace("&", "And") + "'," + Convert.ToDecimal(drow["Amount_Including_TDS"].ToString()) + ",'" + curr_id + "','" + bill_type + "','31 Days','" + narration + "','u')";
                    cmd = new SqlCommand(query, con, tran);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();



                    total_DR = total_DR + Convert.ToDecimal(drow["Amount_Including_TDS"].ToString());


                    //'CA/A00005/010607-150607', 'ASIATIC LOGISTICS PVT. LTD.', '21523', 'DR'
                    Table_show += "'" + VchNo + ", " + drow["Agent_Name"].ToString().Replace("&", "And") + "'," + "'" + drow["Amount_Including_TDS"].ToString() + "'," + "'" + curr_id + "'<br>";
                    /////////////////Last Print/////////////////////////////
                    query = "insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','" + vocherDate + "','FREIGHT A/C'," + curr_frt_amt + ",'" + ID_type + "','" + bill_type + "','31 Days','" + narration + "','u')";
                    cmd = new SqlCommand(query, con, tran);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    if (ID_type == "CR")
                    {
                        total_CR = total_CR + curr_frt_amt;

                    }
                    else 
                    {
                        total_DR = total_DR + curr_frt_amt;
                    }
                    Table_show += "'" + VchNo + ",'FREIGHT A/C'," + "'" + curr_frt_amt + "'," + "'" + ID_type + "'<br>";
                    /////////////////Last Print/////////////////////////////

                    query = "insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','" + vocherDate + "','IATA COMMISSION'," + Convert.ToDecimal(drow["IATA_Commission"].ToString()) + ",'DR','" + bill_type + "','31 Days','" + narration + "','u')";
                    cmd = new SqlCommand(query, con, tran);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    total_DR = total_DR + Convert.ToDecimal(drow["IATA_Commission"].ToString());
                    Table_show += "'" + VchNo + ",'IATA COMMISSION'," + "'" + drow["IATA_Commission"].ToString() + "','DR'<br>";
                }
                else
                {
                    curr_id = "CR";
                    /////////////////Last Print/////////////////////////////
                    query = "insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','"+vocherDate+"','IATA COMMISSION'," + Convert.ToDecimal(drow["IATA_Commission"].ToString()) + ",'DR','" + bill_type + "','31 Days','" + narration + "','u')";
                    cmd = new SqlCommand(query, con, tran);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    total_DR = total_DR + Convert.ToDecimal(drow["IATA_Commission"].ToString());
                    Table_show += Label2.Text + "'" + VchNo + ",'IATA COMMISSION'," + "'" + drow["IATA_Commission"].ToString() + "'," + "'DR'<br>";

                    query = "insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','"+vocherDate+"','FREIGHT A/C'," + curr_frt_amt  + ",'" + curr_id + "','" + bill_type + "','31 Days','" + narration + "','u')";
                    cmd = new SqlCommand(query, con, tran);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    /////////////////Last Print/////////////////////////////
                    if (curr_id == "CR")
                    {
                        total_CR = total_CR + curr_frt_amt;

                    }
                    else
                    {
                        total_DR = total_DR + curr_frt_amt;
                    }

                    Table_show += "'" + VchNo + ", 'FREIGHT A/C'," + "'" + curr_frt_amt + "'," + "'" + curr_id + "'<br>";
                    /////////////////Last Print/////////////////////////////
                    query = "insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','"+vocherDate+"','" + drow["Agent_Name"].ToString().Replace("&","And").Replace("&","And") + "'," + Convert.ToDecimal(drow["Amount_Including_TDS"].ToString()) + ",'" + curr_id + "','" + bill_type + "','31 Days','" + narration + "','u')";
                    cmd = new SqlCommand(query, con, tran);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                   
                    if (curr_id == "CR")
                    {
                        total_CR = total_CR + Math.Abs(Convert.ToDecimal(drow["Amount_Including_TDS"].ToString()));

                    }
                    else
                    {
                        total_DR = total_DR + Math.Abs(Convert.ToDecimal(drow["Amount_Including_TDS"].ToString()));
                    }
                    Table_show += "'" + VchNo + ", " + drow["Agent_Name"].ToString().Replace("&", "And") + "'," + "'" + Math.Abs(Convert.ToDecimal(drow["Amount_Including_TDS"].ToString())) + "'," + "'" + curr_id + "'<br>";
                }
                /////////////////Last Print/////////////////////////////
                if (Convert.ToDecimal(drow["Agent_Expenses"].ToString()) > 0)
                {
                    query = "insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','"+vocherDate+"','AGENT EXP.'," + Convert.ToDecimal(drow["Agent_Expenses"].ToString()) + ",'DR','" + bill_type + "','31 Days','" + narration + "','u')";
                    cmd = new SqlCommand(query, con, tran);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    total_DR = total_DR + Convert.ToDecimal(drow["Agent_Expenses"].ToString());
                    Table_show += "'" + VchNo + ", 'AGENT EXP.'," + "'" + drow["Agent_Expenses"].ToString() + "'," + "'DR'<br>";

                }
                query = "insert into AscentImport(Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st)values('" + company_name + "','" + VchNo + "','Sales','" + vocherDate + "', 'TDS - COMMISSION'," + Convert.ToDecimal(drow["TDS_Amount"].ToString()) + ",'CR','" + bill_type + "','31 Days','" + narration + "','u')";
                cmd = new SqlCommand(query, con, tran);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                total_CR = total_CR + Convert.ToDecimal(drow["TDS_Amount"].ToString());
                /////////////////Last Print/////////////////////////////
                Table_show += "'" + VchNo + " ,'TDS - COMMISSION'" + "'," + "'" + Convert.ToDecimal(drow["TDS_Amount"].ToString()) + "'," + "'CR'<br>";


                if (total_DR == total_CR)
                {
                    Table_show += "DR - CR =" + total_DR + "-" + total_CR + "<br>";
                    total_CR = 0;
                    total_DR = 0;
                }
                else
                {
                    decimal diff = total_DR - total_CR;
                    Table_show += "<font color=red>DR - CR are Not Equal  (" + total_DR + "-" + total_CR + ")=" + diff + "</font><br>";
                    Label3.CssClass = "error";
                    Label3.Text = "Sorry You Cannot Transfer the Data As there are errors in the calculations";
                    Button1.Visible = false;
                    flag = true;
                    total_CR = 0;
                    total_DR = 0;
                }

                Table_show += "<br><center>" + page + "</center><br><br>";

            }
            Label2.Text = Table_show;
            query = "select csr_no,Agent_name,Amount_Including_TDS from csr_details where airline_detail_id=" + airline_det_id + " and csr_from='" + from + "' and csr_to='" + to + "'and tally_transfer_status=14 order by Agent_name";
           
            cmd = new SqlCommand(query,con,tran);
            dr = cmd.ExecuteReader();
            table = "<table align=center width=90% border=1><tr class=h1><td align=center class=boldtext>Airline Code :" + airline_city[2] + " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      Period " + DropDownList2.SelectedItem.Text + "<td></tr><tr><td><table width=100% border=1><tr><td>S.No.</td><td align=center>CSR No</td><td align=center>Agent</td><td align=center>Amount Rec./<font color=red>Payable</font></td></tr>";
             decimal Amount_Including_TDS=0;
            while (dr.Read())
            {
                Amount_Including_TDS = Convert.ToDecimal(dr["Amount_Including_TDS"].ToString());
                if (Amount_Including_TDS > 0)
                {
                    table += "<tr class=text><td align=center >" + count + "</td><td >" + dr["csr_no"].ToString() + "</td><td>" + dr["Agent_name"].ToString() + "</td><td align=right>" + Amount_Including_TDS + "</td></tr>";
                }
                else
                {

                    table += "<tr class=text><td align=center >" + count + "</td><td >" + dr["csr_no"].ToString() + "</td><td>" + dr["Agent_name"].ToString() + "</td><td align=right class=error>" + Math.Abs( Amount_Including_TDS) + "</td></tr>";
                }
                count++;
            }
            dr.Close();
            cmd.Dispose();
            table += "</table></td></tr></table>";

            query = "update csr_details set tally_transfer_status=13 where airline_detail_id=" + airline_det_id + " and csr_from='" + from + "' and csr_to='" + to + "'and tally_transfer_status=14";
            //where CSR_Detail_ID=" + Convert.ToInt64(drow["CSR_Detail_ID"].ToString ()) + "";
            cmd = new SqlCommand(query, con, tran);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
          
            Label2.Text += "<br>" + table; 
            tran.Commit();
            if (flag == false)
            {
                Button1.Visible = true;

                btnLoad.Visible = false;
            }
           // Label2.Text = display;

            //select Company_name,airline_name,belongs_to_city from company_master inner join airline_master on airline_master.company_id=company_master.company_id inner join airline_detail on airline_detail.airline_id=airline_master.airline_id  where airline_detail_id=147
        }
        catch (Exception eror)
        {
            eror.ToString();
            tran.Rollback(); 
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
           
        }
       btnLoad.Visible = false;
       // btnLoad.Enabled = false; 
    }
    protected void ddl_airline_city_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label2.Text = "";
        btnLoad.Visible = true;
        Button1.Visible = false;
       // btnLoad.Enabled = true; 
        DropDownList2.Items.Clear();
        if (ddl_airline_city.SelectedValue != "Select Airline")
        {
            string[] airline_city = ddl_airline_city.SelectedValue.ToString().Split(',');
            airline_det_id = Convert.ToInt32(airline_city[1]); 
            string query = "select distinct convert(varchar,csr_from,103) as  csr_from,convert(varchar,csr_to,103) as csr_to from csr_details where airline_detail_id=" + airline_city[1] + " and tally_transfer_status=14";
            try
            {
                string from = "";
                string to = "";
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand(query, con);
                dr = cmd.ExecuteReader();
                DropDownList2.Items.Clear();
                DropDownList2.Items.Add(new ListItem("Select Period", "0"));
                while (dr.Read())
                {
                    from = dr["csr_from"].ToString().Trim();
                    to = dr["csr_to"].ToString().Trim();
                    //string[] from1 = from.Split('/');
                    //string[] to1 = to.Split('/');
                    //from = from1[0] + from1[1] + from1[2];
                    //to=to1[0]+to1[1]+to1[2];
                    DropDownList2.Items.Add(from + "-" + to);
                }
                dr.Close();
            }
            catch (Exception eror)
            {

                eror.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
               

            }
        }
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDate(string date)
    {
        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM  + strDD   + strYYYY;
        return strMMDDYYYY;
    }
    public string getMonthName(string month)
    {
        string[] mon = month.Split('/');
        
        string ret_date = "";

       string  strY = mon[2];
       
        switch (Convert.ToInt16(mon[0]))
        {
            case 1:
                ret_date = "Jan";
                break;
            case 2:
                ret_date = "Feb";
                break;
            case 3:
                ret_date = "Mar";
                break;
            case 4:
                ret_date = "April";
                break;
            case 5:
                ret_date = "May";
                break;
            case 6:
                ret_date = "June";
                break;
            case 7:
                ret_date = "July";
                break;
            case 8:
                ret_date = "Aug";
                break;
            case 9:
                ret_date = "Sep";
                break;
            case 10:
                ret_date = "Oct";
                break;
            case 11:
                ret_date = "Nov";
                break;
            case 12:
                ret_date = "Dec";
                break;
        }
        return mon[1]+"-"+ret_date+"-" + strY;
    }


    public void ExportToTallyDatabase()
    {
        string Airline_details = ddl_airline_city.SelectedValue;

        string[] air = Airline_details.Split(',');

        string Query = "select Name,VchNo,Vchtype,Vchdt,ledgerName,amount,id,billType,days,narration,st from ascentImport where vchno like '"+air[2]+"%'";
        DataTable dt = dw.GetAllFromQuery(Query);
        try
        {
            con = new SqlConnection(strCon1);
            con.Open();
            tran = con.BeginTransaction();

            foreach (DataRow dro in dt.Rows)
            {
                Query = "insert into AscentImport(Company,VchNo,Vchtype,[Vch dt],[ledger code],[ledger name],amount,[bill type],days,narration,st) values('" + dro["Name"].ToString() + "','" + dro["VchNo"].ToString() + "','" + dro["Vchtype"].ToString() + "','" + dro["Vchdt"].ToString() + "','" + dro["ledgerName"].ToString() + "'," + dro["amount"].ToString() + ",'" + dro["id"].ToString() + "','" + dro["billType"].ToString() + "','" + dro["days"].ToString() + "','" + dro["narration"].ToString() + "','" + dro["st"].ToString() + "')";
                cmd = new SqlCommand(Query, con, tran);
                cmd.ExecuteNonQuery();
            }
            tran.Commit();
            con.Close();
            Button1.Visible = false ;
        }
        catch (Exception)
        {
            tran.Rollback();
            con.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ExportToTallyDatabase();
        Label2.Text = "<center><h3>Tansfer Completed</h3></center>";
        btnLoad.Visible = true;
    }
}
