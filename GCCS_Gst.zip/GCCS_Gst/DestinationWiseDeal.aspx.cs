﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class DestinationWiseDeal : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    SqlCommand com;
    SqlDataReader red;
    SqlParameter pram;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    DisplayWrap dw = new DisplayWrap();
    int Dest_group = 0;
    string table1 = "";
    string flag1 = "0";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnadd.Attributes.Add("onclick", "return CheckEmpty();");
            btnUpdate.Attributes.Add("onclick", "return CheckEmpty();");

            if (!IsPostBack)
            {
                //VDate.Style.Add("display", "none");
                //VDate1.Style.Add("display", "none");
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
                if (Request.QueryString.Count > 0)
                {
                    LoadData();

                    //if (Request.QueryString["f"].ToString() == "d")
                    //{
                    //    btnadd.Visible = false;
                    //    btnDelete.Visible = true;
                    //    btnUpdate.Visible = false;
                    //    btncancel.Visible = false;
                    //    btnBack.Visible = true;

                    //}
                    //if (Request.QueryString["f"].ToString() == "u")
                    //{
                    btnadd.Visible = false;
                    btnDelete.Visible = false;
                    btnUpdate.Visible = true;
                    btncancel.Visible = false;
                    btnBack.Visible = true;
                    ddlShip.Enabled = false;
                    //}

                }
                else
                {
                    FillAirline();
                    FillDataShipment();
                    Hide();
                    TDSec.Style.Add("display", "none");
                    TDSecHead.Style.Add("display", "none");
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    btnBack.Visible = false;
                }

            }

        }

    }

    public void FillAirline()
    {
        string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in(" + Airline_Access + ") order by Airline_Name", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlAirlineName.DataSource = red;
        ddlAirlineName.DataTextField = "Airline";
        ddlAirlineName.DataValueField = "Airline_Detail_ID";
        ddlAirlineName.DataBind();
        con.Close();
        cmd.Dispose();
        ddlAirlineName.Items.Insert(0, new ListItem("Select Airline", "0"));
    }
    public string Rights()
    {
        string Access = "";
        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(sql_Access, con);

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Access = dr.GetValue(0).ToString();
                }

            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return Access;
    }
    protected void rbtnSector_CheckedChanged(object sender, EventArgs e)
    {
        lblError.Text = "";
        rbtnDes.Checked = false;
        rbtnSector.Checked = true;
        lstSectorData(ddlAirlineName.SelectedValue.ToString(), true);
        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;
        //lblSec.Text = "Sector code";

    }
    protected void rbtnDes_CheckedChanged(object sender, EventArgs e)
    {
        if (ddlShip.SelectedValue == "0")
        {

            //ClientScript.RegisterStartupScript(this.Page, "A", "<script>alert('Please select Shipment Type first');</script>", true);
            //lblError.Visible = true;

            rbtnDes.Checked = false;
            if (txtDisValidFrom.Text == "")
            {
                string strScript = "alert('Please select shipment type and enter valid from date.');";

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
            }
            else
            {
                string strScript = "alert('Please select shipment type.');";

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
            }


        }
        else
        {
            lblError.Text = "";
            rbtnDes.Checked = true;
            rbtnSector.Checked = false;
            lstSectorData(ddlAirlineName.SelectedValue.ToString(), false);
            UnHide();
        }
        //lblSec.Text = "Destination Code";


    }
    protected void FillDataShipment()
    {
        ddlShip.Items.Clear();
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select distinct shipment_id,shipment_name from Shipment_master order by shipment_name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlShip.Items.Add(new ListItem("--Select--", "0"));
            while (dr.Read())
            {
                ddlShip.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
            }
            dr.Close();
            ddlShip.SelectedValue = "0";
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void lstSectorData(string airlineDetailID, bool flag)
    {
        Panel1.Visible = true;
        gvSlab.Visible = true;
        rbtnDes.Checked = false;
        rbtnSector.Checked = flag;
        string searchString = null;
        con = new SqlConnection(strCon);
        if (rbtnSector.Checked == true)
        {
            searchString = "Select distinct asm.sector_name,asm.Sector_ID from airline_sector_master asm inner join Airline_Master am on am.Airline_ID=asm.Airline_ID inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join airline_sector_details asd on asd.sector_id=asm.sector_id where ad.Airline_Detail_ID='" + airlineDetailID + "' and valid_from>='" + ConvertDate1(txtDisValidFrom.Text) + "'";
        }
        else
        {
            if (Request.QueryString.Count > 0)
            {
                //searchString = "Select distinct dm.Destination_Code,ar.Destination from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ad.Airline_Detail_ID='" + airlineDetailID + "'AND dm.Destination_ID NOT IN (SELECT destination FROM db_owner.GD_Dest_Master WHERE dest_group!='" + Convert.ToInt32(Request.QueryString["dest_group"].ToString()) + "' and Shipment_ID!='" + Request.QueryString["sid"].ToString() + "'  )";
                searchString = "Select distinct dm.Destination_Code,ar.Destination from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ad.Airline_Detail_ID='" + airlineDetailID + "'";
            }
            else
            {
                searchString = "Select distinct dm.Destination_Code,ar.Destination from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ad.Airline_Detail_ID='" + airlineDetailID + "' AND dm.Destination_ID NOT IN (SELECT destination FROM db_owner.GD_Dest_Master WHERE Airline_Detail_ID='" + airlineDetailID + "' and Shipment_ID ='" + ddlShip.SelectedValue + "' )";
            }
        }
        try
        {
            con.Open();
            com = new SqlCommand(searchString, con);
            SqlDataReader dr = com.ExecuteReader();
            int p = 0;
            if (rbtnSector.Checked == true)
            {
                chkSec.Items.Clear();
                chkBoxList.Items.Clear();
                if (dr.HasRows)
                {
                    chkSec.Visible = true;
                    while (dr.Read())
                    {
                        chkSec.Items.Add(new ListItem(" " + dr[0].ToString(), dr[1].ToString()));
                        p = p + 1;
                    }
                }
                else
                {
                    Hide2();
                    lblError.Text = "Sector not added for selected airline,Please select destination wise slab.";
                    lblError.Visible = true;

                }
            }
            else
            {
                chkBoxList.Items.Clear();
                chkSec.Items.Clear();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        chkBoxList.Items.Add(new ListItem(" " + dr[0].ToString(), dr[1].ToString()));
                        p = p + 1;
                    }
                }
                else
                {
                    gvSlab.Visible = false;
                    flag1 = "1";
                }
            }
            HiddSec.Value = p.ToString();
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void ddlAirlineName_SelectedIndexChanged(object sender, EventArgs e)
    {
        //VDate.Style.Add("display", "display");
        //VDate1.Style.Add("display", "display");
        lblError.Text = "";
        rbtnDes.Checked = false;
        rbtnSector.Checked = false;
        Hide();
        chkBoxList.Items.Clear();
        string query = "select * from Flight_Master where airline_detail_id='" + ddlAirlineName.SelectedValue.ToString() + "'";
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            //ddlFlight.Items.Clear();
            if (dr.HasRows)
            {

                //ddlFlight.Items.Add(new ListItem("-Select Flight No-", "0"));
                //ddlFlight.Items.Add(new ListItem("All Flights", "0"));
                //while (dr.Read())
                //{
                //    ddlFlight.Items.Add(new ListItem(dr["Flight_No"].ToString(), dr["Flight_ID"].ToString()));
                //}

            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        //lstSectorData(ddlAirlineName.SelectedValue.ToString(),false);
        SlabData(ddlAirlineName.SelectedValue.ToString(), 0);
        if (ddlAirlineName.SelectedValue.ToString() != "0")
        {
            TDSec.Style.Add("display", "display");
            TDSecHead.Style.Add("display", "display");
        }
        //Hide();
    }
    protected void SlabData(string airlineID, int DestGroup)
    {
        string Inc = "";
        string Comm = "";
        string Amt = "";
        con = new SqlConnection(strCon);
        con.Open();
        if (DestGroup == 0)
            com = new SqlCommand("select s.slab_name,s.slab_id,0 as SpotRate,0 AS Price_Value,0 AS IataCom,0 AS CommInc from slab_master s inner join airline_slab a on a.slab_id=s.slab_id where a.airline_detail_id='" + airlineID + "' order by s.slab_ID", con);
        else
            com = new SqlCommand("select s.slab_name,s.slab_id,gsv.Price_Value,ISNULL(gsv.Iata_Comm,0) AS IataCom,ISNULL(gsv.Comm_Inc,0) AS CommInc,ISNULL(gsv.SpotRate,0) AS SpotRate from db_owner.Slab_Master s inner join db_owner.GD_rate_Master gsv ON s.Slab_ID = gsv.Slab_ID WHERE gsv.GD_Rate_ID IN(SELECT TOP 1 GD_Rate_ID FROM db_owner.GD_Dest_Master WHERE Dest_Group=" + DestGroup + ")", con);
        SqlDataReader dr = com.ExecuteReader();
        gvSlab.DataSource = dr;
        gvSlab.DataBind();

        //*******Spot Calculation For Grid****************
        for (int i = 0; i < gvSlab.Rows.Count; i++)
        {
            GridViewRow gvrow = (GridViewRow)gvSlab.Rows[i];
            TextBox txtComm = (TextBox)gvrow.FindControl("txtComm");
            TextBox txtINC = (TextBox)gvrow.FindControl("txtInc");
            TextBox txtValue = (TextBox)gvrow.FindControl("txtValue");
            TextBox txtspotrate = (TextBox)gvrow.FindControl("txtspotrate");

            txtComm.Attributes.Add("onblur", "return spotcalculation('" + txtComm.ClientID + "','" + txtINC.ClientID + "','" + txtValue.ClientID + "','" + txtspotrate.ClientID + "');");
            txtINC.Attributes.Add("onblur", "return spotcalculation1('" + txtComm.ClientID + "','" + txtINC.ClientID + "','" + txtValue.ClientID + "','" + txtspotrate.ClientID + "');");
            //txtValue.Attributes.Add("onkeydown", "return spotcalculation2('" + txtComm.ClientID + "','" + txtINC.ClientID + "','" + txtValue.ClientID + "'); ");

            txtspotrate.Attributes.Add("onblur", "return spotcalculation2('" + txtComm.ClientID + "','" + txtINC.ClientID + "','" + txtValue.ClientID + "','" + txtspotrate.ClientID + "'); ");


            txtValue.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false);");


        }


        //}
        dr.Close();
        com.Dispose();
        con.Close();
    }


    protected void gridview1_rowdatabound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {

        DataTable dtDestgroup = dw.GetAllFromQuery("select ISNULL(max(dest_group),0) as dest_group from GD_Dest_Master ");
        if (dtDestgroup.Rows.Count > 0 && dtDestgroup.Rows[0]["dest_group"].ToString() != "")
        {


            Dest_group = int.Parse(dtDestgroup.Rows[0]["dest_group"].ToString()) + 1;
        }


        string Destination = "";
        string ExistDest = "";
        string Exist = "";
        lblError.Text = "";

        int result = 0;
        for (int x = 0; x < chkBoxList.Items.Count; x++)
        {
            if (chkBoxList.Items[x].Selected == true)
            {
                con = new SqlConnection(strCon);
                SqlTransaction tr = null;
                try
                {
                    string DestinationID = chkBoxList.Items[x].Value;
                    string city = "";
                    string[] Origin = ddlAirlineName.SelectedItem.Text.Split('-');
                    string Org = Origin[1].ToString().Trim();
                    DataTable dtorigin = dw.GetAllFromQuery("select city_id,city_code from city_master where city_name='" + Org + "'");
                    if (dtorigin.Rows.Count > 0)
                    {
                        //city = dtorigin.Rows[0]["city_code"].ToString();
                        city = dtorigin.Rows[0]["city_id"].ToString();
                    }

                    int? scID = null;
                    con.Open();
                    tr = con.BeginTransaction();
                    com = new SqlCommand("DestinationWiseDeal_Add", con, tr);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@AirLine_Detail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
                    com.Parameters.AddWithValue("@Shipment_ID", int.Parse(ddlShip.SelectedValue.ToString()));
                    //com.Parameters.AddWithValue("@Destination_Codes", chkBoxList.Items[x].Text.Trim());
                    com.Parameters.AddWithValue("@Destination", DestinationID);
                    com.Parameters.AddWithValue("@Origin", city);
                    com.Parameters.AddWithValue("@Special_Commodity_ID", 1);
                    com.Parameters.AddWithValue("@status", 2);
                    com.Parameters.AddWithValue("@ValidFrom", DateTime.Parse(ConvertDate1(txtDisValidFrom.Text)));
                    if (txtDisValidTo.Text == "")
                    {
                        com.Parameters.AddWithValue("@ValidTo", DBNull.Value);
                    }
                    else
                    {
                        com.Parameters.AddWithValue("@ValidTo", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
                    }
                    com.Parameters.AddWithValue("@EnteredBY", Session["EMailID"].ToString());
                    com.Parameters.AddWithValue("@EnteredDate", DateTime.Today);



                    com.Parameters.AddWithValue("@dest_group", Dest_group);


                    result = com.ExecuteNonQuery();
                    for (int i = 0; i < gvSlab.Rows.Count; i++)
                    {
                        GridViewRow gr = gvSlab.Rows[i];
                        Label slabID = (Label)gr.FindControl("lblSlabID");
                        TextBox txtValue = (TextBox)gr.FindControl("txtValue");
                        TextBox Iata_Comm = (TextBox)gr.FindControl("txtComm");
                        TextBox Comm_Inc = (TextBox)gr.FindControl("txtInc");
                        TextBox SpotRate = (TextBox)gr.FindControl("txtspotrate");
                        com = new SqlCommand("DestinationWiseDealTrans_Add", con, tr);
                        com.CommandType = CommandType.StoredProcedure;
                        //com.Parameters.AddWithValue("@GD_Rate_ID", result);
                        com.Parameters.AddWithValue("@Slab_ID", slabID.Text);
                        com.Parameters.AddWithValue("@Price_Value", Convert.ToDecimal(txtValue.Text == "" ? "0" : txtValue.Text));
                        com.Parameters.AddWithValue("@AirLine_Detail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
                        com.Parameters.AddWithValue("@Iata_Comm", Convert.ToDecimal(Iata_Comm.Text == "" ? "0" : Iata_Comm.Text));
                        com.Parameters.AddWithValue("@Comm_Inc", Convert.ToDecimal(Comm_Inc.Text == "" ? "0" : Comm_Inc.Text));
                        com.Parameters.AddWithValue("@Updated_By", Session["EMailID"].ToString());
                        com.Parameters.AddWithValue("@Updated_On", DateTime.Now);
                        com.Parameters.AddWithValue("@SpotRate", Convert.ToDecimal(SpotRate.Text == "" ? "0" : SpotRate.Text));


                        //if ((txtValue.Text == "" ? "0" : txtValue.Text) != "0")
                        result = com.ExecuteNonQuery();
                    }

                    if (result == -1)
                    {
                        lblError.Text = "Slab Value Can't be Added Due to Some Error";
                        tr.Rollback();
                    }

                    tr.Commit();
                    con.Close();
                    if (result == 1)
                        lblError.Text = Destination + ": Destination Slab Value Added Successfully.";
                    if (result == 1 && Exist != "")
                        lblError.Text = Destination + ": Destination Slab Value Added Successfully." + "<br>" + Exist + ": Destination already Exists.";
                    if (result == 0 && Exist != "")
                        lblError.Text = Exist + ": Destination already Exists.";

                }
                catch (SqlException se)
                {
                    string err = se.Message;
                    tr.Rollback();
                }

                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
                if (result == 1)
                {
                    //Session["msg"] = Destination + ": Destination Discounted Value Added Successfully.";
                    //Response.Redirect("FlightDiscountingShow.aspx?id=a");


                }
                if (result == 1 && Exist != "")
                {
                    // Session["msg"] = Destination + ": Destination Discounted Value Added Successfully." + "<br>" + Exist + ": Destination already Exists.";
                    //Response.Redirect("DestinationWiseDealShow.aspx?id=a");
                }


            }
            //string strScript = "alert('Record Added successfully.');";

            //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox2", strScript, true);
        }
        //Response.Redirect("FlightDiscountingShow.aspx?id=a");

        string strScript = "alert('Record Added successfully.');location.replace('ViewDestinationWiseDeal.aspx');";

        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        //Response.Redirect("DestinationWiseDeal.aspx");

    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewDestinationWiseDeal.aspx");

    }
    protected string CheckExistsDestination(string Dest)
    {
        string result = "";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("CheckExistDestination", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@airlineDetail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
        //com.Parameters.AddWithValue("@Flight_ID", int.Parse(ddlFlight.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@Shipment_ID", int.Parse(ddlShip.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@validFrom", DateTime.Parse(ConvertDate1(txtDisValidFrom.Text)));
        com.Parameters.AddWithValue("@Validto", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
        com.Parameters.AddWithValue("@Destination", Dest.Trim());

        SqlDataReader dr = com.ExecuteReader();

        while (dr.Read())
        {
            result = dr["Data"].ToString();
        }

        dr.Close();
        com.Dispose();
        con.Close();
        return result;

    }

    protected void sectorDestination()
    {
        string flag = "";
        con = new SqlConnection(strCon);
        con.Open();
        SqlDataReader dr = null;
        chkBoxList.Items.Clear();
        for (int k = 0; k < chkSec.Items.Count; k++)
        {
            if (chkSec.Items[k].Selected == true)
            {
                flag = "true";

                com = new SqlCommand("select a.destination_id,b.destination_code from airline_sector_details a inner join destination_master b on b.destination_id=a.destination_id  where sector_id=" + chkSec.Items[k].Value + " ", con);
                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    chkBoxList.Items.Add(new ListItem(dr["destination_code"].ToString(), dr["destination_id"].ToString()));

                }
                dr.Dispose();
                com.Dispose();


            }

        }

        con.Close();
        for (int k = 0; k < chkBoxList.Items.Count; k++)
        {
            chkBoxList.Items[k].Selected = true;

        }

    }
    protected void chkSec_SelectedIndexChanged(object sender, EventArgs e)
    {
        sectorDestination();

        if (chkBoxList.Items.Count > 0)
            UnHide();
        else
        {
            Hide2();
            chkSec.Visible = true;
        }
        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;
    }
    protected void UnHide()
    {
        //VDate.Style.Add("display", "display");
        //VDate1.Style.Add("display", "display");
        TDSlab.Style.Add("display", "display");
        btnadd.Visible = true;
        btncancel.Visible = true;
        chkSec.Visible = true;
        if (flag1 == "1")
        {
            rbtnDSelect.Visible = false;
            rbtnSelectAll.Visible = false;
            btnadd.Visible = false;
            string strScript = "alert('No Pending destination exist.');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        }
        else
        {
            rbtnDSelect.Visible = true;
            rbtnSelectAll.Visible = true;
        }

    }
    protected void Hide()
    {
        //VDate.Style.Add("display", "none");
        //VDate1.Style.Add("display", "none");
        TDSlab.Style.Add("display", "none");

        TDSec.Style.Add("display", "none");
        TDSecHead.Style.Add("display", "none");
        btnadd.Visible = false;
        btncancel.Visible = false;
        chkSec.Visible = false;
        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;


    }
    protected void Hide2()
    {
        //VDate.Style.Add("display", "none");
        //VDate1.Style.Add("display", "none");
        TDSlab.Style.Add("display", "none");

        //TDSec.Style.Add("display", "none");
        // TDSecHead.Style.Add("display", "none");
        btnadd.Visible = false;
        btncancel.Visible = false;
        chkSec.Visible = false;

        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;


    }


    protected void BindFlight(string airlineID)
    {
        chkBoxList.Items.Clear();
        string query = "select * from Flight_Master where airline_detail_id='" + airlineID + "'";
        con = new SqlConnection(strCon);
        try
        {
            //con.Open();
            //SqlCommand cmd = new SqlCommand(query, con);
            //SqlDataReader dr = cmd.ExecuteReader();
            //ddlFlight.Items.Clear();
            //if (dr.HasRows)
            //{

            //    ddlFlight.Items.Add(new ListItem("-Select Flight No-", "0"));
            //    ddlFlight.Items.Add(new ListItem("All Flights", "0"));
            //    while (dr.Read())
            //    {
            //        ddlFlight.Items.Add(new ListItem(dr["Flight_No"].ToString(), dr["Flight_ID"].ToString()));
            //    }

            //}
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    ///////////////
    //Delete Function imp.

    protected void LoadData()
    {
        FillAirline();
        FillDataShipment();
        //filldestination();
        if (Request.QueryString.Count > 0)
        {
            string airLIne_ID = Request.QueryString["AirlineID"].ToString();
            // string flght_ID = Request.QueryString["flt"].ToString();
            string shipment_ID = Request.QueryString["sid"].ToString();
            string destination_Code = Request.QueryString["d"].ToString();
            string dest_group = Request.QueryString["dest_group"].ToString();
            string validFrom = Request.QueryString["ValidFrom"].ToString();
            //string validto = Request.QueryString["vt"].ToString();
            string[] dest = Request.QueryString["d"].ToString().Split(',');
            for (int i = 0; i < ddlAirlineName.Items.Count; i++)
            {
                if (ddlAirlineName.Items[i].Value == airLIne_ID)
                    ddlAirlineName.Items[i].Selected = true;
            }



            for (int z1 = 0; z1 < ddlShip.Items.Count; z1++)
            {

                ddlShip.Items[z1].Selected = false;

            }
            for (int z = 0; z < ddlShip.Items.Count; z++)
            {
                if (ddlShip.Items[z].Value == shipment_ID)
                    ddlShip.Items[z].Selected = true;

            }
            TDSec.Style.Add("display", "display");
            TDSecHead.Style.Add("display", "display");

            rbtnDes.Checked = true;
            rbtnDes.Checked = true;
            rbtnSector.Checked = false;
            lstSectorData(airLIne_ID, false);
            UnHide();
            for (int k = 0; k < chkBoxList.Items.Count; k++)
            {
                for (int n = 0; n < dest.Length; n++)
                {
                    if (chkBoxList.Items[k].Text.Trim() == dest[n].ToString().Trim())
                        chkBoxList.Items[k].Selected = true;
                }

            }

            txtDisValidFrom.Text = DateTime.Parse(validFrom).ToString("dd/MM/yyyy");
            //txtDisValidTo.Text = DateTime.Parse(validto).ToString("dd/MM/yyyy");

            SlabData(airLIne_ID, Convert.ToInt32(dest_group));


        }
        ddlAirlineName.Enabled = false;

    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {

        con = new SqlConnection(strCon);
        SqlTransaction tr = null;
        bool flag;
        con.Open();
        tr = con.BeginTransaction();

        DataTable dtDestgroup = dw.GetAllFromQuery("select ISNULL(max(dest_group),0) as dest_group from GD_Dest_Master ");
        if (dtDestgroup.Rows.Count > 0 && dtDestgroup.Rows[0]["dest_group"].ToString() != "")
        {


            Dest_group = int.Parse(dtDestgroup.Rows[0]["dest_group"].ToString()) + 1;
        }


        flag = move_to_history(tr);

        if (!flag)
        {
            tr.Rollback();
            con.Close();
            return;
            
        }
        else
        {

            string Destination = "";
            string ExistDest = "";
            string Exist = "";
            lblError.Text = "";

            int result = 0;
            for (int x = 0; x < chkBoxList.Items.Count; x++)
            {
                if (chkBoxList.Items[x].Selected == true)
                {





                    try
                    {
                       
                        string DestinationID = chkBoxList.Items[x].Value;
                        string city = "";
                        string[] Origin = ddlAirlineName.SelectedItem.Text.Split('-');
                        string Org = Origin[1].ToString().Trim();
                        DataTable dtorigin = dw.GetAllFromQuery("select city_id,city_code from city_master where city_name='" + Org + "'");
                        if (dtorigin.Rows.Count > 0)
                        {
                            //city = dtorigin.Rows[0]["city_code"].ToString();
                            city = dtorigin.Rows[0]["city_id"].ToString();
                        }

                        int? scID = null;

                        com = new SqlCommand("DestinationWiseDeal_Add", con, tr);
                        com.CommandType = CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("@AirLine_Detail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
                        com.Parameters.AddWithValue("@Shipment_ID", int.Parse(ddlShip.SelectedValue.ToString()));
                        //com.Parameters.AddWithValue("@Destination_Codes", chkBoxList.Items[x].Text.Trim());
                        com.Parameters.AddWithValue("@Destination", DestinationID);
                        com.Parameters.AddWithValue("@Origin", city);
                        com.Parameters.AddWithValue("@Special_Commodity_ID", 1);
                        com.Parameters.AddWithValue("@status", 2);
                        com.Parameters.AddWithValue("@ValidFrom", DateTime.Parse(ConvertDate1(txtDisValidFrom.Text)));
                        if (txtDisValidTo.Text == "")
                        {
                            com.Parameters.AddWithValue("@ValidTo", DBNull.Value);
                        }
                        else
                        {
                            com.Parameters.AddWithValue("@ValidTo", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
                        }
                        com.Parameters.AddWithValue("@EnteredBY", Session["EMailID"].ToString());
                        com.Parameters.AddWithValue("@EnteredDate", DateTime.Today);



                        com.Parameters.AddWithValue("@dest_group", Dest_group);


                        result = com.ExecuteNonQuery();
                        for (int i = 0; i < gvSlab.Rows.Count; i++)
                        {
                            GridViewRow gr = gvSlab.Rows[i];
                            Label slabID = (Label)gr.FindControl("lblSlabID");
                            TextBox txtValue = (TextBox)gr.FindControl("txtValue");
                            TextBox Iata_Comm = (TextBox)gr.FindControl("txtComm");
                            TextBox Comm_Inc = (TextBox)gr.FindControl("txtInc");
                            TextBox SpotRate = (TextBox)gr.FindControl("txtspotrate");
                            com = new SqlCommand("DestinationWiseDealTrans_Add", con, tr);
                            com.CommandType = CommandType.StoredProcedure;
                            //com.Parameters.AddWithValue("@GD_Rate_ID", result);
                            com.Parameters.AddWithValue("@Slab_ID", slabID.Text);
                            com.Parameters.AddWithValue("@Price_Value", Convert.ToDecimal(txtValue.Text == "" ? "0" : txtValue.Text));
                            com.Parameters.AddWithValue("@AirLine_Detail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
                            com.Parameters.AddWithValue("@Iata_Comm", Convert.ToDecimal(Iata_Comm.Text == "" ? "0" : Iata_Comm.Text));
                            com.Parameters.AddWithValue("@Comm_Inc", Convert.ToDecimal(Comm_Inc.Text == "" ? "0" : Comm_Inc.Text));
                            com.Parameters.AddWithValue("@Updated_By", Session["EMailID"].ToString());
                            com.Parameters.AddWithValue("@Updated_On", DateTime.Now);

                            com.Parameters.AddWithValue("@SpotRate", Convert.ToDecimal(SpotRate.Text == "" ? "0" : SpotRate.Text));


                            // if ((txtValue.Text == "" ? "0" : txtValue.Text) != "0")
                            result = com.ExecuteNonQuery();
                        }

                        if (result == -1)
                        {
                            lblError.Text = "Slab Value Can't be Added Due to Some Error";
                            tr.Rollback();
                        }

                       
                        if (result == 1)
                            lblError.Text = Destination + ": Destination Slab Value Added Successfully.";
                        if (result == 1 && Exist != "")
                            lblError.Text = Destination + ": Destination Slab Value Added Successfully." + "<br>" + Exist + ": Destination already Exists.";
                        if (result == 0 && Exist != "")
                            lblError.Text = Exist + ": Destination already Exists.";

                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;
                        tr.Rollback();
                    }

                    //finally
                    //{
                    //    if (con != null && con.State == ConnectionState.Open)
                    //        con.Close();
                    //}
                    if (result == 1)
                    {
                        //Session["msg"] = Destination + ": Destination Discounted Value Added Successfully.";
                        //Response.Redirect("FlightDiscountingShow.aspx?id=a");


                    }
                    if (result == 1 && Exist != "")
                    {

                    }


                }

            }
            tr.Commit();
            con.Close();


            string strScript = "alert('Record Updated successfully.');location.replace('ViewDestinationWiseDeal.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBoxForupdate", strScript, true);


        }

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        int result = 0;
        string airLIne_ID = Request.QueryString["aid"].ToString();
        string flght_ID = Request.QueryString["flt"].ToString();
        string shipment_ID = Request.QueryString["sid"].ToString();
        string destination_Code = Request.QueryString["d"].ToString();
        string validFrom = Request.QueryString["vf"].ToString();
        string validto = Request.QueryString["vt"].ToString();
        string[] dest = Request.QueryString["d"].ToString().Split(',');

        con = new SqlConnection(strCon);
        SqlTransaction tr = null;

        try
        {
            con.Open();
            SqlCommand cmd = null;
            tr = con.BeginTransaction();
            if (DateTime.Parse(validFrom) < DateTime.Today)
            {
                cmd = new SqlCommand("FlightDiscounting_Update", con, tr);
            }
            else
            {
                cmd = new SqlCommand("FlightDiscounting_Delete", con, tr);
            }
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@New_AirLineDetail_ID", int.Parse(airLIne_ID));
            cmd.Parameters.AddWithValue("@New_Flight_ID", int.Parse(flght_ID));
            cmd.Parameters.AddWithValue("@New_Shipment_ID", int.Parse(shipment_ID));
            cmd.Parameters.AddWithValue("@New_Destination_Codes", destination_Code);
            cmd.Parameters.AddWithValue("@New_ValidFrom", DateTime.Parse(validFrom));
            cmd.Parameters.AddWithValue("@New_ValidTo", DateTime.Parse(validto));
            cmd.Parameters.AddWithValue("@ValidTo", DateTime.Today.AddDays(-1));
            cmd.Parameters.AddWithValue("@LastModifiyDate", DateTime.Today);

            result = cmd.ExecuteNonQuery();
            cmd.Dispose();
            tr.Commit();

        }
        catch (SqlException se)
        {
            string err = se.Message;
            tr.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        if (result == 0 || result == -1)
        {
            Session["msg"] = "Slab value can not deleted due to some error";
            //lblError.Text = "Discounted value can not deleted due to some error";
            Response.Redirect("DestinationWiseDealShow.aspx?id=d");
        }
        else
        {
            Session["msg"] = "Slab value deleted Successfully.";
            //lblError.Text = "Discounted value deleted Successfully.";
            Response.Redirect("DestinationWiseDealShow.aspx?id=d");
        }



    }
    ////////////////
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewDestinationWiseDeal.aspx");

    }
    protected string CheckExistsUpdateDestination(string Dest)
    {
        string result = "";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("CheckExistDestination", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@airlineDetail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
        //com.Parameters.AddWithValue("@Flight_ID", int.Parse(ddlFlight.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@Shipment_ID", int.Parse(ddlShip.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@validFrom", DateTime.Today);
        com.Parameters.AddWithValue("@Validto", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
        com.Parameters.AddWithValue("@Destination", Dest.Trim());

        SqlDataReader dr = com.ExecuteReader();

        while (dr.Read())
        {
            result = dr["Data"].ToString();
        }

        dr.Close();
        com.Dispose();
        con.Close();
        return result;

    }
    protected void ddlShip_SelectedIndexChanged(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        gvSlab.Visible = false;
        btnadd.Visible = false;


        if (txtDisValidFrom.Text == "")
        {
            string strScript = "alert('Please enter valid from date.');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        }
        else
        {


            string dest = "";



            DataTable dt = dw.GetAllFromQuery("select gdm.Destination,gdm.dest_group from GD_Rate_master inner join slab_master on GD_Rate_master.Slab_ID=slab_master.Slab_ID INNER JOIN db_owner.GD_Dest_Master gdm ON gdm.GD_Rate_ID=GD_Rate_master.GD_Rate_ID where gdm.Airline_Detail_id=" + ddlAirlineName.SelectedValue + " and gdm.valid_from>='" + ConvertDate1((txtDisValidFrom.Text)) + "'  AND gdm.shipment_id =" + ddlShip.SelectedValue + " GROUP BY gdm.dest_group, gdm.Destination");
            if (dt.Rows.Count > 0)
            {
                lblBindTable.Visible = true;
                int olddestgroup = int.Parse(dt.Rows[0]["dest_group"].ToString());
                int newdestgroup = 0;
                int count = 0;

                table1 = table1 + @"<table border=1 width=100% align=center><tr class=h1><td class=text colspan=11 align=center>Already Existing Destination</td></tr><tr class=h1><td class=text align=center >DEST</td><td class=text align=center colspan=10>Slab</td></tr>";

                for (int k = 0; k < dt.Rows.Count; k++)
                {
                    newdestgroup = int.Parse(dt.Rows[k]["dest_group"].ToString());


                    if (count == 0)
                    {

                        DataTable dtdest = dw.GetAllFromQuery("select destination from db_owner.GD_Dest_Master where Airline_Detail_id=" + ddlAirlineName.SelectedValue + " and valid_from>='" + ConvertDate1((txtDisValidFrom.Text)) + "' and dest_group=" + newdestgroup + "");
                        if (dtdest.Rows.Count > 0)
                        {
                            for (int l = 0; l < dtdest.Rows.Count; l++)
                            {
                                DataTable dtDestID = dw.GetAllFromQuery("select destination_id,destination_code from destination_master where destination_id=" + dtdest.Rows[l]["Destination"].ToString() + "");
                                //dest += dtdest.Rows[l]["Destination"].ToString() + ",";

                                dest += dtDestID.Rows[0]["destination_code"].ToString() + ",";

                                if (l % 10 == 0)
                                {
                                    dest += " ";
                                }

                            }
                        }
                        if (dtdest.Rows.Count == 1)
                        {
                            dest = dest.TrimEnd();
                        }
                        dest = dest.TrimEnd(',');
                        table1 += @"<tr><td class=boldtext align=center rowspan=2 style='width:125px; white-space:normal'>" + dest + @" </td>";
                        string Price = "<tr>";
                        DataTable dt1 = dw.GetAllFromQuery("select Slab_name as SlabName,Price_value as Price from GD_Rate_master inner join slab_master on GD_Rate_master.Slab_ID=slab_master.Slab_ID INNER JOIN db_owner.GD_Dest_Master gdm ON gdm.GD_Rate_ID=GD_Rate_master.GD_Rate_ID where gdm.Airline_Detail_id=" + ddlAirlineName.SelectedValue + " and gdm.destination='" + dt.Rows[k]["destination"].ToString() + "' and   gdm.Dest_Group='" + dt.Rows[k]["dest_Group"].ToString() + "'");

                        for (int m = 0; m < dt1.Rows.Count; m++)
                        {

                            table1 = table1 + @"<td class=boldtext align=center>" + dt1.Rows[m]["Slabname"].ToString() + @"</td>";
                            Price += "<td class=boldtext align=center >" + dt1.Rows[m]["Price"].ToString() + @"</td>";
                        }

                        table1 += "</tr>" + Price + "</tr>";

                    }
                    if (olddestgroup == newdestgroup)
                    {
                        count++;
                    }
                    else
                    {
                        count = 0;
                        dest = "";
                        olddestgroup = int.Parse(dt.Rows[k]["dest_group"].ToString()); ;
                        k = k - 1;
                    }



                }
                lblBindTable.Text = table1 + "</table>";


            }
            else
            {
                lblBindTable.Visible = false;
            }
        }

    }
    public bool move_to_history(SqlTransaction tr)
    {
        SqlCommand cmd = null;
        //con = new SqlConnection(strCon);
        //con.Open();
        // SqlTransaction trans1 = con.BeginTransaction();
        try
        {


            string Query = " insert into GD_Rate_Master_History select GD_Rate_ID , Slab_ID , Price_Value,Airline_detail_id,Iata_Comm,Comm_Inc,Updated_By,Updated_On ,GD_Slab_ID,SpotRate from GD_Rate_Master WHERE GD_Rate_ID IN (SELECT GD_Rate_ID FROM db_owner.GD_Dest_Master WHERE Dest_Group=" + Convert.ToInt32(Request.QueryString["dest_group"].ToString()) + ")";
            cmd = new SqlCommand(Query, con, tr);

            cmd.ExecuteNonQuery();

            Query = " insert into GD_Dest_Master_History select Airline_Detail_ID ,Shipment_ID , Special_Commodity_ID , Origin ,Destination , Valid_From , Valid_To ,Status , Entered_By ,Entered_On from GD_Dest_Master where Airline_Detail_ID=" + ddlAirlineName.SelectedValue + " and Dest_Group=" + Convert.ToInt32(Request.QueryString["dest_group"].ToString()) + "";
            cmd = new SqlCommand(Query, con, tr);

            cmd.ExecuteNonQuery();




            Query = " Delete FROM db_owner.GD_rate_Master WHERE GD_Rate_ID IN (SELECT GD_Rate_ID FROM db_owner.GD_Dest_Master WHERE Dest_Group=" + Convert.ToInt32(Request.QueryString["dest_group"].ToString()) + ")";

            cmd = new SqlCommand(Query, con, tr);

            cmd.ExecuteNonQuery();


            Query = " Delete from GD_Dest_Master where Airline_Detail_ID =" + ddlAirlineName.SelectedValue + "and Dest_Group=" + Convert.ToInt32(Request.QueryString["dest_group"].ToString()) + "";
            cmd = new SqlCommand(Query, con, tr);

            cmd.ExecuteNonQuery();

            // trans1.Commit();
           // con.Close();
            return true;
        }
        catch
        {

            // tr.Rollback();
            return false;

        }
       
    }

}
