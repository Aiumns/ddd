using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Add_To_Manifest : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    public string strLen = "";
    public string Handover_Id = "";
    public string Stock_ID = "";
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            if (!IsPostBack)
            {

                string PFM_ID = Request.QueryString["PFM_ID"];
               
             
                FillDetails(PFM_ID);
                MakeTable();
                GridView1.DataSource = (DataTable)Session["dtTemp"];
                GridView1.DataBind();
               
            }
        }
    }

    public void MakeTable()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;       
        dtTemp.Columns.Add(dc1);

       
       
        dc1 = new DataColumn();
        dc1.ColumnName = "Pieces";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "GrWt";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume Wt";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);
        DataRow dr = dtTemp.NewRow();        

        dc1 = new DataColumn();
        dc1.ColumnName = "ULD No";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

       

        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
       
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
        ViewState["dtDetails"] = dtTemp;
    }

    public void FillDetails(string PFM_ID)
    {
       

            DataTable dt = dw.GetAllFromQuery("SELECT P.PFM_ID, P.AIRWAYBILL_NO,P.NO_OF_PACKAGES,P.GROSS_WEIGHT,P.VOLUME_WEIGHT,D.DESTINATION_CODE FROM PFM P inner join destination_master d on P.destination_ID=d.destination_id where PFM_ID=" + PFM_ID);
            
            if (dt.Rows.Count > 0)
            {
                lblTPcs.Text = dt.Rows[0]["NO_OF_PACKAGES"].ToString();
                lblTGwt.Text = dt.Rows[0]["GROSS_WEIGHT"].ToString();
                lblTVW.Text = dt.Rows[0]["VOLUME_WEIGHT"].ToString();
                lblAWB.Text = dt.Rows[0]["AIRWAYBILL_NO"].ToString();
                lblDest.Text = dt.Rows[0]["DESTINATION_CODE"].ToString(); 
            }
        
    }

  
    protected void Button1_Click(object sender, EventArgs e)
    {
        int PCS = 0;
        decimal GrWt = 0;
        decimal VolumeWt = 0;
        DataTable dtULD = new DataTable();
        if (Session["dtTemp"] != null)
        {
            dtULD = (DataTable)Session["dtTemp"];
           
       
            for (int i = 0; i < dtULD.Rows.Count; i++)
            {


                PCS = PCS + int.Parse(dtULD.Rows[i]["Pieces"].ToString());
                GrWt = GrWt + decimal.Parse(dtULD.Rows[i]["GrWt"].ToString());
                VolumeWt = VolumeWt + decimal.Parse(dtULD.Rows[i]["Volume Wt"].ToString());
             
               
            }
            
        }

        if (PCS != int.Parse(lblTPcs.Text) || GrWt != decimal.Parse(lblTGwt.Text) || VolumeWt != decimal.Parse(lblTVW.Text))
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Total ULD wise PCS,GRWt And Vol Wt Should be equal total AWB wise.";

        }
        else
        {
            InsertIntoPFM();
        }
        
       
    }

    public void InsertIntoPFM()
    {
        
        
        SqlTransaction Trans = null;
        string Flight_Open_ID = Request.QueryString["fid"];
        string Airline_Detail_ID = Request.QueryString["AID"];
        string PFM_ID = Request.QueryString["PFM_ID"];
        string Entered_By = Session["EMailID"].ToString();
        string insert;
        




        /////////////////////////////////////////////////////////////////////
        try
        {



            SqlConnection con = new SqlConnection(strCon);
            con.Open();
            SqlCommand strcom = null;

            DataTable dtULD = new DataTable();
            if (Session["dtTemp"] != null)
            {
                dtULD = (DataTable)Session["dtTemp"];

                for (int i = 0; i < dtULD.Rows.Count; i++)
                {
                    strcom = new SqlCommand("ADD_ULD", con, Trans);
                    strcom.CommandType = CommandType.StoredProcedure;
                    strcom.Parameters.AddWithValue("@PFM_ID", PFM_ID);
                    strcom.Parameters.AddWithValue("@Flight_Open_ID", Flight_Open_ID);
                    strcom.Parameters.AddWithValue("@PCS", dtULD.Rows[i]["Pieces"].ToString());
                    strcom.Parameters.AddWithValue("@Gross_Weight", dtULD.Rows[i]["GrWt"].ToString());
                    strcom.Parameters.AddWithValue("@Volume_Weight", dtULD.Rows[i]["Volume Wt"].ToString());
                    strcom.Parameters.AddWithValue("@ULD_No", dtULD.Rows[i]["ULD No"].ToString());
                    strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                    strcom.ExecuteNonQuery();
                }
            }

           

            string CITY_ID = Request.QueryString["city_id"];
            string Air_code = Request.QueryString["Airline_code"];
            Response.Redirect("Browse_PFM_Details.aspx?State=Added&city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_ID + "&AID=" + Airline_Detail_ID + "&fno=" + Request.QueryString["fno"] + "&date=" + Request.QueryString["date"] + "");
            con.Close();
            strcom.Dispose();
            //string Flight_Open_ID = Request.QueryString["fid"];
            //string Airline_Detail_ID = Request.QueryString["AID"];
            //string PFM_ID = Request.QueryString["PFM_ID"];
            //string Entered_By = Session["EMailID"].ToString();
       
            //SqlConnection con = new SqlConnection(strCon);
            //con.Open();
            ////Trans = con.BeginTransaction();
            //SqlCommand strcom = null;
            
            //    if (txtPcs1.Text != "" && txtGwt1.Text != "" && txtVwt1.Text != "" && txtULD1.Text != "")
            //    {
            //        int PCS1 = Int32.Parse(txtPcs1.Text);
                   
            //        decimal Gross_Weight1 = decimal.Parse(txtGwt1.Text);
            //        decimal Volume_Weight1 = decimal.Parse(txtVwt1.Text);
                    
            //        strcom = new SqlCommand("ADD_ULD", con, Trans);
            //        strcom.CommandType = CommandType.StoredProcedure;
            //        strcom.Parameters.AddWithValue("@PFM_ID", PFM_ID);
            //        strcom.Parameters.AddWithValue("@PCS", PCS1);
            //        strcom.Parameters.AddWithValue("@Gross_Weight", Gross_Weight1);
            //        strcom.Parameters.AddWithValue("@Volume_Weight", Volume_Weight1);
            //        strcom.Parameters.AddWithValue("@ULD_No", txtULD1.Text);
            //        strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
            //    }
            //    if (txtPcs2.Text != "" && txtGwt2.Text != "" && txtVwt2.Text != "" && txtULD2.Text != "")
            //    {
            //        int PCS2 = Int32.Parse(txtPcs2.Text);

            //        decimal Gross_Weight2 = decimal.Parse(txtGwt2.Text);
            //        decimal Volume_Weight2 = decimal.Parse(txtVwt2.Text);

            //        strcom = new SqlCommand("ADD_ULD", con);
            //        strcom.CommandType = CommandType.StoredProcedure;
            //        strcom.Parameters.AddWithValue("@PFM_ID", PFM_ID);
            //        strcom.Parameters.AddWithValue("@PCS", PCS2);
            //        strcom.Parameters.AddWithValue("@Gross_Weight", Gross_Weight2);
            //        strcom.Parameters.AddWithValue("@Volume_Weight", Volume_Weight2);
            //        strcom.Parameters.AddWithValue("@ULD_No", txtULD2.Text);
            //        strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
            //    }
            //    if (txtPcs3.Text != "" && txtGwt3.Text != "" && txtVwt3.Text != "" && txtULD3.Text != "")
            //    {
            //        int PCS3 = Int32.Parse(txtPcs3.Text);

            //        decimal Gross_Weight3 = decimal.Parse(txtGwt3.Text);
            //        decimal Volume_Weight3 = decimal.Parse(txtVwt3.Text);

            //        strcom = new SqlCommand("ADD_ULD", con);
            //        strcom.CommandType = CommandType.StoredProcedure;
            //        strcom.Parameters.AddWithValue("@PFM_ID", PFM_ID);
            //        strcom.Parameters.AddWithValue("@PCS", PCS3);
            //        strcom.Parameters.AddWithValue("@Gross_Weight", Gross_Weight3);
            //        strcom.Parameters.AddWithValue("@Volume_Weight", Volume_Weight3);
            //        strcom.Parameters.AddWithValue("@ULD_No", txtULD3.Text);
            //        strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
            //    }

            
               
          



         
        }
        catch (SqlException sqe)
        {
            
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string CITY_ID = Request.QueryString["city_id"];
        string Air_code = Request.QueryString["Airline_code"];
        string Flight_Open_ID = Request.QueryString["fid"];
        string Airline_Detail_ID = Request.QueryString["AID"];
        string FDATE = Request.QueryString["date"];
        Response.Redirect("Browse_PFM_Details.aspx?city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_ID + "&AID=" + Airline_Detail_ID + "&fno=" + Request.QueryString["fno"] + "&date=" + FDATE + "");
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (GridView1.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            //lblmsg.Visible = true;
        }
        else
        {
            //lblmsg.Visible = false;
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.DataSource = (DataTable)Session["dtTemp"];
            GridView1.DataBind();
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                int Pieces = 0;
                decimal VoulmeWt = 0;
                decimal GrWt=0;
                
                foreach (DataRow rw in dt.Rows)
                {
                    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                      GrWt = GrWt + decimal.Parse(rw["GrWt"].ToString());

                }
              
             
                   
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();
           
        }
        else
        {
            DataTable dtDetails = (DataTable)ViewState["dtDetails"];
            Session["dtTemp"] = dtDetails;
            GridView1.DataSource = dtDetails;
            GridView1.DataBind();
        }

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];

        int SNo = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Value);
        decimal PCS = Convert.ToDecimal(((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtPcs")).Text);
        decimal GrWt = Convert.ToDecimal(((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtGrWT")).Text);
        decimal Vwt = Convert.ToDecimal(((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtVwt")).Text);
        string ULD = (((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtUld")).Text);

        decimal Volume_Wt;

       
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = PCS;
                dr[2] = GrWt;
                dr[3] = Vwt;
                dr[4] = ULD;
               
            }
        }

        Session["dtTemp"] = dt;
        GridView1.EditIndex = -1;
        GridView1.DataSource = dt;
        GridView1.DataBind();

       
       
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        GridView1.DataSource = (DataTable)Session["dtTemp"];
        GridView1.DataBind();
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();


                decimal PCS = Convert.ToDecimal(((TextBox)GridView1.FooterRow.FindControl("txtPcs")).Text);
                decimal GrWt = Convert.ToDecimal(((TextBox)GridView1.FooterRow.FindControl("txtGrWT")).Text);
                decimal Vwt = Convert.ToDecimal(((TextBox)GridView1.FooterRow.FindControl("txtVwt")).Text);
                string ULD = (((TextBox)GridView1.FooterRow.FindControl("txtUld")).Text);






                dr[1] = PCS;
                dr[2] = GrWt;
                dr[3] = Vwt;
                dr[4] = ULD;
                
                dt.Rows.Add(dr);
               
             
                Session["dtTemp"] = dt;
                GridView1.DataSource = dt;
                GridView1.DataBind();
              


            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }
}
