using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class agent_Gcpp : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
       Label1.Text = ""; 
      string query = @"select distinct s.airline_detail_id,airline_name,airline_code,airline_text_code,city_master.city_code from  sales s inner join airline_detail ad on ad.airline_detail_id=s.airline_detail_id inner join airline_master am on ad.airline_id=am.airline_id inner join  city_master on ad.belongs_to_city=city_master.city_id where awb_date between '04/01/2008' and getdate() and airline_code<> 023 and ad.airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ") order by city_code ";
     DataTable dt = dw.GetAllFromQuery(query);
       //query = "select agent_name,agent_master.agent_id from agent_master inner join agent_branch on agent_master.agent_id=agent_master.agent_id inner join login_master on login_master.agent_id=agent_branch.Agent_branch_id where email_id='" + Session["EMailID"].ToString() + "'";
     query = "select belongs_to_city,agent_Name,am.agent_id from login_master lm inner join agent_branch ab on ab.Agent_branch_id=lm.agent_id left outer join agent_master am on am.agent_id=ab.agent_id where email_id='" + Session["EMailID"].ToString() + "'";
       DataTable dt_agent = dw.GetAllFromQuery(query);
       decimal total_ch_wt = 0;
       lblagent.Text = "<h3>" + dt_agent.Rows[0]["Agent_name"].ToString() + "</h3>";
       string Tables = "<table width=90% border=0 cellpadding=0 cellspacing=1 align=center><tr><td colspan=12 class=boldtext align=center valign=middle nowrap></td></tr><tr><td class=boldtext colspan=12  align=center colspan=2>From 01-Apr-2008 - To" + DateTime.Now.ToString("dd-MMM-yyyy") + "</td></tr>";


        string Query = @"select airline_name+'-'+city_code as 'Airline Name',sum(CASE WHEN charged_weight< 100  then  charged_weight else 0 end) as 'less100',count((CASE WHEN charged_weight< 100  then  charged_weight end)) as shpt,((sum(CASE WHEN charged_weight< 100  then  charged_weight else 0 end)/100)*15) as CPP,sum(CASE WHEN charged_weight >= 100  and charged_weight < 500 then  charged_weight else 0 end) as 'B100500',count((CASE WHEN charged_weight >= 100  and charged_weight < 500 then  charged_weight end)) as 'shpt*',((sum(CASE WHEN charged_weight >= 100  and charged_weight < 500 then  charged_weight else 0 end)/100)*10) as 'CPP*',sum((CASE WHEN charged_weight>= 500 then charged_weight else 0 end)) as 'Gt500',count((CASE WHEN charged_weight>= 500 then charged_weight end)) as 'shpt**',((sum(CASE WHEN charged_weight>= 500 then charged_weight else 0 end)/100)*5) as 'CPP**',(sum(CASE WHEN charged_weight< 100  then  charged_weight else 0 end) +sum(CASE WHEN charged_weight >= 100  and charged_weight < 500 then  charged_weight else 0 end) +sum((CASE WHEN charged_weight>= 500 then charged_weight else 0 end))) as Total,(((sum(CASE WHEN charged_weight< 100  then  charged_weight else 0 end)/100)*15)+((sum(CASE WHEN charged_weight >= 100  and charged_weight < 500 then  charged_weight else 0 end)/100)*10)+((sum(CASE WHEN charged_weight>= 500 then charged_weight else 0 end)/100)*5)) as 'Total CPP' from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where airline_detail.airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ") and sales.status <> 12 and awb_date between '04/01/2008' and getdate()  and airline_code<> 023 and  city_id=" + dt_agent.Rows[0]["belongs_to_city"].ToString() + " and agent_name='" + dt_agent.Rows[0]["Agent_name"].ToString() + "'  group by agent_name,airline_name,city_code order by agent_name ";


        DataTable dt_data = dw.GetAllFromQuery(Query );
        Tables += "<tr class=h1><td class=boldtext>&nbsp;</td><td class=boldtext colspan=3>&lt;100</td><td class=boldtext colspan=3>100-500</td><td colspan=3 class=boldtext>&gt;500</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td></tr><tr class=h1><td class=boldtext>Airline Name</td><td class=boldtext>Ch Wt.</td><td class=boldtext>Shpt.</td><td class=boldtext>CPP</td><td class=boldtext>Ch Wt.</td><td class=boldtext>Shpt.</td><td class=boldtext>CPP</td><td class=boldtext>Ch Wt.</td><td class=boldtext>Shpt.</td><td class=boldtext>CPP</td><td class=boldtext>Total Ch wt.</td><td class=boldtext>CPP</td></tr>";
        decimal tot_cPP = 0;
   total_ch_wt = 0;
   int row = 0;

        foreach (DataRow drow in dt_data.Rows)
        {

            if ((row % 2) == 0)
            {
                Tables += @"<tr bgcolor='#c0c0c0'><td class=boldtext align=left>" + drow["Airline Name"].ToString() + "</td><td class=boldtext align=right>" + drow["less100"].ToString() + "</td><td class=boldtext align=right>" + drow["shpt"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["CPP"].ToString()), MidpointRounding.AwayFromZero) + "</td><td class=boldtext align=right>" + drow["B100500"].ToString() + "</td><td class=boldtext align=right>" + drow["shpt*"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["CPP*"].ToString()), MidpointRounding.AwayFromZero) + "</td><td class=boldtext align=right>" + drow["Gt500"].ToString() + "</td><td class=boldtext align=right>" + drow["shpt**"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["CPP**"].ToString()), MidpointRounding.AwayFromZero) + "</td><td class=boldtext align=right>" + drow["Total"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["Total CPP"].ToString()), MidpointRounding.AwayFromZero) + "</td></tr>";

            }
            else
            {
                Tables += @"<tr bgcolor='#F1F1F1'><td class=boldtext align=left>" + drow["Airline Name"].ToString() + "</td><td class=boldtext align=right>" + drow["less100"].ToString() + "</td><td class=boldtext align=right>" + drow["shpt"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["CPP"].ToString()), MidpointRounding.AwayFromZero) + "</td><td class=boldtext align=right>" + drow["B100500"].ToString() + "</td><td class=boldtext align=right>" + drow["shpt*"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["CPP*"].ToString()), MidpointRounding.AwayFromZero) + "</td><td class=boldtext align=right>" + drow["Gt500"].ToString() + "</td><td class=boldtext align=right>" + drow["shpt**"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["CPP**"].ToString()), MidpointRounding.AwayFromZero) + "</td><td class=boldtext align=right>" + drow["Total"].ToString() + "</td><td class=boldtext align=right>" + Math.Round(Convert.ToDecimal(drow["Total CPP"].ToString()), MidpointRounding.AwayFromZero) + "</td></tr>";

            }

            row = row + 1;
            
          

            total_ch_wt = total_ch_wt + Convert.ToDecimal(drow["Total"].ToString());
            tot_cPP = tot_cPP + Math.Round(Convert.ToDecimal(drow["Total CPP"].ToString()), MidpointRounding.AwayFromZero);
        }
        row = 0;
        Tables += "<tr class=h1><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td><td class=boldtext>Total</td><td class=boldtext align=right>" + total_ch_wt + "</td><td class=boldtext align=right>" + tot_cPP + "</td></tr>";



        //GridView gv = new GridView();
        //gv.DataSource = dt_data;
        //gv.DataBind();
        //gv.CssClass = "text";
        //gv.HeaderRow.CssClass = "h5";
        //gv.HeaderRow.VerticalAlign = VerticalAlign.Middle;
        //gv.HeaderRow.HorizontalAlign = HorizontalAlign.Center;
        //if (gv.Columns.Count > 0)
        //{
        //    gv.Columns[1].Visible = false;
        //}
        
        
        
        //Label1.Controls.Add(gv);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        //Tables = "<tr class=h5><td class=boldtext align=left>&nbsp;</td><td class=boldtext align=center>&nbsp;</td></tr><tr class=h5><td class=boldtext align=left>Airline Name</td><td class=boldtext align=center>Chargeable Weight.</td></tr>";
//        query = "select  airline_name,sum(charged_weight) as charged_weight from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where airline_detail.airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ")  and agent_name='" + dt_agent.Rows[0]["Agent_name"].ToString() + "' and awb_date between '04/01/2008' and getdate()  and airline_code<> 023 group by airline_name order by airline_name";
//        DataTable dt_air = dw.GetAllFromQuery(query);
//        int row = 0;
//        decimal gcrp_cal = 0,Total_gcr=0;
//        decimal bonus = 0;
//        decimal prc = 0;
//        string ag_member = null;
        
//         Tables += "<tr bgcolor='#c0c0c0'><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td></tr>";
//        foreach (DataRow drow in dt_air.Rows)
//        {
//            if (row % 2 == 0)
//            {
//                Tables += "<tr bgcolor='#F1F1F1'><td class=boldtext nowrap>" + drow["airline_name"].ToString() + "</td><td class=boldtext align=right>" + drow["charged_weight"].ToString() + "</td></tr>";
//            }
//            else
//            {
//                Tables += "<tr bgcolor='#c0c0c0'><td class=boldtext nowrap>" + drow["airline_name"].ToString() + "</td><td class=boldtext align=right>" + drow["charged_weight"].ToString() + "</td></tr>";
//            }
//            total_ch_wt = total_ch_wt + Convert.ToDecimal(drow["charged_weight"].ToString());
//            row = row + 1;
//        }
//        row = 0;
//        Tables += "<tr class=h5><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td></tr>";
//        Tables += "<tr bgcolor='#c0c0c0'><td class=boldtext>Total</td><td class=boldtext align=right>" + total_ch_wt + "</td></tr>";
//        gcrp_cal = Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero);
     
//        Tables += "<tr bgcolor='#F1F1F1'><td class=boldtext>GCRP</td><td class=boldtext align=right>" + Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) + "</td></tr>";

//        if (dt.Rows[0]["city_code"].ToString() == "MUM")
//        {
//            if (total_ch_wt >= 0 && total_ch_wt <= 9999)
//            {
//                prc = 0;
//                ag_member = "Base";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 0 / 100, 0);
//            }
//            else if (total_ch_wt >= 10000 && total_ch_wt <= 14999)
//            {
//                prc = 25;
//                ag_member = "Blue";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 25 / 100, 0);
//            }
//            else if (total_ch_wt >= 15000 && total_ch_wt <= 24999)
//            {
//                prc = 30;
//                ag_member = "Silver";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 30 / 100, 0);
//            }
//            else if (total_ch_wt >= 25000 && total_ch_wt <= 34999)
//            {
//                prc = 35;
//                ag_member = "Gold";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 35 / 100, 0);
//            }
//            else
//            {
//                prc = 50;
//                ag_member = "Platinum";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 50 / 100, 0);
//            }
//        }
//        else
//        {
//            if (total_ch_wt >= 0 && total_ch_wt <= 9999)
//            {
//                prc = 0;
//                ag_member = "Base";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 0 / 100, 0);
//            }
//            else if (total_ch_wt >= 10000 && total_ch_wt <= 14999)
//            {
//                prc = 25;
//                ag_member = "Blue";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 25 / 100, 0);
//            }

//            else if (total_ch_wt >= 15000 && total_ch_wt <= 19999)
//            {
//                prc = 30;
//                ag_member = "Silver";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 30 / 100, 0);
//            }

//            else if (total_ch_wt >= 20000 && total_ch_wt <= 29999)
//            {
//                prc = 35;
//                ag_member = "Gold";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 35 / 100, 0);
//            }
//            else
//            {
//                prc = 50;
//                ag_member = "Platinum";
//                bonus = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * 50 / 100, 0);
//            }

//        }
//        Total_gcr = Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero)) + Math.Round(Math.Round(total_ch_wt / 100, MidpointRounding.AwayFromZero) * prc / 100, 0);

//        Tables += "<tr bgcolor='#F1F1F1'><td class=boldtext nowrap>Bonus GCRP " + prc + "% For " + ag_member + " member</td><td class=boldtext align=right>" + bonus + "</td></tr><tr bgcolor='#F1F1F1'><td class=boldtext nowrap>Total GCRP </td><td class=boldtext align=right>" + Total_gcr + "</td></tr><tr bgcolor='#c0c0c0'><td class=boldtext>VAlUE</td><td class=boldtext align=right>" + Math.Round(Total_gcr, MidpointRounding.AwayFromZero) * 10 + "</td></tr>";
//        Tables += "<tr class=h5><td class=boldtext>&nbsp;</td><td class=boldtext>&nbsp;</td></tr>";

//        Tables += "</table><br>";
////Base  GCRP  Value     
//        //100 Kg  1GCRP  10     
//        //Tonnage  Tier  Bonus on Chargeable Weight GCRP  Tier Bonus 
////0-10 Tons  Base  x     
////11-30 Tons  Blue  x  20% of x 
////31-50Tons  Silver  x  30% of x 
////51-75 Tons  Gold  x  40% of x 
////76 & Above  Platinum  x  50% of x 
//        decimal watage = 0;
//        decimal gcrp = 0;
//        decimal chwt = 0;
//        if (dt.Rows[0]["city_code"].ToString() == "MUM")
//        {

//            if (total_ch_wt >= 0 && total_ch_wt <= 9999)
//            {

//                chwt = Convert.ToDecimal(total_ch_wt);

//                watage = 10000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Base Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";
//                Tables += "<tr bgcolor='#D5f0fd'><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Blue</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs. </td><td class=boldtext align=center>25% </td></tr>";



//                watage = 15000;
//                Tables += "<tr bgcolor='#c0c0c0'><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Silver</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs. </td><td class=boldtext align=center>30%</td></tr>";


//                watage = 25000;
//                Tables += "<tr bgcolor='#8B7500'><td class=boldtext align=center><font color=white>" + total_ch_wt + "</font></td><td class=boldtext align=center><font color=white>Gold</font></td><td class=boldtext align=center nowrap><font color=white>" + (watage - chwt) + " kgs.</font></td><td class=boldtext align=center><font color=white>35%</font></td></tr>";

//                watage = 35000;
//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";

//                gcrp = 0;
//            }
//            else if (total_ch_wt >= 10000 && total_ch_wt < 14999)
//            {
//                watage = 15000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Blue Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";


//                Tables += "<tr bgcolor='#c0c0c0''><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Silver</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs. </td><td class=boldtext align=center>30%</td></tr>";


//                watage = 25000;
//                Tables += "<tr bgcolor='#8B7500'><td class=boldtext align=center><font color=white>" + total_ch_wt + "</font></td><td class=boldtext align=center><font color=white>Gold</font></td><td class=boldtext align=center nowrap><font color=white>" + (watage - chwt) + " kgs.</font></td><td class=boldtext align=center><font color=white>35%</font></td></tr>";

//                watage = 35000;
//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 25), MidpointRounding.AwayFromZero);
//            }
//            else if (total_ch_wt >= 15000 && total_ch_wt < 24999)
//            {
//                watage = 25000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Silver Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";


//                Tables += "<tr bgcolor='#8B7500'><td class=boldtext align=center><font color=white>" + total_ch_wt + "</font></td><td class=boldtext align=center><font color=white>Gold</font></td><td class=boldtext align=center nowrap><font color=white>" + (watage - chwt) + " kgs.</font></td><td class=boldtext align=center><font color=white>35%</font></td></tr>";

//                watage = 35000;
//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 30), MidpointRounding.AwayFromZero);
//            }
//            else if (total_ch_wt >= 25000 && total_ch_wt < 34999)
//            {
//                watage = 35000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Gold Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";


//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 35), MidpointRounding.AwayFromZero);
//            }
//            else if (total_ch_wt >= 35000)
//            {

//                chwt = Convert.ToDecimal(total_ch_wt);

//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Platinum Member</td></tr>";

//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 50), MidpointRounding.AwayFromZero);

//            }

//            Tables += "</table>";
//        }
//        else
//        {
//            if (total_ch_wt >= 0 && total_ch_wt <= 9999)
//            {

//                chwt = Convert.ToDecimal(total_ch_wt);

//                watage = 10000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Base Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";
//                Tables += "<tr bgcolor='#D5f0fd'><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Blue</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs. </td><td class=boldtext align=center>25% </td></tr>";



//                watage = 15000;
//                Tables += "<tr bgcolor='#c0c0c0'><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Silver</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs. </td><td class=boldtext align=center>30%</td></tr>";


//                watage = 20000;
//                Tables += "<tr bgcolor='#8B7500'><td class=boldtext align=center><font color=white>" + total_ch_wt + "</font></td><td class=boldtext align=center><font color=white>Gold</font></td><td class=boldtext align=center nowrap><font color=white>" + (watage - chwt) + " kgs.</font></td><td class=boldtext align=center><font color=white>35%</font></td></tr>";

//                watage = 30000;
//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";

//                gcrp = 0;
//            }
//            else if (total_ch_wt >= 10000 && total_ch_wt < 14999)
//            {
//                watage = 15000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Blue Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";


//                Tables += "<tr bgcolor='#c0c0c0'><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Silver</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs. </td><td class=boldtext align=center>30%</td></tr>";


//                watage = 20000;
//                Tables += "<tr bgcolor='#8B7500'><td class=boldtext align=center><font color=white>" + total_ch_wt + "</font></td><td class=boldtext align=center><font color=white>Gold</font></td><td class=boldtext align=center nowrap><font color=white>" + (watage - chwt) + " kgs.</font></td><td class=boldtext align=center><font color=white>35%</font></td></tr>";

//                watage = 30000;
//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 25), MidpointRounding.AwayFromZero);
//            }
//            else if (total_ch_wt >= 15000 && total_ch_wt < 19999)
//            {
//                watage = 20000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Silver Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";


//                Tables += "<tr bgcolor='#8B7500'><td class=boldtext align=center><font color=white>" + total_ch_wt + "</font></td><td class=boldtext align=center><font color=white>Gold</font></td><td class=boldtext align=center nowrap><font color=white>" + (watage - chwt) + " kgs.</font></td><td class=boldtext align=center><font color=white>35%</font></td></tr>";

//                watage = 30000;
//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 30), MidpointRounding.AwayFromZero);
//            }
//            else if (total_ch_wt >= 20000 && total_ch_wt < 29999)
//            {
//                watage = 30000;
//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Gold Member</td></tr><tr class=h5><td class=boldtext align=center>Current Weight</td><td class=boldtext align=center>Membership Type</td><td class=boldtext align=center>Need Weight</td><td class=boldtext align=center>You'll Get Tier  Bonus on Chargeable Weight</td></tr>";


//                Tables += "<tr><td class=boldtext align=center>" + total_ch_wt + "</td><td class=boldtext align=center>Platinum</td><td class=boldtext align=center nowrap>" + (watage - chwt) + " kgs.</td><td class=boldtext align=center>50%</td></tr>";


//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 35), MidpointRounding.AwayFromZero);
//            }
//            else if (total_ch_wt >= 30000)
//            {

//                chwt = Convert.ToDecimal(total_ch_wt);

//                Tables += "<table width=100% cellpadding=0 cellspacing=0 align=center><tr class=h1><td colspan=4 class=boldtext align=center>You are Platinum Member</td></tr>";

//                Tables += "</table>";
//                gcrp = Math.Round(((total_ch_wt / 100) * 50), MidpointRounding.AwayFromZero);

//            }

       
//        }
          Tables += "</table>";
        Label1.Text = Tables;



    }
}
