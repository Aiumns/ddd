using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CrDr_Generate_Show : System.Web.UI.Page
{
    public string page_pop = "";
    string agentName = null, lastTsdsRate = "0";
    string lastSurcharge = "0";
    string tableAll = null, comName = null;
    string massage = null;

    string city_id = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    string csr_detail_id = "", sales_id="";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {

            Response.Redirect("../Login.aspx");
        }
        csr_detail_id = Request.QueryString["sdid"].ToString();
        sales_id = Request.QueryString["sid"].ToString();

        FillSalesFields() ;
        string airline_name = ViewState["airline_name"].ToString();
        string agent_selected_id = ViewState["Agent_ID"].ToString();
        string agent_selected_name = ViewState["Agent_name"].ToString();
        string from_date = ViewState["csr_date"].ToString();
        string to_date = ViewState["csr_date"].ToString();
        string sales_t = ViewState["sales_type"].ToString();
        string sales_type = "";
        if (sales_t.ToString().Trim() == "CR")
        {
            sales_type = "Credit";
        }
        else
        {
            sales_type = "Debit";
        }
        string csrFooter = ViewState["csr_footer"].ToString();
        char ch_f = (char)System.Windows.Forms.Keys.Return;
        char ch2_f = (char)System.Windows.Forms.Keys.Space;
        string ch1_f = Convert.ToString(ch_f);
        string ch3_f = Convert.ToString(ch2_f);
        csrFooter = csrFooter.Replace(ch1_f, "<br>");
        csrFooter = csrFooter.Replace(ch3_f, "&nbsp;");

        string airline_name_city_value = ViewState["airline_detail_id"].ToString();
        string comAdd = null;
        string airline = "A/C " + airline_name.ToUpper().ToString();
        string agnetID = "";
       
        if (Session["groupid"].ToString() != "5")
        {

            //for (int k = 0; k < agent_selected_id.Length - 1; k++)
            //{
                //if (agent_selected_id.i.Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;

                string table = null;
                agnetID =agent_selected_id;
                agentName = agent_selected_name;
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name.ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                else
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        comName = dr["company_name"].ToString();

                        table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""3"">" + dr["Company_Address"].ToString() + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""2"" class=""heading"">" + sales_type + @" Note</font></p></td></tr></table><br>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td><td class=""boldtext"" align=""left"" width=""30%""><font size=""3"">Date:&nbsp;&nbsp;" + ConvertDate1(from_date) + @"&nbsp;&nbsp;&nbsp;&nbsp;</font></td></tr></table><br>";
                    }
                    com.Dispose();
                    dr.Dispose();



                    table += @"<table align=center style=""word-spacing:inherit"" width=""95%""
 border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th><th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th></tr><tr><th class=""h1 boldtext"">PP</th ><th  class=""h1 boldtext"">CC</th></tr><tr><td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td>
</tr>";

                    com = new SqlCommand("CrDrNote", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    //dt.Load(dr);
                    while (dr.Read())
                    {
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            discount = 0;
                            TotDiscount += 0;
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                        // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            // EduChrg -= Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduChrg -= Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                            // EduChrg += Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduChrg += Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }


                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = "";
                        //string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        //if (rdbtn == "No")
                        //{
                        //    remarks = "";
                        //}
                        //else
                        //{
                        //    remarks = remarks;
                        //}
                        table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""2""></td></tr>";

                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";
                    //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds)+ @"</strong></td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)) < 0)
                    {
                        massage = "Total payable from";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)));
                    }
                    else
                    {
                        massage = "Total Receivable from";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge));
                    }


                    table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"">INR &nbsp;" + font + GrandTotal + @"</font></td></tr>";

                    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1>" + csrFooter + @"</font<br> </FONT><br><br></td></tr></table><br style=""page-break-before:always;"">";

                }
                if (GrandTotal > 0)
                    tableAll = tableAll + table;

                Label1.Text = tableAll;

                //}

            //}

            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;

        }
        else
        {
            //for (int k = 0; k < agent_selected_id.Length - 1; k++)
            //{
                //if (agent_selected_id.i.Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;

                string table = null;
                agnetID = agent_selected_id;
                agentName = agent_selected_name;
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name.ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                else
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        comName = dr["company_name"].ToString();

                        table += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""3"">" + dr["Company_Address"].ToString() + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""2"" class=""heading"">" + sales_type + @" Note </font><br><font size=""3"">Date " + ConvertDate1(from_date) + @"</font></p></td></tr></table>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td><td class=""boldtext"" align=""left"" width=""30%""><font size=""3"">Date:&nbsp;&nbsp;" + ConvertDate1(from_date) + @"&nbsp;&nbsp;&nbsp;&nbsp;</font></td></tr></table><br>";
                    }
                    com.Dispose();
                    dr.Dispose();



                    table += @"<table width=""100%""border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th><th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th></tr><tr><th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr><tr><td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td>
</tr>";
                    com = new SqlCommand("CrDrNote", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();

                    while (dr.Read())
                    {
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            discount = 0;
                            TotDiscount += 0;
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()));
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()));
                        TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                        // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                            // EduChrg -= Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduChrg -= Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                            // EduChrg += Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduChrg += Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }


                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000") ;
                        lastSurcharge = dr["surcharge"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = "";
                        //string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        //if (rdbtn == "No")
                        //{
                        //    remarks = "";
                        //}
                        //else
                        //{
                        //    remarks = remarks;
                        //}
                        table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""2""></td></tr>";

                    Total = (TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm);
                    table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";
                    //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds)+ @"</strong></td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)) < 0)
                    {
                        massage = "Total payable from";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)));
                    }
                    else
                    {
                        massage = "Total Receivable from";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge));
                    }


                    table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"">INR &nbsp;" + font + GrandTotal + @"</font></td></tr>";

                    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1>" + csrFooter + @"</font<br> </FONT><br><br></td></tr></table><br style=""page-break-before:always;"">";

                }
                if (GrandTotal > 0)
                    tableAll = tableAll + table;

                Label1.Text = tableAll;

                //}

            //}

            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;
        }

    }
    public void FillSalesFields()
    {
        string SalesID = "";
        if (Request.QueryString["sid"] != null)
        {
            SalesID = Request.QueryString["sid"];
        }
        DataTable dtSales = dw.GetAllFromQuery("SELECT *,convert(varchar,csr_date,101) as csr_date1 FROM Sales where Sales_ID=" + SalesID);
        if (dtSales.Rows.Count > 0)
        {
            ViewState["Stock_ID"] = dtSales.Rows[0]["Stock_ID"].ToString();
            ViewState["csr_date"] = dtSales.Rows[0]["csr_date1"].ToString();
            ViewState["sales_type"] = dtSales.Rows[0]["sales_type"].ToString();
            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select AirWayBill_No,Agent_ID from stock_Master where Stock_ID=" + dtSales.Rows[0]["Stock_ID"].ToString());

            DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + dtAirWayBillNo.Rows[0]["Agent_ID"].ToString());
            if (dtAgent.Rows.Count > 0)
            {
                ViewState["Agent_ID"] = dtAirWayBillNo.Rows[0]["Agent_ID"].ToString();
                ViewState["Agent_name"] = dtAgent.Rows[0]["Agent_Name"].ToString();
            }

            if (dtAirWayBillNo.Rows.Count > 0)
            {
                ViewState["awb_no"] = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
                string AirlineCode = ViewState["awb_no"].ToString().Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID,Airline_name from Airline_Master where Airline_Code=" + AirlineCode);
                ViewState["airline_name"] = AirlineID.Rows[0]["Airline_name"].ToString();
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID,csr_footer from Airline_Detail where Airline_ID=" + AirlineID.Rows[0]["Airline_ID"].ToString() + " and Belongs_To_City=" + dtSales.Rows[0]["City_ID"].ToString());

                long City_ID = long.Parse(dtSales.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                DataTable dtCity = dw.GetAllFromQuery("select City_Code,City_Name from City_Master where City_ID=" + dtSales.Rows[0]["City_ID"].ToString());
                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    ViewState["airline_detail_id"] = AirlineDetailID;
                    ViewState["csr_footer"] = dtAirlineDetail.Rows[0]["csr_footer"].ToString();
                }
            }

           
          

        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat1(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }


}
