﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class AddCluster : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlTransaction trans = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if(!IsPostBack)
        {
            FillCity();
        if (Request.QueryString.Count > 0)
        {
            txtClusterName.Enabled = false;
            btnSummit.Visible = false;
            btnupdate.Visible = true;
            Filldata();
        
        }
        }

    }
    protected void FillCity()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("SELECT City_ID,City_Name FROM dbo.City_Master", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlCity.Items.Clear();
            ddlCity.Items.Insert(0, "- -Select- -");
            ddlCity.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlCity.Items.Add(new ListItem(dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();


        }

        catch
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void Filldata()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string cmdCheck = "SELECT * FROM db_owner.Cluster_master WHERE Cluster_id='" + Request.QueryString["ClusterID"].ToString() + "' ";

        SqlDataAdapter da = new SqlDataAdapter(cmdCheck, con);

        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count != 0)
        {
            txtClusterName.Text = ds.Tables[0].Rows[0]["Cluster_Name"].ToString();
        }

        for (int r = 0; r <= (ddlCity.Items.Count - 1); r++)
        {
            if (ddlCity.Items[r].Value == ds.Tables[0].Rows[0]["Cluster_City"].ToString())
            {
                ddlCity.Items[r].Selected = true;
            }

        }
    
    }
    protected void btnSummit_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
              string cmdCheck = "SELECT * FROM db_owner.Cluster_master WHERE Cluster_Name='" + txtClusterName.Text+ "' ";

                    SqlDataAdapter da = new SqlDataAdapter(cmdCheck, con);

                    DataSet ds = new DataSet();
                    da.Fill(ds);


                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        lblmessage.Visible = true;
                        lblmessage.Text = "The Cluster are already added";
                        return;

                    }


                    string cmdinsert = "INSERT INTO Cluster_master( Cluster_Name,Updated_By,Updated_On,Cluster_City )VALUES  ('" + txtClusterName.Text + " ', ' " + Session["EMailID"].ToString() + "','" + DateTime.Now + "','"+ddlCity.SelectedItem.Value+"' )";
                com = new SqlCommand(cmdinsert, con);
                com.ExecuteNonQuery();
                com.Dispose();


               

                con.Close();
            string strScript = "alert('Saved Successfully.');location.replace('ViewCluster.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        }

        catch
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }



    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();


            //string cmdCheck = "SELECT * FROM db_owner.Cluster_master WHERE Cluster_Name='" + txtClusterName.Text + "' ";

            //SqlDataAdapter da = new SqlDataAdapter(cmdCheck, con);

            //DataSet ds = new DataSet();
            //da.Fill(ds);


            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //    lblmessage.Visible = true;
            //    lblmessage.Text = "The Cluster are already added";
            //    return;

            //}

            string cmdinsert = "update  Cluster_master set Cluster_Name='" + txtClusterName.Text + " ',Updated_By='" + Session["EMailID"].ToString() + "',Updated_On='" + DateTime.Now + "',Cluster_City='"+ddlCity.SelectedItem.Value+"' where Cluster_id='" + Request.QueryString["ClusterID"].ToString() + "'";
            com = new SqlCommand(cmdinsert, con);
            com.ExecuteNonQuery();
            com.Dispose();

            con.Close();
            string strScript = "alert('Updated Successfully.');location.replace('ViewCluster.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        }

        catch
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewCluster.aspx");
    }
}
