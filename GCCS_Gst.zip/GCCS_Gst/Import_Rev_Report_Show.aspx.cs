using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class Import_Rev_Report_Show : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DataTable dtch;
    DataTable dt;
    DataTable dt1;

    DisplayWrap dw = new DisplayWrap();
    decimal CartingTotal = 0;
    decimal DataProcessingFeeTotal = 0;
    decimal CommunicationFeeTotal = 0;
    decimal HAWBTotal = 0;
    decimal StaxRateTotal = 0;

    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
    decimal SBCessRateTotal = 0;
    decimal KKCessRateTotal = 0;
    decimal DOamountTotal = 0;
    decimal DocahrgesTotal = 0;
    decimal NetAmountTotal = 0;
    decimal tdstotal = 0;
    decimal freighttotal = 0;

    decimal Carting = 0;
    decimal DataProcessingFee = 0;
    decimal CommunicationFee = 0;
    decimal MAWB = 0;
    decimal HAWB = 0;
    decimal srate = 0;

    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
    decimal SBrate = 0;
    decimal KKrate = 0;

    decimal StaxRate = 0;
    decimal SBCessRate = 0;
    decimal KKCessRate = 0;

    decimal DOamount = 0;
    decimal Docahrges = 0;
    decimal NetAmount = 0;
    decimal totalhouse = 0;
    int TotalPcs = 0;
    decimal Gwt = 0;
    decimal ChWt = 0;

    string table = "";
    string query = "";
    // ---- Make Connection From Web.Config File ----
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        if (!IsPostBack)
        {

            string[] airline_name_city_text = Session["airline_city_text"].ToString().Split(',');
            string[] airline_name_city_value = Session["airline_city_value"].ToString().Split(',');
            string[] air_name_val = airline_name_city_value[0].Split('%');
            string FromDate = Session["from_date"].ToString();
            string ToDate = Session["to_date"].ToString();


            Label1.Text = "<table width=100% border=0 cellspacing=0 cellpadding=0  align=center><tr><td colspan=29><br/></td></tr><tr align=center><td colspan=29><h2>Import DO Revenue Report</h2></td></tr><tr align=center><td colspan=29><h3><u>" + FormatDateDD(FromDate) + " - " + FormatDateDD(ToDate) + "</u></h3></td></tr><tr><td colspan=29><br/></td></tr></table>";
            string Table1 = "";

            if (airline_name_city_value[0] == "0")
            {
                query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ") and airline_master.Status=2 order by airline_name";
            }
            else
            {
                query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + airline_name_city_value[0].ToString() + ") order by airline_name";
            }
            Int32 count = 1;
            DataTable dtairline = dw.GetAllFromQuery(query);
            foreach (DataRow drow in dtairline.Rows)
            {
                query = "SELECT * FROM db_owner.ImportChargesHeads WHERE Airline_Detail_ID='" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + "' ";
                dt = dw.GetAllFromQuery(query);

                Table1 = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle1 ><td colspan=29 style=' text-align:left;padding: 0px 0px 0px 30px;'  >" + drow["airline_code"].ToString() + "-" + drow["airline_name"].ToString() + "-" + drow["city_code"].ToString() + "</td></tr>";
                //flight_date
                string query2="";
                if(Convert.ToDateTime(FormatDateMM(ToDate))<=Convert.ToDateTime("06/30/2017"))
                query2 = "SELECT CASE IFA.Status WHEN 'DO Generated' THEN  CASE IFA.shipment_type WHEN 'F' THEN 'FOC'ELSE 'Generate'END ELSE 'Void' END AS status,CONVERT(INT, SUBSTRING(Recipt_No,14,LEN(Recipt_No))) AS reciptno,IFA.Freight_Type, IFA.Import_awb_id,IFS.IGM_NO,IFA.Freight_Chgs,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC ,convert(varchar,IFA.DateOfDeposite,103) as Depositedate,ifa.Payment_Mode,IFA.Import_AWB_ID,IFA.Recipt_No,IFA.Gross_Weight,IFA.Commodity,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFA.issue_date,103) as issue_date,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,CASE WHEN IFA.Agent_Name <>'' THEN IFA.Agent_Name ELSE IFA.Consignee_Name  END AS Consignee_Name,IFA.Shipper_Name ,IFA.Issuing_Carrier_Agent,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,ifa.Origin,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Tds_Cut_By_Agent,0) AS Stax_Amount,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,IFA.Remarks,IFA.shipment_type,ifa.Cheque_no AS checkno,isnull(IFA.MAWBDO_Chgs,0) as MAWBDO_Chgs,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID WHERE CAST( CAST(ifa.Issue_date AS VARCHAR(12)) AS datetime) >= '" + FormatDateMM(FromDate) + "' and CAST( CAST(ifa.Issue_date AS VARCHAR(12)) AS datetime) <='" + FormatDateMM(ToDate) + "' AND IFA.Airline_Detail_ID=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " order by  reciptno";
                else
                    query2 = "SELECT CASE IFA.Status WHEN 'DO Generated' THEN  CASE IFA.shipment_type WHEN 'F' THEN 'FOC'ELSE 'Generate'END ELSE 'Void' END AS status,CONVERT(INT, SUBSTRING(Recipt_No,14,LEN(Recipt_No))) AS reciptno,IFA.Freight_Type, IFA.Import_awb_id,IFS.IGM_NO,IFA.Freight_Chgs,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC ,convert(varchar,IFA.DateOfDeposite,103) as Depositedate,ifa.Payment_Mode,IFA.Import_AWB_ID,IFA.Recipt_No,IFA.Gross_Weight,IFA.Commodity,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFA.issue_date,103) as issue_date,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,CASE WHEN IFA.Agent_Name <>'' THEN IFA.Agent_Name ELSE IFA.Consignee_Name  END AS Consignee_Name,IFA.Shipper_Name ,IFA.Issuing_Carrier_Agent,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,ifa.Origin,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Tds_Cut_By_Agent,0) AS Stax_Amount,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,IFA.Remarks,IFA.shipment_type,ifa.Cheque_no AS checkno,isnull(IFA.MAWBDO_Chgs,0) as MAWBDO_Chgs,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,(Case when IFA.GSTNo is null then IFA.StateCode  else IFA.GStNo end) as GSTNo FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID WHERE CAST( CAST(ifa.Issue_date AS VARCHAR(12)) AS datetime) >= '" + FormatDateMM(FromDate) + "' and CAST( CAST(ifa.Issue_date AS VARCHAR(12)) AS datetime) <='" + FormatDateMM(ToDate) + "' AND IFA.Airline_Detail_ID=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " order by  reciptno";
                DataTable dt2 = dw.GetAllFromQuery(query2);

                if (dt2.Rows.Count > 0)
                {
                    if (Convert.ToDateTime(FormatDateMM(ToDate)) <= Convert.ToDateTime("06/30/2017"))
                    Table1 = Table1 + @"<tr class=HeaderStyle2><td     >S.No</td><td   >DoNo</td><td  nowrap >Do Issue Date</td><td nowrap>Flight No</td><td  nowrap >Flight Date</td><td  >I.G.M</td><td  >Consignee Name</td><td  nowrap >Shipper Name</td><td nowrap >Issuing Carrier Agent</td><td  >AwbNo</td><td  >Pcs</td><td  >ORG</td><td  >DEST</td><td  >CH.Weight</td><td  >GR.Weight</td><td  >Comodity</td><td  >pp/cc</td><td  > HAWB</td><td  > F.O.C</td><td  nowrap>DO amount</td><td  nowrap>DO Charges</td>";
                    else
                        Table1 = Table1 + @"<tr class=HeaderStyle2><td     >S.No</td><td   >DoNo</td><td  nowrap >Do Issue Date</td><td nowrap>Flight No</td><td  nowrap >Flight Date</td><td  >I.G.M</td><td  >Consignee Name</td><td  nowrap >Shipper Name</td><td nowrap >Issuing Carrier Agent</td><td  >AwbNo</td><td  >Pcs</td><td  >ORG</td><td  >DEST</td><td  >CH.Weight</td><td  >GR.Weight</td><td  >Comodity</td><td  >pp/cc</td><td  > HAWB</td><td  > F.O.C</td><td> GST No</td><td  nowrap>DO amount</td><td  nowrap>DO Charges</td>";
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {

                        //charges[i] = dt.Rows[i]["ChargeHeadName"].ToString();

                        if ((Convert.ToInt32(drow["airline_detail_id"].ToString()) == 147)||(Convert.ToInt32(drow["airline_detail_id"].ToString()) == 153))
                        {
                            if (dt.Rows[i]["ChargeHeadName"].ToString() != "MAWB")
                                if (dt.Rows[i]["ChargeHeadName"].ToString() == "HAWB")
                                    Table1 += @"<td   align=center > B/Bulk @400/-" + dt.Rows[i]["ChargeHeadName"].ToString() + "</td>";
                                else
                                    Table1 += @"<td   a >" + dt.Rows[i]["ChargeHeadName"].ToString() + "</td>";
                        }
                        else
                        {
                            if (dt.Rows[i]["ChargeHeadName"].ToString() != "MAWB")
                                if (dt.Rows[i]["ChargeHeadName"].ToString() != "HAWB")
                                    Table1 += @"<td  >" + dt.Rows[i]["ChargeHeadName"].ToString() + "</td>";
                        }

                    }
                    ////Table1 += @"<td>S/TAX</td><td>SBCess/TAX</td><td  >TDS</td><td  >Freight_Chgs</td><td  nowrap>NET Amount</td><td  >Status</td><td  nowrap>Cash/Cheque No</td><td  nowrap>Date Of Deposite</td><td  >Remarks</td>";
                    if (Convert.ToDateTime(FormatDateMM(ToDate)) <= Convert.ToDateTime("06/30/2017"))
                    Table1 += @"<td>S/TAX</td><td>SBCess/TAX</td><td>KKCess/TAX</td><td  >TDS</td><td  >Freight_Chgs</td><td  nowrap>NET Amount</td><td  >Status</td><td  nowrap>Cash/Cheque No</td><td  nowrap>Date Of Deposite</td><td  >Remarks</td>";
                    else
                        Table1 += @"<td>CGST</td><td>SGST</td><td>IGST</td><td  >TDS</td><td  >Freight_Chgs</td><td  nowrap>NET Amount</td><td  >Status</td><td  nowrap>Cash/Cheque No</td><td  nowrap>Date Of Deposite</td><td  >Remarks</td>";

                    for (int j = 0; j < dt2.Rows.Count; j++)
                    {                       
                        Table1 = Table1 + @"<tr class=tabletd ><td  >" + count + "</td><td nowrap >" + dt2.Rows[j]["Recipt_No"].ToString() + "</td><td nowrap >" + dt2.Rows[j]["issue_date"].ToString() + "</td><td  nowrap >" + dt2.Rows[j]["Import_Flight_No"].ToString() + "</td><td    >" + dt2.Rows[j]["flight_date"].ToString() + "</td><td  nowrap >" + dt2.Rows[j]["IGM_NO"].ToString() + "</td><td style=' text-align:left;padding: 0px 0px 0px 10px;'  nowrap >" + dt2.Rows[j]["Consignee_Name"].ToString() + "</td><td style=' text-align:left;padding: 0px 0px 0px 10px;' nowrap >" + dt2.Rows[j]["Shipper_Name"].ToString() + "</td><td style=' text-align:left;padding: 0px 0px 0px 10px;'  nowrap >" + dt2.Rows[j]["Issuing_Carrier_Agent"].ToString() + "</td><td nowrap >" + dt2.Rows[j]["import_awb_no"].ToString() + "</td><td  nowrap >" + dt2.Rows[j]["pcs"].ToString() + "</td><td  nowrap >" + dt2.Rows[j]["Origin"].ToString() + "</td><td  nowrap >" + dt2.Rows[j]["Destination"].ToString() + "</td><td style=' text-align:right;' nowrap >" + dt2.Rows[j]["Charged_Weight"].ToString() + "</td><td style=' text-align:right;' nowrap >" + dt2.Rows[j]["Gross_Weight"].ToString() + "</td><td style=' text-align:right;' nowrap >" + dt2.Rows[j]["Commodity"].ToString() + "</td><td style=' text-align:right;' nowrap > " + dt2.Rows[j]["Freight_Type"].ToString() + "</td><td style=' text-align:right;' nowrap > " + dt2.Rows[j]["No_of_Houses"].ToString() + "</td>";                     
                        TotalPcs += Convert.ToInt32(dt2.Rows[j]["pcs"].ToString());
                        Gwt += decimal.Parse(dt2.Rows[j]["Gross_Weight"].ToString());
                        ChWt += decimal.Parse(dt2.Rows[j]["Charged_Weight"].ToString());
                        //<td>" + dt2.Rows[j]["shipment_type"].ToString() == "F" ? @"Y" : @"N" + @"</td>
                        //Table1+=@"<td>" + dt2.Rows[j]["shipment_type"].ToString()=="F"?"Y":"N"+"</td>";
                        if (dt2.Rows[j]["shipment_type"].ToString() == "F")
                            Table1 += @"<td style=' text-align:right;' nowrap > Y </td>";
                        else
                            Table1 += @"<td style=' text-align:right;' nowrap > N </td>";
                        count++;
                        totalhouse += Convert.ToDecimal(dt2.Rows[j]["No_of_Houses"].ToString());
                        if(Convert.ToDateTime(FormatDateMM(ToDate))>Convert.ToDateTime("06/30/2017"))
                            Table1 += @"<td style=' text-align:right;' nowrap >"+dt2.Rows[j]["GstNo"].ToString()+"</td>";
                        string queryforcharges = "SELECT * FROM db_owner.ImportFlightAwb_Trans WHERE ImportAwbID=" + dt2.Rows[j]["Import_AWB_ID"].ToString() + "";
                        dtch = dw.GetAllFromQuery(queryforcharges);
                        for (int k = 0; k < dtch.Rows.Count; k++)
                        {
                            if (dtch.Rows[k]["ChargeName"].ToString() == "MAWB")
                                MAWB = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                            else if (dtch.Rows[k]["ChargeName"].ToString() == "HAWB")
                                HAWB = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                            else if (dtch.Rows[k]["ChargeName"].ToString() == "Carting")
                                Carting = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                            else if (dtch.Rows[k]["ChargeName"].ToString() == "StaxRate")
                            {
                                StaxRate = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                                srate = Convert.ToDecimal(dtch.Rows[k]["ChargeRate"].ToString()); ;
                            }
                            else if (dtch.Rows[k]["ChargeName"].ToString() == "CommunicationFee")
                                CommunicationFee = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                            else if (dtch.Rows[k]["ChargeName"].ToString() == "DataProcessingFee")
                                DataProcessingFee = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                            else if (dtch.Rows[k]["ChargeName"].ToString() == "SBCess")
                            {
                                SBCessRate = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                                SBrate = Convert.ToDecimal(dtch.Rows[k]["ChargeRate"].ToString()); ;
                            }
                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            else if (dtch.Rows[k]["ChargeName"].ToString() == "KKCess")
                            {
                                KKCessRate = Convert.ToDecimal(dtch.Rows[k]["ChargeAmount"].ToString());
                                KKrate = Convert.ToDecimal(dtch.Rows[k]["ChargeRate"].ToString()); ;
                            }
                        }
                        if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
                        {
                            DOamount = MAWB;
                            Docahrges = MAWB;
                        }
                        else if (drow["airline_detail_id"].ToString() == "159")
                        {
                            //*******************added on 15June2015 :For KE-MUM, flt No HY-127 case******//
                            if ((dt2.Rows[j]["Import_flight_No"].ToString() == "HY-127" || dt2.Rows[j]["Import_flight_No"].ToString() == "KE-9343" || dt2.Rows[j]["Import_flight_No"].ToString() == "KE-9311" || dt2.Rows[j]["Import_flight_No"].ToString() == "KE-9313"))
                            {
                                ////MAWB = Math.Floor(Convert.ToDecimal(MAWB) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBrate)) / 100)));
                                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                MAWB = Math.Floor(Convert.ToDecimal(MAWB) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBrate) + Convert.ToDecimal(KKrate)) / 100)));
                                DOamount = MAWB + HAWB;
                            }
                            else
                            {
                                DOamount = MAWB + HAWB;
                            }
                            //*******************End of 15June2015 :For KE-MUM, flt No HY-127 case******//
                            ////DOamount = MAWB + HAWB;
                            if (StaxRate.ToString() == "0.00")
                                Docahrges = DOamount;
                            else
                                //*******************added on 15June2015 :For KE-MUM, flt No HY-127 case******//
                                if ((dt2.Rows[j]["Import_flight_No"].ToString() == "HY-127" || dt2.Rows[j]["Import_flight_No"].ToString() == "KE-9343" || dt2.Rows[j]["Import_flight_No"].ToString() == "KE-9311" || dt2.Rows[j]["Import_flight_No"].ToString() == "KE-9313"))
                                {
                                    Docahrges = DOamount;
                                }
                                else
                                {
                                    ////Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBrate)) / 100)));
                                    Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBrate) + Convert.ToDecimal(KKrate)) / 100)));
                                }
                            //*******************End of 15June2015 :For KE-MUM, flt No HY-127 case******//
                                /////Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate)) / 100)));
                        }
                        else
                        {
                            DOamount = MAWB + HAWB;

                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            Docahrges = DOamount - StaxRate - SBCessRate - KKCessRate;
                        }


                        //Payment_Mode  

                        Table1 += @"<td style=' text-align:right;'>" + DOamount + "</td><td style=' text-align:right;'>" + Docahrges + "</td>";

                        for (int l = 0; l < dt.Rows.Count; l++)
                        {
                            if ((Convert.ToInt32(drow["airline_detail_id"].ToString()) == 147)||(Convert.ToInt32(drow["airline_detail_id"].ToString()) == 153))
                            {
                                if (dt.Rows[l]["ChargeHeadName"].ToString() != "MAWB")
                                    if (dt.Rows[l]["ChargeHeadName"].ToString() == "HAWB")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + HAWB + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "Carting")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + Carting + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "StaxRate")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + StaxRate + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "CommunicationFee")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + CommunicationFee + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "DataProcessingFee")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + DataProcessingFee + "</td>";

                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "SBCess")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + SBCessRate + "</td>";


       //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "KKCess")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + KKCessRate + "</td>";
                            }
                            else
                            {

                                if (dt.Rows[l]["ChargeHeadName"].ToString() != "MAWB")
                                    if (dt.Rows[l]["ChargeHeadName"].ToString() != "HAWB")
                                        if (dt.Rows[l]["ChargeHeadName"].ToString() == "Carting")
                                            Table1 += @"<td  align=right style=' text-align:right;' > " + Carting + "</td>";
                                        else if (dt.Rows[l]["ChargeHeadName"].ToString() == "StaxRate")
                                            Table1 += @"<td  align=right style=' text-align:right;' > " + StaxRate + "</td>";
                                        else if (dt.Rows[l]["ChargeHeadName"].ToString() == "CommunicationFee")
                                            Table1 += @"<td  align=right style=' text-align:right;' > " + CommunicationFee + "</td>";
                                        else if (dt.Rows[l]["ChargeHeadName"].ToString() == "DataProcessingFee")
                                            Table1 += @"<td  align=right style=' text-align:right;' > " + DataProcessingFee + "</td>";
                                        else if (dt.Rows[l]["ChargeHeadName"].ToString() == "SBCess")
                                            Table1 += @"<td  align=right style=' text-align:right;' > " + SBCessRate + "</td>";


                                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                        else if (dt.Rows[l]["ChargeHeadName"].ToString() == "KKCess")
                                            Table1 += @"<td  align=right style=' text-align:right;' > " + KKCessRate + "</td>";
                            }

                        }

                        ////Table1 += @"<td style=' text-align:right;'>" + StaxRate + "</td><td style=' text-align:right;'>" + SBCessRate + "</td><td style=' text-align:right;' >" + dt2.Rows[j]["Stax_Amount"].ToString() + "</td><td style=' text-align:right;'>" + dt2.Rows[j]["Total_Collection_CC"].ToString() + "</td>";
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        Table1 += @"<td style=' text-align:right;'>" + StaxRate + "</td><td style=' text-align:right;'>" + SBCessRate + "</td><td style=' text-align:right;'>" + KKCessRate + "</td><td style=' text-align:right;' >" + dt2.Rows[j]["Stax_Amount"].ToString() + "</td><td style=' text-align:right;'>" + dt2.Rows[j]["Total_Collection_CC"].ToString() + "</td>";
                        if (dt2.Rows[j]["Payment_Mode"].ToString() == "1")
                        {
                            // Carting StaxRate CommunicationFee DataProcessingFee
                            if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
                                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                //////NetAmount = DOamount + StaxRate+SBCessRate + Carting + CommunicationFee + DataProcessingFee + HAWB - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());
                                NetAmount = DOamount + StaxRate + SBCessRate + KKCessRate + Carting + CommunicationFee + DataProcessingFee + HAWB - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());
                            else
                                ////NetAmount = Docahrges + StaxRate+SBCessRate + Carting + CommunicationFee + DataProcessingFee - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());
                                NetAmount = Docahrges + StaxRate + SBCessRate + KKCessRate + Carting + CommunicationFee + DataProcessingFee - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());
                            Table1 += @"<td style=' text-align:right;' >" + NetAmount + "</td><td style=' text-align:right;' >" + dt2.Rows[j]["Status"].ToString() + "</td><td style=' text-align:right;'>By cash</td><td style=' text-align:right;' >" + dt2.Rows[j]["Depositedate"].ToString() + "</td>";
                        }
                        else
                        {
                            if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))

                                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                ////NetAmount = DOamount + StaxRate+SBCessRate + Carting + CommunicationFee + DataProcessingFee + HAWB - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());
                                NetAmount = DOamount + StaxRate + SBCessRate + KKCessRate + Carting + CommunicationFee + DataProcessingFee + HAWB - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());
                            else
                                ////NetAmount = Docahrges + StaxRate+SBCessRate + Carting + CommunicationFee + DataProcessingFee - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());
                                NetAmount = Docahrges + StaxRate + SBCessRate + KKCessRate + Carting + CommunicationFee + DataProcessingFee - Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString()) + Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());

                            Table1 += @"<td style=' text-align:right;' >" + NetAmount + "</td><td style=' text-align:right;' >" + dt2.Rows[j]["Status"].ToString() + "</td><td style=' text-align:right;' >" + dt2.Rows[j]["checkno"].ToString() + "</td><td style=' text-align:right;' >" + dt2.Rows[j]["Depositedate"].ToString() + "</td>";
                        }

                        Table1 += @"<td style=' text-align:right;' nowrap>" + dt2.Rows[j]["Remarks"].ToString() + "</td></tr>";

                        CartingTotal += Carting;
                        DataProcessingFeeTotal += DataProcessingFee;
                        CommunicationFeeTotal += CommunicationFee;
                        StaxRateTotal += StaxRate;

                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        SBCessRateTotal += SBCessRate;
                        KKCessRateTotal += KKCessRate;

                        DOamountTotal += DOamount;
                        DocahrgesTotal += Docahrges;
                        freighttotal += Convert.ToDecimal(dt2.Rows[j]["Total_Collection_CC"].ToString());

                        if ((Convert.ToInt32(drow["airline_detail_id"].ToString()) == 147)||(Convert.ToInt32(drow["airline_detail_id"].ToString()) == 153))
                            HAWBTotal += HAWB;

                        tdstotal += Convert.ToDecimal(dt2.Rows[j]["Stax_Amount"].ToString());

                        NetAmountTotal += NetAmount;

                        NetAmount = 0;
                        Carting = 0;
                        DataProcessingFee = 0;
                        CommunicationFee = 0;
                        MAWB = 0;
                        HAWB = 0;
                        StaxRate = 0;

                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        SBCessRate = 0;
                        KKCessRate = 0;

                        DOamount = 0;
                        Docahrges = 0;

                    }
                    if (Convert.ToDateTime(FormatDateMM(ToDate)) <= Convert.ToDateTime("06/30/2017"))
                    Table1 += @"<tr class=GrandTotal><td  colspan=10> Total</td><td align=right style=' text-align:right;'>" + TotalPcs + "</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>" + ChWt + "</td><td align=right style=' text-align:right;'>" + Gwt + "</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>" + totalhouse + "</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>" + DOamountTotal + "</td><td align=right style=' text-align:right;'>" + DocahrgesTotal + "</td>";
                    else
                        Table1 += @"<tr class=GrandTotal><td  colspan=10> Total</td><td align=right style=' text-align:right;'>" + TotalPcs + "</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>" + ChWt + "</td><td align=right style=' text-align:right;'>" + Gwt + "</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>" + totalhouse + "</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>&nbsp;</td><td align=right style=' text-align:right;'>" + DOamountTotal + "</td><td align=right style=' text-align:right;'>" + DocahrgesTotal + "</td>";



                    for (int l = 0; l < dt.Rows.Count; l++)
                    {
                        if ((Convert.ToInt32(drow["airline_detail_id"].ToString()) == 147)||(Convert.ToInt32(drow["airline_detail_id"].ToString()) == 153))
                        {
                            if (dt.Rows[l]["ChargeHeadName"].ToString() != "MAWB")
                                if (dt.Rows[l]["ChargeHeadName"].ToString() == "HAWB")
                                    Table1 += @"<td  align=right style=' text-align:right;' > " + HAWBTotal + "</td>";
                                else if (dt.Rows[l]["ChargeHeadName"].ToString() == "Carting")
                                    Table1 += @"<td  align=right style=' text-align:right;' > " + CartingTotal + "</td>";
                                else if (dt.Rows[l]["ChargeHeadName"].ToString() == "StaxRate")
                                    Table1 += @"<td  align=right style=' text-align:right;' > " + StaxRateTotal + "</td>";
                                else if (dt.Rows[l]["ChargeHeadName"].ToString() == "CommunicationFee")
                                    Table1 += @"<td  align=right style=' text-align:right;' > " + CommunicationFeeTotal + "</td>";
                                else if (dt.Rows[l]["ChargeHeadName"].ToString() == "DataProcessingFee")
                                    Table1 += @"<td  align=right style=' text-align:right;' > " + DataProcessingFeeTotal + "</td>";
                                else if (dt.Rows[l]["ChargeHeadName"].ToString() == "SBCess")
                                    Table1 += @"<td  align=right style=' text-align:right;' > " + SBCessRateTotal + "</td>";

       //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                else if (dt.Rows[l]["ChargeHeadName"].ToString() == "KKCess")
                                    Table1 += @"<td  align=right style=' text-align:right;' > " + KKCessRateTotal + "</td>";

                        }

                        else
                        {

                            if (dt.Rows[l]["ChargeHeadName"].ToString() != "MAWB")
                                if (dt.Rows[l]["ChargeHeadName"].ToString() != "HAWB")
                                    if (dt.Rows[l]["ChargeHeadName"].ToString() == "Carting")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + CartingTotal + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "StaxRate")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + StaxRateTotal + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "CommunicationFee")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + CommunicationFeeTotal + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "DataProcessingFee")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + DataProcessingFeeTotal + "</td>";
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "SBCess")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + SBCessRateTotal + "</td>";

       //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                                    else if (dt.Rows[l]["ChargeHeadName"].ToString() == "KKCess")
                                        Table1 += @"<td  align=right style=' text-align:right;' > " + KKCessRateTotal + "</td>";
                        }

                    }

                    ////Table1 += @"<td align=right style=' text-align:right;'>" + StaxRateTotal + "</td><td align=right style=' text-align:right;'>" + SBCessRateTotal + "</td><td align=right style=' text-align:right;'>" + tdstotal + "</td><td align=right style=' text-align:right;'>" + freighttotal + "</td><td align=right style=' text-align:right;' >" + NetAmountTotal + "</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                    Table1 += @"<td align=right style=' text-align:right;'>" + StaxRateTotal + "</td><td align=right style=' text-align:right;'>" + SBCessRateTotal + "</td><td align=right style=' text-align:right;'>" + KKCessRateTotal + "</td><td align=right style=' text-align:right;'>" + tdstotal + "</td><td align=right style=' text-align:right;'>" + freighttotal + "</td><td align=right style=' text-align:right;' >" + NetAmountTotal + "</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";

                    Table1 += @"</tr>";
                }
                else
                {
                    Table1 += @"<tr class=text><td class=boldtext style=""color: Red;font-family:verdana;font-size:12px;  text-align: center;"" colspan=6>No record found.</td></tr>";

                }
                HAWBTotal = 0;
                CartingTotal = 0;
                StaxRateTotal = 0;
                SBCessRateTotal = 0;

                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                KKCessRateTotal = 0;
                CommunicationFeeTotal = 0;
                DataProcessingFeeTotal = 0;
                totalhouse = 0;
                DOamountTotal = 0;
                DocahrgesTotal = 0;
                TotalPcs = 0;
                Gwt = 0;
                ChWt = 0;
                NetAmountTotal = 0;
                Table1 += "</table><br>";
                Label2.Text += Table1;

            }


            //   Label2.Text += Table1;


        }


    }


    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateDD(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void btnexcel_Click(object sender, EventArgs e)
    {
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=InvoiceReport.xls");
        Response.ContentType = "application/vnd.ms-excel";
        StringWriter sw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(sw);
        divexl.RenderControl(htw);
        FileInfo fi = new FileInfo(Server.MapPath("include/Table.css"));
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        StreamReader sr = fi.OpenText();
        while (sr.Peek() >= 0)
            sb.Append(sr.ReadLine());
        sr.Close();
        Response.Write("<html><head><style type='text/css' rel='stylesheet'>" + sb.ToString() + "</style><head>" + sw.ToString() + "</html>");
        Response.Write(sw.ToString());
        Response.End();
    }

}
