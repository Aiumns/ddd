using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


//This Page is Design & Coding By Alok Date:18.11.2007
public partial class Agent_History : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    public string strAgent = "";
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            strAgent = "<script>var FillAgent=new Array(" + getAgentName() + ")</script>";
            Search();
        }
    }
    public string getAgentName()
    {
        string strAgentName = "";
        con = new SqlConnection(strCon);
        try
        {

            string selectGroupName = "SELECT distinct(Airline_Name) FROM Airline_Master";
            com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strAgentName == "")
                    strAgentName = "'" + Convert.ToString(dr["Airline_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strAgentName = strAgentName + "," + "'" + Convert.ToString(dr["Airline_Name"]).ToString().ToUpper().Trim() + "'";
            }
            dr.Close();
            com.Dispose();
            con.Close();


        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strAgentName;
    }
    // function for bind grid
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txtsearch.Text == "")
            {
                selectQ = "select Agent_History_ID,Agent_Code,Login_ID,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,IATA_Code,IATA_Commission,TaxDeductiononSource,TDS_Exemption_Limit,Credit_Limit,Used_Limit,Amount_Paid,SurCharge,Parent_Name,Branch_Status,CSR_Contact_Person,CSR_Email,Pan_No,Status,Entered_By,convert(varchar,Entered_On,103) as 'Entered_On' from Agent_History order by Agent_Name";
            }

            else
            {
                selectQ = "select Agent_History_ID,Agent_Code,Login_ID,Login_Password,Group_Name,Airline_Access,Belongs_To_City,Agent_Name,Agent_Address,Agent_Phone,Agent_Fax,Agent_Email,Concerned_Person,IATA_Code,IATA_Commission,TaxDeductiononSource,TDS_Exemption_Limit,Credit_Limit,Used_Limit,Amount_Paid,SurCharge,Parent_Name,Branch_Status,CSR_Contact_Person,CSR_Email,Pan_No,Status,Entered_By,convert(varchar,Entered_On,103) as 'Entered_On' from Agent_History  where Agent_Name like '" + txtsearch.Text + "%' order by Agent_Name";
            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdhistory.DataSource = dt;
            grdhistory.DataBind();
            con.Close();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void grdhistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdhistory.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
}
