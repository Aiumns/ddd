﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
public partial class Do_Cancel : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    // ---- Make Connection From Web.Config File ----
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    #region from  do print
   // decimal KE_MUM_Tds = 0;
   // decimal KE_MUM_frt = 0;
   // bool flagtable = true;
   // //Declare public variables here 
   // //SqlConnection con;
   //// SqlCommand com;
   // DisplayWrap dw = new DisplayWrap();
   // string Import_AWB_ID;
   // decimal Stax = 0;
   // //****************Updated On 03 May2016: KKCess tax Apply system*****************
   // decimal SBcess = 0;
   // decimal KKcess = 0;
   // decimal mawcharge = 0;
   // string table = null;
   // decimal cartingcharges = 0;
   // string CompAddress = "";

   // #region Gst newly Added
   // decimal GSTDoCharges = 0;
   // decimal IGSTChargs = 0;
   // decimal SGSTChargs = 0;
   // decimal CGSTChargs = 0;
   // decimal totalTds = 0;
   // #endregion Gst newly Added

   // string strAirline_name = "", Label1str = "", awbno = "", flt_no = "", import_rotation_No = "", arr_flight_date = "", contents = "", from = "", to = "", notify = "", IGMNo = "", pay_amt = "", straddress = "", issue_date = "", recipt_no = "", MawbDo_Chgs = "0", HawbDo_Chgs = "0", no_of_Houses = "", payment_mode = "", flight_date = "", part_pcs = "", HAWBChrg = "0", STAXRATE = "0", SBcessRATE = "0", KKcessRATE = "0", Airportadress = "";
   // decimal pcs = 0, frt_chgs = 0, total = 0;
   // string OldAwb_ReciptNo = "";
   // bool Flag = false;

   // /// <summary>
   // /// Making Connection from web.config
   // /// </summary>
   // /// 

   // //string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
   // string AIrwayBill_No = "";
   // string Airline_id = "";
   // int city_id = 0;
   // string FlightNo = "";
   // string CompGstNo = "07";
   // string AgentGstNo = "08";
   // string innerhtml = string.Empty;
   // string TrFreightChrgsCChtml = string.Empty;
   // string lblAddress1html = string.Empty;
   // string lblAddresshtml = string.Empty;
   // string Space6html = string.Empty;
   // string PartShipmentCasehtml = string.Empty;
   // string lblAirlineStaxhtml = string.Empty;
   // string lblairlinenamehtml = string.Empty;
   // string lblAirlineNmehtml = string.Empty;
   // string AmtDescphtml_Sno = string.Empty;
   // string lblheadairlinenamehtml = string.Empty;
   // string lblremarkshtml = string.Empty;
   // string trchennaihtml = string.Empty;
   // string trmumhtml = string.Empty;
   // string trdelhtml = string.Empty;
   // string imgDeliveryAirlogohtml = string.Empty;
   // string imgReciptairlogohtml = string.Empty;
   // string lblchlblchwthtml = string.Empty;
   // string blanktrhtml = string.Empty;
   // string lblName2html = string.Empty;
   // string lblNotifyhtml = string.Empty;
   // string lblNotifyDohtml = string.Empty;
   // string TotalLinehtml = string.Empty;
   // string lblDatehtml = string.Empty;
   // //string lblFlightDatehtml = string.Empty;
   // string lblSno2html = string.Empty;
   // // string Tr5html = string.Empty;
   // string lblNamehtml = string.Empty;
   // string lblfreighthtml = string.Empty;
   // string TotalSpacehtml = string.Empty;
   // string lblInclusivehtml = string.Empty;
   // string Tr4html = string.Empty;
   // string Tr1html = string.Empty;
   // string Space5html = string.Empty;
   // string Space5html_2 = string.Empty;
   // string lblAddresshtml_lbldate2 = string.Empty;
   // string lblFlightDatehtml_lbligmnr = string.Empty;
   // string lblFlightDatehtml_lblFlightDate = string.Empty;
   // string lblFlightDatehtml_lblFlightno = string.Empty;
   // string Tr5html_lblBreakupTotal = string.Empty;
   // string Tr5html_lblTds = string.Empty;
   // string Tr5html_lblRecivedAmt = string.Empty;
   // string AmtDescphtml_Label1 = string.Empty;
   // string div2html = string.Empty;
   // string div2html_1 = string.Empty;
   // string div2html_2 = string.Empty;
   // string div2html_3 = string.Empty;
   // string div2html_4 = string.Empty;
   // string div2html_5 = string.Empty;
   // string Space3html_1 = string.Empty;
   // string lblAwbnohtml = string.Empty;
   // string lblPartPschtml = string.Empty;
   // string lblpppschtml = string.Empty;
   // string lblPcshtml = string.Empty;
   // string lblWthtml = string.Empty;
   // string lblWtVal = string.Empty;
   // string lblcommdyhtml = string.Empty;
   // string Space3html_2 = string.Empty;
   // string lblPartPschtml_Begin = string.Empty;
   // string trchennaihtml_lblSnochennai = string.Empty;
   // string trmumhtml_lblSnomum = string.Empty;
   // string trdelhtml_lblSno = string.Empty;
   // //string Space3html_2 = string.Empty;
   // string[] strawbid = new string[] { };
   // //int jj = 0;
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        // ---- Checking  Validation from Java Script
        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
        {
            //by jj
            //txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
           // txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            ShowAirline();
            #region Cancel Do
//            if (Request.QueryString["AWBID"] != null)
//            {
//                #region if 1 condition
//                strawbid = Regex.Split(Request.QueryString["AWBID"], ",");
//                //strawbid[jj].ToString();               
//                for (int jj = 0; jj < strawbid.Length - 1; jj++)
//                {
//                    lblTds.Text = "0";
//                    Tr5html_lblTds += @"<tr id='tds'>
//                            <td style='width: 290px; text-align: left'>
//                                <label ID='Label7' Font-Names='Verdana' Font-Size='Smaller'
//                                    Font-Bold='True'>Less Agent Tds:</label>
//                            </td>
//                            <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                <label ID='lblTds' Font-Bold='True'
//                                    Font-Names='Verdana' Font-Size='8pt'>" + Convert.ToString(totalTds) + @"</label>
//                            </td>
//                           </tr><tr id='Tr6' style='font-size: 12pt'>
//                            <td colspan='4' style='text-align: left'>
//                                <label ID='Label8' CssClass='text' ></label>
//                            </td>
//                            </tr>";
//                    // innerhtml = @"<div style='width:790px;'><table style='width: 790px;'>"; 
//                    DataTable dtcheckAwbexist = dw.GetAllFromQuery("select Import_Awb_No,Payment_Mode,ia.Airline_Detail_Id,ad.Belongs_To_City,iflight.Import_Flight_No from db_owner.Import_Flight_AWB ia INNER JOIN dbo.Airline_Detail ad ON ad.Airline_Detail_ID =ia.Airline_Detail_Id INNER JOIN db_owner.Import_Flights iflight ON ia.Import_Flight_ID = iflight.Import_Flight_ID  where Import_Awb_Id=" + strawbid[jj] + "");
//                    //Gst

//                    #region Gst
//                    if (dtcheckAwbexist.Rows.Count > 0)
//                    {
//                        DataTable dtCompDt = dw.GetAllFromQuery("select Company_address from Company_Master c inner join airline_detail ad on c.company_id=ad.company_id where ad.airline_detail_id=" + dtcheckAwbexist.Rows[0]["Airline_Detail_Id"].ToString() + " ");
//                        if (dtCompDt.Rows != null || dtCompDt.Rows.Count > 0)
//                        {
//                            CompAddress = dtCompDt.Rows[0]["Company_address"].ToString();
//                        }
//                    }
//                    #endregion

//                    #region Outer 1
//                    //End of Gst
//                    if (dtcheckAwbexist.Rows[0]["Payment_Mode"].ToString() == "1")
//                    {
//                        //Spacehide1.Visible = false;
//                        ////Spacehide2.Visible = false;
//                        //Spacehide3.Visible = false;
//                        //SpaceHide4.Visible = false;
//                    }
//                    Airline_id = dtcheckAwbexist.Rows[0]["Airline_Detail_Id"].ToString();
//                    FlightNo = dtcheckAwbexist.Rows[0]["Import_Flight_No"].ToString();
//                    if (Airline_id == "159" || Airline_id == "160")
//                    {
//                        #region Page.ResolveUrl("./images/Korean-Air.gif");
//                        if (Airline_id == "159" && FlightNo == "HY-127")
//                        {
//                            #region Page.ResolveUrl("./images/uzbekistan.jpg");
//                            imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/uzbekistan.jpg");
//                            imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
//                            //string images = Page.ResolveUrl("./images/uzbekistan.jpg");
//                            string images = "https://www.aspsnippets.com/images/Blue/Logo.png";

//                            imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";

//                            //string images2 = Page.ResolveUrl("./images/Korean-Air.gif");
//                            imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                            #endregion
//                        }
//                        else
//                        {
//                            #region Page.ResolveUrl("./images/Korean-Air.gif");
//                            imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
//                            imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
//                            // string images = Page.ResolveUrl("./images/Korean-Air.gif");
//                            string images = Page.ResolveUrl("https://www.aspsnippets.com/images/Blue/Logo.png");
//                            imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";

//                            imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                            #endregion
//                        }
//                        #endregion
//                    }
//                    else if (Airline_id == "158")
//                    {
//                        #region Page.ResolveUrl("./images/Korean-Air.gif");
//                        if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                        {
//                            imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
//                            imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
//                            //string images = Page.ResolveUrl("./images/Korean-Air.gif");
//                            string images = Page.ResolveUrl("https://www.aspsnippets.com/images/Blue/Logo.png");
//                            imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                            imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                        }
//                        else
//                        {
//                            imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/uzbekistan.jpg");
//                            imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
//                            // string images = Page.ResolveUrl("./images/uzbekistan.jpg");
//                            string images = Page.ResolveUrl("https://www.aspsnippets.com/images/Blue/Logo.png");
//                            imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                            string images2 = Page.ResolveUrl("./images/Korean-Air.gif");
//                            imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                        }
//                        #endregion
//                    }
//                    else if (Airline_id == "150" || Airline_id == "153")
//                    {
//                        #region Page.ResolveUrl("./images/THY_Logo_2011-(1).jpg");
//                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/THY_Logo_2011-(1).jpg");
//                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/THY_Logo_2011-(1).jpg");
//                        //string images = Page.ResolveUrl("./images/THY_Logo_2011-(1).jpg");
//                        string images = Page.ResolveUrl("https://www.aspsnippets.com/images/Blue/Logo.png");
//                        imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                        imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                        #endregion
//                    }
//                    else if (Airline_id == "148")
//                    {
//                        #region Page.ResolveUrl("./images/malaysia-airlines.jpg");
//                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/malaysia-airlines.jpg");
//                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/malaysia-airlines.jpg");
//                        //string images = Page.ResolveUrl("./images/malaysia-airlines.jpg");
//                        string images = Page.ResolveUrl("https://www.aspsnippets.com/images/Blue/Logo.png");
//                        imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                        imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";
//                        #endregion
//                    }
//                    else if (Airline_id == "147")
//                    {
//                        //comming  
//                        #region lblheadairlinename.Visible = false;  lblairlinename.Visible = false;
//                        trremarks.Visible = true;

//                        lblremarkshtml = @" <tr id='trremarks'  visible='false'>
//                            <td colspan='4'><label ID='Label2'  Font-Bold='True' Font-Size='8pt'> Remark:-</label>                 
//                                 <label ID='lblremarks' Font-Size='8pt'></label>   
//                            </td>
//                        </tr>
//                        <tr>
//                            <td colspan='4'>
//                                ---------------------------------------------------------------------------------------------------------------------
//                            </td>
//                        </tr>";

//                        lblAirlineNmehtml = @"<tr>
//                        <td colspan=3 style='height: 10px'>
//                        </td>
//                        <td class='text' style='height: 10px'>
//                             <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'></label>
//                        </td></tr>";

//                        lblheadairlinename.Visible = false;
//                        lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'></label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";

//                        lblairlinename.Visible = false;
//                        lblairlinenamehtml = string.Empty;
//                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/mascar_logo.gif");

//                        // string images = Page.ResolveUrl("./images/mascar_logo.gif");
//                        string images = Page.ResolveUrl("https://www.aspsnippets.com/images/Blue/Logo.png");
//                        imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";

//                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/mascar_logo.gif");
//                        string images2 = Page.ResolveUrl("./images/mascar_logo.gif");
//                        imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td>
//                                            </tr>";
//                        #endregion
//                    }
//                    else if (Airline_id == "169" || Airline_id == "169")
//                    {
//                        #region Airline_id == "169" || Airline_id == "169" Page.ResolveUrl("./images/MegaMaldives.gif");
//                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/MegaMaldives.gif");
//                        //string images = Page.ResolveUrl("./images/mascar_logo.gif");
//                        string images = Page.ResolveUrl("https://www.aspsnippets.com/images/Blue/Logo.png");
//                        imgReciptairlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td></tr>";

//                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/MegaMaldives.gif");
//                        string images2 = Page.ResolveUrl("./images/mascar_logo.gif");
//                        imgDeliveryAirlogohtml = @"<tr><td style='height: 15px;' colspan=2>
//                                                &nbsp;
//                                            </td>
//                                            <td style='height: 15px;' align=center colspan=2>
//                                                <img src=" + images + @" width=100px />
//                                            </td>
//                                            </tr>";
//                        #endregion
//                    }
//                    city_id = Convert.ToInt32(dtcheckAwbexist.Rows[0]["Belongs_To_City"].ToString());
//                    if (city_id == 6)
//                    {
//                        #region trmum.Visible = false; trchennai.Visible = false;trdel.Visible = true;
//                        trdel.Visible = true;
//                        trmum.Visible = false;
//                        trchennai.Visible = false;
//                        trmumhtml = string.Empty;
//                        //trdelhtml = string.Empty;
//                        trchennaihtml = string.Empty;
//                        trdelhtml = @"<tr id=trdel>
//                            <td style=height: 25px>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                        webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px>The
//                                        Collector of Customs<br />
//                                        Cargo Terminal(Import)<br />
//                                        I.G.I. Airport<br />
//                                        New Delhi</span></span>
//                            </td>
//                            <td style=height: 50px>
//                            </td>
//                            <td style=height: 50px; text-align: right;>
//                                <span style=font-size: 7pt; font-family: Verdana>Sr.No:</span>
//                            </td>
//                            <td style='height: 50px,font-weight:bold;'>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px>";
//                        #endregion
//                    }
//                    else if (city_id == 18)
//                    {
//                        //comming
//                        #region  trchennai.Visible = false; trdel.Visible = false; trmum.Visible = true;
//                        trchennai.Visible = false;
//                        trdel.Visible = false;
//                        trmum.Visible = true;
//                        // trmumhtml = string.Empty;
//                        trdelhtml = string.Empty;
//                        trchennaihtml = string.Empty;
//                        trmumhtml = @"<tr id=trmum> 
//                            <td style='height: 25px'>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                        webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px>
//                                        The Collector of Customs<br />
//                                        Chhatrapati Shivaji International Airport<br />
//                                        Sahar Cargo Complex, Andheri East.<br />
//                                        Mumbai-400099.</span></span>
//                            </td>
//                            <td style=height: 50px>
//                            </td>
//                            <td style='height: 50px; text-align: right;'>
//                                <span style='font-size: 7pt; font-family: Verdana'>Sr.No:</span>
//                            </td>
//                            <td style='height: 50px,font-weight:bold;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>";
//                        #endregion
//                    }
//                    else
//                    {
//                        #region  trdel.Visible = false; trmum.Visible = false; trchennai.Visible = true;
//                        trdel.Visible = false;
//                        trmum.Visible = false;
//                        trchennai.Visible = true;
//                        trmumhtml = string.Empty;
//                        trdelhtml = string.Empty;
//                        //trchennaihtml = string.Empty;
//                        trchennaihtml = @"<tr id='trchennai'>   
//                        <td style='height: 25px'>
//                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                    style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                    webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px'>THE
//                                    COMMISSIONER OF CUSTOMS<br />
//                                    CARGO TERMINAL<br />
//                                    CHENNAI 600 027. </span></span>
//                        </td>
//                        <td style='height: 50px'>
//                        </td>
//                        <td style='height: 50px; text-align: right;'>
//                            <span style='font-size: 7pt; font-family: Verdana'>Sr.No:</span>
//                        </td>
//                        <td style='height: 50px'>
//                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                    webkit-border-vertical-spacing: 2px'>";
//                        #endregion
//                    }
//                    #endregion

//                    AIrwayBill_No = dtcheckAwbexist.Rows[0]["Import_Awb_No"].ToString();
//                    DataTable dtawbexist = dw.GetAllFromQuery("select Import_Awb_No from Import_Flight_Awb where Import_Awb_No='" + AIrwayBill_No + "' and Import_Awb_Id=" + strawbid[jj] + " and shipment_type='F' and Part_shipment_type='Y' ");
//                    //*******************CASE OF PART SHIPMENT********************
//                    if (Request.QueryString["Mode"] != null)
//                        Flag = true;
//                    if (dtawbexist.Rows.Count > 0 && !Flag)
//                    {
//                        #region  CASE OF PART SHIPMENT
//                        DataTable dtDo_GenerateStatus_check = dw.GetAllFromQuery("select Import_Awb_ID,Import_Awb_No,D0_Generate_Status from Import_Flight_Awb where Import_Awb_No='" + AIrwayBill_No + "' and D0_Generate_Status='YES'");
//                        if (dtDo_GenerateStatus_check.Rows.Count > 0)
//                        {
//                            //document by jj
//                            //space3.visible=false; TotalLine.Visible = false;TotalSpace.Visible = false;
//                            //Space3.Visible = false;Space6.Visible = true; PartShipmentCase.Visible = true;
//                            //#End
//                            #region if condition comming lblAddress1.Visible = true; lblAddress.Visible = true;AmtDescp.Visible = false; Tr1.Visible = false; Tr2.Visible = false;Tr4.Visible = false;Tr5.Visible = false;lblTds.Visible = false;
//                            lblAddress1.Visible = true; lblAddress.Visible = true;
//                            #region started lblAddress1 to lblAddress
//                            lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                            lblAddresshtml = @"<tr>
//                                    <td style='height: 50px;' colspan='2'>
//                                        <div style='width: 320px;'>
//                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                    webkit-border-vertical-spacing: 2px'>
//                                                    <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                    &nbsp;
//                                                    <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                    &nbsp;
//                                                    <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                        </div>
//                                    </td>";
//                            #endregion
//                            AmtDescp.Visible = false;
//                            Tr1.Visible = false;
//                            Tr2.Visible = false;
//                            //gst
//                            Tr4.Visible = false;
//                            Tr4html = string.Empty;
//                            Tr5.Visible = false;
//                            lblTds.Visible = false;
//                            //end of gst
//                            TotalLine.Visible = false;
//                            TotalSpace.Visible = false;
//                            TotalSpacehtml = string.Empty;
//                            Space3.Visible = false;
//                            string Space3html_1 = string.Empty;
//                            // Space4.Visible = false;                      
//                            PartShipmentCase.Visible = true;
//                            #region html from Space6 to PartShipmentCase
//                            Space6.Visible = true;
//                            Space6html = @"<tr id='Space6'>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td style='height: 21px; white-space: nowrap;' class='text'>
//                                <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'></label>
//                            </td>
//                        </tr>";
//                            #endregion
//                            Import_AWB_ID = dtDo_GenerateStatus_check.Rows[0]["Import_Awb_ID"].ToString();
//                            DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFA.GstAddress, IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.recipt_no,IFA.Bank_Name,IFA.Cheque_No,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + strawbid[jj].ToString() + "'");
//                            //**********************MAWB,HAWB,STAXRATE,SBCess,RECIEVDAMOUNT:PICKED FROM IMPORTFLIGHTAWB_TRANS******//
//                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                            DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + strawbid[jj].ToString() + "'");
//                            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
//                            {
//                                #region for loop
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
//                                {
//                                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
//                                {
//                                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
//                                {
//                                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                #endregion
//                            }
//                            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
//                            {
//                                #region for loop
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
//                                {
//                                    MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
//                                {
//                                    HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
//                                {
//                                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
//                                {
//                                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
//                                {
//                                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                #endregion
//                            }

//                            #region outer -1
//                            no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();
//                            recipt_no = dt.Rows[0]["recipt_no"].ToString();
//                            lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
//                            lblremarkshtml = @" <tr id='trremarks'>
//                            <td colspan='4'><label ID='Label2'  Font-Bold='True' Font-Size='8pt'> Remark:-</label>                 
//                                 <label ID='lblremarks' Font-Size='8pt'>" + dt.Rows[0]["Remarks"].ToString() + @"</label>   
//                            </td>
//                        </tr>
//                        <tr>
//                            <td colspan='4'>
//                                ---------------------------------------------------------------------------------------------------------------------
//                            </td>
//                        </tr>";

//                            lblairlinenamehtml = @"<tr>   
//                                    <td colspan='4' style='height: 1px; text-align: center;'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                            <h4 style='text-align: center'>TAX INVOICE</h4>
//                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>
//                                            </span></span>
//                                    </td>
//                            </tr>";

//                            string StaxNo = "";
//                            issue_date = dt.Rows[0]["issue_date"].ToString();
//                            straddress = dt.Rows[0]["office_address"].ToString();
//                            Airportadress = dt.Rows[0]["Airport_Address"].ToString();
//                            payment_mode = dt.Rows[0]["payment_mode"].ToString();
//                            flight_date = dt.Rows[0]["import_flight_Date"].ToString();

//                            //lblFltDateAirline.Text = flight_date;


//                            DateTime fltdate2 = DateTime.Parse(flight_date);
//                            lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");
//                            Space5html_2 = @"<td style='height: 21px;' class='text'>
//                                Of&nbsp;
//                                <label ID='lblFltDateAirline' CssClass='boldtext' Font-Bold='True' Font-Size='8pt'>" + fltdate2.ToString("dd/MM/yyyy") + @"</label>.
//                            </td>
//                        </tr>";

//                            ////lblFlightDate.Text = flight_date;
//                            DateTime fltdate = DateTime.Parse(flight_date);
//                            lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");
//                            lblFlightDatehtml_lblFlightDate = @"<em><strong>/</strong></em>
//                             <label ID='lblFlightDate'  CssClass='boldtext' Font-Bold='True'  Font-Size='7pt'>" + fltdate.ToString("dd/MM/yyyy") + @"</label></span></span></td>";
//                            part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
//                            pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
//                            #endregion

//                            lblPartPschtml_Begin = @"<td style='height: 17px;' class='text'>
//                            Pcs:";
//                            if (part_pcs == "" || part_pcs == "0")
//                            {
//                                lblPartPsc.Visible = false;
//                                lblPartPsc.Text = "";
//                                lblPartPschtml = string.Empty;
//                                lblpppsc.Visible = false;
//                                lblpppsc.Text = "";
//                                lblpppschtml = string.Empty;
//                            }
//                            else
//                            {
//                                lblPartPsc.Visible = true;
//                                lblPartPsc.Text = part_pcs;
//                                lblPartPschtml = @"<label ID='lblPartPsc'  Font-Bold='True' Font-Names='Verdana' Font-Size='Larger'>" + part_pcs + @"</label>";  //lblpppschtml = string.Empty;

//                                lblpppsc.Visible = true;
//                                lblpppsc.Text = "/";
//                                lblpppschtml = @"<label ID='lblpppsc'  CssClass='textbold'>/</label><strong><span style='font-size: 11pt; font-family: Verdana'></span></strong>";  //lblpppschtml = string.Empty;
//                            }
//                            //*****************Added On 1 feb 2011********************
//                            if (dt.Rows[0]["freight_type"].ToString() == "PP")
//                            {
//                                #region
//                                lblBeingFrtchrgs.Text = "PP";
//                                Space3html_1 = @"<div style='width: 650px; margin-bottom: 0px;'  id='div3'>
//                                 <table style='width: 650px;'>
//                                    <tr id='Space3'>
//                                        <td>
//                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                    webkit-border-vertical-spacing: 2px'>being freight charges</span></span>&nbsp;
//                                                <label   ID='lblBeingFrtchrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>PP</label>
//                                        </td>";
//                                #endregion
//                            }
//                            else if (dt.Rows[0]["freight_type"].ToString() == "CC")
//                            {
//                                #region else if
//                                string MawbChrs = "";
//                                string HawbChrs = "";
//                                if (MawbDo_Chgs == "")
//                                {
//                                    MawbChrs = "0";
//                                }
//                                else
//                                {
//                                    MawbChrs = MawbDo_Chgs;
//                                }
//                                if (HawbDo_Chgs == "")
//                                {
//                                    HawbChrs = "0";
//                                }
//                                else
//                                {
//                                    HawbChrs = HawbDo_Chgs;
//                                }
//                                lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
//                                Space3html_1 = @"<div style='width: 650px; margin-bottom: 0px;'  id='div3'>
//                                 <table style='width: 650px;'>
//                                    <tr id='Space3'>
//                                        <td>
//                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                    webkit-border-vertical-spacing: 2px'>being freight charges</span></span>&nbsp;
//                                                <label   ID='lblBeingFrtchrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + dt.Rows[0]["Total_Collection_CC"].ToString() + @"</label>
//                                        </td>";
//                                lblDOChrgs.Text = Convert.ToString(total);
//                                Space3html_2 = @"<td>
//                                        <span class='Apple-style-span' style='font-weight: normal; word-spacing: 0px; text-transform: none;
//                                            color: rgb(0,0,0); text-indent: 0px; line-height: normal; font-style: normal;
//                                            font-family: 'Times New Roman'; white-space: normal; letter-spacing: normal;
//                                            border-collapse: separate; font-variant: normal; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 7pt; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                webkit-border-vertical-spacing: 2px'>Plus Delivery Order Charges</span></span>&nbsp;
//                                                    <label ID='lblDOChrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + Convert.ToString(total) + @"</label>
//                                    </td>

//                                    <td>
//                                        <span style='font-size: 7pt; font-family: Verdana'></span>
//                                    </td>
//                                    <td>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }

//                            Space3html_2 = @"<td>
//                                        <span class='Apple-style-span' style='font-weight: normal; word-spacing: 0px; text-transform: none;
//                                            color: rgb(0,0,0); text-indent: 0px; line-height: normal; font-style: normal;
//                                            font-family: 'Times New Roman'; white-space: normal; letter-spacing: normal;
//                                            border-collapse: separate; font-variant: normal; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 7pt; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                webkit-border-vertical-spacing: 2px'>Plus Delivery Order Charges</span></span>&nbsp;
//                                                    <label ID='lblDOChrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + Convert.ToString(total) + @"</label>
//                                    </td>
//                                    <td>
//                                        <span style='font-size: 7pt; font-family: Verdana'></span>
//                                    </td>
//                                    <td>
//                                    </td>
//                                </tr>";

//                            //*****************END********************
//                            //******************Old AWb Details**************************
//                            DataTable dtOldAwb = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFA.GstAddress,IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");
//                            if (dtOldAwb.Rows.Count > 0 || dtOldAwb != null)
//                            {
//                                OldAwb_ReciptNo = dtOldAwb.Rows[0]["recipt_no"].ToString();
//                            }
//                            //********************************END OF OLD AWB Details***************
//                            strAirline_name = dt.Rows[0]["Airline_Name"].ToString();
//                            if (strAirline_name == "MALAYSIAN AIRLINES")
//                            {
//                                strAirline_name = "MALAYSIA AIRLINES";
//                            }
//                            awbno = dt.Rows[0]["Import_Awb_No"].ToString();
//                            flt_no = dt.Rows[0]["import_flight_no"].ToString();
//                            if (Airline_id == "158")
//                            {
//                                if (FlightNo != "KE-9395" || FlightNo != "KE-9307")
//                                {
//                                    if (FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                        flt_no = flt_no.Replace("HY", "KE");
//                                    else
//                                        flt_no = flt_no.Replace("KE", "HY");
//                                }
//                            }
//                            arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();
//                            lblremarks.Text = dt.Rows[0]["Remarks"].ToString();

//                            lblremarkshtml = @" <tr id='trremarks'>
//                            <td colspan='4'><label ID='Label2'  Font-Bold='True' Font-Size='8pt'> Remark:-</label>                 
//                                 <label ID='lblremarks' Font-Size='8pt'>" + dt.Rows[0]["Remarks"].ToString() + @"</label>   
//                            </td>
//                        </tr>
//                        <tr>
//                            <td colspan='4'>
//                                ---------------------------------------------------------------------------------------------------------------------
//                            </td>
//                        </tr>";
//                            contents = dt.Rows[0]["commodity"].ToString();
//                            if (contents == "Console")
//                            {
//                                contents = "Consol";
//                            }
//                            import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
//                            to = dt.Rows[0]["Consignee_Name"].ToString();
//                            if (to == "")
//                            {
//                                to = dt.Rows[0]["Agent_Name"].ToString();
//                            }
//                            if (Airline_id == "147" || Airline_id == "153")
//                            {
//                                to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
//                            }
//                            if (dt.Rows[0]["GstNo"].ToString() != "")
//                            {
//                                #region
//                                string placeOfDelivery = "DELHI";
//                                string GstAddress = placeOfDelivery;
//                                if (dt.Rows[0]["GstAddress"].ToString() != "")
//                                {
//                                    GstAddress = dt.Rows[0]["GstAddress"].ToString();
//                                }
//                                DataTable dtdeliveryplace = dw.GetAllFromQuery("Select state from gststateCode where statecode=" + dt.Rows[0]["GstNo"].ToString().Substring(0, 2) + "");
//                                if (dtdeliveryplace.Rows != null && dtdeliveryplace.Rows.Count > 0)
//                                {
//                                    #region if condition
//                                    if (dtdeliveryplace.Rows[0]["state"].ToString() == "" || dtdeliveryplace.Rows[0]["state"].ToString() == null)
//                                    {
//                                        placeOfDelivery = dt.Rows[0]["GstNo"].ToString();
//                                        if (dt.Rows[0]["GstAddress"].ToString() == "")
//                                        {
//                                            GstAddress = placeOfDelivery;
//                                        }
//                                    }
//                                    else
//                                    {
//                                        placeOfDelivery = dtdeliveryplace.Rows[0]["state"].ToString();
//                                        if (dt.Rows[0]["GstAddress"].ToString() == "")
//                                        {
//                                            GstAddress = placeOfDelivery;
//                                        }
//                                    }
//                                    //////to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                    to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                    #endregion
//                                }
//                                else
//                                {
//                                    //// to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                    to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                }
//                                #endregion
//                            }

//                            #region outer code
//                            from = dt.Rows[0]["Shipper_Name"].ToString();
//                            notify = dt.Rows[0]["Notify"].ToString();
//                            if (notify == "")
//                            {
//                                lblNotifyDo.Visible = false;
//                                lblNotifyDovalue.Visible = false;
//                                lblNotify.Visible = false; ;

//                                lblNotifyValue.Visible = false;
//                                lblNotifyValue.Text = "";
//                                lblNotifyhtml = string.Empty;
//                            }
//                            else
//                            {
//                                #region else condition
//                                lblNotifyDo.Visible = true;
//                                lblNotifyDovalue.Visible = true;
//                                lblNotifyDovalue.Text = notify;
//                                lblNotifyDohtml = @"<tr>
//                                <td colspan='2' style='height: 15px'>
//                                    <label ID='lblNotifyDo' CssClass='text'>Notify:</label>
//                                    <label ID='lblNotifyDovalue' CssClass='text'>" + notify + @"</label>
//                                </td>
//                                <td style='height: 15px'>
//                                </td>
//                                <td style='height: 15px'>
//                                </td>
//                            </tr>";

//                                lblNotify.Visible = true;
//                                lblNotifyValue.Visible = true;
//                                lblNotifyValue.Text = notify;
//                                lblNotifyhtml = @"<tr>
//                                <td style='height: 20px;' colspan='4'>
//                                    <label ID='lblNotify'  CssClass='text' >Notify:</label>
//                                    <label ID='lblNotifyValue' CssClass='text'>" + notify + @"</label>
//                                </td>
//                            </tr>";
//                                #endregion
//                            }
//                            IGMNo = dt.Rows[0]["IGM_No"].ToString();
//                            string house = dt.Rows[0]["No_of_Houses"].ToString();
//                            decimal housevalue = System.Math.Round(decimal.Parse(house), 0);
//                            decimal d = housevalue * decimal.Parse(HawbDo_Chgs);
//                            //************Added on 1 feb 2011 Added freight Chrages for CC Case****************
//                            decimal DOFrtChrgs = 0;
//                            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
//                            {
//                                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
//                                {
//                                    DOFrtChrgs = 0;
//                                }
//                                else
//                                {
//                                    DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
//                                }
//                                //TrFreightChrgsCC.Visible = true;
//                                TrFreightChrgsCC.Visible = false;
//                                TrFreightChrgsCChtml = string.Empty;
//                                d = d + DOFrtChrgs;
//                            }
//                            //************END**********************************************
//                            string addrs = "";
//                            if (Airline_id == "158")
//                            {
//                                #region if
//                                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                {
//                                    lblAddress.Text = straddress.ToString();
//                                    lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                    lblAddress1.Text = straddress.ToString();
//                                }
//                                else
//                                {
//                                    lblAddress.Text = straddress.ToString();
//                                    lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                    lblAddress1.Text = Airportadress.ToString();
//                                }
//                                #endregion
//                            }
//                            else
//                            {
//                                #region else
//                                lblAddress.Text = straddress.ToString();
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                lblAddress1.Text = straddress.ToString();
//                                #endregion
//                            }
//                            if (lblAddress.Text.Contains("GST NO"))
//                            {
//                                #region if condition
//                                int i = lblAddress.Text.IndexOf(",GST NO");
//                                StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
//                                addrs = lblAddress.Text.Replace(StaxNo, ".");
//                                addrs = addrs.Replace(",.", ".");
//                                lblAddress.Text = addrs;
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + addrs.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                #endregion
//                            }
//                            else
//                            {
//                                #region else part
//                                lblAddress.Text = straddress.ToString();
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                #endregion
//                            }
//                            if (lblAddress1.Text.Contains("GST NO"))
//                            {
//                                int i = lblAddress1.Text.IndexOf(",GST NO");
//                                StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
//                                addrs = lblAddress1.Text.Replace(StaxNo, ".");
//                                addrs = addrs.Replace(",.", ".");
//                                lblAddress1.Text = addrs;
//                            }
//                            else
//                            {
//                                #region else
//                                if (Airline_id == "158")
//                                {
//                                    if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                        lblAddress1.Text = straddress.ToString();
//                                    else
//                                        lblAddress1.Text = Airportadress.ToString();
//                                }
//                                else
//                                    lblAddress1.Text = straddress.ToString();
//                                #endregion
//                            }

//                            if (lblAddress1.Text.Contains("Tel"))
//                                lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
//                            if (lblAddress1.Text.Contains("TEL"))
//                                lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
//                            if (lblAddress.Text.Contains("Tel"))
//                                lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
//                            if (lblAddress.Text.Contains("TEL"))
//                                lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
//                            if (lblAddress1.Text.Contains("Fax"))
//                                lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
//                            if (lblAddress1.Text.Contains("FAX"))
//                                lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
//                            if (lblAddress.Text.Contains("Fax"))
//                                lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
//                            if (lblAddress.Text.Contains("FAX"))
//                                lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");
//                            if (payment_mode == "1")
//                            {
//                                lblCheque.Visible = false;
//                                div2html_3 = string.Empty;
//                                lblCash.Text = "in Cash";
//                                div2html_2 += @"<label ID='lblCash' CssClass='text' Font-Bold='True' Font-Size='8pt'>in Cash</label>";
//                            }
//                            else if (payment_mode == "2")
//                            {
//                                lblCash.Visible = false;
//                                div2html_2 = string.Empty;
//                                lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
//                                div2html_3 += @"<label ID='lblCheque' CssClass='text' Font-Bold='True' Font-Size='8pt'>in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + @" , Bank: " + dt.Rows[0]["Bank_Name"].ToString() + @", Date: " + dt.Rows[0]["Cheque_Dated"].ToString() + @"</label>";
//                            }
//                            #endregion

//                            #region  lblAirlineStax.Text= start asign
//                            if (strAirline_name == "MALAYSIA AIRLINES")
//                            {
//                                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                            }
//                            else if (strAirline_name == "TURKISH AIRLINES")
//                            {
//                                lblAirlineStax.Text = "Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                            }
//                            else if (strAirline_name == "AIR CHINA")
//                            {
//                                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                            }
//                            else if (strAirline_name == "KOREAN AIRLINES")
//                            {
//                                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                            }
//                            else if (strAirline_name == "MEGA MALDIVES AIRLINES")
//                            {
//                                lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                            }
//                            else
//                            {
//                                lblAirlineStax.Text = "Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                            }
//                            #endregion

//                            #region outer 3
//                            lblSno.Text = recipt_no.ToString();
//                            trdelhtml = @"<tr id=trdel>
//                            <td style=height: 25px>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                        webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px>The
//                                        Collector of Customs<br />
//                                        Cargo Terminal(Import)<br />
//                                        I.G.I. Airport<br />
//                                        New Delhi</span></span>
//                            </td>
//                            <td style=height: 50px>
//                            </td>
//                            <td style=height: 50px; text-align: right;>
//                                <span style=font-size: 7pt; font-family: Verdana>Sr.No:</span>
//                            </td>
//                            <td style=height: 50px>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px>&nbsp;<label ID=lblSno runat=server Font-Bold=True Font-Size=8pt>" + recipt_no.ToString() + @"</label></span></span></td></tr>";

//                            lblSnomum.Text = recipt_no.ToString();


//                            lblSnochennai.Text = recipt_no.ToString();
//                            trchennaihtml = @"<tr id='trchennai'>   
//                            <td style='height: 25px'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                        webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px'>THE
//                                        COMMISSIONER OF CUSTOMS<br />
//                                        CARGO TERMINAL<br />
//                                        CHENNAI 600 027. </span></span>
//                            </td>
//                            <td style='height: 50px'>
//                            </td>
//                            <td style='height: 50px; text-align: right;'>
//                                <span style='font-size: 7pt; font-family: Verdana'>Sr.No:</span>
//                            </td>
//                            <td style='height: 50px'>
//                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                    webkit-border-vertical-spacing: 2px'>&nbsp;<label ID='lblSnochennai'  Font-Bold='True' Font-Size='8pt'>" + recipt_no.ToString() + @"</label></span></span></td></tr>";

//                            lblSno2.Text = recipt_no.ToString();
//                            lblSno2html = @"<tr> 
//                            <td style='height: 20px;'>
//                            </td>
//                            <td style='height: 20px;'>
//                            </td>
//                            <td style='height: 20px; text-align: right;'>
//                                <span style='font-size: 7pt; font-family: Verdana'>Sr.No.</span>
//                            </td>
//                            <td style='height: 20px;font-weight: 600;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>&nbsp;<label ID='lblSno2' Font-Bold='True' Font-Size='8pt'>" + recipt_no.ToString() + @"</label></span></span></td>
//                        </tr>";

//                            lblName.Text = to.ToString();
//                            lblNamehtml = @"<tr> 
//                        <td colspan='2' style='height: 26px'>
//                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                    webkit-border-vertical-spacing: 2px'>Received with thanks from M/S
//                                    <label ID='lblName'  Font-Bold='True'>" + to.ToString() + @"</label></span></span>
//                        </td>
//                        <td style='height: 26px;'>
//                        </td>
//                        <td style='height: 26px;'>
//                        </td>
//                        </tr>";


//                            lblName2.Text = to.ToString();
//                            lblName2html = @"<tr>
//                        <td style='height: 15px' colspan='2'>
//                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                    style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'></span>
//                            </span><span style='font-size: 8pt; font-family: Verdana'>Please deliver to M/S</span>
//                            <label ID='lblName2' Font-Bold='True' Font-Size='8pt'></label>
//                        </td>
//                        <td style='height: 15px'>
//                        </td>
//                        <td style='height: 15px'>
//                        </td>
//                       </tr>";

//                            Sno.Text = recipt_no.ToString();
//                            AmtDescphtml_Sno = @"<td class='text' colspan='3'>
//                                        (Rs. Amount Collect by VIA RECP:
//                                        <label ID='Sno'  Font-Bold='True' Font-Size='8pt'>" + recipt_no.ToString() + @"</label>).
//                                    </td>
//                                </tr>";

//                            lblairlinename.Text = strAirline_name.ToString();

//                            lblairlinenamehtml = @"<tr>   
//                                    <td colspan='4' style='height: 1px; text-align: center;'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                <h4 style='text-align: center'>
//                                                    TAX INVOICE</h4>
//                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>
//                                            </span></span>
//                                    </td>
//                                 </tr>";
//                            #endregion

//                            if (Airline_id == "158")
//                            {
//                                #region  Airline_id == "158"
//                                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                {
//                                    #region if condition
//                                    lblAirlineNme.Text = "KOREAN AIR";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "KOREAN AIR";
//                                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";
//                                    #endregion
//                                }
//                                else
//                                {
//                                    #region else part
//                                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
//                                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";
//                                    #endregion
//                                }
//                                #endregion
//                            }
//                            else if (Airline_id == "159")
//                            {
//                                #region  Airline_id == "159"
//                                if (FlightNo == "HY-127")
//                                {
//                                    #region if condition
//                                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
//                                    lblheadairlinenamehtml = @"<div style='width:790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";

//                                    lblairlinename.Text = "UZBEKISTAN AIRWAYS";
//                                    lblairlinenamehtml = @"<tr>   
//                                    <td colspan='4' style='height: 1px; text-align: center;'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                <h4 style='text-align: center'>
//                                                    TAX INVOICE</h4>
//                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>
//                                            </span></span>
//                                    </td>
//                                 </tr>";
//                                    #endregion
//                                }
//                                else
//                                {
//                                    #region else part
//                                    lblAirlineNme.Text = "KOREAN AIR";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "KOREAN AIR";
//                                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";

//                                    lblairlinename.Text = "KOREAN AIR";
//                                    lblairlinenamehtml = @"<tr>   
//                                        <td colspan='4' style='height: 1px; text-align: center;'>
//                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                    style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                    webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                    <h4 style='text-align: center'>
//                                                        TAX INVOICE</h4>
//                                                    <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>KOREAN AIR</label>
//                                                </span></span>
//                                        </td>
//                                  </tr>";
//                                    #endregion
//                                }
//                                #endregion
//                            }
//                            else
//                            {
//                                #region else part
//                                lblAirlineNme.Text = strAirline_name.ToString();
//                                lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>" + strAirline_name.ToString() + @"</label>
//                                    </td></tr>";

//                                lblheadairlinename.Text = strAirline_name.ToString();
//                                lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";
//                                #endregion
//                            }

//                            #region outer start
//                            lblAwbno.Text = awbno.ToString();
//                            lblAwbnohtml = @"<tr>
//                            <td style='height: 17px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>MAWB:
//                                        <label ID='lblAwbno'  Font-Bold='True' Font-Size='8pt'>" + awbno.ToString() + @"</label></span></span>
//                            </td>";

//                            lblPcs.Text = pcs.ToString();
//                            lblPcshtml = @"<label ID='lblPcs'  Font-Bold='True' Font-Names='Verdana' Font-Size='8pt'>" + pcs.ToString() + @"</label>
//                        </td>";

//                            lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");
//                            lblDatehtml = @"<tr><td>
//                                </td><td></td>
//                                 <td style='text-align: right;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; text-transform: none; color: rgb(0,0,0);
//                                        text-indent: 0px; white-space: normal; letter-spacing: normal; border-collapse: separate;
//                                        orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px;
//                                        webkit-text-decorations-in-effect: none; webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px;
//                                        font-weight: normal; line-height: normal; font-style: normal; font-family: 'Times New Roman';
//                                        font-variant: normal;'><span class='Apple-style-span' style='font-size: 7pt; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px'>Date:</span></span>
//                                </td>
//                                <td style='width: 300px;font-weight: 600;'>
//                                    <span style='font-size: 7pt; font-family: Verdana'><strong></strong>
//                                        <label ID='lblDate' Font-Bold='True' Font-Size='8pt'>" + DateTime.Now.ToString("MMM dd yyyy hh:mmtt") + @"</label></span>
//                                </td>
//                        </tr>";

//                            lblcommdy.Text = contents.ToString();
//                            lblcommdyhtml = @"<td style='height: 17px;' class='text'>
//                            Commdy:
//                            <label ID='lblcommdy'  Font-Bold='True' Font-Size='8pt' Font-Underline='False'>" + contents.ToString() + @"</label>
//                          </td>
//                        </tr>";

//                            lblFlightno.Text = flt_no.ToString();
//                            lblFlightDatehtml_lblFlightno = @"<tr><td style='height: 15px;' colspan='2'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>order the following packages which arrived
//                                        <label ID='lblFlightno'  Font-Bold='True' Font-Size='7pt'>" + flt_no.ToString() + @"</label>";

//                            lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();
//                            lblWthtml = @"<td style='height: 17px;' class='text'>
//                            GR.Wt (In Kg):
//                            <label ID='lblWt' Font-Bold='True' Font-Size='8pt'>" + dt.Rows[0]["Gross_Weight"].ToString() + @"</label>
//                        </td>";

//                            lblWtVal = dt.Rows[0]["Gross_Weight"].ToString();

//                            lbligmnr.Text = IGMNo.ToString();
//                            lblFlightDatehtml_lbligmnr = @"<td style='height: 15px; width: 125px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>IGM NO:
//                                        <label ID='lbligmnr'  Font-Bold='True' Font-Size='8pt'>" + IGMNo.ToString() + @"</label></span></span>
//                            </td>
//                            <td style='height: 15px;'>
//                            </td>
//                            </tr>";

//                            lbldate2.Text = issue_date.ToString();
//                            lblAddresshtml_lbldate2 += @"<td style='height: 50px; text-align: right;'>
//                              <span style='font-size: 7pt; font-family: Verdana'>Date:</span>
//                              </td>
//                                <td style='height:21px; width:250px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform:none; color:rgb(0,0,0); text-indent:0px; letter-spacing:normal;
//                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'><b><span style='font-size: 7pt'>&nbsp;</span>
//                                        <label  ID='lbldate2' Font-Size='8pt'>" + issue_date.ToString() + @"</label></b></span></span></td>
//                           </tr>";

//                            lblAwb2.Text = awbno.ToString();
//                            lblFlitno2.Text = flt_no.ToString();
//                            Space5html = @"<tr id='Space5'> 
//                            <td style='height: 21px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>on MAWB:
//                                        <label ID='lblAwb2' Font-Bold='True' Font-Size='8pt'>" + awbno.ToString() + @"</label></span></span>
//                            </td>
//                            <td style='height: 21px;' class='text'>
//                                <label ID='lblFlitno2' Font-Bold='True' Font-Size='8pt'>" + flt_no.ToString() + @"</label>
//                            </td>
//                            <td style='height: 21px;'>
//                            </td>";

//                            lblAirlinemame3.Text = strAirline_name.ToString();
//                            Space6html = @"<tr id='Space6'>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td style='height: 21px; white-space: nowrap;' class='text'>
//                                <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'>" + strAirline_name.ToString() + @"</label>
//                            </td>
//                         </tr>";
//                            #endregion

//                            if (Airline_id == "147")
//                            {
//                                #region if Airline_id == "147"
//                                lblch.Visible = true;
//                                lblchwt.Visible = true;
//                                lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
//                                lblchlblchwthtml = @" <tr>
//                                        <td colspan=2 style='height:17px'>
//                                        </td>
//                                        <td style='height: 17px;' class='text'>
//                                            <label ID='lblch' CssClass='text'>CH.WT (In Kg):</label>                    
//                                             <label ID='lblchwt' Font-Bold='True' Font-Size='8pt'>" + dt.Rows[0]["Charged_Weight"].ToString() + @"</label>
//                                        </td>
//                                        <td class='text' style='height: 17px'>
//                                            <strong>FOR</strong>
//                                        </td>
//                                    </tr>";
//                                lblAirlinemame3.Text = "MASkargo";
//                                Space6html = @"<tr id='Space6'>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td style='height: 21px; white-space: nowrap;' class='text'>
//                                <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'>MASkargo</label>
//                            </td>
//                            </tr>";
//                                lblAirlineNme.Text = "MASkargo";
//                                lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>MASkargo</label>
//                                    </td></tr>";
//                                Space6html = @" <tr id='Space6'>
//                                                <td>
//                                                </td>
//                                                <td>
//                                                </td>
//                                                <td>
//                                                </td>
//                                                <td style='height: 21px; white-space: nowrap;' class='text'>
//                                                    <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'>MASkargo</label>
//                                                </td>
//                                            </tr>";
//                                #endregion
//                            }
//                            else if (Airline_id == "153")
//                            {
//                                #region  Airline_id == "153"
//                                lblch.Visible = true;
//                                lblchwt.Visible = true;
//                                lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
//                                lblchlblchwthtml = @" <tr>
//                                        <td colspan=2 style='height:17px'>
//                                        </td>
//                                        <td style='height: 17px;' class='text'>
//                                            <label ID='lblch' CssClass='text'>CH.WT (In Kg):</label>                    
//                                             <label ID='lblchwt' Font-Bold='True' Font-Size='8pt'>" + dt.Rows[0]["Charged_Weight"].ToString() + @"</label>
//                                        </td>
//                                        <td class='text' style='height: 17px'>
//                                            <strong>FOR</strong>
//                                        </td>
//                                    </tr>";
//                                #endregion
//                            }

//                            if (Airline_id == "159")
//                            {
//                                #region  Airline_id == "159"
//                                lblAirlinemame3.Text = "KOREAN AIR";
//                                Space6html = @" <tr id='Space6'>
//                                                <td>
//                                                </td>
//                                                <td>
//                                                </td>
//                                                <td>
//                                                </td>
//                                                <td style='height: 21px; white-space: nowrap;' class='text'>
//                                                    <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
//                                                </td>
//                                            </tr>";
//                                #endregion
//                            }
//                            //******************Added On 1 feb 2011*********************
//                            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
//                            {
//                                //TrFreightChrgsCChtml here
//                                #region dt.Rows[0]["freight_Type"].ToString() == "CC"
//                                //TrFreightChrgsCC.Visible = true;
//                                TrFreightChrgsCC.Visible = false;
//                                TrFreightChrgsCChtml = string.Empty;
//                                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "")
//                                {
//                                    lblDOFrtChr.Text = "0";
//                                    TrFreightChrgsCChtml = @"<tr id='TrFreightChrgsCC'>  
//                                            <td align='left' colspan='4'>
//                                                <table border='0' width='400px' align='center' cellspacing='0'>
//                                                    <tr>
//                                                        <td style='width: 290px; text-align: left'>
//                                                            <span style='font-size: 8pt;'>Frt&nbsp; Chrgs.&nbsp; &nbsp;&nbsp;</span>
//                                                        </td>
//                                                        <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                            <label ID='lblDOFrtChr'>0</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </td>
//                                        </tr>";
//                                }
//                                else
//                                {
//                                    lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
//                                    TrFreightChrgsCChtml = @"<tr id='TrFreightChrgsCC'>  
//                                            <td align='left' colspan='4'>
//                                                <table border='0' width='400px' align='center' cellspacing='0'>
//                                                    <tr>
//                                                        <td style='width: 290px; text-align: left'>
//                                                            <span style='font-size: 8pt;'>Frt&nbsp; Chrgs.&nbsp; &nbsp;&nbsp;</span>
//                                                        </td>
//                                                        <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                            <label ID='lblDOFrtChr'>" + dt.Rows[0]["Total_Collection_CC"].ToString() + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </td>
//                                        </tr>";
//                                }
//                                #endregion
//                            }
//                            //****************************End*********************************************
//                            lblpartshipmentCase.Text = lblpartshipmentCase.Text + dtOldAwb.Rows[0]["recipt_no"].ToString();

//                            PartShipmentCasehtml = @"<tr id='PartShipmentCase'>  
//                            <td style='height: 20px' colspan='4'>
//                               <span>CASH RECEIVED VIDE RECEIPT NO:</span><label ID='lblpartshipmentCase' CssClass='boldtext' Font-Bold='True' Font-Size='Smaller'>" + dtOldAwb.Rows[0]["recipt_no"].ToString() + @"</label>
//                                <label ID='lblRecipt' CssClass='boldtext' Font-Bold='True' Font-Size='Smaller'></label>
//                            </td>
//                            </tr>";
//                            //*******Updating Import_Flight_Awb Table seting all Amount Zero for the Awb No******************
//                            con = new SqlConnection(strCon);
//                            con.Open();
//                            com = new SqlCommand("update Import_Flight_AWB set DO_stax_rate=0,Tds_Cut_By_Agent=0,DO_Tds_Cut_By_Agent=0,DO_Amount_Received=0,DO_Cheque_Amount=0,CC_Cheque_Amount=0,Total_Collection_CC=0,freight_chgs=0 where import_awb_id='" + strawbid[jj] + "'", con);
//                            com.ExecuteNonQuery();
//                            con.Close();
//                            //***********************End oF Updating*************************************
//                            //*******Updating ImportFlightAwb_Trans Table seting all Amount Zero for the Awb No******************
//                            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
//                            {
//                                con = new SqlConnection(strCon);
//                                con.Open();
//                                com = new SqlCommand("update ImportFlightAWB_trans set ChargeRate=0,ChargeAmount=0 where importawbid='" + strawbid[jj] + "'", con);
//                                com.ExecuteNonQuery();
//                                con.Close();
//                            }
//                            #endregion
//                            //***********************End oF Updating*************************************                        
//                        }
//                        #endregion
//                    }
//                    else
//                    {
//                        //comming
//                        #region else part
//                        DataTable DtDoPrint = dw.GetAllFromQuery("select * from Import_Flight_Awb where Import_awb_Id=" + strawbid[jj] + " and D0_Generate_Status='YES'");
//                        string Awb_NoDoprint = AIrwayBill_No;
//                        DataTable dtawbexistDoPrint = dw.GetAllFromQuery("select Import_Awb_No from Import_Flight_Awb where Import_Awb_No='" + Awb_NoDoprint + "'AND Import_awb_Id=" + strawbid[jj] + " and  shipment_type='F' and Part_shipment_type='Y' ");
//                        if (DtDoPrint.Rows.Count > 0)
//                        {
//                            //comming
//                            Display(jj);
//                            //Temporarly Store On Display_Import_FlightDetailsNew.ascx.cs
//                        }
//                        else if (dtawbexistDoPrint.Rows.Count > 0)
//                        {
//                            // DisplayRepeatAwb();
//                        }
//                        else
//                        {
//                            #region else part  comming lblAddress1.Visible = true;lblAddress.Visible = true;
//                            lblAddress1.Visible = true;
//                            lblAddress.Visible = true;
//                            #region  lblAddress as html
//                            lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True'  style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";

//                            lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                       <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                            #endregion

//                            Import_AWB_ID = Convert.ToString(strawbid[jj]);
//                            DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFA.GstAddress,IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,IFA.PCS,IFA.Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");
//                            //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  
//                            DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + strawbid[jj].ToString() + "'");
//                            string staxamount = "";
//                            string SbCessamount = "";

//                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                            string KKCessamount = "";
//                            table = "<table border=0 width=400px align=center cellspacing=0>";

//                            #region Starting Html Table
//                            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
//                            {
//                                #region for loop
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
//                                {
//                                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                    staxamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
//                                {
//                                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                    SbCessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
//                                }
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
//                                {
//                                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                    KKCessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
//                                }
//                                #endregion
//                            }
//                            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
//                            {
//                                #region for loop
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
//                                {
//                                    MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                    mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
//                                {
//                                    HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
//                                {
//                                    #region dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate"
//                                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                    Stax = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
//                                    if (dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "1")
//                                    {
//                                        staxdetail.Text = "(Service Tax EXEMPTED)";
//                                        div2html_4 += @"<label ID='staxdetail' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>(Service Tax EXEMPTED)</label>";
//                                    }
//                                    else
//                                    {
//                                        staxdetail.Text = "(INCLUSIVE OF SERVICE TAX)only";
//                                        div2html_4 += @"<label ID='staxdetail' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>(INCLUSIVE OF SERVICE TAX)only</label>";
//                                    }
//                                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
//                                    {
//                                        continue;
//                                    }
//                                    #endregion
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
//                                {
//                                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                    SBcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
//                                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
//                                    {
//                                        continue;
//                                    }
//                                }
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
//                                {
//                                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
//                                    KKcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
//                                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
//                                    {
//                                        continue;
//                                    }
//                                }
//                                decimal Allvalue = 0;
//                                //************************ImportChargesHead: DP_FEE,Cartage,CommunicationFee concept****
//                                if (dtImportAwbTrans.Rows.Count > 0)
//                                {
//                                    #region if part
//                                    if (Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]) > 0)
//                                    {
//                                        //***************************Creating Charges*****************************
//                                        #region if part
//                                        if (Airline_id == "159")
//                                        {
//                                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
//                                            {
//                                                //****************Updated On 03 May2016: KKCess tax Apply system*****************                                            
//                                                mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));
//                                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";
//                                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + mawcharge + "' >" + mawcharge.ToString("#,##0.00") + "</label>";
//                                                table += "</td></tr>";
//                                            }
//                                            else
//                                            {
//                                                #region Gst Applicable
//                                                string charge = "GST";
//                                                string ChargeName = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
//                                                if (ChargeName == "StaxRate")
//                                                {
//                                                    charge = "CGST";
//                                                }
//                                                else if (ChargeName == "SBCess")
//                                                {
//                                                    charge = "SGST";
//                                                }
//                                                else if (ChargeName == "KKCess")
//                                                {
//                                                    charge = "IGST";
//                                                }
//                                                else
//                                                {
//                                                    charge = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
//                                                }
//                                                if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
//                                                {
//                                                    table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + charge + "'>" + charge + " Chrgs:</label>";

//                                                    table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
//                                                    table += "</td></tr>";
//                                                }
//                                                else
//                                                {
//                                                    table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

//                                                    table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
//                                                    table += "</td></tr>";
//                                                }
//                                                #endregion end of Gst Applicable
//                                            }
//                                        }
//                                        else
//                                        {
//                                            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

//                                            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";

//                                            table += "</td></tr>";
//                                        }
//                                        //***************************End******************************************
//                                        if (Airline_id == "159")
//                                        {
//                                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() != "StaxRate")
//                                                total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                        }
//                                        else
//                                            total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                        #endregion
//                                    }
//                                    else if (dt.Rows[0]["Shipment_Type"].ToString() == "F")
//                                    {
//                                        table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

//                                        table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + "0.00" + "' >" + "0.00" + "</label>";

//                                        table += "</td></tr>";
//                                        //***************************End******************************************

//                                        total += Convert.ToDecimal("0.00");
//                                    }
//                                    #endregion
//                                    //*****************************END***************************************************** 
//                                }
//                                #endregion
//                            }
//                            if (dt.Rows[0]["Tds_Cut_By_Agent"].ToString() != "0.00")
//                            {
//                                #region if condition
//                                //Gst
//                                totalTds = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());
//                                lblTds.Text = "- " + Convert.ToString(totalTds);
//                                Tr5html_lblTds += @"<tr id='tds'>
//                            <td style='width: 290px; text-align: left'>
//                                <label ID='Label7'  Font-Names='Verdana' Font-Size='Smaller' Font-Bold='True'>Less Agent Tds:</label>
//                            </td>
//                            <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                <label ID='lblTds' Font-Bold='True'
//                                    Font-Names='Verdana' Font-Size='8pt'>" + Convert.ToString(totalTds) + @"</label>
//                            </td>
//                           </tr><tr id='Tr6' style='font-size: 12pt'>
//                            <td colspan='4' style='text-align: left'>
//                                <label ID='Label8' CssClass='text'></label>
//                            </td>
//                            </tr>";
//                                ////table += "<tr><td style=\"width: 290px;   text-align: left\" ><label>TDS :</label>";
//                                ////table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + "-" + dt.Rows[0]["Tds_Cut_By_Agent"].ToString() + "</label></td></tr>";
//                                #endregion
//                            }
//                            #endregion

//                            table += "</table>";
//                            lblTabel.Text = table;
//                            no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();
//                            recipt_no = dt.Rows[0]["recipt_no"].ToString();
//                            lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
//                            lblremarkshtml = @" <tr id='trremarks'>
//                            <td colspan='4'><label ID='Label2'  Font-Bold='True' Font-Size='8pt'> Remark:-</label>                 
//                                 <label ID='lblremarks' Font-Size='8pt'>" + dt.Rows[0]["Remarks"].ToString() + @"</label>   
//                            </td>
//                        </tr>
//                        <tr>
//                            <td colspan='4'>
//                                ---------------------------------------------------------------------------------------------------------------------
//                            </td>
//                        </tr>";
//                            decimal CC_Cheque_Amount = Convert.ToDecimal(dt.Rows[0]["CC_Cheque_Amount"]);
//                            if (Airline_id == "147" || Airline_id == "153")
//                            {
//                                mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[0]["ChargeAmount"]);
//                            }
//                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                            decimal SBCessAmt = 0;
//                            decimal KKCessAmt = 0;
//                            string strInclusive = string.Empty;
//                            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
//                            {
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************      
//                                #region for loop
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
//                                {
//                                    SBCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                }
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
//                                {
//                                    KKCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "Carting")
//                                {
//                                    cartingcharges = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                }
//                                else if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
//                                {
//                                    mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate" && dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "0")
//                                {
//                                    #region if condition
//                                    if (flagtable == true)
//                                    {
//                                        if (Airline_id == "159")
//                                        {

//                                        }

//                                        else
//                                        {
//                                            strInclusive += "<table border=0 width=400px align=center cellspacing=0>";
//                                        }
//                                    }
//                                    decimal STaxAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
//                                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt;
//                                    ViewState["STaxAmt"] = STaxAmt;
//                                    #endregion
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
//                                {
//                                    #region if part
//                                    decimal STaxAmt = 0;
//                                    if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
//                                    {
//                                        ViewState["STaxAmt"] = STaxAmt;
//                                    }
//                                    else
//                                    {
//                                        STaxAmt = (Decimal)ViewState["STaxAmt"];
//                                    }
//                                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt;

//                                    if (Airline_id == "1591")
//                                    {
//                                        DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));
//                                    }
//                                    if (Airline_id == "159")
//                                    {
//                                    }
//                                    else if (Airline_id == "1591")
//                                    {
//                                    }
//                                    else
//                                    {
//                                    }
//                                    #endregion
//                                }
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
//                                {
//                                    #region if part
//                                    decimal STaxAmt = 0;
//                                    if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
//                                    {
//                                        ////ViewState["STaxAmt"] = "0";
//                                        ViewState["STaxAmt"] = STaxAmt;
//                                    }
//                                    else
//                                    {
//                                        STaxAmt = (Decimal)ViewState["STaxAmt"];
//                                    }
//                                    if (STaxAmt == 0)
//                                    {
//                                        STaxAmt = SBCessAmt;
//                                    }
//                                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt - KKCessAmt;
//                                    if (Airline_id == "1591")
//                                    {
//                                        DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));
//                                    }
//                                    if (Airline_id == "159")
//                                    {

//                                    }
//                                    else if (Airline_id == "1591")
//                                    {
//                                        #region elae if part
//                                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
//                                        {
//                                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount@9% :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount@9% :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount@18% :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
//                                        }
//                                        else
//                                        {
//                                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
//                                        }
//                                        #endregion
//                                    }
//                                    else
//                                    {
//                                        #region else part
//                                        if (strInclusive.Contains("<table"))
//                                        {

//                                        }
//                                        else
//                                        {
//                                            flagtable = false;
//                                            strInclusive += "<table border=0 width=400px align=center cellspacing=0>";
//                                        }

//                                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
//                                        {
//                                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount@9% :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount@9% :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount@18% :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
//                                        }

//                                        else
//                                        {
//                                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


//                                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
//                                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
//                                        }
//                                        #endregion
//                                    }
//                                    #region Gst newly Added
//                                    GSTDoCharges = DOCharge;
//                                    CGSTChargs = STaxAmt;
//                                    SGSTChargs = SBCessAmt;
//                                    IGSTChargs = KKCessAmt;
//                                    #endregion Gst newly Added
//                                    #endregion
//                                }

//                                lblInclusive.Text = strInclusive;
//                                lblInclusivehtml = @"<tr style='font-size: 12pt'>
//                                <td colspan='4' style='text-align: center'>
//                                    <label ID='lblInclusive' CssClass='text'>" + strInclusive + @"</label>
//                                </td>
//                            </tr>";

//                                lblBreakupTotal.Text = Convert.ToDecimal(GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs).ToString("#,##0.00");
//                                Tr5html_lblBreakupTotal = @"<tr id='Tr5' style='font-size: 12pt'>
//                              <td align='left' colspan='4'>
//                                  <table border='0' width='400px' align='center' cellspacing='0'>
//                                      <tr>
//                                            <td style='width: 290px; text-align: left'>
//                                                <label ID='lblBreakupTxt' Font-Names='Verdana' Font-Size='Smaller'
//                                                    Font-Bold='True'> Total Amt:</label>
//                                            </td>
//                                            <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                <label ID='lblBreakupTotal' Font-Bold='True' Font-Names='Verdana' Font-Size='8pt'>" + Convert.ToDecimal(GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs).ToString("#,##0.00") + @"</label>
//                                            </td></tr>";

//                                lblRecivedAmt.Text = Convert.ToDecimal((GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs) - totalTds).ToString("#,##0.00");

//                                Tr5html_lblRecivedAmt = @"<tr id='lessTds'>
//                                <td style='width: 290px; text-align: left;'>
//                                    <label ID='lblRecAmt' Font-Names='Verdana' Font-Size='Smaller' Font-Bold='True'>Total Amt Recievable:</label>                                    
//                                </td>
//                                <td style='font-size: 12pt; width: 244px; text-align: right;text-decoration: underline;'>
//                                    <label ID='lblRecivedAmt' Font-Bold='True' 
//                                    Font-Underline='True' Font-Names='Verdana' Font-Size='8pt'>" + Convert.ToDecimal((GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs) - totalTds).ToString("#,##0.00") + @"</label>
//                                </td>
//                                </tr>
//                                </table>
//                                 </td>               
//                                </tr>            
//                                </table></div>";
//                                Label1str = Convert.ToDecimal((GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs) - totalTds).ToString("#,##0.00");
//                                Label1.Text = lblRecivedAmt.Text;
//                                AmtDescphtml_Label1 = @"<tr id='AmtDescp'> 
//                                    <td>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span style='font-size: 10px;
//                                                font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                webkit-border-vertical-spacing: 2px'>an amount of Rs.<label ID='Label1' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + Convert.ToDecimal((GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs) - totalTds).ToString("#,##0.00") + @"</label></span></span>
//                                    </td>";
//                                #endregion
//                            }
//                            string StaxNo = "";
//                            issue_date = dt.Rows[0]["issue_date"].ToString();
//                            straddress = dt.Rows[0]["office_address"].ToString();
//                            Airportadress = dt.Rows[0]["Airport_Address"].ToString();
//                            payment_mode = dt.Rows[0]["payment_mode"].ToString();
//                            flight_date = dt.Rows[0]["import_flight_Date"].ToString();
//                            part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
//                            decimal ServiceTax = 0;
//                            ServiceTax = decimal.Parse(STAXRATE);
//                            lblPartPschtml_Begin = @"<td style='height: 17px;' class='text'>
//                            Pcs:";
//                            if (part_pcs == "" || part_pcs == "0")
//                            {
//                                lblPartPsc.Visible = false;
//                                lblPartPsc.Text = "";
//                                lblpppschtml = string.Empty;

//                                lblpppsc.Visible = false;
//                                lblpppsc.Text = "";
//                                lblpppschtml = string.Empty;
//                            }
//                            else
//                            {
//                                lblPartPsc.Visible = true;
//                                lblPartPsc.Text = part_pcs;
//                                lblPartPschtml = @"<label ID='lblPartPsc'  Font-Bold='True' Font-Names='Verdana' Font-Size='Larger'>" + part_pcs + @"</label>";  //lblpppschtml = string.Empty;

//                                lblpppsc.Visible = true;
//                                lblpppsc.Text = "/";
//                                lblpppschtml = @"<label ID='lblpppsc'  CssClass='textbold'>/</label><strong><span style='font-size: 11pt; font-family: Verdana'></span></strong>";  //lblpppschtml = string.Empty;
//                            }
//                            //*****************Added On 1 feb 2011********************
//                            if (dt.Rows[0]["freight_type"].ToString() == "PP")
//                            {
//                                lblBeingFrtchrgs.Text = "PP";
//                                Space3html_1 = @"<div style='width: 650px; margin-bottom: 0px;'  id='div3' >
//                                 <table style='width: 650px;'>
//                                    <tr id='Space3'>
//                                        <td>
//                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                    webkit-border-vertical-spacing: 2px'>being freight charges</span></span>&nbsp;
//                                                <label   ID='lblBeingFrtchrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>PP</label>
//                                        </td>";
//                            }
//                            else if (dt.Rows[0]["freight_type"].ToString() == "CC")
//                            {
//                                // Space3html_1 here
//                                #region  else if part
//                                string MawbChrs = "";
//                                string HawbChrs = "";
//                                if (MawbDo_Chgs == "")
//                                {
//                                    MawbChrs = "0";
//                                }
//                                else
//                                {
//                                    MawbChrs = MawbDo_Chgs;
//                                }
//                                if (HawbDo_Chgs == "")
//                                {
//                                    HawbChrs = "0";
//                                }
//                                else
//                                {
//                                    HawbChrs = HawbDo_Chgs;
//                                }

//                                lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
//                                Space3html_1 = @"<div style='width: 650px; margin-bottom: 0px;'  id='div3'>
//                                 <table style='width: 650px;'>
//                                    <tr id='Space3'>
//                                        <td>
//                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                    webkit-border-vertical-spacing: 2px'>being freight charges</span></span>&nbsp;
//                                                <label   ID='lblBeingFrtchrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + dt.Rows[0]["Total_Collection_CC"].ToString() + @"</label>
//                                        </td>";
//                                lblDOChrgs.Text = Convert.ToString(total);
//                                Space3html_2 = @"<td>
//                                        <span class='Apple-style-span' style='font-weight: normal; word-spacing: 0px; text-transform: none;
//                                            color: rgb(0,0,0); text-indent: 0px; line-height: normal; font-style: normal;
//                                            font-family: 'Times New Roman'; white-space: normal; letter-spacing: normal;
//                                            border-collapse: separate; font-variant: normal; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 7pt; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                webkit-border-vertical-spacing: 2px'>Plus Delivery Order Charges</span></span>&nbsp;
//                                                    <label ID='lblDOChrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + Convert.ToString(total) + @"</label>
//                                    </td>
//                                    <td>
//                                        <span style='font-size: 7pt; font-family: Verdana'></span>
//                                    </td>
//                                    <td>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }

//                            Space3html_2 = @"<td>
//                                        <span class='Apple-style-span' style='font-weight: normal; word-spacing: 0px; text-transform: none;
//                                            color: rgb(0,0,0); text-indent: 0px; line-height: normal; font-style: normal;
//                                            font-family: 'Times New Roman'; white-space: normal; letter-spacing: normal;
//                                            border-collapse: separate; font-variant: normal; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 7pt; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                webkit-border-vertical-spacing: 2px'>Plus Delivery Order Charges</span></span>&nbsp;
//                                                    <label ID='lblDOChrgs' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + Convert.ToString(total) + @"</label>
//                                    </td>
//                                    <td>
//                                        <span style='font-size: 7pt; font-family: Verdana'></span>
//                                    </td>
//                                    <td>
//                                    </td>
//                                </tr>";
//                            //*****************END********************
//                            strAirline_name = dt.Rows[0]["Airline_Name"].ToString();
//                            if (strAirline_name == "MALAYSIAN AIRLINES")
//                            {
//                                strAirline_name = "MALAYSIA AIRLINES";
//                            }
//                            awbno = dt.Rows[0]["Import_Awb_No"].ToString();
//                            flt_no = dt.Rows[0]["import_flight_no"].ToString();
//                            if (Airline_id == "158")
//                            {
//                                #region Airline_id == "158"
//                                if (FlightNo != "KE-9395")
//                                {
//                                    if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                        if (FlightNo == "KE-9307" || FlightNo == "KE-9665")
//                                            flt_no = flt_no.Replace("HY", "KE");
//                                        else
//                                            flt_no = flt_no.Replace("KE", "HY");
//                                }
//                                #endregion
//                            }
//                            arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();
//                            contents = dt.Rows[0]["commodity"].ToString();
//                            if (contents == "Console")
//                            {
//                                contents = "Consol";
//                            }
//                            pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
//                            import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
//                            to = dt.Rows[0]["Consignee_Name"].ToString();
//                            if (to == "")
//                            {
//                                to = dt.Rows[0]["Agent_Name"].ToString();
//                            }
//                            if (Airline_id == "147" || Airline_id == "153")
//                            {
//                                to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
//                            }
//                            if (dt.Rows[0]["GstNo"].ToString() != "")
//                            {
//                                #region if part
//                                string placeOfDelivery = "DELHI";
//                                string GstAddress = placeOfDelivery;
//                                if (dt.Rows[0]["GstAddress"].ToString() != "")
//                                {
//                                    GstAddress = dt.Rows[0]["GstAddress"].ToString();
//                                }
//                                DataTable dtdeliveryplace = dw.GetAllFromQuery("Select state from gststateCode where statecode=" + dt.Rows[0]["GstNo"].ToString().Substring(0, 2) + "");
//                                if (dtdeliveryplace.Rows != null && dtdeliveryplace.Rows.Count > 0)
//                                {
//                                    #region  dtdeliveryplace.Rows != null
//                                    if (dtdeliveryplace.Rows[0]["state"].ToString() == "" || dtdeliveryplace.Rows[0]["state"].ToString() == null)
//                                    {
//                                        placeOfDelivery = dt.Rows[0]["GstNo"].ToString();
//                                        if (dt.Rows[0]["GstAddress"].ToString() == "")
//                                        {
//                                            GstAddress = placeOfDelivery;
//                                        }
//                                    }
//                                    else
//                                    {
//                                        placeOfDelivery = dtdeliveryplace.Rows[0]["state"].ToString();
//                                        if (dt.Rows[0]["GstAddress"].ToString() == "")
//                                        {
//                                            GstAddress = placeOfDelivery;
//                                        }
//                                    }
//                                    //////to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                    to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                    #endregion
//                                }
//                                else
//                                {
//                                    //// to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                    to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
//                                }
//                                #endregion
//                            }
//                            from = dt.Rows[0]["Shipper_Name"].ToString();
//                            notify = dt.Rows[0]["Notify"].ToString();
//                            if (notify == "")
//                            {
//                                lblNotifyDo.Visible = false;
//                                lblNotifyDovalue.Visible = false;

//                                lblNotify.Visible = false; ;
//                                lblNotifyValue.Visible = false;
//                                lblNotifyValue.Text = "";
//                                lblNotifyhtml = string.Empty;
//                            }
//                            else
//                            {
//                                lblNotifyDo.Visible = true;
//                                lblNotifyDovalue.Visible = true;
//                                lblNotifyDovalue.Text = notify;
//                                lblNotifyDohtml = @"<tr>
//                                <td colspan='2' style='height: 15px'>
//                                    <label ID='lblNotifyDo' CssClass='text'>Notify:</label>
//                                    <label ID='lblNotifyDovalue' CssClass='text'>" + notify + @"</label>
//                                </td>
//                                <td style='height: 15px'>
//                                </td>
//                                <td style='height: 15px'>
//                                </td>
//                            </tr>";

//                                lblNotify.Visible = true;
//                                lblNotifyValue.Visible = true;
//                                lblNotifyValue.Text = notify;
//                                lblNotifyhtml = @"<tr>
//                                <td style='height: 20px;' colspan='4'>
//                                    <label ID='lblNotify'  CssClass='text'>Notify</label>
//                                    <label ID='lblNotifyValue' CssClass='text'>" + notify + @"</label>
//                                </td>
//                            </tr>";

//                            }
//                            IGMNo = dt.Rows[0]["IGM_No"].ToString();
//                            string house = dt.Rows[0]["No_of_Houses"].ToString();
//                            decimal housevalue = System.Math.Round(decimal.Parse(house), 0);
//                            decimal d = housevalue * decimal.Parse(HawbDo_Chgs);
//                            //************Added on 1 feb 2011 Added freight Chrages for CC Case****************
//                            decimal DOFrtChrgs = 0;
//                            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
//                            {
//                                #region if condition
//                                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
//                                {
//                                    DOFrtChrgs = 0;
//                                }
//                                else
//                                {
//                                    DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
//                                }
//                                TrFreightChrgsCC.Visible = true;
//                                TrFreightChrgsCChtml = @"<tr id='TrFreightChrgsCC'>  
//                                            <td align='left' colspan='4'>
//                                                <table border='0' width='400px' align='center' cellspacing='0'>
//                                                    <tr>
//                                                        <td style='width: 290px; text-align: left'>
//                                                            <span style='font-size: 8pt;'>Frt&nbsp; Chrgs.&nbsp; &nbsp;&nbsp;</span>
//                                                        </td>
//                                                        <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                            <label ID='lblDOFrtChr'></label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </td>
//                                        </tr>";
//                                d = d + DOFrtChrgs;
//                                #endregion
//                            }
//                            //************END**********************************************
//                            string addrs = "";
//                            if (Airline_id == "158")
//                            {
//                                #region if condition
//                                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                {
//                                    lblAddress.Text = straddress.ToString();
//                                    lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                    lblAddress1.Text = straddress.ToString();
//                                    #region address as html
//                                    lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";

//                                    lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                                    #endregion
//                                }
//                                else
//                                {
//                                    lblAddress.Text = straddress.ToString();
//                                    lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                    lblAddress1.Text = Airportadress.ToString();
//                                    #region else lblAddress as html
//                                    lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";

//                                    lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + Airportadress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                                    #endregion
//                                }
//                                #endregion
//                            }
//                            else
//                            {
//                                lblAddress.Text = straddress.ToString();
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                lblAddress1.Text = straddress.ToString();

//                                #region else lblAddress as html
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";

//                                lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + Airportadress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                                #endregion
//                            }
//                            // if (lblAddress.Text.Contains("GST NO"))  //By jj
//                            if (straddress.ToString().Contains("GST NO"))
//                            {
//                                #region straddress.ToString().Contains("GST NO")
//                                //commented by jj
//                                //int i = lblAddress.Text.IndexOf(",GST NO");
//                                //StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
//                                //addrs = lblAddress.Text.Replace(StaxNo, ".");
//                                int i = straddress.ToString().IndexOf(",GST NO");
//                                StaxNo = straddress.ToString().Substring(i, straddress.ToString().Length - i).TrimStart(',');
//                                addrs = straddress.ToString().Replace(StaxNo, ".");
//                                addrs = addrs.Replace(",.", ".");
//                                lblAddress.Text = addrs;
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + addrs.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                #endregion
//                            }
//                            else
//                            {
//                                #region  not straddress.ToString().Contains("GST NO")
//                                lblAddress.Text = straddress.ToString();
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                                #endregion
//                            }
//                            //if (lblAddress1.Text.Contains("GST NO")) // commented By jj
//                            if (straddress.ToString().Contains("GST NO"))
//                            {
//                                #region straddress.ToString().Contains("GST NO")
//                                //commented by jj
//                                //int i = lblAddress1.Text.IndexOf(",GST NO");
//                                //StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
//                                //addrs = lblAddress1.Text.Replace(StaxNo, ".");
//                                int i = straddress.IndexOf(",GST NO");
//                                StaxNo = straddress.Substring(i, straddress.Length - i).TrimStart(',');
//                                addrs = straddress.Replace(StaxNo, ".");
//                                addrs = addrs.Replace(",.", ".");
//                                lblAddress1.Text = addrs;
//                                lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + addrs.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                                #endregion
//                            }
//                            else
//                            {
//                                #region Not straddress.ToString().Contains("GST NO")
//                                if (Airline_id == "158")
//                                    if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                        //lblAddress1.Text = straddress.ToString(); by jj                                   
//                                        lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                                    else
//                                        //lblAddress1.Text = Airportadress.ToString();
//                                        lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + Airportadress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                                else
//                                    //lblAddress1.Text = straddress.ToString();
//                                    lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                                #endregion
//                            }

//                            #region straddress.ToString().Contains
//                            //Commented by jj
//                            //if (lblAddress1.Text.Contains("Tel"))
//                            //lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
//                            if (straddress.ToString().Contains("Tel"))
//                                lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("Tel", "<br> Tel") + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                            //Commented by jj
//                            //if (lblAddress1.Text.Contains("TEL"))
//                            //    lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
//                            if (straddress.ToString().Contains("TEL"))
//                                lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("TEL", "<br> TEL") + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                            //Commented by jj
//                            //if (lblAddress.Text.Contains("Tel"))
//                            //    lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
//                            if (straddress.ToString().Contains("Tel"))
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("Tel", "<br> Tel") + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";

//                            //Commented by jj
//                            //if (lblAddress.Text.Contains("TEL"))
//                            //    lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
//                            if (straddress.ToString().Contains("TEL"))
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("TEL", "<br> TEL") + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                            //Commented by jj
//                            //if (lblAddress1.Text.Contains("Fax"))
//                            //    lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
//                            if (straddress.ToString().Contains("Fax"))

//                                lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("Fax", "<br> Fax") + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                            //Commented by jj
//                            //if (lblAddress1.Text.Contains("FAX"))
//                            //    lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
//                            if (straddress.ToString().Contains("FAX"))

//                                lblAddress1html = @"<tr> 
//                                <td style='height: 10px;' colspan='2'>
//                                  <div style='width: 320px;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                        <span class='Apple-style-span'
//                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                            webkit-border-vertical-spacing: 2px'>
//                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("FAX", "<br> FAX") + @"</label><br />
//                                            <label ID='lblTel1' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                            <label ID='lblFax1' Font-Bold='True' style='display:none'>Fax:</label></span>
//                                     </span>
//                                   </div>
//                                </td>
//                                <td colspan='2' style='height: 10px'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
//                                        </span></span>
//                                </td>
//                             </tr>";
//                            //Commented  by jj
//                            //if (lblAddress.Text.Contains("Fax"))
//                            //    lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
//                            if (straddress.ToString().Contains("Fax"))
//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("Fax", "<br> Fax") + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";

//                            //if (lblAddress.Text.Contains("FAX"))
//                            //    lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");
//                            if (straddress.ToString().Contains("FAX"))

//                                lblAddresshtml = @"<tr>
//                                        <td style='height: 50px;' colspan='2'>
//                                            <div style='width: 320px;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>
//                                                        <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'>" + straddress.ToString().Replace("FAX", "<br> FAX") + @"</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblTel' Font-Bold='True' style='display:none'>Tel:</label><br />
//                                                        &nbsp;
//                                                        <label ID='lblFax' Font-Bold='True' style='display:none'>Fax:</label></span></span>
//                                            </div>
//                                        </td>";
//                            #endregion

//                            if (payment_mode == "1")
//                            {
//                                lblCheque.Visible = false;
//                                div2html_3 = string.Empty;
//                                lblCash.Text = "in Cash";
//                                div2html_2 += @"<label ID='lblCash' CssClass='text' Font-Bold='True' Font-Size='8pt'>in Cash</label>";
//                            }
//                            else if (payment_mode == "2")
//                            {
//                                lblCash.Visible = false;
//                                div2html_2 = string.Empty;

//                                lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
//                                div2html_3 += @"<label ID='lblCheque' CssClass='text' Font-Bold='True' Font-Size='8pt'>in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + @" , Bank: " + dt.Rows[0]["Bank_Name"].ToString() + @", Date: " + dt.Rows[0]["Cheque_Dated"].ToString() + @"</label>";
//                            }

//                            #region lblAirlineStax Area
//                            if (strAirline_name == "MALAYSIA AIRLINES")
//                            {
//                                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                #region lblAirlineStax.Text = "Acumen Overseas Pvt converted as html
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }
//                            else if (strAirline_name == "TURKISH AIRLINES")
//                            {
//                                lblAirlineStax.Text = "Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                #region lblAirlineStax.Text = "Ascent Air Pvt  converted as html
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }
//                            else if (strAirline_name == "AIR CHINA")
//                            {
//                                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                #region lblAirlineStax.Text = "Acumen Overseas  converted as html
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }
//                            else if (strAirline_name == "KOREAN AIRLINES")
//                            {
//                                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                #region lblAirlineStax.Text = "Acumen Overseas Pvt converted as html
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }
//                            else if (strAirline_name == "MEGA MALDIVES AIRLINES")
//                            {
//                                lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                #region  lblAirlineStax.Text = "ATC SOFTWAY  converted as html
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }
//                            else
//                            {
//                                #region  lblAirlineStax.Text = "Pace Express  converted as html
//                                lblAirlineStax.Text = "Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
//                                lblAirlineStaxhtml = @"<tr>   
//                                    <td colspan='4'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
//                                                <table style='width: 600px'>
//                                                    <tr>
//                                                        <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
//                                                            font-family: Verdana, Arial, Helvetica, sans-serif'>
//                                                            In accordance with notification stamps No. 3 dated 21st December issued by<br />
//                                                            the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
//                                                            affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
//                                                            <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </span></span>
//                                    </td>
//                                </tr>";
//                                #endregion
//                            }
//                            #endregion

//                            lblairlinename.Text = strAirline_name.ToString();
//                            lblairlinenamehtml = @"<tr>   
//                                    <td colspan='4' style='height: 1px; text-align: center;'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                <h4 style='text-align: center'>
//                                                    TAX INVOICE</h4>
//                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>
//                                            </span></span>
//                                    </td>
//                        </tr>";

//                            if (Airline_id == "158")
//                            {
//                                #region Airline_id == "158"
//                                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
//                                {
//                                    #region lblAirlineNme.Text = "KOREAN AIR";
//                                    lblAirlineNme.Text = "KOREAN AIR";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "KOREAN AIR";
//                                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";
//                                    #endregion
//                                }
//                                else
//                                {
//                                    #region lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
//                                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
//                                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";
//                                    #endregion
//                                }
//                                #endregion
//                            }
//                            else if (Airline_id == "159")
//                            {
//                                #region Airline_id == "159"
//                                if (FlightNo == "HY-127")
//                                {
//                                    #region lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
//                                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
//                                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";

//                                    lblairlinename.Text = "UZBEKISTAN AIRWAYS";
//                                    lblairlinenamehtml = @"<tr>   
//                                    <td colspan='4' style='height: 1px; text-align: center;'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                <h4 style='text-align: center'>
//                                                    TAX INVOICE</h4>
//                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>
//                                            </span></span>
//                                    </td>
//                            </tr>";
//                                    #endregion
//                                }
//                                else
//                                {
//                                    #region lblAirlineNme.Text = "KOREAN AIR";
//                                    lblAirlineNme.Text = "KOREAN AIR";
//                                    lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme' Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
//                                    </td></tr>";

//                                    lblheadairlinename.Text = "KOREAN AIR";
//                                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";

//                                    lblairlinename.Text = "KOREAN AIR";
//                                    lblairlinenamehtml = @"<tr>   
//                                    <td colspan='4' style='height: 1px; text-align: center;'>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                <h4 style='text-align: center'>
//                                                    TAX INVOICE</h4>
//                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>KOREAN AIR</label>
//                                            </span></span>
//                                    </td>
//                            </tr>";
//                                    #endregion
//                                }
//                                #endregion
//                            }
//                            else
//                            {
//                                #region lblAirlineNme.Text = strAirline_name.ToString();
//                                lblAirlineNme.Text = strAirline_name.ToString();
//                                lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                         <label id='lblAirlineNme' Font-Bold='True' Font-Size='8pt'>" + strAirline_name.ToString() + @"</label>
//                                    </td></tr>";

//                                lblheadairlinename.Text = strAirline_name.ToString();
//                                lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
//                                            <td colspan='4' style='text-align: center;'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
//                                                    <span class='Apple-style-span'
//                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
//                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
//                                                        <label ID='lblheadairlinename' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>                            
//                                                    </span>
//                                                 </span>
//                                            </td>
//                                        </tr>";
//                                #endregion
//                            }

//                            lblFlightno.Text = flt_no.ToString();
//                            lblFlightDatehtml_lblFlightno = @"<tr><td style='height: 15px;' colspan='2'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>order the following packages which arrived
//                                        <label ID='lblFlightno'  Font-Bold='True' Font-Size='7pt'>" + flt_no.ToString() + @"</label>";

//                            lbligmnr.Text = IGMNo.ToString();
//                            lblFlightDatehtml_lbligmnr = @"<td style='height: 15px; width: 125px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>IGM NO:
//                                        <label ID='lbligmnr'  Font-Bold='True' Font-Size='8pt'>" + IGMNo.ToString() + @"</label></span></span>
//                            </td>
//                            <td style='height: 15px;'>
//                            </td>
//                        </tr>";

//                            lbldate2.Text = issue_date.ToString();
//                            lblAddresshtml_lbldate2 += @"<td style='height: 50px; text-align: right;'>
//                              <span style='font-size: 7pt; font-family: Verdana'>Date:</span>
//                              </td><td style='height:21px; width:250px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform:none; color:rgb(0,0,0); text-indent:0px; letter-spacing:normal;
//                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'><b><span style='font-size: 7pt'>&nbsp;</span>
//                                        <label  ID='lbldate2' Font-Size='8pt'>" + issue_date.ToString() + @"</label></b></span></span></td>
//                           </tr>";

//                            lblAwb2.Text = awbno.ToString();
//                            lblFlitno2.Text = flt_no.ToString();
//                            Space5html = @"<tr id='Space5'> 
//                            <td style='height: 21px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>on MAWB:
//                                        <label ID='lblAwb2' Font-Bold='True' Font-Size='8pt'>" + awbno.ToString() + @"</label></span></span>
//                            </td>
//                            <td style='height: 21px;' class='text'>
//                                <label ID='lblFlitno2' Font-Bold='True' Font-Size='8pt'>" + flt_no.ToString() + @"</label>
//                            </td>
//                            <td style='height: 21px;'>
//                            </td>";

//                            lblAirlinemame3.Text = strAirline_name.ToString();
//                            Space6html = @"<tr id='Space6'>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td style='height: 21px; white-space: nowrap;' class='text'>
//                                <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'>" + strAirline_name.ToString() + @"</label>
//                            </td>
//                        </tr>";

//                            lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");
//                            lblDatehtml = @"<tr><td>
//                                </td><td></td>
//                                 <td style='text-align: right;'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; text-transform: none; color: rgb(0,0,0);
//                                        text-indent: 0px; white-space: normal; letter-spacing: normal; border-collapse: separate;
//                                        orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px;
//                                        webkit-text-decorations-in-effect: none; webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px;
//                                        font-weight: normal; line-height: normal; font-style: normal; font-family: 'Times New Roman';
//                                        font-variant: normal;'><span class='Apple-style-span' style='font-size: 7pt; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                            webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px'>Date:</span></span>
//                                </td>
//                                <td style='width: 300px;font-weight: 600;'>
//                                    <span style='font-size: 7pt; font-family: Verdana'><strong></strong>
//                                        <label ID='lblDate' Font-Bold='True' Font-Size='8pt'>" + DateTime.Now.ToString("MMM dd yyyy hh:mmtt") + @"</label></span>
//                                </td>
//                        </tr>";

//                            lblAwbno.Text = awbno.ToString();
//                            lblAwbnohtml = @"<tr>
//                            <td style='height: 17px;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>MAWB:
//                                        <label ID='lblAwbno'  Font-Bold='True' Font-Size='8pt'>" + awbno.ToString() + @"</label></span></span>
//                            </td>";

//                            lblpppschtml = @"<label ID='lblpppsc' CssClass='textbold'>/</label><strong><span style='font-size: 11pt; font-family: Verdana'></span></strong>";

//                            lblPcs.Text = pcs.ToString();
//                            lblPcshtml = @"<label ID='lblPcs'  Font-Bold='True' Font-Names='Verdana' Font-Size='8pt'>" + pcs.ToString() + @"</label>
//                        </td>";

//                            lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();
//                            lblWthtml = @"<td style='height: 17px;' class='text'>
//                            GR.Wt (In Kg):
//                            <label ID='lblWt' Font-Bold='True' Font-Size='8pt'>" + dt.Rows[0]["Gross_Weight"].ToString() + @"</label>
//                        </td>";

//                            lblcommdy.Text = contents.ToString();
//                            lblcommdyhtml = @"<td style='height: 17px;' class='text'>
//                            Commdy:
//                            <label ID='lblcommdy'  Font-Bold='True' Font-Size='8pt' Font-Underline='False'>" + contents.ToString() + @"</label>
//                          </td>
//                        </tr>";

//                            if (Airline_id == "147")
//                            {
//                                #region if condition
//                                lblch.Visible = true;
//                                lblchwt.Visible = true;
//                                lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
//                                lblchlblchwthtml = @" <tr>
//                                        <td colspan=2 style='height:17px'>
//                                        </td>
//                                        <td style='height: 17px;' class='text'>
//                                            <label ID='lblch' CssClass='text'>CH.WT (In Kg):</label>                    
//                                             <label ID='lblchwt' Font-Bold='True' Font-Size='8pt'>" + dt.Rows[0]["Charged_Weight"].ToString() + @"</label>
//                                        </td>
//                                        <td class='text' style='height: 17px'>
//                                            <strong>FOR</strong>
//                                        </td>
//                                    </tr>";

//                                lblAirlinemame3.Text = "MASkargo";
//                                Space6html = @"<tr id='Space6'>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td style='height: 21px; white-space: nowrap;' class='text'>
//                                <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'>MASkargo</label>
//                            </td>
//                           </tr>";

//                                lblAirlineNme.Text = "MASkargo";
//                                lblAirlineNmehtml = @"<tr>
//                                    <td colspan=3 style='height: 10px'>
//                                    </td>
//                                    <td class='text' style='height: 10px'>
//                                            <label id='lblAirlineNme' Font-Bold='True' Font-Size='8pt'>MASkargo</label>
//                                    </td></tr>";
//                                #endregion
//                            }
//                            else if (Airline_id == "153")
//                            {
//                                lblch.Visible = true;
//                                lblchwt.Visible = true;
//                                lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
//                                lblchlblchwthtml = @" <tr>
//                                        <td colspan=2 style='height:17px'>
//                                        </td>
//                                        <td style='height: 17px;' class='text'>
//                                            <label ID='lblch' CssClass='text'>CH.WT (In Kg):</label>                    
//                                             <label ID='lblchwt' Font-Bold='True' Font-Size='8pt'>" + dt.Rows[0]["Charged_Weight"].ToString() + @"</label>
//                                        </td>
//                                        <td class='text' style='height: 17px'>
//                                            <strong>FOR</strong>
//                                        </td>
//                                    </tr>";
//                            }
//                            if (Airline_id == "159")
//                            {
//                                lblAirlinemame3.Text = "KOREAN AIR";
//                                Space6html = @"<tr id='Space6'>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td>
//                            </td>
//                            <td style='height: 21px; white-space: nowrap;' class='text'>
//                                <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
//                            </td>
//                        </tr>";
//                            }
//                            //******************Added On 1 feb 2011*********************
//                            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
//                            {
//                                TrFreightChrgsCC.Visible = true;
//                                TrFreightChrgsCChtml = @"<tr id='TrFreightChrgsCC'>  
//                                            <td align='left' colspan='4'>
//                                                <table border='0' width='400px' align='center' cellspacing='0'>
//                                                    <tr>
//                                                        <td style='width: 290px; text-align: left'>
//                                                            <span style='font-size: 8pt;'>Frt&nbsp; Chrgs.&nbsp; &nbsp;&nbsp;</span>
//                                                        </td>
//                                                        <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                            <label ID='lblDOFrtChr'></label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </td>
//                                        </tr>";

//                                #region  dt.Rows[0]["freight_Type"].ToString() == "CC"
//                                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0.00")
//                                {
//                                    lblDOFrtChr.Text = "0";

//                                    //                                TrFreightChrgsCChtml = @"<tr id='TrFreightChrgsCC'>  
//                                    //                                            <td align='left' colspan='4'>
//                                    //                                                <table border='0' width='400px' align='center' cellspacing='0'>
//                                    //                                                    <tr>
//                                    //                                                        <td style='width: 290px; text-align: left'>
//                                    //                                                            <span style='font-size: 8pt;'>Frt&nbsp; Chrgs.&nbsp; &nbsp;&nbsp;</span>
//                                    //                                                        </td>
//                                    //                                                        <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                    //                                                            <label ID='lblDOFrtChr'>0</label>
//                                    //                                                        </td>
//                                    //                                                    </tr>
//                                    //                                                </table>
//                                    //                                            </td>
//                                    //                                        </tr>";
//                                    TrFreightChrgsCC.Visible = false;
//                                    TrFreightChrgsCChtml = string.Empty;
//                                }
//                                else
//                                {

//                                    TrFreightChrgsCC.Visible = true;
//                                    lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
//                                    TrFreightChrgsCChtml = @"<tr id='TrFreightChrgsCC'>  
//                                            <td align='left' colspan='4'>
//                                                <table border='0' width='400px' align='center' cellspacing='0'>
//                                                    <tr>
//                                                        <td style='width: 290px; text-align: left'>
//                                                            <span style='font-size: 8pt;'>Frt&nbsp; Chrgs.&nbsp; &nbsp;&nbsp;</span>
//                                                        </td>
//                                                        <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                            <label ID='lblDOFrtChr'>" + dt.Rows[0]["Total_Collection_CC"].ToString() + @"</label>
//                                                        </td>
//                                                    </tr>
//                                                </table>
//                                            </td>
//                                        </tr>";
//                                    total += Convert.ToDecimal(dt.Rows[0]["Total_Collection_CC"]);
//                                }
//                                #endregion
//                            }
//                            //****************************End*********************************************
//                            decimal _Amount_Received = 0;
//                            decimal _Amount_ReceivedSBCess = 0;
//                            decimal _Amount_ReceivedKKCess = 0;
//                            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
//                            {
//                                #region for looping
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
//                                {
//                                    _Amount_Received = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
//                                }
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
//                                {
//                                    _Amount_ReceivedSBCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
//                                }
//                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
//                                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
//                                {
//                                    _Amount_ReceivedKKCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
//                                }
//                                #endregion
//                            }
//                            decimal _TDSCutByAgent = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());
//                            decimal f = d + Convert.ToDecimal(MawbDo_Chgs);
//                            decimal _Amount = 0;
//                            _Amount = Convert.ToInt64(f);
//                            string TD_S = "";
//                            string TD_S1 = "";
//                            string Total_ = "";
//                            if (Airline_id == "159")
//                            {
//                                decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));
//                                total = total - mawcharge + _Amount_Received + charge;
//                            }
//                            if (_TDSCutByAgent > 0 || ServiceTax > 0)
//                            {
//                                //lblfreighthtml here
//                                #region if part
//                                if (_TDSCutByAgent > 0)
//                                {
//                                    #region  _TDSCutByAgent > 0
//                                    string TD = Convert.ToString(Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
//                                    TD_S = Convert.ToDecimal(TD).ToString("#,##0.00");

//                                    ////string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
//                                    ////string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
//                                    string A = Convert.ToString(total);
//                                    string B = Convert.ToString(total);
//                                    if (Airline_id == "159")
//                                    {
//                                        A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
//                                        KE_MUM_Tds = total;
//                                    }
//                                    decimal AM = 0;
//                                    AM = decimal.Parse(A);
//                                    Total_ = Convert.ToDecimal(A).ToString("#,##0.00");
//                                    if (Airline_id == "159")
//                                    {
//                                        lblfreight.Text = B;
//                                        lblfreighthtml = @"<tr id='Tr2' style='font-size: 12pt'>
//                                        <td align='left' colspan='4'>
//                                            <table border='0' width='400px' align='center' cellspacing='0'>
//                                                <tr>
//                                                    <td style='width: 290px; text-align: left'>
//                                                         <label ID='Label5' Font-Names='Verdana' Font-Size='Smaller'
//                                                            Font-Bold='True'> Total DO Amt (Inc.Gst):</label>
//                                                    </td>
//                                                    <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                        <label ID='lblfreight'  Font-Bold='True' Font-Underline='True'
//                                                            Font-Names='Verdana' Font-Size='8pt'>" + B.ToString() + @"</label>
//                                                    </td>
//                                                </tr>
//                                            </table>
//                                        </td>              
//                                    </tr>";
//                                        KE_MUM_frt = AM;
//                                    }
//                                    else
//                                    {
//                                        lblfreight.Text = Total_;
//                                        lblfreighthtml = @"<tr id='Tr2' style='font-size: 12pt'>
//                                        <td align='left' colspan='4'>
//                                            <table border='0' width='400px' align='center' cellspacing='0'>
//                                                <tr>
//                                                    <td style='width: 290px; text-align: left'>
//                                                         <label ID='Label5' Font-Names='Verdana' Font-Size='Smaller'
//                                                            Font-Bold='True'> Total DO Amt (Inc.Gst):</label>
//                                                    </td>
//                                                    <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                        <label ID='lblfreight' Font-Bold='True' Font-Underline='True'
//                                                            Font-Names='Verdana' Font-Size='8pt'>" + Total_.ToString() + @"</label>
//                                                    </td>
//                                                </tr>
//                                            </table>
//                                        </td>              
//                                    </tr>";
//                                    }
//                                    _Amount = decimal.Parse(lblfreight.Text);
//                                    #endregion
//                                }
//                                //****************** Service Tax Logic on 16 Aug 2010 *****************
//                                else
//                                {
//                                    #region else part
//                                    lblfreight.Text = total.ToString();
//                                    lblfreighthtml = @"<tr id='Tr2' style='font-size: 12pt'>
//                                        <td align='left' colspan='4'>
//                                            <table border='0' width='400px' align='center' cellspacing='0'>
//                                                <tr>
//                                                    <td style='width: 290px; text-align: left'>
//                                                         <label ID='Label5' Font-Names='Verdana' Font-Size='Smaller'
//                                                            Font-Bold='True'> Total DO Amt (Inc.Gst):</label>
//                                                    </td>
//                                                    <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                        <label ID='lblfreight'  Font-Bold='True' Font-Underline='True'
//                                                            Font-Names='Verdana' Font-Size='8pt'>" + total.ToString() + @"</label>
//                                                    </td>
//                                                </tr>
//                                            </table>
//                                        </td>              
//                                    </tr>";
//                                    _Amount = decimal.Parse(lblfreight.Text);
//                                    KE_MUM_frt = decimal.Parse(lblfreight.Text);
//                                    KE_MUM_Tds = decimal.Parse(lblfreight.Text);
//                                    #endregion
//                                }
//                                #endregion
//                            }
//                            else
//                            {
//                                //lblfreighthtml here
//                                #region else epart
//                                string _F = "";
//                                if (dt.Rows[0]["freight_Type"].ToString() == "CC")
//                                {
//                                    _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue) + decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString()));
//                                }
//                                else
//                                {
//                                    _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue));
//                                }
//                                lblfreight.Text = Convert.ToDecimal(_F).ToString("#,##0.00");
//                                lblfreighthtml = @"<tr id='Tr2' style='font-size: 12pt'>
//                                        <td align='left' colspan='4'>
//                                            <table border='0' width='400px' align='center' cellspacing='0'>
//                                                <tr>
//                                                    <td style='width: 290px; text-align: left'>
//                                                         <label ID='Label5' Font-Names='Verdana' Font-Size='Smaller'
//                                                            Font-Bold='True'> Total DO Amt (Inc.Gst):</label>
//                                                    </td>
//                                                    <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                        <label ID='lblfreight'  Font-Bold='True' Font-Underline='True' Font-Names='Verdana' Font-Size='8pt'>" + Convert.ToDecimal(_F).ToString("#,##0.00") + @"</label>
//                                                    </td>
//                                                </tr>
//                                            </table>
//                                        </td>              
//                                    </tr>";

//                                KE_MUM_frt = decimal.Parse(lblfreight.Text);
//                                KE_MUM_Tds = decimal.Parse(lblfreight.Text);
//                                //_Amount = f;
//                                _Amount = decimal.Parse(lblfreight.Text);
//                                #endregion
//                            }
//                            if (Airline_id == "159")
//                            {
//                                //lblfreighthtml here
//                                #region if condition
//                                if (lblfreight.Text == "")
//                                {
//                                    lblfreight.Text = "0";
//                                    lblfreighthtml = @"<tr id='Tr2' style='font-size: 12pt'>
//                                        <td align='left' colspan='4'>
//                                            <table border='0' width='400px' align='center' cellspacing='0'>
//                                                <tr>
//                                                    <td style='width: 290px; text-align: left'>
//                                                         <label ID='Label5' Font-Names='Verdana' Font-Size='Smaller'
//                                                            Font-Bold='True'> Total DO Amt (Inc.Gst):</label>
//                                                    </td>
//                                                    <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                        <label ID='lblfreight'  Font-Bold='True' Font-Underline='True'
//                                                            Font-Names='Verdana' Font-Size='8pt'>------------</label>
//                                                    </td>
//                                                </tr>
//                                            </table>
//                                        </td>              
//                                    </tr>";
//                                }
//                                lblBreakupTotal.Text = KE_MUM_Tds.ToString();
//                                lblRecivedAmt.Text = KE_MUM_frt.ToString();
//                                Tr5html_lblRecivedAmt = @"<tr id='lessTds'>
//                                <td style='width: 290px; text-align: left;'>
//                                    <label ID='lblRecAmt' 
//                                                      Font-Names='Verdana' Font-Size='Smaller' Font-Bold='True'>Total Amt Recievable:</label>                                    
//                                </td>
//                                <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                    <label ID='lblRecivedAmt' Font-Bold='True' Font-Underline='True'
//                                              Font-Names='Verdana' Font-Size='8pt'>" + KE_MUM_frt.ToString() + @"</label>
//                                </td>
//                               </tr></table>
//                                 </td>               
//                               </tr>            
//                               </table>";

//                                Label1str = lblRecivedAmt.Text;
//                                Label1.Text = lblRecivedAmt.Text;
//                                AmtDescphtml_Label1 = @"<tr id='AmtDescp'> 
//                                    <td>
//                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span style='font-size: 10px;
//                                                font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                webkit-border-vertical-spacing: 2px'>an amount of Rs.<label ID='Label1' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + KE_MUM_frt.ToString() + @"</label></span></span>
//                                    </td>";
//                                #endregion
//                            }
//                            ////Label1.Text = lblfreight.Text;
//                            #region

//                            lblSno.Text = recipt_no.ToString();
//                            trdelhtml = @"<tr id=trdel>
//                            <td style=height: 25px>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                        webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px>The
//                                        Collector of Customs<br />
//                                        Cargo Terminal(Import)<br />
//                                        I.G.I. Airport<br />
//                                        New Delhi</span></span>
//                            </td>
//                            <td style=height: 50px>
//                            </td>
//                            <td style=height: 50px; text-align: right;>
//                                <span style=font-size: 7pt; font-family: Verdana>Sr.No:</span>
//                            </td>
//                            <td style=height: 50px>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px>&nbsp;<label ID=lblSno runat=server Font-Bold=True Font-Size=8pt>" + recipt_no.ToString() + @"</label></span></span></td></tr>";

//                            lblSnomum.Text = recipt_no.ToString();
//                            trmumhtml = @"<tr id=trmum> 
//                            <td style='height: 25px'>
//                                <span class=Apple-style-span style=word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px><span class=Apple-style-span
//                                        style=font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                        webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px>
//                                        The Collector of Customs<br />
//                                        Chhatrapati Shivaji International Airport<br />
//                                        Sahar Cargo Complex, Andheri East.<br />
//                                        Mumbai-400099.</span></span>
//                            </td>
//                            <td style=height: 50px>
//                            </td>
//                            <td style='height: 50px; text-align: right;'>
//                                <span style='font-size: 7pt; font-family: Verdana'>Sr.No:</span>
//                            </td>
//                            <td style='height: 50px,font-weight:bold;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>&nbsp;<label ID='lblSnomum' 
//                                            Font-Bold='True' Font-Size='8pt'>" + recipt_no.ToString() + @"</label></span></span></td></tr>";

//                            lblSnochennai.Text = recipt_no.ToString();
//                            trchennaihtml = @"<tr id='trchennai'>   
//                                                <td style='height: 25px'>
//                                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
//                                                            webkit-border-horizontal-spacing: 2px; webkit-border-vertical-spacing: 2px'>THE
//                                                            COMMISSIONER OF CUSTOMS<br />
//                                                            CARGO TERMINAL<br />
//                                                            CHENNAI 600 027. </span></span>
//                                                </td>
//                                                <td style='height: 50px'>
//                                                </td>
//                                                <td style='height: 50px; text-align: right;'>
//                                                    <span style='font-size: 7pt; font-family: Verdana'>Sr.No:</span>
//                                                </td>
//                                                <td style='height: 50px'>
//                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                                        webkit-border-vertical-spacing: 2px'>&nbsp;<label ID='lblSnochennai'  Font-Bold='True' Font-Size='8pt'>" + recipt_no.ToString() + @"</label></span></span></td></tr>";

//                            lblSno2.Text = recipt_no.ToString();
//                            lblSno2html = @"<tr> 
//                            <td style='height: 20px;'>
//                            </td>
//                            <td style='height: 20px;'>
//                            </td>
//                            <td style='height: 20px; text-align: right;'>
//                                <span style='font-size: 7pt; font-family: Verdana'>Sr.No.</span>
//                            </td>
//                           <td style='height: 20px;font-weight: 600;'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
//                                    border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>&nbsp;<label ID='lblSno2' Font-Bold='True' Font-Size='8pt'>" + recipt_no.ToString() + @"</label></span></span></td>
//                           </tr>";

//                            lblName.Text = to.ToString();
//                            lblNamehtml = @"<tr> 
//                            <td colspan='2' style='height: 26px'>
//                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                        style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
//                                        webkit-border-vertical-spacing: 2px'>Received with thanks from M/S
//                                        <label ID='lblName'  Font-Bold='True'>" + to.ToString() + @"</label></span></span>
//                            </td>
//                            <td style='height: 26px;'>
//                            </td>
//                            <td style='height: 26px;'>
//                            </td>
//                            </tr>";

//                            lblName2.Text = to.ToString();
//                            lblName2html = @"<tr>
//                                <td style='height: 15px' colspan='2'>
//                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
//                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
//                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
//                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
//                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
//                                            style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'></span>
//                                    </span><span style='font-size: 8pt; font-family: Verdana'>Please deliver to M/S</span>
//                                    <label ID='lblName2' Font-Bold='True' Font-Size='8pt'>" + to.ToString() + @"</label>
//                                </td>
//                                <td style='height: 15px'>
//                                </td>
//                                <td style='height: 15px'>
//                                </td>
//                                </tr>";
//                            Sno.Text = recipt_no.ToString();
//                            //Sno.Text = recipt_no.ToString();
//                            AmtDescphtml_Sno = @"<td class='text' colspan='3'>
//                                        (Rs. Amount Collect by VIA RECP:
//                                        <label ID='Sno'  Font-Bold='True' Font-Size='8pt'>" + recipt_no.ToString() + @"</label>).
//                                    </td>
//                                </tr>";
//                            #endregion

//                            string englishTranslation = "";
//                            string englishTranslationDecimalPart = "";
//                            //string englishTranslation = changeNumericToWords(Convert.ToDouble(f));
//                            //********** Function Translation of Number figure TO Words******************
//                            string Amt = _Amount.ToString();
//                            string AmtDecimal = "";
//                            string AmountCombined = "";
//                            //***** Shipment Type is FOC Case**********//
//                            if (dt.Rows[0]["shipment_type"].ToString() == "F")
//                            {
//                                // lblfreighthtml here
//                                #region  dt.Rows[0]["shipment_type"].ToString() == "F"
//                                _Amount = 0;
//                                lblfreight.Text = "0.00";
//                                lblfreighthtml = @"<tr id='Tr2' style='font-size: 12pt'>
//                                        <td align='left' colspan='4'>
//                                            <table border='0' width='400px' align='center' cellspacing='0'>
//                                                <tr>
//                                                    <td style='width: 290px; text-align: left'>
//                                                         <label ID='Label5' Font-Names='Verdana' Font-Size='Smaller'
//                                                            Font-Bold='True'> Total DO Amt (Inc.Gst):</label>
//                                                    </td>
//                                                    <td style='font-size: 12pt; width: 244px; text-align: right;'>
//                                                        <label ID='lblfreight'  Font-Bold='True' Font-Underline='True'
//                                                            Font-Names='Verdana' Font-Size='8pt'>0.00</label>
//                                                    </td>
//                                                </tr>
//                                            </table>
//                                        </td>              
//                                    </tr>";

//                                lblRecivedAmt.Text = "0.00";
//                                Tr5html_lblRecivedAmt = @"<tr id='lessTds'>
//                                <td style='width: 290px; text-align: left;'>
//                                    <label ID='lblRecAmt' Font-Names='Verdana' Font-Size='Smaller'
//                                        Font-Bold='True'>Total Amt Recievable:</label>                                    
//                                </td>
//                                <td style='font-size: 12pt; width: 244px; text-align: right;text-decoration: underline;'>
//                                    <label ID='lblRecivedAmt' Font-Bold='True' Font-Underline='True'
//                                        Font-Names='Verdana' Font-Size='8pt'><h4 style='text-align: center'>0.00</h4></label>
//                                </td>
//                               </tr></table>
//                                 </td>               
//                               </tr>            
//                            </table>";

//                                lblAmount.Text = "Zero";
//                                div2html_1 = @" Amount <label ID='lblAmount' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>Zero</label>";
//                                englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
//                                #endregion
//                            }
//                            else
//                            {
//                                ////////englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
//                                englishTranslation = changeNumericToWords(Convert.ToDouble(lblRecivedAmt.Text));
//                                lblAmount.Text = englishTranslation;
//                                div2html_1 = @" Amount <label ID='lblAmount' Font-Bold='True' Font-Underline='False' Font-Size='8pt'>" + englishTranslation + @"</label>";
//                            }
//                            //lblFlightDate.Text = flight_date.ToString();
//                            DateTime fltdate = DateTime.Parse(flight_date);
//                            lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");
//                            lblFlightDatehtml_lblFlightDate = @"<em><strong>/</strong></em>
//                                        <label ID='lblFlightDate'  CssClass='boldtext' Font-Bold='True'  Font-Size='7pt'>" + fltdate.ToString("dd/MM/yyyy") + @"</label></span></span></td>";
//                            // lblFltDateAirline.Text = flight_date.ToString();
//                            DateTime fltdate2 = DateTime.Parse(flight_date);
//                            lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");
//                            Space5html_2 = @"<td style='height: 21px;' class='text'>
//                                Of&nbsp;
//                                <label ID='lblFltDateAirline' CssClass='boldtext' Font-Bold='True' Font-Size='8pt'>" + fltdate2.ToString("dd/MM/yyyy") + @"</label>.
//                            </td>
//                        </tr>";
//                            //*******************Updating DO_GenerateStatus_Ist_Time On 26 Aug 2010******************
//                            con = new SqlConnection(strCon);
//                            con.Open();
//                            com = new SqlCommand("update Import_Flight_AWB set D0_Generate_Status='YES' where import_awb_id='" + strawbid[jj] + "'", con);
//                            com.ExecuteNonQuery();
//                            con.Close();
//                            //***********************End oF DO_Generate_Status*************************************
//                            #endregion
//                        }
//                        #endregion
//                    }
//                    #region final html Post
//                    blanktrhtml = @"<tr>
//                <td style='height: 15px;' colspan='2'>
//                </td>
//                    <td style='height: 15px; width: 125px;'>
//                        &nbsp;
//                    </td>
//                    <td style='height: 15px;'>
//                        &nbsp;
//                    </td>
//                     </tr>";
//                    if (trdelhtml == "" && trchennaihtml == "")
//                    {
//                        trmumhtml += trmumhtml_lblSnomum;
//                    }
//                    else if (trdelhtml == "" && trmumhtml == "")
//                    {
//                        trchennaihtml += trchennaihtml_lblSnochennai;
//                    }
//                    else
//                    {
//                        trdelhtml += trdelhtml_lblSno;
//                    }

//                    innerhtml += lblheadairlinenamehtml + imgDeliveryAirlogohtml + lblAddress1html + lblDatehtml + trdelhtml + trmumhtml + trchennaihtml;

//                    innerhtml += blanktrhtml + lblName2html + lblNotifyDohtml;

//                    innerhtml += lblFlightDatehtml_lblFlightno + lblFlightDatehtml_lblFlightDate + lblFlightDatehtml_lbligmnr;

//                    innerhtml += blanktrhtml + lblAwbnohtml + lblPartPschtml_Begin + lblPartPschtml + lblpppschtml + lblPcshtml + lblWthtml + lblcommdyhtml + lblchlblchwthtml;

//                    innerhtml += lblAirlineNmehtml + lblremarkshtml + lblairlinenamehtml + imgReciptairlogohtml;

//                    innerhtml += lblAddresshtml + lblAddresshtml_lbldate2 + lblSno2html + lblNamehtml + lblNotifyhtml;

//                    innerhtml += PartShipmentCasehtml + AmtDescphtml_Label1 + AmtDescphtml_Sno + Tr1html;

//                    //  innerhtml += @"<tr id='Tr1'> 
//                    //       <td align='left' colspan='4'>
//                    //          <label ID='lblTabel'  CssClass='text'>" + table + @"</label>
//                    //       </td>
//                    //   </tr>";

//                    TotalLinehtml = @"<tr id='TotalLine' style='font-size: 12pt'>  
//                    <td colspan='4' style='text-align: center'>
//                        -----------------------------------------------------------------------------------------------------
//                    </td>
//                    </tr>";

//                    innerhtml += TrFreightChrgsCChtml + TotalLinehtml + lblfreighthtml;
//                    TotalSpacehtml += @"<tr id='TotalSpace' style='font-size: 12pt'>
//                    <td colspan='4' style='text-align: center' class='style1'>
//                    --------------------------------------------------------------------------------------------------
//                    </td>
//                    </tr>";

//                    innerhtml += TotalSpacehtml + lblInclusivehtml;
//                    Tr4html = @"<tr id='Tr4' style='font-size: 12pt'>
//                    <td colspan='4' style='text-align: center'>
//                        -----------------------------------------------------------------
//                    </td>
//                    </tr>";

//                    div2html = @"<div style='width: 750px;' id='div2'>
//                                  <table style='width: 750px;'>
//                                    <tr id='Tr3' style='font-size: 12pt'>
//                                        <td class='text' colspan='4' style='text-align:left; white-space: nowrap;'>";

//                    div2html_5 += @"</td></tr></table></div>";

//                    innerhtml += Tr4html + Tr5html_lblBreakupTotal + Tr5html_lblTds + Tr5html_lblRecivedAmt;

//                    innerhtml += div2html + div2html_1 + div2html_2 + div2html_3 + div2html_4 + div2html_5 + Space3html_1 + Space3html_2;

//                    innerhtml += Space5html + Space5html_2 + Space6html + lblAirlineStaxhtml;

//                    #endregion

//                    innerhtml += @"<tr style='height: 3px;font-size:12px; text-align: center'><td colspan='4'></td></tr>
//                                    <tr style='height: 3px;font-size:12px; text-align: center'><td colspan='4'></td></tr>
//                                    <tr style='height: 3px;font-size:12px; text-align: center'><td colspan='4'><b>This is System Generated invoice, Signature and Stamp is not mandatory.</b></td></tr>
//                                  </table>
//                                  </div>";
//                }
//                Label111.Text = innerhtml.ToString();
//                #endregion

//                #region  pdf generate
//                //Response.ContentType = "application/pdf";
//                //Response.AddHeader("content-disposition", "attachment;filename=CSR.pdf");
//                //Response.Cache.SetCacheability(HttpCacheability.NoCache);
//                //StringWriter sw = new StringWriter();
//                //HtmlTextWriter hw = new HtmlTextWriter(sw);
//                //Label111.RenderControl(hw);
//                //StringReader sr = new StringReader(sw.ToString());
//                //Document pdfDoc = new Document(PageSize.A4, 0f, 0f, 0f, 0f);
//                //HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
//                //iTextSharp.text.Table tbl = new iTextSharp.text.Table(1, 4);
//                //tbl.Cellpadding = 0;
//                //tbl.Cellspacing = 0;
//                //tbl.BorderColor = Color.WHITE;
//                //tbl.Alignment = Element.ALIGN_LEFT;
//                //tbl.Width = 100f;
//                //pdfDoc.SetMargins(0f, 0f, 0f, 0f);
//                //PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
//                //pdfDoc.Open();
//                //pdfDoc.Add(tbl);
//                //htmlparser.Parse(sr);
//                //pdfDoc.Close();
//                #endregion
//            }       
            #endregion
        }
    }

    protected void ShowAirline()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("SELECT ad.Airline_Detail_ID,(am.Airline_Name+'-'+cm.City_Code) AS FlightName  FROM dbo.Airline_Detail ad INNER JOIN dbo.Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN dbo.City_Master cm ON ad.Belongs_To_City=cm.City_ID WHERE ad.Airline_Detail_ID IN (" + Session["AIRLINEACCESS"].ToString() + ") order by am.Airline_Name", con);
            //com = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID  order by airline_name", con);
            dr = com.ExecuteReader();
            ddl_airline_city.Items.Clear();
            ddl_airline_city.Items.Insert(0, "- -Select- -");
            ddl_airline_city.Items[0].Value = "0";
            //ddl_airline_city.Items.Add(new ListItem("Select Airline Name"));
            while (dr.Read())
            {
                ddl_airline_city.Items.Add(new ListItem(dr["FlightName"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            com.Dispose();
        }
        catch (Exception eror)
        {
            string st = eror.ToString();
        }
        finally
        {
            con.Close();
            com.Dispose();
        }
    }

    //protected void ShowAirline()
    //{

    //    ddl_airline_city.Items.Clear();
    //    con = new SqlConnection(strCon);
    //    con.Open();
    //    try
    //    {
    //        com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'('+A.Airline_Code+')/'+B.city_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
    //        SqlDataReader dr = com.ExecuteReader();
    //        ddl_airline_city.Items.Add("Select Airline");
    //        ddl_airline_city.Items[0].Value = "0";
    //        while (dr.Read())
    //        {
    //            ddl_airline_city.Items.Add(new ListItem(dr["airline"].ToString(), Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"])));

    //        }

    //    }
    //    catch (SqlException ex)
    //    {
    //        string strer = ex.ToString();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }

    //}

    protected void Btnload_Click(object sender, EventArgs e)
    {
        string todate=string.Empty;
        String strawbid = string.Empty;
        if (IsValid)
        {
            Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
            Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
            strawbid = Request.QueryString["AWBID"]; 
            //if (TextBox1.Text != "")
            //{
            //    Session["from_date"] = TextBox1.Text;
            //   // Session["Invoive_No"] = txtInvoice.Text;
            //    string[] date = TextBox1.Text.Split('/');
            //    string dd = date[0].ToString();
            //    string MM = date[1].ToString();
            //    string YY = date[2].ToString();
            //    todate = MM + "/" + dd + "/" + YY;  
            //}
            //else 
            //{
            //    Session["from_date"] = txtValidFrom.Text;
            //    Session["to_date"] = txtValidTo.Text;
            //    //Session["Invoive_No"] = txtInvoice.Text;
            //    string[] date = txtValidTo.Text.Split('/');
            //    string dd = date[0].ToString();
            //    string MM = date[1].ToString();
            //    string YY = date[2].ToString();
            //    todate = MM + "/" + dd + "/" + YY;
            //}
            //if (Convert.ToDateTime(todate) <= Convert.ToDateTime("06/30/2017"))
            //    //ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/ViewMainefestDetails.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&FromDate=" + txtValidFrom.Text + "&ToDate=" + txtValidTo.Text + "');</script>");
            //    //ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open('Do_Cancel_Gst.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&FromDate=" + txtValidFrom.Text + "&InvoiveNo=" + "MH-MUM/11-12/" + txtInvoice.Text + "&ToDate=" + txtValidTo.Text + "');</script>");
            //    ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open('DO_Print_Gst_updated.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&AWBID=" + strawbid.ToString() + "');</script>");
            //else
            //    //bY JJ
            //    //ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/ViewmanifestDetails_Gst.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&FromDate=" + txtValidFrom.Text + "&ToDate=" + txtValidTo.Text + "');</script>");
            //    //ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/ViewMainefestDetails.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&FromDate=" + txtValidFrom.Text + "&ToDate=" + txtValidTo.Text + "');</script>");
            //    //ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open('Do_Cancel_Gst.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&FromDate=" + txtValidFrom.Text + "&InvoiveNo=" + "MH-MUM/11-12/" + txtInvoice.Text + "&ToDate=" + txtValidTo.Text + "');</script>");
            //    ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open('DO_Print_Gst_updated.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&AWBID=" + strawbid.ToString() + "');</script>");
            //ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open('DO_Print_Gst2.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&AWBID=" + strawbid.ToString() + "');</script>");
            ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open('DO_Print_Gst_updated.aspx?airline_id=" + ddl_airline_city.SelectedItem.Value + "&AWBID=" + strawbid.ToString() + "');</script>");
        }
    }

    //protected void chkdate_CheckedChanged(object sender, EventArgs e)
    //{
    //    updatecheck.Update();
    //    if (chkdate.Checked == true)
    //    {            
    //        TextBox1.Visible = true;
    //    }
    //    else
    //    {
    //        TextBox1.Visible = false;     
    //    }
    //}
}
