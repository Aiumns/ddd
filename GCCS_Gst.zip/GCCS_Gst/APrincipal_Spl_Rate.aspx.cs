using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class APrincipal_Spl_Rate : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adp;
    SqlDataReader dr;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
      string tt;
      if (!Page.IsPostBack)
      {
          TextBox3.Text = Request.QueryString["awb"];
          TextBox2.Text = Request.QueryString["remark"];
          TextBox1.Text = Request.QueryString["Net_Rate"];
      }
       //tt = Convert.ToString(TextBox2.Text).Trim();
    }
    protected void ADD_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand("UPDATE Sales SET Principle_Spot_Rate = '" + TextBox1.Text + "', Principle_Spot_Rate_Remarks = '" + TextBox2.Text + "' WHERE AirwayBill_No='" + TextBox3.Text + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("Record is UpDated");
        Response.Redirect("Principle_Malaysia_Report.aspx");
    }
}
