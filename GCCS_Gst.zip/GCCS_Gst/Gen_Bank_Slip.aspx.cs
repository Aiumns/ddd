using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Created By Megha Goel On Dated 29 Dec 2008
/// </summary>
/// 
public partial class Gen_Bank_Slip : System.Web.UI.Page
{

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
          lblMessage.Visible = false;
          if (Session["EmailID"] == null)
          {
              Response.Redirect("Login.aspx");
          }
          else
          {
              if (!IsPostBack)
              {
                  DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
                  hdnDate.Value = first.ToString();
                  btnShow.Attributes.Add("onclick", "return CheckEmpty_ddl();");
                  DateTime dtDate = DateTime.Now.Date;
                  string str = Convert.ToString(dtDate.ToShortDateString());
                  txtDate.Text = FormatDateMM(str);
                  AccountNamePlusNo();

              }
          }
    }

    //FUNCTION TO CONVERT THE DATE IN DD/MM YYYY FORMAT
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    // FUNCTION FOR GETTING [ACCOUNT NAME-ACCOUNT NO.] OF ALL AIRLINE AND RELATED COMPANIES

    #region Display Account Name-Account No. 

    public void AccountNamePlusNo()
    {
        try
        {
            string strQuery = "";
            string Airline_Access = Session["AIRLINEACCESS"].ToString();
            ddlAccountName.Items.Clear();

            strQuery = "SELECT ab.Airline_Detail_ID,ab.Acc_Name,ab.Acc_No,CONVERT(VARCHAR,ab.ValidFrom,103) AS ValidFrom,CONVERT(VARCHAR,ab.ValidTo,103) AS ValidTo ,(AIRLINE_NAME+'/ '+CITY_NAME) AS AIRLINE_NAME FROM db_owner.Airline_Bank_Details ab INNER JOIN dbo.Airline_Detail ad ON ab.Airline_Detail_ID = ad.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM ON AM.AIRLINE_ID=AD.AIRLINE_ID INNER JOIN CITY_MASTER CM ON AD.Belongs_To_City=CM.CITY_ID  where ab.Airline_Detail_ID in" + "(" + Airline_Access + ") AND ab.Acc_Name<>'' order by  ab.Acc_Name";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlAccountName.Items.Insert(0, "Select AccountName");
            //ddlAccountName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAccountName.Items.Add(new ListItem(dr["Acc_Name"].ToString() + "-" + dr["Acc_No"].ToString() + "-" + dr["AIRLINE_NAME"].ToString() + "-(" + dr["ValidFrom"] + "-" + dr["ValidTo"] + ")", dr["Airline_Detail_ID"].ToString() + "-" + "A_Acc"));

            }
           
            com.Dispose();
            dr.Dispose();

            strQuery = "SELECT DISTINCT B.Acc_Name,B.Acc_No,B.Company_ID FROM Airline_Detail A INNER JOIN Company_Master B ON A.Company_ID=B.Company_ID where Airline_detail_id in" + "(" + Airline_Access + ") AND B.Acc_Name<>'' order by  B.Acc_Name";

            com = new SqlCommand(strQuery, con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {


                ddlAccountName.Items.Add(new ListItem(dr["Acc_Name"] + "-" + dr["Acc_No"], dr["Company_ID"].ToString() + "-" + "C_Acc"));

            }
            dr.Close();
            con.Close();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
   
    #endregion 
    protected void btnShow_Click(object sender, EventArgs e)
    {
        string C_Date=(txtDate.Text);
        if (ddlAccountName.SelectedValue != "")
        {
            string Acc_Name = ddlAccountName.SelectedItem.Text;

            string[] Arr_Acc = Acc_Name.Split('-');
            string Account_Name = Arr_Acc[0];
            string Acc_No = Arr_Acc[1];
            string Airline = ddlAccountName.SelectedValue;
            string[] Arr_ID = Airline.Split('-');
            string Airline_Detail_ID = Arr_ID[0];
            string Acc_Type = Arr_ID[1];
            string check_type = RadioButtonList1.SelectedValue;


            string Url_ = "Bank_Slip_Details.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("AId", Airline_Detail_ID), new Pair("Acc_Type", Acc_Type), new Pair("C_Date", C_Date), new Pair("check_type", check_type));
            //REDIRECT THE PAGE IN NEW WINDOW
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open('" + Url_ + "');</script>");
        }
        else
        {
            lblMessage.Visible = true;
            lblMessage.Text = "No Account Exist";
        }
      
           

        //btnShow.Attributes.Add("onclick", "javascript:window.open('Bank_Slip_Details.aspx?DATA=' + ParamUtils.WebParam.Encode(new Pair('AId', Airline_Detail_ID), new Pair('Acc_Type', Acc_Type), new Pair('C_Date', C_Date), new Pair('check_type', check_type)); return false;");
        //Response.Redirect("Bank_Slip.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("AId", Airline_Detail_ID)));
        //Response.Redirect("Bank_Slip_Details.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("AId", Airline_Detail_ID), new Pair("Acc_Type", Acc_Type), new Pair("C_Date", C_Date), new Pair("check_type", check_type)));


        
    }
}
