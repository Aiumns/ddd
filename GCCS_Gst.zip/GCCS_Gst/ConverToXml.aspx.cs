using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Xml.Schema;
//using System.Xml.Linq;
public partial class ConverToXml : System.Web.UI.Page
{    
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    decimal TotDr = 0;
    decimal TotCr = 0;
    bool flag = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        //txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy"); 
       
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {               
                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 1;
                ddlMonth.Items[dt - 1].Selected = true;
                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();
                ShowAirline();
            }
        }
    }

    protected void ShowAirline()
    {
        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID,A.airline_code from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select airline name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            com.Dispose();
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public bool GetError()
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("select * from csr_details where csr_from='" + Session["From_Tally"] + "' and csr_to='" + Session["To_Tally"] + "' and airline_detail_id=" + Session["Airline_Detail_id_Tally"] + " order by agent_name", con);
        dr = com.ExecuteReader();
        DataTable dt = new DataTable();
        dt.Load(dr);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
              //  count++;
               // html += @"<tr style='font-size: smaller;font-family: inherit;'><td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>" + count + "</td><td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>" + dt.Rows[i]["CSR_No"].ToString() + "</td><td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>" + dt.Rows[i]["Agent_Name"].ToString() + "</td><td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>" + dt.Rows[i]["Amount_Including_TDS"].ToString() + "</td></tr>";
                //Details Row
                string Frgt_Amount = Convert.ToString(decimal.Parse(dt.Rows[i]["Freight_Amount"].ToString()) + decimal.Parse(dt.Rows[i]["Total_DueCarrier"].ToString()));
                decimal DiscountonNfreight = 0;
                DiscountonNfreight = decimal.Parse(dt.Rows[i]["Incentive_Amount"].ToString());             
                TotDr = decimal.Parse(dt.Rows[i]["Amount_Including_TDS"].ToString()) + DiscountonNfreight;
                TotCr = decimal.Parse(dt.Rows[i]["CGSTAmt"].ToString()) + decimal.Parse(dt.Rows[i]["SGSTAmt"].ToString()) + decimal.Parse(dt.Rows[i]["IGSTAmt"].ToString()) + decimal.Parse(Frgt_Amount.ToString());
                if (TotCr != TotDr)
                {
                    flag = true; 
                }               
            }           
            dr.Dispose();
            com.Dispose();
            con.Close();
        }
        return flag;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        #region  Button Click Event
        string Date_Xml = txtValidTo.Text; ;
        string[] dat = Date_Xml.Split('/');
        Date_Xml = dat[2] + dat[1] + dat[0];
        //****Picking Login Name****
        string LoginEmail_id = Session["EMailID"].ToString();
        string Login_name = "";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("SELECT u.full_name from user_master u inner join login_master l ON u.email=l.Email_ID where l.Email_id='" + LoginEmail_id + "'", con);
        dr = com.ExecuteReader();
        if (dr.Read())
        {
            Login_name = dr["full_name"].ToString();
        }
        dr.Dispose();
        com.Dispose();
        //*********End*********
        string[] airlineName = ddlAirLine.SelectedItem.Text.Split('-');
        string airline = "A/C " + airlineName[0].ToUpper().ToString();
      
        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();

        //string strY = DateTime.Today.Year.ToString();
        string strY = ddlyear.SelectedItem.Text.Trim();

        if (rbtnFirstFortn.Checked == true)
        {
            #region IF CONDITION
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
            #endregion
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            #region else if  condition
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }
            #endregion
        }

        Session["Airline_Detail_id_Tally"] = ddlAirLine.SelectedValue.Trim();

        Session["From_Tally"] = ConvertDate2(TextBox1.Text);

        Session["To_Tally"] = ConvertDate2(TextBox2.Text);

        Session["Date_Xml"]  = txtValidTo.Text; 

        if (ddlchoooseView.SelectedItem.Text == "Voucher")
        {
            string url = "Tally_Csr.aspx";
            // Response.Redirect("Tally_Csr.aspx");
            if (ddlAirLine.SelectedValue.Trim() == "158" || ddlAirLine.SelectedValue.Trim() == "159" || ddlAirLine.SelectedValue.Trim() == "160")
            {
               url = "Tally_KECsr.aspx";
            }
            
            StringBuilder sb = new StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.open('");
            sb.Append(url);
            sb.Append("');");
            sb.Append("</script>");
            ClientScript.RegisterStartupScript(this.GetType(),"script", sb.ToString());
        }
        else if (ddlchoooseView.SelectedItem.Text == "XML") //This is current active condition with CsrXml.aspx Page
        {
            string url = "CsrXml.aspx";
            StringBuilder sb = new StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.open('");
            sb.Append(url);
            sb.Append("');");
            sb.Append("</script>");
            ClientScript.RegisterStartupScript(this.GetType(),"script", sb.ToString());
        }
        else if (ddlchoooseView.SelectedItem.Text == "XML1")  // && GetError() != true
        {
            #region
            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                //********Picking Company Name*****************
                string Company_Name = "";
                com = new SqlCommand("SELECT csr.agent_name,c.company_name,ad.tally_company_name,u.full_name  FROM dbo.CSR_Details csr INNER JOIN dbo.Airline_Detail ad ON csr.Airline_Detail_ID=ad.Airline_Detail_ID INNER JOIN db_owner.Company_Master c ON c.Company_ID=ad.Company_ID INNER JOIN dbo.User_Master u ON u.email=csr.Entered_By  WHERE csr.Airline_Detail_ID=" + ddlAirLine.SelectedValue.Trim() + " and csr.csr_from='" + ConvertDate2(TextBox1.Text) + "' and csr.csr_to='" + ConvertDate2(TextBox2.Text) + "'", con);
                dr = com.ExecuteReader();
                if (dr.Read())
                {
                    Company_Name = dr["tally_company_name"].ToString();
                }
                dr.Dispose();
                com.Dispose();
                //*************End****
                //*********** XML Generation*********************
                string xmlString;
                StringWriter sw = new StringWriter();
                XmlTextWriter xw = new XmlTextWriter(sw);
                //XmlWriterSettings setting = new XmlWriterSettings();
                //setting.Indent = true;
                //setting.IndentChars = ("\t\t\t\t\t\t\t\t\t\t");
                //setting.OmitXmlDeclaration = true;
                //xw.Formatting = Formatting.Indented;
                xw.Formatting = Formatting.Indented;
                xw.WriteStartDocument();

                //************Static Xml Start******************                
                xw.WriteStartElement("ENVELOPE");  //ENVELOPE Starts
                xw.WriteStartElement("HEADER");    //HEADER Starts
                xw.WriteElementString("TALLYREQUEST", "Import Data");
                xw.WriteEndElement();                
                //***********Header Ends****************
                xw.WriteStartElement("BODY");   //Body Starts
                xw.WriteStartElement("IMPORTDATA");   //DATA Starts
                xw.WriteStartElement("REQUESTDESC");
                xw.WriteElementString("REPORTNAME", "All Masters");
                xw.WriteStartElement("STATICVARIABLES");
                xw.WriteElementString("SVCURRENTCOMPANY",Company_Name);
                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.WriteStartElement("REQUESTDATA");
                //**********Static Xml End***************

                com = new SqlCommand("SELECT csr.*,c.company_name,u.full_name  FROM dbo.CSR_Details csr INNER JOIN dbo.Airline_Detail ad ON csr.Airline_Detail_ID=ad.Airline_Detail_ID INNER JOIN db_owner.Company_Master c ON c.Company_ID=ad.Company_ID INNER JOIN dbo.User_Master u ON u.email=csr.Entered_By WHERE csr.Airline_Detail_ID=" + ddlAirLine.SelectedValue.Trim() + " and csr.csr_from='" + ConvertDate2(TextBox1.Text) + "' and csr.csr_to='" + ConvertDate2(TextBox2.Text) + "'", con);

                SqlDataAdapter da1 = new SqlDataAdapter(com);
                con.Close();
                DataTable dtXml = new DataTable("Table");

                da1.Fill(dtXml);
                if (dtXml.Rows.Count > 0)
                {
                   #region
                    int countId = 100048;
                    for (int i = 0; i < dtXml.Rows.Count; i++)
                    {
                      #region

                        #region
                        string datefrom = dtXml.Rows[i]["csr_from"].ToString();
                        string dateTo = dtXml.Rows[i]["csr_to"].ToString();
                        string[] df = datefrom.Split(' ');
                        DateTime df1 = Convert.ToDateTime(df[0].ToString());
                        datefrom = df1.ToString("dd-MMM-yyyy");

                        string[] dto = dateTo.Split(' ');
                        DateTime df2 = Convert.ToDateTime(dto[0].ToString());
                        dateTo = df2.ToString("dd-MMM-yyyy");

                        string fdate = df1.ToString("dd-MM-yy").Replace("-", "");
                        string todate = df2.ToString("dd-MM-yy").Replace("-", "");
                        string Narration = "CSR for the period " + datefrom + " - " + datefrom;

                        //string Narration = "CSR for the period " + dtXml.Rows[i]["csr_from"].ToString()  + "-" + dtXml.Rows[i]["csr_to"].ToString() ;
                        string Agent_name = dtXml.Rows[i]["Agent_name"].ToString();
                        string From_Date1 = TextBox1.Text;
                        string From_Date = Date_Xml;
                        string Effective_date = Date_Xml;
                        string[] frm_date = From_Date1.Split('/');
                        From_Date1 = frm_date[2] + frm_date[0] + frm_date[1];
                        string VchNo = dtXml.Rows[i]["csr_detail_id"].ToString();
                        DataTable DtAirCode = dw.GetAllFromQuery("Select Airline_Text_Code from Airline_Master am inner join Airline_detail ad on Am.Airline_ID=ad.airline_id where ad.Airline_detail_id=" + ddlAirLine.SelectedValue);
                        VchNo = DtAirCode.Rows[0]["Airline_Text_Code"].ToString() + "/" + dtXml.Rows[i]["csr_detail_id"].ToString() + "/" + fdate + "-" + todate;
                        string entered_by = dtXml.Rows[i]["entered_by"].ToString();
                        // string entered_byName = dtXml.Rows[i]["Full_Name"].ToString();
                        string entered_byName = Login_name;
                        string Effective_date1 = TextBox1.Text;
                        string[] Eff_date = Effective_date1.Split('/');
                        Effective_date1 = Eff_date[2] + Eff_date[0] + Eff_date[1];
                        string Amount = dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                        string Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                        string Discount = dtXml.Rows[i]["Incentive_Amount"].ToString();
                        string Tds_Amount = dtXml.Rows[i]["Tds_Amount"].ToString();
                        string Frgt_Amount = dtXml.Rows[i]["Freight_Amount"].ToString();

                        string CGST_AMT = dtXml.Rows[0]["CGSTAmt"].ToString();
                        string SGST_AMT = dtXml.Rows[0]["SGSTAmt"].ToString();
                        string IGST_AMT = dtXml.Rows[0]["IGSTAmt"].ToString();

                        string name = dtXml.Rows[i]["csr_no"].ToString();
                        string Curr_id = string.Empty;
                        decimal DiscountonNfreight = 0;
                        DiscountonNfreight = decimal.Parse(dtXml.Rows[i]["Incentive_Amount"].ToString()) + decimal.Parse(dtXml.Rows[i]["Freight_Amount"].ToString());
                        Frgt_Amount = DiscountonNfreight.ToString();

                        string VchType = "";
                        string Bill_type = "";
                        decimal tot_cr = 0;
                        decimal tot_dr = 0;
                        string Curr_id1 = "";
                        string Agent_expenses = "";
                        //Condition

                        ////decimal Curr_Frght_Amt = decimal.Parse(dtXml.Rows[i]["Freight_Amount_PP"].ToString()) + decimal.Parse(dtXml.Rows[i]["Total_DueCarrier"].ToString()) - decimal.Parse(dtXml.Rows[i]["Incentive_Amount"].ToString());
                        decimal Curr_Frght_Amt = decimal.Parse(dtXml.Rows[i]["Freight_Amount_PP"].ToString()) + decimal.Parse(dtXml.Rows[i]["Total_DueCarrier"].ToString());
                        ////decimal Curr_Frght_Amt = DiscountonNfreight;

                        if (Curr_Frght_Amt > 0)
                        {
                            Curr_id1 = "CR";
                        }
                        else
                        {
                            Curr_id1 = "DR";
                        }

                        #endregion

                        #region
                                if (decimal.Parse(dtXml.Rows[i]["Amount_Including_Tds"].ToString()) > 0)
                                {
                                    if (dtXml.Rows[i]["Sales_Type"].ToString() == "INV")
                                    {
                                        VchType = "Sales";
                                        Bill_type = "CSR from" + datefrom + " - " + dateTo;
                                        Narration = "CSR for the period " + datefrom + " - " + dateTo;
                                    }
                                    else
                                    {
                                        VchType = "Debite Note";
                                        Bill_type = "Debit Note from" + datefrom + " - " + dateTo;
                                        Narration = "Debit Note for the period " + datefrom + " - " + dateTo;
                                    }
                                }
                                else
                                {
                                    VchType = "Credit Note";
                                    Bill_type = "Credit Note" + datefrom + " - " + dateTo;
                                    Narration = "Credit Note for the period " + datefrom + " - " + dateTo;
                                }
                               if (decimal.Parse(dtXml.Rows[i]["Amount_Including_Tds"].ToString()) > 0)
                                {
                                    #region
                            Curr_id = "DR";
                            tot_dr = tot_dr + Math.Round(decimal.Parse(dtXml.Rows[i]["Amount_Including_Tds"].ToString()), 2);
                            Amount = "-" + dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                            if (Curr_id1 == "CR")
                            {
                                Frgt_Amount = Curr_Frght_Amt.ToString();
                            }
                            else
                            {
                                string FrTAmt = "-" + Curr_Frght_Amt.ToString();   //-case
                            }
                            ////Iata_Amount = "-" + dtXml.Rows[i]["Iata_Commission"].ToString();
                            ////Discount = "-" + dtXml.Rows[i]["Incentive_Amount"].ToString();

                            string AIata_Amount = "-" + dtXml.Rows[i]["Iata_Commission"].ToString();   //-case
                            string ADiscount = "-" + dtXml.Rows[i]["Incentive_Amount"].ToString();    //-case
                            if (Curr_id1 == "CR")
                            {
                                tot_cr = tot_cr + Math.Round(Curr_Frght_Amt, 2);
                                //Amount = "-"+dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                                //Frgt_Amount = "-" + Curr_Frght_Amt.ToString();
                                //Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                            }
                            else
                            {
                                tot_dr = tot_dr + Math.Round(Curr_Frght_Amt, 2);
                            }

                            tot_dr = tot_dr + Math.Round(decimal.Parse(dtXml.Rows[i]["IATA_Commission"].ToString()), 2);
                            #endregion
                                }
                               else
                                {
                                    #region
                                        tot_dr = tot_dr + Math.Round(decimal.Parse(dtXml.Rows[i]["IATA_Commission"].ToString()), 2);
                                        //Iata_Amount = "-" + dtXml.Rows[i]["Iata_Commission"].ToString();
                                        Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                                        Discount = dtXml.Rows[i]["Incentive_Amount"].ToString();
                                        Curr_id = "CR";
                                        if (Curr_id1 == "CR")
                                        {
                                            tot_cr = tot_cr + Math.Round(Curr_Frght_Amt, 2);
                                            //Amount = "-" + dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                                            Frgt_Amount = Curr_Frght_Amt.ToString();
                                            //Iata_Amount = dtXml.Rows[i]["Iata_Commission"].ToString();
                                        }
                                        else
                                        {
                                            //////Frgt_Amount = "-" + Curr_Frght_Amt.ToString(); //-case
                                            tot_dr = tot_dr + Math.Round(Curr_Frght_Amt, 2);
                                        }
                                        if (Curr_id == "CR")
                                        {
                                            //////Amount = "-" + dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                                            Amount = dtXml.Rows[i]["Amount_Including_Tds"].ToString(); /// - case

                                        }
                                        else
                                        {
                                            Amount = dtXml.Rows[i]["Amount_Including_Tds"].ToString();
                                        }
                                        tot_cr = tot_cr + Math.Round(decimal.Parse(dtXml.Rows[i]["Amount_Including_Tds"].ToString()), 2);
                                    #endregion
                                }

                                ////Agent Expense
                                //if (decimal.Parse(dtXml.Rows[i]["Agent_Expenses"].ToString()) > 0)
                                //{
                                //    Agent_expenses = "-" + dtXml.Rows[i]["Agent_Expenses"].ToString();
                                //    tot_dr = tot_dr + Math.Round(decimal.Parse(dtXml.Rows[i]["Agent_Expenses"].ToString()), 2);
                                //}
                                ////end of Agent Expense
                                // Tds_Amount

                            if (decimal.Parse(Tds_Amount) > 0)
                            {
                                ////////Tds_Amount = dtXml.Rows[i]["Tds_Amount"].ToString();
                                tot_cr = tot_cr + Math.Round(decimal.Parse(dtXml.Rows[i]["Tds_Amount"].ToString()), 2);
                            }
                            else
                            {
                                //////Tds_Amount = "-" + dtXml.Rows[i]["Tds_Amount"].ToString();
                                tot_dr = tot_dr + Math.Round(decimal.Parse(dtXml.Rows[i]["Tds_Amount"].ToString()), 2);
                            }
                           #endregion

                        //End of Tds_Amount

                        //Condition End

                        // start loop
                       #region

                        xw.WriteStartElement("TALLYMESSAGE", "TallyUDF");
                        xw.WriteStartElement("VOUCHER");
                        xw.WriteStartAttribute("REMOTEID", "e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60");
                        //xw.WriteStartAttribute("REMOTEID","");
                        xw.WriteStartAttribute("VCHTYPE", VchType);
                        xw.WriteStartAttribute("ACTION", "Create");
                        xw.WriteEndAttribute();
                       
                        xw.WriteElementString("DATE", From_Date);
                        //xw.WriteElementString("GUID", "e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60");
                        xw.WriteElementString("GUID", "");
                        xw.WriteElementString("NARRATION", Narration);
                        //xw.WriteElementString("VOUCHERTYPENAME","Sales");

                        if (VchType == "Credit Note")
                        {
                            xw.WriteElementString("VOUCHERTYPENAME", "Credit");
                        }
                        else
                        {
                            xw.WriteElementString("VOUCHERTYPENAME", "Sales");
                        }
                        #region

                        xw.WriteElementString("VOUCHERNUMBER",VchNo);
                        xw.WriteElementString("PARTYLEDGERNAME",Agent_name);
                        xw.WriteElementString("CSTFORMISSUETYPE","");
                        xw.WriteElementString("CSTFORMRECVTYPE ","");
                        xw.WriteElementString("FBTPAYMENTTYPE","Default");
                        xw.WriteElementString("VCHGSTCLASS","");
                        xw.WriteElementString("ENTEREDBY","Rawat");
                        xw.WriteElementString("DIFFACTUALQTY","No");

                        xw.WriteElementString("AUDITED","No");
                        xw.WriteElementString("FORJOBCOSTING","No");
                        xw.WriteElementString("ISOPTIONAL","No");

                        xw.WriteElementString("EFFECTIVEDATE", Effective_date);

                        xw.WriteElementString("USEFORINTEREST", "No");
                        xw.WriteElementString("USEFORGAINLOSS", "No");
                        xw.WriteElementString("USEFORGODOWNTRANSFER","No");

                        xw.WriteElementString("USEFORCOMPOUND", "No");
                        string AuditId = Convert.ToString(countId);
                        xw.WriteElementString("ALTERID", "");
                        countId++;
                        xw.WriteElementString("EXCISEOPENING", "No");

                        xw.WriteElementString("ISCANCELLED", "No");

                        xw.WriteElementString("HASCASHFLOW", "No");
                        xw.WriteElementString("ISPOSTDATED", "No");
                        xw.WriteElementString("USETRACKINGNUMBER", "No");

                        xw.WriteElementString("ISINVOICE", "No");

                        xw.WriteElementString("MFGJOURNAL", "No");

                        xw.WriteElementString("HASDISCOUNTS", "No");

                        xw.WriteElementString("ASPAYSLIP", "No");

                        xw.WriteElementString("ISDELETED", "No");
                        //xw.WriteEndElement();
                        xw.WriteElementString("ASORIGINAL", "Yes");
                        //xw.WriteEndElement();

                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", Agent_name);

                        xw.WriteElementString("GSTCLASS", "");

                        xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");

                        xw.WriteElementString("LEDGERFROMITEM", "No");

                        xw.WriteElementString("REMOVEZEROENTRIES", "No");

                        xw.WriteElementString("ISPARTYLEDGER", "Yes");

                        xw.WriteElementString("AMOUNT", Amount);

                        xw.WriteStartElement("BILLALLOCATIONS.LIST");
                        xw.WriteElementString("NAME", name);

                        xw.WriteElementString("BILLCREDITPERIOD", "30 days");

                        xw.WriteElementString("BILLTYPE", "New Ref");

                        xw.WriteElementString("AMOUNT", Amount);

                        xw.WriteEndElement();
                        xw.WriteEndElement();

                        ////**IATA Commssion*****
                        //xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        //xw.WriteElementString("LEDGERNAME", "IATA Commission");
                        //xw.WriteElementString("GSTCLASS ", "");
                        //xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        //xw.WriteElementString("LEDGERFROMITEM", "No");
                        //xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        //xw.WriteElementString("ISPARTYLEDGER", "No");
                        //xw.WriteElementString("AMOUNT", Iata_Amount);
                        //xw.WriteEndElement();

                        #endregion

                        //*******Agent Expense************
                        if (decimal.Parse(dtXml.Rows[i]["Agent_Expenses"].ToString()) > 0)
                        {
                            Agent_expenses = "-" + dtXml.Rows[i]["Agent_Expenses"].ToString();
                            tot_dr = tot_dr + Math.Round(decimal.Parse(dtXml.Rows[i]["Agent_Expenses"].ToString()), 2);
                            //**Agent Expense*****
                            xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                            xw.WriteElementString("LEDGERNAME", "AGENT Expenses");
                            xw.WriteElementString("GSTCLASS ", "");
                            xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                            xw.WriteElementString("LEDGERFROMITEM", "No");
                            xw.WriteElementString("REMOVEZEROENTRIES", "No");
                            xw.WriteElementString("ISPARTYLEDGER", "No");
                            xw.WriteElementString("AMOUNT", Agent_expenses);
                            xw.WriteEndElement();
                        }
                        //end of Agent Expense

                        #region
                        //**FREIGHT A/C*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "FREIGHT A/C");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", Frgt_Amount);
                        xw.WriteEndElement();

                        //**IATA Commssion*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "IATA COMMISSION");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", Iata_Amount);
                        xw.WriteEndElement();

                        //**Tds Commission*****

                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "TDS - COMMISSION");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", Tds_Amount);
                        xw.WriteEndElement();

                        //**Discount*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "DISCOUNT on Freight");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "Yes");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", Discount);
                        xw.WriteEndElement();

                        //**CGST*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "CGST-T4-100%Credit");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "No");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", CGST_AMT);
                        xw.WriteEndElement();

                        //**SGST*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "SGST-T4-100%Credit");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "No");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", SGST_AMT);
                        xw.WriteEndElement();

                        //**IGST*****
                        xw.WriteStartElement("ALLLEDGERENTRIES.LIST");
                        xw.WriteElementString("LEDGERNAME", "IGST-T4-100%Credit");
                        xw.WriteElementString("GSTCLASS ", "");
                        xw.WriteElementString("ISDEEMEDPOSITIVE", "No");
                        xw.WriteElementString("LEDGERFROMITEM", "No");
                        xw.WriteElementString("REMOVEZEROENTRIES", "No");
                        xw.WriteElementString("ISPARTYLEDGER", "No");
                        xw.WriteElementString("AMOUNT", IGST_AMT);
                        xw.WriteEndElement();
                        #endregion

                        //In Last
                        xw.WriteEndElement();
                        xw.WriteEndElement();
                             #endregion
                           //End loop
                        #endregion                      
                    }
                   #endregion
                }
                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.Close();
                xmlString = sw.ToString();

                xmlString = xmlString.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "");
                //xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Sales\" xmlns:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER REMOTEID=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\" VCHTYPE=\"Sales\" ACTION=\"Create\">");
                xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Sales\" xmlns:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER REMOTEID=\"\" VCHTYPE=\"Sales\" ACTION=\"Create\">");
                //xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Credit Note\" xmlns:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:d6p3=\"Create\" xmlns:d6p2=\"Credit Note\" xmlns:d6p1=\"\">");
                xmlString = xmlString.Replace("xmlns", "xmlns:UDF");
                xmlString = xmlString.Replace("<VOUCHER d6p1:REMOTEID=\"\" d6p2:VCHTYPE=\"\" d6p3:ACTION=\"\" xmlns:UDF:d6p3=\"Create\" xmlns:UDF:d6p2=\"Credit Note\" xmlns:UDF:d6p1=\"e3d6ca40-f822-11d7-83e7-000cf16dc851-0000eb60\">", "<VOUCHER REMOTEID=\"\" VCHTYPE=\"Credit Note\" ACTION=\"Create\">");
                Session["xml"] = xmlString;

                ////**** Opening in New Window*****
                //ScriptManager.RegisterStartupScript(this, GetType(), "key", "window.open('xml.aspx','_blank','location=0,toolbar=0,titlebar=0,menubar=0,resizable=1,scrollbars=1,status=1');", true);

                //**** End *****

                //////*********Opening and saving File with Pop-Up
                XmlDataDocument empDoc = new XmlDataDocument();
                Response.ContentType = "text/xml";
                Response.AppendHeader("Content-Disposition", "attachment; filename=Gccs.xml");
                Response.Write(xmlString);
                Response.End();
                //***End**
                //string q=sw.Close;
                // fs.Close();
            }
            catch (SqlException sqe)
            {
                string err = sqe.ToString();
            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            #endregion
        }
        else
        {
            //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForActCust", "Plz Check.......", true);
            Page.ClientScript.RegisterStartupScript(GetType(), "msgbox1", "alert('Error (Amount not matched)...pls check..');", true);
        }
        #endregion
    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    protected string ConvertDate2(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }

    //protected void ddlchoooseView_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //   Response.Redirect("Tally_CSR.aspx");
    //}
}
