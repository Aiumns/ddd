using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Flight_Add_New : System.Web.UI.Page
{
    string gvUniqueID = String.Empty;
    int gvNewPageIndex = 0;
    int gvEditIndex = -1;
    string gvSortExpr = String.Empty;
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataSet ds;
    DisplayWrap dw = new DisplayWrap();
    string strCon=ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Ajax.Utility.RegisterTypeForAjax(typeof(Flight_Add_New));  
        lblmsg.Visible = false;
        if (!IsPostBack)
        {
            ddlStatus.SelectedValue = "2";
            AirlineNamePlusCode();
            ////FillddlStatus();
            Session["dthold"] = maketable();
            Session["day"] = maketableday();

            GridView2.DataSource = (DataTable)Session["dthold"];
            GridView2.DataBind();

            GridView1.DataSource = (DataTable)Session["day"];
            GridView1.DataBind();

            Gv_DailyWise.DataSource = (DataTable)Session["day"];
            Gv_DailyWise.DataBind();

            if (Request.QueryString["FlightID"] == null)
            {                
                //FillddlStatus();
                //Session["dthold"] = maketable();
                //Session["day"] = maketableday();
                //GridView2.DataSource = (DataTable)Session["dthold"];
                //GridView2.DataBind();
                //GridView1.DataSource = (DataTable)Session["day"];
                //GridView1.DataBind();
                Gv_DailyWise.ShowFooter = true;
                rb.SelectedValue = "FREIGHTER";
                rb1.SelectedValue = "DATEWISE";
                if (rb1.SelectedValue == "DATEWISE")
                {
                    datetd.Visible = true;
                    daytd.Visible = false;
                    dailytd.Visible = false;
                    lblschedule.Text = "DATE WISE";
                }
                if (rb1.SelectedValue == "DAYWISE")
                {
                    datetd.Visible = false;
                    daytd.Visible = true;
                    dailytd.Visible = false;
                    lblschedule.Text = "DAY WISE";
                }
                if (rb1.SelectedValue == "DAILY")
                {
                    datetd.Visible = false;
                    daytd.Visible = false;
                    dailytd.Visible = true;
                    lblschedule.Text = "DAILY";  
                }
            }
            //GridViewRow gv = GridView2.Rows[0];
            //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
            //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;
            //GridViewRow gv1 = GridView1.Rows[0];
            //((LinkButton)(gv1.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
            //((LinkButton)(gv1.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;
            if (Request.QueryString["FlightID"] != null)
            {
                lblHead.Text = "Edit Flight Schedule";
                btnUpdate.Text = "Update";
                btnAdd.Visible = false;
                btnReset.Visible = false;
                Gv_DailyWise.ShowFooter = false;
                FillData();
            }
            else
            {
                lblHead.Text = "Add New Flight Schedule";
                btnAdd.Text = "Add";
                btnUpdate.Visible = false;
                Gv_DailyWise.ShowFooter = true;
            }
        }
    }
    public string Rights()
    {

         string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString()+"'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
       
        dr.Dispose();
        cmd.Dispose();
        con.Close();
        return Access;
    }
    public void FillData()
    {
        con = new SqlConnection(strCon);
        con.Open();
        //try
        //{
       // rb1.AutoPostBack = false;
        if (Request.QueryString["FlightID"] != null)
        {
            string FlightID = Convert.ToString(Request.QueryString["FlightID"]);
            //DataTable dtAirlineID = dw.GetAllFromQuery("select Airline_ID from Flight_Master where Flight_ID=" + FlightID);
            //if (dtAirlineID.Rows.Count > 0)
            //{
            //    ddlAirline.SelectedValue = dtAirlineID.Rows[0]["Airline_ID"].ToString();
            //    ddlAirline.Enabled = false;             
            //}
            ////ddlFlight_No();
            //ddlFlightNo.SelectedValue = FlightID;
            ////ddlFlightNo.Enabled = false;

            //******************************************************
            DataTable dtFlightType = dw.GetAllFromQuery("select Flight_Type,Airline_Detail_ID from Flight_Master where Flight_ID=" + FlightID);
           
            //******************************************************
            com = new SqlCommand("[SHOW_SCHEDULE]", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FlightID", SqlDbType.BigInt).Value = long.Parse(FlightID);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dtFlight = new DataTable();
            da.Fill(dtFlight);
            //******************************************************

            if (dtFlightType.Rows.Count > 0)
            {
                ddlAirline.SelectedValue = dtFlightType.Rows[0]["Airline_Detail_ID"].ToString();
                ddlAirline.Enabled = false;
            }
            if (dtFlightType.Rows.Count > 0)
            {
                rb.SelectedValue = dtFlightType.Rows[0]["Flight_Type"].ToString();
            }
            if (dtFlight.Rows.Count > 0)
            {
                rb1.SelectedValue = dtFlight.Rows[0]["Schedule_Type"].ToString();
                rb1.Enabled = false;
            }
            BindUpdateFlightNo();
            ddlFlightNo.SelectedValue = FlightID;
            ddlFlightNo.Enabled = false;
            if (rb1.SelectedValue == "DATEWISE")
            {
                datetd.Visible = true;
                daytd.Visible = false;
                dailytd.Visible = false;
                lblschedule.Text = "DATE WISE";
            }
            if (rb1.SelectedValue == "DAYWISE")
            {
                datetd.Visible = false;
                daytd.Visible = true;
                dailytd.Visible = false;
                lblschedule.Text = "DAY WISE";
            }
            if (rb1.SelectedValue == "DAILY")
            {
                datetd.Visible = false;
                daytd.Visible = false;
                dailytd.Visible = true;
                lblschedule.Text = "DAILY";
            }
            if (dtFlight.Rows[0]["Schedule_Type"].ToString() == "DATEWISE")
            {
                DataTable dt = (DataTable)Session["dthold"];
                if (dt.Rows[0][0].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                for (int k = 0; k < dtFlight.Rows.Count; k++)
                {
                    string a=dtFlight.Rows[k]["Flight_Date"].ToString();
                    //DataTable dt=(DataTable)Session["dthold"];
                    DataRow dr = dt.NewRow();
                    if (dtFlight.Rows[k]["Flight_Date"].ToString().Length == 2)
                    {
                        dr[1] = dtFlight.Rows[k]["Flight_Date"].ToString();
                    }
                    else
                    {
                        dr[1] = "0"+dtFlight.Rows[k]["Flight_Date"].ToString();
                    }
                    string strTime = dtFlight.Rows[k]["Flight_Time"].ToString();
                    string[] Time = strTime.Split(new char[] { ':' });
                    dr[2] = Time[0].ToString();
                    dr[3] = Time[1].ToString();
                    dt.Rows.Add(dr);
                }
                Session["dthold"] = dt;
                GridView2.DataSource = dt;
                GridView2.DataBind();
            }
            if (dtFlight.Rows[0]["Schedule_Type"].ToString() == "DAILY")
            {
                DataTable dt = (DataTable)Session["day"];
                if (dt.Rows[0][0].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                for (int k = 0; k < dtFlight.Rows.Count; k++)
                {
                    DataRow dr = dt.NewRow();
                    dr[1] = dtFlight.Rows[k]["Flight_Day"].ToString();
                    string strTime = dtFlight.Rows[k]["Flight_Time"].ToString();
                    string[] Time = strTime.Split(new char[] { ':' });
                    dr[2] = Time[0].ToString();
                    dr[3] = Time[1].ToString();
                    dt.Rows.Add(dr);
                }
                Session["day"] = dt;
                Gv_DailyWise.DataSource = dt;
                Gv_DailyWise.DataBind();
            }
            else
            {
                DataTable dt = (DataTable)Session["day"];
                if (dt.Rows[0][0].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                for (int k = 0; k < dtFlight.Rows.Count; k++)
                {
                   // dtFlight.Rows[k]["Flight_Date"].ToString();
                    //DataTable dt=(DataTable)Session["dthold"];
                   ///////// DataRow dr = dt.NewRow();
                    //foreach (DataRow rw in dt.Rows)
                    //{
                        //if (rw["Day"].ToString() == dtFlight.Rows[k]["Flight_Day"].ToString())
                        //{
                             DataRow dr = dt.NewRow();
                             
                            dr[1] = dtFlight.Rows[k]["Flight_Day"].ToString();
                           
                            string strTime = dtFlight.Rows[k]["Flight_Time"].ToString();
                            
                            string[] Time = strTime.Split(new char[] { ':' });
                            dr[2] = Time[0].ToString();
                            dr[3] = Time[1].ToString();
                            //rw["Hours"] = Time[0].ToString();
                            //rw["Minutes"] = Time[1].ToString();
                        //}
                    //}
                    //string dd = dtFlight.Rows[k]["Flight_Day"].ToString();
                    //dr[1] = dtFlight.Rows[k]["Flight_Day"].ToString();
                   
                    //string strTime = dtFlight.Rows[k]["Flight_Time"].ToString();
                    //string[] Time = strTime.Split(new char[] { ':' });
                    //dr[2] = Time[0].ToString();
                    //dr[3] = Time[1].ToString();
                    dt.Rows.Add(dr);
                }
                Session["day"] = dt;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            txtFrom.Value = FormatDateMM(((DateTime)dtFlight.Rows[0]["Valid_From"]).ToShortDateString());
            txtTo.Value = FormatDateMM(((DateTime)dtFlight.Rows[0]["Valid_To"]).ToShortDateString()); 
            ddlStatus.SelectedValue = dtFlight.Rows[0]["Status"].ToString(); 
        }
    }
    public void AirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            string Airline_Access = Rights();
            strQuery = "Select Airline_Detail_ID,Airline_ID,Belongs_To_City from Airline_Detail where Airline_Detail_ID in("+Airline_Access+")";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirline.Items.Insert(0, "- - Select - -");
            ddlAirline.Items[0].Value = "0";
            while (dr.Read())
            {
                DataTable dtAirlineName = dw.GetAllFromQuery("select Airline_Name from Airline_Master where Airline_ID=" + dr["Airline_ID"].ToString());
                DataTable dtCity = dw.GetAllFromQuery("select City_Name from City_Master where City_ID=" + dr["Belongs_To_City"].ToString());
                ddlAirline.Items.Add(new ListItem(dtAirlineName.Rows[0]["Airline_Name"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    //public void airline_code()
    //{
    //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["gccs"]);
    //    con.Open();
    //    string str = "select alcd from ac_aline";
    //    SqlCommand cmd = new SqlCommand(str, con);
    //    SqlDataReader dr;

    //    dr = cmd.ExecuteReader();
    //    alcode.DataSource = dr;
    //    alcode.DataTextField = "alcd";
    //    alcode.DataBind();
    //    cmd.Dispose();
    //    con.Close();
    //}
    public void filldate()
    {
       DataTable dt=(DataTable)Session["dthold"];
      //  dt.Rows[0].Delete();
       string FlightID = Convert.ToString(Request.QueryString["FlightID"]);
       foreach (DataRow rw in dt.Rows)
       {
           con = new SqlConnection(strCon);
           try
           {
               con.Open();
               string AirlineID = Convert.ToString(Request.QueryString["AirlineID"]);
               con = new SqlConnection(strCon);
               con.Open();
               com = new SqlCommand("SCHEDULE_INSERT", con);
               com.CommandType = CommandType.StoredProcedure;
               com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = ddlFlightNo.SelectedValue;
               com.Parameters.Add("@Schedule_Type", SqlDbType.VarChar).Value = "DATEWISE";
               com.Parameters.Add("@Flight_Day", SqlDbType.VarChar).Value = "";
               com.Parameters.Add("@Flight_Date", SqlDbType.Int).Value = rw["Date"].ToString();
               com.Parameters.Add("@Flight_Time", SqlDbType.VarChar).Value = rw["Hours"].ToString() + ":" + rw["Minutes"].ToString() + ":" + "00";
               com.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtFrom.Value);
               com.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtTo.Value);              
               com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = "ADMIN";
               com.Parameters.Add("@Entered_Date", SqlDbType.DateTime).Value = DateTime.Now;
               com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
               com.ExecuteNonQuery();
               con.Close();
               com.Connection.Close();
               //DateTime.Parse(DateTime.Now.Month + "/" + ddlDates1.SelectedItem.Text + "/" + DateTime.Now.Year + " " + ddlHH1.Text + ":" + ddlMM1.Text + ":" + "00");               
               // Clear();               
               //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('A New Agent has Created');</script>");   
           }
           catch (SqlException sqlex)
           {
               ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Please Enter New Airline Code');</script>");
               string ss = sqlex.Message;
               // txtAirlineCode.Focus();
               // txtAirlineCode.Value = "";
               //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
           }
           finally
           {
               if (con != null && con.State == ConnectionState.Open)
                   con.Close();
           }
       }
       Response.Redirect("FlightDetails.aspx");
    }
    public void des_code()
    {
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["gccs"]);
        //con.Open();
        //string str = "select dstnName from ac_dstn";
        //SqlCommand cmd = new SqlCommand(str, con);
        //SqlDataReader dr;

        //dr = cmd.ExecuteReader();
        //des.DataSource = dr;
        //des.DataTextField = "dstnName";
        //des.DataBind();
        //cmd.Dispose();
        //con.Close();
    }
    #region GridView2 Event Handlers   
    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //if (e.CommandName == "Edit")
        //{
            //string strDate = ((DropDownList)GridView2.FindControl("ddlDate")).SelectedValue;
            //string strhh = ((DropDownList)GridView2.FooterRow.FindControl("ddlhh")).SelectedValue;
            //string strmm = ((DropDownList)GridView2.FooterRow.FindControl("ddlmm")).SelectedValue;
            //ViewState["Date"]=strDate;
            //ViewState["hh"]=strhh;
            //ViewState["mm"] = strmm;
        //}
        if (e.CommandName == "Add")
        {
            try
            {
                
                DataTable dt =(DataTable)Session["dthold"];
                if (dt.Rows[0][1].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                //DataRow dr = dt.NewRow();
               //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames

                string strDate = ((DropDownList)GridView2.FooterRow.FindControl("ddlDate")).SelectedValue;
                string strhh = ((DropDownList)GridView2.FooterRow.FindControl("ddlhh")).SelectedValue;
                string strmm = ((DropDownList)GridView2.FooterRow.FindControl("ddlmm")).SelectedValue;
                //int i = Int32.Parse(strCustomerID);
                int j = Int32.Parse(strDate);
                int k = Int32.Parse(strhh);
                int m = Int32.Parse(strmm);
                //Prepare the Insert Command of the DataSource control

                //dr[1] = j;
                //dr[2] = k;
                //dr[3] = m;
                bool Flag=false;
                foreach(DataRow rw in dt.Rows)
                {
                    int p=int.Parse(rw["Date"].ToString());
                    if (j == p)
                    {
                        Flag = true;
                    }
                }
                if (Flag == false)
                {
                    DataRow dr = dt.NewRow();
                    dr[1] = strDate;
                    dr[2] = strhh;
                    dr[3] = strmm;

                    dt.Rows.Add(dr);
                    Session["dthold"] = dt;
                    GridView2.DataSource = (DataTable)Session["dthold"];
                    GridView2.DataBind();
                    lblDateMsg.Visible = false;
                }
                else
                {
                    lblDateMsg.Visible = true;
                    lblDateMsg.Text = "The Date is Already Exist,Pls Select Another Date";
                   ((DropDownList)GridView2.FooterRow.FindControl("ddlDate")).SelectedValue ="--";
                   ((DropDownList)GridView2.FooterRow.FindControl("ddlhh")).SelectedValue = "--";
                   ((DropDownList)GridView2.FooterRow.FindControl("ddlmm")).SelectedValue = "--";
                    //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('The Date is Already Exist in Schedule,Pls Select Another Date');</script>");
                }
               
                //string s1 = "SELECT Fltno,hh,mm,fltdate,id FROM ac_fltDetails_tran ORDER BY fltno";
                //AccessDataSource1.SelectCommand = s1;

                
                //GridViewRow gv = GridView2.Rows[0];
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;

                //fill();

                
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Date/Hour/Minutes Values Should Not Be Blank" + "');</script>");
            }
        }
    }
    private object LinkButton(object p)
    {
        throw new Exception("The method or operation is not implemented.");
    }
    protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    {       
        GridView2.EditIndex = e.NewEditIndex;
        //((DropDownList)GridView2.FooterRow.FindControl("ddlDate")).SelectedValue = ViewState["Date"].ToString();
        //((DropDownList)GridView2.FooterRow.FindControl("ddlhh")).SelectedValue = ViewState["hh"].ToString();
        //((DropDownList)GridView2.FooterRow.FindControl("ddlmm")).SelectedValue = ViewState["mm"].ToString();   
        //Date.SelectedValue
        GridView2.DataSource =(DataTable)Session["dthold"];
        GridView2.DataBind();
        //GridViewRow gv = GridView2.Rows[0];
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;
    }
    protected void GridView2_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        //Check if there is any exception while deleting
        if (e.Exception != null)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + e.Exception.Message.ToString().Replace("'", "") + "');</script>");
            e.ExceptionHandled = true;
        }
    }
    protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow row1 = GridView2.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["dthold"];
        DataRow[] drp;
        drp = dt.Select("id =  '" + ((Label)row1.FindControl("lblfltno")).Text + "'");
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                    row.Delete();
            }
        }
        Session["dthold"] = dt;
        if (dt.Rows.Count == 0)
        {
            Session["dthold"] = maketable();
            GridView2.DataSource = (DataTable)Session["dthold"];
            GridView2.DataBind();
            //GridViewRow gV = GridView2.Rows[0];
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonEdit")).Visible = false;
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonDelete")).Visible = false;

            //Session["T"] = 1;
        }
        else
        {
            GridView2.DataSource = (DataTable)Session["dthold"];
            GridView2.DataBind();
            //GridViewRow gV = GridView2.Rows[0];
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonEdit")).Visible = false;
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonDelete")).Visible = false;

        }
        ((DropDownList)GridView2.FooterRow.Cells[0].FindControl("ddlDate")).Focus();
    }
    protected void GridView2_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        //Check if there is any exception while deleting
        if (e.Exception != null)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + e.Exception.Message.ToString().Replace("'", "") + "');</script>");
            e.ExceptionHandled = true;
        }
    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        GridView2.Columns[0].Visible = false;
        //Check if this is our Blank Row being databound, if so make the row invisible
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (((DataRowView)e.Row.DataItem)["id"].ToString() == String.Empty) e.Row.Visible = false;

            if (GridView2.EditIndex == e.Row.RowIndex)
            {
                DropDownList Date = (DropDownList)e.Row.FindControl("ddlDate");
                DropDownList hh = (DropDownList)e.Row.FindControl("ddlhh");
                DropDownList mm = (DropDownList)e.Row.FindControl("ddlmm");

                string kk = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Date"].ToString();
                if (Session["dthold"] != null)
                {
                   ViewState["EDate"] =((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Date"].ToString();
                   ViewState["Ehh"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Hours"].ToString();
                   ViewState["Emm"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Minutes"].ToString();

                    Date.SelectedIndex = Date.Items.IndexOf(Date.Items.FindByText(((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Date"].ToString()));
                    hh.SelectedIndex = hh.Items.IndexOf(hh.Items.FindByText(((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Hours"].ToString()));
                    mm.SelectedIndex = mm.Items.IndexOf(mm.Items.FindByText(((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Minutes"].ToString()));

                }
            }
        }
    }
    protected void GridView2_Sorting(object sender, GridViewSortEventArgs e)
    {
        GridView gvTemp = (GridView)sender;
        gvUniqueID = gvTemp.UniqueID;
        gvSortExpr = e.SortExpression;
        GridView2.DataBind();
    }
    #endregion
    protected void Addschedule_Click(object sender, EventArgs e)
    {
        if (rb1.SelectedValue == "DATEWISE")
        {
             DataTable dt = (DataTable)Session["dthold"];
             if (dt.Rows.Count == 1)
             {
                 if (dt.Rows[0][1].ToString() == "0")
                 {
                     lblDateMsg.Visible = true;
                     lblDateMsg.Text = "Pls Add at least One Date in Schedule";
                 }
                 else
                 {
                     filldate();
                     lblDateMsg.Visible = false;
                 }
             }
             else
             {
                 filldate();
                 lblDateMsg.Visible = false;
             }
        }
        if (rb1.SelectedValue == "DAYWISE")
        {
            DataTable dt = (DataTable)Session["Day"];
            if (dt.Rows.Count == 1)
            {
                if (dt.Rows[0][1].ToString() == "0")
                {
                    lblDayMsg.Visible = true;
                    lblDayMsg.Text = "Pls Add at least One Day in Schedule";
                }
                else
                {
                    fillday();
                    lblDateMsg.Visible = false;
                }
            }
            else
            {
                fillday();
                lblDayMsg.Visible = false;
            }
         }
        if (rb1.SelectedValue == "DAILY")
         {
                 //ArrayList arr = new ArrayList();
                 //arr.Add("SUNDAY");
                 //arr.Add("MONDAY");
                 //arr.Add("TUESDAY");
                 //arr.Add("WEDNESDAY");
                 //arr.Add("THURSDAY");
                 //arr.Add("FRIDAY");
                 //arr.Add("SATURDAY");
                 DataTable dt = (DataTable)Session["day"];                                 
                 try
                 {                    
                        if (dt.Rows.Count > 0)
                        {                   
                            con = new SqlConnection(strCon);
                            con.Open();
                            foreach (DataRow dr in dt.Rows)
                            {
                                string AirlineID = Convert.ToString(Request.QueryString["AirlineID"]);
                                com = new SqlCommand("SCHEDULE_INSERT", con);
                                com.CommandType = CommandType.StoredProcedure;
                                com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = ddlFlightNo.SelectedValue;
                                com.Parameters.Add("@Schedule_Type", SqlDbType.VarChar).Value = "DAILY";
                                com.Parameters.Add("@Flight_Day", SqlDbType.VarChar).Value = Convert.ToString(dr["Day"]);
                                com.Parameters.Add("@Flight_Date", SqlDbType.Int).Value = 0;
                                com.Parameters.Add("@Flight_Time", SqlDbType.VarChar).Value = Convert.ToString(dr["Hours"]) + ":" + Convert.ToString(dr["Minutes"]) + ":" + "00";
                                com.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtFrom.Value);
                                com.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtTo.Value);
                                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = "ADMIN";
                                com.Parameters.Add("@Entered_Date", SqlDbType.DateTime).Value = DateTime.Now;
                                com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                                com.ExecuteNonQuery();
                            }
                            con.Close();
                            com.Connection.Close();
                        }
                        else
                        {
                            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Day/Hour/Minutes Values Should Not Be Blank" + "');</script>");
                        }
                       
                 }
                 catch (Exception ex)
                 {
                     ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Day/Hour/Minutes Values Should Not Be Blank" + "');</script>");
                 }
             }
             Response.Redirect("FlightDetails.aspx");          
    }
    public DataTable maketable()
    {
        DataTable dt = new DataTable();
        DataColumn dc3 = new DataColumn("Id", typeof(Int32));
        dc3.AutoIncrement = true;
        dc3.AutoIncrementStep = 1;
        dc3.AutoIncrementSeed = 1;
        dt.Columns.Add(dc3);
        DataColumn dc = new DataColumn("Date", typeof(String));
        
        dt.Columns.Add(dc);
        DataColumn dc1 = new DataColumn("Hours", typeof(String));
        
        dt.Columns.Add(dc1);
        DataColumn dc2 = new DataColumn("Minutes", typeof(String));
       
        dt.Columns.Add(dc2);
        DataRow dr = dt.NewRow();

        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "00";
        dr[3] = "00";
        dt.Rows.Add(dr);
        return dt;
    }
    public DataTable maketableday()
    {
        DataTable dt = new DataTable();
        DataColumn dc3 = new DataColumn("Id", typeof(Int32));
        dc3.AutoIncrement = true;
        dc3.AutoIncrementStep = 1;
        dc3.AutoIncrementSeed = 1;
        dt.Columns.Add(dc3);
        DataColumn dc = new DataColumn("Day", typeof(String));
        dt.Columns.Add(dc);
        DataColumn dc1 = new DataColumn("Hours", typeof(String));
        dt.Columns.Add(dc1);
        DataColumn dc2 = new DataColumn("Minutes", typeof(String));
        dt.Columns.Add(dc2);

        DataRow dr = dt.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "00";
        dr[3] = "00";
        dt.Rows.Add(dr);

        return dt;
       // Session["dtTemp"] = dtTemp;
    }
    protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row1 = GridView2.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["dthold"];
        DataRow[] drp;
        drp = dt.Select("id =  '" + ((Label)row1.FindControl("lblfltno")).Text + "'");

        string h="";
        h = ((DropDownList)row1.FindControl("ddlDate")).SelectedValue;
        bool Flag = false;
        foreach (DataRow rw in dt.Rows)
        {
            int p = int.Parse(rw["Date"].ToString());
            if (int.Parse(h) == p)
            {
                Flag = true;
            }
            if (h == ViewState["EDate"].ToString())
            {
                Flag = false;
            }
        }
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                {
                   row.BeginEdit();
                   row[1] = ((DropDownList)row1.FindControl("ddlDate")).SelectedValue;
                   row[2] = ((DropDownList)row1.FindControl("ddlhh")).SelectedValue;
                   row[3] = ((DropDownList)row1.FindControl("ddlmm")).SelectedValue;

                    if (row[1].ToString() == "") break;
                    if (row[2].ToString() == "") break;
                    if (row[3].ToString() == "") break;
                    row.EndEdit();
                }
            }
        }        
        if (Flag == false)
          {
              GridView2.EditIndex = -1;
              GridView2.DataSource = (DataTable)Session["dthold"];
              GridView2.DataBind();
              //GridViewRow gV = GridView2.Rows[0];
              //((LinkButton)gV.Cells[3].FindControl("LinkButtonEdit")).Visible = false;
              //((LinkButton)gV.Cells[3].FindControl("LinkButtonDelete")).Visible = false;

              ((DropDownList)GridView2.FooterRow.Cells[0].FindControl("ddlDate")).Focus();
              ((DropDownList)GridView2.FooterRow.Cells[0].FindControl("ddlhh")).Focus();
              ((DropDownList)GridView2.FooterRow.Cells[0].FindControl("ddlmm")).Focus();
              lblDateMsg.Visible = false;
          }
          else
          {
              lblDateMsg.Visible = true;
              lblDateMsg.Text = "The Date is Already Exist,Pls Select Another Date";
          }

    }
    protected void GridView2_CancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView2.EditIndex = -1;
        GridView2.DataSource = (DataTable)Session["dthold"];
        GridView2.DataBind();
        //GridViewRow gv = GridView2.Rows[0];
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;

    }  
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        GridView1.Columns[0].Visible = false;
        //Check if this is our Blank Row being databound, if so make the row invisible
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string FlightID = Convert.ToString(Request.QueryString["FlightID"]);
            if (((DataRowView)e.Row.DataItem)["id"].ToString() == String.Empty) e.Row.Visible = false;
            if (GridView1.EditIndex == e.Row.RowIndex)
            {
                DropDownList Date = (DropDownList)e.Row.FindControl("ddlDate");
                DropDownList hh = (DropDownList)e.Row.FindControl("ddlhh");
                DropDownList mm = (DropDownList)e.Row.FindControl("ddlmm");
                DataTable dt=(DataTable)Session["day"];
                if (Session["day"] != null)
                {

                    ViewState["EDate"] = ((DataTable)Session["day"]).Rows[e.Row.RowIndex]["Day"].ToString();
                    ViewState["Ehh"] = ((DataTable)Session["day"]).Rows[e.Row.RowIndex]["Hours"].ToString();
                    ViewState["Emm"] = ((DataTable)Session["day"]).Rows[e.Row.RowIndex]["Minutes"].ToString();
                    Date.SelectedIndex = Date.Items.IndexOf(Date.Items.FindByText(((DataTable)Session["day"]).Rows[e.Row.RowIndex][1].ToString()));
                    int str1=e.Row.RowIndex;
                   // hh.SelectedIndex = hh.Items.IndexOf(dt.Rows[e.Row.RowIndex][2].ToString());
                    hh.SelectedIndex = hh.Items.IndexOf(hh.Items.FindByText(((DataTable)Session["day"]).Rows[e.Row.RowIndex][2].ToString()));
                    mm.SelectedIndex = mm.Items.IndexOf(mm.Items.FindByText(((DataTable)Session["day"]).Rows[e.Row.RowIndex][3].ToString()));
                }
            }
        }
    }
    public void fillday()
    {
          DataTable dt = (DataTable)Session["day"];
          SqlConnection con = new SqlConnection(strCon);          
          foreach (DataRow rw in dt.Rows)
          {
           con = new SqlConnection(strCon);
          try
           {
                con.Open();
                string AirlineID = Convert.ToString(Request.QueryString["AirlineID"]);
                com = new SqlCommand("SCHEDULE_INSERT", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = ddlFlightNo.SelectedValue;
                com.Parameters.Add("@Schedule_Type", SqlDbType.VarChar).Value = "DAYWISE";
                com.Parameters.Add("@Flight_Day", SqlDbType.VarChar).Value = rw["Day"].ToString();
                com.Parameters.Add("@Flight_Date", SqlDbType.Int).Value = 0;
                com.Parameters.Add("@Flight_Time", SqlDbType.VarChar).Value = rw["Hours"].ToString() + ":" + rw["Minutes"].ToString() + ":" + "00";
                com.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtFrom.Value);
                com.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtTo.Value);
                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = "ADMIN";
                com.Parameters.Add("@Entered_Date", SqlDbType.DateTime).Value = DateTime.Now;
                com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;               
                com.ExecuteNonQuery();
                con.Close();
                com.Connection.Close();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Date/Hour/Minutes Values Should Not Be Blank" + "');</script>");
            }
        }  
        Response.Redirect("FlightDetails.aspx");   
    }
    public string FormatDateDD(string date)
        {
            string[] d = date.Split(new char[] { '/' });
            string strDD = d[0];
            string strMM = d[1];
            string strYYYY = d[2];
            string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
            return strMMDDYYYY;
        }
    public string FormatDateMM(string date)
        {

            string[] d = date.Split(new char[] { '/' });

            string strMM = d[0];
            string strDD = d[1];
            string strYYYY = d[2];
            string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
            return strMMDDYYYY;
        }
    protected void ddlAirline_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindFlightNo();
    }
    public void BindFlightNo()
    {
        con = new SqlConnection(strCon);
        con.Open();

        com = new SqlCommand("SHOW_FLIGHT_NO", con);
        com.CommandType = CommandType.StoredProcedure;

        com.Parameters.Add("@Flight_Type", SqlDbType.VarChar, 50).Value = rb.SelectedValue;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = ddlAirline.SelectedItem.Value;

        //string selectQ;
        //if (rb1.SelectedValue == "DATEWISE")
        //{
        //    selectQ = "select Flight_No,Flight_ID from Flight_Master where Flight_Type=@Flight_Type and Airline_Detail_ID=@Airline_Detail_ID and status=2 and Flight_ID not in(select Flight_ID from Flight_Details)";
        //    com = new SqlCommand(selectQ, con);
        //    com.Parameters.Add("@Flight_Type", SqlDbType.VarChar, 50).Value = rb.Text;
        //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = ddlAirline.SelectedItem.Value;
        //}
        //else
        //{
        //    selectQ = "select Flight_No,Flight_ID from Flight_Master where Flight_Type=@Flight_Type and Airline_Detail_ID=@Airline_Detail_ID and status=2 and Flight_ID not in(select Flight_ID from Flight_Details)";
        //    com = new SqlCommand(selectQ, con);
        //    com.Parameters.Add("@Flight_Type", SqlDbType.VarChar, 50).Value = rb.SelectedValue;
        //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = ddlAirline.SelectedItem.Value;
        //}

        com.Connection = con;
        da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ddlFlightNo.DataTextField = "Flight_No";
            ddlFlightNo.DataValueField = "Flight_ID";
            ddlFlightNo.DataSource = dt;
            ddlFlightNo.DataBind();
            ddlFlightNo.Items.Insert(0, "- - Select - -");
            ddlFlightNo.Items[0].Value = "0";
            com.Dispose();
            con.Close();
        }
        else
        {
            lblmsg.Visible = true;
            ddlFlightNo.Items.Clear();
            ddlFlightNo.Items.Insert(0, "- - Select - -");
            ddlFlightNo.Items[0].Value = "0";
            if (ddlAirline.SelectedValue == "0")
            {
                lblmsg.Visible = false;
            }
        }
     }
    public void BindUpdateFlightNo()
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("SHOW_UPDATE_FLIGHT_NO", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Flight_Type", SqlDbType.VarChar, 50).Value = rb.SelectedValue;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = ddlAirline.SelectedItem.Value;

        //string selectQ;
        //if (rb1.SelectedValue == "DATEWISE")
        //{
        //    selectQ = "select Flight_No,Flight_ID from Flight_Master where Flight_Type=@Flight_Type and Airline_Detail_ID=@Airline_Detail_ID";
        //    com = new SqlCommand(selectQ, con);
        //    com.Parameters.Add("@Flight_Type", SqlDbType.VarChar, 50).Value = rb.Text;
        //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = ddlAirline.SelectedItem.Value;
        //}
        //else
        //{
        //    selectQ = "select Flight_No,Flight_ID from Flight_Master where Flight_Type=@Flight_Type and Airline_Detail_ID=@Airline_Detail_ID";
        //    com = new SqlCommand(selectQ, con);
        //    com.Parameters.Add("@Flight_Type", SqlDbType.VarChar, 50).Value = rb.SelectedValue;
        //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = ddlAirline.SelectedItem.Value;
        //}

        com.Connection = con;
        da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ddlFlightNo.DataTextField = "Flight_No";
            ddlFlightNo.DataValueField = "Flight_ID";
            ddlFlightNo.DataSource = dt;
            ddlFlightNo.DataBind();
            com.Dispose();
            con.Close();
        }
        else
        {
            lblmsg.Visible = true;
            ddlFlightNo.Items.Clear();
        }
    }
    protected void rb1_SelectedIndexChanged(object sender, EventArgs e)
    {       
        if (rb1.SelectedValue == "DAYWISE")
        {
            datetd.Visible = false;
            daytd.Visible = true;
            dailytd.Visible = false;
            ViewState["Flag"] = "0";
        }
        if (rb1.SelectedValue == "DATEWISE")
        {
            datetd.Visible = true;
            daytd.Visible = false;
            dailytd.Visible = false;
            ViewState["Flag"] = "1";
        }
        if (rb1.SelectedValue == "DAILY")
        {
            datetd.Visible = false;
            daytd.Visible = false;
            dailytd.Visible = true;
            ViewState["Flag"] = "1";
        }  
    }
    public void FillddlStatus()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("LOAD_STATUS", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = com.ExecuteReader();
            ddlStatus.Items.Insert(0, "- - Select - -");
            ddlStatus.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlStatus.Items.Add(new ListItem(dr["Status_Name"].ToString(), dr["Status_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {

                DataTable dt = (DataTable)Session["day"];
                if (dt.Rows[0][1].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                
                //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames

                string strDate = ((DropDownList)GridView1.FooterRow.FindControl("ddlDate")).SelectedValue;
                string strhh = ((DropDownList)GridView1.FooterRow.FindControl("ddlhh")).SelectedValue;
                string strmm = ((DropDownList)GridView1.FooterRow.FindControl("ddlmm")).SelectedValue;
                //int i = Int32.Parse(strCustomerID);
              
                // int j = Int32.Parse(strDate);
                //int k = Int32.Parse(strhh);
               // int m = Int32.Parse(strmm);

                //Prepare the Insert Command of the DataSource control

                //dr[1] = j;
                //dr[2] = k;
                //dr[3] = m;

                bool Flag=false;
                foreach(DataRow rw in dt.Rows)
                {
                    string Day=rw["Day"].ToString();
                    if (strDate == Day)
                    {
                        Flag = true;
                    }
                }
                if (Flag == false)
                {
                    DataRow dr = dt.NewRow();
                    dr[1] = strDate;
                    dr[2] = strhh;
                    dr[3] = strmm;

                    dt.Rows.Add(dr);
                    Session["day"] = dt;
                    GridView1.DataSource = (DataTable)Session["day"];
                    GridView1.DataBind();                   
                    lblDayMsg.Visible = false;
                }
                else
                {
                    lblDayMsg.Visible = true;
                    lblDayMsg.Text = "The Day is Already Exist,Pls Select Another Day";
                    ((DropDownList)GridView1.FooterRow.FindControl("ddlDate")).SelectedValue = "--";
                    ((DropDownList)GridView1.FooterRow.FindControl("ddlhh")).SelectedValue = "--";
                    ((DropDownList)GridView1.FooterRow.FindControl("ddlmm")).SelectedValue = "--";
                }
                //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Order added successfully');</script>");
                //string s1 = "SELECT Fltno,hh,mm,fltdate,id FROM ac_fltDetails_tran ORDER BY fltno";
                //AccessDataSource1.SelectCommand = s1;


                //GridViewRow gv = GridView2.Rows[0];
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;

                //fill();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Date/Hour/Minutes Values Should Not Be Blank" + "');</script>");
            }
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {        
       //Delete from Flight_schedule
       DeleteSchedule();
       if(rb1.SelectedValue == "DATEWISE")
        {
            DataTable dt = (DataTable)Session["dthold"];
            if (dt.Rows.Count==1)
            {
                if (dt.Rows[0][1].ToString() == "0")
                {
                    lblDateMsg.Visible = true;
                    lblDateMsg.Text = "Pls Add at least One Date in Schedule";
                }
                else
                {
                    filldate();
                    lblDateMsg.Visible = false;
                }
            }
            else
            {
                filldate();
                lblDateMsg.Visible = false;
            }
        }
        if (rb1.SelectedValue == "DAYWISE")
        {
            DataTable dt = (DataTable)Session["Day"];
            if (dt.Rows.Count == 1)
            {
                if (dt.Rows[0][1].ToString() == "0")
                {
                    lblDayMsg.Visible = true;
                    lblDayMsg.Text = "Pls Add at least One Day in Schedule";
                }
                else
                {
                    fillday();
                    lblDateMsg.Visible = false;
                }
            }
            else
            {
                fillday();
                lblDayMsg.Visible = false;
            }
       }
       if (rb1.SelectedValue == "DAILY")
        {
            DataTable dt = (DataTable)Session["Day"];
            if (dt.Rows.Count == 1)
            {
                if (dt.Rows[0][1].ToString() == "0")
                {
                    lblDayMsg.Visible = true;
                    lblDayMsg.Text = "Pls Add at least One Day in Schedule";
                }
                else
                {
                    fillDaily();                  
                    lblDateMsg.Visible = false;
                }
            }
            else
            {
                fillDaily(); 
                lblDayMsg.Visible = false;
            }
        }
    }
    public void fillDaily()
    {       
            try
            {
                string AirlineID = Convert.ToString(Request.QueryString["AirlineID"]);
                DataTable dtdaily = (DataTable)Session["day"];
                SqlConnection con = new SqlConnection(strCon);
                con.Open();    
                foreach (DataRow rw in dtdaily.Rows)
                    {
                        com = new SqlCommand("SCHEDULE_INSERT", con);
                        com.CommandType = CommandType.StoredProcedure;
                        com.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = ddlFlightNo.SelectedValue;
                        com.Parameters.Add("@Schedule_Type", SqlDbType.VarChar).Value = "DAILY";
                        com.Parameters.Add("@Flight_Day", SqlDbType.VarChar).Value = rw["Day"].ToString();
                        com.Parameters.Add("@Flight_Date", SqlDbType.Int).Value = 0;
                        com.Parameters.Add("@Flight_Time", SqlDbType.VarChar).Value = rw["Hours"].ToString() + ":" + rw["Minutes"].ToString() + ":" + "00";
                        com.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtFrom.Value);
                        com.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtTo.Value);
                        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = "ADMIN";
                        com.Parameters.Add("@Entered_Date", SqlDbType.DateTime).Value = DateTime.Now;
                        com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                        com.ExecuteNonQuery();                      
                    }
                con.Close();
                com.Connection.Close();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Date/Hour/Minutes Values Should Not Be Blank" + "');</script>");
            }
            Response.Redirect("FlightDetails.aspx");             
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        DataTable dt = maketable();
        GridView2.DataSource = dt;
        GridView2.DataBind();
        DataTable dt1=maketableday();
        GridView1.DataSource = dt1;
        GridView1.DataBind();

        Gv_DailyWise.DataSource = dt1;
        Gv_DailyWise.DataBind();

        ddlStatus.SelectedIndex = 0;
        ddlAirline.SelectedIndex = 0;
        txtFrom.Value = "";
        txtTo.Value = "";
        ddlFlightNo.Items.Clear();
    }
    public void DeleteSchedule()
    {
        string FlightID = Convert.ToString(Request.QueryString["FlightID"]);
        SqlConnection con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand("DELETE_SCHEDULE", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@FlightID", SqlDbType.BigInt).Value = long.Parse(FlightID);
        com.ExecuteNonQuery();
        con.Close();
        com.Connection.Close();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void GridView1_CancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        GridView1.DataSource = (DataTable)Session["day"];
        GridView1.DataBind();     
        //GridViewRow gv = GridView2.Rows[0];
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;
    }
    protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {

    }
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        GridView gvTemp = (GridView)sender;
        gvUniqueID = gvTemp.UniqueID;
        gvSortExpr = e.SortExpression;
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row1 = GridView1.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["day"];
        DataRow[] drp;
        drp = dt.Select("id =  '" + ((Label)row1.FindControl("lblfltno")).Text + "'");
        string h = "";
        string g = "";
        string k = "";
        h = ((DropDownList)row1.FindControl("ddlDate")).SelectedValue;
        bool Flag = false;
        foreach (DataRow rw in dt.Rows)
        {
            string p = rw["Day"].ToString();
            if (h == p)
            {
                Flag = true;
            }
            if (h == ViewState["EDate"].ToString())
            {
                Flag = false;
            }
        }
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                {
                    row.BeginEdit();
                    row[1] = ((DropDownList)row1.FindControl("ddlDate")).SelectedValue;
                    row[2] = ((DropDownList)row1.FindControl("ddlhh")).SelectedValue;
                    row[3] = ((DropDownList)row1.FindControl("ddlmm")).SelectedValue;

                    if (row[1].ToString() == "") break;
                    if (row[2].ToString() == "") break;
                    if (row[3].ToString() == "") break;
                    row.EndEdit();
                }
            }
        }
        if (Flag == false)
        {
            GridView1.EditIndex = -1;
            GridView1.DataSource = (DataTable)Session["day"];
            GridView1.DataBind();          
            //GridViewRow gV = GridView2.Rows[0];
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonEdit")).Visible = false;
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonDelete")).Visible = false;

            ((DropDownList)GridView1.FooterRow.Cells[0].FindControl("ddlDate")).Focus();
            ((DropDownList)GridView1.FooterRow.Cells[0].FindControl("ddlhh")).Focus();
            ((DropDownList)GridView1.FooterRow.Cells[0].FindControl("ddlmm")).Focus();
            lblDayMsg.Visible = false;
        }
        else
        {
            lblDayMsg.Visible = true;
            lblDayMsg.Text = "The Day is Already Exist,Pls Select Another Day";
        }
      
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;

        //((DropDownList)GridView2.FooterRow.FindControl("ddlDate")).SelectedValue = ViewState["Date"].ToString();
        //((DropDownList)GridView2.FooterRow.FindControl("ddlhh")).SelectedValue = ViewState["hh"].ToString();
        //((DropDownList)GridView2.FooterRow.FindControl("ddlmm")).SelectedValue = ViewState["mm"].ToString();

        DataTable dt = (DataTable)Session["day"];
        //Date.SelectedValue
        GridView1.DataSource = (DataTable)Session["day"];
        GridView1.DataBind();
        //GridViewRow gv = GridView2.Rows[0];
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
        //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow row1 = GridView1.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["day"];
        DataRow[] drp;
        drp = dt.Select("id =  '" + ((Label)row1.FindControl("lblfltno")).Text + "'");
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                    row.Delete();
            }
        }
        Session["day"] = dt;
        if (dt.Rows.Count == 0)
        {               
            Session["day"] = maketableday();
            GridView1.DataSource = (DataTable)Session["day"];
            GridView1.DataBind();
            //GridViewRow gV = GridView2.Rows[0];
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonEdit")).Visible = false;
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonDelete")).Visible = false;

            //Session["T"] = 1;
        }
        else
        {
            GridView1.DataSource = (DataTable)Session["day"];
            GridView1.DataBind();
           
            //GridViewRow gV = GridView2.Rows[0];
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonEdit")).Visible = false;
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonDelete")).Visible = false;

        }
        ((DropDownList)GridView1.FooterRow.Cells[0].FindControl("ddlDate")).Focus();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("FlightDetails.aspx");
    }
    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {

    }
    protected void Gv_DailyWise_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        Gv_DailyWise.Columns[0].Visible = false;
        //Check if this is our Blank Row being databound, if so make the row invisible
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string FlightID = Convert.ToString(Request.QueryString["FlightID"]);
            if (((DataRowView)e.Row.DataItem)["id"].ToString() == String.Empty) e.Row.Visible = false;
            if (Gv_DailyWise.EditIndex == e.Row.RowIndex)
            {
                DropDownList Date = (DropDownList)e.Row.FindControl("ddlDay");
                DropDownList hh = (DropDownList)e.Row.FindControl("ddlhh");
                DropDownList mm = (DropDownList)e.Row.FindControl("ddlmm");
                DataTable dt = (DataTable)Session["day"];
                if (Session["day"] != null)
                {
                     ViewState["EDate"] = ((DataTable)Session["day"]).Rows[e.Row.RowIndex]["Day"].ToString();
                     ViewState["Ehh"] = ((DataTable)Session["day"]).Rows[e.Row.RowIndex]["Hours"].ToString();
                     ViewState["Emm"] = ((DataTable)Session["day"]).Rows[e.Row.RowIndex]["Minutes"].ToString();
                     // Date.SelectedIndex = Date.Items.IndexOf(Date.Items.FindByText(((DataTable)Session["day"]).Rows[e.Row.RowIndex][1].ToString()));
                     // int str1 = e.Row.RowIndex;
                     //hh.SelectedIndex = hh.Items.IndexOf(dt.Rows[e.Row.RowIndex][2].ToString());
                     hh.SelectedIndex = hh.Items.IndexOf(hh.Items.FindByText(((DataTable)Session["day"]).Rows[e.Row.RowIndex][2].ToString()));
                     mm.SelectedIndex = mm.Items.IndexOf(mm.Items.FindByText(((DataTable)Session["day"]).Rows[e.Row.RowIndex][3].ToString()));
                }
            }
        }
    }
    protected void Gv_DailyWise_RowEditing(object sender, GridViewEditEventArgs e)
    {
        Gv_DailyWise.EditIndex = e.NewEditIndex;
        DataTable dt = (DataTable)Session["day"];
        //Date.SelectedValue
        Gv_DailyWise.DataSource = (DataTable)Session["day"];
        Gv_DailyWise.DataBind();
    }
    protected void Gv_DailyWise_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row1 = Gv_DailyWise.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["day"];
        DataRow[] drp;
        drp = dt.Select("id =  '" + ((Label)row1.FindControl("lblfltno")).Text + "'");
        string h = "";
        string g = "";       
        h = ((Label)row1.FindControl("lblfltdate")).Text;
        bool Flag = false;
        foreach (DataRow rw in dt.Rows)
        {
            string p = rw["Day"].ToString();
            if (h == p)
            {
                Flag = true;
            }
            if (h == ViewState["EDate"].ToString())
            {
                Flag = false;
            }
        }
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                {
                    row.BeginEdit();
                    row[1] = ((Label)row1.FindControl("lblfltdate")).Text;//((DropDownList)row1.FindControl("ddlDate")).SelectedValue;
                    row[2] = ((DropDownList)row1.FindControl("ddlhh")).SelectedValue;
                    row[3] = ((DropDownList)row1.FindControl("ddlmm")).SelectedValue;
                    if (row[1].ToString() == "") break;
                    if (row[2].ToString() == "") break;
                    if (row[3].ToString() == "") break;
                    row.EndEdit();
                }
            }
        }
        if (Flag == false)
        {
            Gv_DailyWise.EditIndex = -1;
            Gv_DailyWise.DataSource = (DataTable)Session["day"];
            Gv_DailyWise.DataBind();
            //GridViewRow gV = GridView2.Rows[0];
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonEdit")).Visible = false;
            //((LinkButton)gV.Cells[3].FindControl("LinkButtonDelete")).Visible = false;
            //((DropDownList)Gv_DailyWise.FooterRow.Cells[0].FindControl("ddlDate")).Focus();
            //((Label)Gv_DailyWise.FooterRow.Cells[0].FindControl("lblfltdate")).Focus();
            //((DropDownList)Gv_DailyWise.FooterRow.Cells[0].FindControl("ddlhh")).Focus();
            //((DropDownList)Gv_DailyWise.FooterRow.Cells[0].FindControl("ddlmm")).Focus();
            lblDayMsg.Visible = false;
        }
        else
        {
            lblDayMsg.Visible = true;
            lblDayMsg.Text = "The Day is Already Exist,Pls Select Another Day";
        }
    }
    protected void Gv_DailyWise_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {

    }
    protected void Gv_DailyWise_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        Gv_DailyWise.EditIndex = -1;
        Gv_DailyWise.DataSource = (DataTable)Session["day"];
        Gv_DailyWise.DataBind();     
    }
    protected void Gv_DailyWise_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName == "Add")
         {
            try
            {
                DataTable dt = (DataTable)Session["day"];
                if(dt.Rows.Count == 7)
                {                    
                    lbldailyMsg.Visible = true;                 
                    lbldailyMsg.Text = "All Day is Already Exist";
                    ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlDaily")).SelectedValue = "--";
                    ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlhh")).SelectedValue = "--";
                    ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlmm")).SelectedValue = "--";
                    return;
                }
                else 
                {
                    dt.Rows.Clear();
                    lbldailyMsg.Visible = false;
                    Gv_DailyWise.ShowFooter = true;   
                }
                string strDate = ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlDaily")).SelectedValue;
                string strhh = ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlhh")).SelectedValue;
                string strmm = ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlmm")).SelectedValue;
                bool Flag = false;
                foreach (DataRow rw in dt.Rows)
                {
                    string Day = rw["Day"].ToString();
                    if (strDate == Day)
                    {
                        Flag = true;
                    }
                }
                if (Flag == false)
                {
                    ArrayList arr = new ArrayList();
                    arr.Add("SUNDAY");
                    arr.Add("MONDAY");
                    arr.Add("TUESDAY");
                    arr.Add("WEDNESDAY");
                    arr.Add("THURSDAY");
                    arr.Add("FRIDAY");
                    arr.Add("SATURDAY");
                   // DataRow dr=null;
                    foreach (string str in arr)
                    {
                        DataRow dr = dt.NewRow();
                        dr[1] = str;
                        dr[2] = strhh;
                        dr[3] = strmm;
                        dt.Rows.Add(dr);
                    }                    
                    Session["day"] = dt;                    
                    Gv_DailyWise.DataSource = (DataTable)Session["day"];
                    Gv_DailyWise.DataBind();
                    //Gv_DailyWise.ShowFooter = false;
                    lbldailyMsg.Visible = false;
                }
                else
                {
                    lbldailyMsg.Visible = true;
                    lbldailyMsg.Text = "All Day is Already Exist";
                    ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlDaily")).SelectedValue = "--";
                    ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlhh")).SelectedValue = "--";
                    ((DropDownList)Gv_DailyWise.FooterRow.FindControl("ddlmm")).SelectedValue = "--";
                }
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Date/Hour/Minutes Values Should Not Be Blank" + "');</script>");
            }
        }
    }
}
