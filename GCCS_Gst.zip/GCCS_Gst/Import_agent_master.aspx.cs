using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Import_agent_master : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    //SqlDataAdapter da;
    //string Import_Agent_Name;
    //string Address;
    //string City_ID;
    //string Phone;
    //string Email;
    //decimal Creditlimit=0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack && Request.QueryString["ID"] != "")
        {
            lblmsg.Text = "Update Import Agent"; 
            LoadCity(); ;
            btnAdd.Visible = false;
            btnupdate.Visible = true;
            DataTable dt = dw.GetAllFromQuery("select Import_Agent_ID,Import_Agent_Name,Import_Agent_City,Import_Agent_Email,Import_Credit_Limit,Agent_Address,Agent_Phone,Agent_Contactno from import_agent_master where Import_Agent_ID=" + Request.QueryString["ID"].ToString() + " ");
            if (dt.Rows.Count > 0)
            {
                ddlcity.SelectedIndex = ddlcity.Items.IndexOf(ddlcity.Items.FindByValue(dt.Rows[0]["Import_Agent_City"].ToString()));
                txtImportAgentName.Text = dt.Rows[0]["Import_Agent_Name"].ToString();
                txtEmailId.Text = dt.Rows[0]["Import_Agent_Email"].ToString();
                txtCreditLimit.Text = dt.Rows[0]["Import_Credit_Limit"].ToString();
                txtAddress.Text = dt.Rows[0]["Agent_Address"].ToString();
                txtPhone.Text = dt.Rows[0]["Agent_Phone"].ToString();
                txtContact.Text = dt.Rows[0]["Agent_Contactno"].ToString();
                ddlcity.Enabled = false;
              
            }
        }
        else if (!IsPostBack)
        {
            lblmsg.Text = "Add Import Agent";
            btnupdate.Enabled = false;
            btnupdate.Visible = false;
            LoadCity();           // function for binding dropdown for city name;
           
        }


    }
    //public void ddl()
    //{
    //    con = new SqlConnection(strCon);
    //    cmd = new SqlCommand();
    //    cmd.CommandText = "select city_Code+'-'+city_Name as 'code',city_id from dbo.City_Master";
    //    cmd.Connection = con;
    //    cmd.Connection.Open();
    //    ddlcity.DataTextField = "code";
    //    ddlcity.DataValueField = "city_id";

    //    try
    //    {
    //        rdr = cmd.ExecuteReader();
    //    }
    //    catch (SqlException ee)
    //    {
    //        Response.Write("sql error" + ee.Message);
    //    }
    //    ddlcity.DataSource = rdr;
    //    ddlcity.DataBind();
    //    ddlcity.Items.Insert(0, "- -Select- -");
    //    cmd.Connection.Close();
    //}

    public void LoadCity()
    {
        try
        {
            string strAgent = "select * from City_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlcity.Items.Clear();
            ddlcity.Items.Add(new ListItem("- -Select- -", "0"));
            while (dr.Read())
            {
                ddlcity.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        btnupdate.Enabled = false;
        btnupdate.Visible = false;
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("insert into import_agent_master(Import_Agent_Name,Import_Agent_City,Import_Agent_Email,Import_Credit_Limit,Agent_Address,Agent_Phone,Agent_Contactno,Entered_By,Entered_On) values(@Import_Agent_Name,@Import_Agent_City,@Import_Agent_Email,@Import_Credit_Limit,@Agent_Address,@Agent_Phone,@Agent_Contactno,@Entered_By,@Entered_On)", con);

            //com.Parameters.Add("@DestinationID", SqlDbType.Int).Value = int.Parse(ddlDestination.SelectedValue);
           com.Parameters.Add("@Import_Agent_Name", SqlDbType.VarChar).Value = txtImportAgentName.Text.ToString();
            com.Parameters.Add("@Import_Agent_City", SqlDbType.Int).Value = int.Parse(ddlcity.SelectedValue);
            com.Parameters.Add("@Import_Agent_Email", SqlDbType.VarChar).Value = txtEmailId.Text; 
            com.Parameters.Add("@Import_Credit_Limit", SqlDbType.Decimal).Value =decimal.Parse(txtCreditLimit.Text .ToString());
            com.Parameters.Add("@Agent_Address", SqlDbType.VarChar).Value = txtAddress.Text;
            com.Parameters.Add("@Agent_Phone", SqlDbType.VarChar).Value = txtPhone.Text;
            com.Parameters.Add("@Agent_Contactno", SqlDbType.VarChar).Value = txtContact.Text;
            com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EmailID"].ToString();
            com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
            com.ExecuteNonQuery();
            con.Dispose();
           Response.Redirect("DisplayImport_agent_master.aspx");
        }
        catch (SqlException se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        catch (Exception se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("update import_agent_master set Import_Agent_Name=@Import_Agent_Name,Import_Agent_City=@Import_Agent_City,Import_Agent_Email=@Import_Agent_Email,Import_Credit_Limit=@Import_Credit_Limit,Agent_Address=@Agent_Address,Agent_Phone=@Agent_Phone,Agent_Contactno=@Agent_Contactno,Last_Modified_By=@Last_Modified_By,Last_Modified_On=@Last_Modified_On where Import_Agent_ID=@Import_Agent_ID", con);

            com.Parameters.Add("@Import_Agent_ID", SqlDbType.Int).Value = Request.QueryString["ID"].ToString();
            com.Parameters.Add("@Import_Agent_Name", SqlDbType.VarChar).Value = txtImportAgentName.Text.ToString();
            com.Parameters.Add("@Import_Agent_City", SqlDbType.Int).Value = int.Parse(ddlcity.SelectedValue);
            com.Parameters.Add("@Import_Agent_Email", SqlDbType.VarChar).Value = txtEmailId.Text;
            com.Parameters.Add("@Import_Credit_Limit", SqlDbType.Decimal).Value = decimal.Parse(txtCreditLimit.Text.ToString());
            com.Parameters.Add("@Agent_Address", SqlDbType.VarChar).Value = txtAddress.Text;
            com.Parameters.Add("@Agent_Phone", SqlDbType.VarChar).Value = txtPhone.Text;
            com.Parameters.Add("@Agent_Contactno", SqlDbType.VarChar).Value = txtContact.Text;
            com.Parameters.Add("@Last_Modified_By", SqlDbType.VarChar).Value = Session["EmailID"].ToString();
            com.Parameters.Add("@Last_Modified_On", SqlDbType.DateTime).Value = DateTime.Now;
            com.ExecuteNonQuery();
            con.Dispose();
           Response.Redirect("DisplayImport_agent_master.aspx");

        }

        catch (SqlException se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        catch (Exception se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("DisplayImport_agent_master.aspx");
    }
}
