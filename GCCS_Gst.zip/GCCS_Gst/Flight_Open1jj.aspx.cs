﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Services;

public partial class Flight_Open1jj : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    DateTime openDt;
    string date2 = null;
    string str = "0";
    public string massage = "";
    public string massage1 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Button1.Attributes.Add("onclick", "return CheckEmpty();");

            //Button1.Attributes.Add("onclick", "return CompareDt();");
            if (!IsPostBack)
            {
                lblgv.Visible = false;
                lblgv1.Visible = false;
                ShowAirline();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        flightOpenFillData();
        getData();
    }
    protected void getData()
    {
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            // SqlDataAdapter sda = new SqlDataAdapter("select Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_name as origin,d.destination_name as destination,b.Capacity,convert(Varchar,a.Flight_Date,103)as flightDate1,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id where a.status=6 and (convert(Varchar,a.Flight_Date,103) between '" + (TextBox1.Text) + "' and '" +(TextBox2.Text) + "') and b.airline_detail_id=" + ddlAirlineDetail.SelectedValue + " order by a.Flight_Date ", con);
            SqlDataAdapter sda = new SqlDataAdapter("select Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_code as origin,d.destination_code as destination,b.Capacity,convert(Varchar,a.Flight_Date,103)as flightDate1,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id where a.status=6 and (a.Flight_Date between '" + DateTime.Parse(ConvertDate1(TextBox1.Text)) + "' and '" + DateTime.Parse(ConvertDate1(TextBox2.Text)) + "') and b.airline_detail_id=" + ddlAirlineDetail.SelectedValue + "  and a. flight_open_id not in (" + str + ")order by a.Flight_Date desc ", con);

            DataSet ds = new DataSet();
            sda.Fill(ds);
            gv.DataSource = ds.Tables[0].DefaultView;
            gv.DataBind();

            // ds.Dispose();
            sda.Dispose();
            sda = new SqlDataAdapter("select Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_code as origin,d.destination_code as destination,b.Capacity,convert(Varchar,a.Flight_Date,103)as flightDate1,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id where a.flight_open_id in (" + str + ") order by a.Flight_Date desc ", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count == 0)
            {
                massage = " No Flights due for opening for the period " + TextBox1.Text + " to " + TextBox2.Text + " ";
            }
            gv1.DataSource = dt;
            gv1.DataBind();
            con.Close();
            if (gv.Rows.Count > 0)
            {
                lblgv.Visible = true;
            }
            else
            {
                lblgv.Visible = false;
                //gv.Visible = false;
            }
            if (gv1.Rows.Count > 0)
            {
                lblgv1.Visible = true;
            }
            else
            {
                lblgv1.Visible = false;
            }

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void flightOpenFillData()
    {
        if (IsValid)
        {
            string s = "0";
            DateTime dt1 = DateTime.Parse(ConvertDate1(TextBox1.Text));
            DateTime dt2 = DateTime.Parse(ConvertDate1(TextBox2.Text));
            try
            {
                while (dt1 <= dt2)
                {
                    string[] s1 = dt1.ToLongDateString().Split(',');
                    s = s1[0].ToString();
                    date2 = ConvertDate(ConvertDate1(dt1.ToString().Substring(0, 10)));
                    con = new SqlConnection(strCon);
                    con.Open();
                    //com = new SqlCommand("select a.flight_id,a.flight_Day,a.flight_date,a.flight_time,b.capacity,convert(Varchar,getDate(),101) as FlightDate from flight_details a inner join flight_master b on b.flight_id=a.flight_id where a.status=2 and b.Airline_Detail_ID='" + ddlAirlineDetail.SelectedValue + "' and (flight_Date='" + date2 + "' or flight_Day like '%" + s + "%')", con);
                    //com = new SqlCommand("select a.flight_id,a.flight_Day,a.flight_date,a.flight_time,b.capacity,convert(Varchar,getDate(),101) as FlightDate from flight_details a inner join flight_master b on b.flight_id=a.flight_id where a.status=2 and (flight_Date='" + date2 + "' or flight_Day like '%" + s + "%' ) and b.airline_detail_id=" + ddlAirlineDetail.SelectedValue + " and ('" + ConvertDateFormat1(dt1.ToString().Substring(0, 10)) + "' between convert(Varchar,a.valid_From ,101) and convert(Varchar,a.valid_To ,101) ) ", con);
                    com = new SqlCommand("select a.flight_id,a.flight_Day,a.flight_date,a.flight_time,b.capacity,convert(Varchar,getDate(),101) as FlightDate from flight_details a inner join flight_master b on b.flight_id=a.flight_id where a.status=2 and (flight_Date='" + date2 + "' or flight_Day like '%" + s + "%' ) and b.airline_detail_id=" + ddlAirlineDetail.SelectedValue + " and ('" + dt1 + "' between a.valid_From and a.valid_To ) ", con);
                    // massage = " No flights schedule added for this period";
                    //massage1 = " No Flights due for opening for the period "+TextBox1.Text +" to "+TextBox2.Text +" ";
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        SqlConnection conn1 = new SqlConnection(strCon);
                        conn1.Open();
                        //SqlCommand comm = new SqlCommand("select flight_id,flight_Date from flight_open where flight_id=" + dr[0].ToString() + " and convert(Varchar,Flight_Date,103)='" + ConvertDate1(ConvertDate2(date2)) + "'", conn1);
                        SqlCommand comm = new SqlCommand("select flight_id,flight_Date from flight_open where flight_id=" + dr[0].ToString() + " and convert(Varchar,Flight_Date,103)='" + ConvertDateFormat(dt1.ToString()).Substring(0, 10) + "'", conn1);
                        SqlDataReader dr5 = comm.ExecuteReader();
                        if (dr5.Read())
                        {
                            massage1 = "  Flight already open for this period but cancel  ";
                        }
                        else
                        {
                            string FBookingCode = FlightBookingCode(dr[0].ToString());
                            //DateTime dt = Convert.ToDateTime(dr[5].ToString());
                            //DateTime dt = Convert.ToDateTime(dt1.ToString().Substring(0, 10));
                            DateTime dt = Convert.ToDateTime(dt1);
                            dt = dt.AddDays(10);

                            openDt = Convert.ToDateTime(dr[5].ToString());
                            // string FBookingCode = FlightBookingCode(dr[0].ToString());
                            SqlConnection conn = new SqlConnection(strCon);
                            conn.Open();
                            SqlCommand com1 = new SqlCommand("insert into flight_open(Flight_Booking_Code,Flight_ID,Flight_Day,Flight_Date,Flight_Time,Open_Capacity,Open_Date,Close_Date,Status,Entered_By,Entered_On) values(@Flight_Booking_Code,@Flight_ID,@Flight_Day,@Flight_Date,@Flight_Time,@Open_Capacity,@Open_Date,@Close_Date,@Status,@Entered_By,@Entered_On) ", conn);
                            com1.Parameters.AddWithValue("@Flight_Booking_Code", FBookingCode);
                            com1.Parameters.AddWithValue("@Flight_ID", dr[0].ToString());

                            com1.Parameters.AddWithValue("@Flight_Day", s);
                            //com1.Parameters.Add("@Flight_Date", SqlDbType.DateTime, 8).Value = ConvertDate2(dr[2].ToString());
                            com1.Parameters.Add("@Flight_Date", SqlDbType.DateTime, 8).Value = Convert.ToDateTime(dt1);
                            com1.Parameters.Add("@Flight_Time", SqlDbType.DateTime, 8).Value = Convert.ToDateTime(dr[3].ToString());
                            com1.Parameters.AddWithValue("@Open_Capacity", dr[4].ToString());

                            com1.Parameters.Add("@Open_Date", SqlDbType.DateTime, 8).Value = openDt;
                            com1.Parameters.Add("@Close_Date", SqlDbType.DateTime, 8).Value = dt;
                            com1.Parameters.AddWithValue("@Status", 6);
                            com1.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());

                            com1.Parameters.Add("@Entered_On", SqlDbType.DateTime, 8).Value = openDt;
                            com1.ExecuteNonQuery();
                            com1.Dispose();

                            com1 = new SqlCommand("select ident_current('flight_open')", conn);
                            SqlDataReader dr12 = com1.ExecuteReader();
                            if (dr12.Read())
                            {
                                if (str == "")
                                { str = "'" + dr12[0].ToString() + "'"; }
                                else { str = str + "," + "'" + dr12[0].ToString() + "'"; }

                            }
                            com1.Dispose();
                            conn.Close();

                        }
                        conn1.Close();
                    }
                    dt1 = dt1.AddDays(1);

                }
            }
            catch (Exception se)
            {
                string err = se.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            }
        }
    }
    protected string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Substring(0, 1) == "0")
            Sdate[0] = Sdate[0].Substring(1, 1);
        else
        { Sdate[0] = Sdate[0]; }

        return Sdate[0];

    }
    [WebMethod]
    protected void GetFillData()
    {
        if (IsValid)
        {
            string s = "0";
            DateTime dt1 = DateTime.Parse(ConvertDate1(TextBox1.Text));
            DateTime dt2 = DateTime.Parse(ConvertDate1(TextBox2.Text));
            //DateTime dt1 = DateTime.Parse(ConvertDate1(st1));
            //DateTime dt2 = DateTime.Parse(ConvertDate1(st2));
            try
            {
                while (dt1 <= dt2)
                {
                    string[] s1 = dt1.ToLongDateString().Split(',');
                    s = s1[0].ToString();
                    date2 = ConvertDate(ConvertDate1(dt1.ToString().Substring(0, 10)));
                    con = new SqlConnection(strCon);
                    con.Open();
                    //com = new SqlCommand("select a.flight_id,a.flight_Day,a.flight_date,a.flight_time,b.capacity,convert(Varchar,getDate(),101) as FlightDate from flight_details a inner join flight_master b on b.flight_id=a.flight_id where a.status=2 and b.Airline_Detail_ID='" + ddlAirlineDetail.SelectedValue + "' and (flight_Date='" + date2 + "' or flight_Day like '%" + s + "%')", con);
                    //com = new SqlCommand("select a.flight_id,a.flight_Day,a.flight_date,a.flight_time,b.capacity,convert(Varchar,getDate(),101) as FlightDate from flight_details a inner join flight_master b on b.flight_id=a.flight_id where a.status=2 and (flight_Date='" + date2 + "' or flight_Day like '%" + s + "%' ) and b.airline_detail_id=" + ddlAirlineDetail.SelectedValue + " and ('" + ConvertDateFormat1(dt1.ToString().Substring(0, 10)) + "' between convert(Varchar,a.valid_From ,101) and convert(Varchar,a.valid_To ,101) ) ", con);

                    com = new SqlCommand("select a.flight_id,a.flight_Day,a.flight_date,a.flight_time,b.capacity,convert(Varchar,getDate(),101) as FlightDate from flight_details a inner join flight_master b on b.flight_id=a.flight_id where a.status=2 and (flight_Date='" + date2 + "' or flight_Day like '%" + s + "%' ) and b.airline_detail_id=" + ddlAirlineDetail.SelectedValue + " and ('" + dt1 + "' between a.valid_From and a.valid_To ) ", con);
                    // massage = " No flights schedule added for this period";
                    //massage1 = " No Flights due for opening for the period "+TextBox1.Text +" to "+TextBox2.Text +" ";
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        SqlConnection conn1 = new SqlConnection(strCon);
                        conn1.Open();
                        //SqlCommand comm = new SqlCommand("select flight_id,flight_Date from flight_open where flight_id=" + dr[0].ToString() + " and convert(Varchar,Flight_Date,103)='" + ConvertDate1(ConvertDate2(date2)) + "'", conn1);
                        SqlCommand comm = new SqlCommand("select flight_id,flight_Date from flight_open where flight_id=" + dr[0].ToString() + " and convert(Varchar,Flight_Date,103)='" + ConvertDateFormat(dt1.ToString()).Substring(0, 10) + "'", conn1);
                        SqlDataReader dr5 = comm.ExecuteReader();
                        if (dr5.Read())
                        {
                            massage1 = "  Flight already open for this period but cancel  ";
                        }
                        else
                        {
                            string FBookingCode = FlightBookingCode(dr[0].ToString());
                            //DateTime dt = Convert.ToDateTime(dr[5].ToString());
                            //DateTime dt = Convert.ToDateTime(dt1.ToString().Substring(0, 10));
                            DateTime dt = Convert.ToDateTime(dt1);
                            dt = dt.AddDays(10);

                            openDt = Convert.ToDateTime(dr[5].ToString());
                            // string FBookingCode = FlightBookingCode(dr[0].ToString());
                            SqlConnection conn = new SqlConnection(strCon);
                            conn.Open();
                            SqlCommand com1 = new SqlCommand("insert into flight_open(Flight_Booking_Code,Flight_ID,Flight_Day,Flight_Date,Flight_Time,Open_Capacity,Open_Date,Close_Date,Status,Entered_By,Entered_On) values(@Flight_Booking_Code,@Flight_ID,@Flight_Day,@Flight_Date,@Flight_Time,@Open_Capacity,@Open_Date,@Close_Date,@Status,@Entered_By,@Entered_On) ", conn);
                            com1.Parameters.AddWithValue("@Flight_Booking_Code", FBookingCode);
                            com1.Parameters.AddWithValue("@Flight_ID", dr[0].ToString());

                            com1.Parameters.AddWithValue("@Flight_Day", s);
                            //com1.Parameters.Add("@Flight_Date", SqlDbType.DateTime, 8).Value = ConvertDate2(dr[2].ToString());
                            com1.Parameters.Add("@Flight_Date", SqlDbType.DateTime, 8).Value = Convert.ToDateTime(dt1);
                            com1.Parameters.Add("@Flight_Time", SqlDbType.DateTime, 8).Value = Convert.ToDateTime(dr[3].ToString());
                            com1.Parameters.AddWithValue("@Open_Capacity", dr[4].ToString());

                            com1.Parameters.Add("@Open_Date", SqlDbType.DateTime, 8).Value = openDt;
                            com1.Parameters.Add("@Close_Date", SqlDbType.DateTime, 8).Value = dt;
                            com1.Parameters.AddWithValue("@Status", 6);
                            com1.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());

                            com1.Parameters.Add("@Entered_On", SqlDbType.DateTime, 8).Value = openDt;
                            com1.ExecuteNonQuery();
                            com1.Dispose();
                            com1 = new SqlCommand("select ident_current('flight_open')", conn);
                            SqlDataReader dr12 = com1.ExecuteReader();
                            if (dr12.Read())
                            {
                                if (str == "")
                                { str = "'" + dr12[0].ToString() + "'"; }
                                else { str = str + "," + "'" + dr12[0].ToString() + "'"; }

                            }
                            com1.Dispose();
                            conn.Close();

                        }
                        conn1.Close();
                    }
                    dt1 = dt1.AddDays(1);

                }
            }
            catch (Exception se)
            {
                string err = se.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            }
        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected string ConvertDate2(string strD)
    {
        string[] Sdate = new string[3];
        if (strD != "0")
            Sdate[0] = strD.ToString();
        else
            Sdate[0] = date2;
        Sdate[1] = DateTime.Now.Month.ToString();
        Sdate[2] = DateTime.Now.Year.ToString();
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];

        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat1(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }
    int d;
    protected string FlightBookingCode(string flightid)
    {
        SqlConnection con2 = new SqlConnection(strCon);
        con2.Open();
        string code = null;

        // con = new SqlConnection(strCon);
        //SqlCommand com4 = new SqlCommand("select isnull(max(flight_booking_Code),0) from flight_open where SubString(flight_booking_code,0,4) =(select airline_Code from airline_master where airline_ID=(select airline_ID from  airline_detail where airline_detail_id=(select airline_detail_id from flight_master where flight_id=" + flightid + ")))", con2);        
        SqlCommand com5 = new SqlCommand("select isnull(max(flight_booking_Code),0) from flight_open where SubString(flight_booking_code,0,4) =(select airline_Code from airline_master where airline_ID=(select airline_ID from  airline_detail where airline_detail_id=(select airline_detail_id from flight_master where flight_id=" + flightid + ")))", con2);
        SqlDataReader dr5 = com5.ExecuteReader();

        if (dr5.Read() && dr5[0].ToString() != "0")
        {
            string code1 = dr5[0].ToString();
            string[] bcode = code1.Split('-');

            dr5.Close();
            SqlCommand com4 = new SqlCommand("select isnull(max(abs(cast(SubString(Flight_booking_code,4,50)as int))),1) from flight_open where SubString(flight_booking_code,0,4) =(select airline_Code from airline_master where airline_ID=(select airline_ID from  airline_detail where airline_detail_id=(select airline_detail_id from flight_master where flight_id=" + flightid + ")))", con2);
            SqlDataReader dr4 = com4.ExecuteReader();
            if (dr4.Read())
                d = int.Parse(dr4[0].ToString()) + 1;
            code = bcode[0] + "-" + d;
        }
        else
        {
            com5.Dispose();
            dr5.Dispose();
            com5 = new SqlCommand("select airline_Code from airline_master where airline_ID=(select airline_ID from  airline_detail where airline_detail_id=(select airline_detail_id from flight_master where flight_id=" + flightid + "))", con2);
            dr5 = com5.ExecuteReader();
            if (dr5.Read())
                code = dr5[0].ToString() + "-" + 1;
        }
        return code;

    }
    protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv.PageIndex = e.NewPageIndex;
        getData();
    }
    protected void btnCancel_Click(object o, EventArgs e)
    {
        Button Button1 = (Button)o;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        string strFlightID = grdRow.Cells[0].Text;
        string strFlifgtDate = grdRow.Cells[6].Text;
        //int fl_No = int.Parse(strFlightID.Trim());
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("Update  flight_open set status=7 where flight_id=(select flight_id from flight_master where flight_no='" + strFlightID.Trim() + "') and convert(varchar,flight_Date,103)='" + strFlifgtDate + "'", con);
            int result = com.ExecuteNonQuery();
            com.Dispose();
            con.Close();
            getData();


        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button l = (Button)e.Row.FindControl("btn");

            l.Attributes.Add("onclick", " javascript: return confirm('Are you sure to Cancel? ')");


        }
    }
    protected void ShowAirline()
    {

        ddlAirlineDetail.Items.Clear();

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            // com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and a.airline_id in (" + Session["AIRLINEACCESS"].ToString().Substring(0, +Session["AIRLINEACCESS"].ToString().Length - 1) + ") order by Airline_Name", con);
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineDetail.Items.Add("Select airline name");
            ddlAirlineDetail.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirlineDetail.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}