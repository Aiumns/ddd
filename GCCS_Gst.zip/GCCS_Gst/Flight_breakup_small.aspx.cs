using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
public partial class Flight_breakup_small : System.Web.UI.Page
{

    /// <summary>
    /// 
    /// </description>
    /// <createdBy>--------SHAIKH AKHTAR RASOOL--------</createdBy>
    /// <modified by>Shaikh Akhtar Rasool </modified>
    /// <modifiedon>16-01-2008</modifiedon>
    /// </summary>
    
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        String airline_access = Session["AIRLINEACCESS"].ToString();
        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");

        if (!IsPostBack)
        {

            DateTime DTM;
            DTM = DateTime.Now.AddMonths(6);

            txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txtValidTo.Text = DTM.ToString("dd/MM/yyyy");
            try
            {


              
                //airline_access = airline_access.Substring(0, airline_access.Length - 1);
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));
                }
                cmd.Dispose();
            }
            catch (Exception eror)
            {
                string st = eror.ToString();
            }
            finally
            {
                con.Close();
                cmd.Dispose();
               
            }
        }
    }


    protected void Btnload_Click(object sender, EventArgs e)
    {

        Session["selected_airline_text"] = ddl_airline_city.SelectedItem.Text;
        Session["selected_airline_value"] = ddl_airline_city.SelectedItem.Value;
        Session["from_date"] = txtValidFrom.Text;
        Session["to_date"] = txtValidTo.Text;
        
        string page_pop = "<SCRIPT language='javascript'>window.open('./Reports/flight_breakup_mal.aspx?query=small');</SCRIPT>";
        Response.Write(page_pop);

    }
}
