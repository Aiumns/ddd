using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CSR_Remittence_DetailsShow : System.Web.UI.Page
{

    string strQueryString_Month;
    string strQueryString_Year;
    string strQueryString_FortNight;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        else
        {
            string[] airline_d_id = Session["airline_d_id"].ToString().Split(',');
            decimal Receivable_Amt = 0;
            decimal Total_Receivable_Amt = 0;
            decimal Received_Amt = 0;
            decimal Total_Received_Amt = 0;
            decimal Cheque_Amt = 0;
            decimal Total_Cheque_Amt = 0;
            decimal TDS = 0;
            decimal Total_TDS = 0;
            decimal Short_Excess = 0;
            decimal Total_Short_Excess = 0;
            decimal Service_Tax_Cut_By_Agent = 0;
            decimal SB_Cess_Cut_By_Agent = 0;
            decimal KK_Cess_Cut_By_Agent = 0;
            decimal Total_Service_Tax = 0;
            decimal Total_SB_Cess = 0;
            decimal Total_KK_Cess = 0;
            strQueryString_Month = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "Month");
            strQueryString_Year = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "Year");
            strQueryString_FortNight = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "FortNight");
            TextBox TextBox1 = new TextBox();
            TextBox TextBox2 = new TextBox();
            //TextBox TextBox3 = new TextBox();
            if (strQueryString_FortNight == "1")
            {

                TextBox1.Text = strQueryString_Month + "/01/" + strQueryString_Year;
                TextBox2.Text = strQueryString_Month + "/15/" + strQueryString_Year;

            }
            if (strQueryString_FortNight == "2")
            {


                if (strQueryString_Month == "1")
                {

                    TextBox2.Text = "01/31/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "2")
                {

                    if (DateTime.IsLeapYear(int.Parse(strQueryString_Year)))
                        TextBox2.Text = "02/29/" + strQueryString_Year;
                    else
                    { TextBox2.Text = "02/28/" + strQueryString_Year; }

                }
                else if (strQueryString_Month == "3")
                {

                    TextBox2.Text = "03/31/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "4")
                {

                    TextBox2.Text = "04/30/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "5")
                {

                    TextBox2.Text = "05/31/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "6")
                {

                    TextBox2.Text = "06/30/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "7")
                {

                    TextBox2.Text = "07/31/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "8")
                {

                    TextBox2.Text = "08/31/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "9")
                {

                    TextBox2.Text = "09/30/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "10")
                {

                    TextBox2.Text = "10/31/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "11")
                {

                    TextBox2.Text = "11/30/" + strQueryString_Year;

                }
                else if (strQueryString_Month == "12")
                {

                    TextBox2.Text = "12/31/" + strQueryString_Year;

                }

                TextBox1.Text = strQueryString_Month + "/16/" + strQueryString_Year;

            }
            Label1.Text = "<table width=100% cellpadding=1 cellspacing=1 align=center class=text><tr align=center class=text><th>CSR Remittence Details</th></tr><tr><th>" + FormatDateMM(TextBox1.Text) + " - " + FormatDateMM(TextBox2.Text) + "</th></tr></table>";
            //Label1.Text = "<h5>CSR Remittence Details </h5> " + FormatDateMM(TextBox1.Text) + " - " + FormatDateMM(TextBox2.Text) + "";

            string Table1 = "";
            string Query = "";
            if (airline_d_id[0] == "0")
            {
                Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ") order by airline_name";
            }
            else
            {
                Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + airline_d_id[0].ToString() + ") order by airline_name";
            }

            Int32 count = 1;
            DataTable dt = dw.GetAllFromQuery(Query);
            foreach (DataRow drow in dt.Rows)
            {
                Table1 += "<table width=100% border=1 align=center cellpadding=0 cellspacing=0 class=text><tr class=h5><th colspan=12  align=center>" + drow["airline_code"].ToString() + "-" + drow["airline_name"].ToString() + "-" + drow["city_code"].ToString() + "</td></tr><tr class=h5><th align=center>S.NO</th><th  align=center>Agent Name</th><th  align=center>Receivable</th><th  align=center>Received</td><th  align=center>Cheque Amt</th><th  align=center>Service Tax Cut<br> by Agent</th><th  align=center>SB Cess Cut<br> by Agent</th><th  align=center>KK Cess Cut<br> by Agent</th><th align=center>TDS</th><th  align=center>Short/<br>Excess</th><th  align=center>Date</th><th  align=center>Remarks</th></tr>";

                Query = "select CD.Agent_Name as Agent_Name,CD.Amount_Including_TDS as Amount_Including_TDS,CD.Paid_Amount as Paid_Amount,PD.Paid_Amount as Cheque_Amt,PD.TDS_Cut_By_Agent as TDS_Cut_By_Agent,PD.Service_Tax_Cut_By_Agent AS Service_Tax_Cut_By_Agent,isnull(PD.SB_Cess,0) AS SB_Cess_Cut_By_Agent,isnull(PD.KK_Cess,0) AS KK_Cess_Cut_By_Agent, PD.Short_Excess as Short_Excess_Amount,convert(varchar,PD.Entered_Date,103) as Entered_Date,PD.Remarks as Remarks,*from csr_details CD inner join payment_details PD on  CD.CSR_Detail_ID=PD.CSR_Detail_ID  where PD.csr_from='" + TextBox1.Text.Trim() + "' and PD.csr_to='" + TextBox2.Text.Trim() + "' and PD.airline_detail_id=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " ORDER BY CD.AGENT_NAME";
                DataTable dt_cal = dw.GetAllFromQuery(Query);
                count = 1;

                if (dt_cal.Rows.Count > 0)
                {
                    string tempAgent = "";
                    string tempagent2 = "";
                    foreach (DataRow dro in dt_cal.Rows)
                    {
                     
                        Cheque_Amt = Convert.ToDecimal(dro["Cheque_Amt"].ToString());
                        Total_Cheque_Amt = Total_Cheque_Amt + Cheque_Amt;
                        TDS = Convert.ToDecimal(dro["TDS_Cut_By_Agent"].ToString());
                        Service_Tax_Cut_By_Agent = Convert.ToDecimal(dro["Service_Tax_Cut_By_Agent"].ToString());
                        SB_Cess_Cut_By_Agent = Convert.ToDecimal(dro["SB_Cess_Cut_By_Agent"].ToString());
                        KK_Cess_Cut_By_Agent = Convert.ToDecimal(dro["KK_Cess_Cut_By_Agent"].ToString());
                        Total_Service_Tax = Total_Service_Tax + Service_Tax_Cut_By_Agent;
                        Total_SB_Cess = Total_SB_Cess + SB_Cess_Cut_By_Agent;
                        Total_KK_Cess = Total_KK_Cess + KK_Cess_Cut_By_Agent;
                        Total_TDS = Total_TDS + TDS;
                        Short_Excess = Convert.ToDecimal(dro["Short_Excess_Amount"].ToString());
                        Total_Short_Excess = Total_Short_Excess + Short_Excess;
                        tempAgent = dro["agent_name"].ToString();
                        if (tempAgent == tempagent2)
                        {
                            Receivable_Amt = 0;
                            Total_Receivable_Amt = Total_Receivable_Amt + Receivable_Amt;
                            Received_Amt = 0;
                            Total_Received_Amt = Total_Received_Amt + Received_Amt;
                           // tempagent2 = tempAgent;
                        }
                        else
                        {
                            Receivable_Amt = Convert.ToDecimal(dro["Amount_Including_TDS"].ToString());
                            Total_Receivable_Amt = Total_Receivable_Amt + Receivable_Amt;
                            Received_Amt = Convert.ToDecimal(dro["Paid_Amount"].ToString());
                            Total_Received_Amt = Total_Received_Amt + Received_Amt;
                           // tempagent2 = tempAgent;
                        }

                        if (tempAgent == tempagent2)
                        {



                            Table1 += "<tr class=text><td  align=center class=boldtext>" + count + "</td><td  align=left class=boldtext>''</td><td  align=right class=text>&nbsp;</td><td  align=right class=text>&nbsp;</td><td  align=right class=text>" + Cheque_Amt + "</td><td  align=right class=text>" + Service_Tax_Cut_By_Agent + "</td><td  align=right class=text>" + SB_Cess_Cut_By_Agent + "</td><td  align=right class=text>" + KK_Cess_Cut_By_Agent + "</td><td  align=right class=text>" + Math.Ceiling(TDS) + "</td><td  align=right class=text nowrap> " + Short_Excess + " </td><td  align=left class=text>" + dro["Entered_Date"].ToString() + "</td><td  align=left class=text>&nbsp; " + dro["Remarks"].ToString() + " </td></tr>";
                            tempagent2 = tempAgent;
                        }
                        else
                        {
                            Table1 += "<tr class=text><td  align=center class=boldtext>" + count + "</td><td  align=left class=boldtext>" + dro["agent_name"].ToString() + "</td><td  align=right class=text>" + Receivable_Amt + "</td><td  align=right class=text>" + Received_Amt + "</td><td  align=right class=text>" + Cheque_Amt + "</td><td  align=right class=text>" + Service_Tax_Cut_By_Agent + "</td><td  align=right class=text>" + SB_Cess_Cut_By_Agent + "</td><td  align=right class=text>" + KK_Cess_Cut_By_Agent + "</td><td  align=right class=text>" + Math.Ceiling(TDS) + "</td><td  align=right class=text nowrap> " + Short_Excess + " </td><td  align=left class=text>" + dro["Entered_Date"].ToString() + "</td><td  align=left class=text>&nbsp; " + dro["Remarks"].ToString() + " </td></tr>";
                            tempagent2 = tempAgent;

                        }

                        count++;

                    }
                }
                else
                {
                    Table1 += "<tr class=text><td  align=center colspan=11 class=error>NO RECORD FOUND FOR THIS AIRLINE</td></tr>";
                }
                Table1 += "<tr  class=h1><td  align=right colspan=2 class=boldtext>Total</td><td  align=right class=boldtext> " + Total_Receivable_Amt + " </td><td  align=right class=boldtext> " + Total_Received_Amt + " </td><td  align=right class=boldtext> " + Total_Cheque_Amt + " </td><td  align=right class=boldtext> " + Total_Service_Tax + " </td><td  align=right class=boldtext> " + Total_SB_Cess + " </td><td  align=right class=boldtext> " + Total_KK_Cess + " </td><td  align=right class=boldtext> " + Math.Ceiling(Total_TDS) + " </td><td  align=right class=boldtext nowrap> " + Total_Short_Excess + " </td><td  align=left class=boldtext> </td><td  align=left class=boldtext> </td></tr>";
                Total_Receivable_Amt = 0;
                Total_Received_Amt = 0;
                Total_Cheque_Amt = 0;
                Total_TDS = 0;
                Total_Short_Excess = 0;
                Total_Service_Tax = 0;
                Total_SB_Cess= 0;
                Total_KK_Cess = 0;
                Table1 += "</table><br>";
            }
            Label2.Text += Table1;
        }

    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateDD(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
