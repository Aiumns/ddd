using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
// This page view only agent login;

public partial class AmendmentChrgColl_Agent : System.Web.UI.Page
{
     string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");
            
            if (!IsPostBack)
            {               
                ShowAirline();
            }
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int Result;
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("Collection_Charges_INSERT", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Agent_ID", Session["ID"].ToString());
        com.Parameters.AddWithValue("@Airline_Detail_ID", ddlAirLine.SelectedValue.ToString());
        com.Parameters.AddWithValue("@AWBNo",ddlAwbno.SelectedValue.ToString());
        com.Parameters.AddWithValue("@Request",ddlRequest.SelectedValue.ToString());
        com.Parameters.AddWithValue("@Remarks",txtRemarks.Text);
        com.Parameters.AddWithValue("@AddedBy", Session["EMailID"].ToString());
        com.Parameters.AddWithValue("@AddedDate",DateTime.Today);
        com.Parameters.AddWithValue("@Status","Requested");
        Result = com.ExecuteNonQuery();
        if (Result == 1)
        {
            lblMsg.Text = "Your Amendment request has been sent to Customer Care. You will be conatacted very soon.";
            
        }        

    }

    protected void ShowAirline()
    {
        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {            
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirLine.Items.Add("-Select Airline Name-");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        DateTime dt = DateTime.Parse(DateTime.Today.AddDays(-60).ToShortDateString());
        string query = "select b.airWayBill_no from handOver a inner join Stock_Master b on a.Stock_id=b.Stock_id inner join agent_master am on am.agent_ID=b.agent_ID inner join Agent_Branch ab  on ab.agent_ID=am.agent_ID  where Flight_open_ID in(Select Flight_Open_ID from Flight_open where Flight_ID in (select Flight_ID from Flight_master where AirLine_Detail_id=" + ddlAirLine.SelectedValue.ToString() + ")) and  Handover_date >'" + dt + "' and ab.agent_Branch_ID='" + Session["ID"].ToString() + "' and b.Status not in (17,12)";
        ddlAwbno.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand(query,con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAwbno.Items.Add("-Select AWBNo-");
            ddlAwbno.Items[0].Value = "";
            if (dr.HasRows==true)
            {
                while (dr.Read())
                {
                    ddlAwbno.Items.Add(new ListItem(dr["AirWayBill_No"].ToString(), dr["AirWayBill_No"].ToString()));
                }
            }
            else
            {
                lblMsg.Text = "Not found any AWBNo";
                return;
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAwbno_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
