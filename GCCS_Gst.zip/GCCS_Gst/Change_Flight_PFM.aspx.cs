using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Change_Flight_PFM : System.Web.UI.Page
{
    SqlConnection con = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    int HANDOVER_ID;
    int FLIGHT_OPEN_ID;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {

            Search();
        }
    }
    private void Search()
    {
        string flightDate = "";
        string Data = "";
        string airline = "";
          string Var_B_id = Request.QueryString["BID"];
            string[] Arr_B_Id = Var_B_id.Split('-');
            string BOOKING_ID= Arr_B_Id[0];
            string Stock_ID = Arr_B_Id[1];
            string Airline_Detail_ID = Request.QueryString["AID"];

       
        DataTable dt = dw.GetAllFromQuery("SELECT  cast(BOOKING_ID as varchar(30))+'-'+cast(Stock_ID as varchar(30)) as BSID, AirWayBill_No,FLIGHT_NO,CONVERT(VARCHAR,FLIGHT_DATE,103) AS FLIGHT_DATE,Gross_Weight,Destination_CODE FROM PFM P  INNER JOIN FLIGHT_OPEN FO ON FO.Flight_Open_ID=P.Flight_Open_ID INNER JOIN FLIGHT_MASTER FM ON FO.Flight_ID=FM.Flight_ID INNER JOIN DESTINATION_MASTER DM ON P.Destination_ID=DM.Destination_ID WHERE Stock_ID NOT IN(SELECT Stock_ID FROM SALES)  AND BOOKING_ID='" + BOOKING_ID + "'");
        if (dt.Rows.Count > 0)
        {
            Data = "<Table align=center width=70%><tr class=h1><td class=boldtext>Awb No.</td><td class=boldtext>Dstn.</td><td class=boldtext>Gr.Wt.</td><td class=boldtext>Current Flight No.</td><td class=boldtext>Current Flight Date</td></tr>";
            foreach (DataRow drow in dt.Rows)
            {
                Data += "<tr><td>" + drow["AirWayBill_No"].ToString() + "</td><td>" + drow["Destination_CODE"].ToString() + "</td><td>" + drow["Gross_Weight"].ToString() + "</td><td>" + drow["FLIGHT_NO"].ToString() + "</td><td>" + drow["FLIGHT_DATE"].ToString() + "</td></tr>";
                flightDate = drow["FLIGHT_DATE"].ToString();
              
            }
            Data += "<tr><td></td><td></td><td></td><td></td><td></td></tr></table>";
            Label2.Text = Data;

            DataTable dt2 = dw.GetAllFromQuery("select Flight_no+'-'+convert(varchar,flight_date,103) as flight_date,FLIGHT_open_ID from Flight_Open inner join flight_master on Flight_Open.flight_id=flight_master.flight_id where flight_date BETWEEN Convert(datetime,'" + DateTime.Now.ToString("MM/dd/yyyy") + "') AND  Convert(datetime,'" + DateTime.Now.ToString("MM/dd/yyyy") + "')+15 and airline_detail_id=" + Convert.ToInt64(Airline_Detail_ID) + " AND (FLIGHT_open_ID NOT IN ("+Request.QueryString["fid"]+")) ORDER BY flight_date ASC");
            ddlflight.Items.Clear();
            foreach (DataRow Drow in dt2.Rows)
            {
                ddlflight.Items.Add(new ListItem(Drow["flight_date"].ToString(), Drow["FLIGHT_open_ID"].ToString()));

            }
            Label3.Visible = false;
            Panel1.Visible = true;

        }
        else
        {
            Label3.Visible = false;
            Panel1.Visible = false;
            Label2.Text = "";
            Label2.Text = "No Record Found";
            Label2.CssClass = "error";
            Label2.Visible = true;
            Label3.Visible = false;

        }
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string[] flight_date_no = ddlflight.SelectedItem.Text.Split('-');
        string Modified_By = Session["EMailID"].ToString();
        con = new SqlConnection(strCon);
        con.Open();
        FLIGHT_OPEN_ID = Convert.ToInt32(ddlflight.SelectedItem.Value);
     
        try
        {
            string Var_B_id = Request.QueryString["BID"];
            string[] Arr_B_Id = Var_B_id.Split('-');
            string BOOKING_ID = Arr_B_Id[0];        
          

            SqlCommand strcom = new SqlCommand("CHANGE_FLIGHT_AFTER_PFM", con);
            strcom.CommandType = CommandType.StoredProcedure;

            strcom.Parameters.AddWithValue("@FLIGHT_OPEN_ID", FLIGHT_OPEN_ID);
            strcom.Parameters.AddWithValue("@FLIGHT_DATE", FormatDateMM(flight_date_no[2]));
            strcom.Parameters.AddWithValue("@BOOKING_ID", BOOKING_ID);
            strcom.Parameters.AddWithValue("@Modified_By", Modified_By);
           // strcom.Parameters.AddWithValue("@Modified_On", DateTime.Now.ToString("MM/dd/yyyy"));
            strcom.ExecuteNonQuery();
            Label3.Visible = true;
            Panel1.Visible = false;
            Label2.Text = "";
            Button1.Visible = true;
            
        }
        catch (Exception)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        string CITY_ID = Request.QueryString["city_id"];
        string Air_code = Request.QueryString["Airline_code"];
        string Flight_Open_ID = ddlflight.SelectedItem.Value;
        string Airline_Detail_ID = Request.QueryString["AID"];
        string[] FDATE = ddlflight.SelectedItem.Text.Split('-');
        string FNo = FDATE[0] + "-" + FDATE[1];
        Response.Redirect("PFM_Details.aspx?city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_ID + "&AID=" + Airline_Detail_ID + "&fno=" + FNo + "&date=" + (FDATE[2]) + "");
        con.Close();
    }
}
