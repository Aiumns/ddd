﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Net.Mime;



public partial class AutoAgentmail : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSendMail_Click(object sender, EventArgs e)
    {
        ////sendmail("Mail");
        //////DataTable AgentMail = dw.GetAllFromQuery("SELECT DISTINCT email_id FROM dbo.Login_Master WHERE Group_ID=5 AND Login_Master_ID IN (395,396)");

        ///////////////send();

        #region Send Mail to Agent Code Below
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("Auto_MailToAgent", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dtAgentMail = new DataTable();
        da.Fill(dtAgentMail);

        if (dtAgentMail.Rows.Count > 0)
        {
            for (int i = 0; i < dtAgentMail.Rows.Count; i++)
            {
                sendmail(dtAgentMail.Rows[0]["email_id"].ToString());
            }

        }
        com.Dispose();
        con.Close();


        #endregion SendMail Code end

    }
    private AlternateView getEmbeddedImage(String filePath)
    {
        LinkedResource inline = new LinkedResource(filePath);
        inline.ContentId = Guid.NewGuid().ToString();
        string htmlBody = @"<img src='cid:" + inline.ContentId + @"'/>";
        AlternateView alternateView = AlternateView.CreateAlternateViewFromString(htmlBody, null, MediaTypeNames.Text.Html);
        alternateView.LinkedResources.Add(inline);
        return alternateView;
    }

    ////protected void send()
    ////{
    ////    MailMessage mail = new MailMessage();
    ////    mail.IsBodyHtml = true;
    ////   var inlineLogo = new LinkedResource(Server.MapPath("~/Images/cargoflashInv.jpg"));
    ////   inlineLogo.ContentId = Guid.NewGuid().ToString();
    ////   string body = string.Format(@"<b>Dear Invitee,</b><br/> We are heartly welcome you to join the Cargo fair: <br/><br/><img src=""cid:{0}"" /> <br/><br/><br/>Thanks!<br/><b>Team Cargoflash!</b>", inlineLogo.ContentId);
    ////   var view = AlternateView.CreateAlternateViewFromString(body, null, "text/html");
    ////   view.LinkedResources.Add(inlineLogo);
    ////   mail.AlternateViews.Add(view);

    ////    mail.From = new MailAddress("ddalal@cargoflash.com");
    ////    mail.To.Add("ddalal@cargoflash.com,ddalal@cargoflash.com");
    ////    mail.Subject = "Cargo Fair Invitation";

    ////    //
    ////    SmtpClient smtp = new SmtpClient("mail.cargoflash.com");
    ////    smtp.Credentials = new NetworkCredential("test@cargoflash.com", "Admin$567");
    ////    smtp.Send(mail);
    ////}


    protected void send()
    {
        ////MailMessage mail = new MailMessage();
        ////mail.IsBodyHtml = true;
        ////var inlineLogo = new LinkedResource(Server.MapPath("~/Images/ACEMailer.jpg"));
        ////inlineLogo.ContentId = Guid.NewGuid().ToString();
        /////////string body = string.Format(@"<b>Dear Natasha,</b><br/> We are heartly welcome you to join the Air Cargo Fair Europe as per below invitation: <br/><br/><img src=""cid:{0}"" /> <br/><br/><br/>Thanks!<br/><b>Team Cargoflash!</b>", inlineLogo.ContentId);
        ////DataTable dtMailer = dw.GetAllFromQuery("Select * from CfMailer");
        ////if (dtMailer.Rows.Count > 0)
        ////{
        ////    for (int i = 0; i < dtMailer.Rows.Count; i++)
        ////    {
        ////        //string name = dtMailer.Rows[i]["Name"].ToString();
        ////        string body = string.Format(@"<b>Dear " + dtMailer.Rows[i]["Name"].ToString() + ",");
        ////        string body1 = string.Format(@"</b><br/>We would love to meet you in Munich at Booth 437.<br/><br/><img src=""cid:{0}"" /> <br/><br/><br/>Best regards<br/><b>Rahim Bhimani</b><br/>CEO | Cargo Flash InfoTech<br/>Land Line : +91 124 712 5027 | Mobile : +91 9643 78 7474<br/>Email : Rahim@cargoflash.com<br/>Http://www.cargoflash.com<br/>Creating Value", inlineLogo.ContentId);
        ////        string Wholebody = body + body1;
        ////        ////string body = string.Format(@"<b>Dear Mahesh Vemula,</b><br/>We would love to meet you in Munich at Booth 437.<br/><br/><img src=""cid:{0}"" /> <br/><br/><br/>Best regards<br/><b>Rahim Bhimani</b><br/>CEO | Cargo Flash InfoTech<br/>Land Line : +91 124 712 5027 | Mobile : +91 9643 78 7474<br/>Email : Rahim@cargoflash.com<br/>Http://www.cargoflash.com<br/>Creating Value", inlineLogo.ContentId);
        ////        ////string body = string.Format(@"<b>Dear Invitee,</b><br/>We are heartly welcome you to join the Air Cargo Fair Europe as per below invitation: <br/><br/><img src=""cid:{0}"" /> <br/><br/><br/>Thanks!<br/><b>Team Cargoflash!</b>", inlineLogo.ContentId);
        ////        var view = AlternateView.CreateAlternateViewFromString(body + body1, null, "text/html");
        ////        view.LinkedResources.Add(inlineLogo);
        ////        mail.AlternateViews.Add(view);

        ////        ////mail.From = new MailAddress("Rahim@cargoflash.com");
        ////        ////mail.To.Add("" + dtMailer.Rows[i]["Email"].ToString() + "");
        ////        //// mail.CC.Add("natasha@groupconcorde.com");
        ////        mail.From = new MailAddress("ddalal@cargoflash.com");
        ////        mail.To.Add("ddalal@groupconcorde.com");
        ////        mail.Bcc.Add("ddalal@groupconcorde.com");
        ////        mail.Subject = "For Innovative Cargo Solutions - Meet Cargo Flash at Booth. 437";


        ////        SmtpClient smtp = new SmtpClient("mail.cargoflash.com");
        ////        smtp.Credentials = new NetworkCredential("test@cargoflash.com", "Admin$567");
        ////        smtp.Send(mail);
        ////        mail.AlternateViews.Clear();
        ////        mail.To.Clear();
        ////        mail.CC.Clear();
        ////    }

        ////}
    }



    protected void sendmail(string email)
    {

        try
        {
            MailMessage mail = new MailMessage();
            mail.IsBodyHtml = true;
            string body = string.Format(@"<b>Dear Sir</b>,<br/><br/>As decided by GST council (Government of India) meeting held on 18.06.2017, GST will be implemented wef 01.07.2017. As per Sec12(8) of IGST Act, as the service provider and the service receiver both are located in taxable territory of India, transportation of goods from India to outside India would be taxable.<br/><br/>Accordingly wef 01.07.2017, Export Air Freight will be taxable under GST and GST will be charged @18% on Freight plus Due Carrier minus Discount. IATA commission will be shown in CSR/Tax Invoice for the calculation of Net receivable. Further IATA agent will raise invoice for IATA commission along with GST after the fortnight as it is sale/income of IATA agents in order to claim GST.<br/><br/>Thanks & Regards! <Br/> Team GroupConcorde! <Br/> Finanace Department!");
            mail.From = new MailAddress("info@groupconcorde.com");
            ////mail.To.Add("ddalal@cargoflash.com");
            mail.Bcc.Add(email);
            mail.Subject = "GST Alert";
            mail.Body = body;

            SmtpClient smtp = new SmtpClient("mail.cargoflash.com");
            smtp.Credentials = new NetworkCredential("test@cargoflash.com", "Admin$567");
            smtp.Send(mail);
            mail.AlternateViews.Clear();
            mail.To.Clear();
            mail.CC.Clear();

        }

        catch (Exception ex)
        {
            Response.Write("<script>alert(" + ex.Message + ");</script>");
        }
    }
}
