using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Handover_Edit : System.Web.UI.Page
{
    DirectHandoverClass DHandover = new DirectHandoverClass();
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    int NA = 0;
    SqlDataReader red;
    SqlTransaction trans;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

        HtmlGenericControl body = (HtmlGenericControl)Page.Master.FindControl("MyBody");

        //body.Attributes.Add("onload", "Change()");


        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (chkbxShowDetails.Checked == true)
            {
                pnlShowDetails.Visible = true;
            }
            else
            {
                pnlShowDetails.Visible = false;
            }

            ViewState["edit"] = "0";
            ViewState["et"] = "1";
            if (!IsPostBack)
            {
                txtValuationCharge.Attributes.Add("onblur", "Valuation()");
                txtTax.Attributes.Add("onblur", "Tax()");
                Session["dtOtherCharges"] = null;
                Session["dtTemp"] = null;
                Session["dtTem"] = null;
                Session["dtOther"] = null;
                //txthandover_date.Text = FormatDateMM(Convert.ToString(DateTime.Now.ToShortDateString()));
                txtAWBDate.Text = FormatDateMM(Convert.ToString(DateTime.Now.ToShortDateString()));
                maketableVolumewt();
                grdCal.DataSource = (DataTable)Session["dtTemp"];
                grdCal.DataBind();
                MakeTable();
                DataTable dt = (DataTable)Session["dtOtherCharges"];
                grd.Visible = true;
                grd.DataSource = dt;
                grd.DataBind();

                pnlHandoverDetails.Visible = false;

                LoadShipmentType();
                LoadOrigin();
                LoadCommodity();
                LoadDestination();
              

            }
            if (!Page.IsPostBack && Request.QueryString["Booking_ID"] != null)
            {
                btnFill.Visible = false;
                getBookingDetails();
                btnUpdate.Visible = false;
                pnlHandoverDetails.Visible = true;


            }
            if (!Page.IsPostBack && Request.QueryString["Handover_ID"] != null)
            {
                btnFill.Visible = false;
                getHandoverDetails();
                btnUpdate.Visible = true;
                pnlHandoverDetails.Visible = true;
            
            }
        }
    }
    protected void CheckFlightClose()
    {
        string airlineID = "";
        string airDetailID = "";
        string awbNo = txtAWBNo.Text;
        string cityID = "";
        string strCheckCity = "";
        //CHECK FOR AWB NO. EXISTS OR NOT
        if (Request.QueryString["Handover_ID"] != null)
        {
            strCheckCity = "select * from stock_master S inner join Agent_master A on S.agent_Id = A.Agent_ID inner join city_master C on S.city_ID = C.city_ID where AirWayBill_No = '" + awbNo + "'";
        }
        if (Request.QueryString["Booking_ID"] != null)
        {
            strCheckCity = "select * from stock_master S inner join Agent_master A on S.agent_Id = A.Agent_ID inner join city_master C on S.city_ID = C.city_ID where AirWayBill_No = '" + awbNo + "' and (status = '16' or status = '9' )";
        }

        DataTable dtCityID = dw.GetAllFromQuery(strCheckCity);
        if (dtCityID.Rows.Count > 0)
        {
            cityID = dtCityID.Rows[0]["City_ID"].ToString();
            ViewState["CityID"] = cityID;
        }

        string airlineCode = txtAWBNo.Text.Trim();
        airlineCode = airlineCode.Substring(0, 3);
        DataTable dtAirlineID = dw.GetAllFromQuery("select airline_id from airline_master where airline_code = '" + airlineCode + "'");
        if (dtAirlineID.Rows.Count > 0)
        {
            airlineID = dtAirlineID.Rows[0]["Airline_ID"].ToString();
            //ViewState["Airlilne"] = airlineID;
        }

        DataTable dtAirlineDetail = dw.GetAllFromQuery("select * from airline_detail where airline_Id = '" + airlineID + "' and belongs_to_City = '" + cityID + "'");
        if (dtAirlineDetail.Rows.Count > 0)
        {
            airDetailID = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();

        }
        DateTime fltclodedate = System.DateTime.Today;
    
        DataTable selectflt = dw.GetAllFromQuery("select b.Flight_No +'('+convert(varchar,a.Flight_date,103)+')' as Fldate,Convert(varchar,a.Close_date,103) as CloseDate,a.Flight_Open_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id  where b.Airline_Detail_ID='" + airDetailID + "' and a.Close_Date >= '" + fltclodedate + "' and  b.status=2 and flight_no='" + txtFlightNo.Text + "' and Flight_Open_ID='" + hdnfldFlightOpenId.Value + "'  order by a.Flight_date desc");

        if (selectflt.Rows.Count > 0)
        {
            ShowFlightOpen();
        }
        else
        {
            ddlflightOpen.Visible = false;
            lblopenflt.Visible = false;
        }

        con.Close();

    }
    protected void ShowFlightOpen()
    {
        string airlineID = "";
        string airDetailID = "";
        string awbNo = txtAWBNo.Text;
        string cityID = "";
        string strCheckCity = "";
        //CHECK FOR AWB NO. EXISTS OR NOT
        if (Request.QueryString["Handover_ID"] != null)
        {
            strCheckCity = "select * from stock_master S inner join Agent_master A on S.agent_Id = A.Agent_ID inner join city_master C on S.city_ID = C.city_ID where AirWayBill_No = '" + awbNo + "'";
        }
        if (Request.QueryString["Booking_ID"] != null)
        {
            strCheckCity = "select * from stock_master S inner join Agent_master A on S.agent_Id = A.Agent_ID inner join city_master C on S.city_ID = C.city_ID where AirWayBill_No = '" + awbNo + "' and (status = '16' or status = '9' )";
        }
        DataTable dtCityID = dw.GetAllFromQuery(strCheckCity);
        if (dtCityID.Rows.Count > 0)
        {
            cityID = dtCityID.Rows[0]["City_ID"].ToString();
            ViewState["CityID"] = cityID;
        }
        string airlineCode = txtAWBNo.Text.Trim();
        airlineCode = airlineCode.Substring(0, 3);
        DataTable dtAirlineID = dw.GetAllFromQuery("select airline_id from airline_master where airline_code = '" + airlineCode + "'");
        if (dtAirlineID.Rows.Count > 0)
        {
            airlineID = dtAirlineID.Rows[0]["Airline_ID"].ToString();
            //ViewState["Airlilne"] = airlineID;
        }
        DataTable dtAirlineDetail = dw.GetAllFromQuery("select * from airline_detail where airline_Id = '" + airlineID + "' and belongs_to_City = '" + cityID + "'");
        if (dtAirlineDetail.Rows.Count > 0)
        {
            airDetailID = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
        }
        DateTime dateClose = System.DateTime.Today;
        string strflt = "select b.Flight_No +'('+convert(varchar,a.Flight_date,103)+')' as Fldate,Convert(varchar,a.Close_date,103) as CloseDate,a.Flight_Open_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id  where b.Airline_Detail_ID='" + airDetailID + "' and a.Close_Date >= '" + dateClose + "' and  b.status=2 order by a.Flight_date desc";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand(strflt, con);
        SqlDataReader dr = com.ExecuteReader();
        //ddlflightOpen.Items.Clear();
        while (dr.Read())
        {
            ddlflightOpen.Items.Add(new ListItem(dr["Fldate"].ToString(), dr["Flight_Open_ID"].ToString()));
        }
        dr.Close();
        DataTable selectflt = dw.GetAllFromQuery("select b.Flight_No +'('+convert(varchar,a.Flight_date,103)+')' as Fldate,Convert(varchar,a.Close_date,103) as CloseDate ,a.Flight_Open_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id  where b.Airline_Detail_ID='" + airDetailID + "' and Flight_Open_ID='" + hdnfldFlightOpenId.Value + "'");
        string q = "";
        if (selectflt.Rows.Count > 0)
        {
            q=selectflt.Rows[0]["Flight_Open_ID"].ToString();           
        }
        for (int p = 0; p <= (ddlflightOpen.Items.Count - 1); p++)
        {
            if (ddlflightOpen.Items[p].Value == q)
            {
                ddlflightOpen.Items[p].Selected = true;
            }
        }
        con.Close();
    }
    public void getHandoverDetails()
    {
        string handoverId = Request.QueryString["Handover_ID"].ToString();
        //string handoverId = ParamUtils.WebParam.GetQuery(Request.Params["Handover_ID"].ToString(), "id");


        //***************Added on 7 april 2011(For Airline_Detail_Id)****************

        DataTable dtAid = dw.GetAllFromQuery("select hm.city_id,SUBSTRING(sm.airwaybill_no,0,4) AS Airline_code from Handover hm inner join stock_master sm on hm.stock_id=sm.stock_id where Handover_Id = '" + handoverId + "'");
        if (dtAid.Rows.Count > 0)
        {
            DataTable dtAirlineDetailID = dw.GetAllFromQuery("select airline_detail_id from airline_detail ad inner join airline_master am on ad.airline_id=am.airline_id where ad.belongs_to_city=" + dtAid.Rows[0]["city_id"].ToString() + " and am.airline_code='" + dtAid.Rows[0]["Airline_code"].ToString() + "'");

            hdnAirlineDetailId.Value = dtAirlineDetailID.Rows[0]["airline_detail_id"].ToString();
        }


        //*****************End******************************************************




        con = new SqlConnection(strCon);
        string strHandoverDetail = "select * from Handover H inner join Stock_Master S on H.Stock_Id = S.Stock_Id where Handover_Id = '" + handoverId + "'";
        con.Open();
        SqlDataAdapter daHandoverDetail = new SqlDataAdapter(strHandoverDetail, con);
        DataSet dsHandoverDetail = new DataSet();
        daHandoverDetail.Fill(dsHandoverDetail);
        DateTime HandoverDate = Convert.ToDateTime(dsHandoverDetail.Tables[0].Rows[0]["Handover_Date"].ToString());  
        ViewState["Handover_DATE"] = HandoverDate.ToShortDateString();
        txthandover_date.Text = ViewState["Handover_DATE"].ToString();
        txtAWBNo.Text = dsHandoverDetail.Tables[0].Rows[0]["AirwayBill_No"].ToString();
        txtAWBNo.ReadOnly = true;
        ViewState["hStockId"] = dsHandoverDetail.Tables[0].Rows[0]["Stock_ID"].ToString();
        DataTable dtAgent = dw.GetAllFromQuery("select Agent_ID From Stock_Master where stock_ID=" + ViewState["hStockId"].ToString());
        ViewState["Agent_ID"] = dtAgent.Rows[0]["Agent_ID"].ToString();
        con.Close();
        fillDestination();
        FillHandoverDetails();
        CheckFlightClose();
        fillVolumeDimension(handoverId, "HandOver");
        fillOtherCharges(handoverId, "HandOver");
        HandoverCalculation();
    }

    public void HandoverCalculation()
    {
        int Houses = int.Parse(txtHouses.Value);
        decimal aciFee = decimal.Parse(txtACIFee.Text);
        decimal awbFee = decimal.Parse(txtAWBFee.Text);
        decimal DbCharges = decimal.Parse(txtDisbursmentCharges.Text);
        decimal cartage = decimal.Parse(txtCatrage.Text);
        decimal valuation = decimal.Parse(txtValuationCharge.Text);
        decimal tax = decimal.Parse(txtTax.Text);
        string dueAgentP = txtDueAgentP.Text;
        string dueAgentC = txtDueAgentC.Text;
        string specialAmt = txtSpAmt.Text;
        string chWt = txtChargeableWt.Text;
        decimal fff = decimal.Parse(txtFSC.Text);
        fff = Math.Round(fff, MidpointRounding.AwayFromZero);
        txtFSC.Text = fff.ToString();
        string fsc = txtFSC.Text;
        decimal www = decimal.Parse(txtWSC.Text);
        www = Math.Round(www, MidpointRounding.AwayFromZero);
        txtWSC.Text = www.ToString();
        string wsc = txtWSC.Text;
        decimal xxx = decimal.Parse(txtXRAY.Text);
        xxx = Math.Round(xxx, MidpointRounding.AwayFromZero);
        txtXRAY.Text = xxx.ToString();
        hdnCGC.Value = Math.Round(decimal.Parse(txtCGC.Text), MidpointRounding.AwayFromZero).ToString();
        decimal MSC = decimal.Parse(txtMSC.Text);
        MSC = Math.Round(MSC, MidpointRounding.AwayFromZero);
        txtMSC.Text = MSC.ToString();

        string xray = txtXRAY.Text;
        decimal ACI = 0;
        decimal TotalPrepaid = 0;
        decimal TotalCollect = 0;
        if (txtDmcharges.Text == "")
        {
            txtDmcharges.Text = "0";
        }

        cartage = Math.Round(cartage, MidpointRounding.AwayFromZero);
        //alert(DueCarrier);
        decimal TotalDueCarrier = decimal.Parse(fsc) + decimal.Parse(wsc) + decimal.Parse(xray) + aciFee + awbFee + DbCharges + cartage + MSC + decimal.Parse(txtCGC.Text) + decimal.Parse(txtDmcharges.Text);

        TotalDueCarrier = Math.Round(TotalDueCarrier, MidpointRounding.AwayFromZero);

        decimal totalDueAgent = decimal.Parse(dueAgentC) + decimal.Parse(dueAgentP);
        totalDueAgent = Math.Round(totalDueAgent, MidpointRounding.AwayFromZero);
        txtDueCarrier.Text = TotalDueCarrier.ToString();
        txtTotalDueAgent.Text = totalDueAgent.ToString();

        if (rbFType.SelectedValue == "PREPAID")
        {
            TotalPrepaid = TotalPrepaid + decimal.Parse(specialAmt);
            //alert(TotalPrepaid);
        }
        else
        {
            TotalCollect = TotalCollect + decimal.Parse(specialAmt);
        }

        // ::::::: CHECK FOR DUE CARRIER TYPE :::::::

        if (rbDueFreight.SelectedValue == "PREPAID")
        {
            //if(document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true)
            //{
            TotalPrepaid = TotalPrepaid + decimal.Parse(dueAgentP) + TotalDueCarrier + valuation + tax;
            TotalCollect = TotalCollect + decimal.Parse(dueAgentC);

        }
        else
        {
            TotalPrepaid = TotalPrepaid + decimal.Parse(dueAgentP);
            TotalCollect = TotalCollect + decimal.Parse(dueAgentC) + TotalDueCarrier + valuation + tax;
        }
        TotalPrepaid = Math.Round(TotalPrepaid, MidpointRounding.AwayFromZero);
        TotalCollect = Math.Round(TotalCollect, MidpointRounding.AwayFromZero);
        txtPrepaid.Text = TotalPrepaid.ToString();
        txtCollect.Text = TotalCollect.ToString();
    }

    public void getBookingDetails()
    {
        string bookingId = Request.QueryString["Booking_ID"].ToString();

        //***************Added on 30 Mar 2011(For Airline_Detail_Id)****************

        DataTable dtAid = dw.GetAllFromQuery("select bm.city_id,SUBSTRING(sm.airwaybill_no,0,4) AS Airline_code from booking_master bm inner join stock_master sm on bm.stock_id=sm.stock_id where booking_id=" + bookingId);
        if (dtAid.Rows.Count > 0)
        {
            DataTable dtAirlineDetailID = dw.GetAllFromQuery("select airline_detail_id from airline_detail ad inner join airline_master am on ad.airline_id=am.airline_id where ad.belongs_to_city=" + dtAid.Rows[0]["city_id"].ToString() + " and am.airline_code='" + dtAid.Rows[0]["Airline_code"].ToString() + "'");

            hdnAirlineDetailId.Value = dtAirlineDetailID.Rows[0]["airline_detail_id"].ToString();
        }


        //*****************End******************************************************


        con = new SqlConnection(strCon);
        string strBookingDetail = "select * from Booking_Master B inner join Stock_Master S on B.Stock_Id = S.Stock_Id where Booking_Id = '" + bookingId + "'";
        con.Open();
        SqlDataAdapter daBookingDetail = new SqlDataAdapter(strBookingDetail, con);
        DataSet dsBookingDetail = new DataSet();
        daBookingDetail.Fill(dsBookingDetail);
        DateTime bookingDate = Convert.ToDateTime(dsBookingDetail.Tables[0].Rows[0]["Booking_Date"].ToString());
        DateTime exptHandoverDate = Convert.ToDateTime(dsBookingDetail.Tables[0].Rows[0]["Expected_Handover_Date"].ToString());
        string mmm = dsBookingDetail.Tables[0].Rows[0]["special_commodity_id"].ToString();
        string ssss = dsBookingDetail.Tables[0].Rows[0]["shipment_id"].ToString();
        int s = int.Parse(ssss);
        ddlShipmentType.SelectedValue = ssss;
        ddlScr.SelectedIndex = ddlScr.Items.IndexOf(ddlScr.Items.FindByValue(dsBookingDetail.Tables[0].Rows[0]["special_commodity_id"].ToString()));
        ViewState["BOOKING_DATE"] = bookingDate.ToShortDateString();
        ViewState["EXPTHANDOVERDATE"] = exptHandoverDate.ToShortDateString();
        txtAWBNo.Text = dsBookingDetail.Tables[0].Rows[0]["AirwayBill_No"].ToString();
        txtAWBNo.ReadOnly = true;
        ViewState["StockId"] = dsBookingDetail.Tables[0].Rows[0]["Stock_ID"].ToString();
        DataTable dtAgent = dw.GetAllFromQuery("select Agent_ID From Stock_Master where stock_ID=" + ViewState["StockId"].ToString());
        ViewState["Agent_ID"] = dtAgent.Rows[0]["Agent_ID"].ToString();
        con.Close();
        fillDestination();
        FillHandoverDetails();
        fillVolumeDimension(bookingId, "Booking");
        fillOtherCharges(bookingId, "Booking");
        HandoverCalculation();
    }

    public void fillDestination()
    {
        string airlineID = "";
        string airDetailID = "";
        string awbNo = txtAWBNo.Text;
        string cityID = "";
        string strCheckCity = "";
        //CHECK FOR AWB NO. EXISTS OR NOT
        if (Request.QueryString["Handover_ID"] != null)
        {
            strCheckCity = "select * from stock_master S inner join Agent_master A on S.agent_Id = A.Agent_ID inner join city_master C on S.city_ID = C.city_ID where AirWayBill_No = '" + awbNo + "'";
        }
        if (Request.QueryString["Booking_ID"] != null)
        {
            strCheckCity = "select * from stock_master S inner join Agent_master A on S.agent_Id = A.Agent_ID inner join city_master C on S.city_ID = C.city_ID where AirWayBill_No = '" + awbNo + "' and (status = '16' or status = '9' )";
        }

        DataTable dtCityID = dw.GetAllFromQuery(strCheckCity);
        if (dtCityID.Rows.Count > 0)
        {
            cityID = dtCityID.Rows[0]["City_ID"].ToString();
            ViewState["CityID"] = cityID;
        }

        string airlineCode = txtAWBNo.Text.Trim();
        airlineCode = airlineCode.Substring(0, 3);
        DataTable dtAirlineID = dw.GetAllFromQuery("select airline_id from airline_master where airline_code = '" + airlineCode + "'");
        if (dtAirlineID.Rows.Count > 0)
        {
            airlineID = dtAirlineID.Rows[0]["Airline_ID"].ToString();
            //ViewState["Airlilne"] = airlineID;
        }

        DataTable dtAirlineDetail = dw.GetAllFromQuery("select * from airline_detail where airline_Id = '" + airlineID + "' and belongs_to_City = '" + cityID + "'");
        if (dtAirlineDetail.Rows.Count > 0)
        {
            airDetailID = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
            //ViewState["Airline_Detail_Id"] = airDetailID;
            //txtAWBFee.Text = dtAirlineDetail.Rows[0]["AWB_Fees"].ToString();
            //txtACIFee.Text = dtAirlineDetail.Rows[0]["ACI_Fees"].ToString();
            //txtDisbursmentCharges.Text = dtAirlineDetail.Rows[0]["DisBursementCharges"].ToString();
        }
        string strDestination = "select distinct Destination_ID,Destination_Name from agent_rate_master A inner join destination_master D on A.destination=D.Destination_ID where  A.airline_detail_Id = '" + airDetailID + "'";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand(strDestination, con);
        SqlDataReader dr = com.ExecuteReader();
        ddlDestination.Items.Clear();
        while (dr.Read())
        {
            ddlDestination.Items.Add(new ListItem(dr["Destination_Name"].ToString(), dr["Destination_Id"].ToString()));
        }
        dr.Close();
        con.Close();
    }

    public void fillVolumeDimension(string Id, string Check)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "";
        if (Request.QueryString["Handover_ID"] != null)
        {
            strQuery = "select * from Handover_Dimensions where handover_Id = '" + Id + "'";
        }
        if (Request.QueryString["Booking_ID"] != null)
        {
            strQuery = "select * from Booking_Dimensions where booking_Id = '" + Id + "'";
        }
        if (Check == "Booking")
        {
            strQuery = "select * from Booking_Dimensions where booking_Id = '" + Id + "'";
        }
        if (Check == "HandOver")
        {
            strQuery = "select * from Handover_Dimensions where handover_Id = '" + Id + "'";
        }

        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = tableVolumewt();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            dw = dt.NewRow();
            dw[0] = i++;

            string len = dr["Length"].ToString();
            string width = dr["Breadth"].ToString();
            string Height = dr["Height"].ToString();

            decimal l = System.Math.Round(decimal.Parse(len), MidpointRounding.AwayFromZero);
            decimal w = System.Math.Round(decimal.Parse(width), MidpointRounding.AwayFromZero);
            decimal h = System.Math.Round(decimal.Parse(Height), MidpointRounding.AwayFromZero);

            dw[1] = l;
            dw[2] = w;
            dw[3] = h;
            dw[4] = dr["No_of_Packages"].ToString();
            dw[5] = dr["Total"].ToString();

            dt.Rows.Add(dw);

        }
        if (dt.Rows.Count > 0)
        {
            grdCal.DataSource = dt;
            grdCal.DataBind();
        }
        else
        {
            Session["dtTem"] = null;
            maketableVolumewt();
        }
        con.Close();
    }

    public void fillOtherCharges(string Id, string Check)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "";
        if (Request.QueryString["Handover_ID"] != null)
        {
            strQuery = "select * from Other_Charges where Handover_Id = '" + Id + "'";
        }
        if (Request.QueryString["Booking_ID"] != null)
        {
            strQuery = "select * from Other_Charges where booking_Id = '" + Id + "'";
        }
        if (Check == "Booking")
        {
            strQuery = "select * from Other_Charges where booking_Id = '" + Id + "'";
        }
        if (Check == "HandOver")
        {
            strQuery = "select * from Other_Charges where Handover_Id = '" + Id + "'";
        }
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = tableCharges();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            dw = dt.NewRow();
            dw[0] = i++;

            string amount = dr["Amount"].ToString();
            decimal amt = System.Math.Round(decimal.Parse(amount), MidpointRounding.AwayFromZero);
            dw[1] = dr["Charge_Name"].ToString();
            dw[2] = amt;
            dw[3] = dr["Prepaid_or_Collect"].ToString();

            dt.Rows.Add(dw);

        }
        if (dt.Rows.Count > 0)
        {
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            Session["dtOther"] = null;
            MakeTable();
        }
        con.Close();
    }

    public void DueCarrier()
    {
        decimal DueCarrier = 0, A = 0, B = 0, C = 0, Gw = 0, Cw = 0, FSC = 0, AWBFee = 0, DisbursmentCharges = 0, ACIFee = 0, Security_Surcharge = 0, Xray = 0;
        if (txtGrossWt.Text != "" && txtChargeableWt.Text != "")
        {
            Gw = decimal.Parse(txtGrossWt.Text);
            Cw = decimal.Parse(txtChargeableWt.Text);
        }

        DataTable dtCharges = dw.GetAllFromQuery("select FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,DisBursementCharges from Airline_Detail where Airline_Detail_ID=" + ViewState["Airline_Detail_Id"].ToString());

        string str = "select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID= '" + ViewState["Airline_Detail_Id"].ToString() + "' and Shipment_ID='" + ddlShipmentType.SelectedValue + "'  and Destination='" + ddlDestination.SelectedValue + "' and Agent_Rate_ID='" + ViewState["AgentRateID"].ToString() + "'";
        DataTable dtChargesDetails = dw.GetAllFromQuery(str);
        if (dtCharges.Rows.Count > 0)
        {
            if (dtCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["FreightSurCharge_On"].ToString() == "Chargable Wt")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Cw * FSC;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Gw * FSC;
                    }
                }
            }
            if (dtCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["WarSurcharge_On"].ToString() == "Chargable Wt")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Cw * Security_Surcharge;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Gw * Security_Surcharge;
                    }
                }
            }
            if (dtCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["XRayCharge_On"].ToString() == "Chargable Wt")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        B = Cw * Xray;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        B = Gw * Xray;
                    }
                }
            }
            //ACIFee = decimal.Parse(dtCharges.Rows[0]["ACI_Fees"].ToString());
            ACIFee = decimal.Parse(txtACIFee.Text);
            if (decimal.Parse(txtDueAgentC.Text) > 0)
            {
                decimal dbCharges = decimal.Parse(dtCharges.Rows[0]["DisBursementCharges"].ToString());
                decimal finalDBCharge = decimal.Parse(txtDueAgentC.Text) * 10 / 100;
                if (finalDBCharge >= dbCharges)
                {
                    DisbursmentCharges = finalDBCharge;
                }
                else
                {
                    DisbursmentCharges = dbCharges;
                }
            }
            else
            {
                DisbursmentCharges = 0;
            }

            //**** For Catrage Charges***************
            if (ddlOrigin.SelectedValue == "18")
            {
                if (decimal.Parse(txtGrossWt.Text) >= 50)
                {
                    txtCatrage.Text = txtGrossWt.Text;
                }
                else
                {
                    txtCatrage.Text = "50";
                }
            }
            else
            {
                txtCatrage.Text = "0";
            }
            //****End of Catrage Charges*************


            AWBFee = decimal.Parse(txtAWBFee.Text);

            DueCarrier = A + B + C + AWBFee + ACIFee + DisbursmentCharges + decimal.Parse(txtCGC.Text) + decimal.Parse(txtDmcharges.Text);
    
        }
        // txtACIFee.Text = ACIFee.ToString();

        txtFSC.Text = A.ToString();
        txtWSC.Text = B.ToString();
        txtXRAY.Text = C.ToString();

        Hidden1.Value = ACIFee.ToString();
        Hidden2.Value = DisbursmentCharges.ToString();
        hdnCGC.Value = txtCGC.Text;
        txtDisbursmentCharges.Text = DisbursmentCharges.ToString();
        //txtAWBFee.Text = AWBFee.ToString();
        txtDueCarrier.Text = DueCarrier.ToString();
        decimal Charges = A + B + C;
        Hidden3.Value = Charges.ToString();
        if (rbDueFreight.SelectedValue == "PREPAID")
        {
            decimal TotalPrepaid = Convert.ToDecimal(DueCarrier.ToString()) + Convert.ToDecimal(txtFreightAmount.Text);
            txtPrepaid.Text = TotalPrepaid.ToString();
            txtCollect.Text = "0";
        }
        else
        {
            decimal TotalCollect = Convert.ToDecimal(DueCarrier.ToString()) + Convert.ToDecimal(txtFreightAmount.Text);
            txtCollect.Text = TotalCollect.ToString();
            txtPrepaid.Text = "0";
        }
    }

    public DataTable tableCharges()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int32");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "FeeName";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Fee";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "PaymentType";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        Session["dtOther"] = dtTemp;
        return dtTemp;
    }

    public DataTable tableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Length";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Width";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Height";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Pieces";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume Wt";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        Session["dtTem"] = dtTemp;
        return dtTemp;
    }

    public void maketableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Length";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Width";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Height";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Pieces";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume Wt";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);
        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
    }

    protected void MakeTable()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "Sno";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "FeeName";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "Fee";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "PaymentType";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        DataRow dr = dt.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dt.Rows.Add(dr);
        Session["dtOtherCharges"] = dt;

    }

    public void LoadDestination()
    {
        try
        {
            string strAgent = "select Destination_ID,Destination_Code,Destination_Name from Destination_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Clear();
            ddlDestination.Items.Add(new ListItem("- -Select- -", "0"));
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadCommodity()
    {
        try
        {
            string strAgent = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();

            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            con.Close();
            //ddlScr.SelectedItem.Text = "General";
            // ddlScr.SelectedIndex = ddlScr.Items.IndexOf(ddlScr.Items.FindByText("General"));
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadOrigin()
    {
        try
        {
            string strAgent = "select City_ID,City_Code,City_Name from City_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Add(new ListItem("- -Select- -", "0"));
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadShipmentType()
    {
        try
        {
            ddlShipmentType.Items.Clear();
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();

            while (dr.Read())
            {
                ddlShipmentType.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }

            con.Close();
            //ddlShipmentType.SelectedIndex = ddlShipmentType.Items.IndexOf(ddlShipmentType.Items.FindByText("Normal"));
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        decimal DueAgent = 0, DueAgentP = 0, DueAgentC = 0;
        if (e.CommandName == "Add")
        {
            //DataTable dt = (DataTable)Session["dtOtherCharges"];
            DataTable dt1;// = (DataTable)Session["dtOther"];
            if (Session["dtOther"] == null)
            {
                dt1 = (DataTable)Session["dtOtherCharges"];
            }
            else
            {
                dt1 = (DataTable)Session["dtOther"];
            }
            if (dt1.Rows.Count > 0)
            {
                if (dt1.Rows[0]["Sno"].ToString() == "0")
                {
                    dt1.Rows[0].Delete();
                }
                TextBox txthader = grd.FooterRow.FindControl("txtheader") as TextBox;
                TextBox txtfee = grd.FooterRow.FindControl("txtvalue") as TextBox;
                DropDownList drp = (DropDownList)(grd.FooterRow.FindControl("ddlgrd"));
                string paymenttype = drp.SelectedItem.Text;
                DataRow dr = dt1.NewRow();
                dr[1] = txthader.Text;
                dr[2] = txtfee.Text;
                dr[3] = paymenttype;
                dt1.Rows.Add(dr);

                if (Session["dtOther"] == null)
                {
                    Session["dtOtherCharges"] = dt1;
                }
                else
                {
                    Session["dtOther"] = dt1;
                }
                //Session["dtOtherCharges"] = dt1;
                //Session["dtOtherCharges"] = dt;

                //decimal DueAgent = 0, DueAgentP = 0, DueAgentC = 0;
                foreach (DataRow rw in dt1.Rows)
                {
                    //DueAgent = DueAgent + Convert.ToDecimal(rw["Fee"].ToString());
                    if (rw["PaymentType"].ToString() == "PREPAID")
                    {
                        DueAgentP = DueAgentP + Convert.ToDecimal(rw["Fee"].ToString());
                    }
                    if (rw["PaymentType"].ToString() == "COLLECT")
                    {
                        DueAgentC = DueAgentC + Convert.ToDecimal(rw["Fee"].ToString());
                    }
                }
                grd.DataSource = dt1;
                grd.DataBind();

            }

            //****************************************
            txtDueAgentP.Text = DueAgentP.ToString();
            txtDueAgentC.Text = DueAgentC.ToString();
            decimal total = decimal.Parse(txtDueAgentP.Text) + decimal.Parse(txtDueAgentC.Text);
            txtTotalDueAgent.Text = total.ToString();
            //****************************************
            //******Calculation of Dbcharges****************
            decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = dueP.ToString();
            decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = dueC.ToString();
            decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
            txtPrepaid.Text = PP.ToString();
            decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
            txtCollect.Text = CC.ToString();
            decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
            //Taking 10% of Dbcharges*******************
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
            decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
            if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
            {
                txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
            }
            //****End of Dbcharges**************************

            //*****Managing Values After PostBack***********

            decimal ACI = decimal.Parse(Hidden1.Value) * decimal.Parse(txtHouses.Value);
            txtACIFee.Text = ACI.ToString();
            //decimal Due = decimal.Parse(Hidden3.Value) + (ACI - decimal.Parse(Hidden1.Value));
            decimal Result = Convert.ToDecimal(Hidden3.Value) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtCGC.Text) + decimal.Parse(txtDmcharges.Text);
            txtDueCarrier.Text = Result.ToString();

            //*****End of Manage Values******************

            if (rbDueFreight.SelectedValue == "PREPAID")
            {
                decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Total_Prepaid = Total_Prepaid + decimal.Parse(txtSpAmt.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = txtDueAgentC.Text;
                }
                else
                {
                    decimal Total_Collect = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueAgentC.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = Total_Prepaid.ToString();
                }
            }
            else
            {
                decimal Total_Collect = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentC.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    decimal Total_Prepaid = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueAgentP.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = Total_Collect.ToString();
                }
                else
                {
                    Total_Collect = Total_Collect + decimal.Parse(txtSpAmt.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = txtDueAgentP.Text;
                }
            }
        }
        HandoverCalculation();
    }

    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        if (Session["dtOther"] == null)
        {
            dt = (DataTable)Session["dtOtherCharges"];
        }
        else
        {
            dt = (DataTable)Session["dtOther"];
        }
        int Sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                break;
            }
        }
        if (Session["dtOther"] == null)
        {
            Session["dtOtherCharges"] = dt;
        }
        else
        {
            Session["dtOther"] = dt;
        }
        //Session["dtOtherCharges"] = dt;

        grd.DataSource = dt;
        grd.DataBind();
        if (dt.Rows.Count <= 0)
        {
            //DataRow dr = dt.NewRow();
            //dr[0] = "0";
            //dr[1] = "0";
            //dr[2] = "0";
            //dr[3] = "0";
            //dt.Rows.Add(dr);
            MakeTable();
            dt = (DataTable)Session["dtOtherCharges"];
            if (Session["dtOther"] == null)
            {
                Session["dtOtherCharges"] = dt;
            }
            else
            {
                Session["dtOther"] = dt;
            }
            txtDueAgentC.Text = "0";
            txtDueAgentP.Text = "0";
            txtTotalDueAgent.Text = "0";
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            decimal feePrepaid = 0;
            decimal feeCollect = 0;

            foreach (DataRow rw in dt.Rows)
            {
                string type = rw["PaymentType"].ToString();
                if (type == "PREPAID")
                {
                    feePrepaid = feePrepaid + decimal.Parse(rw["Fee"].ToString());
                }
                else
                {
                    feeCollect = feeCollect + decimal.Parse(rw["Fee"].ToString());
                }
            }
            txtDueAgentP.Text = Convert.ToString(System.Math.Round(feePrepaid, 2));
            txtDueAgentC.Text = Convert.ToString(System.Math.Round(feeCollect, 2));

            decimal totalDueAgent = feePrepaid + feeCollect;
            txtTotalDueAgent.Text = Convert.ToString(totalDueAgent);
            // ************** CHECK FOR DISBURSEMENT CHARGES ******************
            decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = dueP.ToString();
            decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = dueC.ToString();
            decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
            txtPrepaid.Text = PP.ToString();
            decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
            txtCollect.Text = CC.ToString();
            decimal applyDBCharge = feeCollect * 10 / 100;
            if (applyDBCharge > decimal.Parse(Hidden2.Value))
            {
                txtDisbursmentCharges.Text = Convert.ToString(applyDBCharge);
            }
            else
            {
                txtDisbursmentCharges.Text = Hidden2.Value;
            }
            // *****************************************************************

            grd.DataSource = dt;
            grd.DataBind();
        }
        HandoverCalculation();
        //txtTotalDueAgent.Focus();
    }

    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grd.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
        }
        else
        {
            lblmsg.Visible = false;
            Label edit = (Label)grd.Rows[e.NewEditIndex].FindControl("lblpaymenttype");
            ViewState["edit"] = edit.Text;
            ViewState["et"] = ViewState["edit"];
            grd.EditIndex = e.NewEditIndex;
            DataTable dt;
            if (Session["dtOther"] == null)
            {
                dt = (DataTable)Session["dtOtherCharges"];
            }
            else
            {
                dt = (DataTable)Session["dtOther"];
            }
            //DataTable dt = (DataTable)Session["dtOtherCharges"];
            grd.DataSource = dt;
            grd.DataBind();
        }
    }

    protected void grd_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt;// = (DataTable)Session["dtOtherCharges"];
        if (Session["dtOther"] == null)
        {
            dt = (DataTable)Session["dtOtherCharges"];
        }
        else
        {
            dt = (DataTable)Session["dtOther"];
        }
        int sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        string strheader = ((TextBox)grd.Rows[e.RowIndex].FindControl("txtheader")).Text;
        int value = Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        DropDownList drp = (DropDownList)(grd.Rows[e.RowIndex].FindControl("ddlgrd"));
        string paymenttype = drp.SelectedItem.Text;
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == sno.ToString())
            {
                dr[1] = strheader;
                dr[2] = value;
                dr[3] = paymenttype;
            }
        }
        //Session["dtOtherCharges"] = dt;

        if (Session["dtOther"] == null)
        {
            Session["dtOtherCharges"] = dt;
        }
        else
        {
            Session["dtOther"] = dt;
        }

        decimal feePrepaid = 0;
        decimal feeCollect = 0;

        foreach (DataRow rw in dt.Rows)
        {
            string type = rw["PaymentType"].ToString();
            if (type == "PREPAID")
            {
                feePrepaid = feePrepaid + decimal.Parse(rw["Fee"].ToString());
            }
            else
            {
                feeCollect = feeCollect + decimal.Parse(rw["Fee"].ToString());
            }
        }
        txtDueAgentP.Text = Convert.ToString(System.Math.Round(feePrepaid, 2));
        txtDueAgentC.Text = Convert.ToString(System.Math.Round(feeCollect, 2));

        decimal totalDueAgent = feePrepaid + feeCollect;
        txtTotalDueAgent.Text = Convert.ToString(totalDueAgent);

        // ************** CHECK FOR DISBURSEMENT CHARGES ******************
        decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
        txtDueAgentP.Text = dueP.ToString();
        decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
        txtDueAgentC.Text = dueC.ToString();
        decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
        txtPrepaid.Text = PP.ToString();
        decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
        txtCollect.Text = CC.ToString();
        decimal applyDBCharge = feeCollect * 10 / 100;
        if (applyDBCharge > decimal.Parse(Hidden2.Value))
        {
            txtDisbursmentCharges.Text = Convert.ToString(applyDBCharge);
        }
        else
        {
            txtDisbursmentCharges.Text = Hidden2.Value;
        }
        // *****************************************************************
        grd.EditIndex = -1;
        grd.DataSource = dt;
        grd.DataBind();

        HandoverCalculation();
    }

    protected void grd_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd.EditIndex = -1;

        DataTable dt; //= (DataTable)Session["dtOtherCharges"];
        if (Session["dtOther"] == null)
        {
            dt = (DataTable)Session["dtOtherCharges"];
        }
        else
        {
            dt = (DataTable)Session["dtOther"];
        }
        grd.DataSource = dt;
        grd.DataBind();
    }

    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (ViewState["edit"].ToString() == ViewState["et"].ToString())
            {
                Label lbl = (Label)e.Row.Cells[3].FindControl("lblpaymenttype");
                DropDownList ddl = (DropDownList)e.Row.Cells[3].FindControl("ddlgrd");
                if (ViewState["edit"].ToString() == "PREPAID")
                {
                    //ddl.SelectedIndex=2;
                }
                else
                {
                    //ddl.SelectedIndex=1;

                }
            }
        }
    }

    public void FillHandoverDetails()
    {
        string warSurcharges = "";
        string fuelSurcharges = "";
        string xrayChaarges = "";
        string aPrepaid = "";
        string aCollect = "";
        string Cgc_Charges = "";
        int AWBFees = 0;
        decimal agentPrepaid = 0;
        decimal agentCollect = 0;
        con = new SqlConnection(strCon);
        con.Open();
        string strAWBNo = txtAWBNo.Text;
        string strAWBFill = "";

        if (Request.QueryString["Handover_ID"] != null)
        {
            strAWBFill = "select * from testHandover where airwaybill_No='" + strAWBNo + "'";
        }
        else
        {
            strAWBFill = "select * from Handover_EditDetails where airwaybill_No='" + strAWBNo + "'" + " and status=9";
        }

        com = new SqlCommand(strAWBFill, con);
        red = com.ExecuteReader();
        if (red.Read())
        {
            lblAgent.Text = red["Agent_Name"].ToString();
            int commodity = Convert.ToInt32(red["Special_commodity_id"].ToString());
            int shipment = Convert.ToInt32(red["shipment_id"].ToString());
            string shipment_Id_ = red["shipment_id"].ToString();
            int origin = Convert.ToInt32(red["city_Id"].ToString());
            int destination = Convert.ToInt32(red["destination_Id"].ToString());
            string destCode = red["Destination_Code"].ToString();
            string ship = red["shipment_Name"].ToString();
            string dest = red["Destination_Code"].ToString() + '-' + red["destination_name"].ToString();
            string scr = red["special_commodity_Name"].ToString();
            string ftype = red["Freight_Type"].ToString();
            string dtype = red["DueCarrier_Type"].ToString();
            string spotRate = red["Spot_Rate"].ToString();
            string comm=red["Commission"].ToString();
            string scr_inc = red["special_commodity_incentive"].ToString();
            string bookId = red["Booking_Id"].ToString();
            DateTime dtawb = Convert.ToDateTime(red["Used_Date"].ToString());
            string awbdate = FormatDateMM(Convert.ToString(dtawb.ToShortDateString()));
            txtAWBDate.Text = awbdate;
            DateTime dthndawb = Convert.ToDateTime(red["handover_Date"].ToString());
            string hnddate = FormatDateMM(Convert.ToString(dthndawb.ToShortDateString()));
            txthandover_date.Text = hnddate;
            txtAdhocRate.Text = red["Adhoc_Rate"].ToString();
            if (bookId == "0" || bookId == "")
            {
                ViewState["BookID"] = "0";
                //ViewState["bookDate"] = null;
            }
            else
            {
                ViewState["BookID"] = bookId;
            }
            if (spotRate == "")
            {
                txtSpotRate.Text = "0";
            }
            else
            {
                txtSpotRate.Text = spotRate;
            }
            if (comm == "")
            {
                 txtIATACommission.Text = "0";
            }
            else
            {
               txtIATACommission.Text = comm;
            }
              if (scr_inc == "")
            {
                txtSCR_Incentive.Text = "0";
            }
            else
            {
                txtSCR_Incentive.Text = comm;
            }
            rbFType.SelectedValue = ftype;
            rbDueFreight.SelectedValue = dtype;
            ddlDestination.SelectedValue = destination.ToString();
            hdnfldDestination.Value = red["destination_name"].ToString();
            ddlOrigin.SelectedValue = origin.ToString();
            ddlOrigin.Enabled = false;
            ddlScr.SelectedItem.Text = scr;

            //Shipment Added on 1-July-2010 (Missed earlier by mistake: Filling Shipment)
            ddlShipmentType.SelectedValue = shipment_Id_;
            //////////End of Shipment Fill



            txtFlightNo.Text = red["Flight_No"].ToString();
            DateTime flightD = Convert.ToDateTime(red["flight_date"].ToString());
            hdnfldFlightOpenId.Value = red["flight_open_id"].ToString();
            txtFlightDate.Text = FormatDateMM(Convert.ToString(flightD.ToShortDateString()));
            string freight = red["freight_type"].ToString();
            //ddlFreightType.SelectedItem.Text = freight;
            txtPieces.Text = red["No_of_Packages"].ToString();
            txtGrossWt.Text = red["gross_weight"].ToString();
            txtVolumeWt.Text = red["volume_weight"].ToString();
            txtChargeableWt.Text = red["charged_Weight"].ToString();
            hdnfldChargeWt.Value = red["charged_Weight"].ToString();
            txtShipper.Text = red["shipper_name"].ToString();
            txtShipperAddress.Text = red["shipper_address"].ToString();
            txtConsignee.Text = red["consignee_name"].ToString();
            txtConsigneeAddress.Text = red["consignee_address"].ToString();
            txtCurrency.Text = red["currency"].ToString();
            txtCGHSCode.Text = red["CHGS_Code"].ToString();
            txtDVCarriage.Text = red["declared_carriage_value"].ToString();
            txtDVCustom.Text = red["declared_custom_value"].ToString();
            txtHandlingInformation.Text = red["handling_information"].ToString();
            txtNatureGoods.Text = red["nature_and_quantity"].ToString();
            txtDueCarrier.Text = red["total_duecarrier"].ToString();
            //txtAgentDealRemarks.Text = red["Remarks"].ToString();
            txtDmcharges.Text = red["DMCharges"].ToString();
            Hidden3.Value = red["total_duecarrier"].ToString();
            txtCollect.Text = red["Total_Collect"].ToString();
            txtPrepaid.Text = red["Total_Prepaid"].ToString();
          
            aPrepaid = red["TotalDueAgent_Prepaid"].ToString();
            aCollect = red["TotalDueAgent_Collect"].ToString();
            string houses = red["No_of_houses"].ToString();
            if (houses == "")
            {
                txtHouses.Value = "0";
            }
            else
            {
                txtHouses.Value = houses;
            }
            string  aci_f= red["total_ACI_Fees"].ToString();
            string hidden1 = red["ACI_Fees"].ToString();
            //if (aci_f.ToString() != "0.00")
            //{ 
            //    Hidden1.Value = red["total_ACI_Fees"].ToString();
            //}
            //else 
            if(hidden1.ToString() != "0.00")
            {
                Hidden1.Value = hidden1;
            }
            else
            {
                Hidden1.Value = "0";
            }
            decimal totalACI = decimal.Parse(Hidden1.Value) * decimal.Parse(txtHouses.Value);
            txtACIFee.Text = Convert.ToString(aci_f);
            warSurcharges = red["War_Surcharges"].ToString();
            fuelSurcharges = red["Fuel_Surcharges"].ToString();
            xrayChaarges = red["Xray_Charges"].ToString();
            Cgc_Charges = red["Cgc_Charges"].ToString();
            decimal DueCarrier = 0;
            decimal FreightAmount = 0;
            string MSC_Charges = "";
            MSC_Charges = red["MSC_Charges"].ToString();
            ///// CAse Disbursement charges 29 aug 2011 /////
          //  Hidden2.Value = txtDisbursmentCharges.Text;

            Hidden2.Value = red["DisBursementCharges"].ToString();
            if (txtDueCarrier.Text == "")
            {
                DueCarrier = 0;
            }
            else
            {
                DueCarrier = decimal.Parse(txtDueCarrier.Text);
            }

            if (txtFreightAmount.Text == "")
            {
                FreightAmount = 0;
            }
            else
            {
                FreightAmount = decimal.Parse(txtFreightAmount.Text);
            }

            ViewState["NetUsed"] = DueCarrier + FreightAmount;

            if (warSurcharges == "")
            {
                txtWSC.Text = "0";
            }
            else
            {
                txtWSC.Text = warSurcharges;
            }

            if (fuelSurcharges == "")
            {
                txtFSC.Text = "0";
            }
            else
            {
                txtFSC.Text = fuelSurcharges;
            }
            HiddenFSC.Value = txtFSC.Text;
            if (xrayChaarges == "")
            {
                txtXRAY.Text = "0";
            }
            else
            {
                txtXRAY.Text = xrayChaarges;
            }
            HiddenXRay.Value = txtXRAY.Text;
            if (Cgc_Charges == "")
            {
                txtCGC.Text = "0";
            }
            else
            {
                txtCGC.Text = Cgc_Charges;
            }
            hdnCGC.Value = txtCGC.Text;

            if (MSC_Charges == "")
            {
                txtMSC.Text = "0";
            }
            else
            {
                txtMSC.Text = MSC_Charges;
            }

            string sprate = red["Special_Rate"].ToString();
            string samt = red["Special_Amount"].ToString();
            if (sprate == "")
            {
                txtSpRate.Text = "0";
            }
            else
            {
                txtSpRate.Text = sprate;
            }
            if (samt == "")
            {
                txtSpAmt.Text = "0";
            }
            else
            {
                txtSpAmt.Text = samt;
                lblSpecialAmount.Text = txtSpAmt.Text;
            }

            if (aPrepaid == "")
            {
                agentPrepaid = 0;
                txtDueAgentP.Text = "0";
            }
            else
            {
                agentPrepaid = Convert.ToDecimal(aPrepaid);
                txtDueAgentP.Text = aPrepaid;
            }
            if (aCollect == "")
            {
                agentCollect = 0;
                txtDueAgentC.Text = "0";
            }
            else
            {
                txtDueAgentC.Text = aCollect;
                agentCollect = Convert.ToDecimal(aCollect);
            }
            decimal totalDueAgent = agentPrepaid + agentCollect;
            txtTotalDueAgent.Text = Convert.ToString(totalDueAgent);
            txtFreightAmount.Text = red["Freight_Amount"].ToString();
            txtTariffRate.Text = red["Tariff_Rate"].ToString();
            string awbFee = red["AWB_Fees"].ToString();
            if (awbFee == "")
            {
                AWBFees = 0;
            }
            else
            {
                AWBFees = Convert.ToInt32(System.Math.Round((decimal.Parse(awbFee)), MidpointRounding.AwayFromZero));
            }
            string Cartridge_Charges = red["Cartridge_Charges"].ToString();
            txtCatrage.Text = Cartridge_Charges;

            if (rbDueFreight.SelectedValue == "COLLECT")
            {
                txtDisbursmentCharges.Text = red["DisBursementCharges"].ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = "0";
            
            }
           


            ViewState["Airline_Detail_Id"] = red["Airline_Detail_Id"].ToString();
            txtAWBFee.Text = Convert.ToString(AWBFees);
        }
     
        con.Close();
    }

    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }

    protected void txtACIFee_TextChanged(object sender, EventArgs e)
    {

    }

    public void fillDirectHandover()
    {
        ddlShipmentType.SelectedValue = "8";
        string DBCharge = "";
        string ACIFee = "";
        string AWBFee = "";
        string strQuery = "";
        string awbNo = txtAWBNo.Text;
        int awb = awbNo.IndexOf("-");
        string a = awbNo.Substring(0, awb);
        con = new SqlConnection(strCon);

        strQuery = "select * from airline_detail where airline_detail_Id = '" + ViewState["Airline_Detail_Id"].ToString() + "'";
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter(strQuery, con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DBCharge = ds.Tables[0].Rows[0]["DisBursementCharges"].ToString();
            ACIFee = ds.Tables[0].Rows[0]["ACI_Fees"].ToString();
            AWBFee = ds.Tables[0].Rows[0]["AWB_Fees"].ToString();
        }
        if (DBCharge == "")
        {
            Hidden2.Value = "0";
        }
        else
        {
            Hidden2.Value = DBCharge;
        }

        if (decimal.Parse(txtDueAgentC.Text) > 0)
        {
            decimal val = decimal.Parse(txtDueAgentC.Text) * 10 / 100;
            if (val > decimal.Parse(Hidden2.Value))
            {
                txtDisbursmentCharges.Text = val.ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = Hidden2.Value;
            }
        }
        else
        {
            txtDisbursmentCharges.Text = "0";
        }
        if (ACIFee == "")
        {
            Hidden1.Value = "0";
        }
        else
        {
            Hidden1.Value = ACIFee;
        }

        if (int.Parse(txtHouses.Value) > 0)
        {
            decimal val = int.Parse(txtHouses.Value) * decimal.Parse(Hidden1.Value);
            txtACIFee.Text = val.ToString();
        }
        else
        {
            txtACIFee.Text = "0";
        }
        decimal afee = 0;
        if (AWBFee == "")
        {
            if (decimal.Parse(txtChargeableWt.Text) > 150)
            {
                afee = decimal.Parse(txtChargeableWt.Text);
            }
            else
            {
                afee = 150;
            }
        }
        else
        {
            if (decimal.Parse(txtChargeableWt.Text) > 150)
            {
                afee = decimal.Parse(txtChargeableWt.Text);
            }
            else
            {
                afee = 150;
            }
        }
        decimal valDue = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text) + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtMSC.Text) + decimal.Parse(txtCGC.Text);

        txtDueCarrier.Text = valDue.ToString();
        //HandoverCalculation();
        con.Close();
    }

    protected void btnUpdate_OnClick(object sender, EventArgs e)
    {
        string hdate = "";
        hdate = txthandover_date.Text;
        DateTime dt = DateTime.Now;
        string curDate = FormatDateMM(Convert.ToString(dt.ToShortDateString()));
        //bool val = compareCurDate(hdate, curDate);
        //if (val == true)
        //{
            checkLimit();
        //}
        //else
        //{
        //    Page.MaintainScrollPositionOnPostBack = false;
        //    lblErrorMsg.Text = "Handover date should not be less than current date.";
        //}
    }

    protected void chkbxShowDetails_CheckedChanged(object sender, EventArgs e)
    {
        if (chkbxShowDetails.Checked == true)
        {
            pnlShowDetails.Visible = true;
        }
        else
        {
            pnlShowDetails.Visible = false;
        }
    }

    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblMsg1.Text = "This row is not Editted";
        }
        else
        {
            grdCal.EditIndex = e.NewEditIndex;
            DataTable dt;
            if (Session["dtTem"] == null)
            {
                dt = (DataTable)Session["dtTemp"];
            }
            else
            {
                dt = (DataTable)Session["dtTem"];
            }
            grdCal.DataSource = dt;
            grdCal.DataBind();
        }
    }

    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt;// = (DataTable)Session["dtTemp"];
       
      
        if (Session["dtTem"] == null)
        {
            dt = (DataTable)Session["dtTemp"];
        }
        else
        {
            dt = (DataTable)Session["dtTem"];
        }
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                break;
            }
        }
        if (Session["dtTem"] == null)
        {
            Session["dtTemp"] = dt;
        }
        else
        {
            Session["dtTem"] = dt;
        }
        //Session["dtTemp"] = dt;
        grdCal.DataSource = dt;
        grdCal.DataBind();
        if (dt.Rows.Count <= 0)
        {
            //DataRow dr = dt.NewRow();
            //dr[0] = "0";
            //dr[1] = "0";
            //dr[2] = "0";
            //dr[3] = "0";
            //dr[4] = "0";
            //dr[5] = "0";
            maketableVolumewt();
            dt = (DataTable)Session["dtTemp"];
            //dt.Rows.Add(dr);
            if (Session["dtTem"] == null)
            {
                Session["dtTemp"] = dt;
            }
            else
            {
                Session["dtTem"] = dt;
            }
            //Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            txtVolumeWt.Text = "0";
            txtVolumeWt.Focus();
        }
        else
        {
            int Pieces = 0;
            decimal VoulmeWt = 0;
            foreach (DataRow rw in dt.Rows)
            {
                Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
            }
            string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
            txtPieces.Text = Pieces.ToString();
            txtVolumeWt.Text = Convert.ToString(System.Math.Round(VoulmeWt, 3));
            txtVolumeWt.Focus();
            //ViewState["Volume_Wt"]=VoulmeWt.ToString();
            if (Session["dtTem"] == null)
            {
                Session["dtTemp"] = dt;
            }
            else
            {
                Session["dtTem"] = dt;
            }
            //Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
        }
        //maketableVolumewt();
        //txtTotalDueAgent.Focus();
    }

    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt;// = (DataTable)Session["dtTemp"];
      
      
        if (Session["dtTem"] == null)
        {
            dt = (DataTable)Session["dtTemp"];
        }
        else
        {
            dt = (DataTable)Session["dtTem"];
        }
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        decimal L = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text);
        decimal W = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtw")).Text);
        decimal H = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txth")).Text);
        decimal P = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtp")).Text);
        // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

        // Calculatin Volume Wait
        decimal Volume_Wt;

        if (rbCal.SelectedValue == "Cm")
        {
            Volume_Wt = (L * W * H * P) / 6000;
        }
        else
        {
            Volume_Wt = (L * W * H * P) / 366;

        }
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = Math.Round(Volume_Wt, 3);
            }
        }

        txtVolumeWt.Text = Convert.ToString(Math.Round(Volume_Wt, 3));
        //ViewState["Volume_Wt"] = Convert.ToString(Math.Round(Volume_Wt, 2));
        if (Session["dtTem"] == null)
        {
            Session["dtTemp"] = dt;
        }
        else
        {
            Session["dtTem"] = dt;
        }
        //Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();

        int Pieces = 0;
        decimal VoulmeWt = 0;
        foreach (DataRow rw in dt.Rows)
        {
            Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
            VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
        }
        string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
        txtPieces.Text = Pieces.ToString();
        txtVolumeWt.Text = Convert.ToString(System.Math.Round(VoulmeWt, 3));
        txtVolumeWt.Focus();
        ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;

    }

    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;

        DataTable dt;// = (DataTable)Session["dtTemp"];
        if (Session["dtTem"] == null)
        {
            dt = (DataTable)Session["dtTemp"];
        }
        else
        {
            dt = (DataTable)Session["dtTem"];
        }

        grdCal.DataSource = dt;
        grdCal.DataBind();

    }

    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Add")
        {
            try
            {
               
               
                DataTable dt1;
                int Pieces = 0;
                decimal VoulmeWt = 0;
                if (Session["dtTem"] == null)
                {
                    dt1 = (DataTable)Session["dtTemp"];
                }
                else
                {
                    dt1 = (DataTable)Session["dtTem"];
                }

                if (dt1.Rows.Count > 0)
                {
                    if (dt1.Rows[0]["SNo"].ToString() == "0")
                    {
                        dt1.Rows[0].Delete();
                    }
                    DataRow dr = dt1.NewRow();

                    decimal L = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtl")).Text);
                    decimal W = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtw")).Text);
                    decimal H = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txth")).Text);
                    decimal P = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);

                    // Calculatin Volume Wait
                    decimal Volume_Wt;
                    if (rbCal.SelectedValue == "Cm")
                    {
                        Volume_Wt = (L * W * H * P) / 6000;
                    }
                    else
                    {
                        Volume_Wt = (L * W * H * P) / 366;
                    }

                    //Prepare the Insert Command of the DataSource control
                    dr[1] = L;
                    dr[2] = W;
                    dr[3] = H;
                    dr[4] = P;
                    dr[5] = Math.Round(Volume_Wt, 3);
                    dt1.Rows.Add(dr);
                    foreach (DataRow rw in dt1.Rows)
                    {
                        Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                        VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                    }
                    string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                    txtPieces.Text = Pieces.ToString();
                    if (txtGrossWt.Text != "")
                    {
                        VoulmeWt = Math.Round(VoulmeWt, 3);
                        txtVolumeWt.Text = VoulmeWt.ToString();
                        if (decimal.Parse(txtGrossWt.Text) > VoulmeWt)
                        {
                            decimal Gw = Math.Round(decimal.Parse(txtGrossWt.Text), 3);
                            txtChargeableWt.Text = Gw.ToString();
                        }
                        else
                        {
                            VoulmeWt = Math.Round(VoulmeWt, 3);
                            txtChargeableWt.Text = VoulmeWt.ToString();
                        }
                    }
                    else
                    {
                        VoulmeWt = Math.Round(VoulmeWt, 3);
                        txtVolumeWt.Text = VoulmeWt.ToString();
                    }
                    grdCal.DataSource = dt1;
                    grdCal.DataBind();
                    ((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
                }
                //txtVolumeWt.Text = Convert.ToString(System.Math.Round(VoulmeWt,0));
                //txtVolumeWt.Focus();
                Session["dtTemp"] = dt1;
            }
            catch (Exception ex)
            {

            }
        }
    }

    public bool compareCurDate(string first, string second)
    {
        string[] cdate1 = first.Split('/');
        string[] cdate2 = second.Split('/');

        int fd = Convert.ToInt32(cdate1[0]);
        int fm = Convert.ToInt32(cdate1[1]);
        int fy = Convert.ToInt32(cdate1[2]);
        int sd = Convert.ToInt32(cdate2[0]);
        int sm = Convert.ToInt32(cdate2[1]);
        int sy = Convert.ToInt32(cdate2[2]);
        DateTime dt1 = new DateTime(fy, fm, fd);
        DateTime dt2 = new DateTime(sy, sm, sd);
        if (DateTime.Compare(dt1, dt2) > 0 || DateTime.Compare(dt1, dt2) == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void updateHandover()
    {
        using (con)
        {
            try
            {
                con = new SqlConnection(strCon);
                con.Open();
                trans = con.BeginTransaction();
                //************************************************************************************************
                //string bookingId = "";
                string stockId = "";
                string handoverID = "";
                string strQuery = "";
                //handoverID = ParamUtils.WebParam.GetQuery(Request.Params["Handover_Id"].ToString(), "id");
                handoverID = Request.QueryString["Handover_Id"].ToString();
                //string expdate = "";
                //string bookingDate = "";
                string awbNo = txtAWBNo.Text;
                string awbDate = FormatDateMM(txtAWBDate.Text);
                string handoverDate = FormatDateMM(txthandover_date.Text);
                string flightDate = FormatDateMM(txtFlightDate.Text);
                string pieces = txtPieces.Text;
                decimal grossWt = decimal.Parse(txtGrossWt.Text);
                decimal volumeWt = decimal.Parse(txtVolumeWt.Text);
                decimal chargeableWt = decimal.Parse(txtChargeableWt.Text);
                decimal Adhoc_Rate = decimal.Parse(txtAdhocRate.Text);
                string unitofVolWt = rbCal.SelectedValue;
                string originName = ddlOrigin.SelectedItem.Text;
                string destinationName = ddlDestination.SelectedItem.Text;
                string origin = ddlOrigin.SelectedValue;
                string destination = ddlDestination.SelectedValue;
                string shipmentType = ddlShipmentType.SelectedItem.Text;
                string shipment = ddlShipmentType.SelectedValue;
                string commodityType = ddlScr.SelectedItem.Text;
                string commodity = ddlScr.SelectedValue;
                string freightType = rbFType.SelectedValue;
                string tariffRate = txtTariffRate.Text;
                string freightAmount = txtSpAmt.Text;
                string flt_no = txtFlightNo.Text;
                //string remarks = txtAgentDealRemarks.Text;
                string spotRate = "0";
                if (txtSpotRate.Text == "")
                {
                    spotRate = "0";
                }
                else
                {
                    spotRate = txtSpotRate.Text;
                }
                string iat_comm = "0";
                if (txtIATACommission.Text == "")
                {
                    iat_comm = "0";
                }
                else
                {
                    iat_comm = txtIATACommission.Text;
                }
                string scr_incen = "0";
                if (txtSCR_Incentive.Text == "")
                {
                    scr_incen = "0";
                }
                else
                {
                    scr_incen = txtSCR_Incentive.Text;
                }
                string valueCharge = "0";
                if (txtValuationCharge.Text == "")
                {
                    valueCharge = "0";
                }
                else
                {
                    valueCharge = txtValuationCharge.Text;
                }

                string taxCharge = "0";
                if (txtTax.Text == "")
                {
                    taxCharge = "0";
                }
                else
                {
                    valueCharge = txtTax.Text;
                }
                string emailId = Session["EMailID"].ToString();
                string shipperName = txtShipper.Text;
                shipperName = shipperName.Replace("'", "`");
                string shipperAddress = txtShipperAddress.Text;
                shipperAddress = shipperAddress.Replace("'", "`");
                string consigneeName = txtConsignee.Text;
                consigneeName = consigneeName.Replace("'", "`");
                string consigneeAddress = txtConsigneeAddress.Text;
                consigneeAddress = consigneeAddress.Replace("'", "`");
                string currency = txtCurrency.Text;
                currency = currency.Replace("'", "`");
                string CGHSCode = txtCGHSCode.Text;
                CGHSCode = CGHSCode.Replace("'", "`");
                string HInfo = txtHandlingInformation.Text;
                HInfo = HInfo.Replace("'", "`");
                string Nature = txtNatureGoods.Text;
                Nature = Nature.Replace("'", "`");
                string editsales = "14";
                string srate = txtTariffRate.Text;
                string sAmt = txtSpAmt.Text;
                string deal = "14";
                string enteredOn = Convert.ToString(DateTime.Now);
                string Booking_Date = "";
                string bid = ViewState["BookID"].ToString();
                if (bid != "0")
                {
                    string strdate = "select booking_date from booking_master where booking_id='" + bid + "'";
                    DataTable dtdate = dw.GetAllFromQuery(strdate);
                    Booking_Date = dtdate.Rows[0]["booking_date"].ToString();
                }
                // FETCH DATA FOR PARTICULAR HANDOVER_ID TO MAINTAIN HISTORY

                //*************************Added On 15 June****************
                DataTable dtOfflineCityChk = dw.GetAllFromQuery("select Offline_CityID from booking_master where stock_id=(select stock_id from handover where handover_Id=" + Request.QueryString["Handover_ID"].ToString() + ") and Offline_CityID!=''");
                //************************End*****************************


                string strQuery1 = "select * from testHandover where airwaybill_No='" + awbNo + "'";
                //SqlDataAdapter da = new SqlDataAdapter(strQuery1, con,trans);
                //DataSet ds = new DataSet();
                //da.Fill(ds);
                SqlDataReader dr;
                SqlCommand cmd = new SqlCommand(strQuery1, con, trans);
                dr = cmd.ExecuteReader();
                //###############################################################################################################
                dr.Read();
                //string Booking_Date = "";
                string Flight_No = dr["Flight_No"].ToString();
                string City_Name = dr["City_Name"].ToString();
                string Destination_Name = dr["Destination_Name"].ToString();
                string Flight_Date = dr["Flight_Date"].ToString();
                string Special_Commodity_Name = dr["Special_Commodity_Name"].ToString();
                string Shipment_Name = dr["Shipment_Name"].ToString();
                string No_of_Packages = dr["No_of_Packages"].ToString();
                string Measurement_Unit = dr["Measurement_Unit"].ToString();
                string Gross_Weight = dr["Gross_Weight"].ToString();
                string Volume_Weight = dr["Volume_Weight"].ToString();
                string Charged_Weight = dr["Charged_Weight"].ToString();
                string Spot_Rate = dr["Spot_Rate"].ToString();
                string Expected_Handover_Date = dr["Expected_Handover_Date"].ToString();
                string Freight_Type = dr["Freight_Type"].ToString();
                string Tariff_Rate = dr["Tariff_Rate"].ToString();
                string Freight_Amount = dr["Freight_Amount"].ToString();
                string Entered_By = dr["Entered_By"].ToString();
                string Handover_Date = dr["Handover_Date"].ToString();
                string Special_Rate = dr["Special_Rate"].ToString();
                string Special_Amount = dr["Special_Amount"].ToString();
                string Added_To_Sales = dr["Added_To_Sales"].ToString();
                string Entered_On = dr["Entered_On"].ToString();
                string Shipper_Name = dr["Shipper_Name"].ToString();
                Shipper_Name = Shipper_Name.Replace("'", "`");
                string Shipper_Address = dr["Shipper_Address"].ToString();
                Shipper_Address = Shipper_Address.Replace("'", "`");
                string Consignee_Name = dr["Consignee_Name"].ToString();
                Consignee_Name = Consignee_Name.Replace("'", "`");
                string Consignee_Address = dr["Consignee_Address"].ToString();
                Consignee_Address = Consignee_Address.Replace("'", "`");
                string Currency = dr["Currency"].ToString();
                Currency = Currency.Replace("'", "`");
                string CHGS_Code = dr["CHGS_Code"].ToString();
                CHGS_Code = CHGS_Code.Replace("'", "`");
                string Valuation_Charge = dr["Valuation_Charge"].ToString();
                string Tax = dr["Tax"].ToString();
                int No_of_houses = int.Parse(dr["No_of_houses"].ToString());
                string Total_ACI_Fees = dr["Total_ACI_Fees"].ToString();
                string Cartridge_Charges = dr["Cartridge_Charges"].ToString();
                string Handling_Information = dr["Handling_Information"].ToString();
                Handling_Information = Handling_Information.Replace("'", "`");
                string Nature_and_Quantity = dr["Nature_and_Quantity"].ToString();
                Nature_and_Quantity = Nature_and_Quantity.Replace("'", "`");
                string DueCarrier_Type = dr["DueCarrier_Type"].ToString();
                string TotalDueAgent_Prepaid = dr["TotalDueAgent_Prepaid"].ToString();
                string Total_DueAgent_Collect = dr["TotalDueAgent_Collect"].ToString();
                string Total_DueCarrier = dr["Total_DueCarrier"].ToString();
                string Total_Prepaid = dr["Total_Prepaid"].ToString();
                string Total_Collect = dr["Total_Collect"].ToString();
                string total_amount = dr["Freight_Amount"].ToString();
                //string Email_ID1 = dr["entered_By"].ToString();
                //string Changes_From = "";
                string Disbursement_Charges = dr["DisbursementCharges"].ToString();
                string AWB_Fees = dr["AWB_Fees"].ToString();
                string MSC_Charges = dr["MSC_Charges"].ToString();
                string Cgc_Charges = dr["Cgc_Charges"].ToString();
                string DMCharges = dr["DMCharges"].ToString();
                string Remark = dr["Remarks"].ToString();
                Remark = Remark.Replace("'", "`");
                string Declared_Carriage_Value = dr["Declared_Carriage_Value"].ToString();
                Declared_Carriage_Value = Declared_Carriage_Value.Replace("'", "`");
                string Declared_Custom_Value = dr["Declared_Custom_Value"].ToString();
                Declared_Custom_Value = Declared_Custom_Value.Replace("'", "`");
                dr.Close();
                //################################################################################################################

                //while (dr.Read())
                //{
                // INSERT INTO HANDOVER_HISTORY
                string Changes_From = "";
                //string changeFrom = "";
                DataTable dtChangeFrom = dw.GetAllFromQuery("select status_name from status_master where status_Id = 10");
                if (dtChangeFrom.Rows.Count > 0)
                {
                    Changes_From = dtChangeFrom.Rows[0]["status_name"].ToString();
                }
                else
                {
                    Changes_From = "";
                }
                strQuery = "insert into Handover_History(Handover_ID,AirWayBill_No,Booking_Date,Flight_No,Origin,Destination,Flight_Date,Special_Commodity_Name,Shipment_Name,No_of_Packages,Measurement_Unit,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Entered_By,Handover_Date,Special_Rate,Special_Amount,Added_To_Sales,Entered_On,Expected_Handover_Date,Adhoc_Rate) values(@Handover_ID,@AirWayBill_No,@Booking_Date,@Flight_No,@Origin,@Destination,@Flight_Date,@Special_Commodity_Name,@Shipment_Name,@No_of_Packages,@Measurement_Unit,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Entered_By,@Handover_Date,@Special_Rate,@Special_Amount,@Added_To_Sales,@Entered_On,@Expected_Handover_Date,@Adhoc_Rate)";

                com = new SqlCommand(strQuery, con, trans);
                //PASS THE PARAMETERS 
                com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = handoverID;
                com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = awbNo;
                if (ViewState["BookID"].ToString() == "0")
                {
                    com.Parameters.Add("@Booking_Date", SqlDbType.DateTime).Value = DBNull.Value;
                }
                else
                {
                    com.Parameters.Add("@Booking_Date", SqlDbType.DateTime).Value = Booking_Date;
                }
                com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = Flight_No;
                com.Parameters.Add("@Origin", SqlDbType.VarChar).Value = City_Name;
                com.Parameters.Add("@Destination", SqlDbType.VarChar).Value = Destination_Name;
                com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = DateTime.Parse(Flight_Date);
                com.Parameters.Add("@Special_Commodity_Name", SqlDbType.VarChar).Value = Special_Commodity_Name;
                com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = Shipment_Name;
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(No_of_Packages);
                com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = Measurement_Unit;
                com.Parameters.Add("@Gross_Weight", SqlDbType.BigInt).Value = decimal.Parse(Gross_Weight);
                com.Parameters.Add("@Volume_Weight", SqlDbType.BigInt).Value = decimal.Parse(Volume_Weight);
                com.Parameters.Add("@Charged_Weight", SqlDbType.BigInt).Value = decimal.Parse(Charged_Weight);
                com.Parameters.Add("@Spot_Rate", SqlDbType.BigInt).Value = decimal.Parse(Spot_Rate);
                com.Parameters.Add("@Commission", SqlDbType.BigInt).Value = decimal.Parse(iat_comm);
                com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.BigInt).Value = decimal.Parse(scr_incen);
                com.Parameters.Add("@Expected_Handover_Date", SqlDbType.DateTime).Value = Expected_Handover_Date;
                com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = Freight_Type;
                com.Parameters.Add("@Tariff_Rate", SqlDbType.BigInt).Value = decimal.Parse(Tariff_Rate);
                com.Parameters.Add("@Freight_Amount", SqlDbType.BigInt).Value = decimal.Parse(Freight_Amount);
                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Entered_By;
                com.Parameters.Add("@Handover_Date", SqlDbType.DateTime).Value = Handover_Date;
                com.Parameters.Add("@Special_Rate", SqlDbType.BigInt).Value = decimal.Parse(Special_Rate);
                com.Parameters.Add("@Special_Amount", SqlDbType.BigInt).Value = decimal.Parse(Special_Amount);
                com.Parameters.Add("@Added_To_Sales", SqlDbType.BigInt).Value = int.Parse(Added_To_Sales);
                com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = Entered_On;
                com.Parameters.Add("@Adhoc_Rate", SqlDbType.Decimal).Value = Adhoc_Rate;

                com.ExecuteNonQuery();
                com.Dispose();

                //INSERT INTO BOOKING_AWB_HISTORY
                strQuery = "insert into Booking_AWB_History(AirWayBill_No,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Currency,CHGS_Code,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,Handling_Information,Nature_and_Quantity,DueCarrier_Type,TotalDueAgent_Prepaid,Total_DueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,total_amount,Email_ID,Changes_From,Declared_Carriage_Value,Declared_Custom_Value,Disbursement_Charges,AWB_Fees,Remarks,MSC_Charges,Cgc_Charges,DMCharges) values(@AirWayBill_No,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Currency,@CHGS_Code,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@Handling_Information,@Nature_and_Quantity,@DueCarrier_Type,@TotalDueAgent_Prepaid,@Total_DueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@total_amount,@Email_ID,@Changes_From,@Declared_Carriage_Value,@Declared_Custom_Value,@Disbursement_Charges,@AWB_Fees,@Remarks,@MSC_Charges,@Cgc_Charges,@DMCharges)";

                com = new SqlCommand(strQuery, con, trans);

                //PASS THE PARAMETER
                com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = awbNo;
                com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = Shipper_Name;
                com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = Shipper_Address;
                com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = Consignee_Name;
                com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = Consignee_Address;
                com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = Currency;
                com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = CHGS_Code;
                com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(Valuation_Charge);
                com.Parameters.Add("@Tax", SqlDbType.BigInt).Value = decimal.Parse(Tax);
                com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = No_of_houses;
                com.Parameters.Add("@Total_ACI_Fees", SqlDbType.BigInt).Value = decimal.Parse(Total_ACI_Fees);
                com.Parameters.Add("@Cartridge_Charges", SqlDbType.BigInt).Value = decimal.Parse(Cartridge_Charges);
                com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = Handling_Information;
                com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = Nature_and_Quantity;
                com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = DueCarrier_Type;
                com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.BigInt).Value = decimal.Parse(TotalDueAgent_Prepaid);
                com.Parameters.Add("@Total_DueAgent_Collect", SqlDbType.BigInt).Value = decimal.Parse(Total_DueAgent_Collect);
                com.Parameters.Add("@Total_DueCarrier", SqlDbType.BigInt).Value = decimal.Parse(Total_DueCarrier);
                com.Parameters.Add("@Total_Prepaid", SqlDbType.BigInt).Value = decimal.Parse(Total_Prepaid);
                com.Parameters.Add("@Total_Collect", SqlDbType.BigInt).Value = decimal.Parse(Total_Collect);
                com.Parameters.Add("@total_amount", SqlDbType.BigInt).Value = decimal.Parse(total_amount);
                com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Entered_By;
                com.Parameters.Add("@Changes_From", SqlDbType.VarChar).Value = Changes_From;
                com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = Declared_Carriage_Value;
                com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = Declared_Custom_Value;
                com.Parameters.Add("@Disbursement_Charges", SqlDbType.BigInt).Value = decimal.Parse(Disbursement_Charges);
                com.Parameters.Add("@AWB_Fees", SqlDbType.BigInt).Value = decimal.Parse(AWB_Fees);
                com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = Remark;
                com.Parameters.Add("@MSC_Charges", SqlDbType.VarChar).Value = MSC_Charges;
                com.Parameters.Add("@Cgc_Charges", SqlDbType.VarChar).Value = Cgc_Charges;
                com.Parameters.Add("@DMCharges", SqlDbType.VarChar).Value = DMCharges;
                com.ExecuteNonQuery();
                com.Dispose();

                // INSERT INTO HANDOVER_DIMENSIONS_HISTORY TABLE 
                if (grdCal.Rows.Count > 0)
                {
                    DataTable dt123;
                    if (Session["dtTem"] == null)
                    {
                        dt123 = (DataTable)Session["dtTemp"];
                    }
                    else
                    {
                        dt123 = (DataTable)Session["dtTem"];
                    }
                    if (dt123.Rows[0]["Sno"].ToString() == "0")
                    {

                    }
                    else
                    {
                        strQuery = "select * from handover_dimensions where handover_id = '" + handoverID + "'";
                        SqlDataReader drDim;
                        SqlCommand cmdDim = new SqlCommand(strQuery, con, trans);
                        drDim = cmdDim.ExecuteReader();
                        string l = "", w = "", h = "", vw = "", p = "", u = "";
                        int res = 0;
                        while (drDim.Read())
                        {
                            res++;
                            l = l + drDim["Length"].ToString() + ",";
                            w = w + drDim["Breadth"].ToString() + ",";
                            h = h + drDim["Height"].ToString() + ",";
                            vw = vw + drDim["Total"].ToString() + ",";
                            p = p + drDim["No_of_Packages"].ToString() + ",";
                            u = u + drDim["Measurement_Unit"].ToString() + ",";
                        }
                        drDim.Close();
                        string[] strlength = l.Split(',');
                        string[] strwidth = w.Split(',');
                        string[] strheight = h.Split(',');
                        string[] strvolumeWeight = vw.Split(',');
                        string[] strtPieces = p.Split(',');
                        string[] strunit1 = u.Split(',');

                        for (int counter = 0; counter < res; counter++)
                        {
                            string strlength1 = strlength[counter];
                            string strwidth1 = strwidth[counter];
                            string strheight1 = strheight[counter];
                            string strvolumeWeight1 = strvolumeWeight[counter];
                            string strtPieces1 = strtPieces[counter];
                            string strunit2 = strunit1[counter];
                            if (strlength1 != "")
                            {
                                string strDimensionHistory = "insert into Handover_Dimensions_History(AirWayBill_No,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit) values('" + awbNo + "','" + strtPieces1 + "','" + strlength1 + "','" + strwidth1 + "','" + strheight1 + "','" + strvolumeWeight1 + "','" + strunit2 + "')";

                                SqlCommand cmdDimnensionHistory = new SqlCommand(strDimensionHistory, con, trans);
                                cmdDimnensionHistory.ExecuteNonQuery();
                            }
                        }
                    }

                }

                //UPDATE HANDOVER TABLE
                strQuery = "update Handover set Booking_Id = @Booking_Id, Flight_open_Id = @Flight_open_Id, Stock_Id = @Stock_Id,Special_Commodity_Id = @Special_Commodity_Id, Shipment_ID=@Shipment_ID, City_ID = @City_ID, Destination_Id = @Destination_Id,Flight_Date = @Flight_Date, No_of_Packages =@No_of_Packages, Measurement_unit = @Measurement_unit, Gross_Weight = @Gross_Weight, Volume_Weight = @Volume_Weight, Charged_Weight = @Charged_Weight, spot_Rate = @spot_Rate, Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Freight_Type = @Freight_Type, tariff_rate = @tariff_rate ,freight_amount = @freight_amount, handover_date = @handover_date, entered_By = @entered_By, Special_Rate = @Special_Rate, Special_Amount = @Special_Amount, Added_To_Sales = @Added_To_Sales, Add_To_Deal = @Add_To_Deal,Last_Modified_By=@Last_Modified_By, Last_Modified_On = @Last_Modified_On,Adhoc_Rate=@Adhoc_Rate where Handover_Id = '" + handoverID + "'";

                com = new SqlCommand(strQuery, con, trans);

                // PASS THE PARAMETERS
                com.Parameters.Add("@Booking_Id", SqlDbType.Int).Value = ViewState["BookID"].ToString();
                if (ddlflightOpen.Visible == false)
                {
                    com.Parameters.Add("@Flight_open_Id", SqlDbType.Int).Value = hdnfldFlightOpenId.Value;
                }
                else
                {
                    com.Parameters.Add("@Flight_open_Id", SqlDbType.Int).Value = ddlflightOpen.SelectedItem.Value;
                }
                com.Parameters.Add("@Stock_Id", SqlDbType.Int).Value = ViewState["hStockId"].ToString();
                com.Parameters.Add("@Special_Commodity_Id", SqlDbType.Int).Value = commodity;
                com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = shipment;
                com.Parameters.Add("@City_ID", SqlDbType.Int).Value = origin;
                com.Parameters.Add("@Destination_Id", SqlDbType.Int).Value = destination;
                com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = flightDate;
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = pieces;
                com.Parameters.Add("@Measurement_unit", SqlDbType.VarChar).Value = unitofVolWt;
                com.Parameters.Add("@Gross_Weight", SqlDbType.BigInt).Value = grossWt;
                com.Parameters.Add("@Volume_Weight", SqlDbType.BigInt).Value = volumeWt;
                com.Parameters.Add("@Charged_Weight", SqlDbType.BigInt).Value = chargeableWt;
                com.Parameters.Add("@spot_Rate", SqlDbType.BigInt).Value = decimal.Parse(spotRate);
                com.Parameters.Add("@Commission", SqlDbType.BigInt).Value = decimal.Parse(iat_comm);
                com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.BigInt).Value = decimal.Parse(scr_incen);
                com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = freightType;
                com.Parameters.Add("@tariff_rate", SqlDbType.BigInt).Value = decimal.Parse(tariffRate);
                com.Parameters.Add("@freight_amount", SqlDbType.BigInt).Value = decimal.Parse(freightAmount);
                com.Parameters.Add("@handover_date", SqlDbType.DateTime).Value = handoverDate;
                com.Parameters.Add("@entered_By", SqlDbType.VarChar).Value = emailId;
                com.Parameters.Add("@Special_Rate", SqlDbType.BigInt).Value = decimal.Parse(srate);
                com.Parameters.Add("@Special_Amount", SqlDbType.BigInt).Value = decimal.Parse(sAmt);
                com.Parameters.Add("@Added_To_Sales", SqlDbType.Int).Value = editsales;
                com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = deal;
                com.Parameters.Add("@Last_Modified_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                com.Parameters.Add("@Last_Modified_On", SqlDbType.DateTime).Value = DateTime.Now;
                com.Parameters.Add("@Adhoc_Rate", SqlDbType.Decimal).Value = Adhoc_Rate;

                com.ExecuteNonQuery();
                com.Dispose();

                //UPDATE Booking Master
                string strbookupdate = "update booking_master set  Flight_open_Id = @Flight_open_Id, Flight_Date = @Flight_Date,Special_Commodity_Id = @Special_Commodity_Id, Shipment_ID=@Shipment_ID,Destination_Id = @Destination_Id, No_of_Packages =@No_of_Packages, Measurement_unit = @Measurement_unit, Gross_Weight = @Gross_Weight, Volume_Weight = @Volume_Weight, Charged_Weight = @Charged_Weight,spot_Rate = @spot_Rate, Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Freight_Type = @Freight_Type, tariff_rate = @tariff_rate ,freight_amount = @freight_amount, Special_Rate = @Special_Rate, Special_Amount = @Special_Amount,Adhoc_Rate=@Adhoc_Rate where Booking_ID = '" + ViewState["BookID"].ToString() + "'";

                com = new SqlCommand(strbookupdate, con, trans);

                // PASS THE PARAMETERS
                if (ddlflightOpen.Visible == false)
                {
                    com.Parameters.Add("@Flight_open_Id", SqlDbType.Int).Value = hdnfldFlightOpenId.Value;
                }
                else
                {
                    com.Parameters.Add("@Flight_open_Id", SqlDbType.Int).Value = ddlflightOpen.SelectedItem.Value;
                }
                
                com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = flightDate;
                com.Parameters.Add("@Special_Commodity_Id", SqlDbType.Int).Value = commodity;
                com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = shipment;
                com.Parameters.Add("@Destination_Id", SqlDbType.Int).Value = destination;
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = pieces;
                com.Parameters.Add("@Measurement_unit", SqlDbType.VarChar).Value = unitofVolWt;
                com.Parameters.Add("@Gross_Weight", SqlDbType.BigInt).Value = grossWt;
                com.Parameters.Add("@Volume_Weight", SqlDbType.BigInt).Value = volumeWt;
                com.Parameters.Add("@Charged_Weight", SqlDbType.BigInt).Value = chargeableWt;
                com.Parameters.Add("@spot_Rate", SqlDbType.BigInt).Value = decimal.Parse(spotRate);
                com.Parameters.Add("@Commission", SqlDbType.BigInt).Value = decimal.Parse(iat_comm);
                com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.BigInt).Value = decimal.Parse(scr_incen);
                com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = freightType;
                com.Parameters.Add("@tariff_rate", SqlDbType.BigInt).Value = decimal.Parse(tariffRate);
                com.Parameters.Add("@freight_amount", SqlDbType.BigInt).Value = decimal.Parse(freightAmount);
                com.Parameters.Add("@Special_Rate", SqlDbType.BigInt).Value = decimal.Parse(srate);
                com.Parameters.Add("@Special_Amount", SqlDbType.BigInt).Value = decimal.Parse(sAmt);
                com.Parameters.Add("@Adhoc_Rate", SqlDbType.Decimal).Value = Adhoc_Rate;

               
                com.ExecuteNonQuery();
                com.Dispose();


                // UPDATE BOOKING_AWB TABLE
                strQuery = "update Booking_AWB set Shipper_Name='" + shipperName + "',Shipper_Address='" + shipperAddress + "',Consignee_Name='" + consigneeName + "',Consignee_Address= '" + consigneeAddress + "', Currency= '" + currency + "',CHGS_Code= '" + CGHSCode + "',Declared_Carriage_Value='" + txtDVCarriage.Text.Replace("'", "`") + "',Declared_Custom_Value='" + txtDVCustom.Text.Replace("'", "`") + "', Disbursement_Charges='" + Convert.ToDecimal(txtDisbursmentCharges.Text) + "',AWB_Fees='" + Convert.ToDecimal(txtAWBFee.Text) + "',Valuation_Charge='" + valueCharge + "',Tax='" + taxCharge + "',No_of_houses='" + Convert.ToInt32(txtHouses.Value) + "',Total_ACI_Fees='" + Convert.ToDecimal(txtACIFee.Text) + "',Cartridge_Charges='" + Convert.ToDecimal(txtCatrage.Text) + "',Handling_Information='" + HInfo + "',Nature_and_Quantity='" + Nature + "',DueCarrier_Type='" + rbDueFreight.SelectedValue + "',TotalDueAgent_Prepaid='" + Convert.ToDecimal(txtDueAgentP.Text) + "',TotalDueAgent_Collect='" + Convert.ToDecimal(txtDueAgentC.Text) + "',Total_DueCarrier='" + Convert.ToDecimal(txtDueCarrier.Text) + "',Total_Prepaid='" + Convert.ToDecimal(txtPrepaid.Text) + "',Total_Collect='" + Convert.ToDecimal(txtCollect.Text) + "',War_Surcharges='" + Convert.ToDecimal(txtWSC.Text) + "',Fuel_Surcharges = '" + Convert.ToDecimal(txtFSC.Text) + "',Xray_Charges = '" + Convert.ToDecimal(txtXRAY.Text) + "',MSC_Charges= '" + Convert.ToDecimal(txtMSC.Text) + "',Cgc_Charges='"+Convert.ToDecimal(txtCGC.Text)+"',DMCharges='"+Convert.ToDecimal(txtDmcharges.Text)+"' where handover_ID='" + handoverID + "'";

                com = new SqlCommand(strQuery, con, trans);
                com.ExecuteNonQuery();
                com.Dispose();

                // UPDATE OTHER_CHARGES TABLE
                //BEFORE UPDATATION THIS TABLE WE'LL DELETE ALL RECORDS BELONG TO THIS HANDOVER_ID
                strQuery = "delete from other_charges where handover_id = '" + handoverID + "'";
                com = new SqlCommand(strQuery, con, trans);
                com.ExecuteNonQuery();
                com.Dispose();

                // NOW INSERT INTO OTHER_CHARGES TABLES AGAINST HANDOVER_ID 
                if (grd.Rows.Count > 0)
                {
                    DataTable dtOthersCharges;

                    if (Session["dtOther"] == null)
                    {
                        dtOthersCharges = (DataTable)Session["dtOtherCharges"];
                    }
                    else
                    {
                        dtOthersCharges = (DataTable)Session["dtOther"];
                    }
                    if (dtOthersCharges.Rows[0]["Sno"].ToString() == "0")
                    {

                    }
                    else
                    {
                        foreach (DataRow d in dtOthersCharges.Rows)
                        {
                            string feeName = d["feeName"].ToString();
                            feeName = feeName.Replace("'", "`");
                            decimal fee = decimal.Parse(d["fee"].ToString());
                            string paymentType = d["PaymentType"].ToString();

                            string strOtherCharge = "insert into Other_Charges(Booking_ID,Handover_ID,AirWayBill_No,Charge_Name,Amount,Prepaid_or_Collect) values('" + ViewState["BookID"].ToString() + "','" + handoverID + "','" + txtAWBNo.Text + "','" + feeName + "','" + fee + "','" + paymentType + "')";

                            SqlCommand cmdOtherCharges = new SqlCommand(strOtherCharge, con, trans);
                            cmdOtherCharges.ExecuteNonQuery();
                        }
                    }
                }

                //INSERT INTO HANDOVER_DIMENSIONS TABLE
                strQuery = "delete from handover_dimensions where handover_id = '" + handoverID + "'";
                com = new SqlCommand(strQuery, con, trans);
                com.ExecuteNonQuery();
                com.Dispose();

                if (grdCal.Rows.Count > 0)
                {
                    DataTable dt12;
                    if (Session["dtTem"] == null)
                    {
                        dt12 = (DataTable)Session["dtTemp"];
                    }
                    else
                    {
                        dt12 = (DataTable)Session["dtTem"];
                    }
                    if (dt12.Rows[0]["Sno"].ToString() == "0")
                    {

                    }
                    else
                    {
                        foreach (DataRow rw in dt12.Rows)
                        {
                            int tPieces = int.Parse(rw["Pieces"].ToString());
                            decimal VolWt = decimal.Parse(rw["Volume Wt"].ToString());
                            decimal volumeWeight = System.Math.Round(VolWt, MidpointRounding.AwayFromZero);
                            int length = int.Parse(rw["Length"].ToString());
                            int width = int.Parse(rw["width"].ToString());
                            int height = int.Parse(rw["height"].ToString());

                            string strDimension = "insert into Handover_Dimensions(Handover_ID,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit) values('" + handoverID + "','" + tPieces + "','" + length + "','" + width + "','" + height + "','" + volumeWeight + "','" + rbCal.SelectedValue + "')";

                            SqlCommand cmdDimnension = new SqlCommand(strDimension, con, trans);
                            cmdDimnension.ExecuteNonQuery();
                        }
                    }
                }
                string strupdt = "update stock_master set Used_Date = '" + awbDate + "' where AirWayBill_No = '" + txtAWBNo.Text + "'";
                SqlCommand cmdUpdate1 = new SqlCommand(strupdt, con, trans);
                cmdUpdate1.ExecuteNonQuery();

                //UPDATE CREDIT LIMIT 
                decimal updtLim = decimal.Parse(ViewState["updtLimit"].ToString());
                string agentID = "";
                string strAgent = "select * from agent_master where agent_Name = '" + lblAgent.Text.Trim() + "'";
                DataTable dtAgent = dw.GetAllFromQuery(strAgent);
                if (dtAgent.Rows.Count > 0)
                {
                    agentID = dtAgent.Rows[0]["agent_Id"].ToString();
                }
                string strCreditLimit = "update agent_master set used_Limit = '" + updtLim + "' where agent_id = '" + agentID + "'";
                
                SqlCommand cmdLimit = new SqlCommand(strCreditLimit, con, trans);
                cmdLimit.ExecuteNonQuery();
                //************************************************************************************************
                trans.Commit();
                con.Close();
                pnlHandoverDetails.Visible = false;
                Panel1.Visible = false;
                //lblErrorMsg.Text = "Handover successfully updated.";
                Response.Redirect("HandoverDetails.aspx");
                //*************************************************************************************************
            }
            catch (SqlException sqe)
            {
                lblErrorMsg.Text = "sql error" + sqe.Message;
                trans.Rollback();
            }
            finally
            {
                con.Close();
            }
        }
    }

    public void checkLimit()
    {
        decimal creditLimit = 0;
        decimal usedLimit = 0;
        string creditLim = "";
        string usedLim = "";
        decimal remainLimit = 0;
        decimal netBooking = 0;
        decimal limit = 0;
        decimal totalAmount = 0;
        decimal DueCarrier = 0;
        decimal FreightAmt = 0;
        decimal HandoverAmt = 0;
        decimal HandOverAmount = 0;

        DueCarrier = decimal.Parse(txtDueCarrier.Text);
        FreightAmt = decimal.Parse(txtFreightAmount.Text);
        totalAmount = DueCarrier + FreightAmt;
        HandOverAmount = DueCarrier + FreightAmt;

        con = new SqlConnection(strCon);
        string strQuery = "select isnull(Used_Limit,0) as Used_Limit,isnull(Credit_Limit,0) as Credit_Limit,isnull(Amount_Paid,0) as Amount_Paid from Agent_Branch where agent_ID =" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["CityID"].ToString();
        SqlDataAdapter da = new SqlDataAdapter(strQuery, con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            creditLim = ds.Tables[0].Rows[0]["Credit_Limit"].ToString();
            usedLim = ds.Tables[0].Rows[0]["Used_Limit"].ToString();
        }
        //********************Added On 8 Apr 2011 for Offline agent Case*********
        //else
        //{
        //    DataTable dtOffBookingID = dw.GetAllFromQuery("select Booking_Id from handover where Handover_Id=" + Request.QueryString["Handover_ID"] + "");
        //    if (dtOffBookingID.Rows.Count > 0)
        //    {
        //        DataTable dtOfflineCity = dw.GetAllFromQuery("select Offline_CityId from booking_master where booking_id=" + dtOffBookingID.Rows[0]["Booking_Id"].ToString() + "");
        //        if (dtOfflineCity.Rows.Count > 0)
        //        {
        //            DataTable dtOffLimit = dw.GetAllFromQuery("select isnull(Used_Limit,0) as Used_Limit,isnull(Credit_Limit,0) as Credit_Limit,isnull(Amount_Paid,0) as Amount_Paid from Agent_Branch where agent_ID =" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtOfflineCity.Rows[0]["Offline_CityId"].ToString());

        //            if (dtOffLimit.Rows.Count > 0)
        //            {
        //                creditLim = dtOffLimit.Rows[0]["Credit_Limit"].ToString();
        //                usedLim = dtOffLimit.Rows[0]["Used_Limit"].ToString();
        //            }
        //        }
        //    }
        //}
        else
        {
            DataTable dtOffBookingID = dw.GetAllFromQuery("select Booking_Id from handover where Handover_Id=" + Request.QueryString["Handover_ID"] + "");
            if (dtOffBookingID.Rows.Count > 0)
            {
                DataTable dtOfflineCity = dw.GetAllFromQuery("select Offline_CityId from booking_master where booking_id=" + dtOffBookingID.Rows[0]["Booking_Id"].ToString() + " and Offline_CityID!=''");
                if (dtOfflineCity.Rows.Count > 0)
                {

                    strQuery = "select isnull(Used_Limit,0) as Used_Limit,isnull(Credit_Limit,0) as Credit_Limit,isnull(Amount_Paid,0) as Amount_Paid from Agent_Branch where agent_ID =" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtOfflineCity.Rows[0]["offline_cityID"].ToString();

                    da = new SqlDataAdapter(strQuery, con);
                    ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        creditLim = ds.Tables[0].Rows[0]["Credit_Limit"].ToString();
                        usedLim = ds.Tables[0].Rows[0]["Used_Limit"].ToString();
                    }
                    else
                    {
                        strQuery = "select isnull(Used_Limit,0) as Used_Limit,isnull(Credit_Limit,0) as Credit_Limit,isnull(Amount_Paid,0) as Amount_Paid from Agent_Branch where agent_ID =" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtOfflineCity.Rows[0]["offline_cityID"].ToString();

                        da = new SqlDataAdapter(strQuery, con);
                        ds = new DataSet();
                        da.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            creditLim = ds.Tables[0].Rows[0]["Credit_Limit"].ToString();
                            usedLim = ds.Tables[0].Rows[0]["Used_Limit"].ToString();
                        }
                    }
                }
            }

        }
        //*******************End Offline Case************************************
        if (creditLim == "")
        {
            creditLimit = 0;
        }
        else
        {
            creditLimit = decimal.Parse(creditLim);
        }
        if (usedLim == "")
        {
            usedLimit = 0;
        }
        else
        {
            usedLimit = decimal.Parse(usedLim);
        }

        if (ViewState["NetUsed"] == null)
        {
            netBooking = 0;
        }
        else
        {
            netBooking = decimal.Parse(ViewState["NetUsed"].ToString());
        }
        totalAmount = usedLimit + totalAmount;

        remainLimit = creditLimit - usedLimit + decimal.Parse(ds.Tables[0].Rows[0]["Amount_Paid"].ToString());
        // HandoverAmt = totalAmount + limit;
        ViewState["updtLimit"] = totalAmount;
        if (remainLimit < HandOverAmount)
        {
            //CHECK FOR REMAINING LIMIT < HANDOVER AMOUNT
            lblErrorMsg.Text = "Your credit limit is too low for handover";
        }
        else
        {
            //CHECK FOR REMAINING LIMIT > HANDOVER AMOUNT

            if (Request.QueryString["Handover_ID"] != null)
            {
                updateHandover();
            }
            else
            {
                DataTable AirlineDetailID = dw.GetAllFromQuery("SELECT  am.Airline_Code, ad.Airline_ID, ad.Belongs_To_City, ad.Airline_Detail_ID FROM Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID where am.Airline_Code=" + txtAWBNo.Text.Substring(0, 3) + " and ad.Belongs_To_City=" + ddlOrigin.SelectedValue);
                ViewState["AirlineDetailID"] = AirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString();
                //addHandover();
            }
        }
        //}
    }

    protected void btnAdd_OnClick(object sender, EventArgs e)
    {
        string flightDate = "";
        flightDate = txtFlightDate.Text;
        string hdate = "";
        hdate = txthandover_date.Text;
        DateTime dt = DateTime.Now;
        string curDate = FormatDateMM(Convert.ToString(dt.ToShortDateString()));
        // bool val = compareCurDate(hdate, curDate);
        //if (val == true)
        //{           
        DataTable dtStock = dw.GetAllFromQuery("select stock_ID From Stock_Master where AirWayBill_No='" + txtAWBNo.Text + "'");
        DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Handover where Stock_ID=" + dtStock.Rows[0]["stock_ID"].ToString());
        if (dtAWBCheck.Rows.Count <= 0)
        {
            lblAWBmsg.Visible = false;
            bool ret = compareDate(flightDate, hdate);
            if (ret == true)
            {
                checkLimit();
            }
            else
            {
                lblErrorMsg.Text = "Please Change Handover date,Handover Date is less than or equal to Flight Date.";
            }
        }
        else
        {
            lblAWBmsg.Visible = true;
        }

        //}
        //else
        //{
        //    Page.MaintainScrollPositionOnPostBack = false;
        //    lblErrorMsg.Text = "Handover date should not be less than current date.";
        //}

    }
    public bool compareDate(string first, string second)
    {
        string[] cdate1 = first.Split('/');
        string[] cdate2 = second.Split('/');

        int fd = Convert.ToInt32(cdate1[0]);
        int fm = Convert.ToInt32(cdate1[1]);
        int fy = Convert.ToInt32(cdate1[2]);

        int sd = Convert.ToInt32(cdate2[0]);
        int sm = Convert.ToInt32(cdate2[1]);
        int sy = Convert.ToInt32(cdate2[2]);

        DateTime dt1 = new DateTime(fy, fm, fd);
        DateTime dt2 = new DateTime(sy, sm, sd);

        if (DateTime.Compare(dt1, dt2) > 0 || DateTime.Compare(dt1, dt2) == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    protected void RateGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            bool disC = true;

            bool disOnMin = true;
            bool MinCheck = true;
            //decimal TariffRate=decimal.Parse(e.Row.Cells[5].Text);
            decimal TotalPayableAmount = decimal.Parse(e.Row.Cells[6].Text) * decimal.Parse(txtChargeableWt.Text);
            decimal Min = decimal.Parse(ViewState["Min"].ToString());
            decimal TariffRate = decimal.Parse(e.Row.Cells[6].Text);
            if (TotalPayableAmount > Min)
            {
                decimal TPA = Math.Round(TotalPayableAmount, 2);
                e.Row.Cells[7].Text = TPA.ToString();
            }
            else//Minimum Case
            {
                MinCheck = false;
                decimal Minimum = Math.Round(Min, 2);
                e.Row.Cells[7].Text = Minimum.ToString();
                e.Row.Cells[6].Text = Minimum.ToString();//change bye Rajinder

                string flight_openid = e.Row.Cells[12].Text;
                //******************Minimum pe Discount******************

                con = new SqlConnection(strCon);
                com = new SqlCommand("[HANDOVER_MIN_RATE]", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Origin", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
                com.Parameters.Add("@Destination", SqlDbType.BigInt).Value = long.Parse(ddlDestination.SelectedValue);
                com.Parameters.Add("@FlightDate", SqlDbType.DateTime).Value = FormatDateDD(txthandover_date.Text);
                com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
                com.Parameters.Add("@Agent_Rate_ID", SqlDbType.Int).Value = Convert.ToInt64(ViewState["AgentRateID"]);

                com.Parameters.Add("@AgentSlabID", SqlDbType.Int).Value = Convert.ToInt32(ViewState["SlabID"]);

                com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(ddlShipmentType.SelectedValue);
                //com.Parameters.Add("@Flightdays", SqlDbType.Int).Value = int.Parse(txtFlightDays.Value);
                com.Parameters.Add("@Flight_Open_Id", SqlDbType.BigInt).Value = long.Parse(flight_openid);

                SqlDataAdapter da = new SqlDataAdapter(com);
                DataTable dt_Min_Rate = new DataTable();
                da.Fill(dt_Min_Rate);
                if (dt_Min_Rate.Rows.Count > 0)
                {
                    disOnMin = false;

                    e.Row.Cells[11].Text = dt_Min_Rate.Rows[0]["Prefix_Name"].ToString();
                    e.Row.Cells[8].Text = dt_Min_Rate.Rows[0]["DiscountedRate"].ToString();
                    e.Row.Cells[9].Text = dt_Min_Rate.Rows[0]["DiscountedRate"].ToString();
                }

            }

            //decimal TariffRate = decimal.Parse(e.Row.Cells[6].Text);
            decimal nextslabrate = Convert.ToDecimal(ViewState["BeneficialPriceValue"]) * Convert.ToDecimal(ViewState["nextslabChwt"]);
            ViewState["nextslabrate"] = nextslabrate;
            decimal freightamount = decimal.Parse(e.Row.Cells[7].Text);

            //if (Convert.ToDecimal(ViewState["BeneficialPriceValue"]) >= TariffRate)

            //******When nextSlab is not Exist In case of AirlineSlab not Exist***********
            if (ViewState["BeneficialPriceValue"] == null && ViewState["nextslabChwt"] == null)
            {
                e.Row.Cells[10].Text = "NA";
              
            }
            if (nextslabrate >= freightamount)
            {
                e.Row.Cells[10].Text = "NA";
               
            }
            else
            {
                if (nextslabrate != 0)
                {
                    NA = 1;
                    ViewState["Flag"] = "1";
                    //lblMessage.Visible = true;
                  

                    e.Row.Cells[10].Text = ViewState["BeneficialPriceValue"].ToString();
                    decimal strNextSlabRate = decimal.Parse(e.Row.Cells[10].Text) * Convert.ToDecimal(ViewState["nextslabChwt"]);
                    //decimal strNextSlabRate =decimal.Parse(e.Row.Cells[10].Text) * decimal.Parse(txtChWt.Value);
                    e.Row.Cells[10].Text = strNextSlabRate.ToString();
                }
                else
                {
                   
                    e.Row.Cells[10].Text = "NA";
                }
            }
            //if (MinCheck == false && disOnMin == false)//Minimum ke case main Can not enter in these Prefix
            //{
            if (e.Row.Cells[11].Text.Trim() == "-")
            {
                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //     e.Row.Cells[7].Text="0";
                //     e.Row.Cells[8].Text="0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) - decimal.Parse(e.Row.Cells[9].Text);
                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChargeableWt.Text);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                //DiscountedRate = Math.Round(DiscountedRate, 2);

                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt=decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChargeableWt.Text), 2));
                }
                else
                {
                    if (disOnMin == true)
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        // e.Row.Cells[9].Text = Min_rate.ToString(); //Change By Rajinder
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder

                    }
                    else
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }

                }
                //e.Row.Cells[9].Text = DiscountedRate.ToString();
                //}
            }

            if (e.Row.Cells[11].Text.Trim() == "+")
            {

                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //    e.Row.Cells[7].Text = "0";
                //    e.Row.Cells[8].Text = "0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) + decimal.Parse(e.Row.Cells[9].Text);

                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChargeableWt.Text);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //DiscountedRate = DiscountedRate * decimal.Parse(txtChWt.Value);
                //DiscountedRate = Math.Round(DiscountedRate, 2);
                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt = decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChargeableWt.Text), 2));
                }
                else
                {
                    if (disOnMin == true)
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        //e.Row.Cells[9].Text = Min_rate.ToString();//Change By Rajinder
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder

                    }
                    else
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }

                }

                //e.Row.Cells[9].Text = DiscountedRate.ToString();
                //}
            }
            if (e.Row.Cells[11].Text.Trim() == "%")
            {
                //if (decimal.Parse(e.Row.Cells[8].Text) == 0)
                //{
                //    e.Row.Cells[7].Text = "0";
                //    e.Row.Cells[8].Text = "0";
                //}
                //else
                //{
                disC = false;
                decimal DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) * decimal.Parse(e.Row.Cells[9].Text);
                DiscountedRate = DiscountedRate / 100;
                // e.Row.Cells[8].Text = DiscountedRate.ToString();
                DiscountedRate = decimal.Parse(e.Row.Cells[6].Text) - DiscountedRate;
                DiscountedRate = Math.Round(DiscountedRate, 2);
                e.Row.Cells[8].Text = DiscountedRate.ToString();

                if (disOnMin == false)
                {
                    DiscountedRate = DiscountedRate;
                }
                else
                {
                    DiscountedRate = DiscountedRate * decimal.Parse(txtChargeableWt.Text);
                }
                DiscountedRate = Math.Round(DiscountedRate, 2);

                //if (DiscountedRate > Min)
                //{
                if (MinCheck == true)//Change by Rajinder(DiscountRate is less than Minimum)
                {
                    //decimal SpecialAmt = decimal.Parse(e.Row.Cells[7].Text) - decimal.Parse(e.Row.Cells[8].Text);
                    //e.Row.Cells[9].Text = SpecialAmt.ToString();
                    e.Row.Cells[9].Text = Convert.ToString(Math.Round(decimal.Parse(e.Row.Cells[8].Text) * decimal.Parse(txtChargeableWt.Text), 2));
                }
                else
                {
                    if (disOnMin == true)  // Minimum Case Discount Not Issue
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = SpecialAmt.ToString();//Change By Rajinder
                        e.Row.Cells[8].Text = SpecialAmt.ToString();//Change By Rajinder
                    }
                    else// Minimum Case Discount Issue
                    {
                        decimal Min_rate = Math.Round(Min, 2);
                        decimal SpecialAmt = Min_rate - decimal.Parse(e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[9].Text = (e.Row.Cells[8].Text);//Change By Rajinder
                        e.Row.Cells[8].Text = e.Row.Cells[9].Text;//Change By Rajinder
                    }
                }

                //}
                // }
            }//*****End of MinCheck True and DisonMin true*********
            if (disC == true)
            {
                e.Row.Cells[9].Text = e.Row.Cells[7].Text;//Change By Rajinder
                e.Row.Cells[8].Text = e.Row.Cells[6].Text;//Change By Rajinder
            }
            //checking for discounting rate to min rate

            //decimal d_rate = decimal.Parse(e.Row.Cells[9].Text);
            //if (drate)
            //{
            //    if (drate > Min)
            //    {
            //        e.Row.Cells[9].Text = d_rate;
            //    }
            //    else
            //    { 
            //         decimal Min_rate = Math.Round(Min, 2);
            //         e.Row.Cells[9].Text = Min_rate;
            //    }
            //}

            //******************************************************
            //e.Row.Cells[11].Visible = false;

            //*********Time Field***************
            // e.Row.Cells[].Text

            //***********City and Destination***********
            int CityID = Convert.ToInt32(e.Row.Cells[4].Text);
            long DestinationID = Convert.ToInt64(e.Row.Cells[5].Text);
            DataTable dtCity = dw.GetAllFromQuery("select City_Name,City_Code from City_Master where City_ID=" + ddlOrigin.SelectedValue);
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Name,Destination_Code from Destination_Master where Destination_ID=" + DestinationID);
            if (dtCity.Rows.Count > 0)
            {
                e.Row.Cells[4].Text = dtCity.Rows[0]["City_Code"].ToString();
            }
            if (dtDestination.Rows.Count > 0)
            {
                e.Row.Cells[5].Text = dtDestination.Rows[0]["Destination_Code"].ToString();
            }
        }
        e.Row.Cells[11].Visible = false;
        e.Row.Cells[12].Visible = false;//10:08 prefix name

    }


    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public string convertDate(string date)
    {
        string[] datearray = date.Split('/');
        string convertDate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
        return convertDate;
    }
    public void DueCarrierSelect()
    {
        decimal A = 0, B = 0, C = 0, Gw = 0, Cw = 0, FSC = 0, AWBFee = 0, DisbursmentCharges = 0, ACIFee = 0, Security_Surcharge = 0, Xray = 0;
        if (txtGrossWt.Text != "" && txtChargeableWt.Text != "")
        {
            Gw = decimal.Parse(txtGrossWt.Text);
            Cw = decimal.Parse(txtChargeableWt.Text);
        }

        DataTable dtCharges = dw.GetAllFromQuery("select FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,DisBursementCharges from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());


        DataTable dtAgentRateID = dw.GetAllFromQuery("select Agent_Rate_ID from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and Destination=" + ddlDestination.SelectedValue + " and Shipment_ID=" + ddlShipmentType.SelectedValue + " and Status=2 and valid_from <= '" + FormatDateDD(txtFlightDate.Text) + "' and valid_to >= '" + FormatDateDD(txtFlightDate.Text) + "'");
        long AgentRateID = 0;
        DataTable dtChargesDetails = new DataTable();
        if (dtAgentRateID.Rows.Count > 0)
        {

            dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue + " and Agent_Rate_ID=" + long.Parse(dtAgentRateID.Rows[0]["Agent_Rate_ID"].ToString()));
        }
        if (dtCharges.Rows.Count > 0)
        {
            if (dtCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Cw * FSC;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        FSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                        A = Gw * FSC;
                    }
                }
            }
            if (dtCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Cw * Security_Surcharge;
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Security_Surcharge = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                        B = Gw * Security_Surcharge;
                    }
                }
            }
            if (dtCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
            {
                if (dtCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Cw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
                else
                {
                    if (dtChargesDetails.Rows.Count > 0)
                    {
                        Xray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                        C = Gw * Xray;
                        DataTable dtFixCharges = dw.GetAllFromQuery("select Min_XRay_Charges from Fix_Charges");
                        if (dtFixCharges.Rows.Count > 0)
                        {
                            if (C <= decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString()))
                            {
                                C = decimal.Parse(dtFixCharges.Rows[0]["Min_XRay_Charges"].ToString());
                            }
                            else
                            {
                                C = C;
                            }
                        }
                    }
                }
            }
            A = Math.Round(A, MidpointRounding.AwayFromZero);
            B = Math.Round(B, MidpointRounding.AwayFromZero);
            C = Math.Round(C, MidpointRounding.AwayFromZero);
            txtFSC.Text = A.ToString();
            txtWSC.Text = B.ToString();
            txtXRAY.Text = C.ToString();
            DataTable dtOrigin = dw.GetAllFromQuery("select City_ID from City_Master where City_Code='" + ddlOrigin.SelectedItem.Text.Substring(0, 3) + "'");



           
            //**** For End ofAWB Fee*****************
            decimal TotalDueCarrier = A + B + C + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtCGC.Text)+decimal.Parse(txtDmcharges.Text);
            TotalDueCarrier = Math.Round(TotalDueCarrier, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = TotalDueCarrier.ToString();

            if (rbDueFreight.SelectedValue == "PREPAID")
            {
                decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Total_Prepaid = Total_Prepaid + decimal.Parse(txtFreightAmount.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = txtDueAgentC.Text;
                }
                else
                {
                    decimal Total_Collect = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentC.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = Total_Prepaid.ToString();
                }
            }
            else
            {
                decimal Total_Collect = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentC.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    decimal Total_Prepaid = decimal.Parse(txtFreightAmount.Text) + decimal.Parse(txtDueAgentP.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = Total_Collect.ToString();
                }
                else
                {
                    Total_Collect = Total_Collect + decimal.Parse(txtFreightAmount.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = txtDueAgentP.Text;
                }
            }
        }
    }

    protected void btnFill_Click(object sender, EventArgs e)
    {

        string airlineID = "";
        string airDetailID = "";

        DataSet dsAWBNo;

        string awbNo = txtAWBNo.Text;

        //CHECK FOR AWB NO. EXISTS OR NOT
        string strCheckAWBNo = "select * from stock_master S inner join Agent_master A on S.agent_Id = A.Agent_ID inner join city_master C on S.city_ID = C.city_ID where AirWayBill_No = '" + awbNo + "' and (status = '16' or status = '9' )";
        dsAWBNo = new DataSet();
        dsAWBNo = DHandover.checkAWBNo(strCheckAWBNo);
        if (dsAWBNo.Tables[0].Rows.Count > 0)
        {

            lblErrorMsg.Visible = false;
            string cityID = dsAWBNo.Tables[0].Rows[0]["City_ID"].ToString();
            string airlineCode = txtAWBNo.Text.Trim();
            airlineCode = airlineCode.Substring(0, 3);
            DataTable dtAirlineID = dw.GetAllFromQuery("select airline_id from airline_master where airline_code = '" + airlineCode + "'");
            if (dtAirlineID.Rows.Count > 0)
            {
                airlineID = dtAirlineID.Rows[0]["Airline_ID"].ToString();
                ViewState["Airlilne"] = airlineID;
            }
            DataTable dtAirlineDetail = dw.GetAllFromQuery("select * from airline_detail where airline_Id = '" + airlineID + "' and belongs_to_City = '" + cityID + "'");
            if (dtAirlineDetail.Rows.Count > 0)
            {
                airDetailID = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
                ViewState["Airline_Detail_Id"] = airDetailID;
                txtAWBFee.Text = dtAirlineDetail.Rows[0]["AWB_Fees"].ToString();
                txtACIFee.Text = dtAirlineDetail.Rows[0]["ACI_Fees"].ToString();
                txtDisbursmentCharges.Text = dtAirlineDetail.Rows[0]["DisBursementCharges"].ToString();
            }
            string strDestination = "select distinct Destination_ID,Destination_Name from agent_rate_master A inner join destination_master D on A.destination=D.Destination_ID where  A.airline_detail_Id = '" + airDetailID + "'";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strDestination, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Clear();
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Name"].ToString(), dr["Destination_Id"].ToString()));
            }
            dr.Close();
            con.Close();

            string awbStockID = dsAWBNo.Tables[0].Rows[0]["Stock_ID"].ToString();
            ViewState["DStockId"] = awbStockID;
            string agentID = dsAWBNo.Tables[0].Rows[0]["Agent_Id"].ToString();
            ViewState["Agent_ID"] = dsAWBNo.Tables[0].Rows[0]["Agent_Id"].ToString();
            lblAgent.Text = dsAWBNo.Tables[0].Rows[0]["Agent_Name"].ToString();
            ddlOrigin.Items.Clear();
            ddlOrigin.Items.Add(new ListItem(dsAWBNo.Tables[0].Rows[0]["City_Name"].ToString(), dsAWBNo.Tables[0].Rows[0]["City_Id"].ToString()));
            //CHECK FOR AWB NO IS BOOKED OR NOT
            string checkBooking = "select * from booking_master where stock_Id = '" + awbStockID + "'" + " and status=9";
            dsAWBNo = new DataSet();
            dsAWBNo = DHandover.checkAWBNo(checkBooking);
            if (dsAWBNo.Tables[0].Rows.Count > 0)
            {
                lblAWBNoMsg.Visible = true;
                lblAWBNoMsg.Text = "This AWB No. is already Booked Pls select another AWB No.";
                

            }
            else
            {
                //lblErrorMsg.Text = "AWB No is available.";
                pnlHandoverDetails.Visible = true;
                //pnlSpotRate.Visible = false;
                pnlMoreDetail.Visible = false;
                fillDirectHandover();
            }
        }
        else
        {
            lblAWBNoMsg.Visible = true;
            lblAWBNoMsg.Text = "AWB No does not exist";
            // lblErrorMsg.Text = "AWB No does not exist.";
           
            pnlHandoverDetails.Visible = false;
        }

    }

    protected void btnCancel_OnClick(object sender, EventArgs e)
    {
        if (Request.QueryString["Booking_ID"] != null)
        {
            Response.Redirect("Booking_details.aspx");
        }
        else if (Request.QueryString["Handover_ID"] != null)
        {
            Response.Redirect("HandoverDetails.aspx");
        }
        else
        {
            Response.Redirect("Handover_new.aspx");
        }
    }

    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
     
        
    }

    protected void ddlflightOpen_SelectedIndexChanged1(object sender, EventArgs e)
    {
        string[] strflt_text = ddlflightOpen.SelectedItem.Text.Split('(');
        string[] strflt_text1 = strflt_text[1].Split(')');
        string strflt_val = ddlflightOpen.SelectedItem.Value;
        txtFlightNo.Text = strflt_text[0].ToString();
        txtFlightDate.Text = strflt_text1[0].ToString();
    }
}
