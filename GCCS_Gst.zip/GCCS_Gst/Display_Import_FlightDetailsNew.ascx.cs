using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
public partial class Display_Import_FlightDetailsNew : System.Web.UI.UserControl
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    SqlTransaction trans = null;
    DisplayWrap dw = new DisplayWrap();
    GridView gv = new GridView();
    DataTable DtImportChargesHeads = new DataTable();

    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    bool flag = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        #region from Do_Print_Gst
                //public void Display()
                //    {
                //        lblAddress1.Visible = true;
                //        lblAddress.Visible = true;
                //        #region htmlregion
                //        lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td>
                //                                 </tr>";
                //        lblAddresshtml = @"<tr>
                //                    <td style='height: 50px;' colspan='2'>
                //                        <div style='width: 320px;'>
                //                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
                //                                border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                    style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                    webkit-border-vertical-spacing: 2px'>
                //                                    <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'></label><br />
                //                                    &nbsp;
                //                                    <label ID='lblTel'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                    &nbsp;
                //                                    <label ID='lblFax' Text='Fax:'  Font-Bold='True'></lLabel></span></span>
                //                        </div>
                //                    </td>
                //                    <td style='height: 50px; text-align: right;'>
                //                        <span style='font-size: 7pt; font-family: Verdana'>Date:</span>
                //                    </td>
                //                    <td style='height: 21px; width: 250px;'>
                //                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
                //                            border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                webkit-border-vertical-spacing: 2px'><b><span style='font-size: 7pt'>&nbsp;</span>
                //                                <label  ID='lbldate2' Font-Size='8pt'></label></b></span></span></td>
                //                   </tr>";
                //        #endregion
                //        string strInclusive = string.Empty;
                //        string displayinnerhtml = string.Empty;
                //        Import_AWB_ID = Convert.ToString(strawbid[0]);
                //        DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFA.GstAddress, IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,IFA.PCS,IFA.Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");
                //        //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  
                //        DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + strawbid[0].ToString() + "'");
                //        string table = "";
                //        //decimal total = 0;
                //        decimal STaxAmount = 0;
                //        string STaxRecivedAmt = "";
                //        string STaxRate = "";
                //        string staxamount = "";
                //        //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //        string sbcessamount = "";
                //        string KKcessamount = "";
                //        table = "<table border=0 width=400px align=center cellspacing=0>";
                //        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                //        {
                //            #region for looping
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                //            {
                //                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                staxamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //            {
                //                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                sbcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                //            }
                //            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //            {
                //                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                KKcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                //            }
                //            #endregion
                //        }
                //        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                //        {
                //            #region for looping
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                //            {
                //                MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
                //            {
                //                HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                //            {
                //                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                Stax = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                //                if (dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "1")
                //                {
                //                    staxdetail.Text = "(Service Tax EXEMPTED)";
                //                }
                //                else
                //                {
                //                    staxdetail.Text = "(INCLUSIVE OF SERVICE TAX)only";
                //                }
                //                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                //                {
                //                    continue;
                //                }
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //            {
                //                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                SBcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                //                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                //                {
                //                    continue;
                //                }
                //            }
                //            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //            {
                //                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                KKcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                //                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                //                {
                //                    continue;
                //                }
                //            }
                //            decimal Allvalue = 0;

                //            //************************ImportChargesHead: DP_FEE,Cartage,CommunicationFee concept****
                //            if (dtImportAwbTrans.Rows.Count > 0)
                //            {
                //                #region
                //                if (Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]) > 0)
                //                {
                //                    #region
                //                    //***************************Creating Charges*****************************
                //                    if (Airline_id == "159")
                //                    {
                //                        #region
                //                        if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                //                        {
                //                            ////if (staxamount != "0.00")
                //                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //                            ////mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                //                            mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));
                //                            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";
                //                            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + mawcharge + "' >" + mawcharge.ToString("#,##0.00") + "</label>";
                //                            table += "</td></tr>";
                //                        }
                //                        else
                //                        {
                //                            #region Gst Applicable
                //                            string charge = "";
                //                            string ChargeName = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
                //                            if (ChargeName == "StaxRate")
                //                            {
                //                                charge = "CGST";
                //                            }
                //                            else if (ChargeName == "SBCess")
                //                            {
                //                                charge = "SGST";
                //                            }
                //                            else if (ChargeName == "KKCess")
                //                            {
                //                                charge = "IGST";
                //                            }
                //                            else
                //                            {
                //                                charge = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
                //                            }
                //                            if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                //                            {
                //                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + charge + "'>" + charge + " Chrgs:</label>";

                //                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                //                                table += "</td></tr>";
                //                            }
                //                            else
                //                            {
                //                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                //                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                //                                table += "</td></tr>";
                //                            }

                //                            #endregion end of Gst Applicable
                //                        }
                //                        #endregion
                //                    }
                //                    else
                //                    {
                //                        table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";
                //                        table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                //                        table += "</td></tr>";
                //                    }
                //                    //***************************End******************************************
                //                    if (Airline_id == "159")
                //                    {
                //                        if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() != "StaxRate")
                //                            total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //                    }
                //                    else
                //                        total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //                    #endregion
                //                }
                //                else if (dt.Rows[0]["Shipment_Type"].ToString() == "F")
                //                {
                //                    table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";
                //                    table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + "0.00" + "' >" + "0.00" + "</label>";
                //                    table += "</td></tr>";
                //                    //***************************End******************************************
                //                    total += Convert.ToDecimal("0.00");
                //                }
                //                //*****************************END*****************************************************
                //                #endregion
                //            }
                //            #endregion
                //        }
                //        if (dt.Rows[0]["Tds_Cut_By_Agent"].ToString() != "0.00")
                //        {
                //            //Gst
                //            totalTds = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());
                //            lblTds.Text = "- " + Convert.ToString(totalTds);
                //            ////table += "<tr><td style=\"width: 290px;   text-align: left\" ><label>TDS :</label>";
                //            ////table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + "-" + dt.Rows[0]["Tds_Cut_By_Agent"].ToString() + "</label></td></tr>";
                //        }

                //        table += "</table>";

                //        lblTabel.Text = table;

                //        displayinnerhtml = @"<tr id='Tr1'> 
                //                <td align='left' colspan='4'>
                //                    <label ID='lblTabel' runat='server' CssClass='text'>" + table + @"</lLabel>
                //                </td>
                //            </tr>"; 

                //        no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();

                //        recipt_no = dt.Rows[0]["recipt_no"].ToString();

                //        lblremarks.Text = dt.Rows[0]["Remarks"].ToString();

                //        lblremarkshtml = @"<tr id='trremarks'>
                //                                <td colspan='4'><asp:Label ID='Label2' runat='server' Font-Bold='True' Font-Size='8pt'> Remark:-</asp:Label>                 
                //                                     <label ID='lblremarks' Font-Size='8pt'>" + dt.Rows[0]["Remarks"].ToString() + @"</label>   
                //                                </td>
                //                            </tr>
                //                            <tr>
                //                                <td colspan='4'>
                //                                    ---------------------------------------------------------------------------------------------------------------------
                //                                </td>
                //                            </tr>";

                //        decimal CC_Cheque_Amount = Convert.ToDecimal(dt.Rows[0]["CC_Cheque_Amount"]);
                //        if (Airline_id == "147" || Airline_id == "153")
                //        {
                //            mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[0]["ChargeAmount"]);
                //        }
                //        //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //        decimal SBCessAmt = 0;
                //        decimal KKCessAmt = 0;
                //        //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                //        {
                //             #region for looping
                //            ////////****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            //////decimal SBCessAmt = 0;
                //            //////decimal KKCessAmt = 0;
                //            ////////****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //            {
                //                SBCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //            {
                //                KKCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "Carting")
                //            {
                //                cartingcharges = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //            }
                //            else if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                //            {
                //                mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate" && dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "0")
                //            {
                //                #region stax
                //                ////string strInclusive = string.Empty;
                //                if (flagtable == true)
                //                {
                //                    strInclusive += "<table border=0 width=400px align=center cellspacing=0>";
                //                }

                //                decimal STaxAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt;
                //                ViewState["STaxAmt"] = STaxAmt;
                //                //////if (Airline_id == "159")
                //                //////{
                //                //////    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                //                //////    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                //                //////    //DOCharge = Convert.ToDecimal(TD);

                //                //////}

                //                if (Airline_id == "147" || Airline_id == "153")
                //                {
                //                    //strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + mawcharge + "</label></td></tr>";
                //                    //strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                //                }
                //                else if (Airline_id == "159")
                //                {
                //                    //strInclusive += "<tr style=\"display:none\" ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                    //strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                //                }
                //                else
                //                {
                //                    //strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                    //strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                //                }
                //                #endregion
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //            {
                //                #region SBCESS
                //                // string strInclusive = string.Empty;
                //                decimal STaxAmt = 0;
                //                if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                //                {
                //                    ////ViewState["STaxAmt"] = "0";
                //                    ViewState["STaxAmt"] = STaxAmt;
                //                }
                //                else
                //                {

                //                    STaxAmt = (Decimal)ViewState["STaxAmt"];
                //                }
                //                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt;

                //                if (Airline_id == "1591")
                //                {
                //                    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                //                    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                //                    //DOCharge = Convert.ToDecimal(TD);

                //                }

                //                if (Airline_id == "159")
                //                {
                //                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";

                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr></table>";

                //                }
                //                else if (Airline_id == "1591")
                //                {
                //                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";
                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";
                //                }
                //                else
                //                {
                //                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";

                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";

                //                }
                //                #endregion
                //            }
                //            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //            {
                //                #region if KKCess
                //                // string strInclusive = string.Empty;
                //                decimal STaxAmt = 0;
                //                if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                //                {
                //                    ////ViewState["STaxAmt"] = "0";
                //                    ViewState["STaxAmt"] = STaxAmt;
                //                }
                //                else
                //                {

                //                    STaxAmt = (Decimal)ViewState["STaxAmt"];
                //                }
                //                if (STaxAmt == 0)
                //                {
                //                    STaxAmt = SBCessAmt;
                //                }
                //                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt - KKCessAmt;

                //                if (Airline_id == "1591")
                //                {
                //                    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                //                    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                //                    //DOCharge = Convert.ToDecimal(TD);

                //                }

                //                if (Airline_id == "159")
                //                {
                //                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                //                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";

                //                }
                //                else if (Airline_id == "1591")
                //                {
                //                    #region  else if (Airline_id == "1591")
                //                    if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                //                    {
                //                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount@9% :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount@9% :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount@18% :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                    }

                //                    else
                //                    {
                //                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                    }
                //                    #endregion
                //                }
                //                else
                //                {
                //                    #region  else if (Airline_id == "1591")
                //                    if (strInclusive.Contains("<table"))
                //                    {

                //                    }
                //                    else
                //                    {
                //                        flagtable = false;
                //                        strInclusive += "<table border=0 width=400px align=center cellspacing=0>";
                //                    }
                //                    if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                //                    {
                //                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount@9% :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount@9% :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount@18% :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                    }

                //                    else
                //                    {
                //                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                //                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                    }
                //                    #endregion
                //                }
                //                #region Gst newly Added
                //                GSTDoCharges = DOCharge;
                //                CGSTChargs = STaxAmt;
                //                SGSTChargs = SBCessAmt;
                //                IGSTChargs = KKCessAmt;
                //                #endregion Gst newly Added
                //                #endregion
                //            }
                //            lblInclusive.Text = strInclusive;
                //            //Gst
                //            lblBreakupTotal.Text = Convert.ToDecimal(GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs).ToString("#,##0.00");
                //            lblRecivedAmt.Text = Convert.ToDecimal((GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs) - totalTds).ToString("#,##0.00");
                //            Label1.Text = lblRecivedAmt.Text;
                //            #endregion
                //        }
                //        string StaxNo = "";
                //        issue_date = dt.Rows[0]["issue_date"].ToString();
                //        straddress = dt.Rows[0]["office_address"].ToString();
                //        Airportadress = dt.Rows[0]["Airport_Address"].ToString();
                //        payment_mode = dt.Rows[0]["payment_mode"].ToString();
                //        flight_date = dt.Rows[0]["import_flight_Date"].ToString();
                //        part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
                //        decimal ServiceTax = 0;
                //        ServiceTax = decimal.Parse(STAXRATE);
                //        if (part_pcs == "" || part_pcs == "0")
                //        {
                //            lblPartPsc.Visible = false;
                //            lblPartPsc.Text = "";
                //            lblpppsc.Visible = false;
                //            lblpppsc.Text = "";
                //        }
                //        else
                //        {
                //            lblPartPsc.Visible = true; ;
                //            lblPartPsc.Text = part_pcs;
                //            lblpppsc.Visible = true;
                //            lblpppsc.Text = "/";
                //        }
                //        //*****************Added On 1 feb 2011********************
                //        if (dt.Rows[0]["freight_type"].ToString() == "PP")
                //        {
                //            lblBeingFrtchrgs.Text = "PP";
                //        }
                //        else if (dt.Rows[0]["freight_type"].ToString() == "CC")
                //        {
                //            #region else if condition
                //            string MawbChrs = "";
                //            string HawbChrs = "";
                //            if (MawbDo_Chgs == "")
                //            {
                //                MawbChrs = "0";
                //            }
                //            else
                //            {
                //                MawbChrs = MawbDo_Chgs;
                //            }
                //            if (HawbDo_Chgs == "")
                //            {
                //                HawbChrs = "0";
                //            }
                //            else
                //            {
                //                HawbChrs = HawbDo_Chgs;
                //            }
                //            lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                //            lblDOChrgs.Text = Convert.ToString(total);
                //            #endregion
                //        }
                //        //*****************END********************
                //        strAirline_name = dt.Rows[0]["Airline_Name"].ToString();
                //        if (strAirline_name == "MALAYSIAN AIRLINES")
                //        {
                //            strAirline_name = "MALAYSIA AIRLINES";
                //        }
                //        awbno = dt.Rows[0]["Import_Awb_No"].ToString();
                //        flt_no = dt.Rows[0]["import_flight_no"].ToString();
                //        if (Airline_id == "158")
                //        {
                //            #region if condition
                //            if (FlightNo != "KE-9395")
                //            {
                //                if (FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                //                    flt_no = flt_no.Replace("HY", "KE");
                //                else
                //                    flt_no = flt_no.Replace("KE", "HY");
                //            }
                //            #endregion
                //        }
                //        arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();
                //        contents = dt.Rows[0]["commodity"].ToString();
                //        if (contents == "Console")
                //        {
                //            contents = "Consol";
                //        }
                //        pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
                //        import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
                //        to = dt.Rows[0]["Consignee_Name"].ToString();
                //        if (to == "")
                //        {
                //            to = dt.Rows[0]["Agent_Name"].ToString();
                //        }
                //        if (Airline_id == "147" || Airline_id == "153")
                //        {
                //            to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
                //        }
                //        if (dt.Rows[0]["GstNo"].ToString() != "")
                //        {
                //            #region if condition
                //            string placeOfDelivery = "DELHI";
                //            string GstAddress = placeOfDelivery;

                //            if (dt.Rows[0]["GstAddress"].ToString() != "")
                //            {
                //                GstAddress = dt.Rows[0]["GstAddress"].ToString();
                //            }
                //            DataTable dtdeliveryplace = dw.GetAllFromQuery("Select state from gststateCode where statecode=" + dt.Rows[0]["GstNo"].ToString().Substring(0, 2) + "");
                //            if (dtdeliveryplace.Rows != null && dtdeliveryplace.Rows.Count > 0)
                //            {
                //                #region if condition
                //                if (dtdeliveryplace.Rows[0]["state"].ToString() == "" || dtdeliveryplace.Rows[0]["state"].ToString() == null)
                //                {
                //                    placeOfDelivery = dt.Rows[0]["GstNo"].ToString();
                //                    if (dt.Rows[0]["GstAddress"].ToString() == "")
                //                    {
                //                        GstAddress = placeOfDelivery;
                //                    }
                //                }
                //                else
                //                {
                //                    placeOfDelivery = dtdeliveryplace.Rows[0]["state"].ToString();
                //                    if (dt.Rows[0]["GstAddress"].ToString() == "")
                //                    {
                //                        GstAddress = placeOfDelivery;
                //                    }
                //                }
                //                //////to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //                to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //                #endregion
                //            }
                //            else
                //            {
                //                //// to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //                to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //            }
                //            #endregion
                //        }
                //        from = dt.Rows[0]["Shipper_Name"].ToString();
                //        notify = dt.Rows[0]["Notify"].ToString();
                //        if (notify == "")
                //        {
                //            lblNotifyDo.Visible = false;
                //            lblNotifyDovalue.Visible = false;
                //            lblNotify.Visible = false; ;
                //            lblNotifyValue.Visible = false;
                //            lblNotifyValue.Text = "";
                //        }
                //        else
                //        {
                //            lblNotifyDo.Visible = true;
                //            lblNotifyDovalue.Visible = true;
                //            lblNotifyDovalue.Text = notify;
                //            lblNotify.Visible = true;
                //            lblNotifyValue.Visible = true;
                //            lblNotifyValue.Text = notify;
                //        }
                //        IGMNo = dt.Rows[0]["IGM_No"].ToString();
                //        string house = dt.Rows[0]["No_of_Houses"].ToString();
                //        decimal housevalue = System.Math.Round(decimal.Parse(house), 0);
                //        decimal d = housevalue * decimal.Parse(HawbDo_Chgs);
                //        //************Added on 1 feb 2011 Added freight Chrages for CC Case****************
                //        decimal DOFrtChrgs = 0;
                //        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                //        {
                //            #region if condition
                //            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
                //            {
                //                DOFrtChrgs = 0;
                //            }
                //            else
                //            {
                //                DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
                //            }
                //            TrFreightChrgsCC.Visible = true;
                //            TrFreightChrgsCChtml = @"<tr id='TrFreightChrgsCC'>  
                //                                                <td align='left' colspan='4'>
                //                                                    <table border='0' width='400px' align='center' cellspacing='0'>
                //                                                        <tr>
                //                                                            <td style='width: 290px; text-align: left'>
                //                                                                <span style='font-size: 8pt;'>Frt&nbsp; Chrgs.&nbsp; &nbsp;&nbsp;</span>
                //                                                            </td>
                //                                                            <td style='font-size: 12pt; width: 244px; text-align: right;'>
                //                                                                <label ID='lblDOFrtChr'></label>
                //                                                            </td>
                //                                                        </tr>
                //                                                    </table>
                //                                                </td>
                //                                            </tr>";
                //            d = d + DOFrtChrgs;
                //            #endregion
                //        }
                //        //************END**********************************************
                //        string addrs = "";
                //        if (Airline_id == "158")
                //        {
                //            #region if condition
                //            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                //            {
                //                #region if condition
                //                lblAddress.Text = straddress.ToString();
                //                lblAddress1.Text = straddress.ToString();
                //                lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td>
                //                                 </tr>";
                //                #endregion
                //            }
                //            else
                //            {
                //                #region else part
                //                lblAddress.Text = straddress.ToString();
                //                lblAddress1.Text = Airportadress.ToString();
                //                lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td>
                //                      </tr>";
                //                #endregion
                //            }
                //            #endregion
                //        }
                //        else
                //        {
                //            #region else part
                //            lblAddress.Text = straddress.ToString();
                //            lblAddress1.Text = straddress.ToString();
                //            lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td>
                //                                 </tr>";
                //            #endregion
                //        }
                //        if (lblAddress.Text.Contains("GST NO"))
                //        {
                //            int i = lblAddress.Text.IndexOf(",GST NO");
                //            StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                //            addrs = lblAddress.Text.Replace(StaxNo, ".");
                //            addrs = addrs.Replace(",.", ".");
                //            //lblAddress1.Text = addrs;
                //            lblAddress.Text = addrs;
                //        }
                //        else
                //        {
                //            // lblAddress1.Text = straddress.ToString();
                //            lblAddress.Text = straddress.ToString();
                //        }
                //        if (lblAddress1.Text.Contains("GST NO"))
                //        {
                //            #region if condition
                //            int i = lblAddress1.Text.IndexOf(",GST NO");
                //            StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
                //            addrs = lblAddress1.Text.Replace(StaxNo, ".");
                //            addrs = addrs.Replace(",.", ".");
                //            lblAddress1.Text = addrs;
                //            lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + addrs + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td>
                //                                 </tr>";
                //            #endregion
                //        }
                //        else
                //        {
                //            #region else condition
                //            if (Airline_id == "158")
                //                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                //                    //lblAddress1.Text = straddress.ToString();  //byjj
                //                    lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td></tr>";
                //                else
                //                    //lblAddress1.Text = Airportadress.ToString(); //byjj
                //                    lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + Airportadress.ToString() + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td></tr>";
                //            else
                //                //lblAddress1.Text = straddress.ToString();  //By jj
                //                lblAddress1html = @"<tr> 
                //                                <td style='height: 10px;' colspan='2'>
                //                                    <div style='width: 320px;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                            <span class='Apple-style-span'
                //                                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                                webkit-border-vertical-spacing: 2px'>
                //                                                <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
                //                                                <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                                <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                         </span>
                //                                    </div>
                //                                </td>
                //                                    <td colspan='2' style='height: 10px'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                            </span></span>
                //                                    </td></tr>";
                //            #endregion
                //        }
                //        if (lblAddress1.Text.Contains("Tel"))
                //            lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
                //        if (lblAddress1.Text.Contains("TEL"))
                //            lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
                //        if (lblAddress.Text.Contains("Tel"))
                //            lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
                //        if (lblAddress.Text.Contains("TEL"))
                //            lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
                //        if (lblAddress1.Text.Contains("Fax"))
                //            lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
                //        if (lblAddress1.Text.Contains("FAX"))
                //            lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
                //        if (lblAddress.Text.Contains("Fax"))
                //            lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
                //        if (lblAddress.Text.Contains("FAX"))
                //            lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");
                //        if (payment_mode == "1")
                //        {
                //            lblCheque.Visible = false;
                //            lblCash.Text = "in Cash";
                //        }
                //        else if (payment_mode == "2")
                //        {
                //            lblCash.Visible = false;
                //            lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
                //        }

                //        #region stax region
                //        if (strAirline_name == "MALAYSIA AIRLINES")
                //        {
                //            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            #region lblAirlineStax.Text = "Acumen Overseas
                //            lblAirlineStaxhtml = @"<tr>   
                //                                        <td colspan='4'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
                //                                                    <table style='width: 600px'>
                //                                                        <tr>
                //                                                            <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
                //                                                                font-family: Verdana, Arial, Helvetica, sans-serif'>
                //                                                                In accordance with notification stamps No. 3 dated 21st December issued by<br />
                //                                                                the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
                //                                                                affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
                //                                                                <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
                //                                                            </td>
                //                                                        </tr>
                //                                                    </table>
                //                                                </span></span>
                //                                        </td>
                //                                    </tr>";
                //            #endregion
                //        }
                //        else if (strAirline_name == "TURKISH AIRLINES")
                //        {
                //            lblAirlineStax.Text = "Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            #region lblAirlineStax.Text = "Ascent Air
                //            lblAirlineStaxhtml = @"<tr>   
                //                                        <td colspan='4'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
                //                                                    <table style='width: 600px'>
                //                                                        <tr>
                //                                                            <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
                //                                                                font-family: Verdana, Arial, Helvetica, sans-serif'>
                //                                                                In accordance with notification stamps No. 3 dated 21st December issued by<br />
                //                                                                the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
                //                                                                affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
                //                                                                <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
                //                                                            </td>
                //                                                        </tr>
                //                                                    </table>
                //                                                </span></span>
                //                                        </td>
                //                                    </tr>";
                //            #endregion
                //        }
                //        else if (strAirline_name == "AIR CHINA")
                //        {
                //            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            #region  lblAirlineStax.Text = "Acumen Overseas Pv
                //            lblAirlineStaxhtml = @"<tr>   
                //                                        <td colspan='4'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
                //                                                    <table style='width: 600px'>
                //                                                        <tr>
                //                                                            <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
                //                                                                font-family: Verdana, Arial, Helvetica, sans-serif'>
                //                                                                In accordance with notification stamps No. 3 dated 21st December issued by<br />
                //                                                                the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
                //                                                                affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
                //                                                                <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
                //                                                            </td>
                //                                                        </tr>
                //                                                    </table>
                //                                                </span></span>
                //                                        </td>
                //                                    </tr>";
                //            #endregion
                //        }
                //        else if (strAirline_name == "KOREAN AIRLINES")
                //        {
                //            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            #region  lblAirlineStax.Text = "Acumen Overse
                //            lblAirlineStaxhtml = @"<tr>   
                //                                        <td colspan='4'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
                //                                                    <table style='width: 600px'>
                //                                                        <tr>
                //                                                            <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
                //                                                                font-family: Verdana, Arial, Helvetica, sans-serif'>
                //                                                                In accordance with notification stamps No. 3 dated 21st December issued by<br />
                //                                                                the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
                //                                                                affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
                //                                                                <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
                //                                                            </td>
                //                                                        </tr>
                //                                                    </table>
                //                                                </span></span>
                //                                        </td>
                //                                    </tr>";
                //            #endregion
                //        }
                //        else if (strAirline_name == "MEGA MALDIVES AIRLINES")
                //        {
                //            lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            #region  lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT
                //            lblAirlineStaxhtml = @"<tr>   
                //                                        <td colspan='4'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
                //                                                    <table style='width: 600px'>
                //                                                        <tr>
                //                                                            <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
                //                                                                font-family: Verdana, Arial, Helvetica, sans-serif'>
                //                                                                In accordance with notification stamps No. 3 dated 21st December issued by<br />
                //                                                                the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
                //                                                                affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
                //                                                                <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
                //                                                            </td>
                //                                                        </tr>
                //                                                    </table>
                //                                                </span></span>
                //                                        </td>
                //                                    </tr>";
                //            #endregion
                //        }
                //        else
                //        {
                //            lblAirlineStax.Text = "Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            #region  lblAirlineStax.Text = "Pace Express <b
                //            lblAirlineStaxhtml = @"<tr>   
                //                                        <td colspan='4'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-size: 13px; font-family: arial, verdana, arial, sans-serif'>
                //                                                    <table style='width: 600px'>
                //                                                        <tr>
                //                                                            <td align='left' class='text' style='padding-left: 5px; font-size: 10px; color: rgb(0,0,0);
                //                                                                font-family: Verdana, Arial, Helvetica, sans-serif'>
                //                                                                In accordance with notification stamps No. 3 dated 21st December issued by<br />
                //                                                                the Finance Department Government of India, the Company is exempted from<span class='Apple-converted-space'>&nbsp;</span><br />
                //                                                                affixing stamps on receipts for passage fares, excess baggage and freight charges.<br />
                //                                                                <label ID='lblAirlineStax' CssClass='text' Font-Bold='True'>Pace Express <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo + @"</label>
                //                                                            </td>
                //                                                        </tr>
                //                                                    </table>
                //                                                </span></span>
                //                                        </td>
                //                                    </tr>";
                //            #endregion
                //        }
                //        #endregion

                //        lblairlinename.Text = strAirline_name.ToString();
                //        lblairlinenamehtml = @"<tr>   
                //                                        <td colspan='4' style='height: 1px; text-align: center;'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                    webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                    <h4 style='text-align: center'>
                //                                                        TAX INVOICE</h4>
                //                                                    <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>
                //                                                </span></span>
                //                                        </td>
                //                                </tr>";

                //        if (Airline_id == "158")
                //        {
                //            #region if condition
                //            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                //            {
                //                #region lblAirlineNme.Text = "KOREAN AIR";
                //                lblAirlineNme.Text = "KOREAN AIR";
                //                lblAirlineNmehtml = @"<tr>
                //                                        <td colspan=3 style='height: 10px'>
                //                                        </td>
                //                                        <td class='text' style='height: 10px'>
                //                                             <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
                //                                        </td></tr>";
                //                lblheadairlinename.Text = "KOREAN AIR";
                //                lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
                //                                                <td colspan='4' style='text-align: center;'>
                //                                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                        <span class='Apple-style-span'
                //                                                            style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                            webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                            <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                            <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
                //                                                        </span>
                //                                                     </span>
                //                                                </td>
                //                                            </tr>";
                //                #endregion
                //            }
                //            else
                //            {
                //                #region  lblAirlineNme.Text = "UZBEKIS
                //                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                //                lblAirlineNmehtml = @"<tr>
                //                                        <td colspan=3 style='height: 10px'>
                //                                        </td>
                //                                        <td class='text' style='height: 10px'>
                //                                             <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
                //                                        </td></tr>";

                //                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                //                lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                        <span class='Apple-style-span'
                //                                                            style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                            webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                            <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                            <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
                //                                                        </span>
                //                                                     </span>
                //                                                </td>
                //                                            </tr>";
                //                #endregion
                //            }
                //            #endregion
                //        }
                //        else if (Airline_id == "159")
                //        {
                //            #region else if condition
                //            if (FlightNo == "HY-127")
                //            {
                //                #region FlightNo == "HY-127"
                //                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                //                lblAirlineNmehtml = @"<tr>
                //                                        <td colspan=3 style='height: 10px'>
                //                                        </td>
                //                                        <td class='text' style='height: 10px'>
                //                                             <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
                //                                        </td></tr>";

                //                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                //                lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                        <span class='Apple-style-span'
                //                                                            style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                            webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                            <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                            <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
                //                                                        </span>
                //                                                     </span>
                //                                                </td>
                //                                            </tr>";

                //                lblairlinename.Text = "UZBEKISTAN AIRWAYS";
                //                lblairlinenamehtml = @"<tr>   
                //                                        <td colspan='4' style='height: 1px; text-align: center;'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                    webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                    <h4 style='text-align: center'>
                //                                                        TAX INVOICE</h4>
                //                                                    <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>
                //                                                </span></span>
                //                                        </td>
                //                                </tr>";
                //                    #endregion
                //            }
                //            else
                //            {
                //                #region else part
                //                lblAirlineNme.Text = "KOREAN AIR";
                //                lblAirlineNmehtml = @"<tr>
                //                                        <td colspan=3 style='height: 10px'>
                //                                        </td>
                //                                        <td class='text' style='height: 10px'>
                //                                             <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
                //                                        </td></tr>";

                //                lblheadairlinename.Text = "KOREAN AIR";
                //                lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr>
                //                                                <td colspan='4' style='text-align: center;'>
                //                                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                        <span class='Apple-style-span'
                //                                                            style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                            webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                            <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                            <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
                //                                                        </span>
                //                                                     </span>
                //                                                </td>
                //                                            </tr>";

                //                lblairlinename.Text = "KOREAN AIR";
                //                lblairlinenamehtml = @"<tr>   
                //                                        <td colspan='4' style='height: 1px; text-align: center;'>
                //                                            <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                    style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                    webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                    <h4 style='text-align: center'>
                //                                                        TAX INVOICE</h4>
                //                                                    <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>KOREAN AIR</label>
                //                                                </span></span>
                //                                        </td>
                //                                </tr>";
                //                #endregion
                //            }
                //            #endregion
                //        }
                //        else
                //        {
                //            #region else part
                //            lblAirlineNme.Text = strAirline_name.ToString();
                //            lblAirlineNmehtml = @"<tr>
                //                                        <td colspan=3 style='height: 10px'>
                //                                        </td>
                //                                        <td class='text' style='height: 10px'>
                //                                             <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>" + strAirline_name.ToString() + @"</label>
                //                                        </td></tr>";
                //            lblheadairlinename.Text = strAirline_name.ToString();
                //            lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                        <span class='Apple-style-span'
                //                                                            style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                            webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                            <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                            <label ID='lblheadairlinename' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>                            
                //                                                        </span>
                //                                                     </span>
                //                                                </td>
                //                                            </tr>";
                //            #endregion
                //        }
                //        lblAwbno.Text = awbno.ToString();
                //        lblPcs.Text = pcs.ToString();
                //        ////////lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");
                //        //****************Added On 01_Mach_2011******
                //        lblDate.Text = issue_date;
                //        //***************End*************
                //        lblcommdy.Text = contents.ToString();
                //        lblFlightno.Text = flt_no.ToString();
                //        lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();
                //        lbligmnr.Text = IGMNo.ToString();
                //        lblAwb2.Text = awbno.ToString();
                //        lbldate2.Text = issue_date.ToString();
                //        lblFlitno2.Text = flt_no.ToString();
                //        lblAirlinemame3.Text = strAirline_name.ToString();
                //        if (Airline_id == "147")
                //        {
                //            lblch.Visible = true;
                //            lblchwt.Visible = true;
                //            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                //            lblAirlinemame3.Text = "MASkargo";

                //            lblAirlineNme.Text = "MASkargo";
                //            lblAirlineNmehtml = @"<tr>
                //                                        <td colspan=3 style='height: 10px'>
                //                                        </td>
                //                                        <td class='text' style='height: 10px'>
                //                                             <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>MASkargo</label>
                //                                        </td></tr>";
                //        }
                //        else if (Airline_id == "153")
                //        {
                //            lblch.Visible = true;
                //            lblchwt.Visible = true;
                //            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                //            ////lblAirlinemame3.Text = "MASkargo";
                //            ////lblAirlineNme.Text = "MASkargo";
                //        }
                //        if (Airline_id == "159")
                //        {
                //            lblAirlinemame3.Text = "KOREAN AIR";
                //        }
                //        //******************Added On 1 feb 2011*********************
                //        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                //        {
                //            #region if condition
                //            TrFreightChrgsCC.Visible = true;
                //            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0.00")
                //            {
                //                lblDOFrtChr.Text = "0";
                //                TrFreightChrgsCC.Visible = false;
                //            }
                //            else
                //            {
                //                TrFreightChrgsCC.Visible = true;
                //                lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                //                total += Convert.ToDecimal(dt.Rows[0]["Total_Collection_CC"]);
                //            }
                //            #endregion
                //        }
                //        //****************************End*********************************************
                //        decimal _Amount_Received = 0;
                //        decimal _Amount_ReceivedSBCess = 0;
                //        decimal _Amount_ReceivedKKCess = 0;
                //        //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  
                //        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                //        {
                //            #region for looping
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                //            {
                //                _Amount_Received = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
                //            }
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //            {
                //                _Amount_ReceivedSBCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
                //            }
                //            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //            {
                //                _Amount_ReceivedKKCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());
                //            }
                //            #endregion
                //        }
                //        decimal _TDSCutByAgent = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());
                //        //decimal f = d+1000;
                //        decimal f = d + Convert.ToDecimal(MawbDo_Chgs);
                //        //decimal Tds=9.75;
                //        decimal _Amount = 0;
                //        _Amount = Convert.ToInt64(f);
                //        string TD_S = "";
                //        string TD_S1 = "";
                //        string Total_ = "";
                //        if (Airline_id == "159")
                //        {
                //            #region if condition
                //            ////if (_Amount_Received != 0)
                //            ////{
                //            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            ////decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                //            decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));
                //            total = total - mawcharge + _Amount_Received + charge;
                //            ////// }
                //            #endregion
                //        }
                //        // lblMaster.Text = MawbDo_Chgs.ToString();
                //        if (_TDSCutByAgent > 0 || ServiceTax > 0)
                //        {
                //            #region if condition
                //            if (_TDSCutByAgent > 0)
                //            {
                //                #region if condition
                //                string TD = Convert.ToString(Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
                //                TD_S = Convert.ToDecimal(TD).ToString("#,##0.00");
                //                //////string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
                //                ////string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
                //                string A = Convert.ToString(total);


                //                decimal AM = 0;
                //                AM = decimal.Parse(A);
                //                Total_ = Convert.ToDecimal(A).ToString("#,##0.00");

                //                lblfreight.Text = Total_;
                //                if (Airline_id == "159")
                //                {
                //                    lblBreakupTotal.Text = Convert.ToString(total);
                //                    lblRecivedAmt.Text = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
                //                    Label1.Text = lblRecivedAmt.Text;
                //                    Label6.Visible = false;
                //                }
                //                _Amount = decimal.Parse(lblfreight.Text);
                //                #endregion
                //            }
                //            //****************** Service Tax Logic on 16 Aug 2010 *****************
                //            else
                //            {
                //                #region else condition
                //                lblfreight.Text = total.ToString();
                //                if (Airline_id == "159")
                //                {
                //                    lblBreakupTotal.Text = lblfreight.Text;
                //                    lblRecivedAmt.Text = lblfreight.Text;
                //                    Label1.Text = lblRecivedAmt.Text;
                //                    Label6.Visible = false;
                //                }
                //                _Amount = decimal.Parse(lblfreight.Text);
                //                #endregion
                //            }
                //            #endregion
                //        }
                //        else
                //        {
                //            #region else condition
                //            string _F = "";
                //            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                //            {
                //                _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue) + decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString()));
                //            }
                //            else
                //            {
                //                _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue));
                //            }
                //            lblfreight.Text = Convert.ToDecimal(_F).ToString("#,##0.00");
                //            if (Airline_id == "159")
                //            {
                //                lblfreight.Text = total.ToString();
                //                lblRecivedAmt.Text = lblfreight.Text;
                //                lblBreakupTotal.Text = lblRecivedAmt.Text;
                //                Label1.Text = lblRecivedAmt.Text;
                //                Label6.Visible = false;
                //            }
                //            //_Amount = f;
                //            _Amount = decimal.Parse(lblfreight.Text);
                //            #endregion
                //        }
                //        //Label1.Text = lblfreight.Text;
                //        lblSno.Text = recipt_no.ToString();
                //        lblSnomum.Text = recipt_no.ToString();
                //        lblSnochennai.Text = recipt_no.ToString();
                //        lblSno2.Text = recipt_no.ToString();
                //        lblName.Text = to.ToString();
                //        lblName2.Text = to.ToString();
                //        Sno.Text = recipt_no.ToString();
                //        Sno.Text = recipt_no.ToString();
                //        Snohtml = @"<tr id='AmtDescp'> 
                //                                <td>
                //                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span style='font-size: 10px;
                //                                            font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                            webkit-border-vertical-spacing: 2px'>an amount of Rs.<label ID='Label1' Font-Bold='True' Font-Underline='False' Font-Size='8pt'></label></span></span>
                //                                </td>
                //                                <td class='text' colspan='3'>
                //                                    (Rs. Amount Collect by VIA RECP:
                //                                    <label ID='Sno' runat='server' Font-Bold='True' Font-Size='8pt'></label>).
                //                                </td>
                //                            </tr>";
                //        string englishTranslation = "";
                //        string englishTranslationDecimalPart = "";
                //        //string englishTranslation = changeNumericToWords(Convert.ToDouble(f));
                //        //********** Function Translation of Number figure TO Words******************
                //        string Amt = _Amount.ToString();
                //        string AmtDecimal = "";
                //        string AmountCombined = "";
                //        //*********Decimal Logic****************
                //        //***** Shipment Type is FOC Case**********//
                //        if (dt.Rows[0]["shipment_type"].ToString() == "F")
                //        {
                //            #region if condition
                //            _Amount = 0;
                //            lblfreight.Text = "0.00";
                //            lblAmount.Text = "Zero";
                //            lblRecivedAmt.Text = "0.00";
                //            englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
                //            #endregion
                //        }
                //        else
                //        {
                //            //////englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
                //            englishTranslation = changeNumericToWords(Convert.ToDouble(lblRecivedAmt.Text));
                //            lblAmount.Text = englishTranslation;
                //        }
                //        //englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
                //        ////lblFlightDate.Text = flight_date.ToString();
                //        DateTime fltdate = DateTime.Parse(flight_date);
                //        lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");
                //        //lblFltDateAirline.Text = flight_date.ToString();
                //        DateTime fltdate2 = DateTime.Parse(flight_date);
                //        lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");
                //    }




                //    public void DisplayRepeatAwb()
                //    {
                //        string strInclusive = string.Empty;
                //        DataTable dtDo_GenerateStatus_check = dw.GetAllFromQuery("select Import_Awb_ID,Import_Awb_No,D0_Generate_Status from Import_Flight_Awb where Import_Awb_No='" + AIrwayBill_No + "' and D0_Generate_Status='YES'");
                //        if (dtDo_GenerateStatus_check.Rows.Count > 0)
                //        {
                //            //Not use here Space3
                //            #region if condition
                //            lblAddress1.Visible = true;
                //            lblAddress.Visible = true;
                //            #region htmlregion
                //            lblAddress1html = @"<tr> 
                //                            <td style='height: 10px;' colspan='2'>
                //                                <div style='width: 320px;'>
                //                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                        <span class='Apple-style-span'
                //                                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                            webkit-border-vertical-spacing: 2px'>
                //                                            <label ID='lblAddress1'  Font-Bold='True' Font-Size='8pt'>" + straddress.ToString() + @"</label><br />
                //                                            <label ID='lblTel1'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                            <label ID='lblFax1' Text='Fax:'Font-Bold='True'></label></span>
                //                                     </span>
                //                                </div>
                //                            </td>
                //                                <td colspan='2' style='height: 10px'>
                //                                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                        letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                            style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                            webkit-border-horizontal-spacing: 0px; webkit-border-vertical-spacing: 0px'>
                //                                        </span></span>
                //                                </td>
                //                             </tr>";            
                //            lblAddresshtml = @"<tr>
                //                <td style='height: 50px;' colspan='2'>
                //                    <div style='width: 320px;'>
                //                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
                //                            border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                                webkit-border-vertical-spacing: 2px'>
                //                                <label ID='lblAddress' Font-Bold='True' Font-Size='8pt'></label><br />
                //                                &nbsp;
                //                                <label ID='lblTel'  Text='Tel:'  Font-Bold='True'></label><br />
                //                                &nbsp;
                //                                <label ID='lblFax' Text='Fax:'  Font-Bold='True'></lLabel></span></span>
                //                    </div>
                //                </td>
                //                <td style='height: 50px; text-align: right;'>
                //                    <span style='font-size: 7pt; font-family: Verdana'>Date:</span>
                //                </td>
                //                <td style='height: 21px; width: 250px;'>
                //                    <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                        text-transform: none; color: rgb(0,0,0); text-indent: 0px; letter-spacing: normal;
                //                        border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                        webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                        webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                            style='font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; webkit-border-horizontal-spacing: 2px;
                //                            webkit-border-vertical-spacing: 2px'><b><span style='font-size: 7pt'>&nbsp;</span>
                //                            <label  ID='lbldate2' Font-Size='8pt'></label></b></span></span></td>
                //               </tr>";
                //            #endregion
                //            AmtDescp.Visible = false;
                //            Tr1.Visible = false;
                //            Tr2.Visible = false;
                //            Tr4.Visible = false;
                //            Tr5.Visible = false;
                //            lblTds.Visible = false;
                //            TotalLine.Visible = false;
                //            TotalSpace.Visible = false;
                //            Space3.Visible = false;        
                //            Space6.Visible = true;
                //            PartShipmentCase.Visible = true;
                //            #region space6 to PartShipmentCase html
                //            Space6html = @"<tr id='Space6'>
                //                <td>
                //                </td>
                //                <td>
                //                </td>
                //                <td>
                //                </td>
                //                <td style='height: 21px; white-space: nowrap;' class='text'>
                //                    <label ID='lblAirlinemame3' Font-Bold='True' Font-Size='8pt'></label>
                //                </td>
                //            </tr>";
                //            PartShipmentCasehtml = @"<tr id='PartShipmentCase'>  
                //                <td style='height: 20px' colspan='4'>
                //                    <label ID='lblpartshipmentCase' CssClass='boldtext' Text='CASH RECEIVED VIDE RECEIPT NO:'
                //                        Font-Bold='True' Font-Size='Smaller'></label>
                //                    <label ID='lblRecipt' CssClass='boldtext' Font-Bold='True' Font-Size='Smaller'></label>
                //                </td>
                //            </tr>";
                //            #endregion
                //            Import_AWB_ID = dtDo_GenerateStatus_check.Rows[0]["Import_Awb_ID"].ToString();
                //            DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFA.GstAddress, IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + strawbid[0].ToString() + "'");
                //            //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  
                //            DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + strawbid[0].ToString() + "'");
                //            string table = "";
                //            decimal total = 0;
                //            decimal STaxAmount = 0;
                //            string STaxRecivedAmt = "";
                //            string STaxRate = "";
                //            string staxamount = "";
                //            string sbcessamount = "";
                //            string KKcessamount = "";
                //            table = "<table border=0 width=100% align=center cellspacing=0>";
                //            #region html table dynamic
                //            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                //            {
                //                #region for looping
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                //                {
                //                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                    staxamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                //                }               
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //                {
                //                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                    sbcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                //                }
                //                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //                {
                //                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                    KKcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                //                }
                //                #endregion
                //            }
                //            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                //            {
                //                #region for loop
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                //                {

                //                    MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                    mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                //                }
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
                //                {
                //                    HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                //                }
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                //                {
                //                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                    Stax = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                //                    if (dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "1")
                //                    {
                //                        staxdetail.Text = "(Service Tax EXEMPTED)";
                //                    }
                //                    else
                //                    {
                //                        staxdetail.Text = "(INCLUSIVE OF SERVICE TAX)only";
                //                    }
                //                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                //                    {
                //                        continue;
                //                    }
                //                    //continue;
                //                }
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //                {
                //                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                    SBcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                //                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                //                    {
                //                        continue;
                //                    }
                //                }
                //                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //                {
                //                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                //                    KKcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                //                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                //                    {
                //                        continue;
                //                    }
                //                }
                //                decimal Allvalue = 0;
                //                //************************ImportChargesHead: DP_FEE,Cartage,CommunicationFee concept****
                //                if (dtImportAwbTrans.Rows.Count > 0)
                //                {
                //                    #region uif part
                //                    if (Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]) > 0)
                //                    {

                //                        //***************************Creating Charges*****************************
                //                        if (Airline_id == "159")
                //                        {


                //                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                //                            {
                //                               ///// if (staxamount != "0.00")
                //                                    //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //                                    ////mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                //                                    mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));

                //                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                //                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + mawcharge + "' >" + mawcharge.ToString("#,##0.00") + "</label>";
                //                                table += "</td></tr>";
                //                            }
                //                            else
                //                            {


                //                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                //                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                //                                table += "</td></tr>";
                //                            }


                //                        }
                //                        else
                //                        {
                //                            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                //                            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                //                        }

                //                        table += "</td></tr>";
                //                        //***************************End******************************************

                //                        if (Airline_id == "159")
                //                        {
                //                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() != "StaxRate")
                //                                total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //                        }
                //                        else
                //                            total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                //                    }

                //                    #endregion
                //                }
                //                #endregion
                //            }
                //            if (dt.Rows[0]["Tds_Cut_By_Agent"].ToString() != "0.00")
                //            {
                //                //Gst
                //                totalTds = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());
                //                lblTds.Text = "- " + Convert.ToString(totalTds);
                //                ////table += "<tr><td style=\"width: 290px;   text-align: left\" ><label>TDS :</label>";
                //                ////table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + "-" + dt.Rows[0]["Tds_Cut_By_Agent"].ToString() + "</label></td></tr>";
                //            }
                //            #endregion
                //            table += "</table>";
                //            lblTabel.Text = table;
                //            no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();
                //            recipt_no = dt.Rows[0]["recipt_no"].ToString();
                //            lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
                //            lblremarkshtml = @" <tr id='trremarks'>
                //                            <td colspan='4'><asp:Label ID='Label2' runat='server' Font-Bold='True' Font-Size='8pt'> Remark:-</asp:Label>                 
                //                                 <label ID='lblremarks' Font-Size='8pt'>" + dt.Rows[0]["Remarks"].ToString() + @"</label>   
                //                            </td>
                //                        </tr>
                //                        <tr>
                //                            <td colspan='4'>
                //                                ---------------------------------------------------------------------------------------------------------------------
                //                            </td>
                //                        </tr>";
                //            decimal CC_Cheque_Amount = Convert.ToDecimal(dt.Rows[0]["CC_Cheque_Amount"]);
                //            mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[0]["ChargeAmount"]);
                //            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //            decimal SBCessAmt = 0;
                //            decimal KKCessAmt = 0;
                //            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                //            {
                //               #region for looping
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //                {
                //                    SBCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                //                }
                //                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //                {
                //                    KKCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                //                }
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "Carting")
                //                {
                //                    cartingcharges = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //                }
                //                else if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                //                {
                //                    mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //                }
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate" && dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "0")
                //                {
                //                    #region if part
                //                    ////string strInclusive = string.Empty;
                //                    if (flagtable == true)
                //                    {
                //                        strInclusive += "<table border=0 width=400px align=center cellspacing=0>";
                //                    }

                //                    ////decimal DOCharge = Math.Round(Convert.ToDecimal(CC_Cheque_Amount - ((CC_Cheque_Amount * Convert.ToDecimal(10.3)) / (100 + Convert.ToDecimal(STAXRATE)))), 0, MidpointRounding.AwayFromZero);
                //                    ////decimal STaxAmt = Math.Round(Convert.ToDecimal((CC_Cheque_Amount * Convert.ToDecimal(10.3)) / (100 + Convert.ToDecimal(STAXRATE))), 0, MidpointRounding.AwayFromZero);

                //                    decimal STaxAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                //                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt;

                //                    ViewState["STaxAmt"] = STaxAmt;
                //                    ////if (Airline_id == "159")
                //                    ////{

                //                    ////    DOCharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100)));
                //                    ////}
                //                    if (Airline_id == "147" || Airline_id == "153")
                //                    {
                //                        ////strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + mawcharge + "</label></td></tr>";
                //                        ////strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                //                    }
                //                    else if (Airline_id == "159")
                //                    {
                //                        ////strInclusive += "<tr style=\"display:none\" ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        ////strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                //                    }
                //                    else
                //                    {
                //                        ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                //                    }
                //                   //// lblInclusive.Text = strInclusive;
                //                    #endregion
                //                }
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                //                {
                //                    #region if part
                //                    // string strInclusive = string.Empty;
                //                    decimal STaxAmt = 0;
                //                    if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                //                    {
                //                        ////ViewState["STaxAmt"] = "0";
                //                        ViewState["STaxAmt"] = STaxAmt;
                //                    }
                //                    else
                //                    {

                //                        STaxAmt = (Decimal)ViewState["STaxAmt"];
                //                    }
                //                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt;

                //                    if (Airline_id == "1591")
                //                    {
                //                        DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                //                        //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                //                        //DOCharge = Convert.ToDecimal(TD);

                //                    }

                //                    if (Airline_id == "159")
                //                    {
                //                        ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr></table>";

                //                    }
                //                    else if (Airline_id == "1591")
                //                    {
                //                        //////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                    }
                //                    else
                //                    {
                //                        //////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";

                //                    }
                //                    #endregion
                //                }
                //                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                //                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                //                {
                //                    #region if part
                //                    // string strInclusive = string.Empty;
                //                    decimal STaxAmt = 0;
                //                    if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                //                    {
                //                        ////ViewState["STaxAmt"] = "0";
                //                        ViewState["STaxAmt"] = STaxAmt;
                //                    }
                //                    else
                //                    {
                //                        STaxAmt = (Decimal)ViewState["STaxAmt"];
                //                    }
                //                    if (STaxAmt == 0)
                //                    {
                //                        STaxAmt = SBCessAmt;
                //                    }
                //                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt - KKCessAmt;
                //                    if (Airline_id == "1591")
                //                    {
                //                        #region if part
                //                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                //                        {
                //                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount@9% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount@9% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount@18% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                        }

                //                        else
                //                        {
                //                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                        }
                //                        #endregion
                //                    }
                //                    if (Airline_id == "159")
                //                    {
                //                        #region if aprt
                //                        ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                //                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                        #endregion
                //                    }
                //                    else if (Airline_id == "1591")
                //                    {
                //                        #region else if part
                //                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                //                        {
                //                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount@9% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount@9% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount@18% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                        }

                //                        else
                //                        {
                //                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                        }
                //                        #endregion
                //                    }
                //                    else
                //                    {
                //                        #region
                //                        if (strInclusive.Contains("<table"))
                //                        {

                //                        }
                //                        else
                //                        {
                //                            flagtable = false;
                //                            strInclusive += "<table border=0 width=400px align=center cellspacing=0>";
                //                        }
                //                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                //                        {
                //                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount@9% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount@9% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount@18% :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                        }

                //                        else
                //                        {
                //                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                //                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                //                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                //                        }
                //                         #endregion
                //                    }
                //                    #region Gst newly Added
                //                    GSTDoCharges = DOCharge;
                //                    CGSTChargs = STaxAmt;
                //                    SGSTChargs = SBCessAmt;
                //                    IGSTChargs = KKCessAmt;
                //                    #endregion Gst newly Added 
                //                #endregion
                //                }
                //                lblInclusive.Text = strInclusive;
                //                //Gst
                //                lblBreakupTotal.Text = Convert.ToDecimal(GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs).ToString("#,##0.00");
                //                lblRecivedAmt.Text = Convert.ToDecimal((GSTDoCharges + CGSTChargs + SGSTChargs + IGSTChargs) - totalTds).ToString("#,##0.00");
                //                Label1.Text = lblRecivedAmt.Text;  
                //               #endregion
                //            }
                //            string StaxNo = "";
                //            issue_date = dt.Rows[0]["issue_date"].ToString();
                //            straddress = dt.Rows[0]["office_address"].ToString();
                //            Airportadress = dt.Rows[0]["Airport_Address"].ToString();
                //            payment_mode = dt.Rows[0]["payment_mode"].ToString();
                //            flight_date = dt.Rows[0]["import_flight_Date"].ToString();
                //            //lblFltDateAirline.Text = flight_date;
                //            DateTime fltdate2 = DateTime.Parse(flight_date);
                //            lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");
                //            ////lblFlightDate.Text = flight_date;
                //            DateTime fltdate = DateTime.Parse(flight_date);
                //            lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");
                //            part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
                //            pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
                //            if (part_pcs == "" || part_pcs == "0")
                //            {
                //                lblPartPsc.Visible = false;
                //                lblPartPsc.Text = "";
                //                lblpppsc.Visible = false;
                //                lblpppsc.Text = "";
                //            }
                //            else
                //            {
                //                lblPartPsc.Visible = true; 
                //                lblPartPsc.Text = part_pcs;
                //                lblpppsc.Visible = true;
                //                lblpppsc.Text = "/";
                //            }
                //            //*****************Added On 1 feb 2011********************
                //            if (dt.Rows[0]["freight_type"].ToString() == "PP")
                //            {
                //                lblBeingFrtchrgs.Text = "PP";
                //            }
                //            else if (dt.Rows[0]["freight_type"].ToString() == "CC")
                //            {
                //                #region  dt.Rows[0]["freight_type"].ToString() == "CC"
                //                string MawbChrs = "";
                //                string HawbChrs = "";
                //                if (MawbDo_Chgs == "")
                //                {
                //                    MawbChrs = "0";
                //                }
                //                else
                //                {
                //                    MawbChrs = MawbDo_Chgs;
                //                }
                //                if (HawbDo_Chgs == "")
                //                {
                //                    HawbChrs = "0";
                //                }
                //                else
                //                {
                //                    HawbChrs = HawbDo_Chgs;
                //                }
                //                lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                //                lblDOChrgs.Text = Convert.ToString(decimal.Parse(MawbChrs) + decimal.Parse(HawbChrs));
                //                #endregion
                //            }
                //            //*****************END********************
                //            //******************Old AWb Details**************************
                //            DataTable dtOldAwb = dw.GetAllFromQuery("select IFS.import_flight_no,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFA.GstAddress,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");
                //            if (dtOldAwb.Rows.Count > 0 || dtOldAwb != null)
                //            {
                //                OldAwb_ReciptNo = dtOldAwb.Rows[0]["recipt_no"].ToString();
                //            }
                //            //********************************END OF OLD AWB Details***************
                //            strAirline_name = dt.Rows[0]["Airline_Name"].ToString();
                //            if (strAirline_name == "MALAYSIAN AIRLINES")
                //            {
                //                strAirline_name = "MALAYSIA AIRLINES";
                //            }
                //            awbno = dt.Rows[0]["Import_Awb_No"].ToString();
                //            flt_no = dt.Rows[0]["import_flight_no"].ToString();
                //            if (Airline_id == "158")
                //            {
                //                #region Airline_id == "158"
                //                if (FlightNo != "KE-9395" || FlightNo != "KE-9307" )
                //                {
                //                    if (FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                //                        flt_no = flt_no.Replace("HY", "KE");
                //                    else
                //                        flt_no = flt_no.Replace("KE", "HY");
                //                }
                //                #endregion
                //            }
                //            arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();
                //            contents = dt.Rows[0]["commodity"].ToString();
                //            if (contents == "Console")
                //            {
                //                contents = "Consol";
                //            }
                //            import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
                //            to = dt.Rows[0]["Consignee_Name"].ToString();
                //            if (to == "")
                //            {
                //                to = dt.Rows[0]["Agent_Name"].ToString();
                //            }
                //            if (Airline_id == "147" || Airline_id == "153")
                //            {
                //                to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
                //            }
                //            if (dt.Rows[0]["GstNo"].ToString() != "")
                //            {
                //                #region 
                //                string placeOfDelivery = "DELHI";
                //                string GstAddress = placeOfDelivery;

                //                if (dt.Rows[0]["GstAddress"].ToString() != "")
                //                {
                //                    GstAddress = dt.Rows[0]["GstAddress"].ToString();
                //                }

                //                DataTable dtdeliveryplace = dw.GetAllFromQuery("Select state from gststateCode where statecode=" + dt.Rows[0]["GstNo"].ToString().Substring(0, 2) + "");
                //                if (dtdeliveryplace.Rows != null && dtdeliveryplace.Rows.Count > 0)
                //                {
                //                    #region if condition
                //                    if (dtdeliveryplace.Rows[0]["state"].ToString() == "" || dtdeliveryplace.Rows[0]["state"].ToString() == null)
                //                    {
                //                        placeOfDelivery = dt.Rows[0]["GstNo"].ToString();
                //                        if (dt.Rows[0]["GstAddress"].ToString() == "")
                //                        {
                //                            GstAddress = placeOfDelivery;
                //                        }
                //                    }
                //                    else
                //                    {
                //                        placeOfDelivery = dtdeliveryplace.Rows[0]["state"].ToString();
                //                        if (dt.Rows[0]["GstAddress"].ToString() == "")
                //                        {
                //                            GstAddress = placeOfDelivery;
                //                        }
                //                    }
                //                    //////to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //                    to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //                    #endregion
                //                }
                //                else
                //                {
                //                    //// to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //                    to = to + "<br><b>GST Address:" + GstAddress + "</b><br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b><br/><b>Place of Delivery:" + placeOfDelivery + "</b>";
                //                }
                //                #endregion
                //            }
                //            from = dt.Rows[0]["Shipper_Name"].ToString();
                //            notify = dt.Rows[0]["Notify"].ToString();
                //            lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
                //            lblremarkshtml = @" <tr id='trremarks'>
                //                            <td colspan='4'><asp:Label ID='Label2' runat='server' Font-Bold='True' Font-Size='8pt'> Remark:-</asp:Label>                 
                //                                 <label ID='lblremarks' Font-Size='8pt'>" + dt.Rows[0]["Remarks"].ToString() + @"</label>   
                //                            </td>
                //                        </tr>
                //                        <tr>
                //                            <td colspan='4'>
                //                                ---------------------------------------------------------------------------------------------------------------------
                //                            </td>
                //                        </tr>";
                //            if (notify == "")
                //            {
                //                lblNotifyDo.Visible = false;
                //                lblNotifyDovalue.Visible = false;
                //                lblNotify.Visible = false; ;
                //                lblNotifyValue.Visible = false;
                //                lblNotifyValue.Text = "";

                //            }
                //            else
                //            {
                //                lblNotifyDo.Visible = true;
                //                lblNotifyDovalue.Visible = true;
                //                lblNotifyDovalue.Text = notify;
                //                lblNotify.Visible = true;
                //                lblNotifyValue.Visible = true;
                //                lblNotifyValue.Text = notify;
                //            }
                //            IGMNo = dt.Rows[0]["IGM_No"].ToString();
                //            string house = dt.Rows[0]["No_of_Houses"].ToString();
                //            decimal housevalue = System.Math.Round(decimal.Parse(house), 0);
                //            decimal d = housevalue * decimal.Parse(HAWBChrg);
                //            //************Added on 1 feb 2011 Added freight Chrages for CC Case****************
                //            decimal DOFrtChrgs = 0;
                //            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                //            {
                //                #region dt.Rows[0]["freight_Type"].ToString() == "CC"
                //                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
                //                {
                //                    DOFrtChrgs = 0;
                //                }
                //                else
                //                {
                //                    DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
                //                }
                //                TrFreightChrgsCC.Visible = true;
                //                d = d + DOFrtChrgs;
                //                #endregion
                //            }
                //            //************END**********************************************
                //            string addrs = "";
                //            lblAddress.Text = straddress.ToString();
                //            if (Airline_id == "158")
                //            {
                //                lblAddress.Text = straddress.ToString();
                //                lblAddress1.Text = Airportadress.ToString();
                //            }
                //            else
                //            {
                //                lblAddress.Text = straddress.ToString();
                //                lblAddress1.Text = straddress.ToString();
                //            }
                //            if (lblAddress.Text.Contains("GST NO"))
                //            {
                //                int i = lblAddress.Text.IndexOf(",GST NO");
                //                StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                //                addrs = lblAddress.Text.Replace(StaxNo, ".");
                //                addrs = addrs.Replace(",.", ".");              
                //                lblAddress.Text = addrs;
                //            }
                //            else
                //            {               
                //                lblAddress.Text = straddress.ToString();
                //            }
                //            if (lblAddress1.Text.Contains("GST NO"))
                //            {
                //                int i = lblAddress1.Text.IndexOf(",GST NO");
                //                StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
                //                addrs = lblAddress1.Text.Replace(StaxNo, ".");
                //                addrs = addrs.Replace(",.", ".");
                //                lblAddress1.Text = addrs;                
                //            }
                //            else
                //            {
                //                if (Airline_id == "158")
                //                    lblAddress1.Text = Airportadress.ToString();
                //                else
                //                    lblAddress1.Text = straddress.ToString();
                //            }
                //            if (lblAddress1.Text.Contains("Tel"))
                //                lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
                //            if (lblAddress1.Text.Contains("TEL"))
                //                lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
                //            if (lblAddress.Text.Contains("Tel"))
                //                lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
                //            if (lblAddress.Text.Contains("TEL"))
                //                lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
                //            if (lblAddress1.Text.Contains("Fax"))
                //                lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
                //            if (lblAddress1.Text.Contains("FAX"))
                //                lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
                //            if (lblAddress.Text.Contains("Fax"))
                //                lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
                //            if (lblAddress.Text.Contains("FAX"))
                //                lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");           
                //            if (payment_mode == "1")
                //            {
                //                lblCheque.Visible = false;
                //                lblCash.Text = "in Cash";
                //            }
                //            else if (payment_mode == "2")
                //            {
                //                lblCash.Visible = false;
                //                lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
                //            }

                //            #region  lblAirlineStax.Text
                //            if (strAirline_name == "MALAYSIA AIRLINES")
                //            {
                //                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            }
                //            else if (strAirline_name == "TURKISH AIRLINES")
                //            {
                //                lblAirlineStax.Text = "Ascent Air Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            }
                //            else if (strAirline_name == "AIR CHINA")
                //            {
                //                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            }
                //            else if (strAirline_name == "KOREAN AIRLINES")
                //            {
                //                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            }
                //            else if (strAirline_name == "KOREAN AIRLINES")
                //            {
                //                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            }
                //            else if (strAirline_name == "MEGA MALDIVES AIRLINES")
                //            {
                //                lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD <br/>GSSA " + strAirline_name + "<br/>" + CompAddress + ", " + StaxNo;
                //            }
                //            else
                //            {
                //                lblAirlineStax.Text = "Pace Express <br/>" + CompAddress + ", " + StaxNo;
                //            }
                //            #endregion

                //            lblSno.Text = recipt_no.ToString();
                //            lblSnomum.Text = recipt_no.ToString();
                //            lblSnochennai.Text = recipt_no.ToString();
                //            lblSno2.Text = recipt_no.ToString();
                //            lblName.Text = to.ToString();
                //            lblName2.Text = to.ToString();
                //            Sno.Text = recipt_no.ToString();          
                //            lblairlinename.Text = strAirline_name.ToString();
                //            lblairlinenamehtml = @"<tr>   
                //                                    <td colspan='4' style='height: 1px; text-align: center;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                <h4 style='text-align: center'>
                //                                                    TAX INVOICE</h4>
                //                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>
                //                                            </span></span>
                //                                    </td>
                //                            </tr>";
                //            if (Airline_id == "158")
                //            {
                //                //********************Updated on 19 Dec 2016******************
                //                #region  Airline_id == "158"
                //                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                //                {
                //                    lblAirlineNme.Text = "KOREAN AIR";
                //                    lblAirlineNmehtml = @"<tr>
                //                                    <td colspan=3 style='height: 10px'>
                //                                    </td>
                //                                    <td class='text' style='height: 10px'>
                //                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
                //                                    </td></tr>";

                //                    lblheadairlinename.Text = "KOREAN AIR";
                //                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                    <span class='Apple-style-span'
                //                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                        <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
                //                                                    </span>
                //                                                 </span>
                //                                            </td>
                //                                        </tr>";
                //                }
                //                else
                //                {

                //                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                //                    lblAirlineNmehtml = @"<tr>
                //                                    <td colspan=3 style='height: 10px'>
                //                                    </td>
                //                                    <td class='text' style='height: 10px'>
                //                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
                //                                    </td></tr>";

                //                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                //                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                    <span class='Apple-style-span'
                //                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                        <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
                //                                                    </span>
                //                                                 </span>
                //                                            </td>
                //                                        </tr>";
                //                }
                //                #endregion
                //                //********************End of Updated on 19 Dec 2016******************              
                //            }
                //            else if (Airline_id == "159")
                //            {
                //                #region else if condition
                //                if (FlightNo == "HY-127")
                //                {
                //                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                //                    lblAirlineNmehtml = @"<tr>
                //                                    <td colspan=3 style='height: 10px'>
                //                                    </td>
                //                                    <td class='text' style='height: 10px'>
                //                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>UZBEKISTAN AIRWAYS</label>
                //                                    </td></tr>";

                //                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                //                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                    <span class='Apple-style-span'
                //                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                        <label ID='lblheadairlinename' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>                            
                //                                                    </span>
                //                                                 </span>
                //                                            </td>
                //                                        </tr>";

                //                    lblairlinename.Text = "UZBEKISTAN AIRWAYS";
                //                    lblairlinenamehtml = @"<tr>   
                //                                    <td colspan='4' style='height: 1px; text-align: center;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                <h4 style='text-align: center'>
                //                                                    TAX INVOICE</h4>
                //                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>UZBEKISTAN AIRWAYS</label>
                //                                            </span></span>
                //                                    </td>
                //                            </tr>";
                //                }
                //                else
                //                {
                //                    lblAirlineNme.Text = "KOREAN AIR";
                //                    lblAirlineNmehtml = @"<tr>
                //                                    <td colspan=3 style='height: 10px'>
                //                                    </td>
                //                                    <td class='text' style='height: 10px'>
                //                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>KOREAN AIR</label>
                //                                    </td></tr>";

                //                    lblheadairlinename.Text = "KOREAN AIR";
                //                    lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                    <span class='Apple-style-span'
                //                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                        <label ID='lblheadairlinename' Font-Size='16px'>KOREAN AIR</label>                            
                //                                                    </span>
                //                                                 </span>
                //                                            </td>
                //                                        </tr>";

                //                    lblairlinename.Text = "KOREAN AIR";
                //                    lblairlinenamehtml = @"<tr>   
                //                                    <td colspan='4' style='height: 1px; text-align: center;'>
                //                                        <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                            text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                            letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                            webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                            webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'><span class='Apple-style-span'
                //                                                style='font-weight: bold; font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                <h4 style='text-align: center'>
                //                                                    TAX INVOICE</h4>
                //                                                <label ID='lblairlinename' Font-Bold='True' Font-Size='16px'>KOREAN AIR</label>
                //                                            </span></span>
                //                                    </td>
                //                            </tr>";
                //                }
                //                #endregion
                //            }
                //            else
                //            {
                //                #region else part
                //                lblAirlineNme.Text = strAirline_name.ToString();
                //                lblAirlineNmehtml = @"<tr>
                //                                    <td colspan=3 style='height: 10px'>
                //                                    </td>
                //                                    <td class='text' style='height: 10px'>
                //                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>" + strAirline_name.ToString() + @"</label>
                //                                    </td></tr>";

                //                lblheadairlinename.Text = strAirline_name.ToString();
                //                lblheadairlinenamehtml = @"<div style='width: 790px;'><table style='width: 790px'><tr><td colspan='4' style='text-align: center;'>
                //                                                <span class='Apple-style-span' style='word-spacing: 0px; font: medium 'Times New Roman';
                //                                                    text-transform: none; color: rgb(0,0,0); text-indent: 0px; white-space: normal;
                //                                                    letter-spacing: normal; border-collapse: separate; orphans: 2; widows: 2; webkit-border-horizontal-spacing: 0px;
                //                                                    webkit-border-vertical-spacing: 0px; webkit-text-decorations-in-effect: none;
                //                                                    webkit-text-size-adjust: auto; webkit-text-stroke-width: 0px'>
                //                                                    <span class='Apple-style-span'
                //                                                        style='font-weight: bold; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif;
                //                                                        webkit-border-horizontal-spacing: 1px; webkit-border-vertical-spacing: 1px'>
                //                                                        <h4 style='text-align: center'>DELIVERY ORDER</h4>
                //                                                        <label ID='lblheadairlinename' Font-Size='16px'>" + strAirline_name.ToString() + @"</label>                            
                //                                                    </span>
                //                                                 </span>
                //                                            </td>
                //                                        </tr>";
                //                #endregion
                //            }

                //            lblAwbno.Text = awbno.ToString();
                //            lblPcs.Text = pcs.ToString();
                //            ////////lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");
                //            //****************Added On 01_Mach_2011******
                //            lblDate.Text = issue_date;
                //            //***************End*************
                //            //lblDate.Text = DateTime.Now.ToString();
                //            lblcommdy.Text = contents.ToString();
                //            lblFlightno.Text = flt_no.ToString();
                //            //lblWt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                //            lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();
                //            lbligmnr.Text = IGMNo.ToString();
                //            lblAwb2.Text = awbno.ToString();
                //            lbldate2.Text = issue_date.ToString();
                //            lblFlitno2.Text = flt_no.ToString();
                //            lblAirlinemame3.Text = strAirline_name.ToString();
                //            if (Airline_id == "147" || Airline_id == "153")
                //            {
                //                lblch.Visible = true;
                //                lblchwt.Visible = true;
                //                lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                //                lblAirlinemame3.Text = "MASkargo";
                //                lblAirlineNme.Text = "MASkargo";

                //                lblAirlineNmehtml = @"<tr>
                //                                    <td colspan=3 style='height: 10px'>
                //                                    </td>
                //                                    <td class='text' style='height: 10px'>
                //                                         <label id='lblAirlineNme Font-Bold='True' Font-Size='8pt'>MASkargo</label>
                //                                    </td></tr>";
                //            }
                //            if (Airline_id == "159")
                //            {
                //                lblAirlinemame3.Text = "KOREAN AIR";
                //            }
                //            //******************Added On 1 feb 2011*********************
                //            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                //            {
                //                #region dt.Rows[0]["freight_Type"].ToString() == "CC"
                //                TrFreightChrgsCC.Visible = true;
                //                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "")
                //                {
                //                    lblDOFrtChr.Text = "0";
                //                }
                //                else
                //                {
                //                    lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                //                }
                //                #endregion
                //            }
                //            //****************************End*********************************************
                //            lblpartshipmentCase.Text = lblpartshipmentCase.Text + dtOldAwb.Rows[0]["recipt_no"].ToString();
                //            #endregion
                //        }
                //    }


        #endregion

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            FillGrd();
            rowColor();
            lblprint.Attributes.Add("onclick", "javascript:window.open('DisplayImportAirwaybillDetails.aspx?Import_Flight_ID=" + Session["FltID"].ToString() + "&st=print" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes');return false;");
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
        rowColor();
    }

    public void FillGrd()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string selectQ = null;
            //selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,Agent_Name,Consignee_Name,notify,rotation_no,remarks,landing_type,status from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + " ";
            //selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,CASE WHEN Tds_Cut_By_Agent > 0 THEN (ISNULL(CC_Cheque_Amount,0)-Tds_Cut_By_Agent) ELSE CASE WHEN stax_rate > 0 THEN (ISNULL(CC_Cheque_Amount,0)-stax_rate) ELSE  CASE WHEN CC_Cheque_Amount IS NULL  THEN 0  ELSE CC_Cheque_Amount  END END END AS DOAmount from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + " ";
            //selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,CASE WHEN Status!='DO Generated' THEN MAWBDO_chgs +(No_of_Houses*HAWBDO_chgs) ELSE 0 END AS DOAmount,case when part_pcs > 0 then part_pcs+'/'+pcs else isnull(pcs,0) end as No_0fpcs from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + "AND status!='DO Generated'";
            ///////selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,CASE WHEN Status!='DO Generated' THEN MAWBDO_chgs +(No_of_Houses*HAWBDO_chgs)  END AS DOAmount,case when part_pcs > 0 then part_pcs+'/'+pcs else isnull(pcs,0) end as No_0fpcs from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + " ";
            selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,MAWBDO_chgs +(No_of_Houses*HAWBDO_chgs) AS DOAmount,case when part_pcs > 0 then part_pcs+'/'+pcs else isnull(pcs,0) end as No_0fpcs,payment_mode from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + " and Status!='Void' ";
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                DataTable BankConsigneeStatus = dw.GetAllFromQuery("select  Freight_Type,BankConsigneeStatus,Import_AWB_No,isnull(No_of_Houses,0)as No_of_Houses,HawbDo_Chgs,MawbDo_Chgs,shipment_type,Charged_Weight from import_flight_awb where Import_Awb_Id=" + dt.Rows[i]["import_awb_id"].ToString() + "");
                if (Session["Airline_detail_Id"].ToString() == "159" && BankConsigneeStatus.Rows[0]["shipment_type"].ToString() == "C")
                DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + " and ChargeHeadName NOT IN ('Carting','CommunicationFee')");
                else
                DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + "");
                decimal Allvalue = 0;
                decimal total = 0;
                if (DtImportChargesHeads.Rows.Count > 0)
                {
                    int j;
                    for (j = 0; j < DtImportChargesHeads.Rows.Count; j++)
                    {
                        if (DtImportChargesHeads.Rows[j]["ForEach"].ToString() == "Y")
                        {
                            Allvalue = decimal.Parse(DtImportChargesHeads.Rows[j]["defaultValue"].ToString()) * decimal.Parse(dt.Rows[i]["No_of_Houses"].ToString());
                        }
                        else
                        {
                            Allvalue = decimal.Parse(DtImportChargesHeads.Rows[j]["defaultValue"].ToString());
                        }
                        total += Allvalue;
                        
                    }
                }
                //******Added on 24 feb 2011 logic: If part_Shipment OR Duble Awb exixt in import_Fight_Awb Table then DO Amount of 2nd Awb is Zero(becoz payment has alreday been collected on first Reciept No of Ist AwbNo)******
                DataTable dtAwbexist = dw.GetAllFromQuery("select import_awb_no ,import_awb_id,D0_Generate_Status,Import_flight_id from import_flight_awb where import_awb_no='" + dt.Rows[i]["import_awb_no"].ToString() + "'");
                //if (dtAwbexist.Rows.Count > 1)
                //{
                //    for (int b = 0; b < dtAwbexist.Rows.Count; b++)
                //    {
                //        if (dtAwbexist.Rows[b]["D0_Generate_Status"].ToString() != "YES")
                //        {
                //            if (dtAwbexist.Rows[b]["Import_flight_id"].ToString() == Session["FltID"].ToString())
                //           {
                //               total = 0;
                //           }
                           
                //        }
                //    }
                //}
                //*************END*************************
                //****************Added on 24 feb 2011: IN Case Of  FOC Shipment: DO  Amount=0**************
                if (dt.Rows[i]["shipment_type"].ToString() == "F")
                {
                    total = 0;
                }
                //*************END*************************            
                dt.Rows[i]["DOAmount"] = total;
            }
            grdDisplayAllocation.DataSource = dt;
            grdDisplayAllocation.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

        // Display Row Color
    protected void rowColor()
    {
        int c = grdDisplayAllocation.Columns.Count;
        for (int i = 0; i < grdDisplayAllocation.Rows.Count; i++)
        {
            GridViewRow gr = grdDisplayAllocation.Rows[i];
            LinkButton l1 = (LinkButton)(gr.FindControl("lblPrint"));
            LinkButton l2 = (LinkButton)(gr.FindControl("lblPrintCan"));
            /// added on 21 sep 2011 for given permision of void to head only  ////
            LinkButton lbnVoid = (LinkButton)(gr.FindControl("lbnVoid"));
            /////end//////////////
            if (((Label)(gr.FindControl("lblLtype"))).Text == "S")
            {
                gr.BackColor = System.Drawing.Color.LightBlue;
                l1.Visible = false;
                l2.Visible = false;
            }
            if (((Label)(gr.FindControl("lblLtype"))).Text == "E")
            {
                gr.BackColor = System.Drawing.Color.PeachPuff;
                l1.Visible = false;
                l2.Visible = false;
            }
            //******Change Color of DO generated Row    on :29 July 2010******
            if (((Label)(gr.FindControl("lblDoStatus"))).Text == "DO Generated")
            {
                gr.BackColor = System.Drawing.Color.Silver;
/// added on 21 sep 2011 for given permision of void to head only  ////
              
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand("GetPermision_Import_DO_Void", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            SqlDataAdapter sdaPermission = new SqlDataAdapter(com);
            DataTable dtPermission = new DataTable();
            sdaPermission.Fill(dtPermission);
            con.Close();
            if (dtPermission.Rows.Count > 0)
            {
                if (dtPermission.Rows[0]["Permission"].ToString() == "1")
                {
                    lbnVoid.Visible = true;
                }
                else
                {
                    lbnVoid.Visible = false;
                }
            }
                /////end//////////////

            }
            else
            {
                ((LinkButton)(gr.FindControl("lblPrint"))).Text = "DO Generate";
                gr.BackColor = System.Drawing.Color.Cornsilk;
            }
            //******************End**********************************************
        }
    }

    public void Search()
    {
        string s1 = ddlAllocationt.Text;

        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string selectQ = null;
            //selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,Agent_Name,Consignee_Name,notify,rotation_no,remarks,landing_type,Status from Import_Flight_AWB where import_awb_no like'%" + ddlAllocationt.Text + "%'";

            //selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,CASE WHEN Tds_Cut_By_Agent > 0 THEN (ISNULL(CC_Cheque_Amount,0)-Tds_Cut_By_Agent) ELSE CASE WHEN stax_rate > 0 THEN (ISNULL(CC_Cheque_Amount,0)-stax_rate) ELSE  CASE WHEN CC_Cheque_Amount IS NULL  THEN 0  ELSE CC_Cheque_Amount  END END END AS DOAmount from Import_Flight_AWB where import_awb_no like'%" + ddlAllocationt.Text + "%'";



            if (ddlAllocationt.Text != "")
            {
                ////selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,CASE WHEN Status!='DO Generated' THEN MAWBDO_chgs +(No_of_Houses*HAWBDO_chgs) ELSE 0 END AS DOAmount,case when part_pcs > 0 then part_pcs+'/'+pcs else isnull(pcs,0) end as No_0fpcs from Import_Flight_AWB where import_awb_no like'%" + ddlAllocationt.Text + "%'";


                selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,MAWBDO_chgs +(No_of_Houses*HAWBDO_chgs) AS DOAmount,case when part_pcs > 0 then part_pcs+'/'+pcs else isnull(pcs,0) end as No_0fpcs,payment_mode from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + " and import_awb_no like'%" + ddlAllocationt.Text + "%'";
            }
            else
            {
                selectQ = "Select import_awb_id,import_awb_no,import_flight_id,pcs,part_pcs,part_shipment_type,charged_weight,Gross_Weight,Origin,Destination,Freight_Type,Commodity,SLS,No_of_Houses,Shipper_Name,shipment_type,agent_id,CASE WHEN Agent_Name <>'' THEN Agent_Name ELSE Consignee_Name  END AS Agent_Name ,Consignee_Name,notify,rotation_no,remarks,landing_type,status,MAWBDO_chgs +(No_of_Houses*HAWBDO_chgs) AS DOAmount,case when part_pcs > 0 then part_pcs+'/'+pcs else isnull(pcs,0) end as No_0fpcs,payment_mode from Import_Flight_AWB where import_flight_id=" + int.Parse(Session["FltID"].ToString()) + "";

            }


            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataTable DtImportChargesHeads = dw.GetAllFromQuery("SELECT * FROM ImportChargesHeads  WHERE Airline_detail_id=" + Session["Airline_detail_Id"].ToString() + "");
                decimal Allvalue = 0;
                decimal total = 0;
                if (DtImportChargesHeads.Rows.Count > 0)
                {
                    int j;
                    for (j = 0; j < DtImportChargesHeads.Rows.Count; j++)
                    {
                        if (DtImportChargesHeads.Rows[j]["ForEach"].ToString() == "Y")
                        {
                            Allvalue = decimal.Parse(DtImportChargesHeads.Rows[j]["defaultValue"].ToString()) * decimal.Parse(dt.Rows[i]["No_of_Houses"].ToString());
                        }
                        else
                        {
                            Allvalue = decimal.Parse(DtImportChargesHeads.Rows[j]["defaultValue"].ToString());
                        }
                        total += Allvalue;

                    }
                }
                //******Added on 24 feb 2011 logic: If part_Shipment OR Duble Awb exixt in import_Fight_Awb Table then DO Amount of 2nd Awb is Zero(becoz payment has alreday been collected on first Reciept No of Ist AwbNo)******
                DataTable dtAwbexist = dw.GetAllFromQuery("select import_awb_no ,import_awb_id,D0_Generate_Status,Import_flight_id from import_flight_awb where import_awb_no='" + dt.Rows[i]["import_awb_no"].ToString() + "'");
                if (dtAwbexist.Rows.Count > 1)
                {
                    for (int b = 0; b < dtAwbexist.Rows.Count; b++)
                    {
                        if (dtAwbexist.Rows[b]["D0_Generate_Status"].ToString() != "YES")
                        {
                            if (dtAwbexist.Rows[b]["Import_flight_id"].ToString() == Session["FltID"].ToString())
                            {
                                total = 0;
                            }

                        }
                    }
                }
                //*************END*************************

                //****************Added on 24 feb 2011: IN Case Of  FOC Shipment: DO  Amount=0**************
                if (dt.Rows[i]["shipment_type"].ToString() == "F")
                {
                    total = 0;
                }
                //*************END*************************

                dt.Rows[i]["DOAmount"] = total;
            }
            grdDisplayAllocation.DataSource = dt;
            grdDisplayAllocation.DataBind();
            con.Close();

            //com = new SqlCommand(selectQ, con);
            //da = new SqlDataAdapter(com);
            //dt = new DataTable();
            //da.Fill(dt);
            //grdDisplayAllocation.DataSource = dt;
            //grdDisplayAllocation.DataBind();
            //con.Close();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void grdDisplayAllocation_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdDisplayAllocation.PageIndex = e.NewPageIndex;
        FillGrd();
        rowColor();
    }

    protected void Modify(object sender, CommandEventArgs e)
    {
        ////Response.Redirect("View_Import_Flight_Details_New.aspx?Import_Awb_ID=" + e.CommandArgument.ToString() + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=E&Import_Flight_No=" + Session["Import_Flight_No"] + "&Airline_Detail_ID=" + Session["Airline_Detail_ID"] +"");
    }

    protected void Can(object sender, CommandEventArgs e)
    {
        Response.Redirect("Import_Flight_Awb.aspx?AWBID=" + e.CommandArgument.ToString() + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=CAN");
    }

    protected void grdDisplayAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
    {
       //////if (e.CommandName == "SetEdit")
       ////// {
       //////     Response.Redirect("View_Import_Flight_Details_New.aspx?Import_Awb_ID=" + e.CommandArgument.ToString() + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=E");

       ////// }
        if (e.CommandName == "SetEdit")
        {
            //Response.Redirect("View_Import_Flight_Details_New.aspx?Import_Awb_ID=" + e.CommandArgument.ToString() + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=E");
            DataTable dt = dw.GetAllFromQuery("SELECT * FROM db_owner.Import_Flight_AWB WHERE Import_AWB_ID=" + e.CommandArgument.ToString() + " AND Status='DO Generated'");
            if (dt.Rows.Count > 0)
            {

                string strScript = "alert('You are not able to MODIFY shipment after DO Generated. Please VOID this shipment and generate new DO for same shipment, if want to MODIFY.' );";

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
                return;

            }
            else
            {
                Response.Redirect("View_Import_Flight_Details_New.aspx?Import_Awb_ID=" + e.CommandArgument.ToString() + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=E&Import_Flight_No=" + Session["Import_Flight_No"] + "&Airline_Detail_ID=" + Session["Airline_Detail_ID"] + "");
            }

        }

        else if (e.CommandName == "SetDelete")
        {
            int i = int.Parse(e.CommandArgument.ToString());
        }

       else if (e.CommandName == "SetVoid")
       {

           voidAirwaybill(e.CommandArgument.ToString());       
       }
        else if (e.CommandName == "DO/Print")
        {
            hdnNewWindowForPrint.Value = string.Empty;   
        }
    }

    protected void grdDisplayAllocation_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //LinkButton l = (LinkButton)e.Row.FindControl("lbldelete");
            //l.Attributes.Add("onclick", "javascript: return confirm('Are you sure you want to Delete Record ?')");
             LinkButton lbnVoid = (LinkButton)e.Row.FindControl("lbnVoid");          
             //lbnVoid.Attributes.Add("onclick", " javascript: return confirm('Are you sure you want to Void Record ?')"); //by jj
             Label  lblstatus = (Label)e.Row.FindControl("lblstatus");
             Label lblp = (Label)e.Row.FindControl("Label17");
             Label lblpcs = (Label)e.Row.FindControl("Label14");
             if (lblstatus.Text == "Y")
             {
                 lblp.Visible = true;
                 lblpcs.Visible = true;
             }
            //**************** For Open DO/Print Status Direct*********************on 19 Aug 2010
             LinkButton lblPrint = (LinkButton)e.Row.FindControl("lblPrint");
             Label LblAwbID = (Label)e.Row.FindControl("LblAwbID");
             Label lblDoStatus = (Label)e.Row.FindControl("lblDoStatus");
             if (lblDoStatus.Text == "DO Generated")
             {
                 lblPrint.OnClientClick = "javascript:window.open('DO_Print_Gst.aspx?AWBID=" + LblAwbID.Text + " &Mode=1');";
             }
            //********** End*********************************
        }       
    }
   
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_Import_Flight_Details_New.aspx");
    }

    protected void lnkPrintAll(Object sender, CommandEventArgs e)
    {
        string printSNoAll = string.Empty;   
        string[] strawbid = new string[] { };
        for (int SNoAll = 0; SNoAll < grdDisplayAllocation.Rows.Count; SNoAll++)
        {
            Label lblSNo = (Label)grdDisplayAllocation.Rows[SNoAll].FindControl("LblAwbID");
            CheckBox cboxPrint = (CheckBox)grdDisplayAllocation.Rows[SNoAll].FindControl("cboxPrint");
            if (cboxPrint.Checked)
                printSNoAll = printSNoAll + lblSNo.Text + ",";           
        }       
        if (printSNoAll == string.Empty)
        {
            hdnNewWindowForPrint.Value = string.Empty;
            //printSNoAll = string.Empty;
        }
        else
        {
            strawbid = Regex.Split(printSNoAll, ",");
            //hdnNewWindowForPrint.Value = "DO_Print_Gst_updated.aspx?AWBID=" + strawbid[0]  + "&Mode=1";
            hdnNewWindowForPrint.Value = "DO_Cancel.aspx?AWBID=" + strawbid[0] + "&Mode=1";
        }
        //hdnNewWindowForPrint.Value = "DO_Print_Gst2.aspx?AWBID=" + printSNoAll + "&Mode=1";  
        // hdnNewWindowForPrint.Value = "Do_testpage.aspx?AWBID=" + printSNoAll + "&Mode=1";
        //hdnNewWindowForPrint.Value = "DO_Cancel.aspx?AWBID=" + printSNoAll + "&Mode=1";
        // Server.Transfer("DO_Print_Gst.aspx?AWBID=" + printSNoAll + "&Mode=1");           
        //Response.Write("<script>window.open ('DO_Print_Gst.aspx?AWBID=" + printSNoAll + "&Mode=1','_blank');</script>");
    }   

    public string GetViewUrlWithQueryString(string sno)
    {
        //return "javascript:window.open('PrepaidCollect.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";
        //*************Added on 15June2015 :PrepaidCollect Page should be seperate in case of KE-MUM**************//
        hdnNewWindowForPrint.Value = null;
        string temp = Session["Airline_detail_Id"].ToString();
        //return "javascript:window.open('PrepaidCollect.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";
        if (temp != null && temp == "159")
        {
            return "location.href='PrepaidCollectKE_MUMHY127.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "';";
        }
        else if (temp != null && temp == "165")
        {
            return "location.href='PrepaidCollect_CA_MUM.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "';";
        }
        else
            return "location.href='PrepaidCollect.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "';";

        //*****************End of 15June2015********************************************
        ////////////return "location.href='PrepaidCollect.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "';";       
    }

    public string GetViewUrlWithQueryStringCAN(string sno)
    {
        //*************Added on 15June2015:CAN Print pafe should be difrrent for KE-MUM cas*********************//
        string temp = Session["Airline_detail_Id"].ToString();
        if (temp != null && temp == "159")
        {
            return "javascript:window.open('CAN_Print_KE_MUM.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";
        }
       else if (temp != null && temp == "165")
        {
            return "javascript:window.open('Can_Print_CA_MUM.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";
        }
        else
            return "javascript:window.open('CAN_Print.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";
        //************End on 15June2015*************************************************************************//
       
        /////return "javascript:window.open('CAN_Print.aspx?AWBID=" + sno + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=DO" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";
        
           
    }

    protected void Delete(object sender, CommandEventArgs e)
    {
        Response.Redirect("View_Import_Flight_Details_New.aspx?Import_Awb_ID=" + e.CommandArgument.ToString() + "&Import_Flight_ID=" + Session["FltID"].ToString() + "&st=D&Import_Flight_No=" + Session["Import_Flight_No"] + "&Airline_Detail_ID=" + Session["Airline_Detail_ID"] + "");
    }

    //protected void lblprint_Click(object sender, EventArgs e)
    //{
    //    //return "javascript:window.open('DisplayImportAirwaybillDetails.aspx?Import_Flight_ID=" + Session["FltID"].ToString() + "&st=print" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";

    //    Response.Redirect("DisplayImportAirwaybillDetails.aspx?Import_Flight_ID=" + Session["FltID"].ToString() + "&st=print");
    //}

    //public string GetViewUrlWithQueryStringFlightDetails()
    //{

    //    return "javascript:window.open('DisplayImportAirwaybillDetails.aspx?Import_Flight_ID=" + Session["FltID"].ToString() + "&st=print" + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes')";

    //}
    //protected void lblprint_Click1(object sender, EventArgs e)
    //{
    //    Response.Redirect("DisplayImportAirwaybillDetails.aspx?Import_Flight_ID=" + Session["FltID"].ToString() + "&st=print");
    //}

    protected void voidAirwaybill(string Import_Awb_ID)
    { 
              
                con = new SqlConnection(strCon);
                con.Open();
                DataTable dtcheckshipment = dw.GetAllFromQuery("SELECT shipment_type from Import_Flight_AWB where Import_Awb_ID=" + Import_Awb_ID + " AND shipment_type!='F'");
                if (dtcheckshipment.Rows.Count > 0)
                {

                    DataTable dtairwaybillno = dw.GetAllFromQuery("SELECT Import_AWB_ID FROM Import_Flight_AWB WHERE Import_AWB_No=(SELECT Import_AWB_No  FROM db_owner.Import_Flight_AWB WHERE Import_AWB_ID=" + Import_Awb_ID + " AND Airline_Detail_Id=" + Request.QueryString["Airline_Detail_ID"].ToString() + ")AND status !='Void'");
                    for (int i = 0; i < dtairwaybillno.Rows.Count; i++)
                    {
                        com=new SqlCommand("VoidImportAwb",con);
                        com.CommandType = CommandType.StoredProcedure;
                        //com.Parameters.Add("@Import_Awb_ID", SqlDbType.VarChar).Value = Import_Awb_ID;
                        com.Parameters.Add("@Import_Awb_ID", SqlDbType.VarChar).Value = dtairwaybillno.Rows[i]["Import_AWB_ID"].ToString();

                        //com = new SqlCommand("update Import_Flight_AWB set Status='Void',Payment_Mode=NULL where Import_Awb_ID=" + dtairwaybillno.Rows[i]["Import_AWB_ID"], con);
                        com.ExecuteNonQuery();



                        //com = new SqlCommand("update ImportFlightAwb_Trans set ChargeAmount=0,ChargeRate=0,Quantity=0 where ImportAwbID=" + dtairwaybillno.Rows[i]["Import_AWB_ID"], con);
                        //com.ExecuteNonQuery();
                       
                    
                    
                    }

                }
                else
                {

                //    com = new SqlCommand("update Import_Flight_AWB set Status='Void',Payment_Mode=NULL where Import_Awb_ID=" + Import_Awb_ID, con);
                //com.ExecuteNonQuery();
              

                con = new SqlConnection(strCon);
                con.Open();

                com = new SqlCommand("VoidImportAwb", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Import_Awb_ID", SqlDbType.VarChar).Value = Import_Awb_ID;


                //com = new SqlCommand("update ImportFlightAwb_Trans set ChargeAmount=0,ChargeRate=0,Quantity=0 where ImportAwbID=" + Import_Awb_ID, con);
                com.ExecuteNonQuery();
          

                }
                con.Close();
                //Response.Redirect("View_Import_Flight_Details_New.aspx?Import_Fli;ght_ID=" + Session["FltID"].ToString()); 
                Response.Redirect("View_Import_Flight_Details_New.aspx?Import_Flight_ID=" + Session["FltID"].ToString() + "&Airline_detail_Id=" + Session["Airline_detail_Id"].ToString() + "&Import_Flight_No=" + Session["Import_Flight_No"].ToString() + "&City_code=" + Session["City_code"].ToString());
            
    
    }
}
