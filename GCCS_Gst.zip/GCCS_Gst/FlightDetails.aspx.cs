using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Default5 : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DataSet ds;
    DisplayWrap dw = new DisplayWrap();
    DataTable dt = new DataTable();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        if (!IsPostBack)
        {
            ViewFlights();
        }
    }
    #region ViewFlights
    public void ViewFlights()
    {
        try
        {
            //con.Open();
            //com = new SqlCommand("select_Flight_Details", con);
            //com.CommandType = CommandType.StoredProcedure;
            //com.Parameters.Add("@Origin", SqlDbType.Int).Value = 1;
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt=dw.GetAllFromQuery("select distinct fd.Flight_ID,fm.Origin,fd.Schedule_Type,fm.Airline_Detail_ID,fd.Entered_By from Flight_Details fd INNER JOIN Flight_Master fm ON fd.Flight_ID = fm.Flight_ID where Airline_Detail_ID in(" + Session["AIRLINEACCESS"].ToString() + ")");
            DataTable dt = new DataTable();
            com = new SqlCommand("GetFlightDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@AirlineAcess", Session["AIRLINEACCESS"].ToString());
            com.Parameters.AddWithValue("@Flight_No", txt_search.Text);
            com.Parameters.AddWithValue("@Email_ID", Session["EMailID"].ToString());
            SqlDataAdapter adp = new SqlDataAdapter(com);
            adp.Fill(dt);
            FlightGridView.DataSource = dt;
            FlightGridView.DataBind();
            con.Close();
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    #endregion
    public void BindGrid2(long FlightID)
    {
        #region BindGrid Method For Binding Grid
        con = Util.getcon();
        con.Open();
        com = new SqlCommand("[BIND_SCHEDULE]", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@ScheduleType", SqlDbType.Int).Value = 1;
        com.Parameters.Add("@FlightID", SqlDbType.BigInt).Value = FlightID;
        DataTable dtSchedule = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(com);
        da.Fill(dtSchedule);
        ViewState["dtSchedule"] = dtSchedule;
        #endregion
    }
    public void BindGrid3(long FlightID)
    {
        #region BindGrid Method For Binding Grid
        con = Util.getcon();
        con.Open();
        com = new SqlCommand("[BIND_SCHEDULE]", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@ScheduleType", SqlDbType.Int).Value = 0;
        com.Parameters.Add("@FlightID", SqlDbType.BigInt).Value = FlightID;
        DataTable dtSchedule1 = new DataTable();
        com.Connection = con;
        SqlDataAdapter da = new SqlDataAdapter(com);
        da.Fill(dtSchedule1);
        ViewState["dtSchedule1"] = dtSchedule1;
        #endregion
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ViewFlights();
    }
    protected void AirlineGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //e.Row.Cells[4].Visible = false;
            //e.Row.Cells[5].Visible = false;
            //e.Row.Cells[6].Visible = false;
            long FlightID = Convert.ToInt64(e.Row.Cells[0].Text);
            long CityID = Convert.ToInt64(e.Row.Cells[1].Text);
            DataTable dtFlight = dw.GetAllFromQuery("Select Flight_No,Origin from Flight_Master where Flight_ID=" + FlightID);
            DataTable dtCity = dw.GetAllFromQuery("Select City_Code from City_Master where City_ID=" + CityID);
            if (dtFlight.Rows.Count > 0)
            {
                e.Row.Cells[0].Text = dtFlight.Rows[0]["Flight_No"].ToString();
            }
            if (dtCity.Rows.Count > 0)
            {
                e.Row.Cells[1].Text = dtCity.Rows[0]["City_Code"].ToString();
            }
            //LinkButton lnkFlightOpen = e.Row.Cells[4].FindControl("lnkModify");
            //dw.GetAllFromQuery();
            if (e.Row.Cells[2].Text == "DAYWISE")
            {
                BindGrid2(FlightID);
                dt = (DataTable)ViewState["dtSchedule"];

                GridView GridViewNew = (GridView)e.Row.Cells[3].FindControl("GridView2");
                GridViewNew.DataSource = dt;
                GridViewNew.DataBind();
                GridViewNew.Caption = "EVERY WEEK";
            }
            if (e.Row.Cells[2].Text == "DATEWISE")
            {
                BindGrid3(FlightID);
                dt = (DataTable)ViewState["dtSchedule1"];
                GridView GridViewNew = (GridView)e.Row.Cells[3].FindControl("GridView2");
                GridViewNew.DataSource = dt;
                GridViewNew.DataBind();
                //GridViewNew.HeaderRow.Font.Bold = true;
                GridViewNew.Caption = "EVERY MONTH";
            }
            if (e.Row.Cells[2].Text == "DAILY")
            {
                BindGrid2(FlightID);
                dt = (DataTable)ViewState["dtSchedule"];

                GridView GridViewNew = (GridView)e.Row.Cells[3].FindControl("GridView2");
                GridViewNew.DataSource = dt;
                GridViewNew.DataBind();
                GridViewNew.Caption = "EVERY DAY";
            }          
            //dt = (DataTable)ViewState["dtSchedule"];
            //GridView GridViewNew = (GridView)e.Row.Cells[3].FindControl("GridView2");
            //GridViewNew.DataSource = dt;
            //GridViewNew.DataBind();
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Flight_Add.aspx");
    }
    //protected void FlightGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //    FlightGridView.PageIndex = e.NewPageIndex;
    //    ViewFlights();

    //}
    public void Modi(object sender, CommandEventArgs e)
    {
        Response.Redirect("Flight_Add.aspx?FlightID=" + e.CommandArgument);
    }
}
