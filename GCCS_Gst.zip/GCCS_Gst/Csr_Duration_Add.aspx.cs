using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;


// This Page is Design & Coding By Alok Date:22.01.2008
public partial class Csr_Duration_Add : System.Web.UI.Page
{
    /// <summary>
    /// Make connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;


    // Declare Public Variables Here
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataAdapter da=null;
    DataTable dt = null;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            //int dt = System.DateTime.Now.Month;
            //if (dt == 1)
            //    dt = 2;
            //ddlMonth.Items[dt - 2].Selected = true;
            //int yy = System.DateTime.Now.Year;
            //int s = ddlyear.Items.IndexOf(ddlyear.Items.FindByValue(yy.ToString()));
            //ddlyear.Items[s].Selected = true;
        }
    }
    protected void btnadde_Click(object sender, EventArgs e)
    {
        Session["dt"] = null;

        string comAdd = null;
        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();

        TextBox TextBox4 = new TextBox();
        TextBox TextBox5 = new TextBox();
        TextBox TextBox6 = new TextBox();
        //string strY = DateTime.Today.Year.ToString();
        string strY = ddlyear.SelectedItem.Text.Trim();
        string strY1 = ddlyear.SelectedItem.Text.Trim().Substring(2,2);
        if (rbtnFirstFortn.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
                TextBox4.Text = "01/01/" + strY1;
                TextBox5.Text = "01/15/" + strY1;
                TextBox6.Text = "01/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;

                TextBox4.Text = "02/01/" + strY1;
                TextBox5.Text = "02/15/" + strY1;
                TextBox6.Text = "02/16/" + strY1;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
                TextBox4.Text = "03/01/" + strY1;
                TextBox5.Text = "03/15/" + strY1;
                TextBox6.Text = "03/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
                TextBox4.Text = "04/01/" + strY1;
                TextBox5.Text = "04/15/" + strY1;
                TextBox6.Text = "04/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
                TextBox4.Text = "05/01/" + strY1;
                TextBox5.Text = "05/15/" + strY1;
                TextBox6.Text = "05/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
                TextBox4.Text = "06/01/" + strY1;
                TextBox5.Text = "06/15/" + strY1;
                TextBox6.Text = "06/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
                TextBox4.Text = "07/01/" + strY1;
                TextBox5.Text = "07/15/" + strY1;
                TextBox6.Text = "07/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
                TextBox4.Text = "08/01/" + strY1;
                TextBox5.Text = "08/15/" + strY1;
                TextBox6.Text = "08/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
                TextBox4.Text = "09/01/" + strY1;
                TextBox5.Text = "09/15/" + strY1;
                TextBox6.Text = "09/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
                TextBox4.Text = "10/01/" + strY1;
                TextBox5.Text = "10/15/" + strY1;
                TextBox6.Text = "10/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
                TextBox4.Text = "11/01/" + strY1;
                TextBox5.Text = "11/15/" + strY1;
                TextBox6.Text = "11/16/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
                TextBox4.Text = "12/01/" + strY1;
                TextBox5.Text = "12/15/" + strY1;
                TextBox6.Text = "12/16/" + strY1;
            }
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
                TextBox4.Text = "01/16/" + strY1;
                TextBox5.Text = "01/31/" + strY1;
                TextBox6.Text = "02/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { 
                    TextBox2.Text = "02/28/" + strY;
                }

                TextBox3.Text = "03/01/" + strY;

                TextBox4.Text = "02/16/" + strY1;
                if (DateTime.IsLeapYear(int.Parse(strY1)))
                    TextBox5.Text = "02/29/" + strY1;
                else
                {
                    TextBox5.Text = "02/28/" + strY1;
                }

                TextBox6.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
                TextBox4.Text = "03/16/" + strY1;
                TextBox5.Text = "03/31/" + strY1;
                TextBox6.Text = "04/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
                TextBox4.Text = "04/16/" + strY1;
                TextBox5.Text = "04/30/" + strY1;
                TextBox6.Text = "05/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
                TextBox4.Text = "05/16/" + strY1;
                TextBox5.Text = "05/31/" + strY1;
                TextBox6.Text = "06/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
                TextBox4.Text = "06/16/" + strY1;
                TextBox5.Text = "06/30/" + strY1;
                TextBox6.Text = "07/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
                TextBox4.Text = "07/16/" + strY1;
                TextBox5.Text = "07/31/" + strY1;
                TextBox6.Text = "08/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
                TextBox4.Text = "08/16/" + strY1;
                TextBox5.Text = "08/31/" + strY1;
                TextBox6.Text = "09/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
                TextBox4.Text = "09/16/" + strY1;
                TextBox5.Text = "09/30/" + strY1;
                TextBox6.Text = "10/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
                TextBox4.Text = "10/16/" + strY1;
                TextBox5.Text = "10/31/" + strY1;
                TextBox6.Text = "11/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
                TextBox4.Text = "11/16/" + strY1;
                TextBox5.Text = "11/30/" + strY1;
                TextBox6.Text = "12/01/" + strY1;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
                TextBox4.Text = "12/16/" + strY1;
                TextBox5.Text = "12/31/" + strY1;
                TextBox6.Text = "01/01/" + strY1;
            }

        }
        string csr_dur = TextBox4.Text + "-" + TextBox5.Text;
        string csr_dur1 = TextBox1.Text + "-" + TextBox2.Text;
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string strselect = "select * from CSR_Duration where CSR_Duration='" + csr_dur + "' and CSR_Duration1='" + csr_dur1 + "'";
            com = new SqlCommand(strselect, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = " Record Already Exists For Period " + TextBox1.Text + " To " + TextBox2.Text;

            }
            else
            {
                string stradd = "insert into CSR_Duration(CSR_Duration,CSR_Duration1) values('" + csr_dur + "','" + csr_dur1 + "')";
                com = new SqlCommand(stradd, con);
                com.ExecuteNonQuery();
                lblmsg.Visible = true;
                lblmsg.Text = " Record Successfully Inserted For Period " + TextBox1.Text + " To " + TextBox2.Text;
            }
            con.Close();
        }
        catch (Exception)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

}
