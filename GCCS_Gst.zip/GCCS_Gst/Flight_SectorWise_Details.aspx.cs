using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// Created By Rakhi
/// </summary>

public partial class Flight_SectorWise_Details : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        Search();
    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txtsearch.Text == "")
            {
                //selectQ = "SELECT  ad.Airline_Detail_Id,am.Airline_Name, cm.City_Name, ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged,ad.WarSurcharge_On,cb.Branch_Name, ad.DisBursementCharges,ad.Deal,sm.Status_Name FROM  Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN Company_Branch cb ON ad.Company_Branch_ID = cb.Company_Branch_ID INNER JOIN Status_Master sm ON cb.Status = sm.Status_ID INNER JOIN City_Master cm ON am.Airline_ID = cm.City_ID ";
                selectQ = "select fs.Flight_Sector_ID,fm.Flight_No,asm.Sector_Name from Flight_Sectorwise fs inner join Flight_Master fm on fs.Flight_ID=fm.Flight_ID inner join Airline_Sector_Master asm on fs.Sector_ID=asm.Sector_ID";
            }

            else
            {
                //selectQ = "SELECT  ad.Airline_Detail_Id,am.Airline_Name, cm.City_Name, ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged,ad.WarSurcharge_On,cb.Branch_Name, ad.DisBursementCharges,ad.Deal,sm.Status_Name FROM  Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN Company_Branch cb ON ad.Company_Branch_ID = cb.Company_Branch_ID INNER JOIN Status_Master sm ON cb.Status = sm.Status_ID INNER JOIN City_Master cm ON am.Airline_ID = cm.City_ID and am.Airline_Name like " + "'" + txtsearch.Text + "%'";
                //selectQ = "SELECT am.Airline_Name, cm.City_Name, ad.DisBursementCharges, ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged, ad.WarSurcharge_On, ad.XRayCharge_Charged, ad.XRayCharge_On, ad.AWB_Fees, ad.ACI_Fees, cmp.Company_Name, ad.Deal, sm.Status_Name FROM  Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN Company_Master cmp ON ad.Company_ID = cmp.Company_ID INNER JOIN Status_Master sm ON ad.Status = sm.Status_ID INNER JOIN City_Master cm ON ad.Belongs_To_City = cm.City_ID  and am.Airline_Name like " + "'" + txtsearch.Text + "%'";
                selectQ = "select fs.Flight_Sector_ID,fm.Flight_No,asm.Sector_Name from Flight_Sectorwise fs inner join Flight_Master fm on fs.Flight_ID=fm.Flight_ID inner join Airline_Sector_Master asm on fs.Sector_ID=asm.Sector_ID and fm.Flight_No like " + "'" + txtsearch.Text + "%' ";
            }

            cmd = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Flight_SectorWise_Add.aspx");
    }

  

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Search();
    }
}
