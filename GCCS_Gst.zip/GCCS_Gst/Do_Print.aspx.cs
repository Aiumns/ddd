using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Do_Print : System.Web.UI.Page
{// Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string Import_AWB_ID;
    decimal Stax = 0;
    //****************Updated On 03 May2016: KKCess tax Apply system*****************
    decimal SBcess = 0;
    decimal KKcess = 0;
    decimal mawcharge = 0;
    string table = null;
    decimal cartingcharges = 0;

    string strAirline_name = "", awbno = "", flt_no = "", import_rotation_No = "", arr_flight_date = "", contents = "", from = "", to = "", notify = "", IGMNo = "", pay_amt = "", straddress = "", issue_date = "", recipt_no = "", MawbDo_Chgs = "0", HawbDo_Chgs = "0", no_of_Houses = "", payment_mode = "", flight_date = "", part_pcs = "", HAWBChrg = "0", STAXRATE = "0", SBcessRATE = "0", KKcessRATE = "0", Airportadress = "";
    decimal pcs = 0, frt_chgs = 0, total = 0;
    string OldAwb_ReciptNo = "";
    bool Flag = false;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    string AIrwayBill_No = "";
    string Airline_id = "";
    int city_id = 0;
    string FlightNo = "";
    string CompGstNo = "07";
    string AgentGstNo = "08";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {


            if (Request.QueryString["AWBID"] != null)
            {

            
                DataTable dtcheckAwbexist = dw.GetAllFromQuery("select Import_Awb_No,Payment_Mode,ia.Airline_Detail_Id,ad.Belongs_To_City,iflight.Import_Flight_No from db_owner.Import_Flight_AWB ia INNER JOIN dbo.Airline_Detail ad ON ad.Airline_Detail_ID =ia.Airline_Detail_Id INNER JOIN db_owner.Import_Flights iflight ON ia.Import_Flight_ID = iflight.Import_Flight_ID  where Import_Awb_Id=" + Request.QueryString["AWBID"] + "");
                if (dtcheckAwbexist.Rows[0]["Payment_Mode"].ToString() == "1")
                {
                    //Spacehide1.Visible = false;
                    ////Spacehide2.Visible = false;
                    //Spacehide3.Visible = false;
                    //SpaceHide4.Visible = false;
                }

                Airline_id = dtcheckAwbexist.Rows[0]["Airline_Detail_Id"].ToString();
                FlightNo = dtcheckAwbexist.Rows[0]["Import_Flight_No"].ToString();
                if (Airline_id == "159" || Airline_id == "160")
                {
                    if (Airline_id == "159" && FlightNo == "HY-127")
                    {
                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/uzbekistan.jpg");
                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
                    }
                    else
                    {
                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
                    }
                }

                else if (Airline_id == "158")
                {
                    if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                    {
                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
                    }
                    else
                    {
                        imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/uzbekistan.jpg");
                        imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/Korean-Air.gif");
                    }
                }
                else if (Airline_id == "150" || Airline_id == "153")
                {

                    imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/THY_Logo_2011-(1).jpg");
                    imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/THY_Logo_2011-(1).jpg");
                }

                else if (Airline_id == "148")
                {

                    imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/malaysia-airlines.jpg");
                    imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/malaysia-airlines.jpg");

                }
                else if (Airline_id == "147" )
                {
                    trremarks.Visible = true;
                    lblheadairlinename.Visible = false;
                    lblairlinename.Visible = false;
                    imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/mascar_logo.gif");
                    imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/mascar_logo.gif");

                }



                else if (Airline_id == "169" || Airline_id == "169")
                {

                    imgReciptairlogo.ImageUrl = Page.ResolveUrl("./images/MegaMaldives.gif");
                    imgDeliveryAirlogo.ImageUrl = Page.ResolveUrl("./images/MegaMaldives.gif");
                }



                city_id = Convert.ToInt32(dtcheckAwbexist.Rows[0]["Belongs_To_City"].ToString());
                if (city_id == 6)
                {
                    trdel.Visible = true;
                    trmum.Visible = false;
                    trchennai.Visible = false;
                }
                else if (city_id == 18)
                {
                    trdel.Visible = false;
                    trmum.Visible = true;
                    trchennai.Visible = false;
                }
                else
                {
                    trdel.Visible = false;
                    trmum.Visible = false;
                    trchennai.Visible = true;
                }


                AIrwayBill_No = dtcheckAwbexist.Rows[0]["Import_Awb_No"].ToString();
                DataTable dtawbexist = dw.GetAllFromQuery("select Import_Awb_No from Import_Flight_Awb where Import_Awb_No='" + AIrwayBill_No + "' and Import_Awb_Id=" + Request.QueryString["AWBID"] + " and shipment_type='F' and Part_shipment_type='Y' ");

                //*******************CASE OF PART SHIPMENT********************

                if (Request.QueryString["Mode"] != null)
                    Flag = true;

                if (dtawbexist.Rows.Count > 0 && !Flag)
                {
                    DataTable dtDo_GenerateStatus_check = dw.GetAllFromQuery("select Import_Awb_ID,Import_Awb_No,D0_Generate_Status from Import_Flight_Awb where Import_Awb_No='" + AIrwayBill_No + "' and D0_Generate_Status='YES'");



                    if (dtDo_GenerateStatus_check.Rows.Count > 0)
                    {
                        lblAddress1.Visible = true;
                        lblAddress.Visible = true;
                        AmtDescp.Visible = false;

                        Tr1.Visible = false;
                        Tr2.Visible = false;
                        TotalLine.Visible = false;
                        TotalSpace.Visible = false;

                        Space3.Visible = false;
                        // Space4.Visible = false;

                        Space6.Visible = true;
                        PartShipmentCase.Visible = true;


                        Import_AWB_ID = dtDo_GenerateStatus_check.Rows[0]["Import_Awb_ID"].ToString();
                        DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo, IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.recipt_no,IFA.Bank_Name,IFA.Cheque_No,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Request.QueryString["AWBID"].ToString() + "'");


                        //**********************MAWB,HAWB,STAXRATE,SBCess,RECIEVDAMOUNT:PICKED FROM IMPORTFLIGHTAWB_TRANS******//

                        //****************Updated On 03 May2016: KKCess tax Apply system*****************

                        DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + Request.QueryString["AWBID"].ToString() + "'");
                        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                        {
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                            {
                                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                            {
                                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                            {
                                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                        }
                        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                        {
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                            {
                                MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
                            {
                                HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                            {
                                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                            {
                                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                            {
                                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                        }

                        no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();
                        recipt_no = dt.Rows[0]["recipt_no"].ToString();
                        lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
                        string StaxNo = "";

                        issue_date = dt.Rows[0]["issue_date"].ToString();
                        straddress = dt.Rows[0]["office_address"].ToString();
                        Airportadress = dt.Rows[0]["Airport_Address"].ToString();

                        payment_mode = dt.Rows[0]["payment_mode"].ToString();
                        flight_date = dt.Rows[0]["import_flight_Date"].ToString();
                        //lblFltDateAirline.Text = flight_date;
                        DateTime fltdate2 = DateTime.Parse(flight_date);
                        lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");

                        ////lblFlightDate.Text = flight_date;
                        DateTime fltdate = DateTime.Parse(flight_date);
                        lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");


                        part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
                        pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
                        if (part_pcs == "" || part_pcs == "0")
                        {
                            lblPartPsc.Visible = false;
                            lblPartPsc.Text = "";
                            lblpppsc.Visible = false;
                            lblpppsc.Text = "";
                        }
                        else
                        {


                            lblPartPsc.Visible = true; ;
                            lblPartPsc.Text = part_pcs;
                            lblpppsc.Visible = true;
                            lblpppsc.Text = "/";
                        }
                        //*****************Added On 1 feb 2011********************

                        if (dt.Rows[0]["freight_type"].ToString() == "PP")
                        {
                            lblBeingFrtchrgs.Text = "PP";
                        }

                        else if (dt.Rows[0]["freight_type"].ToString() == "CC")
                        {
                            string MawbChrs = "";
                            string HawbChrs = "";
                            if (MawbDo_Chgs == "")
                            {
                                MawbChrs = "0";
                            }
                            else
                            {
                                MawbChrs = MawbDo_Chgs;
                            }
                            if (HawbDo_Chgs == "")
                            {
                                HawbChrs = "0";
                            }
                            else
                            {
                                HawbChrs = HawbDo_Chgs;
                            }
                            lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();



                            lblDOChrgs.Text = Convert.ToString(total);
                        }

                        //*****************END********************

                        //******************Old AWb Details**************************

                        DataTable dtOldAwb = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");



                        if (dtOldAwb.Rows.Count > 0 || dtOldAwb != null)
                        {

                            OldAwb_ReciptNo = dtOldAwb.Rows[0]["recipt_no"].ToString();
                        }

                        //********************************END OF OLD AWB Details***************

                        strAirline_name = dt.Rows[0]["Airline_Name"].ToString();

                        if (strAirline_name == "MALAYSIAN AIRLINES")
                        {
                            strAirline_name = "MALAYSIA AIRLINES";
                        }
                        awbno = dt.Rows[0]["Import_Awb_No"].ToString();
                        flt_no = dt.Rows[0]["import_flight_no"].ToString();
                        if (Airline_id == "158")
                        {
                            if (FlightNo != "KE-9395" || FlightNo != "KE-9307")
                            {
                                if (FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                                    flt_no = flt_no.Replace("HY", "KE");
                                else
                                    flt_no = flt_no.Replace("KE", "HY");
                            }
                        }
                        arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();
                        lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
                        contents = dt.Rows[0]["commodity"].ToString();
                        if (contents == "Console")
                        {
                            contents = "Consol";
                        }

                        import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
                        to = dt.Rows[0]["Consignee_Name"].ToString();
                        if (to == "")
                        {
                            to = dt.Rows[0]["Agent_Name"].ToString();
                        }
                        
                        if (Airline_id == "147" || Airline_id == "153")
                        {
                            to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
                        }
                        if (dt.Rows[0]["GstNo"].ToString() != "")
                            to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b>";
                        from = dt.Rows[0]["Shipper_Name"].ToString();
                        notify = dt.Rows[0]["Notify"].ToString();
                        if (notify == "")
                        {
                            lblNotifyDo.Visible = false;
                            lblNotifyDovalue.Visible = false;
                            lblNotify.Visible = false; ;
                            lblNotifyValue.Visible = false;
                            lblNotifyValue.Text = "";

                        }
                        else
                        {
                            lblNotifyDo.Visible = true;
                            lblNotifyDovalue.Visible = true;
                            lblNotifyDovalue.Text = notify;
                            lblNotify.Visible = true;
                            lblNotifyValue.Visible = true;
                            lblNotifyValue.Text = notify;
                        }
                        IGMNo = dt.Rows[0]["IGM_No"].ToString();
                        string house = dt.Rows[0]["No_of_Houses"].ToString();
                        decimal housevalue = System.Math.Round(decimal.Parse(house), 0);

                        decimal d = housevalue * decimal.Parse(HawbDo_Chgs);

                        //************Added on 1 feb 2011 Added freight Chrages for CC Case****************

                        decimal DOFrtChrgs = 0;
                        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                        {
                            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
                            {
                                DOFrtChrgs = 0;
                            }
                            else
                            {
                                DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
                            }

                            //TrFreightChrgsCC.Visible = true;
                            TrFreightChrgsCC.Visible = false;
                            d = d + DOFrtChrgs;
                        }

                        //************END**********************************************
                        string addrs = "";

                        if (Airline_id == "158")
                        {
                            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                            {
                                lblAddress.Text = straddress.ToString();
                                lblAddress1.Text = straddress.ToString();
                            }
                            else
                            {
                                lblAddress.Text = straddress.ToString();
                                lblAddress1.Text = Airportadress.ToString();
                            }
                        }
                        else
                        {
                            lblAddress.Text = straddress.ToString();
                            lblAddress1.Text = straddress.ToString();
                        }


                        if (lblAddress.Text.Contains("GST NO"))
                        {
                            int i = lblAddress.Text.IndexOf(",GST NO");
                            StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                            addrs = lblAddress.Text.Replace(StaxNo, ".");
                            addrs = addrs.Replace(",.", ".");
                            //lblAddress1.Text = addrs;
                            lblAddress.Text = addrs;
                        }
                        else
                        {
                            // lblAddress1.Text = straddress.ToString();
                            lblAddress.Text = straddress.ToString();
                        }


                        if (lblAddress1.Text.Contains("GST NO"))
                        {
                            int i = lblAddress1.Text.IndexOf(",GST NO");
                            StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
                            addrs = lblAddress1.Text.Replace(StaxNo, ".");
                            addrs = addrs.Replace(",.", ".");
                            lblAddress1.Text = addrs;
                            //lblAddress.Text = addrs;
                        }
                        else
                        {
                            if (Airline_id == "158")
                            {
                                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                                    lblAddress1.Text = straddress.ToString();
                                else
                                    lblAddress1.Text = Airportadress.ToString();

                            }
                            else
                                lblAddress1.Text = straddress.ToString();
                        }

                        if (lblAddress1.Text.Contains("Tel"))
                            lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
                        if (lblAddress1.Text.Contains("TEL"))
                            lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
                        if (lblAddress.Text.Contains("Tel"))
                            lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
                        if (lblAddress.Text.Contains("TEL"))
                            lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");

                        if (lblAddress1.Text.Contains("Fax"))
                            lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
                        if (lblAddress1.Text.Contains("FAX"))
                            lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
                        if (lblAddress.Text.Contains("Fax"))
                            lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
                        if (lblAddress.Text.Contains("FAX"))
                            lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");








                        //lblAddress.Text = straddress.ToString();


                        //if (lblAddress.Text.Contains("S.TAX NO"))
                        //{
                        //    int i = lblAddress.Text.IndexOf(",S.TAX NO");
                        //    StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                        //    addrs = lblAddress.Text.Replace(StaxNo, ".");
                        //    addrs = addrs.Replace(",.", ".");
                        //    lblAddress1.Text = addrs;
                        //    lblAddress.Text = addrs;
                        //}
                        //else
                        //{
                        //    lblAddress1.Text = straddress.ToString();
                        //    lblAddress.Text = straddress.ToString();
                        //}


                        if (payment_mode == "1")
                        {
                            lblCheque.Visible = false;
                            lblCash.Text = "in Cash";
                        }
                        else if (payment_mode == "2")
                        {
                            lblCash.Visible = false;
                            lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
                        }



                        if (strAirline_name == "MALAYSIA AIRLINES")
                        {
                            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo, " + StaxNo;
                        }

                        else if (strAirline_name == "TURKISH AIRLINES")
                        {
                            lblAirlineStax.Text = "Ascent Air Pvt Ltd, " + StaxNo;
                        }

                        else if (strAirline_name == "AIR CHINA")
                        {
                            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd, " + StaxNo;
                        }
                        else if (strAirline_name == "KOREAN AIRLINES")
                        {
                            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO, " + StaxNo;
                        }
                        else if (strAirline_name == "MEGA MALDIVES AIRLINES")
                        {
                            lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD, " + StaxNo;
                        }
                        else
                        {
                            lblAirlineStax.Text = "Pace Express, " + StaxNo;
                        }
                        lblSno.Text = recipt_no.ToString();
                        lblSnomum.Text = recipt_no.ToString();

                        lblSnochennai.Text = recipt_no.ToString();
                        lblSno2.Text = recipt_no.ToString();
                        lblName.Text = to.ToString();
                        lblName2.Text = to.ToString();
                        Sno.Text = recipt_no.ToString();
                        lblairlinename.Text = strAirline_name.ToString();


                        if (Airline_id == "158")
                        {
                            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                            {
                                lblAirlineNme.Text = "KOREAN AIR";
                                lblheadairlinename.Text = "KOREAN AIR";
                            }
                            else
                            {

                                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                            }
                        }
                        else if (Airline_id == "159")
                        {
                            if (FlightNo == "HY-127")
                            {
                                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                                lblairlinename.Text = "UZBEKISTAN AIRWAYS";
                            }
                            else
                            {
                                lblAirlineNme.Text = "KOREAN AIR";
                                lblheadairlinename.Text = "KOREAN AIR";
                                lblairlinename.Text = "KOREAN AIR";
                            }
                        }
                        else
                        {
                            lblAirlineNme.Text = strAirline_name.ToString();
                            lblheadairlinename.Text = strAirline_name.ToString();
                        }
                        lblAwbno.Text = awbno.ToString();
                        lblPcs.Text = pcs.ToString();
                        lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");

                        lblcommdy.Text = contents.ToString();
                        lblFlightno.Text = flt_no.ToString();


                        lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();



                        lbligmnr.Text = IGMNo.ToString();
                        lblAwb2.Text = awbno.ToString();
                        lbldate2.Text = issue_date.ToString();
                        lblFlitno2.Text = flt_no.ToString();
                        lblAirlinemame3.Text = strAirline_name.ToString();
                        if (Airline_id == "147")
                        {
                            lblch.Visible = true;
                            lblchwt.Visible = true;
                            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                            lblAirlinemame3.Text = "MASkargo";
                            lblAirlineNme.Text = "MASkargo";
                        }
                        else if (Airline_id == "153")
                        {
                            lblch.Visible = true;
                            lblchwt.Visible = true;
                            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                            ////lblAirlinemame3.Text = "MASkargo";
                            ////lblAirlineNme.Text = "MASkargo";
                        }
                        if (Airline_id == "159")
                        {
                            lblAirlinemame3.Text = "KOREAN AIR";

                        }

                        //******************Added On 1 feb 2011*********************
                        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                        {
                            //TrFreightChrgsCC.Visible = true;
                            TrFreightChrgsCC.Visible = false;
                            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "")
                            {
                                lblDOFrtChr.Text = "0";
                            }
                            else
                            {
                                lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                            }


                        }
                        //****************************End*********************************************

                        lblpartshipmentCase.Text = lblpartshipmentCase.Text + dtOldAwb.Rows[0]["recipt_no"].ToString();

                        //*******Updating Import_Flight_Awb Table seting all Amount Zero for the Awb No******************

                        con = new SqlConnection(strCon);
                        con.Open();
                        com = new SqlCommand("update Import_Flight_AWB set DO_stax_rate=0,Tds_Cut_By_Agent=0,DO_Tds_Cut_By_Agent=0,DO_Amount_Received=0,DO_Cheque_Amount=0,CC_Cheque_Amount=0,Total_Collection_CC=0,freight_chgs=0 where import_awb_id='" + Request.QueryString["AWBID"] + "'", con);
                        com.ExecuteNonQuery();
                        con.Close();
                        //***********************End oF Updating*************************************


                        //*******Updating ImportFlightAwb_Trans Table seting all Amount Zero for the Awb No******************
                        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                        {
                            con = new SqlConnection(strCon);
                            con.Open();
                            com = new SqlCommand("update ImportFlightAWB_trans set ChargeRate=0,ChargeAmount=0 where importawbid='" + Request.QueryString["AWBID"] + "'", con);
                            com.ExecuteNonQuery();
                            con.Close();

                        }



                        //***********************End oF Updating*************************************


                    }
                }

                else
                {
                    DataTable DtDoPrint = dw.GetAllFromQuery("select * from Import_Flight_Awb where Import_awb_Id=" + Request.QueryString["AWBID"] + " and D0_Generate_Status='YES'");

                    string Awb_NoDoprint = AIrwayBill_No;
                    DataTable dtawbexistDoPrint = dw.GetAllFromQuery("select Import_Awb_No from Import_Flight_Awb where Import_Awb_No='" + Awb_NoDoprint + "'AND Import_awb_Id=" + Request.QueryString["AWBID"] + " and  shipment_type='F' and Part_shipment_type='Y' ");
                    if (DtDoPrint.Rows.Count > 0)
                    {
                        Display();
                    }
                    else if (dtawbexistDoPrint.Rows.Count > 0)
                    {
                        DisplayRepeatAwb();
                    }
                    else
                    {
                        lblAddress1.Visible = true;
                        lblAddress.Visible = true;

                        Import_AWB_ID = Convert.ToString(Request.QueryString["AWBID"]);
                        DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,IFA.PCS,IFA.Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");


                        //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  

                        DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + Request.QueryString["AWBID"].ToString() + "'");
                        string staxamount = "";
                        string SbCessamount = "";
                        //****************Updated On 03 May2016: KKCess tax Apply system*****************
                        string KKCessamount = "";
                        table = "<table border=0 width=400px align=center cellspacing=0>";
                        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                        {
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                            {
                                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                                staxamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                            {
                                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                                SbCessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                            }
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                            {
                                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                                KKCessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                            }
                        }
                        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                        {
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                            {
                                MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                                mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
                            {
                                HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                            {
                                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                                Stax = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                                if (dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "1")
                                {
                                    staxdetail.Text = "(Service Tax EXEMPTED)";
                                }
                                else
                                {
                                    staxdetail.Text = "(INCLUSIVE OF SERVICE TAX)only";
                                }
                                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                                {
                                    continue;
                                }
                                //continue;
                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                            {
                                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                                SBcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                                {
                                    continue;
                                }
                            }
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                            {
                                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                                KKcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                                {
                                    continue;
                                }
                            }

                            decimal Allvalue = 0;

                            //************************ImportChargesHead: DP_FEE,Cartage,CommunicationFee concept****
                            if (dtImportAwbTrans.Rows.Count > 0)
                            {
                                if (Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]) > 0)
                                {
                                    //***************************Creating Charges*****************************
                                    if (Airline_id == "159")
                                    {


                                        if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                                        {
                                            if (staxamount != "0.00")
                                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                                                ////mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                                                mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));

                                            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + mawcharge + "' >" + mawcharge.ToString("#,##0.00") + "</label>";
                                            table += "</td></tr>";

                                        }
                                        else
                                        {


                                            ////table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                            ////table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                                            ////table += "</td></tr>";

                                            #region Gst Applicable
                                            string charge = "GST";
                                            string ChargeName = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
                                            if (ChargeName == "StaxRate")
                                            {
                                                charge = "CGST";
                                            }
                                            else if (ChargeName == "SBCess")
                                            {
                                                charge = "SGST";
                                            }
                                            else if (ChargeName == "KKCess")
                                            {
                                                charge = "IGST";
                                            }
                                            else
                                            {
                                                charge = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
                                            }
                                            if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                                            {
                                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + charge + "'>" + charge + " Chrgs:</label>";

                                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                                                table += "</td></tr>";
                                            }
                                            else
                                            {
                                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                                                table += "</td></tr>";
                                            }

                                            #endregion end of Gst Applicable
                                        }


                                    }
                                    else
                                    {
                                        table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                        table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";

                                        table += "</td></tr>";
                                    }
                                    //***************************End******************************************
                                    if (Airline_id == "159")
                                    {
                                        if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() != "StaxRate")
                                            total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                                    }
                                    else
                                        total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);



                                }
                                else if (dt.Rows[0]["Shipment_Type"].ToString() == "F")
                                {
                                    table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                    table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + "0.00" + "' >" + "0.00" + "</label>";

                                    table += "</td></tr>";
                                    //***************************End******************************************

                                    total += Convert.ToDecimal("0.00");
                                }

                                //}
                                //*****************************END*****************************************************               


                            }



                        }
                        if (dt.Rows[0]["Tds_Cut_By_Agent"].ToString() != "0.00")
                        {
                            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label>TDS :</label>";
                            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + "-" + dt.Rows[0]["Tds_Cut_By_Agent"].ToString() + "</label></td></tr>";
                        }
                        table += "</table>";
                        lblTabel.Text = table;
                        no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();
                        recipt_no = dt.Rows[0]["recipt_no"].ToString();
                        lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
                        decimal CC_Cheque_Amount = Convert.ToDecimal(dt.Rows[0]["CC_Cheque_Amount"]);
                        if (Airline_id == "147" || Airline_id == "153")
                        {
                            mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[0]["ChargeAmount"]);
                        }

                        //****************Updated On 03 May2016: KKCess tax Apply system*****************
                        decimal SBCessAmt = 0;
                        decimal KKCessAmt = 0;
                        string strInclusive = string.Empty;
                        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                        {
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            ////decimal SBCessAmt = 0;
                            ////decimal KKCessAmt = 0;

                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                            {
                                SBCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                            }
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                            {
                                KKCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                            }

                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "Carting")
                            {
                                cartingcharges = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                            }
                            else if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                            {
                                mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                            }


                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate" && dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "0")
                            {
                                ////string strInclusive = string.Empty;
                                strInclusive += "<table border=0 width=400px align=center cellspacing=0>";

                                decimal STaxAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt;
                                ViewState["STaxAmt"] = STaxAmt;

                                //////if (Airline_id == "159")
                                //////{
                                //////    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));
                                //////}

                                ////if (Airline_id == "147" || Airline_id == "153")
                                ////{
                                ////    strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                ////    strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + mawcharge + "</label></td></tr>";
                                ////    strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                ////    strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                                ////}
                                ////else if (Airline_id == "159")
                                ////{
                                ////    strInclusive += "<tr style=\"display:none\" ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                ////    strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                ////    strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                ////    strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                                ////}
                                ////else
                                ////{
                                ////    strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                ////    strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                ////    strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                ////    strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                                ////}



                                ////lblInclusive.Text = strInclusive;
                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                            {
                                // string strInclusive = string.Empty;
                                ////if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                                ////{
                                ////    ViewState["STaxAmt"] = "0";
                                ////}


                                decimal STaxAmt = 0;
                                if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                                {
                                    ////ViewState["STaxAmt"] = "0";
                                    ViewState["STaxAmt"] = STaxAmt;
                                }
                                else
                                {

                                    STaxAmt = (Decimal)ViewState["STaxAmt"];
                                }
                                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt;

                                if (Airline_id == "1591")
                                {
                                    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                                    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                                    //DOCharge = Convert.ToDecimal(TD);

                                }

                                if (Airline_id == "159")
                                {
                                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr></table>";

                                }
                                else if (Airline_id == "1591")
                                {
                                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                                }
                                else
                                {
                                    //////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                    //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                    //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                    //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                    //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                                    //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";

                                }


                            }
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                            {
                                // string strInclusive = string.Empty;
                                ////if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                                ////{
                                ////    ViewState["STaxAmt"] = "0";
                                ////}


                                decimal STaxAmt = 0;
                                if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                                {
                                    ////ViewState["STaxAmt"] = "0";
                                    ViewState["STaxAmt"] = STaxAmt;
                                }
                                else
                                {

                                    STaxAmt = (Decimal)ViewState["STaxAmt"];
                                }
                                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt - KKCessAmt;

                                if (Airline_id == "1591")
                                {
                                    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                                    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                                    //DOCharge = Convert.ToDecimal(TD);

                                }

                                if (Airline_id == "159")
                                {
                                    ////////////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                    ////////////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                    ////////////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                    ////////////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                    ////////////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                                    ////////////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                                    ////////////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                                    ////////////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";

                                    
                                    
                                    
                                    
                                    
                                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr></table>";

                                }
                                else if (Airline_id == "1591")
                                {
                                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";
                                    if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                                    {
                                         strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                                    }
                                    
                                    else
                                    {
                                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                                    }


                                }
                                else
                                {
                                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";

                                    if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                                    {
                                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                                    }

                                    else
                                    {
                                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                                    }

                                }


                            }
                            lblInclusive.Text = strInclusive;
                        }

                        string StaxNo = "";

                        issue_date = dt.Rows[0]["issue_date"].ToString();
                        straddress = dt.Rows[0]["office_address"].ToString();
                        Airportadress = dt.Rows[0]["Airport_Address"].ToString();
                        payment_mode = dt.Rows[0]["payment_mode"].ToString();
                        flight_date = dt.Rows[0]["import_flight_Date"].ToString();
                        part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
                        decimal ServiceTax = 0;

                        ServiceTax = decimal.Parse(STAXRATE);

                        if (part_pcs == "" || part_pcs == "0")
                        {
                            lblPartPsc.Visible = false;
                            lblPartPsc.Text = "";
                            lblpppsc.Visible = false;
                            lblpppsc.Text = "";
                        }
                        else
                        {

                            lblPartPsc.Visible = true; ;
                            lblPartPsc.Text = part_pcs;
                            lblpppsc.Visible = true;
                            lblpppsc.Text = "/";
                        }




                        //*****************Added On 1 feb 2011********************

                        if (dt.Rows[0]["freight_type"].ToString() == "PP")
                        {
                            lblBeingFrtchrgs.Text = "PP";
                        }

                        else if (dt.Rows[0]["freight_type"].ToString() == "CC")
                        {
                            string MawbChrs = "";
                            string HawbChrs = "";
                            if (MawbDo_Chgs == "")
                            {
                                MawbChrs = "0";
                            }
                            else
                            {
                                MawbChrs = MawbDo_Chgs;
                            }
                            if (HawbDo_Chgs == "")
                            {
                                HawbChrs = "0";
                            }
                            else
                            {
                                HawbChrs = HawbDo_Chgs;
                            }
                            lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();

                            lblDOChrgs.Text = Convert.ToString(total);
                        }

                        //*****************END********************


                        strAirline_name = dt.Rows[0]["Airline_Name"].ToString();

                        if (strAirline_name == "MALAYSIAN AIRLINES")
                        {
                            strAirline_name = "MALAYSIA AIRLINES";
                        }
                        awbno = dt.Rows[0]["Import_Awb_No"].ToString();
                        flt_no = dt.Rows[0]["import_flight_no"].ToString();
                        if (Airline_id == "158")
                        {
                            if (FlightNo != "KE-9395")
                            {
                                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                                    if (FlightNo == "KE-9307" || FlightNo == "KE-9665")
                                    flt_no = flt_no.Replace("HY", "KE");
                                else
                                    flt_no = flt_no.Replace("KE", "HY");
                            }
                        }
                        arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();

                        contents = dt.Rows[0]["commodity"].ToString();
                        if (contents == "Console")
                        {
                            contents = "Consol";
                        }
                        pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
                        import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
                        to = dt.Rows[0]["Consignee_Name"].ToString();
                        if (to == "")
                        {
                            to = dt.Rows[0]["Agent_Name"].ToString();
                        }
                        if (Airline_id == "147" || Airline_id == "153")
                        {
                            to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
                        }
                        if (dt.Rows[0]["GstNo"].ToString() != "")
                            to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b>";
                        from = dt.Rows[0]["Shipper_Name"].ToString();
                        notify = dt.Rows[0]["Notify"].ToString();
                        if (notify == "")
                        {
                            lblNotifyDo.Visible = false;
                            lblNotifyDovalue.Visible = false;
                            lblNotify.Visible = false; ;
                            lblNotifyValue.Visible = false;
                            lblNotifyValue.Text = "";

                        }
                        else
                        {
                            lblNotifyDo.Visible = true;
                            lblNotifyDovalue.Visible = true;
                            lblNotifyDovalue.Text = notify;
                            lblNotify.Visible = true;
                            lblNotifyValue.Visible = true;
                            lblNotifyValue.Text = notify;
                        }
                        IGMNo = dt.Rows[0]["IGM_No"].ToString();
                        string house = dt.Rows[0]["No_of_Houses"].ToString();
                        decimal housevalue = System.Math.Round(decimal.Parse(house), 0);
                        decimal d = housevalue * decimal.Parse(HawbDo_Chgs);
                        //************Added on 1 feb 2011 Added freight Chrages for CC Case****************

                        decimal DOFrtChrgs = 0;
                        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                        {
                            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
                            {
                                DOFrtChrgs = 0;
                            }
                            else
                            {
                                DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
                            }
                            TrFreightChrgsCC.Visible = true;

                            d = d + DOFrtChrgs;
                        }

                        //************END**********************************************
                        string addrs = "";
                        if (Airline_id == "158")
                        {
                            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                            {
                                lblAddress.Text = straddress.ToString();
                                lblAddress1.Text = straddress.ToString();
                            }
                            else
                            {
                                lblAddress.Text = straddress.ToString();
                                lblAddress1.Text = Airportadress.ToString();
                            }


                        }
                        else
                        {
                            lblAddress.Text = straddress.ToString();
                            lblAddress1.Text = straddress.ToString();
                        }


                        if (lblAddress.Text.Contains("GST NO"))
                        {
                            int i = lblAddress.Text.IndexOf(",GST NO");
                            StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                            addrs = lblAddress.Text.Replace(StaxNo, ".");
                            addrs = addrs.Replace(",.", ".");
                            //lblAddress1.Text = addrs;
                            lblAddress.Text = addrs;
                        }
                        else
                        {
                            // lblAddress1.Text = straddress.ToString();
                            lblAddress.Text = straddress.ToString();
                        }


                        if (lblAddress1.Text.Contains("GST NO"))
                        {
                            int i = lblAddress1.Text.IndexOf(",GST NO");
                            StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
                            addrs = lblAddress1.Text.Replace(StaxNo, ".");
                            addrs = addrs.Replace(",.", ".");
                            lblAddress1.Text = addrs;
                            //lblAddress.Text = addrs;
                        }
                        else
                        {
                            if (Airline_id == "158")
                                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                                    lblAddress1.Text = straddress.ToString();
                                else
                                    lblAddress1.Text = Airportadress.ToString();
                            else
                                lblAddress1.Text = straddress.ToString();
                        }
                        if (lblAddress1.Text.Contains("Tel"))
                            lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
                        if (lblAddress1.Text.Contains("TEL"))
                            lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
                        if (lblAddress.Text.Contains("Tel"))
                            lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
                        if (lblAddress.Text.Contains("TEL"))
                            lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
                        if (lblAddress1.Text.Contains("Fax"))
                            lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
                        if (lblAddress1.Text.Contains("FAX"))
                            lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
                        if (lblAddress.Text.Contains("Fax"))
                            lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
                        if (lblAddress.Text.Contains("FAX"))
                            lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");
                        //lblAddress.Text = straddress.ToString();
                        //if (lblAddress.Text.Contains("S.TAX NO"))
                        //{
                        //    int i = lblAddress.Text.IndexOf(",S.TAX NO");
                        //    StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                        //    addrs = lblAddress.Text.Replace(StaxNo, ".");
                        //    addrs = addrs.Replace(",.", ".");
                        //    lblAddress1.Text = addrs;
                        //    lblAddress.Text = addrs;
                        //}
                        //else
                        //{
                        //    lblAddress1.Text = straddress.ToString();
                        //    lblAddress.Text = straddress.ToString();
                        //}
                        if (payment_mode == "1")
                        {
                            lblCheque.Visible = false;
                            lblCash.Text = "in Cash";
                        }
                        else if (payment_mode == "2")
                        {
                            lblCash.Visible = false;
                            lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
                        }



                        if (strAirline_name == "MALAYSIA AIRLINES")
                        {
                            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo, " + StaxNo;
                        }

                        else if (strAirline_name == "TURKISH AIRLINES")
                        {
                            lblAirlineStax.Text = "Ascent Air Pvt Ltd, " + StaxNo;
                        }

                        else if (strAirline_name == "AIR CHINA")
                        {
                            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd, " + StaxNo;
                        }
                        else if (strAirline_name == "KOREAN AIRLINES")
                        {

                            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO, " + StaxNo;
                        }
                        else if (strAirline_name == "MEGA MALDIVES AIRLINES")
                        {
                            lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD, " + StaxNo;
                        }

                        else
                        {
                            lblAirlineStax.Text = "Pace Express, " + StaxNo;
                        }

                        lblairlinename.Text = strAirline_name.ToString();

                        if (Airline_id == "158")
                        {
                            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                            {
                                lblAirlineNme.Text = "KOREAN AIR";
                                lblheadairlinename.Text = "KOREAN AIR";
                            }
                            else
                            {
                                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                            }
                        }
                        else if (Airline_id == "159")
                        {
                            if (FlightNo == "HY-127")
                            {
                                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                                lblairlinename.Text = "UZBEKISTAN AIRWAYS";
                            }
                            else
                            {
                                lblAirlineNme.Text = "KOREAN AIR";
                                lblheadairlinename.Text = "KOREAN AIR";
                                lblairlinename.Text = "KOREAN AIR";
                            }
                        }
                        else
                        {
                            lblAirlineNme.Text = strAirline_name.ToString();
                            lblheadairlinename.Text = strAirline_name.ToString();
                        }
                        lblAwbno.Text = awbno.ToString();
                        lblPcs.Text = pcs.ToString();
                        lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");
                        lblcommdy.Text = contents.ToString();
                        lblFlightno.Text = flt_no.ToString();
                        lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();


                        lbligmnr.Text = IGMNo.ToString();
                        lblAwb2.Text = awbno.ToString();
                        lbldate2.Text = issue_date.ToString();
                        lblFlitno2.Text = flt_no.ToString();
                        lblAirlinemame3.Text = strAirline_name.ToString();

                        if (Airline_id == "147")
                        {
                            lblch.Visible = true;
                            lblchwt.Visible = true;
                            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                            lblAirlinemame3.Text = "MASkargo";
                            lblAirlineNme.Text = "MASkargo";
                        }

                        else if (Airline_id == "153")
                        {
                            lblch.Visible = true;
                            lblchwt.Visible = true;
                            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
                            ////lblAirlinemame3.Text = "MASkargo";
                            ////lblAirlineNme.Text = "MASkargo";
                        }
                        if (Airline_id == "159")
                        {
                            lblAirlinemame3.Text = "KOREAN AIR";

                        }

                        //******************Added On 1 feb 2011*********************
                        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                        {
                            TrFreightChrgsCC.Visible = true;
                            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0.00")
                            {
                                lblDOFrtChr.Text = "0";
                                TrFreightChrgsCC.Visible = false;
                            }
                            else
                            {
                                TrFreightChrgsCC.Visible = true;
                                lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                                total += Convert.ToDecimal(dt.Rows[0]["Total_Collection_CC"]);
                            }


                        }
                        //****************************End*********************************************
                        decimal _Amount_Received = 0;
                        decimal _Amount_ReceivedSBCess = 0;
                        decimal _Amount_ReceivedKKCess = 0;
                        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                        {

                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                            {
                                _Amount_Received = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());

                            }
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                            {
                                _Amount_ReceivedSBCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());

                            }
                            //****************Updated On 03 May2016: KKCess tax Apply system*****************
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                            {
                                _Amount_ReceivedKKCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());

                            }
                        }
                        decimal _TDSCutByAgent = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());

                        decimal f = d + Convert.ToDecimal(MawbDo_Chgs);

                        decimal _Amount = 0;
                        _Amount = Convert.ToInt64(f);

                        string TD_S = "";
                        string TD_S1 = "";
                        string Total_ = "";

                        if (Airline_id == "159")
                        {
                            if (_Amount_Received != 0)
                            {
                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                                ////decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                                decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));

                                total = total - mawcharge + _Amount_Received + charge;
                            }


                        }

                        if (_TDSCutByAgent > 0 || ServiceTax > 0)
                        {
                            if (_TDSCutByAgent > 0)
                            {

                                string TD = Convert.ToString(Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
                                TD_S = Convert.ToDecimal(TD).ToString("#,##0.00");

                                string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
                                decimal AM = 0;
                                AM = decimal.Parse(A);
                                Total_ = Convert.ToDecimal(A).ToString("#,##0.00");

                                lblfreight.Text = Total_;
                                _Amount = decimal.Parse(lblfreight.Text);
                            }
                            //****************** Service Tax Logic on 16 Aug 2010 *****************
                            else
                            {
                                lblfreight.Text = total.ToString();
                                _Amount = decimal.Parse(lblfreight.Text);
                            }
                        }
                        else
                        {
                            string _F = "";
                            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
                            {
                                _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue) + decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString()));
                            }
                            else
                            {
                                _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue));
                            }
                            lblfreight.Text = Convert.ToDecimal(_F).ToString("#,##0.00");
                            //_Amount = f;
                            _Amount = decimal.Parse(lblfreight.Text);
                        }

                        Label1.Text = lblfreight.Text;
                        lblSno.Text = recipt_no.ToString();
                        lblSnomum.Text = recipt_no.ToString();
                        lblSnochennai.Text = recipt_no.ToString();
                        lblSno2.Text = recipt_no.ToString();
                        lblName.Text = to.ToString();
                        lblName2.Text = to.ToString();
                        Sno.Text = recipt_no.ToString();
                        string englishTranslation = "";
                        string englishTranslationDecimalPart = "";
                        //string englishTranslation = changeNumericToWords(Convert.ToDouble(f));
                        //********** Function Translation of Number figure TO Words******************
                        string Amt = _Amount.ToString();
                        string AmtDecimal = "";
                        string AmountCombined = "";



                        //***** Shipment Type is FOC Case**********//
                        if (dt.Rows[0]["shipment_type"].ToString() == "F")
                        {
                            _Amount = 0;
                            lblfreight.Text = "0.00";
                            lblAmount.Text = "Zero";
                            englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));

                        }
                        else
                        {
                            englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
                            lblAmount.Text = englishTranslation;
                        }

                        //lblFlightDate.Text = flight_date.ToString();
                        DateTime fltdate = DateTime.Parse(flight_date);
                        lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");

                        // lblFltDateAirline.Text = flight_date.ToString();
                        DateTime fltdate2 = DateTime.Parse(flight_date);
                        lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");

                        //*******************Updating DO_GenerateStatus_Ist_Time On 26 Aug 2010******************

                        con = new SqlConnection(strCon);
                        con.Open();
                        com = new SqlCommand("update Import_Flight_AWB set D0_Generate_Status='YES' where import_awb_id='" + Request.QueryString["AWBID"] + "'", con);
                        com.ExecuteNonQuery();
                        con.Close();
                        //***********************End oF DO_Generate_Status*************************************
                    }
                }
            }
        }
    }
    public string IntegerToWords(long inputNum)
    {
        int dig1, dig2, dig3, level = 0, lasttwo, threeDigits;

        string retval = "";
        string x = "";
        string[] ones ={
"zero",
"one",
"two",
"three",
"four",
"five",
"six",
"seven",
"eight",
"nine",
"ten",
"eleven",
"twelve",
"thirteen",
"fourteen",
"fifteen",
"sixteen",
"seventeen",
"eighteen",
"nineteen"
};
        string[] tens ={
"zero",
"ten",
"twenty",
"thirty",
"forty",
"fifty",
"sixty",
"seventy",
"eighty",
"ninety"
};
        string[] thou ={
"",
"thousand",
"million",
"billion",
"trillion",
"quadrillion",
"quintillion"
};

        bool isNegative = false;
        if (inputNum < 0)
        {
            isNegative = true;
            inputNum *= -1;
        }

        if (inputNum == 0)
            return ("zero");

        string s = inputNum.ToString();

        while (s.Length > 0)
        {
            // Get the three rightmost characters
            x = (s.Length < 3) ? s : s.Substring(s.Length - 3, 3);

            // Separate the three digits
            threeDigits = int.Parse(x);
            lasttwo = threeDigits % 100;
            dig1 = threeDigits / 100;
            dig2 = lasttwo / 10;
            dig3 = (threeDigits % 10);

            // append a "thousand" where appropriate
            if (level > 0 && dig1 + dig2 + dig3 > 0)
            {
                retval = thou[level] + " " + retval;
                retval = retval.Trim();
            }

            // check that the last two digits is not a zero
            if (lasttwo > 0)
            {
                if (lasttwo < 20) // if less than 20, use "ones" only
                    retval = ones[lasttwo] + " " + retval;
                else // otherwise, use both "tens" and "ones" array
                    retval = tens[dig2] + " " + ones[dig3] + " " + retval;
            }

            // if a hundreds part is there, translate it
            if (dig1 > 0)
                retval = ones[dig1] + " hundred " + retval;

            s = (s.Length - 3) > 0 ? s.Substring(0, s.Length - 3) : "";
            level++;
        }

        while (retval.IndexOf(" ") > 0)
            retval = retval.Replace(" ", " ");

        retval = retval.Trim();

        if (isNegative)
            retval = "negative " + retval;

        return (retval);
    }

    //-------------------------CODE TO CONVERT FROM DIGIT TO WORDS----BY: DHIRAJ GAUTAM----------------
    public static String changeNumericToWords(double numb)
    {
        String num = numb.ToString();
        return changeToWords(num, false);
    }
    public static String changeCurrencyToWords(String numb)
    {
        return changeToWords(numb, true);
    }
    public static String changeNumericToWords(String numb)
    {
        return changeToWords(numb, false);
    }
    public static String changeCurrencyToWords(double numb)
    { return changeToWords(numb.ToString(), true); }
    private static String changeToWords(String numb, bool isCurrency)
    {
        String val = "", wholeNo = numb, points = "", andStr = "", pointStr = "";
        String endStr = (isCurrency) ? ("Only") : ("");
        try
        {
            int decimalPlace = numb.IndexOf(".");
            if (decimalPlace > 0)
            {
                wholeNo = numb.Substring(0, decimalPlace);
                points = numb.Substring(decimalPlace + 1);
                if (Convert.ToInt32(points) > 0)
                {
                    andStr = (isCurrency) ? ("and") : ("point");// just to separate whole numbers from points/centsendStr = (isCurrency) ? ("Cents "+endStr) : ("");pointStr = translateCents(points);
                }
            }
            val = String.Format("{0} {1}{2} {3}", translateWholeNumber(wholeNo).Trim(), andStr, pointStr, endStr);
        }
        catch
        { ;}
        return val;
    }
    private static String translateWholeNumber(String number)
    {
        string word = "";
        try
        {
            bool beginsZero = false;//tests for 0XXbool 
            bool isDone = false;//test if already translateddouble 
            double dblAmt = (Convert.ToDouble(number));
            //if ((dblAmt > 0) && number.StartsWith("0"))
            if (dblAmt > 0)
            {
                //test for zero or digit zero in a nuemric
                beginsZero = number.StartsWith("0");
                int numDigits = number.Length;
                int pos = 0;//store digit grouping
                String place = "";//digit grouping name:hundres,thousand,etc...
                switch (numDigits)
                {
                    case 1://ones' range
                        word = ones(number);
                        isDone = true; break;
                    case 2://tens'  range
                        word = tens(number);
                        isDone = true; break;
                    case 3://hundreds' range
                        pos = (numDigits % 3) + 1;
                        place = " Hundred "; break;
                    case 4://thousands'  range
                    case 5:
                    case 6: pos = (numDigits % 4) + 1;
                        place = " Thousand ";
                        break;
                    case 7://millions' range
                    case 8:
                    case 9:
                        pos = (numDigits % 7) + 1;
                        place = " Million ";
                        break;
                    case 10://Billions's range
                        pos = (numDigits % 10) + 1;
                        place = " Billion ";
                        break;//add extra case options for anything above Billion...
                    default: isDone = true;
                        break;
                }
                if (!isDone)
                {
                    //if transalation is not done, continue...(Recursion comes in now!!)
                    word = translateWholeNumber(number.Substring(0, pos)) + place + translateWholeNumber(number.Substring(pos));
                    //check for trailing zeros
                    if (beginsZero) word = " and " + word.Trim();
                }
                //ignore digit grouping names
                if (word.Trim().Equals(place.Trim()))
                    word = "";
            }
        }
        catch
        { ;}
        return word.Trim();
    }
    private static String tens(String digit)
    {
        int digt = Convert.ToInt32(digit);
        String name = null;
        switch (digt)
        {
            case 10: name = "Ten";
                break;
            case 11: name = "Eleven";
                break;
            case 12: name = "Twelve";
                break;
            case 13: name = "Thirteen";
                break;
            case 14: name = "Fourteen";
                break;
            case 15: name = "Fifteen";
                break;
            case 16: name = "Sixteen";
                break;
            case 17: name = "Seventeen";
                break;
            case 18: name = "Eighteen";
                break;
            case 19: name = "Nineteen";
                break;
            case 20: name = "Twenty";
                break;
            case 30: name = "Thirty";
                break;
            case 40: name = "Fourty";
                break;
            case 50: name = "Fifty";
                break;
            case 60: name = "Sixty";
                break;
            case 70: name = "Seventy";
                break;
            case 80: name = "Eighty";
                break;
            case 90: name = "Ninety";
                break;
            default: if (digt > 0)
                {
                    name = tens(digit.Substring(0, 1) + "0") + " " + ones(digit.Substring(1));
                }
                break;
        }
        return name;
    }
    private static String ones(String digit)
    {
        int digt = Convert.ToInt32(digit);
        String name = "";
        switch (digt)
        {
            case 1: name = "One";
                break;
            case 2: name = "Two";
                break;
            case 3: name = "Three";
                break;
            case 4: name = "Four";
                break;
            case 5: name = "Five";
                break;
            case 6: name = "Six";
                break;
            case 7: name = "Seven";
                break;
            case 8: name = "Eight";
                break;
            case 9: name = "Nine";
                break;
        }
        return name;
    }
    private static String translateCents(String cents)
    {
        String cts = "", digit = "", engOne = "";
        for (int i = 0; i < cents.Length; i++)
        {
            digit = cents[i].ToString();
            if (digit.Equals("0"))
            {
                engOne = "Zero";
            }
            else
            {
                engOne = ones(digit);
            }
            cts += " " + engOne;
        }
        return cts;
    }
    //-------------------------END OF CODE TO CONVERT FROM DIGIT TO WORDS----------------

    public void Display()
    {
        lblAddress1.Visible = true;
        lblAddress.Visible = true;
        string strInclusive = string.Empty;


        Import_AWB_ID = Convert.ToString(Request.QueryString["AWBID"]);
        DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo, IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,IFA.PCS,IFA.Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");



        //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  

        DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + Request.QueryString["AWBID"].ToString() + "'");
        string table = "";
        //decimal total = 0;
        decimal STaxAmount = 0;
        string STaxRecivedAmt = "";
        string STaxRate = "";
        string staxamount = "";
        //****************Updated On 03 May2016: KKCess tax Apply system*****************
        string sbcessamount = "";
        string KKcessamount = "";
        table = "<table border=0 width=400px align=center cellspacing=0>";
        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
        {
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
            {
                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                staxamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
            }
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
            {
                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                sbcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
            }
            //****************Updated On 03 May2016: KKCess tax Apply system*****************
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
            {
                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                KKcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
            }
        }
        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
        {
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
            {
                MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

            }
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
            {
                HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

            }
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
            {
                STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                Stax = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                if (dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "1")
                {
                    staxdetail.Text = "(Service Tax EXEMPTED)";
                }
                else
                {
                    staxdetail.Text = "(INCLUSIVE OF SERVICE TAX)only";
                }
                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                {
                    continue;
                }
            }
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
            {
                SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                SBcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                {
                    continue;
                }
            }
            //****************Updated On 03 May2016: KKCess tax Apply system*****************
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
            {
                KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                KKcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                {
                    continue;
                }
            }
            decimal Allvalue = 0;

            //************************ImportChargesHead: DP_FEE,Cartage,CommunicationFee concept****
            if (dtImportAwbTrans.Rows.Count > 0)
            {
                if (Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]) > 0)
                {
                    //***************************Creating Charges*****************************
                    if (Airline_id == "159")
                    {
                        if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                        {
                            if (staxamount != "0.00")
                                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                                ////mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                                mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));
                            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + mawcharge + "' >" + mawcharge.ToString("#,##0.00") + "</label>";
                            table += "</td></tr>";

                        }
                        else
                        {
                            #region Gst Applicable
                            string charge = "";
                            string ChargeName = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
                            if (ChargeName == "StaxRate")
                            {
                                charge = "CGST";
                            }
                            else if (ChargeName == "SBCess")
                            {
                                charge = "SGST";
                            }
                            else if (ChargeName == "KKCess")
                            {
                                charge = "IGST";
                            }
                            else
                            {
                                charge = dtImportAwbTrans.Rows[i]["ChargeName"].ToString();
                            }
                            if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                            {
                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + charge + "'>" + charge + " Chrgs:</label>";

                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                                table += "</td></tr>";
                            }
                            else
                            {
                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                                table += "</td></tr>";
                            }

                            #endregion end of Gst Applicable
                        }
                    }
                    else
                    {
                        table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                        table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";

                        table += "</td></tr>";
                    }
                    //***************************End******************************************
                    if (Airline_id == "159")
                    {
                        if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() != "StaxRate")
                            total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                    }
                    else
                        total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);


                }
                else if (dt.Rows[0]["Shipment_Type"].ToString() == "F")
                {
                    table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                    table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + "0.00" + "' >" + "0.00" + "</label>";

                    table += "</td></tr>";
                    //***************************End******************************************

                    total += Convert.ToDecimal("0.00");
                }


                //*****************************END*****************************************************               
            }



        }

        //if (Airline_id == "159")
        //{ 
        //total=total-

        //}
        if (dt.Rows[0]["Tds_Cut_By_Agent"].ToString() != "0.00")
        {
            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label>TDS :</label>";
            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + "-" + dt.Rows[0]["Tds_Cut_By_Agent"].ToString() + "</label></td></tr>";
        }
        table += "</table>";
        lblTabel.Text = table;
        no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();
        recipt_no = dt.Rows[0]["recipt_no"].ToString();
        lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
        decimal CC_Cheque_Amount = Convert.ToDecimal(dt.Rows[0]["CC_Cheque_Amount"]);
        if (Airline_id == "147" || Airline_id == "153")
        {
            mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[0]["ChargeAmount"]);
        }
        //****************Updated On 03 May2016: KKCess tax Apply system*****************
        decimal SBCessAmt = 0;
        decimal KKCessAmt = 0;
        //****************Updated On 03 May2016: KKCess tax Apply system*****************
        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
        {
            ////////****************Updated On 03 May2016: KKCess tax Apply system*****************
            //////decimal SBCessAmt = 0;
            //////decimal KKCessAmt = 0;
            ////////****************Updated On 03 May2016: KKCess tax Apply system*****************
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
            {
                SBCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

            }
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
            {
                KKCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

            }

            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "Carting")
            {
                cartingcharges = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
            }
            else if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
            {
                mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
            }


            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate" && dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "0")
            {
                ////string strInclusive = string.Empty;
                strInclusive += "<table border=0 width=400px align=center cellspacing=0>";

                decimal STaxAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt;
                ViewState["STaxAmt"] = STaxAmt;
                //////if (Airline_id == "159")
                //////{
                //////    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                //////    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                //////    //DOCharge = Convert.ToDecimal(TD);

                //////}

                if (Airline_id == "147" || Airline_id == "153")
                {
                    //strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + mawcharge + "</label></td></tr>";
                    //strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                }
                else if (Airline_id == "159")
                {
                    //strInclusive += "<tr style=\"display:none\" ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                    //strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                }
                else
                {
                    //strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                    //strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                    //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                }

                //if (Airline_id == "147")
                //    strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: center\" ><label>DoCharge :</label>";
                //else
                //    strInclusive += "<tr ><td style=\"width: 290px;   text-align: center\" ><label>DoCharge :</label>";

                //if (Airline_id == "147")
                //    strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + mawcharge + "</label></td></tr>";
                //else
                //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge + "</label></td></tr>";
                //strInclusive += "<tr><td style=\"width: 290px;   text-align: center\" ><label>Stax Amount :</label>";
                //strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";

                ////lblInclusive.Text = strInclusive;
            }

            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
            {
                // string strInclusive = string.Empty;
                decimal STaxAmt = 0;
                if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                {
                    ////ViewState["STaxAmt"] = "0";
                    ViewState["STaxAmt"] = STaxAmt;
                }
                else
                {

                    STaxAmt = (Decimal)ViewState["STaxAmt"];
                }
                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt;

                if (Airline_id == "1591")
                {
                    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                    //DOCharge = Convert.ToDecimal(TD);

                }

                if (Airline_id == "159")
                {
                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";

                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr></table>";

                }
                else if (Airline_id == "1591")
                {
                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";

                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                }
                else
                {
                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";

                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";

                }


            }
            //****************Updated On 03 May2016: KKCess tax Apply system*****************
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
            {
                // string strInclusive = string.Empty;
                decimal STaxAmt = 0;
                if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                {
                    ////ViewState["STaxAmt"] = "0";
                    ViewState["STaxAmt"] = STaxAmt;
                }
                else
                {

                    STaxAmt = (Decimal)ViewState["STaxAmt"];
                }
                decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt - KKCessAmt;

                if (Airline_id == "1591")
                {
                    DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                    //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                    //DOCharge = Convert.ToDecimal(TD);

                }

                if (Airline_id == "159")
                {
                    ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                    ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                    ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";

                }
                else if (Airline_id == "1591")
                {
                    if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                    {
                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                    }

                    else
                    {
                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                    }
                }
                else
                {
                    if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                    {
                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                    }

                    else
                    {
                        strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                        strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                        strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                    }
                }


            }
            lblInclusive.Text = strInclusive;
        }
        string StaxNo = "";

        issue_date = dt.Rows[0]["issue_date"].ToString();
        straddress = dt.Rows[0]["office_address"].ToString();
        Airportadress = dt.Rows[0]["Airport_Address"].ToString();
        payment_mode = dt.Rows[0]["payment_mode"].ToString();
        flight_date = dt.Rows[0]["import_flight_Date"].ToString();
        part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
        decimal ServiceTax = 0;
        ServiceTax = decimal.Parse(STAXRATE);

        if (part_pcs == "" || part_pcs == "0")
        {
            lblPartPsc.Visible = false;
            lblPartPsc.Text = "";
            lblpppsc.Visible = false;
            lblpppsc.Text = "";
        }
        else
        {
            lblPartPsc.Visible = true; ;
            lblPartPsc.Text = part_pcs;
            lblpppsc.Visible = true;
            lblpppsc.Text = "/";
        }

        //*****************Added On 1 feb 2011********************

        if (dt.Rows[0]["freight_type"].ToString() == "PP")
        {
            lblBeingFrtchrgs.Text = "PP";
        }

        else if (dt.Rows[0]["freight_type"].ToString() == "CC")
        {
            string MawbChrs = "";
            string HawbChrs = "";
            if (MawbDo_Chgs == "")
            {
                MawbChrs = "0";
            }
            else
            {
                MawbChrs = MawbDo_Chgs;
            }
            if (HawbDo_Chgs == "")
            {
                HawbChrs = "0";
            }
            else
            {
                HawbChrs = HawbDo_Chgs;
            }
            lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
            lblDOChrgs.Text = Convert.ToString(total);
        }

        //*****************END********************

        strAirline_name = dt.Rows[0]["Airline_Name"].ToString();

        if (strAirline_name == "MALAYSIAN AIRLINES")
        {
            strAirline_name = "MALAYSIA AIRLINES";
        }
        awbno = dt.Rows[0]["Import_Awb_No"].ToString();
        flt_no = dt.Rows[0]["import_flight_no"].ToString();
        if (Airline_id == "158")
        {
            if (FlightNo != "KE-9395")
            {
                if (FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                flt_no = flt_no.Replace("HY", "KE");
                else
                    flt_no = flt_no.Replace("KE", "HY");
            }
            
            
        }
        arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();

        contents = dt.Rows[0]["commodity"].ToString();
        if (contents == "Console")
        {
            contents = "Consol";
        }
        pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
        import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
        to = dt.Rows[0]["Consignee_Name"].ToString();
        if (to == "")
        {
            to = dt.Rows[0]["Agent_Name"].ToString();
        }
        if (Airline_id == "147" || Airline_id == "153")
        {
            to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
        }
        if (dt.Rows[0]["GstNo"].ToString() != "")
            to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b>";
        from = dt.Rows[0]["Shipper_Name"].ToString();
        notify = dt.Rows[0]["Notify"].ToString();
        if (notify == "")
        {
            lblNotifyDo.Visible = false;
            lblNotifyDovalue.Visible = false;
            lblNotify.Visible = false; ;
            lblNotifyValue.Visible = false;
            lblNotifyValue.Text = "";

        }
        else
        {
            lblNotifyDo.Visible = true;
            lblNotifyDovalue.Visible = true;
            lblNotifyDovalue.Text = notify;
            lblNotify.Visible = true;
            lblNotifyValue.Visible = true;
            lblNotifyValue.Text = notify;
        }
        IGMNo = dt.Rows[0]["IGM_No"].ToString();
        string house = dt.Rows[0]["No_of_Houses"].ToString();
        decimal housevalue = System.Math.Round(decimal.Parse(house), 0);
        decimal d = housevalue * decimal.Parse(HawbDo_Chgs);

        //************Added on 1 feb 2011 Added freight Chrages for CC Case****************

        decimal DOFrtChrgs = 0;
        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
        {
            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
            {
                DOFrtChrgs = 0;
            }
            else
            {
                DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
            }
            TrFreightChrgsCC.Visible = true;

            d = d + DOFrtChrgs;
        }

        //************END**********************************************
        string addrs = "";
        if (Airline_id == "158")
        {
            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
            {
                lblAddress.Text = straddress.ToString();
                lblAddress1.Text = straddress.ToString();
            }
            else
            {
                lblAddress.Text = straddress.ToString();
                lblAddress1.Text = Airportadress.ToString();
            }
        }
        else
        {
            lblAddress.Text = straddress.ToString();
            lblAddress1.Text = straddress.ToString();
        }


        if (lblAddress.Text.Contains("GST NO"))
        {
            int i = lblAddress.Text.IndexOf(",GST NO");
            StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
            addrs = lblAddress.Text.Replace(StaxNo, ".");
            addrs = addrs.Replace(",.", ".");
            //lblAddress1.Text = addrs;
            lblAddress.Text = addrs;
        }
        else
        {
            // lblAddress1.Text = straddress.ToString();
            lblAddress.Text = straddress.ToString();
        }


        if (lblAddress1.Text.Contains("GST NO"))
        {
            int i = lblAddress1.Text.IndexOf(",GST NO");
            StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
            addrs = lblAddress1.Text.Replace(StaxNo, ".");
            addrs = addrs.Replace(",.", ".");
            lblAddress1.Text = addrs;
            //lblAddress.Text = addrs;
        }
        else
        {
            if (Airline_id == "158")
                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                    lblAddress1.Text = straddress.ToString();
                else
                    lblAddress1.Text = Airportadress.ToString();
            else
                lblAddress1.Text = straddress.ToString();
        }

        if (lblAddress1.Text.Contains("Tel"))
            lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
        if (lblAddress1.Text.Contains("TEL"))
            lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
        if (lblAddress.Text.Contains("Tel"))
            lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
        if (lblAddress.Text.Contains("TEL"))
            lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
        if (lblAddress1.Text.Contains("Fax"))
            lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
        if (lblAddress1.Text.Contains("FAX"))
            lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
        if (lblAddress.Text.Contains("Fax"))
            lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
        if (lblAddress.Text.Contains("FAX"))
            lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");
        //lblAddress.Text = straddress.ToString();
        //if (lblAddress.Text.Contains("S.TAX NO"))
        //{
        //    int i = lblAddress.Text.IndexOf(",S.TAX NO");
        //    StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
        //    addrs = lblAddress.Text.Replace(StaxNo, ".");
        //    addrs = addrs.Replace(",.", ".");
        //    lblAddress1.Text = addrs;
        //    lblAddress.Text = addrs;
        //}
        //else
        //{
        //    lblAddress1.Text = straddress.ToString();
        //    lblAddress.Text = straddress.ToString();
        //}
        if (payment_mode == "1")
        {
            lblCheque.Visible = false;
            lblCash.Text = "in Cash";
        }
        else if (payment_mode == "2")
        {
            lblCash.Visible = false;
            lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
        }



        if (strAirline_name == "MALAYSIA AIRLINES")
        {
            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo, " + StaxNo;
        }

        else if (strAirline_name == "TURKISH AIRLINES")
        {
            lblAirlineStax.Text = "Ascent Air Pvt Ltd, " + StaxNo;
        }

        else if (strAirline_name == "AIR CHINA")
        {
            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd, " + StaxNo;
        }
        else if (strAirline_name == "KOREAN AIRLINES")
        {
            lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO, " + StaxNo;
        }

        else if (strAirline_name == "MEGA MALDIVES AIRLINES")
        {
            lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD, " + StaxNo;
        }
        else
        {
            lblAirlineStax.Text = "Pace Express, " + StaxNo;
        }

        lblairlinename.Text = strAirline_name.ToString();
        if (Airline_id == "158")
        {
            if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
            {
                lblAirlineNme.Text = "KOREAN AIR";
                lblheadairlinename.Text = "KOREAN AIR";
            }
            else
            {
                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
            }
        }
        else if (Airline_id == "159")
        {
            if (FlightNo == "HY-127")
            {
                lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                lblairlinename.Text = "UZBEKISTAN AIRWAYS";
            }
            else
            {
                lblAirlineNme.Text = "KOREAN AIR";
                lblheadairlinename.Text = "KOREAN AIR";
                lblairlinename.Text = "KOREAN AIR";
            }

        }
        else
        {
            lblAirlineNme.Text = strAirline_name.ToString();
            lblheadairlinename.Text = strAirline_name.ToString();
        }
        lblAwbno.Text = awbno.ToString();
        lblPcs.Text = pcs.ToString();
        ////////lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");

        //****************Added On 01_Mach_2011******
        lblDate.Text = issue_date;
        //***************End*************

        lblcommdy.Text = contents.ToString();
        lblFlightno.Text = flt_no.ToString();
        lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();

        lbligmnr.Text = IGMNo.ToString();
        lblAwb2.Text = awbno.ToString();
        lbldate2.Text = issue_date.ToString();
        lblFlitno2.Text = flt_no.ToString();
        lblAirlinemame3.Text = strAirline_name.ToString();
        if (Airline_id == "147")
        {
            lblch.Visible = true;
            lblchwt.Visible = true;
            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
            lblAirlinemame3.Text = "MASkargo";
            lblAirlineNme.Text = "MASkargo";
        }
        else if (Airline_id == "153")
        {
            lblch.Visible = true;
            lblchwt.Visible = true;
            lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();
            ////lblAirlinemame3.Text = "MASkargo";
            ////lblAirlineNme.Text = "MASkargo";
        }

        if (Airline_id == "159")
        {
            lblAirlinemame3.Text = "KOREAN AIR";

        }

        //******************Added On 1 feb 2011*********************
        if (dt.Rows[0]["freight_Type"].ToString() == "CC")
        {
            TrFreightChrgsCC.Visible = true;
            if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0.00")
            {
                lblDOFrtChr.Text = "0";
                TrFreightChrgsCC.Visible = false;
            }
            else
            {
                TrFreightChrgsCC.Visible = true;
                lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                total += Convert.ToDecimal(dt.Rows[0]["Total_Collection_CC"]);
            }


        }
        //****************************End*********************************************

        decimal _Amount_Received = 0;
        decimal _Amount_ReceivedSBCess = 0;
        decimal _Amount_ReceivedKKCess = 0;




        //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  

        for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
        {
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
            {
                _Amount_Received = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());

            }
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
            {
                _Amount_ReceivedSBCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());

            }
            //****************Updated On 03 May2016: KKCess tax Apply system*****************
            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
            {
                _Amount_ReceivedKKCess = decimal.Parse(dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString());

            }
        }



        decimal _TDSCutByAgent = decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString());
        //decimal f = d+1000;
        decimal f = d + Convert.ToDecimal(MawbDo_Chgs);
        //decimal Tds=9.75;
        decimal _Amount = 0;
        _Amount = Convert.ToInt64(f);

        string TD_S = "";
        string TD_S1 = "";

        string Total_ = "";
        if (Airline_id == "159")
        {
            if (_Amount_Received != 0)
            {
                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                ////decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                decimal charge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));

                total = total - mawcharge + _Amount_Received + charge;
            }
        }

        // lblMaster.Text = MawbDo_Chgs.ToString();
        if (_TDSCutByAgent > 0 || ServiceTax > 0)
        {
            if (_TDSCutByAgent > 0)
            {

                string TD = Convert.ToString(Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));
                TD_S = Convert.ToDecimal(TD).ToString("#,##0.00");

                string A = Convert.ToString(total - Math.Round(decimal.Parse(dt.Rows[0]["Tds_Cut_By_Agent"].ToString()), 0, MidpointRounding.AwayFromZero));


                decimal AM = 0;
                AM = decimal.Parse(A);
                Total_ = Convert.ToDecimal(A).ToString("#,##0.00");

                lblfreight.Text = Total_;
                _Amount = decimal.Parse(lblfreight.Text);
            }
            //****************** Service Tax Logic on 16 Aug 2010 *****************
            else
            {

                lblfreight.Text = total.ToString();
                _Amount = decimal.Parse(lblfreight.Text);
            }


        }
        else
        {
            string _F = "";
            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
            {
                _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue) + decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString()));
            }
            else
            {
                _F = Convert.ToString(decimal.Parse(MawbDo_Chgs) + (decimal.Parse(HawbDo_Chgs) * housevalue));
            }
            lblfreight.Text = Convert.ToDecimal(_F).ToString("#,##0.00");
            //_Amount = f;
            _Amount = decimal.Parse(lblfreight.Text);
        }

        Label1.Text = lblfreight.Text;

        lblSno.Text = recipt_no.ToString();
        lblSnomum.Text = recipt_no.ToString();
        lblSnochennai.Text = recipt_no.ToString();
        lblSno2.Text = recipt_no.ToString();
        lblName.Text = to.ToString();
        lblName2.Text = to.ToString();
        Sno.Text = recipt_no.ToString();
        string englishTranslation = "";
        string englishTranslationDecimalPart = "";
        //string englishTranslation = changeNumericToWords(Convert.ToDouble(f));
        //********** Function Translation of Number figure TO Words******************
        string Amt = _Amount.ToString();
        string AmtDecimal = "";
        string AmountCombined = "";

        //*********Decimal Logic****************

        //***** Shipment Type is FOC Case**********//
        if (dt.Rows[0]["shipment_type"].ToString() == "F")
        {
            _Amount = 0;
            lblfreight.Text = "0.00";
            lblAmount.Text = "Zero";
            englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));

        }
        else
        {
            englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));
            lblAmount.Text = englishTranslation;
        }
        //englishTranslation = changeNumericToWords(Convert.ToDouble(_Amount));

        ////lblFlightDate.Text = flight_date.ToString();
        DateTime fltdate = DateTime.Parse(flight_date);
        lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");

        //lblFltDateAirline.Text = flight_date.ToString();
        DateTime fltdate2 = DateTime.Parse(flight_date);
        lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");
    }

    public void DisplayRepeatAwb()
    {
        string strInclusive = string.Empty;
        DataTable dtDo_GenerateStatus_check = dw.GetAllFromQuery("select Import_Awb_ID,Import_Awb_No,D0_Generate_Status from Import_Flight_Awb where Import_Awb_No='" + AIrwayBill_No + "' and D0_Generate_Status='YES'");



        if (dtDo_GenerateStatus_check.Rows.Count > 0)
        {
            lblAddress1.Visible = true;
            lblAddress.Visible = true;
            AmtDescp.Visible = false;
            Tr1.Visible = false;
            Tr2.Visible = false;
            TotalLine.Visible = false;
            TotalSpace.Visible = false;

            Space3.Visible = false;
            //  Space4.Visible = false;

            Space6.Visible = true;
            PartShipmentCase.Visible = true;


            Import_AWB_ID = dtDo_GenerateStatus_check.Rows[0]["Import_Awb_ID"].ToString();
            DataTable dt = dw.GetAllFromQuery("select IFA.BankConsigneeStatus,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo, IFS.import_flight_no,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Request.QueryString["AWBID"].ToString() + "'");


            //*****************************MAWB,HAWB,STAX_rATE:PICKED FROM IMPORTFLIGHT_AWB****************  

            DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + Request.QueryString["AWBID"].ToString() + "'");
            string table = "";
            decimal total = 0;
            decimal STaxAmount = 0;
            string STaxRecivedAmt = "";
            string STaxRate = "";
            string staxamount = "";
            string sbcessamount = "";
            string KKcessamount = "";
            table = "<table border=0 width=100% align=center cellspacing=0>";
            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
            {
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                {
                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    staxamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                }
               
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                {
                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    sbcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                }
                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                {
                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    KKcessamount = dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString();
                }
            }
            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
            {
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                {

                    MawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                }
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "HAWB")
                {
                    HawbDo_Chgs = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                }
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                {
                    STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    Stax = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                    if (dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "1")
                    {
                        staxdetail.Text = "(Service Tax EXEMPTED)";
                    }
                    else
                    {
                        staxdetail.Text = "(INCLUSIVE OF SERVICE TAX)only";
                    }
                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                    {
                        continue;
                    }
                    //continue;
                }
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                {
                    SBcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    SBcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                    {
                        continue;
                    }
                }
                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                {
                    KKcessRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    KKcess = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);
                    if (Airline_id != "147" && Airline_id != "159" && Airline_id != "153")
                    {
                        continue;
                    }
                }

                decimal Allvalue = 0;

                //************************ImportChargesHead: DP_FEE,Cartage,CommunicationFee concept****
                if (dtImportAwbTrans.Rows.Count > 0)
                {
                    if (Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]) > 0)
                    {

                        //***************************Creating Charges*****************************
                        if (Airline_id == "159")
                        {


                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                            {
                                if (staxamount != "0.00")
                                    //****************Updated On 03 May2016: KKCess tax Apply system*****************
                                    ////mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE)) / 100)));
                                    mawcharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE) + Convert.ToDecimal(SBcessRATE) + Convert.ToDecimal(KKcessRATE)) / 100)));

                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + mawcharge + "' >" + mawcharge.ToString("#,##0.00") + "</label>";
                                table += "</td></tr>";
                            }
                            else
                            {


                                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                                table += "</td></tr>";
                            }


                        }
                        else
                        {
                            table += "<tr><td style=\"width: 290px;   text-align: left\" ><label id='lblChrgsame" + i + "' name='lblChrgsame" + i + "' text='" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + "'>" + dtImportAwbTrans.Rows[i]["ChargeName"].ToString() + " Chrgs:</label>";

                            table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label id='txtChrgsValue" + i + "' style='width:50px' name='txtChrgsValue" + i + "' type='textbox' text='" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "' >" + dtImportAwbTrans.Rows[i]["ChargeAmount"].ToString() + "</label>";
                        }

                        table += "</td></tr>";
                        //***************************End******************************************

                        if (Airline_id == "159")
                        {
                            if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() != "StaxRate")
                                total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                        }
                        else
                            total += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                    }


                }





            }
            if (dt.Rows[0]["Tds_Cut_By_Agent"].ToString() != "0.00")
            {
                table += "<tr><td style=\"width: 290px;   text-align: left\" ><label>TDS :</label>";
                table += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + "-" + dt.Rows[0]["Tds_Cut_By_Agent"].ToString() + "</label></td></tr>";
            }
            table += "</table>";
            lblTabel.Text = table;
            no_of_Houses = dt.Rows[0]["no_of_Houses"].ToString();
            recipt_no = dt.Rows[0]["recipt_no"].ToString();
            lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
            decimal CC_Cheque_Amount = Convert.ToDecimal(dt.Rows[0]["CC_Cheque_Amount"]);
            mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[0]["ChargeAmount"]);
            //****************Updated On 03 May2016: KKCess tax Apply system*****************
            decimal SBCessAmt = 0;
            decimal KKCessAmt = 0;
            for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
            {
                ////decimal SBCessAmt = 0;
                ////decimal KKCessAmt = 0;
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                {
                    SBCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                }
                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                {
                    KKCessAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);

                }
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "Carting")
                {
                    cartingcharges = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                }
                else if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "MAWB")
                {
                    mawcharge = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                }



                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate" && dtImportAwbTrans.Rows[i]["Quantity"].ToString() == "0")
                {
                    ////string strInclusive = string.Empty;
                    strInclusive += "<table border=0 width=100% align=center cellspacing=0>";
                    ////decimal DOCharge = Math.Round(Convert.ToDecimal(CC_Cheque_Amount - ((CC_Cheque_Amount * Convert.ToDecimal(10.3)) / (100 + Convert.ToDecimal(STAXRATE)))), 0, MidpointRounding.AwayFromZero);
                    ////decimal STaxAmt = Math.Round(Convert.ToDecimal((CC_Cheque_Amount * Convert.ToDecimal(10.3)) / (100 + Convert.ToDecimal(STAXRATE))), 0, MidpointRounding.AwayFromZero);

                    decimal STaxAmt = Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt;

                    ViewState["STaxAmt"] = STaxAmt;
                    ////if (Airline_id == "159")
                    ////{

                    ////    DOCharge = Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100)));
                    ////}
                    if (Airline_id == "147" || Airline_id == "153")
                    {
                        ////strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + mawcharge + "</label></td></tr>";
                        ////strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                    }
                    else if (Airline_id == "159")
                    {
                        ////strInclusive += "<tr style=\"display:none\" ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        ////strInclusive += "<tr style=\"display:none\"><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                    }
                    else
                    {
                        ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr></table>";
                    }





                   //// lblInclusive.Text = strInclusive;
                }
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "SBCess")
                {
                    // string strInclusive = string.Empty;
                    decimal STaxAmt = 0;
                    if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                    {
                        ////ViewState["STaxAmt"] = "0";
                        ViewState["STaxAmt"] = STaxAmt;
                    }
                    else
                    {

                        STaxAmt = (Decimal)ViewState["STaxAmt"];
                    }
                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt;

                    if (Airline_id == "1591")
                    {
                        DOCharge = Convert.ToDecimal(Math.Floor(mawcharge / (1 + ((Convert.ToDecimal(STAXRATE)) / 100))));

                        //TD = Convert.ToDecimal(TD).ToString("#,##0.00");
                        //DOCharge = Convert.ToDecimal(TD);

                    }

                    if (Airline_id == "159")
                    {
                        ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr></table>";

                    }
                    else if (Airline_id == "1591")
                    {
                        //////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                    }
                    else
                    {
                        //////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        //////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                        //////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";

                    }


                }

                //****************Updated On 03 May2016: KKCess tax Apply system*****************
                if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "KKCess")
                {
                    // string strInclusive = string.Empty;
                    decimal STaxAmt = 0;
                    if (ViewState["STaxAmt"] == null || ViewState["STaxAmt"] == "")
                    {
                        ////ViewState["STaxAmt"] = "0";
                        ViewState["STaxAmt"] = STaxAmt;
                    }
                    else
                    {

                        STaxAmt = (Decimal)ViewState["STaxAmt"];
                    }
                    decimal DOCharge = Convert.ToDecimal(CC_Cheque_Amount) - STaxAmt - SBCessAmt - KKCessAmt;

                    if (Airline_id == "1591")
                    {
                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                        {
                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                        }

                        else
                        {
                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                        }

                    }

                    if (Airline_id == "159")
                    {
                        ////strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                        ////strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                        ////strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";

                    }
                    else if (Airline_id == "1591")
                    {
                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                        {
                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                        }

                        else
                        {
                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                        }

                    }
                    else
                    {
                        if (Convert.ToDateTime(dt.Rows[0]["Flight_date"].ToString()) >= Convert.ToDateTime("07/01/2017"))
                        {
                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>CGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>IGST Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                        }

                        else
                        {
                            strInclusive += "<tr ><td style=\"width: 290px;   text-align: left\" ><label>DoCharge :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + DOCharge.ToString("#,##0.00") + "</label></td></tr>";
                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>Stax Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + STaxAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>SBCess Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + SBCessAmt + "</label></td></tr>";


                            strInclusive += "<tr><td style=\"width: 290px;   text-align: left\" ><label>KKCess Amount :</label>";
                            strInclusive += "</td><td style=\"font-size: 12pt; width: 244px;   text-align: right;\"><label >" + KKCessAmt + "</label></td></tr></table>";
                        }
                    }


                }
                lblInclusive.Text = strInclusive;
            }

            string StaxNo = "";

            issue_date = dt.Rows[0]["issue_date"].ToString();
            straddress = dt.Rows[0]["office_address"].ToString();
            Airportadress = dt.Rows[0]["Airport_Address"].ToString();
            payment_mode = dt.Rows[0]["payment_mode"].ToString();
            flight_date = dt.Rows[0]["import_flight_Date"].ToString();
            //lblFltDateAirline.Text = flight_date;
            DateTime fltdate2 = DateTime.Parse(flight_date);
            lblFltDateAirline.Text = fltdate2.ToString("dd/MM/yyyy");
            ////lblFlightDate.Text = flight_date;
            DateTime fltdate = DateTime.Parse(flight_date);
            lblFlightDate.Text = fltdate.ToString("dd/MM/yyyy");
            part_pcs = dt.Rows[0]["Part_Pcs"].ToString();
            pcs = Convert.ToDecimal(dt.Rows[0]["pcs"].ToString());
            if (part_pcs == "" || part_pcs == "0")
            {
                lblPartPsc.Visible = false;
                lblPartPsc.Text = "";
                lblpppsc.Visible = false;
                lblpppsc.Text = "";
            }
            else
            {
                lblPartPsc.Visible = true; ;
                lblPartPsc.Text = part_pcs;
                lblpppsc.Visible = true;
                lblpppsc.Text = "/";
            }


            //*****************Added On 1 feb 2011********************

            if (dt.Rows[0]["freight_type"].ToString() == "PP")
            {
                lblBeingFrtchrgs.Text = "PP";
            }

            else if (dt.Rows[0]["freight_type"].ToString() == "CC")
            {
                string MawbChrs = "";
                string HawbChrs = "";
                if (MawbDo_Chgs == "")
                {
                    MawbChrs = "0";
                }
                else
                {
                    MawbChrs = MawbDo_Chgs;
                }
                if (HawbDo_Chgs == "")
                {
                    HawbChrs = "0";
                }
                else
                {
                    HawbChrs = HawbDo_Chgs;
                }
                lblBeingFrtchrgs.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                lblDOChrgs.Text = Convert.ToString(decimal.Parse(MawbChrs) + decimal.Parse(HawbChrs));
            }

            //*****************END********************

            //******************Old AWb Details**************************

            DataTable dtOldAwb = dw.GetAllFromQuery("select IFS.import_flight_no,convert(varchar,IFs.Import_flight_date,101) as Flight_date,IFA.GstNo,imfe.office_address,imfe.Airport_Address,convert(varchar,IFA.issue_date,100) as issue_date,IFA.recipt_no,IFA.MawbDo_Chgs,isnull(IFA.CC_cheque_amount,0) as CC_cheque_amount,isnull(IFA.DO_cheque_amount,0) as DO_cheque_amount,IFA.Cheque_No,IFA.Bank_Name,convert(varchar,IFA.Cheque_dated,101) as Cheque_Dated,IFA.HawbDo_Chgs,IFA.no_of_Houses,IFA.payment_mode,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,convert(varchar,IFS.import_flight_Date,101) as import_flight_Date,IFS.IGM_NO,IFa.import_Flight_id,IFA.No_of_Houses,IFA.Import_AWB_No,IFA.Gross_Weight,IFA.Charged_Weight,isnull(IFA.PCS,0) as PCS,isnull(IFA.Part_Pcs,0) as Part_Pcs,IFA.Origin,IFA.Destination,IFA.freight_Type,IFA.Commodity,IFA.SLS,IFA.No_of_Houses,IFA.Shipper_NAme,IFA.Consignee_Name,IFA.Agent_Name,IFA.Notify,IFA.Rotation_No,IFA.Remarks,IFA.shipment_type,AM.Airline_Name,isnull(IFA.Amount_Received,0) as Amount_Received,isnull(IFA.DO_Amount_Received,0) as DO_Amount_Received,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_Cut_By_Agent,isnull(IFA.DO_Tds_Cut_By_Agent,0) as DO_Tds_Cut_By_Agent,isnull(stax_rate,0)as stax_rate,isnull(DO_stax_rate,0) as DO_stax_rate,isnull(IFA.Total_Collection_CC,0) as  Total_Collection_CC from import_flights IFS inner join import_flight_Awb IFA on IFS.Import_flight_id=IFA.Import_flight_id inner join Airline_detail AD on AD.Airline_detail_id=IFS.Airline_Detail_ID INNER JOIN AIRLINE_MASTER AM on AM.Airline_ID=AD.Airline_ID inner join Import_Charges_fee imfe on imfe.Airline_detail_id=IFS.Airline_detail_id where IFA.Import_AWB_ID='" + Import_AWB_ID + "'");



            if (dtOldAwb.Rows.Count > 0 || dtOldAwb != null)
            {

                OldAwb_ReciptNo = dtOldAwb.Rows[0]["recipt_no"].ToString();
            }

            //********************************END OF OLD AWB Details***************

            strAirline_name = dt.Rows[0]["Airline_Name"].ToString();

            if (strAirline_name == "MALAYSIAN AIRLINES")
            {
                strAirline_name = "MALAYSIA AIRLINES";
            }
            awbno = dt.Rows[0]["Import_Awb_No"].ToString();
            flt_no = dt.Rows[0]["import_flight_no"].ToString();
            if (Airline_id == "158")
            {
                if (FlightNo != "KE-9395" || FlightNo != "KE-9307" )
                {
                    if (FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                        flt_no = flt_no.Replace("HY", "KE");
                    else
                        flt_no = flt_no.Replace("KE", "HY");
                }
            }
            arr_flight_date = dt.Rows[0]["import_Flight_date"].ToString();

            contents = dt.Rows[0]["commodity"].ToString();
            if (contents == "Console")
            {
                contents = "Consol";
            }

            import_rotation_No = dt.Rows[0]["Rotation_No"].ToString();
            to = dt.Rows[0]["Consignee_Name"].ToString();
            if (to == "")
            {
                to = dt.Rows[0]["Agent_Name"].ToString();
            }
            if (Airline_id == "147" || Airline_id == "153")
            {
                to = dt.Rows[0]["BankConsigneeStatus"].ToString() == "Y" ? dt.Rows[0]["Notify"].ToString() : to;
            }

            if (dt.Rows[0]["GstNo"].ToString() != "")
                to = to + "<br><b>GST No:" + dt.Rows[0]["GstNo"].ToString() + "</b>";
            from = dt.Rows[0]["Shipper_Name"].ToString();
            notify = dt.Rows[0]["Notify"].ToString();
            lblremarks.Text = dt.Rows[0]["Remarks"].ToString();
            if (notify == "")
            {
                lblNotifyDo.Visible = false;
                lblNotifyDovalue.Visible = false;
                lblNotify.Visible = false; ;
                lblNotifyValue.Visible = false;
                lblNotifyValue.Text = "";

            }
            else
            {
                lblNotifyDo.Visible = true;
                lblNotifyDovalue.Visible = true;
                lblNotifyDovalue.Text = notify;
                lblNotify.Visible = true;
                lblNotifyValue.Visible = true;
                lblNotifyValue.Text = notify;
            }
            IGMNo = dt.Rows[0]["IGM_No"].ToString();
            string house = dt.Rows[0]["No_of_Houses"].ToString();
            decimal housevalue = System.Math.Round(decimal.Parse(house), 0);
            decimal d = housevalue * decimal.Parse(HAWBChrg);

            //************Added on 1 feb 2011 Added freight Chrages for CC Case****************

            decimal DOFrtChrgs = 0;
            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
            {
                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "0")
                {
                    DOFrtChrgs = 0;
                }
                else
                {
                    DOFrtChrgs = decimal.Parse(dt.Rows[0]["Total_Collection_CC"].ToString());
                }
                TrFreightChrgsCC.Visible = true;

                d = d + DOFrtChrgs;
            }

            //************END**********************************************
            string addrs = "";
            lblAddress.Text = straddress.ToString();
            if (Airline_id == "158")
            {
                lblAddress.Text = straddress.ToString();
                lblAddress1.Text = Airportadress.ToString();
            }
            else
            {
                lblAddress.Text = straddress.ToString();
                lblAddress1.Text = straddress.ToString();
            }


            if (lblAddress.Text.Contains("GST NO"))
            {
                int i = lblAddress.Text.IndexOf(",GST NO");
                StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
                addrs = lblAddress.Text.Replace(StaxNo, ".");
                addrs = addrs.Replace(",.", ".");
                //lblAddress1.Text = addrs;
                lblAddress.Text = addrs;
            }
            else
            {
                // lblAddress1.Text = straddress.ToString();
                lblAddress.Text = straddress.ToString();
            }


            if (lblAddress1.Text.Contains("GST NO"))
            {
                int i = lblAddress1.Text.IndexOf(",GST NO");
                StaxNo = lblAddress1.Text.Substring(i, lblAddress1.Text.Length - i).TrimStart(',');
                addrs = lblAddress1.Text.Replace(StaxNo, ".");
                addrs = addrs.Replace(",.", ".");
                lblAddress1.Text = addrs;
                //lblAddress.Text = addrs;
            }
            else
            {
                if (Airline_id == "158")
                    lblAddress1.Text = Airportadress.ToString();
                else
                    lblAddress1.Text = straddress.ToString();
            }
            if (lblAddress1.Text.Contains("Tel"))
                lblAddress1.Text = lblAddress1.Text.Replace("Tel", "<br> Tel");
            if (lblAddress1.Text.Contains("TEL"))
                lblAddress1.Text = lblAddress1.Text.Replace("TEL", "<br> TEL");
            if (lblAddress.Text.Contains("Tel"))
                lblAddress.Text = lblAddress.Text.Replace("Tel", "<br> Tel");
            if (lblAddress.Text.Contains("TEL"))
                lblAddress.Text = lblAddress.Text.Replace("TEL", "<br> TEL");
            if (lblAddress1.Text.Contains("Fax"))
                lblAddress1.Text = lblAddress1.Text.Replace("Fax", "<br> Fax");
            if (lblAddress1.Text.Contains("FAX"))
                lblAddress1.Text = lblAddress1.Text.Replace("FAX", "<br> FAX");
            if (lblAddress.Text.Contains("Fax"))
                lblAddress.Text = lblAddress.Text.Replace("Fax", "<br> Fax");
            if (lblAddress.Text.Contains("FAX"))
                lblAddress.Text = lblAddress.Text.Replace("FAX", "<br> FAX");
            //if (lblAddress.Text.Contains("S.TAX NO"))
            //{
            //    int i = lblAddress.Text.IndexOf(",S.TAX NO");
            //    StaxNo = lblAddress.Text.Substring(i, lblAddress.Text.Length - i).TrimStart(',');
            //    addrs = lblAddress.Text.Replace(StaxNo, ".");
            //    addrs = addrs.Replace(",.", ".");
            //    //lblAddress1.Text = straddress.ToString();
            //    lblAddress1.Text = addrs;
            //    lblAddress.Text = addrs;
            //}
            //else
            //{
            //    lblAddress1.Text = straddress.ToString();
            //    lblAddress.Text = straddress.ToString();
            //}
            if (payment_mode == "1")
            {
                lblCheque.Visible = false;
                lblCash.Text = "in Cash";
            }
            else if (payment_mode == "2")
            {
                lblCash.Visible = false;
                lblCheque.Text = "in by Cheque.  Cheque No: " + dt.Rows[0]["Cheque_No"].ToString() + ", Bank: " + dt.Rows[0]["Bank_Name"].ToString() + ", Date: " + dt.Rows[0]["Cheque_Dated"].ToString();
            }



            if (strAirline_name == "MALAYSIA AIRLINES")
            {
                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA for MAS kargo, " + StaxNo;
            }

            else if (strAirline_name == "TURKISH AIRLINES")
            {
                lblAirlineStax.Text = "Ascent Air Pvt Ltd, " + StaxNo;
            }

            else if (strAirline_name == "AIR CHINA")
            {
                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd, " + StaxNo;
            }

            else if (strAirline_name == "KOREAN AIRLINES")
            {
                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO, " + StaxNo;
            }
            else if (strAirline_name == "KOREAN AIRLINES")
            {
                lblAirlineStax.Text = "Acumen Overseas Pvt Ltd GSA KOREAN AIR CARGO, " + StaxNo;
            }
            else if (strAirline_name == "MEGA MALDIVES AIRLINES")
            {
                lblAirlineStax.Text = "ATC SOFTWAY SOLUTIONS PVT LTD, " + StaxNo;
            }
            else
            {
                lblAirlineStax.Text = "Pace Express, " + StaxNo;
            }
            lblSno.Text = recipt_no.ToString();
            lblSnomum.Text = recipt_no.ToString();
            lblSnochennai.Text = recipt_no.ToString();
            lblSno2.Text = recipt_no.ToString();
            lblName.Text = to.ToString();
            lblName2.Text = to.ToString();
            Sno.Text = recipt_no.ToString();
            lblairlinename.Text = strAirline_name.ToString();
            if (Airline_id == "158")
            {
                //********************Updated on 19 Dec 2016******************
                if (FlightNo == "KE-9395" || FlightNo == "KE-9307" || FlightNo == "KE-9665" || FlightNo == "KE-3665" || FlightNo == "KE-0481" || FlightNo == "KE-481")
                {
                    lblAirlineNme.Text = "KOREAN AIR";
                    lblheadairlinename.Text = "KOREAN AIR";
                }
                else
                {

                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                }
                //********************End of Updated on 19 Dec 2016******************
                ////lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                ////lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
            }
            else if (Airline_id == "159")
            {
                if (FlightNo == "HY-127")
                {
                    lblAirlineNme.Text = "UZBEKISTAN AIRWAYS";
                    lblheadairlinename.Text = "UZBEKISTAN AIRWAYS";
                    lblairlinename.Text = "UZBEKISTAN AIRWAYS";
                }
                else
                {
                    lblAirlineNme.Text = "KOREAN AIR";
                    lblheadairlinename.Text = "KOREAN AIR";
                    lblairlinename.Text = "KOREAN AIR";
                }

            }
            else
            {
                lblAirlineNme.Text = strAirline_name.ToString();
                lblheadairlinename.Text = strAirline_name.ToString();
            }
            lblAwbno.Text = awbno.ToString();
            lblPcs.Text = pcs.ToString();
            ////////lblDate.Text = DateTime.Now.ToString("MMM dd yyyy hh:mmtt");

            //****************Added On 01_Mach_2011******
            lblDate.Text = issue_date;
            //***************End*************
            //lblDate.Text = DateTime.Now.ToString();
            lblcommdy.Text = contents.ToString();
            lblFlightno.Text = flt_no.ToString();
            //lblWt.Text = dt.Rows[0]["Charged_Weight"].ToString();

            lblWt.Text = dt.Rows[0]["Gross_Weight"].ToString();


            lbligmnr.Text = IGMNo.ToString();
            lblAwb2.Text = awbno.ToString();
            lbldate2.Text = issue_date.ToString();
            lblFlitno2.Text = flt_no.ToString();
            lblAirlinemame3.Text = strAirline_name.ToString();
            if (Airline_id == "147" || Airline_id == "153")
            {
                lblch.Visible = true;
                lblchwt.Visible = true;
                lblchwt.Text = dt.Rows[0]["Charged_Weight"].ToString();

                lblAirlinemame3.Text = "MASkargo";
                lblAirlineNme.Text = "MASkargo";
            }
            if (Airline_id == "159")
            {
                lblAirlinemame3.Text = "KOREAN AIR";

            }


            //******************Added On 1 feb 2011*********************
            if (dt.Rows[0]["freight_Type"].ToString() == "CC")
            {
                TrFreightChrgsCC.Visible = true;
                if (dt.Rows[0]["Total_Collection_CC"].ToString() == "")
                {
                    lblDOFrtChr.Text = "0";
                }
                else
                {
                    lblDOFrtChr.Text = dt.Rows[0]["Total_Collection_CC"].ToString();
                }


            }
            //****************************End*********************************************

            lblpartshipmentCase.Text = lblpartshipmentCase.Text + dtOldAwb.Rows[0]["recipt_no"].ToString();
        }
    }
}