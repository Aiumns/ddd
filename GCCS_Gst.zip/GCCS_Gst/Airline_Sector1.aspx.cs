using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;


public partial class Airline_Sector : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    //DataSet ds;
    SqlTransaction trans = null;
    string Sector_ID;
    string Airline_ID;
    string Airline_Name;
    string Sector_Name;
    int SectorId;
    string ts1;
    bool flag,flagChecked=false;
    string strRemove = null;
    string s1 = null;
    string s2 = null;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
       
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            lblmsg.Visible = false;
            flag = false;
            btnAdd1.Attributes.Add("onclick", "return CheckEmpty();");
            btnRemove.Attributes.Add("onclick", "return CheckEmpty1();");
            //if (!IsPostBack && Request.QueryString["Sector_ID"] != null)
            if (Request.QueryString["Sector_ID"] != null)
            {
                flag = true;
                lblSector.Text = txtSectorName.Text;
                //upDest();

            }
            bool con_flag = flag;

            if (flag)
            {

                lnkDestination.Visible = false;
                ddlAirlineName.Enabled = false;
                lbladd.Visible = false;
                lblupdate.Visible = true;
                btnUpdate.Visible = true;
                bthAdd.Visible = false;
                //lstDest.Visible = false;
                Label1.Visible = true;
                lnkDestination.Visible = false;
                lnkupDest.Visible = false;
                lstDest.Visible = true;
                lstDestAfter.Visible = true;
                //lnkDestination.Attributes.Add("onclick", "return CheckEmpty1();");
                //btnUpdate.Attributes.Add("onclick", "return CheckEmpty1();");
                Sector_ID = Convert.ToString(Request.QueryString["Sector_ID"]);
                //string str1 = "select Asm.Sector_Id as 'Sector_ID',AM.Airline_ID as 'Airline_ID',AM.Airline_Name as 'Airline_Name',AM.Airline_Code as 'Airline_Code',ASM.Sector_Name as 'Sector_Name'  from  Airline_Master AM inner join  Airline_sector_Master ASM on AM.Airline_ID=ASM.Airline_ID  where Sector_ID='" + Sector_ID + "' order by AM.AirLine_Name";

                
                ///////////Start:**************Modify By Hemant Sharma on 21 July 2014*****************************/////////////////////////////

                string str1 = " SELECT  Asm.Sector_Id as 'Sector_ID',AM.Airline_ID as 'Airline_ID',AM.Airline_Name as 'Airline_Name',AM.Airline_Code as 'Airline_Code',ASM.Sector_Name as 'Sector_Name'  FROM dbo.Airline_Master am INNER JOIN dbo.Airline_Detail ad ON ad.Airline_ID = am.Airline_ID INNER JOIN db_owner.Airline_Sector_Master asm ON asm.Airline_Detail_ID = ad.Airline_Detail_ID WHERE asm.Sector_ID=" + Sector_ID + "  ORDER BY am.Airline_Name";

                ///////////End:**************Modify By Hemant Sharma on 21 July 2014*****************************/////////////////////////////
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(str1, con);
                SqlDataReader dr = com.ExecuteReader();
                dr.Read();

                Airline_ID = dr["Airline_ID"].ToString();
                Airline_Name = dr["Airline_Name"].ToString();
                Sector_Name = dr["Sector_Name"].ToString();
                //txtairlinecode.Text = Airline_Code;
                //txtairlinename.Text = Airline_Name;
                txtSectorName.Text = Sector_Name;
                //lblSector.Text = Sector_Name.ToString();
                con.Close();
                selectData();
                //fillDest();
                //upDest();

            }
            else
            {

                lnkDestination.Attributes.Add("onclick", "return CheckEmpty();");
                bthAdd.Attributes.Add("onclick", "return CheckEmpty();");
                selectData();
                lstDest.Visible = false;
                lbladd.Visible = true;
                lblupdate.Visible = false;
                btnUpdate.Visible = false;
                bthAdd.Visible = true;
                Label1.Visible = false;
                lnkupDest.Visible = false;
                btnRemove.Visible = false;
                btnAdd1.Visible = false;
                lstDestAfter.Visible = false;

            }
        }
    }

    /// <summary>
    /// This Function  is used to bind the Airline Name in dropdownlist
    /// </summary>

    private void fillAirline()
    {
        con = new SqlConnection(strCon);
        try
        {

            string strQuery = "";
            strQuery = " select Airline_Name,Airline_Id from  Airline_Master order by Airline_Name";
            //strQuery = "select AM.Airline_Id,AM.Airline_Name from  Airline_Master AM inner join Airline_sector_Master ASM on AM.Airline_Id=ASM.Airline_Id ";
            con.Open();
            com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineName.Items.Clear();
            ddlAirlineName.Items.Add(new ListItem("Select Airline Name"));
            while (dr.Read())
            {

                ddlAirlineName.Items.Add(new ListItem(dr["Airline_Name"].ToString(), dr["Airline_Id"].ToString()));


            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

    /// <summary>
    /// This Function  is used to bind the Destination  in listBox
    /// </summary>
    private void fillDest()
    {       
        con = new SqlConnection(strCon);
        //string strQuery = "select ARM.Destination,DM.destination_Code from Agent_Rate_Master ARM inner join Destination_Master DM on DM.Destination_ID=ARM.Destination where Destination not in (select Destination_Id from Airline_Sector_Details where Sector_Id in (select Sector_Id from Airline_Sector_Master where Airline_ID='"+ddlAirlineName.SelectedItem.Value.Trim() +"')) order by destination_Name  ";//Generating Query
        //string strQuery = "select distinct ARM.Destination,DM.Destination_Name,DM.Destination_Code  from Agent_Rate_Master ARM inner join Airline_Detail AD on  AD.Airline_Detail_Id=ARM.Airline_Detail_Id inner join Destination_Master DM on DM.Destination_ID=ARM.Destination where Destination not in (select Destination_Id from Airline_Sector_Details where Sector_Id in(select Sector_Id from Airline_Sector_Master where Airline_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "'))order by destination_Name";//Generating Query
        string strQuery = "select distinct DM.Destination_Code,DM.Destination_Id from Airline_detail AD inner join Agent_Rate_Master ARM on ARM.Airline_Detail_Id=AD.Airline_Detail_Id inner join  destination_master DM on DM.Destination_Id=ARM.Destination WHERE AIRLINE_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "' AND DESTINATION NOT IN  (SELECT DESTINATION_ID FROM AIRLINE_SECTOR_DETAILS WHERE SECTOR_ID IN(SELECT SECTOR_ID FROM AIRLINE_SECTOR_MASTER WHERE AIRLINE_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "')) order by DM.Destination_Code";

        using (con)
        {
            try
            {
                con.Open();//Open Connection To Get Recodrs
                com = new SqlCommand(strQuery, con);//Giving Commands
                SqlDataReader dr = com.ExecuteReader();//Getting Records
                lstDest.Items.Clear();
                while (dr.Read())//Check For Records
                {
                    lstDest.Items.Add(new ListItem(dr["Destination_Code"].ToString(), dr["Destination_Id"].ToString()));//Adding AirLine Code To DropDown List.
                }
                if (lstDest.Items.Count <= 0)
                {
                    lstDest.Visible = false;
                    Label1.Visible = false;
                    lblmsg.Visible = true;
                    lblmsg.Text = " No Destination Exists of Airline " + ddlAirlineName.SelectedItem.Text.Trim() + " For  Sector " + txtSectorName.Text.Trim();
                }
                else
                {
                    lstDest.Visible = true;
                    Label1.Visible = true;
                    lblmsg.Visible = false;
                }
                con.Close();
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
               
    }

    /// <summary>
    /// This Function  is used to bind the Destination  in listbox in update case
    /// </summary>
    public void upDest()
    {   
         
            con = new SqlConnection(strCon);
            string strQuery = "select distinct DM.Destination_Code as 'Destination_Code', DM.Destination_Name as 'Destination_Name',ASD.Destination_ID as 'Destination_ID' from Airline_Sector_Details ASD inner join Destination_Master DM on  ASD.Destination_ID=DM.Destination_ID where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "' order by Destination_Name ";//Generating Query
              try
                {
                    con.Open();//Open Connection To Get Recodrs
                    com = new SqlCommand(strQuery, con);//Giving Commands
                    SqlDataReader dr = com.ExecuteReader();//Getting Records
                    lstDestAfter.Items.Clear();
                   while(dr.Read())//Check For Records
                   {
                       lstDestAfter.Items.Add(dr["Destination_Code"].ToString());
                   }
                   for (int i = 0; i < lstDestAfter.Items.Count; i++)
                   {
                       lstDestAfter.Items[i].Selected = true;
                   }
                    dr.Dispose();
                    con.Close();

                    con.Open();//Open Connection To Get Recodrs
                    //string str11 = "select  distinct AD.Airline_Id as 'Airline_Id',ARM.Destination as'Destination',DM.Destination_Name as 'Destination_Name',DM.Destination_Code as 'Destination_Code' from  Agent_Rate_Master ARM inner join Airline_Detail AD on ARM.Airline_Detail_Id=ARM.Airline_Detail_ID inner join Destination_Master DM on DM.Destination_Id=ARM.Destination WHERE AIRLINE_ID='" + ddlAirlineName.SelectedItem.Value + "' AND DESTINATION NOT IN  (SELECT DESTINATION_ID FROM AIRLINE_SECTOR_DETAILS WHERE SECTOR_ID IN(SELECT SECTOR_ID FROM AIRLINE_SECTOR_MASTER WHERE AIRLINE_ID='" + ddlAirlineName.SelectedItem.Value + "'))";
                    string str11 = "select distinct DM.Destination_Code,DM.Destination_Id from Airline_detail AD inner join Agent_Rate_Master ARM on ARM.Airline_Detail_Id=AD.Airline_Detail_Id inner join  destination_master DM on DM.Destination_Id=ARM.Destination WHERE AIRLINE_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "' AND DESTINATION NOT IN  (SELECT DESTINATION_ID FROM AIRLINE_SECTOR_DETAILS WHERE SECTOR_ID IN(SELECT SECTOR_ID FROM AIRLINE_SECTOR_MASTER WHERE AIRLINE_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "')) order by DM.Destination_Code";
                    com = new SqlCommand(str11, con);//Giving Commands
                    SqlDataReader dr1 = com.ExecuteReader();//Getting Records                
                    while (dr1.Read())//Check For Records
                    {
                        lstDest.Items.Add(dr1["Destination_Code"].ToString());
                    }
                    if (lstDest.Items.Count <= 0 && lstDestAfter.Items.Count <= 0)
                    {
                        btnAdd1.Visible = false;
                        btnRemove.Visible = false;
                        lstDestAfter.Visible = false;
                        lstDest.Visible = false;
                        Label1.Visible = false;
                        lblmsg.Visible = true;
                        lblmsg.Text = " No Destination Exists of Airline " + ddlAirlineName.SelectedItem.Text.Trim() + " For Sector " + txtSectorName.Text.Trim();

                    }
                    else
                    {
                        lstDest.Visible = true;
                        Label1.Visible = true;
                        lblmsg.Visible = false;
                    }
                    con.Close();                
                }
                catch (SqlException sqlex)
                {
                    string err = sqlex.ToString();
                }
                finally
                {
                    if (con != null || con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Airline_Sector_Master.aspx");
    }
    protected void bthAdd_Click(object sender, EventArgs e)
    {
        AddData();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        updateData();
    }
    public void selectData()
     {
        try
        {
            if (!Page.IsPostBack)
            {
                fillAirline();
                ddlAirlineName.SelectedIndex = ddlAirlineName.Items.IndexOf(ddlAirlineName.Items.FindByValue(Airline_ID));
                upDest();
                //lstDest.SelectedIndex = lstDest.Items.IndexOf(lstDest.Items.FindByValue(Destination_ID));
               
            }
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }

    }
    protected void lnkDestination_Click(object sender, EventArgs e)
    {
         //AddDest();
          fillDest();
        //ddlAirlineName.Enabled = false;

    }
    public void AddDest()
    {
        lnkDestination.Attributes.Add("onclick", "return CheckEmpty1();");
        con = new SqlConnection(strCon);//Making Connection
        try
        {
            con.Open();
            //string strSelect = "select DM.destination_Name from Agent_Rate_Master ARM inner join Destination_Master DM on DM.Destination_ID=ARM.Destination where Destination not in (select Destination_Id from Airline_Sector_Details where Sector_Id in (select Sector_Id from Airline_Sector_Master where Airline_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "')) order by destination_Name  ";//Generating Query
            string strSelect = "select distinct ARM.Destination,DM.Destination_Name from Agent_Rate_Master ARM inner join Airline_Detail AD on  AD.Airline_Detail_Id=ARM.Airline_Detail_Id inner join Destination_Master DM on DM.Destination_ID=ARM.Destination where Destination not in (select Destination_Id from Airline_Sector_Details where Sector_Id in (select Sector_Id from Airline_Sector_Master where Airline_ID='"+ ddlAirlineName.SelectedItem.Value + "')) order by destination_Name";//Generating Query
            da = new SqlDataAdapter(strSelect, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count <= 0)
            {
                Label1.Visible = false;
                lstDest.Visible = false;
                //bthAdd.Visible = false;
                //btnUpdate.Visible = true;
                //lbladd.Visible = false;
                //lblupdate.Visible = true;
                lblmsg.Text = " Detination Name  does not exists for Airline  " + ddlAirlineName.SelectedItem.Text.Trim();


            }
            else
            {            
                Label1.Visible = true;
                lstDest.Visible = true;
            }

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void AddData()
    {
        //bthAdd.Attributes.Add("onclick", "return CheckEmpty();");
        con = new SqlConnection(strCon);//Making Connection
        try
        {
            con.Open();
            string strSelect = "select Sector_Name from Airline_Sector_Master where Airline_Id='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + txtSectorName.Text.Trim() + "'";
            da = new SqlDataAdapter(strSelect, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (lstDest.Items.Count > 0)
                {
                    string str1 = "select Asm.Sector_Id as 'Sector_ID',AM.Airline_ID as 'Airline_ID',AM.Airline_Name as 'Airline_Name',AM.Airline_Code as 'Airline_Code',ASM.Sector_Name as 'Sector_Name'  from  Airline_Master AM inner join  Airline_sector_Master ASM on AM.Airline_ID=ASM.Airline_ID where AM.Airline_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and ASM.Sector_Name='"+ txtSectorName.Text.Trim() +"'  order by AM.AirLine_Name";
                    con = new SqlConnection(strCon);
                    con.Open();
                    com = new SqlCommand(str1, con);
                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();

                    string SID = dr["Sector_Id"].ToString();                                  
                    con.Close();
                    string insertQ1;
                    con = new SqlConnection(strCon);//Making Connection

                    try
                    {
                        con.Open();
                        trans = con.BeginTransaction();                                                                             // Insert Value in Airline_Sector_Master table

                        //insertQ = "INSERT INTO Airline_Sector_Master (Sector_Name,Airline_Id)values('" + txtSectorName.Text.Trim() + "','" + ddlAirlineName.SelectedItem.Value + "')";
                        //com = new SqlCommand(insertQ, con, trans);
                        //com.ExecuteNonQuery();
                        // Find Sector_ID
                        //string selectQ;
                        //selectQ = "select max(Sector_ID) From Airline_Sector_Master ";
                        //com = new SqlCommand(selectQ, con, trans);
                        //SectorId = Convert.ToInt32(com.ExecuteScalar().ToString());

                        // Insert into Airline_Sector_Details
                        for (int i = 0; i < lstDest.Items.Count; i++)    // values store in listbox
                        {
                            if (lstDest.Items[i].Selected)
                            {

                                ts1 = lstDest.Items[i].Value;
                                insertQ1 = "insert into Airline_Sector_Details(Sector_ID,Destination_ID)values('" + SID.ToString() + "','" + ts1 + "')";
                                com = new SqlCommand(insertQ1, con, trans);
                                com.ExecuteNonQuery();

                            }
                        }
                        trans.Commit();
                        con.Close();

                        Response.Redirect("Airline_Sector_Master.aspx");

                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;

                        trans.Rollback();
                        lblmsg.Text = err;
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    }

                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = " Sector Name " + txtSectorName.Text.Trim() + " already exists for Airline  " + ddlAirlineName.SelectedItem.Text.Trim();
                    //Label1.Visible = true;
                    //lstDest.Visible = true;
                }


            }
            else
            {
                if (lstDest.Items.Count <= 0)
                {
                    con.Open();//Open Connection
                    // Insert Value in Airline_Sector_Master table
                    string strQuery = "INSERT INTO Airline_Sector_Master (Sector_Name,Airline_Id)values('" + txtSectorName.Text.Trim() + "','" + ddlAirlineName.SelectedItem.Value + "')";//Giving Connection String.
                    com = new SqlCommand(strQuery, con);
                    com.ExecuteNonQuery();
                    com.Dispose();
                    con.Close();
                    Response.Redirect("Airline_Sector_Master.aspx");
                }
                else
                {
                    string insertQ, insertQ1;
                    con = new SqlConnection(strCon);//Making Connection

                    try
                    {
                        con.Open();
                        trans = con.BeginTransaction();                                                                             // Insert Value in Airline_Sector_Master table

                        insertQ = "INSERT INTO Airline_Sector_Master (Sector_Name,Airline_Id)values('" + txtSectorName.Text.Trim() + "','" + ddlAirlineName.SelectedItem.Value + "')";
                        com = new SqlCommand(insertQ, con, trans);
                        com.ExecuteNonQuery();
                        // Find Sector_ID
                        string selectQ;
                        selectQ = "select max(Sector_ID) From Airline_Sector_Master ";
                        com = new SqlCommand(selectQ, con, trans);
                        SectorId = Convert.ToInt32(com.ExecuteScalar().ToString());

                        // Insert into Airline_Sector_Details
                        for (int i = 0; i < lstDest.Items.Count; i++)    // values store in listbox
                        {
                            if (lstDest.Items[i].Selected)
                            {

                                ts1 = lstDest.Items[i].Value;
                                insertQ1 = "insert into Airline_Sector_Details(Sector_ID,Destination_ID)values('" + SectorId + "','" + ts1 + "')";
                               com = new SqlCommand(insertQ1, con, trans);
                                com.ExecuteNonQuery();

                            }
                        }
                        trans.Commit();
                        con.Close();

                        Response.Redirect("Airline_Sector_Master.aspx");

                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;

                        trans.Rollback();
                        lblmsg.Text = err;
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    }
                }

            }
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

    public void updateData()
    {
        //btnUpdate.Attributes.Add("onclick", "return CheckEmpty();");        
        con = new SqlConnection(strCon);//Making Connection  
        try
        {
             s1 = txtSectorName.Text;
             s2 = lblSector.Text;
            if (s1 == s2)
            {
                if (lstDestAfter.Items.Count >= 0)
                {
                    string strSelect = "select Sector_ID,Sector_Name from Airline_Sector_Master where Airline_Detail_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + txtSectorName.Text.Trim() + "'";

                    da = new SqlDataAdapter(strSelect, con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    con.Close();
                    if (ds.Tables[0].Rows.Count >= 0)
                    {
                        con.Open();
                        string strDel = "delete from Airline_Sector_Details where Sector_ID in(select Sector_ID from Airline_Sector_Master where Airline_Detail_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + txtSectorName.Text.Trim() + "')";
                        com = new SqlCommand(strDel, con);
                        com.ExecuteNonQuery();
                        com.Dispose();
                        con.Close();
                        string str1 = "select Sector_ID,Sector_Name from Airline_Sector_Master where Airline_Detail_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + txtSectorName.Text.Trim() + "'";

                        con = new SqlConnection(strCon);
                        con.Open();
                        com = new SqlCommand(str1, con);
                        SqlDataReader dr = com.ExecuteReader();
                        dr.Read();
                        string SID = dr["Sector_Id"].ToString();
                        con.Close();
                        con = new SqlConnection(strCon);//Making Connection
                        string insertQ, insertQ1;
                        try
                        {
                            con.Open();
                            trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table

                            insertQ = "update Airline_Sector_Master set Sector_Name='" + txtSectorName.Text.Trim() + "',Airline_Detail_ID='" + ddlAirlineName.SelectedItem.Value + "'  where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";
                            com = new SqlCommand(insertQ, con, trans);
                            com.ExecuteNonQuery();

                            // Insert into Airline_Sector_Details
                            for (int i = 0; i < lstDestAfter.Items.Count; i++)    // values store in listbox
                            {
                                //if (lstDestAfter.Items[i].Selected)
                                //{  
                                    // con.Open();
                                    string strDest = "select Destination_ID,Destination_Code from Destination_Master where Destination_Code='" + lstDestAfter.Items[i].Value + "'";
                                   com = new SqlCommand(strDest, con,trans);
                                  SqlDataReader dr11 = com.ExecuteReader();
                                  dr11.Read();
                                  string DID = dr11["Destination_ID"].ToString();
                                  dr11.Dispose();
                                  //ts1 = lstDest.Items[i].Value;
                                    insertQ1 = "insert into Airline_Sector_Details(Sector_ID,Destination_ID)values('" + SID.ToString() + "','" + DID + "')";
                                    com = new SqlCommand(insertQ1, con, trans);
                                    com.ExecuteNonQuery();

                                //}
                            }
                            trans.Commit();
                            con.Close();

                            Response.Redirect("Airline_Sector_Master.aspx");

                        }
                        catch (SqlException se)
                        {
                            string err = se.Message;
                            trans.Rollback();
                            lblmsg.Text = err;
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }

                   }

                }

            }

            else
            {
                if (lstDestAfter.Items.Count >= 0)
                {
                    string strSelect = "select Sector_ID,Sector_Name from Airline_Sector_Master where Airline_Detail_ID='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + lblSector.Text.Trim() + "'";

                    da = new SqlDataAdapter(strSelect, con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    con.Close();
                    if (ds.Tables[0].Rows.Count <= 0)
                    {
                        con.Open();
                        string strDel = "delete from Airline_Sector_Details where Sector_ID in(select Sector_ID from Airline_Sector_Master where Airline_Id='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + lblSector.Text.Trim() + "')";
                        com = new SqlCommand(strDel, con);
                        com.ExecuteNonQuery();
                        com.Dispose();
                        con.Close();
                        string str1 = "select Sector_ID,Sector_Name from Airline_Sector_Master where Airline_Id='" + ddlAirlineName.SelectedItem.Value.Trim() + "' or Sector_Name='" + lblSector.Text.Trim() + "'";

                        con = new SqlConnection(strCon);
                        con.Open();
                        com = new SqlCommand(str1, con);
                        SqlDataReader dr = com.ExecuteReader();
                        dr.Read();
                        string SID = dr["Sector_Id"].ToString();
                        con.Close();
                        con = new SqlConnection(strCon);//Making Connection
                        string insertQ, insertQ1;
                        try
                        {
                            con.Open();
                            trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table

                            insertQ = "update Airline_Sector_Master set Sector_Name='" + lblSector.Text.Trim() + "',Airline_Id='" + ddlAirlineName.SelectedItem.Value + "'  where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";
                            com = new SqlCommand(insertQ, con, trans);
                            com.ExecuteNonQuery();

                            // Insert into Airline_Sector_Details
                            for (int i = 0; i < lstDestAfter.Items.Count; i++)    // values store in listbox
                            {
                                //if (lstDestAfter.Items[i].Selected)
                                //{
                                    // con.Open();
                                string strDest = "select Destination_ID from Destination_Master where Destination_Code='" + lstDestAfter.Items[i].Value + "'";
                                    com = new SqlCommand(strDest, con, trans);
                                    SqlDataReader dr11 = com.ExecuteReader();
                                    dr11.Read();
                                    string DID = dr11["Destination_ID"].ToString();
                                    dr11.Dispose();
                                    //ts1 = lstDest.Items[i].Value;
                                    insertQ1 = "insert into Airline_Sector_Details(Sector_ID,Destination_ID)values('" + SID.ToString() + "','" + DID + "')";
                                    com = new SqlCommand(insertQ1, con, trans);
                                    com.ExecuteNonQuery();

                                //}
                            }
                            trans.Commit();
                            con.Close();

                            Response.Redirect("Airline_Sector_Master.aspx");

                        }
                        catch (SqlException se)
                        {
                            string err = se.Message;
                            trans.Rollback();
                            lblmsg.Text = err;
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }

                    }

                    else
                    {   
                       s1 = txtSectorName.Text;
                       s2 = lblSector.Text;
                        if (s1 != s2)
                        {
                            if (lstDest.Items.Count <= 0 && lstDestAfter.Items.Count <= 0)
                            {
                                lblmsg.Visible = true;
                                lblmsg.Text = " Sector Name " + lblSector.Text.Trim() + " Alredy Exist For Airline " + ddlAirlineName.SelectedItem.Text.Trim();
                                lstDest.Visible = false;
                                lstDestAfter.Visible = false;
                                Label1.Visible = false;
;
                            }
                            else
                            {
                                lblmsg.Visible = true;
                                lblmsg.Text = " Sector Name " + lblSector.Text.Trim() + " Alredy Exist For Airline " + ddlAirlineName.SelectedItem.Text.Trim();
                            }
                        }
                        
                    }
                }
            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }

        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
        //btnUpdate.Attributes.Add("onclick", "return CheckEmpty();");
        //con = new SqlConnection(strCon);//Making Connection       
        //try
        //{
        //    string s1 = txtSectorName.Text;
        //    string s2 = lblSector.Text;
        //    if (s1 == s2)
        //    {
        //        if (lstDest.Items.Count <= 0)
        //        {
        //            con.Open();//Open Connection
        //            // Insert Value in Airline_Sector_Master table
        //            string strQuery = "update Airline_Sector_Master set Sector_Name='" + txtSectorName.Text.Trim() + "',Airline_Id='" + ddlAirlineName.SelectedItem.Value + "'  where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";//Giving Connection String.
        //            com = new SqlCommand(strQuery, con);
        //            com.ExecuteNonQuery();
        //            com.Dispose();
        //            con.Close();
        //            Response.Redirect("Airline_Sector_Master.aspx");
        //        }
        //        else
        //        {
        //            string upstr1, upstr2;
        //            con = new SqlConnection(strCon);//Making Connection

        //            try
        //            {
        //                con.Open();
        //                trans = con.BeginTransaction();                                                                             // Insert Value in Airline_Sector_Master table

        //                upstr1 = "update Airline_Sector_Master set Sector_Name='" + txtSectorName.Text.Trim() + "',Airline_Id='" + ddlAirlineName.SelectedItem.Value + "'  where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";
        //                com = new SqlCommand(upstr1, con, trans);
        //                com.ExecuteNonQuery();
        //                // Find Sector_ID
        //                string selectQ;
        //                selectQ = "select max(Sector_ID) From Airline_Sector_Master ";
        //                com = new SqlCommand(selectQ, con, trans);
        //                SectorId = Convert.ToInt32(com.ExecuteScalar().ToString());

        //                // Insert into Airline_Sector_Details
        //                for (int i = 0; i < lstDest.Items.Count; i++)    // values store in listbox
        //                {
        //                    if (lstDest.Items[i].Selected)
        //                    {

        //                        ts1 = lstDest.Items[i].Value;
        //                        upstr2 = "update Airline_Sector_Details set Sector_ID='" + SectorId + "',Destination_ID='" + ts1 + "' where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";
        //                        com = new SqlCommand(upstr2, con, trans);
        //                        com.ExecuteNonQuery();

        //                    }
        //                }
        //                trans.Commit();
        //                con.Close();
        //                Response.Redirect("Airline_Sector_Master.aspx");

        //            }
        //            catch (SqlException se)
        //            {
        //                string err = se.Message;
        //            }
        //        }
        //    }

        //    else
        //    {
        //        try
        //        {
        //            con.Open();
        //            txtSectorName.Text = lblSector.Text;
        //            string strSelect = "select Sector_Name from Airline_Sector_Master where Airline_Id='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + txtSectorName.Text.Trim() + "'";
        //            da = new SqlDataAdapter(strSelect, con);
        //            DataSet ds = new DataSet();
        //            da.Fill(ds);
        //            con.Close();
        //            if (ds.Tables[0].Rows.Count <= 0)
        //            {
        //                if (lstDest.Items.Count <= 0)
        //                {
        //                    con.Open();//Open Connection
        //                    // Insert Value in Airline_Sector_Master table
        //                    string strQuery = "update Airline_Sector_Master set Sector_Name='" + txtSectorName.Text.Trim() + "',Airline_Id='" + ddlAirlineName.SelectedItem.Value + "'  where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";//Giving Connection String.
        //                    com = new SqlCommand(strQuery, con);
        //                    com.ExecuteNonQuery();
        //                    com.Dispose();
        //                    con.Close();
        //                    Response.Redirect("Airline_Sector_Master.aspx");
        //                }
        //                else
        //                {
        //                    string upstr1, upstr2;
        //                    con = new SqlConnection(strCon);//Making Connection

        //                    try
        //                    {
        //                        con.Open();
        //                        trans = con.BeginTransaction();                                                                             // Insert Value in Airline_Sector_Master table

        //                        upstr1 = "update Airline_Sector_Master set Sector_Name='" + txtSectorName.Text.Trim() + "',Airline_Id='" + ddlAirlineName.SelectedItem.Value + "'  where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";
        //                        com = new SqlCommand(upstr1, con, trans);
        //                        com.ExecuteNonQuery();
        //                        // Find Sector_ID
        //                        string selectQ;
        //                        selectQ = "select max(Sector_ID) From Airline_Sector_Master ";
        //                        com = new SqlCommand(selectQ, con, trans);
        //                        SectorId = Convert.ToInt32(com.ExecuteScalar().ToString());

        //                        // Insert into Airline_Sector_Details
        //                        for (int i = 0; i < lstDest.Items.Count; i++)    // values store in listbox
        //                        {
        //                            if (lstDest.Items[i].Selected)
        //                            {

        //                                ts1 = lstDest.Items[i].Value;
        //                                upstr2 = "update Airline_Sector_Details set Sector_ID='" + SectorId + "',Destination_ID='" + ts1 + "' where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "'";
        //                                com = new SqlCommand(upstr2, con, trans);
        //                                com.ExecuteNonQuery();

        //                            }
        //                        }
        //                        trans.Commit();
        //                        con.Close();
        //                        Response.Redirect("Airline_Sector_Master.aspx");

        //                    }
        //                    catch (SqlException se)
        //                    {
        //                        string err = se.Message;
        //                    }
        //                }
        //            }

        //            else
        //            {
        //                bthAdd.Visible = false;
        //                btnUpdate.Visible = true;
        //                lblupdate.Visible = true;
        //                lbladd.Visible = false;
        //                lblmsg.Text = " Sector Name " + txtSectorName.Text.Trim() + " already exists for Airline  " + ddlAirlineName.SelectedItem.Text.Trim();

        //                //lbladd.Visible = false;
        //                //lblupdate.Visible = true;
        //            }
        //        }

        //        catch (SqlException se)
        //        {
        //            string err = se.Message;
        //        }

        //    }

        //}

        //catch (SqlException se)
        //{
        //    string err = se.Message;
        //}

        //finally
        //{
        //    if (con != null && con.State == ConnectionState.Open)
        //        con.Close();

        //}
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {     
            upDest();          
    }
    protected void btnAdd1_Click(object sender, EventArgs e)
    {
        if (lstDest.Items.Count > 0)
        {
            for (int k=0; k < lstDest.Items.Count; k++)
            {
                if (lstDest.Items[k].Selected == true)
                {
                    flagChecked = true;
                    break;
                }
                else
                {
                    flagChecked = false;
                    //lblmsg.Visible = true;
                    //lblmsg.Text = "plz select Destination";
                    //break;
                }

            }
            if (flagChecked==true)
            {
                for (int i = 0; i < lstDest.Items.Count; i++)    // values store in listbox
                {
                    if (lstDest.Items[i].Selected == true)
                    {
                        
                        lstDestAfter.Items.Add(new ListItem(lstDest.Items[i].ToString()));
                        strRemove = strRemove + (new ListItem(lstDest.Items[i].ToString())) + ",";                                  }                    
                }
                strRemove = strRemove.Remove(strRemove.LastIndexOf(','));
                string[] strRemoveArray = strRemove.Split(',');
                for (int i = 0; i < strRemoveArray.Length; i++)
                {
                    lstDest.Items.Remove(strRemoveArray[i]);
                }
            }
            
        } 
    }
    protected void btnRemove_Click(object sender, EventArgs e)
    {
        if (lstDestAfter.Items.Count > 0)
        {
            for (int k = 0; k < lstDestAfter.Items.Count; k++)
            {
                if (lstDestAfter.Items[k].Selected == true)
                {
                    flagChecked = true;
                    break;
                }
                else
                {
                    flagChecked = false;
                    //lblmsg.Visible = true;
                    //lblmsg.Text = "plz select Destination";
                    //break;
                }

            }
            if (flagChecked == true)
            {
                for (int i = 0; i < lstDestAfter.Items.Count; i++)    // values store in listbox
                {
                    if (lstDestAfter.Items[i].Selected == true)
                    {
                        lstDest.Items.Add(new ListItem(lstDestAfter.Items[i].ToString()));
                        strRemove = strRemove + (new ListItem(lstDestAfter.Items[i].ToString())) + ",";
                    }
                }
                strRemove = strRemove.Remove(strRemove.LastIndexOf(','));
                string[] strRemoveArray = strRemove.Split(',');
                for (int i = 0; i < strRemoveArray.Length; i++)
                {
                    lstDestAfter.Items.Remove(strRemoveArray[i]);
                }
            }

        }
    }
    protected void ddlAirlineName_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtSectorName.Text = "";
        lstDest.SelectedIndex = -1;
    }
}
