using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//Created by Rakhi on 22 Oct 2007
//Last Modified by Alok on date:07.11.2007
//Last Modified byhn mishra on date:28.01.2008
public partial class Airlines_Details_Add1 : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    SqlTransaction trans = null;
    public int id;
    string Airline_ID;
    public string strCurrency = "";
    string ts1;
    //int Airline_Detail_ID;
    DisplayWrap dw = new DisplayWrap();
    string aID;

    protected void Page_Load(object sender, EventArgs e)
    {
        strCurrency = "<script>var CurrencyArray=new Array(" + Currency() + ")</script>";
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                rb1.SelectedValue = "13";
                rb2.SelectedValue = "Gross Wt.";
                rb3.SelectedValue = "13";
                rb4.SelectedValue = "Gross Wt.";
                rb5.SelectedValue = "13";
                rb6.SelectedValue = "Gross Wt.";
                txtgsacomm.Text = "0";

            }


            if (!Page.IsPostBack && Request.QueryString["Airline_Detail_ID"] != null)
            {
                btnupdate.Attributes.Add("onclick", "return CheckEmpty1()");
                btnupdate.Visible = true;
                btnadd.Visible = false;
                lblAdd.Visible = false;
                lblUpdate.Visible = true;
               

                ddlAirlineNamePlusCode();
                //FillddlCompany();
               
                FillddlCompany1();
                //ddlCityNamePlusCode();
                ddlCityNamePlusCode1();
                FillddlStatus();
                selectData();
                //FillddlCompany();
                //fillSlab();
                upDest();
                lblcity.Text = ddlCity.SelectedItem.Value;

                ddlAirlineCode.Enabled = false;
                ddlCompany.Enabled = false;
            }
            else if (!Page.IsPostBack && Request.QueryString["Airline_Detail_ID"] == null)
            {
                btnupdate.Visible = false;
                btnadd.Visible = true;
                lblAdd.Visible = true;
                lblUpdate.Visible = false;
                btnadd.Attributes.Add("onclick", "return CheckEmpty()");

                if (!Page.IsPostBack)
                {
                    ddlAirlineNamePlusCode();
                    //FillddlCompany();
                    //ddlCityNamePlusCode1();
                    FillddlStatus();
                    fillSlab();
                }
             

            }

        }
        btnadd.Attributes.Add("onclick", "return CheckEmpty()");
    }
    public string Currency()
    {
        string strTemp1 = "";
        con = new SqlConnection(strCon);
       
        try
        {
            cmd = new SqlCommand("Alc_BindCurrency", con);
            cmd.CommandType = CommandType.StoredProcedure; ;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp1 == "")
                    strTemp1 = "'" + Convert.ToString(dr["CurrencyCode"]).ToString().ToUpper().Trim() + "'";
                else
                    strTemp1 = strTemp1 + "," + "'" + Convert.ToString(dr["CurrencyCode"]).ToString().ToUpper().Trim() + "'";
            }
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp1;
    }


    
    public void ddlAirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            strQuery = "Select Airline_ID,Airline_Code,Airline_Name from Airline_Master where Status='2' order by Airline_Name";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineCode.Items.Clear();
            ddlAirlineCode.Items.Add(new ListItem("Select Airline"));
           
            while (dr.Read())
            {
                ddlAirlineCode.Items.Add(new ListItem(dr["Airline_Name"].ToString() + " (" + (dr["Airline_Code"].ToString()) + ")", dr["Airline_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    private void FillddlCompany1()
    {

        con = new SqlConnection(strCon);
        con.Open();

        string Airline_Detail_ID = Convert.ToString(Request.QueryString["Airline_Detail_ID"]);
        DataTable dtAirline = new DataTable();
        cmd = new SqlCommand("select * from Airline_Detail where Airline_Detail_ID='" + Airline_Detail_ID + "'");
        cmd.Connection = con;
        da = new SqlDataAdapter(cmd);
        da.Fill(dtAirline);
        if (dtAirline.Rows.Count > 0)
        {

            //aID = dtAirline.Rows[0]["Airline_ID"].ToString();
            ddlAirlineCode.SelectedValue = dtAirline.Rows[0]["Airline_ID"].ToString();
        }
        con.Close();
        con = new SqlConnection(strCon);
        try
        {
            string Airline_ID = ddlAirlineCode.SelectedValue.ToString();
            con = new SqlConnection(strCon);
            SqlCommand com = new SqlCommand("select distinct AM.Company_ID 'Company_ID',AM.Airline_Name,AM.Airline_ID,CM.Company_name as 'Company_Name' from Airline_Master AM  inner join company_master Cm on CM.Company_id=Am.Company_ID where AM.Airline_ID='" + Airline_ID + "' and CM.Status='2'", con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            ddlCompany.Items.Clear();
            ddlCompany.Items.Add(new ListItem("Select Company"));
            while (dr.Read())
            {

                ddlCompany.Items.Add(new ListItem(dr["Company_Name"].ToString(), dr["Company_ID"].ToString()));
            }
            dr.Close();
            con.Close();
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    private void FillddlCompany()
    {

            con = new SqlConnection(strCon);
            try
            {
                string Airline_ID = ddlAirlineCode.SelectedValue.ToString();
                con = new SqlConnection(strCon);
                //SqlCommand com = new SqlCommand("select CM.Company_ID as 'Company_ID',CM.Company_Name as 'Company_Name' from company_master CM inner join Airline_Master AM on CM.Company_ID=AM.Company_ID where AM.Airline_ID='" + Airline_ID + "' and CM.Status='2'", con);
                SqlCommand com = new SqlCommand("select distinct AM.Company_ID 'Company_ID',AM.Airline_Name,AM.Airline_ID,CM.Company_name as 'Company_Name' from Airline_Master AM  inner join company_master Cm on CM.Company_id=Am.Company_ID where AM.Airline_ID='" + Airline_ID + "' and CM.Status='2'", con);
                con.Open();
                SqlDataReader dr = com.ExecuteReader();
                ddlCompany.Items.Clear();
                ddlCompany.Items.Add(new ListItem("Select Company"));
                while (dr.Read())
                {

                    ddlCompany.Items.Add(new ListItem(dr["Company_Name"].ToString(), dr["Company_ID"].ToString()));
                }
                dr.Close();
                con.Close();
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

    /// <summary>
    /// This Function  is used to bind the Destination  CheckBox in update case
    /// </summary>
    
    public void upDest()
    {

        con = new SqlConnection(strCon);
        //string strQuery = "select distinct DM.Destination_Name as 'Destination_Name',DM.Destination_Code as 'Destination_Code',ASD.Destination_ID as 'Destination_ID' from Airline_Sector_Details ASD inner join Destination_Master DM on  ASD.Destination_ID=DM.Destination_ID where Sector_ID='" + Convert.ToString(Request.QueryString["Sector_ID"]) + "' order by Destination_Name ";//Generating Query
        string strQuery = "select SM.Slab_Name as 'Slab_Name',SM.Slab_Id as 'Slab_Id' from slab_Master SM inner join airline_slab ARS on  ARS.slab_ID=SM.Slab_ID where Airline_detail_id='" + Convert.ToString(Request.QueryString["Airline_detail_id"]) + "' order by Slab_Start ";//Generating Query

        try
        {
            con.Open();//Open Connection To Get Recodrs
            cmd = new SqlCommand(strQuery, con);//Giving Commands
            SqlDataReader dr = cmd.ExecuteReader();//Getting Records
            chklist.Items.Clear();
            while (dr.Read())//Check For Records
            {
                chklist.Items.Add(dr["Slab_Name"].ToString());
            }
            for (int i = 0; i < chklist.Items.Count; i++)
            {
                chklist.Items[i].Selected = true;
            }
            dr.Dispose();
            con.Close();

            con.Open();//Open Connection To Get Recodrs
            string str11 = "select Slab_Name,Slab_Id from Slab_Master where Slab_Id not in (select distinct SM.Slab_Id as 'Slab_Id' from slab_Master SM inner join airline_slab ARS on  ARS.slab_ID=SM.Slab_ID where Airline_detail_id='" + Convert.ToString(Request.QueryString["Airline_detail_id"]) + "') order by Slab_Start";//Generating Query
            
            //string str11 = "select distinct SM.Slab_Name as 'Slab_Name',SM.Slab_Id as 'Slab_Id' from slab_Master SM inner join airline_slab ARS on  ARS.slab_ID=SM.Slab_ID where Airline_detail_id !='" + Convert.ToString(Request.QueryString["Airline_detail_id"]) + "'";
            
            cmd = new SqlCommand(str11, con);//Giving Commands
            SqlDataReader dr1 = cmd.ExecuteReader();//Getting Records                
            while (dr1.Read())//Check For Records
            {
                chklist.Items.Add(dr1["Slab_Name"].ToString());
            }

            con.Close();
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    
    public void ddlCityNamePlusCode()
    {

        con = new SqlConnection(strCon);
        con.Open();
          try
          {
            string strQuery = "";
           
            //strQuery = "select  CM1.company_ID as 'company_ID',CM.city_id as 'city_id',Cm.City_Code as 'City_Code',CM.city_Name as 'city_Name' from city_master CM inner join Company_Master CM1 on CM.city_id=CM1.City where  company_ID='" + ddlCompany.SelectedItem.Value + "'";
            strQuery = "select * from city_master where city_id in(select city from company_master where (company_ID='" + ddlCompany.SelectedItem.Value + "' and parent_id='0') or parent_id='" + ddlCompany.SelectedItem.Value + "') ";

            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlCity.Items.Clear();
            ddlCity.Items.Add(new ListItem("Select City"));
            while (dr.Read())
            {
                ddlCity.Items.Add(new ListItem(dr["City_Name"].ToString() + "-" + (dr["City_Code"].ToString()), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void ddlCityNamePlusCode1()
    {
        string cid = null;
        string bid=null;
        con = new SqlConnection(strCon);
        con.Open();

        string Airline_Detail_ID = Convert.ToString(Request.QueryString["Airline_Detail_ID"]);
        DataTable dtAirline = new DataTable();
        cmd = new SqlCommand("select * from Airline_Detail where Airline_Detail_ID='" + Airline_Detail_ID + "'");
        cmd.Connection = con;
        da = new SqlDataAdapter(cmd);
        da.Fill(dtAirline);
        if (dtAirline.Rows.Count > 0)
        {

            //aID = dtAirline.Rows[0]["Airline_ID"].ToString();
            ddlAirlineCode.SelectedValue = dtAirline.Rows[0]["Airline_ID"].ToString();
            cid = dtAirline.Rows[0]["company_ID"].ToString();
            bid = dtAirline.Rows[0]["Belongs_To_City"].ToString();

        }
        con.Close();
        try
        {
            string strQuery = "";
            Airline_ID = ddlAirlineCode.SelectedValue.ToString();
            strQuery = "select * from city_master where city_id in(select city from company_master where (company_ID='" + cid + "' and parent_id='0') or parent_id='" + cid + "') ";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlCity.Items.Clear();
            ddlCity.Items.Add(new ListItem("Select City"));
            while (dr.Read())
            {
                ddlCity.Items.Add(new ListItem(dr["City_Name"].ToString() + "-" + (dr["City_Code"].ToString()), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    
    private void FillddlStatus()
    {
        con = new SqlConnection(strCon);
        SqlCommand com = new SqlCommand("select Status_Name,Status_ID from Status_Master where Status_Name in( 'Active','Inactive') ", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        //ddlStatus.Items.Add("--Select--");
        //ddlStatus.Items[0].Value = "";
        while (dr.Read())
        {

            ddlStatus.Items.Add(new ListItem(dr["Status_Name"].ToString(), dr["Status_ID"].ToString()));
        }
        dr.Close();
        con.Close();
    }

    private void fillSlab()
    {
        con = new SqlConnection(strCon);
        try
        {

            string strQuery = "";
            strQuery = "select Slab_Id,Slab_Name from slab_Master order by Slab_start";
            con.Open();
            cmd = new SqlCommand(strQuery, con);
            SqlDataReader dr = cmd.ExecuteReader();
            //ddlStatus.Items.Clear();
            //ddlStatus.Items.Add(new ListItem("Select Status"));
            while (dr.Read())
            {

              chklist.Items.Add(new ListItem(dr["Slab_Name"].ToString(), dr["Slab_Id"].ToString()));


            }
            con.Close();
            //if (dr["Slab_Id"] == '4')
            //{
             
            //}
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

    public void selectData()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            string Airline_Detail_ID = Convert.ToString(Request.QueryString["Airline_Detail_ID"]);
            DataTable dtAirline = new DataTable();
            cmd = new SqlCommand("select * from Airline_Detail where Airline_Detail_ID='" + Airline_Detail_ID + "'");
            cmd.Connection = con;
            da = new SqlDataAdapter(cmd);
            da.Fill(dtAirline);
            if (dtAirline.Rows.Count > 0)
            {

                //ddlCompany.Items.Clear();
                //aID = dtAirline.Rows[0]["Airline_ID"].ToString();
                ddlAirlineCode.SelectedValue = dtAirline.Rows[0]["Airline_ID"].ToString();
                ddlCompany.SelectedValue = dtAirline.Rows[0]["Company_ID"].ToString();
                ddlCity.SelectedValue = dtAirline.Rows[0]["Belongs_To_City"].ToString();
                txtBankName.Text = dtAirline.Rows[0]["Bank_Name"].ToString();
                txtbankaddress.Text = dtAirline.Rows[0]["Bank_Address"].ToString();
                txtAccountName.Text = dtAirline.Rows[0]["Acc_Name"].ToString();
                txtAccountNumber.Text = dtAirline.Rows[0]["Acc_No"].ToString();
                txtDueAgent.Value = dtAirline.Rows[0]["AWB_Fees"].ToString();
                txtDueCarrier.Value = dtAirline.Rows[0]["ACI_Fees"].ToString();
                txtgsacomm.Text = dtAirline.Rows[0]["GSAComm_Rate"].ToString();
                txtDisBursementCharges.Value = dtAirline.Rows[0]["DisBursementCharges"].ToString();
                rb1.SelectedValue = dtAirline.Rows[0]["FreightSurCharge_Charged"].ToString();
                if (dtAirline.Rows[0]["FreightSurCharge_Charged"].ToString() == "14")
                {
                    rb2.Enabled = false;
                }
                rb2.SelectedValue = dtAirline.Rows[0]["FreightSurCharge_On"].ToString();
                rb3.SelectedValue = dtAirline.Rows[0]["WarSurCharge_Charged"].ToString();
                rb4.SelectedValue = dtAirline.Rows[0]["WarSurcharge_On"].ToString();
                if (dtAirline.Rows[0]["WarSurCharge_Charged"].ToString() == "14")
                {
                    rb4.Enabled = false;
                }
                if (dtAirline.Rows[0]["XRayCharge_Charged"].ToString() == "14")
                {
                    rb6.Enabled = false;
                }
                rb5.SelectedValue = dtAirline.Rows[0]["XRayCharge_Charged"].ToString();
                rb6.SelectedValue = dtAirline.Rows[0]["XRayCharge_On"].ToString();

                string aid = dtAirline.Rows[0]["Deal"].ToString();
                for (int p = 0; p <= (ddlDeal.Items.Count - 1); p++)
                {
                    if (ddlDeal.Items[p].Text == aid)
                    {
               
                        ddlDeal.Items[p].Selected = true;

                    }
                }

                //ddlDeal.SelectedItem.Text = dtAirline.Rows[0]["Deal"].ToString();
                txtCsrFooter.Text = dtAirline.Rows[0]["Csr_Footer"].ToString();
                ddlStatus.SelectedValue = dtAirline.Rows[0]["Status"].ToString();
            }
            DataTable dtCheckCsr_Footer = dw.GetAllFromQuery("select convert(varchar,valid_from,101) as valid_from ,convert(varchar,valid_to,101) as valid_to,* from csr_footer where Airline_Detail_ID='" + Airline_Detail_ID + "'");

            if (dtCheckCsr_Footer.Rows.Count > 0)
            {
                txtValidFrom.Text = FormatDateDD(dtCheckCsr_Footer.Rows[0]["valid_from"].ToString());

                txtValidTo.Text = FormatDateDD(dtCheckCsr_Footer.Rows[0]["valid_to"].ToString());
            }
            txtCurrency.Text = dtAirline.Rows[0]["Currency"].ToString();
        }
        catch (SqlException se)
        {
            string err = se.Message;
           
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
               con.Close();
        }
    }
   
    protected void btnadd_Click(object sender, EventArgs e)
    {
       
        con = new SqlConnection(strCon);
        try
        {
            string str1 = "";
            str1 = "select * from Airline_Detail where Airline_ID='" + ddlAirlineCode.SelectedValue + "' and Belongs_To_City='" + ddlCity.SelectedValue + "'";
            da = new SqlDataAdapter(str1, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {

                lblError.Text = "Records Already Exist For Airline " + ddlAirlineCode.SelectedItem.Text + " and Company " + ddlCompany.SelectedItem.Text + " and City " + ddlCity.SelectedItem.Text;
            }
            else
            {
                string insert1, insert2;
                con = new SqlConnection(strCon);//Making Connection
                try
                {
                    con.Open();
                    trans = con.BeginTransaction();                                                                             // Insert Value in Airline_Detail table
                    insert1 = "insert into Airline_Detail(Airline_ID,Belongs_To_City,Bank_Name,Bank_Address,Acc_Name,Acc_No,DisBursementCharges,FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,GSAComm_Rate,Company_ID,Deal,Csr_Footer,Status,Currency) values(@Airline_ID,@Belongs_To_City,@Bank_Name,@Acc_Name,@Bank_Address,@Acc_No,@DisBursementCharges,@FreightSurCharge_Charged,@FreightSurCharge_On,@WarSurCharge_Charged,@WarSurcharge_On,@XRayCharge_Charged,@XRayCharge_On,@AWB_Fees,@ACI_Fees,@GSAComm_Rate,@Company_ID,@Deal,@Csr_Footer,@Status,@Currency)";
                    SqlCommand com = new SqlCommand(insert1, con,trans);
                    com.CommandType = CommandType.Text;
                    com.Parameters.Add("@Airline_ID", SqlDbType.Int).Value = ddlAirlineCode.SelectedValue;
                    com.Parameters.AddWithValue("@Belongs_To_City", ddlCity.SelectedValue);
                    com.Parameters.Add("@Bank_Name", SqlDbType.VarChar).Value = txtBankName.Text;
                    com.Parameters.Add("@Bank_Address", SqlDbType.VarChar).Value = txtbankaddress.Text;
                    com.Parameters.Add("@Acc_Name", SqlDbType.VarChar).Value = txtAccountName.Text;
                    com.Parameters.Add("@Acc_No", SqlDbType.VarChar).Value = txtAccountNumber.Text;
                    com.Parameters.Add("@DisBursementCharges", SqlDbType.Decimal).Value = txtDisBursementCharges.Value.Trim();

                    if (rb1.SelectedValue == "13")
                    {
                        com.Parameters.Add("@FreightSurCharge_Charged", SqlDbType.TinyInt).Value = 13;
                        if (rb2.SelectedValue == "Gross Wt.")
                        {
                            com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = rb2.SelectedValue;
                        }
                        else
                        {
                            com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = rb2.SelectedValue;
                        }
                    }
                    else
                    {
                        com.Parameters.Add("@FreightSurCharge_Charged", SqlDbType.TinyInt).Value = 14;
                        com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = "";
                    }

                    if (rb3.SelectedValue == "13")
                    {
                        com.Parameters.Add("@WarSurCharge_Charged", SqlDbType.TinyInt).Value = 13;
                        if (rb4.SelectedValue == "Gross Wt.")
                        {
                            com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = rb4.SelectedValue;
                        }
                        else
                        {
                            com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = rb4.SelectedValue;
                        }
                    }
                    else
                    {
                        com.Parameters.Add("@WarSurCharge_Charged", SqlDbType.TinyInt).Value = 14;
                        com.Parameters.AddWithValue("@WarSurcharge_On", "");
                    }
                    if (rb5.SelectedValue == "13")
                    {
                        com.Parameters.Add("@XRayCharge_Charged", SqlDbType.TinyInt).Value = 13;
                        if (rb6.SelectedValue == "Gross Wt.")
                        {
                            com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = rb6.SelectedValue;
                        }
                        else
                        {
                            com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = rb6.SelectedValue;
                        }
                    }
                    else
                    {
                        com.Parameters.Add("@XRayCharge_Charged", SqlDbType.TinyInt).Value = 14;
                        com.Parameters.AddWithValue("@XRayCharge_On", "");
                    }
                    com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtDueAgent.Value.Trim();
                    com.Parameters.Add("@ACI_Fees", SqlDbType.Decimal).Value = txtDueCarrier.Value.Trim();
                    com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = txtgsacomm.Text.Trim();
                    com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = ddlCompany.SelectedValue;
                    com.Parameters.Add("@Deal", SqlDbType.VarChar).Value = ddlDeal.SelectedItem.Text;
                    com.Parameters.Add("@Csr_Footer", SqlDbType.Text).Value = txtCsrFooter.Text; 
                    com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                    com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = txtCurrency.Text;
                    com.ExecuteNonQuery();
                    string selectQ;
                    selectQ = "select max(Airline_Detail_Id) from Airline_Detail";
                    cmd = new SqlCommand(selectQ, con, trans);
                    int  ADI= Convert.ToInt32(cmd.ExecuteScalar().ToString());

                    // Insert into Airline_Sector_Details
                    for (int i = 0; i < chklist.Items.Count; i++)    // values store in listbox
                    {
                        if (chklist.Items[i].Selected)
                        {

                            ts1 = chklist.Items[i].Value;
                          insert2 = "insert into airline_slab(Airline_Detail_Id,Slab_ID)values('" + ADI + "','" + ts1 + "')";
                            com = new SqlCommand(insert2, con, trans);
                            com.ExecuteNonQuery();

                        }
                    }

                    //**************Added On 11 May 2011 :Entry Transfer Into CsrFooter (Transaction) table
                    insert2 = "insert into csr_footer(Airline_Detail_Id,Airline_Id,City_id,Csr_Footer,valid_from,valid_To,company_Id)values('" + ADI + "','" + ddlAirlineCode.SelectedValue + "','" + ddlCity.SelectedValue + "','" + txtCsrFooter.Text + "','" + FormatDateDD(txtValidFrom.Text) + "','" + FormatDateDD(txtValidTo.Text) + "','" + ddlCompany.SelectedValue + "')";
                    com = new SqlCommand(insert2, con, trans);
                    com.ExecuteNonQuery();
                    //********************End***************************

                    trans.Commit();
                    con.Close();
                    Response.Redirect("Airline_Details.aspx");
                }

                catch (SqlException se)
                {
                    string err = se.Message;
                    trans.Rollback();
                    lblError.Text = err;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            Response.Write(er);
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
          
        updateData();
    }

    public void updateData()
    {       
        con = new SqlConnection(strCon);//Making Connection  
        string city1 = ddlCity.SelectedItem.Value;
        string citylabel=lblcity.Text;
        if (city1 == citylabel)
        {
            try
            {
               
                    if (chklist.Items.Count >= 0)
                    {

                        string strSelect = "select  AD.Airline_Detail_Id,Airline_Id,SM.Slab_Name  from Airline_Detail AD inner join Airline_Slab  ARS on ARS.Airline_Detail_Id=AD.Airline_Detail_Id inner join Slab_Master SM  on SM.Slab_ID=ARS.Slab_ID where Airline_ID='" + ddlAirlineCode.SelectedItem.Value.Trim() + "' and AD.Airline_detail_id='" + Convert.ToString(Request.QueryString["Airline_detail_id"]) + "' ";
                        da = new SqlDataAdapter(strSelect, con);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        con.Close();
                        if (ds.Tables[0].Rows.Count >= 0)
                        {
                            con.Open();
                            string strDel = "delete from airline_slab where Airline_detail_id='" + Convert.ToString(Request.QueryString["Airline_detail_id"]) + "'";
                            cmd = new SqlCommand(strDel, con);
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                            con.Close();
                            con = new SqlConnection(strCon);//Making Connection
                            string insertQ, insertQ1;
                            try
                            {
                                con.Open();
                                long Airline_Detail_ID = Convert.ToInt64(Request.QueryString["Airline_Detail_ID"]);
                                trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table
                                insertQ = "update Airline_Detail set Airline_ID=@Airline_ID,Belongs_To_City=@Belongs_To_City,Bank_Name = @Bank_Name,Bank_Address=@Bank_Address,Acc_Name = @Acc_Name,Acc_No = @Acc_No,DisBursementCharges=@DisBursementCharges,FreightSurCharge_Charged=@FreightSurCharge_Charged,FreightSurCharge_On=@FreightSurCharge_On,WarSurCharge_Charged=@WarSurCharge_Charged,WarSurcharge_On=@WarSurcharge_On,XRayCharge_Charged=@XRayCharge_Charged,XRayCharge_On=@XRayCharge_On,AWB_Fees=@AWB_Fees,ACI_Fees=@ACI_Fees,Company_ID=@Company_ID,Deal=@Deal,Csr_Footer=@Csr_Footer,Status=@Status,GSAComm_Rate=@GSAComm_Rate,Currency=@Currency where Airline_Detail_ID=" + Airline_Detail_ID + "";

                                SqlCommand com = new SqlCommand(insertQ, con, trans);
                                com.CommandType = CommandType.Text;
                                com.Parameters.Add("@Airline_ID", SqlDbType.Int).Value = ddlAirlineCode.SelectedValue;
                                com.Parameters.AddWithValue("@Belongs_To_City", ddlCity.SelectedValue);

                                com.Parameters.Add("@Bank_Name", SqlDbType.VarChar).Value = txtBankName.Text;
                                com.Parameters.Add("@Bank_Address", SqlDbType.VarChar).Value = txtbankaddress.Text;
                                com.Parameters.Add("@Acc_Name", SqlDbType.VarChar).Value = txtAccountName.Text;
                                com.Parameters.Add("@Acc_No", SqlDbType.VarChar).Value = txtAccountNumber.Text;
                                com.Parameters.Add("@DisBursementCharges", SqlDbType.Decimal).Value = txtDisBursementCharges.Value.Trim();
                                if (rb1.SelectedValue == "13")
                                {
                                    com.Parameters.Add("@FreightSurCharge_Charged", SqlDbType.TinyInt).Value = 13;
                                    if (rb2.SelectedValue == "Gross Wt.")
                                    {
                                        com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = rb2.SelectedValue;
                                    }
                                    else
                                    {
                                        com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = rb2.SelectedValue;
                                    }
                                }
                                else
                                {
                                    com.Parameters.Add("@FreightSurCharge_Charged", SqlDbType.TinyInt).Value = 14;
                                    com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = "";
                                }

                                if (rb3.SelectedValue == "13")
                                {
                                    com.Parameters.Add("@WarSurCharge_Charged", SqlDbType.TinyInt).Value = 13;
                                    if (rb4.SelectedValue == "Gross Wt.")
                                    {
                                        com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = rb4.SelectedValue;
                                    }
                                    else
                                    {
                                        com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = rb4.SelectedValue;
                                    }
                                }
                                else
                                {
                                    com.Parameters.Add("@WarSurCharge_Charged", SqlDbType.TinyInt).Value = 14;
                                    com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = "";
                                }
                                if (rb5.SelectedValue == "13")
                                {
                                    com.Parameters.Add("@XRayCharge_Charged", SqlDbType.TinyInt).Value = 13;
                                    if (rb6.SelectedValue == "Gross Wt.")
                                    {
                                        com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = rb6.SelectedValue;
                                    }
                                    else
                                    {
                                        com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = rb6.SelectedValue;
                                    }
                                }
                                else
                                {
                                    com.Parameters.Add("@XRayCharge_Charged", SqlDbType.TinyInt).Value = 14;
                                    com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = "";
                                }
                                com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtDueAgent.Value.Trim();
                                com.Parameters.Add("@ACI_Fees", SqlDbType.Decimal).Value = txtDueCarrier.Value.Trim();
                                com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = txtgsacomm.Text.Trim();
                                com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = ddlCompany.SelectedValue;
                                com.Parameters.Add("@Deal", SqlDbType.VarChar).Value = ddlDeal.SelectedItem.Text;
                                com.Parameters.Add("@Csr_Footer", SqlDbType.Text).Value = txtCsrFooter.Text;
                                com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                                com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = txtCurrency.Text;
                                //con.Open();
                                com.ExecuteNonQuery();
                                //cmd.ExecuteNonQuery();
                                //con.Close();
                                // Insert into Airline_Sector_Details
                                for (int i = 0; i < chklist.Items.Count; i++)    // values store in listbox
                                {
                                    if (chklist.Items[i].Selected)
                                    {
                                        ////if (con != null && con.State == ConnectionState.Open)
                                        ////    con.Close();
                                        ////con.Open();
                                        string Airline_ID;
                                        string strDest = "select distinct Slab_ID from Slab_Master where Slab_Name='" + chklist.Items[i].Value + "'";
                                        com = new SqlCommand(strDest, con, trans);
                                        SqlDataReader dr11 = com.ExecuteReader();
                                        dr11.Read();
                                        string DID = dr11["Slab_ID"].ToString();
                                        dr11.Dispose();
                                        //ts1 = lstDest.Items[i].Value;
                                        insertQ1 = "insert into  airline_slab(Airline_Detail_Id,Slab_ID)values('" + Airline_Detail_ID + "','" + DID + "')";
                                        cmd = new SqlCommand(insertQ1, con, trans);
                                        cmd.ExecuteNonQuery();
                                        cmd.Dispose();
                                        ////con.Close();
                                    }
                                }

                                //*****Added On 11 May 2011 :update CsrFooter in Csr_footer Table*****

                                DataTable dtCsrFooterCheck = dw.GetAllFromQuery("select * from Csr_Footer where airline_detail_id="+Airline_Detail_ID+" and valid_from='"+FormatDateDD(txtValidFrom.Text)+"' and valid_to='"+FormatDateDD(txtValidTo.Text) +"'");
                                if (dtCsrFooterCheck.Rows.Count > 0)
                                {

                                    insertQ1 = "update csr_footer set Airline_detail_id=" + Airline_Detail_ID + ",Airline_id=" + ddlAirlineCode.SelectedValue + ",City_id=" + ddlCity.SelectedValue + ",Csr_Footer='" + txtCsrFooter.Text + "',Valid_from='" + FormatDateDD(txtValidFrom.Text) + "',valid_to='" + FormatDateDD(txtValidTo.Text) + "',company_Id=" + ddlCompany.SelectedValue + " where Airline_detail_id=" + Airline_Detail_ID + " and valid_from='" + FormatDateDD(txtValidFrom.Text) + "' and valid_to='" + FormatDateDD(txtValidTo.Text) + "'";
                                   ////if (con != null && con.State == ConnectionState.Open)
                                   ////     con.Close();
                                   ////con.Open();
                                    cmd = new SqlCommand(insertQ1, con, trans);
                                    cmd.ExecuteNonQuery();
                                    cmd.Dispose();
                                    //con.Close();
                                }
                                else
                                {
                                    //**************Added On 11 May 2011 :Entry Transfer Into CsrFooter (Transaction) table
                                    ////if (con != null && con.State == ConnectionState.Open)
                                    ////    con.Close();
                                    ////con.Open();
                                    insertQ1 = "insert into csr_footer(Airline_Detail_Id,Airline_Id,City_id,Csr_Footer,valid_from,valid_To,company_Id)values('" + Airline_Detail_ID + "','" + ddlAirlineCode.SelectedValue + "','" + ddlCity.SelectedValue + "','" + txtCsrFooter.Text + "','" + FormatDateDD(txtValidFrom.Text) + "','" + FormatDateDD(txtValidTo.Text) + "','" + ddlCompany.SelectedValue + "')";
                                    com = new SqlCommand(insertQ1, con, trans);
                                    com.ExecuteNonQuery();
                                    //********************End***************************

                                }

                                //*********End*****************************************

                                trans.Commit();
                                con.Close();

                                Response.Redirect("Airline_Details.aspx");

                            }
                            catch (SqlException se)
                            {
                                string err = se.Message;
                                trans.Rollback();
                                lblError.Text = err;
                            }
                            finally
                            {
                                if (con != null && con.State == ConnectionState.Open)
                                    con.Close();
                            }

                        }

                        else
                        {
                            //lblmsg.Text = " Sector Name " + lblSector.Text.Trim() + " Alredy Exist For Airline " + ddlAirlineName.SelectedItem.Text.Trim();
                        }
                    }
                }
            catch (SqlException se)
            {
                string err = se.Message;
            }

            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            } 
        }
        else
        {
            try
            {
                string str1 = "";
                str1 = "select * from Airline_Detail where Airline_ID='" + ddlAirlineCode.SelectedValue + "' and Belongs_To_City='" + ddlCity.SelectedValue + "'";
                da = new SqlDataAdapter(str1, con);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                if (ds1.Tables[0].Rows.Count >= 1)
                {
                    lblError.Text = "Records Already Exist For Airline " + ddlAirlineCode.SelectedItem.Text + " and Company " + ddlCompany.SelectedItem.Text + " and City " + ddlCity.SelectedItem.Text;
                }
                else
                {

                    if (chklist.Items.Count >= 0)
                    {

                        string strSelect = "select  AD.Airline_Detail_Id,Airline_Id,SM.Slab_Name  from Airline_Detail AD inner join Airline_Slab  ARS on ARS.Airline_Detail_Id=AD.Airline_Detail_Id inner join Slab_Master SM  on SM.Slab_ID=ARS.Slab_ID where Airline_ID='" + ddlAirlineCode.SelectedItem.Value.Trim() + "' and AD.Airline_detail_id='" + Convert.ToString(Request.QueryString["Airline_detail_id"]) + "' ";
                        da = new SqlDataAdapter(strSelect, con);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        con.Close();
                        if (ds.Tables[0].Rows.Count >= 0)
                        {
                            con.Open();
                            string strDel = "delete from airline_slab where Airline_detail_id='" + Convert.ToString(Request.QueryString["Airline_detail_id"]) + "'";
                            cmd = new SqlCommand(strDel, con);
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                            con.Close();
                            con = new SqlConnection(strCon);//Making Connection
                            string insertQ, insertQ1;
                            try
                            {
                                con.Open();
                                long Airline_Detail_ID = Convert.ToInt64(Request.QueryString["Airline_Detail_ID"]);
                                trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table
                                insertQ = "update Airline_Detail set Airline_ID=@Airline_ID,Belongs_To_City=@Belongs_To_City,Bank_Name = @Bank_Name,Bank_Address=@Bank_Address,Acc_Name = @Acc_Name,Acc_No = @Acc_No,DisBursementCharges=@DisBursementCharges,FreightSurCharge_Charged=@FreightSurCharge_Charged,FreightSurCharge_On=@FreightSurCharge_On,WarSurCharge_Charged=@WarSurCharge_Charged,WarSurcharge_On=@WarSurcharge_On,XRayCharge_Charged=@XRayCharge_Charged,XRayCharge_On=@XRayCharge_On,AWB_Fees=@AWB_Fees,ACI_Fees=@ACI_Fees,Company_ID=@Company_ID,Deal=@Deal,Status=@Status where Airline_Detail_ID=" + Airline_Detail_ID + "";

                                SqlCommand com = new SqlCommand(insertQ, con, trans);
                                com.CommandType = CommandType.Text;
                                com.Parameters.Add("@Airline_ID", SqlDbType.Int).Value = ddlAirlineCode.SelectedValue;
                                com.Parameters.AddWithValue("@Belongs_To_City", ddlCity.SelectedValue);

                                com.Parameters.Add("@Bank_Name", SqlDbType.VarChar).Value = txtBankName.Text;
                                com.Parameters.Add("@Bank_Address", SqlDbType.VarChar).Value = txtbankaddress.Text;
                                com.Parameters.Add("@Acc_Name", SqlDbType.VarChar).Value = txtAccountName.Text;
                                com.Parameters.Add("@Acc_No", SqlDbType.VarChar).Value = txtAccountNumber.Text;
                                com.Parameters.Add("@DisBursementCharges", SqlDbType.Decimal).Value = txtDisBursementCharges.Value.Trim();
                                if (rb1.SelectedValue == "13")
                                {
                                    com.Parameters.Add("@FreightSurCharge_Charged", SqlDbType.TinyInt).Value = 13;
                                    if (rb2.SelectedValue == "Gross Wt.")
                                    {
                                        com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = rb2.SelectedValue;
                                    }
                                    else
                                    {
                                        com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = rb2.SelectedValue;
                                    }
                                }
                                else
                                {
                                    com.Parameters.Add("@FreightSurCharge_Charged", SqlDbType.TinyInt).Value = 14;
                                    com.Parameters.Add("@FreightSurCharge_On", SqlDbType.VarChar).Value = "";
                                }

                                if (rb3.SelectedValue == "13")
                                {
                                    com.Parameters.Add("@WarSurCharge_Charged", SqlDbType.TinyInt).Value = 13;
                                    if (rb4.SelectedValue == "Gross Wt.")
                                    {
                                        com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = rb4.SelectedValue;
                                    }
                                    else
                                    {
                                        com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = rb4.SelectedValue;
                                    }
                                }
                                else
                                {
                                    com.Parameters.Add("@WarSurCharge_Charged", SqlDbType.TinyInt).Value = 14;
                                    com.Parameters.Add("@WarSurcharge_On", SqlDbType.VarChar).Value = "";
                                }
                                if (rb5.SelectedValue == "13")
                                {
                                    com.Parameters.Add("@XRayCharge_Charged", SqlDbType.TinyInt).Value = 13;
                                    if (rb6.SelectedValue == "Gross Wt.")
                                    {
                                        com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = rb6.SelectedValue;
                                    }
                                    else
                                    {
                                        com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = rb6.SelectedValue;
                                    }
                                }
                                else
                                {
                                    com.Parameters.Add("@XRayCharge_Charged", SqlDbType.TinyInt).Value = 14;
                                    com.Parameters.Add("@XRayCharge_On", SqlDbType.VarChar).Value = "";
                                }
                                com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtDueAgent.Value.Trim();
                                com.Parameters.Add("@ACI_Fees", SqlDbType.Decimal).Value = txtDueCarrier.Value.Trim();
                                com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = ddlCompany.SelectedValue;
                                com.Parameters.Add("@Deal", SqlDbType.VarChar).Value = ddlDeal.SelectedItem.Text;
                                com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                                //con.Open();
                                com.ExecuteNonQuery();
                                //cmd.ExecuteNonQuery();
                                //con.Close();
                                // Insert into Airline_Sector_Details
                                for (int i = 0; i < chklist.Items.Count; i++)    // values store in listbox
                                {
                                    if (chklist.Items[i].Selected)
                                    {
                                        ////if (con != null && con.State == ConnectionState.Open)
                                        ////    con.Close();
                                        ////con.Open();
                                        string Airline_ID;
                                        string strDest = "select distinct Slab_ID from Slab_Master where Slab_Name='" + chklist.Items[i].Value + "'";
                                        com = new SqlCommand(strDest, con, trans);
                                        SqlDataReader dr11 = com.ExecuteReader();
                                        dr11.Read();
                                        string DID = dr11["Slab_ID"].ToString();
                                        dr11.Dispose();
                                        //ts1 = lstDest.Items[i].Value;
                                        insertQ1 = "insert into  airline_slab(Airline_Detail_Id,Slab_ID)values('" + Airline_Detail_ID + "','" + DID + "')";
                                        cmd = new SqlCommand(insertQ1, con, trans);
                                        cmd.ExecuteNonQuery();

                                    }
                                }

                                //*****Added On 11 May 2011 :update CsrFooter in Csr_footer Table*****

                                DataTable dtCsrFooterCheck = dw.GetAllFromQuery("select * from Csr_Footer where airline_detail_id=" + Airline_Detail_ID + " and valid_from='" + FormatDateDD(txtValidFrom.Text) + "' and valid_to='" + FormatDateDD(txtValidTo.Text) + "'");
                                if (dtCsrFooterCheck.Rows.Count > 0)
                                {

                                    insertQ1 = "update csr_footer set Airline_detail_id=" + Airline_Detail_ID + ",Airline_id=" + ddlAirlineCode.SelectedValue + ",City_id=" + ddlCity.SelectedValue + ",Csr_Footer='" + txtCsrFooter.Text + "',Valid_from='" + FormatDateDD(txtValidFrom.Text) + "',valid_to='" + FormatDateDD(txtValidTo.Text) + "',company_Id=" + ddlCompany.SelectedValue + " where Airline_detail_id=" + Airline_Detail_ID + " and valid_from='" + FormatDateDD(txtValidFrom.Text) + "' and valid_to='" + FormatDateDD(txtValidTo.Text) + "'";
                                    //if (con != null && con.State == ConnectionState.Open)
                                    //    con.Close();
                                    //con.Open();
                                    cmd = new SqlCommand(insertQ1, con, trans);
                                    cmd.ExecuteNonQuery();
                                    cmd.Dispose();
                                    //con.Close();
                                }
                                else
                                {
                                    //**************Added On 11 May 2011 :Entry Transfer Into CsrFooter (Transaction) table
                                    if (con != null && con.State == ConnectionState.Open)
                                        con.Close();
                                    con.Open();
                                    insertQ1 = "insert into csr_footer(Airline_Detail_Id,Airline_Id,City_id,Csr_Footer,valid_from,valid_To,company_Id)values('" + Airline_Detail_ID + "','" + ddlAirlineCode.SelectedValue + "','" + ddlCity.SelectedValue + "','" + txtCsrFooter.Text + "','" + FormatDateDD(txtValidFrom.Text) + "','" + FormatDateDD(txtValidTo.Text) + "','" + ddlCompany.SelectedValue + "')";
                                    com = new SqlCommand(insertQ1, con, trans);
                                    com.ExecuteNonQuery();
                                    //********************End***************************

                                }

                                //*********End*****************************************

                                trans.Commit();
                                con.Close();

                                Response.Redirect("Airline_Details.aspx");

                            }
                            catch (SqlException se)
                            {
                                string err = se.Message;
                                trans.Rollback();
                                lblError.Text = err;
                            }
                            finally
                            {
                                if (con != null && con.State == ConnectionState.Open)
                                    con.Close();
                            }

                        }

                        else
                        {
                            //lblmsg.Text = " Sector Name " + lblSector.Text.Trim() + " Alredy Exist For Airline " + ddlAirlineName.SelectedItem.Text.Trim();
                        }
                    }
                }
            }
            catch (SqlException se)
            {
                string err = se.Message;
            }

            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            } 
        }
          
    }

    protected void rb1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rb1.SelectedValue == "13")
        {
            rb2.Enabled = true;
        }
        else
        {
            rb2.Enabled = false;
        }
    }

    protected void rb3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rb3.SelectedValue == "13")
        {
            rb4.Enabled = true;
        }
        else
        {
            rb4.Enabled = false;
        }
    }

    protected void rb5_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rb5.SelectedValue == "13")
        {
            rb6.Enabled = true;
        }
        else
        {
            rb6.Enabled = false;
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Airline_Details.aspx");
    }

    protected void ddlAirlineCode_SelectedIndexChanged(object sender, EventArgs e)
    {        
        FillddlCompany();
        ddlCompany.SelectedIndex = 0;
        ddlCity.Items.Clear();
        ddlCity.Items.Add(new ListItem("Select City"));
    }

    protected void chklist_SelectedIndexChanged(object sender, EventArgs e)
    {
    
    }

    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlCityNamePlusCode();
    }

    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public string FormatDate(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
