using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;



//This Page is design & Coding By Alok Date:28.01.2008 
public partial class AirlineWise_Tds : System.Web.UI.Page
{
    string loginid;
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    SqlTransaction trans = null;
    DisplayWrap dw = new DisplayWrap();
    string Principle_TDS_ID;
    string[] Sdate;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            loginid = Session["EMailID"].ToString();
            if (!IsPostBack && Request.QueryString["Principle_TDS_ID"] != null)
            {
                ShowAirline();                
                lblAdd.Visible = false;
                lblUpdate.Visible = true;
                btnupdate.Visible = true;
                btnAdd.Visible = false;
                btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                Principle_TDS_ID = Convert.ToString(Request.QueryString["Principle_TDS_ID"]);
                string str1 = "select Airline_Detail_ID ,TDS_Rate ,Surcharge,Education_Cess ,convert(varchar,Valid_From,103) as 'Valid_From',convert(varchar,Valid_To,103) as 'Valid_To' ,Entered_By ,Entered_On  from Airlinewise_TDS where  Principle_TDS_ID='" + Principle_TDS_ID + "'";
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(str1, con);
                SqlDataReader dr = com.ExecuteReader();
                dr.Read();
                string Airdid = dr["Airline_Detail_ID"].ToString();
                for (int p = 0; p <= (ddlairline.Items.Count - 1); p++)
                {
                    if (ddlairline.Items[p].Value == Airdid)
                    {
                        ddlairline.Items[p].Selected = true;
                    }
                }

                txttdsrate.Text = dr["TDS_Rate"].ToString();
                txtschg.Text = dr["Surcharge"].ToString();
                txtedcess.Text = dr["Education_Cess"].ToString();
                txtfromdate.Text = dr["Valid_From"].ToString();
                txttodate.Text = dr["Valid_To"].ToString();
                con.Close();
            }
                //UserAirlineNamePlusCode1();
            else if (!IsPostBack)
                {
                    //btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
                    txtfromdate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    Sdate = txtfromdate.Text.Split('/');
                    btnupdate.Visible = false;
                    lblUpdate.Visible = false;
                    string month = Sdate[1];
                    string year = Sdate[2];
                    if (Sdate[1] == "01" || Sdate[1] == "02" || Sdate[1] == "03")
                    {
                        int yy = int.Parse(year);
                        string destdata = "31/03/" + yy.ToString();
                        txttodate.Text = destdata;
                    }
                    if (Sdate[1] == "04" || Sdate[1] == "05" || Sdate[1] == "06" || Sdate[1] == "07" || Sdate[1] == "08" || Sdate[1] == "09" || Sdate[1] == "10" || Sdate[1] == "11" || Sdate[1] == "12")
                    {
                        int yy = int.Parse(year) + 1;
                        string destdata = "31/03/" + yy.ToString();
                        txttodate.Text = destdata;
                    }
                    ShowAirline();
                  
                }
        }
    }
    protected void ShowAirline()
    {

       ddlairline.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'('+A.Airline_Code+')/'+B.city_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlairline.Items.Add("Select Airline Name");
            ddlairline.Items[0].Value = "";
            while (dr.Read())
            {
                ddlairline.Items.Add(new ListItem(dr["airline"].ToString(), Convert.ToString(dr["airline_detail_id"])));

            }
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    #region Functions For Convert Date
    public string ConvertDate(string strD)
    {

        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];

    }

    #endregion
    public void AddData()
    {
        if (IsValid)
        {
            string aid = null;
            DateTime val_from=new DateTime();
            DateTime val_to=new DateTime();
            string aid1 = null;
            con = new SqlConnection(strCon);//Making Connection
            con.Open();
            string insertQ, updateQ,insertQ1;
            string fromDat = ConvertDate(txtfromdate.Text);
            string todat = ConvertDate(txttodate.Text);
            DateTime dt1 = DateTime.Parse(ConvertDate(txtfromdate.Text));
            DateTime dt3 = dt1.AddDays(-1);
            DateTime dt2 = DateTime.Parse(ConvertDate(txttodate.Text));
            DateTime dt4 = dt2.AddDays(1);
            //string strSelect = "select Airline_Detail_ID,valid_From,Valid_To from Airlinewise_TDS where '" + dt1 + "' between  valid_From and Valid_To and Airline_Detail_ID='" + airline_name_city_value[0] + "'";
            string strSelect = "select Airline_Detail_ID,convert(varchar,Valid_From,103) as 'Valid_From',convert(varchar,Valid_To,103) as 'Valid_To'  from Airlinewise_TDS where Airline_Detail_ID='" + ddlairline.SelectedItem.Value + "'";
            com = new SqlCommand(strSelect, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                aid1 = dr["Airline_Detail_ID"].ToString();
                lblfromdate.Text=dr["valid_From"].ToString();
                lbltodate.Text = dr["Valid_To"].ToString();
                val_from = DateTime.Parse(ConvertDate(lblfromdate.Text));
                val_to = DateTime.Parse(ConvertDate(lbltodate.Text));
            }
            dr.Close();
            con.Close();
            if (ddlairline.SelectedItem.Value == aid1)
            {

                if (dt1 >= val_from)
                {
                    if (val_to >= dt2)
                    {
                        try
                        {
                            con.Open();
                            trans = con.BeginTransaction();
                            string aid2=null, t_rate = null, sch = null, ed = null, stax=null;
                            string strSelect1 = "select *  from Airlinewise_TDS where '" + dt1 + "' between  valid_From and Valid_To";
                            com = new SqlCommand(strSelect1, con, trans);
                            SqlDataReader dr1 = com.ExecuteReader();
                            if (dr1.Read())
                            {
                                aid2 = dr1["Airline_Detail_ID"].ToString();
                                t_rate = dr1["TDS_Rate"].ToString();
                                sch = dr1["Surcharge"].ToString();
                                ed = dr1["Education_Cess"].ToString();
                                stax = dr1["Stax"].ToString();
                            }
                            dr1.Close();

                            insertQ1 = "INSERT INTO Airlinewise_TDS (Airline_Detail_ID,TDS_Rate,Surcharge,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,Stax)values('" + aid2 + "','" + t_rate + "','" + sch + "','" + ed + "','" + dt4 + "','" + val_to + "','" + loginid + "','" + DateTime.Now + "','" + stax + "')";

                            com = new SqlCommand(insertQ1, con, trans);
                            com.ExecuteNonQuery();
                            updateQ = "update Airlinewise_TDS  set Valid_To='" + dt3 + "',Entered_By='" + loginid + "',Entered_On='" + DateTime.Now + "' where '" + dt1 + "' between  valid_From and Valid_To";
                            com = new SqlCommand(updateQ, con, trans);
                            com.ExecuteNonQuery();
                            if (txtschg.Text == "" && txtedcess.Text == "")
                            {
                                txtschg.Text = "0";
                                txtedcess.Text = "0";
                            }
                            else if (txtschg.Text == "")
                            {
                                txtschg.Text = "0";
                                txtedcess.Text = txtedcess.Text;

                            }
                            else if (txtedcess.Text == "")
                            {
                                txtschg.Text = txtschg.Text;
                                txtedcess.Text = "0";

                            }

                            else
                            {
                                txtschg.Text = txtschg.Text;
                                txtedcess.Text = txtedcess.Text;
                            }
                            insertQ = "INSERT INTO Airlinewise_TDS (Airline_Detail_ID,TDS_Rate,Surcharge,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,Stax)values('" + ddlairline.SelectedItem.Value + "','" + txttdsrate.Text + "','" + txtschg.Text + "','" + txtedcess.Text.Trim() + "','" + dt1 + "','" + todat + "','" + loginid + "','" + DateTime.Now + "','"+txtImportStax.Text+"')";

                            com = new SqlCommand(insertQ, con, trans);
                            com.ExecuteNonQuery();
                        
                            trans.Commit();
                            con.Close();
                            Response.Redirect("ViewAirlineWise_Tds.aspx");
                        }
                        catch (SqlException se)
                        {
                            string err = se.Message;
                            trans.Rollback();
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }
                    }

                    else
                    {
                        try
                        {
                            con.Open();
                            trans = con.BeginTransaction();
                            updateQ = "update Airlinewise_TDS  set Valid_To='" + dt3 + "',Entered_By='" + loginid + "',Entered_On='" + DateTime.Now + "' where '" + dt1 + "' between  valid_From and Valid_To";
                            com = new SqlCommand(updateQ, con, trans);
                            com.ExecuteNonQuery();
                            if (txtschg.Text == "" && txtedcess.Text == "")
                            {
                                txtschg.Text = "0";
                                txtedcess.Text = "0";
                            }
                            else if (txtschg.Text == "")
                            {
                                txtschg.Text = "0";
                                txtedcess.Text = txtedcess.Text;

                            }
                            else if (txtedcess.Text == "")
                            {
                                txtschg.Text = txtschg.Text;
                                txtedcess.Text = "0";

                            }

                            else
                            {
                                txtschg.Text = txtschg.Text;
                                txtedcess.Text = txtedcess.Text;
                            }
                            insertQ = "INSERT INTO Airlinewise_TDS (Airline_Detail_ID,TDS_Rate,Surcharge,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,Stax)values('" + ddlairline.SelectedItem.Value + "','" + txttdsrate.Text + "','" + txtschg.Text + "','" + txtedcess.Text.Trim() + "','" + dt1 + "','" + todat + "','" + loginid + "','" + DateTime.Now + "','"+txtImportStax.Text+"')";

                            com = new SqlCommand(insertQ, con, trans);
                            com.ExecuteNonQuery();
                            //string aid, t_rate, sch, ed;
                            //string strSelect1 = "select *  from Airlinewise_TDS where '" + dt1 + "' between  valid_From and Valid_To";
                            //com = new SqlCommand(strSelect1, con);
                            //SqlDataReader dr = com.ExecuteReader();
                            //if (dr.Read())
                            //{
                            //    aid = dr["Airline_Detail_ID"].ToString();
                            //    t_rate = dr["TDS_Rate"].ToString();
                            //    sch = dr["Surcharge"].ToString();
                            //    ed = dr["Education_Cess"].ToString();

                            //}
                            //dr.Close();

                            //insertQ1 = "INSERT INTO Airlinewise_TDS (Airline_Detail_ID,TDS_Rate,Surcharge,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On)values('" + aid + "','" + t_rate + "','" + sch + "','" + ed + "','" + dt4 + "','" + val_to + "','" + loginid + "','" + DateTime.Now + "')";

                            //com = new SqlCommand(insertQ1, con, trans);
                            //com.ExecuteNonQuery();
                            trans.Commit();
                            con.Close();
                            Response.Redirect("ViewAirlineWise_Tds.aspx");
                        }
                        catch (SqlException se)
                        {
                            string err = se.Message;
                            trans.Rollback();
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }
                    }
                }
                else
                {
                    try
                    {
                        if (txtschg.Text == "" && txtedcess.Text == "")
                        {
                            txtschg.Text = "0";
                            txtedcess.Text = "0";
                        }
                        else if (txtschg.Text == "")
                        {
                            txtschg.Text = "0";
                            txtedcess.Text = txtedcess.Text;

                        }
                        else if (txtedcess.Text == "")
                        {
                            txtschg.Text = txtschg.Text;
                            txtedcess.Text = "0";

                        }

                        else
                        {
                            txtschg.Text = txtschg.Text;
                            txtedcess.Text = txtedcess.Text;
                        }
                        insertQ = "INSERT INTO Airlinewise_TDS (Airline_Detail_ID,TDS_Rate,Surcharge,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,Stax)values('" + ddlairline.SelectedItem.Value + "','" + txttdsrate.Text + "','" + txtschg.Text + "','" + txtedcess.Text.Trim() + "','" + fromDat + "','" + todat + "','" + loginid + "','" + DateTime.Now + "','"+txtImportStax.Text+"')";

                        com = new SqlCommand(insertQ, con);
                        com.ExecuteNonQuery();
                        con.Close();
                        Response.Redirect("ViewAirlineWise_Tds.aspx");
                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }
            else
            {
                try
                {
                    con.Open();

                          if (txtschg.Text == "" && txtedcess.Text == "")
                    {
                        txtschg.Text = "0";
                        txtedcess.Text = "0";
                    }
                    else if (txtschg.Text == "" ) 
                    {
                        txtschg.Text = "0";
                        txtedcess.Text = txtedcess.Text;

                    }
                    else if(txtedcess.Text == "")
                    {
                        txtschg.Text = txtschg.Text;
                        txtedcess.Text = "0";
                      
                    }
               
                    else
                    {
                        txtschg.Text = txtschg.Text;
                        txtedcess.Text = txtedcess.Text;
                    }
                    insertQ = "INSERT INTO Airlinewise_TDS (Airline_Detail_ID,TDS_Rate,Surcharge,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,Stax)values('" + ddlairline.SelectedItem.Value + "','" + txttdsrate.Text + "','" + txtschg.Text + "','" + txtedcess.Text.Trim() + "','" + fromDat + "','" + todat + "','" + loginid + "','" + DateTime.Now + "','"+txtImportStax.Text+"')";

                    com = new SqlCommand(insertQ, con);
                    com.ExecuteNonQuery();
                    con.Close();
                    Response.Redirect("ViewAirlineWise_Tds.aspx");
                }
                catch (SqlException se)
                {
                    string err = se.Message;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();

                }
            }
        }
    }
    //public void UpdateData()
    //{
    //    con = new SqlConnection(strCon);//Making Connection
    //    string updateQ;
    //    string fromDat = ConvertDate(txtfromdate.Text);
    //    string todat = ConvertDate(txttodate.Text);
    //    try
    //    {

    //            try
    //            {
                   

    //                    con.Open();
    //                    updateQ = "update Agentwise_TDS  set Airline_Detail_ID='" + mm + "',Exempted_TDS_Rate='" + txtTdsRate.Text + "',TDS_Exemption_Limit='" + txtTdsLimit.Text + "',TDS_Status_Limited='13',Remarks='" + txtRemarks.Text + "',Valid_From='" + fromDat + "',Valid_To='" + todat + "',Entered_By='" + loginid + "',Entered_On='" + DateTime.Now + "' where Agent_Tds_ID='" + Convert.ToString(Request.QueryString["Agent_Tds_ID"]) + "'";
                    
    //                com = new SqlCommand(updateQ, con);
    //                com.ExecuteNonQuery();
    //                con.Close();
    //                Response.Redirect("ViewAgentWise_Tds.aspx");

    //            }

    //            catch (SqlException se)
    //            {
    //                string err = se.Message;
    //                lblmsg.Text = err;
    //            }
    //            finally
    //            {
    //                if (con != null && con.State == ConnectionState.Open)
    //                    con.Close();
    //            }

    //        }

    //}
    protected void btnAdd_Click(object sender, EventArgs e)
    {
         AddData();


    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewAirlineWise_Tds.aspx");
    }
}
