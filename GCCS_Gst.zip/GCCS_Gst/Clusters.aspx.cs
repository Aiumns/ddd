﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Clusters : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlTransaction trans = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                lblselection.Visible = false;
                lblflight.Visible = false;
                lstflight.Visible = false;
                FillCluster();


            }

            if (Request.QueryString["ClusterID"] != null)
            {
                if (!IsPostBack)
                {
                    ddlCursore.Enabled = false;
                    btnSummit.Visible = false;
                    btnupdate.Visible = true;
                    FillData(Convert.ToInt32(Request.QueryString["ClusterID"].ToString()));
                }

            }
        }


    }

    protected void FillCluster()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("SELECT Cluster_id,Cluster_Name FROM db_owner.Cluster_master", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlCursore.Items.Clear();
            ddlCursore.Items.Insert(0, "- -Select- -");
            ddlCursore.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlCursore.Items.Add(new ListItem(dr["Cluster_Name"].ToString(), dr["Cluster_id"].ToString()));
            }
            con.Close();


        }

        catch
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }

    protected void FillAirline(string clusterid)
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("SELECT ad.Airline_Detail_ID,(am.Airline_Text_Code+'-'+cm.City_Code) AS FlightName  FROM dbo.Airline_Detail ad INNER JOIN dbo.Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN dbo.City_Master cm ON ad.Belongs_To_City=cm.City_ID INNER JOIN db_owner.Cluster_master cms ON cms.Cluster_City=cm.City_ID WHERE cms.Cluster_id='" + clusterid + "'", con);


            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();

            DataTable dt = ds.Tables[0];
            if (dt.Rows.Count == 0)
            {
                lblselection.Visible = false;
                lblflight.Visible = false;
                lstflight.Visible = false;
                lblmessage.Visible = true;
                lblmessage.Text = "No Airline For This Cluster";
            }
            else
            {
                lblmessage.Visible = false;
                lblselection.Visible = true;
                lblflight.Visible = true;
                lstflight.Visible = true;
                for (int i = 0; i <= dt.Rows.Count; i++)
                {

                    ListItem lk = new ListItem();
                    lk.Text = dt.Rows[i]["FlightName"].ToString();
                    lk.Value = dt.Rows[i]["Airline_Detail_ID"].ToString();
                    lstflight.Items.Insert(i, lk);
                }
            }

            ds.Clear();


        }

        catch
        {
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    protected void FillData(int ClusterID)
    {


        FillAirline(ClusterID.ToString());

        con = new SqlConnection(strCon);
        con.Open();
        string cmd = "SELECT Cluster_id,Airline_Aopair FROM db_owner.Cluster_tran WHERE Cluster_id=" + ClusterID + "";
        SqlDataAdapter da = new SqlDataAdapter(cmd, con);

        DataSet ds = new DataSet();
        da.Fill(ds);
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            ddlCursore.SelectedValue = ds.Tables[0].Rows[i]["Cluster_id"].ToString();
            string airlinepair = ds.Tables[0].Rows[i]["Airline_Aopair"].ToString().Remove(ds.Tables[0].Rows[i]["Airline_Aopair"].ToString().Length - 1, 1);
            string[] d = airlinepair.Split(new char[] { ',' });
            foreach (string j in d)
            {
                for (int k = 0; k < lstflight.Items.Count; k++)
                {
                    if (lstflight.Items[k].Value == j)
                    {
                        lstflight.Items[k].Selected = true;
                    }
                }


            }
            uplistbox.Update();

        }

    }


    protected void btnSummit_Click(object sender, EventArgs e)
    {

        try
        {
            int select = 0;
            con = new SqlConnection(strCon);
            con.Open();
            string cluster = "";
            string ClusterText = "";

            for (int i = 0; i < lstflight.Items.Count; i++)
            {
                if (lstflight.Items[i].Selected)
                {

                    //string cmdCheck = "SELECT * FROM Cluster_Tran WHERE Cluster_id=" + ddlCursore.SelectedValue + " AND Airline_Aopair like '%" + lstflight.Items[i].Value + "%'";
                    string cmdCheck = "SELECT * FROM Cluster_Tran WHERE Cluster_id=" + ddlCursore.SelectedValue + " ";

                    SqlDataAdapter da = new SqlDataAdapter(cmdCheck, con);

                    DataSet ds = new DataSet();
                    da.Fill(ds);


                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        lblmessage.Visible = true;
                        lblmessage.Text = "The Cluster are already added";
                        return;

                    }


                }
            }


            for (int i = 0; i < lstflight.Items.Count; i++)
            {
                if (lstflight.Items[i].Selected)
                {
                    select++;

                    cluster = cluster + lstflight.Items[i].Value + ',';
                    ClusterText = ClusterText + ',' + lstflight.Items[i].Text;

                }
            }
            if (select == 0)
            {
                lblmessage.Visible = true;
                lblmessage.Text = "Select Any One Flight";
                return;
            }
            else
            {
                ClusterText = ClusterText.Remove(0, 1);
                string cmdinsert = "INSERT INTO Cluster_Tran( Cluster_id ,Airline_Aopair ,Updated_By ,Updated_On,Airline_AopairName )VALUES  (" + ddlCursore.SelectedValue + " , '" + cluster + "' ,' " + Session["EMailID"].ToString() + "','" + DateTime.Now + "','" + ClusterText + "' )";
                com = new SqlCommand(cmdinsert, con);
                com.ExecuteNonQuery();
                com.Dispose();
            }
            con.Close();
            string strScript = "alert('Saved Successfully.');location.replace('ViewClustersTransaction.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);



        }

        catch
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }




    protected void btnupdate_Click(object sender, EventArgs e)
    {

        try
        {
            int select = 0;
            con = new SqlConnection(strCon);
            con.Open();

            string cluster = "";
            string ClusterText = "";

            foreach (int i in lstflight.GetSelectedIndices())// values store in listbox
            {
                if (lstflight.Items[i].Selected)
                {
                    select++;

                    cluster = cluster + ',' + lstflight.Items[i].Value;
                    ClusterText = ClusterText + ',' + lstflight.Items[i].Text;
                }


            }

            //for (int i = 0; i < lstflight.Items.Count; i++)
            //{
            //    if (lstflight.Items[i].Selected)
            //    {
            //        select++;

            //        cluster = cluster + lstflight.Items[i].Value + ',';
            //        ClusterText = ClusterText + ',' + lstflight.Items[i].Text;

            //    }
            //}
            if (select == 0)
            {
                lblmessage.Visible = true;
                lblmessage.Text = "Select Any One Flight";
                return;
            }
            else
            {
                cluster = cluster.Remove(0, 1);
                ClusterText = ClusterText.Remove(0, 1);
                string cmdinsert = "UPDATE db_owner.Cluster_tran SET Airline_AopairName='" + ClusterText + "',Airline_Aopair='" + cluster + "',Updated_On='" + DateTime.Now + "',Updated_By='" + Session["EMailID"].ToString() + "' WHERE Cluster_id=" + ddlCursore.SelectedValue + " ";
                com = new SqlCommand(cmdinsert, con);

                com.ExecuteNonQuery();
                com.Dispose();

            }
            con.Close();
            string strScript = "alert('Updated Successfully.');location.replace('ViewClustersTransaction.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);



        }

        catch (SqlException sqlex)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Error');</script>");
            string ss = sqlex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }


    protected void lstflight_SelectedIndexChanged(object sender, EventArgs e)
    {
        foreach (int i in lstflight.GetSelectedIndices())// values store in listbox
        {
            if (lstflight.Items[i].Selected)
            {
                //  select++;

                // cluster = cluster + lstflight.Items[i].Value + ',';
                // ClusterText = ClusterText + ',' + lstflight.Items[i].Text;
            }


        }

    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewClustersTransaction.aspx");

    }
    protected void ddlCursore_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillAirline(ddlCursore.SelectedItem.Value);
    }
}
