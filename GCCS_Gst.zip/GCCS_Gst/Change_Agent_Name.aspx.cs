﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class Change_Agent_Name : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    SqlCommand cmd;
    SqlDataAdapter da;
    SqlTransaction trans ;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            if (!IsPostBack)
            {
                Panel1.Visible = false;
                fillagentname();
                //DataTable st = new DataTable();
                //st = dw.GetAllFromQuery("SELECT Status FROM dbo.Stock_Master WHERE AirWayBill_No='"+txtawbno.Text+"'");
                //Session["status"] = st;
            }
        }
        

    }

    public void fillagentname()
    {
        con = new SqlConnection(strCon);
        con.Open();
        //ddlagentname.Items.Clear();
       // DataTable dt = dw.GetAllFromQuery("SELECT  Agent_Name,Agent_ID FROM dbo.Agent_Master");
        cmd = new SqlCommand("SELECT  Agent_Name,Agent_ID FROM dbo.Agent_Master order by Agent_Name ASC  ", con);
        SqlDataReader dr = cmd.ExecuteReader();
        //ddlagentname.Items.Insert(0,"Select Agent");
        //ddlagentname.Items[0].Value = "0";
        while (dr.Read())
        {
            ddlagentname.Items.Add(new ListItem(dr["Agent_Name"].ToString(), dr["Agent_ID"].ToString()));
        }
    }
    protected void btnagent_Click(object sender, EventArgs e)
    {
        /*  */
        


        con = new SqlConnection(strCon);
        com = new SqlCommand("Agent_Transfer_CSR_Aprroved_CASE",con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Airwaybill_NO",SqlDbType.VarChar).Value = txtawbno.Text;
        com.Parameters.Add("@Agent_ID",SqlDbType.Int).Value= ddlagentname.SelectedValue;
        com.Parameters.Add("@CSR_From",SqlDbType.VarChar).Value= FormatDateDD(txtfromdate.Text);
        com.Parameters.Add("@CSR_To",SqlDbType.VarChar).Value= FormatDateDD(txttodate.Text);
        con.Open();
        com.ExecuteNonQuery();
       // string strScript = "alert('Agent Name Changed Successfully.');";
        string strScript = "alert('Agent Name Changed Successfully.');location.replace('Change_Agent_Name.aspx')";
        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);

        
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      
        Panel1.Visible = true;
         DataTable dt2 = new DataTable();
        dt2 = dw.GetAllFromQuery("SELECT Agent_Name,Agent_ID FROM dbo.Agent_Master WHERE Agent_ID IN ( SELECT Agent_ID FROM dbo.Stock_Master  WHERE AirWayBill_No='" + txtawbno.Text + "')");
       
        ddlagentname.SelectedValue = dt2.Rows[0]["Agent_ID"].ToString();
        DataTable date = new DataTable();
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("AgentDetailsCheck", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Awb", SqlDbType.VarChar).Value = txtawbno.Text;
        da = new SqlDataAdapter(com);
        da.Fill(date);
        
       string d = datecheck(date.Rows[0]["Date"].ToString());
        string[] d1 = date.Rows[0]["Date"].ToString().Split('/');
        string month = d1[1];
        string year = d1[2];
        if (d == "firstfn")
        {
            txtfromdate.Text = "01" + "/" + month + "/" + year;
            txttodate.Text = "15" + "/" + month + "/" + year;
        }
        else
        {
            txtfromdate.Text = "16" + "/" + month + "/" + year;
            if(month=="01"||month=="03"||month=="05"||month=="07"||month=="08"||month=="10"||month=="12")
            {
                txttodate.Text = "31" + "/" + month + "/" + year;
            }
           
            else
            {
                if (month == "02")
                {
                    txttodate.Text = "28" + "/" + month + "/" + year;
                }
                else
                {
                    txttodate.Text = "30" + "/" + month + "/" + year;
                }
            }

        }
      


       
    }

    public string datecheck(string date)
    {
        string[] a=date.Split('/');
        string d;

        string date1 = a[0];
        if ( Convert.ToInt32(date1) >= 01 && Convert.ToInt32( date1) <= 15)
        {
            //d = "01" + "/" + a[1] + "/" + a[2];
            //return d;
            return "firstfn";
           
        }
        else
        {
            //d = "16" +"/"+ a[1]+"/" + a[2];
            //return d;
            return "secondfn";
        }

       
    }
}
