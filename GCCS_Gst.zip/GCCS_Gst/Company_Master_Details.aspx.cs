using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//Created by Rakhi on 15 Oct 2007

public partial class Company_Master_Details : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Search();
        }
    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txtsearch.Text == "")
            {                
                //selectQ = "SELECT cm.Company_ID,cm.Company_Name, cm.Company_Address, cm.Phone,cm.Company_Fax,cm.Company_Email, cm.TDS_Rate, cm.SurCharge,ctm.City_Name,  sm.Status_Name  FROM    City_Master ctm INNER JOIN Company_Master cm ON ctm.City_ID = cm.Company_ID INNER JOIN Status_Master sm ON ctm.City_ID = sm.Status_ID where sm.Status_Name in( 'active','inactive')";
                selectQ = "select cm.Company_ID,cm.Company_Name,cm.Company_Address,cm.Phone,cm.Company_Fax,cm.Company_Email,cm.TDS_Rate,cm.SurCharge,ctm.City_Name,sm.Status_Name from Company_Master cm inner join City_Master ctm on ctm.City_Id=cm.City inner join Status_Master sm on sm.Status_Id=cm.Status where sm.Status_Name in('Active','Inactive') and cm.Parent_ID=0";
            }

            else
            {
                selectQ = "select cm.Company_ID,cm.Company_Name,cm.Company_Address,cm.Phone,cm.Company_Fax,cm.Company_Email,cm.TDS_Rate,cm.SurCharge,ctm.City_Name,sm.Status_Name from Company_Master cm inner join City_Master ctm on ctm.City_Id=cm.City inner join Status_Master sm on sm.Status_Id=cm.Status where sm.Status_Name in('Active','Inactive') and cm.Parent_ID=0 and cm.Company_Name like " + "'" + txtsearch.Text + "%'";                
            }


            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }

    protected void gridview1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Company_Master_Add.aspx");
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        GridView1.PageIndex = e.NewSelectedIndex;
        Search();
    }
    protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
         Search();
    }

}
