using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

//This Page is Design & Coding By Alok Date:18.10.2007

public partial class DisplayAirline : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Search();
        }
    }
    public string Rights()
    {
        string Access = "";
        try
        {
            string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


            con = new SqlConnection(strCon);
            con.Open();

            SqlCommand cmd = new SqlCommand(sql_Access, con);

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Access = dr["Airline_Access"].ToString();
                }

            }
            dr.Dispose();
            con.Close();
            cmd.Dispose();

        }
        catch (Exception ee)
        {
            ee.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
        return Access;

    }

    // function for bind grid
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string strAirline_Access = Rights();
            string selectQ = null;
            if (txt_search.Text == "")
            {
                selectQ = "select  AM.Airline_ID as 'Airline_ID', AM.Airline_Code as 'Airline_Code' ,AM.Airline_Text_Code as 'Airline_Text_Code',AM.Airline_Name as 'Airline_Name',CM.Company_Name as 'Company_Name',SM.Status_Name as 'Status_Name' from Airline_Master AM inner join Company_Master CM on   CM.Company_Id =AM.Company_Id inner join Status_Master SM on AM.Status=SM.Status_Id  order by AM.AirLine_Name";
            }

            else
            {
                selectQ = "select AM.Airline_ID as 'Airline_ID',AM.Airline_Code as 'Airline_Code' ,AM.Airline_Text_Code as 'Airline_Text_Code',AM.Airline_Name as 'Airline_Name',CM.Company_Name as 'Company_Name', SM.Status_Name as 'Status_Name' from Airline_Master AM inner join Company_Master CM on   CM.Company_Id =AM.Company_Id inner join Status_Master SM on AM.Status=SM.Status_Id  where AM.Airline_Name like '" + txt_search.Text + "%' order by AM.AirLine_Name";
            }
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdAirline.DataSource = dt;
            grdAirline.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void lnkaddairline_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddAirline.aspx");
    }
    protected void Modify(object sender, CommandEventArgs e)
    {
        Response.Redirect("AddAirline.aspx?Airline_ID=" + e.CommandName);
    }
    protected void grdAirline_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdAirline.PageIndex = e.NewPageIndex;
        Search();
    }
}
