using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

public partial class holidaylist : System.Web.UI.Page
{
    public int sno = 1;

    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        SqlConnection myConnection = new SqlConnection(strCon);
        SqlCommand storeimage = new SqlCommand("INSERT INTO tblholiday "
                + "(city,hotel,days,price,active) "
                + " values (@city, @hotel, @days,@price,@active)", myConnection);

        storeimage.Parameters.Add("@city", SqlDbType.VarChar, 100).Value = txtcity.Text;
        storeimage.Parameters.Add("@hotel", SqlDbType.VarChar, 100).Value = txthotel.Text;
        storeimage.Parameters.Add("@days", SqlDbType.VarChar, 50).Value = txtdays.Text;
        storeimage.Parameters.Add("@price", SqlDbType.Int).Value = txtprice.Text;
        storeimage.Parameters.Add("@active", SqlDbType.VarChar, 5).Value = cmbactive.SelectedValue.ToString();
        myConnection.Open();
        storeimage.ExecuteNonQuery();
        myConnection.Close();

        txtprice.Text = "0";
        txtcity.Text = "";
        txthotel.Text = "";
        txtdays.Text = "";

    }



}