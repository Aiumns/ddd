using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AgentAddressDetails : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            if (Request.QueryString["sno"].ToString() != "")
            {
                DataTable dt_TempFill = dw.GetAllFromQuery("select * from Agent_temp where Agent_Temp_ID='" + Request.QueryString["sno"].ToString() + "'");
                if (dt_TempFill.Rows.Count > 0)
                {
                    lblAddress.Text = dt_TempFill.Rows[0]["agent_address"].ToString();
                    lblconsperson.Text = dt_TempFill.Rows[0]["concerned_person"].ToString();
                }
            }
        }
    }

}
