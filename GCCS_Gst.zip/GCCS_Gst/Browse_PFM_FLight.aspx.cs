using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Browse_PFM_FLight : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    DisplayWrap dw = new DisplayWrap();
    string table2 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                ShowAirline();
                FillDataGv();
              
            }
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        FillDataGv();

    }



    protected void FillDataGv()
    {
        string searchString = null;
        con = new SqlConnection(strcon);
        try
        {
            con.Open();

            if (ddlAirlineCity.SelectedValue != "")
            {
                searchString = "  SELECT AM.Airline_code,AD.Belongs_To_City AS city_id, P.FLIGHT_OPEN_ID,P.Airline_Detail_ID,am.Airline_Name +'-'+ c.city_name as airlineName,P.Flight_No,CONVERT(VARCHAR,P.FLIGHT_DATE,103) AS FLIGHT_DATE,substring(cast(FO.flight_time as varchar),12,50)as flight_time,COUNT(P.AIRWAYBILL_NO) AS AIRWAYBILL_NO,SUM(P.NO_OF_PACKAGES) AS NO_OF_PACKAGES,SUM(P.GROSS_WEIGHT)AS GROSS_WEIGHT,SUM(P.VOLUME_WEIGHT) AS VOLUME_WEIGHT ,Convert(varchar,FO.Close_date,103) as CloseDate  FROM PFM  P INNER JOIN FLIGHT_OPEN FO ON P.FLIGHT_OPEN_ID=FO.FLIGHT_OPEN_ID inner join Airline_Detail ad on ad.Airline_Detail_ID=P.Airline_Detail_ID inner join Airline_Master am on am.Airline_ID=ad.Airline_ID inner join city_master c on AD.Belongs_To_City=c.city_id inner join destination_master d on P.destination_ID=d.destination_id INNER JOIN HANDOVER HM ON HM.HANDOVER_ID=P.HANDOVER_ID WHERE P.Airline_Detail_ID =" + ddlAirlineCity.SelectedValue.Trim() + "   GROUP BY P.FLIGHT_OPEN_ID,P.FLIGHT_NO,P.FLIGHT_DATE ,FO.flight_time,FO.Close_date,am.Airline_Name,c.city_name,P.Airline_Detail_ID,AD.Belongs_To_City ,AM.Airline_code ORDER BY P.Airline_Detail_ID, P.FLIGHT_DATE DESC ";

              

            }
            else
            {
                searchString = "SELECT AM.Airline_code,AD.Belongs_To_City AS city_id, P.FLIGHT_OPEN_ID,P.Airline_Detail_ID,am.Airline_Name +'-'+ c.city_name as airlineName,P.Flight_No,CONVERT(VARCHAR,P.FLIGHT_DATE,103) AS FLIGHT_DATE,substring(cast(FO.flight_time as varchar),12,50)as flight_time,COUNT(P.AIRWAYBILL_NO) AS AIRWAYBILL_NO,SUM(P.NO_OF_PACKAGES) AS NO_OF_PACKAGES,SUM(P.GROSS_WEIGHT)AS GROSS_WEIGHT,SUM(P.VOLUME_WEIGHT) AS VOLUME_WEIGHT ,Convert(varchar,FO.Close_date,103) as CloseDate  FROM PFM  P INNER JOIN FLIGHT_OPEN FO ON P.FLIGHT_OPEN_ID=FO.FLIGHT_OPEN_ID inner join Airline_Detail ad on ad.Airline_Detail_ID=P.Airline_Detail_ID inner join Airline_Master am on am.Airline_ID=ad.Airline_ID inner join city_master c on AD.Belongs_To_City=c.city_id inner join destination_master d on P.destination_ID=d.destination_id INNER JOIN HANDOVER HM ON HM.HANDOVER_ID=P.HANDOVER_ID WHERE P.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ")  GROUP BY P.FLIGHT_OPEN_ID,P.FLIGHT_NO,P.FLIGHT_DATE ,FO.flight_time,FO.Close_date,am.Airline_Name,c.city_name,P.Airline_Detail_ID,AD.Belongs_To_City ,AM.Airline_code ORDER BY P.Airline_Detail_ID, P.FLIGHT_DATE DESC   ";
            }



            string AirlineDetailID = "";
            string AirlineDetailIDTem = "";
            com = new SqlCommand(searchString, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {

                while (dr.Read())
                {
                    string ss = @"  ""  ";
                    //string status = dr["status_name"].ToString();
                    string reopen = "";
                    string pfm = "";
                    DataTable dt_flight = dw.GetAllFromQuery("SELECT MANIFEST_STATUS FROM HANDOVER HM INNER JOIN PFM P ON P.HANDOVER_ID=HM.HANDOVER_ID WHERE P.FLIGHT_OPEN_ID= " + dr["Flight_Open_ID"].ToString() + " and  MANIFEST_STATUS=14");
                    //if (dt_flight.Rows.Count <= 0)
                    //{
                    //   // pfm = @"<a id=""yy"" href=""./Reports/Print_FinalManifest.aspx?fno=" + dr["Flight_No"].ToString() + "&city_id=" + dr["city_id"].ToString() + "&date=" + dr["FLIGHT_DATE"].ToString() + "&Airline_code=" + dr["Airline_code"].ToString() + "&fid=" + dr["Flight_Open_ID"].ToString() + "&AID=" + dr["Airline_Detail_ID"].ToString() + @"""  align=center target=_blank>Print </a> &nbsp; <a id=""xx"" href=""Generate_Manifest.aspx?fno=" + dr["Flight_No"].ToString() + "&city_id=" + dr["city_id"].ToString() + "&date=" + dr["FLIGHT_DATE"].ToString() + "&Airline_code=" + dr["Airline_code"].ToString() + "&fid=" + dr["Flight_Open_ID"].ToString() + "&AID=" + dr["Airline_Detail_ID"].ToString() + @""" class=""boldtext"" align=center class=""but"">View Manifest</a>";
                    //}
                    //else
                    //{
                        pfm = @"<a id=""yy"" href=""Generate_Manifest.aspx?fno=" + dr["Flight_No"].ToString() + "&city_id=" + dr["city_id"].ToString() + "&date=" + dr["FLIGHT_DATE"].ToString() + "&Airline_code=" + dr["Airline_code"].ToString() + "&fid=" + dr["Flight_Open_ID"].ToString() + "&AID=" + dr["Airline_Detail_ID"].ToString() + @""" class=""boldtext"" align=center class =""but"">View PFM</a>";
                       
                    //}

                    //string finalise = @"<a id=""yy"" href=""CreateFInaliseMAnifest.aspx?fno=" + dr["Flight_No"].ToString() + "&city_id=" + dr["city_id"].ToString() + "&date=" + dr["FLIGHT_DATE"].ToString() + "&Airline_code=" + dr["Airline_code"].ToString() + "&fid=" + dr["Flight_Open_ID"].ToString() + "&AID=" + dr["Airline_Detail_ID"].ToString() + @""" class=""boldtext"" align=center class =""but"">Finalise Manifest</a>";


                  

                    string color = "";

                    AirlineDetailIDTem = dr["Airline_Detail_ID"].ToString();
                    if (AirlineDetailID == dr["Airline_Detail_ID"].ToString())
                    {

                        table2 += @"<tr " + color + @"><td nowrap>" + dr["Flight_No"].ToString() + @"</td><td align=center>" + dr["FLIGHT_DATE"].ToString() + @"</td><td align=center>" + dr["flight_time"].ToString() + @"</td><td align=center>" + dr["AIRWAYBILL_NO"].ToString() + @"</td><td width=20%>" + pfm + @"</td> </tr>";
                    }
                    else
                    {
                        table2 += @"<table class=""text"" width=""100%"" align=""center"" border=""1"">";


                        table2 += @"<tr align=""center""><td colspan=""9""  class=""h1 boldtext"">" + dr["airlineName"].ToString() + @"</td><tr>";


                        table2 += @"<tr align=""center""><td nowrap class=""h1 boldtext"">Flt No </td><td class=""h1  boldtext"">Flt Date </td><td class=""h1 boldtext"">Flt Time</td><td class=""h1 boldtext"">Total Shipment </td><td class=""h1 boldtext"">PFM Details</td></tr>";


                        table2 += @"<tr " + color + @"><td nowrap>" + dr["Flight_No"].ToString() + @"</td><td align=center>" + dr["FLIGHT_DATE"].ToString() + @"</td><td align=center>" + dr["flight_time"].ToString() + @"</td><td align=center>" + dr["AIRWAYBILL_NO"].ToString() + @"</td><td width=20%>" + pfm + @"</td> </tr>";
                        AirlineDetailID = dr["Airline_Detail_ID"].ToString();

                    }


                }
                table2 += @"</table>";
                Label1.Text = table2;
            }
            else
            {
                Label1.CssClass = "boldtext";
                Label1.Text = "No Flight Added To PFM";
               
          
                
            }
          
           
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    protected void ShowAirline()
    {

        ddlAirlineCity.Items.Clear();

        con = new SqlConnection(strcon);
        con.Open();
        try
        {
            // com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and a.airline_id in (" + Session["AIRLINEACCESS"].ToString().Substring(0, +Session["AIRLINEACCESS"].ToString().Length - 1) + ") order by Airline_Name", con);
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineCity.Items.Add("Select airline name");
            ddlAirlineCity.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirlineCity.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
}
