using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Agent_RegionWise_Show : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    //DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }

        string checkDate = Session["SelectDate"].ToString();
        string strTop = Session["top"].ToString();
        string[] airline_name_city_text = Session["airline_city_value"].ToString().Split(',');
        string[] airline_name_city_value = Session["airline_city_text"].ToString().Split(',');
        string from_date = Session["from_date"].ToString();
        string to_date = Session["to_date"].ToString();
        string Region_code = Session["selected_region_code"].ToString();
            Int64 count = 1;
            bool record_found = true;
            decimal ch_wt = 0;
            decimal total_wt = 0;
            decimal frt_amt = 0;
            decimal total_frt_amt = 0;
            decimal due_carrier = 0;
            decimal total_due_carrier = 0;
            decimal rev = 0;
            decimal total_rev = 0;
            Response.Write("<center><strong>Agent Region - Wise</strong></center> ");
            Response.Write("<center><strong>" + DateTime.Now.ToString("dd/MM/yyyy") + "</strong></center>");
            Response.Write("<center><span class=text>From : " + from_date + "-" + to_date + "</span></center><br> ");
            try
            {
                con = new SqlConnection(strCon);
                 con.Open();
                    if (checkDate.ToString().Trim() == "0")
                    {
                        cmd = new SqlCommand("select top " + strTop + " AM.Agent_Name as Agent_Name,sum(isnull(Charged_weight,0)) as Charged_weight,sum(isnull(Freight_amount,0)) as Freight_amount,sum(isnull(total_duecarrier,0)) as total_duecarrier from Agent_Master AM inner join Sales S on S.Agent_ID=AM.Agent_ID where s.flight_no in (select flight_no from flight_master where boundgroup='" + Region_code + "') and s.airline_detail_id=" + Convert.ToInt64(airline_name_city_text[1]) + " and s.city_id=" + Convert.ToInt64(airline_name_city_text[0]) + " and s.AWB_date between '" + FormatDateMM(from_date) + "' and '" + FormatDateMM(to_date) + "' and s.status=11 group by Am.Agent_Name order by Charged_weight desc", con);
                    }
                    else
                    {
                        cmd = new SqlCommand("select top " + strTop + " AM.Agent_Name as Agent_Name,sum(isnull(Charged_weight,0)) as Charged_weight,sum(isnull(Freight_amount,0)) as Freight_amount,sum(isnull(total_duecarrier,0)) as total_duecarrier from Agent_Master AM inner join Sales S on S.Agent_ID=AM.Agent_ID where s.flight_no in (select flight_no from flight_master where boundgroup='" + Region_code + "') and s.airline_detail_id=" + Convert.ToInt64(airline_name_city_text[1]) + " and s.city_id=" + Convert.ToInt64(airline_name_city_text[0]) + " and s.Flight_date between '" + FormatDateMM(from_date) + "' and '" + FormatDateMM(to_date) + "' and s.status=11 group by Am.Agent_Name order by Charged_weight desc", con);

                    }

                    dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        Response.Write("<table border=1 width=40% align=center   bordercolor=#bacbcc cellpadding=3 cellspacing=0> ");
                        Response.Write("<tr>");
                        Response.Write("<td ALIGN=CENTER colspan=6><span class=boldtext>Region :" + Region_code + " For " + airline_name_city_value[0] + "</span></td>");
                        record_found = false;
                        Response.Write("<tr>");
                        Response.Write("<td>");
                        Response.Write("<table border=1 width=100% align=center  bordercolor=#bacbcc cellpadding=3 cellspacing=0> ");
                        Response.Write("<tr class=h5>");
                        Response.Write("<td nowrap><b>S.No.</b></td>");
                        Response.Write("<td nowrap ><b>Agent Name</b></td>");
                        Response.Write("<td nowrap ><b>Tonnage</b></td>");
                        Response.Write("<td nowrap><b>FreightAmt</b></td>");
                        Response.Write("<td nowrap><b>Total Due Carrier</b></td>");
                        Response.Write("<td nowrap><b>Revenue</b></td>");
                        Response.Write("<tr>");


                        while (dr.Read())
                        {
                            Response.Write("<tr class=text>");
                            Response.Write("<td>" + count + "</td>");
                            Response.Write("<td align=left>" + dr["Agent_Name"].ToString() + "</td>");
                            ch_wt = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                            total_wt = total_wt + ch_wt;
                            frt_amt = Convert.ToDecimal(dr["Freight_amount"].ToString());
                            total_frt_amt = total_frt_amt + frt_amt;
                            due_carrier = Convert.ToDecimal(dr["total_duecarrier"].ToString());
                            total_due_carrier = total_due_carrier + due_carrier;
                            rev = frt_amt + due_carrier;
                            total_rev = total_rev + rev;
                            Response.Write("<td align=right>" + ch_wt + "</td>");
                            Response.Write("<td align=right>" + frt_amt + "</td>");
                            Response.Write("<td align=right>" + due_carrier + "</td>");
                            Response.Write("<td align=right>" + rev + "</td>");
                            Response.Write("<tr>");
                            count = count + 1;
                        }

                        count = 1;
                        Response.Write("<tr class=h1>");
                        Response.Write("<td colspan=2 align=right><b>Total</b></td>");
                        Response.Write("<td align=right><b >" + total_wt + "</b></td>");
                        Response.Write("<td align=right><b >" + total_frt_amt + "</b></td>");
                        Response.Write("<td align=right><b >" + total_due_carrier + "</b></td>");
                        Response.Write("<td align=right><b >" + total_rev + "</b></td>");
                        Response.Write("<tr>");
                        Response.Write("</table > ");
                        Response.Write("</td>");
                        Response.Write("<tr>");
                        Response.Write("<td colspan=6></td>");
                        Response.Write("</tr>");
                        Response.Write("</table > ");
                        Response.Write("<br>");
                        count = 1;
                        total_wt = 0;
                    }
                    dr.Close();
            }
            catch (Exception eror)
            {

                string s = eror.ToString();
            }
            finally
            {
                con.Close();


            }

            if (record_found)
            {

                Response.Write("<center><strong><span class=error>NO RECORD FOUND BETWEEN THESE DATES</span></strong></center> ");
            }
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
