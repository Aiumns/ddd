using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Data.SqlClient;
using System.Net.Mail;
using System.IO;

public partial class CPP_MAILReport : System.Web.UI.Page
{
    DataTable dt = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        if (!IsPostBack)
        {
            LoadDetails();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }
    public void LoadDetails()
    {
        string email = "";
        string tables = "";
        decimal total_total_cpp = 0;
        decimal total_total_total_cpp = 0;
        decimal total_total_redeem = 0;
        DataTable dt_total = dw.GetAllFromQuery("select * from cppusermap where status=2");
        if (dt_total.Rows.Count > 0)
        {
            foreach (DataRow drow in dt_total.Rows)
            {
                tables = "<table width=100% border=1 style=border-right: maroon thin groove; border-top: maroon thin groove; border-left: maroon thin groove;sborder-bottom: maroon thin groove align=center><tr class=h1><td colspan=3 align=center>CPP DETAILS as on " + DateTime.Today.ToString("MMM-dd") + "</td></tr>";
                DataTable dt_checkagent_city = dw.GetAllFromQuery("Select distinct ab.belongs_to_city as belongs_to_city,CM1.City_name +'(' + cm1.city_code + ')' as city_code from Agent_master am inner join agent_branch ab on ab.agent_id=am.agent_id inner join city_master CM1 on CM1.city_id=ab.belongs_to_city  inner join cppusermap cm on cm.sno in (SELECT DATA FROM SPLIT(cppusermapid,','))  where cppusermapid is  NOT null  and cm.sno=" + drow["sno"] + "");
                if (dt_checkagent_city.Rows.Count > 0)
                {

                    foreach (DataRow dt_Check_city in dt_checkagent_city.Rows)
                    {
                        tables += "<table width=100% border=1 style=border-right: maroon thin groove; border-top: maroon thin groove; border-left: maroon thin groove;sborder-bottom: maroon thin groove align=center><tr class=h1><td colspan=3 align=center>CITY: " + dt_Check_city["city_code"] + "</td></tr>";
                        tables += "<tr style=font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#555555; padding-left:5px; font-weight:bold;><td  align=center> AGENT NAME </td><td  align=center> TOTAL CPP </td><td  align=center> REDEEEMED CPP </td></tr>";
                        DataTable dt_checkagent = dw.GetAllFromQuery("Select distinct ab.agent_id as agent_id from Agent_master am inner join agent_branch ab on ab.agent_id=am.agent_id  inner join cppusermap cm on cm.sno in (SELECT DATA FROM SPLIT(cppusermapid,','))  where cppusermapid is  NOT null and ab.belongs_to_city=" + dt_Check_city["belongs_to_city"] + "  and cm.sno=" + drow["sno"] + "");
                        if (dt_checkagent.Rows.Count > 0)
                        {
                            foreach (DataRow dt_Check in dt_checkagent.Rows)
                            {
                                dt = dw.GetAllFromQuery("Select am.agent_name as agent_name,sum(totalcpp) as totalcpp,sum(redeemedcpp) as redeemedcpp  from Agent_master am inner join agent_branch ab on ab.agent_id=am.agent_id inner join cpp_agentwisetotal ca on ca.agentid=ab.agent_id and ca.cityid=ab.belongs_to_city where  ab.belongs_to_city=" + dt_Check_city["belongs_to_city"] + "  and agentid=" + dt_Check["agent_id"] + " group by agent_name order by totalcpp desc");
                                if (dt.Rows.Count > 0)
                                {
                                    total_total_cpp = total_total_cpp + Convert.ToDecimal(dt.Rows[0]["totalcpp"].ToString());
                                    total_total_total_cpp = total_total_total_cpp + Convert.ToDecimal(dt.Rows[0]["totalcpp"].ToString());
                                    total_total_redeem = total_total_redeem + Convert.ToDecimal(dt.Rows[0]["redeemedcpp"].ToString());
                                    tables += "<tr style=font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#000000; padding-left:5px;><td  align=left width=60%>" + dt.Rows[0]["agent_name"].ToString() + "</td><td  align=right>" + Convert.ToDecimal(dt.Rows[0]["totalcpp"].ToString()) + "</td><td  align=right>" + Convert.ToDecimal(dt.Rows[0]["redeemedcpp"].ToString()) + "</td></tr>";
                                }

                            }
                        }

                        tables += "<tr style=font-family:Verdana, Arial, Helvetica, sans-serif; color:#FFFFFF; font-weight:bold; font-size:10px; line-height:18px; padding-left:35px;><td align=right>Total : " + dt_Check_city["city_code"] + "</td><td align=right>" + Math.Round(total_total_cpp,MidpointRounding.AwayFromZero) + "</td><td align=right>" + Math.Round(total_total_redeem,MidpointRounding.AwayFromZero) + "</td></tr></table>";
                        total_total_cpp = 0;
                        total_total_redeem = 0;
                    }
                   

                }

                if (total_total_total_cpp > 0)
                
                {
                    SmtpClient client = new SmtpClient("192.168.0.3");
                    MailMessage msg = new MailMessage();
                    email = drow["emailid"].ToString();
                    msg.To.Add(email);
                    msg.From = new MailAddress("Info@groupconcorde.com");
                    msg.Subject = "CPP DETAILS";
                    msg.IsBodyHtml = true;
                    msg.Body = " CPP Details are attached as on " + DateTime.Today.ToString("MMM-dd") + ".<br>GCCS SYSTEM";
                    Response.ClearContent();
                    StreamWriter sw = File.CreateText(Server.MapPath("CPPDetails.xls"));
                    sw.WriteLine(tables);
                    sw.Close();
                    msg.Attachments.Add(new Attachment(Server.MapPath("CPPDetails.xls")));
                    msg.Priority = MailPriority.Normal;
                    client.Send(msg);
                    //File.Delete(Server.MapPath("CPPDetails.xls"));                   
                }
                total_total_total_cpp = 0;
            }

            }

        }
 
}

