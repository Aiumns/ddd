using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Drawing;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class IssueStock : System.Web.UI.Page
{
    #region variable declaration
       string Agentid;
    string showalert;
    Int64 conn;
    string cityid;
    string cityname;
    string[] airlinecode;
    int z;
    string recieptdate;
    string updateairlineaccess;
    string Airlineaccess;
    string Receiptlotno;
       string s;
    bool airlinea = false;
       string createdby;
    string createdon ;
    SqlTransaction trans;
    string issueawb; 
    //string ddlcityvalue = null;
    //string ddlcitytext = null;
    string strquery;
    SqlCommand cmd;
    bool citycheck = false;
    SqlDataReader rdr;
    string alertji;
    SqlConnection con;
    SqlDataAdapter sda;
    string acid;
    string agcid;
    string ccid;
    string[] strCityAirline = null;
    string[] strCityAgent = null;
    string[] strAirlineAccesss = null;

    DisplayWrap dw = new DisplayWrap();
    int ss;
    bool AWB = false;
   
    #endregion

    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Issue Stock</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>29 Oct</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription>to issue AWBNo with validation , check</changeDescription>
    /// <modifiedBy>Mukul Chandra</modifiedBy>
    /// <modifiedOn>4th April 08</modifiedOn>
    /// <modifiedby></modifiedby>
    /// <modifiedOn></modifiedOn>
    /// <changeDescription></changeDescription>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;//Getting Connection String For Web.config File.

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnissue.Enabled = false;

            btnissue.Attributes.Add("onclick", "return awbstartingno()");// Calling javascript function;
            //txt_Date.Text = DateTime.Now.ToString("dd/MM/yyyy");//On Load Assign Present Date To Date TextBox
            

            if (!IsPostBack)
            {
                txt_Date.Text = DateTime.Now.ToString("dd/MM/yyyy");//On Load Assign Present Date To Date TextBox
            
                ddlfillairlinecode();//function for bind airline code
                //ddlfillagent();//function for bind agent name  
                CheckBox1.Enabled = false;
                
                ddlAgent.Enabled = false;
                
            }
        }
    }
    #region to bind airlinecode in dropdown list
    protected void ddlfillairlinecode()
    {
        using (con)
        {
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            try
            {
                strquery = " select Airline_Access from dbo.Login_Master where Email_ID='" + Session["EMailID"] + "'";//query for getting airline access from login master on the basis of email 
                cmd = new SqlCommand(strquery, con);// pass argument in command  
                rdr = cmd.ExecuteReader();
                rdr.Read();
                string airline_access = rdr["Airline_Access"].ToString();//getting value in string airline_access
                rdr.Close();
                //string[] split_ac = airline_access.Split(',');//getting value in string arrey with split 
                ddlAirlinecode.Items.Insert(0, "--Select--");// add --select--on 0 index
                ddlAirlinecode.Items[0].Value = "0";
                strquery = "select  am.Airline_Code,am.airline_name,cm.City_Code,ad.Airline_Detail_ID,cm.City_ID from dbo.Airline_Master as am inner join airline_detail as ad on ad.airline_id=am.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City where ad.Airline_Detail_ID in (" + airline_access + ")  and am.status='2' order by am.Airline_Code asc";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                    ddlAirlinecode.Items.Add(new ListItem(rdr["airline_code"].ToString() + '-' + rdr["Airline_name"].ToString() + ',' + rdr["City_Code"].ToString(), rdr["City_ID"].ToString() + "-" + rdr["Airline_Detail_ID"].ToString()));
                rdr.Close();
               
            }
            catch (SqlException ee)
            {
                Response.Write("sql error" + ee.Message);
            }
        }
    }
    #endregion
    #region to bind agent in dropdownlist
    protected void ddlfillagent()
    {
        con = new SqlConnection(strCon);
        con.Open();
        ddlAgent.Items.Insert(0, "--Select--");
        ddlAgent.Items[0].Value = "0";
        if (ddlAirlinecode.SelectedIndex > 0)
        {
            string[] citycode = ddlAirlinecode.SelectedItem.Text.Split(',');
            string airline_access_code = ddlAirlinecode.SelectedValue.ToString();
            string city_id = ddlAirlinecode.SelectedItem.Value;
            string[] belongs_to_city = city_id.Split('-');
            //DataTable city_id = new DataTable();

            //city_id = dw.GetAllFromQuery("SELECT * FROM dbo.City_Master WHERE City_Code='"+citycode[1]+"'");
            //************Added On 25 Mar 2011************For Offline Agent Testing***********
            //strquery = "select  am.agent_name,ab.agent_id from agent_branch as ab inner join agent_master as am on am.agent_id=ab.agent_id inner join city_master as cm on cm.city_id=ab.belongs_to_city where cm.city_code='" + citycode[1] + "' and ab.status=2 order by am.agent_name ";

           // strquery = "select DISTINCT am.agent_name,ab.agent_id from agent_branch as ab inner join agent_master as am on am.agent_id=ab.agent_id inner join city_master as cm on cm.city_id=ab.belongs_to_city where ab.status=2 order by am.agent_name ";

        /**************************************Edited by Hemant Sharma on 11'th Sepetember 2013*******************************/

            strquery = "select AM.agent_name, AM.Agent_ID from Agent_Master AM INNER JOIN Agent_Branch AB ON AB.Agent_ID=AM.Agent_ID INNER JOIN Login_Master LM ON AB.Agent_Branch_ID=LM.Agent_ID  WHERE Airline_Access LIKE '%" + belongs_to_city[1] + "%' OR Airline_Access LIKE '" + belongs_to_city[1] + "%' OR Airline_Access LIKE '%" + belongs_to_city[1] + "' OR  Airline_Access LIKE '" + belongs_to_city[1] + "' AND Belongs_To_City='" + belongs_to_city[0] + "' order by Agent_Name asc";

            //strquery = "select Agent_ID,Agent_Name from Agent_Master order by Agent_Name asc ";
            cmd = new SqlCommand(strquery, con);
            rdr = cmd.ExecuteReader();

            while (rdr.Read())
                ddlAgent.Items.Add(new ListItem(rdr["Agent_Name"].ToString(), rdr["Agent_ID"].ToString()));
        }
        
    }
    #endregion

    //int i = 0;// 
     
   

    #region task done on selected index changed of ddlagent so that city bound on the basis of both airline code and agent name(regarding cityid)
    protected void ddlagentindexchanged(object sender, EventArgs e)
    {
        btnissue.Enabled = true;
       
    }
    #endregion
    #region function to fetch lot issue_lotno
    int lotNoCheck()
    {
        int lot = 0;//used for return integer value.
        con = new SqlConnection(strCon);//Making Connection
        cmd = new SqlCommand("Select Max(Issue_LotNo) From Stock_Master", con);//Giving Connection String.
        using (con)
        {
            try
            {
                con.Open();//Open Connection
                if (Convert.IsDBNull(cmd.ExecuteScalar()))//Check For Receipt_LotNo Present or not
                    lot = 0;//If Not having any Receipt_LotNo id then return 0.
                else
                {
                    //int i = Convert.ToInt16(cmd.ExecuteScalar());//Getting Receipt_LotNo
                    //**********Added on 19 Nov 2010****************
                    int i = Convert.ToInt32(cmd.ExecuteScalar());//Getting Receipt_LotNo
                    lot = i;//Make it return
                }
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
                Response.Write(err);
            }
            return lot;//Returning Receipt_LotNo to calling Statement
        }
    }
    #endregion
    #region on generate click
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            ArrayList ar = new ArrayList();//Creating Array For Store AWB No During Generation
            double val = Convert.ToDouble(txtAWB.Text);//Getting AWB No Lot
            //Loop For Generation Of AWBNo.
            for (int i = 1; i <= int.Parse(txtAWBN.Text); i++)
            {
                if (i == 1)//Check for How Many No awb Have.
                {
                    string strI = val.ToString() + Convert.ToString(val % 7);
                    int l = strI.Length;
                    if (l == 1)
                        strI = "0000000" + strI;
                    else if (l == 2)
                        strI = "000000" + strI;
                    else if (l == 3)
                        strI = "00000" + strI;
                    else if (l == 4)
                        strI = "0000" + strI;
                    else if (l == 5)
                        strI = "000" + strI;
                    else if (l == 6)
                        strI = "00" + strI;
                    else if (l == 7)
                        strI = "0" + strI;
                    ar.Add(ddlAirlinecode.SelectedItem.Text + "-" + strI);//Adding Value To the Array
                }
                else
                {
                    val = val + 1;
                    double val2 = val % 7; //Math.IEEERemainder(val, 7);
                    string strI = val.ToString() + Math.Abs(val2);
                    int l = strI.Length;
                    if (l == 1)
                        strI = "0000000" + strI;
                    else if (l == 2)
                        strI = "000000" + strI;
                    else if (l == 3)
                        strI = "00000" + strI;
                    else if (l == 4)
                        strI = "0000" + strI;
                    else if (l == 5)
                        strI = "000" + strI;
                    else if (l == 6)
                        strI = "00" + strI;
                    else if (l == 7)
                        strI = "0" + strI;
                    ar.Add(ddlAirlinecode.SelectedItem.Text + "-" + strI);//Adding Value To The Array
                }
            }
            lstAWB.DataSource = ar;//Binding ListBox To the Array
            lstAWB.DataBind();//Assigning Value To The ListBox
            lblst.Visible = true;
            lbllt.Visible = true;
            lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
            lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
        }
    }
    #endregion
    #region bool function for checking awb no and more
    bool CheckAWBNO()
    {
        string str = "";//For Getting String
        con = new SqlConnection(strCon);//Making Connection
        try
        {
            con.Open();//Opening Connection
            AWB = true;//Making Existance is true
            //Loop For Checking Existance
            for (int i = 0; i < lstAWB.Items.Count; i++)
            {
                strquery = "Select * From Stock_Master Where (Status='8' or status='17') and  AirWayBill_No='" + lstAWB.Items[i].ToString() + "'";//Giving Sql Query
                cmd = new SqlCommand(strquery, con);//Giving Commands 
                rdr = cmd.ExecuteReader();//Getting Values to Reader
                if (rdr.Read())//Reading Values From Reader
                {
                    AWB = false;//Making Existance FAlse                    
                    ss = Convert.ToInt32(rdr["City_ID"].ToString());
                    if (str == "")
                        str = lstAWB.Items[i].Text;//Getting Values To String
                    else
                        str = str + "," + lstAWB.Items[i].Text;//Getting Values To String
                }
                else
                {
                    issue.Visible = false;
                    lblaissue.Visible = true;
                    lblaissue.Text = "AWB No. not available for issue";
                    btnreturn.Visible = true;
                }
                rdr.Close();//Closing The Data Reader
            }
            if (AWB == false)//Checking For Existance Of AWB No.
            {
                if (ss == int.Parse(cityid) )
                //if (ss == int.Parse(ddlcity.SelectedValue))
                {
                    lblissue.Visible = true;
                    issue.Visible = false;
                    btnreturn.Visible = true;
                    lblissue.Text = "Issued Airway No are<br><br>" + str;
                }
                else
                {
                    cityerror.Visible = true;
                    issue.Visible = false;
                    btnreturn.Visible = true;
                    cityerror.Text = "city not matched with<br><br>" + str;
                }
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return AWB;//Returning From Function.
    }
    #endregion

    #region on click event of btnissue

    protected void btnissue_Click(object sender, EventArgs e)

    {
        
        
        //CheckAirlineAceess();

        using (con)
            {          
                string date = ConvertDate(txt_Date.Text);
                int nos = lstAWB.Items.Count;//Counting Nos of AWBs
                if (nos > 0)
                {
                    CheckAirlineAceess();
                    int lot = lotNoCheck() + 1;
                    con = new SqlConnection(strCon);
                    con.Open();
                    try
                    {
                        for (int f = 0; f <= (lstAWB.Items.Count - 1); f++)
                        {
                            if (lstAWB.Items[f].Selected == true)
                            {
                                strquery = "select status from stock_master where status='8' and AirWayBill_No='" + lstAWB.Items[f].ToString() + "'";
                                cmd = new SqlCommand(strquery, con);
                                rdr = cmd.ExecuteReader();
                                if (rdr.HasRows == true)
                                {
                                    rdr.Close();
                                    citymatter();
                                trans = con.BeginTransaction();

                                strquery = " update  dbo.Stock_Master set Agent_ID=@Agent_ID,Issue_Date=@Issue_Date,Status=@Status,Issue_LotNo=@Issue_LotNo,Issued_By=@Issued_By,Issued_On=@Issued_On,Issued_Agent_Id=@Issued_Agent_Id where AirWayBill_No='" + lstAWB.Items[f].ToString() + "' and Status='8'";//Giving Sql Query  ";//Giving Sql Query;
                                    cmd = new SqlCommand(strquery, con, trans);
                                    cmd.Parameters.AddWithValue("@Agent_ID", ddlAgent.SelectedValue);
                                    cmd.Parameters.AddWithValue("@Issue_Date", date);
                                    cmd.Parameters.AddWithValue("@Status", 16);
                                    cmd.Parameters.AddWithValue("@Issue_LotNo", lot);
                                    cmd.Parameters.AddWithValue("@Issued_By", Session["EMailID"].ToString());
                                    cmd.Parameters.AddWithValue("@Issued_On", DateTime.Now);
                                    cmd.Parameters.AddWithValue("@Issued_Agent_Id", ddlAgent.SelectedValue);
                                    cmd.ExecuteNonQuery();

                                    strquery = "select * from dbo.Stock_Master where AirWayBill_No='" + lstAWB.Items[f].ToString() + "'";
                                    cmd = new SqlCommand(strquery, con, trans);
                                    rdr = cmd.ExecuteReader();

                                    rdr.Read();
                                    recieptdate = rdr["Receipt_Date"].ToString();
                                    Receiptlotno = rdr["Receipt_LotNo"].ToString();
                                    createdby = rdr["Created_By"].ToString();
                                    createdon = rdr["Created_On"].ToString();
                                    rdr.Close();
                                    strquery = "insert into db_owner.Stock_History(AirWayBill_No,City_Name,Receipt_Date,Receipt_LotNo,Created_By,Created_On,Agent_Name,Issue_Date,Status,Issue_LotNo)values(@AirWayBill_No,@City_Name,@Receipt_Date,@Receipt_LotNo,@Created_By,@Created_On,@Agent_Name,@Issue_Date,@Status,@Issue_LotNo) ";
                                    //string city = ddlcity.SelectedItem.Text;
                                    //int str = city.IndexOf("-");
                                    cmd = new SqlCommand(strquery, con, trans);
                                    cmd.Parameters.AddWithValue("@AirWayBill_No", lstAWB.Items[f].ToString());
                                    cmd.Parameters.AddWithValue("@City_Name", cityname );
                                    cmd.Parameters.AddWithValue("@Receipt_Date", recieptdate);
                                    cmd.Parameters.AddWithValue("@Receipt_LotNo", Receiptlotno);
                                    cmd.Parameters.AddWithValue("@Created_By", createdby);
                                    cmd.Parameters.AddWithValue("@Created_On", createdon);
                                    cmd.Parameters.AddWithValue("@Agent_Name", ddlAgent.SelectedItem.Text);
                                    cmd.Parameters.AddWithValue("@Issue_Date", date);
                                    cmd.Parameters.AddWithValue("@Status", "Issued");
                                    cmd.Parameters.AddWithValue("@Issue_LotNo", lot);
                                    cmd.ExecuteNonQuery();
                                    issueawb = issueawb + lstAWB.Items[f] + ",";
                                    trans.Commit();
                                    issue.Visible = false;
                                    lblissue.Visible = true;
                                    btnreturn.Visible = true;
                                    btnreturn.Enabled = true;
                                    lblissue.ForeColor = Color.Blue;
                                    lblissue.Text = "Issued AWBNo for" + "  " + ddlAgent.SelectedItem.Text + "  " + "are following:" + "<br><br>" + issueawb;

                                }
                                else
                                {
                                    issueawb = issueawb + lstAWB.Items[f] + ",";
                                    issue.Visible = false;
                                    lblissue.Text = null;
                                    lblissue.Visible = true;
                                    lblissue.ForeColor = Color.Red;
                                    lblissue.Text = "Sorry," + "<br>" +"The AWB No " + issueawb + " " + "for" + " "+ ddlAgent.SelectedItem.Text + "<br>" + "are  already issued";
                                    btnreturn.Visible = true;
                                    btnreturn.Enabled = true;
                                }
                                rdr.Close();
                              
                            }
                        }
                        
                    }
                        
                    catch (SqlException ee)
                    {
                        
                        Response.Write("sql error" + ee.Message);
                        trans.Rollback();
                    }
                }
            }        
    }
    #endregion
    #region function for convert date whatever taken in txt_date into true format
    string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    #endregion

    #region task on btnretun so that page reflect on original part
    protected void btnreturn_Click(object sender, EventArgs e)
    {
        issue.Visible = true;
        btnreturn.Enabled = false;
        CheckBox1.Enabled = false;
        lblerrlistbox.Visible = false;        
        txt_Date.Text = DateTime.Now.ToString("dd/MM/yyyy");//Displaying Current Date After Clear Entry        
        txtAWB.Text = "";//Blanking TextBoxes
        txtAWBN.Text = "";//Blanking TextBoxes                
        ddlAirlinecode.SelectedIndex = 0;
        //ddlcity.SelectedIndex = 0;
        ddlAgent.SelectedIndex = 0;
        ddlAgent.Enabled = false;
        lstAWB.Items.Clear();
        //ddlcity.Items.Clear();
        //lblcityerror.Visible = false;
        lblissue.Visible = false;
        lbllt.Visible = false;
        lblst.Visible = false;
        lblissue.Visible = false;
        btnreturn.Visible = false;
        lblaissue.Visible = false;
        //lblcityerror.Visible = false;
        cityerror.Visible = false;
    }
    #endregion

    public  void topawbno()
    {
        RequiredFieldValidator6.Enabled = true;
        lstAWB.Items.Clear();
        using (con)
        {
            if (ddlAirlinecode.SelectedIndex == 0)
            {
                lstAWB.Items.Clear();
              
                ddlAgent.Enabled = false;
                CheckBox1.Enabled = false;
                btnissue.Enabled = false;
                lbllt.Text = null;
                lblst.Text = null;
            }
            else
            {
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            try
            {
                ddlAgent.Enabled = false;
                //ddlAgent.SelectedIndex = 0;
                string airlinetext = ddlAirlinecode.SelectedItem.Text.ToString();
                string[] citycode = airlinetext.Split(',');
                string[] airlinecode = citycode[0].Split('-');
                strquery="select city_id, city_name from city_master where city_code='"+ citycode[1]+"'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                rdr.Read();
                cityid = rdr["city_id"].ToString();
                cityname = rdr["city_name"].ToString();
                rdr.Close();
                if (rdbtnCheck.SelectedItem.Value == "0")
                {
                    strquery = " select top 10 AirWayBill_No from stock_master where City_ID='" + cityid + "' and AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8' or status='17') and neutralawb='N'";//query for getting airline access from login master on the basis of email 
                }
                else
                {
                    strquery = " select top 10 AirWayBill_No from stock_master where City_ID='" + cityid + "' and AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8' or status='17') and neutralawb='Y'";//query for getting airline access from login master on the basis of email 
                }
                cmd = new SqlCommand(strquery, con);// pass argument in command                  
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        lstAWB.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));

                    }
                    ddlAgent.Enabled = true;
                    RequiredFieldValidator6.Enabled = false;
                    for (int x = 0; x < lstAWB.Items.Count; x++)
                    {
                        lstAWB.Items[x].Selected = true;
                    }
                    CheckBox1.Enabled = true;
                    CheckBox1.Checked = true;
                    //ddlAgent.SelectedIndex = 0;
                    //rbtnselect.SelectedValue = "0";
                    lblerrlistbox.Visible = false;
                    lblst.Visible = true;
                    lbllt.Visible = true;
                    lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                    lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;                  
                }
                else
                {
                    lblst.Visible = false;
                    lbllt.Visible = false;
                    lblerrlistbox.Visible = true;
                    lblerrlistbox.Text = "No AWBNo found for issue";
                    CheckBox1.Enabled = false;                    
                }

                txtAWB.Text = "";
                txtAWBN.Text = "";
                rdr.Close();
            }
            catch (SqlException ee)
            {
                Response.Write("sql error" + ee.Message);
            }
        }
    }
        RequiredFieldValidator6.Enabled = true;
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        lstAWB.Items.Clear();
        //Label1.Text = "";
        lbllt.Text = "";
        lblst.Text = "";
        Label2.Text = "";
        Label3.Text = "";
        btnissue.Enabled = true;
        citymatter();
        RequiredFieldValidator6.Enabled = true;
        if (!(txtAWB.Text=="") && !(txtAWBN.Text==""))
        {
            using (con)
            {
                RequiredFieldValidator6.Enabled = true;
                con = new SqlConnection(strCon);//intialise connection  
                con.Open();//connection open   
                string a = cityid;
                string strquery1 = "";
                try
                {
                    if (rdbtnCheck.SelectedItem.Value == "0")
                    {
                        strquery1 = "select  Receipt_LotNo from stock_master where City_ID='" + cityid + "' and AirWayBill_No like  '%" + airlinecode[0] + "-" + txtAWB.Text + "' and neutralawb='N'";//query for getting airline access from login master on the basis of email ";
                        strquery = "select  AirWayBill_No,status from stock_master where Receipt_LotNo=(" + strquery1 + ") and (Status='8' or status='17') and neutralawb='N' ORDER BY dbo.Stock_Master.AirWayBill_No";
                    }
                    else
                    {
                        strquery1 = "select  Receipt_LotNo from stock_master where City_ID='" + cityid + "' and AirWayBill_No like  '%" + airlinecode[0] + "-" + txtAWB.Text + "' and neutralawb='Y'";//query for getting airline access from login master on the basis of email ";
                        strquery = "select  AirWayBill_No,status from stock_master where Receipt_LotNo=(" + strquery1 + ") and (Status='8'  or status='17') and neutralawb='Y' ORDER BY dbo.Stock_Master.AirWayBill_No ";
                    }

                    
                    cmd = new SqlCommand(strquery, con);// pass argument in command  
                    lstAWB.DataTextField = "AirWayBill_No";
                    //ListBox1.DataTextField = "AirWayBill_No";
                    rdr = cmd.ExecuteReader();
                    int count=int.Parse(txtAWBN.Text);
                    if (rdr.HasRows)
                    {
                        conn = 0;
                        while (rdr.Read())
                        {

                            decimal m = decimal.Parse(rdr["AirWayBill_No"].ToString().Substring(4));
                            decimal p=decimal.Parse(txtAWB.Text);
                            string sts = rdr["status"].ToString();
                            if (decimal.Parse(rdr["AirWayBill_No"].ToString().Substring(4)) >= decimal.Parse(txtAWB.Text))
                            {
                                if (count != 0)
                                {
                                    if (sts == "8" || sts=="17")
                                    {
                                        lstAWB.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                                        lblst.Visible = true;
                                        lbllt.Visible = true;
                                        lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                                        lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
                                    }
                                    if (sts == "16")
                                    {
                                        Label2.Visible = true;
                                        Label3.Visible = true;
                                        Label3.Text = "Already Issued AWB No:-";
                                        //ListBox1.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                                        Label2.Text += rdr["AirWayBill_No"].ToString()+" , ";
                                         //alertji = m.ToString();
                                         conn++;

                                    
                                    }
                                    //showalert = showalert +  alertji + "</br>";

                                    count--;
                                   
                                    
                                }
                                
                            }
                            
                            
                        }
                        lblerrlistbox.Visible = false;                      
                            for (int q = 0; q < lstAWB.Items.Count; q++)
                            {
                                lstAWB.Items[q].Selected = true;
                            }
                            //rbtnselect.SelectedValue = "0";
                            CheckBox1.Enabled = true;
                            CheckBox1.Checked = true;
                            lblerrlistbox.Visible = false;
                        
                        
                        if(Convert.ToInt16 (txtAWBN.Text)>(lstAWB.Items.Count) )
                        {
                            lblerrlistbox.Visible = true;
                        lblerrlistbox.Text="Only"+"  "+lstAWB.Items.Count +" "+" "+ " AWBNo.(s) are Available. ";
                        }
                        //lblst.Visible = true;
                        //lbllt.Visible = true;
                        //lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                        //lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
                    }
                        

                    else
                    {
                        lblerrlistbox.Visible = true;
                        lblerrlistbox.Text = "No AWBNo. Found";
                        CheckBox1.Enabled = false;
                        lblst.Visible = false;
                        lbllt.Visible = false;
                    }
                    rdr.Close();                   
                }              
                catch (SqlException ee)
                {
                    Response.Write("sql error" + ee.Message);
                }              
            }
        }
        else            
        {
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            
            if ((txtAWB.Text == "") && !(txtAWBN.Text == ""))
            {
                RequiredFieldValidator6.Enabled = true;
                lblerrlistbox.Visible = false;
                string strquery = "";
                if (rdbtnCheck.SelectedItem.Value == "0")
                {
                     strquery = strquery = "select top " + int.Parse(txtAWBN.Text) + " AirWayBill_No,status from stock_master where City_ID='" + cityid + "'and   AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8'  or status='17') and neutralawb='N' ";
                }
                else
                {
                    strquery = strquery = "select top " + int.Parse(txtAWBN.Text) + " AirWayBill_No,status from stock_master where City_ID='" + cityid + "'and   AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8'  or status='17') and neutralawb='Y' ";
                }
                cmd = new SqlCommand(strquery, con);// pass argument in command  
                lstAWB.DataTextField = "AirWayBill_No";
                //ListBox1.DataTextField = "AirWayBill_No";
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows )
                {
                    while (rdr.Read())

                    {
                        string topsts = rdr["status"].ToString();
                        if (topsts == "8" || topsts=="17")
                        {
                            lstAWB.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                            lblst.Visible = true;
                            lbllt.Visible = true;
                            lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                            lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
                        }
                        if (topsts == "16")
                        {
                            //ListBox1.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                            Label2.Visible = true;
                            Label3.Visible = true;
                            //ListBox1.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                            Label2.Text += rdr["AirWayBill_No"].ToString() + " , ";
                        
                        }
                       
                    }
                        for (int q = 0; q < lstAWB.Items.Count; q++)
                        {
                            lstAWB.Items[q].Selected = true;
                        }
                        //rbtnselect.SelectedValue = "0";
                        CheckBox1.Enabled = true;
                        CheckBox1.Checked = true;
                    lblerrlistbox.Visible = false;                    
                    if (Convert.ToInt16(txtAWBN.Text) > (lstAWB.Items.Count))
                    {
                        lblerrlistbox.Visible = true;
                        lblerrlistbox.Text = "Only" + "  " + lstAWB.Items.Count + " " + " " + " AWB No.(s) are Available.";
                    }
                    //lblst.Visible = true;
                    //lbllt.Visible = true;
                    //lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                    //lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
                }
                else
                {
                    lblerrlistbox.Visible = true;
                    lblerrlistbox.Text = "No AWBNo. Found.";
                    CheckBox1.Enabled = false;
                    lbllt.Visible = false;
                    lblst.Visible = false;
                }
                rdr.Close();
            }
        }
        if ((txtAWB.Text == "") && (txtAWBN.Text == ""))
        {
            lblerrlistbox.Visible = false;
            RequiredFieldValidator6.Enabled = false;
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            if (rdbtnCheck.SelectedItem.Value == "0")
            {
                strquery = " select top 10 AirWayBill_No,status from stock_master where City_ID='" + cityid + "' and AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8'  or status='17') and neutralawb='N'";//query for getting airline access from login master on the basis of email 
            }
            else
            {
                strquery = " select top 10 AirWayBill_No,status from stock_master where City_ID='" + cityid + "' and AirWayBill_No like '" + airlinecode[0] + "%' and (Status='8'  or status='17') and neutralawb='Y'";//query for getting airline access from login master on the basis of email 
            }
            cmd = new SqlCommand(strquery, con);// pass argument in command  
            //rdr = new SqlDataReader();

            rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    string topsts = rdr["status"].ToString();
                    if (topsts == "8" || topsts=="17")
                    {
                        lstAWB.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                        lblst.Visible = true;
                        lbllt.Visible = true;
                        lblst.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                        lbllt.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
                    }
                    if (topsts == "16")
                    {
                        //ListBox1.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                        Label2.Visible = true;
                        Label3.Visible = true;
                        //ListBox1.Items.Add(new ListItem(rdr["AirWayBill_No"].ToString()));
                        Label2.Text += rdr["AirWayBill_No"].ToString() + " , ";
                    }
                }
                lblerrlistbox.Visible = false;
                RequiredFieldValidator6.Enabled = false;                
                    for (int q = 0; q < lstAWB.Items.Count; q++)
                    {
                        lstAWB.Items[q].Selected = true;
                    }
                    //rbtnselect.SelectedValue = "0";
                    CheckBox1.Enabled = true;
                    CheckBox1.Checked = true;
            }
            else
            {
                lblerrlistbox.Visible = true;
                lblerrlistbox.Text = "No AWBNo. Found.";
                CheckBox1.Enabled = false;
                lblst.Visible = false;
                lblst.Visible = false;
            }
            rdr.Close();        
        }
    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        ddlAirlinecode.SelectedIndex = 0;
        //ddlcity.Enabled = false;
        ddlAgent.Enabled = false;
        lblerrlistbox.Visible = false;
        ddlAgent.SelectedIndex = 0;
        rdbtnCheck.SelectedIndex = 0;
        txtAWB.Text = null;
        lbllt.Visible = false;
        lblst.Visible = false;
        CheckBox1.Enabled = false;
        txtAWBN.Text = null;
        txt_Date.Text = null;
        //ddlcity.Items.Clear();
        lstAWB.Items.Clear();
        txt_Date.Text = DateTime.Now.ToString("dd/MM/yyyy");        
    }
    protected void rbtnselect_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void txt_Date_TextChanged(object sender, EventArgs e)
    {

    }
    public bool CheckAirlineAceess()
    {
        using (con)
        {
            citymatter();
            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                //*************Added On 07 May 2011 (Only for Testing-Offline Agent case(City Free Agent))*****
                DataTable dtOfflineAgentCheck=dw.GetAllFromQuery("select * from agent_master where agent_id="+ddlAgent.SelectedValue+" and offline_agent='Y'");
                if (dtOfflineAgentCheck.Rows.Count > 0)
                {
                    strquery = "select  airline_access,agent_id from login_master where agent_id=(select TOP 1 agent_branch_id from agent_branch where agent_id='" + ddlAgent.SelectedValue + "' and offline_city='" + dtOfflineAgentCheck.Rows[0]["Offline_City"].ToString() + "')";
                }
                else
                {
                    strquery = "select  airline_access,agent_id from login_master where agent_id=(select agent_branch_id from agent_branch where agent_id='" + ddlAgent.SelectedValue + "' and belongs_to_city='" + cityid + "')";
                }

                //////strquery = "select  airline_access,agent_id from login_master where agent_id=(select agent_branch_id from agent_branch where agent_id='" + ddlAgent.SelectedValue + "')";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
            }
            catch (SqlException ss)
            {
                Response.Write("sql error" + ss.Message);
            }
            catch (Exception mm)
            {
                Response.Write("error occur" + mm.Message);
            }

            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Airlineaccess = rdr["airline_access"].ToString();
                    Agentid = rdr["agent_id"].ToString();

                    updateairlineaccess = Airlineaccess + "," + ddlAirlinecode.SelectedValue + ",";

                }
                rdr.Close();
                //string removecomma = Airlineaccess.Substring(0, Airlineaccess.LastIndexOf(','));
                if (Airlineaccess.Length > 1)
                {
                    strAirlineAccesss = Airlineaccess.Split(',');

                    for (z = 0; z < strAirlineAccesss.Length; z++)
                    {
                        if (strAirlineAccesss[z] == (ddlAirlinecode.SelectedValue))
                        {
                            airlinea = true;
                        }
                    }
                }
            }
            rdr.Close();
                if (airlinea != true)
                {
                    airlinea = false;
                    strquery = "update login_master set airline_access='" + updateairlineaccess.Substring(0,updateairlineaccess.Length-1) + "' where airline_access='" + Airlineaccess + "' and agent_id='" + Agentid + "'";
                    cmd = new SqlCommand(strquery, con);
                    cmd.ExecuteNonQuery();
                }
                return airlinea;
            }
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (ddlAgent.SelectedIndex == 0)
        {
            btnissue.Enabled = false;
        }
        else
        {
            btnissue.Enabled = true;
        }
        if (CheckBox1.Checked == true)
        {
           

            for (int q = 0; q < lstAWB.Items.Count; q++)
            {
                lstAWB.Items[q].Selected = true;
            }
        }
        else
        {
            for (int q = 0; q < lstAWB.Items.Count; q++)
            {
                lstAWB.Items[q].Selected = false;

            }
            lstAWB.Items[0].Selected = true;
        }
    }
    protected void airlindecodesindexchanged(object sender, EventArgs e)
    {

        ddlAgent.Items.Clear();
        Label3.Text = "";
        Label2.Text = "";
        ddlfillagent();
        topawbno();

        if (ddlAirlinecode.SelectedValue == "150")
        {
            rdbtnCheck.SelectedValue = "1";
        }
        else
        {
            rdbtnCheck.SelectedValue = "0";
        }
    }
    public void citymatter()
    { 
      using (con)
        {
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            
                string airlinetext = ddlAirlinecode.SelectedItem.ToString();
                string[] citycode = airlinetext.Split(',');
                 airlinecode=airlinetext.Split('-');
                strquery="select city_id, city_name from city_master where city_code='"+citycode[1]+"'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                rdr.Read();
                cityid = rdr["city_id"].ToString();
                cityname = rdr["city_name"].ToString();
                rdr.Close();
    
    
    }
      }

    protected void rdbtnCheck_SelectedIndexChanged(object sender, EventArgs e)
    {
        topawbno();
    }
}
