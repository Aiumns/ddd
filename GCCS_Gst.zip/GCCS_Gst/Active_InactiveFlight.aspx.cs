﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Text.RegularExpressions;
public partial class Active_InactiveFlight : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter sda;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string Table = "";
    string Table2 = "";
    int ToTal = 0;
    int count = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
           
        }
        htmlTableSimple();
      
    }
    public void htmlTableSimple()
    {
        try
        {
            SqlDataReader dr1;      
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select fm.*,cm.city_name as origin,dm.destination_name as Dest,sm.status_name as status from flight_master fm inner join status_master sm on fm.status=sm.status_id inner join city_master cm on fm.origin=cm.city_id inner join destination_master dm on fm.destination=dm.destination_id where fm.status=2", con);
          
            dr1 = com.ExecuteReader();
            if (dr1.HasRows)
            {

                Table += @"<table align=center border=1><tr class=h1 align=left><th>Sno</th><th align=center>Flt No</th><th align=center>Origin</th><th align=center>Dest</th><th align=center>Capacity</th><th align=center>Status</th></tr>";
                while (dr1.Read())
                {
                    count++;

                    Table += @"<tr><td align=center class=boldtext>" + count + @"</td><td align=left class=boldtext nowrap>" + dr1["flight_no"].ToString() + @"</td><td align=left class=boldtext nowrap>" + dr1["origin"].ToString() + @"</td><td align=center class=boldtext>" + dr1["Dest"].ToString() + @"</td><td align=center class=boldtext>" + dr1["capacity"].ToString() + @"</td><td align=center class=boldtext>" + dr1["status"].ToString() + @"</td></tr>";

                }
                dr1.Close();
                con.Close();
              
            }
            else
            {
                Table += @"<Table align=center width=60% border=1><tr>&nbsp;<center><span class=error><b>No Record Found</b></span></center></tr></Table>";
                lblActive.Text = Table;
            }

            Table += "</table>";

            lblActive.Text = Table;
            //StringBuilder strTab = new StringBuilder();
            //strTab.Append("<div id=\"fragment-1\">");
            //strTab.Append(lblActive.Text);
            //strTab.Append("</div>");
            count = 0;

            //************************For Inactive***************************
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select fm.*,cm.city_name as origin,dm.destination_name as Dest,sm.status_name as status from flight_master fm inner join status_master sm on fm.status=sm.status_id inner join city_master cm on fm.origin=cm.city_id inner join destination_master dm on fm.destination=dm.destination_id where fm.status=5", con);
           
            dr1 = com.ExecuteReader();
            if (dr1.HasRows)
            {

                Table2 += @"<table align=center border=1><tr class=h1 align=left><th>Sno</th><th align=center>Flt No</th><th align=center>Origin</th><th align=center>Dest</th><th align=center>Capacity</th><th align=center>Status</th></tr>";
                while (dr1.Read())
                {
                    count++;

                    Table2 += @"<tr><td align=center class=boldtext>" + count + @"</td><td align=left class=boldtext nowrap>" + dr1["flight_no"].ToString() + @"</td><td align=left class=boldtext nowrap>" + dr1["origin"].ToString() + @"</td><td align=center class=boldtext>" + dr1["Dest"].ToString() + @"</td><td align=center class=boldtext>" + dr1["capacity"].ToString() + @"</td><td align=center class=boldtext>" + dr1["status"].ToString() + @"</td></tr>";

                }
                dr1.Close();
                con.Close();

            }
            else
            {
                Table2 += @"<Table align=center width=60% border=1><tr>&nbsp;<center><span class=error><b>No Record Found</b></span></center></tr></Table>";
                lblActive.Text = Table2;
            }


            Table2 += "</table>";
            lblInactive.Text = Table2;
           
            //StringBuilder strTab2 = new StringBuilder();
            //strTab2.Append("<div id=\"fragment-2\">");
            //strTab2.Append(lblInactive.Text);
            //strTab2.Append("</div>");


           

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

}
