﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class ChequeDepositeReport : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    DataTable dt;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string city = "";
    int Sid;
    decimal total = 0;
    decimal totalOnCondition = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
                txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
                ShowAirline();

            }

        }

    }
    protected void ShowAirline()
    {

        ddl_airline_city.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'('+A.Airline_Code+')/'+B.city_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddl_airline_city.Items.Add("All Assigned Airlines");
            ddl_airline_city.Items[0].Value = "0";
            while (dr.Read())
            {
                ddl_airline_city.Items.Add(new ListItem(dr["airline"].ToString(), Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"])));

            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

    protected void Btnload_Click(object sender, EventArgs e)
    {
        string[] airlinesplit = ddl_airline_city.SelectedItem.Value.Split(',');

        string[] airline_name_city_text = ddl_airline_city.SelectedItem.Text.Split('/');
        string[] airline_name_city_value = ddl_airline_city.SelectedItem.Value.Split(',');
        string date_from = txtValidFrom.Text;
        string date_to = txtValidTo.Text;
        Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
        Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
        Session["from_date"] = date_from;
        Session["to_date"] = date_to;
        BindGrid();


       
    }


    public void BindGrid()
    {
        string[] airline_name_city_text = Session["airline_city_text"].ToString().Split(',');
        string[] airline_name_city_value = Session["airline_city_value"].ToString().Split(',');
        string[] air_name_val = airline_name_city_value[0].Split('%');
        string from_date = Session["from_date"].ToString();
        string to_date = Session["to_date"].ToString();

        con = new SqlConnection(strCon);
        con.Open();
        string StrAgent = "SELECT IFA.Import_awb_id,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,ISNULL(IFA.Tds_Cut_By_Agent,0) AS TDSCUT,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,IFA.Amount_Received,isnull(IFA.Total_Collection_CC,0) as FrtChrgs FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID  WHERE CONVERT(VARCHAR,IFA.issue_date,101) >= '" + FormatDateMM(from_date) + "' and CONVERT(VARCHAR,IFA.issue_date,101) <='" + FormatDateMM(to_date) + "' AND IFA.Airline_Detail_ID=" + airline_name_city_value[0].ToString() + " and payment_mode=2 order by IFA.Recipt_No";

        SqlDataAdapter sda = new SqlDataAdapter(StrAgent, con);
        DataTable dt = new DataTable();
        sda.Fill(dt);


        #region Receved Amount

        string TDS = "0";
        string FrtChrgs = "0";
        //string MawbDo_Chgs = "0", HawbDo_Chgs = "0", STAXRATE = "0";
        decimal Alltotal = 0; decimal InnerTotal = 0;
        decimal RecivdAmtAfterStax = 0;
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            InnerTotal = 0;
            DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + dt.Rows[i]["Import_awb_id"].ToString() + "'");
            for (int j = 0; j < dtImportAwbTrans.Rows.Count; j++)
            {
                //InnerTotal = 0;
                RecivdAmtAfterStax = 0;
                if (dtImportAwbTrans.Rows[j]["ChargeName"].ToString() != "StaxRate")
                {
                    //STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();

                    InnerTotal += decimal.Parse(dtImportAwbTrans.Rows[j]["ChargeAmount"].ToString());

                }
                //*****************Condition for Stax Deduction***************
                //else 
                //{
                //    if (dtImportAwbTrans.Rows[j]["ChargeName"].ToString() == "StaxRate" && dtImportAwbTrans.Rows[j]["Quantity"].ToString() == "0")
                //    {
                //        RecivdAmtAfterStax = decimal.Parse(dtImportAwbTrans.Rows[j]["ChargeAmount"].ToString());

                //    }
                //    else
                //    {
                //        RecivdAmtAfterStax = 0;
                //    }
                //}
            }
            /////InnerTotal = InnerTotal - RecivdAmtAfterStax;

            //*******************Condition For Frt chrgs*****************//
            if (decimal.Parse(dt.Rows[i]["FrtChrgs"].ToString()) > 0)
            {
                FrtChrgs = dt.Rows[i]["FrtChrgs"].ToString();
            }
            InnerTotal = InnerTotal + decimal.Parse(FrtChrgs);
            //*******************Condition for Tds Cut By Agent checked for AWB*****************//
            if (decimal.Parse(dt.Rows[i]["TDSCUT"].ToString()) > 0)
            {
                TDS = dt.Rows[i]["TDSCUT"].ToString();
            }
            InnerTotal = InnerTotal - decimal.Parse(TDS);


            Alltotal += InnerTotal;

            dt.Rows[i]["Amount_Received"] = Convert.ToString(InnerTotal);
        }


        #endregion
        GridView1.DataSource = dt;
        GridView1.DataBind();

        for (int i = 0; i < dt.Rows.Count; i++)
        {

            total += decimal.Parse(dt.Rows[i]["Amount_Received"].ToString() == "" ? "0" : dt.Rows[i]["Amount_Received"].ToString());

        }


        Label LblAwbID = (Label)GridView1.FooterRow.FindControl("lblTotal");
        LblAwbID.Text = Convert.ToString(total);




        sda.Dispose();
        con.Close();
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string AwbID = "";
        try
        {


            foreach (GridViewRow gv in GridView1.Rows)
            {
                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");

                if (ChkBxItem.Checked)
                {
                    AwbID += gv.Cells[1].Text;
                    Label AmountRecevd = (Label)gv.FindControl("lblRecievdAmount");

                    totalOnCondition += decimal.Parse(AmountRecevd.Text == "" ? "0" : AmountRecevd.Text);

                }




            }

            lblFinalTotal.Text = Convert.ToString(totalOnCondition);

        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChequeCashDepositeReport.aspx");
    }
}
