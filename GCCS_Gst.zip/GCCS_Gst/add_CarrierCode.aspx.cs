﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class add_CarrierCode : System.Web.UI.Page
{
    #region Created by Pradeep Sharma
    /// <summary>
    /// <class>Add Gateway Master</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Pradeep Sharma</createdBy>
    /// <createdOn>oct 17</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription>insert all value in Gateway & update</changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion

    #region ConnectionString
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  //connection string
    #endregion
    #region Global Variables Declaration
    SqlConnection con;
    public string strLen = "";
    SqlCommand cmd;
    SqlDataReader rdr;
    string carrierCodeval = "";  
    string UpdateQuery = "";

    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (Request.QueryString["CarrierCode"] != null)
        {
            carrierCodeval = Request.QueryString["CarrierCode"];
        }
        if (!IsPostBack)
        {
            btnupdate.Visible = false;
           // BindDpr();

            if (Request.QueryString["CarrierCode"] != null)
            {
                btnadd.Visible = false;
                btnupdate.Visible = true;
                FillAllField();
            }
        }

    }
    public void BindDpr()
    {
        con = new SqlConnection(strCon);
        SqlDataAdapter adp = new SqlDataAdapter("SELECT CarrierCode  FROM db_owner.InterLineCarrier ORDER BY CarrierCode", con);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        dprCarrierType.DataSource = dt;
        dprCarrierType.DataTextField = "CarrierCode";
        dprCarrierType.DataValueField = "CarrierCode";
        dprCarrierType.DataBind();
    }
    public void FillAllField()
    {
        con = new SqlConnection(strCon);
        SqlDataAdapter adp = new SqlDataAdapter("SELECT CarrierName,CarrierCode ,Interline  FROM db_owner.InterLineCarrier where CarrierCode='"+carrierCodeval+"' ", con);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        dprCarrierType.SelectedValue = dt.Rows[0]["Interline"].ToString();
        txtCarrierCode.Text = dt.Rows[0]["CarrierCode"].ToString();
        txtCarrierName.Text = dt.Rows[0]["CarrierName"].ToString();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "INSERT INTO db_owner.InterLineCarrier ( CarrierName ,CarrierCode , Interline  )VALUES  (@CarrierName ,@CarrierCode , @Interline )";
        try
        {
            cmd.Parameters.AddWithValue("@CarrierName",txtCarrierName.Text);
            cmd.Parameters.AddWithValue("@CarrierCode",txtCarrierCode.Text);
            cmd.Parameters.AddWithValue("@Interline", dprCarrierType.SelectedValue);          
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Carrier.aspx");
        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    #region updataion on update click
    protected void btnupdate_Click(object sender, EventArgs e)
    {

        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;
        try
        {
            cmd.CommandText = "update db_owner.InterLineCarrier set  CarrierName=@CarrierName ,CarrierCode=@CarrierCode , Interline =@Interline  where CarrierCode='" + carrierCodeval + "'";

            cmd.Parameters.AddWithValue("@CarrierName",txtCarrierName.Text);
            cmd.Parameters.AddWithValue("@CarrierCode", txtCarrierCode.Text);
            cmd.Parameters.AddWithValue("@Interline", dprCarrierType.SelectedValue);
            con.Open();
            cmd.ExecuteNonQuery();
          
            con.Close();
            Response.Redirect("Carrier.aspx");
        }
        catch (SqlException aa)
        {
            if (aa.Number == 2627)
            {
                lblerr.Visible = true;
                //lblerr.Text = " Gateway Name " + dprGatewayName.SelectedValue + " already Exists";
                btnadd.Visible = false;
                btnupdate.Visible = true;
                btnupdate.Enabled = true;

            }
            else
            {
                Response.Write("sql error is" + aa.Message);
            }
        }
        finally
        {

            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();

            }
        }


    }
    #endregion

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Carrier.aspx");

    }
}