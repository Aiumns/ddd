﻿/*
*************************************************************************************
Page Name		:	FedEXBulkEntries
Purpose		:	To Upload Entries in bulk
Company		:   	CargoFlash InfoTech. 
Author			:  Kuldeep Kumar
Created On		:   12/06/2014
Modified By (On)	:	Kuldeep Kumar(12/06/2014) v1,<User Name>(<Date>)v2
Description		:	V1) Upload Excel File to Database
				V2) <Description>

*************************************************************************************
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using Excel;
using ICSharpCode.SharpZipLib;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

public partial class FedEXBulkEntries : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnupload_Click(object sender, EventArgs e)
    {
        if (IsPostBack)
        {           
            if (CheckFile())
            {
                try
                {
                    if (DataUpload())
                    {
                        lblMessage.Text = "File uploaded Successfully!";
                    }
                    else
                    {
                        lblMessage.Text = "Invalid Data, Please Check!";
                    }
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "File could not be uploaded.";
                }
            }
            else
            {
                lblMessage.Text = "Cannot accept files of this type.";
            }
        }
    }


    #region Check for valid File Extension
    public Boolean CheckFile()
    {
        Boolean fileOK = false;       
        if (FileUpload1.HasFile)
        {
            String fileExtension =
                Path.GetExtension(FileUpload1.FileName).ToLower();
            String[] allowedExtensions = { ".xls", ".xlsx" };
            for (int i = 0; i < allowedExtensions.Length; i++)
            {
                if (fileExtension == allowedExtensions[i])
                {
                    fileOK = true;
                }
            }
        }
        return fileOK;
    }
    #endregion
    #region File Upload
    protected Boolean DataUpload()
    {       
            string Extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
            DataTable dt;
            //string path = FileUpload1.PostedFile.FileName;

            //FileStream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            IExcelDataReader excelReader;
            if (Extension == ".xls")
            {
                //for excel 2003
                excelReader = ExcelReaderFactory.CreateBinaryReader(FileUpload1.PostedFile.InputStream);
            }
            else
            {
                // for Excel 2007
                excelReader = ExcelReaderFactory.CreateOpenXmlReader(FileUpload1.PostedFile.InputStream);
            }
            excelReader.IsFirstRowAsColumnNames = true;
            DataSet result = excelReader.AsDataSet();
            excelReader.IsFirstRowAsColumnNames = true;
            if (result.Tables[0].Rows.Count > 0)
            {               
                if (DataVarificaton(result.Tables[0]))
                {
                   //dt=ImportData(RemoveEmptyRows(result.Tables[0]));

                    //Strart:Changes made By Kuldeep Kumar on 7'th July 2014
                    dt = ImportData(result.Tables[0].Select("[AgentName] is not null OR [AgentName]<>''").CopyToDataTable());

                    //End:Changes made By Kuldeep Kumar on 7'th July 2014
                   if (dt.Rows.Count > 0 && dt != null)
                   {
                       GenerateXLS("ErrorReport.xls", dt);
                   }
                }
                else
                {
                    excelReader.Close();
                    return false;
                }
            }
            else
            {
                excelReader.Close();
                return false;
            }
            excelReader.Close();
            return true;
            
            
    }
    #endregion    
    #region Import File to Database.
    protected DataTable ImportData(DataTable dt)
    {
        DataSet ds = new DataSet();
        SqlDataAdapter da;
        DateTime fltDt, awbDt,handoverDt,upliftDate;        
        for(int i=0;i<dt.Rows.Count;i++)
        {
            //Convert Date format
            DateTime.TryParseExact(dt.Rows[i]["FltDt"].ToString(), new[] { "dd/MM/yyyy", "d/M/yyyy","d/MM/yyyy", "dd/M/yyyy"}, CultureInfo.InvariantCulture, DateTimeStyles.None, out fltDt);
            DateTime.TryParseExact(dt.Rows[i]["AwbDt"].ToString(), new[] { "dd/MM/yyyy", "d/M/yyyy", "d/MM/yyyy", "dd/M/yyyy"}, CultureInfo.InvariantCulture, DateTimeStyles.None, out awbDt);
            DateTime.TryParseExact(dt.Rows[i]["HandoverDt"].ToString(), new[] { "dd/MM/yyyy", "d/M/yyyy", "d/MM/yyyy", "dd/M/yyyy"}, CultureInfo.InvariantCulture, DateTimeStyles.None, out handoverDt);
            DateTime.TryParseExact(dt.Rows[i]["UpliftDate"].ToString(), new[] { "dd/MM/yyyy", "d/M/yyyy", "d/MM/yyyy", "dd/M/yyyy"}, CultureInfo.InvariantCulture, DateTimeStyles.None, out upliftDate);
            dt.Rows[i]["FltDt"] = fltDt.ToString("MM/dd/yyyy");
            dt.Rows[i]["AwbDt"] = awbDt.ToString("MM/dd/yyyy");
            dt.Rows[i]["HandoverDt"] = handoverDt.ToString("MM/dd/yyyy");
            dt.Rows[i]["UpliftDate"] = upliftDate.ToString("MM/dd/yyyy");
            dt.Rows[i]["TRKNo"] = dt.Rows[i]["TRKNo"].ToString();
            dt.Rows[i]["AWBNo"] = dt.Rows[i]["AWBNo"].ToString();
                
            dt.AcceptChanges();
        }
        #region Changes Made BY Hemant Sharma on 18 Nov 2014
        string column_name = "";
        DataTable dt_check = dt.Clone();
        //for (int i = 0; i < dt.Rows.Count; i++)
        //{
        if (dt_check.Columns["AgentName"].DataType != typeof(string))
        {
            dt_check.Columns["AgentName"].DataType = typeof(string);


        }
        if (dt_check.Columns["Org"].DataType != typeof(string))
        {
            dt_check.Columns["Org"].DataType = typeof(string);

        }
        if (dt_check.Columns["TRKNo"].DataType != typeof(string))
        {
            dt_check.Columns["TRKNo"].DataType = typeof(string);

        }
        if (dt_check.Columns["AWBNo"].DataType != typeof(string))
        {
            dt_check.Columns["AWBNo"].DataType = typeof(string);

        }
        if (dt_check.Columns["AccountNo"].DataType != typeof(string))
        {
            dt_check.Columns["AccountNo"].DataType = typeof(string);

        }
        if (dt_check.Columns["ShipmentType"].DataType != typeof(string))
        {
            dt_check.Columns["ShipmentType"].DataType = typeof(string);

        }
        if (dt_check.Columns["FltDt"].DataType != typeof(string))
        {
            dt_check.Columns["FltDt"].DataType = typeof(string);

        }
        if (dt_check.Columns["AwbDt"].DataType != typeof(string))
        {
            dt_check.Columns["AwbDt"].DataType = typeof(string);

        }
        if (dt_check.Columns["HandoverDt"].DataType != typeof(string))
        {
            dt_check.Columns["HandoverDt"].DataType = typeof(string);

        }
        if (dt_check.Columns["UpliftDate"].DataType != typeof(string))
        {
            dt_check.Columns["UpliftDate"].DataType = typeof(string);

        }
        if (dt_check.Columns["FltNo"].DataType != typeof(string))
        {
            dt_check.Columns["FltNo"].DataType = typeof(string);

        }
        if (dt_check.Columns["DestCode"].DataType != typeof(string))
        {
            dt_check.Columns["DestCode"].DataType = typeof(string);

        }
        if (dt_check.Columns["CountryCode"].DataType != typeof(string))
        {
            dt_check.Columns["CountryCode"].DataType = typeof(string);

        }
        if (dt_check.Columns["PCS"].DataType != typeof(string))
        {
            dt_check.Columns["PCS"].DataType = typeof(string);

        }
        if (dt_check.Columns["GrossWt"].DataType != typeof(string))
        {
            dt_check.Columns["GrossWt"].DataType = typeof(string);

        }
        if (dt_check.Columns["ChargWt"].DataType != typeof(string))
        {
            dt_check.Columns["ChargWt"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingRate"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingFSCRATE"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingFSCRATE"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingFSCAmt"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingFSCAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingDGChargs"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingDGChargs"].DataType = typeof(string);

        }
        if (dt_check.Columns["TotalBuyingAmt"].DataType != typeof(string))
        {
            dt_check.Columns["TotalBuyingAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["StaxRate"].DataType != typeof(string))
        {
            dt_check.Columns["StaxRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingSTaxAmt"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingSTaxAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingEduCessRate"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingEduCessRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingEduCessAmt"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingEduCessAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingHEduCessRate"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingHEduCessRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["BuyingHEduCessAmt"].DataType != typeof(string))
        {
            dt_check.Columns["BuyingHEduCessAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["GrandBuyingAmt"].DataType != typeof(string))
        {
            dt_check.Columns["GrandBuyingAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["NNSellingRate"].DataType != typeof(string))
        {
            dt_check.Columns["NNSellingRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingFscRate"].DataType != typeof(string))
        {
            dt_check.Columns["SellingFscRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingFscAmt"].DataType != typeof(string))
        {
            dt_check.Columns["SellingFscAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingDGChargs"].DataType != typeof(string))
        {
            dt_check.Columns["SellingDGChargs"].DataType = typeof(string);

        }
        if (dt_check.Columns["TotalSellingAmt"].DataType != typeof(string))
        {
            dt_check.Columns["TotalSellingAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["StaxRate"].DataType != typeof(string))
        {
            dt_check.Columns["StaxRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingSTaxAmt"].DataType != typeof(string))
        {
            dt_check.Columns["SellingSTaxAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingEduCessRate"].DataType != typeof(string))
        {
            dt_check.Columns["SellingEduCessRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingEduCessAmt"].DataType != typeof(string))
        {
            dt_check.Columns["SellingEduCessAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingHEduCessRate"].DataType != typeof(string))
        {
            dt_check.Columns["SellingHEduCessRate"].DataType = typeof(string);

        }
        if (dt_check.Columns["SellingHEduCessAmt"].DataType != typeof(string))
        {
            dt_check.Columns["SellingHEduCessAmt"].DataType = typeof(string);

        }
        if (dt_check.Columns["GrandSellingAmt"].DataType != typeof(string))
        {
            dt_check.Columns["GrandSellingAmt"].DataType = typeof(string);

        }
        foreach (DataRow dr_check in dt.Rows)
        {
            dt_check.ImportRow(dr_check);
        }
        // }
        #endregion
        using (SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString))
        {
            try
            {
                sqlCon.Open();
                SqlCommand cmd = new SqlCommand("spGccs_InsertFedexIPEntries", sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FedExIPData", dt);
                cmd.Parameters.AddWithValue("@Entered_by", Session["EMailID"].ToString());

                da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                //cmd.ExecuteNonQuery();

                sqlCon.Close();

                sqlCon.Dispose();
            }
            catch (SqlException ex)
            { 
            }
        }
        return ds.Tables[0];
    }
    #endregion
    #region Validate Data from Excel
    protected Boolean DataVarificaton(DataTable dt)
    {
        //Check number of columns required
        if(dt.Columns.Count<40)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Supplied Columns are Lesser than Required.');</script>");
            return false;
        }
        //Check Columns Name
       else  if (dt.Columns[0].ColumnName != "AgentName" &&
            dt.Columns[1].ColumnName!="Org" &&
            dt.Columns[2].ColumnName!="TRKNo" &&
            dt.Columns[3].ColumnName!="AWBNo" &&
            dt.Columns[4].ColumnName!="AccountNo" && 
            dt.Columns[5].ColumnName!="ShipmentType" &&
            dt.Columns[6].ColumnName!="FltDt" &&
            dt.Columns[7].ColumnName!="AwbDt" &&
            dt.Columns[8].ColumnName!="HandoverDt" && 
            dt.Columns[9].ColumnName!="UpliftDate" &&
            dt.Columns[10].ColumnName!="FltNo" &&
            dt.Columns[11].ColumnName!="DestCode" &&
            dt.Columns[12].ColumnName != "CountryCode" &&
            dt.Columns[13].ColumnName!="PCS" && 
            dt.Columns[14].ColumnName!="GrossWt" && 
            dt.Columns[15].ColumnName!="ChargWt" &&
            dt.Columns[16].ColumnName!="BuyingRate" && 
            dt.Columns[17].ColumnName!="BuyingFSCRATE" &&
            dt.Columns[18].ColumnName!="BuyingFSCAmt"	&& 
            dt.Columns[19].ColumnName!="BuyingDGChargs" &&
            dt.Columns[20].ColumnName!="TotalBuyingAmt" && 
            dt.Columns[21].ColumnName!="StaxRate" &&
            dt.Columns[22].ColumnName!="BuyingSTaxAmt" && 
            dt.Columns[23].ColumnName!="BuyingEduCessRate" &&
            dt.Columns[24].ColumnName!="BuyingEduCessAmt" &&
            dt.Columns[25].ColumnName!="BuyingHEduCessRate" && 
            dt.Columns[26].ColumnName!="BuyingHEduCessAmt" &&
            dt.Columns[27].ColumnName!="GrandBuyingAmt" &&
            dt.Columns[28].ColumnName!="NNSellingRate" && 
            dt.Columns[29].ColumnName!="SellingFscRate"	&& 
            dt.Columns[30].ColumnName!="SellingFscAmt" && 
            dt.Columns[31].ColumnName!="SellingDGChargs" &&
            dt.Columns[32].ColumnName!="TotalSellingAmt" && 
            dt.Columns[33].ColumnName!="StaxRate" &&
            dt.Columns[34].ColumnName!="SellingSTaxAmt"	&& 
            dt.Columns[35].ColumnName!="SellingEduCessRate" && 
            dt.Columns[36].ColumnName!="SellingEduCessAmt" &&
            dt.Columns[37].ColumnName!="SellingHEduCessRate"	&& 
            dt.Columns[38].ColumnName!="SellingHEduCessAmt" &&
            dt.Columns[39].ColumnName!="GrandSellingAmt")
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Please Check Excel Column Name.');</script>");
        return false;
        }
        else  if (dt.Columns[0].DataType != typeof(string) &&
            dt.Columns[1].DataType != typeof(string) &&
            dt.Columns[2].DataType != typeof(string) &&
            dt.Columns[3].DataType != typeof(string) &&
            dt.Columns[4].DataType != typeof(string) && 
            dt.Columns[5].DataType != typeof(string) &&
            dt.Columns[6].DataType != typeof(string) &&
            dt.Columns[7].DataType != typeof(string) &&
            dt.Columns[8].DataType != typeof(string) && 
            dt.Columns[9].DataType != typeof(string) &&
            dt.Columns[10].DataType != typeof(string) &&
            dt.Columns[11].DataType != typeof(string) &&
            dt.Columns[12].DataType != typeof(string) && 
            dt.Columns[13].DataType != typeof(string) && 
            dt.Columns[14].DataType != typeof(string) &&
            dt.Columns[15].DataType != typeof(string) && 
            dt.Columns[16].DataType != typeof(string) &&
            dt.Columns[17].DataType != typeof(string)	&& 
            dt.Columns[18].DataType != typeof(string) &&
            dt.Columns[19].DataType != typeof(string) && 
            dt.Columns[20].DataType != typeof(string) &&
            dt.Columns[21].DataType != typeof(string) && 
            dt.Columns[22].DataType != typeof(string) &&
            dt.Columns[23].DataType != typeof(string) &&
            dt.Columns[24].DataType != typeof(string) && 
            dt.Columns[25].DataType != typeof(string) &&
            dt.Columns[26].DataType != typeof(string) &&
            dt.Columns[27].DataType != typeof(string) && 
            dt.Columns[28].DataType != typeof(string)	&& 
            dt.Columns[29].DataType != typeof(string) && 
            dt.Columns[30].DataType != typeof(string) &&
            dt.Columns[31].DataType != typeof(string) && 
            dt.Columns[32].DataType != typeof(string) &&
            dt.Columns[33].DataType != typeof(string)	&& 
            dt.Columns[34].DataType != typeof(string) && 
            dt.Columns[35].DataType != typeof(string) &&
            dt.Columns[36].DataType != typeof(string)	&& 
            dt.Columns[37].DataType != typeof(string) &&
            dt.Columns[38].DataType != typeof(string) &&
            dt.Columns[39].DataType != typeof(string))
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Column Type Should Be in Text Format.');</script>");
        return false;
        }   
     
        return true;
    }
    #endregion
    #region Data Validation
    protected DataTable RemoveEmptyRows(DataTable dt)
    {
        DataTable validData = dt;
       // DataTable invalidData=dt.Clone();
        int index=0;
        foreach (DataRow row in dt.Rows)
        {          
            if(
               String.IsNullOrEmpty(row["AgentName"].ToString())
               && String.IsNullOrEmpty(row["Org"].ToString())
                && String.IsNullOrEmpty(row["TRKNo"].ToString())
                && String.IsNullOrEmpty(row["AWBNo"].ToString())
                && String.IsNullOrEmpty(row["AccountNo"].ToString())
                && String.IsNullOrEmpty(row["ShipmentType"].ToString())
                && String.IsNullOrEmpty(row["FltDt"].ToString())
                && String.IsNullOrEmpty(row["AwbDt"].ToString())
                && String.IsNullOrEmpty(row["HandoverDt"].ToString())
                && String.IsNullOrEmpty(row["UpliftDate"].ToString())
                && String.IsNullOrEmpty(row["FltNo"].ToString())
                && String.IsNullOrEmpty(row["DestCode"].ToString())
                && String.IsNullOrEmpty(row["PCS"].ToString())
                && String.IsNullOrEmpty(row["GrossWt"].ToString())
                && String.IsNullOrEmpty(row["ChargWt"].ToString())
                && String.IsNullOrEmpty(row["BuyingRate"].ToString())
                && String.IsNullOrEmpty(row["BuyingFSCRATE"].ToString())
                && String.IsNullOrEmpty(row["BuyingFSCAmt"].ToString())
                && String.IsNullOrEmpty(row["BuyingDGChargs"].ToString())
                && String.IsNullOrEmpty(row["TotalBuyingAmt"].ToString())
                && String.IsNullOrEmpty(row["StaxRate"].ToString())
                && String.IsNullOrEmpty(row["BuyingSTaxAmt"].ToString())
                && String.IsNullOrEmpty(row["BuyingEduCessRate"].ToString())
                && String.IsNullOrEmpty(row["BuyingEduCessAmt"].ToString())
                && String.IsNullOrEmpty(row["BuyingHEduCessRate"].ToString())
                && String.IsNullOrEmpty(row["BuyingHEduCessAmt"].ToString())
                && String.IsNullOrEmpty(row["GrandBuyingAmt"].ToString())
                && String.IsNullOrEmpty(row["NNSellingRate"].ToString())
                && String.IsNullOrEmpty(row["SellingFscRate"].ToString())
                && String.IsNullOrEmpty(row["SellingFscAmt"].ToString())
                && String.IsNullOrEmpty(row["SellingDGChargs"].ToString())
                && String.IsNullOrEmpty(row["TotalSellingAmt"].ToString())
                && String.IsNullOrEmpty(row["StaxRate"].ToString())
                && String.IsNullOrEmpty(row["SellingSTaxAmt"].ToString())
                && String.IsNullOrEmpty(row["SellingEduCessRate"].ToString())
                && String.IsNullOrEmpty(row["SellingEduCessAmt"].ToString())
                && String.IsNullOrEmpty(row["SellingHEduCessRate"].ToString())
                && String.IsNullOrEmpty(row["SellingHEduCessAmt"].ToString())
                && String.IsNullOrEmpty(row["GrandSellingAmt"].ToString()) 
              )
            {
                //Delete Empty Row
                validData.Rows.RemoveAt(index);
                index=index-1;
            }           
        }
        return validData; 
    }
    #endregion
    #region Function to generate excel on response via datatable
    public void GenerateXLS(string pFileName, DataTable pdtSource)
    {
        HttpResponse response = HttpContext.Current.Response;
        response.Clear();
        response.Charset = "";
        // set the response mime type for excel 

        if ((pFileName).ToLower().Contains(".xlsx"))
        {
            response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
        else
        {
            response.ContentType = "application/vnd.ms-excel";
        }

        response.AddHeader("Content-Disposition", "attachment;filename=\"" + pFileName + "\"");

        // create a string writer 
        using (StringWriter sw = new StringWriter())
        {
            using (HtmlTextWriter htw = new HtmlTextWriter(sw))
            {
                // instantiate a datagrid 
                GridView gvExport = new GridView();
                gvExport.DataSource = pdtSource;
                gvExport.DataBind();
                //(start): require for date format issue
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                foreach (GridViewRow r in gvExport.Rows)
                {
                    if (r.RowType == DataControlRowType.DataRow)
                    {
                        for (int columnIndex = 0; columnIndex < r.Cells.Count; columnIndex++)
                        {
                            r.Cells[columnIndex].Attributes.Add("class", "text");
                        }
                    }
                }
                //(end): require for date format issue

                gvExport.RenderControl(htw);
                //(start): require for date format issue
                System.Text.StringBuilder style = new System.Text.StringBuilder();
                style.Append("<style>");
                style.Append("." + "text" + " { mso-number-format:" + "\\@;" + " }");
                style.Append("</style>");
                response.Clear();
                Response.Buffer = true;
                //response.Charset = "";
                //response.Write(sw.ToString());
                Response.Write(style.ToString());
                Response.Output.Write(sw.ToString());
                Response.Flush();
                //(end): require for date format issue
                try
                {
                    response.End();
                }
                catch (Exception er)
                {
                    ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + er.Message.ToString().Replace("'", "") + "');</script>");
                }
                //HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
        }
    }
    #endregion
}