﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class Import_Void : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    DataTable dt;
    SqlDataReader dr = null;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
                txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
                ShowAirline();

            }

        }

    }
    protected void ShowAirline()
    {

        ddl_airline_city.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'('+A.Airline_Code+')/'+B.city_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddl_airline_city.Items.Add("All Assigned Airlines");
            ddl_airline_city.Items[0].Value = "0";
            while (dr.Read())
            {
                ddl_airline_city.Items.Add(new ListItem(dr["airline"].ToString(), Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"])));

            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

    protected void Btnload_Click(object sender, EventArgs e)
    {
        string[] airlinesplit = ddl_airline_city.SelectedItem.Value.Split(',');

        string[] airline_name_city_text = ddl_airline_city.SelectedItem.Text.Split('/');
        string[] airline_name_city_value = ddl_airline_city.SelectedItem.Value.Split(',');
        string date_from = txtValidFrom.Text;
        string date_to = txtValidTo.Text;
        Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
        Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
        Session["from_date"] = date_from;
        Session["to_date"] = date_to;
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Import_Void_Show.aspx');</script>");
    }
}
