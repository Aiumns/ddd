using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CPP_OldWithOffers : System.Web.UI.Page
{
    SqlConnection con = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        else if (!IsPostBack)
        {
            Page.Form.Target = "_blank";
            GetCPP();
        }
    }
    public void GetCPP()
    {
        string Tables = "";
        string Query = "";
        string Query_Last = "";
        Query = @"select distinct CM.CITY_ID,CM.CITY_NAME from  CPP_Quarterly CQ INNER JOIN CITY_MASTER CM ON CM.CITY_ID=CQ.CITY_ID  order by CM.CITY_ID ";

        DataTable dt_airline = dw.GetAllFromQuery(Query);
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            for (int i = 0; i < dt_airline.Rows.Count; ++i)
            {
                string CITY_ID = dt_airline.Rows[i]["CITY_ID"].ToString();
                string CITY_NAME = dt_airline.Rows[i]["CITY_NAME"].ToString();
                decimal total_bonus_cpp = 0;
                decimal total_redeem_cpp = 0;
                decimal Total_CPP = 0;
                decimal TotalBalance_CPP = 0;
                //decimal total_tonnage = 0;
                //decimal avg_ton = 0;
                SqlConnection con1 = new SqlConnection(strCon);
                con1.Open();
                SqlCommand com_csr = new SqlCommand("SELECT distinct AGENT_NAME,CQ.AGENT_ID as AGENT_ID,sum(ISNULL(Total_CPP,0)) AS Total_CPP,sum(ISNULL(Redeemed_CPP,0)) AS Redeemed_CPP,(sum(ISNULL(Total_CPP,0))-sum(ISNULL(Redeemed_CPP,0))) as balance_CPP FROM CPP_Quarterly CQ INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=CQ.AGENT_ID WHERE CITY_ID=" + CITY_ID + " group by AGENT_NAME,CQ.AGENT_ID  ORDER BY Total_CPP DESC ", con1);


                SqlDataReader dr_CPP = com_csr.ExecuteReader();
                //SqlDataReader dr_CPP1 = com_csr1.ExecuteReader();
                if (dr_CPP.HasRows)
                {
                    int COUNT = 0;

                    Tables += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0>";
                    Tables += "<tr><td class=boldtext align=center COLSPAN=5><h5>" + CITY_NAME + " - period up to " + DateTime.Now.ToString("dd/MM/yyyy") + "</h5></td></tr>";
                    Tables += "<tr class=h5 Style='background-color: Lavender' align=center><th>S.No</th><th>Agent Name</th><th>Total CPP</th><th><table><tr width=100%><th align=left width=15%>Redeemed CPP</th><th align=center width=20%>MobNo</th><th align=center width=40%>Remarks</th><th align=center width=25%>Status</th></tr></table></th><th>Balance CPP</th></tr>";
                    while (dr_CPP.Read())
                    {
                        if (dr_CPP["Redeemed_CPP"].ToString() != "0.00")
                        {
                            DataTable dt_red = dw.GetAllFromQuery("SELECT Redeemed_CPP,gift_send_to,gift_send_to_phone_no,remarks,status from redeem_cpp where agent_id=" + dr_CPP["AGENT_ID"].ToString() + " and city_id=" + CITY_ID + "");
                            COUNT++;
                            Tables += "<tr onclick=ChangeColor(this);>";
                            Tables += "<td>" + COUNT + "</td>";
                            Tables += "<td align=left>" + dr_CPP["AGENT_NAME"].ToString() + "</td>";
                            Tables += "<td align=right>" + dr_CPP["Total_CPP"].ToString() + "</td>";
                            Tables += "<td><table width=100% border=1 bordercolor=lightblue frame=void cellpadding=0 cellspacing=0 >";
                            if (dt_red.Rows.Count > 0)
                            {
                                foreach (DataRow drow in dt_red.Rows)
                                {
                                    Tables += "<tr width=100%><td align=left width=15% nowrap>&nbsp;" + drow["Redeemed_CPP"].ToString() + "</td><td align=left width=20% nowrap>&nbsp;" + drow["gift_send_to_phone_no"].ToString() + "</td><td align=left width=40%>&nbsp;" + drow["remarks"].ToString() + "</td><td align=left width=25%>&nbsp;" + drow["status"].ToString() + "</td></tr>";
                                }
                                Tables += "</td></table>";
                                Tables += "<td align=right>" + dr_CPP["balance_CPP"].ToString() + "</td>";
                                Tables += "</tr>";
                                total_redeem_cpp = total_redeem_cpp + decimal.Parse(dr_CPP["Redeemed_CPP"].ToString());
                                Total_CPP = Total_CPP + decimal.Parse(dr_CPP["Total_CPP"].ToString());
                                TotalBalance_CPP = TotalBalance_CPP + decimal.Parse(dr_CPP["balance_CPP"].ToString());
                            }
                        }
                    }
                }

                Tables += " <tr>";
                Tables += "<th colspan=2>Total " + CITY_NAME + "</th>";
                Tables += "<th align=right>" + Total_CPP + "</th>";
                Tables += "<th align=left>" + total_redeem_cpp + "</th>";
                Tables += "<th align=right>" + TotalBalance_CPP + "</th>";
                Tables += "</tr>";
                Tables += "</TABLE><br><br style=page-break-before:always;>";
            }
            if (Tables == "")
            {
                Label1.Text = "No Records Found";
                Label1.CssClass = "boldtext";
            }
            else
            {
                Label1.CssClass = "text";
                Label1.Text = Tables;
            }
          
        }
        catch (Exception)
        {

        }




    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["CPPoffers"] = Label1.Text;
        Response.Redirect("CPP_OldWithOffersDetails.aspx");
    }
}
