using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Add_To_PFM : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    public string strLen = "";
    public string Handover_Id = "";
    public string Stock_ID = "";
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            if (!IsPostBack)
            {
                strLen = "<script>var FillCity=new Array(" + TxtDestinationPlusCode() + ")</script>";
                string Var_Handover_Id = Request.QueryString["BID"];
                string[] Arr_BId = Var_Handover_Id.Split('-');
                 Handover_Id = Arr_BId[0];
                 Stock_ID = Arr_BId[1];
                FillDetails(Handover_Id);
                DataTable dt_AWB = dw.GetAllFromQuery("SELECT AirWayBill_No,CITY_ID FROM STOCK_MASTER WHERE STOCK_ID=" + Stock_ID + "");
                if (dt_AWB.Rows.Count > 0)
                {
                    lblAWB.Text = dt_AWB.Rows[0]["AirWayBill_No"].ToString();

                }

            }
        }
    }

    public void FillDetails(string Handover_Id)
    {
        if (Request.QueryString["Action"].ToString() == "add")
        {
            Button3.Visible = false;

            DataTable dt = dw.GetAllFromQuery("SELECT Part_Shipment_Status,HM.No_of_Packages as Total_PCS,HM.Gross_Weight as Total_Gwt,HM.Volume_Weight as Total_Vwt, CASE WHEN Part_Shipment_Status=13 THEN ISNULL(HM.No_of_Packages -(SELECT SUM(No_of_Packages) FROM Partial_Shipment_Details WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0)ELSE No_of_Packages END AS PCS,CASE WHEN Part_Shipment_Status=13 THEN ISNULL(HM.Gross_Weight -(SELECT SUM(Gross_Weight) FROM Partial_Shipment_Details WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0)ELSE Gross_Weight END AS Gross_Weight,CASE WHEN Part_Shipment_Status=13 THEN ISNULL(HM.Volume_Weight -(SELECT SUM(Volume_Weight) FROM Partial_Shipment_Details WHERE Handover_ID=HM.HANDOVER_ID GROUP BY Handover_ID),0)ELSE Volume_Weight END AS Volume_Weight,Nature_and_Quantity,DESTINATION_CODE,Destination_Name FROM HANDOVER HM INNER JOIN Booking_AWB BA ON HM.Handover_Id=BA.Handover_Id INNER JOIN DESTINATION_MASTER DM ON DM.DESTINATION_ID=HM.Destination_ID WHERE  HM.Handover_Id=" + Handover_Id);
            //DataTable dt = dw.GetAllFromQuery("SELECT No_of_Packages AS PCS,Gross_Weight,Volume_Weight,Nature_and_Quantity,DESTINATION_CODE,Destination_Name FROM HANDOVER HM INNER JOIN Booking_AWB BA ON HM.Handover_Id=BA.Handover_Id INNER JOIN DESTINATION_MASTER DM ON DM.DESTINATION_ID=HM.Destination_ID WHERE  HM.Handover_Id=" + Handover_Id);
            if (dt.Rows.Count > 0)
            {
                txtPcs.Text = dt.Rows[0]["PCS"].ToString();
                txtGrossWt.Text = dt.Rows[0]["Gross_Weight"].ToString();
                txtVolWt.Text = dt.Rows[0]["Volume_Weight"].ToString();
                txtDest.Text = dt.Rows[0]["DESTINATION_CODE"].ToString() + "-" + dt.Rows[0]["Destination_Name"].ToString();
                txtComm.Text = dt.Rows[0]["Nature_and_Quantity"].ToString();

                lblTPcs.Text = dt.Rows[0]["Total_PCS"].ToString();
                lblTGwt.Text = dt.Rows[0]["Total_Gwt"].ToString();
                lblTVW.Text = dt.Rows[0]["Total_Vwt"].ToString();

                lblp.Text = Convert.ToString(decimal.Parse(dt.Rows[0]["Total_PCS"].ToString()) - decimal.Parse(dt.Rows[0]["PCS"].ToString()));
                lblg.Text = Convert.ToString(decimal.Parse(dt.Rows[0]["Total_Gwt"].ToString()) - decimal.Parse(dt.Rows[0]["Gross_Weight"].ToString()));
                lblv.Text = Convert.ToString(decimal.Parse(dt.Rows[0]["Total_Vwt"].ToString()) - decimal.Parse(dt.Rows[0]["Volume_Weight"].ToString()));

                if (dt.Rows[0]["Part_Shipment_Status"].ToString() == "13")
                {
                    if (RadioButtonList1.SelectedValue == "")
                    {
                        RadioButtonList1.SelectedValue = "13";
                        RadioButtonList1.Enabled = false;
                    }
                    lblPartspt.Text = "- Part Shipment";
                    LoadStatus.Visible = true;
                }
                else
                {
                    LoadStatus.Visible = false;
                    lblPartspt.Text = "";
                    RadioButtonList1.SelectedValue = "14";
                }

            }
        }
        else if (Request.QueryString["Action"].ToString() == "edit")
        {
            Button1.Visible = false;
            DataTable dt = dw.GetAllFromQuery("SELECT No_of_Packages AS PCS,Gross_Weight,Volume_Weight,Nature_and_Quantity,DESTINATION_CODE,Destination_Name,Location,Shipping_Bill_No,Location_Date FROM  PFM PF  INNER JOIN DESTINATION_MASTER DM ON DM.DESTINATION_ID=PF.Destination_ID  WHERE  Handover_Id=" + Handover_Id);
            if (dt.Rows.Count > 0)
            {
                txtPcs.Text = dt.Rows[0]["PCS"].ToString();
                txtGrossWt.Text = dt.Rows[0]["Gross_Weight"].ToString();
                txtVolWt.Text = dt.Rows[0]["Volume_Weight"].ToString();
                txtDest.Text = dt.Rows[0]["DESTINATION_CODE"].ToString() + "-" + dt.Rows[0]["Destination_Name"].ToString();
                txtComm.Text = dt.Rows[0]["Nature_and_Quantity"].ToString();
                txtLOC.Text = dt.Rows[0]["Location"].ToString();
                txtSbNo.Text = dt.Rows[0]["Shipping_Bill_No"].ToString();
                txtLOCDate.Text = dt.Rows[0]["Location_Date"].ToString();
            }
        }
    }

    //*************************Filling Destination TextBox with javascript******************
    public string TxtDestinationPlusCode()
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {

            //string selectGroupName = "SELECT Destination_ID,Destination_Code,Destination_Name FROM Destination_Master";
            string selectGroupName = " Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + Request.QueryString["AID"];
            SqlCommand com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";// +" "+ Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";//+ " " +Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        InsertIntoPFM();
    }

    public void InsertIntoPFM()
    {
        SqlTransaction Trans = null;
        try
        {
            // GET DESTINATION_ID
            string Destination_ID = "";
            string strDestination = txtDest.Text.Trim();
            strDestination = strDestination.Substring(0, 3);
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_ID from Destination_Master where Destination_Code='" + strDestination + "'");
            if (dtDestination.Rows.Count > 0)
            {
                Destination_ID = dtDestination.Rows[0]["Destination_ID"].ToString();
            }

            string Var_B_id = Request.QueryString["BID"];
            string[] Arr_B_Id = Var_B_id.Split('-');
            Handover_Id = Arr_B_Id[0];
            Stock_ID = Arr_B_Id[1];

            string Flight_Open_ID = Request.QueryString["fid"];
            string Airline_Detail_ID = Request.QueryString["AID"];

            int PCS = Int32.Parse(txtPcs.Text);
            decimal Gross_Weight = decimal.Parse(txtGrossWt.Text);
            decimal Volume_Weight = decimal.Parse(txtVolWt.Text);
            string Nature_and_Quantity = txtComm.Text;
            string LOC = txtLOC.Text;
            string SBNO = txtSbNo.Text;
            string LOCDATE = txtLOCDate.Text;
            string FDATE = Request.QueryString["date"];
            string Entered_By = Session["EMailID"].ToString();
            string State = "";
            string Part_Shipment_Status = RadioButtonList1.SelectedItem.Value;
            SqlConnection con = new SqlConnection(strCon);
            con.Open();
            Trans = con.BeginTransaction();
            SqlCommand strcom = null;
            if (Request.QueryString["Action"].ToString() == "add")
            {
                strcom = new SqlCommand("ADD_PFM", con, Trans);
                strcom.CommandType = CommandType.StoredProcedure;
                strcom.Parameters.AddWithValue("@Stock_ID", Stock_ID);
                strcom.Parameters.AddWithValue("@Handover_Id", Handover_Id);
                strcom.Parameters.AddWithValue("@Flight_No", Request.QueryString["fno"]);
                strcom.Parameters.AddWithValue("@Part_Shipment_Status", Part_Shipment_Status);
                strcom.Parameters.AddWithValue("@Flight_Open_ID", Flight_Open_ID);
                strcom.Parameters.AddWithValue("@Flight_Date", ConvertDate1(FDATE));
                strcom.Parameters.AddWithValue("@Destination_ID", Destination_ID);
                strcom.Parameters.AddWithValue("@Airline_Detail_ID", Airline_Detail_ID);
                strcom.Parameters.AddWithValue("@PCS", PCS);
                strcom.Parameters.AddWithValue("@Gross_Weight", Gross_Weight);
                strcom.Parameters.AddWithValue("@Volume_Weight", Volume_Weight);
                strcom.Parameters.AddWithValue("@Nature_and_Quantity", Nature_and_Quantity);
                strcom.Parameters.AddWithValue("@LOC", LOC);
                strcom.Parameters.AddWithValue("@SBNO", SBNO);
                strcom.Parameters.AddWithValue("@LOCDATE", LOCDATE);
                strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                State = "Added";
            }
            else if (Request.QueryString["Action"].ToString() == "edit")
            {
                strcom = new SqlCommand("UPDATE_PFM", con, Trans);
                strcom.CommandType = CommandType.StoredProcedure;

                strcom.Parameters.AddWithValue("@Stock_ID", Stock_ID);
                strcom.Parameters.AddWithValue("@Handover_Id", Handover_Id);               
                strcom.Parameters.AddWithValue("@Destination_ID", Destination_ID);        

                strcom.Parameters.AddWithValue("@PCS", PCS);
                strcom.Parameters.AddWithValue("@Gross_Weight", Gross_Weight);
                strcom.Parameters.AddWithValue("@Volume_Weight", Volume_Weight);
                strcom.Parameters.AddWithValue("@Nature_and_Quantity", Nature_and_Quantity);
                strcom.Parameters.AddWithValue("@LOC", LOC);
                strcom.Parameters.AddWithValue("@SBNO", SBNO);
                strcom.Parameters.AddWithValue("@LOCDATE", LOCDATE);
                strcom.Parameters.AddWithValue("@Modified_By", Entered_By);
                strcom.Parameters.AddWithValue("@Modified_On", DateTime.Now.ToString("MM/dd/yyyy"));
                
                State = "Updated";
            }
            //SqlCommand strcom = new SqlCommand("ADD_PFM", con, Trans);
          


            strcom.ExecuteNonQuery();
            Trans.Commit();
            string CITY_ID = Request.QueryString["city_id"];
            string Air_code = Request.QueryString["Airline_code"];
            Response.Redirect("PFM_Details.aspx?State=" + State + "&city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_ID + "&AID=" + Airline_Detail_ID + "&fno=" + Request.QueryString["fno"] + "&date=" + FDATE + "");
            con.Close();
            strcom.Dispose();
        }
        catch (SqlException sqe)
        {
            Trans.Rollback();
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
       
    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string CITY_ID = Request.QueryString["city_id"];
        string Air_code = Request.QueryString["Airline_code"];
        string Flight_Open_ID = Request.QueryString["fid"];
        string Airline_Detail_ID = Request.QueryString["AID"];
        string FDATE = Request.QueryString["date"];
        Response.Redirect("PFM_Details.aspx?city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_ID + "&AID=" + Airline_Detail_ID + "&fno=" + Request.QueryString["fno"] + "&date=" + FDATE + "");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        InsertIntoPFM();
    }
}
