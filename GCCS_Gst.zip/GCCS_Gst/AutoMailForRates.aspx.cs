using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;

public partial class AutoMailForRates : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSendMail_Click(object sender, EventArgs e)
    {
        string body = "";
        string Airwaybill_No = "";
        string Airwaybill_NoAll = "";
        string Flight_No = "";
        string Flight_NoAll = "";
        string Flight_date = Convert.ToString(DateTime.Parse(DateTime.Now.ToString()).ToString("dd/MM/yyyy"));
        string Agent_Id = "";
        string date = Convert.ToString(DateTime.Parse(DateTime.Now.AddDays(-2).ToString()).ToString("dd/MM/yyyy"));
        //date = DateTime.Parse(DateTime.Now).ToString("dd/MM/yyyy");
        //////DataTable Flightdetails = dw.GetAllFromQuery("SELECT DISTINCT fm.flight_no,s.flight_date,s.Airline_Detail_ID,sm.airwaybill_no,s.spot_rate,s.commission,s.special_commodity_incentive,sm.agent_id FROM flight_open fo INNER JOIN flight_master fm ON fo.flight_id=fm.flight_id INNER JOIN sales s ON fo.flight_date=s.flight_date inner join stock_master sm on s.stock_id=sm.stock_id WHERE   fo.flight_date='" + FormatDateMM(date) + "' AND s.spot_rate=0 AND s.commission=0 AND s.special_commodity_incentive=0 AND fo.status=6 AND sm.STATUS=10");

        DataTable Flightdetails = dw.GetAllFromQuery("SELECT DISTINCT fm.flight_no,s.flight_date,s.Airline_Detail_ID,sm.airwaybill_no,s.spot_rate,s.commission,s.special_commodity_incentive,sm.agent_id,at.sales_person_id,lm.email_id FROM flight_open fo INNER JOIN flight_master fm ON fo.flight_id=fm.flight_id INNER JOIN sales s ON fo.flight_date=s.flight_date inner join stock_master sm on s.stock_id=sm.stock_id inner join AgentToSalesPerson_Cluster at on sm.agent_id=at.agent_id INNER JOIN login_master lm ON at.sales_person_id=lm.user_id WHERE   fo.flight_date='" + FormatDateMM(date) + "' AND s.spot_rate=0 AND s.commission=0 AND s.special_commodity_incentive=0 AND fo.status=6 AND sm.STATUS=10 ORDER BY sales_person_id");
        if (Flightdetails.Rows.Count > 0)
        {
            string salespersonid = Flightdetails.Rows[0]["sales_person_id"].ToString();
            for(int q=0;q<Flightdetails.Rows.Count;q++)
            {
                string userid=Flightdetails.Rows[q]["sales_person_id"].ToString();
                if (salespersonid == userid)
                {
                    //Airwaybill_No += "'" + Flightdetails.Rows[q]["airwaybill_no"].ToString() + "'" + ",";
                    //Flight_No += Flightdetails.Rows[q]["Flight_No"].ToString() + ",";
                    Airwaybill_No =Flightdetails.Rows[q]["airwaybill_no"].ToString();
                    Flight_No = Flightdetails.Rows[q]["Flight_No"].ToString();
                    string INSERTQ = "INSERT INTO DealNotEntered_History(salesPerson_Id,flt_no,Airwaybill_no,flt_date,mail_date) VALUES(@salesPerson_Id,@flt_no,@Airwaybill_no,@flt_date,@mail_date)";
                    SqlConnection con = new SqlConnection(strCon);

                    SqlCommand cmd = new SqlCommand(INSERTQ, con);
                    con.Open();
                  
                    cmd.Parameters.Add("@salesPerson_Id", SqlDbType.VarChar, 50).Value = salespersonid;
                    cmd.Parameters.Add("@flt_no", SqlDbType.VarChar, 50).Value = Flight_No;
                    cmd.Parameters.Add("@Airwaybill_no", SqlDbType.NVarChar).Value = Airwaybill_No;
                    cmd.Parameters.Add("@flt_date", SqlDbType.DateTime).Value = DateTime.Now.AddDays(-2).ToString();
                    cmd.Parameters.Add("@mail_date", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.ExecuteNonQuery();

                    cmd.Dispose();
                    con.Close();

                    Airwaybill_NoAll += Flightdetails.Rows[q]["airwaybill_no"].ToString() + "  For Flight No " + Flightdetails.Rows[q]["Flight_No"].ToString() + ","; 
                    //Flight_NoAll += Flightdetails.Rows[q]["Flight_No"].ToString() + ","; 
                    //body = Airwaybill_NoAll + " For Flight No " + Flight_NoAll + ",";
                    Airwaybill_No = "";
                    Flight_No = "";
                    salespersonid = Flightdetails.Rows[q]["sales_person_id"].ToString();
                }
                else
                {
                    DataTable dtemail = dw.GetAllFromQuery("select lm.email_id,um.full_name from login_master lm inner join user_master um on lm.user_id=um.userId where user_id=" + salespersonid + "");
                    sendmail(dtemail.Rows[0]["email_id"].ToString(), Airwaybill_NoAll, dtemail.Rows[0]["full_name"].ToString(), "", "", "");
                    
                    Airwaybill_No = Flightdetails.Rows[q]["airwaybill_no"].ToString();
                    Flight_No = Flightdetails.Rows[q]["Flight_No"].ToString();
                    string INSERTQ = "INSERT INTO DealNotEntered_History(salesPerson_Id,flt_no,Airwaybill_no,flt_date,mail_date) VALUES(@salesPerson_Id,@flt_no,@Airwaybill_no,@flt_date,@mail_date)";
                    SqlConnection con = new SqlConnection(strCon);

                    SqlCommand cmd = new SqlCommand(INSERTQ, con);
                    con.Open();

                    cmd.Parameters.Add("@salesPerson_Id", SqlDbType.VarChar, 50).Value = salespersonid;
                    cmd.Parameters.Add("@flt_no", SqlDbType.VarChar, 50).Value = Flight_No;
                    cmd.Parameters.Add("@Airwaybill_no", SqlDbType.NVarChar).Value = Airwaybill_No;
                    cmd.Parameters.Add("@flt_date", SqlDbType.DateTime).Value = DateTime.Now.AddDays(-2).ToString();
                    cmd.Parameters.Add("@mail_date", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.ExecuteNonQuery();

                    cmd.Dispose();
                    con.Close();

                    salespersonid = Flightdetails.Rows[q]["sales_person_id"].ToString();
                    Airwaybill_NoAll = "";
                    Airwaybill_NoAll += Flightdetails.Rows[q]["airwaybill_no"].ToString() + "  For Flight No " + Flightdetails.Rows[q]["Flight_No"].ToString() + ","; 
                    //Flight_NoAll += Flightdetails.Rows[q]["Flight_No"].ToString() + ",";
                    //body = Airwaybill_NoAll + " For Flight No " + Flight_NoAll + ",";
                }
            }
                   
                
            }
            

       
       
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void sendmail(string email, string body, string name,string AirwayBill_No,string name1,string Flight_Date)
    {

        try
        {
            MailMessage msg = new MailMessage();
            //msg.From = new MailAddress("ddalal@cargoflash.com", "asrao");
            //msg.To.Add(new MailAddress(email, name));
            //"vkukreja.acumen@groupconcorde.com"
            msg.From = new MailAddress("ddalal@cargoflash.com", "asrao");
            msg.To.Add(new MailAddress("msati@cargoflash.com", "Deepak"));
            msg.CC.Add(new MailAddress("msati@cargoflash.com", "Deepak"));
            msg.Subject = "Please enter Selling Rate";
            msg.Body = "Dear " + name + "," + "<br/><br/>You have not entered sold rate for the Shipment having details mentioned:<br/>" + body + "<br/>For any query please contact IT dept at asrao@cargoflash.com.<br/><br/>Best regards,<br/>IT Team<br/>Group Concorde";
            msg.IsBodyHtml = true;
            msg.Priority = MailPriority.High;
            SmtpClient c = new SmtpClient("mail.cargoflash.com", 25);
            c.Send(msg);
        }

        catch (Exception ex)
        {
            Response.Write("<script>alert(" + ex.Message + ");</script>");
        }
    }
}
