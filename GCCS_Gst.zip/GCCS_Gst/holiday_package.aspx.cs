using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;


public partial class holiday_package : System.Web.UI.Page
{
    //string strCon = ConfigurationManager.AppSettings["CN"];
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    public double lprice = 0;


    protected void Page_Load(object sender, EventArgs e)
    {
        DataList1.DataSource = FetchAllImagesInfo();
        DataList1.DataBind();
        if (!Page.IsPostBack)
        {
            GridView1.DataSource = getCity();
            GridView1.DataBind();
            Hotel();
        }



    }


    public DataTable FetchAllImagesInfo()
    {
        string sql = "Select * from tbimage where category='Holiday'";
        SqlDataAdapter da = new SqlDataAdapter(sql, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public DataTable getCity()
    {
        string sql = "SELECT distinct city FROM tblholiday where active='Y' order by city";
        SqlDataAdapter da = new SqlDataAdapter(sql, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public DataTable MakeHotelTable()
    {
        DataColumn dc1 = new DataColumn();
        dc1.Caption = "Hotel/Resort";
        dc1.ColumnName = "Hotel";
        dc1.DataType = System.Type.GetType("System.String");

        DataColumn dc2 = new DataColumn();
        dc2.Caption = "Days";
        dc2.ColumnName = "Days";
        dc2.DataType = System.Type.GetType("System.String");

        DataColumn dc3 = new DataColumn();
        dc3.Caption = "Price";
        dc3.ColumnName = "Price";
        dc3.DataType = System.Type.GetType("System.String");

        DataTable dt = new DataTable();

        dt.Columns.Add(dc1);
        dt.Columns.Add(dc2);
        dt.Columns.Add(dc3);

        return dt;
    }

    public void Hotel()
    {

        NumberFormatInfo nfi = new NumberFormatInfo();
        nfi.CurrencyDecimalDigits = 2;
        nfi.CurrencyDecimalSeparator = ".";
        nfi.CurrencyGroupSeparator = ",";
        int[] groups = new int[1];
        groups[0] = 3;
        nfi.CurrencyGroupSizes = groups;
        nfi.CurrencySymbol = "";
        string sQuery = "";

        SqlConnection con = new SqlConnection(strCon);

        try
        {
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                DataTable dt = MakeHotelTable();
                DataRow dRow;
                GridViewRow gRow = GridView1.Rows[i];
                sQuery = "SELECT city,hotel,days,price from tblholiday where city='" + ((Label)gRow.FindControl("lblcity")).Text + "' and active='Y' order by sno";

                SqlCommand com = new SqlCommand(sQuery, con);
                con.Open();
                SqlDataReader dr = com.ExecuteReader();


                while (dr.Read())
                {
                    dRow = dt.NewRow();
                    dRow[0] = dr["hotel"].ToString();
                    dRow[1] = dr["days"].ToString() + "PACKAGE";
                    lprice = Convert.ToDouble(dr["price"].ToString().Trim());
                    string value = lprice.ToString("c", nfi);
                    value = value.Remove(value.Length - 3, 3);
                    dRow[2] = value + "*";
                    dt.Rows.Add(dRow);
                }
                dr.Close();
                con.Close();
                ((DataList)gRow.FindControl("DataList2")).DataSource = dt;
                ((DataList)gRow.FindControl("DataList2")).DataBind();
                dt.Rows.Clear();

            }
        }
        catch (SqlException ex)
        {
            string str2 = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}