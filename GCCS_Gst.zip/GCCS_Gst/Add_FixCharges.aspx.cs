using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

// This Page is Design & Coding By Alok Date:31.01.2007

public partial class Add_FixCharges : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    string Fix_Charges_ID;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
      {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack && Request.QueryString["Fix_Charges_ID"] != null)
            {
                lbladd.Visible = false;
                lblupdate.Visible = true;
                btnupdate.Visible = true;
                btnAdd.Visible = false;
                btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                Fix_Charges_ID = Convert.ToString(Request.QueryString["Fix_Charges_ID"]);
                string str1 = "select * from Fix_Charges where Fix_Charges_ID='" + Fix_Charges_ID + "'";
               
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(str1, con);
                SqlDataReader dr = com.ExecuteReader();
                dr.Read();
                string st=dr.FieldCount.ToString();
                txtAwbFee.Text = dr["AWC_Fees"].ToString();
                txtStax.Text = dr["Service_Tax"].ToString();
                min_xray.Text = dr["Min_XRay_Charges"].ToString();
                txtAwbRecheck.Text = dr["AWB_Recheck_Days"].ToString();
                con.Close();

            }
            else if(!IsPostBack)
            {
                btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
                lbladd.Visible = true;
                lblupdate.Visible = false;
                btnupdate.Visible = false;
                btnAdd.Visible = true;

            }
        }

    }

    public void UpdateData()
    {
        con = new SqlConnection(strCon);
        string strupdate = "";
        try
        {
            con.Open();
            strupdate = "update Fix_Charges  set AWC_Fees='" + txtAwbFee.Text + "',Service_Tax='" + txtStax.Text + "',Min_XRay_Charges='" + min_xray.Text + "',AWB_Recheck_Days='"+ txtAwbRecheck.Text+"' where Fix_Charges_ID='" + Convert.ToString(Request.QueryString["Fix_Charges_ID"]) + "'"; ;

                        com = new SqlCommand(strupdate, con);
                        com.ExecuteNonQuery();
                        con.Close();
                        Response.Redirect("view_fixcharges.aspx");
                    }

                    catch (SqlException se)
                    {
                        string err = se.Message;
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    }
       }
               
protected void  btnAdd_Click(object sender, EventArgs e)
{

}
protected void  btnupdate_Click(object sender, EventArgs e)
{
    UpdateData();
}
protected void  btnCancel_Click(object sender, EventArgs e)
{
    Response.Redirect("view_fixcharges.aspx");
}  

}
