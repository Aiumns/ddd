﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class InterLineCarrier : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  //connection string
    SqlConnection con;
    public string strLen = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           show();
        }
    }
    protected void btnSearch_Click1(object sender, EventArgs e)
    {
        show();
    }
    public void show()
    {
        string search = null;
        con = new SqlConnection(strCon);
        if (txtsearch.Text == "")
            search = "SELECT CarrierCode,CarrierName,Interline  FROM db_owner.InterLineCarrier";
        else
        {
            search = "SELECT CarrierCode,CarrierName,Interline  FROM db_owner.InterLineCarrier where CarrierCode like '" + txtsearch.Text + "'+ '%'";
        }
        con.Open();
        SqlDataAdapter sda = new SqlDataAdapter(search, con);
        DataSet dsssss = new DataSet();
        sda.Fill(dsssss);
        ddlInteline.AppendDataBoundItems = true;
        ddlInteline.Items.Insert(0, "Select");
        ddlInteline.DataTextField = "CarrierName";
        ddlInteline.DataValueField = "CarrierCode";
        ddlInteline.DataSource = dsssss;
        ddlInteline.DataBind();
        con.Close();
    }
}