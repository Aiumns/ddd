using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

// This Page is Design & Coding By Alok Date:18.10.2007
// Last Updated by Alok Date:20.11.2007


public partial class AddAirline : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    string Airline_ID;
    string Airline_Code;
    string Airline_Text_Code;
    string Airline_Name;
    string Status_ID;
    string Company_Id;
    SqlTransaction trans = null;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
      
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack && Request.QueryString["Airline_ID"] != null)
            {
                lbladd.Visible = false;
                lblupdate.Visible = true;
                btnupdate.Visible = true;
                btnAdd.Visible = false;
                btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                Airline_ID = Convert.ToString(Request.QueryString["Airline_ID"]);
                string str1 = "select  AM.Airline_ID as 'Airline_ID', AM.Airline_Code as 'Airline_Code' ,AM.Airline_Text_Code as 'Airline_Text_Code',AM.Airline_Name as 'Airline_Name',CM.Company_ID as 'Company_ID',SM.Status_ID as 'Status_ID'  from Airline_Master AM inner join Company_Master CM on  CM.Company_Id =AM.Company_Id  inner join Status_Master SM on AM.Status=SM.Status_Id  where Airline_ID='" + Airline_ID + "' order by AM.AirLine_Name";
                con = new SqlConnection(strCon);
                con.Open();

                com = new SqlCommand(str1, con);
                SqlDataReader dr = com.ExecuteReader();
                dr.Read();

                Airline_Code = dr["Airline_Code"].ToString();
                Airline_Text_Code = dr["Airline_Text_Code"].ToString();
                Airline_Name = dr["Airline_Name"].ToString();
                Status_ID = dr["Status_ID"].ToString();
                Company_Id = dr["Company_Id"].ToString();
                txtairlinecode.Text = Airline_Code;
                txtAirlineTextcode.Text = Airline_Text_Code;
                txtairlinename.Text = Airline_Name;
                lblid.Text = Airline_Code.ToString();
                con.Close();
                selectData();

            }
            else
            {
                
                btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
                selectData();
                lbladd.Visible = true;
                lblupdate.Visible = false;
                btnupdate.Visible = false;
                btnAdd.Visible = true;

            }
        }

    }
    /// <summary>
    /// This Function  is used to bind the Comapany name in dropdownlist
    /// </summary>

    private void fillCompany()
    {
        con = new SqlConnection(strCon);
        try
        {
            string strQuery = "";
            //strQuery = " select distinct(CM.Company_Id),CM.Company_Name as 'Company_Name' from Airline_Master AM inner join Company_Master CM on CM.Company_Id =AM.Company_Id order by Company_Name";

            strQuery = "select distinct company_id,company_Name from Company_Master where status='2' and parent_id='0' order by Company_Name";


            con.Open();
            com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlcompanyname.Items.Clear();
            ddlcompanyname.Items.Add(new ListItem("Select Company Name"));
            while (dr.Read())
            {

                ddlcompanyname.Items.Add(new ListItem(dr["Company_Name"].ToString(), dr["Company_ID"].ToString()));


            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    /// <summary>
    /// This Function  is used to bind the status in dropdownlist
    /// </summary>

    private void fillstatus()
    {
        con = new SqlConnection(strCon);
        try
        {
            string strQuery = "";
            strQuery = " select * from Status_Master where Status_Name in ('Active','Inactive')";
            con.Open();
            com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlStatus.Items.Clear();
            //ddlStatus.Items.Add(new ListItem("Select Status"));
            while (dr.Read())
            {

                ddlStatus.Items.Add(new ListItem(dr["Status_Name"].ToString(), dr["Status_ID"].ToString()));


            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("DisplayAirline.aspx");
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        string stradd = "";
        try
        {
            //stradd = "select * from Airline_master where Airline_Code = '" + txtairlinecode.Text.Trim() + "' and ";
            stradd = "select Airline_Code,Airline_Text_Code,Airline_Name from Airline_master where Airline_Code='" + txtairlinecode.Text + "' or Airline_Text_Code='" + txtAirlineTextcode.Text + "' or Airline_Name='" + txtairlinename.Text + "'";
            con.Open();
            da = new SqlDataAdapter(stradd, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count <= 0)
            {
                if (ddlStatus.SelectedValue == "2")
                {
                    string stradd1 = "insert into  Airline_master(Airline_Code,Airline_Text_Code,Airline_Name,Company_ID,status) values('" + txtairlinecode.Text + "','" + txtAirlineTextcode.Text + "','" + txtairlinename.Text + "','" + ddlcompanyname.SelectedItem.Value + "','" + ddlStatus.SelectedItem.Value + "')";
                    con.Open();
                    com = new SqlCommand(stradd1, con);
                    com.ExecuteNonQuery();
                    com.Dispose();
                    con.Close();
                    Response.Redirect("DisplayAirline.aspx");
                }
                else if (ddlStatus.SelectedValue == "5")
                {
                    lblstatus.Text = "Please Select Active Status";
                }
            }
            else
            {
                lblmsg.Text = " Records already exists.";
            }

        }

        catch (SqlException err)
        {
            string msg = err.ToString();

        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        string strupdate = "";
        try
        {
            strupdate = "select Airline_Code,Airline_Text_Code,Airline_Name from Airline_master where Airline_Code='" + txtairlinecode.Text + "' or Airline_Text_Code='" + txtAirlineTextcode.Text + "' or Airline_Name='" + txtairlinename.Text + "'";
            con.Open();
            da = new SqlDataAdapter(strupdate, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count <= 1)
            {

                if (ddlStatus.SelectedValue == "5")
                {
                    try
                    {
                        con.Open();
                        trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table

                        string strupdate1 = "update airline_master  set Airline_Code='" + txtairlinecode.Text + "',Airline_Text_Code='" + txtAirlineTextcode.Text + "',Airline_Name='" + txtairlinename.Text + "',Company_ID='" + ddlcompanyname.SelectedItem.Value + "',Status='" + ddlStatus.SelectedItem.Value + "' where Airline_ID='" + Convert.ToString(Request.QueryString["Airline_ID"]) + "'"; ;
                        com = new SqlCommand(strupdate1, con, trans);
                        com.ExecuteNonQuery();

                        // Update Airline_Detail
                        string up1 = "update  Airline_Detail set status='5' where Airline_ID='" + Convert.ToString(Request.QueryString["Airline_ID"]) + "'"; ;
                        com = new SqlCommand(up1, con, trans);
                        com.ExecuteNonQuery();
                        trans.Commit();
                        con.Close();
                        Response.Redirect("DisplayAirline.aspx");
                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;
                        trans.Rollback();
                        lblmsg.Text = err;
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
                else if (ddlStatus.SelectedValue == "2")
                {
                    try
                    {
                        con.Open();
                        trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table

                        string strupdate1 = "update airline_master  set Airline_Code='" + txtairlinecode.Text + "',Airline_Text_Code='" + txtAirlineTextcode.Text + "',Airline_Name='" + txtairlinename.Text + "',Company_ID='" + ddlcompanyname.SelectedItem.Value + "',Status='" + ddlStatus.SelectedItem.Value + "' where Airline_ID='" + Convert.ToString(Request.QueryString["Airline_ID"]) + "'"; ;
                        com = new SqlCommand(strupdate1, con, trans);
                        com.ExecuteNonQuery();

                        // Update Airline_Detail
                        string up1 = "update  Airline_Detail set status='2' where Airline_ID='" + Convert.ToString(Request.QueryString["Airline_ID"]) + "'"; ;
                        com = new SqlCommand(up1, con, trans);
                        com.ExecuteNonQuery();
                        trans.Commit();
                        con.Close();
                        Response.Redirect("DisplayAirline.aspx");
                    }
                    catch (SqlException se)
                    {
                        string err = se.Message;
                        trans.Rollback();
                        lblmsg.Text = err;
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    };
                }

            }
            else
            {

                lblmsg.Text = " Record already exists.";
                btnAdd.Visible = false;
                btnupdate.Visible = true;
                lbladd.Visible = false;
                lblupdate.Visible = true;
            }

        }

        catch (SqlException err)
        {
            string msg = err.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
                con.Close();
        }
         
   }
    public void selectData()
    {
        try
        {
            if (!Page.IsPostBack)
            {
                fillCompany();
                fillstatus();
                ddlcompanyname.SelectedIndex = ddlcompanyname.Items.IndexOf(ddlcompanyname.Items.FindByValue(Company_Id));
                ddlStatus.SelectedIndex = ddlStatus.Items.IndexOf(ddlStatus.Items.FindByValue(Status_ID));          
            }
        }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }

    }

    protected void ddlcompanyname_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
