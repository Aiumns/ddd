﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class IPAgent : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    DisplayWrap dw = new DisplayWrap();
    SqlDataReader red;
    SqlParameter pram;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    public string strLen = "";
    public string strLen1 = "";   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
           // strLen = "<script>var FillDest =new Array(" + Dest() + ")</script>";
           // strLen1 = "<script>var FillCity =new Array(" + City() + ")</script>";

            if (!IsPostBack && Request.QueryString["Sno"] == null)
            {
                btnadd.Attributes.Add("onclick", "return CheckEmpty();");
                btnadd.Visible = true;
                lblpagename.Text = "Add Agent";
                btnupdate.Visible = false;
                 FillCityMaster();
              //  ddlAirlineName.Enabled = true;
               // FillStatus();
               // TodayDate = DateTime.Now.ToShortDateString();
               // loginid = Session["EMailID"].ToString();
            }
            else if (!IsPostBack && Request.QueryString["Sno"] != null)
            {
                if (!IsPostBack)
                {
                    btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                    btnadd.Visible = false; ;
                    btnupdate.Visible = true;
                    lblpagename.Text = "Update Agent Details";
                     FillCityMaster();
                    //ddlAirlineName.Enabled = false;
                    // FillStatus();
                    search();
                    //TodayDate = DateTime.Now.ToShortDateString();
                    //loginid = Session["EMailID"].ToString();
                }

            }
        }
    }

    public void FillCityMaster()
    {
        //string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select City_ID,C.City_Code +'-'+ C.City_Name as CityName  from City_Master C order by City_Name", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlCityCode.DataSource = red;
        ddlCityCode.DataTextField = "CityName";
        ddlCityCode.DataValueField = "City_ID";
        ddlCityCode.DataBind();
      

        con.Close();
        cmd.Dispose();
        ddlCityCode.Items.Insert(0, new ListItem("Select City", "-1"));
    }

    protected void ddlCityCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        if (ddlCityCode.SelectedIndex <= 0)
        {
            //txtFlightNo.Text = "";
            Label1.Visible = false;
            lblError.Visible = true;
            lblError.Text = "Please Select City Name";
            ddlCityCode.Focus();

        }
        else
        {
            // txtFlightNo.Text = "";
            lblError.Visible = false;
            string[] strAwb = ddlCityCode.SelectedItem.Text.Split('-');
            //int AW = strAwb.IndexOf("-");
            // string strAwb1 = strAwb.Substring(0, AW);
            //string str11 = "select Airline_Text_Code from Airline_Master where Airline_Name='" + strAwb[0] + "'";
            //SqlCommand com = new SqlCommand(str11, con);
            //SqlDataReader dr11 = com.ExecuteReader();
            //dr11.Read();
            //string ATC = dr11["Airline_Text_Code"].ToString();
            //Label1.Visible = true;
            //Label1.Text = ATC + "-";
        }
        con.Close();
    }

    void reset()
    {
        txtagentname.Text = "";
        txtaddress.Text = "";
        txtcoctactperson.Text = "";
        txtemailid.Text = "";
        txtfaxno.Text = "";
        txtgstaddress.Text="";
        txtgstno.Text = "";
        txtmobileno.Text = "";
        txtpanno.Text = "";
        txtphoneno.Text = "";
        txtTaxno.Text = "";               
    }

    public void search()
    {
       // FillCityMaster();
        int idfl;
        idfl = Int32.Parse(Request.QueryString["Sno"].ToString());
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand("IPAgent_Select", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Sno", idfl);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                txtagentname.Text = dr["Agent_Name"].ToString();
                // ddlCityCode.SelectedValue = dr["AgentCity"].ToString();
                ddlCityCode.Items.FindByText(dr["AgentCity"].ToString()).Selected = true;
                txtaddress.Text = dr["Agent_Address"].ToString();
                txtmobileno.Text = dr["Agent_MobNo"].ToString();
                txtphoneno.Text = dr["Agent_Phone"].ToString();
                txtemailid.Text = dr["Agent_Email"].ToString();
                txtcoctactperson.Text = dr["Concerned_Person"].ToString();
                txtgstaddress.Text = dr["Gst_Address"].ToString();
                txtpanno.Text = dr["Pan_No"].ToString();
                txtTaxno.Text = dr["Tin_No"].ToString();
                txtfaxno.Text = dr["Fax_No"].ToString();
                txtgstno.Text = dr["Gst_No"].ToString();              
           
                //string aaa = dr["Flight_Type"].ToString();
                //ddlAirlineName.Text = dr["Airline_Detail_ID"].ToString();
                //txtFlightNo.Text = dr["Flight_No"].ToString().Substring(3, dr["Flight_No"].ToString().Length - 3);
                //lblFlightNo.Text = dr["Flight_No"].ToString().Substring(3, dr["Flight_No"].ToString().Length - 3);
                //ddlFlightType.Text = dr["Flight_Type"].ToString();
                //txtDestination.Text = dr["Destination"].ToString();
                //txtorigin.Text = dr["Origin"].ToString();
                //txtcapacity.Text = dr["Capacity"].ToString();
                //ddlststus.Text = dr["Status"].ToString();
               // ddlFlightType.SelectedIndex = ddlFlightType.Items.IndexOf(ddlFlightType.Items.FindByText(aaa));
               // Label1.Visible = true;
               // flightCode();
                //Label1.Text = dr["Flight_No"].ToString().Substring(0, dr["Flight_No"].ToString().Length - 1);
            }
        }
        con.Close();
        cmd.Dispose();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        Add();
    }

    public void Add()
    {
        string insert1;
        con = new SqlConnection(strCon);
        try
        {         
            string str = "";
            str = "insert into IP_Agent(Agent_Name,Agent_City,Agent_Address,Agent_MobNo,Agent_Phone,Agent_Email,Concerned_Person,Gst_Address,Pan_No,Tin_No,FAX_No,Gst_No,Entered_On,Airline_Access,Airline_detail_id) values('" + txtagentname.Text + "'," + ddlCityCode.SelectedValue + ",'" + txtaddress.Text + "','" + txtmobileno.Text + "','" + txtphoneno.Text + "','" + txtemailid.Text + "','" + txtcoctactperson.Text + "','" + txtgstaddress.Text + "','" + txtpanno.Text + "','" + txtTaxno.Text + "','" + txtfaxno.Text + "','" + txtgstno.Text + "','" + DateTime.Now + "','152',152)";
            SqlCommand cmd = new SqlCommand(str, con);
            con.Open();
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            Response.Redirect("ShowIPAgent.aspx");
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            //Response.Write(er);
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void Update()
    {
        //string insert1;
        string strupdate = string.Empty;
        string S_no = string.Empty;
        con = new SqlConnection(strCon);
        try
        {
                S_no = Request.QueryString["Sno"].ToString();       
                con.Open();
                strupdate = "update IP_Agent set  Agent_Name='" + txtagentname.Text + "',Agent_City=" + ddlCityCode.SelectedValue + ",Agent_Address='" + txtaddress.Text + "',Agent_MobNo='" + txtmobileno.Text + "',Agent_Phone='" + txtphoneno.Text + "',Agent_Email='" + txtemailid.Text + "',Concerned_Person='" + txtcoctactperson.Text + "',Gst_Address='" + txtgstaddress.Text + "',Pan_No='" + txtpanno.Text + "',Tin_No='" + txtTaxno.Text + "',Fax_No='" + txtfaxno.Text + "',Gst_No='" + txtgstno.Text + "',Entered_On='" + DateTime.Now + "' where Sno='" + S_no + "'";
                SqlCommand cmd = new SqlCommand(strupdate, con);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Redirect("ShowIPAgent.aspx");        
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            //Response.Write(er);
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        Update();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowIPAgent.aspx");
    }
}