using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Import_Flight_Awb : System.Web.UI.Page
{
    /// <summary>
    /// <class>Add AWB DETAILS</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>--------ALOK KUMAR SHATMA--------</createdBy>
    /// <createdOn>-----26EPT 2008-------</createdOn>
    /// <modifications>
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand com;
    //SqlTransaction trans = null;
    DataSet ds;
    DisplayWrap dw = new DisplayWrap();
    string Import_AWB_No;
    long Import_AWB_ID;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.Session["EMailID"] == null)
        {
            base.Response.Redirect("Login.aspx");
        }
        else if (!base.IsPostBack)
        {
            this.rdAgent.SelectedIndex = 0;
            this.BindAgentNameCity();
            this.BindFlightNo();
            this.txtEmail.ReadOnly = false;
            this.txtAddress.ReadOnly = false;
            if (this.ddlFlightNo.Text == "")
            {
                this.btnSubmit.Visible = false;
            }
        }
    }
    public void BindAgentNameCity()
    {
        this.con = new SqlConnection(this.strCon);
        this.con.Open();
        try
        {
            string cmdText = "SELECT (a.Agent_Name +'-'+c.City_Name ) as AgentCity, a.Agent_ID FROM Agent_Master a INNER JOIN Agent_Branch b ON a.Agent_ID =b.Agent_ID INNER JOIN City_Master c ON b.Belongs_To_City = c.City_ID WHERE a.Parent_ID = 0 AND b.Branch_Status = 18 order by a.Agent_Name,c.City_Name";
            this.com = new SqlCommand(cmdText, this.con);
            this.da = new SqlDataAdapter(this.com);
            this.ds = new DataSet();
            this.da.Fill(this.ds);
            this.ddlAgent.DataSource = this.ds;
            this.ddlAgent.DataTextField = "AgentCity";
            this.ddlAgent.DataValueField = "Agent_ID";
            this.ddlAgent.DataBind();
            this.ddlAgent.Items.Insert(0, new ListItem("--Select--", "0"));
            this.con.Close();
        }
        catch (SqlException exception)
        {
            string message = exception.Message;
            this.lblMessage.Text = message;
            this.lblMessage.Visible = true;
        }
        finally
        {
            if ((this.con != null) && (this.con.State == ConnectionState.Open))
            {
                this.con.Close();
            }
        }
    }

    public void BindFlight()
    {
        this.con = new SqlConnection(this.strCon);
        this.con.Open();
        this.com = new SqlCommand("select Import_flight");
    }

    public void BindFlightNo()
    {
        this.con = new SqlConnection(this.strCon);
        this.con.Open();
        try
        {
            DateTime today = DateTime.Today;
            string cmdText = "select a.Import_Flight_Open_ID,(a.Import_Flight_No +'('+convert(varchar,a.flight_date,103)+')') as Fldate from Import_Flight_Open a inner join flight_open b on a.Import_Flight_Open_ID=b.Import_Flight_Open_ID where b.Close_Date >= '" + today + "'order by b.Open_Date desc";
            this.com = new SqlCommand(cmdText, this.con);
            this.da = new SqlDataAdapter(this.com);
            this.ds = new DataSet();
            this.da.Fill(this.ds);
            this.ddlFlightNo.DataSource = this.ds;
            this.ddlFlightNo.DataTextField = "Fldate";
            this.ddlFlightNo.DataValueField = "Import_Flight_Open_ID";
            this.ddlFlightNo.DataBind();
        }
        catch (SqlException exception)
        {
            string message = exception.Message;
            this.lblMessage.Text = message;
            this.lblMessage.Visible = true;
        }
        finally
        {
            if ((this.con != null) && (this.con.State == ConnectionState.Open))
            {
                this.con.Close();
            }
        }
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        this.txtAwbNo.Text = "";
        this.AwbFtDate.Text = "";
        this.txtNoOfPieces.Text = "";
        this.txtNoOfHouses.Text = "";
        this.txtGrosswt.Text = "";
        this.txtChargeWt.Text = "";
        this.ddlFrieght.SelectedIndex = 0;
        this.txtPersonName.Text = "";
        this.txtRemarks.Text = "";
        this.txtAddress.Text = "";
        this.txtNewCustomer.Text = "";
        this.txtEmail.Text = "";
        this.txtNatuteGood.Text = "";
        this.txtMobile.Text = "";
        this.ddlAgent.SelectedIndex = 0;
        if (this.ddlFlightNo.Text != "")
        {
            this.ddlFlightNo.SelectedIndex = 0;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (this.ddlFrieght.SelectedValue == "Collect")
        {
            this.InsertCollectData();
        }
        else if (this.ddlFrieght.SelectedValue == "Prepaid")
        {
            this.InsertPrepaidData();
        }
    }

    protected void ddlAgent_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.FindEmaiAddress();
    }

    protected void ddlFlightNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.FindFlightDate();
    }

    public void FindEmaiAddress()
    {
        this.con = new SqlConnection(this.strCon);
        this.con.Open();
        try
        {
            if (this.ddlAgent.SelectedValue == "0")
            {
                this.txtEmail.Text = "";
                this.txtAddress.Text = "";
                this.txtEmail.ReadOnly = false;
                this.txtAddress.ReadOnly = false;
            }
            else
            {
                string cmdText = "select Agent_Email,Agent_Address from Agent_Branch where Agent_ID=" + this.ddlAgent.SelectedValue + "and Branch_Status=18";
                this.com = new SqlCommand(cmdText, this.con);
                this.da = new SqlDataAdapter(this.com);
                this.ds = new DataSet();
                this.da.Fill(this.ds);
                this.txtEmail.Text = this.ds.Tables[0].Rows[0]["Agent_Email"].ToString();
                this.txtAddress.Text = this.ds.Tables[0].Rows[0]["Agent_Address"].ToString();
                this.txtEmail.ReadOnly = true;
                this.txtAddress.ReadOnly = true;
                this.con.Close();
            }
        }
        catch (SqlException exception)
        {
            string message = exception.Message;
            this.lblMessage.Text = message;
            this.lblMessage.Visible = true;
        }
        finally
        {
            if ((this.con != null) && (this.con.State == ConnectionState.Open))
            {
                this.con.Close();
            }
        }
    }

    public void FindFlightDate()
    {
        this.con = new SqlConnection(this.strCon);
        this.con.Open();
        try
        {
            if (!(this.ddlFlightNo.SelectedValue == "-1"))
            {
                this.com = new SqlCommand("Select convert(varchar,Flight_Date,103) as Flight_Date from Import_Flight_Open where Import_Flight_Open_ID='" + this.ddlFlightNo.SelectedValue + "'", this.con);
                this.da = new SqlDataAdapter(this.com);
                this.ds = new DataSet();
                this.da.Fill(this.ds);
            }
        }
        catch (SqlException exception)
        {
            string message = exception.Message;
            this.lblMessage.Text = message;
            this.lblMessage.Visible = true;
        }
        finally
        {
            if ((this.con != null) && (this.con.State == ConnectionState.Open))
            {
                this.con.Close();
            }
        }
    }

    public void InsertCollectData()
    {
        this.con = new SqlConnection(this.strCon);
        this.con.Open();
        try
        {
            this.com = new SqlCommand("select Status_ID from Status_Master where Status_Name='No'", this.con);
            int num = Convert.ToInt32(this.com.ExecuteScalar().ToString());
            this.com.Dispose();
            string cmdText = "select * from Import_AWB where Import_AWB_no='" + this.txtAwbNo.Text + "'";
            this.com = new SqlCommand(cmdText, this.con);
            this.da = new SqlDataAdapter(this.com);
            DataTable dataTable = new DataTable();
            this.da.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                this.lblMessage.Text = "AWBNo Alredy Exists Plz Enter Other AWBNo!!";
                this.lblMessage.Visible = true;
            }
            else
            {
                string str2 = "insert into Import_AWB(Import_AWB_No,Import_Flight_Open_ID,No_of_Packages,Gross_Weight,Charged_Weight,No_of_Houses,Agent_Name,Agent_Email,Agent_Address,Mobile_No,Delivery_Order,Can_Status,Concerned_Person,Remarks,Nature_of_Goods,Freight_Type,Delivery_Order_Rate_House,Delivery_Order_Rate_Master)values(@Import_AWB_No,@Import_Flight_Open_ID,@No_of_Packages,@Gross_Weight,@Charged_Weight,@No_of_Houses,@Agent_Name,@Agent_Email,@Agent_Address,@Mobile_No,@Delivery_Order,@Can_Status,@Concerned_Person,@Remarks,@Nature_of_Goods,@Freight_Type,@Delivery_Order_Rate_House,@Delivery_Order_Rate_Master) ";
                this.com = new SqlCommand(str2, this.con);
                this.com.Parameters.AddWithValue("@Import_AWB_No", this.txtAwbNo.Text);
                this.com.Parameters.AddWithValue("@Import_Flight_Open_ID", this.ddlFlightNo.SelectedValue);
                this.com.Parameters.AddWithValue("@No_of_Packages", this.txtNoOfPieces.Text);
                this.com.Parameters.AddWithValue("@Gross_Weight", this.txtGrosswt.Text);
                this.com.Parameters.AddWithValue("@Charged_Weight", this.txtChargeWt.Text);
                this.com.Parameters.AddWithValue("@No_of_Houses", this.txtNoOfHouses.Text);
                if (this.rdAgent.SelectedValue == "0")
                {
                    string text = this.ddlAgent.SelectedItem.Text;
                    int index = text.IndexOf("-");
                    string str4 = text.Substring(0, index);
                    this.com.Parameters.AddWithValue("@Agent_Name", str4);
                }
                else if (this.rdAgent.SelectedValue == "1")
                {
                    this.com.Parameters.AddWithValue("@Agent_Name", this.txtNewCustomer.Text);
                }
                this.com.Parameters.AddWithValue("@Agent_Email", this.txtEmail.Text);
                this.com.Parameters.AddWithValue("@Agent_Address", this.txtAddress.Text);
                this.com.Parameters.AddWithValue("@Mobile_No", this.txtMobile.Text);
                this.com.Parameters.AddWithValue("@Delivery_Order", num);
                this.com.Parameters.AddWithValue("@Can_Status", num);
                this.com.Parameters.AddWithValue("@Concerned_Person", this.txtPersonName.Text);
                this.com.Parameters.AddWithValue("@Remarks", this.txtRemarks.Text);
                this.com.Parameters.AddWithValue("@Nature_of_Goods", this.txtNatuteGood.Text);
                this.com.Parameters.AddWithValue("@Freight_Type", this.ddlFrieght.SelectedValue);
                this.com.Parameters.AddWithValue("@Delivery_Order_Rate_House", 200);
                this.com.Parameters.AddWithValue("@Delivery_Order_Rate_Master", 700);
                this.com.ExecuteNonQuery();
                this.con.Close();
                this.lblMessage.Text = "Records Added Successfuly";
                this.lblMessage.Visible = true;
            }
        }
        catch (SqlException exception)
        {
            string message = exception.Message;
            this.lblMessage.Text = message;
            this.lblMessage.Visible = true;
        }
        finally
        {
            if ((this.con != null) && (this.con.State == ConnectionState.Open))
            {
                this.con.Close();
            }
        }
    }

    public void InsertPrepaidData()
    {
        this.con = new SqlConnection(this.strCon);
        this.con.Open();
        try
        {
            this.ddlFlightNo.SelectedItem.Text.Split(new char[] { '-' });
            double num2 = Convert.ToInt32(this.txtNoOfHouses.Text) * 200;
            double num3 = 700.0;
            double num4 = (num2 + num3) + (((num2 + num3) * 12.36) / 100.0);
            this.com = new SqlCommand("select Status_ID from Status_Master where Status_Name='No'", this.con);
            int num5 = Convert.ToInt32(this.com.ExecuteScalar().ToString());
            this.com.Dispose();
            string cmdText = "select * from Import_AWB where Import_AWB_no='" + this.txtAwbNo.Text + "'";
            this.com = new SqlCommand(cmdText, this.con);
            this.da = new SqlDataAdapter(this.com);
            DataTable dataTable = new DataTable();
            this.da.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                this.lblMessage.Text = "AWBNo Alredy Exists Plz Enter Other AWBNo!!";
                this.lblMessage.Visible = true;
            }
            else
            {
                string str2 = "insert into Import_AWB(Import_AWB_No,Import_Flight_Open_ID,No_of_Packages,Gross_Weight,Charged_Weight,No_of_Houses,Agent_Name,Agent_Email,Agent_Address,Mobile_No,Delivery_Order,Can_Status,Concerned_Person,Remarks,Payable_Amount,Nature_of_Goods,Freight_Type,Delivery_Order_Rate_House,Delivery_Order_Rate_Master)values(@Import_AWB_No,@Import_Flight_Open_ID,@No_of_Packages,@Gross_Weight,@Charged_Weight,@No_of_Houses,@Agent_Name,@Agent_Email,@Agent_Address,@Mobile_No,@Delivery_Order,@Can_Status,@Concerned_Person,@Remarks,@Payable_Amount,@Nature_of_Goods,@Freight_Type,@Delivery_Order_Rate_House,@Delivery_Order_Rate_Master) ";
                this.com = new SqlCommand(str2, this.con);
                this.com.Parameters.AddWithValue("@Import_AWB_No", this.txtAwbNo.Text);
                this.com.Parameters.AddWithValue("@Import_Flight_Open_ID", this.ddlFlightNo.SelectedValue);
                this.com.Parameters.AddWithValue("@No_of_Packages", this.txtNoOfPieces.Text);
                this.com.Parameters.AddWithValue("@Gross_Weight", this.txtGrosswt.Text);
                this.com.Parameters.AddWithValue("@Charged_Weight", this.txtChargeWt.Text);
                this.com.Parameters.AddWithValue("@No_of_Houses", this.txtNoOfHouses.Text);
                if (this.rdAgent.SelectedValue == "0")
                {
                    string text = this.ddlAgent.SelectedItem.Text;
                    int index = text.IndexOf("-");
                    string str4 = text.Substring(0, index);
                    this.com.Parameters.AddWithValue("@Agent_Name", str4);
                }
                else if (this.rdAgent.SelectedValue == "1")
                {
                    this.com.Parameters.AddWithValue("@Agent_Name", this.txtNewCustomer.Text);
                }
                this.com.Parameters.AddWithValue("@Agent_Email", this.txtEmail.Text);
                this.com.Parameters.AddWithValue("@Agent_Address", this.txtAddress.Text);
                this.com.Parameters.AddWithValue("@Mobile_No", this.txtMobile.Text);
                this.com.Parameters.AddWithValue("@Delivery_Order", num5);
                this.com.Parameters.AddWithValue("@Can_Status", num5);
                this.com.Parameters.AddWithValue("@Concerned_Person", this.txtPersonName.Text);
                this.com.Parameters.AddWithValue("@Remarks", this.txtRemarks.Text);
                this.com.Parameters.AddWithValue("@Payable_Amount", num4);
                this.com.Parameters.AddWithValue("@Nature_of_Goods", this.txtNatuteGood.Text);
                this.com.Parameters.AddWithValue("@Freight_Type", this.ddlFrieght.SelectedValue);
                this.com.Parameters.AddWithValue("@Delivery_Order_Rate_House", 200);
                this.com.Parameters.AddWithValue("@Delivery_Order_Rate_Master", 700);
                this.com.ExecuteNonQuery();
                this.con.Close();
                this.lblMessage.Text = "Records Added Successfuly";
                this.lblMessage.Visible = true;
            }
        }
        catch (SqlException exception)
        {
            string message = exception.Message;
            this.lblMessage.Text = message;
            this.lblMessage.Visible = true;
        }
        finally
        {
            if ((this.con != null) && (this.con.State == ConnectionState.Open))
            {
                this.con.Close();
            }
        }
    }

    protected void rdAgent_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.rdAgent.SelectedValue == "0")
        {
            this.txtNewCustomer.Visible = false;
            this.ddlAgent.Visible = true;
            this.BindAgentNameCity();
        }
        else
        {
            this.ddlAgent.Visible = false;
            this.txtNewCustomer.Visible = true;
            this.txtAddress.Text = "";
            this.txtEmail.Text = "";
            this.txtEmail.ReadOnly = false;
            this.txtAddress.ReadOnly = false;
        }
    }
}

