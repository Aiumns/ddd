﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CppReportQuaterwise : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();

    int City_ID;
    string City_Name = "";
    string From_Date = "";
    string To_date = "";
    string table1 = "";
    string table2 = "";
    int j;
    string FinalTable = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }



        else
        {
            FinalTable += @"<h5><p align=center> CPP QUARTERLY REPORTS<br></p></h5>";
            DataTable dtcity = dw.GetAllFromQuery("select city_id,City_Name from city_master where city_id in (6,18) ");
            if (dtcity.Rows.Count > 0)
            {

                for (int i = 0; i < dtcity.Rows.Count; i++)
                {
                    DataTable dtstartdate = dw.GetAllFromQuery("SELECT TOP 1  CONVERT(VARCHAR(11),tran_date,101) AS STARTdate,(SELECT TOP 1 CONVERT(VARCHAR(11),tran_date,101) FROM db_owner.CPP_tran WHERE city_id=" + dtcity.Rows[i]["city_id"].ToString() + " ORDER BY tran_date DESC) AS ENDDate FROM db_owner.CPP_tran  where db_owner.CPP_tran.city_id=" + dtcity.Rows[i]["city_id"].ToString() + "  ORDER BY db_owner.CPP_tran.tran_date asc");
                    DateTime STARTDATE = Convert.ToDateTime(dtstartdate.Rows[0]["STARTDATE"].ToString());
                    DateTime ENDDate = Convert.ToDateTime(dtstartdate.Rows[0]["ENDDate"].ToString());
                    int k = ENDDate.Year - STARTDATE.Year;
                    int month = ((k * 12) + Math.Abs((ENDDate.Month - STARTDATE.Month)));
                    City_Name = dtcity.Rows[i]["city_Name"].ToString();
                    table1 = @"<table border=1 width=100% align=center cellpading=2 > <tr class=h1 width=100%><td align=center class=boldtext width=30% colspan=10 NOWRAP><h4> Cpp Reports </h4></tr>";
                    table1 += @" <tr class=h1 width=100%><td align=center class=boldtext width=30% colspan=10 NOWRAP><h4> Reports for " + City_Name + " for period of " + From_Date + " - " + To_date + "</h4></td></tr>";
                    table2 += @"<table border=1 width=70% align=center><tr><td class=h1 align=center colspan=10 NOWRAP><b> " + City_Name + "</b></td></tr>";
                    table2 = table2 + @"<tr><td class=boldtext align=center  widtd=10%> Quarter </td><td class=boldtext nowrap widtd=15% align=center>Opening Bal</td><td class=boldtext nowrap widtd=20% align=center>Earned</td><td class=boldtext nowrap widtd=15% align=center>Advance</td><td class=boldtext widtd=15% align=center >Expired</td><td class=boldtext widtd=15% >Advance Reverse </td><td class=boldtext widtd=15% align=center>Redeemed</td><td widtd=15% class=boldtext align=center>Closing Bal</td></tr>";
                    
                    for (int l = 0; l < month/3-1; l++)
                    {
                        

                       
                       
                        LoadDetails1(dtcity.Rows[i]["city_id"].ToString(),STARTDATE.AddMonths(3*l));

                        

                    }
                    table1 = table1 + @"</table>";
                    table2 = table2 + @"</table>";
                   //
                    
                }
            }
            FinalTable += table2;
            lblcity.Text = FinalTable;
        }


    }
    public void LoadDetails1(string city_id,DateTime dt)
    {

        City_ID = Convert.ToInt32(city_id);
        //DataTable dtCityName = dw.GetAllFromQuery("select City_Name from City_Master Where City_Id=" + city_id + "");
        //if (dtCityName.Rows.Count > 0)
        //{
        //    City_Name = dtCityName.Rows[0]["city_Name"].ToString();
        //}
        // From_Date = dt.ToString("MM/dd/yyyy");
        // To_date = dt.AddMonths(3).AddDays(-1).ToString("MM/dd/yyyy");
        //Panel2.Visible = true;

        int totalDeposite = 0;
        int totalExpired = 0;
        int totalAdvanced = 0;
        int totalredeemed = 0;
        int totalreverse = 0;

        int totalDeposite1 = 0;
        int totalExpired1 = 0;
        int totalAdvanced1 = 0;
        int totalredeemed1 = 0;
        int totalopeningbal1 = 0;
        int totalclosing = 0;
        int totalreverse1 = 0;

       
        string old_agent_name = "";



        //---------------------------------------------------create table1//--------------------------------------
        DataTable dt1 = null;

        //DataTable dt1 = dw.GetAllFromQuery("select am.agent_name ,ct.* from cpp_tran ct inner join agent_master am on ct.agent_id=am.agent_id where ct.city_id="+City_ID +" and ct.tran_date between '" + FormatDateDD(From_Date) + "'and '" + FormatDateDD(To_date) + "' order by ct.agent_id,ct.tran_date ");
        dt1 = dw.GetAllFromQuery("create table #tem3( agent_name varchar(250), tran_id bigint, agent_id bigint,city_id bigint,opening_bal decimal, cpp decimal,closing_bal decimal,tran_type char,tran_date datetime,remarks varchar(255),Value_Date datetime )insert into #tem3( agent_name, tran_id , agent_id ,city_id ,opening_bal , cpp ,closing_bal ,tran_type ,tran_date ,remarks,Value_Date) select am.agent_name ,ct.* from cpp_tran ct inner join agent_master am on ct.agent_id=am.agent_id where ct.city_id=" + City_ID + " order by ct.agent_id,ct.ValueDate ,ct.tran_id  create table #tem4( agent_name varchar(250), tran_id bigint, agent_id bigint,city_id bigint,opening_bal decimal, cpp decimal,closing_bal decimal,tran_type char,tran_date datetime,remarks varchar(255) ,Value_Date datetime)insert into #tem4( agent_name, tran_id , agent_id ,city_id ,opening_bal , cpp ,closing_bal ,tran_type ,tran_date ,remarks,Value_Date ) select am.agent_name ,ct.* from cpp_tran ct inner join agent_master am on ct.agent_id=am.agent_id where ct.city_id=" + City_ID + " AND CAST( CAST(ct.tran_date AS VARCHAR(12)) AS datetime)>='" + dt.ToString("MM/dd/yyyy") + "' AND CAST( CAST(ct.tran_date AS VARCHAR(12)) AS datetime)<='" + dt.AddMonths(3).AddDays(-1).ToString("MM/dd/yyyy") + "' order by ct.agent_id,ct.ValueDate ,ct.tran_id create table #tem5( agent_name varchar(250), tran_id bigint, agent_id bigint,city_id bigint,opening_bal decimal, cpp decimal,closing_bal decimal,tran_type char,tran_date datetime,remarks varchar(255),Value_Date datetime)insert into #tem5( agent_name, tran_id , agent_id ,city_id ,opening_bal , cpp ,closing_bal,tran_type,tran_date ,remarks,Value_Date  )SELECT * FROM #tem3 WHERE agent_id NOT IN (SELECT agent_id FROM #tem4)DECLARE @id INT DECLARE Agentin CURSOR FOR SELECT DISTINCT agent_id FROM #tem5 WHERE CAST( CAST(tran_date AS VARCHAR(12)) AS datetime)<='" + dt.ToString("MM/dd/yyyy") + "' OPEN Agentin FETCH NEXT FROM Agentin INTO @id WHILE @@FETCH_STATUS=0 BEGIN insert into #tem4( agent_name, tran_id , agent_id ,city_id ,opening_bal ,closing_bal, tran_type,tran_date ,remarks,Value_Date ) SELECT TOP 1 agent_name,tran_id,agent_id,city_id,closing_bal,closing_bal,tran_type,tran_date,remarks,Value_Date  FROM #tem5 WHERE CAST( CAST(tran_date AS VARCHAR(12)) AS datetime)<'" + dt.ToString("MM/dd/yyyy") + "' AND agent_id=@id  ORDER BY  Value_Date DESC,tran_id desc FETCH NEXT FROM Agentin INTO @id END CLOSE Agentin DEALLOCATE Agentin SELECT agent_name,tran_id,agent_id,city_id,opening_bal,ISNULL(cpp,0)AS cpp,closing_bal,tran_type,tran_date,remarks,Value_Date FROM #tem4 ORDER BY agent_name");






        //table1 = @"<table border=1 width=100% align=center cellpading=2 > <tr class=h1 width=100%><td align=center class=boldtext width=30% colspan=10 NOWRAP><h4> Cpp Reports </h4></tr>";

        //table1 += @" <tr class=h1 width=100%><td align=center class=boldtext width=30% colspan=10 NOWRAP><h4> Reports for " + City_Name + " for period of " + From_Date + " - " + To_date + "</h4></td></tr>";
        //table2 += @"<table border=1 width=70% align=center><tr><td class=h1 align=center colspan=10 NOWRAP><b>Reports for " + City_Name + "</b></td></tr>";

        if (dt1.Rows.Count > 0)
        {

            table1 = table1 + @"<tr><td class=boldtext align=center colspan=2 widtd=10%>S.No</td><td class=boldtext >Agent Name</td><td class=boldtext nowrap widtd=15% >Opening Bal</td><td class=boldtext nowrap widtd=20%>Earned</td><td class=boldtext nowrap widtd=15%>Advance</td><td class=boldtext widtd=15% >Expired</td><td class=boldtext widtd=15% >Advance Reverse </td><td class=boldtext widtd=15% >Redeemed</td><td widtd=15% class=boldtext >Closing Bal</td></tr>";
         //   table2 = table2 + @"<tr><td class=boldtext align=center rowspan=2 widtd=10%>" + dt.ToString("MM/dd/yyyy") + "-" + dt.AddMonths(3).AddDays(-1).ToString("MM/dd/yyyy") + "</td><td class=boldtext nowrap widtd=15% align=center>Opening Bal</td><td class=boldtext nowrap widtd=20% align=center>Earned</td><td class=boldtext nowrap widtd=15% align=center>Advance</td><td class=boldtext widtd=15% align=center >Expired</td><td class=boldtext widtd=15% >Advance Reverse </td><td class=boldtext widtd=15% align=center>Redeemed</td><td widtd=15% class=boldtext align=center>Closing Bal</td></tr>";
            int i = 0;
            old_agent_name = dt1.Rows[i]["agent_name"].ToString();
            string openingbal = dt1.Rows[i]["opening_bal"].ToString();
            for (i = 0; i < dt1.Rows.Count; i++)
            {

                string agent_name = dt1.Rows[i]["agent_name"].ToString();
                if (agent_name == old_agent_name)
                {
                    if (dt1.Rows[i]["Tran_type"].ToString() == "D")
                    {
                        totalDeposite += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                    }
                    else
                    {
                        if (dt1.Rows[i]["Tran_type"].ToString() == "E")
                        {
                            totalExpired += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                        }
                        else
                        {
                            if (dt1.Rows[i]["Tran_type"].ToString() == "A")
                            {
                                totalAdvanced += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                            }
                            else
                            {
                                if (dt1.Rows[i]["Tran_type"].ToString() == "B")
                                {
                                    totalreverse += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }
                                else
                                {

                                    totalredeemed += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }

                            }
                        }
                    }

                }
                else
                {



                    j = j + 1;

                    table1 = table1 + @"<tr><td class=boldtext align=center colspan=2 >" + j + @" </td><td class=boldtext align=left>" + old_agent_name + @"</td><td class=boldtext nowrap align=right >" + openingbal + @"</td><td class=boldtext align=right nowrap>" + totalDeposite + @"</td><td align=right class=boldtext nowrap>" + totalAdvanced + @"</td><td align=right class=boldtext nowrap>" + -totalExpired + @"</td><td align=right class=boldtext >" + -totalreverse + @"</td><td align=right class=boldtext >" + -totalredeemed + @"</td><td align=right class=boldtext nowrap>" + dt1.Rows[i - 1]["closing_bal"].ToString() + @"</td></tr>";
                    totalDeposite1 += totalDeposite;
                    totalExpired1 = totalExpired1 - totalExpired;
                    totalAdvanced1 += totalAdvanced;
                    totalredeemed1 = totalredeemed1 - totalredeemed;
                    totalopeningbal1 += Convert.ToInt32(openingbal);
                    totalreverse1 = totalreverse1 - totalreverse;
                    totalclosing += Convert.ToInt32(dt1.Rows[i - 1]["closing_bal"].ToString());


                    old_agent_name = dt1.Rows[i]["agent_name"].ToString();
                    openingbal = dt1.Rows[i]["opening_bal"].ToString();

                    totalAdvanced = 0;
                    totalDeposite = 0;
                    totalExpired = 0;
                    totalredeemed = 0;
                    totalreverse = 0;

                    if (dt1.Rows[i]["Tran_type"].ToString() == "D")
                    {
                        totalDeposite += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                    }
                    else
                    {
                        if (dt1.Rows[i]["Tran_type"].ToString() == "E")
                        {
                            totalExpired += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                        }
                        else
                        {
                            if (dt1.Rows[i]["Tran_type"].ToString() == "A")
                            {
                                totalAdvanced += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                            }
                            else
                            {
                                if (dt1.Rows[i]["Tran_type"].ToString() == "B")
                                {
                                    totalreverse += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }
                                else
                                {

                                    totalredeemed += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }

                            }
                        }
                    }


                }






            }

            table1 = table1 + @"<tr><td class=boldtext align=center colspan=2 >" + (j + 1) + @" </td><td class=boldtext align=left >" + old_agent_name + @"</td><td align=right class=boldtext nowrap >" + openingbal + @"</td><td align=right class=boldtext nowrap>" + totalDeposite + @"</td><td align=right class=boldtext nowrap>" + totalAdvanced + @"</td><td align=right class=boldtext nowrap>" + -totalExpired + @"</td><td align=right class=boldtext >" + -totalreverse + @"</td><td align=right class=boldtext >" + -totalredeemed + @"</td><td align=right class=boldtext nowrap>" + dt1.Rows[i - 1]["closing_bal"].ToString() + @"</td></tr>";
            totalDeposite1 += totalDeposite;
            totalExpired1 = totalExpired1 - totalExpired;
            totalAdvanced1 += totalAdvanced;
            totalredeemed1 = totalredeemed1 - totalredeemed;
            totalreverse1 = totalreverse1 - totalreverse;
            totalopeningbal1 += Convert.ToInt32(openingbal);
            totalclosing += Convert.ToInt32(dt1.Rows[i - 1]["closing_bal"].ToString());
            table1 = table1 + @"<tr><td class=boldtext align=center colspan=3 > </td><td align=right class=boldtext nowrap >" + totalopeningbal1 + @"</td><td align=right class=boldtext nowrap>" + totalDeposite1 + @"</td><td align=right class=boldtext nowrap>" + totalAdvanced1 + @"</td><td align=right class=boldtext nowrap>" + -totalExpired1 + @"</td><td align=right class=boldtext >" + totalreverse1 + @"</td><td align=right class=boldtext >" + -totalredeemed1 + @"</td><td align=right class=boldtext nowrap>" + totalclosing + @"</td></tr>";
            table2 = table2 + @"<tr><td class=boldtext align=center  widtd=10%>" + dt.ToString("dd/MM/yy") +   "-" + dt.AddMonths(3).AddDays(-1).ToString("dd/MM/yy") + "</td><td align=center class=boldtext nowrap >" + totalopeningbal1 + @"</td><td align=center class=boldtext nowrap>" + totalDeposite1 + @"</td><td align=center class=boldtext nowrap>" + totalAdvanced1 + @"</td><td align=center class=boldtext nowrap>" + totalExpired1 + @"</td><td align=right class=boldtext >" + totalreverse1 + @"</td><td align=center class=boldtext >" + totalredeemed1 + @"</td><td align=center class=boldtext nowrap>" + totalclosing + @"</td></tr>";

        }
        else
        {
            table1 = table1 + @"<tr><td class=boldtext style=""color: Red;font-family:verdana;font-size:12px; text-align: center;"" colspan=10>No Record Found</td></tr>";
            table2 = table2 + @"<tr><td class=boldtext style=""color: Red;font-family:verdana;font-size:12px; text-align: center;"" colspan=10>No Record Found</td></tr>";

        }




        //table1 = table1 + @"</table>";
        //table2 = table2 + @"</table>";

        if (dt.ToString("MM/dd/yyyy") == "10/01/2010" )
            {
            
            }
        // lblreports.Text = table1;
        //FinalTable = table2;
        //lblcity.Text = table2;
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
