using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Cheque_Deposit_Summ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            hdnDate.Value = first.ToString();
            Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");

            txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }
    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        Session["from_date"] = txtValidFrom.Text;
        Session["to_date"] = txtValidTo.Text;

        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/Cheque_Deposit_Summary.aspx');</script>");
    }
}
