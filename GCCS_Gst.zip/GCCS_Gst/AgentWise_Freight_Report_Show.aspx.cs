using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AgentWise_Freight_Report_Show : System.Web.UI.Page
{
    // --- Declare Public Variables here ---
    string table = null;
    DisplayWrap dw = new DisplayWrap();
    /// <summary>
    /// Make Connection From Web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            // ---- Fetch Data From Session ---
            string[] airline_name_city_text = Session["airline_city_text"].ToString().Split(',');
            string[] airline_name_city_value = Session["airline_city_value"].ToString().Split(',');
            string[] air_name_val = airline_name_city_value[0].Split('%');
            string from_date = Session["from_date"].ToString();
            string to_date = Session["to_date"].ToString();
            string SelectDate = Session["SelectDate"].ToString();
            string SelectDate1 = "", SelectDate2 = "";
            int awb = 0;
            int total_Awb = 0;
            decimal ch_wt = 0, freight_amt = 0, due_agent_pp = 0, due_agent_cc= 0,due_agent=0, due_carr = 0, comm_amt, discount = 0;
            decimal total_ch_wt = 0, total_freight_amt = 0, total_due_agent_pp = 0, total_due_agent = 0, total_due_agent_cc = 0, total_due_carr = 0, total_comm_amt=0, total_discount = 0;
            if (SelectDate.ToString() == "0")
            {
                SelectDate1 = "Awb_Date";
                SelectDate2 = "Awb Date";
            }
            else
            {
                SelectDate1 = "Flight_Date";
                SelectDate2 = "Flight Date";
            }
            DataTable dt = dw.GetAllFromQuery("select Agent_Name,count(Airwaybill_no) as Awb,Agent_Address,sum(isnull(Charged_Weight,0)) as 'Charged_Weight',sum(isnull(Freight_Amount,0)) as 'Freight_Amount',sum(isnull(TotalDueAgent_Prepaid,0)) as 'TotalDueAgent_Prepaid',sum(isnull(TotalDueAgent_collect,0)) as 'TotalDueAgent_collect',sum(isnull(Total_DueCarrier,0)) as 'Total_DueCarrier',sum(CASE WHEN Commission=0 AND Spot_Rate=0 THEN 0 ELSE CASE WHEN Commission=0 AND Spot_Rate<>0 THEN (Freight_Amount*5)/100 ELSE (Freight_Amount*Commission)/100 END END) AS Commissionable_Amount,sum(CASE WHEN Commission=0 AND Spot_Rate=0 THEN 0 ELSE CASE WHEN Commission=0 AND Spot_Rate<>0 THEN CASE WHEN (tariff_rate-spot_rate=0) THEN 0 ELSE	(round(((Tariff_Rate-Spot_Rate)*Charged_Weight),0)-round(((Freight_Amount*5)/100),0))END	ELSE CASE Spot_Rate WHEN 0 THEN (((Freight_Amount-((Freight_Amount*Commission)/100))*Special_Commodity_Incentive)/100)ELSE ((Tariff_Rate-Spot_Rate)*Charged_Weight)+(((Freight_Amount-((Freight_Amount*Commission)/100))*Special_Commodity_Incentive)/100)END END END)AS Discount from Sales inner join Agent_Master on Sales.Agent_ID=Agent_Master.Agent_ID inner join agent_branch AB on AB.Agent_id=Agent_Master.Agent_ID where airline_detail_id=" + Convert.ToInt64(airline_name_city_value[1]) + " and city_id=" + Convert.ToInt64(air_name_val[0]) + " and belongs_to_city=" + Convert.ToInt64(air_name_val[0]) + " and " + SelectDate1 + " between '" + FormatDateMM(from_date) + "' and '" + FormatDateMM(to_date) + "' group by  Agent_Name,Agent_Address  order by agent_name");
            if (dt.Rows.Count > 0)
            {
                Response.Write("<h5><p align=center>CARGO RATES REPORT <br>" + from_date + " - " + to_date + "</p></h5>");
                Response.Write("<table align=center width=100% border=1 cellspacing=0><tr><th colspan=9 align=center>" + airline_name_city_text[0] + " (Based on " + SelectDate2 + ")</th></tr><tr><th>Agent/Party</th><th>Party Address</th><th>Awb Count</th> <th>Ch Wt.</th><th>Total Freight</th> <th>Due Agent</th> <th>Due Carrier</th><th>Commission</th><th>Discount</th></tr>");
                foreach (DataRow drow in dt.Rows)
                {
                    awb = int.Parse(drow["Awb"].ToString());
                    total_Awb += awb;
                    ch_wt = Math.Round(decimal.Parse(drow["Charged_Weight"].ToString()),MidpointRounding.AwayFromZero);
                    total_ch_wt=total_ch_wt+ch_wt;
                    freight_amt = Math.Round(decimal.Parse(drow["Freight_Amount"].ToString()),MidpointRounding.AwayFromZero);
                    total_freight_amt = total_freight_amt + freight_amt;
                    due_agent_pp = Math.Round(decimal.Parse(drow["TotalDueAgent_Prepaid"].ToString()),MidpointRounding.AwayFromZero);
                    total_due_agent_pp = total_due_agent_pp + due_agent_pp;
                    due_agent_cc = Math.Round(decimal.Parse(drow["TotalDueAgent_collect"].ToString()),MidpointRounding.AwayFromZero);
                    total_due_agent_cc = total_due_agent_cc + due_agent_cc;
                    due_agent = due_agent_pp + due_agent_cc;
                    total_due_agent = total_due_agent + due_agent;
                    due_carr = Math.Round(decimal.Parse(drow["Total_DueCarrier"].ToString()),MidpointRounding.AwayFromZero);
                    total_due_carr = total_due_carr + due_carr;
                    comm_amt = Math.Round(decimal.Parse(drow["Commissionable_Amount"].ToString()),MidpointRounding.AwayFromZero);
                    total_comm_amt = total_comm_amt + comm_amt;
                    discount = Math.Round(decimal.Parse(drow["discount"].ToString()),MidpointRounding.AwayFromZero);
                    total_discount = total_discount + discount;

                    Response.Write("<tr><td class=text>" + drow["Agent_Name"].ToString() + "</td><td class=text>" + drow["Agent_Address"].ToString() + "</td><td align=right class=text>" + awb + "</td><td align=right class=text>" + ch_wt + "</td><td align=right class=text>" + freight_amt + "</td><td align=right class=text>" + due_agent + "</td><td align=right class=text>" + due_carr + "</td><td align=right class=text>" + comm_amt + "</td><td align=right class=text>" + discount + "</td></tr>");
                }
                Response.Write("<tr><td colspan =2></td><td align=right class=boldtext>" + total_Awb + "</td><td align=right class=boldtext>" + total_ch_wt + "</td><td align=right class=boldtext>" + total_freight_amt + "</td><td align=right class=boldtext>" + total_due_agent + "</td><td align=right class=boldtext>" + total_due_carr + "</td><td align=right class=boldtext>" + total_comm_amt + "</td><td align=right class=boldtext>" + total_discount + "</td></tr>");


            }

        }
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
