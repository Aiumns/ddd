using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//using System.Windows.Forms;
//using System.Windows.Browser;

///<modification>
///			<changeDescription>
/// </changeDescription>
///			<modifiedBy>Shaikh Akhtar Rasool</modifiedBY>
/// ///			<modifiedOn>16 Jan 2008</modifiedOn>
///		</modification>
/// </modifications>

public partial class AgentRate : System.Web.UI.Page
{
    public string disableString = "";
    public string disableValidTo = "";
    DisplayWrap dw = new DisplayWrap();
    public string strLen = "";
    SqlConnection con;
    SqlCommand cmd;
    public string SlabCounter1 = "";
    string shipmentId;
    string SCRId;
    string statusId;
    string email_Id = "";
    string loginid ;
    string[] strAgentID;
    SqlTransaction trans;
    int s = 0;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            loginid = Session["EMailID"].ToString();
            //**********Calling Javascript on Textboxes************************
            strLen = "<script>var FillCity=new Array(" + TxtDestinationPlusCode() + ")</script>";

            if (!IsPostBack)
            {
                //************* Filling All Dropdowns*******************
                //AirlineNamePlusCode();
                airlineDetails();
                if (ddlAirline.SelectedValue.Equals("y"))
                {
                    ddlAirlineCity.Items.Clear();
                    btnAdd.Enabled = false;
                }

                ddlShipmentNameFill();
                ddlScrNameFill();
            }
            if (!IsPostBack && Request.QueryString["Agent_Rate_ID"] != null)
            {
               
                lblUpdate.Visible = true;
                lblAdd.Visible = false;
                btnUpdate.Visible = true;
                btnAdd.Visible = false;
                
                lblViewRate.Visible = false;
                selectData();
                ddlAirline.Enabled = false;
                ddlAirlineCity.Enabled = false;
                ddlScrName.Enabled = false;
                ddlShipmentName.Enabled = false;
                txtDestination.ReadOnly = true;
                txtValidFrom.ReadOnly = true;
                txtValidTo.ReadOnly = true;
                disableString = "visibility:hidden";
                disableValidTo = "visibility:hidden";
            }
            else
            {
                disableValidTo = "";
                disableString = "";
                lblUpdate.Visible = false;
                lblAdd.Visible = true;
                btnAdd.Visible = true;
                btnUpdate.Visible = false;
                lblViewRate.Visible = false;
            }
        }
    }
    public void airlineDetails()
    {
        con = new SqlConnection(strCon);
        try
        {  
            con.Open();
            string Access = "select * from Login_Master where Email_Id='" + loginid + "'";
            SqlCommand com1 = new SqlCommand(Access, con);
            SqlDataReader dr11 = com1.ExecuteReader();
            dr11.Read();
            string ATC = dr11["Airline_Access"].ToString();
         
            //int s = ATC.LastIndexOf(",");
            //string s1 = ATC.Remove(s);
            string[] str = ATC.Split(',');
            dr11.Close();
            ddlAirline.Items.Add(new ListItem("--Select--", "y"));
            
            
            //foreach (string st in str)
            //{ strQuery = "Select Airline_Detail_ID,Airline_ID,Belongs_To_City from Airline_Detail where Airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ")";
                ////////////Modified here ///////////////////////
            string strAirline = "select Airline_Name,Airline_Code,Airline_Detail_ID,City_Code from airline_master inner join Airline_Detail on airline_master.Airline_ID=Airline_Detail.Airline_ID inner join City_Master on Airline_Detail.Belongs_To_City=City_ID where Airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ")order by Airline_Name,City_Code";
                SqlCommand com = new SqlCommand(strAirline, con);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "-(" + dr["Airline_Code"].ToString() + ")-(" + dr["City_Code"] .ToString() + ")", dr["Airline_Detail_ID"].ToString()));
                }
                    dr.Close();
            //}

            if (Request.QueryString["Agent_Rate_ID"] != null)
            {

                ddlAirline.Items.Clear();
                
                DataTable dtAir = dw.GetAllFromQuery("select Airline_Detail_ID from db_owner.Agent_Rate_Master where Agent_Rate_ID=" + Request.QueryString["Agent_Rate_ID"] + "");

              strAirline = "select Airline_Name,Airline_Code,Airline_Detail_ID,City_Code from airline_master inner join Airline_Detail on airline_master.Airline_ID=Airline_Detail.Airline_ID inner join City_Master on Airline_Detail.Belongs_To_City=City_ID where Airline_detail_id in (" + dtAir.Rows[0]["Airline_Detail_ID"].ToString()+ ")order by Airline_Name";
                com = new SqlCommand(strAirline, con);
                 dr = com.ExecuteReader();
                while (dr.Read())
                {
                    ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "-(" + dr["Airline_Code"].ToString() + ")-(" + dr["City_Code"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));
                }
                dr.Close();


                //int s = ddlAirline.Items.IndexOf(ddlAirline.Items.FindByValue(dtAir.Rows[0]["Airline_Detail_ID"].ToString()));
               // ddlAirline.Items[s].Selected = true;

                
                
                
                //for (int it = 0; it < ddlAirline.Items.Count; it++)
                //{
                //    s = ddlAirline.Items.IndexOf(ddlAirline.Items.FindByValue(dtAir.Rows[0]["Airline_Detail_ID"].ToString()));
                //    if (it != s)
                //    {
                //        ddlAirline.Items.RemoveAt(it);   
                //    }
                //    else
                //    {
                //        if (s != 1)
                //        {
                //            it = 0;
                //        }
                //    }
                //    if (s == 1)
                //    {
                //        break;

                //    }

                //}
                int count = ddlAirline.Items.Count; 
                s = ddlAirline.Items.IndexOf(ddlAirline.Items.FindByValue(dtAir.Rows[0]["Airline_Detail_ID"].ToString()));
                ddlAirline.SelectedIndex = s;
                //ddlAirline.Items[s].Selected = true;


            } 
            
            con.Close();
        }
        catch(SqlException sqle)
        {
            string err = sqle.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

    public void airlineCity()
    {
        
        con = new SqlConnection(strCon);
        try
        {
            ddlAirlineCity.Enabled = true;
            string airlineId = ddlAirline.SelectedValue;
            string strCity = "select C.city_name,C.city_Id, Airline_Detail_Id from City_Master C inner join Airline_Detail A on C.City_ID = A.Belongs_To_City where A.Airline_Detail_ID = '" + airlineId + "' order by C.city_name";
            con.Open();
            SqlDataAdapter daCity = new SqlDataAdapter(strCity, con);
            DataSet dsCity = new DataSet();
            daCity.Fill(dsCity);
            if (dsCity.Tables[0].Rows.Count > 0)
            {
                ddlAirlineCity.DataSource = dsCity;
                ddlAirlineCity.DataTextField = "city_name";
                ddlAirlineCity.DataValueField = "city_Id";
                ddlAirlineCity.DataBind();
                
            }
            con.Close();
            fillSlabGrid();
        }
        catch (SqlException sqle)
        {
            string err = sqle.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void fillSlabGrid()
    {
        con = new SqlConnection(strCon);
        try
        {
            string strQuery = "";
            string airlineId = ddlAirline.SelectedValue;
            string cityId = ddlAirlineCity.SelectedValue;
           // strQuery = "select airline_detail_id from airline_detail where Airline_ID = '" + airlineId + "' and Belongs_To_City = '" + cityId + "' ";
            con.Open();
           // SqlDataAdapter daSlab = new SqlDataAdapter(strQuery, con);
            //DataSet dsSlab = new DataSet();
            //daSlab.Fill(dsSlab);
            //if (dsSlab.Tables[0].Rows.Count > 0)
            //{
                SlabGrd.Visible = true;
                string airlineDetailId = airlineId; //dsSlab.Tables[0].Rows[0]["Airline_Detail_ID"].ToString();
                ViewState["airlineDetailId"] = airlineId;
                DataTable dtSlab = dw.GetAllFromQuery("select S.slab_Id,S.Slab_Name from Slab_Master S inner join Airline_Slab A on S.Slab_ID = A.Slab_ID where A.airline_detail_id='" + airlineDetailId + "' order by S.Slab_Start asc ");
                ViewState["dtSlab"] = dtSlab;
                SlabGrd.DataSource = dtSlab;
                SlabGrd.DataBind();
            //}
            //else
            //{
            //    SlabGrd.Visible = false;
            //}
                con.Close();
        }
        catch (SqlException sqle)
        {
            string err = sqle.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public bool compareDate(string first, string second)
    {
        string[] cdate1 = first.Split('/');
        string[] cdate2 = second.Split('/');

        int fd = Convert.ToInt32(cdate1[0]);
        int fm = Convert.ToInt32(cdate1[1]);
        int fy = Convert.ToInt32(cdate1[2]);

        int sd = Convert.ToInt32(cdate2[0]);
        int sm = Convert.ToInt32(cdate2[1]);
        int sy = Convert.ToInt32(cdate2[2]);

        DateTime dt1 = new DateTime(fy, fm, fd);
        DateTime dt2 = new DateTime(sy, sm, sd);

        if (DateTime.Compare(dt1, dt2) < 0 || DateTime.Compare(dt1, dt2) == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool compareCurDate(string first, string second)
    {
        string[] cdate1 = first.Split('/');
        string[] cdate2 = second.Split('/');

        int fd = Convert.ToInt32(cdate1[0]);
        int fm = Convert.ToInt32(cdate1[1]);
        int fy = Convert.ToInt32(cdate1[2]);

        int sd = Convert.ToInt32(cdate2[0]);
        int sm = Convert.ToInt32(cdate2[1]);
        int sy = Convert.ToInt32(cdate2[2]);

        DateTime dt1 = new DateTime(fy, fm, fd);
        DateTime dt2 = new DateTime(sy, sm, sd);

        if (DateTime.Compare(dt1, dt2) > 0 || DateTime.Compare(dt1, dt2) == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool checkRate()
    {
        con = new SqlConnection(strCon);
        string airlineDetailId= "";
        string destination="";
        string airlineId = ddlAirline.SelectedValue;
        string cityId = ddlAirlineCity.SelectedValue;
        string shipmentId = ddlShipmentName.SelectedValue;
        string commodity = ddlScrName.SelectedValue; 
        //string destination = txtDestination.Text;
        string strDestination = txtDestination.Text.Trim();
        strDestination = strDestination.Substring(0, 3);
        DataTable dtDestination = dw.GetAllFromQuery("select Destination_ID from Destination_Master where Destination_Code='" + strDestination + "'");
        if (dtDestination.Rows.Count > 0)
        {
            destination = dtDestination.Rows[0]["Destination_ID"].ToString();
        }
        DataTable dtAirlineDetailID = dw.GetAllFromQuery("select airline_detail_Id from airline_detail where airline_id = '" + airlineId + "' and belongs_to_city = '" + cityId + "'");
        if (dtAirlineDetailID.Rows.Count > 0)
        {
            airlineDetailId = dtAirlineDetailID.Rows[0]["airline_detail_Id"].ToString();
        }

        string strCheckRate = "select * from agent_rate_master where Airline_Detail_ID = '" + airlineDetailId + "' and  Shipment_ID='" + shipmentId + "' and Destination='" + destination + "' and Origin='" + cityId + "'";
        con.Open();
        SqlDataAdapter daCheck = new SqlDataAdapter(strCheckRate, con);
        DataSet ds = new DataSet();
        daCheck.Fill(ds);
        con.Close();
        //return ds;
        if (ds.Tables[0].Rows.Count > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void addAgentSlabRate()
    {
        using (con)
        {
            try
            {
                //string slabID;
                string insert = "";
                con = new SqlConnection(strCon);
                con.Open();
                trans = con.BeginTransaction();
                if (ddlAirline.SelectedValue.Equals("y"))
                {
                    lblDateError.Text = "Please select Airline";
                }
                else
                {
                    bool ret = compareDate(txtValidFrom.Text, txtValidTo.Text);
                    if (ret == true)
                    {
                        email_Id = Session["EMailID"].ToString();
                        //string newd = ViewState["NEWDATE"].ToString();
                        string agentRateId = "";
                        if (ViewState["AGENT_RATEID"]!= null)
                        {
                            agentRateId = ViewState["AGENT_RATEID"].ToString();
                            string oldValidTo = ViewState["oldValidTo"].ToString();

                            string newValidFrom = txtValidFrom.Text;
                            string newValidTo = txtValidTo.Text;

                            bool checkDate = compareDate(newValidFrom, oldValidTo);
                            if (checkDate == true)
                            {
                                DateTime validF = Convert.ToDateTime(FormatDateDD(newValidFrom));
                                DateTime validPreviousDate = validF.AddDays(-1);
                                string newd = Convert.ToString(validPreviousDate.ToShortDateString());
                                //ViewState["NEWDATE"] = newd;
                                string strUpadteDate = "update agent_rate_master set valid_To = '" + newd + "' where agent_rate_ID = '" + agentRateId + "'";

                                SqlCommand cmdUpdate = new SqlCommand(strUpadteDate, con, trans);
                                cmdUpdate.ExecuteNonQuery();

                            }
                        }

                        insert = "insert into Agent_Rate_Master(Airline_Detail_ID,Shipment_ID,Special_Commodity_ID,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On) values(@Airline_Detail_ID,@Shipment_ID,@Special_Commodity_ID,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

                        SqlCommand com = new SqlCommand(insert, con,trans);
                        com.CommandType = CommandType.Text;
                        DataTable dtAirlineDetailID = dw.GetAllFromQuery("select airline_detail_Id from airline_detail where airline_id = '" + ddlAirline.SelectedValue + "' and belongs_to_city = '" + ddlAirlineCity.SelectedValue + "'");
                        if (dtAirlineDetailID.Rows.Count > 0)
                        {
                            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = dtAirlineDetailID.Rows[0]["airline_detail_Id"].ToString();
                        }
                        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentName.SelectedValue;
                        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScrName.SelectedValue;
                        com.Parameters.Add("@Origin", SqlDbType.Int).Value = ddlAirlineCity.SelectedValue;
                        string strDestination = txtDestination.Text.Trim();
                        strDestination = strDestination.Substring(0, 3);
                        DataTable dtDestination = dw.GetAllFromQuery("select Destination_ID from Destination_Master where Destination_Code='" + strDestination + "'");
                        if (dtDestination.Rows.Count > 0)
                        {
                            com.Parameters.Add("@Destination", SqlDbType.BigInt).Value = dtDestination.Rows[0]["Destination_ID"].ToString();
                        }
                        if (txtFreightSurCharge.Text != "")
                        {
                            com.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
                        }
                        else
                        {
                            com.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
                        }
                        if (txtSecuritySurCharge.Text != "")
                        {
                            com.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
                        }
                        else
                        {
                            com.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
                        }
                        com.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
                        com.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
                        com.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
                        com.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = email_Id;
                        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                        com.ExecuteNonQuery();

                        DataTable dtID;

                        dtID = dw.GetAllFromQuery("select ident_current('Agent_Rate_Master') as ID");
                        string agentRateId1 = "";
                        if (dtID.Rows.Count > 0)
                        {
                            agentRateId1 = dtID.Rows[0]["ID"].ToString();
                            ViewState["agentRateId"] = agentRateId1;
                        }
                        //if (dtID.Rows.Count > 0)
                        //{
                           string insert2;

                            for (int i = 0; i < SlabGrd.Rows.Count; i++)
                            {
                                GridViewRow row = SlabGrd.Rows[i];
                                TextBox txtSlab = (TextBox)row.FindControl("txtSlab");
                                string SlabName = row.Cells[0].Text;

                                DataTable dtSlabID = dw.GetAllFromQuery("select slab_id from slab_master where slab_name='" + SlabName + "'");
                                DataTable dtSlab = (DataTable)ViewState["dtSlab"];
                                insert2 = "insert into Agent_Slab_Rate(Agent_Rate_ID,Airline_Detail_ID,Slab_ID,Price_Value) values(@Rate_ID,@Airline_Detail_ID,@Slab_ID,@Price_Value)";

                                com = new SqlCommand(insert2, con,trans);
                                com.CommandType = CommandType.Text;
                                //if (dtID.Rows.Count > 0)
                                //{
                                //    com.Parameters.Add("@Rate_ID", SqlDbType.BigInt).Value = dtID.Rows[0]["ID"].ToString();
                                //}
                                com.Parameters.Add("@Rate_ID", SqlDbType.BigInt).Value = agentRateId1;
                                DataTable dtAirlineDetailID1 = dw.GetAllFromQuery("select airline_detail_Id from airline_detail where airline_id = '" + ddlAirline.SelectedValue + "' and belongs_to_city = '" + ddlAirlineCity.SelectedValue + "'");
                                if (dtAirlineDetailID1.Rows.Count > 0)
                                {
                                    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = dtAirlineDetailID1.Rows[0]["airline_detail_Id"].ToString();
                                }
                                if (dtSlabID.Rows.Count > 0)
                                {

                                    com.Parameters.Add("@Slab_ID", SqlDbType.Int).Value = dtSlabID.Rows[0]["Slab_ID"].ToString();
                                }
                                if (txtSlab.Text != "")
                                {
                                    com.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value =(txtSlab.Text.Trim() == "" ? 0 : decimal.Parse(txtSlab.Text.Trim())); 
                                    
                                }
                                else
                                {
                                    com.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = 0;
                                }
                                com.ExecuteNonQuery();

                                
                                 
//INSERT INTO AGENT_SLAB_RATE_HISTORY 
                                //GET CURRENT SLAB_RATE_ID 

                                DataTable slabdtID = dw.GetAllFromQuery("select ident_current('Agent_Slab_Rate') as SID");
                                string slabID ="";
                                if (slabdtID.Rows.Count > 0)
                                {
                                    slabID = slabdtID.Rows[0]["SID"].ToString();
                                }
                                string slabHistory = "insert into Agent_Slab_Rate_History(Agent_Slab_ID,Agent_Rate_ID,Airline_Name,City,Slab_Name,Price_Value) values(@Agent_Slab_ID,@Agent_Rate_ID,@Airline_Name,@City,@Slab_Name,@Price_Value)";
                                com = new SqlCommand(slabHistory, con, trans);
                                com.CommandType = CommandType.Text;
                                com.Parameters.Add("@Agent_Slab_ID", SqlDbType.BigInt).Value = slabID;
                                com.Parameters.Add("@Agent_Rate_ID", SqlDbType.BigInt).Value = agentRateId1;
                                com.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = ddlAirline.SelectedItem.Text;
                                com.Parameters.Add("@City", SqlDbType.VarChar).Value = ddlAirlineCity.SelectedItem.Text;
                                com.Parameters.Add("@Slab_Name", SqlDbType.VarChar).Value = SlabName;
                                if (txtSlab.Text != "")
                                {
                                    com.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = (txtSlab.Text.Trim() == "" ? 0 : decimal.Parse(txtSlab.Text.Trim())); 
                                }
                                else
                                {
                                    com.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = 0;
                                }
                                com.ExecuteNonQuery();
                            }
                        //}
                        //*************** Inserting Data in Agent_Rate_Master_History Table***************
                        string insert3;
                        insert3 = "insert into Agent_Rate_Master_History(Agent_Rate_ID,Airline_Name,Shipment_Name,Special_Commodity_Name,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On)values(@Agent_Rate_ID,@Airline_Name,@Shipment_Name,@Special_Commodity_Name,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

                        com = new SqlCommand(insert3, con,trans);
                        com.CommandType = CommandType.Text;
                        com.Parameters.Add("@Agent_Rate_ID", SqlDbType.Int).Value = ViewState["agentRateId"].ToString();
                        com.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = ddlAirline.SelectedItem.Text;
                        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentName.SelectedItem.Text;
                        com.Parameters.Add("@Special_Commodity_Name", SqlDbType.VarChar).Value = ddlScrName.SelectedItem.Text;
                        com.Parameters.Add("@Origin", SqlDbType.VarChar).Value = ddlAirlineCity.SelectedItem.Text;
                        string strDes = txtDestination.Text.Trim();
                        strDes = strDes.Substring(0, 3);
                        DataTable dtDes = dw.GetAllFromQuery("select Destination_Name from Destination_Master where Destination_Code='" + strDes + "'");
                        if (dtDes.Rows.Count > 0)
                        {
                            com.Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtDes.Rows[0]["Destination_Name"].ToString();
                        }
                        if (txtFreightSurCharge.Text != "")
                        {
                            com.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
                        }
                        else
                        {
                            com.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
                        }
                        if (txtSecuritySurCharge.Text != "")
                        {
                            com.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
                        }
                        else
                        {
                            com.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
                        }
                        com.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
                        com.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
                        com.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
                        com.Parameters.Add("@Status", SqlDbType.VarChar).Value = ddlStatus.SelectedItem.Text;
                        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = email_Id;
                        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

                        com.ExecuteNonQuery();
                        trans.Commit();
                        Response.Redirect("agent_Rate_MasterDetails.aspx");
                    }
                    else
                    {
                        lblDateError.Text = "ValidFrom date should not be greater than ValidTo date";
                    }
                }
                con.Close();
            }
            catch (SqlException sqe)
            {
                lblDateError.Text = "sql error" + sqe.Message;
                trans.Rollback();
            }
            finally
            {
                con.Close();
            }
        }
    }

    public void insertAgentRate()
    {
        string DBvalidF = "";
        string DBvalidT = "";
        string agentRateId = "";
        string strFindRate = "";
        con = new SqlConnection(strCon);
        string airlineDetailId = "";
        string destination = "";
        string strInsert = "";
        string strHist = "";
        string email_Id = "";
    // GET AIRLINE_DETAIL_ID
        email_Id = Session["EMailID"].ToString();
        DataTable dtAirlineDetailID = dw.GetAllFromQuery("select airline_detail_Id from airline_detail where airline_detail_Id = '" + ddlAirline.SelectedValue + "' and belongs_to_city = '" + ddlAirlineCity.SelectedValue + "'");
        if (dtAirlineDetailID.Rows.Count > 0)
        {
            airlineDetailId = dtAirlineDetailID.Rows[0]["airline_detail_Id"].ToString();
            ViewState["ADID"] = airlineDetailId;
        }

    // GET DESTINATION_ID
        string strDestination = txtDestination.Text.Trim();
        strDestination = strDestination.Substring(0, 3);
        DataTable dtDestination = dw.GetAllFromQuery("select Destination_ID from Destination_Master where Destination_Code='" + strDestination + "'");
        if (dtDestination.Rows.Count > 0)
        {
            destination = dtDestination.Rows[0]["Destination_ID"].ToString();
        }

        string fdate = FormatDateMM(txtValidFrom.Text);
        string tdate = FormatDateMM(txtValidTo.Text);
        string strDel = "";
        try
        {
            con.Open();
            trans = con.BeginTransaction();
        // QUERY FOR GET RECORD BASED ON VALID_FROM DATE i.e. 
            strFindRate = "select * from Agent_Rate_Master where Airline_Detail_ID = '" + airlineDetailId + "' and  Shipment_ID='" + ddlShipmentName.SelectedValue + "' and Destination='" + destination + "' and Origin='" + ddlAirlineCity.SelectedValue + "' and valid_from <= '" + fdate + "' and valid_to >= '" + fdate + "' ";
            //con.Open();
            cmd = new SqlCommand(strFindRate, con, trans);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            //cmd.Dispose();
            if (dr.Read())
            {
                
                agentRateId = dr["Agent_Rate_ID"].ToString();
                DBvalidF = Convert.ToDateTime(dr["valid_from"]).ToString("DD/MM/YYYY");
                DBvalidT = Convert.ToDateTime(dr["valid_to"]).ToString("DD/MM/YYYY");

        //CONDITION 1 ::: --- > GIVEN FROM DATE IS EQUAL TO VALID_FROM DATE AND VALID_TO & VALID_FROM DATE IS EQUAL IN DB 
                if ((Convert.ToDateTime(dr["valid_from"].ToString()) == Convert.ToDateTime(fdate)) && (Convert.ToDateTime(dr["valid_from"].ToString()) == Convert.ToDateTime(dr["valid_to"].ToString())))
                {
                    dr.Close();
                    cmd.Dispose();

        // MAINTAIN IN HISTORY 
                    
        //DELETE RECORD
                    //1. DELETE FROM AGENT_SLAB_RATE 
                    string agentID = "";
                    string strGetID = "select agent_rate_ID from Agent_Rate_Master where Airline_Detail_ID = '" + airlineDetailId + "' and  Shipment_ID='" + ddlShipmentName.SelectedValue + "' and Destination='" + destination + "' and Origin='" + ddlAirlineCity.SelectedValue + "' and valid_from >= '" + fdate + "'";
                    SqlDataReader drID;
                    SqlCommand cmdID = new SqlCommand(strGetID, con, trans);
                    drID = cmdID.ExecuteReader();

                    while (drID.Read())
                    {
                        //drID.Read();
                        agentID = agentID + drID["agent_rate_id"].ToString() + ",";
                        
                    }
                    drID.Close();
                    cmdID.Dispose();
                    //int len = agentID.
                    string[] strArrey = agentID.Split(',');
                    for(int i=0; i<strArrey.Length; i++)
                    {
                        string id = strArrey[i];
                        if (id != "")
                        {
                            SqlCommand cmdDelete = new SqlCommand();
                            strDel = "delete from Agent_Slab_Rate where agent_rate_id = '" + id + "'";
                            cmdDelete = new SqlCommand(strDel, con, trans);
                            cmdDelete.ExecuteNonQuery();
                            cmdDelete.Dispose();

                            //2. DELETE FROM AGENT_SLAB_RATE
                            strDel = "delete from agent_rate_master where agent_rate_id = '" + id + "'";
                            cmdDelete = new SqlCommand(strDel, con, trans);
                            cmdDelete.ExecuteNonQuery();
                            cmdDelete.Dispose();
                        }
                    }
                        // INSERT INTO AGENT_RATE_MASTER 
                        strInsert = "insert into Agent_Rate_Master(Airline_Detail_ID,Shipment_ID,Special_Commodity_ID,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On) values(@Airline_Detail_ID,@Shipment_ID,@Special_Commodity_ID,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

                    cmd = new SqlCommand(strInsert, con, trans);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = airlineDetailId;
                    cmd.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentName.SelectedValue;
                    cmd.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScrName.SelectedValue;
                    cmd.Parameters.Add("@Origin", SqlDbType.Int).Value = ddlAirlineCity.SelectedValue;
                    //string strDestination = txtDestination.Text.Trim();
                    //strDestination = strDestination.Substring(0, 3);
                    cmd.Parameters.Add("@Destination", SqlDbType.BigInt).Value = destination;
                    if (txtFreightSurCharge.Text != "")
                    {
                        cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
                    }
                    if (txtSecuritySurCharge.Text != "")
                    {
                        cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
                    }
                    else
                    {
                        cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
                    }
                    cmd.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
                    cmd.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
                    cmd.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
                    cmd.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                    cmd.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = email_Id;
                    cmd.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                else if ((Convert.ToDateTime(dr["Valid_From"].ToString()) == Convert.ToDateTime(fdate)) || (Convert.ToDateTime(dr["Valid_From"].ToString()) == Convert.ToDateTime(dr["Valid_To"].ToString())))
                {
                    dr.Close();
                    cmd.Dispose();

                    // MAINTAIN IN HISTORY 

                    //DELETE RECORD

                    string agentID = "";
                    string strGetID = "select agent_rate_ID from Agent_Rate_Master where Airline_Detail_ID = '" + airlineDetailId + "' and  Shipment_ID='" + ddlShipmentName.SelectedValue + "' and Destination='" + destination + "' and Origin='" + ddlAirlineCity.SelectedValue + "' and valid_from >= '" + fdate + "'";
                    SqlDataReader drID;
                    SqlCommand cmdID = new SqlCommand(strGetID, con, trans);
                    drID = cmdID.ExecuteReader();
                    while (drID.Read())
                    {
                        //drID.Read();
                        agentID = agentID + drID["agent_rate_id"].ToString() + ",";

                    }
                    drID.Close();
                    cmdID.Dispose();
                    string[] strArrey = agentID.Split(',');
                    for (int i = 0; i < strArrey.Length; i++)
                    {
                        string id = strArrey[i];
                        if (id != "")
                        {
                            SqlCommand cmdDelete = new SqlCommand();
                            strDel = "delete from Agent_Slab_Rate where agent_rate_id = '" + id + "'";
                            cmdDelete = new SqlCommand(strDel, con, trans);
                            cmdDelete.ExecuteNonQuery();
                            cmdDelete.Dispose();

                            //2. DELETE FROM AGENT_SLAB_RATE
                            strDel = "delete from agent_rate_master where agent_rate_id = '" + id + "'";
                            cmdDelete = new SqlCommand(strDel, con, trans);
                            cmdDelete.ExecuteNonQuery();
                            cmdDelete.Dispose();
                        }
                    }

                    // INSERT INTO AGENT_RATE_MASTER 
                    strInsert = "insert into Agent_Rate_Master(Airline_Detail_ID,Shipment_ID,Special_Commodity_ID,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On) values(@Airline_Detail_ID,@Shipment_ID,@Special_Commodity_ID,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

                    cmd = new SqlCommand(strInsert, con, trans);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = airlineDetailId;
                    cmd.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentName.SelectedValue;
                    cmd.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScrName.SelectedValue;
                    cmd.Parameters.Add("@Origin", SqlDbType.Int).Value = ddlAirlineCity.SelectedValue;
                    //string strDestination = txtDestination.Text.Trim();
                    //strDestination = strDestination.Substring(0, 3);
                    cmd.Parameters.Add("@Destination", SqlDbType.BigInt).Value = destination;
                    if (txtFreightSurCharge.Text != "")
                    {
                        cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
                    }
                    if (txtSecuritySurCharge.Text != "")
                    {
                        cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
                    }
                    else
                    {
                        cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
                    }
                    cmd.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
                    cmd.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
                    cmd.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
                    cmd.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                    cmd.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = email_Id;
                    cmd.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                else
                {
                    dr.Close();
                    cmd.Dispose();
                    DateTime validFd = Convert.ToDateTime(FormatDateDD(txtValidFrom.Text));
                    DateTime validPreviousDate = validFd.AddDays(-1);
                    string newd = Convert.ToString(validPreviousDate.ToShortDateString());
                    string sUpdate = "UPDATE agent_rate_master set valid_to='" + newd + "' where agent_rate_id = '" + agentRateId + "'";
                    cmd = new SqlCommand(sUpdate, con, trans);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();

                    string agentID = "";
                    string strGetID = "select agent_rate_ID from Agent_Rate_Master where Airline_Detail_ID = '" + airlineDetailId + "' and  Shipment_ID='" + ddlShipmentName.SelectedValue + "' and Destination='" + destination + "' and Origin='" + ddlAirlineCity.SelectedValue + "' and valid_from >= '" + fdate + "'";
                    SqlDataReader drID;
                    SqlCommand cmdID = new SqlCommand(strGetID, con, trans);
                    drID = cmdID.ExecuteReader();
                    while (drID.Read())
                    {
                        //drID.Read();
                        agentID = agentID + drID["agent_rate_id"].ToString() + ",";

                    }
                    drID.Close();
                    cmdID.Dispose();
                    string[] strArrey = agentID.Split(',');
                    for (int i = 0; i < strArrey.Length; i++)
                    {
                        string id = strArrey[i];
                        if (id != "")
                        {
                            SqlCommand cmdDelete = new SqlCommand();
                            strDel = "delete from Agent_Slab_Rate where agent_rate_id = '" + id + "'";
                            cmdDelete = new SqlCommand(strDel, con, trans);
                            cmdDelete.ExecuteNonQuery();
                            cmdDelete.Dispose();

                            //2. DELETE FROM AGENT_SLAB_RATE
                            strDel = "delete from agent_rate_master where agent_rate_id = '" + id + "'";
                            cmdDelete = new SqlCommand(strDel, con, trans);
                            cmdDelete.ExecuteNonQuery();
                            cmdDelete.Dispose();
                        }
                    }
                   
                    strInsert = "insert into Agent_Rate_Master(Airline_Detail_ID,Shipment_ID,Special_Commodity_ID,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On) values(@Airline_Detail_ID,@Shipment_ID,@Special_Commodity_ID,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

                    cmd = new SqlCommand(strInsert, con, trans);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = airlineDetailId;
                    cmd.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentName.SelectedValue;
                    cmd.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScrName.SelectedValue;
                    cmd.Parameters.Add("@Origin", SqlDbType.Int).Value = ddlAirlineCity.SelectedValue;
                    //string strDestination = txtDestination.Text.Trim();
                    //strDestination = strDestination.Substring(0, 3);
                    cmd.Parameters.Add("@Destination", SqlDbType.BigInt).Value = destination;
                    if (txtFreightSurCharge.Text != "")
                    {
                        cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
                    }
                    if (txtSecuritySurCharge.Text != "")
                    {
                        cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
                    }
                    else
                    {
                        cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
                    }
                    cmd.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
                    cmd.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
                    cmd.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
                    cmd.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                    cmd.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = email_Id;
                    cmd.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();

                }
            }
            else
            {
                //INSERT RECORD INTO DATABASE SIMPLE 
                dr.Close();
                cmd.Dispose();

                string agentID = "";
                string strGetID = "select agent_rate_ID from Agent_Rate_Master where Airline_Detail_ID = '" + airlineDetailId + "' and  Shipment_ID='" + ddlShipmentName.SelectedValue + "' and Destination='" + destination + "' and Origin='" + ddlAirlineCity.SelectedValue + "' and valid_from >= '" + fdate + "'";
                SqlDataReader drID;
                SqlCommand cmdID = new SqlCommand(strGetID, con, trans);
                drID = cmdID.ExecuteReader();
                while (drID.Read())
                {
                    //drID.Read();
                    agentID = agentID + drID["agent_rate_id"].ToString() + ",";

                }
                drID.Close();
                cmdID.Dispose();
                string[] strArrey = agentID.Split(',');
                for (int i = 0; i < strArrey.Length; i++)
                {
                    string id = strArrey[i];
                    if (id != "")
                    {
                        SqlCommand cmdDelete = new SqlCommand();
                        strDel = "delete from Agent_Slab_Rate where agent_rate_id = '" + id + "'";
                        cmdDelete = new SqlCommand(strDel, con, trans);
                        cmdDelete.ExecuteNonQuery();
                        cmdDelete.Dispose();

                        //2. DELETE FROM AGENT_SLAB_RATE
                        strDel = "delete from agent_rate_master where agent_rate_id = '" + id + "'";
                        cmdDelete = new SqlCommand(strDel, con, trans);
                        cmdDelete.ExecuteNonQuery();
                        cmdDelete.Dispose();
                    }
                }
               
                strInsert = "insert into Agent_Rate_Master(Airline_Detail_ID,Shipment_ID,Special_Commodity_ID,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On) values(@Airline_Detail_ID,@Shipment_ID,@Special_Commodity_ID,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

                cmd = new SqlCommand(strInsert, con, trans);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = ddlAirline.SelectedItem.Value;
                cmd.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentName.SelectedValue;
                cmd.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScrName.SelectedValue;
                cmd.Parameters.Add("@Origin", SqlDbType.Int).Value = ddlAirlineCity.SelectedValue;
                //string strDestination = txtDestination.Text.Trim();
                //strDestination = strDestination.Substring(0, 3);
                cmd.Parameters.Add("@Destination", SqlDbType.BigInt).Value = destination;
                if (txtFreightSurCharge.Text != "")
                {
                    cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
                }
                else
                {
                    cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
                }
                if (txtSecuritySurCharge.Text != "")
                {
                    cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
                }
                else
                {
                    cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
                }
                cmd.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
                cmd.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
                cmd.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
                cmd.Parameters.Add("@Status", SqlDbType.Int).Value = ddlStatus.SelectedValue;
                cmd.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = email_Id;
                cmd.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }

    //NOW ENTER INTO AGENT_SLAB_RATE
            DataTable dtID;

            dtID = dw.GetAllFromQuery("select ident_current('Agent_Rate_Master') as ID");
            string agentRateId1 = "";
            if (dtID.Rows.Count > 0)
            {
                agentRateId1 = dtID.Rows[0]["ID"].ToString();
                ViewState["agentRateId"] = agentRateId1;
            }

            string insert2;

            for (int i = 0; i < SlabGrd.Rows.Count; i++)
            {
                GridViewRow row = SlabGrd.Rows[i];
                TextBox txtSlab = (TextBox)row.FindControl("txtSlab");
                string SlabName = row.Cells[0].Text;

                DataTable dtSlabID = dw.GetAllFromQuery("select slab_id from slab_master where slab_name='" + SlabName + "'");
                DataTable dtSlab = (DataTable)ViewState["dtSlab"];
                insert2 = "insert into Agent_Slab_Rate(Agent_Rate_ID,Airline_Detail_ID,Slab_ID,Price_Value) values(@Rate_ID,@Airline_Detail_ID,@Slab_ID,@Price_Value)";

                cmd = new SqlCommand(insert2, con, trans);
                cmd.CommandType = CommandType.Text;
                //if (dtID.Rows.Count > 0)
                //{
                //    com.Parameters.Add("@Rate_ID", SqlDbType.BigInt).Value = dtID.Rows[0]["ID"].ToString();
                //}
                cmd.Parameters.Add("@Rate_ID", SqlDbType.BigInt).Value = agentRateId1;
                cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = ddlAirline.SelectedValue;  
                //DataTable dtAirlineDetailID1 = dw.GetAllFromQuery("select airline_detail_Id from airline_detail where airline_id = '" + ddlAirline.SelectedValue + "' and belongs_to_city = '" + ddlAirlineCity.SelectedValue + "'");
                //if (dtAirlineDetailID1.Rows.Count > 0)
                //{
                //    cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = dtAirlineDetailID1.Rows[0]["airline_detail_Id"].ToString();
                //}
                if (dtSlabID.Rows.Count > 0)
                {

                    cmd.Parameters.Add("@Slab_ID", SqlDbType.Int).Value = dtSlabID.Rows[0]["Slab_ID"].ToString();
                }
                if (txtSlab.Text != "")
                {
                    cmd.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = (txtSlab.Text.Trim() == "" ? 0 : decimal.Parse(txtSlab.Text.Trim())); 
                }
                else
                {
                    cmd.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = 0;
                }
                cmd.ExecuteNonQuery();

                //INSERT INTO AGENT_SLAB_RATE_HISTORY 
                //GET CURRENT SLAB_RATE_ID 

                DataTable slabdtID = dw.GetAllFromQuery("select ident_current('Agent_Slab_Rate') as SID");
                string slabID = "";
                if (slabdtID.Rows.Count > 0)
                {
                    slabID = slabdtID.Rows[0]["SID"].ToString();
                }
                string slabHistory = "insert into Agent_Slab_Rate_History(Agent_Slab_ID,Agent_Rate_ID,Airline_Name,City,Slab_Name,Price_Value) values(@Agent_Slab_ID,@Agent_Rate_ID,@Airline_Name,@City,@Slab_Name,@Price_Value)";
                cmd = new SqlCommand(slabHistory, con, trans);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@Agent_Slab_ID", SqlDbType.BigInt).Value = slabID;
                cmd.Parameters.Add("@Agent_Rate_ID", SqlDbType.BigInt).Value = agentRateId1;
                cmd.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = ddlAirline.SelectedItem.Text;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = ddlAirlineCity.SelectedItem.Text;
                cmd.Parameters.Add("@Slab_Name", SqlDbType.VarChar).Value = SlabName;
                if (txtSlab.Text != "")
                {
                    cmd.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = (txtSlab.Text.Trim() == "" ? 0 : decimal.Parse(txtSlab.Text.Trim())); 
                }
                else
                {
                    cmd.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = 0;
                }
                cmd.ExecuteNonQuery();
            }

            //*************** Inserting Data in Agent_Rate_Master_History Table***************
            string insert3;
            insert3 = "insert into Agent_Rate_Master_History(Agent_Rate_ID,Airline_Name,Shipment_Name,Special_Commodity_Name,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On)values(@Agent_Rate_ID,@Airline_Name,@Shipment_Name,@Special_Commodity_Name,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

            cmd = new SqlCommand(insert3, con, trans);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@Agent_Rate_ID", SqlDbType.Int).Value = ViewState["agentRateId"].ToString();
            cmd.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = ddlAirline.SelectedItem.Text;
            cmd.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentName.SelectedItem.Text;
            cmd.Parameters.Add("@Special_Commodity_Name", SqlDbType.VarChar).Value = ddlScrName.SelectedItem.Text;
            cmd.Parameters.Add("@Origin", SqlDbType.VarChar).Value = ddlAirlineCity.SelectedItem.Text;
            string strDes = txtDestination.Text.Trim();
            strDes = strDes.Substring(0, 3);
            DataTable dtDes = dw.GetAllFromQuery("select Destination_Name from Destination_Master where Destination_Code='" + strDes + "'");
            if (dtDes.Rows.Count > 0)
            {
                cmd.Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtDes.Rows[0]["Destination_Name"].ToString();
            }
            if (txtFreightSurCharge.Text != "")
            {
                cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
            }
            else
            {
                cmd.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
            }
            if (txtSecuritySurCharge.Text != "")
            {
                cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
            }
            else
            {
                cmd.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
            }
            cmd.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
            cmd.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
            cmd.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = ddlStatus.SelectedItem.Text;
            cmd.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = email_Id;
            cmd.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

            cmd.ExecuteNonQuery();
            trans.Commit();
            Response.Redirect("agent_Rate_MasterDetails.aspx");
        }
        catch(SqlException sqe)
        {
            lblDateError.Text = "sql error" + sqe.Message;
            trans.Rollback();
            con.Close();
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //CHECK DATE i.e. VALID_FROM DATE SHOULD BE EQUAL OR GREATER THAN CURRENT DATE
        DateTime dt = DateTime.Now;
        string vfdate = txtValidFrom.Text;
        string vtdate = txtValidTo.Text;
        string curDate = FormatDateMM(Convert.ToString(dt.ToShortDateString()));
        bool ret = compareCurDate(vfdate, curDate);
        lblDateError.Visible = false;
        if(ret == true)
        {
    //CHECK VALID_TO DATE SHOULD BE EQUAL OR GREATER THAN VALID_FROM DATE 
            bool val = compareDate(vfdate, vtdate);
            if (val == true)
            {
                insertAgentRate();
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "Valid_To date should be equal or greater than Valid_From date.";
            }
        }
        else
        {
            lblDateError.Visible = true;
            lblDateError.Text = "Valid_From date should be equal or greater than current date.";
        }
    }

    //*******************Clearing All the Fields***********************
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect("agent_rate_masterDetails.aspx");
        
    }

    //*******************Filling Airline Dropdownlist************************
    public void AirlineNamePlusCode()
    {
        //try
        //{
        //    string strQuery = "";
        //    strQuery = "Select Airline_Detail_ID,Airline_ID,Belongs_To_City from Airline_Detail";
        //    con = new SqlConnection(strCon);
        //    con.Open();
        //    SqlCommand com = new SqlCommand(strQuery, con);
        //    SqlDataReader dr = com.ExecuteReader();
        //    ddlAirline.Items.Insert(0, "- - Select - -");
        //    ddlAirline.Items[0].Value = "0";
        //    while (dr.Read())
        //    {
        //        DataTable dtAirlineName = dw.GetAllFromQuery(" select Airline_Name from Airline_Master where Airline_ID=" + dr["Airline_ID"].ToString());
        //        DataTable dtCity = dw.GetAllFromQuery("select City_Name from City_Master where City_ID=" + dr["Belongs_To_City"].ToString());
        //        ddlAirline.Items.Add(new ListItem(dtAirlineName.Rows[0]["Airline_Name"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString(), dr["Airline_Detail_ID"].ToString()));
        //    }
        //    con.Close();
        //}
        //catch (SqlException sqe)
        //{
        //    string err = sqe.ToString();
        //}
        //finally
        //{
        //    if (con != null && con.State == ConnectionState.Open)
        //        con.Close();
        //}
    }

    //*************************Filling Destination TextBox with javascript******************
    public string TxtDestinationPlusCode()
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT Destination_ID,Destination_Code,Destination_Name FROM Destination_Master";
            SqlCommand com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";// +" "+ Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";//+ " " +Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }

    //********************* Filling the ShipmentName Dropdownlist *******************
    public void ddlShipmentNameFill()
    {
        try
        {
            string strQuery = "";
            strQuery = "Select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlShipmentName.Items.Insert(0, "- - Select - -");
            //ddlShipmentName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlShipmentName.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            string shipment = "Normal";
            ddlShipmentName.SelectedIndex = ddlShipmentName.Items.IndexOf(ddlShipmentName.Items.FindByText(shipment));
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    //*********************Filling the ScrName Drpdownlist***********************
    public void ddlScrNameFill()
    {
        try
        {
            string strQuery = "";
            strQuery = "Select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
          
            while (dr.Read())
            {
                ddlScrName.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            string commodity = "General";
            ddlScrName.SelectedIndex = ddlScrName.Items.IndexOf(ddlScrName.Items.FindByText(commodity));
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void ddlAirline_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAirline.SelectedValue.Equals("y"))
        {
            //lblDateError.Text = "Please select Airline";
            ddlAirlineCity.Items.Clear();
            ddlAirlineCity.Items.Add(new ListItem("--Select--", "y"));
            btnAdd.Enabled = false;
        }
        else
        {
            btnAdd.Enabled = true;
            airlineCity();
        }
        //*************Retreiving the City ID from Airline Dropdownlist ***********************************
        //int AirlineDetailID = Convert.ToInt32(ddlAirline.SelectedValue);
        //DataTable dtCityID = dw.GetAllFromQuery("select Belongs_To_City from Airline_Detail where Airline_Detail_ID=" + AirlineDetailID);
        //if (dtCityID.Rows.Count > 0)
        //{
        //    ViewState["CityID"] = dtCityID.Rows[0]["Belongs_To_City"].ToString();
        //}
        //Visibility();
        ////FillOrigin();
    }

    //public void FillOrigin()
    //{
    //    DataTable dtCity1;
    //    DataTable dtCity2;
    //    string str = "";
    //    dtCity1 = dw.GetAllFromQuery("select Belongs_To_City from  Airline_Detail where Airline_ID=" + ddlAirline.SelectedValue);
    //    if (dtCity1.Rows.Count > 0)
    //    {
    //        for (int k = 0; k < dtCity1.Rows.Count; k++)
    //        {
    //            str = str + dtCity1.Rows[k]["Belongs_To_City"].ToString() + ",";
    //        }
    //        str = str.Remove(str.LastIndexOf(','));
    //        dtCity2 = dw.GetAllFromQuery("select City_ID,City_Code,City_Name from City_Master where City_ID in(" + str + ")");
    //        for (int i = 0; i < dtCity2.Rows.Count; i++)
    //        {
    //            ddlOrigin.Items.Add(new ListItem(dtCity2.Rows[i]["City_Code"].ToString() + "-" + (dtCity2.Rows[i]["City_Name"].ToString()), dtCity2.Rows[i]["City_ID"].ToString()));
    //        }
    //        Visibility();
    //        // ddlOrigin.Enabled = false;
    //    }
    //}
    //**************** Showing the Data After Modifying*********************

    public void selectData()
    {

        con = new SqlConnection(strCon);
        con.Open();

        if (Request.QueryString["Agent_Rate_ID"] != null)
        {
            string RateID = Convert.ToString(Request.QueryString["Agent_Rate_ID"]);
            DataTable dtRate = new DataTable();
            dtRate = dw.GetAllFromQuery("select * from Agent_Rate_Master A inner join Airline_Detail AD on A.airline_detail_Id = AD.Airline_Detail_ID where Agent_Rate_ID=" + RateID);
            if (dtRate.Rows.Count > 0)
            {
                ddlAirline.SelectedValue = dtRate.Rows[0]["Airline_ID"].ToString();
                airlineCity();
                
                ddlAirlineCity.SelectedValue = dtRate.Rows[0]["Origin"].ToString();
                fillSlabGrid();
                ddlShipmentName.SelectedValue = dtRate.Rows[0]["Shipment_ID"].ToString();
                ddlScrName.SelectedValue = dtRate.Rows[0]["Special_Commodity_ID"].ToString();
                
                string strDestinationID = dtRate.Rows[0]["Destination"].ToString();
                DataTable dtDestination = dw.GetAllFromQuery("select Destination_Code,Destination_Name from Destination_Master where Destination_ID=" + strDestinationID);
                if (dtDestination.Rows.Count > 0)
                {
                    txtDestination.Text = dtDestination.Rows[0]["Destination_Code"].ToString() + "-" + dtDestination.Rows[0]["Destination_Name"].ToString();
                }
                string fuelCharge = dtRate.Rows[0]["Freight_SurCharge"].ToString();
                decimal fuelChargevalue = decimal.Parse(fuelCharge);

                string security = dtRate.Rows[0]["Security_SurCharge"].ToString();
                decimal securityvalue = decimal.Parse(security);

                string Xray = dtRate.Rows[0]["XRay_Charges"].ToString();
                decimal Xrayvalue = decimal.Parse(Xray);

                txtFreightSurCharge.Text = fuelChargevalue.ToString();
                txtSecuritySurCharge.Text = securityvalue.ToString();
                txtXRayCharges.Text = Xrayvalue.ToString();

                txtValidFrom.Text = FormatDateMM(((DateTime)dtRate.Rows[0]["Valid_From"]).ToShortDateString());
                txtValidTo.Text = FormatDateMM(((DateTime)dtRate.Rows[0]["Valid_To"]).ToShortDateString());
                ddlStatus.SelectedValue = dtRate.Rows[0]["Status"].ToString();

            }


            //*****************Showing Data in the Slab Grid********************************
            for (int i = 0; i < SlabGrd.Rows.Count; i++)
            {
                GridViewRow row = SlabGrd.Rows[i];

                TextBox txtSlab = (TextBox)row.FindControl("txtSlab");
                string SlabName = row.Cells[0].Text;
                DataTable dtID = dw.GetAllFromQuery("select Slab_ID from Slab_Master where Slab_Name='" + SlabName + "'");
                DataTable dtSlabID = dw.GetAllFromQuery("select Price_Value from Agent_Slab_Rate where Slab_ID='" + dtID.Rows[0]["Slab_ID"].ToString() + "'  and Agent_Rate_ID=" + RateID);
                if (dtSlabID.Rows.Count > 0)
                {
                    string price = dtSlabID.Rows[0]["Price_Value"].ToString();
                    decimal pvalue = decimal.Parse(price);
                    txtSlab.Text = pvalue.ToString();
                }
            }
        }
    }
    
    //FUNCTION FOR UPDATE AGENT RATE

    public void updateAgentRate()
    {
        using (con)
        {
            try
            {
                string strUpdateRate = "";
                string rateId = "";
                con = new SqlConnection(strCon);
                con.Open();
                trans = con.BeginTransaction();
                SqlCommand cmdUpdateRate;

                rateId = Request.QueryString["Agent_Rate_ID"].ToString();
                string emailId = Session["EMailID"].ToString();
                string fuel = txtFreightSurCharge.Text;
                string security = txtSecuritySurCharge.Text;
                string Xray = txtXRayCharges.Text;
                string airDetailId = ddlAirline.SelectedItem.Value;
                string status = ddlStatus.SelectedValue;
                //string airline = ddlAirline.SelectedValue;

//UPDATE AGENT_RATE_MASTER  

                strUpdateRate = "update Agent_Rate_Master set Freight_SurCharge = '" + fuel + "',Security_SurCharge = '" + security + "',XRay_Charges='" + Xray + "', status = '"+ status +"' where Agent_Rate_ID = '" + rateId + "'";

                cmdUpdateRate = new SqlCommand(strUpdateRate, con, trans);
                cmdUpdateRate.CommandType = CommandType.Text;

                cmdUpdateRate.ExecuteNonQuery();

//INSERT INTO AGENT_RATE_MASTER_HISTORY 

                strUpdateRate = "insert into Agent_Rate_Master_History(Agent_Rate_ID,Airline_Name,Shipment_Name,Special_Commodity_Name,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On)values(@Agent_Rate_ID,@Airline_Name,@Shipment_Name,@Special_Commodity_Name,@Origin,@Destination,@Freight_SurCharge,@Security_SurCharge,@XRay_Charges,@Valid_From,@Valid_To,@Status,@Entered_By,@Entered_On)";

                cmdUpdateRate = new SqlCommand(strUpdateRate, con, trans);
                cmdUpdateRate.CommandType = CommandType.Text;
                cmdUpdateRate.Parameters.Add("@Agent_Rate_ID", SqlDbType.Int).Value = rateId;
                cmdUpdateRate.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = ddlAirline.SelectedItem.Text;
                cmdUpdateRate.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentName.SelectedItem.Text;
                cmdUpdateRate.Parameters.Add("@Special_Commodity_Name", SqlDbType.VarChar).Value = ddlScrName.SelectedItem.Text;
                cmdUpdateRate.Parameters.Add("@Origin", SqlDbType.VarChar).Value = ddlAirlineCity.SelectedItem.Text;
                string strDes = txtDestination.Text.Trim();
                strDes = strDes.Substring(0, 3);
                DataTable dtDes = dw.GetAllFromQuery("select Destination_Name from Destination_Master where Destination_Code='" + strDes + "'");
                if (dtDes.Rows.Count > 0)
                {
                    cmdUpdateRate.Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtDes.Rows[0]["Destination_Name"].ToString();
                }
                if (txtFreightSurCharge.Text != "")
                {
                    cmdUpdateRate.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = txtFreightSurCharge.Text.Trim();
                }
                else
                {
                    cmdUpdateRate.Parameters.AddWithValue("@Freight_SurCharge", SqlDbType.Decimal).Value = 0;
                }
                if (txtSecuritySurCharge.Text != "")
                {
                    cmdUpdateRate.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = txtSecuritySurCharge.Text.Trim();
                }
                else
                {
                    cmdUpdateRate.Parameters.Add("@Security_SurCharge", SqlDbType.Decimal).Value = 0;
                }
                cmdUpdateRate.Parameters.Add("@XRay_Charges", SqlDbType.Decimal).Value = txtXRayCharges.Text.Trim();
                cmdUpdateRate.Parameters.Add("@Valid_From", SqlDbType.DateTime).Value = FormatDateDD(txtValidFrom.Text);
                cmdUpdateRate.Parameters.Add("@Valid_To", SqlDbType.DateTime).Value = FormatDateDD(txtValidTo.Text);
                cmdUpdateRate.Parameters.Add("@Status", SqlDbType.VarChar).Value = ddlStatus.SelectedItem.Text;
                cmdUpdateRate.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = emailId;
                cmdUpdateRate.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

                cmdUpdateRate.ExecuteNonQuery();

    //UPDATE AGENT_SLAB_RATE 

                for (int i = 0; i < SlabGrd.Rows.Count; i++)
                {
                    GridViewRow row = SlabGrd.Rows[i];
                    TextBox txtSlab = (TextBox)row.FindControl("txtSlab");
                    string SlabName = row.Cells[0].Text;

                // GET SLAB_ID
                    DataTable dtSlabId = dw.GetAllFromQuery("select slab_id from slab_master where slab_name='" + SlabName + "'");
                    string slabId = "";
                    if (dtSlabId.Rows.Count > 0)
                    {
                        slabId = dtSlabId.Rows[0]["slab_id"].ToString();
                    }

                // GET AGENT_SLAB_ID
                    string agentslabId = "";
                    string str = "select Agent_Slab_ID from Agent_Slab_Rate where Agent_Rate_ID='" + rateId + "' and Airline_Detail_ID='" + airDetailId + "' and Slab_ID ='" + slabId + "'";
                    SqlCommand com = new SqlCommand(str, con,trans);
                    SqlDataReader dr;
                    dr = com.ExecuteReader();
                    if(dr.Read())
                    {
                        agentslabId = dr["Agent_Slab_ID"].ToString();
                    }
                    dr.Close();

                //UPDATE TABLE
                    string price = "0";
                    if(txtSlab.Text == "")
                    {
                        price = "0";
                    }
                    else
                    {
                        price = txtSlab.Text;
                    }

             // IF SLAB_ID NOT EXIST INTO AGENT_SLAB_RATE THEN 
                    if (agentslabId == "")
                    {
                        string pr = "0";
                        if (txtSlab.Text != "")
                        {
                            pr = txtSlab.Text;
                        }
                        else
                        {
                            pr = "0";
                        }
                        strUpdateRate = "insert into Agent_Slab_Rate(Agent_Rate_ID,Airline_Detail_ID,Slab_ID,Price_Value) values('" + rateId + "','" + airDetailId + "','" + slabId + "','" + pr + "')";
                        cmdUpdateRate = new SqlCommand(strUpdateRate, con, trans);
                        cmdUpdateRate.CommandType = CommandType.Text;

                        cmdUpdateRate.ExecuteNonQuery();

                        DataTable slabdtID = dw.GetAllFromQuery("select ident_current('Agent_Slab_Rate') as SID");
                        string slabID1 = "";
                        if (slabdtID.Rows.Count > 0)
                        {
                            slabID1 = slabdtID.Rows[0]["SID"].ToString();
                        }

                        strUpdateRate = "insert into Agent_Slab_Rate_History(Agent_Slab_ID,Agent_Rate_ID,Airline_Name,City,Slab_Name,Price_Value) values(@Agent_Slab_ID,@Agent_Rate_ID,@Airline_Name,@City,@Slab_Name,@Price_Value)";
                        cmdUpdateRate = new SqlCommand(strUpdateRate, con, trans);
                        cmdUpdateRate.CommandType = CommandType.Text;
                        cmdUpdateRate.Parameters.Add("@Agent_Slab_ID", SqlDbType.BigInt).Value = slabID1;
                        cmdUpdateRate.Parameters.Add("@Agent_Rate_ID", SqlDbType.BigInt).Value = rateId;
                        cmdUpdateRate.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = ddlAirline.SelectedItem.Text;
                        cmdUpdateRate.Parameters.Add("@City", SqlDbType.VarChar).Value = ddlAirlineCity.SelectedItem.Text;
                        cmdUpdateRate.Parameters.Add("@Slab_Name", SqlDbType.VarChar).Value = SlabName;
                        if (txtSlab.Text != "")
                        {
                            cmdUpdateRate.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = (txtSlab.Text.Trim() == "" ? 0 : decimal.Parse(txtSlab.Text.Trim())); 
                        }
                        else
                        {
                            cmdUpdateRate.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = 0;
                        }
                        cmdUpdateRate.ExecuteNonQuery();
                    }
                    else
                    {
                        strUpdateRate = "update Agent_Slab_Rate set Price_Value = '" + price + "'where Agent_Slab_ID = '" + agentslabId + "'";
                        cmdUpdateRate = new SqlCommand(strUpdateRate, con, trans);
                        cmdUpdateRate.CommandType = CommandType.Text;

                        cmdUpdateRate.ExecuteNonQuery();

                        //INSERT INTO AGENT_SLAB_HISTORY 
                        strUpdateRate = "insert into Agent_Slab_Rate_History(Agent_Slab_ID,Agent_Rate_ID,Airline_Name,City,Slab_Name,Price_Value) values(@Agent_Slab_ID,@Agent_Rate_ID,@Airline_Name,@City,@Slab_Name,@Price_Value)";
                        cmdUpdateRate = new SqlCommand(strUpdateRate, con, trans);
                        cmdUpdateRate.CommandType = CommandType.Text;
                        cmdUpdateRate.Parameters.Add("@Agent_Slab_ID", SqlDbType.BigInt).Value = agentslabId;
                        cmdUpdateRate.Parameters.Add("@Agent_Rate_ID", SqlDbType.BigInt).Value = rateId;
                        cmdUpdateRate.Parameters.Add("@Airline_Name", SqlDbType.VarChar).Value = ddlAirline.SelectedItem.Text;
                        cmdUpdateRate.Parameters.Add("@City", SqlDbType.VarChar).Value = ddlAirlineCity.SelectedItem.Text;
                        cmdUpdateRate.Parameters.Add("@Slab_Name", SqlDbType.VarChar).Value = SlabName;
                        if (txtSlab.Text != "")
                        {
                            cmdUpdateRate.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value =decimal.Parse(txtSlab.Text);
                        }
                        else
                        {
                            cmdUpdateRate.Parameters.Add("@Price_Value", SqlDbType.Decimal).Value = 0;
                        }
                        cmdUpdateRate.ExecuteNonQuery();
                    }
                    
                }

                trans.Commit();
                Response.Redirect("agent_Rate_MasterDetails.aspx");
            }
            catch(SqlException sqe)
            {
                lblDateError.Text = "sql error" + sqe.Message;
                trans.Rollback();
            }
            finally
            {
                con.Close();
            }
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        updateAgentRate();
    }

    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    //*************Enable and Disable the Charge Fields*******************************
    public void Visibility()
    {
        //DataTable dtChek = dw.GetAllFromQuery("select FreightSurCharge_Charged,WarSurCharge_Charged from Airline_Detail where Airline_Detail_ID=" + ddlAirline.SelectedValue);
        //DataTable dtYes = dw.GetAllFromQuery("select Status_ID from Status_Master where Status_Name='YES'");
        //string strYes = dtYes.Rows[0]["Status_ID"].ToString();
        //DataTable dtNo = dw.GetAllFromQuery("select Status_ID from Status_Master where Status_Name='No'");
        //string strNo = dtNo.Rows[0]["Status_ID"].ToString();
        //if (dtChek.Rows.Count > 0)
        //{
        //    if ((dtChek.Rows[0]["FreightSurCharge_Charged"].ToString() == strYes) && (dtChek.Rows[0]["WarSurCharge_Charged"].ToString() == strYes))
        //    {
        //        txtFreightSurCharge.Text = "";
        //        txtSecuritySurCharge.Text = "";
        //        //RowFreightSurCharge.Visible = true;
        //        //RowSecuritySurCharge.Visible = true;
        //    }
        //    if ((dtChek.Rows[0]["FreightSurCharge_Charged"].ToString() == strNo) && (dtChek.Rows[0]["WarSurCharge_Charged"].ToString() == strNo))
        //    {
        //        txtFreightSurCharge.Text = "";
        //        txtSecuritySurCharge.Text = "";
        //        //RowFreightSurCharge.Visible = false;
        //        //RowSecuritySurCharge.Visible = false;
        //    }
        //    if ((dtChek.Rows[0]["FreightSurCharge_Charged"].ToString() == strYes) && (dtChek.Rows[0]["WarSurCharge_Charged"].ToString() == strNo))
        //    {
        //        txtFreightSurCharge.Text = "";
        //        txtSecuritySurCharge.Text = "";
        //        //RequiredFieldValidator5 = false;
        //        //RowFreightSurCharge.Visible = true;
        //        //RowSecuritySurCharge.Visible = false;
        //    }
        //    if ((dtChek.Rows[0]["FreightSurCharge_Charged"].ToString() == strNo) && (dtChek.Rows[0]["WarSurCharge_Charged"].ToString() == strYes))
        //    {
        //        txtFreightSurCharge.Text = "";
        //        txtSecuritySurCharge.Text = "";
        //        //RowFreightSurCharge.Visible = false;
        //        //RowSecuritySurCharge.Visible = true;
        //    }
        //}
    }

    protected void SlabGrd_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void SlabGrd_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ddlAirlineCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillSlabGrid();
    }

}