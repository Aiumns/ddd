using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CSRSummary_CC : System.Web.UI.Page
{
    string table = "", page_pop="";
    string pageHead = "";
    string airlineId = null;
    string bID = null;
    decimal GtchrWt = 0;
    decimal GtamountPP = 0;
    decimal GtamountCC = 0;
    decimal GtDueCarr = 0;
    decimal GtagentExp = 0;
    decimal Gtcomm = 0;
    decimal GtTDS = 0;
    decimal Gtedcess = 0;
    decimal Gtsurchg = 0;
    decimal Gtincentive = 0;
    decimal GtspotDiff = 0;
    decimal GtfrtDiff = 0;
    decimal MHGtincentive = 0;
    decimal MHGtspotDiff = 0;
    decimal MHGtfrtDiff = 0;
    decimal GtGrandTotal = 0;
    decimal GtxrayCh = 0;
    decimal GrandTotal = 0;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");
                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 1;
                ddlMonth.Items[dt - 1].Selected = true;
                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();
                ShowAirline();

            }

        }


    }
    protected void ShowAirline()
    {

        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            //com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and C.airline_detail_id in (148,147,150,153) order by Airline_Name", con);
            
            
            com = new SqlCommand("select A.Airline_Name as 'Airline_Name',A.Airline_Code as 'Airline_Code', A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ")  order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select Airline Name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));

            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string comAdd = null, comName = null;
        string[] airlineName = ddlAirLine.SelectedItem.Text.Split('-');
        string airline = "A/C " + airlineName[0].ToUpper().ToString();
        string ss = "";

        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();
        string strY = ddlyear.SelectedItem.Text.Trim();

        if (rbtnFirstFortn.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }

        }
        if (airlineName[0] == "MALAYSIAN AIRLINES")
        {
             string VarDate = "08/15/2008";
             if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
             {
                 table += @"<table  border=""1"" cellspacing=0 cellpadding=3 align=""center"" width=80% class=""text""><tr class=""h5 boldtext""><th "" width=""3%"">S.No</th><th  width=""30%"" >Agent</th><th width=""7%"">CSR NO.</th><th width=""8%"">Chrg. Wt</th><th width=""8%"">Agent Expenses</th><th width=""8%"">Commission</th><th width=""8%"">Discount</th><th width=""7%"">TDS</th><th width=""7%"">Ecess</th><th width=""7%"">Schg</th><th width=""8%"">Receivable<br>/<font color=""red"">Payable</font></th></tr>";

                 con = new SqlConnection(strCon);
                 con.Open();
                 try
                 {//////
                     com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                     dr = com.ExecuteReader();
                     if (dr.Read())
                     {
                         airlineId = dr["airline_id"].ToString();
                         bID = dr["belongs_to_city"].ToString();
                     }
                     dr.Dispose();
                     com.Dispose();
                     com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ")) and city=" + bID + "", con);
                     //com = new SqlCommand("select * from company_master where company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " )", con);
                     dr = com.ExecuteReader();
                     while (dr.Read())
                     {
                         comAdd = dr["company_address"].ToString();
                         comName = dr["company_name"].ToString();
                         string s = dr["company_address"].ToString();
                         char ch = (char)System.Windows.Forms.Keys.Return;
                         char ch2 = (char)System.Windows.Forms.Keys.Space;
                         string ch1 = Convert.ToString(ch);
                         string ch3 = Convert.ToString(ch2);
                         string h = s.Replace(ch1, "<br>");
                         h = h.Replace(ch3, "&nbsp;");

                         pageHead += @"<p align=""center"" class=""boldtext""><font size=""2"">" + airlineName[0].ToUpper().ToString() + @"</font><br><font size=""2"">" + h + @"<br> Phone :" + dr["Phone"].ToString() + @"<br>CSR Summary Report<br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     }
                     com.Dispose();
                     dr.Dispose();

                     //////

                     com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
                     dr = com.ExecuteReader();
                     int sno = 1;
                     while (dr.Read())
                     {
                         SqlConnection con1 = new SqlConnection(strCon);
                         con1.Open();
                         SqlCommand com1 = new SqlCommand();
                         com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect'", con1);
                         SqlDataReader dr5 = com1.ExecuteReader();
                         if (dr5.Read())
                         {
                             com1.Dispose();
                             dr5.Dispose();
                             decimal xrayCh = 0;
                             decimal frAmount = 0;
                             decimal DueCarr = 0;
                             decimal agentExp = 0;
                             decimal comm = 0;
                             decimal incentive = 0;
                             decimal mHincentive = 0;
                             decimal spotDiff = 0;
                             decimal mHspotDiff = 0;
                             decimal frtDiff = 0;
                             decimal mHfrtDiff = 0;
                             decimal chrWt = 0;
                             decimal amountPP = 0;
                             decimal amountCC = 0;
                             decimal TotFrAmountCC = 0;
                             decimal TotTds = 0;
                             decimal TotTax = 0, TotDiscount = 0;
                             decimal EduChrg = 0; decimal Total = 0;
                             decimal surCharge = 0;
                             decimal lastTsdsRate = 0;
                             decimal lastSurcharge = 0;
                             decimal Tds_discount = 0;

                             string csrno = "";

                             table += @"<tr class=""text""><td>" + sno + @"</td><td align=""left"" nowrap>" + dr["agent_name"].ToString() + @"</td>";

                             com1 = new SqlCommand("mh_cc", con1);
                             com1.CommandType = CommandType.StoredProcedure;
                             com1.Parameters.AddWithValue("agent_id", dr["agent_id"].ToString());
                             com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                             com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                             com1.Parameters.AddWithValue("Airline_Detail_ID", ddlAirLine.SelectedValue.Trim());
                             SqlDataReader dr1 = com1.ExecuteReader();

                             while (dr1.Read())
                             {
                                 lastTsdsRate = 0.0000M;
                                 lastSurcharge = 0.0000M;
                                 csrno = dr1["csr_sno"].ToString();
                                 if (dr1["Freight_type"].ToString() == "COLLECT")
                                 {

                                     amountCC += (Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero));
                                     TotFrAmountCC += Math.Round(amountCC, MidpointRounding.AwayFromZero);

                                 }
                                 TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                 TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                 chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                 xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                 frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                 DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                 agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);

                                 comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString() == "" ? "0" : dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                                 // calculation for incentive
                                 if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {
                                         incentive += 0;
                                     }
                                     else
                                     {
                                         incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     }
                                 }
                                 else
                                 {
                                     incentive += 0;

                                 }
                                 //calculation for MH Incentive
                                 if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {
                                         mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     }
                                     else
                                     {
                                         mHincentive += 0;
                                     }

                                 }
                                 else
                                 {
                                     mHincentive += 0;

                                 }

                                 // calculation for spot Diff.

                                 if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     { spotDiff += 0; }
                                     else
                                     {
                                         //Freight_Diff_Amount

                                         spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                     }
                                 }
                                 else
                                 {
                                     spotDiff += 0;
                                 }
                                 //cal for hm 
                                 if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {

                                         mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                     }
                                     else
                                     {
                                         mHspotDiff = 0;
                                     }
                                 }
                                 else
                                 {
                                     mHspotDiff += 0;
                                 }

                                 frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);

                                 mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);

                                 if (dr1["tds"].ToString() != "0.0000")
                                     lastTsdsRate = decimal.Parse(dr1["tds"].ToString());
                                 if (dr1["surcharge"].ToString() != "0.0000")
                                     lastSurcharge = decimal.Parse(dr1["surcharge"].ToString());
                                 Tds_discount = Math.Ceiling(((decimal.Parse(dr1["MHDiscount"].ToString()) + decimal.Parse(dr1["Commissionable_Amount"].ToString())) * lastTsdsRate) / 100);

                                 TotTds += Math.Ceiling(Tds_discount);

                                 EduChrg += Math.Round(( Math.Ceiling(Tds_discount) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                 surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                 
                                 Total = Math.Round((agentExp+comm + mHfrtDiff -  Math.Ceiling(TotTds) - EduChrg - surCharge), MidpointRounding.AwayFromZero);
                                 GrandTotal = Total;
                                 ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";

                             }

                             GtchrWt += chrWt;
                             GtamountPP += amountPP;
                             GtamountCC += amountCC;
                             GtDueCarr += DueCarr;
                             GtagentExp += agentExp;
                             Gtcomm += comm;
                             Gtincentive += incentive;
                             GtspotDiff += spotDiff;
                             GtfrtDiff += frtDiff;
                             GtTDS += TotTds;
                             Gtedcess += EduChrg;
                             Gtsurchg += surCharge;
                             MHGtincentive += mHincentive;
                             MHGtspotDiff += mHspotDiff;
                             MHGtfrtDiff += mHfrtDiff;
                             GtGrandTotal += GrandTotal;
                             GtxrayCh += xrayCh;
                             table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + comm + @"</td><td align=""right"">" + mHfrtDiff + @"</td><td align=""right"">" + TotTds + @"</td><td align=""right"">" + EduChrg + @"</td><td align=""right"">" + surCharge + @"</td><td align=""right"">" + ss + @"</td></tr>";
                             sno = sno + 1;


                         }


                         con1.Close();
                     }
                     table += @"<tr class=""boldtext h1"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + MHGtfrtDiff + @"</td><td>" + Math.Ceiling(GtTDS) + @"</td><td>" + Gtedcess + @"</td><td>" + Gtsurchg + @"</td><td><font color=red>(" + Math.Abs(GtGrandTotal) + ")" + @"</td></tr></table>";
                     Session["dt"] = pageHead + table;
                     if (pageHead == "")
                     {
                         pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                         Session["dt"] = pageHead;
                     }
                 }
                 catch (SqlException ex)
                 {
                     string strer = ex.ToString();
                 }
                 finally
                 {
                     if (con != null && con.State == ConnectionState.Open)
                         con.Close();
                 }
                 page_pop = "<SCRIPT language='javascript'>window.open('CSRSummary_CCShow.aspx');</SCRIPT>";
                 ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CSRSummary_CCShow.aspx');</script>");
             }

             else 
             {
                 table += @"<table  border=""1"" cellspacing=0 cellpadding=3 align=""center"" width=80% class=""text""><tr class=""h5 boldtext""><
th "" width=""3%"">S.No</th><th  width=""30%"" >Agent</th><th width=""7%"">CSR NO.</th><th width=""8%"">Chrg. Wt</th><th width=""8%"">Agent Expenses</th><th width=""8%"">Discount</th><th width=""7%"">TDS</th><th width=""7%"">Ecess</th><th width=""7%"">Schg</th><th width=""8%"">Receivable<br>/<font color=""red"">Payable</font></th></tr>";

                 con = new SqlConnection(strCon);
                 con.Open();
                 try
                 {//////
                     com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                     dr = com.ExecuteReader();
                     if (dr.Read())
                     {
                         airlineId = dr["airline_id"].ToString();
                         bID = dr["belongs_to_city"].ToString();
                     }
                     dr.Dispose();
                     com.Dispose();
                     com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ")) and city=" + bID + "", con);
                     dr = com.ExecuteReader();
                     while (dr.Read())
                     {
                         comAdd = dr["company_address"].ToString();
                         comName = dr["company_name"].ToString();
                         string s = dr["company_address"].ToString();
                         char ch = (char)System.Windows.Forms.Keys.Return;
                         char ch2 = (char)System.Windows.Forms.Keys.Space;
                         string ch1 = Convert.ToString(ch);
                         string ch3 = Convert.ToString(ch2);
                         string h = s.Replace(ch1, "<br>");
                         h = h.Replace(ch3, "&nbsp;");

                         pageHead += @"<p align=""center"" class=""boldtext""><font size=""2"">" + airlineName[0].ToUpper().ToString() + @"</font><br><font size=""2"">" + h + @"<br> Phone :" + dr["Phone"].ToString() + @"<br>CSR Summary Report<br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     }
                     com.Dispose();
                     dr.Dispose();
                     com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
                     dr = com.ExecuteReader();
                     int sno = 1;
                     while (dr.Read())
                     {
                         SqlConnection con1 = new SqlConnection(strCon);
                         con1.Open();
                         SqlCommand com1 = new SqlCommand();
                         com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect'", con1);
                         SqlDataReader dr5 = com1.ExecuteReader();
                         if (dr5.Read())
                         {
                             com1.Dispose();
                             dr5.Dispose();
                             decimal xrayCh = 0;
                             decimal frAmount = 0;
                             decimal DueCarr = 0;
                             decimal agentExp = 0;
                             decimal comm = 0;
                             decimal incentive = 0;
                             decimal mHincentive = 0;
                             decimal spotDiff = 0;
                             decimal mHspotDiff = 0;
                             decimal frtDiff = 0;
                             decimal mHfrtDiff = 0;
                             decimal chrWt = 0;
                             decimal amountPP = 0;
                             decimal amountCC = 0;
                             decimal TotFrAmountCC = 0;
                             decimal TotTds = 0;
                             decimal TotTax = 0, TotDiscount = 0;
                             decimal EduChrg = 0; decimal Total = 0;
                             decimal surCharge = 0;
                             decimal lastTsdsRate = 0;
                             decimal lastSurcharge = 0;
                             decimal Tds_discount = 0;

                             string csrno = "";

                             table += @"<tr class=""text""><td>" + sno + @"</td><td align=""left"" nowrap>" + dr["agent_name"].ToString() + @"</td>";

                             com1 = new SqlCommand("mh_cc", con1);
                             com1.CommandType = CommandType.StoredProcedure;
                             com1.Parameters.AddWithValue("agent_id", dr["agent_id"].ToString());
                             com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                             com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                             com1.Parameters.AddWithValue("Airline_Detail_ID", ddlAirLine.SelectedValue.Trim());
                             SqlDataReader dr1 = com1.ExecuteReader();

                             while (dr1.Read())
                             {
                                 lastTsdsRate = 0.0000M;
                                 lastSurcharge = 0.0000M;
                                 csrno = dr1["csr_sno"].ToString();
                                 if (dr1["Freight_type"].ToString() == "COLLECT")
                                 {

                                     amountCC += (Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero));
                                     TotFrAmountCC += Math.Round(amountCC, MidpointRounding.AwayFromZero);

                                 }
                                 TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                 TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                 chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                 xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                 frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                 DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                 agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                 comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString() == "" ? "0" : dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                                 // calculation for incentive
                                 if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {
                                         incentive += 0;
                                     }
                                     else
                                     {
                                         incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     }
                                 }
                                 else
                                 {
                                     incentive += 0;

                                 }
                                 //calculation for MH Incentive
                                 if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {
                                         mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     }
                                     else
                                     {
                                         mHincentive += 0;
                                     }

                                 }
                                 else
                                 {
                                     mHincentive += 0;

                                 }

                                 // calculation for spot Diff.

                                 if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     { spotDiff += 0; }
                                     else
                                     {
                                         //Freight_Diff_Amount

                                         spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                     }
                                 }
                                 else
                                 {
                                     spotDiff += 0;
                                 }
                                 //cal for hm 
                                 if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {

                                         mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                     }
                                     else
                                     {
                                         mHspotDiff = 0;
                                     }
                                 }
                                 else
                                 {
                                     mHspotDiff += 0;
                                 }

                                 frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);

                                 mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);


                                 if (dr1["tds"].ToString() != "0.0000")
                                     lastTsdsRate = decimal.Parse(dr1["tds"].ToString());
                                 if (dr1["surcharge"].ToString() != "0.0000")
                                     lastSurcharge = decimal.Parse(dr1["surcharge"].ToString());
                                 Tds_discount = Math.Ceiling((decimal.Parse(dr1["MHDiscount"].ToString()) * lastTsdsRate) / 100);

                                 TotTds += Math.Ceiling(Tds_discount);
                                 EduChrg += Math.Round((Math.Ceiling(Tds_discount) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                                 surCharge += Math.Round((Math.Ceiling(Tds_discount) * decimal.Parse(dr1["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                 Total = Math.Round((mHfrtDiff + agentExp - Math.Ceiling(TotTds) - EduChrg - surCharge), MidpointRounding.AwayFromZero);
                                 GrandTotal = Total;
                                 ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";

                             }

                             GtchrWt += chrWt;
                             GtamountPP += amountPP;
                             GtamountCC += amountCC;
                             GtDueCarr += DueCarr;
                             GtagentExp += agentExp;
                             Gtcomm += comm;
                             Gtincentive += incentive;
                             GtspotDiff += spotDiff;
                             GtfrtDiff += frtDiff;
                             GtTDS += TotTds;
                             Gtedcess += EduChrg;
                             Gtsurchg += surCharge;
                             MHGtincentive += mHincentive;
                             MHGtspotDiff += mHspotDiff;
                             MHGtfrtDiff += mHfrtDiff;
                             GtGrandTotal += GrandTotal;
                             GtxrayCh += xrayCh;
                             table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + mHfrtDiff + @"</td><td align=""right"">" + TotTds + @"</td><td align=""right"">" + EduChrg + @"</td><td align=""right"">" + surCharge + @"</td><td align=""right"">" + ss + @"</td></tr>";
                             sno = sno + 1;


                         }


                         con1.Close();
                     }
                     table += @"<tr class=""boldtext h1"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtagentExp + @"</td><td>" + MHGtfrtDiff + @"</td><td>" + Math.Ceiling(GtTDS) + @"</td><td>" + Gtedcess + @"</td><td>" + Gtsurchg + @"</td><td><font color=red>(" + Math.Abs(GtGrandTotal) + ")" + @"</td></tr></table>";
                     Session["dt"] = pageHead + table;
                     if (pageHead == "")
                     {
                         pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                         Session["dt"] = pageHead;
                     }
                 }
                 catch (SqlException ex)
                 {
                     string strer = ex.ToString();
                 }
                 finally
                 {
                     if (con != null && con.State == ConnectionState.Open)
                         con.Close();
                 }
                 page_pop = "<SCRIPT language='javascript'>window.open('CSRSummary_CCShow.aspx');</SCRIPT>";
                 ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CSRSummary_CCShow.aspx');</script>");
             }
        }
        else if (airlineName[0] == "TURKISH AIRLINES")
        {
             string VarDate = "07/31/2008";
             if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
             {
                 table += @"<table  border=""1"" cellspacing=0 cellpadding=3 align=""center"" width=80% class=""text""><tr class=""h5 boldtext""><th "" width=""3%"">S.No</th><th  width=""30%"" >Agent</th><th width=""7%"">CSR NO.</th><th width=""8%"">Chrg. Wt</th><th width=""8%"">Agent Expenses</th><th width=""8%"">Commission</th><th width=""8%"">Discount</th><th width=""7%"">TDS</th><th width=""7%"">Ecess</th><th width=""7%"">Schg</th><th width=""8%"">Receivable<br>/<font color=""red"">Payable</font></th></tr>";

                 con = new SqlConnection(strCon);
                 con.Open();
                 try
                 {//////
                     com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                     dr = com.ExecuteReader();
                     if (dr.Read())
                     {
                         airlineId = dr["airline_id"].ToString();
                         bID = dr["belongs_to_city"].ToString();
                     }
                     dr.Dispose();
                     com.Dispose();
                     com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ")) and city=" + bID + "", con);
                     //com = new SqlCommand("select * from company_master where company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " )", con);
                     dr = com.ExecuteReader();
                     while (dr.Read())
                     {
                         comAdd = dr["company_address"].ToString();
                         comName = dr["company_name"].ToString();
                         string s = dr["company_address"].ToString();
                         char ch = (char)System.Windows.Forms.Keys.Return;
                         char ch2 = (char)System.Windows.Forms.Keys.Space;
                         string ch1 = Convert.ToString(ch);
                         string ch3 = Convert.ToString(ch2);
                         string h = s.Replace(ch1, "<br>");
                         h = h.Replace(ch3, "&nbsp;");

                         pageHead += @"<p align=""center"" class=""boldtext""><font size=""2"">" + airlineName[0].ToUpper().ToString() + @"</font><br><font size=""2"">" + h + @"<br> Phone :" + dr["Phone"].ToString() + @"<br>CSR Summary Report<br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                     }
                     com.Dispose();
                     dr.Dispose();

                     //////

                     com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
                     dr = com.ExecuteReader();
                     int sno = 1;
                     while (dr.Read())
                     {
                         SqlConnection con1 = new SqlConnection(strCon);
                         con1.Open();
                         SqlCommand com1 = new SqlCommand();
                         com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect'", con1);
                         SqlDataReader dr5 = com1.ExecuteReader();
                         if (dr5.Read())
                         {
                             com1.Dispose();
                             dr5.Dispose();
                             decimal xrayCh = 0;
                             decimal frAmount = 0;
                             decimal DueCarr = 0;
                             decimal agentExp = 0;
                             decimal comm = 0;
                             decimal incentive = 0;
                             decimal mHincentive = 0;
                             decimal spotDiff = 0;
                             decimal mHspotDiff = 0;
                             decimal frtDiff = 0;
                             decimal mHfrtDiff = 0;
                             decimal chrWt = 0;
                             decimal amountPP = 0;
                             decimal amountCC = 0;
                             decimal TotFrAmountCC = 0;
                             decimal TotTds = 0;
                             decimal TotTax = 0, TotDiscount = 0;
                             decimal EduChrg = 0; decimal Total = 0;
                             decimal surCharge = 0;
                             decimal lastTsdsRate = 0;
                             decimal lastSurcharge = 0;
                             decimal Tds_discount = 0;

                             string csrno = "";

                             table += @"<tr class=""text""><td>" + sno + @"</td><td align=""left"" nowrap>" + dr["agent_name"].ToString() + @"</td>";
                            
                             com1 = new SqlCommand("TK_cc", con1);
                             com1.CommandType = CommandType.StoredProcedure;
                             com1.Parameters.AddWithValue("agent_id", dr["agent_id"].ToString());
                             com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                             com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                             com1.Parameters.AddWithValue("Airline_Detail_ID", ddlAirLine.SelectedValue.Trim());
                             SqlDataReader dr1 = com1.ExecuteReader();

                             while (dr1.Read())
                             {
                                 lastTsdsRate = 0.0000M;
                                 lastSurcharge = 0.0000M;
                                 csrno = dr1["csr_sno"].ToString();
                                 if (dr1["Freight_type"].ToString() == "COLLECT")
                                 {

                                     amountCC += (Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero));
                                     TotFrAmountCC += Math.Round(amountCC, MidpointRounding.AwayFromZero);

                                 }
                                 TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                 TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                 chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                 xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                 frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                 DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                 agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                 
                                 comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString() == "" ? "0" : dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                                 // calculation for incentive
                                 if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {
                                         incentive += 0;
                                     }
                                     else
                                     {
                                         incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     }
                                 }
                                 else
                                 {
                                     incentive += 0;

                                 }
                                 //calculation for MH Incentive
                                 if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {
                                         mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                     }
                                     else
                                     {
                                         mHincentive += 0;
                                     }

                                 }
                                 else
                                 {
                                     mHincentive += 0;

                                 }

                                 // calculation for spot Diff.

                                 if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     { spotDiff += 0; }
                                     else
                                     {
                                         //Freight_Diff_Amount
                                         
                                         spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                     }
                                 }
                                 else
                                 {
                                     spotDiff += 0;
                                 }
                                 //cal for hm 
                                 if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                 {
                                     if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                     {
                                         
                                         mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                     }
                                     else
                                     {
                                         mHspotDiff = 0;
                                     }
                                 }
                                 else
                                 {
                                     mHspotDiff += 0;
                                 }

                                 frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                 
                                 mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                 
                                 if (dr1["tds"].ToString() != "0.0000")
                                     lastTsdsRate = decimal.Parse(dr1["tds"].ToString());
                                 if (dr1["surcharge"].ToString() != "0.0000")
                                     lastSurcharge = decimal.Parse(dr1["surcharge"].ToString());
                                 Tds_discount = Math.Ceiling(((decimal.Parse(dr1["MHDiscount"].ToString()) + decimal.Parse(dr1["Commissionable_Amount"].ToString())) * lastTsdsRate) / 100);

                                 TotTds += Math.Ceiling(Tds_discount);
  
                                 EduChrg += Math.Round((Tds_discount * decimal.Parse(dr1["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                                 surCharge += Math.Round((Math.Ceiling(Tds_discount) * decimal.Parse(dr1["surcharge"].ToString())) / 100, 0);
                                 Total = Math.Round((comm + mHfrtDiff + agentExp - Math.Ceiling(TotTds) - EduChrg - surCharge), MidpointRounding.AwayFromZero);
                                 GrandTotal = Total;
                                 ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";

                             }

                             GtchrWt += chrWt;
                             GtamountPP += amountPP;
                             GtamountCC += amountCC;
                             GtDueCarr += DueCarr;
                             GtagentExp += agentExp;
                             Gtcomm += comm;
                             Gtincentive += incentive;
                             GtspotDiff += spotDiff;
                             GtfrtDiff += frtDiff;
                             GtTDS += TotTds;
                             Gtedcess += EduChrg;
                             Gtsurchg += surCharge;
                             MHGtincentive += mHincentive;
                             MHGtspotDiff += mHspotDiff;
                             MHGtfrtDiff += mHfrtDiff;
                             GtGrandTotal += GrandTotal;
                             GtxrayCh += xrayCh;
                             table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + comm + @"</td><td align=""right"">" + mHfrtDiff + @"</td><td align=""right"">" + TotTds + @"</td><td align=""right"">" + EduChrg + @"</td><td align=""right"">" + surCharge + @"</td><td align=""right"">" + ss + @"</td></tr>";
                             sno = sno + 1;


                         }


                         con1.Close();
                     }
                     table += @"<tr class=""boldtext h1"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + MHGtfrtDiff + @"</td><td>" +Math.Ceiling(GtTDS) + @"</td><td>" + Gtedcess + @"</td><td>" + Gtsurchg + @"</td><td><font color=red>(" + Math.Abs(GtGrandTotal) + ")" + @"</td></tr></table>";
                     Session["dt"] = pageHead + table;
                     if (pageHead == "")
                     {
                         pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                         Session["dt"] = pageHead;
                     }
                 }
                 catch (SqlException ex)
                 {
                     string strer = ex.ToString();
                 }
                 finally
                 {
                     if (con != null && con.State == ConnectionState.Open)
                         con.Close();
                 }
                 page_pop = "<SCRIPT language='javascript'>window.open('CSRSummary_CCShow.aspx');</SCRIPT>";
                 ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CSRSummary_CCShow.aspx');</script>");

             }
             else
             {
                 string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";


                 Session["dt"] = mass;
                 ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CSRSummary_CCShow.aspx');</script>");
             }

        }
        
        else
        {
            string VarDate = "08/15/2008";
            if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
            {
                table += @"<table  border=""1"" cellspacing=0 cellpadding=3 align=""center"" width=80% class=""text""><tr class=""h5 boldtext""><th "" width=""3%"">S.No</th><th  width=""30%"" >Agent</th><th width=""7%"">CSR NO.</th><th width=""8%"">Chrg. Wt</th><th width=""8%"">Agent Expenses</th><th width=""8%"">Commission</th><th width=""8%"">Discount</th><th width=""7%"">TDS</th><th width=""7%"">Ecess</th><th width=""7%"">Schg</th><th width=""8%"">Receivable<br>/<font color=""red"">Payable</font></th></tr>";

                con = new SqlConnection(strCon);
                con.Open();
                try
                {//////
                    com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        airlineId = dr["airline_id"].ToString();
                        bID = dr["belongs_to_city"].ToString();
                    }
                    dr.Dispose();
                    com.Dispose();
                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ")) and city=" + bID + "", con);
                    //com = new SqlCommand("select * from company_master where company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " )", con);
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        comName = dr["company_name"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");

                        pageHead += @"<p align=""center"" class=""boldtext""><font size=""2"">" + airlineName[0].ToUpper().ToString() + @"</font><br><font size=""2"">" + h + @"<br> Phone :" + dr["Phone"].ToString() + @"<br>CSR Summary Report<br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    }
                    com.Dispose();
                    dr.Dispose();

                    //////

                    com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
                    dr = com.ExecuteReader();
                    int sno = 1;
                    while (dr.Read())
                    {
                        SqlConnection con1 = new SqlConnection(strCon);
                        con1.Open();
                        SqlCommand com1 = new SqlCommand();
                        com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect'", con1);
                        SqlDataReader dr5 = com1.ExecuteReader();
                        if (dr5.Read())
                        {
                            com1.Dispose();
                            dr5.Dispose();
                            decimal xrayCh = 0;
                            decimal frAmount = 0;
                            decimal DueCarr = 0;
                            decimal agentExp = 0;
                            decimal comm = 0;
                            decimal incentive = 0;
                            decimal mHincentive = 0;
                            decimal spotDiff = 0;
                            decimal mHspotDiff = 0;
                            decimal frtDiff = 0;
                            decimal mHfrtDiff = 0;
                            decimal chrWt = 0;
                            decimal amountPP = 0;
                            decimal amountCC = 0;
                            decimal TotFrAmountCC = 0;
                            decimal TotTds = 0;
                            decimal TotTax = 0, TotDiscount = 0;
                            decimal EduChrg = 0; decimal Total = 0;
                            decimal surCharge = 0;
                            decimal lastTsdsRate = 0;
                            decimal lastSurcharge = 0;
                            decimal Tds_discount = 0;

                            string csrno = "";

                            table += @"<tr class=""text""><td>" + sno + @"</td><td align=""left"" nowrap>" + dr["agent_name"].ToString() + @"</td>";

                            com1 = new SqlCommand("mh_cc", con1);
                            com1.CommandType = CommandType.StoredProcedure;
                            com1.Parameters.AddWithValue("agent_id", dr["agent_id"].ToString());
                            com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                            com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                            com1.Parameters.AddWithValue("Airline_Detail_ID", ddlAirLine.SelectedValue.Trim());
                            SqlDataReader dr1 = com1.ExecuteReader();

                            while (dr1.Read())
                            {
                                lastTsdsRate = 0.0000M;
                                lastSurcharge = 0.0000M;
                                csrno = dr1["csr_sno"].ToString();
                                if (dr1["Freight_type"].ToString() == "COLLECT")
                                {

                                    amountCC += (Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero));
                                    TotFrAmountCC += Math.Round(amountCC, MidpointRounding.AwayFromZero);

                                }
                                TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);

                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString() == "" ? "0" : dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                                // calculation for incentive
                                if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        incentive += 0;
                                    }
                                    else
                                    {
                                        incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    incentive += 0;

                                }
                                //calculation for MH Incentive
                                if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        mHincentive += 0;
                                    }

                                }
                                else
                                {
                                    mHincentive += 0;

                                }

                                // calculation for spot Diff.

                                if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    { spotDiff += 0; }
                                    else
                                    {
                                        //Freight_Diff_Amount

                                        spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    spotDiff += 0;
                                }
                                //cal for hm 
                                if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {

                                        mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        mHspotDiff = 0;
                                    }
                                }
                                else
                                {
                                    mHspotDiff += 0;
                                }

                                frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);

                                mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);

                                if (dr1["tds"].ToString() != "0.0000")
                                    lastTsdsRate = decimal.Parse(dr1["tds"].ToString());
                                if (dr1["surcharge"].ToString() != "0.0000")
                                    lastSurcharge = decimal.Parse(dr1["surcharge"].ToString());
                                Tds_discount = Math.Ceiling(((decimal.Parse(dr1["MHDiscount"].ToString()) + decimal.Parse(dr1["Commissionable_Amount"].ToString())) * lastTsdsRate) / 100);

                                TotTds += Math.Ceiling(Tds_discount);

                                EduChrg += Math.Round((Math.Ceiling(Tds_discount) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                Total = Math.Round((agentExp + comm + mHfrtDiff - Math.Ceiling(TotTds) - EduChrg - surCharge), MidpointRounding.AwayFromZero);
                                GrandTotal = Total;
                                ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";

                            }

                            GtchrWt += chrWt;
                            GtamountPP += amountPP;
                            GtamountCC += amountCC;
                            GtDueCarr += DueCarr;
                            GtagentExp += agentExp;
                            Gtcomm += comm;
                            Gtincentive += incentive;
                            GtspotDiff += spotDiff;
                            GtfrtDiff += frtDiff;
                            GtTDS += TotTds;
                            Gtedcess += EduChrg;
                            Gtsurchg += surCharge;
                            MHGtincentive += mHincentive;
                            MHGtspotDiff += mHspotDiff;
                            MHGtfrtDiff += mHfrtDiff;
                            GtGrandTotal += GrandTotal;
                            GtxrayCh += xrayCh;
                            table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + comm + @"</td><td align=""right"">" + mHfrtDiff + @"</td><td align=""right"">" + TotTds + @"</td><td align=""right"">" + EduChrg + @"</td><td align=""right"">" + surCharge + @"</td><td align=""right"">" + ss + @"</td></tr>";
                            sno = sno + 1;


                        }


                        con1.Close();
                    }
                    table += @"<tr class=""boldtext h1"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + MHGtfrtDiff + @"</td><td>" + Math.Ceiling(GtTDS) + @"</td><td>" + Gtedcess + @"</td><td>" + Gtsurchg + @"</td><td><font color=red>(" + Math.Abs(GtGrandTotal) + ")" + @"</td></tr></table>";
                    Session["dt"] = pageHead + table;
                    if (pageHead == "")
                    {
                        pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                        Session["dt"] = pageHead;
                    }
                }
                catch (SqlException ex)
                {
                    string strer = ex.ToString();
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
                page_pop = "<SCRIPT language='javascript'>window.open('CSRSummary_CCShow.aspx');</SCRIPT>";
                ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CSRSummary_CCShow.aspx');</script>");
            }

            else
            {
                table += @"<table  border=""1"" cellspacing=0 cellpadding=3 align=""center"" width=80% class=""text""><tr class=""h5 boldtext""><
th "" width=""3%"">S.No</th><th  width=""30%"" >Agent</th><th width=""7%"">CSR NO.</th><th width=""8%"">Chrg. Wt</th><th width=""8%"">Agent Expenses</th><th width=""8%"">Discount</th><th width=""7%"">TDS</th><th width=""7%"">Ecess</th><th width=""7%"">Schg</th><th width=""8%"">Receivable<br>/<font color=""red"">Payable</font></th></tr>";

                con = new SqlConnection(strCon);
                con.Open();
                try
                {//////
                    com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        airlineId = dr["airline_id"].ToString();
                        bID = dr["belongs_to_city"].ToString();
                    }
                    dr.Dispose();
                    com.Dispose();
                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ")) and city=" + bID + "", con);
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        comName = dr["company_name"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");

                        pageHead += @"<p align=""center"" class=""boldtext""><font size=""2"">" + airlineName[0].ToUpper().ToString() + @"</font><br><font size=""2"">" + h + @"<br> Phone :" + dr["Phone"].ToString() + @"<br>CSR Summary Report<br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
                    dr = com.ExecuteReader();
                    int sno = 1;
                    while (dr.Read())
                    {
                        SqlConnection con1 = new SqlConnection(strCon);
                        con1.Open();
                        SqlCommand com1 = new SqlCommand();
                        com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and  sales.freight_type='Collect' union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and sales_drcr.freight_type='Collect'", con1);
                        SqlDataReader dr5 = com1.ExecuteReader();
                        if (dr5.Read())
                        {
                            com1.Dispose();
                            dr5.Dispose();
                            decimal xrayCh = 0;
                            decimal frAmount = 0;
                            decimal DueCarr = 0;
                            decimal agentExp = 0;
                            decimal comm = 0;
                            decimal incentive = 0;
                            decimal mHincentive = 0;
                            decimal spotDiff = 0;
                            decimal mHspotDiff = 0;
                            decimal frtDiff = 0;
                            decimal mHfrtDiff = 0;
                            decimal chrWt = 0;
                            decimal amountPP = 0;
                            decimal amountCC = 0;
                            decimal TotFrAmountCC = 0;
                            decimal TotTds = 0;
                            decimal TotTax = 0, TotDiscount = 0;
                            decimal EduChrg = 0; decimal Total = 0;
                            decimal surCharge = 0;
                            decimal lastTsdsRate = 0;
                            decimal lastSurcharge = 0;
                            decimal Tds_discount = 0;

                            string csrno = "";

                            table += @"<tr class=""text""><td>" + sno + @"</td><td align=""left"" nowrap>" + dr["agent_name"].ToString() + @"</td>";

                            com1 = new SqlCommand("mh_cc", con1);
                            com1.CommandType = CommandType.StoredProcedure;
                            com1.Parameters.AddWithValue("agent_id", dr["agent_id"].ToString());
                            com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                            com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                            com1.Parameters.AddWithValue("Airline_Detail_ID", ddlAirLine.SelectedValue.Trim());
                            SqlDataReader dr1 = com1.ExecuteReader();

                            while (dr1.Read())
                            {
                                lastTsdsRate = 0.0000M;
                                lastSurcharge = 0.0000M;
                                csrno = dr1["csr_sno"].ToString();
                                if (dr1["Freight_type"].ToString() == "COLLECT")
                                {

                                    amountCC += (Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero));
                                    TotFrAmountCC += Math.Round(amountCC, MidpointRounding.AwayFromZero);

                                }
                                TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString() == "" ? "0" : dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                                // calculation for incentive
                                if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        incentive += 0;
                                    }
                                    else
                                    {
                                        incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    incentive += 0;

                                }
                                //calculation for MH Incentive
                                if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        mHincentive += 0;
                                    }

                                }
                                else
                                {
                                    mHincentive += 0;

                                }

                                // calculation for spot Diff.

                                if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    { spotDiff += 0; }
                                    else
                                    {
                                        //Freight_Diff_Amount

                                        spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    spotDiff += 0;
                                }
                                //cal for hm 
                                if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {

                                        mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        mHspotDiff = 0;
                                    }
                                }
                                else
                                {
                                    mHspotDiff += 0;
                                }

                                frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);

                                mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);


                                if (dr1["tds"].ToString() != "0.0000")
                                    lastTsdsRate = decimal.Parse(dr1["tds"].ToString());
                                if (dr1["surcharge"].ToString() != "0.0000")
                                    lastSurcharge = decimal.Parse(dr1["surcharge"].ToString());
                                Tds_discount = Math.Ceiling((decimal.Parse(dr1["MHDiscount"].ToString()) * lastTsdsRate) / 100);

                                TotTds += Math.Ceiling(Tds_discount);
                                EduChrg += Math.Round((Math.Ceiling(Tds_discount) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                                surCharge += Math.Round((Math.Ceiling(Tds_discount) * decimal.Parse(dr1["surcharge"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                Total = Math.Round((mHfrtDiff + agentExp - Math.Ceiling(TotTds) - EduChrg - surCharge), MidpointRounding.AwayFromZero);
                                GrandTotal = Total;
                                ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";

                            }

                            GtchrWt += chrWt;
                            GtamountPP += amountPP;
                            GtamountCC += amountCC;
                            GtDueCarr += DueCarr;
                            GtagentExp += agentExp;
                            Gtcomm += comm;
                            Gtincentive += incentive;
                            GtspotDiff += spotDiff;
                            GtfrtDiff += frtDiff;
                            GtTDS += TotTds;
                            Gtedcess += EduChrg;
                            Gtsurchg += surCharge;
                            MHGtincentive += mHincentive;
                            MHGtspotDiff += mHspotDiff;
                            MHGtfrtDiff += mHfrtDiff;
                            GtGrandTotal += GrandTotal;
                            GtxrayCh += xrayCh;
                            table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + mHfrtDiff + @"</td><td align=""right"">" + TotTds + @"</td><td align=""right"">" + EduChrg + @"</td><td align=""right"">" + surCharge + @"</td><td align=""right"">" + ss + @"</td></tr>";
                            sno = sno + 1;


                        }


                        con1.Close();
                    }
                    table += @"<tr class=""boldtext h1"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtagentExp + @"</td><td>" + MHGtfrtDiff + @"</td><td>" + Math.Ceiling(GtTDS) + @"</td><td>" + Gtedcess + @"</td><td>" + Gtsurchg + @"</td><td><font color=red>(" + Math.Abs(GtGrandTotal) + ")" + @"</td></tr></table>";
                    Session["dt"] = pageHead + table;
                    if (pageHead == "")
                    {
                        pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                        Session["dt"] = pageHead;
                    }
                }
                catch (SqlException ex)
                {
                    string strer = ex.ToString();
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
                page_pop = "<SCRIPT language='javascript'>window.open('CSRSummary_CCShow.aspx');</SCRIPT>";
                ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CSRSummary_CCShow.aspx');</script>");
            }
        }
       
        //else
        //{
        //    string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";


        //    Session["dt"] = mass;
        //    ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('CSRSummary_CCShow.aspx');</script>");
        //}


    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
}
