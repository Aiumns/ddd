using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CPP_QtrBonus : System.Web.UI.Page
{
    private string gvUniqueID = String.Empty;
    string gvSortExpr = String.Empty;
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string[] Sdate;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        else
        {
            //rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
            //rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");

            if (!IsPostBack)
            {
                fillCity();
                Session["dthold"] = maketable();
                DataTable dt = (DataTable)Session["dthold"];
                grdCpp_QtrBonus.DataSource = (DataTable)Session["dthold"];
                grdCpp_QtrBonus.DataBind();
                grdCpp_QtrBonus.Rows[0].Visible = false;
                if (dt.Rows[0][0].ToString() == "0")
                {
                    ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = "0";
                    ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[1].FindControl("txtStartvalue")).ReadOnly = true;

                }
                if (Request.QueryString["startDate"].ToString().Trim() == "s" && Request.QueryString["enddate"].ToString().Trim() == "e")
                {
                    txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    Sdate = txtValidFrom.Text.Split('/');
                    string month = Sdate[1];
                    string year = Sdate[2];
                    if (Sdate[1] == "01" || Sdate[1] == "02" || Sdate[1] == "03")
                    {
                        int yy = int.Parse(year);
                        string destdata = "31/03/" + yy.ToString();
                        txtValidTo.Text = destdata;
                    }
                    if (Sdate[1] == "04" || Sdate[1] == "05" || Sdate[1] == "06" || Sdate[1] == "07" || Sdate[1] == "08" || Sdate[1] == "09" || Sdate[1] == "10" || Sdate[1] == "11" || Sdate[1] == "12")
                    {
                        int yy = int.Parse(year) + 1;
                        string destdata = "31/03/" + yy.ToString();
                        txtValidTo.Text = destdata;
                    }

                    btnupdate.Visible = false;
                    btnSubmit.Visible = true;

                }
                else
                {
                    FillData();
                    btnupdate.Visible = true;
                    btnSubmit.Visible = false;
                    //DataTable dt_checkpromo = dw.GetAllFromQuery("Select min(startdate) as startdate,max(enddate) as enddate,sum(ISNULL(TotalPromo,0)) AS TotalPromo from CPP_AgentwiseTotal where   StartDate between '" + FormatDateMM(Request.QueryString["startDate"].ToString().Trim()) + "' AND '" + FormatDateMM(Request.QueryString["enddate"].ToString().Trim()) + "'");
                    DataTable dt_checkpromo = dw.GetAllFromQuery("select min(startdate) as startdate,max(enddate) as enddate,sum(ISNULL(TotalQtr,0)) AS TotalQtr from cpp_agentwisetotal where ('" + FormatDateMM(Request.QueryString["startDate"].ToString().Trim()) + "' between startdate and enddate) or ('" + FormatDateMM(Request.QueryString["enddate"].ToString().Trim()) + "' between startdate and enddate)");
                    if (dt_checkpromo.Rows[0]["startdate"].ToString().Trim() != "")
                    {
                        if (decimal.Parse(dt_checkpromo.Rows[0]["TotalQtr"].ToString()) > 0)
                        {
                            //btnFrom.Visible = false;
                            //btnTo.Visible = true;
                            lblmsg.Visible = true;
                            txtValidFrom.ReadOnly = true;
                            lblmsg.Text = " Qtr CPP already Transffered  in period between " + FormatDateDD(dt_checkpromo.Rows[0]["startdate"].ToString().Trim()) + " and " + FormatDateDD(dt_checkpromo.Rows[0]["enddate"].ToString().Trim()) + "";
                            //txtValidTo.Text = FormatDateDD(dt_checkbase.Rows[0]["Enddate"].ToString().Trim());
                            grdCpp_QtrBonus.FooterRow.Visible = false;
                            grdCpp_QtrBonus.Columns[5].Visible = false;
                        }
                        else
                        {
                            //btnFrom.Visible = true;
                            //btnTo.Visible = true;

                        }
                    }
                    else
                    {
                        //btnFrom.Visible = true;
                        //btnTo.Visible = true;
                    }
                }

            }
        }


    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY.Substring(0, 4);
        return strMMDDYYYY;
    }
    public void FillData()
    {
        decimal factor_show = 0;
        con = new SqlConnection(strCon);
        con.Open();
        if (Request.QueryString["startDate"].ToString().Trim() != "" && Request.QueryString["enddate"].ToString().Trim() != "")
        {
            txtValidFrom.Text = Request.QueryString["startDate"].ToString().Trim();
            txtValidTo.Text = Request.QueryString["enddate"].ToString().Trim();
            DataTable dtDetails = dw.GetAllFromQuery("select * from CPP_QtrBonus where city='" + Request.QueryString["cid"].ToString().Trim() + "' and startDate='" + FormatDateMM(Request.QueryString["startDate"].ToString().Trim()) + "' and EndDate='" + FormatDateMM(Request.QueryString["enddate"].ToString().Trim()) + "' order by startvalue");

            DataTable dt = (DataTable)Session["dthold"];
            string strCityAccess = dtDetails.Rows[0]["City"].ToString();
            string[] arrCity = strCityAccess.Split(new char[] { ',' });

            for (int j = 0; j < arrCity.Length; j++)
            {
                for (int i = 0; i <= (lstCityCode.Items.Count - 1); i++)
                {
                    if (lstCityCode.Items[i].Value == arrCity[j])
                    {
                        lstCityCode.Items[i].Selected = true;
                    }
                }
            }
            if (dt.Rows[0][0].ToString() == "0")
            {
                dt.Rows[0].Delete();
            }
            for (int k = 0; k < dtDetails.Rows.Count; k++)
            {
                DataRow dr = dt.NewRow();
                string strSno = dtDetails.Rows[k]["Sno"].ToString();
                string strStartvalue = dtDetails.Rows[k]["Startvalue"].ToString();
                string strEndValue = dtDetails.Rows[k]["EndValue"].ToString();
                factor_show = Convert.ToDecimal(dtDetails.Rows[k]["Factor"].ToString()) * 100;
                string strfactor = Convert.ToString(factor_show);
                string strMembership = dtDetails.Rows[k]["Membership"].ToString();
                dr[0] = strSno.ToString();
                dr[1] = strStartvalue.ToString();
                dr[2] = strEndValue.ToString();
                dr[3] = strfactor.ToString();
                dr[4] = strMembership.ToString();
                dt.Rows.Add(dr);
            }
            Session["dthold"] = dt;
            grdCpp_QtrBonus.DataSource = dt;
            grdCpp_QtrBonus.DataBind();

        }
    }
    public DataTable maketable()
    {
        DataTable dt = new DataTable();
        DataColumn dc3 = new DataColumn("Sno", typeof(Int32));
        dc3.AutoIncrement = true;
        dc3.AutoIncrementStep = 1;
        dc3.AutoIncrementSeed = 1;
        dt.Columns.Add(dc3);
        DataColumn dc = new DataColumn("Startvalue", typeof(String));
        dt.Columns.Add(dc);

        DataColumn dc1 = new DataColumn("EndValue", typeof(String));
        dt.Columns.Add(dc1);

        DataColumn dc2 = new DataColumn("Factor", typeof(String));
        dt.Columns.Add(dc2);

        DataColumn dc4 = new DataColumn("memberShip", typeof(String));
        dt.Columns.Add(dc4);

        DataRow dr = dt.NewRow();

        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "00";
        dr[3] = "00";
        dr[4] = "00";
        dt.Rows.Add(dr);
        return dt;
    }
    public void DeleteRecords()
    {
        DataTable dt_del = (DataTable)Session["dthold"];
        for (int i = 0; i < dt_del.Rows.Count; i++)
        {
            con = new SqlConnection(strCon);
            try
            {
                DataRow rw = dt_del.Rows[i];
                con.Open();
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand("[CPP_QtrDELETE]", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Sno", SqlDbType.BigInt).Value = long.Parse(rw["sno"].ToString());
                com.ExecuteNonQuery();
                con.Close();
                com.Connection.Close();
            }
            catch (SqlException sqlex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Error');</script>");
                string ss = sqlex.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
    public void ADDDATA()
    {
        string ctCode="";
        string CtCodeCon="";
        string CtCodeCon_remComma="";
        DataTable dt = (DataTable)Session["dthold"];
        //  dt.Rows[0].Delete();
        foreach (int i in lstCityCode.GetSelectedIndices())    // values store in listbox
        {
            if (lstCityCode.Items[i].Selected)
            {
                ctCode = lstCityCode.Items[i].Value + ",";
                CtCodeCon = CtCodeCon + ctCode;


            }

        }
        CtCodeCon_remComma = CtCodeCon.Substring(0, CtCodeCon.LastIndexOf(','));
        foreach (DataRow rw in dt.Rows)
        {
            con = new SqlConnection(strCon);
            try
            {
                con.Open();
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand("[Cpp_QtrBonusInsert]", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@StartValue", SqlDbType.Decimal).Value = Convert.ToDecimal(rw["startvalue"].ToString());
                com.Parameters.Add("@EndValue", SqlDbType.Decimal).Value = Convert.ToDecimal(rw["endvalue"].ToString());
                com.Parameters.Add("@startDate", SqlDbType.DateTime).Value = FormatDateMM(txtValidFrom.Text);
                com.Parameters.Add("@EndDate", SqlDbType.DateTime).Value = FormatDateMM(txtValidTo.Text);
                com.Parameters.Add("@Factor", SqlDbType.Decimal).Value = Convert.ToDecimal(rw["factor"].ToString())/100;
                com.Parameters.Add("@Membership", SqlDbType.VarChar).Value = rw["Membership"].ToString();
                com.Parameters.Add("@City", SqlDbType.VarChar).Value = CtCodeCon_remComma;
                com.ExecuteNonQuery();
                con.Close();
                com.Connection.Close();
            }
            catch (SqlException sqlex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Error');</script>");
                string ss = sqlex.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        }
        Response.Redirect("CppBrowse_QtrBonus.aspx?startDate=s&enddate=e");
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void grdCpp_QtrBonus_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCpp_QtrBonus.EditIndex = -1;
        grdCpp_QtrBonus.DataSource = (DataTable)Session["dthold"];
        grdCpp_QtrBonus.DataBind();
    }
    protected void grdCpp_QtrBonus_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {

                DataTable dt = (DataTable)Session["dthold"];
                if (dt.Rows[0][0].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }

                string str_startvalue = ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtstartvalue")).Text;
                string str_endvalue = ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtendvalue")).Text;
                string factorValue = ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtFactor")).Text;
                string MembershipValue = ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtMemberShip")).Text;
                bool Flag = false;
                foreach (DataRow rw in dt.Rows)
                {
                    string p = rw["Endvalue"].ToString();
                    ViewState["p"] = rw["Endvalue"].ToString();
                    if (Convert.ToDecimal(str_startvalue.Trim().ToString()) != 0 && Convert.ToDecimal(p.Trim().ToString()) != 0)
                    {
                        if (Convert.ToDecimal(str_startvalue.Trim().ToString()) <= Convert.ToDecimal(p.Trim().ToString()))
                        {
                            Flag = true;
                        }
                    }
                }
                if (Flag == false)
                {
                    DataRow dr = dt.NewRow();
                    dr[1] = str_startvalue;
                    dr[2] = str_endvalue;
                    dr[3] = factorValue;
                    dr[4] = MembershipValue;

                    dt.Rows.Add(dr);
                    Session["dthold"] = dt;
                    grdCpp_QtrBonus.DataSource = (DataTable)Session["dthold"];
                    grdCpp_QtrBonus.DataBind();
                    for (int i = 0; i < grdCpp_QtrBonus.Rows.Count - 1; i++)
                    {
                        ((LinkButton)(grdCpp_QtrBonus.Rows[i].FindControl("LinkButtonEdit"))).Visible = false;
                        ((LinkButton)(grdCpp_QtrBonus.Rows[i].FindControl("LinkButtonDelete"))).Visible = false;
                    }
                    ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(str_endvalue)));
                    CppQtrBonusShow.Visible = false;
                    ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtendvalue")).Focus();
                }
                else
                {
                    CppQtrBonusShow.Visible = true;
                    CppQtrBonusShow.Text = "The Start value always be greater than end value of previous slab";
                    ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(str_endvalue)));
                    ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtendvalue")).Text = "";
                    ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtFactor")).Text = "";
                    ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtMemberShip")).Text = "";
                    ((TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtendvalue")).Focus();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Please enter details " + "');</script>");
            }
        }
    }
    protected void grdCpp_QtrBonus_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.Exception != null)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + e.Exception.Message.ToString().Replace("'", "") + "');</script>");
            e.ExceptionHandled = true;
        }
    }
    protected void grdCpp_QtrBonus_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        GridViewRow row1 = grdCpp_QtrBonus.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["dthold"];
        DataRow[] drp;
        drp = dt.Select("sno =  '" + ((Label)row1.FindControl("lblsno")).Text + "'");
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                    row.Delete();
            }
        }
        Session["dthold"] = dt;
        if (dt.Rows.Count == 0)
        {
            Session["dthold"] = maketable();
            grdCpp_QtrBonus.DataSource = (DataTable)Session["dthold"];
            grdCpp_QtrBonus.DataBind();
            grdCpp_QtrBonus.Rows[0].Visible = false;
        }
        else
        {
            grdCpp_QtrBonus.DataSource = (DataTable)Session["dthold"];
            grdCpp_QtrBonus.DataBind();

        }
        ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[0].FindControl("txtStartvalue")).Focus();

    }
    protected void grdCpp_QtrBonus_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdCpp_QtrBonus.EditIndex = e.NewEditIndex;
        grdCpp_QtrBonus.DataSource = (DataTable)Session["dthold"];
        grdCpp_QtrBonus.DataBind();


    }
    protected void grdCpp_QtrBonus_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        //Check if there is any exception while deleting
        if (e.Exception != null)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + e.Exception.Message.ToString().Replace("'", "") + "');</script>");
            e.ExceptionHandled = true;
        }
    }
    protected void grdCpp_QtrBonus_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row1 = grdCpp_QtrBonus.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["dthold"];
        DataRow[] drp;
        drp = dt.Select("Sno =  '" + ((Label)row1.FindControl("lblSno")).Text + "'");

        string h = "";
        h = ((TextBox)row1.FindControl("txtStartvalue")).Text;
        bool Flag = false;
        string p = "";
        for (int i = 0; i < dt.Rows.Count - 1; i++)
        {
            DataRow rw = dt.Rows[i];
            p = rw["endValue"].ToString();
            if (Convert.ToDecimal(h.Trim().ToString()) <= Convert.ToDecimal(p.Trim().ToString()))
            {
                Flag = true;
                ViewState["p"] = rw["endValue"].ToString();

            }
        }
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                {
                    row.BeginEdit();
                    row[1] = ((TextBox)row1.FindControl("txtStartvalue")).Text;
                    row[2] = ((TextBox)row1.FindControl("txtEndvalue")).Text;
                    row[3] = ((TextBox)row1.FindControl("txtfactor")).Text;
                    row[4] = ((TextBox)row1.FindControl("txtmembership")).Text;
                    ViewState["end_value"] = row[2].ToString();

                    if (row[1].ToString() == "") break;
                    if (row[2].ToString() == "") break;
                    if (row[3].ToString() == "") break;
                    if (row[4].ToString() == "") break;
                    row.EndEdit();
                }
            }
        }

        if (Flag == false)
        {
            grdCpp_QtrBonus.EditIndex = -1;
            grdCpp_QtrBonus.DataSource = (DataTable)Session["dthold"];
            grdCpp_QtrBonus.DataBind();
            ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[0].FindControl("txtStartValue")).Focus();
            ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[0].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["end_value"].ToString())));
            CppQtrBonusShow.Visible = false;
        }
        else
        {
            CppQtrBonusShow.Visible = true;
            CppQtrBonusShow.Text = "The Start value always be greater than end value of previous slab";
            ((TextBox)row1.FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["p"].ToString())));
        }
    }
    protected void grdCpp_QtrBonus_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        grdCpp_QtrBonus.Columns[0].Visible = false;
        //Check if this is our Blank Row being databound, if so make the row invisible
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            for (int i = 0; i < grdCpp_QtrBonus.Rows.Count; i++)
            {
                ((LinkButton)(grdCpp_QtrBonus.Rows[i].FindControl("LinkButtonEdit"))).Visible = false;
                ((LinkButton)(grdCpp_QtrBonus.Rows[i].FindControl("LinkButtonDelete"))).Visible = false;
            }
            if (((DataRowView)e.Row.DataItem)["Sno"].ToString() == String.Empty) e.Row.Visible = false;

            if (grdCpp_QtrBonus.EditIndex == e.Row.RowIndex)
            {
                TextBox Start_Value = (TextBox)e.Row.FindControl("txtStartValue");
                TextBox end_value = (TextBox)e.Row.FindControl("txtEndValue");
                TextBox factor_value = (TextBox)e.Row.FindControl("txtfactor");
                 TextBox membership_value = (TextBox)e.Row.FindControl("txtMemberShip");

                string kk = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Sno"].ToString();
                if (Session["dthold"] != null)
                {
                    ViewState["Estartvalue"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["StartValue"].ToString();
                    ViewState["Eendvalue"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["EndValue"].ToString();
                    ViewState["Efactor"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Factor"].ToString();
                    ViewState["EMemberShip"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["MemberShip"].ToString();

                    if (((DataTable)Session["dthold"]).Rows[0][0].ToString() == "0" || ((DataTable)Session["dthold"]).Rows.Count.ToString() == "1")
                    {
                        Start_Value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["StartValue"].ToString();
                        Start_Value.ReadOnly = true;

                    }
                    else
                    {
                        Start_Value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["StartValue"].ToString();
                    }
                    end_value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["EndValue"].ToString();
                    factor_value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["factor"].ToString();
                    membership_value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["membership"].ToString();


                    ((TextBox)grdCpp_QtrBonus.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["Eendvalue"])));

                }
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        DataTable dt = (DataTable)Session["dthold"];
        if (dt.Rows.Count == 1)
        {
            if (dt.Rows[0][0].ToString() == "0")
            {
                CppQtrBonusShow.Visible = true;
                CppQtrBonusShow.Text = "Pls Add at least One Row";
            }
            else
           {

                    ADDDATA();
                    CppQtrBonusShow.Visible = false;
            }
        }

        else
            {
                string ctCode = "";
                string CtCodeCon = "";
                foreach (int i in lstCityCode.GetSelectedIndices())    // values store in listbox
                {
                    if (lstCityCode.Items[i].Selected)
                    {
                         ctCode = lstCityCode.Items[i].Value + ",";
                         CtCodeCon = CtCodeCon + ctCode;


                    }

                }
                DataTable dtDetails = dw.GetAllFromQuery("select * from CPP_QtrBonus where city in ('" + CtCodeCon + "') and startDate='" + FormatDateMM(txtValidFrom.Text) + "' and EndDate='" + FormatDateMM(txtValidTo.Text) + "' order by startvalue");
                if (dtDetails.Rows.Count > 0)
                {
                    CppQtrBonusShow.Visible = false;
                    CppQtrBonusShow.Text = "Records Already exists of this city in this period";
                }
                else
                {
                    ADDDATA();
                    CppQtrBonusShow.Visible = false;
                }
            }
        
    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CppBrowse_QtrBonus.aspx");
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["StartDate"].ToString().Trim() != "" && Request.QueryString["EndDate"].ToString().Trim() != "")
       
        {
            DeleteRecords();
        }
        DataTable dt = (DataTable)Session["dthold"];
        if (dt.Rows.Count == 1)
        {
            if (dt.Rows[0][1].ToString() == "0")
            {
                CppQtrBonusShow.Visible = true;
                CppQtrBonusShow.Text = "Pls Add at least One Row";
            }
            else
            {
                ADDDATA();
                CppQtrBonusShow.Visible = false;
            }
        }
        else
        {
            ADDDATA();
            CppQtrBonusShow.Visible = false;
        }
    }
    protected void linkAddOrder_Click(object sender, EventArgs e)
    {

    }
    private void fillCity()
    {
        con = new SqlConnection(strCon);
        try
        {

            string strQuery = "";
            strQuery = " select City_Code,City_id from  City_master order by City_code";
            con.Open();
            com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            lstCityCode.Items.Clear();
            lstCityCode.Items.Insert(0, "ALL");
            lstCityCode.Items[0].Value = "0";
            //lstCityCode.Items[0].Attributes.CssStyle = "boldtext";
            //lstCityCode.Items[0].Selected = true;
            while (dr.Read())
            {

                lstCityCode.Items.Add(new ListItem(dr["City_Code"].ToString(), dr["City_id"].ToString()));


            }
            //lstCityCode.Enabled = false;
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
    protected void grdCpp_QtrBonus_PreRender(object sender, EventArgs e)
    {
        DataTable dt = (DataTable)Session["dthold"];
        if (dt.Rows[0][0].ToString() == "0")
        {
            chkGridValue.Value = "0"; ;
        }
        else
            chkGridValue.Value = "1";
        ClientScriptManager cs = Page.ClientScript;
        TextBox txtStValue = (TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtStartvalue");
        TextBox txtenValue = (TextBox)grdCpp_QtrBonus.FooterRow.FindControl("txtEndValue");
        cs.RegisterArrayDeclaration("grd_startvalueFooter", String.Concat("'", txtStValue.ClientID, "'"));
        cs.RegisterArrayDeclaration("grd_endvalueFooter", String.Concat("'", txtenValue.ClientID, "'"));
    }
}