using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Issue_Can_Print : System.Web.UI.Page
{
     // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    string Import_AWB_ID;
    string Import_AWB_No;
    string Import_Origin;
    string No_of_Packages;
    string Gross_Weight;
    string Import_Flight_No;
    string Flight_Date;
    string IGM_No;
    string IGM_Date;
    string Import_Flight_Open_ID, Import_destination, Freight_Type, Charged_Weight;
    string Nature_of_Goods, comAdd, comName, Concerned_Person, Agent_Name, Agent_Address;
    string AID, Delivery_order_no;
    string table = null;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            if (Request.QueryString["Import_AWB_ID"] != null)
            {
                Import_AWB_ID = Convert.ToString(Request.QueryString["Import_AWB_ID"]);
                AID = Convert.ToString(Request.QueryString[1]);
             
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand("select * from company_master where company_id=(select company_id from airline_detail where airline_detail_id=" + AID + " )", con);
                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    comAdd = dr["company_address"].ToString();
                    comName = dr["company_name"].ToString();


                    table += @"<table width=""100%""><tr class=""boldtext"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td> <td width=""70%"" align=""left"" nowrap><p align=""center"" class=""boldtext""><font size=""3"">" + dr["company_name"].ToString().ToUpper() + @"</font><br><font size=""2"">" + dr["Company_Address"].ToString() + @"<br> Ph :" + dr["Phone"].ToString() + @"<br></font><br></p></td><tr> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td>
</tr><tr class=text><td align=center colspan=3><font size=2><B>CARGO ARRIVAL NOTICE CUM INVOICE</b></font>&nbsp;&nbsp;&nbsp;&nbsp;<font size=4><b></b></font></td></tr><tr class=text><td colspan=3><font size=2>Dear Sir/Madam,<br>We are pleased to announce the arrival of the following shipment under our consolidation service which has been deposited with customs at DELHI Airport.</font> </td></tr><tr> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr>";
                }
                com.Dispose();
                dr.Dispose();

                string str1 = "select IFO.Import_Flight_Open_ID as 'Import_Flight_Open_ID',IA.Freight_Type as 'Freight_Type',IA.Import_AWB_No as 'Import_AWB_No',IA.Agent_Name as 'Agent_Name',IA.Agent_Address as 'Agent_Address',DM.Destination_Code as 'Destination_Code',cm.city_Code as 'city_Code',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight',IA.Charged_Weight as 'Charged_Weight',IFO.Import_Flight_No as'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IFO.IGM_No as 'IGM_No',convert(varchar,IFO.IGM_Date,103) as 'IGM_Date',IA.Nature_of_Goods as 'Nature_of_Goods',IA.CAN_Status as 'CAN_Status',IA.Delivery_Order as 'Delivery_Order',IA.No_of_Houses as 'No_of_Houses',IA.Freight_Type as 'Freight_Type',IA.Delivery_Order_Rate_House as 'Delivery_Order_Rate_House',IA.Delivery_Order_Rate_Master as 'Delivery_Order_Rate_Master',IA.Concerned_Person as 'Concerned_Person' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID inner join Destination_Master DM on IFO.Import_Origin=DM.Destination_ID inner join city_master cm on cm.city_id=IFO.Import_Destination  where IA.Import_AWB_ID='" + Import_AWB_ID + "'";
          
                com = new SqlCommand(str1, con);
                dr = com.ExecuteReader();
               dr.Read();

                Import_AWB_No = dr["Import_AWB_No"].ToString();
                Import_Origin = dr["Destination_Code"].ToString();
                Agent_Name = dr["Agent_Name"].ToString();
                Agent_Address = dr["Agent_Address"].ToString();
                Import_destination = dr["city_Code"].ToString();
                Freight_Type = dr["Freight_Type"].ToString();
                No_of_Packages = dr["No_of_Packages"].ToString();
                Gross_Weight = dr["Gross_Weight"].ToString();
                Charged_Weight = dr["Charged_Weight"].ToString();
                Import_Flight_No = dr["Import_Flight_No"].ToString();
                Flight_Date = dr["Flight_Date"].ToString();
                IGM_No = dr["IGM_No"].ToString();
                IGM_Date = dr["IGM_Date"].ToString();
                Nature_of_Goods = dr["Nature_of_Goods"].ToString();
                Import_Flight_Open_ID = dr["Import_Flight_Open_ID"].ToString(); 
                 Concerned_Person = dr["Concerned_Person"].ToString();
                //Delivery_order_no =dr["Delivery_order_no"].ToString();
               
                dr.Close();
                table += @"<tr class=text><td width=60%><font size=2><b>" + Agent_Name + @"</b><br>" + Agent_Address + @"</font></td><td valign=top><table width=100% class=text><tr><td>Invoice No.</td><td><font size=2><b>aa</b></font></td> </tr><tr><td>Invoice Date.</td><td>" + DateTime.Now.ToString("dd/MM/yyyy") + @"</td> </tr></table></td></tr><tr> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr><tr> <td colspan=13><table width=100% cellspacing=0><tr class=text><td width=20%>AWB Number </td><td width=40%>" + Import_AWB_No + @" Dated " + Flight_Date + @"</td><td width=20%>HAWB Number</td><td width=20%>aa</td></tr><tr class=text><td>Consignee</td><td>" + Agent_Name + @"</td><td>Packages/Weight</td><td>" + No_of_Packages + @" / " + Charged_Weight + @" kg</td></tr><tr class=text><td>Flight No.</td><td>" + Import_Flight_No + @"</td><td valign=top>Flight Dt.</td><td>" + Flight_Date + @"</td></tr><tr class=text></tr><tr class=text><td>Origin</td><td>" + Import_Origin + @"</td><td>Destination</td><td>" + Import_destination + @"</td></tr><tr class=text><td>Commodity</td><td>" + Nature_of_Goods + @"</td><td>IGM Date.</td><td>" + IGM_Date + @"</td></tr><tr class=text></tr><tr class=text><td>Freight Type</td><td>" + Freight_Type + @"</td></tr></table></td></tr><tr class=text> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr><tr><td colspan=2  valign=top><table width=100%><tr><td  valign=top colspan=5 height=275 cellpadding=0 cellspacing=0><table width=100% cellpadding=2 cellspacing=0 border=0>
<tr><td colspan=5 height=1></td> </tr><tr class=text><td>&nbsp;</td>
<td align=right><b>Total:</td><td align=right>	0.00</td><td width=1%>&nbsp;</td><td align=right>&nbsp;</td></tr><tr class=text><td>&nbsp;</td><td align=right>Net Amount:</td><td align=right>0.00</td><td width=1%>&nbsp;</td>
<td align=right>&nbsp;</td></tr><tr> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr><tr class=text><td>&nbsp;</td><td align=right valign=top><font size=2>Total Amount Due: <b>INR</b></font></td><td align=right>&nbsp;</td><td width=1%>&nbsp;</td><td align=right><font size=2><b>0.00</b></font></td></tr><tr align=""right""><td></td><td></td><td></td><td></td> <td colspan=""13"" align=""right""><img src=""images/line2.gif"" width=""100%"" height=""2""></td></tr><tr class=text><td  valign=top colspan=5><br><font size=1>Your consignment as per above mentioned details has arrived at MUMBAI and is being deposited with AIR CARGO COMPLEX.<br>Delivery Order will be issued on production of this notice along with relevant documents & payment of charges as indicated above, between 10:30 to 1300 hrs and 14:00 to 17:00 hrs on all working days except on second Saturdays  and holidays.
<ol><b>VERY IMPORTANT:-</b><li>Please produce Bank Release Order if the consignment is through Bank, on their original letterhead only.<li>Charges Collect Shipment - If import under negative list, produce freight certificate from your banker. In respect of items not apppearing under negative list of Import Export Policy, please submit declaration on your company letter head to that effect.<li>Freight amount is submitted to changes as per fluctuation in Bank exchange rate.<li>Cargo has been checked while issuing notice. Please ensure to check with us for any shipment or shortlanding before filling Bill Of Entry with Customs.<li>Kindly produce Letter of Authority for collection, documents and Delivery Order.For baggage paasport will be required.<li>For further Terms/conditions please see overleaf.</ol></font></td></tr><tr class=text><td colspan=6><table border=0 width=100%><tr class=text><td width=50% valign=top><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><u>Remark</u></b><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please Collect D/O and Documents against Cash/Pay Order Only.</td><td valign=top align=right class=text><br><b>For " + comName + @"<br><br><br>
Authorised Signatory</td> </tr></table></td></tr></table></td></tr></table> </td></tr></table>";
                Label1.Text = table;
            }
       
        }

    }
}
