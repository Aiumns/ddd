using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Change_Flight_Handover : System.Web.UI.Page
{
    SqlConnection con = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    int HANDOVER_ID ;
    int FLIGHT_OPEN_ID ;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {

            Label3.Visible = false;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search();
    }

    private void Search()
    {
        string flightDate = "";
        string Data = "";
        string airline = "";
        DataTable dt = dw.GetAllFromQuery("select HANDOVER_ID, FM.AIRLINE_DETAIL_ID ,AirWayBill_No,convert(varchar,H.flight_date,103) as Flight_Date,FLIGHT_NO,DESTINATION_CODE,Charged_Weight from HANDOVER H INNER JOIN STOCK_MASTER SM ON H.STOCK_ID=SM.STOCK_ID INNER JOIN FLIGHT_OPEN FO ON FO.FLIGHT_OPEN_ID=H.FLIGHT_OPEN_ID INNER JOIN FLIGHT_MASTER FM ON FO.FLIGHT_ID=FM.FLIGHT_ID INNER JOIN DESTINATION_MASTER D ON H.DESTINATION_ID=D.DESTINATION_ID where AirWayBill_No='" + txtawb.Text.Trim() + "'");
        if (dt.Rows.Count > 0)
        {
            Data = "<Table align=center width=70%><tr class=h1><td>Awb No.</td><td>Dstn.</td><td>Ch.Wt.</td><td>Current Flight No.</td><td>Current Flight Date.</td></tr>";
            foreach (DataRow drow in dt.Rows)
            {
                Data += "<tr><td>" + drow["AirWayBill_No"].ToString() + "</td><td>" + drow["destination_code"].ToString() + "</td><td>" + drow["Charged_Weight"].ToString() + "</td><td>" + drow["flight_no"].ToString() + "</td><td>" + drow["flight_date"].ToString() + "</td></tr>";
                flightDate = drow["flight_date"].ToString();
                airline = drow["airline_detail_id"].ToString();
                Hdn_Hand.Value = drow["HANDOVER_ID"].ToString();
               
            }
            Data += "<tr><td></td><td></td><td></td><td></td><td></td></tr></table>";
            Label2.Text = Data;

            DataTable dt2 = dw.GetAllFromQuery("select Flight_no+'-'+convert(varchar,flight_date,103) as flight_date,FLIGHT_open_ID from Flight_Open inner join flight_master on Flight_Open.flight_id=flight_master.flight_id where flight_date between Convert(datetime,'" + FormatDateMM(flightDate) + "')-15 and Convert(datetime,'" + FormatDateMM(flightDate) + "')+15 and airline_detail_id=" + Convert.ToInt64(airline) + "");
            ddlflight.Items.Clear();
            foreach (DataRow Drow in dt2.Rows)
            {
                ddlflight.Items.Add(new ListItem(Drow["flight_date"].ToString(), Drow["FLIGHT_open_ID"].ToString()));

            }
            Label3.Visible = false;
            Panel1.Visible = true;

        }
        else
        {
            Label3.Visible = false;
            Panel1.Visible = false;
            Label2.Text = "";
            Label2.Text = "No Record Found";
            Label2.CssClass = "error";
            Label2.Visible = true;
            Label3.Visible = false;

        }
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string[] flight_date_no = ddlflight.SelectedItem.Text.Split('-');

        con = new SqlConnection(strCon);
        con.Open();
        FLIGHT_OPEN_ID =Convert.ToInt32(ddlflight.SelectedItem.Value);
        HANDOVER_ID = Convert.ToInt32(Hdn_Hand.Value);
        try
        {

            SqlCommand strcom = new SqlCommand("CHANGE_FLIGHT_AFTER_HANDOVER", con);
            strcom.CommandType = CommandType.StoredProcedure;

            strcom.Parameters.AddWithValue("@FLIGHT_OPEN_ID", FLIGHT_OPEN_ID);
            strcom.Parameters.AddWithValue("@FLIGHT_DATE", FormatDateMM(flight_date_no[2]));
            strcom.Parameters.AddWithValue("@HANDOVER_ID", HANDOVER_ID);
            strcom.ExecuteNonQuery();
            Label3.Visible = true;
            Panel1.Visible = false;
            Label2.Text = "";  
        }
        catch (Exception)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }

    }
}
