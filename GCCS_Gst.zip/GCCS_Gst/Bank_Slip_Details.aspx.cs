using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Bank_Slip_Details : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    DisplayWrap dw = new DisplayWrap();
    DataTable dt;
    string Airline_Detail_ID;
    string Cheque_Deposit_Date;
    string Acc_Type;
    string check_type;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {

                //Getting Query String Value
                Airline_Detail_ID = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "AId");
                //Getting Query String Value
                Acc_Type = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "Acc_Type");
                check_type = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "check_type");
                if (check_type == "13")
                {
                    lblhighval.Text = "High Value";
                }

                lbldate.Text = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "C_Date");

                Cheque_Deposit_Date = lbldate.Text;
                string Airline_Access = Session["AIRLINEACCESS"].ToString();
                if (Acc_Type == "A_Acc")
                {
                    //dt = dw.GetAllFromQuery("  SELECT Acc_Name,Acc_No,Bank_Name,Bank_Address FROM Airline_Detail  where Airline_Detail_ID in" + "(" + Airline_Access + ")  AND Acc_Name<>'' order by  Acc_Name");
                    dt = dw.GetAllFromQuery("  SELECT Acc_Name,Acc_No,Bank_Name,Bank_Address FROM Airline_Bank_Details  where  Airline_Detail_ID='" + Airline_Detail_ID + "' AND Acc_Name<>'' and '" + FormatDateDD(lbldate.Text) + "' between ValidFrom and ValidTo order by  Acc_Name");

                }
                else if (Acc_Type == "C_Acc")
                {
                   
                    dt = dw.GetAllFromQuery("SELECT Acc_Name,Acc_No,Bank_Name,Bank_Address FROM Company_Master  where  Company_ID='" + Airline_Detail_ID + "' AND Acc_Name<>'' order by  Acc_Name");
                }
                if (dt.Rows.Count > 0)
                {
                    lblBankName.Text = dt.Rows[0]["Bank_Name"].ToString();
                    lblbnkAdd.Text = dt.Rows[0]["Bank_Address"].ToString();
                    lblAccname.Text = dt.Rows[0]["Acc_Name"].ToString();
                    lblAccNo.Text = dt.Rows[0]["Acc_No"].ToString();

                }

                FillGrdDetails();
                //recordCount();
            }
        }


    }
    public void FillGrdDetails()
    {

        //DataTable dt = dw.GetAllFromQuery("SELECT A.Agent_Name,A.Cheque_No,convert(varchar,A.Cheque_Date,103) as Cheque_Date,A.Bank,A.Bank_Branch,A.Paid_Amount FROM Payment_Details A INNER JOIN Airline_Detail B ON A.Airline_Detail_ID=B.Airline_Detail_ID  WHERE A.Status=32 AND A.Airline_Detail_ID='" + Airline_Detail_ID + "' and Cheque_Deposit_Date='" + FormatDateDD(Cheque_Deposit_Date) + "' and High_Value='" + check_type + "' order by A.Total_Paid_Amount");
        DataTable dt_AIRLINE = dw.GetAllFromQuery(" SELECT DISTINCT Airline_Detail_ID,SUBSTRING(CSR_NO,10,3) AS Airline_Code FROM Payment_Details WHERE Status=32 AND Account_No='" + lblAccNo.Text + "' and Cheque_Deposit_Date='" + FormatDateDD(Cheque_Deposit_Date) + "' and High_Value='" + check_type + "' order by Airline_Detail_ID");
        if (dt_AIRLINE.Rows.Count > 0)
        {
            string Table = "";
            for (int i = 0; i < dt_AIRLINE.Rows.Count; i++)
            {
                DataTable dt = dw.GetAllFromQuery(" SELECT Agent_Name,Cheque_No,convert(varchar,Cheque_Date,103) as Cheque_Date,Bank,Bank_Branch,Paid_Amount FROM Payment_Details WHERE Airline_Detail_ID='" + dt_AIRLINE.Rows[i]["Airline_Detail_ID"].ToString() + "' AND Status=32 AND Account_No='" + lblAccNo.Text + "' and Cheque_Deposit_Date='" + FormatDateDD(Cheque_Deposit_Date) + "' and High_Value='" + check_type + "'  order by PAYMENT_DETAIL_ID");
               
                if (dt.Rows.Count > 0)
                {

                  
                        Table += @"<table border=1 cellspacing=0 align=center style=font-family:Verdana;font-size:small; width: 70%;>";
                        Table += @"<tr class=h5 >";
                        Table += @"<td align=left colspan=2 class=boldtext>" + lblBankName.Text + "</td>";
                        Table += @"<td align=left colspan=3 class=boldtext>(" + dt_AIRLINE.Rows[i]["Airline_Code"].ToString() + ")" + lblhighval.Text + "</td>";
                        Table += @"<td align=right  class=boldtext>DATED</td>";
                        Table += @"<td align=center  class=boldtext>" + lbldate.Text + "</td>";
                     
                        Table += @"</tr>";
                        Table += @"<tr class=h5  >";
                        Table += @"<td align=left colspan=2  class=boldtext>" + lblbnkAdd.Text + "</td>";
                        Table += @"<td align=center colspan=5 class=boldtext>&nbsp;</td>";
                      
                        Table += @"</tr>";

                        Table += @"<tr  >";
                        Table += @"<td align=center colspan=7 class=boldtext>&nbsp;</td>";                       
                        Table += @"</tr>";
                        Table += @"<tr >";
                        Table += @"<td align=left colspan=2 class=boldtext>FOR THE CREDIT OF</td>";
                        Table += @"<td align=center  class=boldtext>:</td>";
                        Table += @"<td align=left colspan=4 class=boldtext>" + lblAccname.Text + "</td>";
                      
                        Table += @"</tr>";

                        Table += @"<tr >";
                        Table += @"<td align=left colspan=2 class=boldtext>CURRENT ACCOUNT NO.</td>";
                        Table += @"<td align=center  class=boldtext>:</td>";
                        Table += @"<td align=left colspan=4 class=boldtext>" + lblAccNo.Text + "</td>";

                        Table += @"</tr>";
                        Table += @"<tr >";
                        Table += @"<td align=left colspan=2  class=boldtext>CHEQUES DETAIL</td>";
                        Table += @"<td align=center colspan=5 class=boldtext>&nbsp;</td>";
                        
                        Table += @"</tr>";

                        Table += @"<tr class=h5 >";
                        Table += @"<td align=center  class=boldtext>SNO.</td>";
                        Table += @"<td align=center  class=boldtext>ISSUED BY</td>";
                        Table += @"<td align=center  class=boldtext>CH.NO</td>";
                        Table += @"<td align=center class=boldtext>DATED</td>";
                        Table += @"<td align=center  class=boldtext>DRAWN ON</td>";
                        Table += @"<td align=center  class=boldtext>BRANCH</td>";
                        Table += @"<td align=center  class=boldtext>AMT(RS.)</td>";
                        Table += @"</tr>";
                        decimal amount = 0;
                        for (int j = 0; j < dt.Rows.Count; j++)
                        {
                            Table += @"<tr class=h5 >";
                            Table += @"<td align=left  class=text>" +(j+1)+ "</td>";
                            Table += @"<td align=left  class=text>" + dt.Rows[j]["Agent_Name"].ToString() + "</td>";
                            Table += @"<td align=center  class=text>" + dt.Rows[j]["Cheque_No"].ToString() + "</td>";
                            Table += @"<td align=left  class=text>" + dt.Rows[j]["Cheque_Date"].ToString() + "</td>";
                            Table += @"<td align=left  class=text>" + dt.Rows[j]["Bank"].ToString() + "</td>";
                            Table += @"<td align=LEFT  class=text>" + dt.Rows[j]["Bank_Branch"].ToString() + "</td>";
                            Table += @"<td align=right  class=text>" + dt.Rows[j]["Paid_Amount"].ToString() + "</td>";
                           
                            Table += @"</tr>";
                            amount = amount +decimal.Parse(dt.Rows[j]["Paid_Amount"].ToString());
                        }
                        Table += @"<tr class=h5 >";
                        Table += @"<td align=center  class=boldtext>&nbsp;</td>";
                        Table += @"<td align=center  class=boldtext>&nbsp;</td>";
                        Table += @"<td align=center  class=boldtext>&nbsp;</td>";
                        Table += @"<td align=center  class=boldtext>&nbsp;</td>";
                        Table += @"<td align=center  class=boldtext>&nbsp; </td>";
                        Table += @"<td align=center  class=boldtext>Total</td>";
                        Table += @"<td align=center  class=boldtext>" + amount + "</td>";
                        Table += @"</tr>";
                        Table += @"</table>";
                    //Grdbankslip.DataSource = dt;
                    //Grdbankslip.DataBind();
                    //recordCount();
                }
                
            }
            Label2.Text = Table;
        }
        else
        {
            string table2 = "";

            table2 += @"<table border=1 align=left style=font-family:Verdana;font-size:small; width: 70%;>";
            table2 += @"<tr class=h5 >";
            table2 += @"<td align=left  class=boldtext>" + lblBankName.Text + "</td>";
            table2 += @"<td align=left colspan=3 class=boldtext>" + lblhighval.Text + "</td>";
            table2 += @"<td align=right  class=boldtext>DATED</td>";
            table2 += @"<td align=center  class=boldtext>" + lbldate.Text + "</td>";

            table2 += @"</tr>";
            table2 += @"<tr class=h5  >";
            table2 += @"<td align=left  class=boldtext>" + lblbnkAdd.Text + "</td>";
            table2 += @"<td align=center colspan=5 class=boldtext>&nbsp;</td>";

            table2 += @"</tr>";

            table2 += @"<tr  >";
            table2 += @"<td align=center  class=boldtext>&nbsp;</td>";
            table2 += @"</tr>";
            table2 += @"<tr >";
            table2 += @"<td align=left  class=boldtext>FOR THE CREDIT OF</td>";
            table2 += @"<td align=center  class=boldtext>:</td>";
            table2 += @"<td align=left colspan=4 class=boldtext>" + lblAccname.Text + "</td>";

            table2 += @"</tr>";

            table2 += @"<tr colspan=6>";
            table2 += @"<td align=left  class=boldtext>CURRENT ACCOUNT NO.</td>";
            table2 += @"<td align=center  class=boldtext>:</td>";
            table2 += @"<td align=left colspan=4 class=boldtext>" + lblAccNo.Text + "</td>";

            table2 += @"</tr>";
            table2 += @"<tr  >";
            table2 += @"<td align=left   class=boldtext>CHEQUES DETAIL</td>";
            table2 += @"<td align=center colspan=5 class=boldtext>&nbsp;</td>";

            table2 += @"</tr>";
            table2 += @"</table>";
            Label2.Text = table2;

        }


      


      
    }

    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    //private void recordCount()
    //{

    //    decimal sum1 = 0;



    //    for (int i = 0; i < Grdbankslip.Rows.Count; i++)
    //    {
    //        GridViewRow gr = Grdbankslip.Rows[i];


    //        sum1 = sum1 + decimal.Parse(((Label)(gr.FindControl("lblamt"))).Text);



    //        ((Label)(Grdbankslip.FooterRow.FindControl("lblTotalamt"))).Text = sum1.ToString();



    //    }




    //}
}
