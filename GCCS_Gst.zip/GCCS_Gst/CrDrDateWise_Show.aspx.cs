using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CrDrDateWise_Show : System.Web.UI.Page
{
    public string page_pop = "";
    string agentName = null, lastTsdsRate = "0";
    string lastSurcharge = "0";
    string tableAll = null, comName = null;
    string massage = null;

    string city_id = null;

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    string csr_detail_id = "", sales_id = "";
    DisplayWrap dw = new DisplayWrap();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {

            Response.Redirect("../Login.aspx");
        }
        string[] airline_name_city_text = Session["airline_name"].ToString().Split('-');
        string airline_name_city_value = Session["airline_value"].ToString();
        string[] agent_selected_id = Session["Agent_List_value"].ToString().Split('~');
        string[] agent_selected_name = Session["Agent_list_Text"].ToString().Split('~');
        string StartDate = ConvertDate1(Session["StartDate"].ToString());
        string EndDate = ConvertDate1(Session["EndDate"].ToString());
        string StartDate_fnt = Session["StartDate_fortnight"].ToString();
        string EndDate_fnt = Session["EndDate_fortnight"].ToString();
        string csrFooter = Session["csr_footer"].ToString();
        string comAdd = null;
        string airline = "A/C " + airline_name_city_text[0].ToUpper().ToString();
        string agnetID = "";
        string approveCsr = checkApprove(StartDate, EndDate);


        if (Session["groupid"].ToString() != "5")
        {

            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //if (agent_selected_id.i.Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal total_TotTdsss = 0;
                decimal total_EduCh_show = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;

                string table = null, table1 = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                string sales_t = "";

                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "'  and  '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";
                }
                else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                {
                    if (StartDate == "04/1/2008" && EndDate == "04/15/2008")
                    {
                        sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (CSR_DATE between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (CSR_DATE between '" + StartDate_fnt + "'  and  '" + EndDate_fnt + "')  and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";

                    }
                    else
                    {
                        sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "'  and  '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "')  and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "')  and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";
                    }

                }
                else
                {
                    sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (CSR_DATE between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + "  and  (CSR_DATE between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";
                }

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (Session["chkstatus"].ToString() == "Y")
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td><td class=boldtext>No: " + csrso + "</td></tr></table><br>";
                        }

                        else
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table><br>";
                        };
                    }
                    com.Dispose();
                    dr.Dispose();
                    table += @"<table align=center style=""word-spacing:inherit"" width=""95%""
 border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th><th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >TDS</th><th rowspan=""2"" >EDU</th><th rowspan=""2"" >Remark</th></tr><tr><th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr><tr><td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td>
</tr>";

                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        com = new SqlCommand("CrDrDateWise_China", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (StartDate == "04/1/2008" && EndDate == "04/15/2008")
                        {
                            com = new SqlCommand("CrDrDateWise", con);

                        }
                        else
                        {
                            com = new SqlCommand("CrDrDateWise_China", con);
                        }

                    }
                    else
                    {
                        com = new SqlCommand("CrDrDateWise", con);
                    }


                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(StartDate));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(EndDate));
                    com.Parameters.AddWithValue("FROM_DATEFnt", DateTime.Parse(StartDate_fnt));
                    com.Parameters.AddWithValue("TO_DATEFnt", DateTime.Parse(EndDate_fnt));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    //dt.Load(dr);
                    while (dr.Read())
                    {
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            discount = Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                        // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));

                        decimal EduCh_show = Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            TotTdsss = -Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            // EduChrg -= Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduCh_show = -(Math.Round((Math.Ceiling(Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()))) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero));
                            EduChrg -= Math.Round((Math.Ceiling(Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()))) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                            // EduChrg += Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduCh_show = +(Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero));
                            EduChrg += Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }
                        total_TotTdsss = total_TotTdsss + TotTdsss;
                        total_EduCh_show = total_EduCh_show + EduCh_show;


                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        //string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        //if (rdbtn == "No")
                        //{
                        string remarks = "";
                        //}
                        //else
                        //{
                        //    remarks = remarks;
                        //}
                        if (Session["chkstatus"].ToString() == "Y")
                        {
                            table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + (discount) + @"</td><td align=""right"">" +Math.Ceiling(TotTdsss) + @"</td><td align=""right"">" + EduCh_show + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + " , " + dr["entered_on"].ToString() + " , " + dr["approved_for_csr"].ToString() + @"</td></tr>";
                        }
                        else
                        {
                            table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + (discount) + @"</td><td align=""right"">" + Math.Ceiling(TotTdsss) + @"</td><td align=""right"">" + EduCh_show + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + "</td></tr>";
                        }

                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""13"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""2""></td></tr>";

                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    table += @"<tr ><td colspan=""13"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Ceiling(total_TotTdsss)+ @"</td><td align=""right"">" + Math.Round(total_EduCh_show, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    table += @"<tr class=""boldtext""> <td colspan=""13"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
                    table += @"<tr class=""boldtext""><td colspan=""11"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";
                    //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""11"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""8"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Math.Abs(Total)) + @"</strong></th></tr>";
                    string strt = "";
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)) < 0)
                    {
                        strt = "Less";
                    }
                    else
                    {
                        strt = "Add";
                    }

                    table += @"<tr class=""boldtext""><td colspan=""11"" align=""right""><strong>" + strt + " TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""4"" align=""right""><strong>" + Math.Ceiling(TotTds)+ @"</strong></td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td colspan=""11"" align=""right""><strong>" + strt + " SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""11"" align=""right""><strong>" + strt + @" EDUCATIONAL CESS</strong></td><td colspan=""4"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                    table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""4"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";
                        sales_t = "Credit";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        sales_t = "Debit";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge));
                    }

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        comName = dr["company_name"].ToString();

                        table1 += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p align=""center"" class=""text"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""3"">" + dr["Company_Address"].ToString() + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""2"" class=""heading"">" + sales_t.ToString() + @" Note</font></p></td></tr></table><br>";

                    }
                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr class=""boldtext""><th colspan=""11"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""4"" align=""right"">INR &nbsp;" + font + GrandTotal + @"</font></td></tr>";

                    table += @"<tr align=""left"" class=""text""> <td colspan=""11"">&nbsp;</td> <td colspan=""4"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""13"" nowrap ><hr><font size=1>" + csrFooter + @"</font></td></tr><tr><td colspan=""13"" nowrap class=text align=left>ModPrd between " + ConvertDate2(StartDate) + @"-" + ConvertDate2(EndDate) + @".<br><br></td></tr></table><br style=""page-break-before:always;"">";

                }
                if (GrandTotal > 0)
                    tableAll = tableAll + (table1 + table);
                Label1.Text = tableAll;

                //}

            }

            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(StartDate) + " To " + ConvertDate1(EndDate) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;

        }
        else if (approveCsr == "notApprove")
        {

            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //if (lstAgent.Items[k].Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal GrandTotal = 0;

                string table = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                com = new SqlCommand("select agent_id from sales where agent_id=" + agnetID + " and (AWB_Date between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " ", con);

                dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    com.Dispose();
                    dr.Dispose();


                    table += @"<p><font color=""red"" size=""2""> The CSR not Generated for selected period  " + ConvertDate1(StartDate) + " To " + ConvertDate1(EndDate) + @".</font><br> The following AWB No are in this period:</p>";
                    table += @"<table width=""650px"" border=""0""><tr class=""h1""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"">Freight</th><th rowspan=""2"">Due Carrier</th><th rowspan=""2"">Agent Expenses</th></tr><tr class=""h1"">  <th>PP</th >  <th >CC</th> </tr><tr class=""h1""> <td colspan=""11"" align=""center""  class=""h1""> </td></tr>";

                    //com = new SqlCommand("CrDrDateWise", con);
                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        com = new SqlCommand("CrDrDateWise_China", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (StartDate == "04/1/2008" && EndDate == "04/15/2008")
                        {
                            com = new SqlCommand("CrDrDateWise", con);

                        }
                        else
                        {
                            com = new SqlCommand("CrDrDateWise_China", con);
                        }

                    }
                    else
                    {
                        com = new SqlCommand("CrDrDateWise", con);
                    }

                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(StartDate));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(EndDate));
                    com.Parameters.AddWithValue("FROM_DATEFnt", DateTime.Parse(StartDate_fnt));
                    com.Parameters.AddWithValue("TO_DATEFnt", DateTime.Parse(EndDate_fnt));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();


                    while (dr.Read())
                    {

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += decimal.Parse(dr["Total_DueCarrier"].ToString());
                        TotTax += decimal.Parse(dr["Tax"].ToString());
                        TotAgentExp += decimal.Parse(dr["TotalDueAgent_Collect"].ToString());

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += decimal.Parse(amountCC);

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += decimal.Parse(amountPP);
                        }
                        //string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        //if (rdbtn == "no")
                        string remarks = "";


                        table += @"<tr class=""text""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap>" + dr["AirWayBill_No"].ToString() + @"</td><td>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Charged_Weight"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero) + @"</td></tr>";

                    }
                    table += @"</table>";
                    com.Dispose();
                    dr.Dispose();

                }
                tableAll = tableAll + table;
                Label1.Text = tableAll;
                //}

            }

            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(StartDate) + " To " + ConvertDate1(EndDate) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;


        }
        else
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //if (agent_selected_id.i.Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;

                string table = null, table1 = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                string sales_t = "";
                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "'  and  '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";
                }
                else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                {
                    if (StartDate == "04/1/2008" && EndDate == "04/15/2008")
                    {
                        sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (CSR_DATE between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (CSR_DATE between '" + StartDate_fnt + "'  and  '" + EndDate_fnt + "')  and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";

                    }
                    else
                    {
                        sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "'  and  '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "')  and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "')  and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";
                    }

                }
                else
                {
                    sql_query = "select agent_id,sales_type,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (CSR_DATE between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR') union select agent_id,sales_type,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + "  and  (CSR_DATE between '" + StartDate_fnt + "' and '" + EndDate_fnt + "') and (entered_on between '" + StartDate + "' and '" + EndDate + "') and airline_detail_id=" + airline_name_city_value + " and sales_type in('CRDR')";
                }

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (Session["chkstatus"].ToString() == "Y")
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td><td class=boldtext>No: " + csrso + "</td></tr></table><br>";
                        }

                        else
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table><br>";
                        }
                    }
                    com.Dispose();
                    dr.Dispose();



                    table += @"<table width=""100%""border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th><th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th></tr><tr><th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr><tr><td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td>
</tr>";
                    //com = new SqlCommand("CrDrDateWise", con);          
                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        com = new SqlCommand("CrDrDateWise_China", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (StartDate == "04/1/2008" && EndDate == "04/15/2008")
                        {
                            com = new SqlCommand("CrDrDateWise", con);

                        }
                        else
                        {
                            com = new SqlCommand("CrDrDateWise_China", con);
                        }

                    }
                    else
                    {
                        com = new SqlCommand("CrDrDateWise", con);
                    }

                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(StartDate));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(EndDate));
                    com.Parameters.AddWithValue("FROM_DATEFnt", DateTime.Parse(StartDate_fnt));
                    com.Parameters.AddWithValue("TO_DATEFnt", DateTime.Parse(EndDate_fnt));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();

                    while (dr.Read())
                    {
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            discount = 0;
                            TotDiscount += 0;
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()));
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()));
                        TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                        // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                            // EduChrg -= Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduChrg -= Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                            surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                            // EduChrg += Math.Round((decimal.Parse(dr["ONLY_TDS"].ToString())) * Math.Round(decimal.Parse(dr["Education_Cess"].ToString()))) / 100;
                            EduChrg += Math.Round((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100, MidpointRounding.AwayFromZero);

                        }


                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000") ;
                        lastSurcharge = dr["surcharge"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        //string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        //if (rdbtn == "No")
                        //{
                        string remarks = "";
                        //}
                        //else
                        //{
                        //    remarks = remarks;
                        //}
                        if (Session["chkstatus"].ToString() == "Y")
                        {
                            table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + "," + dr["entered_on"].ToString() + " , " + dr["approved_for_csr"].ToString() + @"</td></tr>";
                        }
                        else
                        {
                            table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString())) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero) + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";
                        }

                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""2""></td></tr>";

                    Total = (TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm);
                    table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""2""> </td></tr><tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";
                    //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";
                    string strt = "";
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)) < 0)
                    {
                        strt = "Less";
                    }
                    else
                    {
                        strt = "Add";
                    }

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>" + strt + " TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>" + strt + " SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>" + strt + @" EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";
                        sales_t = "Credit";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        sales_t = "Debit";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge));
                    }

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        comName = dr["company_name"].ToString();

                        table1 += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""3"">" + dr["Company_Address"].ToString() + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""2"" class=""heading"">" + sales_t.ToString() + @" Note</font></p></td></tr></table><br>";

                    }
                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr class=""boldtext""><th colspan=""11"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""4"" align=""right"">INR &nbsp;" + font + GrandTotal + @"</font></td></tr>";

                    table += @"<tr align=""left"" class=""text""> <td colspan=""11"">&nbsp;</td> <td colspan=""4"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""13"" nowrap ><hr><font size=1>" + csrFooter + @"</font></td></tr><tr><td colspan=""13"" nowrap class=text align=left>ModPrd between " + ConvertDate2(StartDate) + @"-" + ConvertDate2(EndDate) + @".<br><br></td></tr></table><br style=""page-break-before:always;"">";

                }
                if (GrandTotal > 0)
                    tableAll = tableAll + (table1 + table);
                Label1.Text = tableAll;

                //}

            }

            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(StartDate) + " To " + ConvertDate1(EndDate) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;
        }

    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected string ConvertDate2(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1]+ Sdate[0]+ Sdate[2].Substring(2,2);
    }

    public string ConvertDateFormat1(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }
    protected string checkApprove(string dt1, string dt2)
    {
        string s = null;
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("select * from Approved_CSR a inner join CSR_Duration b on a.CSR_Duration_ID=b.CSR_Duration_ID where CSR_Duration1='" + ConvertDateFormat1(dt1) + "-" + ConvertDateFormat1(dt2) + "'", con);
        dr = com.ExecuteReader();
        if (dr.Read())
            s = "approve";
        else
            s = "notApprove";

        return s;


    }
}
