using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;


public partial class DisplayFlightSchedule : Page
{
   
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    SqlTransaction trans = null;
    DisplayWrap dw = new DisplayWrap();
    GridView gv = new GridView();
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            UserAirlineNamePlusCode();

        }
        Search();

    }




    //function for bind grid
    public void Search()
    {
        string s1 = ddlflight.SelectedItem.Value;
       
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string selectQ = null;
                selectQ = "SELECT FlightMaster.SNo,FlightMaster.FlightNo,FlightMaster.Route,FlightTrans.Origin,FlightTrans.Destination AS Dest, FlightTrans.ETD,FlightTrans.ETA,REPLACE(REPLACE(CONVERT(VARCHAR,FlightTrans.ValidFrom,107), ' ', '-'), ',', '') AS Validfrom, REPLACE(REPLACE(CONVERT(VARCHAR,FlightTrans.ValidTo, 107), ' ', '-'), ',', '') AS ValidTo,FlightTrans.Days,FlightTrans.Allocation,FlightTrans.Volume FROM FlightMaster INNER JOIN FlightTrans ON FlightMaster.FlightNo = dbo.FlightTrans.FlightNo ORDER BY FlightMaster.FlightNo";
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdDisplayFlight.DataSource = dt;
            grdDisplayFlight.DataBind();
            con.Close();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void UserAirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";

            ddlflight.Items.Insert(0, "Select Flight No");
            ddlflight.Items[0].Value = "0";
            strQuery = "select  sno,FlightNo from flightmaster";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                ddlflight.Items.Add(new ListItem(dr["FlightNo"].ToString(), dr["sno"].ToString()));

            }
            con.Close();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
     
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("FlightSchedule.aspx");
    }

    protected void Modify(object sender, CommandEventArgs e)
    {
        Response.Redirect("FlightSchedule.aspx?Id=" + e.CommandName+"&st=E");
    }
    protected void grdDisplayFlight_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdDisplayFlight.PageIndex = e.NewPageIndex;
        Search();
    }

    protected void Delete(object sender, CommandEventArgs e)
    {
        Response.Redirect("FlightSchedule.aspx?Id=" + e.CommandName + "&st=D");
    }
}