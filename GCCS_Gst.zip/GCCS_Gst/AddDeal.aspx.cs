using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AddDeal : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;    
    DateTime dt1;
    DateTime dateNow;
    SqlTransaction tr = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                ShowDetails();
                showSpotDetails();

            }
        }
    }
    protected void ShowDetails()
    {
        
        string searchStr = "";
        searchStr = "select c.agent_name,g.destination_code,f.city_code,a.Charged_Weight,a.Gross_Weight,a.Volume_Weight,a.Freight_amount,a.Special_Rate,a.Special_Amount,a.handover_id,a.booking_id,a.stock_id,b.AirWayBill_No,e.flight_No,e.airline_Detail_id,a.No_Of_packages,a.spot_rate,a.city_id,a.destination_id,a.Shipment_Id,a.Special_Commodity_ID,convert(varchar,d.flight_Date,103) as flight_Date,a.agent_Deal_Remarks,d.Flight_Open_ID,a.tariff_Rate,a.Freight_Type,a.Special_Rate,convert(Varchar,getDate(),101) as nowDate from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.handover_id=" + Request.QueryString["hid"] + " ";
        //convert(varchar,d.flight_Date,103) as flight_Date,
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand(searchStr, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                //HandoverID =Request.QueryString["hid"].ToString();
                //BookingID = dr["booking_id"].ToString();
                //FlightOpenID = dr["Flight_Open_ID"].ToString();
                //StockID = dr["stock_id"].ToString();
                //SpecialCommodityID = dr["Special_Commodity_ID"].ToString();
                //ShipmentID = dr["Shipment_Id"].ToString();
                //CityID = dr["city_id"].ToString();
                //DestinationID = dr["destination_id"].ToString();
                //AirlineDetailID = dr["airline_Detail_id"].ToString();
                //NoOfpackages = dr["No_Of_packages"].ToString();
                //VolumeWeight = dr["Volume_Weight"].ToString();
                //TariffRate = dr["tariff_Rate"].ToString();
                //FreightType = dr["Freight_Type"].ToString();
                //SpecialRate = dr["Special_Rate"].ToString();
               // AWCFees = dr["AWC_Fees"].ToString();
                //OtherDueCarrier = dr["Other_DueCarrier"].ToString();
               // OtherRemarks = dr["Other_Remarks"].ToString();
                lblAwb.Text = dr["AirWayBill_No"].ToString();
                lblAgentName.Text = dr["agent_name"].ToString();
                lblDestn.Text = dr["destination_code"].ToString();
                lblOrigin.Text = dr["city_code"].ToString();
                lblChargeableWeight.Text = dr["Charged_Weight"].ToString();
                lblGrossWeight.Text = dr["Gross_Weight"].ToString();
                lblTariffAmt.Text = dr["Freight_amount"].ToString();
                lblSpclAmt.Text = dr["Special_Amount"].ToString();
                txtAgentDealRem.Text = dr["agent_Deal_Remarks"].ToString();
                Label1.Text = dr["tariff_Rate"].ToString();
                Label2.Text = dr["Special_Rate"].ToString();
                
                //lblPrnRate.Text = dr[""].ToString();
                // lblPrnAmt.Text = dr[""].ToString();

                txtSpot.Text = dr["spot_rate"].ToString();

                 dt1 = DateTime.Parse(ConvertDate1(dr["flight_Date"].ToString().Trim()));
                 //SalesAddedDate = DateTime.Parse(dr["Sales_Added_Date"].ToString());
                 dateNow = Convert.ToDateTime(dr["nowDate"].ToString());

                SqlConnection con1 = new SqlConnection(strCon);
                con1.Open();
                //SqlCommand com1 = new SqlCommand("Select principle_rate from Handover_Deal Where Shipment_Id=" + dr["Shipment_Id"].ToString().Trim() + " and Special_Commodity_ID=" + dr["Special_Commodity_ID"].ToString().Trim() + " and Origin=" + dr["city_id"].ToString().Trim() + " and Destination=" + dr["destination_id"].ToString().Trim() + " and Airline_Detail_ID=" + dr["airline_Detail_id"].ToString().Trim() + " and Slab_Start<=" + dr["Charged_Weight"].ToString().Trim() + " and Slab_End>=" + dr["Charged_Weight"].ToString().Trim() + " and convert(varchar,Valid_From,103) <='" + dr["flight_Date"].ToString().Trim() + "' and convert(varchar,Valid_To,103)>='" + dr["flight_Date"].ToString() + "' and status=2", con1);

                SqlCommand com1 = new SqlCommand("Select principle_rate from Handover_Deal Where Shipment_Id=" + dr["Shipment_Id"].ToString().Trim() + " and Special_Commodity_ID=" + dr["Special_Commodity_ID"].ToString().Trim() + " and Origin=" + dr["city_id"].ToString().Trim() + " and Destination=" + dr["destination_id"].ToString().Trim() + " and Airline_Detail_ID=" + dr["airline_Detail_id"].ToString().Trim() + " and Slab_Start<=" + dr["Charged_Weight"].ToString().Trim() + " and Slab_End>=" + dr["Charged_Weight"].ToString().Trim() + " and ('" + dt1 + "' between Valid_From and Valid_To ) and status=2", con1);

                SqlDataReader dr1 = com1.ExecuteReader();
                if (dr1.Read())
                {
                    lblPrnRate.Text = dr1["principle_rate"].ToString();
                    lblPrnAmt.Text = ((decimal.Parse(dr["Charged_Weight"].ToString().Trim())) * (decimal.Parse(dr1["principle_rate"].ToString().Trim()))).ToString();
                    // lblPrnAmt.Text = decimal.Parse(dr["Charged_Weight"].ToString()).ToString();
                    dr1.Dispose();
                    con1.Close();

                }
                else
                {

                    lblPrnRate.Text = "0";
                    lblPrnAmt.Text = "0";
                    dr1.Dispose();
                    con1.Close();
                
                }
                con.Close();
            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void showSpotDetails()
    {

        string searchStr = "";
        searchStr = "select Spot_Rate,Commission,Special_Commodity_Incentive,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Agent_Deal_Remarks from sales where handover_id=" + Request.QueryString["hid"] + " ";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand(searchStr, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {

                txtSpot.Text = dr["Spot_Rate"].ToString();
                txtCommission.Text = dr["Commission"].ToString();
                txtIncentives.Text = dr["Special_Commodity_Incentive"].ToString();
                txtPriSpotRat.Text = dr["Principle_Spot_Rate"].ToString();
                PrinSpotRateRem.Text = dr["Principle_Spot_Rate_Remarks"].ToString();
                txtAgentDealRem.Text = dr["Agent_Deal_Remarks"].ToString();
                Button1.Visible = false;
                con.Close();
            }
            else
            {
                ShowDetails();
                btnupdatedeal.Visible = false;
            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    protected void InsertDataDeal()
      {
          string HandoverID = null, SpecialRate = null, BookingID=null, FlightOpenID = null, StockID = null, SpecialCommodityID = null, ShipmentID = null, CityID = null, DestinationID = null, AirlineDetailID = null, NoOfpackages = null, VolumeWeight = null, TariffRate = null, FreightType = null, AWCFees = null, OtherDueCarrier = null, OtherRemarks = null;

        string searchStr = "";
        searchStr = "select c.agent_name,g.destination_code,f.city_code,a.Charged_Weight,a.Gross_Weight,a.Volume_Weight,a.Freight_amount,a.Special_Amount,a.handover_id,a.booking_id,a.stock_id,b.AirWayBill_No,e.flight_No,e.airline_Detail_id,a.No_Of_packages,a.spot_rate,a.city_id,a.destination_id,a.Shipment_Id,a.Special_Commodity_ID,convert(varchar,d.flight_Date,103) as flight_Date,a.agent_Deal_Remarks,d.Flight_Open_ID,a.tariff_Rate,a.Freight_Type,a.Special_Rate,convert(Varchar,getDate(),101) as nowDate from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.handover_id=" + Request.QueryString["hid"] + " ";

        string now = DateTime.Now.ToLongDateString();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
             com = new SqlCommand(searchStr, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                HandoverID = Request.QueryString["hid"].ToString();
                BookingID = dr["booking_id"].ToString();
                FlightOpenID = dr["Flight_Open_ID"].ToString();
                StockID = dr["stock_id"].ToString();
                SpecialCommodityID = dr["Special_Commodity_ID"].ToString();
                ShipmentID = dr["Shipment_Id"].ToString();
                CityID = dr["city_id"].ToString();
                DestinationID = dr["destination_id"].ToString();
                AirlineDetailID = dr["airline_Detail_id"].ToString();
                NoOfpackages = dr["No_Of_packages"].ToString();
                VolumeWeight = dr["Volume_Weight"].ToString();
                TariffRate = dr["tariff_Rate"].ToString();
                FreightType = dr["Freight_Type"].ToString();
                SpecialRate = dr["Special_Rate"].ToString();
                dt1 = DateTime.Parse(ConvertDate1(dr["flight_Date"].ToString().Trim()));
                com.Dispose();
                dr.Dispose();
             }

             tr = con.BeginTransaction();
             com = new SqlCommand("insert into sales(Booking_ID,Handover_ID,Flight_Open_ID,Flight_Date,Stock_ID,Special_Commodity_ID,Shipment_ID,City_ID,Destination_ID,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Agent_Deal_Remarks,Add_To_Deal,Entered_By,Entered_On) values (@Booking_ID,@Handover_ID,@Flight_Open_ID,@Flight_Date,@Stock_ID,@Special_Commodity_ID,@Shipment_ID,@City_ID,@Destination_ID,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Agent_Deal_Remarks,@Add_To_Deal,@Entered_By,@Entered_On)", con, tr);

            //comm.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(flightOpenID);
            com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = long.Parse(BookingID);
            com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(FlightOpenID);
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = dt1;
            com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(StockID);
            com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = long.Parse(SpecialCommodityID);
             com.Parameters.AddWithValue("@Shipment_ID",ShipmentID);
             com.Parameters.AddWithValue("@City_ID",CityID);
             com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = long.Parse(DestinationID);
             com.Parameters.AddWithValue("@Airline_Detail_ID",AirlineDetailID);
             com.Parameters.AddWithValue("@No_of_Packages",NoOfpackages);
             com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(lblGrossWeight.Text);
             com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(VolumeWeight);
             com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(lblChargeableWeight.Text);
            decimal sp_rate=(txtSpot.Text.Trim() == "" ?  0 : decimal.Parse(txtSpot.Text));
            com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = sp_rate; 
             com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = txtCommission.Text.Trim() == "" ? 0 : decimal.Parse(txtCommission.Text);
             com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = txtIncentives.Text.Trim() == "" ? 0 : decimal.Parse(txtIncentives.Text);
            // com.Parameters.AddWithValue("@AWC_Fees",AWCFees);
             com.Parameters.AddWithValue("@Freight_Type",FreightType);
             com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(TariffRate);
             com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(lblTariffAmt.Text);
             com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(SpecialRate);
             com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(lblSpclAmt.Text);
             com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(lblPrnRate.Text);
             com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(lblPrnAmt.Text);
             com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = txtPriSpotRat.Text.Trim() == "" ? 0 : decimal.Parse(txtPriSpotRat.Text);
             com.Parameters.Add("@Principle_Spot_Rate_Remarks",SqlDbType.VarChar).Value =PrinSpotRateRem.Text;
             com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtAgentDealRem.Text;
            // com.Parameters.AddWithValue("@Other_DueCarrier", OtherDueCarrier);
            // com.Parameters.AddWithValue("@Other_Remarks", OtherRemarks);
            // com.Parameters.Add("@Sales_Added_Date",SqlDbType.DateTime,8).Value=SalesAddedDate;
             com.Parameters.AddWithValue("@Add_To_Deal", 20);
            com.Parameters.AddWithValue("@Entered_By",Session["EmailID"].ToString());
            //com.Parameters.Add("@Entered_On", SqlDbType.DateTime, 8).Value = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            //com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

            //com1.Parameters.Add("@Entered_On", SqlDbType.DateTime, 8).Value = openDt;

            com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
            com.ExecuteNonQuery();
            //con.Close();
            com.Dispose();

            com = new SqlCommand("update handover set Add_to_Deal=13 where handover_id="+Request.QueryString["hid"].ToString() +" ", con,tr);
            com.ExecuteNonQuery();
            tr.Commit();
            con.Close();

           
            
        }
        catch (SqlException se)
        {
            string err = se.Message;
            tr.Rollback();
            Response.Write(err);
        }
        catch (Exception se)
        {
            string err = se.Message;
            tr.Rollback();
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Response.Redirect("HandoverDetails.aspx");

    }
    protected void UpdateDataDeal()
    {
        string HandoverID = null, SpecialRate = null, BookingID = null, FlightOpenID = null, StockID = null, SpecialCommodityID = null, ShipmentID = null, CityID = null, DestinationID = null, AirlineDetailID = null, NoOfpackages = null, VolumeWeight = null, TariffRate = null, FreightType = null, AWCFees = null, OtherDueCarrier = null, OtherRemarks = null;

        string searchStr = "";
        searchStr = "select c.agent_name,g.destination_code,f.city_code,a.Charged_Weight,a.Gross_Weight,a.Volume_Weight,a.Freight_amount,a.Special_Amount,a.handover_id,a.booking_id,a.stock_id,b.AirWayBill_No,e.flight_No,e.airline_Detail_id,a.No_Of_packages,a.spot_rate,a.city_id,a.destination_id,a.Shipment_Id,a.Special_Commodity_ID,convert(varchar,d.flight_Date,103) as flight_Date,a.agent_Deal_Remarks,d.Flight_Open_ID,a.tariff_Rate,a.Freight_Type,a.Special_Rate,convert(Varchar,getDate(),101) as nowDate from handover a inner join stock_master b inner join agent_master c on c.Agent_id=b.Agent_id on b.stock_id =a.stock_id inner join flight_open d on d.Flight_Open_ID=a.Flight_Open_ID inner join flight_master e on e.flight_ID=d.flight_id inner join city_master f on f.city_id=a.city_id inner join destination_master g on g.destination_id=a.destination_id where a.handover_id=" + Request.QueryString["hid"] + " ";

        string now = DateTime.Now.ToLongDateString();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand(searchStr, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                HandoverID = Request.QueryString["hid"].ToString();
                BookingID = dr["booking_id"].ToString();
                FlightOpenID = dr["Flight_Open_ID"].ToString();
                StockID = dr["stock_id"].ToString();
                SpecialCommodityID = dr["Special_Commodity_ID"].ToString();
                ShipmentID = dr["Shipment_Id"].ToString();
                CityID = dr["city_id"].ToString();
                DestinationID = dr["destination_id"].ToString();
                AirlineDetailID = dr["airline_Detail_id"].ToString();
                NoOfpackages = dr["No_Of_packages"].ToString();
                VolumeWeight = dr["Volume_Weight"].ToString();
                TariffRate = dr["tariff_Rate"].ToString();
                FreightType = dr["Freight_Type"].ToString();
                SpecialRate = dr["Special_Rate"].ToString();
                dt1 = DateTime.Parse(ConvertDate1(dr["flight_Date"].ToString().Trim()));
                com.Dispose();
                dr.Dispose();
            }
           
            tr = con.BeginTransaction();
            com = new SqlCommand("update sales set Spot_Rate=@Spot_Rate,Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Principle_Spot_Rate=@Principle_Spot_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Agent_Deal_Remarks=@Agent_Deal_Remarks,Entered_By=@Entered_By,Entered_On=@Entered_On  where handover_id=" + Request.QueryString["hid"].ToString() + "", con, tr);

            decimal sp_rate = (txtSpot.Text.Trim() == "" ? 0 : decimal.Parse(txtSpot.Text));
            com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = sp_rate;
            com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = txtCommission.Text.Trim() == "" ? 0 : decimal.Parse(txtCommission.Text);
            com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = txtIncentives.Text.Trim() == "" ? 0 : decimal.Parse(txtIncentives.Text);
            
            com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = txtPriSpotRat.Text.Trim() == "" ? 0 : decimal.Parse(txtPriSpotRat.Text);
            com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = PrinSpotRateRem.Text;

            com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtAgentDealRem.Text;
            com.Parameters.AddWithValue("@Entered_By", Session["EmailID"].ToString());
            com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
            com.ExecuteNonQuery();
            //con.Close();
            com.Dispose();

            com = new SqlCommand("update handover set Add_to_Deal=13 where handover_id=" + Request.QueryString["hid"].ToString() + " ", con, tr);
            com.ExecuteNonQuery();
            tr.Commit();
            con.Close();



        }
        catch (SqlException se)
        {
            string err = se.Message;
            tr.Rollback();
            Response.Write(err);
        }
        catch (Exception se)
        {
            string err = se.Message;
            tr.Rollback();
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        Response.Redirect("HandoverDetails.aspx");

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        InsertDataDeal();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("HandOverDetails.aspx");
    }
    protected void btnupdatedeal_Click(object sender, EventArgs e)
    {
        UpdateDataDeal();
    }
}
