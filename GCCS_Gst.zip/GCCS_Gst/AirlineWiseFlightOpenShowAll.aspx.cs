using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AirlineWiseFlightOpenShowAll : System.Web.UI.Page
{

    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataAdapter sda = null;
    string table = "";
    string table2 = "";
    string flightOpen = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
           
            if (!Page.IsPostBack)
            {
                FillDataGv();
                ShowAirline();
                
              // rowColor();
            }
        }
    }
    protected void FillDataGv()
    {
        Label1.Text = "";
        string searchString = null;
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            if (txtFromDate.Text == "" && txtToDate.Text == "" && txtFlightNo.Text == "" && ddlAirlineCity.SelectedValue == "")
            {
                searchString = "select am.Airline_Name +'-'+ c.city_name as airlineName, Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_Code as origin,d.destination_Code as destination,a.open_capacity as capacity,convert(Varchar,a.Flight_Date,103)as flightDate1,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate,s.status_name ,a.Flight_Open_ID,a.Import_Flight_Open_ID,b.Airline_Detail_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id inner join status_master s on a.status=s.status_ID inner join Airline_Detail ad on ad.Airline_Detail_ID=b.Airline_Detail_ID inner join Airline_Master am on am.Airline_ID=ad.Airline_ID where b.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and a.Close_date > '" + DateTime.Parse(DateTime.Now.ToShortDateString()) + "' order by b.Airline_Detail_ID,a.Flight_Date desc  ";
            }
            else if (txtFromDate.Text == "" && txtToDate.Text == "" && txtFlightNo.Text == "" && ddlAirlineCity.SelectedValue != "")
            {
                searchString = "select am.Airline_Name +'-'+ c.city_name as airlineName, Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_Code as origin,d.destination_Code as destination,a.open_capacity as capacity,convert(Varchar,a.Flight_Date,103)as flightDate1,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate,s.status_name ,a.Flight_Open_ID,a.Import_Flight_Open_ID,b.Airline_Detail_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id inner join status_master s on a.status=s.status_ID and b.Airline_Detail_ID=" + ddlAirlineCity.SelectedValue.Trim() + "  inner join Airline_Detail ad on ad.Airline_Detail_ID=b.Airline_Detail_ID inner join Airline_Master am on am.Airline_ID=ad.Airline_ID and a.Close_date > '" + DateTime.Parse(DateTime.Now.ToShortDateString()) + "' order by b.Airline_Detail_ID, a.Flight_Date desc ";

            }

            else if (txtFlightNo.Text == "")
            {

                searchString = "select  am.Airline_Name +'-'+ c.city_name as airlineName,Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_Code as origin,d.destination_Code as destination,a.open_capacity as capacity,convert(Varchar,a.Flight_Date,103)as flightDate1,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate,s.status_name,a.Flight_Open_ID,a.Import_Flight_Open_ID,b.Airline_Detail_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id inner join status_master s on a.status=s.status_ID inner join Airline_Detail ad on ad.Airline_Detail_ID=b.Airline_Detail_ID inner join Airline_Master am on am.Airline_ID=ad.Airline_ID  where a.Flight_Date between '" + DateTime.Parse(ConvertDate1(txtFromDate.Text)) + "' and '" + DateTime.Parse(ConvertDate1(txtToDate.Text)) + "' and b.Airline_Detail_ID=" + ddlAirlineCity.SelectedValue.Trim() + " and a.Close_date > '" + DateTime.Parse(DateTime.Now.ToShortDateString()) + "' order by b.Airline_Detail_ID,a.Flight_Date desc";
            }
            else if (txtFromDate.Text == "" && txtToDate.Text == "" && ddlAirlineCity.SelectedValue == "")
            {
                searchString = "select am.Airline_Name +'-'+ c.city_name as airlineName, Convert(varchar,a.open_date,103) as FlightDate ,b.Flight_no,b.Flight_type,c.city_Code as origin,d.destination_Code as destination,a.open_capacity as capacity,convert(Varchar,a.Flight_Date,103)as flightDate1,substring(cast(a.flight_time as varchar),12,50)as flight_time,a.Flight_Day,Convert(varchar,a.Close_date,103) as CloseDate,s.status_name,a.Flight_Open_ID,a.Import_Flight_Open_ID,b.Airline_Detail_ID from flight_open a inner join flight_master b on a.flight_id=b.flight_id inner join city_master c on b.Origin=c.city_id inner join destination_master d on b.destination=d.destination_id inner join status_master s on a.status=s.status_ID  inner join Airline_Detail ad on ad.Airline_Detail_ID=b.Airline_Detail_ID inner join Airline_Master am on am.Airline_ID=ad.Airline_ID where b.flight_no like '" + txtFlightNo.Text.Trim() + "%' and b.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and a.Close_date > '" + DateTime.Parse(DateTime.Now.ToShortDateString()) + "' order by b.Airline_Detail_ID,a.Flight_Date desc";
            }
            string AirlineDetailID = "";
            string AirlineDetailIDTem = "";
            com = new SqlCommand(searchString, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {

                while (dr.Read())
                {
                    string ss = @"  ""  ";
                    string status = dr["status_name"].ToString();
                    string reopen = "";
                    string capacity = @"<a id=""yy"" href=""UpdateCapacity.aspx?fno=" + dr["Flight_No"].ToString() + "&type=" + dr["Flight_type"].ToString() + "&org=" + dr["origin"].ToString() + "&dest=" + dr["Destination"].ToString() + "&date=" + dr["FlightDate1"].ToString() + "&cap=" + dr["capacity"].ToString() + "&fid=" + dr["Flight_Open_ID"].ToString() + @""" class=""boldtext"">" + dr["Flight_No"].ToString() + "</a>";
                    string importFlight = @"<a id=""yy"" href=""importflightopen.aspx?fno=" + dr["Flight_No"].ToString() + "&org=" + dr["origin"].ToString() + "&dest=" + dr["Destination"].ToString() + "&date=" + dr["FlightDate1"].ToString() + "&cdate=" + dr["CloseDate"].ToString() + "&fid=" + dr["Flight_Open_ID"].ToString() + @""" class=""boldtext"">ImportFltOpen </a>";
                    string egmDetails = @"<a id=""egm"" href=""egm.aspx?fno=" + dr["Flight_Open_ID"].ToString() + "&f=" + dr["Flight_no"].ToString() + @""" class=""boldtext"">EGM Details</a>";
                    string discount = @"<a id=""ss"" class=""boldtext"" style=""text-decoration:none"" href=""DiscountFlight.aspx?fno=" + dr["Flight_No"].ToString() + @"&cap=" + dr["Capacity"].ToString() + @"&date=" + dr["flightDate1"].ToString() + @"" + ss + @"" + @">Discount" + @"</a>";
                    string cancel = @"<input type=""Button""  OnClick=""window.open('FlightCancel.aspx?foid=" + dr["Flight_Open_ID"].ToString() + @"&fDate=" + dr["flightDate1"].ToString() + @"&fno=" + dr["Flight_No"].ToString() + @"&Action=Cancel','mywindow','width=500,height=400,toolbar=yes,location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,copyhistory=yes,resizable=yes')""  value=""Cancel"" />";

                    string Nil_Manifest = @"<input type=""Button""  OnClick=""window.open('FlightCancel.aspx?foid=" + dr["Flight_Open_ID"].ToString() + @"&fDate=" + dr["flightDate1"].ToString() + @"&fno=" + dr["Flight_No"].ToString() + @"&Action=NilManifest','mywindow','width=500,height=400,toolbar=yes,location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,copyhistory=yes,resizable=yes')""  value=""Nil Manifest"" />";
                    string color = ""; 

                    DateTime dtCloseDate = DateTime.Parse(ConvertDate1(dr["CloseDate"].ToString()));
                    if (dr["status_name"].ToString() == "Cancelled")
                    {
                        importFlight = "";
                        egmDetails = "";
                        discount = "";
                        cancel = "";
                        Nil_Manifest = "";
                        color = @"style=""color:Red""";
                        reopen = @"<a id=""Reopen"" href=""ReopenFlight.aspx?fno=" + dr["Flight_Open_ID"].ToString() + "&f=" + dr["Flight_no"].ToString() + @""" class=""boldtext"">Reopen</a>";
                    }


                    if (dr["status_name"].ToString() == "Nil Manifest")
                    {
                        importFlight = "";
                        egmDetails = "";
                        discount = "";
                        cancel = "";
                        Nil_Manifest = "";
                        color = @"style=""color:Red""";
                        reopen = @"<a id=""Reopen"" href=""ReopenFlight.aspx?fno=" + dr["Flight_Open_ID"].ToString() + "&f=" + dr["Flight_no"].ToString() + @""" class=""boldtext"">Reopen</a>";
                    }
                    AirlineDetailIDTem = dr["Airline_Detail_ID"].ToString();
                    if (AirlineDetailID == dr["Airline_Detail_ID"].ToString())
                    {
                        table2 += @"<tr " + color + @"><td nowrap class=mostlink>" + capacity + @"</td><td>" + dr["Flight_type"].ToString() + @"</td><td>" + dr["Origin"].ToString() + @"</td><td>" + dr["Destination"].ToString() + @"</td><td>" + dr["Capacity"].ToString() + @"</td><td>" + dr["flightDate1"].ToString() + @"</td><td nowrap>" + dr["flight_time"].ToString() + @"</td><td>" + dr["FlightDate"].ToString() + @"</td><td>" + dr["CloseDate"].ToString() + @"</td><td>" + status + @"</td><td>" + discount + @"</td><td>" + cancel + @"</td><td>" + Nil_Manifest + @"</td><td>" + importFlight + @"</td><td nowrap>" + egmDetails + @"</td> </tr>";
                    }
                    else
                    {
                        table2 += @"<table class=""text"" width=""100%"" align=""center"" border=""1"">";
                        table2 += @"<tr align=""center""><td colspan=""15""  class=""h1 boldtext"">" + dr["airlineName"].ToString() + @"</td><tr>";
                        table2 += @"<tr align=""center""><td nowrap class=""h1 boldtext"">Flt No </td><td class=""h1  boldtext"">Flt Type </td><td class=""h1 boldtext"">Origin </td><td class=""h1 boldtext"">Dstn</td><td class=""h1 boldtext"">Capacity </td><td class=""h1 boldtext"">Flt Date </td><td nowrap class=""h1 boldtext"">Flt Time </td><td class=""h1 boldtext"">Open Date </td><td class=""h1 boldtext"">CloseDate </td><td class=""h1 boldtext"">status </td><td class=""h1 boldtext"">Discount </td><td class=""h1 boldtext"">Cancel</td><td class=""h1 boldtext"">Nil Manifest</td><td class=""h1 boldtext"">ImportFltOpen </td><td  nowrap class=""h1 boldtext""> EGM Details</td></tr>";
                        table2 += @"<tr " + color + @"><td  nowrap class=mostlink>" + capacity + @"</td><td>" + dr["Flight_type"].ToString() + @"</td><td>" + dr["Origin"].ToString() + @"</td><td>" + dr["Destination"].ToString() + @"</td><td>" + dr["Capacity"].ToString() + @"</td><td>" + dr["flightDate1"].ToString() + @"</td><td nowrap>" + dr["flight_time"].ToString() + @"</td><td>" + dr["FlightDate"].ToString() + @"</td><td>" + dr["CloseDate"].ToString() + @"</td><td>" + status + @"</td><td>" + discount + @"</a></td><td>" + cancel + @"</td><td>" + Nil_Manifest + @"</td><td>" + importFlight + @"</td><td nowrap>" + egmDetails + @"</td></tr>";
                        AirlineDetailID = dr["Airline_Detail_ID"].ToString();

                    }
                }
            }

            table2 += @"</table>";
            Label1.Text = table2;
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv.PageIndex = e.NewPageIndex;
        FillDataGv();
        //rowColor();
    }

    protected void rowColor()
    {
        if (Session["groupid"].ToString() == "1")
        {
            gv.Columns[15].Visible = true;
        }
        else
        {
            gv.Columns[16].Visible = false;

        }
        int c = gv.Columns.Count;
        for (int i = 0; i < gv.Rows.Count; i++)
        {
            GridViewRow gr = gv.Rows[i];
            Label lblDt = (Label)(gr.FindControl("lblCloseDate"));
            DateTime dtCloseDate = DateTime.Parse(ConvertDate1(lblDt.Text));
            Label lblimp = (Label)gr.FindControl("lblImpId");
            if (lblimp.Text != "0")
                gr.Cells[12].Text = "";


            if (((Label)(gr.FindControl("lblStatus"))).Text == "Cancelled")
            {
                gr.Cells[0].ForeColor = System.Drawing.Color.Red;
                gr.Cells[10].Text = "";
                gr.Cells[12].Text = "";
                gr.Cells[14].Text = "";
                gr.Cells[16].Text = "";

                //  ((Label)(gr.FindControl("lblFlightNo"))).ForeColor = System.Drawing.Color.Red;
                ((Label)(gr.FindControl("lblFlight"))).ForeColor = System.Drawing.Color.Red;

                ((Label)(gr.FindControl("lblorigin"))).ForeColor = System.Drawing.Color.Red;
                ((Label)(gr.FindControl("lblDes"))).ForeColor = System.Drawing.Color.Red;
                ((Label)(gr.FindControl("lblCapacity"))).ForeColor = System.Drawing.Color.Red;
                ((Label)(gr.FindControl("lblFlightTime"))).ForeColor = System.Drawing.Color.Red;

                //((Label)(gr.FindControl("lblFlightTime1"))).ForeColor = System.Drawing.Color.Red;
                gr.Cells[6].ForeColor = System.Drawing.Color.Red;

                ((Label)(gr.FindControl("lblDate"))).ForeColor = System.Drawing.Color.Red;
                ((Label)(gr.FindControl("lblCloseDate"))).ForeColor = System.Drawing.Color.Red;

                ((Label)(gr.FindControl("lblStatus"))).ForeColor = System.Drawing.Color.Red;


                ((Button)(gr.FindControl("btnCancel"))).Visible = false;

                //((HtmlAnchor)(gr.FindControl("ss"))).Visible = false;

            }

            if (dtCloseDate >= DateTime.Parse(DateTime.Today.ToShortDateString()))
            {
                gr.Cells[14].Text = "";
                //  gr.Cells[16].Text = "";                                                            

            }
            if (dtCloseDate < DateTime.Parse(DateTime.Now.ToShortDateString()))
            {
                DateTime fdffdf = DateTime.Parse(DateTime.Now.ToShortDateString());
                gr.Cells[9].Text = "Closed";
                gr.Cells[12].Text = "";
                gr.Cells[16].Text = "";


            }

        }


    }


    protected void Button3_Click(object sender, EventArgs e)
    {
        FillDataGv();
       // rowColor();
    }

    protected void Button1_Click(object o, EventArgs e)
    {
        Button Button1 = (Button)o;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        string strFlightID = grdRow.Cells[0].Text;
        string strFlifgtDate = grdRow.Cells[6].Text;
        Label ll = (Label)grdRow.FindControl("lblFlightOpenID");
        int flag = 0;
        string awb = "";

        //int fl_No = int.Parse(strFlightID.Trim());
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            com = new SqlCommand("select a.stock_id ,b.airwaybill_no from booking_master a inner join stock_master b on b.stock_id=a.stock_id where Flight_Open_ID=" + ll.Text.Trim() + " ", con);
            SqlDataReader dr = com.ExecuteReader();

            while (dr.Read())
            {
                if (awb == "")
                    awb += dr["airwaybill_no"].ToString();
                awb += ", " + dr["airwaybill_no"].ToString();
                flag = 1;
            }
            if (flag == 1)
            {
                table += "Sorry, the flight cancel by you contains AWB No. ";
                table += awb;
                table += " in booking. Please transfer these AWBs to another flight and then try again!";
                Session["fltCancel"] = table;
                //string page_pop = "<SCRIPT language='javascript'>window.open('NewReportDrCr.aspx');</SCRIPT>";
                string page_pop = "<SCRIPT language='javascript'>window.open('FlightCancel.aspx','mywin','left=20,top=20,width=300,height=200,toolbar=0,resizable=1,scrollbars=1');</SCRIPT>";

                FillDataGv();
               // rowColor();
                com.Dispose();
                dr.Dispose();
                Response.Write(page_pop);
            }
            else
            {
                com.Dispose();
                dr.Dispose();
                com = new SqlCommand("Update  flight_open set status=7 where flight_id=(select flight_id from flight_master where flight_no='" + strFlightID.Trim() + "') and convert(varchar,flight_Date,103)='" + strFlifgtDate + "'", con);
                int result = com.ExecuteNonQuery();
                com.Dispose();
                con.Close();
                FillDataGv();
                //rowColor();
            }

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }


    protected void btnNilManifest_Click(object o, EventArgs e)
    {

        Button Button1 = (Button)o;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        string strFlightID = grdRow.Cells[0].Text;
        string strFlifgtDate = grdRow.Cells[6].Text;
        Label ll = (Label)grdRow.FindControl("lblFlightOpenID");
        int flag = 0;
        string awb = "";

        //int fl_No = int.Parse(strFlightID.Trim());
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            com = new SqlCommand("select a.stock_id ,b.airwaybill_no from booking_master a inner join stock_master b on b.stock_id=a.stock_id where Flight_Open_ID=" + ll.Text.Trim() + " ", con);
            SqlDataReader dr = com.ExecuteReader();

            while (dr.Read())
            {
                if (awb == "")
                    awb += dr["airwaybill_no"].ToString();
                awb += ", " + dr["airwaybill_no"].ToString();
                flag = 1;
            }
            if (flag == 1)
            {
                table += "Sorry, the flight Nil manifest by you contains AWB No. ";
                table += awb;
                table += " in booking. Please transfer these AWBs to another flight and then try again!";
                Session["fltCancel"] = table;
                //string page_pop = "<SCRIPT language='javascript'>window.open('NewReportDrCr.aspx');</SCRIPT>";
                string page_pop = "<SCRIPT language='javascript'>window.open('FlightCancel.aspx','mywin','left=20,top=20,width=300,height=200,toolbar=0,resizable=1,scrollbars=1');</SCRIPT>";

                FillDataGv();
                // rowColor();
                com.Dispose();
                dr.Dispose();
                Response.Write(page_pop);
            }
            else
            {
                com.Dispose();
                dr.Dispose();
                com = new SqlCommand("Update  flight_open set status=35 where flight_id=(select flight_id from flight_master where flight_no='" + strFlightID.Trim() + "') and convert(varchar,flight_Date,103)='" + strFlifgtDate + "'", con);
                int result = com.ExecuteNonQuery();
                com.Dispose();
                con.Close();
                FillDataGv();
                //rowColor();
            }

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }


    protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button l = (Button)e.Row.FindControl("btnCancel");
            l.Attributes.Add("onclick", " javascript: return confirm('Are you sure to Cancel? ')");
        }
    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public String flightOpenId
    {
        get
        {
            return flightOpen;

        }
    }
    protected void ShowAirline()
    {

        ddlAirlineCity.Items.Clear();

        con = new SqlConnection(strcon);
        con.Open();
        try
        {
            // com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and a.airline_id in (" + Session["AIRLINEACCESS"].ToString().Substring(0, +Session["AIRLINEACCESS"].ToString().Length - 1) + ") order by Airline_Name", con);
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineCity.Items.Add("Select airline name");
            ddlAirlineCity.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirlineCity.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

}
