using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class LoginNew : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    Login_Check login = new Login_Check();
    protected string UserId = "";
    protected string Password = "";
    protected string airlineAccess = "";
    protected string uID = "";
    protected string aID = "";
    protected string sID = "";
    string strQuery = "";
    Int64 groupID = 0;
    DataSet dsLogin = new DataSet();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Write(a);

        //if (User.Identity.IsAuthenticated)
        //{
        //    Response.Redirect("NotAuthorized.aspx");
        //}
        if (Request.QueryString["a"] != null)
        {
            lblErrorMsg.Text = "Sorry, Wrong UserId or Password!";
        }
        txtUserName.Focus();
    }

    //FUNCTION TO ADD NEW USER IN APPLICATION VARIABLE
    public void AddNameToApplicationVariable(string UserId)
    {
        ArrayList EmailList = new ArrayList();
        EmailList = (ArrayList)Application["Emails"];
        if (EmailList == null)
        {
            EmailList = new ArrayList();
        }
        EmailList.Add(UserId);
        Application["Emails"] = EmailList;
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        UserId = txtUserName.Text;
        Password = txtPassword.Text;
        if ((Password.Contains("'")) || (UserId.Contains("'")))
        {
            lblErrorMsg.Text = "User ID or Password can't contain special characters";
            return;
        }
        else
            dsLogin = login.checkUser(UserId, Password);

        if (dsLogin.Tables[0].Rows.Count > 0)
        {
            AddLastTime();
            FormsAuthentication.RedirectFromLoginPage(txtUserName.Text, true);
            aID = dsLogin.Tables[0].Rows[0]["Agent_ID"].ToString();
            uID = dsLogin.Tables[0].Rows[0]["User_ID"].ToString();
            sID = dsLogin.Tables[0].Rows[0]["Subagent_Id"].ToString();
            Session["TimeLimit"] = dsLogin.Tables[0].Rows[0]["TimeLimit"].ToString();
            if (uID != "")
            {
                Session["MenuRight"] = "1";
            }
            else
            {
                Session["MenuRight"] = "0";
            }
            //sID = "";
            if (sID != "")
            {
                Session["ID"] = sID;
                strQuery = "SELECT * FROM db_owner.SubAgent_Master WHERE SubAgentID= '" + this.sID + "'";
                ds = login.getloginDetail(strQuery);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Session["USER_NAME"] = ds.Tables[0].Rows[0]["SubAgentName"].ToString();
                    Session["BELONG_TO_CITY"] = ds.Tables[0].Rows[0]["CityId"].ToString();
                }
            }
            else if (aID == "")
            {
                Session["ID"] = uID;
                strQuery = "select * from user_Master where userId = '" + this.uID + "'";
                ds = login.getloginDetail(strQuery);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Session["USER_NAME"] = ds.Tables[0].Rows[0]["Full_Name"].ToString();
                    Session["BELONG_TO_CITY"] = ds.Tables[0].Rows[0]["Belongs_To_City"].ToString();
                }
            }
            else if (uID == "")
            {
                Session["ID"] = aID;
                strQuery = "select * from Agent_Master a inner join Agent_Branch b on a.Agent_ID = b.Agent_ID where b.Agent_Branch_ID = '" + this.aID + "'";
                ds = login.getloginDetail(strQuery);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Session["AGENT_NAME"] = ds.Tables[0].Rows[0]["Agent_Name"].ToString();
                    Session["BELONG_TO_CITY"] = ds.Tables[0].Rows[0]["Belongs_To_City"].ToString();
                }
            }
            Session["EMailID"] = UserId;
            string Mid = dsLogin.Tables[0].Rows[0]["Login_Master_ID"].ToString();
            Session["Login_Master_ID"] = dsLogin.Tables[0].Rows[0]["Login_Master_ID"].ToString();
            Session["AIRLINEACCESS"] = dsLogin.Tables[0].Rows[0]["Airline_Access"].ToString();
            groupID = Convert.ToInt64(dsLogin.Tables[0].Rows[0]["Group_ID"].ToString());
            strQuery = "select * from Group_Master where Group_ID = '" + this.groupID + "'";
            Session["groupid"] = groupID;
            ds = new DataSet();
            ds = login.getloginDetail(strQuery);
            if (ds.Tables[0].Rows.Count > 0)
            {
                string menuRights = ds.Tables[0].Rows[0]["Mainmenu_Rights"].ToString();
                Session["menurgt"] = menuRights;
            }
            AddNameToApplicationVariable(UserId);
            try
            {
                con.Open();
                con = new SqlConnection(strcon);
                con.Open();
                com = new SqlCommand("Login_Details_Insert", con);
                com.CommandType = CommandType.StoredProcedure;
                //string Agname = (ds.Tables[0].Rows[0]["Agent_Name"].ToString().Trim() == "" ? "" : ds.Tables[0].Rows[0]["Agent_Name"].ToString().Trim());
                if (sID != "")
                {
                    com.Parameters.Add("@AgentName", SqlDbType.VarChar).Value = "";
                    com.Parameters.Add("@username", SqlDbType.VarChar).Value = Session["USER_NAME"].ToString();
                }
                else if (aID == "")
                {
                    com.Parameters.Add("@AgentName", SqlDbType.VarChar).Value = "";
                    com.Parameters.Add("@username", SqlDbType.VarChar).Value = Session["USER_NAME"].ToString();
                }
                else
                {
                    com.Parameters.Add("@AgentName", SqlDbType.VarChar).Value = Session["Agent_name"].ToString();
                    com.Parameters.Add("@username", SqlDbType.VarChar).Value = "";
                }
                com.Parameters.Add("@City", SqlDbType.Int).Value = Session["BELONG_TO_CITY"];
                com.Parameters.Add("@Email", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                com.Parameters.Add("@LoginType", SqlDbType.VarChar).Value = ds.Tables[0].Rows[0]["Group_Type"].ToString();
                com.Parameters.Add("@LoginDate", SqlDbType.DateTime).Value = DateTime.Now;
                com.ExecuteNonQuery();
                con.Close();
                com.Connection.Close();
            }
            catch (SqlException sqlex)
            {
                string ss = sqlex.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
            Response.Redirect("LoginSuccess.aspx");
        }
        else
        {
            lblErrorMsg.Text = "Sorry, Wrong UserId or Password!";
            txtUserName.Focus();
        }
    }
    protected void AddLastTime()
    {
        con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand com = new SqlCommand("update login_master set Last_login_at='" + DateTime.Now + "' where email_id='" + txtUserName.Text + "' ", con);
            com.ExecuteNonQuery();
        }
        catch (Exception se)
        {
            Response.Write(se);
        }
        finally
        {
            con.Close();
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("NewAgent_Register.aspx");
    }
}
