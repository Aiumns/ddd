using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class home_open : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        string Tables = "";

        Label1.Visible = false;
        string query_status = "select status_name from group_master inner join status_master on status_id=booking_handover_details where group_id=" + Convert.ToInt64(Session["groupid"].ToString()) + "";

        DataTable dtw = dw.GetAllFromQuery(query_status);

        if (dtw.Rows[0]["status_name"].ToString() == "Yes")
        {
            HyperLink1.Visible = false;
            Label1.Visible = true;
            string Query = "select distinct flight_master.airline_detail_id,airline_name,airline_text_code,airline_code,belongs_to_city,city_code,city_name,city_master.city_id  from flight_open inner join flight_master on flight_open.flight_id=flight_master.flight_id inner join airline_detail on flight_master.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id inner join city_master on airline_detail.belongs_to_city=city_master.city_id where airline_detail.airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ")  order by airline_name";
            DataTable dt_airline = dw.GetAllFromQuery(Query);

            foreach (DataRow drow in dt_airline.Rows)
            {
                Tables += @"<table width=100% ><tr class=h1 align=center><td colspan=9 class=boldtext>" + drow["airline_name"].ToString() + "-(" + drow["airline_code"].ToString() + ")-" + drow["city_code"].ToString() + "</td></tr><tr class=h5><td class=boldtext align=center>&nbsp;</td><td class=boldtext align=center>Flight No.</td><td class=boldtext align=center>Flight Date</td><td class=boldtext align=center>Flight Type</td><td class=boldtext align=center>Destination</td><td class=boldtext align=center>Capacity (in Kgs)</td><td class=boldtext align=center>Gross Wt(in Kgs)</td><td class=boldtext align=center>Chargeable Weight(in Kgs)</td><td class=boldtext align=center>&nbsp;</td></tr>";
                Query = "select booking_master.flight_open_id,flight_no,convert(varchar,flight_open.flight_date,107) as flight_date,Convert(varchar,open_date,103) as open_date,Convert(varchar,close_date,103) as close_date,flight_open.flight_date as fd,flight_type,destination_code,capacity,sum(gross_weight) as gross_weight,sum(charged_weight) as charged_weight from flight_open inner join flight_master on flight_open.flight_id=flight_master.flight_id inner join booking_master on flight_open.flight_open_id=booking_master.flight_open_id inner join destination_master on destination_master.destination_id=flight_master.destination where airline_detail_id=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " and  close_date>=getdate() group by flight_no,flight_open.flight_Date,flight_type,destination_code,capacity,open_date,close_date,booking_master.flight_open_id order by flight_open.flight_date ";

                DataTable dt_flight = dw.GetAllFromQuery(Query);
                foreach (DataRow dr_fl in dt_flight.Rows)
                {
                    string Query_book = "select booking_master.flight_open_id,flight_no,convert(varchar,flight_open.flight_date,107) as flight_date,Convert(varchar,open_date,103) as open_date,Convert(varchar,close_date,103) as close_date,flight_open.flight_date as fd,flight_type,destination_code,capacity,sum(gross_weight) as bgross_weight,sum(charged_weight) as bcharged_weight from flight_open inner join flight_master on flight_open.flight_id=flight_master.flight_id inner join booking_master on flight_open.flight_open_id=booking_master.flight_open_id inner join destination_master on destination_master.destination_id=flight_master.destination where airline_detail_id=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " and booking_master.flight_open_id=" + Convert.ToInt64(dr_fl["flight_open_id"].ToString()) + " and  close_date>=getdate() group by flight_no,flight_open.flight_Date,flight_type,destination_code,capacity,open_date,close_date,booking_master.flight_open_id order by flight_open.flight_date ";
                    DataTable dt_booking = dw.GetAllFromQuery(Query_book);
                    foreach (DataRow dr_booking in dt_booking.Rows)
                    {
                        Tables += @"<tr><td class=error >Bookings</td><td class=text align=left >" + dr_fl["flight_no"].ToString() + "</td><td class=text align=left>" + dr_fl["flight_date"].ToString() + "</td><td class=text align=left>" + dr_fl["flight_type"].ToString() + "</td><td class=text align=center>" + dr_fl["destination_code"].ToString() + "</td><td class=text align=right>" + dr_fl["capacity"].ToString() + "</td><td class=text align=right>" + dr_booking["bgross_weight"].ToString() + "</td><td class=text align=right>" + dr_booking["bcharged_weight"].ToString() + "</td><td class=text nowrap><a href='Reports/detail_booking.aspx?fd1=" + dr_fl["flight_date"].ToString() + "&amp;fd=" + dr_fl["fd"].ToString() + "&amp;airid=" + drow["airline_detail_id"].ToString() + "&amp;fno=" + dr_fl["flight_no"].ToString() + "&amp;od=" + dr_fl["open_date"].ToString() + "&amp;cd=" + dr_fl["close_date"].ToString() + "&amp;cap=" + dr_fl["capacity"].ToString() + "&amp;booked=" + dr_booking["bgross_weight"].ToString() + "&amp;air=" + drow["airline_code"].ToString() + "&amp;foid=" + dr_fl["flight_open_id"].ToString() + "' target=_blank>View Details</a></td></tr>";
                    }
                    string Query_hand = "select booking_master.flight_open_id,flight_no,convert(varchar,flight_open.flight_date,107) as flight_date,Convert(varchar,open_date,103) as open_date,Convert(varchar,close_date,103) as close_date,flight_open.flight_date as fd,flight_type,destination_code,capacity,sum(gross_weight) as hgross_weight,sum(charged_weight) as hcharged_weight from flight_open inner join flight_master on flight_open.flight_id=flight_master.flight_id inner join booking_master on flight_open.flight_open_id=booking_master.flight_open_id inner join destination_master on destination_master.destination_id=flight_master.destination where airline_detail_id=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " and booking_master.flight_open_id=" + Convert.ToInt64(dr_fl["flight_open_id"].ToString()) + " and handovered_status=13 and  close_date>=getdate() group by flight_no,flight_open.flight_Date,flight_type,destination_code,capacity,open_date,close_date,booking_master.flight_open_id order by flight_open.flight_date ";
                    DataTable dt_hand = dw.GetAllFromQuery(Query_hand);
                    foreach (DataRow dr_hand in dt_hand.Rows)
                    {

                        Tables += "<tr><td class=text >Handedover</td><td class=text align=center>-</td><td class=text align=center>-</td><td class=text align=center>-</td><td class=text align=center>-</td><td class=text align=center>-</td><td class=text align=right>" + dr_hand["hgross_weight"].ToString() + "</td><td class=text align=right>" + dr_hand["hcharged_weight"].ToString() + "</td><td class=text ><a href='Reports/detail_handover.aspx?fd1=" + dr_fl["flight_date"].ToString() + "&amp;fd=" + dr_fl["fd"].ToString() + "&amp;airid=" + drow["airline_detail_id"].ToString() + "&amp;fno=" + dr_fl["flight_no"].ToString() + "&amp;od=" + dr_fl["open_date"].ToString() + "&amp;cd=" + dr_fl["close_date"].ToString() + "&amp;cap=" + dr_fl["capacity"].ToString() + "&amp;booked=" + dr_hand["hgross_weight"].ToString() + "&amp;air=" + drow["airline_code"].ToString() + "&amp;foid=" + dr_fl["flight_open_id"].ToString() + "' target=_blank>View Details</a></td></tr>";
                    }
                    Tables += "<tr><td class=text colspan=9><hr class=boldtext>&nbsp;</td></tr>";

                }

                Tables += "</table><br>";
            }

            Label2.Text = Tables;
        }
        else
        {
            HyperLink1.Visible = false;
            Tables += @"<object classid=""clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"" codebase=""http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0"" width=""800"" height=""270""><param name=""movie"" value=""flash_cpp1.swf"" /><param name=""quality"" value=""high"" /><embed src=""flash_cpp1.swf"" quality=""high"" pluginspage=""http://www.macromedia.com/go/getflashplayer"" type=""application/x-shockwave-flash"" width=""735"" height=400 bgcolor=#F2FEF9 ></embed></object>";
            Label3.Text = Tables;

            if (Session["groupid"].ToString() == "5")
            {
                HyperLink1.Visible = true;
                grddetails.Visible = true;
                lblAgShow.Visible = true;
                lblMessage.Visible = true;
                string strtb = "<table style=font: caption; text-align: left; border-top: purple thin dotted; border-right-style: dotted; border-left-style: dotted; border-bottom-style: dotted; width=100% border=0>            <tr><td style=height: 20px;color: olive colspan=3><marquee BEHAVIOR=ALTERNATE >::::::Please Update Your PAN & TAN No:::::</marquee></td></tr></table>";
                 lblAgShow.Text = strtb;
                 string stMsg = "<table style=font: caption; text-align: left; border-top: purple thin dotted; border-right-style: dotted; border-left-style: dotted; border-bottom-style: dotted; width=100% border=0>            <tr><td style=height: 20px;color: olive colspan=3>FORM-16A ARE READY, PLEASE COLLECT THE SAME AND PROVIDE US OUR FORM-16A AS EARLY AS POSSIBLE</td></tr></table>";
                 lblMessage.Text = stMsg;
                DataTable stshow = dw.GetAllFromQuery("select agent_branch_id,pan_no,tan_no from Agent_master AM inner join agent_branch AB on AB.Agent_id=am.agent_id where ab.agent_branch_id=" + Session["ID"].ToString() + " and ab.belongs_to_city=" + Session["BELONG_TO_CITY"] + "");
                if (stshow.Rows.Count > 0)
                {
                    grddetails.DataSource = stshow;
                    grddetails.DataBind();
                }
            }
        }


    }


    protected void Modify(object sender, CommandEventArgs e)
    {
        Session["AGID"] = e.CommandName;
        Response.Redirect("Tan_Change.aspx");
    }
}
