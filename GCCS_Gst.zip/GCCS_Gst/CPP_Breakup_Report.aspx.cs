﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CPP_Breakup_Report : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand com = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string Table = "";
    int SNo = 0;
    decimal ChargebleWeight = 0;
    decimal cppamount = 0;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        else
        {
            ShowDetails();
        }
    }
    protected void ShowDetails()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("GetCppBreakuData_CSR", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Agent_ID", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["AgentID"].ToString());
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["SubAgentID"].ToString());
            com.Parameters.Add("@StartDate", SqlDbType.DateTime).Value = Convert.ToDateTime(FormatDateMM(Request.QueryString["StartDate"].ToString()));
            com.Parameters.Add("@EndDate", SqlDbType.DateTime).Value = Convert.ToDateTime(FormatDateMM(Request.QueryString["EndDate"].ToString()));
            com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["Company_id"].ToString());
            com.Parameters.Add("@City_ID", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["City_ID"].ToString());
            DataSet dsCppBreakup = new DataSet();
            SqlDataAdapter daCppBreakup = new SqlDataAdapter(com);
            DataTable dtCppBreakup = new DataTable();
            daCppBreakup.Fill(dsCppBreakup);
            dtCppBreakup = dsCppBreakup.Tables[0];
            Label1.Text = "<table width=100% border=0 cellspacing=0 cellpadding=0  align=center><tr><td><br/></td></tr><tr align=center><td><h2>Cpp Breakup Report </h2></td></tr><tr align=center><td><h3><u>" + Request.QueryString["StartDate"].ToString() + " - " + Request.QueryString["EndDate"].ToString() + "</u></h3></td></tr><tr><td><br/></td></tr></table>";
            if (dtCppBreakup.Rows.Count > 0)
            {

                if (Request.QueryString["SubAgentID"].ToString() == "0")
                {
                    Table += @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle1><td colspan=4>" + dsCppBreakup.Tables[1].Rows[0]["Agent_Name"].ToString() + "</td></tr><tr class=HeaderStyle2><td>S.No</td><td>AirwaybillNo</td><td>ChargebleWeight</td><td>Cpp Points</td></tr>";
                }
                else
                {
                    Table += @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle1><td colspan=5 align=center>" + dsCppBreakup.Tables[1].Rows[0]["SubAgentName"].ToString() + "</td></tr><tr class=HeaderStyle2><td>S.No</td><td>AirwaybillNo</td><td>Agent Name</td><td>ChargebleWeight</td><td>Cpp Points</td></tr>";
                }
                for (int i = 0; i < dtCppBreakup.Rows.Count; i++)
                {
                    SNo++;
                    if (Request.QueryString["SubAgentID"].ToString() == "0")
                    {
                        Table += @"<tr><td align=center >" + SNo + "</td><td align=center >" + dtCppBreakup.Rows[i]["AirWayBill_No"].ToString() + "</td><td align=right >" + dtCppBreakup.Rows[i]["Charged_Weight"].ToString() + "</td><td align=right >" + decimal.Parse(dtCppBreakup.Rows[i]["cpp_Amount"].ToString()).ToString("0.00") + "</td></tr>";
                    }
                    else
                    {
                        Table += @"<tr><td align=center >" + SNo + "</td><td align=center >" + dtCppBreakup.Rows[i]["AirWayBill_No"].ToString() + "</td><td align=center >" + dtCppBreakup.Rows[i]["Agent_Name"].ToString() + "</td><td align=right >" + dtCppBreakup.Rows[i]["Charged_Weight"].ToString() + "</td><td align=right >" + decimal.Parse(dtCppBreakup.Rows[i]["cpp_Amount"].ToString()).ToString("0.00") + "</td></tr>";
                    }

                    cppamount += decimal.Parse(dtCppBreakup.Rows[i]["cpp_Amount"].ToString());
                    ChargebleWeight += decimal.Parse(dtCppBreakup.Rows[i]["Charged_Weight"].ToString());
                }

                if (Request.QueryString["SubAgentID"].ToString() == "0")
                {
                    Table += @"<tr class=HeaderStyle2><td colspan=2>Total</td><td align=right>" + ChargebleWeight + "</td><td align=right>" + cppamount.ToString("0.00") + "</td></tr>";
                }
                else
                {
                    Table += @"<tr class=HeaderStyle2><td colspan=3>Total</td><td align=right>" + ChargebleWeight + "</td><td align=right>" + cppamount.ToString("0.00") + "</td></tr>";
                }
                Table += @"</table>";
            }
            else
            {
                Table += @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=text><td class=boldtext style=""color: Red;font-family:verdana;font-size:12px;  text-align: center;"" colspan=6>No record found.</td></tr></table>";

            }
            lblDetails.Text = Table.ToString();
        }
        catch (Exception ex)
        { }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
