using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class sdf : System.Web.UI.Page
{
    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Add User</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>Sep 07</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription>insert all value in user_master & update</changeDescription>
    /// <modifiedBy>Mukul Chandra</modifiedBy>
    /// <modifiedOn>08/10/2007</modifiedOn>
    /// <modifiedby>Mukul Chandra</modifiedby>
    /// <modifiedOn>22/10/2007</modifiedOn>
    /// <changeDescription>insert all value in user_master & update with trans & modified desining css etc</changeDescription>
    /// </modification>
      //  By Alok Kumar Sharma Date:16.11.2007
    /// </modifications> 
    /// </summary> 
    ///
    #endregion
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  //connection string

    #region variables Declaration

    string id;
    string pp;
    string qq;
    string tt;
    int sy = 0;
    string mm;
    string aa;
    string rra = "";
    string ts = "";
    string ma = "";
    SqlCommand cmd;
    SqlDataReader rdr;
    string gid = "";
    string userid;
    SqlConnection con;
    SqlTransaction trans;
    string strquery = "";
    #endregion
    #region pageload coding

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {          
            if (!IsPostBack)
            {
                ddl();           // function for binding dropdown for city name;
                ddlairlin();     //function for binding ListBox for airline name;
                ddlgtype();     // function for binding dropdown for group name;
                ddlstat();      // function for  binding status name.
                //ddlcityrights();// function for binding listbox for city rights.
            }

         

            if (!Page.IsPostBack && Request.QueryString["userid"] != null)// fetching querystirng with pageload
            {
            //    if (Request.QueryString["Chk"] != null)
            //{
            //    tr_grp.Visible = false;
            //    tr_Em.Visible = false;
            //    tr_pass.Visible = false;
            //    tr_name.Visible = false;
            //    tr_city.Visible = false;
            //    tr_accs.Visible = false;
            //    tr_St.Visible = false;

            //}
                btnupdate.Attributes.Add("onclick", "return numeric()");// calling javascript function;
                btnadd.Visible = false;
                btnadd.Enabled = false;
               
                btnReset.Visible = false;
                btnReset.Enabled = false;
                txtemail.ReadOnly = true;
                lblHead.Text = "Edit User";
                btnupdate.Visible = true;
                btnupdate.Enabled = true;
                btnCancel.Visible = true;
                if (Session["groupid"].ToString() == "2" || Session["groupid"].ToString() == "3" || Session["groupid"].ToString() == "5" || Session["groupid"].ToString() == "6" || Session["groupid"].ToString() == "7" || Session["groupid"].ToString() == "8" || Session["groupid"].ToString() == "9" || Session["groupid"].ToString() == "10" || Session["groupid"].ToString() == "11" || Session["groupid"].ToString() == "13" || Session["groupid"].ToString() == "15" || Session["groupid"].ToString() == "12" || Session["groupid"].ToString() == "43")
                {
                    ListBox2.Enabled = false;

                    ddltype.Enabled = false;
                    ddlstatus.Enabled = false;
                    ddlcity.Enabled = false;
                    txtpass.ReadOnly = true;
                    
                }
                if (Session["groupid"].ToString() == "1")
                {
                    ListBox2.Enabled = true;
                    ddltype.Enabled = true;
                    ddlstatus.Enabled = true; 
                    ddlcity.Enabled = true; 
                    txtpass.ReadOnly = false;
                    
                }


                userid = Convert.ToString(Request.QueryString["userid"]);// assign querystring into userid


                coverdata(); // function for cover datavalue for editable mode for user_master;    
                status();   //  function for cover datavalue for status name;
                coveridpas(); //function for cover datavalue for login_master;
            }
            else if (!Page.IsPostBack)
            {
                btnadd.Attributes.Add("onclick", "return numeric()");// Calling javascript function;
                lblHead.Text = "Add User";
                btnadd.Visible = true;
                btnadd.Enabled = true;
                btnupdate.Visible = false;
                btnupdate.Enabled = false;
                btnCancel.Visible = true;
                ddlstatus.SelectedIndex = 1;
            }



        }
    }
    #endregion
        #region coding for insert button
        protected void btnadd_Click(object sender, EventArgs e)// insert values.
    {
       
             btnupdate.Enabled = false;
             btnupdate.Visible = false;
        
        using (con)
        {
                con = new SqlConnection(strCon);
                con.Open();
                try
                {
                    trans = con.BeginTransaction();

                    //foreach (int i in ListBox1.GetSelectedIndices())    // values store in listbox
                    //{
                    //    if (ListBox1.Items[i].Selected)
                    //    {
                    //    tt = ListBox1.Items[i].Value + ",";
                    //    mm = mm + tt;

                    //    }
                    // }

                    strquery = "insert into User_Master(Full_Name,Address,Phone,Mobile,Status,Created_By,Created_On,Belongs_To_City,Email)values(@Full_Name,@Address,@Phone,@Mobile,@Status,@Created_By,@Created_On,@Belongs_To_City,@Email)";
                    cmd = new SqlCommand(strquery, con, trans);
                    cmd.Parameters.Add("@Full_Name", SqlDbType.VarChar, 100).Value = txtname.Text;
                    cmd.Parameters.Add("@Belongs_To_City", SqlDbType.VarChar, 50).Value = ddlcity.SelectedValue;

                    cmd.Parameters.Add("@Address", SqlDbType.VarChar, 250).Value = txtadd.Text;
                    cmd.Parameters.Add("@Phone", SqlDbType.VarChar, 50).Value = txtphone.Text;
                    cmd.Parameters.Add("@Mobile", SqlDbType.VarChar, 50).Value = txtmobile.Text;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar, 250).Value = txtemail.Text;
                    //cmd.Parameters.Add("@City_Rights", SqlDbType.VarChar, 100).Value = mm;

                    cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100).Value = ddlstatus.SelectedItem.Value.ToString();
                    cmd.Parameters.Add("@Created_By", SqlDbType.VarChar, 100).Value = Session["EMailID"];
                    cmd.Parameters.Add("@Created_On", SqlDbType.VarChar, 100).Value = DateTime.Now;
                    cmd.ExecuteNonQuery();
                    foreach (int i in ListBox2.GetSelectedIndices())    // values store in listbox
                    {
                        if (ListBox2.Items[i].Selected)
                        {
                            ts = ListBox2.Items[i].Value + ",";
                            ma = ma + ts;


                        }

                    }
                    string tt = ma.Substring(0, ma.LastIndexOf(','));
                    strquery = "select max(UserID) from dbo.User_Master";
                    cmd = new SqlCommand(strquery, con, trans);
                    int aa = Convert.ToInt32(cmd.ExecuteScalar().ToString());

                    strquery = "insert into Login_Master(Email_ID,Login_Password,User_ID,Group_ID,Airline_Access  )values(@Email_ID,@Login_Password,@User_ID ,@Group_ID,@Airline_Access )";
                    cmd = new SqlCommand(strquery, con, trans);
                    cmd.Parameters.Add("@Email_ID", SqlDbType.VarChar, 100).Value = txtemail.Text;
                    cmd.Parameters.Add("@Login_Password", SqlDbType.VarChar, 50).Value = txtpass.Text;
                    cmd.Parameters.Add("@User_ID", SqlDbType.BigInt).Value = aa;
                    cmd.Parameters.Add("@Group_ID", SqlDbType.BigInt).Value = ddltype.SelectedItem.Value;
                    cmd.Parameters.Add("@Airline_Access", SqlDbType.VarChar, 50).Value = tt;

                    cmd.ExecuteNonQuery();
                    trans.Commit();
                    Response.Redirect("User_Details.aspx");
                }
                catch (SqlException ss)
                {
                    if (ss.Number == 2627)
                    {
                        lblalreadyexists.Visible = true;
                        lblalreadyexists.Text = "Email Already Exists";

                    }
                    else
                    {
                        lblalreadyexists.Visible = true;
                        lblalreadyexists.Text = "Sql Error" + ss.Message;

                    }

                    trans.Rollback();
                }
                finally//add by hn mishra
                {
                    if (con != null || con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }

                }
          
        }


    }
        #endregion
    #region tocover datavalue from user_master for editable mode
    public void coverdata()
    {
        id = Convert.ToString(Request.QueryString["userid"]);
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;              
        cmd.CommandText = "select Full_Name,Address,Phone,Mobile,Email,Status,Belongs_To_City from user_master  where userid='" + id + "'";
        cmd.Connection.Open();
        rdr = cmd.ExecuteReader();
        rdr.Read();
        txtname.Text = rdr["Full_Name"].ToString();
        string q = rdr["Belongs_To_City"].ToString();
        for (int p = 0; p <= (ddlcity.Items.Count - 1); p++)
        {
            if (ddlcity.Items[p].Value == q)
            {
                ddlcity.Items[p].Selected = true;
            }

        }
        
        txtpass.TextMode = TextBoxMode.SingleLine;
       

        txtadd.Text = rdr["Address"].ToString();
        txtphone.Text = rdr["Phone"].ToString();
        txtmobile.Text = rdr["Mobile"].ToString();
        txtemail.Text = rdr["Email"].ToString();
        
        string s = rdr["Status"].ToString();
        for (int p = 0; p <= (ddlstatus.Items.Count - 1); p++)
        {
            if (ddlstatus.Items[p].Value == s)
            {
                ddlstatus.Items[p].Selected = true;
            }

        }
        //string z = rdr["City_Rights"].ToString();
        //string[] zz = z.Split(new char[] { ',' });
        //for (int j = 0; j < zz.Length; j++)
        //{
        //    for (int i = 0; i <= (ListBox1.Items.Count - 1); i++)
        //    {
        //        if (ListBox1.Items[i].Value == zz[j])
        //        {
        //            ListBox1.Items[i].Selected = true;
        //        }
        //    }
        //}       
       
         cmd.Connection.Close();

     }
    #endregion
     #region..coding for udpdate button
     protected void btnupdate_Click(object sender, EventArgs e)
    {
        string str_up = "";
        using (con)
        {
            con = new SqlConnection(strCon);
            con.Open();
            try
            {

                trans = con.BeginTransaction();

                //foreach (int j in ListBox1.GetSelectedIndices())// values store in listbox
                //{
                //    if (ListBox1.Items[j].Selected)
                //    {
                //        pp = ListBox1.Items[j].Value + ",";
                //        qq = qq + pp;
                //    }
                //}
                //if (Request.QueryString["Chk"] != null)
                //{
                //    str_up = "UPDATE  dbo.User_Master SET Address='"+txtadd.Text+"',Phone='"+txtphone.Text+"',Mobile='"+txtmobile.Text+"' WHERE UserID=" + Request.QueryString["userid"].ToString()+ "";
                   
                //    cmd = new SqlCommand(str_up, con,trans);
                //    cmd.ExecuteNonQuery();
                //}
                //else
                //{
                    mm = Convert.ToString(Request.QueryString["userid"]);
                    strquery = "update User_Master set Full_Name=@Full_Name,Belongs_To_City=@Belongs_To_City,Address=@Address,Phone=@Phone,Mobile=@Mobile,Email=@Email,Status=@Status  where UserID='" + mm + "'";
                    cmd = new SqlCommand(strquery, con, trans);
                    cmd.Parameters.Add("@Full_Name", SqlDbType.VarChar, 100).Value = txtname.Text;
                    cmd.Parameters.Add("@Belongs_To_City", SqlDbType.VarChar, 50).Value = ddlcity.SelectedValue;

                    cmd.Parameters.Add("@Address", SqlDbType.VarChar, 250).Value = txtadd.Text;
                    //cmd.Parameters.Add("@City_Rights", SqlDbType.VarChar, 100).Value = qq;
                    cmd.Parameters.Add("@Phone", SqlDbType.VarChar, 50).Value = txtphone.Text;
                    cmd.Parameters.Add("@Mobile", SqlDbType.VarChar, 50).Value = txtmobile.Text;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar, 250).Value = txtemail.Text;
                    cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100).Value = ddlstatus.SelectedValue;
                    cmd.ExecuteNonQuery();
                    foreach (int i in ListBox2.GetSelectedIndices())// values store in listbox
                    {
                        if (ListBox2.Items[i].Selected)
                        {
                            ts = ListBox2.Items[i].Value + ",";
                            ma = ma + ts;

                        }


                    }
                    string ss = ma.Substring(0, ma.LastIndexOf(','));
                    strquery = "update  Login_Master set Email_ID=@Email_ID,Login_Password=@Login_Password,Group_ID=@Group_ID,Airline_Access=@Airline_Access where User_ID='" + mm + "'";
                    cmd = new SqlCommand(strquery, con, trans);
                    cmd.Parameters.Add("@Email_ID", SqlDbType.VarChar, 100).Value = txtemail.Text;
                    cmd.Parameters.Add("@Login_Password", SqlDbType.VarChar, 50).Value = txtpass.Text;

                    cmd.Parameters.Add("@Group_ID", SqlDbType.BigInt).Value = ddltype.SelectedItem.Value;
                    cmd.Parameters.Add("@Airline_Access", SqlDbType.VarChar, 200).Value = ss;
                    cmd.ExecuteNonQuery();
                    strquery = "insert into user_history(Full_Name,Belongs_To_City,Address,Phone,Mobile,Email,Status,Email_ID,Login_Password,Group_ID,Airline_Access,Entered_By,Entered_On)values(@Full_Name,@Belongs_To_City,@Address,@Phone,@Mobile,@Email,@Status,@Email_ID,@Login_Password,@Group_ID,@Airline_Access,@Entered_By,@Entered_On)";
                    cmd = new SqlCommand(strquery, con, trans);
                    cmd.Parameters.Add("@Full_Name", SqlDbType.VarChar, 100).Value = txtname.Text;
                    cmd.Parameters.Add("@Belongs_To_City", SqlDbType.VarChar, 50).Value = ddlcity.SelectedValue;

                    cmd.Parameters.Add("@Address", SqlDbType.VarChar, 250).Value = txtadd.Text;
                    //cmd.Parameters.Add("@City_Rights", SqlDbType.VarChar, 100).Value = qq;
                    cmd.Parameters.Add("@Phone", SqlDbType.VarChar, 50).Value = txtphone.Text;
                    cmd.Parameters.Add("@Mobile", SqlDbType.VarChar, 50).Value = txtmobile.Text;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar, 250).Value = txtemail.Text;
                    cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100).Value = ddlstatus.SelectedValue;
                    cmd.Parameters.Add("@Email_ID", SqlDbType.VarChar, 100).Value = txtemail.Text;
                    cmd.Parameters.Add("@Login_Password", SqlDbType.VarChar, 50).Value = txtpass.Text;

                    cmd.Parameters.Add("@Group_ID", SqlDbType.BigInt).Value = ddltype.SelectedItem.Value;
                    cmd.Parameters.Add("@Airline_Access", SqlDbType.VarChar, 200).Value = ss;
                    cmd.Parameters.Add("@Entered_By", SqlDbType.VarChar, 50).Value = Session["EMailID"];
                    cmd.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = System.DateTime.Now;
                    cmd.ExecuteNonQuery();
               //}
                trans.Commit();
                con.Close();
            }
            catch (SqlException tt)
            {
                Response.Redirect("sql error" + tt.Message);
                trans.Rollback();

            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            //if (Request.QueryString["Chk"] != null)
            //{
            //    Response.Redirect("LoginSuccess.aspx");
            //}
            //else
            //{
                Response.Redirect("User_Details.aspx");
          //  }
        }
    }
     #endregion
    #region coding for reset button
    protected void btnReset_Click(object sender, EventArgs e)
    {
        txtname.Text = null;

        txtemail.Text = null;
        txtmobile.Text = null;
        txtphone.Text = null;
        ddlstatus.SelectedIndex = 0;
        txtadd.Text = null;

        txtpass.Text = null;
        ddltype.SelectedIndex = 0;
        ddlcity.SelectedIndex = 0;
        //ListBox1.SelectedIndex = -1;
        ListBox2.SelectedIndex = -1;
    }
    #endregion
    #region ddlcity
    public void ddl()
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.CommandText = "select city_name+'-'+city_code as 'code',city_id from dbo.City_Master";
        cmd.Connection = con;
        cmd.Connection.Open();
        ddlcity.DataTextField = "code";
        ddlcity.DataValueField = "city_id";

        try
        {
            rdr = cmd.ExecuteReader();
        }
        catch (SqlException ee)
        {
            Response.Write("sql error" + ee.Message);
        }
        ddlcity.DataSource = rdr;
        ddlcity.DataBind();
        ddlcity.Items.Insert(0, "- -Select- -");
        cmd.Connection.Close();
    }
    #endregion
    #region ddlairline
    public void ddlairlin()
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.CommandText = "select cm.City_Code + ',' + space(2) + am.airline_name + '-'+ am.airline_code as code, ad.airline_detail_id  from airline_master as am inner join airline_detail as ad on am.airline_id=ad.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City";
        cmd.Connection = con;
        cmd.Connection.Open();
        ListBox2.DataTextField = "code";
        ListBox2.DataValueField = "airline_detail_id";
        SqlDataReader rdr = cmd.ExecuteReader();
        ListBox2.DataSource = rdr;
        ListBox2.DataBind();
        //ListBox2.Items.Insert(0, "Select Airline");
        cmd.Connection.Close();

    }
    #endregion
    #region ddlgroup
    public void ddlgtype()
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.CommandText = "select Group_Name,Group_ID from Group_Master ";
        cmd.Connection = con;
        cmd.Connection.Open();
        ddltype.DataTextField = "Group_Name";
        ddltype.DataValueField = "Group_ID";

        SqlDataReader rdr = cmd.ExecuteReader();
        ddltype.DataSource = rdr;
        ddltype.DataBind();
        ddltype.Items.Insert(0, "- -Select- -");
        cmd.Connection.Close();
    }
    #endregion
    #region to bind status in ddlstatus
    public void ddlstat()
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.CommandText = "select Status_ID,Status_Name from  Status_Master where Status_ID in(2,5) ";
        cmd.Connection = con;
        cmd.Connection.Open();
        ddlstatus.DataTextField = "Status_Name";
        ddlstatus.DataValueField = "Status_ID";

        SqlDataReader rdr = cmd.ExecuteReader();
        ddlstatus.DataSource = rdr;
        ddlstatus.DataBind();
        ddlstatus.Items.Insert(0, "- -Select - - ");
        cmd.Connection.Close();
    }
    #endregion

    #region tocover datavalue from login_master for editable mode
    public void coveridpas()
    {
        id = Convert.ToString(Request.QueryString["userid"]);
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "select g.Group_Name,g.Group_ID from Group_Master as g inner join Login_Master as l on g.Group_ID=l.Group_ID where l.User_ID='" + id + "'";

        cmd.Connection.Open();
        rdr = cmd.ExecuteReader();

        rdr.Read();
        
        ddltype.SelectedValue = rdr["Group_ID"].ToString();
        string gid = rdr["Group_ID"].ToString();
        
        cmd.Connection.Close();

        id = Convert.ToString(Request.QueryString["userid"]);
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "select Email_ID,Group_ID,Login_Password,Airline_Access from Login_Master where User_ID='" + id + "' and Group_ID='" + gid + "'";
        
        cmd.Connection.Open();
        rdr = cmd.ExecuteReader();

        rdr.Read();

        txtpass.TextMode = TextBoxMode.SingleLine;
        txtpass.Text = rdr["Login_Password"].ToString();
        string strAirlineAccess = rdr["Airline_Access"].ToString();
        string[] arrAirline = strAirlineAccess.Split(new char[] { ',' });


        for (int j = 0; j < arrAirline.Length; j++)
        {
            for (int i = 0; i <= (ListBox2.Items.Count - 1); i++)
            {
                if (ListBox2.Items[i].Value == arrAirline[j])
                {
                    ListBox2.Items[i].Selected = true;
                }
            }
        }
        for (int p = 0; p <= (ddltype.Items.Count - 1); p++)
        {
            if (ddltype.Items[p].Value == gid)
            {
                ddltype.Items[p].Selected = true;
            }

        }

         cmd.Connection.Close();
     }
    #endregion


    
    #region cover data value for editable mode(status)
    public void status()
    {

        id = Convert.ToString(Request.QueryString["userid"]);
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "select s.Status_Name,s.Status_ID from dbo.Status_Master as s inner join dbo.User_Master as u on u.Status=s.Status_ID where u.UserID='" + id + "'";
        cmd.Connection.Open();
        rdr = cmd.ExecuteReader();
        rdr.Read();
        ddlstatus.SelectedItem.Text = rdr["Status_Name"].ToString();
        ddlstatus.SelectedItem.Value = rdr["Status_ID"].ToString();
        cmd.Connection.Close();
    }
    #endregion




    #region ddlcityrights
    //public void ddlcityrights()
    //{
    //    con = new SqlConnection(strCon);
    //    cmd = new SqlCommand();
    //    cmd.CommandText = "select city_name+'-'+city_code as 'code',city_id from dbo.City_Master";
    //    cmd.Connection = con;
    //    cmd.Connection.Open();
    //    ListBox1.DataTextField = "code";
    //    ListBox1.DataValueField = "city_id";


    //    SqlDataReader rdr = cmd.ExecuteReader();
    //    ListBox1.DataSource = rdr;
    //    ListBox1.DataBind();
    //    //ListBox1.Items.Insert(0, "Select City");


    //    cmd.Connection.Close();


    //}
    #endregion

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("User_Details.aspx");
    }
}
