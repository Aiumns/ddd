using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class DO_Receipt_Show : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();

    decimal total = 0;
    decimal totalOnCondition = 0;

    decimal Carting = 0;
    decimal DataProcessingFee = 0;
    decimal CommunicationFee = 0;
    decimal MAWB = 0;
    decimal HAWB = 0;
    decimal srate = 0;

    decimal StaxRate = 0;
    decimal DOamount = 0;
    decimal Docahrges = 0;
    decimal NetAmount = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        decimal Receivable_Amt = 0;
        decimal Total_Receivable_Amt = 0;
        decimal Receivable_AmtCash = 0;
        decimal Receivable_AmtCheque = 0;
        decimal TotalReceivable_AmtCash = 0;
        decimal TotalReceivable_AmtCheque = 0;
        decimal pay_amt = 0;
        decimal total_pay_amt = 0;

        //decimal Receivable_Amt1 = 0;
        //decimal Total_Receivable_Amt1 = 0;
        //decimal pay_amt1 = 0;
        //decimal total_pay_amt1 = 0;

        string[] airline_name_city_text = Session["airline_city_text"].ToString().Split(',');
        string[] airline_name_city_value = Session["airline_city_value"].ToString().Split(',');
        string[] air_name_val = airline_name_city_value[0].Split('%');
        string from_date = Session["from_date"].ToString();
        string to_date = Session["to_date"].ToString();

        Label1.Text = "<table width=100%  border=0 cellspacing=0 cellpadding=0  align=center ><tr><td><br/></td></tr><tr align=center  ><td><h2>Delivery Order Cash Record</h2></td></tr><tr><td></td></tr><tr align=center ><td><h4>" + FormatDateDD(from_date) + " - " + FormatDateDD(to_date) + "</h4></td></tr><tr><td><br/></td></tr></table>";
        string Table1 = "";
        string Query = "";
        if (airline_name_city_value[0] == "0")
        {
            Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ") order by airline_name";
        }
        else
        {
            Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + airline_name_city_value[0].ToString() + ") order by airline_name";
        }

        Int32 count = 1;
        int sno = 0;
        DataTable dt = dw.GetAllFromQuery(Query);
        foreach (DataRow drow in dt.Rows)
        {
           
            Table1 += "<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle1><td colspan=9  align=center >" + drow["airline_code"].ToString() + "-" + drow["airline_name"].ToString() + "-" + drow["city_code"].ToString() + "</td></tr><tr class=HeaderStyle2><td  >S. No.</td><td  >Rcpt. No.</td><td  >Flight No </td><td >Flight Date</td><td>MAWB</td><td  >HAWB</td><td  align=right>Cheque No</td><td colspan=2 >Received Amt</td></tr><tr class=HeaderStyle2><td colspan=7>&nbsp;</td><td >Cash</td><td >Cheque</td></tr> ";

            //Query = " select IB.Import_awb_id as Import_awb_id,IB.import_awb_no  as import_awb_no,IFO.Import_Flight_No as Import_Flight_No,convert(varchar,IFO.Flight_Date,103) as flight_date,No_of_houses,payable_amount,amount_received  from import_flight_open IFO inner join Import_Awb IB on IFO.Import_Flight_open_ID=IB.Import_Flight_open_ID where amt_recd_date between '" + FormatDateMM(from_date) + "' and '" + FormatDateMM(to_date) + "' and  IFO.airline_detail_id=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + "";


            if (DateTime.Parse(FormatDateMM(to_date)) < DateTime.Parse("08/01/2017"))
            {
                Query = "SELECT CONVERT(INT, SUBSTRING(Recipt_No,14,LEN(Recipt_No))) AS reciptno ,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC, IFA.Import_awb_id,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,ISNULL(IFA.Tds_Cut_By_Agent,0) AS Stax_Amount,ISNULL(IFA.stax_rate,0) AS ServiceTax_Amount,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.MAWBDO_Chgs,0) as MAWBDO_Chgs,isnull(IFA.HAWBDO_Chgs,0) as HAWBDO_Chgs,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,IFA.Tds_Cut_By_Agent,IFA.Total_Collection_CC AS FrtChrgs,IFA.Payment_Mode,isnull(IFA.Cheque_no,0) AS ChequeNo FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID  WHERE CONVERT(VARCHAR,IFA.issue_date,101) >= '" + FormatDateMM(from_date) + "' and CONVERT(VARCHAR,IFA.issue_date,101) <='" + FormatDateMM(to_date) + "' AND IFA.Airline_Detail_ID=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " order by reciptno";
            }
            else
            {
                Query = "SELECT CONVERT(INT, SUBSTRING(Recipt_No,11,LEN(Recipt_No))) AS reciptno ,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC, IFA.Import_awb_id,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,ISNULL(IFA.Tds_Cut_By_Agent,0) AS Stax_Amount,ISNULL(IFA.stax_rate,0) AS ServiceTax_Amount,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.MAWBDO_Chgs,0) as MAWBDO_Chgs,isnull(IFA.HAWBDO_Chgs,0) as HAWBDO_Chgs,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,IFA.Tds_Cut_By_Agent,IFA.Total_Collection_CC AS FrtChrgs,IFA.Payment_Mode,isnull(IFA.Cheque_no,0) AS ChequeNo FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID  WHERE CONVERT(VARCHAR,IFA.issue_date,101) >= '" + FormatDateMM(from_date) + "' and CONVERT(VARCHAR,IFA.issue_date,101) <='" + FormatDateMM(to_date) + "' AND IFA.Airline_Detail_ID=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " order by reciptno";
            }

            DataTable dt_cal = dw.GetAllFromQuery(Query);
            count = 1;
            sno = 0;
            if (dt_cal.Rows.Count > 0)
            {

                foreach (DataRow dro in dt_cal.Rows)
                {
                    Receivable_AmtCash = 0;
                    Receivable_AmtCheque = 0;
                    CommunicationFee = 0;
                    DataProcessingFee = 0;
                    StaxRate = 0;
                    Carting = 0;
                    sno++;
                    //string MawbDo_Chgs="0";
                    //string HawbDo_Chgs="0";
                    //string Cartage = "0";
                    //string DataProcessing = "0";
                    //string CommunicationChrgs = "0";
                     string STAXRATE="0";
                    
                    decimal Stax=0;
                   // decimal staxdetail=0;
                    pay_amt = 0;
                    DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportflightAwb_Trans where ImportAwbId=" + dro["Import_awb_id"].ToString() + "");

                    for (int k = 0; k < dtImportAwbTrans.Rows.Count; k++)
                    {
                        if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "MAWB")
                            MAWB = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "HAWB")
                            HAWB = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "Carting")
                            Carting = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "StaxRate")
                        {
                            StaxRate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                            srate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeRate"].ToString()); ;
                        }
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "CommunicationFee")
                            CommunicationFee = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "DataProcessingFee")
                            DataProcessingFee = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                    }

                    if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
                    {
                        DOamount = MAWB;
                        Docahrges = MAWB;
                    }
                    else if (drow["airline_detail_id"].ToString() == "159")
                    {
                        DOamount = MAWB + HAWB;
                        if (StaxRate.ToString() == "0.00")
                            Docahrges = DOamount;
                        else
                            Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate)) / 100)));


                    }

                    else
                    {
                        DOamount = MAWB + HAWB;

                        Docahrges = DOamount - StaxRate;
                    }





                    //for (int i = 0; i < dtImportAwbTrans.Rows.Count; i++)
                    //{
                    //    if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() != "StaxRate")
                    //    {
                    //        pay_amt += Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]);
                    //    }
                    //    if (dtImportAwbTrans.Rows[i]["ChargeName"].ToString() == "StaxRate")
                    //    {
                    //        STAXRATE = dtImportAwbTrans.Rows[i]["ChargeRate"].ToString();
                    //        Stax = Math.Round(Convert.ToDecimal(dtImportAwbTrans.Rows[i]["ChargeAmount"]), 0, MidpointRounding.AwayFromZero);

                    //    }
                    //}
                    total_pay_amt = total_pay_amt + pay_amt;
                    Receivable_Amt = pay_amt;
                    //string FrtChrgs = "0";
                    
                    ///******************Condition For Frt chrgs****************/
                    //if (decimal.Parse(dro["FrtChrgs"].ToString() == string.Empty ? "0" : dro["FrtChrgs"].ToString()) > 0)
                    //{
                    //    FrtChrgs = dro["FrtChrgs"].ToString();
                    //    pay_amt = pay_amt + decimal.Parse(FrtChrgs);
                    //}
                    //decimal TDs_CuttBy_Agent=0;
                    //********For Tds Deduction********************
                    //TDs_CuttBy_Agent =Math.Ceiling(Convert.ToDecimal(dro["Tds_Cut_By_Agent"].ToString() == string.Empty ? "0" : dro["Tds_Cut_By_Agent"].ToString()));
                    //decimal ServiceTax=0;
                    //ServiceTax = Convert.ToDecimal(STAXRATE);
                    //if (TDs_CuttBy_Agent > 0)
                    //{
                    //        Receivable_Amt = (pay_amt) - Convert.ToDecimal(TDs_CuttBy_Agent);
                    //        Total_Receivable_Amt = Total_Receivable_Amt + Receivable_Amt;
                    //}

                    if (dro["Payment_Mode"].ToString() == "1")
                    {
                        if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
                            pay_amt = DOamount + StaxRate + Carting + CommunicationFee + DataProcessingFee + HAWB - Convert.ToDecimal(dro["Stax_Amount"].ToString()) + Convert.ToDecimal(dro["Total_Collection_CC"].ToString());
                        else
                            pay_amt = Docahrges + StaxRate + Carting + CommunicationFee + DataProcessingFee - Convert.ToDecimal(dro["Stax_Amount"].ToString()) + Convert.ToDecimal(dro["Total_Collection_CC"].ToString());

                       

                        total_pay_amt = total_pay_amt + pay_amt;
                        Receivable_Amt = pay_amt;

                        Receivable_AmtCash = Receivable_Amt;
                        TotalReceivable_AmtCash += Receivable_AmtCash;
                    }
                    else if (dro["Payment_Mode"].ToString() == "2")
                    {
                        if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
                            pay_amt = DOamount + StaxRate + Carting + CommunicationFee + DataProcessingFee + HAWB - Convert.ToDecimal(dro["Stax_Amount"].ToString()) + Convert.ToDecimal(dro["Total_Collection_CC"].ToString());
                        else
                            pay_amt = Docahrges + StaxRate + Carting + CommunicationFee + DataProcessingFee - Convert.ToDecimal(dro["Stax_Amount"].ToString()) + Convert.ToDecimal(dro["Total_Collection_CC"].ToString());
                        
                        total_pay_amt = total_pay_amt + pay_amt;
                        Receivable_Amt = pay_amt;

                        Receivable_AmtCheque = Receivable_Amt;
                        TotalReceivable_AmtCheque += Receivable_AmtCheque;
                    }
                    //********For SERVICE TAX Deduction********************
                    //if (ServiceTax > 0)
                    //{
                    //    ////Receivable_Amt = (Convert.ToDecimal(dro["MAWBDO_Chgs"].ToString()) + (Convert.ToDecimal(dro["HAWBDO_Chgs"].ToString()) * Convert.ToDecimal(dro["No_of_Houses"].ToString()))) - Convert.ToDecimal(dro["ServiceTax_Amount"].ToString());


                        //    Receivable_Amt1 = (pay_amt) / (1 + ((Stax) / 100));

                        //    Total_Receivable_Amt = Total_Receivable_Amt + Receivable_Amt1;
                    //}

                    else
                    {
                        if ((airline_name_city_value[0].ToString() == "147")||(airline_name_city_value[0].ToString() == "153"))
                            pay_amt = DOamount + StaxRate + Carting + CommunicationFee + DataProcessingFee + HAWB - Convert.ToDecimal(dro["Stax_Amount"].ToString()) + Convert.ToDecimal(dro["Total_Collection_CC"].ToString());
                        else
                            pay_amt = Docahrges + StaxRate + Carting + CommunicationFee + DataProcessingFee - Convert.ToDecimal(dro["Stax_Amount"].ToString()) + Convert.ToDecimal(dro["Total_Collection_CC"].ToString());
                        total_pay_amt = total_pay_amt + pay_amt;
                      


                        Receivable_Amt = pay_amt;

                        Total_Receivable_Amt = Total_Receivable_Amt + Receivable_Amt;
                    }
                    Table1 += "<tr class=tabletd><td >" + sno + "</td><td >" + dro["Recipt_No"].ToString() + "</td><td  >" + dro["Import_Flight_No"].ToString() + "</td><td >" + dro["flight_date"].ToString() + "</td><td  >" + dro["import_awb_no"].ToString() + "</td><td  align=right >" + dro["No_of_houses"].ToString() + "</td><td  align=right >" + dro["ChequeNo"].ToString() + "</td><td  align=right>" + Math.Round(Receivable_AmtCash, MidpointRounding.AwayFromZero) + "</td><td  align=right>" + Math.Round(Receivable_AmtCheque, MidpointRounding.AwayFromZero) + "</td></tr>";

                    count++;

                }
            }
            else
            {
                Table1 += "<tr class=tabletd ><td  align=center colspan=9 class=error>NO RECORD FOUND FOR THIS AIRLINE</td></tr>";
            }
            Table1 += "<tr  class=GrandTotal><td  align=right colspan=7 >Total</td><td  align=right  nowrap> " + Math.Round(TotalReceivable_AmtCash, MidpointRounding.AwayFromZero) + "</td><td  align=right > " + Math.Round(TotalReceivable_AmtCheque, MidpointRounding.AwayFromZero) + "</td></tr>";
            Total_Receivable_Amt = 0;
            total_pay_amt = 0;
            TotalReceivable_AmtCash = 0;
            TotalReceivable_AmtCheque=0;
           
            Table1 += "</table><br>";
        }
       
        Label2.Text += Table1;

    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateDD(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
