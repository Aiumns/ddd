using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class flightDiscount : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataAdapter sda = null;
    string flight_id = null;
    string shipment = null;
    string date = null;
    protected void Page_Load(object sender, EventArgs e)
    {        date = Request.QueryString["date"].ToString();
        flight_id = Request.QueryString["fno"].ToString();

        string s = showDetails(Request.QueryString["date"].ToString(), Request.QueryString["fno"].ToString());
        string[] ssinfo = s.Split('-');
        lblFlightNo.Text = "Flight No:: " + flight_id + "  " + "Flight Date: " + date + "  " + "Close Date:" + ssinfo[7];

       // DateTime dt=Convert.ToDateTime(Request.QueryString["date"].ToString());
        ss();
       
        if (!Page.IsPostBack)
        {
            //MakeTable();
          lstSectorData();
          FillDataShipment();
          FillDatadd();
          TextBox1.Text = Request.QueryString["cap"].ToString();
          TextBox2.Text = ssinfo[7];
        }
        //DataBindGv();
    }
    protected DataTable MakeTable()
    { 
        DataTable dt = new DataTable();

        DataColumn dc1 = new DataColumn();
        dc1.Caption = "Destination:";
        dc1.ColumnName = "Destination";
        dc1.DataType = System.Type.GetType("System.String");

        DataColumn dc2 = new DataColumn();
        dc2.Caption = "Sector";
        dc2.ColumnName = "Sector";
        dc2.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc1);
        dt.Columns.Add(dc2);


        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select slab_name, from slab_master order by slab_start", con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                dt.Columns.Add(new DataColumn(dr["slab_name"].ToString(), typeof(string)));
            }
            dr.Close();
            com.Dispose(); 
            con.Close(); 
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return dt;

    }

    protected void getSlab()
    {
        try
        {
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
                              
        }

    protected void lstSectorData()
    {
       
        string searchString = null;
        con = new SqlConnection(strCon);
        if (rbtnSector.Checked == true)
            searchString = "select distinct a.sector_name,b.sector_ID from airline_sector_master a inner join flight_Sectorwise b on b.sector_ID=a.sector_ID";
        else
        {            
            searchString = "select distinct a.destination_name,b. destination from destination_master a inner join agent_Rate_master b on b. destination=a. destination_id";
        }

        try
        {
            con.Open();
            com = new SqlCommand(searchString, con);
            SqlDataReader dr = com.ExecuteReader();
            chkBoxList.Items.Clear();
            while(dr.Read())
            {               
                chkBoxList.Items.Add(new ListItem(dr[0].ToString(), dr[1].ToString()));

            }
            dr.Close();
            com.Dispose();
            con.Close();

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void rbtnSector_CheckedChanged(object sender, EventArgs e)
    {
        shipment = ddlShip.SelectedItem.Text;
        //lstSector.Items.Clear();
        FillDataShipment();
        lstSectorData();
        ddlShip.SelectedItem.Text = shipment;
    }
    protected void rbtnDes_CheckedChanged(object sender, EventArgs e)
    {
        shipment = ddlShip.SelectedItem.Text;
        //lstSector.Items.Clear();
        lstSectorData();
        FillDataShipment();
        ddlShip.SelectedItem.Text = shipment;
    }

    protected void FillDataShipment()
    {

        ddlShip.Items.Clear();
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select distinct shipment_id,shipment_name from Shipment_master order by shipment_name", con);
            SqlDataReader dr = com.ExecuteReader();
           // ddlShip.Items.Add("-Select shipment-");
           // ddlShip.Items[0].Value = "";
            while (dr.Read())
            {
                ddlShip.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));                
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;

        }
        catch(Exception be)
        {
            string err = be.Message;
        }
        finally 
        {
           if (con !=null && con.State==ConnectionState.Open)
               con.Close();
        }

    }
    //private void ss()
    //{
    //    con = new SqlConnection(strCon);
    //    sda = new SqlDataAdapter("select  slab_Name from slab_master  order by slab_start", con);
    //    DataSet ds = new DataSet();
    //    sda.Fill(ds, "slab");

    //    foreach (DataColumn dc in ds.Tables[0].Columns)
    //    {
    //        TableRow trow = new TableRow();
    //        TableCell tcellcolname = new TableCell();
    //        TableCell slabName = new TableCell();
    //        slabName.Text = "Slab:";
    //        trow.Cells.Add(slabName);
    //        foreach (DataRow dr in ds.Tables[0].Rows)
    //        {
    //            TableCell tcellcoldata = new TableCell();
    //            tcellcoldata.Controls.Add(new LiteralControl(dr[dc.ColumnName].ToString()));

    //            trow.Cells.Add(tcellcoldata);
    //        }
    //        Table1.Rows.Add(trow);
    //    }
    //    //here codiing for inputtype

    //    foreach (DataColumn dc in ds.Tables[0].Columns)
    //    {

    //        TableRow trow = new TableRow();
    //        TableCell tcellcolname = new TableCell();
    //        TableCell Value = new TableCell();
    //        Value.Text = "Value:";
    //        trow.Cells.Add(Value);
    //        //To Display the Column Data 
    //        int i = 0;
    //        foreach (DataRow dr in ds.Tables[0].Rows)
    //        {
    //            TextBox txt = new TextBox();
    //           // txt.ID = "m" + i;
    //            txt.ID = dr[0].ToString();
    //            TableCell tcellcoldata = new TableCell();
    //            //Populate the TableCell with the Column Data
    //            tcellcoldata.Controls.Add(txt);
    //            trow.Cells.Add(tcellcoldata);
    //            i = i + 1;
    //        }
    //        Table1.Rows.Add(trow);
    //    }
    //    // coding for select 
    //    foreach (DataColumn dc in ds.Tables[0].Columns)
    //    {

    //        TableRow trow = new TableRow();

    //        TableCell tcellcolname = new TableCell();
    //        TableCell prefix = new TableCell();
    //        prefix.Text = "Prefix:";
    //        trow.Cells.Add(prefix);
            
    //        int k = 0;
    //        foreach (DataRow dr in ds.Tables[0].Rows)
    //        {
    //            DropDownList ddl = new DropDownList();
    //            ddl.ID = "ll" + k;               
    //            con = new SqlConnection(strCon);
    //            con.Open();
    //            TableCell tcellcoldata = new TableCell();
    //            //Populate the TableCell with the Column Data
    //            tcellcoldata.Controls.Add(ddl);
    //            trow.Cells.Add(tcellcoldata);
    //            k = k + 1;

    //        }
    //        Table1.Rows.Add(trow);
    //    }
    //}

    private void ss()
    {
        con = new SqlConnection(strCon);
        sda = new SqlDataAdapter("select slab_Name,slab_id from slab_master order by slab_start", con);
        DataSet ds = new DataSet();
        sda.Fill(ds, "slab");
        DataColumn dc;
        TableRow trow = new TableRow();
        TableCell tcellcolname = new TableCell();
        TableCell slabName = new TableCell();

        dc = ds.Tables[0].Columns[0];
        slabName.Text = "Slab:";
        trow.Cells.Add(slabName);

        foreach (DataRow dr in ds.Tables[0].Rows)
        {
            TableCell tcellcoldata = new TableCell();

            tcellcoldata.Controls.Add(new LiteralControl(dr[dc.ColumnName].ToString()));
            trow.Cells.Add(tcellcoldata);
        }


        Table1.Rows.Add(trow);

        trow = new TableRow();
        tcellcolname = new TableCell();
        TableCell Value = new TableCell();
        Value.Text = "Value:";
        trow.Cells.Add(Value);

        foreach (DataRow dr in ds.Tables[0].Rows)
        {
            TextBox txt = new TextBox();
            txt.ID = dr[1].ToString();
            txt.Text = "0";
            txt.Width =60;
            TableCell tcellcoldata = new TableCell();
            tcellcoldata.Controls.Add(txt);
            trow.Cells.Add(tcellcoldata);
        }

        Table1.Rows.Add(trow);

        trow = new TableRow();
        tcellcolname = new TableCell();
        TableCell Value1 = new TableCell();
        Value1.Text = "Prifix:";
        trow.Cells.Add(Value1);
        int i = 0;
        foreach (DataRow dr in ds.Tables[0].Rows)
        {
            DropDownList ddl = new DropDownList();
            ddl.ID = "ll" + i;
            TableCell tcellcoldata = new TableCell();
            tcellcoldata.Controls.Add(ddl);
            trow.Cells.Add(tcellcoldata);
            i = i + 1;
        }
        Table1.Rows.Add(trow);
    }

    protected void FillDatadd()
    {
          int i = 0;
         foreach (TableCell cc in Table1.Rows[1].Cells)        
           {            
            SqlConnection con = new SqlConnection(strCon);
            con.Open();
         SqlCommand com2 = new SqlCommand("select prefix_name,prefix_id from prefix_master", con);
            SqlDataReader dr5 = com2.ExecuteReader();
            while (dr5.Read() && i < Table1.Rows[1].Cells.Count-1)
            {
                DropDownList l = new DropDownList();
                l = (DropDownList)cc.FindControl("ll" + i);
               //l.Items.Add(dr5[0].ToString());
                l.Items.Add(new ListItem(dr5[0].ToString(), dr5[1].ToString()));
            }
            i = i + 1;
        }
    }
    protected string showDetails(string date, string fno)
    {
        string basicinfo = null;
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select m.flight_no,m.flight_type,c.city_name,d.destination_name,convert(varchar,o.flight_date,103)as flight_date,o.open_capacity,convert(varchar,o.close_date,103)as close_date,o.flight_id  from flight_master m inner join flight_open o on m.flight_id=o.flight_id inner join city_master c on c.city_id=m.origin inner join destination_master d on d.destination_id=m.destination where convert(varchar,o.flight_date,103)='" + date + "' and o.flight_id=(select flight_id from flight_master where flight_no='" + fno + "')", con);

            SqlDataReader sdr = com.ExecuteReader();
            if(sdr.Read())
                basicinfo = sdr[0].ToString() + "-" + sdr[1].ToString() + "-" + sdr[2].ToString() + "-" + sdr[3].ToString() + "-" + sdr[4].ToString() + "-" + sdr[5].ToString() + "-" + sdr[6].ToString() + "-" + sdr[7].ToString();
           
        }
        catch (SqlException se)
        {
            string err = se.Message;

        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

       return basicinfo;       

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string ident = null;
        string sID = null;
        string flightOpenID = null;
        string shipid = ddlShip.SelectedItem.Value;
        string s = showDetails(Request.QueryString["date"].ToString(), Request.QueryString["fno"].ToString());
        string[] ss = s.Split('-');
        con = new SqlConnection(strCon);
        //SqlTransaction tr = null;
        try
        {
            con.Open();
           // tr = con.BeginTransaction();
            
            com = new SqlCommand("select flight_open_id from flight_open where  convert(varchar,flight_Date,103)='" + date + "' and flight_id=" + ss[8] + " ", con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
                flightOpenID = dr[0].ToString();
            dr.Close();
            com.Dispose();
            // Insert data i8nto sector_datewise_discount table

            com = new SqlCommand("insert into Sector_Datewise_Discount(Flight_ID,Flight_Open_ID,Shipment_ID) values(@Flight_ID,@Flight_Open_ID,@Shipment_ID)", con);
            com.Parameters.AddWithValue("@Flight_ID", ss[8]);
            com.Parameters.AddWithValue("@Flight_Open_ID", flightOpenID);
            com.Parameters.AddWithValue("@Shipment_ID", shipid);
            int result = com.ExecuteNonQuery();
            com.Dispose();
            // con.Close();
            if (result != 0)
            {
                //con.Open();
                com = new SqlCommand("select ident_current('Sector_Datewise_Discount')", con);
                dr = com.ExecuteReader();
                if (dr.Read())
                {
                     ident = dr[0].ToString();
                    dr.Close();
                    com.Dispose();
                    if (rbtnSector.Checked == true)
                    {
                        com = new SqlCommand("select destination_id from airline_sector_details where sector_id=" + chkBoxList.SelectedItem.Value + " ", con);
                        dr = com.ExecuteReader();
                        while (dr.Read())
                        {
                      
                                SqlConnection conn = new SqlConnection(strCon);
                                conn.Open();
                                SqlCommand comm = new SqlCommand("select slab_id from slab_master order by slab_start", conn);
                                SqlDataReader drr = comm.ExecuteReader();
                                int i = 0;
                                while (drr.Read())
                                {
                                    sID = drr[0].ToString();
                                    TextBox tt = (TextBox)Table1.Rows[1].FindControl(sID);
                                    DropDownList dd = (DropDownList)Table1.Rows[1].FindControl("ll" + i);
                                    SqlConnection con7 = new SqlConnection(strCon);
                                    con7.Open();
                                    SqlCommand com7 = new SqlCommand("insert into Sector_Datewise_Discount_details(Datewise_Discount_ID,Slab_ID,Destination_ID,Sector_ID,Prefix_ID,Price_Value) values(@Datewise_Discount_ID,@Slab_ID,@Destination_ID,@Sector_ID,@Prefix_ID,@Price_Value)", con7);

                                    com7.Parameters.AddWithValue("@Datewise_Discount_ID", ident);
                                    com7.Parameters.AddWithValue("@Slab_ID", sID);
                                    com7.Parameters.AddWithValue("@Destination_ID", dr[0].ToString());
                                    com7.Parameters.AddWithValue("@Sector_ID", chkBoxList.SelectedItem.Value);
                                    com7.Parameters.AddWithValue("@Prefix_ID", dd.SelectedItem.Value);
                                    com7.Parameters.AddWithValue("@Price_Value", tt.Text);
                                    com7.ExecuteNonQuery();
                                    con7.Close();
                                    i = i + 1;
                                 }                                                             
                                                           
                        }
                    }
                    else if (rbtnDes.Checked == true)
                    {
                        com = new SqlCommand("select sector_ID from airline_sector_details where Destination_id=" + chkBoxList.SelectedItem.Value + " ", con);
                        dr = com.ExecuteReader();              
                       
                        while (dr.Read())
                        {

                            SqlConnection conn = new SqlConnection(strCon);
                            conn.Open();
                            SqlCommand comm = new SqlCommand("select slab_id from slab_master order by slab_start", conn);
                            SqlDataReader drr = comm.ExecuteReader();
                            int i = 0;
                            while (drr.Read())
                            {
                                sID = drr[0].ToString();
                                TextBox tt = (TextBox)Table1.Rows[1].FindControl(sID);
                                DropDownList dd = (DropDownList)Table1.Rows[1].FindControl("ll" + i);
                                SqlConnection con7 = new SqlConnection(strCon);
                                con7.Open();
                                SqlCommand com7 = new SqlCommand("insert into Sector_Datewise_Discount_details(Datewise_Discount_ID,Slab_ID,Destination_ID,Sector_ID,Prefix_ID,Price_Value) values(@Datewise_Discount_ID,@Slab_ID,@Destination_ID,@Sector_ID,@Prefix_ID,@Price_Value)", con7);

                                com7.Parameters.AddWithValue("@Datewise_Discount_ID", ident);
                                com7.Parameters.AddWithValue("@Slab_ID", sID);
                                com7.Parameters.AddWithValue("@Destination_ID",chkBoxList.SelectedItem.Value);
                                com7.Parameters.AddWithValue("@Sector_ID", dr[0].ToString());
                                com7.Parameters.AddWithValue("@Prefix_ID", dd.SelectedItem.Value);
                                com7.Parameters.AddWithValue("@Price_Value", tt.Text);
                                com7.ExecuteNonQuery();
                                con7.Close();
                                i = i + 1;
                            }

                        }

                    }
                }
            }
            com.Dispose();
            dr.Close();

                    // Update data flight_open table

                    com = new SqlCommand("update flight_open set open_capacity=" + Convert.ToDecimal(TextBox1.Text.Trim()) + ",close_date='" + Convert.ToDateTime(ConvertDate1(TextBox2.Text)) + "' where flight_Open_id=" + flightOpenID + " ", con);
                    int result1 = com.ExecuteNonQuery();
                    com.Dispose();
                    con.Close();
                            
           DataBindGv(ident);
        }
        catch (SqlException se)
        {
            string err = se.Message;
            //tr.Rollback();

        }
        catch (Exception be)
        {
            string err = be.Message;
           // tr.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        //string s = showDetails();
        //Response.Write(s); 


    }
    
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    protected void DataBindGv(string identID)
    {
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand("select d.destination_name,b.slab_name,a.price_value,c.prefix_name from Sector_Datewise_Discount_Details a inner join slab_master b on b.slab_id=a.slab_id inner join prefix_master c on c.prefix_id=a.prefix_id inner join destination_master d on d.destination_id=a.destination_id where a.Datewise_Discount_ID=" + identID.Trim() + "order by b.slab_start ", con);
        SqlDataReader dr = com.ExecuteReader();
        DataColumn dc;
        DataColumn dc1;
        DataColumn dc2;
        TableRow trow = new TableRow();
        TableCell tcellcolname = new TableCell();
        TableCell slabName = new TableCell();
        slabName.Text = "Destination:";
        slabName.ForeColor = System.Drawing.Color.Red;
        trow.Cells.Add(slabName);
        TableRow trow1 = new TableRow();
        TableCell tcellcolname1 = new TableCell();
        TableCell DestinatioName = new TableCell();
        DestinatioName.ForeColor = System.Drawing.Color.Red;
        trow1.Cells.Add(DestinatioName);

        while (dr.Read())
        {

            TableCell tcellcoldata = new TableCell();
            tcellcoldata.Controls.Add(new LiteralControl(dr[1].ToString()));
            trow.Cells.Add(tcellcoldata);
            DestinatioName.Text = dr[0].ToString();

            TableCell Value = new TableCell();
            TableCell tcellcoldata1 = new TableCell();


            tcellcoldata1.Controls.Add(new LiteralControl(dr[2].ToString()));
            trow1.Cells.Add(tcellcoldata1);
        }

        Table2.Rows.Add(trow);
        Table2.Rows.Add(trow1);

    }

    //protected void DataBindGv()
    //{
    //    con = new SqlConnection(strCon);
    //    con.Open();
    //    // SqlCommand com = new SqlCommand("select d.destination_name,b.slab_name,a.price_value,c.prefix_name from Sector_Datewise_Discount_Details a inner join slab_master b on b.slab_id=a.slab_id inner join prefix_master c on c.prefix_id=a.prefix_id inner join destination_master d on d.destination_id=a.destination_id where a.Datewise_Discount_ID=" + identID.Trim() + "order by b.slab_start ", con);
    //    SqlCommand com = new SqlCommand("select distinct Destination_id,sector_id from Sector_Datewise_Discount_Details where Datewise_Discount_ID=57", con);
    //    SqlDataReader dr = com.ExecuteReader();

    //    while (dr.Read())
    //    {


    //    }




    //}
}


