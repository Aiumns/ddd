﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 
public partial class GenCSR_DownloadHistory : System.Web.UI.Page
{
    SqlConnection con;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
       if(!IsPostBack)
        {
            LoadAgent();
        }
    }
    protected void LoadAgent()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("GetAgent", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = com.ExecuteReader();
            ddlagent.Items.Insert(0, "- -Select- -");
            ddlagent.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlagent.Items.Add(new ListItem(dr["Agent_Name"].ToString(), dr["Agent_ID"].ToString()));

            }
          
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        string agentname = ddlagent.SelectedItem.Text;
        string agentid = ddlagent.SelectedValue;
        string fromdate = txtValidFrom.Text;
        string todate = txtValidTo.Text;
        string url = "CSR_DownloadHistoryReport.aspx?AgentName=" + agentname + "&AgentId=" + agentid + "&from_date=" + fromdate + "&to_date=" + todate + "";


        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");
    }

}