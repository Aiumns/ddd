using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Browse_Import_Flights : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataAdapter sda = null;
    string table = "";
    string table2 = "";
    string flightOpen = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {

               ShowAirline();
                FillDataGv();

            }
        }
    }
    protected void FillDataGv()
    {
        string searchString = null;
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            if (txtFlightNo.Text == "" && ddlAirlineCity.SelectedValue == "" && txtFltDate.Text == "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and  Import_Flight_Date >=getdate()-15 and IFO.status=2 order by IFO.Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";
            }
            else if (txtFlightNo.Text == "" && txtFltDate.Text == "" && ddlAirlineCity.SelectedValue != "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and  Import_Flight_Date >=getdate()-15 and IFO.Airline_detail_id=" + ddlAirlineCity.SelectedItem.Value + " and IFO.status=2 order by IFO.Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";

            }
                 else if (txtFlightNo.Text == "" && txtFltDate.Text != "" && ddlAirlineCity.SelectedValue != "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ")  and IFO.Airline_detail_id=" + ddlAirlineCity.SelectedItem.Value + " and Import_Flight_Date='" + FormatDateDD(txtFltDate.Text) + "' and IFO.status=2  order by IFO.Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";

            }

            else if (txtFlightNo.Text != "" && txtFltDate.Text == "" && ddlAirlineCity.SelectedValue != "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and  Import_Flight_Date >=getdate()-15 and IFO.Airline_detail_id=" + ddlAirlineCity.SelectedItem.Value + " and Import_Flight_No='" + txtFlightNo.Text + "' and IFO.status=2 order by IFO.Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";

            }
            else if (txtFlightNo.Text == "" && txtFltDate.Text != "" && ddlAirlineCity.SelectedValue != "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ")  and IFO.Airline_detail_id=" + ddlAirlineCity.SelectedItem.Value + " and Import_Flight_Date='" + FormatDateDD(txtFltDate.Text) + "' and IFO.status=2  order by IFO.Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";

            }

            else if (txtFlightNo.Text != "" && ddlAirlineCity.SelectedValue != "" && txtFltDate.Text != "")
            {
                //searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and  Import_Flight_Date >=getdate()-15 and IFO.Airline_detail_id=" + ddlAirlineCity.SelectedItem.Value + " and Import_Flight_No='" + txtFlightNo.Text + "' order by Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";


                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ")  and IFO.Airline_detail_id=" + ddlAirlineCity.SelectedItem.Value + " and Import_Flight_No='" + txtFlightNo.Text + "' and Import_Flight_Date='" + FormatDateDD(txtFltDate.Text) + "' and IFO.status=2 order by Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";


            }

            else if (txtFlightNo.Text != "" && txtFltDate.Text != "" && ddlAirlineCity.SelectedValue == "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and Import_Flight_No='" + txtFlightNo.Text + "' and Import_Flight_Date='" + FormatDateDD(txtFltDate.Text) + "' and IFO.status=2 order by Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";

            }
            else if (txtFlightNo.Text != "" && txtFltDate.Text == "" && ddlAirlineCity.SelectedValue == "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and Import_Flight_No='" + txtFlightNo.Text + "' and IFO.status=2 order by Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";

            }

            else if (txtFlightNo.Text == "" && ddlAirlineCity.SelectedValue == "" && txtFltDate.Text != "")
            {
                searchString = "Select IFO.Import_Flight_ID,IFO.Airline_Detail_ID,IFO.Import_Flight_No,CM.City_Code,convert(varchar,IFO.Import_Flight_Date,103) as Import_Flight_Date,IFO.IGM_No,AM.Airline_name from  Import_Flights  IFO inner join Airline_detail AD on AD.Airline_detail_id=IFO.Airline_Detail_ID inner join Airline_master AM on AM.Airline_id=AD.Airline_ID inner join City_master CM on CM.City_ID=AD.Belongs_to_city where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and Import_Flight_Date='" + FormatDateDD(txtFltDate.Text) + "' and IFO.status=2 order by Airline_Detail_ID,Import_Flight_Date,Import_Flight_No desc";

            }
            string AirlineDetailID = "";
            string AirlineDetailIDTem = "";
            com = new SqlCommand(searchString, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {

                while (dr.Read())
                {
                    //string importFlight = @"<a id=""yy"" href=""Edit_importflightopen.aspx?fno=" + dr["Import_Flight_No"].ToString() + "&org=" + dr["origin"].ToString() + "&date=" + dr["FlightDate1"].ToString() + "&cdate=" + dr["CloseDate"].ToString() + "&date=" + dr["FlightDate1"].ToString() + "&cdate=" + dr["CloseDate"].ToString() + "&fid=" + dr["Import_Flight_Open_ID"].ToString() + @""" class=""boldtext"">ImportFltOpen </a>";
                    string importFlight = @"<a id=""yy"" href=""Create_Import_Flights.aspx?Import_Flight_ID=" + dr["Import_Flight_ID"].ToString() + @""" class=""boldtext"">Edit</a>";
                    //string View = @"<a id=""yy"" href=""View_Import_Flight_Details_New.aspx?Import_Flight_ID=" + dr["Import_Flight_ID"].ToString() + @""" class=""boldtext"" target=blank>View</a>";

                    //Start On 21 July 2010
                    string View = @"<a id=""yy"" href=""View_Import_Flight_Details_New.aspx?Import_Flight_ID=" + dr["Import_Flight_ID"].ToString() + @"&Airline_detail_Id=" + dr["Airline_detail_Id"].ToString() + @"&Import_Flight_No=" + dr["Import_Flight_No"].ToString() + @"&City_code=" + dr["City_code"].ToString() + @""" class=""boldtext"">View</a>";
                   // Session["Airline_detail_Id"] = dr["Airline_detail_Id"].ToString();
                    Session["City_code"] = dr["City_code"].ToString();
                    Session["Import_Flight_No"] = dr["Import_Flight_No"].ToString();

                    //End On 21 July 2010
                    AirlineDetailIDTem = dr["Airline_Detail_ID"].ToString();
                    if (AirlineDetailID == dr["Airline_Detail_ID"].ToString())
                    {
                        table2 += @"<tr><td  nowrap>" + View + @"</td><td nowrap>" + dr["Import_Flight_No"].ToString() + @"</td><td>" + dr["Import_Flight_Date"].ToString() + @"</td><td>" + dr["Igm_No"].ToString() + @"</td><td>" + importFlight + @"</td></tr>";
                    }
                    else
                    {
                        table2 += @"<table class=""text"" width=""100%"" align=""center"" border=""1"">";


                        table2 += @"<tr align=""center""><td colspan=""13""  class=""h5 boldtext"">" + dr["airline_Name"].ToString() + "(" + dr["City_Code"].ToString() + "" + ")" + @"</td><tr>";


                        table2 += @"<tr align=""center""><td nowrap class=""h1 boldtext"">View</td><td nowrap class=""h1 boldtext"">FltNo </td><td class=""h1 boldtext"">Flight Date</td><td class=""h1 boldtext"">IGMNo </td><td class=""h1 boldtext"">Update </td></tr>";
                        table2 += @"<tr><td  nowrap>" + View + @"</td><td nowrap>" + dr["Import_Flight_No"].ToString() + @"</td><td>" + dr["Import_Flight_Date"].ToString() + @"</td><td>" + dr["Igm_No"].ToString() + @"</td><td>" + importFlight + @"</td></tr>";
                        AirlineDetailID = dr["Airline_Detail_ID"].ToString();

                    }


                }
                table2 += @"</table>";
                Label1.Text = table2;

            }
            else
            {
                //table2 = "<table><tr><td colspan=6> No Records Found!!</td></tr></table>";
                table2 += @"</table>";
                Label1.Text = table2;
            }
            
            
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        FillDataGv();
    }

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void ShowAirline()
    {

        ddlAirlineCity.Items.Clear();

        con = new SqlConnection(strcon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineCity.Items.Add("Select airline name");
            ddlAirlineCity.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirlineCity.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Create_Import_Flights.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("All_Browse_Import_Flights.aspx");
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
