using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;

/// <summary>
/// This Page intended to Load Data from Excel sheet in bulk and load to Database
/// </description>
/// <createdBy>--------SHAIKH AKHTAR RASOOL--------</createdBy>
/// <modified by>Shaikh Akhtar Rasool </modified>
/// <createdOn>-----27, DEC 2007-------</createdOn>
/// <modifiedon>16-01-2008</modifiedon>
/// </summary>


public partial class add_rates : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DataSet ds1 = new DataSet("excel_table");
    DataSet ds2 = new DataSet("Table2");
    OleDbConnection connection_excel;
    OleDbDataAdapter ex_adp;
    OleDbCommand cmd_excel;
    SqlTransaction trans;
    string column_excel;
    Boolean flag_check = true;

    DataTable dt_mul = new DataTable(); 
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
         {
              
            DateTime DTM;
            DTM = DateTime.Now.AddMonths(6);
     
            txtValidFrom.Text = DateTime.Now .ToString("dd/MM/yyyy");
            txtValidTo.Text = DTM.ToString("dd/MM/yyyy");  
            try
            {
                String airline_access = Session["AIRLINEACCESS"].ToString();
                //airline_access = airline_access.Substring(0, airline_access.Length - 1);
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
               dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]))));
                }
                cmd.Dispose(); 
            }
            catch (Exception eror)
            {
                string st = eror.ToString(); 
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                con.Close();
                cmd.Dispose(); 
            }
        }
    }

    protected void Btnload_Click(object sender, EventArgs e)
    {
        string strFileName;
        string strFilePath="";
        string strFolder;
        string all_Extension;
        GridView1.Visible = false;
        strFolder = Server.MapPath("./temp");
        //strFolder1 = Server.MapPath("" + DateTime.Now + "");  
        // Retrieve the name of the file that is posted.
        bool com_not_avb = false;
        lbldest_mis.Visible = false; 
        if (ddl_airline_city.SelectedItem.Value == "0,0")
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Please Select the Airline/City." + "');</script>");
        }
        else 
        {
        strFileName = FileUpload1.PostedFile.FileName;
        strFileName = System.IO.Path.GetFileName(strFileName);
        all_Extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
       //Check Allowed Extension
        if (FileUpload1.HasFile)
        {
            if (all_Extension == ".xls" || all_Extension == ".XlS")
            {
                // Create the folder if it does not exist.
                if (!Directory.Exists(strFolder))
                {
                    Directory.CreateDirectory(strFolder);
                }
                // Save the uploaded file to the server.

                strFilePath = strFolder + '\\' + strFileName;
                //Deletes the file if Exists with Same name
                if (File.Exists(strFilePath))
                {
                    File.Delete(strFilePath);
                }
                else
                {
                    Label1.Visible = false;
                    FileUpload1.PostedFile.SaveAs(strFilePath);
                    string connect_to_excel;
                    try
                    {
                        connect_to_excel = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strFilePath + ";Extended Properties=Excel 8.0;";
                        connection_excel = new OleDbConnection(connect_to_excel);
                        ex_adp = new OleDbDataAdapter();
                        cmd_excel = new OleDbCommand();
                        cmd_excel.Connection = connection_excel;
                        cmd_excel.CommandText = "select * from [Sheet1$]";
                        ex_adp.SelectCommand = cmd_excel;
                        decimal fsc, wsc, xray;
                        int Shipment_ID = 0;
                        int Origin = 0;
                        int src = 0;
                        string Valid_From = "";
                        string Valid_To = "";
                        string dest_code_miss = "";
                        string missing_excel = "";
                        string Entered_By = "";
                        string Entered_On = "";
                        int city_id = 0;
                        int airline_id;
                        int dest_id = 0;
                        string shipment_not_avb = "";
                        ex_adp.Fill(ds1, "excel_table");
                        //Deletes the file after loading the Data to DataSet
                        //Directory.Delete(strFolder, true);

                        if (File.Exists(strFilePath))
                        {
                            File.Delete(strFilePath);
                        }

                        if (validate_columns(ds1))
                        {
                            string air_id = Convert.ToString(ddl_airline_city.SelectedItem.Value);
                            string[] air_or_city_id = air_id.Split(',');
                            int columns_in_excel = ds1.Tables[0].Columns.Count;
                            string[] colum = column_excel.Split(',');
                            DataSet ds_comp = new DataSet();
                            decimal slab_price;
                            string dest_name = "";
                            int get_slabid = 0;
                            con = new SqlConnection(strCon);
                            cmd = new SqlCommand();
                            SqlCommand comd = new SqlCommand();
                            con.Open();
                            trans = con.BeginTransaction();
                            //cmd.Connection = con;
                            //Call Function That returns dataset And moveS Records to History

                            ds_comp = move_to_history();

                            //if (ds_comp.Tables[0].Rows.Count >= ds1.Tables[0].Rows.Count)
                            //{
                            //string strp = Server.MapPath("./asd.xml");
                            //XmlWriteMode mode = new XmlWriteMode(); 
                            //ds1.WriteXml(strp,mode);

                            //Check Missing Destinations..
                            bool flag = false;

                            foreach (DataRow drow in ds_comp.Tables[0].Rows)
                            {
                                if (flag)
                                {
                                    missing_excel = missing_excel + dest_name + ",";
                                }
                                foreach (DataRow drow2 in ds1.Tables[0].Rows)
                                {
                                    dest_id = get_dest_id(drow2[1].ToString());

                                    if (Convert.ToInt32(drow["Destination"]) != dest_id)
                                    {
                                        dest_name = get_dest_name(Convert.ToInt32(drow["Destination"]));
                                        flag = true;
                                    }
                                    else
                                    {
                                        flag = false;
                                        break;
                                    }
                                }
                            }
                            //}
                            if (flag)
                            {
                                missing_excel = missing_excel + dest_name;
                            }
                            if (missing_excel.Length > 0)
                            {

                                lblmis.Text = "You have not inserted Rate for these Destinations .<br> " + missing_excel.Replace(',', '*');
                                lblmis.Visible = true;
                                //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert(' " + missing_excel + "');</script>");
                            }
                            foreach (DataRow datar in ds1.Tables[0].Rows)
                            {
                                dt_mul = multipleDest(datar[1].ToString(), ds1); 
                                foreach( DataRow dr_mul in dt_mul.Rows)
                                {
                                if (datar[columns_in_excel - 3].ToString() != "")
                                {
                                    fsc = Convert.ToDecimal(datar[columns_in_excel - 3]);
                                }
                                else
                                {
                                    fsc = 0;
                                }
                                if (datar[columns_in_excel - 2].ToString() != "")
                                {
                                    wsc = Convert.ToDecimal(datar[columns_in_excel - 2]);
                                }
                                else
                                {
                                    wsc = 0;
                                }
                                if (datar[columns_in_excel - 1].ToString() != "")
                                {
                                    xray = Convert.ToDecimal(datar[columns_in_excel - 1]);
                                }
                                else
                                {
                                    xray = 0;
                                }
                                src = get_src_id(datar[2].ToString());

                                Shipment_ID = Convert.ToInt32(getshipment_id(datar[2].ToString()));

                                if (Shipment_ID == 0)
                                {
                                    shipment_not_avb = shipment_not_avb + datar[1].ToString() + " ";
                                    if (shipment_not_avb != " " )
                                    {
                                        lblmis.Text = "Please Check the Special Commodity Name for these Destinations :- <u>" + shipment_not_avb + "</u>   ";
                                        lblmis.Visible = true;
                                    }
                                    continue;
                                }

                                Origin = Convert.ToInt32(air_or_city_id[0]);
                                Valid_From = FormatDateDD(txtValidFrom.Text);
                                Valid_To = FormatDateDD(txtValidTo.Text);
                                Entered_By = Session["EMailID"].ToString();
                                Entered_On = Convert.ToString(DateTime.Now);

                                //city_id = get_dest_id(datar[1].ToString());
                                city_id = Convert.ToInt32( dr_mul["destination_id"].ToString());  


                                if (city_id == 0)
                                {
                                    dest_code_miss = dest_code_miss + datar[1].ToString() + ",";
                                    if(dest_code_miss !=",")
                                    {
                                    lbldest_mis.Text = "Following Records Not Inserted Due to Unavialability of Destination Code<br><u>" + dest_code_miss.Replace(',', ' ') + "</u>";
                                    lbldest_mis.Visible = true;
                                     }
                                    continue;
                                }

                                airline_id = Convert.ToInt32(air_or_city_id[1].ToString());

                                cmd.Connection = con;
                                cmd.Transaction = trans;
                                cmd.CommandText = "insert into Agent_Rate_Master(Airline_Detail_ID,Shipment_ID,Special_Commodity_ID,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On) values(" + airline_id + "," + Shipment_ID + "," + src + "," + Origin + "," + city_id + "," + fsc + "," + wsc + "," + xray + ",'" + Valid_From + "','" + Valid_To + "',2,'" + Entered_By + "','" + Entered_On + "')";

                                cmd.ExecuteNonQuery();

                                //********************* Retrieves Last Tables Agent_Rate_ID**************//////////////
                                DataTable dtID;

                                dtID = dw.GetAllFromQuery("select ident_current('Agent_Rate_Master') as ID");
                                string agentRateId1 = "";
                                if (dtID.Rows.Count > 0)
                                {
                                    agentRateId1 = dtID.Rows[0]["ID"].ToString();
                                }

                                //******************************Insert Data  into Agent_slab_master Table*************/////////////////                  
                                for (int i = 3; i <= columns_in_excel - 4; ++i)
                                {
                                    get_slabid = get_slab_id(colum[i]);
                                    if (datar[i].ToString() != "")
                                    {
                                        slab_price = Convert.ToDecimal(datar[i]);
                                    }
                                    else
                                    {
                                        slab_price = 0;
                                    }

                                    comd.Connection = con;
                                    comd.Transaction = trans;
                                    comd.CommandText = "insert into Agent_Slab_Rate(Agent_Rate_ID,Airline_Detail_ID,Slab_ID,Price_Value)values(" + agentRateId1 + "," + Convert.ToInt32(air_or_city_id[1]) + "," + get_slabid + "," + slab_price + ")";
                                    comd.ExecuteNonQuery();
                                }
                                }
                            }
                            GridView1.Visible = true;
                            GridView1.DataSource = ds1;
                            GridView1.DataBind();
                            trans.Commit();
                            cmd.Dispose();
                            con.Close();
                            ddl_airline_city.SelectedIndex = -1;

                        }
                        else
                        {
                            ds1.Clear();
                            GridView1.Visible = false;
                            Label1.Visible = true;
                            Label1.Text = "Plz Check the File.";
                        }
                    }
                    catch (OleDbException oledb_exc)
                    {
                        oledb_exc.ToString();
                        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Please Check the Sheet Name in Excel File It Should be Sheet1 (Default)" + "');</script>");
                        if (File.Exists(strFilePath))
                        {
                            File.Delete(strFilePath);
                        }
                    }
                    catch(System.Data.SqlClient.SqlException tou)
                    {
                        Label1.Text = "Server Timout Please try Agian";
                        Label1.Visible = true ; 


                    }
                    catch (Exception sqle)
                    {
                        trans.Rollback();

                        Label1.Text = "Please Check the file Consistency..";
                        Label1.Visible = true;
                        string err = sqle.ToString();
                        if (File.Exists(strFilePath))
                        {
                            File.Delete(strFilePath);
                        }
                    }
                    finally
                    {
                        if (con != null && con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }
            else
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Please Check the file only Excel files are accepted." + "');</script>");
                Label1.Text = "This File is not allowed plz";
                Label1.Visible = true;
            }
        }
        else
        {
            Label1.Text = "Please Browse the file.";
            GridView1.Visible = false;
        }
    }
    }
    //Function That Returns Shipment_id
    int getshipment_id(string ship_name)
    {
            int ret_ship_id = 0;
            try
            {
                SqlConnection bcon = new SqlConnection(strCon);
                bcon.Open();
                cmd = new SqlCommand("select shipment_id from shipment_master where Shipment_Name='" + ship_name + "'", bcon);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ret_ship_id = Convert.ToInt32(dr["shipment_id"]);
                }
                bcon.Close(); 
            }
            catch (Exception   sqle)
            {
                string err = sqle.ToString();
            }

            finally
            {
            //    if (con != null && con.State == ConnectionState.Open)
            //        con.Close();
                cmd.Dispose();
                dr.Close(); 
            }
       return (ret_ship_id); 
    }
    //Function That Returns Destination_id
    int get_dest_id(string dest_code)
    {
        int ret_dest_id = 0;
        try
        {
            SqlConnection bcon = new SqlConnection(strCon);
            bcon.Open();
            cmd = new SqlCommand("select Destination_ID from destination_master where Destination_Code='" + dest_code + "' or Destination_Code2='" + dest_code + "'", bcon);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ret_dest_id = Convert.ToInt32(dr["Destination_ID"]);
            }
            bcon.Close();  
        }
        catch (Exception sqle)
        {
            string err = sqle.ToString();
        }

        finally
        {
        //    if (con != null && con.State == ConnectionState.Open)
        //        con.Close();
            
            cmd.Dispose();
            dr.Close(); 
        }
        return (ret_dest_id);
    }
    bool chech_destination(string destination_code)
    {
        return false;
    }
//Function Returns DataSet 
   //  void
     DataSet move_to_history()
    {
        string[] air_city_code = ddl_airline_city.SelectedItem.Value.Split(',');
        string query1_agent_rate_master = "select * from Agent_Rate_Master where Airline_Detail_ID=" + air_city_code[1] + " and Origin=" + air_city_code[0] + "";
        //con = new SqlConnection(strCon);
        //con.Open(); 
        cmd = new SqlCommand(query1_agent_rate_master, con,trans);
        SqlDataAdapter da_get = new SqlDataAdapter();
        da_get.SelectCommand = cmd;
        DataSet ds_get_Agent_rate_master = new DataSet("Table1");
        da_get.Fill(ds_get_Agent_rate_master, "Table1");
        cmd.Dispose();
        da_get.Dispose();  
        SqlDataAdapter da_get_Agent_slab_master= new SqlDataAdapter();
        string query_asr = "select asr.Agent_Slab_ID,asr.Agent_Rate_ID,asr.Airline_Detail_ID,Slab_ID,Price_Value from Agent_Slab_Rate asr inner join  Agent_Rate_Master arm on asr.Agent_Rate_ID=arm.Agent_Rate_ID where arm.Airline_Detail_ID=" + air_city_code[1] + " and origin="+ air_city_code[0]+"";
        cmd = new SqlCommand(query_asr,con,trans);
        da_get_Agent_slab_master.SelectCommand = cmd;
        da_get_Agent_slab_master.Fill(ds_get_Agent_rate_master, "Table2");
        cmd.Dispose();
        // Moves Records From Agent_Slab_master to Agent_Slab_master_History Table..
        string slab_name="";
        string[] air_line_city_name = ddl_airline_city.SelectedItem.Text.Split('/');

           
        foreach (DataRow drow in ds_get_Agent_rate_master.Tables["Table2"].Rows)
        {
                slab_name = get_slab_name(Convert.ToInt32(drow["Slab_id"]));
                query_asr = "insert into Agent_Slab_Rate_History(Agent_Slab_ID,Agent_Rate_ID,Airline_Name,City,Slab_Name,Price_Value)values(" + Convert.ToInt32(drow["Agent_Slab_ID"]) + "," + Convert.ToInt32(drow["Agent_Rate_ID"]) + ",'" + Convert.ToString(air_line_city_name[0]) + "','" + Convert.ToString(air_line_city_name[1]) + "','" + Convert.ToString(slab_name) + "'," + Convert.ToDecimal(drow["Price_Value"]) + ")";
            cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.Transaction = trans;
            cmd.CommandText = query_asr;
            cmd.ExecuteNonQuery();
        }
        cmd.Dispose(); 
        string ship_name="";
        string scr_name = "";
        string dest_name = "";

        foreach (DataRow drows in ds_get_Agent_rate_master.Tables["Table1"].Rows)
        {
            ship_name = get_shipment_name(Convert.ToInt32( drows["Shipment_ID"])); 
            scr_name= get_src_name(Convert.ToInt32(drows["Special_Commodity_ID"]));
            dest_name = get_dest_name (Convert.ToInt32(drows["Destination"]));

            query1_agent_rate_master = "insert into Agent_Rate_Master_History(Agent_Rate_ID,Airline_Name,Shipment_Name,Special_Commodity_Name,Origin,Destination,Freight_SurCharge,Security_SurCharge,XRay_Charges,Valid_From,Valid_To,Status,Entered_By,Entered_On)values(" + drows["Agent_Rate_ID"] + ",'" + air_line_city_name[0] + "','" + ship_name + "','" + scr_name + "','" + air_line_city_name[1] + "','" + dest_name + "'," + drows["Freight_SurCharge"] + "," + drows["Security_SurCharge"] + "," + drows["XRay_Charges"] + ",'" + drows["Valid_From"] + "','" + drows["Valid_To"] + "'," + drows["Status"] + ",'" + drows["Entered_By"] + "','" + drows["Entered_On"] + "')"; 
            cmd.Transaction = trans;  
            cmd = new SqlCommand(query1_agent_rate_master, con,trans);
            cmd.ExecuteNonQuery();
        }
        cmd.Dispose(); 
 //Delete Records From Agent_Slab_Master Table.
        foreach (DataRow drows in ds_get_Agent_rate_master.Tables["Table2"].Rows )
        {
            query_asr = "delete from Agent_Slab_Rate where Agent_Slab_ID=" + drows["Agent_Slab_ID"] + "";
            cmd = new SqlCommand(query_asr, con,trans);
            cmd.ExecuteNonQuery();
             
        }
        cmd.Dispose(); 
//Delete Records From Agent_Rate_Master Table.
        cmd = new SqlCommand("delete from  Agent_Rate_Master where Airline_Detail_ID=" + Convert.ToInt32(air_city_code[1]) + " and origin=" + Convert.ToInt32(air_city_code[0]) + "", con,trans);
        cmd.ExecuteNonQuery();
        cmd.Dispose(); 


       //query1_agent_rate_master = "delete from Agent_Rate_Master where Airline_Detail_ID=" + air_city_code[1] + " and Origin=" + air_city_code[0] + "";

         return ds_get_Agent_rate_master; 
    }
    // Function that Returns Special Comidity Name From Special_Commodity_Master.
    string get_src_name(int src_id)
    {
        SqlConnection bcon = new SqlConnection(strCon);
        bcon.Open(); 
        cmd = new SqlCommand("select Special_Commodity_Name from Special_Commodity_Master where Special_Commodity_ID=" + src_id + "", bcon);
        SqlDataReader dr = cmd.ExecuteReader();
        string ret="";
        while (dr.Read())
        {
            ret  = Convert.ToString(dr["Special_Commodity_Name"]);
        }
        bcon.Close();
        dr.Close();
        cmd.Dispose(); 
        return ret;
    }
    // Function that Returns Special Comidity Id From Special_Commodity_Master.
    int get_src_id(string src_name)
    {
      SqlConnection bcon = new SqlConnection(strCon);
        bcon.Open();
        cmd = new SqlCommand("select Special_Commodity_ID from Special_Commodity_Master where Special_Commodity_Name='" + src_name + "'", bcon);
        SqlDataReader dr = cmd.ExecuteReader();
        int ret=0;
        while (dr.Read())
        {
           ret  = Convert.ToInt32(dr["Special_Commodity_ID"]);
        }
        bcon.Close();
        dr.Close();
        cmd.Dispose(); 
        return ret;
    }

    //Function that returns the Destination_Name.
    string get_dest_name(int dest_id)
    {
        SqlConnection bcon = new SqlConnection(strCon);
        bcon.Open();
        cmd = new SqlCommand("select Destination_Name from Destination_Master where Destination_ID=" + dest_id + "", bcon);
        SqlDataReader dr = cmd.ExecuteReader();
        string ret="";
        while (dr.Read())
        {
           ret  = Convert.ToString(dr["Destination_Name"]);
        }
        bcon.Close();
        cmd.Dispose();
        dr.Close(); 
        return ret;
    }
    //Function that returns the Slab_Name.
    string get_slab_name(int slab_id)
    {
        SqlConnection bcon = new SqlConnection(strCon);
        bcon.Open();
        cmd = new SqlCommand("select Slab_Name from Slab_master where Slab_id=" + slab_id + "", bcon);
        SqlDataReader dr=cmd.ExecuteReader();
        string ret = "";
        while (dr.Read())
        {
            ret = Convert.ToString(dr["Slab_Name"]);
        }
        bcon.Close();
        cmd.Dispose();
        dr.Close(); 
        return ret;
    }
    //Function That Returns Shipment name from Shipment_Master Table. 
    string get_shipment_name(int ship_id)
    {
        SqlConnection bcon = new SqlConnection(strCon);
        bcon.Open();
        cmd = new SqlCommand("select Shipment_Name from Shipment_Master where Shipment_ID=" + ship_id + "", bcon);
        SqlDataReader dr = cmd.ExecuteReader();
        string ret="";
        while (dr.Read())
        {
           ret   = Convert.ToString(dr["Shipment_Name"]);
        }
        bcon.Close();
        cmd.Dispose();
        dr.Close();
        return ret;
    }
    //Function that returns the Slab_id.
    int get_slab_id(string slab_name)
    {
        int ret_slab_id = 0;
        try
        {
            string airline_id = Convert.ToString(ddl_airline_city.SelectedItem.Value);
            string[] air_id = airline_id.Split(',');
            SqlConnection bcon = new SqlConnection(strCon);
            bcon.Open();
            //cmd = new SqlCommand("select sm.slab_id from Slab_Master sm inner join Principle_Slab_Rate psr on psr.slab_id=sm.slab_id where Rate_ID=(select max(rate_id) from Principle_Rate_Master prm where Airline_Detail_ID=" + Convert.ToInt32(air_id[1])+ ") and slab_name='" + slab_name.Trim()  + "'",bcon);

            cmd = new SqlCommand("select sm.slab_id from Airline_Slab ars inner join Slab_Master sm on ars.slab_id=sm.slab_id where Airline_Detail_ID=" + Convert.ToInt32(air_id[1]) + "and slab_name='" + slab_name + "'", bcon);

            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ret_slab_id = Convert.ToInt32(dr["slab_id"]);
            }
            bcon.Close();  
            return ret_slab_id; 
        }
        catch (Exception sqle)
        {
            string err = sqle.ToString();
        }
        finally
        {
        //    if (con != null && con.State == ConnectionState.Open)
        //        con.Close();
            dr.Close(); 
        }
        return (ret_slab_id);
    }
    //Function that checks the format of the excel  sheet
    bool validate_columns(DataSet ds_check)
    {

        string airline_id = Convert.ToString(ddl_airline_city.SelectedItem.Value);
        string[] air_id = airline_id.Split(',');
        string compare_to_column = "";

        if (ds_check.Tables[0].Rows[1][0].ToString() != air_id[2])
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Please Choose the valid file its Airline Code is Incorrect!!');</script>");
            return false;

        }    
            con = new SqlConnection(strCon);
            con.Open();
           // cmd = new SqlCommand("select sm.slab_id,slab_Name,Airline_Detail_ID,Rate_id from Slab_Master sm inner join Principle_Slab_Rate psr on psr.slab_id=sm.slab_id where Rate_ID=(select max(rate_id) from Principle_Rate_Master prm where Airline_Detail_ID='" + Convert.ToString(air_id[1]) + "')", con);


            cmd = new SqlCommand("select sm.slab_id,slab_Name,Airline_Detail_ID from Airline_Slab ars inner join Slab_Master sm on ars.slab_id=sm.slab_id where Airline_Detail_ID='" + Convert.ToInt32(air_id[1]) + "'  order by slab_id", con);
       
            dr = cmd.ExecuteReader();
            int count=0;    
           while (dr.Read())
            {
                count = count + 1;
                compare_to_column = compare_to_column + dr["slab_Name"] + ",";
            }
            con.Close();
            cmd.Dispose(); 
        
            compare_to_column = "alCD,dstnCd,scr," + compare_to_column +"FSC,WSC,Xray_CH,"; 
       //Response.Write(compare_to_column + "<br>");
            
        count = count + 6;
        if (count == ds_check.Tables[0].Columns.Count)
            {
                string column = "";
                int inc = 0;
                int column_present_in_excelsheet = Convert.ToInt32(ds_check.Tables[0].Columns.Count);
               
                while (inc < column_present_in_excelsheet)
                {
                    column = column + Convert.ToString(ds_check.Tables[0].Columns[inc]) + ",";
                    inc = inc + 1;
                } 
               
      //Response.Write(column);  

                column_excel = column; 
                //if (!(compare_to_column.Equals(column)))
                //    {
                //        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "The File Formate Is Not Correct...(Check the Number of Columns should be" + count + ")" + compare_to_column +  "');</script>");
                //    return false;    
                //    }
                return (true);       
            }
            else
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Check the Column Names should be in this format:- [" + compare_to_column.Replace(',','*') + "]" + "');</script>");
                return false; 
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public bool compareDate(string first, string second)
    {
        string[] cdate1 = first.Split('/');
        string[] cdate2 = second.Split('/');

        int fd = Convert.ToInt32(cdate1[0]);
        int fm = Convert.ToInt32(cdate1[1]);
        int fy = Convert.ToInt32(cdate1[2]);

        int sd = Convert.ToInt32(cdate2[0]);
        int sm = Convert.ToInt32(cdate2[1]);
        int sy = Convert.ToInt32(cdate2[2]);

        DateTime dt1 = new DateTime(fy, fm, fd);
        DateTime dt2 = new DateTime(sy, sm, sd);

        if (DateTime.Compare(dt1, dt2) < 0 || DateTime.Compare(dt1, dt2) == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    protected void ddl_airline_city_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridView1.Visible = false;
        lblmis.Visible = false;
        Label1.Visible = false ;
        lbldest_mis.Visible = false;
    }

    public DataTable  multipleDest(string dest,DataSet Ds)
    {
        //con = new SqlConnection(strCon);
        //cmd = new SqlCommand("select distinct destination_code2,destination_code from destination_master where destination_code2='" + dest + "' or destination_code='" + dest + "'");
        //SqlDataAdapter dap = new SqlDataAdapter(cmd);
        //DataSet ds_dest = new DataSet("Table1");
        //dap.Fill(ds_dest, "Table1");
        //return(ds_dest);  

        DataTable dt_dest = dw.GetAllFromQuery("select distinct destination_id,destination_code2,destination_code from destination_master where destination_code2='" + dest + "' or destination_code='" + dest + "' order by destination_code2");
        DataTable dt_dest_modified = dt_dest;

        for (int i = 0; i < dt_dest.Rows.Count; ++i)
        {

             
        
        //foreach (DataRow drMul in dt_dest.Rows)
        //{
           flag_check = true;
           foreach (DataRow drExcel in Ds.Tables[0].Rows)
            {
                //if (drMul["destination_code2"].ToString() == drExcel[1].ToString() || drMul["destination_code"].ToString() == drExcel[1].ToString())
                if (dt_dest.Rows[i]["destination_code2"].ToString() == drExcel[1].ToString() || dt_dest.Rows[i]["destination_code"].ToString() == drExcel[1].ToString())
                {
                    if (flag_check == false)
                    {
                        if (dt_dest_modified.Rows.Count != 1)
                        {
                            dt_dest_modified.Rows.Remove(dt_dest.Rows[i]);
                            dt_dest.AcceptChanges();
                            break;
                        }
                    }
                    flag_check = false;
                }
            }
            
            
        }
        flag_check = true;

        return(dt_dest_modified) ;

    }



}
