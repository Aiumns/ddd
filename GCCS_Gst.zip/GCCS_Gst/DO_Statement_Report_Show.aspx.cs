using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class DO_Statement_Report_Show : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    decimal total = 0;
    decimal totalOnCondition = 0;

    decimal Carting = 0;
    decimal DataProcessingFee = 0;
    decimal CommunicationFee = 0;
    decimal MAWB = 0;
    decimal HAWB = 0;
    decimal srate = 0;
    decimal totalHAWB = 0;
    decimal StaxRate = 0;
    decimal DOamount = 0;
    decimal Docahrges = 0;
    decimal NetAmount = 0;
    decimal totalcartingcharges = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        decimal Receivable_Amt = 0;
        decimal Total_Receivable_Amt = 0;
        decimal pay_amt = 0;
        decimal total_pay_amt = 0;
        string[] airline_name_city_text = Session["airline_city_text"].ToString().Split(',');
        string[] airline_name_city_value = Session["airline_city_value"].ToString().Split(',');
        string[] air_name_val = airline_name_city_value[0].Split('%');
        string from_date = Session["from_date"].ToString();
        string to_date = Session["to_date"].ToString();
        decimal TotalRecieved = 0;
        decimal Total_TotalRecieved = 0;
        decimal Stax_Amount = 0;
        decimal Total_Stax_Amount = 0;
        decimal recievedHalf = 0;
        decimal Total_recievedHalf = 0;
        decimal TdsCut_ByAgent = 0;
        decimal TotalTdsCut_ByAgent = 0;
        Label1.Text = "<table width=100% border=0 cellspacing=0 cellpadding=0  align=center><tr><td><br/></td></tr><tr align=center ><td ><h2>DO SHARE REPORT</h2></td></tr><tr align=center><td><h3><u>" + FormatDateDD(from_date) + " - " + FormatDateDD(to_date) + "</u></h3></td></tr><tr><td><br/></td></tr></table>";
        string Table1 = "";
        string Query = "";
        if (airline_name_city_value[0] == "0")
        {
            Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ")  AND airline_detail.company_id=106  and airline_master.Status=2 order by airline_name";
        }
        else
        {
            Query = "select airline_name,airline_code,airline_text_code,airline_detail_id,city_code from airline_master inner join airline_detail on airline_master.airline_id=airline_detail.airline_id inner join city_master on belongs_to_city=city_id where airline_detail_id in (" + airline_name_city_value[0].ToString() + ") order by airline_name";
        }
        Int32 count = 1;
        DataTable dt = dw.GetAllFromQuery(Query);
        foreach (DataRow drow in dt.Rows)
        {
            Table1 += "<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle1><td colspan=20  align=center >" + drow["airline_code"].ToString() + "-" + drow["airline_name"].ToString() + "-" + drow["city_code"].ToString() + "</td></tr><tr class=HeaderStyle2><td>S.NO</td><td>Flight No </td><td>Flight Date</td><td  >MAWB</td><td >HAWB</td><td>D/O Date</td><td  >DO/Rcpt. No.</td>";
            if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
            {
                Table1 += "<td align=right>DO Amt</td><td align=right>HAWB</td><td align=right>Carting Charges</td>";
            }
            else
            {
                Table1 += "<td align=right>DO Amt(Incl of Stax)</td>";
            }
            //Table1 += "<th align=right>Stax Rate</th><th align=right>Stax Amt</th><th align=right>Tds Amt</th><th  align=right>50 % of M DO</th></tr>";
            Table1 += "<td  align=right>50 % of M DO</td></tr>";
            Query = "SELECT CONVERT(INT, SUBSTRING(Recipt_No,14,LEN(Recipt_No))) AS reciptno,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC,IFA.Payment_Mode, IFA.Import_awb_id,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,(CASE WHEN  IFA.Tds_Cut_By_Agent > 0 Then IFA.Tds_Cut_By_Agent ELSE  CASE WHEN IFA.Stax_Rate > 0 Then IFA.Stax_Rate ELSE 0 END END) AS Stax_Amount,isnull(IFA.Stax_Rate,0) as serviceTax,isnull(IFA.Tds_Cut_By_Agent,0) as Tds_deduction,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.MAWBDO_Chgs,0) as MAWBDO_Chgs,isnull(IFA.HAWBDO_Chgs,0) as HAWBDO_Chgs,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID INNER JOIN Destination_Master DM ON IFA.Destination=DM.Destination_Code where CONVERT(VARCHAR,IFA.issue_date,101) >= '" + FormatDateMM(from_date) + "' and CONVERT(VARCHAR,IFA.issue_date,101) <='" + FormatDateMM(to_date) + "' and  IFA.airline_detail_id=" + Convert.ToInt64(drow["airline_detail_id"].ToString()) + " order by reciptno";
            DataTable dt_cal = dw.GetAllFromQuery(Query);
            count = 1;
            if (dt_cal.Rows.Count > 0)
            {

                foreach (DataRow dro in dt_cal.Rows)
                {
                    pay_amt = 0;
                    Carting = 0;
                    StaxRate = 0;
                    CommunicationFee = 0;
                    DataProcessingFee = 0;

                    //pay_amt = Convert.ToDecimal(dro["payable_amount"].ToString());
                    //pay_amt = (Convert.ToDecimal(dro["MAWBDO_Chgs"].ToString()) + (Convert.ToDecimal(dro["HAWBDO_Chgs"].ToString()) * Convert.ToDecimal(dro["No_of_Houses"].ToString())));
                    DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportflightAwb_Trans where ImportAwbId=" + dro["Import_awb_id"].ToString() + "");
                    decimal ServiceTax_ = 0;
                    for (int k = 0; k < dtImportAwbTrans.Rows.Count; k++)
                    {
                        if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "MAWB")
                            MAWB = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "HAWB")
                            HAWB = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "Carting")
                            Carting = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "StaxRate")
                        {
                            StaxRate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                            srate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeRate"].ToString()); ;
                        }
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "CommunicationFee")
                            CommunicationFee = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "DataProcessingFee")
                            DataProcessingFee = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                    }

                    if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
                    {



                        DOamount = MAWB + HAWB;
                        Docahrges = MAWB;
                        //  recievedHalf = MAWB / 2 + HAWB / 2 + Carting;
                        recievedHalf = MAWB / 2 + HAWB / 2;
                        StaxRate = 0;
                        totalcartingcharges += Carting;

                    }

                    //else  if (drow["airline_detail_id"].ToString() == "148")
                    // {

                    //     //DOamount = MAWB;

                    //     //StaxRate = MAWB - Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate)) / 100)));
                    //     //Docahrges = MAWB - StaxRate;
                    //     //recievedHalf = Docahrges / 2;


                    //     DOamount = MAWB + HAWB;
                    //     Docahrges = DOamount - StaxRate;
                    //     decimal TdsCut_ByAgent = 0;
                    //     TdsCut_ByAgent = Convert.ToDecimal(dro["Tds_deduction"].ToString());
                    //     recievedHalf = (Docahrges-TdsCut_ByAgent) / 2;

                    // }
                    else if (drow["airline_detail_id"].ToString() == "159")
                    {
                        //*******************added on 15June2015 :For KE-MUM, flt No HY-127 case******//
                        if (dro["Import_flight_No"].ToString() == "HY-127")
                        {
                            MAWB = Math.Floor(Convert.ToDecimal(MAWB) / (1 + ((Convert.ToDecimal(srate)) / 100)));
                            DOamount = MAWB + HAWB;
                        }
                        else
                        {
                            DOamount = MAWB + HAWB;
                        }
                        //*******************End of 15June2015 :For KE-MUM, flt No HY-127 case******//
                        
                        
                        /////DOamount = MAWB + HAWB;
                        if (StaxRate.ToString() == "0.00")
                            Docahrges = DOamount;
                        else
                            //*******************added on 15June2015 :For KE-MUM, flt No HY-127 case******//
                            if (dro["Import_flight_No"].ToString() == "HY-127")
                            {
                                Docahrges = DOamount;
                            }
                            else
                            {
                                Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate)) / 100)));
                            }
                        //*******************End of 15June2015 :For KE-MUM, flt No HY-127 case******//
                            /////Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate)) / 100)));

                        recievedHalf = Docahrges / 2;
                    }

                    else
                    {
                        //////DOamount = MAWB + HAWB;

                        //////Docahrges = DOamount - StaxRate;
                        //////recievedHalf = Docahrges/2;

                        //Added On 23 Mar 2011
                        DOamount = MAWB + HAWB;
                        Docahrges = DOamount - StaxRate;

                        TdsCut_ByAgent = Convert.ToDecimal(dro["Tds_deduction"].ToString());
                        recievedHalf = (Docahrges - TdsCut_ByAgent) / 2;
                    }



                    pay_amt = DOamount;

                    total_pay_amt = total_pay_amt + pay_amt;



                    totalHAWB += HAWB;

                    decimal StaxRateTds = 0;
                    Total_Stax_Amount = Total_Stax_Amount + StaxRate;



                    TotalTdsCut_ByAgent += TdsCut_ByAgent;



                    Total_recievedHalf = Total_recievedHalf + recievedHalf;



                    Table1 += "<tr class=tabletd ><td  >&nbsp;" + count + "</td><td  >&nbsp;" + dro["Import_Flight_No"].ToString() + "</td><td  >&nbsp;" + dro["flight_date"].ToString() + "</td><td  >&nbsp;" + dro["Import_awb_no"].ToString() + "</td><td  >&nbsp;" + dro["No_of_houses"].ToString() + "</td><td  >" + dro["Amt_recd_date"].ToString() + "</td><td  >" + dro["Recipt_No"].ToString() + "</td><td  align=right >" + Math.Round(pay_amt, MidpointRounding.AwayFromZero) + "</td>";


                    // Table1 += "<tr class=text><td  align=center class=text>" + count + "</td><td  align=left class=text>" + dro["Import_Flight_No"].ToString() + "</td><td  align=left class=text>" + dro["flight_date"].ToString() + "</td><td  align=left class=text>" + dro["Import_awb_no"].ToString() + "</td><td  align=center class=text>" + dro["No_of_houses"].ToString() + "</td><td  align=left class=text>" + dro["Amt_recd_date"].ToString() + "</td><td  align=left class=text>" + dro["Recipt_No"].ToString() + "</td><td  align=right class=text>" + Math.Round(pay_amt, MidpointRounding.AwayFromZero) + "</td>";
                    if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
                    {
                        Table1 += "<td  align=right >" + HAWB + "</td><td  align=right >" + Carting + "</td>";

                    }


                    //      Table1 += "<td  align=right class=text>" + Math.Round(srate, 1) + "</td><td  align=right class=text>&nbsp;" + Math.Round(StaxRate, MidpointRounding.AwayFromZero) + "</td><td  align=right class=text>" + Math.Round(TdsCut_ByAgent, MidpointRounding.AwayFromZero) + "</td><td  align=right class=text>" + Math.Round(recievedHalf, MidpointRounding.AwayFromZero) + "</td></tr>";
                    Table1 += "<td  align=right >" + Math.Round(recievedHalf, MidpointRounding.AwayFromZero) + "</td></tr>";

                    count++;

                }
            }
            else
            {
                Table1 += "<tr class=text><td  align=center colspan=12 class=error>NO RECORD FOUND FOR THIS AIRLINE</td></tr>";
            }
            Table1 += "<tr  class=GrandTotal><td  align=right colspan=7 >Total</td><td  align=right  nowrap> " + Math.Round(total_pay_amt, MidpointRounding.AwayFromZero) + "</td>";
            if ((drow["airline_detail_id"].ToString() == "147")||(drow["airline_detail_id"].ToString() == "153"))
            {
                Table1 += "<td  align=right  nowrap> " + Math.Round(totalHAWB, MidpointRounding.AwayFromZero) + "</td><td  align=right  nowrap> " + Math.Round(totalcartingcharges, MidpointRounding.AwayFromZero) + "</td>";

            }
            ///Table1 += "<td  align=right class=boldtext>&nbsp;</td><td  align=right class=boldtext> " + Math.Round(Total_Stax_Amount, MidpointRounding.AwayFromZero) + "</td><td  align=right class=boldtext> " + Math.Round(TotalTdsCut_ByAgent, MidpointRounding.AwayFromZero) + "</td><td  align=right class=boldtext> " + Math.Round(Total_recievedHalf, MidpointRounding.AwayFromZero) + "</td></tr>";
            Table1 += "<td  align=right > " + Math.Round(Total_recievedHalf, MidpointRounding.AwayFromZero) + "</td></tr>";
            Total_Receivable_Amt = 0;
            total_pay_amt = 0;
            Total_Stax_Amount = 0;
            Total_recievedHalf = 0;
            totalcartingcharges = 0;
            TotalTdsCut_ByAgent = 0;
            totalHAWB = 0;
            Table1 += "</table><br>";
        }
        Label2.Text += Table1;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateDD(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
