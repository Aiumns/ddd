﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class KE_Principal_report : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
        {
            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            hdnDate.Value = first.ToString();

            txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            ShowAirline();
        }
    }
    // ---- This Function is used to  bind Airline in dropdown ----
    protected void ShowAirline()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where airline_detail_id in (" + Rights() + ") AND am.Airline_ID=162 order by airline_name,City_name", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));

            }
            cmd.Dispose();
        }
        catch (Exception eror)
        {
            string st = eror.ToString();
        }
        finally
        {
            con.Close();
            cmd.Dispose();
            dr.Close();
        }

    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            string[] airlinesplit = ddl_airline_city.SelectedItem.Value.Split(',');

            string[] airline_name_city_text = ddl_airline_city.SelectedItem.Text.Split('/');
            string[] airline_name_city_value = ddl_airline_city.SelectedItem.Value.Split(',');
            string date_from = txtValidFrom.Text;
            string date_to = txtValidTo.Text;
            if (ddl_airline_city.SelectedItem.Value == "0,0")
            {

                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Please Choose Airline/City.');</script>");
            }
            else if (airlinesplit[2] == "232")
            {
                Session["st1"] = ConvertDate1(date_from);
                Session["st2"] = ConvertDate1(date_to);
                Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
                Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
                Session["from_date"] = date_from;
                Session["to_date"] = date_to;
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Principle_Malaysia_Report.aspx');</script>");

            }
            else if (airlinesplit[2] == "999")
            {
                //string url = "PrincipalAirChinaReport.aspx?airline_detail_id=" + airline_name_city_value[1] + "&amp;from=" + date_from + "&amp;to=" + date_to;

                string url = "PrincipalAirChinaReport.aspx?airline_detail_id=" + airline_name_city_value[1] + "&from=" + date_from + "&to=" + date_to;

                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './" + url + "');</script>");


            }
            else if (airlinesplit[2] == "297")
            {
                //  string airline_name_city_value=
                Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
                Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
                Session["from_date"] = date_from;
                Session["to_date"] = date_to;
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/Prin_report.aspx');</script>");

            }
            else if (airlinesplit[2] == "235")
            {
                //string url = "PrincipalTurkishReportShow.aspx?airline_detail_id=" + airline_name_city_value[1] + "&amp;from=" + date_from + "&amp;to=" + date_to;

                string url = "PrincipalTurkishReportShow.aspx?airline_detail_id=" + airline_name_city_value[1] + "&from=" + date_from + "&to=" + date_to;

                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './" + url + "');</script>");


            }
            else if (airlinesplit[2] == "360")
            {
                //string url = "Principle_Deccan_Report.aspx?airline_detail_id=" + airline_name_city_value[1] + "&amp;from=" + date_from + "&amp;to=" + date_to;
                string url = "Principle_Deccan_Report.aspx?airline_detail_id=" + airline_name_city_value[1] + "&from=" + date_from + "&to=" + date_to;

                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './" + url + "');</script>");

            }

            else if (airlinesplit[2] == "180")
            {
                Session["airline_name"] = ddl_airline_city.SelectedItem.Value;
                Session["airline_value"] = ddl_airline_city.SelectedItem.Value; 
                Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
                Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
                Session["from_date"] = date_from;
                Session["to_date"] = date_to;
                //string url = "Principle_Deccan_Report.aspx?airline_detail_id=" + airline_name_city_value[1] + "&amp;from=" + date_from + "&amp;to=" + date_to;
                string url = "KE_Principal_reportShow.aspx?airline_detail_id=" + airline_name_city_value[1] + "&from=" + date_from + "&to=" + date_to;

                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './" + url + "');</script>");

            }
            else
            {
                //string url = "PrincipalFedexReport.aspx?airline_detail_id=" + airline_name_city_value[1] + "&amp;from=" + date_from + "&amp;to=" + date_to;

                string url = "PrincipalFedexReport.aspx?airline_detail_id=" + airline_name_city_value[1] + "&from=" + date_from + "&to=" + date_to;

                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './" + url + "');</script>");

            }
        }

    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        dr.Dispose();
        cmd.Dispose();

        return Access;

    }
}
