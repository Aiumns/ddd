using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Mail;


public partial class ASpHandover_Details : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    SqlTransaction trans;
    string awb_date = "", hnd_date = "", shpt_id = "", commodity = "", frt_type = "", tarriff_rate = "", frt_amt = "", sp_rate = "", sp_amt = "", fltopen_id = "", ms_unit = "", cityID = "", no_of_pcs = "", leng = "", brth = "", heigt = "", total = "", cityname = "", mail_awb_date = "", citycode = "";
    string awb_no = "";
    decimal AgentID = 0, StockID = 0, bookingID = 0;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");
            ViewState["edit"] = "0";
            ViewState["et"] = "1";
            ViewState["bookingID"] = "";
            ViewState["leng"] = "";
            ViewState["brth"] = "";
            ViewState["heigt"] = "";
            if (Request.QueryString.Count > 0)
            {
                if (Request.QueryString["st"] == "H")
                {
                    FillHandoverFields();
                    btnCancel.Visible = false;
                    btnSubmit.Visible = false;
                }
                if (Request.QueryString["st"] == "U")
                {
                    btnUpdate.Attributes.Add("onclick", "return CheckEmpty();");
                    FillHandoverFields();
                    btnSubmit.Visible = false;
                    btnUpdate.Visible = true;
                }
            }
            FillAllFields();

        }
    }

    public void FillAllFields()
    {

        if (Request.QueryString != null)
        {
            awb_no = Request.QueryString["Airwaybill_no"];
        }
        con = new SqlConnection(strCon);
        com = new SqlCommand("select convert(varchar,bm.Location_Date,101) as Loc_Date,* from booking_master bm  inner join stock_master sm on bm.stock_id=sm.stock_id where Sm.Airwaybill_no='" + awb_no + "' and (bm.Status=9 or bm.Status=3)", con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dtawbEdit = new DataTable();
        da.Fill(dtawbEdit);

        ViewState["dtawbEdit"] = dtawbEdit;
        if (dtawbEdit.Rows.Count > 0)
        {
            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select Used_Date,AirWayBill_No from stock_Master where Stock_ID=" + dtawbEdit.Rows[0]["Stock_ID"].ToString());
            DateTime awbdt = Convert.ToDateTime(dtawbEdit.Rows[0]["Booking_date"].ToString());
            mail_awb_date = FormatDateDD(awbdt.ToShortDateString());
            awb_date = dtawbEdit.Rows[0]["Booking_date"].ToString();
            ViewState["awb_date"] = awb_date;
            ViewState["mail_awb_date"] = mail_awb_date;
            hnd_date = dtawbEdit.Rows[0]["Expected_handover_Date"].ToString();
            ViewState["hnd_date"] = hnd_date;
            shpt_id = dtawbEdit.Rows[0]["Shipment_ID"].ToString();
            hdnshipment.Value = shpt_id;

            ViewState["shpt_id"] = shpt_id;
            commodity = dtawbEdit.Rows[0]["Special_commodity_id"].ToString();
            ViewState["commodity"] = commodity;
            frt_type = dtawbEdit.Rows[0]["freight_type"].ToString();
            ViewState["frt_type"] = frt_type;
            tarriff_rate = dtawbEdit.Rows[0]["Tariff_rate"].ToString();
            ViewState["tarriff_rate"] = tarriff_rate;
            frt_amt = dtawbEdit.Rows[0]["Freight_Amount"].ToString();
            ViewState["frt_amt"] = frt_amt;
            sp_rate = dtawbEdit.Rows[0]["Special_rate"].ToString();
            ViewState["sp_rate"] = sp_rate;
            sp_amt = dtawbEdit.Rows[0]["Special_Amount"].ToString();
            ViewState["sp_amt"] = sp_amt;
            fltopen_id = dtawbEdit.Rows[0]["flight_open_id"].ToString();
            ViewState["fltopen_id"] = fltopen_id;
            ms_unit = dtawbEdit.Rows[0]["measurement_unit"].ToString();
            ViewState["ms_unit"] = ms_unit;
            cityID = dtawbEdit.Rows[0]["city_id"].ToString();
            ViewState["cityID"] = cityID;
            AgentID = decimal.Parse(dtawbEdit.Rows[0]["Agent_ID"].ToString());
            ViewState["Agent_ID"] = AgentID;
            StockID = decimal.Parse(dtawbEdit.Rows[0]["Stock_id"].ToString());
            ViewState["StockID"] = StockID;
            bookingID = decimal.Parse(dtawbEdit.Rows[0]["Booking_ID"].ToString());
            ViewState["bookingID"] = bookingID;


            if (dtAirWayBillNo.Rows.Count > 0)
            {
                lblawbno.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
                string AirlineCode = lblawbno.Text.Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Airline_ID=" + AirlineID.Rows[0]["Airline_ID"].ToString() + " and Belongs_To_City=" + dtawbEdit.Rows[0]["City_ID"].ToString());


                long City_ID = long.Parse(dtawbEdit.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    hdnairlineid.Value = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
                    ViewState["AirlineDetailID"] = AirlineDetailID;
                }
            }

            LoadDestination();
            LoadCommodity();
            DataTable dtAgentName = dw.GetAllFromQuery("Select Agent_Name from Agent_Master where Agent_ID=" + ViewState["Agent_ID"].ToString());
            if (dtAgentName.Rows.Count > 0)
            {
                lblAgentname.Text = dtAgentName.Rows[0]["Agent_Name"].ToString();
            }
            DataTable dtcityname = dw.GetAllFromQuery("Select city_name,city_code from city_master where city_id=" + dtawbEdit.Rows[0]["City_ID"].ToString());
            if (dtcityname.Rows.Count > 0)
            {
                cityname = dtcityname.Rows[0]["city_name"].ToString();
                ViewState["cityname"] = cityname;
                citycode = dtcityname.Rows[0]["city_code"].ToString();
                ViewState["citycode"] = citycode;
            }
            if (dtawbEdit.Rows[0]["NeutralAWB"].ToString() == "N")
            {
                rblnutralAWB.Items[1].Selected = true;
                rblnutralAWB.Items[0].Selected = false;
            }
            else
            {
                rblnutralAWB.Items[1].Selected = false;
                rblnutralAWB.Items[0].Selected = true;
            }
            uptnutralawb.Update();

            decimal gw = decimal.Parse(dtawbEdit.Rows[0]["Gross_Weight"].ToString());
            txtgwt.Text = gw.ToString();
            decimal cw = decimal.Parse(dtawbEdit.Rows[0]["Charged_Weight"].ToString());
            txtchwt.Text = cw.ToString();
            decimal vw = decimal.Parse(dtawbEdit.Rows[0]["Volume_Weight"].ToString());
            txtvolwt.Text = vw.ToString();
            txtpcs.Text = dtawbEdit.Rows[0]["No_of_Packages"].ToString();

            txttariffrate.Text = dtawbEdit.Rows[0]["Tariff_Rate"].ToString();

            if (dtawbEdit.Rows[0]["Loc_Date"].ToString() == null || dtawbEdit.Rows[0]["Loc_Date"].ToString() == "")
            {
                txtLOCDate.Text = FormatDateDD(DateTime.Now.ToShortDateString());
            }
            else
            {
                txtLOCDate.Text = FormatDateDD(dtawbEdit.Rows[0]["Loc_Date"].ToString());
            }

            txtLocTime.Text = dtawbEdit.Rows[0]["Location_Time"].ToString();
            txtcommodity.Text = dtawbEdit.Rows[0]["Nature_and_Quantity"].ToString();

            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtawbEdit.Rows[0]["Flight_Open_ID"].ToString());
            if (dtFlight.Rows.Count > 0)
            {
                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

                if (dtFlightNo.Rows.Count > 0)
                {
                    lblfltno.Text = dtFlightNo.Rows[0]["Flight_No"].ToString();
                }
                DateTime FlightDate = Convert.ToDateTime(dtFlight.Rows[0]["Flight_Date"].ToString());
                lblfdate.Text = FormatDateDD(FlightDate.ToShortDateString());
            }
            DataTable dtLength = dw.GetAllFromQuery("select * from booking_dimensions where booking_ID=" + bookingID);
            if (dtLength.Rows.Count > 0)
            {

                no_of_pcs = dtLength.Rows[0]["No_of_Packages"].ToString();
                ViewState["no_of_pcs"] = no_of_pcs;
                leng = dtLength.Rows[0]["Length"].ToString();
                ViewState["leng"] = leng;
                brth = dtLength.Rows[0]["Breadth"].ToString();
                ViewState["brth"] = brth;
                heigt = dtLength.Rows[0]["Height"].ToString();
                ViewState["heigt"] = heigt;
                total = dtLength.Rows[0]["Total"].ToString();
                ViewState["total"] = total;

            }


            ddldestination.SelectedValue = dtawbEdit.Rows[0]["Destination_ID"].ToString();
            ddlScr.SelectedValue = dtawbEdit.Rows[0]["Special_commodity_id"].ToString();
        }
    }
    public void FillHandoverFields()
    {

        if (Request.QueryString != null)
        {
            awb_no = Request.QueryString["Airwaybill_no"];
        }
        con = new SqlConnection(strCon);
        com = new SqlCommand("select convert(varchar,Location_Date,101) as Loc_Date,* from Handover bm  inner join stock_master sm on bm.stock_id=sm.stock_id where Sm.Airwaybill_no='" + awb_no + "' and (sm.Status=10)", con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dtawbEdit = new DataTable();
        da.Fill(dtawbEdit);

        ViewState["dtawbEdit"] = dtawbEdit;
        if (dtawbEdit.Rows.Count > 0)
        {
            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select Used_Date,AirWayBill_No from stock_Master where Stock_ID=" + dtawbEdit.Rows[0]["Stock_ID"].ToString());
            //DateTime awbdt = Convert.ToDateTime(dtawbEdit.Rows[0]["Booking_date"].ToString());
            //mail_awb_date = FormatDateDD(awbdt.ToShortDateString());
            //awb_date = dtawbEdit.Rows[0]["Booking_date"].ToString();
            ViewState["awb_date"] = awb_date;
            ViewState["mail_awb_date"] = mail_awb_date;
            hnd_date = dtawbEdit.Rows[0]["Expected_handover_Date"].ToString();
            ViewState["hnd_date"] = hnd_date;
            shpt_id = dtawbEdit.Rows[0]["Shipment_ID"].ToString();
            hdnshipment.Value = shpt_id;
            ViewState["shpt_id"] = shpt_id;
            commodity = dtawbEdit.Rows[0]["Special_commodity_id"].ToString();
            ViewState["commodity"] = commodity;
            frt_type = dtawbEdit.Rows[0]["freight_type"].ToString();
            ViewState["frt_type"] = frt_type;
            tarriff_rate = dtawbEdit.Rows[0]["Tariff_rate"].ToString();
            ViewState["tarriff_rate"] = tarriff_rate;
            txttariffrate.Text = tarriff_rate;
            frt_amt = dtawbEdit.Rows[0]["Freight_Amount"].ToString();
            ViewState["frt_amt"] = frt_amt;
            sp_rate = dtawbEdit.Rows[0]["Special_rate"].ToString();
            ViewState["sp_rate"] = sp_rate;
            sp_amt = dtawbEdit.Rows[0]["Special_Amount"].ToString();
            ViewState["sp_amt"] = sp_amt;
            fltopen_id = dtawbEdit.Rows[0]["flight_open_id"].ToString();
            ViewState["fltopen_id"] = fltopen_id;
            ms_unit = dtawbEdit.Rows[0]["measurement_unit"].ToString();
            ViewState["ms_unit"] = ms_unit;
            cityID = dtawbEdit.Rows[0]["city_id"].ToString();
            ViewState["cityID"] = cityID;
            AgentID = decimal.Parse(dtawbEdit.Rows[0]["Agent_ID"].ToString());
            ViewState["Agent_ID"] = AgentID;
            StockID = decimal.Parse(dtawbEdit.Rows[0]["Stock_id"].ToString());
            ViewState["StockID"] = StockID;
            bookingID = decimal.Parse(dtawbEdit.Rows[0]["Booking_ID"].ToString());
            ViewState["bookingID"] = bookingID;



            if (dtAirWayBillNo.Rows.Count > 0)
            {
                lblawbno.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
                string AirlineCode = lblawbno.Text.Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Airline_ID=" + AirlineID.Rows[0]["Airline_ID"].ToString() + " and Belongs_To_City=" + dtawbEdit.Rows[0]["City_ID"].ToString());
                long City_ID = long.Parse(dtawbEdit.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    hdnairlineid.Value = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
                    ViewState["AirlineDetailID"] = AirlineDetailID;
                }
            }

            LoadDestination();
            LoadCommodity();
            DataTable dtAgentName = dw.GetAllFromQuery("Select Agent_Name from Agent_Master where Agent_ID=" + ViewState["Agent_ID"].ToString());
            if (dtAgentName.Rows.Count > 0)
            {
                lblAgentname.Text = dtAgentName.Rows[0]["Agent_Name"].ToString();
            }
            DataTable dtcityname = dw.GetAllFromQuery("Select city_name,city_code from city_master where city_id=" + dtawbEdit.Rows[0]["City_ID"].ToString());
            if (dtcityname.Rows.Count > 0)
            {
                cityname = dtcityname.Rows[0]["city_name"].ToString();
                ViewState["cityname"] = cityname;
                citycode = dtcityname.Rows[0]["city_code"].ToString();
                ViewState["citycode"] = citycode;
            }

            if (dtawbEdit.Rows[0]["NeutralAWB"].ToString() == "N")
            {
                rblnutralAWB.Items[1].Selected = true;
                rblnutralAWB.Items[0].Selected = false;
            }
            else
            {
                rblnutralAWB.Items[1].Selected = false;
                rblnutralAWB.Items[0].Selected = true;
            }
            uptnutralawb.Update();

            decimal gw = decimal.Parse(dtawbEdit.Rows[0]["Gross_Weight"].ToString());
            txtgwt.Text = gw.ToString();
            decimal cw = decimal.Parse(dtawbEdit.Rows[0]["Charged_Weight"].ToString());
            txtchwt.Text = cw.ToString();
            decimal vw = decimal.Parse(dtawbEdit.Rows[0]["Volume_Weight"].ToString());
            txtvolwt.Text = vw.ToString();
            txtpcs.Text = dtawbEdit.Rows[0]["No_of_Packages"].ToString();

            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtawbEdit.Rows[0]["Flight_Open_ID"].ToString());
            if (dtFlight.Rows.Count > 0)
            {
                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

                if (dtFlightNo.Rows.Count > 0)
                {
                    lblfltno.Text = dtFlightNo.Rows[0]["Flight_No"].ToString();
                }
                DateTime FlightDate = Convert.ToDateTime(dtFlight.Rows[0]["Flight_Date"].ToString());
                lblfdate.Text = FormatDateDD(FlightDate.ToShortDateString());
            }
            DataTable dtLength = dw.GetAllFromQuery("select * from booking_dimensions where booking_ID=" + bookingID);
            if (dtLength.Rows.Count > 0)
            {

                no_of_pcs = dtLength.Rows[0]["No_of_Packages"].ToString();
                ViewState["no_of_pcs"] = no_of_pcs;
                leng = dtLength.Rows[0]["Length"].ToString();
                ViewState["leng"] = leng;
                brth = dtLength.Rows[0]["Breadth"].ToString();
                ViewState["brth"] = brth;
                heigt = dtLength.Rows[0]["Height"].ToString();
                ViewState["heigt"] = heigt;
                total = dtLength.Rows[0]["Total"].ToString();
                ViewState["total"] = total;

            }


            ddldestination.SelectedValue = dtawbEdit.Rows[0]["Destination_ID"].ToString();
            ddlScr.SelectedValue = dtawbEdit.Rows[0]["Special_commodity_id"].ToString();
            //DataTable dtPFM = dw.GetAllFromQuery("select * from pfm where airwaybill_no='" + Request.QueryString["Airwaybill_no"] + "'");
            //if (dtPFM.Rows.Count > 0)
            //{
            txtcommodity.Text = dtawbEdit.Rows[0]["Nature_and_Quantity"].ToString(); ;
            txtLOC.Text = dtawbEdit.Rows[0]["Location"].ToString();
            txtSbNo.Text = dtawbEdit.Rows[0]["ShipmentBill"].ToString();
            if (dtawbEdit.Rows[0]["Loc_Date"].ToString() == null || dtawbEdit.Rows[0]["Location_Date"].ToString() == "")
            {
                txtLOCDate.Text = FormatDateDD(DateTime.Now.ToShortDateString());
            }
            else
            {
                txtLOCDate.Text = FormatDateDD(dtawbEdit.Rows[0]["Loc_Date"].ToString());
            }

            txtLocTime.Text = dtawbEdit.Rows[0]["Location_Time"].ToString();
            txtcommodity.Text = dtawbEdit.Rows[0]["Nature_and_Quantity"].ToString();
            //txtLOCDate.Text = dtPFM.Rows[0]["Location_Date"].ToString();
            // }

        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDate(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public void LoadDestination()
    {

        try
        {
            string strAgent = "";
            //strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString();
            strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID";


            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddldestination.Items.Clear();
            while (dr.Read())
            {
                ddldestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadCommodity()
    {
        try
        {
            string strcomm = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strcomm, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlScr.Items.Clear();
            ddlScr.Items.Insert(0, "--Select--");
            ddlScr.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        addHandover();
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public void flightSearch()
    {
        ViewState["AgentRateID"] = null;
        ViewState["SlabID"] = null;
        ViewState["NextSlabID"] = null;
        ViewState["nextslabChwt"] = null;
        ViewState["BeneficialPriceValue"] = null;
        ViewState["Min"] = null;
        ViewState["nextslabrate"] = null;

        DataTable AirlineDetailID = dw.GetAllFromQuery("SELECT  am.Airline_Code, ad.Airline_ID, ad.Belongs_To_City, ad.Airline_Detail_ID FROM Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID where am.Airline_Code=" + lblawbno.Text.Substring(0, 3) + " and ad.Belongs_To_City=" + cityID);
        ViewState["AirlineDetailID"] = AirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString();

        con = new SqlConnection(strCon);
        com = new SqlCommand("[ASPHANDOVER_RATE]", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Origin", SqlDbType.Int).Value = int.Parse(cityID);
        com.Parameters.Add("@Destination", SqlDbType.BigInt).Value = long.Parse(ddldestination.SelectedValue);
        com.Parameters.Add("@FlightDate", SqlDbType.DateTime).Value = FormatDateDD(lblfdate.Text);
        com.Parameters.Add("@AirlineDetailID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@ShipmentID", SqlDbType.Int).Value = int.Parse(shpt_id);
        com.Parameters.Add("@Gw", SqlDbType.Decimal).Value = decimal.Parse(txtgwt.Text);
        com.Parameters.Add("@Chwt", SqlDbType.Decimal).Value = decimal.Parse(txtchwt.Text);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Columns.Count != 1)
        {
            if (dt.Rows.Count > 0)
            {

                ViewState["AgentRateID"] = long.Parse(dt.Rows[0]["AgentRateID"].ToString());
                ViewState["SlabID"] = int.Parse(dt.Rows[0]["SlabID"].ToString());
                ViewState["NextSlabID"] = int.Parse(dt.Rows[0]["NextSlabID"].ToString());
                ViewState["nextslabChwt"] = decimal.Parse(dt.Rows[0]["NextSlabChwt"].ToString());
                ViewState["BeneficialPriceValue"] = decimal.Parse(dt.Rows[0]["BeneficialPriceValue"].ToString());
                decimal Min = decimal.Parse(dt.Rows[0]["Min"].ToString());
                Min = Math.Round(Min, MidpointRounding.AwayFromZero);
                ViewState["Min"] = Min.ToString();

                //**********
                msg.Visible = false;
            }
            else
            {

                msg.Visible = true;
                msg.Text = "Flight not found";
            }
        }
        else
        {
            msg.Visible = true;
            msg.Text = "Rates not found";
        }

    }
    public void addHandover()
    {
        string handoverID = "";
        string enteredOn = Convert.ToString(DateTime.Now);
        string emailId = Session["EMailID"].ToString();
        string deal = "14";
        string editsales = "14";
        decimal tariffamount = 0;


        tariffamount = decimal.Parse(txttariffrate.Text) * decimal.Parse(txtchwt.Text);

        // INSERT DATA INTO HANDOVER TABLE
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            trans = con.BeginTransaction();
            string strAddHandover = "insert into Handover(Booking_ID,Flight_open_Id,Stock_Id,Special_Commodity_Id,Shipment_ID,City_ID,Destination_Id,Flight_Date,No_of_Packages,Measurement_unit,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,tariff_rate,freight_amount,handover_date,entered_By,Expected_Handover_Date,Special_Rate,Special_Amount,Added_To_Sales,Add_To_Deal,Entered_On,Location,ShipmentBill,Nature_and_Quantity,Location_date,Location_Time) values('" + ViewState["bookingID"].ToString() + "','" + ViewState["fltopen_id"].ToString() + "','" + ViewState["StockID"].ToString() + "','" + ddlScr.SelectedValue + "','" + ViewState["shpt_id"].ToString() + "','" + ViewState["cityID"].ToString() + "','" + ddldestination.SelectedItem.Value + "','" + FormatDateMM(lblfdate.Text) + "','" + txtpcs.Text + "','" + ViewState["ms_unit"].ToString() + "','" + txtgwt.Text + "','" + txtvolwt.Text + "','" + txtchwt.Text + "','" + ViewState["frt_type"].ToString() + "','" + txttariffrate.Text + "','" + tariffamount.ToString() + "','" + ViewState["hnd_date"].ToString() + "','" + emailId + "','" + ViewState["hnd_date"].ToString() + "','" + ViewState["sp_rate"].ToString() + "','" + ViewState["sp_amt"].ToString() + "','" + editsales + "','" + deal + "','" + enteredOn + "','" + txtLOC.Text + "','" + txtSbNo.Text + "','" + txtcommodity.Text + "','" + FormatDateMM(txtLOCDate.Text) + "','" + txtLocTime.Text + "')";

            SqlCommand cmdAddHandover = new SqlCommand(strAddHandover, con, trans);
            cmdAddHandover.ExecuteNonQuery();

            DataTable dtID;
            dtID = dw.GetAllFromQuery("select ident_current('Handover') as ID");

            if (dtID.Rows.Count > 0)
            {
                handoverID = dtID.Rows[0]["ID"].ToString();
                ViewState["HANDOVERID"] = handoverID;
            }
            string HID = ViewState["HANDOVERID"].ToString();
            string strOtherCharge = "update  Other_Charges set Handover_ID='" + handoverID + "' where Booking_ID='" + ViewState["bookingID"].ToString() + "'";

            SqlCommand cmdOtherCharges = new SqlCommand(strOtherCharge, con, trans);
            cmdOtherCharges.ExecuteNonQuery();

            // INSERT INTO Handover_Dimensions 
            if (ViewState["leng"].ToString() != "" && ViewState["brth"].ToString() != "" && ViewState["heigt"].ToString() != "")
            {

                string strDimension = "insert into Handover_Dimensions(Handover_ID,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit) values('" + handoverID + "','" + ViewState["no_of_pcs"].ToString() + "','" + ViewState["leng"].ToString() + "','" + ViewState["brth"].ToString() + "','" + ViewState["heigt"].ToString() + "','" + ViewState["total"].ToString() + "','" + ViewState["ms_unit"].ToString() + "')";

                SqlCommand cmdDimnension = new SqlCommand(strDimension, con, trans);

                cmdDimnension.ExecuteNonQuery();
            }

            // UPDATE BOOKING_AWB TABLE
            string strBookingAWB = "";

            strBookingAWB = "update Booking_AWB set Handover_ID = '" + HID + "' where Booking_ID='" + ViewState["bookingID"].ToString() + "' ";

            SqlCommand cmdBookingAWB = new SqlCommand(strBookingAWB, con, trans);
            cmdBookingAWB.ExecuteNonQuery();

            string handStatus = "13";
            string stat = "10";
            // UPDATE BOOKING STATUS if booked cargo is handover.
            if (ViewState["bookingID"].ToString() != "")
            {
                string strUpdate = "update booking_master set Handovered_Status = '" + handStatus + "',status = '" + stat + "',ShipmentBill='" + txtSbNo.Text + "',Location='" + txtLOC.Text + "',Gross_Weight='" + txtgwt.Text + "',Volume_Weight='" + txtvolwt.Text + "',Charged_Weight='" + txtchwt.Text + "',Special_Commodity_ID='" + ddlScr.SelectedValue + "',Destination_ID='" + ddldestination.SelectedItem.Value + "',Tariff_Rate='" + txttariffrate.Text + "',Freight_Amount='" + tariffamount.ToString() + "',Entered_By='" + Session["EMailID"].ToString() + "',Entered_On='" + DateTime.Now + "',Nature_and_Quantity='" + txtcommodity.Text + "',Location_Date='" + FormatDateMM(txtLOCDate.Text) + "',Location_Time='" + txtLocTime.Text + "' where Booking_ID = '" + ViewState["bookingID"].ToString() + "'";
                SqlCommand cmdUpdate = new SqlCommand(strUpdate, con, trans);
                cmdUpdate.ExecuteNonQuery();
            }
            string strupdt = "update stock_master set status = '" + stat + "',Used_Date = '" + ViewState["awb_date"].ToString() + "',NeutralAWB='" + rblnutralAWB.SelectedValue + "' where AirWayBill_No = '" + lblawbno.Text + "'";
            SqlCommand cmdUpdate1 = new SqlCommand(strupdt, con, trans);
            cmdUpdate1.ExecuteNonQuery();
            trans.Commit();
            con.Close();



            Response.Redirect("APSHandover.aspx?id=" + lblawbno.Text);
        }
        catch (SqlException ee)
        {
            lblErrorMsg.Text = "sql error" + ee.Message;
            trans.Rollback();

        }
        finally
        {
            con.Close();
        }

    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("APSHandover.aspx");
    }
    //private void SendMail(string emailAdd, string body)
    //{
    //    //Label1.Visible = true;
    //    MailMessage msg = new MailMessage();
    //    msg.To = emailAdd;
    //    msg.Bcc = "software@groupconcorde.com";
    //    msg.From = "Group Concorde <admin@groupconcorde.com>";
    //    msg.Subject = lblawbno.Text + " Collect Shpt Det";
    //    msg.BodyFormat = MailFormat.Html;
    //    msg.Body = body;
    //    try
    //    {
    //        SmtpMail.SmtpServer = "mail.groupconcorde.com";
    //        SmtpMail.Send(msg);
    //    }
    //    catch (HttpException ex)
    //    {
    //    }
    //}

    protected void ddlScr_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlScr.SelectedItem.Value == "0")
        {
            txtcommodity.Text = "";
        }
        else
        {
            txtcommodity.Text = ddlScr.SelectedItem.Text;
        }
    }



    protected void btnUpdate_Click(object sender, EventArgs e)
    {


        con = new SqlConnection(strCon);
        decimal grosswt = Convert.ToDecimal(txtgwt.Text);
        decimal chrgwt = Convert.ToDecimal(txtchwt.Text);
        decimal Volwt = Convert.ToDecimal(txtvolwt.Text);

        DataTable dtBooking_AWB = dw.GetAllFromQuery("select * from Handover_EditDetails where airwaybill_No='" + Request.QueryString["Airwaybill_no"] + "' and status in (9,10)");

        if (dtBooking_AWB.Rows.Count > 0)
        {

            //***************************Condition Checked***********


            string Origin = dtBooking_AWB.Rows[0]["City_ID"].ToString();
            // string DestinationID = dtBooking_AWB.Rows[0]["Destination_ID"].ToString();
            //string Shipment_ID = dtBooking_AWB.Rows[0]["Shipment_ID"].ToString();
            string Destination = ddldestination.SelectedValue;
            //string Shipment_ID = ddlShipmentType.SelectedValue;
            string Airline_detailID = dtBooking_AWB.Rows[0]["Airline_Detail_ID"].ToString();
            //decimal tariff_rate = Convert.ToDecimal(dtBooking_AWB.Rows[0]["Tariff_Rate"].ToString());
            //decimal freightAmt = Convert.ToDecimal(dtBooking_AWB.Rows[0]["Freight_Amount"].ToString());

            decimal tariff_rate = Convert.ToDecimal(txttariffrate.Text);
            decimal freightAmt = Convert.ToDecimal(txttariffrate.Text) * Convert.ToDecimal(txtchwt.Text);

            string Location = txtLOC.Text;
            string ShptBill = txtSbNo.Text;

            string Pieces = Convert.ToString(txtpcs.Text);
            decimal sFSC = 0;
            decimal sWSC = 0;
            decimal sXray = 0;
            decimal DueCarrier = 0;
            decimal ACI = 0;
            decimal AWBFee = 0;
            decimal DisburmentChrgs = 0;
            decimal Cartage = 0;
            decimal srate = 0;
            decimal Special_Amt = 0;
            string emailId = Session["EMailID"].ToString();
            decimal TotalPrepaid = 0;
            decimal TotalCollect = 0;
            string editsales = "14";
            string deal = "14";

            DataTable dtCharges = dw.GetAllFromQuery("select FreightSurCharge_Charged,FreightSurCharge_On,WarSurCharge_Charged,WarSurcharge_On,XRayCharge_Charged,XRayCharge_On,AWB_Fees,ACI_Fees,DisBursementCharges from Airline_Detail where Airline_Detail_ID=" + Airline_detailID);

            DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID= '" + Airline_detailID + "' and Shipment_ID='" + ViewState["shpt_id"].ToString() + "'  and Destination='" + ddldestination.SelectedItem.Value + "' and Origin='" + Origin + "'");



            if (dtCharges.Rows.Count > 0)
            {
                if (dtCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
                {
                    if (dtCharges.Rows[0]["FreightSurCharge_On"].ToString() == "Chargable Wt")
                    {
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            sFSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                            sFSC = chrgwt * sFSC;
                        }
                    }
                    else
                    {
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            sFSC = decimal.Parse(dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString());
                            sFSC = grosswt * sFSC;
                        }
                    }
                }
                if (dtCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
                {
                    if (dtCharges.Rows[0]["WarSurcharge_On"].ToString() == "Chargable Wt")
                    {
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            sWSC = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                            sWSC = chrgwt * sWSC;
                        }
                    }
                    else
                    {
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            sWSC = decimal.Parse(dtChargesDetails.Rows[0]["Security_SurCharge"].ToString());
                            sWSC = grosswt * sWSC;
                        }
                    }
                }
                if (dtCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
                {
                    if (dtCharges.Rows[0]["XRayCharge_On"].ToString() == "Chargable Wt")
                    {
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            sXray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                            sXray = chrgwt * sXray;
                        }
                    }
                    else
                    {
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            sXray = decimal.Parse(dtChargesDetails.Rows[0]["XRay_Charges"].ToString());
                            sXray = grosswt * sXray;
                        }
                    }
                }

                ACI = decimal.Parse(dtBooking_AWB.Rows[0]["ACI_Fees"].ToString());
                AWBFee = decimal.Parse(dtBooking_AWB.Rows[0]["AWb_Fees"].ToString());
                DisburmentChrgs = decimal.Parse(dtBooking_AWB.Rows[0]["DisbursementCharges"].ToString());
                Cartage = decimal.Parse(dtBooking_AWB.Rows[0]["Cartridge_Charges"].ToString());


                //**** For Catrage Charges***************
                if (dtBooking_AWB.Rows[0]["City_ID"].ToString() == "18")
                {
                    if (grosswt >= 50)
                    {
                        Cartage = grosswt;
                    }
                    else
                    {
                        Cartage = 50;
                    }
                }
                else
                {
                    Cartage = 0;
                }
                //****End of Catrage Charges*************
                //srate = decimal.Parse(dtBooking_AWB.Rows[0]["special_Rate"].ToString());

                srate = tariff_rate;

                DueCarrier = sFSC + sWSC + sXray + ACI + AWBFee + DisburmentChrgs + Cartage;
                Special_Amt = chrgwt * srate;
                //****************Total Preapaid and Total collect Calculation on DueCarrier Basis
                if (ViewState["frt_type"].ToString() == "PREPAID")
                {
                    TotalPrepaid = DueCarrier + freightAmt;

                }
                else
                {
                    TotalCollect = DueCarrier + freightAmt;

                }
                //***********End Of Total Preaid and total Collect calculation*******************
                //****************************End****************************



                con.Open();
                com = new SqlCommand("UpdateAspHandoverDetails", con);
                com.CommandType = CommandType.StoredProcedure;

                // PASS THE PARAMETERS
                com.Parameters.Add("@Booking_Id", SqlDbType.Int).Value = int.Parse(dtBooking_AWB.Rows[0]["Booking_ID"].ToString());

                com.Parameters.Add("@Special_commodity_Id", SqlDbType.Int).Value = int.Parse(ddlScr.SelectedItem.Value);
                com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(ViewState["shpt_id"].ToString());

                com.Parameters.Add("@Destination_Id", SqlDbType.Int).Value = int.Parse(Destination);
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(Pieces);
                com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = grosswt;
                com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = Volwt;
                com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = chrgwt;

                com.Parameters.Add("@tariff_rate", SqlDbType.Decimal).Value = tariff_rate;
                com.Parameters.Add("@freight_amount", SqlDbType.Decimal).Value = freightAmt;
                com.Parameters.Add("@entered_By", SqlDbType.VarChar).Value = emailId;
                com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = srate;
                com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = Special_Amt;
                com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                com.Parameters.Add("@Location", SqlDbType.VarChar).Value = Location;
                com.Parameters.Add("@ShipmentBill", SqlDbType.VarChar).Value = ShptBill;
                com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = txtcommodity.Text;

                com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = ACI;
                com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = Cartage;
                com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = DueCarrier;
                com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = DisburmentChrgs;
                com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = AWBFee;
                com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = sFSC;
                com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = sWSC;
                com.Parameters.Add("@Xray_charges", SqlDbType.Decimal).Value = sXray;
                com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = TotalPrepaid;
                com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = TotalCollect;
                com.Parameters.Add("@NeutralAWB", SqlDbType.VarChar).Value = rblnutralAWB.SelectedValue;
                
                com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = lblawbno.Text;

                com.Parameters.Add("@Location_Date", SqlDbType.DateTime).Value = FormatDateDD(txtLOCDate.Text);

                com.Parameters.Add("@Location_Time", SqlDbType.VarChar).Value = txtLocTime.Text;

                com.ExecuteNonQuery();
                con.Close();


            }
        }

        string strScript = "alert('HANDOVER Successfully.');location.replace('APSHandover.aspx');";

        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);



    }
}
