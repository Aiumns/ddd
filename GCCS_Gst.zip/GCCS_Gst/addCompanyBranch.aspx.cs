using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class addCompanyBranch : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataAdapter da;
    DataSet ds;
    string str = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack && Request.QueryString["id"] == null)
            {

                BindCompId();
                BindCity();
                BindStatus();
                btnAdd.Text = "Add";
                lblMsg.Text = "Add Company Branch Details";
                btnAdd.Attributes.Add("onclick", "return CheckEmpty()");
            }

            if (!Page.IsPostBack && Request.QueryString["id"] != null)
            //if (!Page.IsPostBack && Request.QueryString["id"] != null)
            {
                ddlCom.Enabled = false;
                btnAdd.Text = "Update";
                lblMsg.Text = "Update Company Branch Details";
                BindCompId();
                BindCity();
                BindStatus();
                SelectDDl();
                btnAdd.Attributes.Add("onclick", "return CheckEmpty()");
            }
        }
    }
        
  public void btnAdd_Click(object sender, EventArgs e)
    { 
      
        try
        {
            if (btnAdd.Text == "Add")
            {

                con = new SqlConnection(strcon);
                {
                    con.Open();
                    string str1 = "";
                    //Company_ID = Int32.Parse(Request.QueryString["Company_ID"]);
                    str1 = "select city from company_master where (company_id='" + ddlCom.SelectedItem.Value + "' or parent_id='" + ddlCom.SelectedItem.Value + "') and city='" + ddlCity.SelectedItem.Value.Trim() + "'";
                    //str1 = "select * from Company_Master where City='" + ddlCity.SelectedItem.Value.Trim() + "' and Company_name='" + ddlCom.SelectedItem.Text + "'";
                    //str1 = "select * from Company_Master where Company_Email='" + txtCompanyEmail.Text + "'";
                    da = new SqlDataAdapter(str1, con);
                    ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {

                        lblError.Text = " City " + ddlCity.SelectedItem.Text + " Alredy Exist For Company " + ddlCom.SelectedItem.Text.Trim();

                    }
                    else
                    {

                        com = new SqlCommand("insert into company_master(Company_Name,Company_Address,Phone,Company_Fax,Company_Email,Parent_ID,TDS_Rate,SurCharge,City,Status) values(@Company_Name,@Company_Address,@Phone,@Company_Fax,@Company_Email,@Parent_ID,@TDS_Rate,@SurCharge,@City,@Status)", con);
                        com.Parameters.AddWithValue("@Company_Name", txtBname.Text);
                        com.Parameters.AddWithValue("@Company_Address", txtBadd.Text);
                        com.Parameters.AddWithValue("@Phone", txtBphone.Text);
                        com.Parameters.AddWithValue("@Company_Fax", txtBfax.Text);
                        com.Parameters.AddWithValue("@Company_Email", txtbemail.Text);
                        com.Parameters.AddWithValue("@Parent_ID", ddlCom.SelectedItem.Value);
                        com.Parameters.AddWithValue("@TDS_Rate", txtTaxDeductionSource.Text);
                        com.Parameters.AddWithValue("@SurCharge", txtBsurCh.Text);
                        com.Parameters.AddWithValue("@City", ddlCity.SelectedItem.Value); com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
                        int a = com.ExecuteNonQuery();
                        con.Close();
                        Response.Redirect("showCompanyBranch.aspx");
                    }
                }
            }
            else
            {
                UpdateBranch();
            } 
          //  Response.Write "Data has Been saved";
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
            //if (btnAdd.Text == "Add")        
            //Response.Redirect("addCompanyBranch.aspx");
            //else
            Response.Redirect("showCompanyBranch.aspx");  
     
    }
    protected void BindCompId()
    {
        ddlCom.Items.Clear();
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            string search = "select company_id,company_name  from company_master where parent_id=0";
            com = new SqlCommand(search, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlCom.Items.Add("--Select--");
            ddlCom.Items[0].Value = "";
            while (dr.Read())
            {
                ddlCom.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }      
    }
    protected void  BindCity()
    {
        ddlCity.Items.Clear();
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            string search = "select * from city_master";
            com = new SqlCommand(search, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlCity.Items.Add("--Select--");
            ddlCity.Items[0].Value = "";
            while (dr.Read())
            {
                ddlCity.Items.Add(new ListItem(dr[2].ToString()+"("+dr[1].ToString()+")", dr[0].ToString()));
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }      
    }

    protected void BindStatus()
    {

        ddlStatus.Items.Clear();
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            string search = "select * from status_master where status_name in ('Active','Inactive')";
            com = new SqlCommand(search, con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlStatus.Items.Add("--Select--");
            //ddlStatus.Items[0].Value = "";
            while (dr.Read())
            {
                ddlStatus.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }      
    
    }
protected void SelectDDl()
       {
       //if (Request.QueryString != null)
       
        try
        {
            str = Request.QueryString["id"].ToString();        
                con = new SqlConnection(strcon);
                con.Open();
                com = new SqlCommand("select b.company_id,a.company_name ,b.company_name as Bcompany_name,a.company_address,a.Phone,a.Company_fax ,a.company_email,a.tds_rate,a.surcharge ,a.City as City ,a.Status from company_master a inner join company_master b on b.company_id=a.parent_id where a.parent_id<>0 and a.company_id=" + str + " ", con);
                SqlDataReader dr = com.ExecuteReader();
              if (dr.Read())
              {
                  //string s = dr[0].ToString();
                  ddlCom.SelectedIndex = ddlCom.Items.IndexOf(ddlCom.Items.FindByValue(dr["company_id"].ToString()));
              // ddlCom.SelectedIndex = ddlCom.Items.IndexOf(ddlCom.Items.FindByValue(s));
                    ddlCity.SelectedIndex = ddlCity.Items.IndexOf(ddlCity.Items.FindByValue(dr["city"].ToString()));
                    ddlStatus.SelectedIndex = ddlStatus.Items.IndexOf(ddlStatus.Items.FindByValue(dr["status"].ToString()));
                    txtBname.Text = dr[1].ToString();
                    txtBadd.Text = dr["Company_Address"].ToString();
                    txtBphone.Text = dr["Phone"].ToString();
                    txtBfax.Text = dr["Company_Fax"].ToString();
                    txtbemail.Text = dr["Company_Email"].ToString();
                    txtTaxDeductionSource.Text = dr["TDS_Rate"].ToString();
                    txtBsurCh.Text = dr["SurCharge"].ToString();
                    lblcity.Text = dr["City"].ToString();
                    //ddlCom.SelectedIndex =int.Parse(s);
             }
             con.Close();
            }
        
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
      

    }
}
    protected void UpdateBranch()
    {
     
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            string str1;
            //string name1 = lblName.Text;
            //string name2 = ddlCom.SelectedItem.Text;
            string name3 = lblcity.Text;
            string name4 = ddlCity.SelectedItem.Value;
            //con = new SqlConnection(strCon);
            //int Company_ID = Int32.Parse(Request.QueryString["id"]);
            //str1 = "select city from company_master where (company_id='" + ddlCom.SelectedItem.Value + "' or parent_id='" + ddlCom.SelectedItem.Value + "') and city='" + ddlCity.SelectedItem.Value.Trim() + "'";
            if (String.Compare(name3, name4) == 0 )
            {
                com = new SqlCommand("Update company_master set Company_Name=@Company_Name,Company_Address=@Company_Address,Phone=@Phone,Company_Fax=@Company_Fax,Company_Email=@Company_Email,Parent_ID=@Parent_ID,TDS_Rate=@TDS_Rate,SurCharge=@SurCharge,City=@City,Status=@Status where company_id=" + Request.QueryString["id"].ToString() + "", con);

                com.Parameters.AddWithValue("@Company_Name", txtBname.Text);
                com.Parameters.AddWithValue("@Company_Address", txtBadd.Text);
                com.Parameters.AddWithValue("@Phone", txtBphone.Text);
                com.Parameters.AddWithValue("@Company_Fax", txtBfax.Text);
                com.Parameters.AddWithValue("@Company_Email", txtbemail.Text);
                com.Parameters.AddWithValue("@Parent_ID", ddlCom.SelectedItem.Value);
                com.Parameters.AddWithValue("@TDS_Rate", txtTaxDeductionSource.Text);
                com.Parameters.AddWithValue("@SurCharge", txtBsurCh.Text);
                com.Parameters.AddWithValue("@City", ddlCity.SelectedItem.Value);
                com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
                com.ExecuteNonQuery();
                con.Close();
                Response.Redirect("showCompanyBranch.aspx");
            }
            else

            {

    str1 = "select city from company_master where (company_id='" + ddlCom.SelectedItem.Value + "' or parent_id='" + ddlCom.SelectedItem.Value + "') and city='" + ddlCity.SelectedItem.Value.Trim() + "'";
                da = new SqlDataAdapter(str1, con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    lblError.Text = " City  " + ddlCity.SelectedItem.Text + " Already Exist For Company " + ddlCom.SelectedItem.Text;
                    //btnAdd.Visible = false;
                    //bt.Visible = true;
                    //lblAdd.Visible = false;
                    //lblUpdate.Visible = true;
                }
                else
                {
                    com = new SqlCommand("Update company_master set Company_Name=@Company_Name,Company_Address=@Company_Address,Phone=@Phone,Company_Fax=@Company_Fax,Company_Email=@Company_Email,Parent_ID=@Parent_ID,TDS_Rate=@TDS_Rate,SurCharge=@SurCharge,City=@City,Status=@Status where company_id=" + Request.QueryString["id"].ToString() + "", con);

                    com.Parameters.AddWithValue("@Company_Name", txtBname.Text);
                    com.Parameters.AddWithValue("@Company_Address", txtBadd.Text);
                    com.Parameters.AddWithValue("@Phone", txtBphone.Text);
                    com.Parameters.AddWithValue("@Company_Fax", txtBfax.Text);
                    com.Parameters.AddWithValue("@Company_Email", txtbemail.Text);
                    com.Parameters.AddWithValue("@Parent_ID", ddlCom.SelectedItem.Value);
                    com.Parameters.AddWithValue("@TDS_Rate", txtTaxDeductionSource.Text);
                    com.Parameters.AddWithValue("@SurCharge", txtBsurCh.Text);
                    com.Parameters.AddWithValue("@City", ddlCity.SelectedItem.Value);
                    com.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
                    com.ExecuteNonQuery();
                    con.Close();
                    Response.Redirect("showCompanyBranch.aspx");

                }
            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
