using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Mail;

public partial class air_tickets : System.Web.UI.Page
{
    //string strCon = ConfigurationManager.AppSettings["CN"];
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        lbmsg.Visible = false;
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {

            SqlConnection Con = new SqlConnection(strCon);
            SqlCommand Com = new SqlCommand();
            string strQuery = "";
            strQuery = "INSERT INTO Details(Name,CompName,Telephone,Email,Origin,Destination,FromDate,ToDate,PreferredClass,OtherDetail)VALUES(@Name,@CompName,@Telephone,@Email,@Origin,@Destination,@FromDate, @ToDate,@PreferredClass,@OtherDetail)";
            Com = new SqlCommand(strQuery, Con);
            Con.Open();
            Com.Parameters.Add("@Name", SqlDbType.VarChar).Value = TxtName.Text;
            Com.Parameters.Add("@CompName", SqlDbType.VarChar).Value = TxtCompanyName.Text;
            Com.Parameters.Add("@Telephone", SqlDbType.VarChar).Value = TxtTelephone.Text;
            Com.Parameters.Add("@Email", SqlDbType.VarChar).Value = TxtEmail.Text;
            Com.Parameters.Add("@Origin", SqlDbType.VarChar).Value = TxtOther.Text;
            Com.Parameters.Add("@Destination", SqlDbType.VarChar).Value = TxtDestination.Text;
            Com.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = DateTime.Parse(TxtFdate.Text);
            Com.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = DateTime.Parse(TxtToDate.Text);
            Com.Parameters.Add("@PreferredClass", SqlDbType.VarChar).Value = Rdlistclass.SelectedItem.Text.ToString();
            Com.Parameters.Add("@OtherDetail", SqlDbType.VarChar).Value = TxtOther.Text;
            Com.ExecuteNonQuery();
            Com.Dispose();
            Con.Close();

            string body = "<font face='verdana' color='blue' size=" + ("'2'>Dear Trade Partner,<br><br>The IterItinerary Details  are as below <br><br>" + " Name:" + TxtName.Text + "<br> CompanyName:" + TxtCompanyName.Text + "<br>Phone no:" + TxtTelephone.Text + "<br>Origin:" + TxtOrigin.Text + "<br> Destination:" + TxtDestination.Text + "<br>From Date:" + TxtFdate.Text + "<br> To Date:" + TxtToDate.Text + "<br>Preferred Class:" + Rdlistclass.SelectedItem.Text + " <br> Other Detail :" + TxtOther.Text + "<br><br><br>Best Regards, <br> ") + "Team<br><br><br><a href='http://www.groupconcorde.com'>http://www.groupconcorde.com</a>";
            string body2 = "<font face='verdana' color='blue' size=" + ("'2'>Dear Customer,<br><br> Thank you! We have recieved your itinerary.We will revert back shortly.<br><br><br>Best Regards, <br> ") + "Marketing Team<br>Group Concorde";
            SendEMail(TxtEmail.Text, body);
            SendEMail2(TxtEmail.Text, body2);
            ClearTextbox();
        }
        catch (SqlException ex)
        {
            string str = ex.ToString();
        }
    }

    private void ClearTextbox()
    {
        TxtName.Text = "";
        TxtCompanyName.Text = "";
        TxtEmail.Text = "";
        TxtTelephone.Text = "";
        TxtOrigin.Text = "";
        TxtDestination.Text = "";
        TxtFdate.Text = "";
        TxtToDate.Text = "";
        TxtOther.Text = "";
    }

    protected void SendEMail(string emailAddress, string body)
    {
        MailMessage msg = new MailMessage();
        //msg.To = "srastogi.cargoflash@groupconcorde.com";
        // msg.To = emailAddress;
        //   msg.From = "akhan.cargoflash@groupconcorde.com";
        // msg.From = "madhur@groupconcorde.com,srarora.ascent@groupconcorde.com";
        //msg.To = "madhur@groupconcorde.com;srarora.ascent@groupconcorde.com;srastogi.cargoflash@groupconcorde.com";
        msg.To = "srarora.ascent@groupconcorde.com";
        msg.From = "info@groupconcorde.com";
        msg.Subject = "Itinerary Detail Of Agent";
        msg.BodyFormat = MailFormat.Html;
        msg.Body = body;
        //   msg.Fields["http://schemas.microsoft.com/cdo/configuration/smtpserverport"] = 26;
        try
        {
            SmtpMail.SmtpServer = "DH-CFIWEB";
            SmtpMail.Send(msg);
        }
        catch (HttpException ex)
        {
            string str = ex.ToString();
        }
    }
    protected void SendEMail2(string emailAddress, string body2)
    {
        MailMessage msg = new MailMessage();
        // msg.To = "srastogi.cargoflash@groupconcorde.com";
        // msg.To = emailAddress;
        //   msg.From = "akhan.cargoflash@groupconcorde.com";
        // msg.From = "madhur@groupconcorde.com,srarora.ascent@groupconcorde.com";
        msg.To = emailAddress;
        msg.From = "info@groupconcorde.com";
        msg.Subject = "Itinerary Detail Of Agent";
        msg.BodyFormat = MailFormat.Html;
        msg.Body = body2;
        msg.Fields["http://schemas.microsoft.com/cdo/configuration/smtpserverport"] = 26;
        try
        {
            // SmtpMail.SmtpServer = "DH-CFIWEB";
            SmtpMail.SmtpServer = "localhost";
            SmtpMail.Send(msg);
            lbmsg.Visible = true;
            lbmsg.Text = "&quot; Thank you &shy; this is an auto receipt confirmation of your query mail, we will revert back to you soon.&quot;";

        }
        catch (HttpException ex)
        {
            lbmsg.Visible = true;
            lbmsg.Text = "&quot; Mail could not be sent.&quot;";
            string str = ex.ToString();
        }
    }
}
