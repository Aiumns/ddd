using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Edit_importflightopen : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    //SqlTransaction trans;
    string Import_Flight_OpenId;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            string str1;
            if (!IsPostBack && Request.QueryString["fid"] != null)
            {
                con = new SqlConnection(strCon);
                Import_Flight_OpenId = Convert.ToString(Request.QueryString["fid"]);
                DataTable dtShow = dw.GetAllFromQuery("select IFO.Import_Flight_Open_ID,Airline_Name,IFO.Airline_Detail_ID,AM.Airline_Name +'-'+ CM.city_name as airlineName,Convert(varchar,FO.Open_Date,103) as FlightDate,Convert(varchar,IFO.Flight_Date,103) as FlightDate1,IFO.Import_Flight_No,FM.Flight_Type,CM.City_Code as Origin,DM.Destination_Code as Destination,Convert(varchar,IFO.Flight_Close_date,103) as CloseDate,IFO.IGM_NO,Convert(varchar,IFO.IGM_DATE,103) as IGMDATE,IFO.RegNo,IFO.Flight_Status_Check from Import_Flight_Open IFO Inner Join Flight_Open FO ON IFO.Import_Flight_Open_ID=FO.Import_Flight_Open_ID INNER JOIN Flight_Master FM on FM.Flight_ID=FO.Flight_ID INNER JOIN CITY_Master CM ON CM.City_ID=IFO.Import_Destination INNER JOIN DESTINATION_MASTER DM on DM.Destination_ID=IFO.Import_Origin Inner Join AIRLINE_DETAIL AD on AD.Airline_detail_id=IFO.Airline_detail_id Inner Join Airline_Master AM on AM.Airline_ID=Ad.Airline_ID where IFO.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and IFO.FLIGHT_Close_date > '" + DateTime.Parse(DateTime.Now.ToShortDateString()) + "' and Ifo.Import_Flight_Open_ID=" + Import_Flight_OpenId + " order by IFO.Airline_Detail_ID,IFO.Flight_Date desc");
                 ddlairline.Items.Add(new ListItem(dtShow.Rows[0]["Airline_Name"].ToString(), dtShow.Rows[0]["Airline_Detail_Id"].ToString()));
                 txtflightno.Text = dtShow.Rows[0]["Import_Flight_No"].ToString();
                 txtdestn.Text = dtShow.Rows[0]["Destination"].ToString();
                 txtorigin.Text = dtShow.Rows[0]["Origin"].ToString();
                 txtflightdate.Text = dtShow.Rows[0]["FlightDate"].ToString();
                 txtigmno.Text = dtShow.Rows[0]["IGM_No"].ToString();
                 txtigmdate.Text = dtShow.Rows[0]["IGMDATE"].ToString();
                 txtclosedate.Text = dtShow.Rows[0]["CloseDate"].ToString();
                 txtRegNo.Text = dtShow.Rows[0]["RegNo"].ToString();
                 rdfltStatus.SelectedValue = dtShow.Rows[0]["Flight_Status_Check"].ToString();
                 


                }
            }
        }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowImportFlight_Open.aspx");
    }

    string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
       
        Update();
    }
    public void Update()
    {
        con = new SqlConnection(strCon);//Making Connection
        string UpdateQ;
        try
        {
            con.Open();
            //trans = con.BeginTransaction();

            {
                //decimal amt_rec1 = (txtAmtRec.Text.Trim() == "" ? 0 : decimal.Parse(txtAmtRec.Text));
                //decimal other_chg1 = (txtOthers.Text.Trim() == "" ? 0 : decimal.Parse(txtOthers.Text));
                //decimal stx = (txtServiceTax.Text.Trim() == "" ? 0 : decimal.Parse(txtServiceTax.Text));
                //Update Import_AWB table

                UpdateQ = "update Import_Flight_Open set IGM_No=@IGM_No,IGM_Date=@IGM_Date,Flight_Close_Date=@Flight_Close_Date,RegNo=@RegNo,Flight_Status_Check=@Flight_Status_Check,Last_Modified_By=@Last_Modified_By, Last_Modified_On = @Last_Modified_On where Import_Flight_Open_ID='" + Convert.ToString(Request.QueryString["fid"]) + "'";
                com = new SqlCommand(UpdateQ, con);
                com.Parameters.Add("@IGM_No", SqlDbType.VarChar, 50).Value = txtigmno.Text;
                com.Parameters.Add("@IGM_Date", SqlDbType.DateTime).Value = ConvertDate(txtigmdate.Text);
                com.Parameters.Add("@Flight_Close_Date", SqlDbType.DateTime).Value = ConvertDate(txtclosedate.Text);
                com.Parameters.Add("@RegNo", SqlDbType.VarChar, 50).Value = txtRegNo.Text;
                com.Parameters.Add("@Flight_Status_Check", SqlDbType.VarChar, 50).Value = rdfltStatus.SelectedItem.Text;
                com.Parameters.Add("@Last_Modified_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                com.Parameters.Add("@Last_Modified_On", SqlDbType.DateTime).Value = DateTime.Now;


                com.ExecuteNonQuery();
                com.Dispose();

            }

            //trans.Commit();
            con.Close();
            Response.Redirect("ShowImportFlight_Open.aspx");

        }
        catch (SqlException se)
        {
            string err = se.Message;
            //trans.Rollback();
            //lblmsg.Text = err;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
