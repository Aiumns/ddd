using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Bookingstatusreport_show : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter sda;
    SqlCommand cmd;
    DisplayWrap dw = new DisplayWrap();
    SqlDataReader dr;
    string no_of_pas;

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        string airlinecityvalue = Session["airline_city_value"].ToString();
        string[] exatvalue = airlinecityvalue.Split(',');
        string airlinename = Session["airline_city_text"].ToString();
        string flightno = Session["flight_no"].ToString();
        string fromdate = Session["from_date"].ToString();
        string todate = Session["to_date"].ToString();
        string flightopenid = Session["flight_id"].ToString();
        Int64 count = 1;
        Int64 no_of_pcs = 0;
        Int64 total_no_pcs = 0;
        decimal total_gwt = 0;
        decimal gwt = 0;
        decimal vwt = 0;
        decimal cwt = 0;
        decimal total_vwt = 0;
        decimal total_cwt = 0;
        Int64 grand_no_pcs = 0;
        decimal grand_cwt = 0;
        decimal grand_vwt = 0;
        decimal grant_gwt = 0;
        decimal cbm = 0;
        decimal total_cbm = 0;
        decimal grand_cbm = 0;
        decimal total_Rate = 0;
        decimal grand_Rate = 0;
        con = new SqlConnection(strCon);
        con.Open();
        Response.Write("<table border=1 width=90% align=center cellspacing=0><tr class=h1><td colspan=16 class=h1>FLT.NO.:-" + flightno + "/" + getMonthName(fromdate) + "</td></tr><tr><td colspan=16 class=boldtext align=center>From:" + fromdate + "&nbsp;&nbsp;&nbsp;To:" + todate + "</td></tr><tr><td class=boldtext align=center>S.NO.</td><td class=boldtext align=center>PER</td><td class=boldtext align=center>AWB.NO</td><td class=boldtext align=center>PCS</td><td class=boldtext align=center>G.WT</td><td class=boldtext align=center>V.WT</td><td class=boldtext align=center>C.WT</td><td class=boldtext align=center>CBM</td><td class=boldtext align=center>DEST</td><td class=boldtext align=center>P/C</td><td class=boldtext align=center>COM</td><td class=boldtext align=center>AGENT</td><td class=boldtext align=center>Status</td><td class=boldtext align=center nowrap>Booking Date</td><td class=boldtext align=center nowrap>Booking Time</td><td class=boldtext align=center nowrap>Rate</td><td class=text>&nbsp;</td></tr>");

        cmd = new SqlCommand("SELECT  SM.airwaybill_no,baw.nature_and_quantity,BM.Spot_Rate,BM.neutral,BM.Commission,BM.Tariff_Rate,BM.Special_Commodity_Incentive,BM.No_of_Packages,BM.Gross_Weight,BM.Volume_Weight,BM.Charged_Weight,BM.Freight_Type,DM.Destination_code,SC.Special_Commodity_Name,AM.Agent_name,BM.flight_date,FM.flight_no,convert(varchar,BM.entered_on,105) as 'Flight_date', convert(CHAR(5),BM.entered_on,114) as 'Booking_Time',Bm.status FROM Booking_Master BM INNER JOIN  Flight_Open FO ON BM.Flight_Open_ID = FO.Flight_Open_ID INNER JOIN Flight_Master FM ON FO.Flight_ID = FM.Flight_ID inner join stock_master SM on BM.stock_id=SM.stock_id inner join destination_master DM on DM.destination_id=BM.destination_id inner join Special_Commodity_Master SC on SC.special_commodity_id=BM.special_commodity_id  inner join agent_master AM on AM.agent_id=BM.agent_id inner join booking_awb BAW on BAW.booking_id=BM.booking_id   where FM.airline_detail_id='" + exatvalue[1] + "' and FM.flight_no='" + flightno + "'  and  BM.Flight_date >= '" + FormatDateMM(fromdate) + "' and BM.Flight_date <= '" + FormatDateMM(todate) + "'", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                no_of_pcs = Convert.ToInt64(dr["No_of_Packages"].ToString());
                string mm = dr["Gross_Weight"].ToString();
                string neutral = dr["neutral"].ToString();
                string nofq = dr["nature_and_quantity"].ToString();
                gwt = decimal.Parse(dr["Gross_Weight"].ToString());
                vwt = decimal.Parse(dr["Volume_Weight"].ToString());
                cwt = decimal.Parse(dr["Charged_Weight"].ToString());
                string[] awb = dr["airwaybill_no"].ToString().Split('-');
                cbm = Convert.ToDecimal(dr["volume_Weight"]) / 167;
                string spot = dr["Spot_Rate"].ToString();
                string rate = dr["Tariff_Rate"].ToString();
                if (spot == "")
                {
                    spot = "0";
                }
                else
                {
                    spot = dr["Spot_Rate"].ToString();
                }
                string comm = dr["Commission"].ToString();
                if (comm == "")
                {
                    comm = "0";
                }
                else
                {
                    comm = dr["Commission"].ToString();
                }
                if (neutral == "yes")
                {
                    neutral = "<b><font color=red size=5>N</b></font>" + awb[0];
                }
                else
                {
                    neutral = awb[0];
                }
                string inc = dr["Special_Commodity_Incentive"].ToString();
                if (inc == "")
                {
                    inc = "0";
                }
                else
                {
                    inc = dr["Special_Commodity_Incentive"].ToString();
                }
                string deal = "Spot=" + spot + ",-Commission=" + comm + ",-Incentive=" + inc;
                string Flight_date = dr["Flight_date"].ToString();

                string Booking_Time = dr["Booking_Time"].ToString();
                string status="";
                if (dr["status"].ToString() == "9")
                {
                    status = "Booked";
                }
                if (dr["status"].ToString() == "10")
                {
                    status = "Handover";
                }
                if (dr["status"].ToString() == "17")
                {
                    status = "NoShow";
                }
                if (dr["status"].ToString() == "12")
                {
                    status = "Void";
                }
                Response.Write("<tr><td class=text align=center>" + count + "</td><td class=text nowrap >" + neutral + "</td><td class=text onMouseover=ddrivetip('" + deal + "','','10')  onMouseout=hideddrivetip() >" + awb[1] + "</td><td class=text >" + no_of_pcs + "</td><td class=text >" + dr["Gross_Weight"].ToString() + "</td><td class=text >" + dr["Volume_Weight"].ToString() + "</td><td class=text >" + dr["charged_Weight"].ToString() + "</td><td class=text >" + Math.Round(cbm, 2) + "</td><td class=text >" + dr["Destination_code"].ToString() + "</td><td class=text >" + dr["Freight_Type"].ToString() + "</td><td class=text >" + dr["Special_Commodity_Name"].ToString() + " " + nofq + " </td><td class=text nowrap>" + dr["Agent_Name"].ToString() + "</td><td class=text >" + status + "</td><td class=text >" + Flight_date + "</td><td class=text nowrap>" + Booking_Time + "</td><td class=text nowrap>" + rate + "</td><td class=text nowrap>&nbsp;</td><td class=boldtext ></td></tr>");
                count = count + 1;
                total_gwt = total_gwt + gwt;
                total_cwt = total_cwt + cwt;
                total_vwt = total_vwt + vwt;
                total_no_pcs = total_no_pcs + no_of_pcs;
                total_cbm = total_cbm + cbm;
                total_Rate = total_Rate + decimal.Parse(rate);

            }
            Response.Write("<tr><td class=text align=center>&nbsp;</td><td class=text >&nbsp;</td><td class=boldtext >Total</td><td class=boldtext >" + total_no_pcs + "</td><td class=boldtext >" + total_gwt + "</td><td class=boldtext >" + total_vwt + "</td><td class=boldtext >" + total_cwt + "</td><td class=boldtext >" + Math.Round(total_cbm, 2) + "</td><td class=boldtext >&nbsp;</td><td class=boldtext >&nbsp;</td><td class=text >&nbsp;</td><td class=text >&nbsp;</td><td class=text >&nbsp;</td><td class=text >&nbsp;</td><td class=text >&nbsp;</td><td class=text >" + total_Rate + "</td><td class=text >&nbsp;</td></tr>");
            dr.Close();
            cmd.Dispose();
            grand_no_pcs = grand_no_pcs + total_no_pcs;
            grand_cwt = grand_cwt + total_cwt;
            grand_vwt = grand_vwt + total_vwt;
            grant_gwt = grant_gwt + total_gwt;
            grand_cbm = grand_cbm + total_cbm;
            grand_Rate = grand_Rate + total_Rate;

            total_no_pcs = 0;
            total_gwt = 0;
            total_cwt = 0;
            total_vwt = 0;
            total_cbm = 0;

        }
        else
        {
            //Response.Write("<tr><td class=error align=center colspan=15>Record not found for booking</td><tr>");

        }
        dr.Close();
        cmd.Dispose();
        con.Close();
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string getMonthName(string date1)
    {
        string monthName = "";
        TextBox txt1 = new TextBox();
        TextBox txt2 = new TextBox();
        string[] date2 = date1.Split('/');
        string strY = date2[2];
        switch (Convert.ToInt32(date2[1]))
        {
            case 1:
                monthName = "Jan-" + strY;

                break;
            case 2:
                monthName = "Feb-" + strY;

                break;
            case 3:
                monthName = "Mar-" + strY;
                txt1.Text = "03/01/" + strY;
                txt2.Text = "03/31/" + strY;
                break;
            case 4:
                monthName = "Apr-" + strY;


                break;
            case 5:
                monthName = "May-" + strY;

                break;
            case 6:
                monthName = "June-" + strY;
                break;
            case 7:
                monthName = "July-" + strY;
                break;
            case 8:
                monthName = "Aug-" + strY;
                break;
            case 9:
                monthName = "Sep-" + strY;
                break;
            case 10:
                monthName = "Oct-" + strY;
                break;
            case 11:
                monthName = "Nov-" + strY;
                break;
            case 12:
                monthName = "Dec-" + strY;
                break;
        }
        return (date2[0] + monthName);
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
}
