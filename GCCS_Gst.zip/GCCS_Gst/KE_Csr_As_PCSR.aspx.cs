﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;


public partial class KE_Csr_As_PCSR : System.Web.UI.Page
{
    public string page_pop = "";
    string agentName = null;
    string tableAll = "", comName = null;
    string massage = null;
    string city_id = null;
    string tableCSr = "";
    string tableTdsMsg = "";
    string tableTdsExemptedMsg = "";
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        //////string DateWise = Session["Date"].ToString();
        string DateWise = "flight_date";
        string[] airline_name_city_text = Session["airline_name"].ToString().Split('-');
        string airline_name_city_value = Session["airline_value"].ToString();
        ///////////Start:********************Modify Ny Hemant Sharma on 23 July 2014 for Additon of CIN NO**************************/////////
        #region Fetching of Airline ID
        string AID = "";
        SqlConnection con1 = new SqlConnection(strCon);
        DataTable dt_AID = dw.GetAllFromQuery("SELECT  Airline_ID FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + airline_name_city_value + "");
        if (dt_AID.Rows.Count > 0)
        {
            AID = dt_AID.Rows[0]["Airline_ID"].ToString();
        }

        #endregion
        ///////////End:********************Modify Ny Hemant Sharma on 23 July 2014 for Additon of CIN NO**************************/////////
        if (airline_name_city_value == "150" || airline_name_city_value == "153" || airline_name_city_value == "163" || airline_name_city_value == "166")
        {
            DateWise = "awb_date";
        }
        string[] agent_selected_id = Session["Agent_List_value"].ToString().Split('~');
        string[] agent_selected_name = Session["Agent_list_Text"].ToString().Split('~');
        string from_date = Session["from_date"].ToString().Trim();
        string to_date = Session["to_date"].ToString().Trim();
        string rdbtn = Session["rdbtn1"].ToString();
        string csrFooter = Session["csr_footer"].ToString();
        string comAdd = null;
        string airline = "A/C " + airline_name_city_text[0].ToUpper().ToString();
        string agnetID = "";
        string approveCsr = checkApprove(from_date, to_date);
        // CHECK FOR FINANCIAL YEAR
        string sCurrentDate = from_date.ToString();
        DateTime curDate = DateTime.Parse(sCurrentDate);
        string sFinYear = "";
        if (curDate.Month <= 3)
        {
            int startYr = curDate.Year - 1;
            sFinYear = "01/04/" + startYr.ToString() + "-" + DateTime.Parse(from_date).AddDays(-1).ToString("dd/MM/yyyy");
        }
        else
        {
            int endYr = curDate.Year + 1;
            sFinYear = "01/04/" + curDate.Year + "-" + DateTime.Parse(from_date).AddDays(-1).ToString("dd/MM/yyyy");
        }

        string FinancialYear = sFinYear;

        if (Session["groupid"].ToString() != "5")
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //if (agent_selected_id.i.Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotValuationCharges = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;
                string lastSurcharge = "0.0000", lastTsdsRate = "0.0000", lastedcess = "0.00";

                string table = null, table_image = null, table_note = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    ////////sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Flight_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";

                }
                else
                {
                    //////////sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (Csr_Date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (Csr_Date between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (airline_name_city_value.Trim() == "152")
                        {
                            if (h.Contains("11005"))
                            {
                                string[] h1 = h.Split('5');
                                h = h1[0].ToString() + "5";
                            }
                        }
                        comName = dr["company_name"].ToString();
                        table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";
                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        s = s.Replace("\r\n", "");
                        s = s.Replace(",", ", ");
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (AID == "160")
                        {
                            table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>CIN NO.U74899DL1993PTC052734</td></tr></table>";
                        }
                        /////// table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</td></tr></table>";

                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b></br><b><br><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************
                    }
                    com.Dispose();
                    dr.Dispose();
                    table += @"<table align=center style=""word-spacing:inherit"" width=""95%""
 border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th><th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th></tr><tr><th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr><tr><td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""1""></td>
</tr>";
                    //com = new SqlCommand("CSRsort", con);
                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        ////com = new SqlCommand("CSR_SORT_CHINA", con);
                        com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                        ////com = new SqlCommand("CSR_SORT_CHINA_Temp_TESTProc", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (from_date == "04/1/2008" && to_date == "04/15/2008")
                        {
                            //////com = new SqlCommand("CSRsort", con);

                            com = new SqlCommand("CSRsort_Temp_KE", con);

                            ////////com = new SqlCommand("CSRsort_Temp_KE_TESTPROC", con);
                        }
                        else
                        {
                            ////com = new SqlCommand("CSR_SORT_CHINA", con);
                            com = new SqlCommand("CSR_SORT_CHINA_Temp", con);

                            /////////com = new SqlCommand("CSR_SORT_CHINA_Temp_TESTProc", con);
                        }

                    }
                    else
                    {
                        //////com = new SqlCommand("CSRsort", con);

                        com = new SqlCommand("CSRsort_Temp_KE", con);

                        ////com = new SqlCommand("CSRsort_Temp_KE_TESTPROC", con);
                    }

                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    // com.Parameters.AddWithValue("DateWise", DateWise);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    ///////dt.Load(dr);
                    string VarDate = "07/31/2008";
                    string MH_Period = "08/15/2008";
                    int p = 0;

                    while (dr.Read())
                    {
                        p++;

                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString() == "235-70456945")
                        {
                        }
                        //lastTsdsRate = "0.0000";
                        //lastSurcharge = "0.0000";
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;

                            }
                            else
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                ////////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                //****************Added On 02 dec 2011***************
                                if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                                {
                                    DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                    if (dtMinCheck.Rows.Count > 0)
                                    {
                                        if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                        {
                                            TotDiscount += 0;
                                            TotComm += 0;
                                        }

                                        else
                                        {
                                            TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                            TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                }
                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                //**********************End Of 02 Dec*****************************
                                //////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            ////////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            //****************Added On 02 dec 2011***************
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                            {
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }
                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }

                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            }

                            //**********************End Of 02 Dec*****************************
                            //////////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotValuationCharges += Math.Round(decimal.Parse(dr["Valuation_Charge"].ToString()), MidpointRounding.AwayFromZero);
                        //TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                        ////decimal TotTdsss = Math.Round(decimal.Parse(dr["ONLY_TDS"].ToString()), MidpointRounding.AwayFromZero);
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }

                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }
                        else
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }



                        }
                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();

                        if (dr["Education_Cess"].ToString() != "0.0000")
                            lastedcess = dr["Education_Cess"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        if (rdbtn == "No")
                        {
                            remarks = "";
                        }
                        else
                        {
                            remarks = remarks;
                        }
                        decimal Comm_Amnt = 0;
                        decimal Agent_Ex = 0;

                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else
                        {
                            Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        }

                        //**************************Added On 02 Dec 2011**********************
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                        {
                            DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                            if (dtMinCheck.Rows.Count > 0)
                            {
                                if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                {
                                    discount = 0;
                                    Comm_Amnt = 0;
                                }
                            }
                        }
                        //**********************End on 02 Dec 2011***********************



                        table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Agent_Ex + @"</td><td align=""right"">" + Comm_Amnt + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                    }
                    //lastTsdsRate = "0";

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""1""></td></tr>";

                    //////Total =Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm)),MidpointRounding.AwayFromZero);


                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);

                    table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""1""> </td></tr><tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";


                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                    //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";


                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");

                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge For the Period  (" + FinancialYear + @") </strong></td><td colspan=""2"" align=""right""><strong>" + Debit_Surcharge + @"</strong></td></tr>";

                    }
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge));
                    }

                    if (airline_name_city_value == "168")
                    {
                        table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"">USD &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right""><img src=""images/rs.gif""> &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    }
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    //////////DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM CPP_AgentWiseTotal WHERE  CITYID='" + city_id + "' and agentid='" + agnetID + "' AND ExpiryDate>GETDATE() group by AGENTID  ORDER BY TotalCPP DESC");

                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCppPoints,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM dbo.CPP_Details WHERE CityID='" + city_id + "' and AgentID='" + agnetID + "' AND ExpiryDate>GETDATE() group by AgentID ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    //*****************Added on 11 Nov 2010
                    //string[] csrFooterBold = csrFooter.Split('<');
                    //string csrFootr = csrFooter[0].ToString();


                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("P.A.N."))
                        {
                            int i = csrFooter.IndexOf("Please&nbsp;intimate");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    //csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                        }
                        if (csrFtr != "")
                        {
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }
                        else
                        {
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }

                    }
                    else
                    {

                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("Service&nbsp;Tax"))
                        {
                            int i = csrFooter.IndexOf("Service&nbsp;Tax");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                            //csrFtr = csrFtr.Replace(",.", ".");
                        }
                        //////if (csrFtr != "")
                        //////{
                        //////    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" >TERMS AND CONDITIONS<br/>Please make payment in fav our of ""ASCENT AIR PRIVATE LIMITED"" , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Raw at-0124-6154064, Mr. Basant-0124-6154065.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11>THE ABOVE SALES REPORT IS BASED ON COMMERCIAL TERMS AS MUTUALLY AGREED BY YOU WITH ASCENT AIR PRIVATE LIMITED. PLEASE NOTE THAT THESE COMMERCIAL TERMS ARE TO BE KEPT CONFIDENTIAL AND THAT NEITHER YOU NOR ASCENT AIR PRIVATE LIMITED SHALL DISCLOSE THESE COMMERCIAL TERMS TO ANY OTHER PERSON/ENTITY EXCEPT FOR STATUTORY AUDIT AND REGULATORY PURPOSE</td></tr><td colspan=11><hr></td></tr></table>";
                        //////}
                        //////else
                        //////{
                        //////    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                        //////}

                        if (airline_name_city_value == "147" || airline_name_city_value == "148" || airline_name_city_value == "158" || airline_name_city_value == "159" || airline_name_city_value == "160" || airline_name_city_value == "163" || airline_name_city_value == "157" || airline_name_city_value == "161" || airline_name_city_value == "165" || airline_name_city_value == "151" || airline_name_city_value == "166" || airline_name_city_value == "167")
                        {
                            //////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with <b>\"ACUMEN OVERSEAS PVT LTD\"</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\"ACUMEN OVERSEAS PVT LTD\"</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>"; 

                            //New with running font case 1//

                            //////////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>";

                            //End Csr case1////////////////


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with <b>\""ACUMEN OVERSEAS PVT LTD\""</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\""ACUMEN OVERSEAS PVT LTD\""</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>\"ACUMEN OVERSEAS PVT LTD\"</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><td colspan=11><hr></td></tr></table>"; 


                            //New Csr case 2//

                            //////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>"; 

                            //End of csr case 2//

                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with <b>\"ACUMEN OVERSEAS PVT LTD\"</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\"ACUMEN OVERSEAS PVT LTD\"</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>"; 

                            //New Format Csr Case 3//
                            //    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Please ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Basant Kumar -8376800339, Mr.B S Rawat- 8376800738..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>"; 

                            //end of Csr Case 3//

                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Acumen Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.  Please deduct the TDS @1.50% U/S 194C as per exemption certificate no. 197/AADCA8499B/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 30/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ACUMEN OVERSEAS PVT LTD</b>"", Pan No. AADCA8499B, Tan No. DELA06791B, Service Tax No. AADCA8499BST004</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion

                        }
                        else
                        {


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>";


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11""  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with <b>""ASCENT AIR PRIVATE LIMITED""</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>""ASCENT AIR PRIVATE LIMITED""</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>\"ASCENT AIR PRIVATE LIMITED\"</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><td colspan=11><hr></td></tr></table>";




                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11""  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";





                            //  table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr.Basant Kumar -8376800339, Mr.B S Rawat- 8376800738.</td></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";

                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Ascent Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.Please deduct the TDS @1% U/S 194C as per exemption certificate no. 197/AACCA7284R/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 29/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with ascent air pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ASCENT AIR PVT LTD</b>""</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion
                        }
                    }
                    //Added on 11 Nov 2010
                    ////csrFooter = Session["csr_footer"].ToString();

                    if (p < 7)
                    {

                        ////////table_image = @"<table  align=""center"" ><tr><td><img src=""images/gcinitiative_treessave_1.JPG"" width=""700""></td></tr></table>";
                    }

                    if ((from_date == "07/1/2008" && to_date == "07/15/2008") || (from_date == "07/16/2008" && to_date == "07/31/2008"))
                    {
                        table_note = @"<table><tr class=""boldtext"" align=""left""><th><strong>Please Note :-</strong> We will not be sending CSR from next time onwards through courier.You can check the same in your account at <a class=""link"" href=""http://groupconcorde.com"" target=""blank"">http://www.groupconcorde.com</a>. For Queries/Login details please contact our sales team.</th></tr></table><br style=""page-break-before:always;"">";
                    }
                    else
                    {
                        table_note = @"<br style=""page-break-before:always;"">";
                    }
                    //***************Added on  12 Nov 2010
                    ////if (approveCsr == "approve")
                    ////{
                    ////    tableCSr = "<table width=100% border=1><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.<Blink></b></Font></td></tr></table>";
                    ////}
                    ////else
                    ////{
                    ////    tableCSr = "<table width=100% border=1><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Not Approved.<Blink></b></Font></td></tr></table>";
                    ////}


                    //**************************Added on 08 Dec 2016: Systems Generated Invoice:***************
                    if (approveCsr == "approve")
                    {
                        tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=1><tr  align=center><td width=70%><b> This is System Generated invoice, Signature and Stamp is not mandatory.</b></td></tr></table>";
                    }
                    else
                    {
                        tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Not Approved.</font><Blink></td></tr></table><table width=100% border=1><tr  align=center><td width=70%><b> This is System Generated invoice, Signature and Stamp is not mandatory.</b></td></tr></table>";
                    }
                    //***************************End of added on 08 Dec 2016**************************************************

                    //==========================================**************Msg Added on  26 april 2012 **********************======================//
                    if (airline_name_city_text[0].ToString() != "FEDEX AIR CARGO")
                    {
                        if ((airline_name_city_value == "148") || (airline_name_city_value == "147") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160") || (airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165"))
                        {
                            //////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 07px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECEIVED TDS EXEMPTION CERTIFICATE OF 1.5% EFFECTIVE 30.04.13 PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                        }
                        else
                        {
                            ///For Fedex Airline CSR Footer
                            // tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECEIVED TDS EXEMPTION CERTIFICATE OF 1% EFFECTIVE 19.04.12 PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                            //////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECIEVED TDS EXEMPTION CERTIFICATE FY 2014-15 @1% w.e.f 17th June'14. PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";

                        }
                    }
                    else
                    {

                        if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                        {
                            if (airline_name_city_value == "152")
                            {
                                // tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >:::::We have received TDS Exemption Certificate of @0.75% for FY 2013-14 effective from 11-06-2013 please collect the same and deduct accordingly.::: </marquee></td></tr></table>";
                                // tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECIEVED TDS EXEMPTION CERTIFICATE FY 2014-15 @1% w.e.f 17th June'14. PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                            }

                        }
                        else
                        {
                            tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 07px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::We have received TDS Exemption Certificate @0.50% for FY 2012-13 w.e.f from 10th May'12 and please collect the same.:::::</marquee></td></tr></table>";

                        }
                    }
                    //=====================================================end =========================
                    //*************Added On 26 Apr 2011***************Msg To Agent*********
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                    }
                    else
                    {
                        ////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 05px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment:::::</marquee></td></tr></table>";
                    }
                    DataTable dtAirlineDetail_IdAccumen = dw.GetAllFromQuery("select * from Airline_detail where company_id=106");
                    string AirLineDetailId_Accumen = "";
                    if (dtAirlineDetail_IdAccumen.Rows.Count > 0)
                    {
                        for (int j = 0; j < dtAirlineDetail_IdAccumen.Rows.Count; j++)
                        {
                            AirLineDetailId_Accumen += dtAirlineDetail_IdAccumen.Rows[j]["airline_detail_id"].ToString() + ",";
                        }
                        AirLineDetailId_Accumen = AirLineDetailId_Accumen.TrimEnd(',');
                        if (AirLineDetailId_Accumen.Contains(airline_name_city_value))
                        {
                            //     tableTdsExemptedMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><font size=1px><b>We have received TDS Exemption Certificate from IT Dept for the FY 2011-12 @ 1%. Please deduct the TDS accordingly.</b></font></td></tr></table>";
                        }
                    }
                }

                //tableAll = tableAll + (table + table_image + table_note); //Original code
                //Added on 12 Nov 2010
                //tableAll = tableAll + (table + table_image + table_note) + tableCSr;
                // Add By hn mishra on Dated 29 Nov 2010,

                //tableAll = tableAll + (table + table_image + "<br/>") + tableCSr;

                if (table != null)
                {
                    tableAll = tableAll + (table + table_image) + tableTdsMsg + tableTdsExemptedMsg + tableCSr + table_note;
                    //************End******************************************************
                    //////tableAll = tableAll + (table + table_image + "<br/>") + tableCSr + table_note; 


                    //*****************************Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                    ////tableAll += "<table align=center width=70%><tr><td colspan=2><b><font size=2px>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                    //*****************************End of Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                }

                Label1.Text = tableAll;
                //Added on 12 Nov 2010
                tableCSr = "";

                tableTdsMsg = "";
                tableTdsExemptedMsg = "";
                //}

            }

            string mass = @"<p><font color=""red"" size=""3"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;

        }
        else if (approveCsr == "notApprove")
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //if (agent_selected_id.i.Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotValuationCharges = 0;

                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;
                string lastSurcharge = "0.0000", lastTsdsRate = "0.0000", lastedcess = "0.00";

                string table = null, table_image = null, table_note = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                else
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (airline_name_city_value.Trim() == "152")
                        {
                            if (h.Contains("11005"))
                            {
                                string[] h1 = h.Split('5');
                                h = h1[0].ToString() + "5";
                            }
                        }
                        comName = dr["company_name"].ToString();

                        table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        s = s.Replace("\r\n", "");
                        s = s.Replace(",", ", ");
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        //////table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b></td></tr></table>";

                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b></br><b><br><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************
                        //table += @"<table align=center style=""word-spacing:inherit"" width=""95%""
                        //border=""0""><tr class=""boldtext""><th  colspan=""9""><strong>This is not final approved CSR. It may change if needed.</strong></th></tr></table><br>";
                    }
                    com.Dispose();
                    dr.Dispose();

                    table += @"<table align=center style=""word-spacing:inherit"" width=""95%""
 border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th><th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th></tr><tr><th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr><tr><td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""1""></td>
</tr>";

                    //com = new SqlCommand("CSRsort", con);

                    if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    {
                        ////com = new SqlCommand("CSR_SORT_CHINA", con);

                        com = new SqlCommand("CSR_SORT_CHINA_Temp", con);

                        //////////com = new SqlCommand("CSR_SORT_CHINA_Temp_TESTProc", con);
                    }
                    else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    {
                        if (from_date == "04/1/2008" && to_date == "04/15/2008")
                        {
                            //////com = new SqlCommand("CSRsort", con);
                            com = new SqlCommand("CSRsort_Temp_KE", con);
                            ///////////com = new SqlCommand("CSRsort_Temp_KE_TESTPROC", con);
                        }
                        else
                        {
                            ////com = new SqlCommand("CSR_SORT_CHINA", con);
                            com = new SqlCommand("CSR_SORT_CHINA_Temp", con);
                            ////com = new SqlCommand("CSR_SORT_CHINA_Temp_TESTProc", con);
                        }
                    }
                    else
                    {
                        //////com = new SqlCommand("CSRsort", con);
                        com = new SqlCommand("CSRsort_Temp_KE", con);
                        ////////////////com = new SqlCommand("CSRsort_Temp_KE_TESTPROC", con);
                    }
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    // com.Parameters.AddWithValue("DateWise", DateWise);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    //dt.Load(dr);
                    string VarDate = "07/31/2008";
                    string MH_Period = "08/15/2008";
                    int p = 0;
                    while (dr.Read())
                    {
                        p++;
                        //lastTsdsRate = "0.0000";
                        //lastSurcharge = "0.0000";
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                //////////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                //////////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                //****************Added On 02 dec 2011***************
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }
                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                                //**********************End Of 02 Dec*****************************
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            ////////////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            ////////////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            //****************Added On 02 dec 2011***************
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                            {
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }

                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }
                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            }
                            //**********************End Of 02 Dec*****************************

                            TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);

                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotValuationCharges += Math.Round(decimal.Parse(dr["Valuation_Charge"].ToString()), MidpointRounding.AwayFromZero);


                        //TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        //TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                        // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }
                        else
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;

                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                                {
                                    TotTds += 0;
                                    surCharge += 0;

                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }


                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();
                        if (dr["Education_Cess"].ToString() != "0.0000")
                            lastedcess = dr["Education_Cess"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        if (rdbtn == "No")
                        {
                            remarks = "";
                        }
                        else
                        {
                            remarks = remarks;
                        }

                        decimal Comm_Amnt = 0;
                        decimal Agent_Ex = 0;

                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(MH_Period))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else
                        {
                            Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        }



                        //**************************Added On 02 Dec 2011**********************
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                        {
                            DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                            if (dtMinCheck.Rows.Count > 0)
                            {
                                if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                {
                                    discount = 0;
                                    Comm_Amnt = 0;
                                }
                            }
                        }
                        //**********************End on 02 Dec 2011***********************




                        table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Agent_Ex + @"</td><td align=""right"">" + Comm_Amnt + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""1""></td></tr>";

                    Total = Math.Round(((TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""1""> </td></tr><tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";


                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";

                    //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";


                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");
                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge For the Period  (" + FinancialYear + @") </strong></td><td colspan=""2"" align=""right""><strong>" + Debit_Surcharge + @"</strong></td></tr>";

                    }


                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge));
                    }

                    if (airline_name_city_value == "168")
                    {
                        table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"">USD &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right""><img src=""images/rs.gif""> &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    }

                    //// table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right""><img src=""images/rs.gif""> &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    //////DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM CPP_AgentWiseTotal WHERE  CITYID='" + city_id + "' and agentid='" + agnetID + "' AND ExpiryDate>GETDATE() group by AGENTID  ORDER BY TotalCPP DESC");
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCppPoints,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM dbo.CPP_Details WHERE CityID='" + city_id + "' and AgentID='" + agnetID + "' AND ExpiryDate>GETDATE() group by AgentID ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    //*********************************Added On 11 Nov 2010*****************
                    csrFooter = Session["csr_footer"].ToString();
                    //string[] csrFooterBold = csrFooter.Split('<');
                    //string csrFootr = csrFooter[0].ToString();
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("P.A.N."))
                        {
                            int i = csrFooter.IndexOf("Please&nbsp;intimate");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    //csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                        }
                        if (csrFtr != "")
                        {
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }
                        else
                        {
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }

                    }
                    else
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("Service&nbsp;Tax"))
                        {
                            int i = csrFooter.IndexOf("Service&nbsp;Tax");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                            //csrFtr = csrFtr.Replace(",.", ".");
                        }
                        ////if (csrFtr != "")
                        ////{
                        ////    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b><font size=2>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeem CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                        ////}
                        ////else
                        ////{
                        ////    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeem CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                        ////}

                        if (airline_name_city_value == "147" || airline_name_city_value == "148" || airline_name_city_value == "158" || airline_name_city_value == "159" || airline_name_city_value == "160" || airline_name_city_value == "163" || airline_name_city_value == "157" || airline_name_city_value == "161" || airline_name_city_value == "165" || airline_name_city_value == "151" || airline_name_city_value == "166" || airline_name_city_value == "167")
                        {
                            //////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with <b>\"ACUMEN OVERSEAS PVT LTD\"</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\"ACUMEN OVERSEAS PVT LTD\"</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>"; 

                            //New with running font case 1//

                            //////////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>";

                            //End Csr case1////////////////


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with <b>\""ACUMEN OVERSEAS PVT LTD\""</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\""ACUMEN OVERSEAS PVT LTD\""</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>\"ACUMEN OVERSEAS PVT LTD\"</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><td colspan=11><hr></td></tr></table>"; 


                            //New Csr case 2//

                            //////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>"; 

                            //End of csr case 2//

                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with <b>\"ACUMEN OVERSEAS PVT LTD\"</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\"ACUMEN OVERSEAS PVT LTD\"</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>"; 

                            //New Format Csr Case 3//


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Please ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Basant Kumar -8376800339, Mr.B S Rawat- 8376800738.</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Acumen Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.  Please deduct the TDS @1.50% U/S 194C as per exemption certificate no. 197/AADCA8499B/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 30/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ACUMEN OVERSEAS PVT LTD</b>"", Pan No. AADCA8499B, Tan No. DELA06791B, Service Tax No. AADCA8499BST004</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion

                            //end of Csr Case 3//


                        }
                        else
                        {


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>";


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11""  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with <b>""ASCENT AIR PRIVATE LIMITED""</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>""ASCENT AIR PRIVATE LIMITED""</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>\"ASCENT AIR PRIVATE LIMITED\"</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><td colspan=11><hr></td></tr></table>";




                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11""  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";





                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr.Basant Kumar -8376800339,Mr.B S Rawat- 8376800738.</td></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";


                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Ascent Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.Please deduct the TDS @1% U/S 194C as per exemption certificate no. 197/AACCA7284R/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 29/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with ascent air pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ASCENT AIR PVT LTD</b>""</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion
                        }
                    }

                    //*****Aded on 11 Nov 2010***********

                    csrFooter = Session["csr_footer"].ToString();


                    //style="" text-decoration: blink; color: Red; font-size: large;"" 

                    table += @"<tr  align=""left"" class=""text""><td class=""Amit"" colspan=""11"" nowrap ><font  color=""red""><b><Blink>This is not final approved CSR. It may change if needed.</Blink></b></font><br> </FONT><br><br></td></tr></table>";
                    if (p < 7)
                    {

                        //////table_image = @"<table  align=""center"" ><tr><td><img src=""images/gcinitiative_treessave_1.JPG"" width=""700""></td></tr></table>";
                    }
                    if ((from_date == "07/1/2008" && to_date == "07/15/2008") || (from_date == "07/16/2008" && to_date == "07/31/2008"))
                    {
                        table_note = @"<table><tr class=""boldtext"" align=""left""><th><strong>Please Note :-</strong> We will not be sending CSR from next time onwards through courier.You can check the same in your account at <a class=""link"" href=""http://groupconcorde.com"" target=""blank"">http://www.groupconcorde.com</a>. For Queries/Login details please contact our sales team.</th></tr></table><br style=""page-break-before:always;"">";
                    }
                    else
                    {
                        table_note = @"<br style=""page-break-before:always;"">";
                    }

                    //==========================================**************Msg Added on  26 april 2012 **********************======================//
                    if (airline_name_city_text[0].ToString() != "FEDEX AIR CARGO")
                    {
                        if ((airline_name_city_value == "148") || (airline_name_city_value == "147") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160") || (airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165"))
                        {
                            ///// tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 07px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECEIVED TDS EXEMPTION CERTIFICATE OF 1.5% EFFECTIVE 30.04.13 PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                        }
                        else
                        {
                            // tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECEIVED TDS EXEMPTION CERTIFICATE OF 1% EFFECTIVE 19.04.12 PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                            /////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECIEVED TDS EXEMPTION CERTIFICATE FY 2014-15 @1% w.e.f 17th June'14. PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                        }
                    }
                    else
                    {
                        if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                        {
                            if (airline_name_city_value == "152")
                            {
                                // tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >:::::We have received TDS Exemption Certificate of @0.75% for FY 2013-14 effective from 11-06-2013 please collect the same and deduct accordingly.::: </marquee></td></tr></table>";
                                //tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECIEVED TDS EXEMPTION CERTIFICATE FY 2014-15 @1% w.e.f 17th June'14. PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                            }

                        }
                        else
                        {
                            tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=color: red colspan=3><b><marquee BEHAVIOR=ALTERNATE >::::::We have received TDS Exemption Certificate @0.50% for FY 2012-13 w.e.f from 10th May'12 and please collect the same.:::::</marquee></b></td></tr></table>";
                        }
                    }
                    //=====================================================end=========================

                    //*************Added On 26 Apr 2011***************Msg To Agent*********
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                    }
                    else
                    {
                        ////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 05px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment:::::</marquee></td></tr></table>";
                    }
                    //tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=color: red colspan=3><b><marquee BEHAVIOR=ALTERNATE >::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment:::::</marquee></b></td></tr></table>";
                }
                DataTable dtAirlineDetail_IdAccumen = dw.GetAllFromQuery("select * from Airline_detail where company_id=106");
                string AirLineDetailId_Accumen = "";
                if (dtAirlineDetail_IdAccumen.Rows.Count > 0)
                {
                    for (int j = 0; j < dtAirlineDetail_IdAccumen.Rows.Count; j++)
                    {
                        AirLineDetailId_Accumen += dtAirlineDetail_IdAccumen.Rows[j]["airline_detail_id"].ToString() + ",";
                    }
                    AirLineDetailId_Accumen = AirLineDetailId_Accumen.TrimEnd(',');
                    if (AirLineDetailId_Accumen.Contains(airline_name_city_value))
                    {
                        //  tableTdsExemptedMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 20px;color: red colspan=3><font size=1px><b>We have received TDS Exemption Certificate from IT Dept for the FY 2011-12 @ 1%. Please deduct the TDS accordingly.</b></font></td></tr></table>";
                    }
                }
                //**************************Added on 08 Dec 2016: Systems Generated Invoice:***************
                if (approveCsr == "approve")
                {
                    tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=1><tr  align=center><td width=70%><b> This is System Generated invoice, Signature and Stamp is not mandatory.</b></td></tr></table>";
                }
                else
                {
                    tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Not Approved.</font><Blink></td></tr></table><table width=100% border=1><tr  align=center><td width=70%><b> This is System Generated invoice, Signature and Stamp is not mandatory.</b></td></tr></table>";
                }
                //***************************End of added on 08 Dec 2016**************************************************
                if (table != null)
                    ////tableAll = tableAll + (table + table_image + table_note);
                    tableAll = tableAll + (table + table_image + tableTdsMsg + tableTdsExemptedMsg + tableCSr + table_note);
                //*****************************Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                ///// tableAll += "<table align=center width=70%><tr><td colspan=2><b><font size=2px>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                //*****************************End of Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****

                Label1.Text = tableAll;
                tableTdsMsg = "";
                tableTdsExemptedMsg = "";
                //}

            }

            string mass = @"<p><font color=""red"" size=""2"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;


        }
        else
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //if (agent_selected_id.i.Selected == true)
                //{
                decimal TotChAmount = 0;
                decimal TotDueCar = 0;
                decimal TotTax = 0;
                decimal TotValuationCharges = 0;
                decimal TotAgentExp = 0;
                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal TotTds = 0;
                decimal EduChrg = 0; decimal Total = 0;
                decimal surCharge = 0;
                decimal GrandTotal = 0;
                string lastSurcharge = "0.0000", lastTsdsRate = "0.0000", lastedcess = "0.00";

                string table = null, table_image = null, table_note = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }
                else
                {
                    sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (" + DateWise + " between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (" + DateWise + " between '" + from_date + "'  and  '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";
                }

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        if (airline_name_city_value.Trim() == "152")
                        {
                            if (h.Contains("11005"))
                            {
                                string[] h1 = h.Split('5');
                                h = h1[0].ToString() + "5";
                            }
                        }
                        comName = dr["company_name"].ToString();

                        table += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p style=""font-size:12px;"" align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""1"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""1"">Cargo Sales Report </font><br><font size=""1"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        s = s.Replace("\r\n", "");
                        s = s.Replace(",", ", ");
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        /////table += @"<table width=""100%"" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b></td></tr></table>";
                        //***************Updated on 22 May 2015: Showing AgentTds Exmption related Msg******************
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top style=""font-size:12px;""><b>" + agentName + @"</b><br>" + h + @"<b><br>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</b></br><b><br><font size=2px>Note: Please deduct TDS with exempted rate as per TDS Exemption Certificate provided to you.</font></b></tr></table>";
                        //***************End of Updation on 22 May 2015: Showing AgentTds Exmption related Msg******************
                    }
                    com.Dispose();
                    dr.Dispose();



                    table += @"<table width=""100%""border=""0"" cellpadding=""2"" cellspacing=""0""><tr class=""h5 boldtext""><th rowspan=""2"">Date</th><th rowspan=""2"">AWB No.</th><th rowspan=""2"">Dest</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" >Freight</th><th rowspan=""2"" >Due Carrier</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"" >Comm.</th><th rowspan=""2"" >Discount</th><th rowspan=""2"" >Remark</th></tr><tr><th class=""h1 boldtext"">PP</th >  <th  class=""h1 boldtext"">CC</th></tr><tr><td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%"" height=""2""></td>
</tr>";
                    //////com = new SqlCommand("CSRsort", con);

                    com = new SqlCommand("CSRsort_Temp_KE", con);


                    /////com = new SqlCommand("CSRsort_Temp_KE_TESTPROC", con);

                    //if (airline_name_city_text[0].ToString() == "CHINA AIRLINES")
                    //{
                    //    com = new SqlCommand("CSR_SORT_CHINA", con);
                    //}
                    //else if (airline_name_city_text[0].ToString() == "MALAYSIAN AIRLINES")
                    //{
                    //    if (from_date == "04/1/2008" && to_date == "04/15/2008")
                    //    {
                    //        com = new SqlCommand("CSRsort", con);

                    //    }
                    //    else
                    //    {
                    //        com = new SqlCommand("CSR_SORT_CHINA", con);
                    //    }

                    //}
                    //else
                    //{
                    //    com = new SqlCommand("CSRsort", con);
                    //}



                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    ////////////com.Parameters.AddWithValue("DateWise", DateWise);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    string VarDate = "07/31/2008";
                    string Mh_Period = "08/15/2008";

                    int p = 0;
                    while (dr.Read())
                    {
                        p++;
                        //lastTsdsRate = "0.0000";
                        //lastSurcharge = "0.0000";
                        decimal discount = 0;
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(Mh_Period))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                discount = 0;
                                TotDiscount += 0;
                                TotComm += 0;
                                TotAgentExp += 0;
                            }
                            else
                            {
                                discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                ////////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                ////////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                                //****************Added On 02 dec 2011***************

                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }

                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }

                                //**********************End Of 02 Dec*****************************
                                TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            discount = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            //////TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            //////TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                            //****************Added On 02 dec 2011***************
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                            {
                                DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                                if (dtMinCheck.Rows.Count > 0)
                                {
                                    if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                    {
                                        TotDiscount += 0;
                                        TotComm += 0;
                                    }

                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                            }

                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            }

                            //**********************End Of 02 Dec*****************************

                            TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        string ss = dr["Used_Date"].ToString();
                        TotChAmount += decimal.Parse(dr["Charged_Weight"].ToString());
                        TotDueCar += Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString()));
                        TotTax += Math.Round(decimal.Parse(dr["Tax"].ToString()));


                        TotValuationCharges += Math.Round(decimal.Parse(dr["Valuation_Charge"].ToString()), MidpointRounding.AwayFromZero);


                        //TotAgentExp += Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        //TotComm += Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);

                        // TotFrAmount += decimal.Parse(dr["Freight_Amount"].ToString());
                        decimal TotTdsss = Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                        if (decimal.Parse(dr["Freight_Amount"].ToString()) < 0)
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(Mh_Period))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }
                        else
                        {
                            if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(from_date) > DateTime.Parse(Mh_Period))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr["only_surcharge"].ToString()));

                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }


                        }


                        if (dr["tds"].ToString() != "0.0000")
                            lastTsdsRate = dr["tds"].ToString();

                        if (dr["surcharge"].ToString() != "0.0000")
                            lastSurcharge = dr["surcharge"].ToString();

                        if (dr["Education_Cess"].ToString() != "0.0000")
                            lastedcess = dr["Education_Cess"].ToString();

                        string amountPP = null;
                        string amountCC = null;
                        if (dr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC));

                        }
                        else
                        {
                            amountPP = dr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP));
                        }
                        string remarks = dr["tariff_rate"].ToString() + "--" + dr["spot_rate"].ToString() + "--" + dr["Commission"].ToString() + "--" + dr["Special_Commodity_Incentive"].ToString() + "--" + dr["TDS"].ToString() + "--" + dr["surcharge"].ToString();
                        if (rdbtn == "No")
                        {
                            remarks = "";
                        }
                        else
                        {
                            remarks = remarks;
                        }
                        decimal Comm_Amnt = 0;
                        decimal Agent_Ex = 0;

                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(VarDate))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (DateTime.Parse(from_date) > DateTime.Parse(Mh_Period))
                            {
                                Comm_Amnt = 0;
                                Agent_Ex = 0;
                            }
                            else
                            {
                                Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                            }
                        }
                        else
                        {
                            Comm_Amnt = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Ex = Math.Round(decimal.Parse(dr["TotalDueAgent_Collect"].ToString()));
                        }



                        //**************************Added On 02 Dec 2011**********************
                        if (dr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235")
                        {
                            DataTable dtMinCheck = dw.GetAllFromQuery("select  Agent_Min_Status,Principle_Min_Status, * from sales where airwaybill_no ='" + dr["AirwayBill_No"].ToString() + "'");
                            if (dtMinCheck.Rows.Count > 0)
                            {
                                if (dtMinCheck.Rows[0]["Agent_Min_Status"].ToString() == "13" && (airline_name_city_value != "150" && airline_name_city_value != "153"))
                                {
                                    discount = 0;
                                    Comm_Amnt = 0;
                                }
                            }
                        }
                        //**********************End on 02 Dec 2011***********************





                        table += @"<tr class=""boldtext""><td>" + dr["Used_Date"].ToString() + @"</td><td nowrap >" + dr["AirWayBill_No"].ToString() + @"</td><td nowrap>" + dr["Destination_Code"].ToString() + @"</td><td align=""right"">" + dr["Charged_Weight"].ToString() + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountPP)) + @"</td><td align=""right"">" + Math.Round(decimal.Parse(amountCC)) + @"</td><td align=""right"" >" + Math.Round(decimal.Parse(dr["Total_DueCarrier"].ToString())) + @"</td><td align=""right"">" + Agent_Ex + @"</td><td align=""right"">" + Comm_Amnt + @"</td><td align=""right"">" + (discount) + @"</td><td>" + remarks + dr["CSR_Remarks"].ToString() + @"</td></tr>";

                    }

                    com.Dispose();
                    dr.Dispose();

                    table += @"<tr> <td colspan=""11"" align=""center""><img src=""images/line2.gif""  width=""100%"" height=""2""></td></tr>";

                    Total = (TotFrAmount + TotDueCar + TotTax + TotValuationCharges) - (TotAgentExp + TotDiscount + TotComm);
                    table += @"<tr ><td colspan=""11"" class=""text""> </td> </tr>";
                    table += @"<tr class=""boldtext""><td colspan=""3"">&nbsp;</td><td align=""right"">" + TotChAmount + @" </td><td align=""right"">" + Math.Round(TotFrAmount) + @" </td><td align=""right"" >" + Math.Round(TotFrAmountCC) + @"</td><td align=""right"">" + Math.Round(TotDueCar) + @" </td><td align=""right"">" + Math.Round(TotAgentExp) + @"</td><td align=""right"">" + (TotComm) + @" </td><td align=""right"">" + Math.Round(TotDiscount, MidpointRounding.AwayFromZero) + @"</td><td>&nbsp;</td></tr>";
                    table += @"<tr class=""boldtext""> <td colspan=""11"" align=""center""><img src=""images/line2.gif"" width=""100%""  height=""1""> </td></tr><tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Total Freight</strong></td>	<td colspan=""2"" align=""right""><strong>" + Math.Round(TotFrAmount) + @"</strong></td></tr>";
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Due Carrier</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDueCar) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add Valuation Chrgs</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotValuationCharges) + @"</strong></td></tr>";
                    //table += @"<tr class=""boldtext"">	<td colspan=""09"" align=""right""><strong>Add TXC(PP)</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotTax) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Agent Expenses</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotAgentExp) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Discount</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotDiscount) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext"">	<td colspan=""9"" align=""right""><strong>Less Commission</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(TotComm) + @"</strong></td></tr>";

                    table += @"<tr class=""boldtext""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""6"">&nbsp;</td><th colspan=""3"" align=""right""><strong>Total</strong></td><th colspan=""2"" align=""right""><strong>" + Math.Round(Total) + @"</strong></th></tr>";

                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add TDS @" + lastTsdsRate + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Ceiling(TotTds) + @"</strong></td></tr>";
                    if (Math.Round(surCharge) != 0)
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge@" + Math.Round(decimal.Parse(lastSurcharge), 2) + @"% </strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(surCharge) + @"</strong></td></tr>";


                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");
                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);
                        table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add SurCharge For the Period  (" + FinancialYear + @") </strong></td><td colspan=""2"" align=""right""><strong>" + Debit_Surcharge + @"</strong></td></tr>";

                    }
                    table += @"<tr class=""boldtext""><td colspan=""9"" align=""right""><strong>Add EDUCATIONAL CESS</strong></td><td colspan=""2"" align=""right""><strong>" + Math.Round(EduChrg) + @"</strong></td></tr>";

                    table += @"<tr> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr>";
                    //table += @"<tr> <td colspan=""11"">&nbsp;</td> <td colspan=""2"" align=""right""></td></tr>";
                    string font = null;
                    GrandTotal = Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge;
                    if (Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)) < 0)
                    {
                        massage = "Total Payable To";
                        font = "<font color='red'>";

                        GrandTotal = Math.Abs(Math.Round((Total + Math.Ceiling(TotTds) + EduChrg + surCharge + Debit_Surcharge)));
                    }
                    else
                    {
                        massage = "Total Receivable From";
                        font = "<font class='text'>";
                        GrandTotal = Math.Round((Total + Math.Ceiling(TotTds) + surCharge + Debit_Surcharge));
                    }

                    if (airline_name_city_value == "168")
                    {
                        table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right"">USD &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    }
                    else
                    {
                        table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right""><img src=""images/rs.gif""> &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    }
                    //////table += @"<tr class=""boldtext""><th colspan=""9"" align=""right""><strong>" + massage + @" " + " " + agentName + @" </strong></td><th colspan=""2"" align=""right""><img src=""images/rs.gif""> &nbsp;" + font + GrandTotal + @"</font></td></tr>";
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    //////////////DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM CPP_AgentWiseTotal WHERE  CITYID='" + city_id + "' and agentid='" + agnetID + "' AND ExpiryDate>GETDATE() group by AGENTID  ORDER BY TotalCPP DESC");
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCppPoints,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM dbo.CPP_Details WHERE CityID='" + city_id + "' and AgentID='" + agnetID + "' AND ExpiryDate>GETDATE() group by AgentID ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    //************************Added On 11 Nov 2010****************

                    csrFooter = Session["csr_footer"].ToString();
                    //string[] csrFooterBold = csrFooter.Split('<');
                    //string csrFootr = csrFooter[0].ToString();
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("P.A.N."))
                        {
                            int i = csrFooter.IndexOf("Please&nbsp;intimate");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    //csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                        }
                        if (csrFtr != "")
                        {
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr align=""left"" class=""text""><td colspan=""11"" nowrap ><hr><font size=1><b><font size=1>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr align=""left"" class=""text""><td colspan=""11"" nowrap ><hr><font size=1><b><font size=1>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }
                        else
                        {
                            //////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1><b>" + csrFooter + @"</font><hr></td></tr><tr><td colspan=11><hr></td></tr></table>";
                        }

                    }
                    else
                    {
                        string footer = "";
                        string csrFtr = "";
                        if (csrFooter.Contains("Service&nbsp;Tax"))
                        {
                            int i = csrFooter.IndexOf("Service&nbsp;Tax");
                            footer = csrFooter.Substring(i, csrFooter.Length - i);
                            if (footer != "")
                            {
                                csrFtr = csrFooter.Replace(footer, "");
                                if (csrFtr != "")
                                {
                                    csrFooter = csrFooter.Replace(csrFtr, "");
                                    csrFtr = csrFtr.Replace("<br>", "");
                                }
                            }
                            //csrFtr = csrFtr.Replace(",.", ".");
                        }
                        ////if (csrFtr != "")
                        ////{
                        ////    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px""><hr><font size=1><b><font size=1>" + csrFtr + @"</font></b><br/>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeem CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                        ////}
                        ////else
                        ////{
                        ////    table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><hr><font size=1>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeem CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table>";
                        ////}

                        if (airline_name_city_value == "147" || airline_name_city_value == "148" || airline_name_city_value == "158" || airline_name_city_value == "159" || airline_name_city_value == "160" || airline_name_city_value == "163" || airline_name_city_value == "157" || airline_name_city_value == "161" || airline_name_city_value == "165" || airline_name_city_value == "151" || airline_name_city_value == "166" || airline_name_city_value == "167")
                        {
                            //////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with <b>\"ACUMEN OVERSEAS PVT LTD\"</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\"ACUMEN OVERSEAS PVT LTD\"</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>"; 

                            //New with running font case 1//

                            //////////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>";

                            //End Csr case1////////////////


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with <b>\""ACUMEN OVERSEAS PVT LTD\""</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\""ACUMEN OVERSEAS PVT LTD\""</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>\"ACUMEN OVERSEAS PVT LTD\"</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><td colspan=11><hr></td></tr></table>"; 


                            //New Csr case 2//

                            //////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>"; 

                            //End of csr case 2//

                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ACUMEN OVERSEAS PVT LTD""</b>  Service Tax Registration No : AADCA8499BST004,   PAN : AADCA8499B.Please deduct  the TDS @1.00% (excluding  S.C. + E. C.) U/S 194C as per exemption certificate no. 197/AADCA8499B/2011-12   dated 28/04/2011 issued by ACIT,TDS Circle 49(1), New Delhi valid from 27/04/2011 to 31/03/2012. (Pls ensure your company/firm name in the cert. before deducting at  lower rate). Please intimate your P.A.N. alongwith Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.  Note: Commission and due agent charges against the CC shpts would be shown in the next CSR provided no discrepancy found in CC shpts.For more details contact Mr.Lahwar Mahto-0124-6154077.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with <b>\"ACUMEN OVERSEAS PVT LTD\"</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>\"ACUMEN OVERSEAS PVT LTD\"</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>"; 

                            //New Format Csr Case 3//


                            #region CSR Footer Change By Hemant Sharma on 1 Nov 2014 For Acumen Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.  Please deduct the TDS @1.50% U/S 194C as per exemption certificate no. 197/AADCA8499B/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 30/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ACUMEN OVERSEAS PVT LTD</b>"", Pan No. AADCA8499B, Tan No. DELA06791B, Service Tax No. AADCA8499BST004</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion

                            //end of Csr Case 3//


                        }
                        else
                        {


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11"" width=""300px"" ><b>TERMS AND CONDITIONS</b><br/>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 style=font-size:9px>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><td colspan=11><hr></td></tr></table>";


                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11""  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with <b>""ASCENT AIR PRIVATE LIMITED""</b>. Please note that these commercial terms are to be kept confidential and that neither you nor <b>""ASCENT AIR PRIVATE LIMITED""</b> shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>\"ASCENT AIR PRIVATE LIMITED\"</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><td colspan=11><hr></td></tr></table>";




                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=""11""  style=font-size:9px ><b>TERMS AND CONDITIONS</b><br/>The above sales report is based on commercial terms as mutually agreed by you with ascent air private limited. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air private limited shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 width=300px>Please make payment in favour of <b>""ASCENT AIR PRIVATE LIMITED""</b> , Service Tax Registration No : AACCA7284RST003, PAN : AACCA7284R. Please intimate your P.A.N. along with Registered office Address in writing, on your letter head. This is required for issuing of TDS certificate.Commission and due agent charges against the CC shpts would be show n in the next CSR provided no discrepancy found in CC shpts. For more details contact Mr. B S Rawat-0124-6154064, Mr. Basant-0124-6154065.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";






                            #region CSR Footer Chanes By Hemant Sharma on 1 Nov 2014 For Ascent Airline
                            ////table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A.Please deduct the TDS @1% U/S 194C as per exemption certificate no. 197/AACCA7284R/2014-15 dated 30/04/2014 issued by ACIT,TDS Circle 49(1), New Delhi valid from 29/04/2014 to 31/03/2015. (Please ensure your company/firm name in the cert. before deducting at lower rate).For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with acumen overseas pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor acumen overseas pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr align=""left"" ><th colspan=""11"" nowrap >Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeemed CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left ><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><td colspan=11><hr></td></tr></table>";
                            table += @"<tr align=""left"" class=""text""> <td colspan=""9"">&nbsp;</td> <td colspan=""2"" align=""right""><img src=""images/line2.gif""></td></tr><tr  align=""left"" class=""text""><td colspan=11 width=300px style=font-size:9px><b>TERMS AND CONDITIONS</b><br/>PLEASE MAKE CSR PAYMENT ON DUE DATE AS PER IATA DEADLINE OTHERWISE INTEREST WILL BE CHARGED @ 24% P.A. For more details contact Mr. B S Rawat- 9582596293 , Mr.  Basant Kumar -8376800339..</td></tr><tr><td colspan=11 style=font-size:9px >The above sales report is based on commercial terms as mutually agreed by you with ascent air pvt ltd. Please note that these commercial terms are to be kept confidential and that neither you nor ascent air pvt ltd shall disclose these commercial terms to any other person/entity except for statutory audit and regulatory purpose.</td></tr><tr><td colspan=11 style=font-size:9px>Please make payment in favour of ""<b>ASCENT AIR PVT LTD</b>""</td></tr><tr><td colspan=11><hr></td></tr></table>";
                            #endregion
                        }
                    }
                    //*****Adde on 11 Nov 2010********
                    csrFooter = Session["csr_footer"].ToString();



                    if (p < 7)
                    {

                        ////table_image = @"<table  align=""center""><tr><td><img src=""images/gcinitiative_treessave_1.JPG"" width=""700""></td></tr></table>";
                    }
                    if ((from_date == "07/1/2008" && to_date == "07/15/2008") || (from_date == "07/16/2008" && to_date == "07/31/2008"))
                    {
                        table_note = @"<table><tr class=""boldtext"" align=""left""><th><strong>Please Note :-</strong> We will not be sending CSR from next time onwards through courier.You can check the same in your account at <a class=""link"" href=""http://groupconcorde.com"" target=""blank"">http://www.groupconcorde.com</a>. For Queries/Login details please contact our sales team.</th></tr></table><br style=""page-break-before:always;"">";
                    }
                    else
                    {
                        table_note = @"<br style=""page-break-before:always;"">";
                    }
                    //***************Added on  12 Nov 2010
                    tableCSr = "<table width=100% border=1><tr class=boldtext align=left><td width=70%><Font color=red><b><Blink>CSR Approved.<Blink></b></td></tr></table>";
                    //==========================================**************Msg Added on  26 april 2012 **********************======================//
                    if (airline_name_city_text[0].ToString() != "FEDEX AIR CARGO")
                    {
                        if ((airline_name_city_value == "148") || (airline_name_city_value == "147") || (airline_name_city_value == "158") || (airline_name_city_value == "159") || (airline_name_city_value == "160") || (airline_name_city_value == "151") || (airline_name_city_value == "157") || (airline_name_city_value == "161") || (airline_name_city_value == "165"))
                        {
                            //////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 07px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECEIVED TDS EXEMPTION CERTIFICATE OF 1.5% EFFECTIVE 30.04.13 PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                        }
                        else
                        {
                            //  tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECEIVED TDS EXEMPTION CERTIFICATE OF 1% EFFECTIVE 19.04.12 PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                            //////  tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECIEVED TDS EXEMPTION CERTIFICATE FY 2014-15 @1% w.e.f 17th June'14. PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                        }
                    }
                    else
                    {
                        //  tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::We have received TDS Exemption Certificate @0.50% for FY 2012-13 w.e.f from 10th May'12 and please collect the same.:::::</marquee></td></tr></table>";
                        /////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECIEVED TDS EXEMPTION CERTIFICATE FY 2014-15 @1% w.e.f 17th June'14. PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr></table>";
                    }
                    //=====================================================end =========================

                    //*************Added On 26 Apr 2011***************Msg To Agent*********
                    if (airline_name_city_text[0].ToString() == "FEDEX AIR CARGO")
                    {
                    }
                    else
                    {
                        ////tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 05px;color: red colspan=3><marquee BEHAVIOR=ALTERNATE >::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment:::::</marquee></td></tr></table>";
                    }
                    //  tableTdsMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=color: red colspan=3>::::::Your TDS Certificates are ready with us & Please bring our TDS Certificate along with IATA Payment.:::::</marquee></td></tr></table>";
                    DataTable dtAirlineDetail_IdAccumen = dw.GetAllFromQuery("select * from Airline_detail where company_id=106");
                    string AirLineDetailId_Accumen = "";
                    if (dtAirlineDetail_IdAccumen.Rows.Count > 0)
                    {
                        for (int j = 0; j < dtAirlineDetail_IdAccumen.Rows.Count; j++)
                        {
                            AirLineDetailId_Accumen += dtAirlineDetail_IdAccumen.Rows[j]["airline_detail_id"].ToString() + ",";
                        }
                        AirLineDetailId_Accumen = AirLineDetailId_Accumen.TrimEnd(',');
                        if (AirLineDetailId_Accumen.Contains(airline_name_city_value))
                        {
                            // tableTdsExemptedMsg += @"<table  border=""0"" width=""100%"" ><tr class=""heading"" ><td style=height: 10px;color: red colspan=3><font size=1px><b>We have received TDS Exemption Certificate from IT Dept for the FY 2011-12 @ 1%. Please deduct the TDS accordingly.</b></font></td></tr></table>";
                        }
                    }
                }
                //if (GrandTotal > 0)

                //tableAll = tableAll + (table + table_image + table_note);//Original Code
                //***************Added on  12 Nov 2010
                // tableAll = tableAll + (table + table_image + table_note) + tableCSr;

                //**************************Added on 08 Dec 2016: Systems Generated Invoice:***************
                if (approveCsr == "approve")
                {
                    tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Approved.</font><Blink></td></tr></table><table width=100% border=1><tr  align=center><td width=70%><b> This is System Generated invoice, Signature and Stamp is not mandatory.</b></td></tr></table>";
                }
                else
                {
                    tableCSr = "<table width=100% border=0><tr  align=left><td width=70%><Font color=red><b><Blink>CSR Not Approved.</font><Blink></td></tr></table><table width=100% border=1><tr  align=center><td width=70%><b> This is System Generated invoice, Signature and Stamp is not mandatory.</b></td></tr></table>";
                }
                //***************************End of added on 08 Dec 2016**************************************************
                if (table != null)
                    tableAll = tableAll + (table + table_image) + tableTdsMsg + tableTdsExemptedMsg + tableCSr;
                //************End******************************************************

                ////tableAll = tableAll + (table + table_image + "<br/>") + tableCSr;

                //*****************************Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****
                /////tableAll += "<table align=center width=70%><tr><td colspan=2><b><font size=2px>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                //*****************************End of Added on 08 Dec 2016: System Generated Invoice, stap not manadatory in last of CSR*****

                Label1.Text = tableAll;
                //***************Added on  12 Nov 2010
                tableCSr = "";
                tableTdsMsg = "";
                tableTdsExemptedMsg = "";
                //}

            }

            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;
        }

    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat1(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }
    protected string checkApprove(string dt1, string dt2)
    {
        string s = null;
        con = new SqlConnection(strCon);
        con.Open();
        //////com = new SqlCommand("select * from Approved_CSR a inner join CSR_Duration b on a.CSR_Duration_ID=b.CSR_Duration_ID where CSR_Duration1='" + ConvertDateFormat1(dt1.Trim()) + "-" + ConvertDateFormat1(dt2.Trim()) + "'", con);

        com = new SqlCommand("select * from Approved_CSR a inner join CSR_Duration b on a.CSR_Duration_ID=b.CSR_Duration_ID where CSR_Duration1='" + ConvertDateFormat1(dt1.Trim()) + "-" + ConvertDateFormat1(dt2.Trim()) + "' and a.airline_detail_id=" + Session["AIRDetailID"].ToString() + "", con);
        dr = com.ExecuteReader();
        if (dr.Read())
            s = "approve";
        else
            s = "notApprove";

        return s;


    }
    protected void btnexcel_Click(object sender, EventArgs e)
    {

        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=CSR.xls");
        Response.ContentType = "application/InternationalCsr.ms-excel";
        StringWriter sw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(sw);
        Label1.RenderControl(htw);
        Response.Write(sw.ToString());
        Response.End();
    }

}
