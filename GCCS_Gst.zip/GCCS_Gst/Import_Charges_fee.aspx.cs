using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Import_Charges_fee : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    SqlDataReader rdr;
    DataTable dt;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack && Request.QueryString["Sno"] != null)
        {

            FillAirline();
            con = new SqlConnection(strCon);
            con.Open();

            string strquery = "SELECT icf.Sno,am.airline_name+'-'+C.city_name AS Airline,icf.mawbfee,icf.hawbfee,icf.office_address FROM Airline_Master AS am INNER JOIN Airline_Detail AS ad ON am.airline_id=ad.Airline_ID INNER JOIN City_Master AS C ON C.city_id=ad.Belongs_To_City INNER JOIN Import_Charges_fee icf ON icf.airline_detail_id=ad.Airline_Detail_ID WHERE Sno=" + Request.QueryString["Sno"].ToString() + "";
            com = new SqlCommand(strquery, con);
            rdr = com.ExecuteReader();
            rdr.Read();
            txtmawb.Text = rdr["mawbfee"].ToString();
            txthawb.Text = rdr["hawbfee"].ToString();
            txtAddress.Text = rdr["Office_address"].ToString();
            ddlAirlineName.Text = rdr["Airline"].ToString();
            rdr.Close();
            con.Close();
            btnsubmit.Visible = false;
            btnUpdate.Visible = true;
        }
        else if (!IsPostBack)
        {
            FillAirline();
        }
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if (ddlAirlineName.SelectedIndex <= 0)
        {
            lblerror.Visible = true;
            lblerror.Text = "Please Select Airline Name";
            ddlAirlineName.Focus();
        }
        else
        {
            string check_Query = "select * from Import_Charges_fee where Airline_detail_id='" + ddlAirlineName.SelectedValue + "'";
            con = new SqlConnection(strCon);
            con.Open();
            da = new SqlDataAdapter(check_Query, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblerror.Visible = true;
                lblerror.Text = " Airline already exists.";
            }
            else
            {

                string insert_Query = ("insert into Import_Charges_fee (Airline_detail_id,MawbFee,Hawbfee,Office_Address)values('" + ddlAirlineName.SelectedValue + "','" + txtmawb.Text + "','" + txthawb.Text + "','" + txtAddress.Text + "')");
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand(insert_Query, con);
                com.ExecuteNonQuery();
                con.Close();
                Response.Redirect("View_charges_fee.aspx");

            }
        }

    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        return Access;
    }
    public void FillAirline()
    {
        string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in(" + Airline_Access + ") order by Airline_Name", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        ddlAirlineName.DataSource = dr;
        ddlAirlineName.DataTextField = "Airline";
        ddlAirlineName.DataValueField = "Airline_Detail_ID";
        ddlAirlineName.DataBind();
        con.Close();
        com.Dispose();
        ddlAirlineName.Items.Insert(0, new ListItem("Select Airline", "-1"));
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_charges_fee.aspx");
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (ddlAirlineName.SelectedIndex <= 0)
        {
            lblerror.Visible = true;
            lblerror.Text = "Please Select Airline Name";
            ddlAirlineName.Focus();

        }
        else
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("UPDATE Import_Charges_fee SET Airline_detail_id =" + ddlAirlineName.SelectedValue + ",MawbFee ='" + txtmawb.Text + "',Hawbfee = '" + txthawb.Text + "',Office_Address = '" + txtAddress.Text + "' WHERE Sno=" + Request.QueryString["Sno"].ToString() + "", con);
            //com = new SqlCommand(strupdate, con);
            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("View_charges_fee.aspx");
        }
    }
}