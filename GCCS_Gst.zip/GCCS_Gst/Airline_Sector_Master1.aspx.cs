using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


/// <summary>
/// Designed by Alok Kumar Sharma Date:15-Oct-2007
/// Coded by Alok Date:22.10.2007
/// </summary>


public partial class Airline_Sector_Master : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Search();
        }
    }
    // function for bind grid
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txt_search.Text == "")
            {
                //selectQ = "select  sector_id,AM.Airline_Name as 'Airline_Name',AM.Airline_Code as 'Airline_Code',ASM.Sector_Name as 'Sector_Name'  from  Airline_Master AM inner join  Airline_sector_Master ASM on AM.Airline_ID=ASM.Airline_ID";


                ///////////Start:**************Modify By Hemant Sharma on 21 July 2014*****************************/////////////////////////////
                selectQ = " SELECT asm.Sector_ID,AM.Airline_Name as 'Airline_Name',AM.Airline_Code as 'Airline_Code',ASM.Sector_Name as 'Sector_Name'   FROM dbo.Airline_Master am INNER JOIN dbo.Airline_Detail ad ON ad.Airline_ID = am.Airline_ID INNER JOIN db_owner.Airline_Sector_Master asm ON  asm.Airline_Detail_ID = ad.Airline_Detail_ID ";

                ///////////End:**************Modify By Hemant Sharma on 21 July 2014*****************************/////////////////////////////
            }

            else
            {
                //selectQ = " select sector_id,AM.Airline_Name as 'Airline_Name',AM.Airline_Code as 'Airline_Code',ASM.Sector_Name as 'Sector_Name'  from  Airline_Master AM inner join  Airline_sector_Master ASM on AM.Airline_ID=ASM.Airline_ID where AM.Airline_Name like '" + txt_search.Text + "%' order by AM.AirLine_Name";


                ///////////Start:**************Modify By Hemant Sharma on 21 July 2014*****************************/////////////////////////////
                selectQ = " SELECT asm.Sector_ID,AM.Airline_Name as 'Airline_Name',AM.Airline_Code as 'Airline_Code',ASM.Sector_Name as 'Sector_Name'   FROM dbo.Airline_Master am INNER JOIN dbo.Airline_Detail ad ON ad.Airline_ID = am.Airline_ID INNER JOIN db_owner.Airline_Sector_Master asm ON  asm.Airline_Detail_ID = ad.Airline_Detail_ID WHERE am.Airline_Name LIKE  '" + txt_search.Text + "%' ORDER BY am.Airline_Name";

                ///////////End:**************Modify By Hemant Sharma on 21 July 2014*****************************/////////////////////////////
            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdSector.DataSource = dt;
            grdSector.DataBind();
            con.Close();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

   protected void Modify(object sender, CommandEventArgs e)
    {
        Response.Redirect("Airline_Sector.aspx?Sector_ID=" + e.CommandName);
    }

 

    protected void lnkAddSector_Click(object sender, EventArgs e)
    {
        Response.Redirect("Airline_Sector.aspx"); // Redirect to Airline_Sector page 
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void grdSector_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdSector.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void Delete(object sender, GridViewDeleteEventArgs e)
    {
    //    string str = "";
    //    con = new SqlConnection(strCon);
    //    string SID = grdSector.DataKeys[e.RowIndex].Value.ToString();
    //    con.Open();
    //    str = "delete from Airline_Sector_Details where Sector_ID in(select Sector_ID from Airline_Sector_Master where Airline_Id='" + ddlAirlineName.SelectedItem.Value.Trim() + "' and Sector_Name='" + lblSector.Text.Trim() + "')";
    //        com = new SqlCommand(str, con);
    //        con.Open();
    //        com.ExecuteNonQuery();
    //        con.Close();
    //        bindasset();
     
    }
}
