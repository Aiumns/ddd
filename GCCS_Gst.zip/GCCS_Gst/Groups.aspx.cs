using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
/// <summary>
/// Created By Ajeet 04 Oct 2007
/// Updated By Ajeet 10 Oct 2007 This Is Due To Change In Concept To Display Data
/// </summary>
public partial class Groups : System.Web.UI.Page
{
    SqlConnection con = null;//For Connection
    SqlCommand cmd = null;//For Giving Commands
    SqlDataAdapter adp=null;//For Holding Records
    DataSet ds=null;//For Getting Records

    string strQuery = null;//For SqlQuery String   

    string strConn = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;//Getting Connection String
    public void bindData()
    {
        using (con)
        {
            try
            {
                con = new SqlConnection(strConn);//Making Connection
                strQuery = "Select RTRIM(LTRIM(group_name))AS group_name,Group_ID, Mainmenu_Rights,User_Rights,Group_Type From Group_Master Where Group_Name <> 'sa' order by group_name";//Giving Sql Query
                cmd = new SqlCommand(strQuery, con);//Making Commands
                adp = new SqlDataAdapter(cmd);//Making Connection And Holding Data
                ds = new DataSet();//Creating DataSet
                adp.Fill(ds);//Getting Data
                gvGroupsName.DataSource = ds;//Binding GridView With Records
                gvGroupsName.DataBind();//Getting Value Displayed On GridView.
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
            }
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                bindData();
            }
        }
    }
    //Function For Handling Event Of Links In GridView
    protected void Test(object sender, CommandEventArgs e)
    {
        Response.Redirect("MenuRights.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("id", e.CommandName)));//Redirecting Page To MenyRights
    }
    public void Modi(object sender, CommandEventArgs e)
    {
        //ustring Group_ID;
       
        Response.Redirect("Update_Group.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("id", e.CommandArgument)));
    }
  
}
