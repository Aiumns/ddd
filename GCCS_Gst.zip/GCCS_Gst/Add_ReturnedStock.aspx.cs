using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
#region Created by Mukul Chandra
/// <summary>
/// <class>Add Returned Stock</class>
/// <description>
/// 
/// </description>
/// <dependency></dependency>
/// <createdBy>Mukul Chandra</createdBy>
/// <createdOn>28jan 08</createdOn>
/// <modifications>
/// 
/// <modification>
/// <changeDescription></changeDescription>
/// <modifiedBy></modifiedBy>
/// <modifiedOn></modifiedOn>
/// <modifiedby></modifiedby>
/// <modifiedOn></modifiedOn>
/// <changeDescription></changeDescription>
/// </modification>
/// </modifications> 
/// </summary> 
///
#endregion
public partial class Add_ReturnedStock : System.Web.UI.Page
{
    SqlConnection con;    
    SqlCommand cmd;    
    SqlDataReader rdr;
    string strquery;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
           btnissue.Attributes.Add("onclick", "return confi()");
           lblmess.Visible = false;
          
            if (!IsPostBack)
            {
                airlinecode();
                //fillagent();
                btnissue.Enabled = false;
                CheckBox1.Visible = false;
            }
        
        }

    }



    public void airlinecode()
    {
        using (con)
        {
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            try
            {
                strquery = " select Airline_Access from dbo.Login_Master where Email_ID='" + Session["EMailID"] + "'";//query for getting airline access from login master on the basis of email 
                cmd = new SqlCommand(strquery, con);// pass argument in command  
                rdr = cmd.ExecuteReader();
                rdr.Read();
                string airline_access = rdr["Airline_Access"].ToString();//getting value in string airline_access
                rdr.Close();
                //string[] split_ac = airline_access.Split(',');//getting value in string arrey with split 
                ddlAirlinecode.Items.Insert(0, "--Select--");// add --select--on 0 index
                ddlAirlinecode.Items[0].Value = "0";

                strquery = "select  am.Airline_Code,am.airline_name,cm.City_Code,cm.city_id,ad.Airline_Detail_ID from dbo.Airline_Master as am inner join airline_detail as ad on ad.airline_id=am.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City where ad.Airline_Detail_ID in (" + airline_access + ")  and am.status='2' order by am.airline_name asc";

                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ddlAirlinecode.Items.Add(new ListItem(rdr["airline_code"].ToString() + '-' + rdr["Airline_name"].ToString() + ',' + rdr["City_Code"].ToString(), rdr["city_id"].ToString() + "-" + rdr["Airline_Detail_ID"].ToString()));
                }
                rdr.Close();
                con.Close();
            }
            catch (SqlException ee)
            {
                Response.Write("sql error" + ee.Message);
            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

    }
    public void fillagent()
    {
        con = new SqlConnection(strCon);
        con.Open();
        
        string var_City = ddlAirlinecode.SelectedItem.Value;
        string[] arr_City=var_City.Split('-');
        string Belongs_To_City = arr_City[0];
        ddlAgent.Items.Clear();
        ddlAgent.Items.Insert(0, "--Select--");
        ddlAgent.Items[0].Value = "0";

        strquery = "select AM.agent_name, AM.Agent_ID from Agent_Master AM INNER JOIN Agent_Branch AB ON AB.Agent_ID=AM.Agent_ID INNER JOIN Login_Master LM ON AB.Agent_Branch_ID=LM.Agent_ID  WHERE Airline_Access LIKE '%" + arr_City[1] + "%' OR Airline_Access LIKE '" + arr_City[1] + "%' OR Airline_Access LIKE '%" + arr_City[1] + "' OR  Airline_Access LIKE '" + arr_City[1] + "' AND Belongs_To_City='" + Belongs_To_City + "' order by Agent_Name asc";


        //strquery = "select  distinct am.agent_name, am.Agent_ID from agent_master as am inner join stock_master as sm on sm.Agent_ID=am.Agent_ID where sm.status='16' and city_id='" + Belongs_To_City + "'  order by agent_name asc";
        cmd = new SqlCommand(strquery, con);
        rdr = cmd.ExecuteReader();

        while (rdr.Read())
        {
            ddlAgent.Items.Add(new ListItem(rdr["Agent_Name"].ToString(), rdr["Agent_ID"].ToString()));
        }
        con.Close();
        rdr.Close();
        cmd.Dispose();
    
    }

    public void Issueagent()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string var_City = ddlAirlinecode.SelectedItem.Value;
        string[] arr_City = var_City.Split('-');
        string Belongs_To_City = arr_City[0];
        string agent=ddlAgent.SelectedItem.Value;
        ddlissueToAgent.Items.Clear();
        ddlissueToAgent.Items.Insert(0, "--Select--");
        ddlissueToAgent.Items[0].Value = "0";

        strquery = "select  distinct AM.agent_name, AM.Agent_ID from Agent_Master AM INNER JOIN Agent_Branch AB ON AB.Agent_ID=AM.Agent_ID INNER JOIN Login_Master LM ON AB.Agent_Branch_ID=LM.Agent_ID  WHERE  am.Agent_ID not in(select Agent_ID from agent_master where Agent_ID='" + agent + "' ) AND (Airline_Access LIKE '%" + arr_City[1] + "%' OR Airline_Access LIKE '" + arr_City[1] + "%' OR Airline_Access LIKE '%" + arr_City[1] + "' OR  Airline_Access LIKE '" + arr_City[1] + "') AND Belongs_To_City='" + Belongs_To_City + "' order by Agent_Name asc";
        
        //strquery = "select  distinct am.agent_name, am.Agent_ID from agent_master as am INNER JOIN AGENT_BRANCH AB ON AM.AGENT_ID=AB.AGENT_ID where am.Agent_ID not in(select Agent_ID from agent_master where Agent_ID='" + agent + "' )AND Belongs_To_City='" + Belongs_To_City + "' order by agent_name asc";
        cmd = new SqlCommand(strquery, con);
        rdr = cmd.ExecuteReader();

        while (rdr.Read())
        {
            ddlissueToAgent.Items.Add(new ListItem(rdr["Agent_Name"].ToString(), rdr["Agent_ID"].ToString()));
        }
        con.Close();
        rdr.Close();
        cmd.Dispose();
    }


    protected void ddlagentindexchanged(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        string var_City = ddlAirlinecode.SelectedItem.Value;
        string[] arr_City = var_City.Split('-');
        string Belongs_To_City = arr_City[0];
        lstAWB.Items.Clear();
        strquery = "select airwaybill_no from stock_master where agent_id=" + ddlAgent.SelectedValue + " and airwaybill_no like " + "'" + ddlAirlinecode.SelectedItem.Text.Substring(0, 3) + "%'" + " and City_Id='" + Belongs_To_City + "' and status='16' ";
        cmd = new SqlCommand(strquery, con);
        rdr = cmd.ExecuteReader();
        if (rdr.HasRows == true)
        {
            while (rdr.Read())
            {
                lstAWB.Items.Add(rdr["airwaybill_no"].ToString());
               
            }
            lstAWB.Items[0].Selected = true;
            btnissue.Enabled = true;
            CheckBox1.Visible = true;
            lblerrlistbox.Visible = false;
            ChkIsuue.Visible = true;
            ChkIsuue.Checked = false;
            ddlissueToAgent.Visible = false;
            
           

            //for (int p = 0; p < lstAWB.Items.Count; p++)
            //{
            //    lstAWB.Items[p].Selected = true;
            //}
        }
        else
        {
            lblerrlistbox.Visible = true;
            btnissue.Enabled = false;

            lblerrlistbox.Text = "Airwaybill No not found";
            CheckBox1.Visible = false;
            ChkIsuue.Visible = false;
            ChkIsuue.Checked = false;
            ddlissueToAgent.Visible = false;
        }
        rdr.Close();
        con.Close();
        cmd.Dispose();

    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked == true)
        {
            for (int i=0;  i< lstAWB.Items.Count; i++)
            {
                lstAWB.Items[i].Selected = true;
            }
        }
        else
        {
            for ( int i=0; i< lstAWB.Items.Count; i++)
            {
                lstAWB.Items[i].Selected = false;
            }
            lstAWB.Items[0].Selected = true;
        
        }
    }
    protected void btnissue_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            if (ChkIsuue.Checked == true)
            {
                for (int j = 0; j < lstAWB.Items.Count; j++)
                {
                    if (lstAWB.Items[j].Selected == true)
                    {
                        strquery = "select sm.airwaybill_no,am.agent_name,cm.city_name,sm.Receipt_Date,sm.Receipt_LotNo,sm.Issue_Date,sm.Issue_LotNo,sm.Status,sm.Created_By,sm.Created_On from stock_master as sm inner join city_master as cm on cm.city_id=sm.city_id inner join agent_master as am on am.agent_id=sm.agent_id where sm.airwaybill_no=" + "'" + lstAWB.Items[j] + "'" + "";
                        cmd = new SqlCommand(strquery, con);
                        rdr = cmd.ExecuteReader();
                        rdr.Read();
                        string airwaybillno = rdr["airwaybill_no"].ToString();
                        string cityname = rdr["City_Name"].ToString();
                        string receipt_date = rdr["Receipt_Date"].ToString();
                        string receipt_lotno = rdr["Receipt_LotNo"].ToString();
                        string agentname = rdr["Agent_Name"].ToString();
                        string issuedate = rdr["Issue_Date"].ToString();
                        string issuelotno = rdr["Issue_LotNo"].ToString();
                        string status = rdr["Status"].ToString();
                        string createdby = rdr["Created_By"].ToString();
                        string createdon = rdr["Created_On"].ToString();
                        //rdr.Close();
                        cmd.Dispose();
                        rdr.Close();
                        strquery = "insert into stock_history(AirWayBill_No,City_Name,Receipt_Date,Receipt_LotNo,Agent_Name,Issue_Date,Issue_LotNo,Status,Created_By,Created_On,Stock_returned_by,Return_stock_date)values(@AirWayBill_No,@City_Name,@Receipt_Date,@Receipt_LotNo,@Agent_Name,@Issue_Date,@Issue_LotNo,@Status,@Created_By,@Created_On,@Stock_returned_by,@Return_stock_date)";
                        cmd = new SqlCommand(strquery, con);
                        cmd.Parameters.AddWithValue("@AirWayBill_No", airwaybillno);
                        cmd.Parameters.AddWithValue("@City_Name", cityname);
                        cmd.Parameters.AddWithValue("@Receipt_Date", receipt_date);
                        cmd.Parameters.AddWithValue("@Receipt_LotNo", receipt_lotno);
                        cmd.Parameters.AddWithValue("@Agent_Name", agentname);
                        cmd.Parameters.AddWithValue("@Issue_Date", issuedate);
                        cmd.Parameters.AddWithValue("@Issue_LotNo", issuelotno);
                        cmd.Parameters.AddWithValue("@Status", status);
                        cmd.Parameters.AddWithValue("@Created_By", createdby);
                        cmd.Parameters.AddWithValue("@Created_On", createdon);
                        cmd.Parameters.AddWithValue("@Stock_returned_by", Session["EMailID"]);
                        cmd.Parameters.AddWithValue("@Return_stock_date", DateTime.Now);
                        cmd.ExecuteNonQuery();
                        //rdr.Close();

                        string agent_id = ddlissueToAgent.SelectedItem.Value;
                        string issued_date = DateTime.Now.ToString("MM/dd/yyyy");
                        strquery = "update stock_master set status='16', agent_id='" + agent_id + "',issue_date='" + issued_date + "' where airwaybill_no=" + "'" + lstAWB.Items[j] + "'" + "";
                        cmd = new SqlCommand(strquery, con);
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();



                    }
                }
                lstAWB.Items.Clear();
                CheckAirlineAceess();
                con.Open();
                lblmess.Visible = true;
                lblmess.Text = "Issued Successfully";
                strquery = "select airwaybill_no from stock_master where agent_id=" + ddlAgent.SelectedValue + " and airwaybill_no like " + "'" + ddlAirlinecode.SelectedItem.Text.Substring(0, 3) + "%'" + " and status='16'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows == true)
                {
                    while (rdr.Read())
                    {
                        lstAWB.Items.Add(rdr["airwaybill_no"].ToString());

                    }
                    btnissue.Enabled = true;
                    CheckBox1.Visible = true;
                    lblerrlistbox.Visible = false;


                    //ClientScript.RegisterStartupScript(GetType(), "Message", "<script Language='javascript'> confirm('are you sure want to return stock');</script>");
                }
                else
                {
                    //lblmess.Visible = false;
                    lblerrlistbox.Text = "Airwaybill not found";
                    btnissue.Enabled = false;
                    CheckBox1.Visible = false;
                }

            }
            else
            {
                for (int j = 0; j < lstAWB.Items.Count; j++)
                {
                    if (lstAWB.Items[j].Selected == true)
                    {
                        strquery = "select sm.airwaybill_no,am.agent_name,cm.city_name,sm.Receipt_Date,sm.Receipt_LotNo,sm.Issue_Date,sm.Issue_LotNo,sm.Status,sm.Created_By,sm.Created_On from stock_master as sm inner join city_master as cm on cm.city_id=sm.city_id inner join agent_master as am on am.agent_id=sm.agent_id where sm.airwaybill_no=" + "'" + lstAWB.Items[j] + "'" + "";
                        cmd = new SqlCommand(strquery, con);
                        rdr = cmd.ExecuteReader();
                        rdr.Read();
                        string airwaybillno = rdr["airwaybill_no"].ToString();
                        string cityname = rdr["City_Name"].ToString();
                        string receipt_date = rdr["Receipt_Date"].ToString();
                        string receipt_lotno = rdr["Receipt_LotNo"].ToString();
                        string agentname = rdr["Agent_Name"].ToString();
                        string issuedate = rdr["Issue_Date"].ToString();
                        string issuelotno = rdr["Issue_LotNo"].ToString();
                        string status = rdr["Status"].ToString();
                        string createdby = rdr["Created_By"].ToString();
                        string createdon = rdr["Created_On"].ToString();
                        //rdr.Close();
                        cmd.Dispose();
                        rdr.Close();
                        strquery = "insert into stock_history(AirWayBill_No,City_Name,Receipt_Date,Receipt_LotNo,Agent_Name,Issue_Date,Issue_LotNo,Status,Created_By,Created_On,Stock_returned_by,Return_stock_date)values(@AirWayBill_No,@City_Name,@Receipt_Date,@Receipt_LotNo,@Agent_Name,@Issue_Date,@Issue_LotNo,@Status,@Created_By,@Created_On,@Stock_returned_by,@Return_stock_date)";
                        cmd = new SqlCommand(strquery, con);
                        cmd.Parameters.AddWithValue("@AirWayBill_No", airwaybillno);
                        cmd.Parameters.AddWithValue("@City_Name", cityname);
                        cmd.Parameters.AddWithValue("@Receipt_Date", receipt_date);
                        cmd.Parameters.AddWithValue("@Receipt_LotNo", receipt_lotno);
                        cmd.Parameters.AddWithValue("@Agent_Name", agentname);
                        cmd.Parameters.AddWithValue("@Issue_Date", issuedate);
                        cmd.Parameters.AddWithValue("@Issue_LotNo", issuelotno);
                        cmd.Parameters.AddWithValue("@Status", status);
                        cmd.Parameters.AddWithValue("@Created_By", createdby);
                        cmd.Parameters.AddWithValue("@Created_On", createdon);
                        cmd.Parameters.AddWithValue("@Stock_returned_by", Session["EMailID"]);
                        cmd.Parameters.AddWithValue("@Return_stock_date", DateTime.Now);
                        cmd.ExecuteNonQuery();
                        //rdr.Close();

                        //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'> return  confirm('are you sure want to returned stock');</script>");
                        strquery = "update stock_master set status='8', agent_id=null where airwaybill_no=" + "'" + lstAWB.Items[j] + "'" + "";
                        cmd = new SqlCommand(strquery, con);
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();


                        //lstAWB.Items.Clear();
                        //strquery = "select airwaybill_no from stock_master where agent_id=" + ddlAgent.SelectedValue + " and airwaybill_no like " + "'" + ddlAirlinecode.SelectedItem.Text.Substring(0, 3) + "%'" + " and status='16'";
                        //cmd = new SqlCommand(strquery, con);
                        //rdr = cmd.ExecuteReader();
                        //if (rdr.HasRows == true)
                        //{
                        //    while (rdr.Read())
                        //    {
                        //        lstAWB.Items.Add(rdr["airwaybill_no"].ToString());

                        //    }
                        //    btnissue.Enabled=true;
                        //    CheckBox1.Visible = true;
                        //    lblerrlistbox.Visible = false;

                        //    //ClientScript.RegisterStartupScript(GetType(), "Message", "<script Language='javascript'> confirm('are you sure want to return stock');</script>");
                        //}
                        //else
                        //{
                        //    lblerrlistbox.Text = "Airwaybill No not found";
                        //    btnissue.Enabled = false;
                        //    CheckBox1.Visible = false;
                        //}
                    }

                }
                lstAWB.Items.Clear();
                strquery = "select airwaybill_no from stock_master where agent_id=" + ddlAgent.SelectedValue + " and airwaybill_no like " + "'" + ddlAirlinecode.SelectedItem.Text.Substring(0, 3) + "%'" + " and status='16'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows == true)
                {
                    while (rdr.Read())
                    {
                        lstAWB.Items.Add(rdr["airwaybill_no"].ToString());

                    }
                    btnissue.Enabled = true;
                    CheckBox1.Visible = true;
                    lblerrlistbox.Visible = false;
                    lblmess.Text = "Stock Returned Successfully";


                    //ClientScript.RegisterStartupScript(GetType(), "Message", "<script Language='javascript'> confirm('are you sure want to return stock');</script>");
                }
                else
                {
                    lblmess.Text = "";

                    lblerrlistbox.Text = "Airwaybill not found";
                    btnissue.Enabled = false;
                    CheckBox1.Visible = false;
                }
            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally //try block added by hn mishra 
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }
    protected void ddlAgent_PreRender(object sender, EventArgs e)
    {

    }
    protected void ddlAirlinecode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAirlinecode.SelectedValue == "0")
        {
            ddlAgent.Items.Clear();
            lstAWB.Items.Clear();
            CheckBox1.Visible = false;
            btnissue.Enabled = false;
            ChkIsuue.Checked = false;
            ChkIsuue.Visible = false;
            ddlissueToAgent.Items.Clear();
            ddlissueToAgent.Visible = false;
        }
        else
        {

            lstAWB.Items.Clear();
            CheckBox1.Visible = false;
            btnissue.Enabled = false;
           
            ChkIsuue.Checked = false;
            ChkIsuue.Visible = false;
            ddlissueToAgent.Items.Clear();
            ddlissueToAgent.Visible = false;
            fillagent();
        }
       
        
    }
    protected void ChkIsuue_CheckedChanged(object sender, EventArgs e)
    {
        if (ChkIsuue.Checked == true)
        {
            ddlissueToAgent.Visible = true;
            Issueagent();

        }
        else
        {
            ddlissueToAgent.Visible = false;
        }
    }

    public bool CheckAirlineAceess()
    {
        string Airlineaccess = "";
        string Agentid = "";
        string updateairlineaccess = "";
        string[] strAirlineAccesss = null;
        bool airlinea = false;
        string var_City = ddlAirlinecode.SelectedItem.Value;
        string[] arr_City = var_City.Split('-');
        string cityid = arr_City[0];
        string Airline_Detail_ID = arr_City[1];
        using (con)
        {
            con = new SqlConnection(strCon);
            con.Open();
            try
            {

                strquery = "select  airline_access,agent_id from login_master where agent_id=(select agent_branch_id from agent_branch where agent_id='" + ddlissueToAgent.SelectedValue + "' and belongs_to_city='" + cityid + "')";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();

                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        Airlineaccess = rdr["airline_access"].ToString();
                        Agentid = rdr["agent_id"].ToString();

                        updateairlineaccess = Airlineaccess + "," + Airline_Detail_ID + ",";

                    }
                    rdr.Close();
                    //string removecomma = Airlineaccess.Substring(0, Airlineaccess.LastIndexOf(','));
                    if (Airlineaccess.Length > 1)
                    {
                        strAirlineAccesss = Airlineaccess.Split(',');

                        for (int z = 0; z < strAirlineAccesss.Length; z++)
                        {
                            if (strAirlineAccesss[z] == (Airline_Detail_ID))
                            {
                                airlinea = true;

                            }

                        }
                    }


                }
                rdr.Close();

                if (airlinea != true)
                {
                    airlinea = false;
                    strquery = "update login_master set airline_access='" + updateairlineaccess.Substring(0, updateairlineaccess.Length - 1) + "' where airline_access='" + Airlineaccess + "' and agent_id='" + Agentid + "'";
                    cmd = new SqlCommand(strquery, con);
                    cmd.ExecuteNonQuery();
                }

                //return airlinea;
            }

            catch (SqlException ss)
            {
                Response.Write("sql error" + ss.Message);
            }
            catch (Exception mm)
            {
                Response.Write("error occur" + mm.Message);
            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }
        return airlinea;

    }
}
