﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class AssignAirwaybill_ToSubAgent : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    string SubAgentTransID = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            tragent.Visible = false;
            trsubag.Visible = false;
            btnAssign.Visible = false;
            btnsearch.Attributes.Add("onclick", "return CheckaAirwaybill();");
        }

    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("GetAirwaybillDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAirwaybill.Text;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lblMessage.Visible = false;
            if (ds.Tables[0].Rows.Count > 0)
            {
                tragent.Visible = true;
                lblAgentName.Text = ds.Tables[0].Rows[0]["Agent_Name"].ToString();
                if (ds.Tables[1].Rows.Count > 0)
                {
                    if (ds.Tables[2].Rows.Count > 0)
                    {
                        SubAgentTransID = ds.Tables[2].Rows[0]["SubAgentTransID"].ToString();
                    }
                    trsubag.Visible = true;
                    btnAssign.Visible = true;
                    ddlSubAgent.Items.Clear();
                    ddlSubAgent.Items.Insert(0, "- -Select- -");
                    ddlSubAgent.Items[0].Value = "0";
                    for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                    {
                        ddlSubAgent.Items.Add(new ListItem(ds.Tables[1].Rows[i]["SubAgentName"].ToString(), ds.Tables[1].Rows[i]["SubAgentTransID"].ToString()));

                        if (ds.Tables[1].Rows[i]["SubAgentTransID"].ToString() == SubAgentTransID)
                        {
                            ddlSubAgent.Items[i + 1].Selected = true;
                        }
                    }
                }
                else
                {
                   btnAssign.Visible = false;
                    lblMessage.Visible = true;
                    lblMessage.Text = "No Subagent For This Agent";
                }
            }
            else
            {
                tragent.Visible = false;
                btnAssign.Visible = false;
                lblMessage.Visible = true;
                lblMessage.Text = "AirwayBill is Not Avialable for Assign";
            }
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnAssign_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dtsubagent = dw.GetAllFromQuery("SELECT ReferenceNo,SubAgentID FROM db_owner.SubAgent_Trans WHERE SubAgentTransID=" + ddlSubAgent.SelectedValue + "");
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("AssignSubAgent", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAirwaybill.Text;
            if (dtsubagent.Rows.Count > 0)
            {
                com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = Convert.ToInt32(dtsubagent.Rows[0]["SubAgentID"].ToString());
                com.Parameters.Add("@NOC_No", SqlDbType.VarChar).Value = dtsubagent.Rows[0]["ReferenceNo"].ToString();
            }
            else
            {
                com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = 0;
                com.Parameters.Add("@NOC_No", SqlDbType.VarChar).Value = DBNull.Value;
            }
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            com.Parameters.Add("@UpdatedON", SqlDbType.DateTime).Value = DateTime.Now;
            com.ExecuteNonQuery();
            con.Close();
            string strScript = "alert('Assigned Successfully.');";
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        }
        catch (SqlException ex)
        {
            return;
        }

        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
