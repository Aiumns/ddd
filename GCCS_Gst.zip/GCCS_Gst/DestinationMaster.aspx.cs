using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class DestinationMaster : System.Web.UI.Page
{   // this form has disign by praveen singh
    //SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString);
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    SqlDataReader red;
    SqlConnection con;
    SqlParameter pram;
    public int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            //btnsubmit.Visible = false;
            //btnupdate.Visible = false;
            if (!Page.IsPostBack && Request.QueryString["Destination_ID"] != null)
            {
                btnsubmit.Visible = false;
                btnupdate.Attributes.Add("onclick", "return CheckEmpty()");
                FillcountryCode();
                FillDIRFLTS();
                string qurstring = Request.QueryString["Destination_ID"].ToString();
                con = new SqlConnection(strCon);
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from Destination_Master where Destination_ID='" + qurstring + "'", con);
                SqlDataReader sdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                //btnupdate.Attributes.Add("onclick", "return CheckEmpty()");
                //btnupdate.Visible = true;
               
                while (sdr.Read())
                {
                    if (sdr.HasRows)
                    {
                       // txtdestionationcode.Enabled = false;

                        txtdestnation.Text = sdr["Destination_Name"].ToString();
                        txtdestionationcode.Text = sdr["Destination_Code"].ToString();
                        txtdestinationcode2.Text = sdr["Destination_Code2"].ToString();
                        string country_code = sdr["Country_Code"].ToString();
                        for (int p = 0; p <= (ddlCountryCode.Items.Count - 1); p++)
                        {
                            if (ddlCountryCode.Items[p].Value == country_code)
                            {
                                ddlCountryCode.Items[p].Selected = true;
                            }
                        }
                        string area_code = sdr["DIRFLTS"].ToString();
                        for (int p = 0; p <= (ddldirflts.Items.Count - 1); p++)
                        {
                            if (ddldirflts.Items[p].Value == area_code)
                            {
                                ddldirflts.Items[p].Selected = true;
                            }
                        }


                    }
                }

                // btnsubmit.Visible = false;
                lblAdd.Visible = false;
                //lblUpdate.Visible = true;


                //search(); 
                sdr.Close();
                cmd.Dispose();
                con.Close();
                //search();            
            }
            else if (!Page.IsPostBack)
            {

                //btnupdate.Visible = false;
                btnupdate.Visible = false;
                lblAdd.Visible = true;
                //lblUpdate.Visible = false;
                btnsubmit.Attributes.Add("onclick", "return CheckEmpty()");
                FillcountryCode();
                FillDIRFLTS();
            }
        }
    }
    protected void btncalcle_Click(object sender, EventArgs e)
    {
        Response.Redirect("Detail_destinationMster.aspx");
        //txtcountarycode.Text = "";
        //txtdestinationcode2.Text = "";
        //txtdestionationcode.Text = "";
        //txtdestnation.Text = "";
        //ddldirflts.SelectedIndex = 0;
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("InsertDestinationMaster", con);
        cmd.CommandType=CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Destination_Name", txtdestnation.Text);
    }
    private void FillDIRFLTS()
    {
        con = new SqlConnection(strCon);
        SqlCommand com = new SqlCommand("select distinct(DIRFLTS) from Destination_Master where DIRFLTS in ('Area 1','Area 2','Area 3') order by DIRFLTS", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        ddldirflts.Items.Add("--Select--");
        ddldirflts.Items[0].Value = "";
        while (dr.Read())
        {
            ddldirflts.Items.Add(new ListItem(dr["DIRFLTS"].ToString(), dr["DIRFLTS"].ToString()));
        }
        dr.Close();
        con.Close();
    }
    public void FillcountryCode() 
    {
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand("select distinct(Country_Code) from Destination_Master order by Country_Code",con);
       
        SqlDataReader dr2 =com.ExecuteReader();
        ddlCountryCode.Items.Add("--Select--");
        ddlCountryCode.Items[0].Value = "";
        while(dr2.Read())
        {
            ddlCountryCode.Items.Add(new ListItem(dr2["Country_Code"].ToString(), dr2["Country_Code"].ToString()));
        }
        dr2.Dispose();
        com.Dispose();
        con.Close();
    }
    protected void btnsubmit_Click1(object sender, EventArgs e)
    {
        btnupdate.Visible = false;
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("InsertDestinationMaster", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Destination_Name", txtdestnation.Text);
        cmd.Parameters.AddWithValue("@Destination_Code", txtdestionationcode.Text);
        if (txtdestinationcode2.Text != "")
        {
            //cmd.Parameters.AddWithValue("@Destination_Code2", SqlDbType.VarChar).Value = DBNull.Value;
            cmd.Parameters.AddWithValue("@Destination_Code2",txtdestinationcode2.Text);
        }
        else
        {
        cmd.Parameters.AddWithValue("@Destination_Code2",txtdestinationcode2.Text);
        }
        cmd.Parameters.AddWithValue("@Country_Code",ddlCountryCode.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@DIRFLTS",ddldirflts.SelectedItem.Text);
        pram=cmd.Parameters.AddWithValue("ReturnValue",SqlDbType.Int);
        pram.Direction=ParameterDirection.ReturnValue;
        con.Open();
        cmd.ExecuteNonQuery();
        int i=(int)cmd.Parameters["ReturnValue"].Value;
        if(i != 0)
        {
            lblmsg.Visible=true;
        lblmsg.Text="Code 1 is already exist";
        con.Close();
        cmd.Dispose();
        }
        else
        {
            cmd.Dispose();
            con.Close();
           
            Response.Redirect("Detail_DestinationMster.aspx");
        }
        
    }
    //private void AddData()
    //{
    //    string Did = Request.QueryString["Destination_ID"].ToString();
    //    cmd = new SqlCommand("UpdateDestinationMaster", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@Destination_ID", SqlDbType.Int).Value = Convert.ToInt32(Did).ToString();
    //    cmd.Parameters.AddWithValue("@Destination_Name", txtdestnation.Text);
    //    cmd.Parameters.AddWithValue("@Destination_Code", txtdestionationcode.Text);
    //    if (txtdestinationcode2.Text != "")
    //    {
    //        cmd.Parameters.AddWithValue("@Destination_Code2", SqlDbType.VarChar).Value = DBNull.Value;
    //    }
    //    else
    //    {
    //        cmd.Parameters.AddWithValue("@Destination_Code2", txtdestinationcode2.Text);
    //    }
    //    cmd.Parameters.AddWithValue("@Country_Code", txtcountarycode.Text);
    //    cmd.Parameters.AddWithValue("@DIRFLTS", ddldirflts.SelectedItem.Text);
    //    con.Open();
    //    cmd.ExecuteNonQuery();
    //    con.Close();
    //    cmd.Dispose();
    //    Response.Redirect("Detail_DestinationMster.aspx");
    //}
    protected void btnupdate_Click(object sender, EventArgs e)
    {

        con = new SqlConnection(strCon);
        string Did = Request.QueryString["Destination_ID"].ToString();
        cmd = new SqlCommand("UpdateDestinationMaster", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Destination_ID",SqlDbType.Int).Value=Convert.ToInt32(Did).ToString();
        cmd.Parameters.AddWithValue("@Destination_Name", txtdestnation.Text);
        cmd.Parameters.AddWithValue("@Destination_Code", txtdestionationcode.Text);
        if (txtdestinationcode2.Text != "")
        {
            cmd.Parameters.AddWithValue("@Destination_Code2", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            cmd.Parameters.AddWithValue("@Destination_Code2", txtdestinationcode2.Text);
        }
        cmd.Parameters.AddWithValue("@Country_Code", ddlCountryCode.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@DIRFLTS", ddldirflts.SelectedItem.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();
     
        Response.Redirect("Detail_DestinationMster.aspx");
    }


    protected void btnupdate_Click1(object sender, EventArgs e)
    {
        
        con = new SqlConnection(strCon);
        string Did = Request.QueryString["Destination_ID"].ToString();
        cmd = new SqlCommand("UpdateDestinationMaster", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Destination_ID",SqlDbType.Int).Value=Convert.ToInt32(Did).ToString();
        cmd.Parameters.AddWithValue("@Destination_Name", txtdestnation.Text);
        cmd.Parameters.AddWithValue("@Destination_Code", txtdestionationcode.Text);
        if (txtdestinationcode2.Text != "")
        {
            cmd.Parameters.AddWithValue("@Destination_Code2", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            cmd.Parameters.AddWithValue("@Destination_Code2", txtdestinationcode2.Text);
        }
        cmd.Parameters.AddWithValue("@Country_Code", ddlCountryCode.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@DIRFLTS", ddldirflts.SelectedItem.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();
       
        Response.Redirect("Detail_DestinationMster.aspx");
    }
    
}
