﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Net;

public partial class AgentSalesPersonCompanyWiseDetails : System.Web.UI.Page
{
    string table = "", page_pop = "";
    string table2 = "";
    string Table_Csr_Payment = "";
    string Table_COLLECTION = "";
    string Table_Csr_Pending = "";
    ////string Table_Csr_Payment_Header = "";
    ////string Table_COLLECTION_Header = "";
    ////string Table_Csr_Pending_Header = "";
    ////string table_Header = "";
    string SubAgent = "";
    string Main_Table = "";
    string pageHead = "";
    string airlineId = null;
    string bID = null;
    decimal GtchrWt = 0;
    decimal GtamountPP = 0;
    decimal GtamountCC = 0;
    decimal GtDueCarr = 0;
    decimal GtagentExp = 0;
    decimal Gtcomm = 0;
    decimal Gtincentive = 0;
    decimal GtspotDiff = 0;
    decimal GtfrtDiff = 0;
    decimal MHGtincentive = 0;
    decimal MHGtspotDiff = 0;
    decimal MHGtfrtDiff = 0;
    decimal GtGrandTotal = 0;
    
    decimal GtxrayCh = 0;
    decimal GrandTotal = 0;
    decimal Csr_Pending_Total = 0;
    decimal Csr_Payment_Total = 0;
    decimal Csr_Collect_Total = 0;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    TextBox TextBox1 = new TextBox();
    TextBox TextBox2 = new TextBox();
    TextBox TextBox3 = new TextBox();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {

                //set Hidden field on IP Basis
                if (IPCheck())
                {
                    hdnCheckIP.Value = "Internal";
                }
                else
                {
                    hdnCheckIP.Value = "Outer";
                    //Generate OTP on first call to page
                    OTPPwd();
                }
                DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
                hdnDate.Value = first.ToString();
                Page.Form.Target = "_blank";
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");
                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 1;
                ddlMonth.Items[dt - 1].Selected = true;
                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();
                //int yy = System.DateTime.Now.Year;
                //int s = ddlyear.Items.IndexOf(ddlyear.Items.FindByValue(yy.ToString()));
                //ddlyear.Items[s].Selected = true;
                ////ShowAirline();
                ShowCompany();

            }

        }


    }

    

    protected void ShowCompany()
    {
        ddlCompany.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("SELECT Company_Name,Company_ID FROM db_owner.Company_Master WHERE Company_ID IN (106,108) ORDER BY Company_Name", con);
            dr = com.ExecuteReader();
            ddlCompany.Items.Add("Select Company name");
            ddlCompany.Items[0].Value = "";
            while (dr.Read())
            {
                ddlCompany.Items.Add(new ListItem(dr["Company_Name"].ToString(), dr["Company_ID"].ToString()));
            }
            dr.Dispose();
            com.Dispose();
            con.Close();
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    public string GetUserIp()
    {
        string VisitorsIPAddr = string.Empty;
        //Users IP Address.
        if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
        {
            //To get the IP address of the machine and not the proxy
            VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
        }
        else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
        {
            VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
        }
        return VisitorsIPAddr;



    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        #region IPCheck
        //string IP = GetUserIp();
        //if (IP != "")
        //{
        //    string[] ip_addrs = IP.Split('.');
        //    if (ip_addrs.Length == 4)
        //    {

        //        con = new SqlConnection(strCon);
        //        con.Open();
        //        string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on)VALUES( '" + IP + "','" + DateTime.Now + "')";
        //        com = new SqlCommand(cInsert, con);
        //        com.ExecuteNonQuery();
        //        con.Close();


        //        if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
        //        {
        //        }
        //        else
        //        {
        //            ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');</script>");
        //            return;
        //        }
        //    }
        //    else
        //    {
        //        ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');</script>");
        //        return;
        //    }
        //}
        //else
        //{
        //    ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');</script>");
        //    return;
        //}
        #endregion


        if (hdnCheckIP.Value == "Outer")
        {

            if (hdnOTP.Value == ViewState["currentOtp"].ToString())
            {

                MakeCsrDate();
                string AirlinDtailId = "";
                DataTable dtAirlineDetailId = dw.GetAllFromQuery("select a.Airline_Text_Code+'-'+b.City_Code as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C,db_owner.Company_Master D where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City AND A.Company_ID=D.Company_ID and c.status=2 and D.Company_ID=" + ddlCompany.SelectedValue + " order by Airline_Name ");
                if (dtAirlineDetailId.Rows.Count > 0)
                {
                    table += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
                    Table_Csr_Payment += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
                    Table_COLLECTION += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
                    Table_Csr_Pending += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";

                    table += @"<tr class=HeaderStyle2 align=left><td rowspan=2  width=""3%"">S.No</td><td nowrap rowspan=2  width=""25%"" >Agent</td><td nowrap rowspan=2 >Account head details</td><td nowrap colspan=" + dtAirlineDetailId.Rows.Count + ">Sales Person Details </td></tr><tr class=HeaderStyle2>";
                    Table_Csr_Payment += @"<tr class=HeaderStyle2><td nowrap colspan=" + (dtAirlineDetailId.Rows.Count + 1) + ">CSR PAYMENT</td></tr><tr class=HeaderStyle2>";
                    Table_COLLECTION += @"<tr  class=HeaderStyle2><td nowrap colspan=" + (dtAirlineDetailId.Rows.Count + 1) + ">COLLECTION </td></tr><tr class=HeaderStyle2>";
                    Table_Csr_Pending += @"<tr  class=HeaderStyle2><td nowrap colspan=" + (dtAirlineDetailId.Rows.Count + 1) + ">Pending </td></tr><tr class=HeaderStyle2>";

                    table2 += @"<tr class=HeaderStyle1 boldtext><td colspan=4></td>";

                    for (int b = 0; b < dtAirlineDetailId.Rows.Count; b++)
                    {
                        table += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                        Table_Csr_Payment += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                        Table_COLLECTION += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                        Table_Csr_Pending += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                        AirlinDtailId += dtAirlineDetailId.Rows[b]["Airline_Detail_ID"].ToString() + ",";
                    }

                    Table_Csr_Payment += @"<td nowrap>Total</td>";
                    Table_COLLECTION += @"<td nowrap>Total</td>";
                    Table_Csr_Pending += @"<td nowrap>Total</td>";
                    table += @"</tr>";
                    Table_Csr_Payment += @"</tr>";
                    Table_COLLECTION += @"</tr>";
                    Table_Csr_Pending += @"</tr>";
                    AirlinDtailId = AirlinDtailId.TrimEnd(',');
                    DataTable dtAgentName = dw.GetAllFromQuery("Select Distinct s.Agent_Id ,am.Agent_Name from db_owner.Sales s INNER JOIN dbo.Agent_Master am ON s.Agent_ID = am.Agent_ID  where s.airline_detail_id in (" + AirlinDtailId + ") and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') ORDER BY Agent_Name ");

                    int colspan = (2 * (dtAirlineDetailId.Rows.Count + 1)) * 4 + 3;
                    string sales_Person_Id = "";
                    if (dtAgentName.Rows.Count > 0)
                    {
                        SqlConnection con1 = new SqlConnection(strCon);
                        con1.Open();
                        SqlCommand com1 = new SqlCommand();
                        con = new SqlConnection(strCon);
                        con.Open();
                        for (int j = 0; j < dtAgentName.Rows.Count; j++)
                        {
                            table += @"<tr><td nowrap>" + (j + 1) + "</td><td nowrap>" + dtAgentName.Rows[j]["Agent_Name"].ToString() + "</td><td nowrap>&nbsp;</td>";
                            Table_Csr_Payment += @"<tr>";
                            Table_COLLECTION += @"<tr>";
                            Table_Csr_Pending += @"<tr>";

                            for (int n = 0; n < dtAirlineDetailId.Rows.Count; n++)
                            {
                                //table += @"<td colspan=8 align=center>" + dtAirlineDetailId.Rows[n]["Airline"].ToString() + "</td>";
                                string comAdd = null, comName = null;
                                string[] airlineName = dtAirlineDetailId.Rows[n]["Airline"].ToString().Split('-');
                                string airline = "A/C " + airlineName[0].ToUpper().ToString();
                                string ss = "";
                                decimal TabTotal = 0;
                                ////***** for party sales agent name ***/////

                                DataTable dtSubagent = dw.GetAllFromQuery("SELECT um.Full_Name FROM db_owner.AgentToSalesPerson_Cluster ac INNER JOIN dbo.User_Master um ON ac.Sales_Person_Id=um.UserID INNER JOIN db_owner.Cluster_tran ct ON ac.Cluster_Id=ct.Cluster_id WHERE ','+ct.Airline_Aopair+',' LIKE ('%," + dtAirlineDetailId.Rows[n]["Airline_Detail_ID"].ToString() + ",%') AND ac.Agent_Id=" + dtAgentName.Rows[j]["Agent_Id"].ToString() + "");

                                /////*********end for party sales agent name *****//////

                                if (dtSubagent.Rows.Count > 0)
                                {

                                    SubAgent = dtSubagent.Rows[0]["Full_Name"].ToString();
                                }
                                else
                                {
                                    SubAgent = "-";

                                }


                                try
                                {


                                    int sno = 1;

                                    decimal xrayCh = 0;
                                    decimal frAmount = 0;
                                    decimal DueCarr = 0;
                                    decimal agentExp = 0;
                                    decimal comm = 0;
                                    decimal incentive = 0;
                                    decimal mHincentive = 0;
                                    decimal spotDiff = 0;
                                    decimal mHspotDiff = 0;
                                    decimal frtDiff = 0;
                                    decimal mHfrtDiff = 0;
                                    decimal chrWt = 0;
                                    decimal amountPP = 0;
                                    decimal amountCC = 0;
                                    decimal TotFrAmountCC = 0;
                                    decimal TotFrAmount = 0;
                                    decimal TotTds = 0;
                                    decimal TotTax = 0, TotDiscount = 0;
                                    decimal EduChrg = 0; decimal Total = 0;
                                    decimal surCharge = 0;

                                    string csrno = "";
                                    decimal total_cc = 0;
                                    decimal total_tds_cut = 0;

                                    if (airlineName[0].ToString().Trim() == "CHINA AIRLINES")
                                    {
                                        com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                                    }
                                    else if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                                    {
                                        com1 = new SqlCommand("CSR_SORT_DECCAN", con1);
                                    }
                                    else if (airlineName[0].ToString() == "MALAYSIAN AIRLINES")
                                    {
                                        if (TextBox1.Text == "04/1/2008" && TextBox2.Text == "04/15/2008")
                                        {
                                            com1 = new SqlCommand("CSRsort", con1);
                                        }
                                        else
                                        {
                                            com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                                        }
                                    }
                                    else
                                    {
                                        com1 = new SqlCommand("CSRsort", con1);
                                    }

                                    com1.CommandType = CommandType.StoredProcedure;
                                    com1.Parameters.AddWithValue("agent_id", dtAgentName.Rows[j]["Agent_Id"].ToString());
                                    com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                                    com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                                    com1.Parameters.AddWithValue("Airline_Detail_ID", dtAirlineDetailId.Rows[n]["Airline_Detail_ID"].ToString());
                                    DataTable dt = new DataTable();
                                    SqlDataAdapter sda = new SqlDataAdapter(com1);

                                    sda.Fill(dt);
                                    DataTableReader dr1;
                                    dr1 = dt.CreateDataReader();

                                    string VarDate = "07/31/2008";
                                    string MH_Period = "08/15/2008";
                                    while (dr1.Read())
                                    {
                                        csrno = dr1["csr_sno"].ToString();
                                        if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                                        {
                                            total_tds_cut += Math.Round(decimal.Parse(dr1["Total_Due_PP_row"].ToString()), MidpointRounding.AwayFromZero);
                                            if (DateTime.Parse(TextBox1.Text) >= DateTime.Parse("08/01/2009"))
                                            {
                                                total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                                            }
                                            else
                                            {
                                                total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr1["TDS"].ToString().Trim()) / 100;
                                            }
                                        }
                                        if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                        {

                                            if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                            {
                                                TotDiscount += 0;
                                                comm += 0;
                                                agentExp += 0;

                                            }
                                            else
                                            {
                                                TotDiscount += 0;
                                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                            }
                                        }
                                        else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                        {
                                            if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                            {

                                                TotDiscount += 0;
                                                comm += 0;
                                                agentExp += 0;

                                            }
                                            else
                                            {
                                                TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                            }
                                        }
                                        else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360")
                                        {

                                            TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                            comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);

                                        }
                                        else
                                        {
                                            TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                            comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                        }
                                        if (dr1["Freight_type"].ToString() == "COLLECT")
                                        {
                                            amountPP += 0;
                                            amountCC += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                            TotFrAmountCC = Math.Round(amountCC, MidpointRounding.AwayFromZero);
                                        }
                                        else
                                        {
                                            amountPP += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                            amountCC += 0;
                                            TotFrAmount = Math.Round(amountPP, MidpointRounding.AwayFromZero);
                                        }
                                        if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() != "360")
                                        {

                                            TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                            chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                            xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                            frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                        }
                                        else
                                        {
                                            TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                            chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                            xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                            frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                        }


                                        // calculation for incentive
                                        if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                        {
                                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                incentive += 0;
                                            }
                                            else
                                            {
                                                incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                            }
                                        }
                                        else
                                        {
                                            incentive += 0;
                                        }
                                        //calculation for MH Incentive
                                        if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                        {
                                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                            }
                                            else
                                            {
                                                mHincentive += 0;
                                            }

                                        }
                                        else
                                        {
                                            mHincentive += 0;

                                        }

                                        // calculation for spot Diff.

                                        if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                        {
                                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            { spotDiff += 0; }
                                            else
                                            {
                                                //Freight_Diff_Amount
                                                //spotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())));
                                                spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            }
                                        }
                                        else
                                        {
                                            spotDiff += 0;
                                        }
                                        //cal for hm 
                                        if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                        {
                                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                // mHspotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())) / 100);
                                                mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            }
                                            else
                                            {
                                                mHspotDiff = 0;
                                            }
                                        }
                                        else
                                        {
                                            mHspotDiff += 0;
                                        }

                                        frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        // frtDiff += decimal.Parse(dr1["Discount"].ToString());
                                        mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                        if (decimal.Parse(dr1["Freight_Amount"].ToString()) < 0)
                                        {
                                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                                {
                                                    TotTds -= 0;
                                                    surCharge -= 0;
                                                    EduChrg -= 0;
                                                }
                                                else
                                                {
                                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                                }

                                            }
                                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                                {
                                                    TotTds -= 0;
                                                    surCharge -= 0;
                                                    EduChrg -= 0;
                                                }
                                                else
                                                {
                                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                                }

                                            }
                                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                            }
                                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                            {

                                                TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                            }
                                            else
                                            {
                                                TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                            }
                                        }
                                        else
                                        {
                                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                                {
                                                    TotTds += 0;
                                                    surCharge += 0;
                                                    EduChrg += 0;
                                                }
                                                else
                                                {
                                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));
                                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                                }
                                            }
                                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                                {
                                                    TotTds += 0;
                                                    surCharge += 0;
                                                    EduChrg += 0;
                                                }
                                                else
                                                {
                                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));

                                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                                }
                                            }
                                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                            {
                                                TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                            }
                                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                            {
                                                TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                            }
                                            else
                                            {
                                                TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                                surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));
                                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                            }
                                        }

                                        Total = (TotFrAmount + DueCarr + TotTax) - (agentExp + TotDiscount + comm);
                                        Decimal Debit_Surcharge = 0;
                                        DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID='" + dtAgentName.Rows[j]["Agent_Id"].ToString() + "' AND AIRLINE_DETAIL_ID=" + dtAirlineDetailId.Rows[n]["Airline_Detail_ID"].ToString() + " AND (CSR_PERIOD>='" + DateTime.Parse(TextBox1.Text) + "' AND CSR_PERIOD<='" + DateTime.Parse(TextBox2.Text) + "')");

                                        if (dt_Sur.Rows.Count > 0)
                                        {
                                            Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                            EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(dr1["Education_Cess"].ToString()) / 100)), MidpointRounding.AwayFromZero);
                                        }

                                        if (Math.Round((Total + TotTds + EduChrg + surCharge - total_tds_cut + total_cc), MidpointRounding.AwayFromZero) < 0)
                                        {
                                            GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                            decimal test = (Math.Round((Total + Math.Ceiling(TotTds) + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + Math.Round(surCharge, MidpointRounding.AwayFromZero)), MidpointRounding.AwayFromZero));
                                            //GrandTotal2 = GrandTotal2 + Math.Abs(GrandTotal);
                                            ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";
                                            TabTotal = Math.Abs(GrandTotal);
                                            // GtGrandTotal -= GrandTotal;
                                        }
                                        else
                                        {
                                            GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                            //GrandTotal1 = GrandTotal1 + Math.Abs(GrandTotal);
                                            ss = "<font color=black>" + Math.Abs(GrandTotal) + "";
                                            TabTotal = Math.Abs(GrandTotal);
                                            // GtGrandTotal += GrandTotal;
                                        }

                                    }
                                    Csr_Payment_Total += TabTotal;
                                    Csr_Pending_Total += TabTotal;
                                    Csr_Collect_Total += TabTotal;
                                    GtchrWt += chrWt;
                                    GtamountPP += amountPP;
                                    GtamountCC += amountCC;
                                    GtDueCarr += DueCarr;
                                    GtagentExp += agentExp;
                                    Gtcomm += comm;
                                    Gtincentive += incentive;
                                    GtspotDiff += spotDiff;
                                    GtfrtDiff += frtDiff;
                                    MHGtincentive += mHincentive;
                                    MHGtspotDiff += mHspotDiff;
                                    MHGtfrtDiff += mHfrtDiff;
                                    GtGrandTotal += GrandTotal;
                                    // GtGrandTotal = GtGrandTotal + GrandTotal;
                                    GtxrayCh += xrayCh;
                                    if (ss == "")
                                    {
                                        ss = "-";
                                    }
                                    if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                                    {
                                        Table_COLLECTION += @"<td nowrap align=right>" + ss + "</td>";
                                        Table_Csr_Pending += @"<td nowrap align=right>-</td>";
                                        Table_Csr_Payment += @"<td nowrap align=right>" + ss + "</td>";
                                        table += @"<td nowrap> " + SubAgent + "</td>";
                                        sno = sno + 1;
                                    }
                                    else
                                    {
                                        //table += @"<td >" + ss == "" ? "-" : ss + "</td>";
                                        Table_Csr_Payment += @"<td nowrap align=right>" + ss + "</td>";
                                        Table_COLLECTION += @"<td nowrap align=right>-</td>";
                                        Table_Csr_Pending += @"<td nowrap align=right>" + ss + "</td>";
                                        table += @"<td nowrap>" + SubAgent + "</td>";

                                        sno = sno + 1;
                                    }

                                    ////end of main loop of calculation 
                                    //}


                                    con1.Close();
                                    // }
                                    //GtGrandTotal = (GrandTotal1 - GrandTotal2);
                                    //////////if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                                    //////////{
                                    //////////    table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td><td>" + MHGtincentive + @"</td><td>" + MHGtspotDiff + @"</td><td>" + MHGtfrtDiff + @"</td></tr></table>";
                                    //////////}
                                    //////////else
                                    //////////{
                                    //////////    table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";

                                    //////////}


                                    Session["dt"] = pageHead + table;
                                    if (pageHead == "")
                                    {
                                        pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                                        Session["dt"] = pageHead;
                                    }

                                }

                                catch (SqlException ex)
                                {
                                    string strer = ex.ToString();
                                }
                                finally
                                {
                                    if (con != null && con.State == ConnectionState.Open)
                                        con.Close();
                                }
                            }
                            table += @"</tr>";
                            Table_COLLECTION += @"<td align=right>-</td></tr>";
                            Table_Csr_Pending += @"<td align=right>" + Csr_Pending_Total.ToString("0.00") + "</td></tr>";
                            Table_Csr_Payment += @"<td align=right>" + Csr_Payment_Total.ToString("0.00") + "</td></tr>";
                            Csr_Collect_Total = 0;
                            Csr_Payment_Total = 0;
                            Csr_Pending_Total = 0;
                        }
                        ////end for agent loop
                    }
                    table += @"</table>";
                    Table_COLLECTION += @"</table>";
                    Table_Csr_Pending += @"</table>";
                    Table_Csr_Payment += @"</table>";
                    Main_Table = @"<table><tr><td><br/></td></tr><tr align=center><td><h2>Reports for " + ddlCompany.SelectedItem.Text + "</h2></td></tr><tr align=center><td><h3><u> " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + "</u></h3></td></tr><tr><td><br/></td></tr><tr><td></td></tr><tr><td>" + table + "</td><td>" + Table_Csr_Payment + "</td><td>" + Table_COLLECTION + "</td><td>" + Table_Csr_Pending + "</td></tr></table>";

                }
                else
                {
                    Main_Table = @"<table><tr><td><br/></td></tr><tr align=center><td><h2>Reports for " + ddlCompany.SelectedItem.Text + "</h2></td></tr><tr align=center><td><h3><u> " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + "</u></h3></td></tr><tr><td><br/></td></tr><tr><td></td></tr><tr><td><p><font color=red size=4>Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p></td></tr></table>";

                }

                //lbltest.Text = Main_Table.ToString();
                Session["CompanyWiseAgentDetails"] = Main_Table.ToString();
                // Response.Redirect("DisplayCompanywiseDeatails.aspx");
                ////////////lblReport.Text = Session["dt"].ToString();
                ////page_pop = "<SCRIPT language='javascript'>window.open('NewReportDrCr.aspx');</SCRIPT>";
                //////Response.Write(page_pop);
                ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('DisplayCompanywiseDeatails.aspx');</script>");

            }
            else
            {
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Invalid OTP, Please Check.');</script>");
            }
        }


        else
        {
        



        MakeCsrDate();
        string AirlinDtailId = "";
        DataTable dtAirlineDetailId = dw.GetAllFromQuery("select a.Airline_Text_Code+'-'+b.City_Code as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C,db_owner.Company_Master D where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City AND A.Company_ID=D.Company_ID and c.status=2 and D.Company_ID=" + ddlCompany.SelectedValue + " order by Airline_Name ");
        if (dtAirlineDetailId.Rows.Count > 0)
        {
            table += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
            Table_Csr_Payment += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
            Table_COLLECTION += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
            Table_Csr_Pending += @"<Table align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";

            table += @"<tr class=HeaderStyle2 align=left><td rowspan=2  width=""3%"">S.No</td><td nowrap rowspan=2  width=""25%"" >Agent</td><td nowrap rowspan=2 >Account head details</td><td nowrap colspan=" + dtAirlineDetailId.Rows.Count + ">Sales Person Details </td></tr><tr class=HeaderStyle2>";
            Table_Csr_Payment += @"<tr class=HeaderStyle2><td nowrap colspan=" + (dtAirlineDetailId.Rows.Count + 1) + ">CSR PAYMENT</td></tr><tr class=HeaderStyle2>";
            Table_COLLECTION += @"<tr  class=HeaderStyle2><td nowrap colspan=" + (dtAirlineDetailId.Rows.Count + 1) + ">COLLECTION </td></tr><tr class=HeaderStyle2>";
            Table_Csr_Pending += @"<tr  class=HeaderStyle2><td nowrap colspan=" + (dtAirlineDetailId.Rows.Count + 1) + ">Pending </td></tr><tr class=HeaderStyle2>";

            table2 += @"<tr class=HeaderStyle1 boldtext><td colspan=4></td>";

            for (int b = 0; b < dtAirlineDetailId.Rows.Count; b++)
            {
                table += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                Table_Csr_Payment += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                Table_COLLECTION += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                Table_Csr_Pending += @"<td nowrap>" + dtAirlineDetailId.Rows[b]["Airline"].ToString() + "</td>";
                AirlinDtailId += dtAirlineDetailId.Rows[b]["Airline_Detail_ID"].ToString() + ",";
            }

            Table_Csr_Payment += @"<td nowrap>Total</td>";
            Table_COLLECTION += @"<td nowrap>Total</td>";
            Table_Csr_Pending += @"<td nowrap>Total</td>";
            table += @"</tr>";
            Table_Csr_Payment += @"</tr>";
            Table_COLLECTION += @"</tr>";
            Table_Csr_Pending += @"</tr>";
            AirlinDtailId = AirlinDtailId.TrimEnd(',');
            DataTable dtAgentName = dw.GetAllFromQuery("Select Distinct s.Agent_Id ,am.Agent_Name from db_owner.Sales s INNER JOIN dbo.Agent_Master am ON s.Agent_ID = am.Agent_ID  where s.airline_detail_id in (" + AirlinDtailId + ") and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') ORDER BY Agent_Name ");

            int colspan = (2 * (dtAirlineDetailId.Rows.Count + 1)) * 4 + 3;
            string sales_Person_Id = "";
            if (dtAgentName.Rows.Count > 0)
            {
                SqlConnection con1 = new SqlConnection(strCon);
                con1.Open();
                SqlCommand com1 = new SqlCommand();
                con = new SqlConnection(strCon);
                con.Open();
                for (int j = 0; j < dtAgentName.Rows.Count; j++)
                {
                    table += @"<tr><td nowrap>" + (j + 1) + "</td><td nowrap>" + dtAgentName.Rows[j]["Agent_Name"].ToString() + "</td><td nowrap>&nbsp;</td>";
                    Table_Csr_Payment += @"<tr>";
                    Table_COLLECTION += @"<tr>";
                    Table_Csr_Pending += @"<tr>";

                    for (int n = 0; n < dtAirlineDetailId.Rows.Count; n++)
                    {
                        //table += @"<td colspan=8 align=center>" + dtAirlineDetailId.Rows[n]["Airline"].ToString() + "</td>";
                        string comAdd = null, comName = null;
                        string[] airlineName = dtAirlineDetailId.Rows[n]["Airline"].ToString().Split('-');
                        string airline = "A/C " + airlineName[0].ToUpper().ToString();
                        string ss = "";
                        decimal TabTotal = 0;
                        ////***** for party sales agent name ***/////

                        DataTable dtSubagent = dw.GetAllFromQuery("SELECT um.Full_Name FROM db_owner.AgentToSalesPerson_Cluster ac INNER JOIN dbo.User_Master um ON ac.Sales_Person_Id=um.UserID INNER JOIN db_owner.Cluster_tran ct ON ac.Cluster_Id=ct.Cluster_id WHERE ','+ct.Airline_Aopair+',' LIKE ('%," + dtAirlineDetailId.Rows[n]["Airline_Detail_ID"].ToString() + ",%') AND ac.Agent_Id=" + dtAgentName.Rows[j]["Agent_Id"].ToString() + "");

                        /////*********end for party sales agent name *****//////

                        if (dtSubagent.Rows.Count > 0)
                        {

                            SubAgent = dtSubagent.Rows[0]["Full_Name"].ToString();
                        }
                        else
                        {
                            SubAgent = "-";

                        }


                        try
                        {


                            int sno = 1;

                            decimal xrayCh = 0;
                            decimal frAmount = 0;
                            decimal DueCarr = 0;
                            decimal agentExp = 0;
                            decimal comm = 0;
                            decimal incentive = 0;
                            decimal mHincentive = 0;
                            decimal spotDiff = 0;
                            decimal mHspotDiff = 0;
                            decimal frtDiff = 0;
                            decimal mHfrtDiff = 0;
                            decimal chrWt = 0;
                            decimal amountPP = 0;
                            decimal amountCC = 0;
                            decimal TotFrAmountCC = 0;
                            decimal TotFrAmount = 0;
                            decimal TotTds = 0;
                            decimal TotTax = 0, TotDiscount = 0;
                            decimal EduChrg = 0; decimal Total = 0;
                            decimal surCharge = 0;

                            string csrno = "";
                            decimal total_cc = 0;
                            decimal total_tds_cut = 0;

                            if (airlineName[0].ToString().Trim() == "CHINA AIRLINES")
                            {
                                com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                            }
                            else if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                            {
                                com1 = new SqlCommand("CSR_SORT_DECCAN", con1);
                            }
                            else if (airlineName[0].ToString() == "MALAYSIAN AIRLINES")
                            {
                                if (TextBox1.Text == "04/1/2008" && TextBox2.Text == "04/15/2008")
                                {
                                    com1 = new SqlCommand("CSRsort", con1);
                                }
                                else
                                {
                                    com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                                }
                            }
                            else
                            {
                                com1 = new SqlCommand("CSRsort", con1);
                            }

                            com1.CommandType = CommandType.StoredProcedure;
                            com1.Parameters.AddWithValue("agent_id", dtAgentName.Rows[j]["Agent_Id"].ToString());
                            com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                            com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                            com1.Parameters.AddWithValue("Airline_Detail_ID", dtAirlineDetailId.Rows[n]["Airline_Detail_ID"].ToString());
                            DataTable dt = new DataTable();
                            SqlDataAdapter sda = new SqlDataAdapter(com1);

                            sda.Fill(dt);
                            DataTableReader dr1;
                            dr1 = dt.CreateDataReader();

                            string VarDate = "07/31/2008";
                            string MH_Period = "08/15/2008";
                            while (dr1.Read())
                            {
                                csrno = dr1["csr_sno"].ToString();
                                if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                                {
                                    total_tds_cut += Math.Round(decimal.Parse(dr1["Total_Due_PP_row"].ToString()), MidpointRounding.AwayFromZero);
                                    if (DateTime.Parse(TextBox1.Text) >= DateTime.Parse("08/01/2009"))
                                    {
                                        total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                                    }
                                    else
                                    {
                                        total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr1["TDS"].ToString().Trim()) / 100;
                                    }
                                }
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                    {
                                        TotDiscount += 0;
                                        comm += 0;
                                        agentExp += 0;

                                    }
                                    else
                                    {
                                        TotDiscount += 0;
                                        comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                    {

                                        TotDiscount += 0;
                                        comm += 0;
                                        agentExp += 0;

                                    }
                                    else
                                    {
                                        TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                        comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360")
                                {

                                    TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                if (dr1["Freight_type"].ToString() == "COLLECT")
                                {
                                    amountPP += 0;
                                    amountCC += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                    TotFrAmountCC = Math.Round(amountCC, MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    amountPP += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                    amountCC += 0;
                                    TotFrAmount = Math.Round(amountPP, MidpointRounding.AwayFromZero);
                                }
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() != "360")
                                {

                                    TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                    chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                    xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                    frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                    chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                    xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                    frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                }


                                // calculation for incentive
                                if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        incentive += 0;
                                    }
                                    else
                                    {
                                        incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    incentive += 0;
                                }
                                //calculation for MH Incentive
                                if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        mHincentive += 0;
                                    }

                                }
                                else
                                {
                                    mHincentive += 0;

                                }

                                // calculation for spot Diff.

                                if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    { spotDiff += 0; }
                                    else
                                    {
                                        //Freight_Diff_Amount
                                        //spotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())));
                                        spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    spotDiff += 0;
                                }
                                //cal for hm 
                                if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        // mHspotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())) / 100);
                                        mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        mHspotDiff = 0;
                                    }
                                }
                                else
                                {
                                    mHspotDiff += 0;
                                }

                                frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                // frtDiff += decimal.Parse(dr1["Discount"].ToString());
                                mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                                if (decimal.Parse(dr1["Freight_Amount"].ToString()) < 0)
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                        {
                                            TotTds -= 0;
                                            surCharge -= 0;
                                            EduChrg -= 0;
                                        }
                                        else
                                        {
                                            TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                            surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                            EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        }

                                    }
                                    else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                        {
                                            TotTds -= 0;
                                            surCharge -= 0;
                                            EduChrg -= 0;
                                        }
                                        else
                                        {
                                            TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                            surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                            EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        }

                                    }
                                    else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                    }
                                    else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                    {

                                        TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                        {
                                            TotTds += 0;
                                            surCharge += 0;
                                            EduChrg += 0;
                                        }
                                        else
                                        {
                                            TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                            surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));
                                            EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                    else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                        {
                                            TotTds += 0;
                                            surCharge += 0;
                                            EduChrg += 0;
                                        }
                                        else
                                        {
                                            TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                            surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));

                                            EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                    else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                    }
                                    else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }

                                Total = (TotFrAmount + DueCarr + TotTax) - (agentExp + TotDiscount + comm);
                                Decimal Debit_Surcharge = 0;
                                DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID='" + dtAgentName.Rows[j]["Agent_Id"].ToString() + "' AND AIRLINE_DETAIL_ID=" + dtAirlineDetailId.Rows[n]["Airline_Detail_ID"].ToString() + " AND (CSR_PERIOD>='" + DateTime.Parse(TextBox1.Text) + "' AND CSR_PERIOD<='" + DateTime.Parse(TextBox2.Text) + "')");

                                if (dt_Sur.Rows.Count > 0)
                                {
                                    Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(dr1["Education_Cess"].ToString()) / 100)), MidpointRounding.AwayFromZero);
                                }

                                if (Math.Round((Total + TotTds + EduChrg + surCharge - total_tds_cut + total_cc), MidpointRounding.AwayFromZero) < 0)
                                {
                                    GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                    decimal test = (Math.Round((Total + Math.Ceiling(TotTds) + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + Math.Round(surCharge, MidpointRounding.AwayFromZero)), MidpointRounding.AwayFromZero));
                                    //GrandTotal2 = GrandTotal2 + Math.Abs(GrandTotal);
                                    ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";
                                    TabTotal = Math.Abs(GrandTotal);
                                    // GtGrandTotal -= GrandTotal;
                                }
                                else
                                {
                                    GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                    //GrandTotal1 = GrandTotal1 + Math.Abs(GrandTotal);
                                    ss = "<font color=black>" + Math.Abs(GrandTotal) + "";
                                    TabTotal = Math.Abs(GrandTotal);
                                    // GtGrandTotal += GrandTotal;
                                }

                            }
                            Csr_Payment_Total += TabTotal;
                            Csr_Pending_Total += TabTotal;
                            Csr_Collect_Total += TabTotal;
                            GtchrWt += chrWt;
                            GtamountPP += amountPP;
                            GtamountCC += amountCC;
                            GtDueCarr += DueCarr;
                            GtagentExp += agentExp;
                            Gtcomm += comm;
                            Gtincentive += incentive;
                            GtspotDiff += spotDiff;
                            GtfrtDiff += frtDiff;
                            MHGtincentive += mHincentive;
                            MHGtspotDiff += mHspotDiff;
                            MHGtfrtDiff += mHfrtDiff;
                            GtGrandTotal += GrandTotal;
                            // GtGrandTotal = GtGrandTotal + GrandTotal;
                            GtxrayCh += xrayCh;
                            if (ss == "")
                            {
                                ss = "-";
                            }
                            if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                            {
                                Table_COLLECTION += @"<td nowrap align=right>" + ss + "</td>";
                                Table_Csr_Pending += @"<td nowrap align=right>-</td>";
                                Table_Csr_Payment += @"<td nowrap align=right>" + ss + "</td>";
                                table += @"<td nowrap> " + SubAgent + "</td>";
                                sno = sno + 1;
                            }
                            else
                            {
                                //table += @"<td >" + ss == "" ? "-" : ss + "</td>";
                                Table_Csr_Payment += @"<td nowrap align=right>" + ss + "</td>";
                                Table_COLLECTION += @"<td nowrap align=right>-</td>";
                                Table_Csr_Pending += @"<td nowrap align=right>" + ss + "</td>";
                                table += @"<td nowrap>" + SubAgent + "</td>";

                                sno = sno + 1;
                            }

                            ////end of main loop of calculation 
                            //}


                            con1.Close();
                            // }
                            //GtGrandTotal = (GrandTotal1 - GrandTotal2);
                            //////////if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                            //////////{
                            //////////    table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td><td>" + MHGtincentive + @"</td><td>" + MHGtspotDiff + @"</td><td>" + MHGtfrtDiff + @"</td></tr></table>";
                            //////////}
                            //////////else
                            //////////{
                            //////////    table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";

                            //////////}


                            Session["dt"] = pageHead + table;
                            if (pageHead == "")
                            {
                                pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                                Session["dt"] = pageHead;
                            }

                        }

                        catch (SqlException ex)
                        {
                            string strer = ex.ToString();
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }
                    }
                    table += @"</tr>";
                    Table_COLLECTION += @"<td align=right>-</td></tr>";
                    Table_Csr_Pending += @"<td align=right>" + Csr_Pending_Total.ToString("0.00") + "</td></tr>";
                    Table_Csr_Payment += @"<td align=right>" + Csr_Payment_Total.ToString("0.00") + "</td></tr>";
                    Csr_Collect_Total = 0;
                    Csr_Payment_Total = 0;
                    Csr_Pending_Total = 0;
                }
                ////end for agent loop
            }
            table += @"</table>";
            Table_COLLECTION += @"</table>";
            Table_Csr_Pending += @"</table>";
            Table_Csr_Payment += @"</table>";
            Main_Table = @"<table><tr><td><br/></td></tr><tr align=center><td><h2>Reports for " + ddlCompany.SelectedItem.Text + "</h2></td></tr><tr align=center><td><h3><u> " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + "</u></h3></td></tr><tr><td><br/></td></tr><tr><td></td></tr><tr><td>" + table + "</td><td>" + Table_Csr_Payment + "</td><td>" + Table_COLLECTION + "</td><td>" + Table_Csr_Pending + "</td></tr></table>";

        }
        else
        {
            Main_Table = @"<table><tr><td><br/></td></tr><tr align=center><td><h2>Reports for " + ddlCompany.SelectedItem.Text + "</h2></td></tr><tr align=center><td><h3><u> " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + "</u></h3></td></tr><tr><td><br/></td></tr><tr><td></td></tr><tr><td><p><font color=red size=4>Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p></td></tr></table>";
                            
        }

        //lbltest.Text = Main_Table.ToString();
        Session["CompanyWiseAgentDetails"] = Main_Table.ToString();
       // Response.Redirect("DisplayCompanywiseDeatails.aspx");
        ////////////lblReport.Text = Session["dt"].ToString();
        ////page_pop = "<SCRIPT language='javascript'>window.open('NewReportDrCr.aspx');</SCRIPT>";
        //////Response.Write(page_pop);
        ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('DisplayCompanywiseDeatails.aspx');</script>");
        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    protected void MakeCsrDate()
    {
        TextBox1.Text = "04/01/2010" ;
        TextBox2.Text = "03/31/2011";
    
    }

    //protected void MakeCsrDate()
    //{
    //    string strY = ddlyear.SelectedItem.Text.Trim();
    //    if (rbtnFirstFortn.Checked == true)
    //    {
    //        if (ddlMonth.SelectedItem.Text.Trim() == "January")
    //        {
    //            TextBox1.Text = "01/01/" + strY;
    //            TextBox2.Text = "01/15/" + strY;
    //            TextBox3.Text = "01/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "February")
    //        {
    //            TextBox1.Text = "02/01/" + strY;
    //            TextBox2.Text = "02/15/" + strY;
    //            TextBox3.Text = "02/16/" + strY;
    //        }
    //        if (ddlMonth.SelectedItem.Text.Trim() == "March")
    //        {
    //            TextBox1.Text = "03/01/" + strY;
    //            TextBox2.Text = "03/15/" + strY;
    //            TextBox3.Text = "03/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "April")
    //        {
    //            TextBox1.Text = "04/01/" + strY;
    //            TextBox2.Text = "04/15/" + strY;
    //            TextBox3.Text = "04/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text == "May")
    //        {
    //            TextBox1.Text = "05/01/" + strY;
    //            TextBox2.Text = "05/15/" + strY;
    //            TextBox3.Text = "05/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "June")
    //        {
    //            TextBox1.Text = "06/01/" + strY;
    //            TextBox2.Text = "06/15/" + strY;
    //            TextBox3.Text = "06/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "July")
    //        {
    //            TextBox1.Text = "07/01/" + strY;
    //            TextBox2.Text = "07/15/" + strY;
    //            TextBox3.Text = "07/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "August")
    //        {
    //            TextBox1.Text = "08/01/" + strY;
    //            TextBox2.Text = "08/15/" + strY;
    //            TextBox3.Text = "08/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "September")
    //        {
    //            TextBox1.Text = "09/01/" + strY;
    //            TextBox2.Text = "09/15/" + strY;
    //            TextBox3.Text = "09/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "October")
    //        {
    //            TextBox1.Text = "10/01/" + strY;
    //            TextBox2.Text = "10/15/" + strY;
    //            TextBox3.Text = "10/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "November")
    //        {
    //            TextBox1.Text = "11/01/" + strY;
    //            TextBox2.Text = "11/15/" + strY;
    //            TextBox3.Text = "11/16/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "December")
    //        {
    //            TextBox1.Text = "12/01/" + strY;
    //            TextBox2.Text = "12/15/" + strY;
    //            TextBox3.Text = "12/16/" + strY;
    //        }
    //    }

    //    else if (rbtnSecondFortN.Checked == true)
    //    {
    //        if (ddlMonth.SelectedItem.Text.Trim() == "January")
    //        {
    //            TextBox1.Text = "01/16/" + strY;
    //            TextBox2.Text = "01/31/" + strY;
    //            TextBox3.Text = "02/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "February")
    //        {
    //            TextBox1.Text = "02/16/" + strY;
    //            if (DateTime.IsLeapYear(int.Parse(strY)))
    //                TextBox2.Text = "02/29/" + strY;
    //            else
    //            { TextBox2.Text = "02/28/" + strY; }

    //            TextBox3.Text = "03/01/" + strY;

    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "March")
    //        {
    //            TextBox1.Text = "03/16/" + strY;
    //            TextBox2.Text = "03/31/" + strY;
    //            TextBox3.Text = "04/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "April")
    //        {
    //            TextBox1.Text = "04/16/" + strY;
    //            TextBox2.Text = "04/30/" + strY;
    //            TextBox3.Text = "05/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "May")
    //        {
    //            TextBox1.Text = "05/16/" + strY;
    //            TextBox2.Text = "05/31/" + strY;
    //            TextBox3.Text = "06/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "June")
    //        {
    //            TextBox1.Text = "06/16/" + strY;
    //            TextBox2.Text = "06/30/" + strY;
    //            TextBox3.Text = "07/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "July")
    //        {
    //            TextBox1.Text = "07/16/" + strY;
    //            TextBox2.Text = "07/31/" + strY;
    //            TextBox3.Text = "08/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "August")
    //        {
    //            TextBox1.Text = "08/16/" + strY;
    //            TextBox2.Text = "08/31/" + strY;
    //            TextBox3.Text = "09/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "September")
    //        {
    //            TextBox1.Text = "09/16/" + strY;
    //            TextBox2.Text = "09/30/" + strY;
    //            TextBox3.Text = "10/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "October")
    //        {
    //            TextBox1.Text = "10/16/" + strY;
    //            TextBox2.Text = "10/31/" + strY;
    //            TextBox3.Text = "11/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "November")
    //        {
    //            TextBox1.Text = "11/16/" + strY;
    //            TextBox2.Text = "11/30/" + strY;
    //            TextBox3.Text = "12/01/" + strY;
    //        }
    //        else if (ddlMonth.SelectedItem.Text.Trim() == "December")
    //        {
    //            TextBox1.Text = "12/16/" + strY;
    //            TextBox2.Text = "12/31/" + strY;
    //            TextBox3.Text = "01/01/" + strY;
    //        }

    //    }

    //}
    #region Generate Unique One Time Password
    private void OTPPwd()
    {
        string oTP = Convert.ToString(DateTime.Now.Second + 70096 + DateTime.Now.Minute);
        ViewState["currentOtp"] = oTP;

        SendSMS("Your OTP is: " + oTP + " ,Use these 5 digit's code to view the report.");
   
    }
    #endregion
    #region TO Check IP whether access from outside from office or not
    private Boolean IPCheck()
    {
        #region IPCheck
        string IP = GetUserIp();//"178.1.2.63";
        if (IP != "")
        {
            string[] ip_addrs = IP.Split('.');
            if (ip_addrs.Length == 4)
            {
                string currentPageName = System.IO.Path.GetFileName(Request.Url.AbsolutePath);
                con = new SqlConnection(strCon);
                con.Open();
                string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on,Email_ID,Page_Name)VALUES( '" + IP + "','" + DateTime.Now + "','" + Session["EMailID"].ToString() + "','" + currentPageName + "')";
                com = new SqlCommand(cInsert, con);
                com.ExecuteNonQuery();
                con.Close();


                if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
        #endregion
    }
    #endregion

    #region For Sending Alert on SMS
    public void SendSMS(string fmessage)
    {
        try
        {

            int Status = 0;
            string StatusMessage = "";
            string str = "";
            string pushURL = "http://www.myvaluefirst.com/smpp/sendsms?username=cargoflash&password=cargohtp&to=@mobileno&from=Cargoflash&text=@message";
            pushURL = pushURL.Replace("@message", fmessage);
            pushURL = pushURL.Replace("@mobileno", GetMobileNo());
            // Get HTML data
            WebClient client = new WebClient();
            Stream data = client.OpenRead(pushURL);
            StreamReader reader = new StreamReader(data);
            str = reader.ReadToEnd();
            data.Close();
            if (str.StartsWith("0,"))
                Status = 0;
            else
                Status = 1;
            StatusMessage = str;
            str = StatusMessage.Substring(StatusMessage.IndexOf("Sent") + "Sent".Length + 1).Trim();
        }
        catch (Exception ee)
        {

        }
    }
    #endregion
    private string GetMobileNo()
    {
        string mobileNo = "";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("SELECT Mobile FROM dbo.User_Master WHERE Email='" + Convert.ToString(Session["EMailID"]) + "'", con);
            mobileNo = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
        return mobileNo;
    }
}
