using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Approve_CSR_Details : System.Web.UI.Page
{

    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    #region Variables Declaration

    // Declare public variables here 
    SqlDataReader dr = null;
    SqlConnection con;
    SqlCommand com;
    //SqlDataAdapter da;
   
    string str_AirlineDetailId;
    int CSR_Duration_ID;
    string strQueryString_Period;
    DateTime FROM_DATE;
    DateTime TO_DATE;
    DisplayWrap dpw = new DisplayWrap();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            
            str_AirlineDetailId = "";
            strQueryString_Period = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "Duration");
            string[] ARR_DATE = strQueryString_Period.Split('-');

            FROM_DATE = DateTime.Parse(ARR_DATE[0].ToString());
            TO_DATE = DateTime.Parse(ARR_DATE[1].ToString());


            str_AirlineDetailId = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "AirlineDetailId");

            //FINDING CSR DURATION IN DD/MM/YY FORMAT
            string csr_d = strQueryString_Period;
            string[] arr_csr = csr_d.Split('-');
            string First_Fort = arr_csr[0];
            string Sec_Fort = arr_csr[1];
            string[] Arr_First_Fort = First_Fort.Split('/');
            string MM = Arr_First_Fort[0];
            string DD = Arr_First_Fort[1];
            string yy = Arr_First_Fort[2];
            string DDMMYYYY = DD + "/" + MM + "/" + yy;

            string[] Arr_Sec_Fort = Sec_Fort.Split('/');
            string strMM = Arr_Sec_Fort[0];
            string strDD = Arr_Sec_Fort[1];
            string stryy = Arr_Sec_Fort[2];
            string strDDMMYYYY = strDD + "/" + strMM + "/" + stryy;

            string Final_CSR_Duration = DDMMYYYY + "-" + strDDMMYYYY;
            lblperiod.Text = Final_CSR_Duration;
            AirlineCode();
            string agnetID = "";
            con.Open();
            if (lblairlinecode.Text != "360")
            {
                /////string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID,a.CSR_SNo FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND ((csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "') OR (csr_DATE<='" + TO_DATE + "'  AND Sales_type='CRDR' AND Approved_for_CSR=29))   order by AM.AGENT_NAME";
                string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID,a.CSR_SNo,a.GstInvNo FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND (csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "')  AND (Approved_for_CSR=29 or Approved_for_CSR is null) order by AM.AGENT_NAME";
                com = new SqlCommand(SqlQuery, con);

                dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    DataTable dt = MakeTable();

                    while (dr.Read())
                    {
                        decimal TotChAmount = 0;
                        decimal TotDueCar = 0;
                        decimal TotTax = 0;
                        decimal TotAgentExp = 0;
                        decimal TotComm = 0;
                        decimal TotDiscount = 0;
                        decimal TotFrAmount = 0;
                        decimal TotFrAmountCC = 0;
                        decimal TotTds = 0;
                        //GST
                        decimal TotCGST = 0;
                        decimal TotSGST = 0;
                        decimal TotIGST = 0;
                        decimal TotGstAmt = 0;
                        decimal EduChrg = 0; decimal Total = 0;
                        decimal GrandTotal = 0;
                        decimal surCharge = 0;
                        string lastTsdsRate = null;

                        decimal TotChAmount_CRDR = 0;
                        decimal TotDueCar_CRDR = 0;
                        decimal TotTax_CRDR = 0;
                        decimal TotAgentExp_CRDR = 0;
                        decimal TotComm_CRDR = 0;
                        decimal TotDiscount_CRDR = 0;
                        decimal TotFrAmount_CRDR = 0;

                        decimal TotTds_CRDR = 0;
                        decimal TotCGST_CRDR = 0;
                        decimal TotSGST_CRDR = 0;
                        decimal TotIGST_CRDR = 0;
                        decimal TotGstAmt_CRDR = 0;
                        decimal EduChrg_CRDR = 0; decimal Total_CRDR = 0;
                        decimal GrandTotal_CRDR = 0;
                        decimal surCharge_CRDR = 0;
                        string lastTsdsRate_CRDR = null;


                        string Agent_name = dr["Agent_name"].ToString();
                        string Agent_Code = dr["Agent_Code"].ToString();
                        string CSR_SNo = dr["CSR_SNo"].ToString();
                        string GstInvNo = dr["GstInvNo"].ToString();
                        agnetID = dr["AGENT_ID"].ToString();
                        SqlConnection con1 = new SqlConnection(strCon);
                        SqlCommand com_csr=new SqlCommand();
                        con1.Open();
                        if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/01/2017"))

                            com_csr = new SqlCommand("APPROVE_CSR_DETAILS", con1);
                        else
                        {
                            if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                            {
                                com_csr = new SqlCommand("APPROVE_CSR_DETAILS_GST_KEIATA", con1);
                            }

                            else
                            {
                                com_csr = new SqlCommand("APPROVE_CSR_DETAILS_GST", con1);
                            }
                        }
                        com_csr.CommandType = CommandType.StoredProcedure;
                        com_csr.Parameters.AddWithValue("agent_id", agnetID);
                        com_csr.Parameters.AddWithValue("CSR_SNo", CSR_SNo);

                        com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
                        com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
                        com_csr.Parameters.AddWithValue("Airline_Detail_ID", str_AirlineDetailId);

                        SqlDataReader dr_csr = com_csr.ExecuteReader();
                        string VarDate = "07/31/2008";
                        string Mh_Period = "08/15/2008";
                        while (dr_csr.Read())
                        {
                            // string type=dr_csr["Sales_Type"].ToString().Trim();
                            if (dr_csr["Sales_Type"].ToString().Trim() == "INV")
                            {
                                //Gst Added
                                TotCGST += Math.Round(decimal.Parse(dr_csr["CGSTAmt"].ToString()), MidpointRounding.AwayFromZero);
                                TotSGST += Math.Round(decimal.Parse(dr_csr["SGSTAmt"].ToString()), MidpointRounding.AwayFromZero);
                                TotIGST += Math.Round(decimal.Parse(dr_csr["IGSTAmt"].ToString()), MidpointRounding.AwayFromZero);


                                TotChAmount += decimal.Parse(dr_csr["Charged_Weight"].ToString());
                                TotDueCar += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                string tEST = dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper();
                                if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    if ((FROM_DATE) > DateTime.Parse(VarDate))
                                    {

                                        TotDiscount += 0;
                                        TotComm += 0;
                                        TotAgentExp += 0;
                                    }
                                    else
                                    {

                                        TotAgentExp += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    if ((FROM_DATE) > DateTime.Parse(Mh_Period))
                                    {

                                        TotDiscount += 0;
                                        TotComm += 0;
                                        TotAgentExp += 0;
                                    }
                                    else
                                    {

                                        TotAgentExp += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                        TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                        TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    }
                                }

                                else
                                {
                                    TotAgentExp += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                    TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                                {
                                    if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                    {

                                        if ((FROM_DATE) > DateTime.Parse(VarDate))
                                        {
                                            TotTds -= 0;
                                            surCharge -= 0;
                                            EduChrg -= 0;
                                        }
                                        else
                                        {
                                            TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                            //Gst Added
                                            TotGstAmt -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                            surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                            EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                        }
                                    }
                                    else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                    {

                                        if ((FROM_DATE) > DateTime.Parse(Mh_Period))
                                        {
                                            TotTds -= 0;
                                            surCharge -= 0;
                                            EduChrg -= 0;
                                        }
                                        else
                                        {
                                            TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                            //Gst Added
                                            TotGstAmt -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));


                                            surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                            EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        }
                                    }

                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));

                                        //Gst Added
                                        TotGstAmt -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));


                                        surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }

                                }
                                else
                                {
                                    if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                    {

                                        if ((FROM_DATE) > DateTime.Parse(VarDate))
                                        {
                                            TotTds += 0;
                                            surCharge += 0;
                                            EduChrg += 0;
                                        }
                                        else
                                        {
                                            TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                            //Gst Added
                                            TotGstAmt += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));


                                            surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                            EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                    else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                    {

                                        if ((FROM_DATE) > DateTime.Parse(Mh_Period))
                                        {
                                            TotTds += 0;
                                            surCharge += 0;
                                            EduChrg += 0;
                                        }
                                        else
                                        {
                                            TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));

                                            //Gst Added
                                            TotGstAmt += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                            surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                            EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        }
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));

                                        //Gst Added
                                        TotGstAmt += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                        surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }

                                }

                                lastTsdsRate = dr_csr["tds"].ToString();
                                string amountPP = null;
                                string amountCC = null;
                                if (dr_csr["Freight_type"].ToString() == "COLLECT")
                                {
                                    amountPP = "0";
                                    amountCC = dr_csr["Freight_Amount"].ToString();
                                    TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    amountPP = dr_csr["Freight_Amount"].ToString();
                                    amountCC = "0";
                                    TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
                                }



                            }
                            else if (dr_csr["Sales_Type"].ToString().Trim() == "CRDR")
                            {
                                //Gst Added
                                TotCGST_CRDR += decimal.Parse(dr_csr["CGSTAmt"].ToString());
                                TotSGST_CRDR += decimal.Parse(dr_csr["SGSTAmt"].ToString());
                                TotIGST_CRDR += decimal.Parse(dr_csr["IGSTAmt"].ToString());

                                TotChAmount_CRDR += decimal.Parse(dr_csr["Charged_Weight"].ToString());
                                TotDueCar_CRDR += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                TotAgentExp_CRDR += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm_CRDR += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDiscount_CRDR += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                                {
                                    TotTds_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    //Gst Added
                                    TotGstAmt_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));


                                    surCharge_CRDR -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg_CRDR -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);


                                }
                                else
                                {
                                    TotTds_CRDR += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    //Gst Added
                                    TotGstAmt_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                    surCharge_CRDR += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg_CRDR += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }

                                lastTsdsRate_CRDR = dr_csr["tds"].ToString();
                                string amountPP_CRDR = null;
                                string amountCC_CRDR = null;
                                if (dr_csr["Freight_type"].ToString() == "COLLECT")
                                {
                                    amountPP_CRDR = "0";
                                    amountCC_CRDR = dr_csr["Freight_Amount"].ToString();
                                    TotFrAmountCC += Math.Round(decimal.Parse(amountCC_CRDR), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    amountPP_CRDR = dr_csr["Freight_Amount"].ToString();
                                    amountCC_CRDR = "0";
                                    TotFrAmount_CRDR += Math.Round(decimal.Parse(amountPP_CRDR), MidpointRounding.AwayFromZero);
                                }
                            }
                        }
                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);



                        Decimal Debit_Surcharge = 0;
                        DataTable dt_Sur = dpw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + str_AirlineDetailId + " AND (CSR_PERIOD>='" + FROM_DATE + "' AND CSR_PERIOD<='" + TO_DATE + "')");
                        if (dt_Sur.Rows.Count > 0)
                        {
                            Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            // EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);

                        }
                        //Gst Added

                        /////GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                        if (Convert.ToDateTime(TO_DATE) <= Convert.ToDateTime("07/15/2017"))
                        {
                            GrandTotal = Math.Round((Total + TotTds + TotCGST + TotSGST + TotIGST + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                        }

                        else
                        {
                            if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                            {
                                GrandTotal = Math.Round((Total + TotTds + TotCGST + TotSGST + TotIGST + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                GrandTotal = Math.Round((Total + TotCGST + TotSGST + TotIGST + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                            }
                        }

                      
                        Total_CRDR = Math.Round(((TotFrAmount_CRDR + TotDueCar_CRDR + TotTax_CRDR) - (TotAgentExp_CRDR + TotDiscount_CRDR + TotComm_CRDR)), MidpointRounding.AwayFromZero);
                        
                        //Gst added
                        /////GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                        if (Convert.ToDateTime(TO_DATE) <= Convert.ToDateTime("07/15/2017"))
                        {
                            GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + TotCGST_CRDR + TotSGST_CRDR + TotIGST_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                            {
                                GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + TotCGST_CRDR + TotSGST_CRDR + TotIGST_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                GrandTotal_CRDR = Math.Round((Total_CRDR  + TotCGST_CRDR + TotSGST_CRDR + TotIGST_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                            }
                        }

                        dr_csr.Dispose();
                        com_csr.Dispose();
                        con1.Close();
                        if (GrandTotal != 0)
                        {
                            DataRow dw = dt.NewRow();
                            if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("08/01/2017"))
                            {

                                dw[0] = CSR_SNo;
                            }
                            else
                            {
                                dw[0] = GstInvNo;
                                
                            }
                            dw[1] = Agent_name;
                            dw[2] = GrandTotal;
                            dw[3] = "INV";
                            dt.Rows.Add(dw);
                        }
                        if (GrandTotal_CRDR != 0)
                        {
                            DataRow dw = dt.NewRow();
                            if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("08/01/2017"))
                            {

                                dw[0] = CSR_SNo;
                            }
                            else
                            {
                                dw[0] = GstInvNo;

                            }
                            dw[1] = Agent_name;
                            dw[2] = GrandTotal_CRDR;
                            dw[3] = "CRDR";
                            dt.Rows.Add(dw);

                        }

                    }
                    if (dt.Rows.Count > 0)
                    {

                        grdCSR.DataSource = dt;
                        grdCSR.DataBind();


                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.ForeColor = System.Drawing.Color.Red;
                        lblmsg.Text = "No Csr generated for the above period";
                        Button1.Visible = false;


                    }


                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    lblmsg.Text = "No Csr generated for the above period";
                    Button1.Visible = false;


                }
                dr.Dispose();
                com.Dispose();
                con.Close();
            }
            
            else
            {
                string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID,a.CSR_SNo FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND ((flight_date BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "') OR (flight_date<='" + TO_DATE + "' AND Sales_type='CRDR' AND Approved_for_CSR=29)) order by AM.AGENT_NAME";
                com = new SqlCommand(SqlQuery, con);

                dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    DataTable dt = MakeTable();

                    while (dr.Read())
                    {
                        decimal TotChAmount = 0;
                        decimal TotDueCar = 0;
                        decimal TotTax = 0;
                        decimal TotAgentExp = 0;
                        decimal TotComm = 0;
                        decimal TotDiscount = 0;
                        decimal TotFrAmount = 0;
                        decimal TotFrAmountCC = 0;
                        decimal TotTds = 0;
                        //Gst added
                        decimal TotCGST = 0;
                        decimal TotSGST = 0;
                        decimal TotIGST = 0;

                        decimal TotCGST_CRDR = 0;
                        decimal TotSGST_CRDR = 0;
                        decimal TotIGST_CRDR = 0;
                        decimal TotGstAmt = 0;
                        decimal EduChrg = 0; decimal Total = 0;
                        decimal GrandTotal = 0;
                        decimal surCharge = 0;
                        string lastTsdsRate = null;

                        decimal TotChAmount_CRDR = 0;
                        decimal TotDueCar_CRDR = 0;
                        decimal TotTax_CRDR = 0;
                        decimal TotAgentExp_CRDR = 0;
                        decimal TotComm_CRDR = 0;
                        decimal TotDiscount_CRDR = 0;
                        decimal TotFrAmount_CRDR = 0;

                        decimal TotTds_CRDR = 0;
                        decimal TotGstAmt_CRDR = 0;
                        decimal EduChrg_CRDR = 0; decimal Total_CRDR = 0;
                        decimal GrandTotal_CRDR = 0;
                        decimal surCharge_CRDR = 0;
                        string lastTsdsRate_CRDR = null;
                        decimal total_cc = 0;
                        decimal total_cc_crdr = 0;
                        decimal total_tds_cut = 0;
                        decimal total_tds_cut_crdr = 0;
                        string Agent_name = dr["Agent_name"].ToString();
                        string Agent_Code = dr["Agent_Code"].ToString();
                        string CSR_SNo = dr["CSR_SNo"].ToString();
                        agnetID = dr["AGENT_ID"].ToString();
                        SqlConnection con1 = new SqlConnection(strCon);
                        SqlCommand com_csr = new SqlCommand();
                        con1.Open();
                        if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/01/2017"))

                            com_csr = new SqlCommand("APPROVE_CSR_DETAILS", con1);
                        else
                            com_csr = new SqlCommand("APPROVE_CSR_DETAILS_GST", con1);
                        com_csr.CommandType = CommandType.StoredProcedure;
                        com_csr.Parameters.AddWithValue("agent_id", agnetID);
                        com_csr.Parameters.AddWithValue("CSR_SNo", CSR_SNo);
                        com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
                        com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
                        com_csr.Parameters.AddWithValue("Airline_Detail_ID", str_AirlineDetailId);
                        SqlDataReader dr_csr = com_csr.ExecuteReader();
                        while (dr_csr.Read())
                        {
                            string st = dr_csr["Airwaybill_no"].ToString();
                            if (dr_csr["Sales_Type"].ToString().Trim() == "INV")
                            {
                                //Gst added
                                TotCGST += decimal.Parse(dr_csr["CGSTAmt"].ToString());
                                TotSGST += decimal.Parse(dr_csr["SGSTAmt"].ToString());
                                TotIGST += decimal.Parse(dr_csr["IGSTAmt"].ToString());

                                TotChAmount += decimal.Parse(dr_csr["Charged_Weight"].ToString());
                                string amountPP = null;
                                string amountCC = null;
                                if (dr_csr["Freight_type"].ToString() == "COLLECT")
                                {
                                    amountPP = "0";
                                    amountCC = dr_csr["Freight_Amount"].ToString();
                                    TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    amountPP = dr_csr["Freight_Amount"].ToString();
                                    amountCC = "0";
                                    TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
                                }
                                TotAgentExp += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDueCar += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()),MidpointRounding.AwayFromZero);
                                TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                total_tds_cut += Math.Round(decimal.Parse(dr_csr["Total_Due_PP_row"].ToString()), MidpointRounding.AwayFromZero);
                                if (FROM_DATE >= DateTime.Parse("08/01/2009"))
                                {
                                    total_cc += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                                }
                                else
                                {
                                    total_cc += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr_csr["TDS"].ToString().Trim()) / 100;
                                }
              
                                if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    
                                    //Gst
                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                    }

                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    //Gst
                                        TotTds -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                        surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                lastTsdsRate = dr_csr["tds"].ToString();
                               

                            }
                            else if (dr_csr["Sales_Type"].ToString().Trim() == "CRDR")
                            {

                                //Gst added
                                TotCGST_CRDR += decimal.Parse(dr_csr["CGSTAmt"].ToString());
                                TotSGST_CRDR += decimal.Parse(dr_csr["SGSTAmt"].ToString());
                                TotIGST_CRDR += decimal.Parse(dr_csr["IGSTAmt"].ToString());


                                TotChAmount_CRDR += decimal.Parse(dr_csr["Charged_Weight"].ToString());
                                TotDueCar_CRDR += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                                TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                total_tds_cut_crdr += Math.Round(decimal.Parse(dr_csr["Total_Due_PP_row"].ToString()), 2);
                                if (FROM_DATE >= DateTime.Parse("08/01/2009"))
                                {
                                    total_cc_crdr += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                                }
                                else
                                {
                                    total_cc_crdr += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr_csr["TDS"].ToString().Trim()) / 100;
                                }
                                TotAgentExp_CRDR += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), 2);
                                TotComm_CRDR += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), 2);
                                TotDiscount_CRDR += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                                {
                                    TotTds_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));

                                    //Gst
                                    TotGstAmt_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                    surCharge_CRDR -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg_CRDR -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);


                                }
                                else
                                {
                                    TotTds_CRDR += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    //Gst
                                    TotGstAmt_CRDR += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                    surCharge_CRDR += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg_CRDR += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                              
                                lastTsdsRate_CRDR = dr_csr["tds"].ToString();
                                string amountPP_CRDR = null;
                                string amountCC_CRDR = null;
                                if (dr_csr["Freight_type"].ToString() == "COLLECT")
                                {
                                    amountPP_CRDR = "0";
                                    amountCC_CRDR = dr_csr["Freight_Amount"].ToString();
                                    TotFrAmountCC += Math.Round(decimal.Parse(amountCC_CRDR), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    amountPP_CRDR = dr_csr["Freight_Amount"].ToString();
                                    amountCC_CRDR = "0";
                                    TotFrAmount_CRDR += Math.Round(decimal.Parse(amountPP_CRDR), MidpointRounding.AwayFromZero);
                                }
                            }
                        }
                        Total = Math.Round(((TotFrAmount + TotDueCar + TotTax) - (TotAgentExp + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);



                        Decimal Debit_Surcharge = 0;
                        DataTable dt_Sur = dpw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + str_AirlineDetailId + " AND (CSR_PERIOD>='" + FROM_DATE + "' AND CSR_PERIOD<='" + TO_DATE + "')");
                        if (dt_Sur.Rows.Count > 0)
                        {
                            Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);

                        }
                        ////Gst Addded

                        /////GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge + Debit_Surcharge + total_cc - total_tds_cut), MidpointRounding.AwayFromZero);
                        GrandTotal = Math.Round((Total + TotTds + TotGstAmt+ EduChrg + surCharge + Debit_Surcharge + total_cc - total_tds_cut), MidpointRounding.AwayFromZero);
                        Total_CRDR = Math.Round(((TotFrAmount_CRDR + TotDueCar_CRDR + TotTax_CRDR) - (TotAgentExp_CRDR + TotDiscount_CRDR + TotComm_CRDR)), MidpointRounding.AwayFromZero);

                        //Gst
                        ////GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + EduChrg_CRDR + surCharge_CRDR + total_cc_crdr - total_tds_cut_crdr), MidpointRounding.AwayFromZero);
                        GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + TotGstAmt_CRDR + EduChrg_CRDR + surCharge_CRDR + total_cc_crdr - total_tds_cut_crdr), MidpointRounding.AwayFromZero);

                        dr_csr.Dispose();
                        com_csr.Dispose();
                        con1.Close();
                        if (GrandTotal != 0)
                        {
                            DataRow dw = dt.NewRow();

                            dw[0] = CSR_SNo;
                            dw[1] = Agent_name;
                            dw[2] = GrandTotal;
                            dw[3] = "INV";
                            dt.Rows.Add(dw);
                        }
                        if (GrandTotal_CRDR != 0)
                        {
                            DataRow dw = dt.NewRow();
                            dw[0] = CSR_SNo;
                            dw[1] = Agent_name;
                            dw[2] = GrandTotal_CRDR;
                            dw[3] = "CRDR";
                            dt.Rows.Add(dw);

                        }

                    }
                    if (dt.Rows.Count > 0)
                    {

                        grdCSR.DataSource = dt;
                        grdCSR.DataBind();


                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.ForeColor = System.Drawing.Color.Red;
                        lblmsg.Text = "No Csr generated for the above period";
                        Button1.Visible = false;


                    }


                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    lblmsg.Text = "No Csr generated for the above period";
                    Button1.Visible = false;


                }
                dr.Dispose();
                com.Dispose();
                con.Close();

            }
        }


    }
    public void Insert_Approve_CSR_Deccan()
    {
        SqlConnection con_First = new SqlConnection(strCon);
        try
        {
            con_First.Open();

            string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID, a.CSR_SNo FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND ((csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "') OR (csr_DATE<='" + TO_DATE + "'  AND Sales_type='CRDR' AND Approved_for_CSR=29))  order by AM.AGENT_NAME  ";

            com = new SqlCommand(SqlQuery, con_First);
            int COUNT = 1;
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {

                while (dr.Read())
                {
                    decimal TotComm = 0;
                    decimal TotDiscount = 0;
                    decimal TotFrAmount = 0;
                    decimal TotFrAmountCC = 0;
                    decimal EduChrg = 0;
                    decimal TotTds = 0;
                    decimal TotGstAmt = 0;
                    decimal Total = 0;
                    decimal GrandTotal = 0;
                    decimal Freight_Amount = 0;
                    decimal Total_DueCarrier = 0;
                    decimal TotTax = 0;
                    decimal Agent_Expenses = 0;
                    decimal Freight_Diff_Amount = 0;
                    decimal IATA_Commission = 0;
                    decimal Amount_Excluding_TDS = 0;
                    decimal LastTdsRate = 0;
                    decimal LastSurcharge = 0;
                    decimal LastEducation_Cess = 0;
                    decimal TDS_Amount = 0;
                    decimal GST_Amount = 0;
                    decimal surCharge = 0;
                    decimal Amount_Including_TDS = 0;

                    decimal TotComm_CRDR = 0;
                    decimal TotDiscount_CRDR = 0;
                    decimal TotFrAmount_CRDR = 0;
                    decimal TotFrAmountCC_CRDR = 0;
                    decimal EduChrg_CRDR = 0;
                    decimal TotTds_CRDR = 0;
                    decimal TotGstAmt_CRDR = 0;
                    decimal Total_CRDR = 0;
                    decimal GrandTotal_CRDR = 0;
                    decimal Freight_Amount_CRDR = 0;
                    decimal Total_DueCarrier_CRDR = 0;
                    decimal TotTax_CRDR = 0;
                    decimal Agent_Expenses_CRDR = 0;
                    decimal Freight_Diff_Amount_CRDR = 0;
                    decimal IATA_Commission_CRDR = 0;
                    decimal Amount_Excluding_TDS_CRDR = 0;
                    decimal LastTdsRate_CRDR = 0;
                    decimal LastSurcharge_CRDR = 0;
                    decimal LastEducation_Cess_CRDR = 0;
                    decimal TDS_Amount_CRDR = 0;
                    decimal Gst_Amount_CRDR = 0;
                    decimal surCharge_CRDR = 0;
                    decimal Amount_Including_TDS_CRDR = 0;
                    int Amount_Type_CRDR;
                    decimal total_cc = 0;
                    decimal total_cc_crdr = 0;
                    decimal total_tds_cut = 0;
                    decimal total_tds_cut_crdr = 0;
                    string AGENT_ID = dr["AGENT_ID"].ToString();
                    string Agent_Name = dr["Agent_name"].ToString();
                    string Agent_Code = dr["Agent_Code"].ToString();
                    string Agent_Address = dr["Agent_Address"].ToString();
                    string CSR_SERIALNo = dr["CSR_SNo"].ToString();
                    long CSR_SNo = 0;
                    long CSR_SNo_CRDR = 0;
                    string CSR_No = dr["Agent_Code"].ToString() + "-" + lblairlinecode.Text + "-" + lblperiod.Text;
                    int Amount_Type;
                    string Sales_Type = "";
                    string Sales_Type_CRDR = "";
                    DateTime CSR_From = FROM_DATE;
                    DateTime CSR_To = TO_DATE;
                    string Entered_By = Session["EMailID"].ToString();
                    DateTime Entered_On = DateTime.Now;

                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand com_csr = new SqlCommand("APPROVE_CSR_DETAILS_Deccan", con1);
                    com_csr.CommandType = CommandType.StoredProcedure;
                    com_csr.Parameters.AddWithValue("agent_id", AGENT_ID);
                    com_csr.Parameters.AddWithValue("CSR_SNo", CSR_SERIALNo);
                    com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
                    com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
                    com_csr.Parameters.AddWithValue("Airline_Detail_ID", str_AirlineDetailId);

                    SqlDataReader dr_csr = com_csr.ExecuteReader();
                    while (dr_csr.Read())
                    {
                        if (dr_csr["Sales_Type"].ToString().Trim() == "INV")
                        {
                            Sales_Type = dr_csr["Sales_Type"].ToString().Trim();
                            CSR_SNo = long.Parse(dr_csr["csr_sno"].ToString());
                            Freight_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Total_DueCarrier += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                            total_tds_cut += Math.Round(decimal.Parse(dr_csr["Total_Due_PP_row"].ToString()), MidpointRounding.AwayFromZero);

                            if (FROM_DATE >= DateTime.Parse("08/01/2009"))
                            {
                                total_cc += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                            }
                            else
                            {
                                total_cc += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr_csr["TDS"].ToString().Trim()) / 100;
                            }

                            Freight_Diff_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            Amount_Excluding_TDS += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);  

                            if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                //Gst
                                TotGstAmt -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));

                                surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                //Gst 
                                TotGstAmt += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                            LastTdsRate = decimal.Parse(dr_csr["tds"].ToString());
                            LastSurcharge = decimal.Parse(dr_csr["surcharge"].ToString());
                            LastEducation_Cess = decimal.Parse(dr_csr["Education_Cess"].ToString());


                            TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);
                            //Gst
                            GST_Amount = Math.Round((TotGstAmt), MidpointRounding.AwayFromZero);

                            string amountPP = null;
                            string amountCC = null;
                            if (dr_csr["Freight_type"].ToString() == "COLLECT")
                            {
                                amountPP = "0";
                                amountCC = dr_csr["Freight_Amount"].ToString();
                                TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                amountPP = dr_csr["Freight_Amount"].ToString();
                                amountCC = "0";
                                TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
                            }


                            TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                            TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
          

                        }
                        else if (dr_csr["Sales_Type"].ToString().Trim() == "CRDR")
                        {
                            Sales_Type_CRDR = dr_csr["Sales_Type"].ToString().Trim();
                            CSR_SNo_CRDR = long.Parse(dr_csr["csr_sno"].ToString());
                            Freight_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Total_DueCarrier_CRDR += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            total_tds_cut_crdr += Math.Round(decimal.Parse(dr_csr["Total_Due_PP_row"].ToString()), MidpointRounding.AwayFromZero);
                            if (FROM_DATE >= DateTime.Parse("08/01/2009"))
                            {
                                total_cc_crdr += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                            }
                            else
                            {
                                total_cc_crdr += decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr_csr["TDS"].ToString().Trim()) / 100;
                            }
                            TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Expenses_CRDR += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            Freight_Diff_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);

                            IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);

                            Amount_Excluding_TDS_CRDR += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

                            if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                            {

                                TotTds_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                //Gst
                                TotGstAmt_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                surCharge_CRDR -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg_CRDR -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                TotTds_CRDR += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                //Gst
                                TotGstAmt_CRDR += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                surCharge_CRDR += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg_CRDR += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                            }
                            LastTdsRate_CRDR = decimal.Parse(dr_csr["tds"].ToString());
                            LastSurcharge_CRDR = decimal.Parse(dr_csr["surcharge"].ToString());
                            LastEducation_Cess_CRDR = decimal.Parse(dr_csr["Education_Cess"].ToString());


                            TDS_Amount_CRDR = Math.Round((TotTds_CRDR + surCharge_CRDR + EduChrg_CRDR), MidpointRounding.AwayFromZero);
                            //Gst
                            Gst_Amount_CRDR = Math.Round((TotGstAmt_CRDR), MidpointRounding.AwayFromZero);

                            string amountPP_CRDR = null;
                            string amountCC_CRDR = null;
                            if (dr_csr["Freight_type"].ToString() == "COLLECT")
                            {
                                amountPP_CRDR = "0";
                                amountCC_CRDR = dr_csr["Freight_Amount"].ToString();
                                TotFrAmountCC_CRDR += Math.Round(decimal.Parse(amountCC_CRDR), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                amountPP_CRDR = dr_csr["Freight_Amount"].ToString();
                                amountCC_CRDR = "0";
                                TotFrAmount_CRDR += Math.Round(decimal.Parse(amountPP_CRDR), MidpointRounding.AwayFromZero);
                            }


                            TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);

                            TotComm_CRDR += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount_CRDR += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);

                        }

                    }



                    Total = Math.Round(((TotFrAmount + Total_DueCarrier + TotTax) - (Agent_Expenses + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dpw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + AGENT_ID + " AND AIRLINE_DETAIL_ID=" + str_AirlineDetailId + " AND (CSR_PERIOD>='" + FROM_DATE + "' AND CSR_PERIOD<='" + TO_DATE + "')");
                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * LastEducation_Cess / 100)), MidpointRounding.AwayFromZero);
                        TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);
                        //Gst
                        GST_Amount = Math.Round((TotGstAmt), MidpointRounding.AwayFromZero);
                    }
                    /////GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge + Debit_Surcharge+total_cc-total_tds_cut), MidpointRounding.AwayFromZero);
                    //Gst
                    GrandTotal = Math.Round((Total + TotTds +TotGstAmt + EduChrg + surCharge + Debit_Surcharge + total_cc - total_tds_cut), MidpointRounding.AwayFromZero);
                    Amount_Including_TDS = GrandTotal;
                    if (Amount_Including_TDS < 0)
                    {
                        Amount_Type = 24;
                    }
                    else
                    {
                        Amount_Type = 23;
                    }

                    /************************/
                    Total_CRDR = Math.Round(((TotFrAmount_CRDR + Total_DueCarrier_CRDR + TotTax_CRDR) - (Agent_Expenses_CRDR + TotDiscount_CRDR + TotComm_CRDR)), MidpointRounding.AwayFromZero);


                    /////GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + EduChrg_CRDR + surCharge_CRDR+total_cc_crdr-total_tds_cut_crdr), MidpointRounding.AwayFromZero);
                    //Gst
                    GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR +TotGstAmt_CRDR + EduChrg_CRDR + surCharge_CRDR + total_cc_crdr - total_tds_cut_crdr), MidpointRounding.AwayFromZero);
                    Amount_Including_TDS_CRDR = GrandTotal_CRDR;
                    if (Amount_Including_TDS_CRDR < 0)
                    {
                        Amount_Type_CRDR = 24;
                    }
                    else
                    {
                        Amount_Type_CRDR = 23;
                    }
                    using (con)
                    {
                        con = new SqlConnection(strCon);
                        con.Open();
                        SqlCommand strcom;
                        if (GrandTotal != 0)
                        {
                            strcom = new SqlCommand("INSERT_CSR_Deccan", con);
                            strcom.CommandType = CommandType.StoredProcedure;

                            strcom.Parameters.AddWithValue("@COUNT", COUNT);
                            strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
                            strcom.Parameters.AddWithValue("@Airline_Detail_ID", str_AirlineDetailId);
                            strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                            strcom.Parameters.AddWithValue("@Sales_Type", "INV");
                            strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo);
                            strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                            strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                            strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                            strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                            strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount);
                            strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC);
                            strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount);
                            strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier);
                            strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses);
                            strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount);
                            strcom.Parameters.AddWithValue("@IATA_Commission", Math.Round(IATA_Commission,MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Math.Round(Total,MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate);
                            strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge);
                            strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess);
                            strcom.Parameters.AddWithValue("@TDS_Amount", Math.Round((Math.Ceiling(TDS_Amount) + Debit_Surcharge),MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@Surcharge_Amount", (surCharge + Debit_Surcharge));
                            strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount);
                            strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg);
                            strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS);
                            strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type);
                            strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                            strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                            strcom.Parameters.AddWithValue("@TDS_Recoverable", Math.Ceiling(total_tds_cut));
                            strcom.Parameters.AddWithValue("@TDS_Cont", Math.Round(total_cc, MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                            strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
                            strcom.ExecuteNonQuery();
                        }
                        /************************************/
                        if (GrandTotal_CRDR != 0)
                        {

                            strcom = new SqlCommand("INSERT_CSR_Deccan", con);
                            strcom.CommandType = CommandType.StoredProcedure;

                            strcom.Parameters.AddWithValue("@COUNT", COUNT);
                            strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
                            strcom.Parameters.AddWithValue("@Airline_Detail_ID", str_AirlineDetailId);
                            strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                            strcom.Parameters.AddWithValue("@Sales_Type", "CRDR");
                            strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo_CRDR);
                            strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                            strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                            strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                            strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                            strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount_CRDR);
                            strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC_CRDR);
                            strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount_CRDR);
                            strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier_CRDR);
                            strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses_CRDR);
                            strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount_CRDR);
                            strcom.Parameters.AddWithValue("@IATA_Commission", Math.Round(IATA_Commission_CRDR,MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Math.Round(Total_CRDR,MidpointRounding.AwayFromZero));

                            strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate_CRDR);
                            strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge_CRDR);
                            strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess_CRDR);

                            strcom.Parameters.AddWithValue("@TDS_Amount", Math.Round((TDS_Amount_CRDR + Debit_Surcharge),MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@Surcharge_Amount", surCharge_CRDR);
                            strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount_CRDR);
                            strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg_CRDR);
                            strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS_CRDR);
                            strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type_CRDR);
                            strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                            strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                            strcom.Parameters.AddWithValue("@TDS_Recoverable", Math.Round(total_tds_cut_crdr, MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@TDS_Cont", Math.Round(total_cc_crdr, MidpointRounding.AwayFromZero));
                            strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                            strcom.Parameters.AddWithValue("@Entered_On", Entered_On);

                            strcom.ExecuteNonQuery();
                        }
                    }


                    COUNT++;



                    dr_csr.Dispose();
                    com_csr.Dispose();
                    con1.Close();


                }
                lblmsg.Visible = true;
                lblmsg.Text = "Approved SuccessFully";
                Button1.Visible = false;

            }
            con_First.Close();

        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con_First != null && con_First.State == ConnectionState.Open)
                con_First.Close();
        }


    }
     public DataTable MakeTable()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "CSR No";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = "Agent";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
                
        dc = new DataColumn();
        dc.ColumnName = "AmountRec/Payable";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = " ";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);


        //dc = new DataColumn();
        //dc.ColumnName = "Tax Amount";
        //dc.DataType = System.Type.GetType("System.Int32");
        //dt.Columns.Add(dc);

        //dc = new DataColumn();
        //dc.ColumnName = "TDS";
        //dc.DataType = System.Type.GetType("System.Int32");
        //dt.Columns.Add(dc);

        //dc = new DataColumn();
        //dc.ColumnName = "Surcharge";
        //dc.DataType = System.Type.GetType("System.Int32");
        //dt.Columns.Add(dc);

        //dc = new DataColumn();
        //dc.ColumnName = "Education Cess";
        //dc.DataType = System.Type.GetType("System.Int32");
        //dt.Columns.Add(dc);
         
        return dt;
       
    }
    public void AirlineCode()
    {
        try
        {
            string strQuery = "";
           
            if (str_AirlineDetailId != "")
            {
                strQuery = "select Airline_Code  from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID where Airline_Detail_ID='" + str_AirlineDetailId + "' ";
            

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                lblairlinecode.Text = dr["Airline_Code"].ToString();
            }
            con.Close();
            com.Dispose();
            dr.Close();
            }
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    protected void grdCSR_RowDataBound(object sender, GridViewRowEventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string strQuery = "";


        strQuery = "SELECT CSR_Duration_ID FROM CSR_Duration WHERE CSR_Duration='" + strQueryString_Period + "' ";


            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                CSR_Duration_ID = int.Parse(dr["CSR_Duration_ID"].ToString());
            }
            con.Close();
            com.Dispose();
            dr.Close();
            AirlineCode();
            if (lblairlinecode.Text != "360")
            {
                Insert_Approve_CSR();
            }
            else
            {
                Insert_Approve_CSR_Deccan();
            }
    }


    public void Insert_Approve_CSR()
    {
        SqlConnection con_First = new SqlConnection(strCon);
        try
        {
           
            con_First.Open();
            //string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND (csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "') ";

            //////string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,case when (a.gstAddress is null or a.gstAddress='') then AB.Agent_Address else a.GstAddress end as Agent_Address,A.Airline_Detail_ID, a.CSR_SNo FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND ((csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "') OR (csr_DATE<='" + TO_DATE + "'  AND Sales_type='CRDR' AND Approved_for_CSR=29))  order by AM.AGENT_NAME  ";
            string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID,a.CSR_SNo FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Airline_Detail_ID='" + str_AirlineDetailId + "' AND (csr_DATE BETWEEN '" + FROM_DATE + "' AND '" + TO_DATE + "')  AND (Approved_for_CSR=29 or Approved_for_CSR is null) order by AM.AGENT_NAME";

            com = new SqlCommand(SqlQuery, con_First);
            int COUNT = 1;
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {

                while (dr.Read())
                {

                    decimal TotComm = 0;
                    decimal TotDiscount = 0;
                    decimal TotFrAmount = 0;
                    decimal TotFrAmountCC = 0;
                    decimal EduChrg = 0;
                    decimal TotTds = 0;
                    decimal TotGstAmt = 0;
                    decimal Total = 0;
                    decimal GrandTotal = 0;
                    decimal Freight_Amount = 0;
                    decimal Total_DueCarrier = 0;
                    decimal TotTax = 0;
                    decimal Agent_Expenses = 0;
                    decimal Freight_Diff_Amount = 0;
                    decimal IATA_Commission = 0;
                    decimal Amount_Excluding_TDS = 0;
                    decimal LastTdsRate=0;
                    decimal LastSurcharge=0;
                    decimal LastEducation_Cess=0;
                    decimal TDS_Amount = 0;
                    //Gst
                    decimal TotCGST = 0;
                    decimal TotSGST = 0;
                    decimal TotIGST = 0;

                    decimal TotCGST_CRDR = 0;
                    decimal TotSGST_CRDR = 0;
                    decimal TotIGST_CRDR = 0;
                    decimal GST_Amount = 0;
                    decimal surCharge = 0;
                    decimal Amount_Including_TDS = 0;

                    decimal TotComm_CRDR = 0;
                    decimal TotDiscount_CRDR = 0;
                    decimal TotFrAmount_CRDR = 0;
                    decimal TotFrAmountCC_CRDR = 0;
                    decimal EduChrg_CRDR = 0;
                    decimal TotTds_CRDR = 0;
                    decimal TotGstAmt_CRDR = 0;
                    decimal Total_CRDR = 0;
                    decimal GrandTotal_CRDR = 0;
                    decimal Freight_Amount_CRDR = 0;
                    decimal Total_DueCarrier_CRDR = 0;
                    decimal TotTax_CRDR = 0;
                    decimal Agent_Expenses_CRDR = 0;
                    decimal Freight_Diff_Amount_CRDR = 0;
                    decimal IATA_Commission_CRDR = 0;
                    decimal Amount_Excluding_TDS_CRDR = 0;
                    decimal LastTdsRate_CRDR = 0;
                    decimal LastSurcharge_CRDR = 0;
                    decimal LastEducation_Cess_CRDR = 0;
                    decimal TDS_Amount_CRDR = 0;
                    decimal GST_Amount_CRDR = 0;
                    decimal surCharge_CRDR = 0;
                    decimal Amount_Including_TDS_CRDR = 0;
                    int Amount_Type_CRDR;
                   
                    string AGENT_ID = dr["AGENT_ID"].ToString();
                    string Agent_Name = dr["Agent_name"].ToString();
                    if (Agent_Name == "Apshan Logistics Pvt.Ltd.")
                    {
                    }
                    string Agent_Code = dr["Agent_Code"].ToString();
                    string Agent_Address = dr["Agent_Address"].ToString();
                    string CSR_SERIALNo = dr["CSR_SNo"].ToString();
                    long CSR_SNo = 0;
                    int GstInvNo = 0;
                    long CSR_SNo_CRDR = 0;
                    string CSR_No = dr["Agent_Code"].ToString() + "-" + lblairlinecode.Text + "-" + lblperiod.Text;
                    int Amount_Type;
                    string Sales_Type = "";
                    string Sales_Type_CRDR = "";
                    DateTime CSR_From = FROM_DATE;
                    DateTime CSR_To = TO_DATE;
                    string Entered_By = Session["EMailID"].ToString();
                    DateTime Entered_On = DateTime.Now;
                   
                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand com_csr = new SqlCommand();
                    if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/01/2017"))

                        com_csr = new SqlCommand("APPROVE_CSR_DETAILS", con1);
                    else
                    {
                        if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                        {
                            
                            com_csr = new SqlCommand("APPROVE_CSR_DETAILS_GST_KEIATA", con1);
                        }
                        else
                        {
                            com_csr = new SqlCommand("APPROVE_CSR_DETAILS_GST", con1);
                        }
                    }
                    com_csr.CommandType = CommandType.StoredProcedure;
                    com_csr.Parameters.AddWithValue("agent_id", AGENT_ID);
                    com_csr.Parameters.AddWithValue("CSR_SNo", CSR_SERIALNo);
                    com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
                    com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
                    com_csr.Parameters.AddWithValue("Airline_Detail_ID", str_AirlineDetailId);

                    SqlDataReader dr_csr = com_csr.ExecuteReader();
                    string VarDate = "07/31/2008";
                    string Mh_Priod = "08/15/2008";
                    while (dr_csr.Read())
                    {
                        if (dr_csr["Sales_Type"].ToString().Trim() == "INV")
                        {
                            // Gst Added

                            //Gst added
                            TotCGST += Math.Round(decimal.Parse(dr_csr["CGSTAmt"].ToString()), MidpointRounding.AwayFromZero);
                            TotSGST += Math.Round(decimal.Parse(dr_csr["SGSTAmt"].ToString()), MidpointRounding.AwayFromZero);
                            TotIGST += Math.Round(decimal.Parse(dr_csr["IGSTAmt"].ToString()), MidpointRounding.AwayFromZero);

                            Sales_Type = dr_csr["Sales_Type"].ToString().Trim();
                            CSR_SNo = long.Parse(dr_csr["csr_sno"].ToString());
                            GstInvNo = int.Parse(dr_csr["GstInvNo"].ToString());
                            Freight_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Total_DueCarrier += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);

                            Freight_Diff_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (FROM_DATE > DateTime.Parse(Mh_Priod))
                                {
                                    IATA_Commission += 0;
                                }
                                else
                                {
                                    IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (FROM_DATE > DateTime.Parse(VarDate))
                                {
                                    IATA_Commission += 0;
                                }
                                else
                                {
                                    IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                            
                            Amount_Excluding_TDS += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

                            if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                            {

                                if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    if ((FROM_DATE) > DateTime.Parse(VarDate))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -=0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                        //Gst
                                        //////TotGstAmt -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                        TotGstAmt -= Math.Round(TotCGST+TotSGST+TotIGST, MidpointRounding.AwayFromZero);
                                        surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                        
                                    }
                                }
                                else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -= 0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                        //Gst
                                        //////TotGstAmt -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                        TotGstAmt -= Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero);
                                        surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    //Gst
                                    ///////TotGstAmt -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                    TotGstAmt -= Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero);
                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }

                            }
                            else
                            {
                                if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    if ((FROM_DATE) > DateTime.Parse(VarDate))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                       /////// TotGstAmt += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                        TotGstAmt += Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero);
                                        surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                        //Gst
                                       ///// TotGstAmt += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                        TotGstAmt += Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero);
                                        surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    //////TotGstAmt += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                    TotGstAmt += Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero);
                                    surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }

                            }
                            LastTdsRate = decimal.Parse(dr_csr["tds"].ToString());
                            LastSurcharge = decimal.Parse(dr_csr["surcharge"].ToString());
                            LastEducation_Cess = decimal.Parse(dr_csr["Education_Cess"].ToString());

                            if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/16/2017"))
                            {
                                TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                                {
                                    TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);
                                }

                                else
                                {
                                    TDS_Amount = Math.Round((surCharge + EduChrg), MidpointRounding.AwayFromZero);
                                }
                            }
                            //Gst
                            GST_Amount = Math.Round((TotGstAmt), MidpointRounding.AwayFromZero);

                            string amountPP = null;
                            string amountCC = null;
                            if (dr_csr["Freight_type"].ToString() == "COLLECT")
                            {
                                amountPP = "0";
                                amountCC = dr_csr["Freight_Amount"].ToString();
                                TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                amountPP = dr_csr["Freight_Amount"].ToString();
                                amountCC = "0";
                                TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
                            }


                            TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(VarDate))
                                {
                                    TotComm += 0;
                                    TotDiscount += 0;
                                    Agent_Expenses += 0;
                                }
                                else
                                {
                                    TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                                {
                                    TotComm += 0;
                                    TotDiscount += 0;
                                    Agent_Expenses += 0;
                                }
                                else
                                {
                                    TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }

                            else
                            {
                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr_csr["Sales_Type"].ToString().Trim() == "CRDR")
                        {
                            //Gst added
                            //Gst added
                            TotCGST_CRDR += Math.Round(decimal.Parse(dr_csr["CGSTAmt"].ToString()), MidpointRounding.AwayFromZero);
                            TotSGST_CRDR += Math.Round(decimal.Parse(dr_csr["SGSTAmt"].ToString()), MidpointRounding.AwayFromZero);
                            TotIGST_CRDR += Math.Round(decimal.Parse(dr_csr["IGSTAmt"].ToString()), MidpointRounding.AwayFromZero);

                            Sales_Type_CRDR = dr_csr["Sales_Type"].ToString().Trim();
                            CSR_SNo_CRDR = long.Parse(dr_csr["csr_sno"].ToString());
                            GstInvNo = int.Parse(dr_csr["GstInvNo"].ToString());
                            Freight_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            Total_DueCarrier_CRDR += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Expenses_CRDR += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            Freight_Diff_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);


                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (FROM_DATE > DateTime.Parse(Mh_Priod))
                                {

                                    IATA_Commission_CRDR += 0;
                                }
                                else
                                {
                                    IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (FROM_DATE > DateTime.Parse(VarDate))
                                {
                                    IATA_Commission_CRDR += 0;
                                }
                                else
                                {
                                    IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                            Amount_Excluding_TDS_CRDR += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

                            if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                            {

                                TotTds_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                //Gst
                                /////TotGstAmt_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                TotGstAmt_CRDR -= Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero);
                                surCharge_CRDR -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg_CRDR -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                TotTds_CRDR += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                //Gst
                                //////TotGstAmt_CRDR += Math.Ceiling(decimal.Parse(dr_csr["GstAmt"].ToString()));
                                TotGstAmt_CRDR += Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero);
                                surCharge_CRDR += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg_CRDR += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                            }
                            LastTdsRate_CRDR = decimal.Parse(dr_csr["tds"].ToString());
                            LastSurcharge_CRDR = decimal.Parse(dr_csr["surcharge"].ToString());
                            LastEducation_Cess_CRDR = decimal.Parse(dr_csr["Education_Cess"].ToString());
                            if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/16/2017"))
                            {
                                TDS_Amount_CRDR = Math.Round((TotTds_CRDR + surCharge_CRDR + EduChrg_CRDR), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                                {
                                    TDS_Amount_CRDR = Math.Round((TotTds_CRDR + surCharge_CRDR + EduChrg_CRDR), MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    TDS_Amount_CRDR = Math.Round((surCharge_CRDR + EduChrg_CRDR), MidpointRounding.AwayFromZero);
                                }
                            }
                            //Gst
                            GST_Amount_CRDR = Math.Round((TotGstAmt_CRDR), MidpointRounding.AwayFromZero);
                            string amountPP_CRDR = null;
                            string amountCC_CRDR = null;
                            if (dr_csr["Freight_type"].ToString() == "COLLECT")
                            {
                                amountPP_CRDR = "0";
                                amountCC_CRDR = dr_csr["Freight_Amount"].ToString();
                                TotFrAmountCC_CRDR += Math.Round(decimal.Parse(amountCC_CRDR), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                amountPP_CRDR = dr_csr["Freight_Amount"].ToString();
                                amountCC_CRDR = "0";
                                TotFrAmount_CRDR += Math.Round(decimal.Parse(amountPP_CRDR), MidpointRounding.AwayFromZero);
                            }
                            TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                            TotComm_CRDR += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount_CRDR += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        }
                    }
                    Total = Math.Round(((TotFrAmount + Total_DueCarrier + TotTax) - (Agent_Expenses + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                    Decimal Debit_Surcharge = 0;
                    DataTable dt_Sur = dpw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + AGENT_ID + " AND AIRLINE_DETAIL_ID=" + str_AirlineDetailId + " AND (CSR_PERIOD>='"+ FROM_DATE + "' AND CSR_PERIOD<='"+ TO_DATE + "')");
                    if (dt_Sur.Rows.Count > 0)
                    {
                        Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/16/2017"))
                            EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * LastEducation_Cess / 100)), MidpointRounding.AwayFromZero);
                        else
                        {
                            if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                            {
                                EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * LastEducation_Cess / 100)), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                EduChrg = Math.Round((((surCharge + Debit_Surcharge) * LastEducation_Cess / 100)), MidpointRounding.AwayFromZero);
                            }
                        }
                        if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/16/2017"))
                        {
                            TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                            {
                                TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                TDS_Amount = Math.Round((surCharge + EduChrg), MidpointRounding.AwayFromZero);
                            }
                        }
                        //Gst
                       GST_Amount = Math.Round((TotGstAmt), MidpointRounding.AwayFromZero);


                    }
                    ////GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                    //Gst
                    if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/16/2017"))
                    {
                        GrandTotal = Math.Round((Total + TotTds + TotCGST + TotSGST + TotIGST + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                    }
                    else
                    {
                        if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                        {
                            GrandTotal = Math.Round((Total + TotTds + TotCGST + TotSGST + TotIGST + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            GrandTotal = Math.Round((Total + TotCGST + TotSGST + TotIGST + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                        }
                    }
                    Amount_Including_TDS = GrandTotal;
                    
                    if (Amount_Including_TDS < 0)
                    {
                        Amount_Type = 24;
                    }
                    else
                    {
                        Amount_Type = 23;
                    }

                    /************************/
                    Total_CRDR = Math.Round(((TotFrAmount_CRDR + Total_DueCarrier_CRDR + TotTax_CRDR) - (Agent_Expenses_CRDR + TotDiscount_CRDR + TotComm_CRDR)), MidpointRounding.AwayFromZero);


                    ///////GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                    //Gst
                    if (Convert.ToDateTime(TO_DATE) < Convert.ToDateTime("07/16/2017"))
                    {
                        GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + TotCGST_CRDR + TotSGST_CRDR + TotSGST_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                    }
                    else
                    {
                        if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                        GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + TotCGST_CRDR + TotSGST_CRDR + TotSGST_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                        else
                            GrandTotal_CRDR = Math.Round((Total_CRDR + TotCGST_CRDR + TotSGST_CRDR + TotSGST_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                    }

                    Amount_Including_TDS_CRDR = GrandTotal_CRDR;
                    if (Amount_Including_TDS_CRDR < 0)
                    {
                        Amount_Type_CRDR = 24;
                    }
                    else
                    {
                        Amount_Type_CRDR = 23;
                    }
                    using (con)
                    {
                        con = new SqlConnection(strCon);
                        con.Open();
                        SqlCommand strcom;
                        if (GrandTotal != 0)
                        {
                            strcom = new SqlCommand("INSERT_CSR", con);
                            strcom.CommandType = CommandType.StoredProcedure;
                            strcom.Parameters.AddWithValue("@COUNT", COUNT);
                            strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
                            strcom.Parameters.AddWithValue("@Airline_Detail_ID", str_AirlineDetailId);
                            strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                            strcom.Parameters.AddWithValue("@Sales_Type", "INV");
                            strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo);
                            strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                            strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                            strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                            strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                            strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount);
                            strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC);
                            strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount);
                            strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier);
                            strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses);
                            strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount);
                            strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission);
                            strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total);
                            strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate);
                            strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge);
                            strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess);
                            strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount) + Debit_Surcharge));
                            strcom.Parameters.AddWithValue("@Surcharge_Amount", (surCharge + Debit_Surcharge));
                            if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                            {
                                strcom.Parameters.AddWithValue("@Incentive_Amount", (TotDiscount));
                                
                            }
                            else
                            {
                                strcom.Parameters.AddWithValue("@Incentive_Amount", (TotDiscount + IATA_Commission));
                            }
                            ////strcom.Parameters.AddWithValue("@Incentive_Amount", (TotDiscount));
                            strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg);
                            strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS);
                            strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type);
                            strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                            strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                            strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                            strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
                            //Gst
                            strcom.Parameters.AddWithValue("@GstAmt", (Math.Round(TotCGST + TotSGST + TotIGST, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@CGSTAmt", (Math.Round(TotCGST, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@SGSTAmt", (Math.Round(TotSGST, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@IGSTAmt", (Math.Round(TotIGST, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@GstInvNo", GstInvNo);
                            strcom.ExecuteNonQuery();
                        }
                        /************************************/
                        if (GrandTotal_CRDR != 0)
                        {

                            strcom = new SqlCommand("INSERT_CSR", con);
                            strcom.CommandType = CommandType.StoredProcedure;
                            strcom.Parameters.AddWithValue("@COUNT", COUNT);
                            strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
                            strcom.Parameters.AddWithValue("@Airline_Detail_ID", str_AirlineDetailId);
                            strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                            strcom.Parameters.AddWithValue("@Sales_Type", "CRDR");
                            strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo_CRDR);
                            strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                            strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                            strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                            strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                            strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount_CRDR);
                            strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC_CRDR);
                            strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount_CRDR);
                            strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier_CRDR);
                            strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses_CRDR);
                            strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount_CRDR);
                            strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission_CRDR);
                            strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total_CRDR);
                            strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate_CRDR);
                            strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge_CRDR);
                            strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess_CRDR);
                            strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount_CRDR) + Debit_Surcharge));
                            strcom.Parameters.AddWithValue("@Surcharge_Amount", surCharge_CRDR);
                            if (str_AirlineDetailId == "158" || str_AirlineDetailId == "159" || str_AirlineDetailId == "160")
                            {
                                strcom.Parameters.AddWithValue("@Incentive_Amount", (TotDiscount_CRDR));

                            }
                            else
                            {
                                strcom.Parameters.AddWithValue("@Incentive_Amount", (TotDiscount_CRDR + IATA_Commission_CRDR));
                            }
                            
                            /////strcom.Parameters.AddWithValue("@Incentive_Amount", (TotDiscount_CRDR));
                            strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg_CRDR);
                            strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS_CRDR);
                            strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type_CRDR);
                            strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                            strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                            strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                            strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
                            //Gst
                            strcom.Parameters.AddWithValue("@GstAmt", (Math.Round(TotCGST_CRDR + TotSGST_CRDR + TotIGST_CRDR, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@CGSTAmt", (Math.Round(TotCGST_CRDR, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@SGSTAmt", (Math.Round(TotSGST_CRDR, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@IGSTAmt", (Math.Round(TotIGST_CRDR, MidpointRounding.AwayFromZero)));
                            strcom.Parameters.AddWithValue("@GstInvNo", GstInvNo);
                            strcom.ExecuteNonQuery();
                        }
                    }
                    COUNT++;
                    dr_csr.Dispose();
                    com_csr.Dispose();
                    con1.Close();
                }
                lblmsg.Visible = true;
                lblmsg.Text = "Approved SuccessFully";
                Button1.Visible = false;

            }
            con_First.Close();

        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con_First != null && con_First.State == ConnectionState.Open)
                con_First.Close();
        }
       

    }
   
    protected void grdCSR_RowCreated(object sender, GridViewRowEventArgs e)
    {
       
    }
    protected void grdCSR_RowDataBound1(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            
         
            double Amount =double.Parse(e.Row.Cells[2].Text);
            string SalesType = e.Row.Cells[3].Text;
            if (SalesType == "INV")
            {
              
            }
            else
            {
                //e.Row.BackColor = System.Drawing.Color.Gray;
                e.Row.ForeColor = System.Drawing.Color.Blue;
            }


            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
         

            if (Amount < 0)
            {

                e.Row.Cells[2].ForeColor = System.Drawing.Color.Red;
                double Payable_Amount = Math.Abs(Amount);
                e.Row.Cells[2].Text = Payable_Amount.ToString();
            }


            e.Row.Cells[3].Visible = false;
        }
    }
}
