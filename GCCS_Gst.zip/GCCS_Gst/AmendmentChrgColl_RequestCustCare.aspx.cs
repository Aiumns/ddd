using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//This page view only Cust Care login;

public partial class AmendmentChrgColl_RequestCustCare : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");

            if (!IsPostBack)
            {
                if (Session["groupid"].ToString() == "6")//AirPortStaff GroupID
                {
                    HyperLink1.Visible = false;
                }
                else
                {
                    HyperLink1.Visible = true;
                }

                ShowAirline();
            }
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int Result;
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("Collection_Charges_INSERT", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Agent_ID", DropDownList1.SelectedValue.ToString());
        com.Parameters.AddWithValue("@Airline_Detail_ID", ddlAirLine.SelectedValue.ToString());
        com.Parameters.AddWithValue("@AWBNo", ddlAwbno.SelectedValue.ToString());
        com.Parameters.AddWithValue("@Request", ddlRequest.SelectedValue.ToString());
        com.Parameters.AddWithValue("@Remarks", txtRemarks.Text);
        com.Parameters.AddWithValue("@AddedBy", Session["EMailID"].ToString());
        com.Parameters.AddWithValue("@AddedDate", DateTime.Today);
        com.Parameters.AddWithValue("@Status", "Requested");
        Result = com.ExecuteNonQuery();
        if (Result == 1)
        {
            lblMsg.Text = "Your Amendment request has been Added";

        }

    }

    protected void ShowAirline()
    {
        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirLine.Items.Add("-Select Airline Name-");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        DropDownList1.Items.Clear();
        ddlAwbno.Items.Clear();
        DateTime dt = DateTime.Parse(DateTime.Today.AddDays(-60).ToShortDateString());
        string query = "select  a.Agent_Name,l.agent_ID  from agent_master a inner join  Agent_Branch b on b.Agent_ID=A.Agent_ID inner join login_master l on l.Agent_ID= b.Agent_Branch_id where AirLine_Access like '%" + ddlAirLine.SelectedValue.ToString() + "%' order by a.agent_Name";
        DropDownList1.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand(query, con);
            SqlDataReader dr = com.ExecuteReader();
            DropDownList1.Items.Add("-Select Agent Name-");
            DropDownList1.Items[0].Value = "";
            if (dr.HasRows == true)
            {
                while (dr.Read())
                {
                    DropDownList1.Items.Add(new ListItem(dr["Agent_Name"].ToString(), dr["Agent_ID"].ToString()));
                }
            }
            else
            {
                lblMsg.Text = "Not found any agent.";
                return;
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

       
    }
    protected void ddlAwbno_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblMsg.Text = "";

        DateTime dt = DateTime.Parse(DateTime.Today.AddDays(-60).ToShortDateString());

        string query = "select b.airWayBill_no,b.city_ID from handOver a inner join Stock_Master b on a.Stock_id=b.Stock_id inner join Agent_Branch ab on ab.agent_id=b.agent_ID and ab.belongs_To_City=b.City_ID inner join agent_master am on am.Agent_ID=ab.agent_ID inner join Airline_Master  am1 on am1.airline_Code=substring(b.airWayBill_no,0,4)inner join Airline_Detail ad on ad.airline_ID=am1.airline_ID where ab.Agent_Branch_ID='" + DropDownList1.SelectedValue.ToString() + "' and ad.Airline_Detail_id='" + ddlAirLine.SelectedValue.ToString() + "' and  Handover_date >'" + dt + "'and b.Status not in (17,12)"; 
             
       
        ddlAwbno.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand(query, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAwbno.Items.Add("-Select AWBNo-");
            ddlAwbno.Items[0].Value = "";
            if (dr.HasRows == true)
            {
                while (dr.Read())
                {
                    ddlAwbno.Items.Add(new ListItem(dr["AirWayBill_No"].ToString(), dr["AirWayBill_No"].ToString()));
                }
            }
            else
            {
                lblMsg.Text = "Not found any AWBNo";
                return;
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (Session["groupid"].ToString() == "6")
            Response.Redirect("AmendmentChrgColl_Account1.aspx");
        else
            Response.Redirect("~/AmendmentChrgColl_CustCare.aspx");
    }
        
}
