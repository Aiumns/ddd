using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Change_AWB : System.Web.UI.Page
{

    SqlConnection con = null;
    SqlCommand com = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    int HANDOVER_ID;
    int BID;
    int Stock_id;
    string u_date = "";
    SqlTransaction trans = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {

            Label3.Visible = false;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search();
    }

    private void Search()
    {
        string flightDate = "";
        string Data = "";
        string airline = "";
        string aid = "";
        DataTable dt1 = dw.GetAllFromQuery("select BM.Booking_id as Booking_id,SM.Agent_id as Agent_id,AM.Agent_Name as Agent_Name,SM.Used_date as Used_date,FM.AIRLINE_DETAIL_ID ,AirWayBill_No,convert(varchar,BM.flight_date,103) as Flight_Date,FLIGHT_NO,DESTINATION_CODE,BM.Charged_Weight as Charged_Weight from Booking_Master BM inner join STOCK_MASTER SM ON BM.STOCK_ID=SM.STOCK_ID INNER JOIN FLIGHT_OPEN FO ON FO.FLIGHT_OPEN_ID=BM.FLIGHT_OPEN_ID INNER JOIN FLIGHT_MASTER FM ON FO.FLIGHT_ID=FM.FLIGHT_ID INNER JOIN DESTINATION_MASTER D ON BM.DESTINATION_ID=D.DESTINATION_ID inner join Agent_master AM on AM.agent_id=SM.Agent_id  where AirWayBill_No='" + txtawb.Text.Trim() + "' and BM.status=9");
        DataTable dt = dw.GetAllFromQuery("select HANDOVER_ID,BM.Booking_id as Booking_id,SM.Agent_id as Agent_id,AM.Agent_Name as Agent_Name,SM.Used_date as Used_date,FM.AIRLINE_DETAIL_ID ,AirWayBill_No,convert(varchar,H.flight_date,103) as Flight_Date,FLIGHT_NO,DESTINATION_CODE,H.Charged_Weight as Charged_Weight from HANDOVER H INNER JOIN STOCK_MASTER SM ON H.STOCK_ID=SM.STOCK_ID INNER JOIN FLIGHT_OPEN FO ON FO.FLIGHT_OPEN_ID=H.FLIGHT_OPEN_ID INNER JOIN FLIGHT_MASTER FM ON FO.FLIGHT_ID=FM.FLIGHT_ID INNER JOIN DESTINATION_MASTER D ON H.DESTINATION_ID=D.DESTINATION_ID inner join Agent_master AM on AM.agent_id=SM.Agent_id inner join booking_master BM on BM.Booking_id=H.Booking_ID  where AirWayBill_No='" + txtawb.Text.Trim() + "' and H.added_to_sales=14");
            if (dt.Rows.Count > 0)
            {
                Data = "<Table align=center width=100%><tr class=h1><td class=boldtext>Agent Name</td><td class=boldtext>Awb No.</td><td class=boldtext>Dstn.</td><td class=boldtext>Ch.Wt.</td><td class=boldtext>Current Flight No.</td><td class=boldtext>Current Flight Date.</td></tr>";
                foreach (DataRow drow in dt.Rows)
                {
                    Data += "<tr><td>" + drow["Agent_Name"].ToString() + "</td><td nowrap>" + drow["AirWayBill_No"].ToString() + "</td><td nowrap>" + drow["destination_code"].ToString() + "</td><td nowrap>" + drow["Charged_Weight"].ToString() + "</td><td nowrap>" + drow["flight_no"].ToString() + "</td><td nowrap>" + drow["flight_date"].ToString() + "</td></tr>";
                    flightDate = drow["flight_date"].ToString();
                    airline = drow["airline_detail_id"].ToString();
                    Hdn_Hand.Value = drow["HANDOVER_ID"].ToString();
                    hnd_bokking.Value = drow["Booking_id"].ToString();
                    aid = drow["Agent_id"].ToString();
                    hdused.Value = drow["Used_date"].ToString();

                }
                Data += "<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>";
                Label2.Text = Data;
                DataTable dt2 = dw.GetAllFromQuery("select stock_id,airwaybill_no from Stock_Master where Agent_id =" + aid + " and status=16 and substring(AirWayBill_No,1,3)='" + txtawb.Text.Trim().Substring(0, 3) + "' order by airwaybill_no");
                //DataTable dt2 = dw.GetAllFromQuery("select * from Stock_Master where Agent_id ="+aid+" and airline_detail_id=" + Convert.ToInt64(airline) + "");
                ddlawb.Items.Clear();
                foreach (DataRow Drow in dt2.Rows)
                {
                    ddlawb.Items.Add(new ListItem(Drow["Airwaybill_no"].ToString(), Drow["Stock_id"].ToString()));

                }
                Label3.Visible = false;
                Panel1.Visible = true;

            }
            else if (dt1.Rows.Count > 0)
            {
                Data = "<Table align=center width=100%><tr class=h1><td class=boldtext>Agent Name</td><td class=boldtext>Awb No.</td><td class=boldtext>Dstn.</td><td class=boldtext>Ch.Wt.</td><td class=boldtext>Current Flight No.</td><td class=boldtext>Current Flight Date.</td></tr>";
                foreach (DataRow drow in dt1.Rows)
                {
                    Data += "<tr><td>" + drow["Agent_Name"].ToString() + "</td><td nowrap>" + drow["AirWayBill_No"].ToString() + "</td><td nowrap>" + drow["destination_code"].ToString() + "</td><td nowrap>" + drow["Charged_Weight"].ToString() + "</td><td nowrap>" + drow["flight_no"].ToString() + "</td><td nowrap>" + drow["flight_date"].ToString() + "</td></tr>";
                    flightDate = drow["flight_date"].ToString();
                    airline = drow["airline_detail_id"].ToString();
                    Hdn_Hand.Value = null;
                    hnd_bokking.Value = drow["Booking_id"].ToString();
                    aid = drow["Agent_id"].ToString();
                    hdused.Value = drow["Used_date"].ToString();

                }
                Data += "<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>";
                Label2.Text = Data;
                DataTable dt2 = dw.GetAllFromQuery("select stock_id,airwaybill_no from Stock_Master where Agent_id =" + aid + " and status=16 and substring(AirWayBill_No,1,3)='" + txtawb.Text.Trim().Substring(0, 3) + "' order by airwaybill_no");
                //DataTable dt2 = dw.GetAllFromQuery("select * from Stock_Master where Agent_id ="+aid+" and airline_detail_id=" + Convert.ToInt64(airline) + "");
                ddlawb.Items.Clear();
                foreach (DataRow Drow in dt2.Rows)
                {
                    ddlawb.Items.Add(new ListItem(Drow["Airwaybill_no"].ToString(), Drow["Stock_id"].ToString()));

                }
                Label3.Visible = false;
                Panel1.Visible = true;

            }
            else
            {
                Label3.Visible = false;
                Panel1.Visible = false;
                Label2.Text = "";
                Label2.Text = "No Record Found";
                Label2.CssClass = "error";
                Label2.Visible = true;
                Label3.Visible = false;

            }
        
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Hdn_Hand .Value == "")
        {
            booking_Insert();
        }
        else
        {
            Handover_Insert();
        }

    }
    public void Handover_Insert()
    {
        string[] flight_date_no = ddlawb.SelectedItem.Text.Split('-');

        con = new SqlConnection(strCon);
        Stock_id = Convert.ToInt32(ddlawb.SelectedItem.Value);
        HANDOVER_ID = Convert.ToInt32(Hdn_Hand.Value);
        BID = Convert.ToInt32(hnd_bokking.Value);
        u_date = Convert.ToString(hdused.Value);
        try
        {
            con.Open();
            trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table

            //Update Stock Master
            string strupdate1 = "update stock_master  set status=10,used_date='" + u_date + "' where airwaybill_no='" + ddlawb.SelectedItem.Text + "'"; ;
            com = new SqlCommand(strupdate1, con, trans);
            com.ExecuteNonQuery();

            //Update Stock Master
            string strupdate = "update stock_master  set status=16,used_date=NULL where airwaybill_no='" + txtawb.Text.Trim() + "'"; ;
            com = new SqlCommand(strupdate, con, trans);
            com.ExecuteNonQuery();

            // Update Booking Master
            string up1 = "update  booking_master set Stock_id=" + Stock_id + " where Booking_ID=" + BID + ""; ;
            com = new SqlCommand(up1, con, trans);
            com.ExecuteNonQuery();
            // Update Handover
            string up2 = "update  handover set Stock_id=" + Stock_id + ",Booking_id=" + BID + " where Handover_ID='" + HANDOVER_ID + "'"; ;
            com = new SqlCommand(up2, con, trans);
            com.ExecuteNonQuery();
            trans.Commit();
            con.Close();
            Label3.Visible = true;
            Panel1.Visible = false;
            Label2.Text = "";
        }
        catch (SqlException se)
        {
            string err = se.Message;
            trans.Rollback();

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void booking_Insert()
    {
        string[] flight_date_no = ddlawb.SelectedItem.Text.Split('-');

        con = new SqlConnection(strCon);
        Stock_id = Convert.ToInt32(ddlawb.SelectedItem.Value);
        BID = Convert.ToInt32(hnd_bokking.Value);
        u_date = Convert.ToString(hdused.Value);
        try
        {
            con.Open();
            trans = con.BeginTransaction();  // Insert Value in Airline_Sector_Master table

            //Update Stock Master
            string strupdate1 = "update stock_master  set status=9,used_date='" + u_date + "' where airwaybill_no='" + ddlawb.SelectedItem.Text + "'"; ;
            com = new SqlCommand(strupdate1, con, trans);
            com.ExecuteNonQuery();

            //Update Stock Master
            string strupdate = "update stock_master  set status=16,used_date=NULL where airwaybill_no='" + txtawb.Text.Trim() + "'"; ;
            com = new SqlCommand(strupdate, con, trans);
            com.ExecuteNonQuery();

            // Update Booking Master
            string up1 = "update  booking_master set Stock_id=" + Stock_id + " where Booking_ID=" + BID + ""; ;
            com = new SqlCommand(up1, con, trans);
            com.ExecuteNonQuery();
            com.ExecuteNonQuery();
            trans.Commit();
            con.Close();
            Label3.Visible = true;
            Panel1.Visible = false;
            Label2.Text = "";
        }
        catch (SqlException se)
        {
            string err = se.Message;
            trans.Rollback();

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    
}
