using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CompWiseFrtReportShow : System.Web.UI.Page
{
     string table = null;
    DisplayWrap dw = new DisplayWrap();
    /// <summary>
    /// Make Connection From Web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            // ---- Fetch Data From Session ---
            string from_date = Session["from_date"].ToString();
            string to_date = Session["to_date"].ToString();
            string SelectDate1 = "", SelectDate2 = "";
            decimal freight_amt = 0, due_carr = 0;
            decimal  total_freight_amt = 0, total_due_carr = 0;
            string SelectDate = Session["SelectDate"].ToString();
            if (SelectDate.ToString() == "0")
            {
                SelectDate1 = "Awb_Date";
                SelectDate2 = "Awb Date";
            }
            else
            {
                SelectDate1 = "Flight_Date";
                SelectDate2 = "Flight Date";
            }
            DataTable dt = dw.GetAllFromQuery("select distinct AM.Agent_Name,AB.Agent_Address,sum(isnull(S.Freight_Amount,0)) as 'Freight_Amount',sum(isnull(S.Total_DueCarrier,0)) as 'Total_DueCarrier',AB.Pan_No,AB.Tan_No from Sales S inner join Agent_Master AM on S.Agent_ID=AM.Agent_ID inner join agent_branch AB on AB.Agent_id=AM.Agent_ID   where airline_detail_id in (" + Session["AID"].ToString() + ")  and " + SelectDate1 + " between '" + FormatDateMM(from_date) + "' and '" + FormatDateMM(to_date) + "' and Freight_Type='PREPAID' group by  AM.Agent_Name,AB.Agent_Address,AB.Pan_No,AB.Tan_No  order by AM.agent_name");
            if (dt.Rows.Count > 0)
            {
                Response.Write("<h5><p align=center >Freight Report <br>" + from_date + " - " + to_date + "</p></h5>");
                Response.Write("<table align=center width=100% border=1 cellspacing=0><tr class=h5><th colspan=8 align=center>" + Session["ATC"].ToString() + " (Based on " + SelectDate2 + ")</th></tr><tr class=h1><th>Agent/Party</th><th>Party Address</th> <th>PANNO</th><th>TANNO</th><th>Total Freight</th><th>Due Carrier</th></tr>");
                foreach (DataRow drow in dt.Rows)
                {
                 
                    freight_amt = Math.Round(decimal.Parse(drow["Freight_Amount"].ToString()),MidpointRounding.AwayFromZero);
                    total_freight_amt = total_freight_amt + freight_amt;
                    
                    due_carr = Math.Round(decimal.Parse(drow["Total_DueCarrier"].ToString()),MidpointRounding.AwayFromZero);
                    total_due_carr = total_due_carr + due_carr;

                    Response.Write("<tr><td class=text>&nbsp;" + drow["Agent_Name"].ToString() + "</td><td class=text>&nbsp;" + drow["Agent_Address"].ToString() + "</td><td class=text>&nbsp;" + drow["Pan_No"].ToString() + "</td><td class=text>&nbsp;" + drow["tan_No"].ToString() + "</td><td align=right class=text>" + freight_amt + "</td><td align=right class=text>" + due_carr + "</td></tr>");
                }
                Response.Write("<tr><td colspan =2></td><td align=right class=boldtext>" + total_freight_amt + "</td><td colspan =2></td><td align=right class=boldtext>" + total_due_carr + "</td></tr>");


            }

        }
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
