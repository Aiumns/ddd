﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AgentStanderedDeal : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["D"] != null)
                {
                    UpdateGDeal.Attributes.Add("onclick", "return CheckEmpty();");
                    ShowAirline();
                    fillDest();
                    addGDeal.Visible = false;
                    UpdateGDeal.Visible = true;
                    btnCancel.Visible = true;
                    CancelGDeal.Visible = false;

                    fillUpdateDate();

                }
                else
                {
                    addGDeal.Attributes.Add("onclick", "return CheckEmpty();");
                    ShowAirline();
                    fillDest();
                    addGDeal.Visible = true;
                    UpdateGDeal.Visible = false;
                    btnCancel.Visible = false;
                    CancelGDeal.Visible = true;

                }
            }
        }

    }
    protected void addGDeal_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("insert into AgentGenricDeal(Airline_Detail_ID,Agent_Id,Destination_ID,ChWt_From,ChWt_To,Spot_Rate,Commission,Special_Commodity_Incentive,Entered_By,Entered_On) values(@Airline_Detail_ID,@Agent_Id,@Destination_ID,@ChWt_From,@ChWt_To,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Entered_By,@Entered_On)", con);
            com.Parameters.AddWithValue("@Airline_Detail_ID", int.Parse(ddlAirlineDetail.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@Destination_ID", Int64.Parse(ddlDest.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@Agent_Id", Int64.Parse(ddlAgentName.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@ChWt_From", decimal.Parse(txtChWtFrom.Text));
            com.Parameters.AddWithValue("@ChWt_To", decimal.Parse(txtChWtTo.Text));
            com.Parameters.AddWithValue("@Spot_Rate", decimal.Parse(txtSpotRate.Text == "" ? "0" : txtSpotRate.Text));
            com.Parameters.AddWithValue("@Commission", decimal.Parse(txtComm.Text == "" ? "0" : txtComm.Text));
            com.Parameters.AddWithValue("@Special_Commodity_Incentive", decimal.Parse(txtscIncentive.Text == "" ? "0" : txtscIncentive.Text));
            com.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());
            com.Parameters.AddWithValue("@Entered_On", DateTime.Today);
            com.ExecuteNonQuery();
            com.Dispose();
            con.Close();
            Response.Redirect("ShowAgentStandredDeal.aspx");
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void ShowAirline()
    {

        ddlAirlineDetail.Items.Clear();

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineDetail.Items.Add("Select airline name");
            ddlAirlineDetail.Items[0].Value = "";
            while (dr.Read())
            {
                int s = int.Parse(dr["Airline_Detail_ID"].ToString());
                ddlAirlineDetail.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void fillDest()
    {
        ddlDest.Items.Clear();

        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select destination_id,destination_code from destination_master order by destination_code", con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlDest.Items.Add("Select Destination");
            //ddlDest.Items[0].Value = "";
            ddlDest.Items.Add("All Destination");
            ddlDest.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlDest.Items.Add(new ListItem(dr["destination_code"].ToString(), dr["destination_id"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }

    protected void CancelGDeal_Click(object sender, EventArgs e)
    {
        Response.Redirect("GenericDeals.aspx");

    }
    protected void UpdateGDeal_Click(object sender, EventArgs e)
    {
        move_to_history();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("update  AgentGenricDeal set Airline_Detail_ID=@Airline_Detail_ID,Agent_Id=@Agent_Id,Destination_ID=@Destination_ID,ChWt_From=@ChWt_From, ChWt_To=@ChWt_To,Spot_Rate=@Spot_Rate,Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Entered_By=@Entered_By,Entered_On=@Entered_On where deal_id=@deal_id", con);

            com.Parameters.AddWithValue("@Airline_Detail_ID", int.Parse(ddlAirlineDetail.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@Agent_Id", int.Parse(ddlAgentName.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@Destination_ID", Int64.Parse(ddlDest.SelectedValue.ToString()));
            com.Parameters.AddWithValue("@ChWt_From", decimal.Parse(txtChWtFrom.Text));
            com.Parameters.AddWithValue("@ChWt_To", decimal.Parse(txtChWtTo.Text));
            com.Parameters.AddWithValue("@Spot_Rate", decimal.Parse(txtSpotRate.Text == "" ? "0" : txtSpotRate.Text));
            com.Parameters.AddWithValue("@Commission", decimal.Parse(txtComm.Text == "" ? "0" : txtComm.Text));
            com.Parameters.AddWithValue("@Special_Commodity_Incentive", decimal.Parse(txtscIncentive.Text == "" ? "0" : txtscIncentive.Text));
            com.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());
            com.Parameters.AddWithValue("@Entered_On", DateTime.Today);
            com.Parameters.AddWithValue("@deal_id", int.Parse(Request.QueryString["d"].ToString()));

            com.ExecuteNonQuery();
            com.Dispose();
            con.Close();
            Response.Redirect("ShowAgentStandredDeal.aspx");
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void fillUpdateDate()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select Airline_Detail_ID,Agent_Id,Destination_ID,ChWt_From,ChWt_To,Spot_Rate,Commission,Special_Commodity_Incentive from AgentGenricDeal where Deal_id=" + Request.QueryString["d"].ToString() + " ", con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                //ddlcompanyname.SelectedIndex = ddlcompanyname.Items.IndexOf(ddlcompanyname.Items.FindByValue(Company_Id));
                //ddlStatus.SelectedIndex = ddlStatus.Items.IndexOf(ddlStatus.Items.FindByValue(Status_ID));

                ddlAirlineDetail.SelectedIndex = ddlAirlineDetail.Items.IndexOf(ddlAirlineDetail.Items.FindByValue(dr["Airline_Detail_ID"].ToString()));
                LoadAgentName();
                ddlAgentName.SelectedValue = dr["Agent_Id"].ToString();
                ddlDest.SelectedIndex = ddlDest.Items.IndexOf(ddlDest.Items.FindByValue(dr["Destination_ID"].ToString()));
                txtChWtFrom.Text = dr["ChWt_From"].ToString();
                txtChWtTo.Text = dr["ChWt_To"].ToString();
                txtComm.Text = dr["Commission"].ToString();
                txtSpotRate.Text = dr["Spot_Rate"].ToString();
                txtscIncentive.Text = dr["Special_Commodity_Incentive"].ToString();

            }
            com.Dispose();
            con.Close();

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowAgentStandredDeal.aspx");
    }
    public void LoadAgentName()
    {
        try
        {
            string strAgent = "SELECT am.Agent_ID,Agent_Name,ad.Airline_Detail_ID FROM agent_master Am INNER JOIN agent_branch ab ON am.agent_id=ab.agent_id INNER JOIN dbo.City_Master cm ON ab.belongs_to_city=cm.city_id INNER JOIN airline_detail ad ON ad.belongs_to_city=ab.belongs_to_city WHERE ad.Airline_Detail_ID=" + ddlAirlineDetail.SelectedValue +" order by Agent_Name asc";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmd = null;
            cmd = new SqlCommand(strAgent, con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlAgentName.Items.Insert(0, "- -Select- -");
            ddlAgentName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAgentName.Items.Add(new ListItem(dr["Agent_Name"].ToString(), dr["Agent_ID"].ToString()));

            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void ddlAirlineDetail_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadAgentName();
    }
    public void move_to_history()
    {
        SqlCommand cmd = null;
        con = new SqlConnection(strCon);
        con.Open();

        SqlTransaction trans1 = con.BeginTransaction();
        string Query = " insert into AgentGenricDeal_History select Airline_Detail_ID ,Agent_Id ,Destination_ID ,ChWt_From ,ChWt_To ,Spot_Rate ,Commission ,Special_Commodity_Incentive ,Entered_By ,          Entered_On from AgentGenricDeal where Deal_id=" + Request.QueryString["d"].ToString() + "";
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.Transaction = trans1;
        cmd.CommandText = Query;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        
        //Query = " Delete from GD_Dest_Master where Airline_Detail_ID=" + ddlAirline.SelectedValue + "";
        //cmd = new SqlCommand();
        //cmd.Connection = con;
        //cmd.Transaction = trans1;
        //cmd.CommandText = Query;
        //cmd.ExecuteNonQuery();
        //cmd.Dispose();
        
        trans1.Commit();
        con.Close();
       
    }
}
