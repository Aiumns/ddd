using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class add_shipmentname : System.Web.UI.Page
{
    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Add Shipment Master</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>oct 17</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription>insert all value in Shipment_master & update</changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion
    #region ConnectionString
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  //connection string
#endregion
    #region Global Variables Declaration
    SqlConnection con;
    public string strLen = "";
    SqlCommand cmd;
    SqlDataReader rdr;
    string shipmentid = "";
    string id = "";
    string mm = "";
    #endregion


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnadd.Attributes.Add("onclick", "return CheckEmpty()");
            btnupdate.Enabled = false;
            btnupdate.Visible = false;
            #region value on querystring and pageload Section
            if (!Page.IsPostBack && Request.QueryString["shipmentid"] != null)
            {
                btnupdate.Attributes.Add("onclick", "return CheckEmpty()");

                btnadd.Visible = false;
                btnadd.Enabled = false;
                //btnreset.Visible = false;
                //btnreset.Enabled = false;


                lbladd.Text = "Edit Shipment Name";
                btnupdate.Visible = true;
                btnupdate.Enabled = true;


                shipmentid = Convert.ToString(Request.QueryString["shipmentid"]);


                coverdata(); // function for cover data for editable mode    




            }
            else
            {
                lbladd.Text = "Add Shipment";
                btnadd.Visible = true;
                btnadd.Enabled = true;
                btnupdate.Visible = false;
                btnupdate.Enabled = false;

            }
            #endregion

        }
    }
    #region insert on add click
    protected void btnadd_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "insert into db_owner.Shipment_Master(Shipment_Name) values(@Shipment_Name)";
        cmd.Parameters.Add("@Shipment_Name", SqlDbType.VarChar, 50).Value = txtshipment.Text;
        con.Open();
        try
        {
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("shipment_details.aspx");

        }
        catch (SqlException ee)
        {
            if (ee.Number == 2627)
            {
                lblerr.Visible = true;
                lblerr.Text = " Shipment Name already exists for  " + txtshipment.Text.Trim();
                txtshipment.Text = null;

            }
            else
            {
                lblerr.Visible = true;
                lblerr.Text = ee.Message;
            }
        }
        finally// this block added bt hn mishra
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
        

    }
    #endregion
    #region to taken value(shipment name) for editable mode
    public void coverdata()
    {
        id = Convert.ToString(Request.QueryString["shipmentid"]);
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;       
        cmd.CommandText = "select Shipment_ID,Shipment_Name from db_owner.Shipment_Master  where Shipment_ID='" + id + "'";
        cmd.Connection.Open();
        rdr = cmd.ExecuteReader();
        rdr.Read();
        txtshipment.Text = rdr["Shipment_Name"].ToString();
        cmd.Connection.Close();//Add by hn mishra
        //con.Close();
    }
    #endregion

    #region updataion on update click
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        mm = Convert.ToString(Request.QueryString["shipmentid"]);
        con = new SqlConnection(strCon);
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "update db_owner.Shipment_Master set Shipment_Name=@Shipment_Name where Shipment_ID='" + mm + "'";
        cmd.Parameters.Add("@Shipment_Name", SqlDbType.VarChar, 50).Value = txtshipment.Text;
        con.Open();
        try
        {

            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("shipment_details.aspx");


        }
        catch (SqlException aa)
        {
            if (aa.Number == 2627)
            {
                lblerr.Visible = true;
                lblerr.Text = " Shipment Name " + txtshipment.Text.Trim() + " already Exists";
                btnadd.Visible = false;
                btnupdate.Visible = true;
                btnupdate.Enabled = true;
                lbladd.Text = "Edit Shipment";

            }
            else
            {
                Response.Write("sql error is" + aa.Message);
            }
        }
        finally //add by hn mishra
        {

            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
      
       
    }
    #endregion
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("shipment_details.aspx");
    }
}
