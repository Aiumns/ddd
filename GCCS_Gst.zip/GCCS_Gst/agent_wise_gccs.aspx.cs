using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class agent_wise_gccs : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        //Label2.Text += "<br><font size=7px>From : 01/04/2008 -  To :" + DateTime.Now.ToString("dd/MM/yyyy")+"</font>";  
        Label3.Text = "From : 01-Apr-2008 -  To :" +DateTime .Now.ToString("dd-MMM-yyyy");  
        decimal total_gccp=0;
        string Tables = "";
        string toatl_Query = "";
        decimal Bonus = 0;
        decimal Total_Gcrp = 0;
        string City_Query = "select distinct city_master.city_code from  sales s inner join airline_detail ad on ad.airline_detail_id=s.airline_detail_id inner join airline_master am on ad.airline_id=am.airline_id inner join  city_master on ad.belongs_to_city=city_master.city_id where awb_date between '04/01/2008' and getdate() and airline_code<> 023  order by city_code ";

        DataTable dt_city = dw.GetAllFromQuery(City_Query);

        foreach (DataRow dr_city in dt_city.Rows)
        {
            
            string Query = @"select distinct s.airline_detail_id,airline_name,airline_code,airline_text_code,city_master.city_code from  sales s inner join airline_detail ad on ad.airline_detail_id=s.airline_detail_id inner join airline_master am on ad.airline_id=am.airline_id inner join
 city_master on ad.belongs_to_city=city_master.city_id where awb_date between '04/01/2008' and getdate() and airline_code<> 023 and  city_master.city_code='" + dr_city["city_code"].ToString() + "' order by city_code ";

            DataTable dt = dw.GetAllFromQuery(Query);

            string Query1 = "select distinct agent_master.agent_name from sales inner join agent_master on sales.agent_id=agent_master.agent_id  inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where awb_date between '04/01/2008' and getdate() and airline_code<> 023 and  city_code='" + dr_city["city_code"].ToString() + "'  order by agent_name";

            DataTable dt_agent = dw.GetAllFromQuery(Query1);


            Tables += "<table width=100% border=0 cellpadding=0 cellspacing=0 >";
            Tables += "<tr class=h1><td class=boldtext align=center><font size='2'>AGENT NAME.</font>";
            foreach (DataRow drow in dt.Rows)
            {
                Tables += "<td class=boldtext align=center nowrap><font size='2'>";
                Tables += drow["airline_text_code"].ToString() + " - " + drow["city_code"].ToString();
                Tables += "</font></td>";
            }
            Tables += "<td class=boldtext align=center><font size='2'>Total</font></td><td class=boldtext align=center><table width=100%><tr class=h1 boldtext><td class=boldtext align=center>&nbsp;&nbsp;&nbsp;GCRP&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr></table></td></tr>";
            //<td align=right class=boldtext>&nbsp;&nbsp;&nbsp;&nbsp;BONUS</td><td class=boldtext align=right>&nbsp;&nbsp;&nbsp;Total GCRP</td>
            Tables += "<tr><td valign=top>";
            Tables += "<table width=100% >";
            int row = 0;
            foreach (DataRow dr in dt_agent.Rows)
            {
                if ((row % 2) == 0)
                {
                    Tables += "<tr bgcolor='#F1F1F1'><td nowrap class=boldtext>" + dr["agent_name"].ToString() + "</td></tr>";
                }
                else
                {
                    Tables += "<tr bgcolor='#c0c0c0'><td nowrap class=boldtext>" + dr["agent_name"].ToString() + "</td></tr>";
                }
                row = row + 1;
            }
            Tables += "<tr class=h1 boldtext ><td align=right><font size='2'>Total</font></td></td></tr>";
            Tables += "</table>";
            Tables += "</td>";

            row = 0;
            for (int i = 0; i < dt.Rows.Count; ++i)
            {
                row = 0;
                Tables += "<td valign=top><table width=100%>";
                foreach (DataRow drow2 in dt_agent.Rows)
                {
                    string Query3 = "select  agent_master.agent_name,sum(charged_weight) as charged_weight from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where airline_detail.airline_detail_id=" + Convert.ToInt64(dt.Rows[i]["airline_detail_id"].ToString()) + "  and agent_name='" + drow2["agent_name"].ToString() + "' and awb_date between '04/01/2008' and getdate()  and airline_code<> 023 and  city_code='" + dr_city["city_code"].ToString() + "' group by agent_name order by agent_name";
                    DataTable dt_chwt = dw.GetAllFromQuery(Query3);

                    if (dt_chwt.Rows.Count > 0)
                    {

                        if ((row % 2) == 0)
                        {
                            Tables += "<tr bgcolor='#F1F1F1'><td align=right class=text>" + dt_chwt.Rows[0]["charged_weight"].ToString() + "</td></tr>";
                        }
                        else
                        {
                            Tables += "<tr bgcolor='#c0c0c0'><td align=right class=text>" + dt_chwt.Rows[0]["charged_weight"].ToString() + "</td></tr>";
                        }
                    }
                    else
                    {
                        if ((row % 2) == 0)
                        {
                            Tables += "<tr bgcolor='#F1F1F1' class=text><td align=right>0.00</td></tr>";
                        }
                        else
                        {
                            Tables += "<tr bgcolor='#c0c0c0' class=text><td align=right>0.00</td></tr>";

                        }
                    }
                    row = row + 1;
                }

                Tables += "</table></td>";
            }
            DataTable dt_total = dw.GetAllFromQuery("select  agent_master.agent_name,sum(charged_weight) as charged_weight from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where awb_date between '04/01/2008' and getdate()  and airline_code<> 023 and  city_code='" + dr_city["city_code"].ToString() + "' group by agent_name order by agent_name ");
            Tables += "<td valign=top><table width=100%>";
            row = 0;
            foreach (DataRow dro in dt_total.Rows)
            {

                if ((row % 2) == 0)
                {
                    Tables += "<tr bgcolor='#F1F1F1'><td align=right class=text>" + dro["charged_weight"].ToString() + "</td></tr>";
                }
                else
                {
                    Tables += "<tr  bgcolor='#c0c0c0'><td align=right class=text>" + dro["charged_weight"].ToString() + "</td></tr>";
                }

                row = row + 1;
            }

            toatl_Query = "select  sum(charged_weight) as charged_weight from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where awb_date between '04/01/2008' and getdate()  and airline_code<> 023 and  city_code='" + dr_city["city_code"].ToString() + "'";

            DataTable dt_to = dw.GetAllFromQuery(toatl_Query );

            Tables += "<tr class=h1 ><td align=right class=h1 boldtext><strong>" + Math.Round(Convert.ToDecimal(dt_to.Rows[0]["charged_weight"].ToString())) + "</strong></td></tr>";

            Tables += "</table></td>";

            DataTable dt_Gcpp = dw.GetAllFromQuery("select  agent_master.agent_name,sum(charged_weight) as charged_weight from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where awb_date between '04/01/2008' and getdate()  and airline_code<> 023 and  city_code='" + dr_city["city_code"].ToString() + "' group by agent_name order by agent_name");
            Tables += "<td valign=top><table width=100%>";
            row = 0;
            foreach (DataRow droGc in dt_Gcpp.Rows)
            {

                if ((row % 2) == 0)
                {

                    Tables += "<tr bgcolor='#F1F1F1' ><td align=right class=boldtext>" + Math.Round(Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) + "&nbsp;</td>";


                    if (dr_city["city_code"].ToString()=="DEL")
                    {
                        if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 0 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 10000)
                         {
                             Bonus = 0;
                          //   Tables += "<td align=right class=boldtext>0</td>";
                             Bonus = Math.Round(Bonus / 100,MidpointRounding.AwayFromZero );
                          //   Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString())/100);
                          //   Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp,MidpointRounding.AwayFromZero) + "</td>";
                         }
                         else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 10001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 15000)
                         {

                             Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString())/100)* 25;
                             Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           //  Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           //  Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           //  Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                         }
                         else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 15001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 20000)
                         {
                             Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 30;
                             Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           //  Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           //  Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                         }
                         else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 20001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 30000)
                         {
                             Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 35;
                             Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           //  Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           //  Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           //  Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                         }
                         else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 30000)
                         {
                             Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 50;
                             Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           //  Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                            // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                         }
                    }
                    else
                    {
                        if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 0 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 10000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 0;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                            //Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 10001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 15000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 25;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           // Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 15001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 25000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 30;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 25001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 35000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 35;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                            //Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 35000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 50;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }

                    }
 Tables += "</tr>"; 

                }
                else
                {
                    Tables += "<tr bgcolor='#c0c0c0'><td align=right class=boldtext>" + Math.Round(Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) + "&nbsp;</td>";


                    if (dr_city["city_code"].ToString() == "DEL")
                    {
                        if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 0 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 10000)
                        {
                            Bonus = 0;
                           // Tables += "<td align=right class=boldtext>0</td>";

                          //  Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 10001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 15000)
                        {

                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 25;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            //Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 15001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 20000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 30;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            //Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                            //Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 20001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 30000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 35;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           // Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            //Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 30000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 50;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           // Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            //Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }
                    }
                    else
                    {
                        if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 0 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 10000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 0;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                            //Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 10001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 15000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 25;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            //Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                            //Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 15001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 25000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 30;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                            //Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 25001 && Convert.ToDecimal(droGc["charged_weight"].ToString()) < 35000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 35;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                           // Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";
                        }
                        else if (Convert.ToDecimal(droGc["charged_weight"].ToString()) > 35000)
                        {
                            Bonus = (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100) * 50;
                            Bonus = Math.Round(Bonus / 100, MidpointRounding.AwayFromZero);
                            //Tables += "<td align=right class=boldtext>" + Bonus + "&nbsp;</td>";
                           // Total_Gcrp = Bonus + (Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                           // Tables += "<td align=right class=boldtext>" + Math.Round(Total_Gcrp, MidpointRounding.AwayFromZero) + "</td>";

                        }

                    }
                    Tables += "</tr>"; 
                }
                total_gccp = total_gccp + Math.Round(Convert.ToDecimal(droGc["charged_weight"].ToString()) / 100);
                row = row + 1;
            }
            // Tables += "<tr bgcolor='#DDAEDF'><td align=right>" +total_gccp  + "&nbsp;</td></tr>";

            decimal tota_GcrP = Convert.ToDecimal(dt_to.Rows[0]["charged_weight"].ToString()) / 100;

            Tables += "<tr class=h1 ><td align=right class=h1 boldtext><strong>" + Math.Round(tota_GcrP) + "</strong></td></tr>";
            Tables += "</table></td></tr>";

            Tables += "</table>";
            Tables += "<table width=100%><tr><td>&nbsp;</td></tr></table>";
        }
        Label2.Text = Tables;

    }
}
