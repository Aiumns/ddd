using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class Agent_Deccan_Report : System.Web.UI.Page
{
    public string page_pop = "";
    string agentName = null;
    string tableAll = "", comName = null;
    string massage = null;
    string city_id = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {

            Response.Redirect("./Login.aspx");
        }
        string[] airline_name_city_text = Session["airline_name"].ToString().Split('-');
        string airline_name_city_value = Session["airline_value"].ToString();
        string[] agent_selected_id = Session["Agent_List_value"].ToString().Split('~');
        string[] agent_selected_name = Session["Agent_list_Text"].ToString().Split('~');
        string from_date = Session["from_date"].ToString();
        string to_date = Session["to_date"].ToString();
        string rdbtn = Session["rdbtn1"].ToString();
        string csrFooter = Session["csr_footer"].ToString();
        string comAdd = null;
        string airline = "A/C " + airline_name_city_text[0].ToUpper().ToString();
        string agnetID = "";
        string approveCsr = checkApprove(from_date, to_date);       
        //START-----------------------CACCULATE THE SERVICE TAX BASED ON AIRLINE WITH ----------------------    
        decimal s_tax = 0;
        DataTable dt_stax = dw.GetAllFromQuery("select isnull(service_tax,10.30) as 'service_tax' from fix_charges where airline_detail_id=" + airline_name_city_value);
        s_tax = Convert.ToDecimal(dt_stax.Rows[0]["service_tax"].ToString());
       //s_tax = 0;
        //-------------------END OF SERVICE TAX CALCULATION ----------------------------------
        //------------END VARIABLES HERE -----------------------------------------

        if (Session["groupid"].ToString() != "5")
        {

            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //------------DECLARE VARIABLES HERE -----------------------------------------
                string frt_type = null;
                string pr_rem_pp = null;
                //Int64 count = 0;
                decimal sid_pp = 0;
                //decimal pcs;
                decimal vol_wt_pp = 0;
                decimal gr_wt_pp = 0;
                decimal ch_wt_pp = 0; decimal total_ch_wt_pp = 0;
                decimal publish_rate_pp = 0;
                decimal pr_rate_pp = 0;
                decimal pr_spot_rate_pp = 0;
                decimal pr_min_amt_pp = 0;
                decimal pr_amount_pp = 0;
                decimal pr_spcl_amount_pp = 0;
                decimal freight_pp = 0; decimal total_freight_pp = 0;
                decimal freight_cc = 0; decimal total_freight_cc = 0;
                int pr_min_status_pp = 0;
                int ag_min_status_pp = 0;
                decimal fsc_pp = 0; decimal total_fsc_pp = 0;
                decimal wsc_pp = 0; decimal total_wsc_pp = 0;
                decimal awbfee_pp = 0; decimal total_awbfee_pp = 0;
                decimal dis_chg_pp = 0;
                decimal aci_fee_pp = 0;
                decimal other_chg_pp = 0; decimal total_other_chg_pp = 0;
                decimal due_carr_pp = 0;
                decimal awb_f_pp = 0;
                decimal gsa_comm_rate = 0;
                decimal net_net_rate_pp = 0;
                decimal net_net_frt_pp = 0; decimal total_net_net_frt_pp = 0;
                decimal xray_chg_pp = 0; decimal total_xray_chg_pp = 0;
                decimal Total_Due_PP_row = 0; decimal total_Total_Due_PP_row = 0;
                decimal other_due_chg_pp = 0;
                decimal status_void_pp = 0;
                decimal col_13_pp = 0; decimal total_col_13_pp = 0;
                decimal col_14_pp = 0; decimal total_col_14_pp = 0;
                decimal col_15_pp = 0; decimal total_col_15_pp = 0;
                decimal col_16_pp = 0; decimal total_col_16_pp = 0;
                decimal due_agent_pp = 0; decimal total_due_agent_pp = 0;
                decimal col_24_pp = 0; decimal total_col_24_pp = 0;
                decimal col_25_pp = 0; decimal total_col_25_pp = 0;
                decimal col_26_pp = 0; decimal total_col_26_pp = 0;
                decimal col_27_pp = 0; decimal total_col_27_pp = 0;
                decimal col_28_pp = 0; decimal total_col_28_pp = 0;
                string table = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (flight_date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (flight_date >='" + from_date + "'  and  flight_date<='" + to_date + "')  and airline_detail_id=" + airline_name_city_value + " ";

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        comName = dr["company_name"].ToString();

                        table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""3"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""2"">Cargo Sales Report </font><br><font size=""3"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table>";
                    }
                    com.Dispose();
                    dr.Dispose();
                    table += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0><tr class=h5><th nowrap rowspan=2>AWBNo</th><th nowrap rowspan=2>Date</th><th nowrap rowspan=2>Origin</th><th nowrap rowspan=2>Dest</th><th nowrap rowspan=2>PP<br>/CC</th><th nowrap rowspan=2>VolWt</th><th nowrap rowspan=2>GrWt</th><th nowrap rowspan=2>ChgWt</th><th nowrap rowspan=2>AWB<br>Rack<br>Rate</th><th nowrap rowspan=2>Net Net<br>Rate</th><th nowrap colspan=2>Frt on<br>Rack<br>Rates</th><th nowrap rowspan=2>Awb.<br>Frt on<br>Net Net<br>Rates</th><th nowrap rowspan=2>(Comm +<br>Discount)</th><th nowrap rowspan=2>Comm<br>(5% of<br>Frt.)</th><th nowrap rowspan=2>Discount</th><th nowrap rowspan=2>Total<br>Due<br>Carrier</th><th nowrap rowspan=2>Due<br>Agent<br>(CC)</th><th nowrap rowspan=2>Net<br>Rec.ble/<br>Payable<br>Before<br>TDS</th><th nowrap rowspan=2>TDS Ded.<br>On Frt./<br>Due Carr.</th><th nowrap rowspan=2>TDS<br>on<br>Comm+<br>Disc.</th><th nowrap rowspan=2>TDS<br>on<br>Due<br>Agent<br>(CC)</th><th nowrap rowspan=2>Total<br>Rec.ble<br>/Payable</th><th nowrap rowspan=2>Remarks</th></tr><tr><th nowrap>PP</th><th nowrap>CC</th></tr>";
                    com = new SqlCommand("csr_deccan", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        //count = count + 1;
                        sid_pp = Convert.ToDecimal(dr["Sales_ID"].ToString());
                        awb_f_pp = Convert.ToDecimal(dr["awb_f"].ToString());
                        //pcs = Convert.ToDecimal(dr["No_of_Packages"].ToString());
                        vol_wt_pp = Convert.ToDecimal(dr["volume_weight"].ToString());
                        gr_wt_pp = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                        ch_wt_pp = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                        publish_rate_pp = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                        pr_rate_pp = Convert.ToDecimal(dr["Principle_Rate"].ToString());
                        pr_spot_rate_pp = Convert.ToDecimal(dr["Principle_Spot_Rate"]);
                        pr_amount_pp = Convert.ToDecimal(dr["Principle_Amount"].ToString());
                        pr_spcl_amount_pp = Convert.ToDecimal(dr["special_Amount"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Fuel_Surcharges"].ToString());
                        xray_chg_pp = Convert.ToDecimal(dr["Xray_Charges"].ToString());
                        wsc_pp = Convert.ToDecimal(dr["War_Surcharges"].ToString());
                        ag_min_status_pp = Convert.ToInt16(dr["agent_Min_Status"].ToString());
                        pr_min_status_pp = Convert.ToInt16(dr["Principle_Min_Status"].ToString());
                        due_carr_pp = Convert.ToDecimal(dr["Total_DueCarrier"].ToString());
                        due_agent_pp = Convert.ToDecimal(dr["TotalDueAgent_Collect"].ToString());
                        awbfee_pp = Convert.ToDecimal(dr["AWB_Fees"].ToString());
                        dis_chg_pp = Convert.ToDecimal(dr["Disbursement_Charges"].ToString());
                        aci_fee_pp = Convert.ToDecimal(dr["total_aci_fees"].ToString());
                        other_due_chg_pp = Convert.ToDecimal(dr["Other_DueCarrier"].ToString());
                        pr_rem_pp = dr["Principle_Spot_Rate_Remarks"].ToString().Trim();
                        status_void_pp = Convert.ToDecimal(dr["status"].ToString().Trim());
                        gsa_comm_rate = Convert.ToDecimal(dr["gsacomm_rate"].ToString().Trim());
                        frt_type = dr["Freight_Type"].ToString().Trim();
                        freight_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString().Trim());
                        freight_cc = Convert.ToDecimal(dr["Freight_Amount"].ToString().Trim());
                        if (pr_rem_pp != "")
                        {
                            pr_rem_pp = pr_rem_pp;
                        }
                        else
                        {
                            pr_rem_pp = "&nbsp";
                        }
                     
                        due_carr_pp = awb_f_pp + xray_chg_pp + fsc_pp + wsc_pp + other_due_chg_pp;
                    
                        if (ag_min_status_pp == 13)
                        {

                            net_net_rate_pp = Convert.ToDecimal(dr["NET_NET_AGENT"].ToString().Trim()) * ch_wt_pp;
                        }
                        else
                        {
                            net_net_rate_pp = Convert.ToDecimal(dr["NET_NET_AGENT"].ToString().Trim());
                        }
                if (frt_type == "PREPAID")
                {
                    freight_pp = freight_pp;
                    freight_cc = 0;
                }
                else if (frt_type == "COLLECT")
                {
                    freight_pp = 0;
                    freight_cc = freight_cc;
                }
                       
                            if (ag_min_status_pp == 13)
                            {

                                net_net_frt_pp = net_net_rate_pp;
                            }
                            else
                            {
                                net_net_frt_pp = net_net_rate_pp * ch_wt_pp;
                            }



                        
                        col_14_pp =Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        col_15_pp = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        col_13_pp = col_14_pp + col_15_pp;
                        other_chg_pp = dis_chg_pp + aci_fee_pp;
                     
                        if (status_void_pp == 12)
                        {
                            awbfee_pp = 0;
                            awb_f_pp = 0;
                            due_carr_pp = 0;
                            Total_Due_PP_row = 0;
                        }
                        else
                        {
                            awb_f_pp = 150;
                        }
                        if (frt_type == "PREPAID")
                        {
                            frt_type = "P";
                            Total_Due_PP_row = fsc_pp + awbfee_pp + wsc_pp + xray_chg_pp + other_chg_pp;
                            due_agent_pp = 0;
                            freight_pp = freight_pp;
                            freight_cc = 0;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            if (DateTime.Parse(from_date) >= DateTime.Parse("10/01/2009"))
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4) / 100;
                            }
                            else
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                            }
                            
                            
                        }
                        else if (frt_type == "COLLECT")
                        {
                            frt_type = "C";
                            Total_Due_PP_row = 0;
                            freight_pp = 0;
                            freight_cc = freight_cc;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            if (DateTime.Parse(from_date) >= DateTime.Parse("10/01/2009"))
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4) / 100;
                            }
                            else
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                            }
                        }
                        else
                        {
                            frt_type = "&nbsp";
                            freight_pp = 0;
                            freight_cc = 0;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            if (DateTime.Parse(from_date) >= DateTime.Parse("10/01/2009"))
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4) / 100;
                            }
                            else
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                            }

                        }
                        if (freight_pp < 0)
                        {
                            col_26_pp = (Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero) + Math.Round((((decimal.Parse(dr["ONLY_TDS"].ToString()) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero));
                       
                        }

                        else
                        {
                            col_26_pp = (Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero) + Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero));
                        }


                        //col_26_pp = (col_14_pp + col_15_pp) * Convert.ToDecimal(dr["TDS"].ToString().Trim()) / 100;
                        if (DateTime.Parse(from_date) >= DateTime.Parse("10/01/2008"))
                        {
                            col_28_pp = due_agent_pp * Convert.ToDecimal(2.266) / 100;
                        }
                        else
                        {
                            col_28_pp = due_agent_pp * Convert.ToDecimal(dr["TDS"].ToString().Trim()) / 100;
                        }
                        col_27_pp = Math.Round(col_24_pp,MidpointRounding.AwayFromZero) -Math.Round(col_25_pp,MidpointRounding.AwayFromZero) + Math.Round(col_26_pp,MidpointRounding.AwayFromZero) + Math.Round(col_28_pp,MidpointRounding.AwayFromZero);

                        //----------------CALCULATION TOTAL HERE -----------------------------------------------
                        // total_vol_wt_pp = total_vol_wt_pp + vol_wt_pp;
                        //total_gr_wt_pp = total_gr_wt_pp + gr_wt_pp;

                        total_ch_wt_pp = total_ch_wt_pp + Math.Round(ch_wt_pp, 2);
                        total_freight_pp = total_freight_pp + Math.Round(freight_pp, MidpointRounding.AwayFromZero);
                        total_freight_cc = total_freight_cc + Math.Round(freight_cc, MidpointRounding.AwayFromZero);
                        total_net_net_frt_pp = total_net_net_frt_pp + Math.Round(net_net_frt_pp, MidpointRounding.AwayFromZero);
                        total_col_13_pp = total_col_13_pp + Math.Round(col_13_pp, MidpointRounding.AwayFromZero);
                        total_col_14_pp = total_col_14_pp + Math.Round(col_14_pp, MidpointRounding.AwayFromZero);
                        total_col_15_pp = total_col_15_pp + Math.Round(col_15_pp, MidpointRounding.AwayFromZero);
                        total_col_16_pp = total_col_16_pp + Math.Round(col_16_pp, MidpointRounding.AwayFromZero);
                        total_fsc_pp = total_fsc_pp + Math.Round(fsc_pp, MidpointRounding.AwayFromZero);
                        total_awbfee_pp = total_awbfee_pp + Math.Round(awbfee_pp, MidpointRounding.AwayFromZero);
                        total_wsc_pp = total_wsc_pp + Math.Round(wsc_pp, MidpointRounding.AwayFromZero);
                        total_xray_chg_pp = total_xray_chg_pp + Math.Round(xray_chg_pp, MidpointRounding.AwayFromZero);
                        total_other_chg_pp = total_other_chg_pp + Math.Round(other_chg_pp, MidpointRounding.AwayFromZero);
                        total_Total_Due_PP_row = total_Total_Due_PP_row + Math.Round(Total_Due_PP_row, MidpointRounding.AwayFromZero);
                        total_due_agent_pp = total_due_agent_pp + Math.Round(due_agent_pp, MidpointRounding.AwayFromZero);
                        total_col_24_pp = total_col_24_pp + Math.Round(col_24_pp, MidpointRounding.AwayFromZero);
                        total_col_25_pp = total_col_25_pp + Math.Round(col_25_pp, MidpointRounding.AwayFromZero);
                        total_col_26_pp = total_col_26_pp + Math.Round(col_26_pp, MidpointRounding.AwayFromZero);
                        total_col_28_pp = total_col_28_pp + Math.Round(col_28_pp, MidpointRounding.AwayFromZero);
                        total_col_27_pp = total_col_27_pp + Math.Round(col_27_pp, MidpointRounding.AwayFromZero);
                        table += "<tr class=text onclick=ChangeColor(this); ><td nowrap align=left>" + dr["AirWayBill_No"] + "</td><td nowrap>" + dr["flight_date"].ToString() + "</td><td>&nbsp;" + dr["city_Code"].ToString() + "</td><td nowrap align=left>&nbsp;" + dr["Destination_Code"].ToString() + "</td><td nowrap>&nbsp;" + frt_type.ToString() + "</td><td align=right nowrap>" + Math.Round(vol_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(gr_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(ch_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(publish_rate_pp, 2) + "</td><td align=right nowrap><font color=maroon>" + Math.Round(net_net_rate_pp, 2) + "</font></td></td><td align=right nowrap>" + Math.Round(freight_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(freight_cc, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(net_net_frt_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_13_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_14_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_15_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(Total_Due_PP_row, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(due_agent_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_24_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_25_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_26_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_28_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_27_pp, MidpointRounding.AwayFromZero) + "</td><td align=left nowrap>&nbsp;" + dr["csr_remarks"].ToString() + "</td></tr>";

                    }
                    //Decimal Debit_Surcharge = 0;
                    //DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + agnetID + " AND AIRLINE_DETAIL_ID=" + airline_name_city_value + " AND (CSR_PERIOD>='" + from_date.Trim() + "' AND CSR_PERIOD<='" + to_date.Trim() + "')");

                    //if (dt_Sur.Rows.Count > 0)
                    //{
                    //    Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                    //    EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(lastedcess) / 100)), MidpointRounding.AwayFromZero);

                    //}
                    com.Dispose();
                    dr.Dispose();

                    //-------------------------------------------------TOTAL RECORDS CALCULATE-------------------
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM CPP_AgentWiseTotal WHERE  CITYID='" + city_id + "' and agentid='" + agnetID + "' AND ExpiryDate>DATEADD(YEAR,-1,GETDATE()) group by AGENTID  ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    string font = null;
                    string massage = null;
                    if (total_col_27_pp > 0)
                    {
                        massage = "Total Receivable From Agent";
                        font = "<font class='text'>";

                    }
                    else
                    {
                        massage = "Total Payable To Agent";
                        font = "<font color='red'>";
                    }
                    table += "<tr class=boldtext1 ><th colspan=7 nowrap>&nbsp;</th><th align=right nowrap>" + total_ch_wt_pp + "</th><th colspan=2 nowrap>&nbsp;</th><th align=right nowrap>" + Math.Round(total_freight_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_freight_cc,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_net_net_frt_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_13_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_14_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_15_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_Total_Due_PP_row,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_due_agent_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_24_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_25_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_26_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_28_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_27_pp,MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>&nbsp;</th></tr></table><br><table width=10% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0 align=left><tr  class=h5><th align=center colspan=2>AGENT CSR SUMMERY</th></tr><tr><th class=boldtext nowrap align=left>Total Gross Freight collected at rack rates</th><th class=boldtext align=right>" + Math.Round(total_freight_pp,MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Commission/discount </th><th class=boldtext align=right>" +Math.Round(total_col_13_pp,MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add:Due Carrier(PP)</th><th class=boldtext align=right>" + Math.Round(total_Total_Due_PP_row,MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less:Due Agent(CC)</th><th class=boldtext align=right>" + Math.Round(total_due_agent_pp,MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less : TDS on Freight and Due Carrier to be deducted by Agent</th><th class=boldtext align=right>" + Math.Round(total_col_25_pp,MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add : TDS on Commission + Discount to agent</th><th class=boldtext align=right>" + Math.Round(total_col_26_pp,MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add:TDS on Due Agent to agent(CC)</th><th class=boldtext align=right>" + Math.Round(total_col_28_pp,MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>" + massage + "</th><th class=boldtext nowrap align=right>INR &nbsp;" + font + Math.Abs(Math.Round(total_col_27_pp,MidpointRounding.AwayFromZero)) + @"</font></th></tr></table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><table><tr  align=left class=text><td colspan=27><hr><font size=1>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeem CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table><table  align=center><tr><td><img src=images/gcinitiative_treessave_1.JPG width=700 height=77></td></tr></table><br style=page-break-before:always;>";

                }
                tableAll = tableAll + table;
                Label1.Text = tableAll;
            }
            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;
        }
        else if (approveCsr == "notApprove")
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //------------DECLARE VARIABLES HERE -----------------------------------------
                string frt_type = null;
                string pr_rem_pp = null;
                //Int64 count = 0;
                decimal sid_pp = 0;
                //decimal pcs;
                decimal vol_wt_pp = 0;
                decimal gr_wt_pp = 0;
                decimal ch_wt_pp = 0; decimal total_ch_wt_pp = 0;
                decimal publish_rate_pp = 0;
                decimal pr_rate_pp = 0;
                decimal pr_spot_rate_pp = 0;
                decimal pr_min_amt_pp = 0;
                decimal pr_amount_pp = 0;
                decimal pr_spcl_amount_pp = 0;
                decimal freight_pp = 0; decimal total_freight_pp = 0;
                decimal freight_cc = 0; decimal total_freight_cc = 0;
                int pr_min_status_pp = 0;
                int ag_min_status_pp = 0;
                decimal fsc_pp = 0; decimal total_fsc_pp = 0;
                decimal wsc_pp = 0; decimal total_wsc_pp = 0;
                decimal awbfee_pp = 0; decimal total_awbfee_pp = 0;
                decimal dis_chg_pp = 0;
                decimal aci_fee_pp = 0;
                decimal other_chg_pp = 0; decimal total_other_chg_pp = 0;
                decimal due_carr_pp = 0;
                decimal awb_f_pp = 0;
                decimal gsa_comm_rate = 0;
                decimal net_net_rate_pp = 0;
                decimal net_net_frt_pp = 0; decimal total_net_net_frt_pp = 0;
                decimal xray_chg_pp = 0; decimal total_xray_chg_pp = 0;
                decimal Total_Due_PP_row = 0; decimal total_Total_Due_PP_row = 0;
                decimal other_due_chg_pp = 0;
                decimal status_void_pp = 0;
                decimal col_13_pp = 0; decimal total_col_13_pp = 0;
                decimal col_14_pp = 0; decimal total_col_14_pp = 0;
                decimal col_15_pp = 0; decimal total_col_15_pp = 0;
                decimal col_16_pp = 0; decimal total_col_16_pp = 0;
                decimal due_agent_pp = 0; decimal total_due_agent_pp = 0;
                decimal col_24_pp = 0; decimal total_col_24_pp = 0;
                decimal col_25_pp = 0; decimal total_col_25_pp = 0;
                decimal col_26_pp = 0; decimal total_col_26_pp = 0;
                decimal col_27_pp = 0; decimal total_col_27_pp = 0;
                decimal col_28_pp = 0; decimal total_col_28_pp = 0;
                string table = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (flight_date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (flight_date>='" + from_date + "'  and  flight_date<='" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        comName = dr["company_name"].ToString();

                        table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""3"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""2"">Cargo Sales Report </font><br><font size=""3"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table>";
                    }
                    com.Dispose();
                    dr.Dispose();
                    table += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0><tr class=h5><th nowrap rowspan=2>AWBNo</th><th nowrap rowspan=2>Date</th><th nowrap rowspan=2>Origin</th><th nowrap rowspan=2>Dest</th><th nowrap rowspan=2>PP<br>/CC</th><th nowrap rowspan=2>VolWt</th><th nowrap rowspan=2>GrWt</th><th nowrap rowspan=2>ChgWt</th><th nowrap rowspan=2>AWB<br>Rack<br>Rate</th><th nowrap rowspan=2>Net Net<br>Rate</th><th nowrap colspan=2>Frt on<br>Rack<br>Rates</th><th nowrap rowspan=2>Awb.<br>Frt on<br>Net Net<br>Rates</th><th nowrap rowspan=2>(Comm +<br>Discount)</th><th nowrap rowspan=2>Comm<br>(5% of<br>Frt.)</th><th nowrap rowspan=2>Discount</th><th nowrap rowspan=2>Total<br>Due<br>Carrier</th><th nowrap rowspan=2>Due<br>Agent<br>(CC)</th><th nowrap rowspan=2>Net<br>Rec.ble/<br>Payable<br>Before<br>TDS</th><th nowrap rowspan=2>TDS Ded.<br>On Frt./<br>Due Carr.</th><th nowrap rowspan=2>TDS<br>on<br>Comm+<br>Disc.</th><th nowrap rowspan=2>TDS<br>on<br>Due<br>Agent<br>(CC)</th><th nowrap rowspan=2>Total<br>Rec.ble<br>/Payable</th><th nowrap rowspan=2>Remarks</th></tr><tr><th nowrap>PP</th><th nowrap>CC</th></tr>";
                    com = new SqlCommand("csr_deccan", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        //count = count + 1;
                        sid_pp = Convert.ToDecimal(dr["Sales_ID"].ToString());
                        awb_f_pp = Convert.ToDecimal(dr["awb_f"].ToString());
                        //pcs = Convert.ToDecimal(dr["No_of_Packages"].ToString());
                        vol_wt_pp = Convert.ToDecimal(dr["volume_weight"].ToString());
                        gr_wt_pp = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                        ch_wt_pp = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                        publish_rate_pp = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                        pr_rate_pp = Convert.ToDecimal(dr["Principle_Rate"].ToString());
                        pr_spot_rate_pp = Convert.ToDecimal(dr["Principle_Spot_Rate"]);
                        pr_amount_pp = Convert.ToDecimal(dr["Principle_Amount"].ToString());
                        pr_spcl_amount_pp = Convert.ToDecimal(dr["special_Amount"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Fuel_Surcharges"].ToString());
                        xray_chg_pp = Convert.ToDecimal(dr["Xray_Charges"].ToString());
                        wsc_pp = Convert.ToDecimal(dr["War_Surcharges"].ToString());
                        ag_min_status_pp = Convert.ToInt16(dr["agent_Min_Status"].ToString());
                        pr_min_status_pp = Convert.ToInt16(dr["Principle_Min_Status"].ToString());
                        due_carr_pp = Convert.ToDecimal(dr["Total_DueCarrier"].ToString());
                        due_agent_pp = Convert.ToDecimal(dr["TotalDueAgent_Collect"].ToString());
                        awbfee_pp = Convert.ToDecimal(dr["AWB_Fees"].ToString());
                        dis_chg_pp = Convert.ToDecimal(dr["Disbursement_Charges"].ToString());
                        aci_fee_pp = Convert.ToDecimal(dr["total_aci_fees"].ToString());
                        other_due_chg_pp = Convert.ToDecimal(dr["Other_DueCarrier"].ToString());
                        pr_rem_pp = dr["Principle_Spot_Rate_Remarks"].ToString().Trim();
                        status_void_pp = Convert.ToDecimal(dr["status"].ToString().Trim());
                        gsa_comm_rate = Convert.ToDecimal(dr["gsacomm_rate"].ToString().Trim());
                        frt_type = dr["Freight_Type"].ToString().Trim();
                        freight_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString().Trim());
                        freight_cc = Convert.ToDecimal(dr["Freight_Amount"].ToString().Trim());
                        if (pr_rem_pp != "")
                        {
                            pr_rem_pp = pr_rem_pp;
                        }
                        else
                        {
                            pr_rem_pp = "&nbsp";
                        }

                        due_carr_pp = awb_f_pp + xray_chg_pp + fsc_pp + wsc_pp + other_due_chg_pp;

                        if (ag_min_status_pp == 13)
                        {

                            net_net_rate_pp = Convert.ToDecimal(dr["NET_NET_AGENT"].ToString().Trim()) * ch_wt_pp;
                        }
                        else
                        {
                            net_net_rate_pp = Convert.ToDecimal(dr["NET_NET_AGENT"].ToString().Trim());
                        }
                        if (frt_type == "PREPAID")
                        {
                            freight_pp = freight_pp;
                            freight_cc = 0;
                        }
                        else if (frt_type == "COLLECT")
                        {
                            freight_pp = 0;
                            freight_cc = freight_cc;
                        }

                        if (ag_min_status_pp == 13)
                        {

                            net_net_frt_pp = net_net_rate_pp;
                        }
                        else
                        {
                            net_net_frt_pp = net_net_rate_pp * ch_wt_pp;
                        }




                        col_14_pp = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        col_15_pp = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        col_13_pp = col_14_pp + col_15_pp;
                        other_chg_pp = dis_chg_pp + aci_fee_pp;

                        if (status_void_pp == 12)
                        {
                            awbfee_pp = 0;
                            awb_f_pp = 0;
                            due_carr_pp = 0;
                            Total_Due_PP_row = 0;
                        }
                        else
                        {
                            awb_f_pp = 150;
                        }
                        if (frt_type == "PREPAID")
                        {
                            frt_type = "P";
                            Total_Due_PP_row = fsc_pp + awbfee_pp + wsc_pp + xray_chg_pp + other_chg_pp;
                            due_agent_pp = 0;
                            freight_pp = freight_pp;
                            freight_cc = 0;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            if (DateTime.Parse(from_date) >= DateTime.Parse("10/01/2009"))
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4) / 100;
                            }
                            else
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                            }

                        }
                        else if (frt_type == "COLLECT")
                        {
                            frt_type = "C";
                            Total_Due_PP_row = 0;
                            freight_pp = 0;
                            freight_cc = freight_cc;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            if (DateTime.Parse(from_date) >= DateTime.Parse("10/01/2009"))
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4) / 100;
                            }
                            else
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                            }
                        }
                        else
                        {
                            frt_type = "&nbsp";
                            freight_pp = 0;
                            freight_cc = 0;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            if (DateTime.Parse(from_date) >= DateTime.Parse("10/01/2009"))
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4) / 100;
                            }
                            else
                            {
                                col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                            }
                        }
                        if (freight_pp < 0)
                        {
                            col_26_pp = (Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero) + Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero));

                        }

                        else
                        {
                            col_26_pp = (Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero) + Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero));
                        }


                        //col_26_pp = (col_14_pp + col_15_pp) * Convert.ToDecimal(dr["TDS"].ToString().Trim()) / 100;
                        if (DateTime.Parse(from_date) >= DateTime.Parse("08/01/2009"))
                        {
                            col_28_pp = due_agent_pp * Convert.ToDecimal(2.266) / 100;
                        }
                        else
                        {
                            col_28_pp = due_agent_pp * Convert.ToDecimal(dr["TDS"].ToString().Trim()) / 100;
                        }
                        col_27_pp = Math.Round(col_24_pp, MidpointRounding.AwayFromZero) - Math.Round(col_25_pp, MidpointRounding.AwayFromZero) + Math.Round(col_26_pp, MidpointRounding.AwayFromZero) + Math.Round(col_28_pp, MidpointRounding.AwayFromZero);

                        //----------------CALCULATION TOTAL HERE -----------------------------------------------
                        // total_vol_wt_pp = total_vol_wt_pp + vol_wt_pp;
                        //total_gr_wt_pp = total_gr_wt_pp + gr_wt_pp;

                        total_ch_wt_pp = total_ch_wt_pp + Math.Round(ch_wt_pp, 2);
                        total_freight_pp = total_freight_pp + Math.Round(freight_pp, MidpointRounding.AwayFromZero);
                        total_freight_cc = total_freight_cc + Math.Round(freight_cc, MidpointRounding.AwayFromZero);
                        total_net_net_frt_pp = total_net_net_frt_pp + Math.Round(net_net_frt_pp, MidpointRounding.AwayFromZero);
                        total_col_13_pp = total_col_13_pp + Math.Round(col_13_pp, MidpointRounding.AwayFromZero);
                        total_col_14_pp = total_col_14_pp + Math.Round(col_14_pp, MidpointRounding.AwayFromZero);
                        total_col_15_pp = total_col_15_pp + Math.Round(col_15_pp, MidpointRounding.AwayFromZero);
                        total_col_16_pp = total_col_16_pp + Math.Round(col_16_pp, MidpointRounding.AwayFromZero);
                        total_fsc_pp = total_fsc_pp + Math.Round(fsc_pp, MidpointRounding.AwayFromZero);
                        total_awbfee_pp = total_awbfee_pp + Math.Round(awbfee_pp, MidpointRounding.AwayFromZero);
                        total_wsc_pp = total_wsc_pp + Math.Round(wsc_pp, MidpointRounding.AwayFromZero);
                        total_xray_chg_pp = total_xray_chg_pp + Math.Round(xray_chg_pp, MidpointRounding.AwayFromZero);
                        total_other_chg_pp = total_other_chg_pp + Math.Round(other_chg_pp, MidpointRounding.AwayFromZero);
                        total_Total_Due_PP_row = total_Total_Due_PP_row + Math.Round(Total_Due_PP_row, MidpointRounding.AwayFromZero);
                        total_due_agent_pp = total_due_agent_pp + Math.Round(due_agent_pp, MidpointRounding.AwayFromZero);
                        total_col_24_pp = total_col_24_pp + Math.Round(col_24_pp, MidpointRounding.AwayFromZero);
                        total_col_25_pp = total_col_25_pp + Math.Round(col_25_pp, MidpointRounding.AwayFromZero);
                        total_col_26_pp = total_col_26_pp + Math.Round(col_26_pp, MidpointRounding.AwayFromZero);
                        total_col_28_pp = total_col_28_pp + Math.Round(col_28_pp, MidpointRounding.AwayFromZero);
                        total_col_27_pp = total_col_27_pp + Math.Round(col_27_pp, MidpointRounding.AwayFromZero);
                        table += "<tr class=text onclick=ChangeColor(this); ><td nowrap align=left>" + dr["AirWayBill_No"] + "</td><td nowrap>" + dr["flight_date"].ToString() + "</td><td>&nbsp;" + dr["city_Code"].ToString() + "</td><td nowrap align=left>&nbsp;" + dr["Destination_Code"].ToString() + "</td><td nowrap>&nbsp;" + frt_type.ToString() + "</td><td align=right nowrap>" + Math.Round(vol_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(gr_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(ch_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(publish_rate_pp, 2) + "</td><td align=right nowrap><font color=maroon>" + Math.Round(net_net_rate_pp, 2) + "</font></td></td><td align=right nowrap>" + Math.Round(freight_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(freight_cc, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(net_net_frt_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_13_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_14_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_15_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(Total_Due_PP_row, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(due_agent_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_24_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_25_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_26_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_28_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_27_pp, MidpointRounding.AwayFromZero) + "</td><td align=left nowrap>&nbsp;" + dr["csr_remarks"].ToString() + "</td></tr>";

                    }
                    com.Dispose();
                    dr.Dispose();

                    //-------------------------------------------------TOTAL RECORDS CALCULATE-------------------
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM CPP_AgentWiseTotal WHERE  CITYID='" + city_id + "' and agentid='" + agnetID + "' AND ExpiryDate>DATEADD(YEAR,-1,GETDATE()) group by AGENTID  ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    string font = null;
                    string massage = null;
                    if (total_col_27_pp > 0)
                    {
                        massage = "Total Receivable From Agent";
                        font = "<font class='text'>";

                    }
                    else
                    {
                        massage = "Total Payable To Agent";
                        font = "<font color='red'>";
                    }
                    table += "<tr class=boldtext1 ><th colspan=7 nowrap>&nbsp;</th><th align=right nowrap>" + total_ch_wt_pp + "</th><th colspan=2 nowrap>&nbsp;</th><th align=right nowrap>" + Math.Round(total_freight_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_freight_cc, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_net_net_frt_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_13_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_14_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_15_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_Total_Due_PP_row, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_due_agent_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_24_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_25_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_26_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_28_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_27_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>&nbsp;</th></tr></table><br><table width=10% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0 align=left><tr  class=h5><th align=center colspan=2>AGENT CSR SUMMERY</th></tr><tr><th class=boldtext nowrap align=left>Total Gross Freight collected at rack rates</th><th class=boldtext align=right>" + Math.Round(total_freight_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Commission/discount </th><th class=boldtext align=right>" + Math.Round(total_col_13_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add:Due Carrier(PP)</th><th class=boldtext align=right>" + Math.Round(total_Total_Due_PP_row, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less:Due Agent(CC)</th><th class=boldtext align=right>" + Math.Round(total_due_agent_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less : TDS on Freight and Due Carrier to be deducted by Agent</th><th class=boldtext align=right>" + Math.Round(total_col_25_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add : TDS on Commission + Discount to agent</th><th class=boldtext align=right>" + Math.Round(total_col_26_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add:TDS on Due Agent to agent(CC)</th><th class=boldtext align=right>" + Math.Round(total_col_28_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>" + massage + "</th><th class=boldtext nowrap align=right>INR &nbsp;" + font + Math.Abs(Math.Round(total_col_27_pp, MidpointRounding.AwayFromZero)) + @"</font></th></tr></table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><table><tr  align=left class=text><td colspan=27><hr><font size=1>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeem CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr><tr  align=left class=text><td colspan=11 nowrap ><font size=1>This is not final approved CSR. It may change if needed.</font<br> </FONT><br><br></td></tr></table><table  align=center><tr><td><img src=images/gcinitiative_treessave_1.JPG width=700></td></tr></table><br style=page-break-before:always;>";

                }
                tableAll = tableAll + table;
                Label1.Text = tableAll;
            }
            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;
        }
        else
        {
            for (int k = 0; k < agent_selected_id.Length - 1; k++)
            {
                //------------DECLARE VARIABLES HERE -----------------------------------------
                string frt_type = null;
                string pr_rem_pp = null;
                //Int64 count = 0;
                decimal sid_pp = 0;
                //decimal pcs;
                decimal vol_wt_pp = 0;
                decimal gr_wt_pp = 0;
                decimal ch_wt_pp = 0; decimal total_ch_wt_pp = 0;
                decimal publish_rate_pp = 0;
                decimal pr_rate_pp = 0;
                decimal pr_spot_rate_pp = 0;
                decimal pr_min_amt_pp = 0;
                decimal pr_amount_pp = 0;
                decimal pr_spcl_amount_pp = 0;
                decimal freight_pp = 0; decimal total_freight_pp = 0;
                decimal freight_cc = 0; decimal total_freight_cc = 0;
                int pr_min_status_pp = 0;
                int ag_min_status_pp = 0;
                decimal fsc_pp = 0; decimal total_fsc_pp = 0;
                decimal wsc_pp = 0; decimal total_wsc_pp = 0;
                decimal awbfee_pp = 0; decimal total_awbfee_pp = 0;
                decimal dis_chg_pp = 0;
                decimal aci_fee_pp = 0;
                decimal other_chg_pp = 0; decimal total_other_chg_pp = 0;
                decimal due_carr_pp = 0;
                decimal awb_f_pp = 0;
                decimal gsa_comm_rate = 0;
                decimal net_net_rate_pp = 0;
                decimal net_net_frt_pp = 0; decimal total_net_net_frt_pp = 0;
                decimal xray_chg_pp = 0; decimal total_xray_chg_pp = 0;
                decimal Total_Due_PP_row = 0; decimal total_Total_Due_PP_row = 0;
                decimal other_due_chg_pp = 0;
                decimal status_void_pp = 0;
                decimal col_13_pp = 0; decimal total_col_13_pp = 0;
                decimal col_14_pp = 0; decimal total_col_14_pp = 0;
                decimal col_15_pp = 0; decimal total_col_15_pp = 0;
                decimal col_16_pp = 0; decimal total_col_16_pp = 0;
                decimal due_agent_pp = 0; decimal total_due_agent_pp = 0;
                decimal col_24_pp = 0; decimal total_col_24_pp = 0;
                decimal col_25_pp = 0; decimal total_col_25_pp = 0;
                decimal col_26_pp = 0; decimal total_col_26_pp = 0;
                decimal col_27_pp = 0; decimal total_col_27_pp = 0;
                decimal col_28_pp = 0; decimal total_col_28_pp = 0;
                string table = null;
                agnetID = agent_selected_id[k];
                agentName = agent_selected_name[k];
                con = new SqlConnection(strCon);
                con.Open();

                string sql_query = "";
                sql_query = "select agent_id,csr_sno,csr_no,City_ID from sales  where agent_id=" + agnetID + "  and  (flight_date between '" + from_date + "' and '" + to_date + "') and airline_detail_id=" + airline_name_city_value + " union select agent_id,csr_sno,csr_no,City_ID from sales_drcr  where agent_id=" + agnetID + " and (flight_date>='" + from_date + "'  and  flight_date<='" + to_date + "') and airline_detail_id=" + airline_name_city_value + " ";

                com = new SqlCommand(sql_query, con);
                dr = com.ExecuteReader();

                if (dr.Read())
                {
                    string csrso = "";
                    string csr = "";
                    city_id = dr["City_ID"].ToString();
                    csrso = dr["csr_sno"].ToString();
                    csr = dr["csr_no"].ToString();
                    com.Dispose();
                    dr.Dispose();

                    com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + airline_name_city_value.Trim() + " and belongs_to_city=" + city_id + ")) and city=" + city_id + "", con);


                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        comAdd = dr["company_address"].ToString();
                        string s = dr["company_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        comName = dr["company_name"].ToString();

                        table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr class=""heading"" ><td width=""25%"" align=""left""><img src=""images/gclogo_new.gif""></td><td width=""70%"" align=""left"" nowrap><p align=""center"" class=""heading"">" + dr["company_name"].ToString().ToUpper() + @"<BR>" + airline + @"<br><font size=""3"">" + h + @"<br>Ph :" + dr["Phone"].ToString() + @"</font><br><font size=""2"">Cargo Sales Report </font><br><font size=""3"">From " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p></td></tr></table><br>";

                    }
                    com.Dispose();
                    dr.Dispose();
                    com = new SqlCommand(" select b.agent_address,a.IATA_code from agent_master a  inner join agent_branch b on b.agent_id=a.agent_id where a.agent_id=" + agnetID + " and b.Belongs_To_City=" + city_id + " order by a.agent_name ", con);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        string s = dr["agent_address"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        string h = s.Replace(ch1, "<br>");
                        h = h.Replace(ch3, "&nbsp;");
                        table += @"<table align=center style=""word-spacing:inherit"" width=""95%"""" border=""0""><tr><td align=""left"" valign=top><b><font size=2>" + agentName + @"</font></b><font size=2><br>" + h + @"</font><br><b><h5>IATA Code &nbsp;&nbsp;&nbsp;" + dr["IATA_Code"].ToString() + @"</h5></b></td></tr></table>";
                    }
                    com.Dispose();
                    dr.Dispose();
                    table += "<table width=100% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0><tr class=h5><th nowrap rowspan=2>AWBNo</th><th nowrap rowspan=2>Date</th><th nowrap rowspan=2>Origin</th><th nowrap rowspan=2>Dest</th><th nowrap rowspan=2>PP<br>/CC</th><th nowrap rowspan=2>VolWt</th><th nowrap rowspan=2>GrWt</th><th nowrap rowspan=2>ChgWt</th><th nowrap rowspan=2>AWB<br>Rack<br>Rate</th><th nowrap rowspan=2>Net Net<br>Rate</th><th nowrap colspan=2>Frt on<br>Rack<br>Rates</th><th nowrap rowspan=2>Awb.<br>Frt on<br>Net Net<br>Rates</th><th nowrap rowspan=2>(Comm +<br>Discount)</th><th nowrap rowspan=2>Comm<br>(5% of<br>Frt.)</th><th nowrap rowspan=2>Discount</th><th nowrap rowspan=2>Total<br>Due<br>Carrier</th><th nowrap rowspan=2>Due<br>Agent<br>(CC)</th><th nowrap rowspan=2>Net<br>Rec.ble/<br>Payable<br>Before<br>TDS</th><th nowrap rowspan=2>TDS Ded.<br>On Frt./<br>Due Carr.</th><th nowrap rowspan=2>TDS<br>on<br>Comm+<br>Disc.</th><th nowrap rowspan=2>TDS<br>on<br>Due<br>Agent<br>(CC)</th><th nowrap rowspan=2>Total<br>Rec.ble<br>/Payable</th><th nowrap rowspan=2>Remarks</th></tr><tr><th nowrap>PP</th><th nowrap>CC</th></tr>";
                    com = new SqlCommand("csr_deccan", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("agent_id", agnetID);
                    com.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(from_date));
                    com.Parameters.AddWithValue("TO_DATE", DateTime.Parse(to_date));
                    com.Parameters.AddWithValue("Airline_Detail_ID", airline_name_city_value);
                    DataTable dt = new DataTable();
                    dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        //count = count + 1;
                        sid_pp = Convert.ToDecimal(dr["Sales_ID"].ToString());
                        awb_f_pp = Convert.ToDecimal(dr["awb_f"].ToString());
                        //pcs = Convert.ToDecimal(dr["No_of_Packages"].ToString());
                        vol_wt_pp = Convert.ToDecimal(dr["volume_weight"].ToString());
                        gr_wt_pp = Convert.ToDecimal(dr["Gross_Weight"].ToString());
                        ch_wt_pp = Convert.ToDecimal(dr["Charged_Weight"].ToString());
                        publish_rate_pp = Convert.ToDecimal(dr["Tariff_Rate"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString());
                        pr_rate_pp = Convert.ToDecimal(dr["Principle_Rate"].ToString());
                        pr_spot_rate_pp = Convert.ToDecimal(dr["Principle_Spot_Rate"]);
                        pr_amount_pp = Convert.ToDecimal(dr["Principle_Amount"].ToString());
                        pr_spcl_amount_pp = Convert.ToDecimal(dr["special_Amount"].ToString());
                        fsc_pp = Convert.ToDecimal(dr["Fuel_Surcharges"].ToString());
                        xray_chg_pp = Convert.ToDecimal(dr["Xray_Charges"].ToString());
                        wsc_pp = Convert.ToDecimal(dr["War_Surcharges"].ToString());
                        ag_min_status_pp = Convert.ToInt16(dr["agent_Min_Status"].ToString());
                        pr_min_status_pp = Convert.ToInt16(dr["Principle_Min_Status"].ToString());
                        due_carr_pp = Convert.ToDecimal(dr["Total_DueCarrier"].ToString());
                        due_agent_pp = Convert.ToDecimal(dr["TotalDueAgent_Collect"].ToString());
                        awbfee_pp = Convert.ToDecimal(dr["AWB_Fees"].ToString());
                        dis_chg_pp = Convert.ToDecimal(dr["Disbursement_Charges"].ToString());
                        aci_fee_pp = Convert.ToDecimal(dr["total_aci_fees"].ToString());
                        other_due_chg_pp = Convert.ToDecimal(dr["Other_DueCarrier"].ToString());
                        pr_rem_pp = dr["Principle_Spot_Rate_Remarks"].ToString().Trim();
                        status_void_pp = Convert.ToDecimal(dr["status"].ToString().Trim());
                        gsa_comm_rate = Convert.ToDecimal(dr["gsacomm_rate"].ToString().Trim());
                        frt_type = dr["Freight_Type"].ToString().Trim();
                        freight_pp = Convert.ToDecimal(dr["Freight_Amount"].ToString().Trim());
                        freight_cc = Convert.ToDecimal(dr["Freight_Amount"].ToString().Trim());
                        if (pr_rem_pp != "")
                        {
                            pr_rem_pp = pr_rem_pp;
                        }
                        else
                        {
                            pr_rem_pp = "&nbsp";
                        }

                        due_carr_pp = awb_f_pp + xray_chg_pp + fsc_pp + wsc_pp + other_due_chg_pp;

                        if (ag_min_status_pp == 13)
                        {

                            net_net_rate_pp = Convert.ToDecimal(dr["NET_NET_AGENT"].ToString().Trim()) * ch_wt_pp;
                        }
                        else
                        {
                            net_net_rate_pp = Convert.ToDecimal(dr["NET_NET_AGENT"].ToString().Trim());
                        }
                        if (frt_type == "PREPAID")
                        {
                            freight_pp = freight_pp;
                            freight_cc = 0;
                        }
                        else if (frt_type == "COLLECT")
                        {
                            freight_pp = 0;
                            freight_cc = freight_cc;
                        }

                        if (ag_min_status_pp == 13)
                        {

                            net_net_frt_pp = net_net_rate_pp;
                        }
                        else
                        {
                            net_net_frt_pp = net_net_rate_pp * ch_wt_pp;
                        }




                        col_14_pp = Math.Round(decimal.Parse(dr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        col_15_pp = Math.Round(decimal.Parse(dr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                        col_13_pp = col_14_pp + col_15_pp;
                        other_chg_pp = dis_chg_pp + aci_fee_pp;

                        if (status_void_pp == 12)
                        {
                            awbfee_pp = 0;
                            awb_f_pp = 0;
                            due_carr_pp = 0;
                            Total_Due_PP_row = 0;
                        }
                        else
                        {
                            awb_f_pp = 150;
                        }
                        if (frt_type == "PREPAID")
                        {
                            frt_type = "P";
                            Total_Due_PP_row = fsc_pp + awbfee_pp + wsc_pp + xray_chg_pp + other_chg_pp;
                            due_agent_pp = 0;
                            freight_pp = freight_pp;
                            freight_cc = 0;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;

                        }
                        else if (frt_type == "COLLECT")
                        {
                            frt_type = "C";
                            Total_Due_PP_row = 0;
                            freight_pp = 0;
                            freight_cc = freight_cc;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                        }
                        else
                        {
                            frt_type = "&nbsp";
                            freight_pp = 0;
                            freight_cc = 0;
                            col_24_pp = freight_pp - col_13_pp + Total_Due_PP_row - due_agent_pp;
                            col_25_pp = (freight_pp + Total_Due_PP_row) * Convert.ToDecimal(.4532) / 100;
                        }
                        if (freight_pp < 0)
                        {
                            col_26_pp = (Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero) + Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero));

                        }

                        else
                        {
                            col_26_pp = (Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + Math.Round(decimal.Parse(dr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero) + Math.Round((((Math.Ceiling(decimal.Parse(dr["ONLY_TDS"].ToString())) + decimal.Parse(dr["only_surcharge"].ToString())) * decimal.Parse(dr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero));
                        }


                        //col_26_pp = (col_14_pp + col_15_pp) * Convert.ToDecimal(dr["TDS"].ToString().Trim()) / 100;
                        if (DateTime.Parse(from_date) >= DateTime.Parse("08/01/2009"))
                        {
                            col_28_pp = due_agent_pp * Convert.ToDecimal(2.266) / 100;
                        }
                        else
                        {
                            col_28_pp = due_agent_pp * Convert.ToDecimal(dr["TDS"].ToString().Trim()) / 100;
                        }
                        col_27_pp = Math.Round(col_24_pp, MidpointRounding.AwayFromZero) - Math.Round(col_25_pp, MidpointRounding.AwayFromZero) + Math.Round(col_26_pp, MidpointRounding.AwayFromZero) + Math.Round(col_28_pp, MidpointRounding.AwayFromZero);

                        //----------------CALCULATION TOTAL HERE -----------------------------------------------
                        // total_vol_wt_pp = total_vol_wt_pp + vol_wt_pp;
                        //total_gr_wt_pp = total_gr_wt_pp + gr_wt_pp;

                        total_ch_wt_pp = total_ch_wt_pp + Math.Round(ch_wt_pp, 2);
                        total_freight_pp = total_freight_pp + Math.Round(freight_pp, MidpointRounding.AwayFromZero);
                        total_freight_cc = total_freight_cc + Math.Round(freight_cc, MidpointRounding.AwayFromZero);
                        total_net_net_frt_pp = total_net_net_frt_pp + Math.Round(net_net_frt_pp, MidpointRounding.AwayFromZero);
                        total_col_13_pp = total_col_13_pp + Math.Round(col_13_pp, MidpointRounding.AwayFromZero);
                        total_col_14_pp = total_col_14_pp + Math.Round(col_14_pp, MidpointRounding.AwayFromZero);
                        total_col_15_pp = total_col_15_pp + Math.Round(col_15_pp, MidpointRounding.AwayFromZero);
                        total_col_16_pp = total_col_16_pp + Math.Round(col_16_pp, MidpointRounding.AwayFromZero);
                        total_fsc_pp = total_fsc_pp + Math.Round(fsc_pp, MidpointRounding.AwayFromZero);
                        total_awbfee_pp = total_awbfee_pp + Math.Round(awbfee_pp, MidpointRounding.AwayFromZero);
                        total_wsc_pp = total_wsc_pp + Math.Round(wsc_pp, MidpointRounding.AwayFromZero);
                        total_xray_chg_pp = total_xray_chg_pp + Math.Round(xray_chg_pp, MidpointRounding.AwayFromZero);
                        total_other_chg_pp = total_other_chg_pp + Math.Round(other_chg_pp, MidpointRounding.AwayFromZero);
                        total_Total_Due_PP_row = total_Total_Due_PP_row + Math.Round(Total_Due_PP_row, MidpointRounding.AwayFromZero);
                        total_due_agent_pp = total_due_agent_pp + Math.Round(due_agent_pp, MidpointRounding.AwayFromZero);
                        total_col_24_pp = total_col_24_pp + Math.Round(col_24_pp, MidpointRounding.AwayFromZero);
                        total_col_25_pp = total_col_25_pp + Math.Round(col_25_pp, MidpointRounding.AwayFromZero);
                        total_col_26_pp = total_col_26_pp + Math.Round(col_26_pp, MidpointRounding.AwayFromZero);
                        total_col_28_pp = total_col_28_pp + Math.Round(col_28_pp, MidpointRounding.AwayFromZero);
                        total_col_27_pp = total_col_27_pp + Math.Round(col_27_pp, MidpointRounding.AwayFromZero);
                        table += "<tr class=text onclick=ChangeColor(this); ><td nowrap align=left>" + dr["AirWayBill_No"] + "</td><td nowrap>" + dr["flight_date"].ToString() + "</td><td>&nbsp;" + dr["city_Code"].ToString() + "</td><td nowrap align=left>&nbsp;" + dr["Destination_Code"].ToString() + "</td><td nowrap>&nbsp;" + frt_type.ToString() + "</td><td align=right nowrap>" + Math.Round(vol_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(gr_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(ch_wt_pp, 2) + "</td><td align=right nowrap>" + Math.Round(publish_rate_pp, 2) + "</td><td align=right nowrap><font color=maroon>" + Math.Round(net_net_rate_pp, 2) + "</font></td></td><td align=right nowrap>" + Math.Round(freight_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(freight_cc, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(net_net_frt_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_13_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_14_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_15_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(Total_Due_PP_row, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(due_agent_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_24_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_25_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_26_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_28_pp, MidpointRounding.AwayFromZero) + "</td><td align=right nowrap>" + Math.Round(col_27_pp, MidpointRounding.AwayFromZero) + "</td><td align=left nowrap>&nbsp;" + dr["csr_remarks"].ToString() + "</td></tr>";

                    }
                    com.Dispose();
                    dr.Dispose();

                    //-------------------------------------------------TOTAL RECORDS CALCULATE-------------------
                    decimal totalCPP = 0;
                    decimal redeemCPP = 0;
                    DataTable dt_cpp = dw.GetAllFromQuery("SELECT sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP FROM CPP_AgentWiseTotal WHERE  CITYID='" + city_id + "' and agentid='" + agnetID + "' AND ExpiryDate>DATEADD(YEAR,-1,GETDATE()) group by AGENTID  ORDER BY TotalCPP DESC");

                    if (dt_cpp.Rows.Count > 0)
                    {
                        totalCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["TotalCPP"].ToString()), MidpointRounding.AwayFromZero);
                        redeemCPP = Math.Round(decimal.Parse(dt_cpp.Rows[0]["RedeemedCPP"].ToString()), MidpointRounding.AwayFromZero);
                    }
                    string font = null;
                    string massage = null;
                    if (total_col_27_pp > 0)
                    {
                        massage = "Total Receivable From Agent";
                        font = "<font class='text'>";

                    }
                    else
                    {
                        massage = "Total Payable To Agent";
                        font = "<font color='red'>";
                    }
                    table += "<tr class=boldtext1 ><th colspan=7 nowrap>&nbsp;</th><th align=right nowrap>" + total_ch_wt_pp + "</th><th colspan=2 nowrap>&nbsp;</th><th align=right nowrap>" + Math.Round(total_freight_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_freight_cc, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_net_net_frt_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_13_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_14_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_15_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_Total_Due_PP_row, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_due_agent_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_24_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_25_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_26_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_28_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>" + Math.Round(total_col_27_pp, MidpointRounding.AwayFromZero) + "</th><th align=right nowrap>&nbsp;</th></tr></table><br><table width=10% border=1  bordercolor=#bacbcc cellpadding=3 cellspacing=0 align=left><tr  class=h5><th align=center colspan=2>AGENT CSR SUMMERY</th></tr><tr><th class=boldtext nowrap align=left>Total Gross Freight collected at rack rates</th><th class=boldtext align=right>" + Math.Round(total_freight_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less : Commission/discount </th><th class=boldtext align=right>" + Math.Round(total_col_13_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add:Due Carrier(PP)</th><th class=boldtext align=right>" + Math.Round(total_Total_Due_PP_row, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less:Due Agent(CC)</th><th class=boldtext align=right>" + Math.Round(total_due_agent_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Less : TDS on Freight and Due Carrier to be deducted by Agent</th><th class=boldtext align=right>" + Math.Round(total_col_25_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add : TDS on Commission + Discount to agent</th><th class=boldtext align=right>" + Math.Round(total_col_26_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>Add:TDS on Due Agent to agent(CC)</th><th class=boldtext align=right>" + Math.Round(total_col_28_pp, MidpointRounding.AwayFromZero) + "</th></tr><tr><th class=boldtext nowrap align=left>" + massage + "</th><th class=boldtext nowrap align=right>INR &nbsp;" + font + Math.Abs(Math.Round(total_col_27_pp, MidpointRounding.AwayFromZero)) + @"</font></th></tr></table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><table><tr  align=left class=text><td colspan=27><hr><font size=1>" + csrFooter + @"</font><hr></td></tr><tr align=""left"" class=h5 boldtext><th colspan=""11"" nowrap ><strong>Your CARGO POWER POINTS as on " + DateTime.Now.ToString("dd/MM/yyyy") + " are <b>" + totalCPP + "</b> and your Redeem CARGO POWER POINTS are " + redeemCPP + ".</th></tr><tr align=left class=h5 boldtext><th colspan=11>Log on to <a class=link href=http://groupconcorde.com target=blank>http://www.groupconcorde.com</a> for various redemption offers.</th></tr><tr><td colspan=11><hr></td></tr></table><table  align=center><tr><td><img src=images/gcinitiative_treessave_1.JPG width=700 height=77></td></tr></table><br style=page-break-before:always;>";

                }
                tableAll = tableAll + table;
                Label1.Text = tableAll;
            }
            string mass = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(from_date) + " To " + ConvertDate1(to_date) + @"</font></p>";

            if (tableAll == "" || tableAll == null)
                Label1.Text = mass;
        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    public string ConvertDateFormat1(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Length < 2) Sdate[0] = "0" + Sdate[0];
        if (Sdate[1].Length < 2) Sdate[1] = "0" + Sdate[1];
        return Sdate[0] + "/" + Sdate[1] + "/" + Sdate[2];
    }
    protected string checkApprove(string dt1, string dt2)
    {
        string s = null;
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("select * from Approved_CSR a inner join CSR_Duration b on a.CSR_Duration_ID=b.CSR_Duration_ID where CSR_Duration1='" + ConvertDateFormat1(dt1) + "-" + ConvertDateFormat1(dt2) + "'", con);
        dr = com.ExecuteReader();
        if (dr.Read())
            s = "approve";
        else
            s = "notApprove";

        return s;


    }

}
