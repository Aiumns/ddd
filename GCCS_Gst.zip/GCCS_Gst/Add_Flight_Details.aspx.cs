using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Add_Flight_Details : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string strquery;
    SqlDataAdapter sda;
    SqlDataReader rdr;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnupdate.Visible = false;
            if (!IsPostBack)
            {
                string foid = Request.QueryString["fid"].ToString();
                con = new SqlConnection(strCon);
                con.Open();
                try
                {

                    strquery = "select egm,igm,ata, atd, cnmt, pax from flight_open where flight_open_id='" + foid + "' and egm<>'' and igm<>'' and ata<>'' and  atd<>'' and cnmt<>''and  pax<>''";
                    cmd = new SqlCommand(strquery, con);
                    rdr = cmd.ExecuteReader();
                    if (rdr.HasRows == true)
                    {
                        Button1.Visible = false;
                        Button2.Visible = false;
                        btnupdate.Visible = true;
                        while (rdr.Read())
                        {
                            txtegm.Text = rdr["egm"].ToString();
                            txtigm.Text = rdr["igm"].ToString();
                            txtata.Text = rdr["ata"].ToString();
                            txtatd.Text = rdr["atd"].ToString();
                            txtcnmt.Text = rdr["cnmt"].ToString();
                            txtpax.Text = rdr["pax"].ToString();

                        }


                    }
                    else
                    {

                        Button2.Visible = true;
                        Button1.Visible = true;
                        btnupdate.Visible = false;
                    }
                }
                catch (SqlException ee)
                {

                }
                catch (Exception mm)
                {


                }
            }


        }
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        btnupdate.Visible = false;
        string foid = Request.QueryString["fid"].ToString();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            strquery = "update flight_open set egm=@egm,igm=@igm,ata=@ata, atd=@atd, cnmt=@cnmt, pax=@pax where flight_open_id='" + foid + "'";
            cmd = new SqlCommand(strquery, con);
            cmd.Parameters.Add("@egm", SqlDbType.VarChar, 20).Value = txtegm.Text;
            cmd.Parameters.Add("@igm", SqlDbType.VarChar, 20).Value = txtigm.Text;
            cmd.Parameters.Add("@ata", SqlDbType.VarChar, 20).Value = txtata.Text;
            cmd.Parameters.Add("@atd", SqlDbType.VarChar, 20).Value = txtatd.Text;
            cmd.Parameters.Add("@cnmt", SqlDbType.VarChar, 20).Value = txtcnmt.Text;
            cmd.Parameters.Add("@pax", SqlDbType.VarChar, 20).Value = txtpax.Text;

            cmd.ExecuteNonQuery();
            //Response.Write("Successfully");
            string CITY_ID = Request.QueryString["city_id"];
            string Air_code = Request.QueryString["Airline_code"];
            string Flight_Open_ID = Request.QueryString["fid"];
            string Airline_Detail_ID = Request.QueryString["AID"];
            string FDATE = Request.QueryString["date"];
            Response.Redirect("PFM_Details.aspx?State=Added&city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_ID + "&AID=" + Airline_Detail_ID + "&fno=" + Request.QueryString["fno"] + "&date=" + FDATE + "");
        }
        catch (SqlException mm)
        {
            string serror = mm.Message;

        }
        catch (Exception s)
        {
            Response.Write("Error occur :" + s.Message);
        }
        finally
        {

            cmd.Dispose();
            con.Close();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        txtegm.Text = null;
        txtigm.Text = null;
        txtata.Text = null;
        txtatd.Text = null;
        txtcnmt.Text = null;
        txtpax.Text = null;
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        btnupdate.Visible = false;
        string foid = Request.QueryString["fid"].ToString();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            strquery = "update flight_open set egm=@egm,igm=@igm,ata=@ata, atd=@atd, cnmt=@cnmt, pax=@pax where flight_open_id='" + foid + "'";
            cmd = new SqlCommand(strquery, con);
            cmd.Parameters.Add("@egm", SqlDbType.VarChar, 20).Value = txtegm.Text;
            cmd.Parameters.Add("@igm", SqlDbType.VarChar, 20).Value = txtigm.Text;
            cmd.Parameters.Add("@ata", SqlDbType.VarChar, 20).Value = txtata.Text;
            cmd.Parameters.Add("@atd", SqlDbType.VarChar, 20).Value = txtatd.Text;
            cmd.Parameters.Add("@cnmt", SqlDbType.VarChar, 20).Value = txtcnmt.Text;
            cmd.Parameters.Add("@pax", SqlDbType.VarChar, 20).Value = txtpax.Text;

            cmd.ExecuteNonQuery();
            //Response.Write("Successfully");
            string CITY_ID = Request.QueryString["city_id"];
            string Air_code = Request.QueryString["Airline_code"];
            string Flight_Open_ID = Request.QueryString["fid"];
            string Airline_Detail_ID = Request.QueryString["AID"];
            string FDATE = Request.QueryString["date"];
            Response.Redirect("PFM_Details.aspx?State=Updated&city_id=" + CITY_ID + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_ID + "&AID=" + Airline_Detail_ID + "&fno=" + Request.QueryString["fno"] + "&date=" + FDATE + "");
        }
        catch (SqlException mm)
        {
            string serror = mm.Message;

        }
        catch (Exception s)
        {
            Response.Write("Error occur :" + s.Message);
        }
        finally
        {

            cmd.Dispose();
            con.Close();
        }
    }
}
