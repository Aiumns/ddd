﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
public partial class ChequeCashDepositeReport : System.Web.UI.Page
{
    string city = "";
    int Sid;
    //string CityDest = "";
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    decimal total = 0;
    decimal totalOnCondition = 0;   
    decimal Carting = 0;
    decimal DataProcessingFee = 0;
    decimal CommunicationFee = 0;
    decimal MAWB = 0;
    decimal HAWB = 0;
    decimal srate = 0;
    decimal StaxRate = 0;

    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
    decimal SBCessRate = 0;
    decimal SBCrate = 0;
    decimal KKCessRate = 0;
    decimal KKCrate = 0;
    decimal DOamount = 0;
    decimal Docahrges = 0;
    decimal NetAmount = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        //btnsubmit.Attributes.Add("onclick", "return checkgridcontrols();return false;");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {               
                txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");               
                BindGrid();
            }
        }
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string AwbID = "";

        try
        {
            foreach (GridViewRow gv in GridView1.Rows)
            {
                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                
                    if (ChkBxItem.Checked)
                    {

                        Label lblAgentID = (Label)gv.FindControl("lblAgentID");
                        AwbID = lblAgentID.Text;
                        Label AmountRecevd = (Label)gv.FindControl("lblRecievdAmount");

                        totalOnCondition += decimal.Parse(AmountRecevd.Text == "" ? "0" : AmountRecevd.Text);
                        ////*******************Update Detail in Import_Flight_Awb*************

                        con = new SqlConnection(strCon);
                        con.Open();
                        cmd = new SqlCommand("update Import_Flight_AWB set Deposit_By='" + Session["EMailID"].ToString() + "', DateOfDeposite='" + FormatDateMM(txtValidFrom.Text) + "',Cheque_Cash='Cash',AmountOfAwbOnDepositeDate=" + decimal.Parse(AmountRecevd.Text == "" ? "0" : AmountRecevd.Text) + " where import_awb_id='" + AwbID + "'", con);
                        cmd.ExecuteNonQuery();
                        con.Close();                        
                    }        
            }
            lblFinalTotal.Text = Convert.ToString(totalOnCondition);

            Response.Redirect("CashReport.aspx");
           


        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
            //ClientScript.RegisterStartupScript(GetType(), "Message1", "<SCRIPT LANGUAGE='javascript'>self.close();</script>");

        }

       }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //ClientScript.RegisterStartupScript(GetType(), "Message2", "<SCRIPT LANGUAGE='javascript'>self.close();</script>");
        Response.Redirect("CashReport.aspx");
    }

    public void BindGrid()
    {
        string[] airline_name_city_text = Session["airline_city_text"].ToString().Split(',');
        string[] airline_name_city_value = Session["airline_city_value"].ToString().Split(',');
        string[] air_name_val = airline_name_city_value[0].Split('%');

        //string from_date = Session["from_date"].ToString();
        //string to_date = Session["to_date"].ToString();

        con = new SqlConnection(strCon);
        con.Open();

        ////string StrAgent = "SELECT IFA.Import_awb_id,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,ISNULL(IFA.Tds_Cut_By_Agent,0) AS TDSCUT,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,IFA.Amount_Received,isnull(IFA.Total_Collection_CC,0) as FrtChrgs FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID  WHERE CONVERT(VARCHAR,IFA.issue_date,101) >= '" + FormatDateMM(from_date) + "' and CONVERT(VARCHAR,IFA.issue_date,101) <='" + FormatDateMM(to_date) + "' AND IFA.Airline_Detail_ID=" + airline_name_city_value[0].ToString() + " and payment_mode=1 order by IFA.Recipt_No";
 
        string StrAgent = "";
        if (DateTime.Now < DateTime.Parse("08/01/2017"))
        {
             StrAgent = "SELECT CONVERT(INT, SUBSTRING(Recipt_No,14,LEN(Recipt_No))) AS reciptno, IFA.Import_awb_id,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,ISNULL(IFA.Tds_Cut_By_Agent,0) AS TDSCUT,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,IFA.Amount_Received,isnull(IFA.Total_Collection_CC,0) as FrtChrgs,IFA.DateOfDeposite FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID  WHERE  IFA.Airline_Detail_ID=" + airline_name_city_value[0].ToString() + " and payment_mode=1 and IFA.DateOfDeposite is null order by  reciptno";
        }
        else
        {
             StrAgent = "SELECT CONVERT(INT, SUBSTRING(Recipt_No,11,LEN(Recipt_No))) AS reciptno, IFA.Import_awb_id,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,ISNULL(IFA.Tds_Cut_By_Agent,0) AS TDSCUT,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,IFA.Amount_Received,isnull(IFA.Total_Collection_CC,0) as FrtChrgs,IFA.DateOfDeposite FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID  WHERE  IFA.Airline_Detail_ID=" + airline_name_city_value[0].ToString() + " and payment_mode=1 and IFA.DateOfDeposite is null order by  reciptno";
        }

        ////string StrAgent = "SELECT CONVERT(INT, SUBSTRING(Recipt_No,14,LEN(Recipt_No))) AS reciptno, IFA.Import_awb_id,ISNULL( IFA.Total_Collection_CC,0) AS Total_Collection_CC,IFA.Recipt_No,IFA.import_awb_no,convert(varchar,IFA.Import_Awb_Date,103) as Import_Awb_Date,IFS.Import_Flight_No as Import_Flight_No,convert(varchar,IFS.Import_Flight_Date,103) as flight_date,convert(varchar,IFA.issue_date,103) as Amt_recd_date,IFA.Agent_Name,ISNULL(IFA.Freight_Chgs,0) AS Freight_Chgs,isnull(IFA.No_of_Houses,0) as No_of_Houses,ISNULL(IFA.cc_cheque_amount,0) AS payable_amount,ISNULL(IFA.Amount_Received,0) AS Amount_Received,IFS.IGM_NO,IFA.Consignee_Name,IFA.Destination,ISNULL(IFA.pcs,0) AS pcs,ISNULL(IFA.Gross_Weight,0) AS Gross_Weight,ISNULL(IFA.Tds_Cut_By_Agent,0) AS TDSCUT,ISNULL(IFA.Charged_Weight,0) AS Charged_Weight,(case when IFA.Freight_type='PP' then 'P' else 'C' end ) as Freight_type,isnull(IFA.CC_Cheque_Amount,0) as CC_Cheque_Amount,IFA.Amount_Received,isnull(IFA.Total_Collection_CC,0) as FrtChrgs,IFA.DateOfDeposite FROM db_owner.Import_Flight_AWB IFA INNER JOIN db_owner.Import_Flights IFS ON IFA.Import_Flight_ID=IFS.Import_Flight_ID INNER JOIN dbo.Airline_Detail ad ON IFA.Airline_Detail_ID=ad.Airline_Detail_ID  WHERE  IFA.Airline_Detail_ID=" + airline_name_city_value[0].ToString() + " and payment_mode=1  order by  reciptno";

        SqlDataAdapter sda = new SqlDataAdapter(StrAgent, con);
        DataTable dt = new DataTable();
        sda.Fill(dt);

        #region Receved Amount

        string TDS = "0";
        string FrtChrgs = "0";
        //string MawbDo_Chgs = "0", HawbDo_Chgs = "0", STAXRATE = "0";
        decimal Alltotal = 0; decimal InnerTotal = 0;
        decimal RecivdAmtAfterStax = 0;
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                TDS = "0";
                FrtChrgs = "0";
                InnerTotal = 0;
                RecivdAmtAfterStax = 0;

                //************************added on 27 May 2011*********

                MAWB = 0;
                HAWB = 0;
                Carting = 0;
                StaxRate = 0;
                srate = 0;

                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                SBCessRate = 0;
                SBCrate = 0;
                KKCessRate = 0;
                KKCrate = 0;
                CommunicationFee = 0;
                DataProcessingFee = 0;
                DOamount = 0;
                Docahrges = 0;

                //*************************END*********************************


                DataTable dtImportAwbTrans = dw.GetAllFromQuery("select * from ImportFlightAwb_Trans where ImportAWBID='" + dt.Rows[i]["Import_awb_id"].ToString() + "'");
                for (int k = 0; k < dtImportAwbTrans.Rows.Count; k++)
                {
                    if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "MAWB")
                        MAWB = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                    else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "HAWB")
                        HAWB = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                    else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "Carting")
                        Carting = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                    else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "StaxRate")
                    {
                        StaxRate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        srate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeRate"].ToString()); ;
                    }
                    else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "CommunicationFee")
                        CommunicationFee = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                    else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "DataProcessingFee")
                        DataProcessingFee = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                    else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "SBCess")
                    {
                        SBCessRate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        SBCrate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeRate"].ToString()); ;
                    }

                   //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    else if (dtImportAwbTrans.Rows[k]["ChargeName"].ToString() == "KKCess")
                    {
                        KKCessRate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeAmount"].ToString());
                        KKCrate = Convert.ToDecimal(dtImportAwbTrans.Rows[k]["ChargeRate"].ToString()); ;
                    }
                }

                if ((airline_name_city_value[0].ToString() == "147")||(airline_name_city_value[0].ToString() == "153"))
                {
                    DOamount = MAWB;
                    Docahrges = MAWB;
                }
                else if (airline_name_city_value[0].ToString() == "159")
                {
                    //*******************added on 15June2015 :For KE-MUM, flt No HY-127 case******//
                    if ((dt.Rows[i]["Import_flight_No"].ToString() == "HY-127" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9343" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9311" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9313" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9345" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9397"))
                    {

                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ////MAWB = Math.Floor(Convert.ToDecimal(MAWB) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBCrate)) / 100)));
                        MAWB = Math.Floor(Convert.ToDecimal(MAWB) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBCrate) + Convert.ToDecimal(KKCrate)) / 100)));
                        DOamount = MAWB + HAWB;
                    }
                    else
                    {
                        DOamount = MAWB + HAWB;
                    }
                    //*******************End of 15June2015 :For KE-MUM, flt No HY-127 case******//
                    ////// DOamount = MAWB + HAWB;
                    ////////if (StaxRate.ToString() == "0.00")
                    ////////    Docahrges = DOamount;
                    ////////else
                        //*******************added on 15June2015 :For KE-MUM, flt No HY-127 case******//
                        if ((dt.Rows[i]["Import_flight_No"].ToString() == "HY-127" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9343" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9311" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9313" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9345" || dt.Rows[i]["Import_flight_No"].ToString() == "KE-9397"))
                        {
                            Docahrges = DOamount;
                        }
                        else
                        {
                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            ////Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBCrate)) / 100)));
                            Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate) + Convert.ToDecimal(SBCrate) + Convert.ToDecimal(KKCrate)) / 100)));
                        }
                    //*******************End of 15June2015 :For KE-MUM, flt No HY-127 case******//
                    ///////Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate)) / 100)));
                    //////DOamount = MAWB + HAWB;
                    //////if (StaxRate.ToString() == "0.00")
                    //////    Docahrges = DOamount;
                    //////else
                    //////    Docahrges = Math.Floor(Convert.ToDecimal(DOamount) / (1 + ((Convert.ToDecimal(srate)) / 100)));


                }

                else
                {
                    DOamount = MAWB + HAWB;

                    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    Docahrges = DOamount - StaxRate - SBCessRate - KKCessRate;
                }


                
                if ((airline_name_city_value[0].ToString() == "147")||(airline_name_city_value[0].ToString() == "153"))
                    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    ////InnerTotal = DOamount + StaxRate +SBCessRate + Carting + CommunicationFee + DataProcessingFee + HAWB + Convert.ToDecimal(dt.Rows[i]["Total_Collection_CC"].ToString()) - Convert.ToDecimal(dt.Rows[i]["TDSCUT"].ToString());
                    InnerTotal = DOamount + StaxRate + SBCessRate + KKCessRate + Carting + CommunicationFee + DataProcessingFee + HAWB + Convert.ToDecimal(dt.Rows[i]["Total_Collection_CC"].ToString()) - Convert.ToDecimal(dt.Rows[i]["TDSCUT"].ToString());
                else
                    ////InnerTotal = Docahrges + StaxRate +SBCessRate + Carting + CommunicationFee + DataProcessingFee + Convert.ToDecimal(dt.Rows[i]["Total_Collection_CC"].ToString()) - Convert.ToDecimal(dt.Rows[i]["TDSCUT"].ToString());
                    InnerTotal = Docahrges + StaxRate + SBCessRate + KKCessRate + Carting + CommunicationFee + DataProcessingFee + Convert.ToDecimal(dt.Rows[i]["Total_Collection_CC"].ToString()) - Convert.ToDecimal(dt.Rows[i]["TDSCUT"].ToString());


                Alltotal += InnerTotal;

                dt.Rows[i]["Amount_Received"] = Convert.ToString(InnerTotal);
            }


        #endregion

            GridView1.DataSource = dt;
            GridView1.DataBind();

            //  added on 5thseptember//

            if (airline_name_city_value[0].ToString() == "147")
            {
                foreach (GridViewRow gv in GridView1.Rows)
                {
                    CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                    ChkBxItem.Checked = false;
                }
            }

            //////
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                total += decimal.Parse(dt.Rows[i]["Amount_Received"].ToString() == "" ? "0" : dt.Rows[i]["Amount_Received"].ToString());
            }

            Label LblAwbID = (Label)GridView1.FooterRow.FindControl("lblTotal");
            LblAwbID.Text = Convert.ToString(total);
            sda.Dispose();
            con.Close();
        }
        else
        {
            TrTotal.Visible = false;
            Trbutton.Visible = false;
            lblmessage.Visible = true;
            lblmessage.Text = "No Record Found";


        }
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
        }
    }
    protected void btnTotalAmt_Click(object sender, EventArgs e)
    {
        string AwbID = "";

        try
        {


            foreach (GridViewRow gv in GridView1.Rows)
            {
                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");

                if (ChkBxItem.Checked)
                {

                    Label lblAgentID = (Label)gv.FindControl("lblAgentID");
                    AwbID = lblAgentID.Text;
                    Label AmountRecevd = (Label)gv.FindControl("lblRecievdAmount");

                    totalOnCondition += decimal.Parse(AmountRecevd.Text == "" ? "0" : AmountRecevd.Text);
                    ////*******************Update Detail in Import_Flight_Awb*************

                    ////con = new SqlConnection(strCon);
                    ////con.Open();
                    ////cmd = new SqlCommand("update Import_Flight_AWB set DateOfDeposite='" + FormatDateMM(txtValidFrom.Text) + "',Cheque_Cash='Cash',AmountOfAwbOnDepositeDate=" + decimal.Parse(AmountRecevd.Text == "" ? "0" : AmountRecevd.Text) + " where import_awb_id='" + AwbID + "'", con);
                    ////cmd.ExecuteNonQuery();
                    ////con.Close();

                }



            }

            lblFinalTotal.Text = Convert.ToString(totalOnCondition);





        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    } 
}
