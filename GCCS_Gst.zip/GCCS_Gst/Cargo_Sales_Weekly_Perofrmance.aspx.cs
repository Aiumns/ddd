using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Cargo_Sales_Weekly_Perofrmance : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlConnection con2 = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    SqlCommand cmd2 = null;
    SqlDataReader dr2 = null;
    agentNNCal agentnn = new agentNNCal();
    string from = "";
    string to = "";
    string from_month = "";
    string to_month = "";
    string strY = "";
    bool year_flag = false;
    int next = 0;
    string mon_year = "";
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string Table = "";
    int Total_sr_no = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }

        string from_date = Request.QueryString["from"];
        string to_date = Request.QueryString["to"];
        bool flag = false;
        from = from_date;
        to = to_date;
        Table += @"<center><strong>" + Request.QueryString["airline_name"] + "/" + Request.QueryString["city_name"] + "<br>Cargo Sales Weekly Performance Report</strong></center>";

        Table += @"<center><span class=text>From : <b>" + from_date + "-" + to_date + "<b><em>(ALL SHIPMENTS)</em></span></center><br> ";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();

            cmd = new SqlCommand("GetFlightNo_WeekelyReports", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Request.QueryString["airline_detail_id"].ToString();
            cmd.Parameters.Add("@From_Date", SqlDbType.VarChar).Value = FormatDateMM(from_date);
            cmd.Parameters.Add("@To_Date ", SqlDbType.VarChar).Value = FormatDateMM(to_date);
            cmd.Parameters.Add("@City_ID", SqlDbType.Int).Value = Request.QueryString["city_code"].ToString();
            cmd.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = Request.QueryString["Flight_No"].ToString();

            cmd.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();

            //cmd = new SqlCommand("select distinct Flight_date,Flight_no from sales  where airline_detail_id=" + Request.QueryString["airline_detail_id"] + " and Flight_date between '" + FormatDateMM(from_date) + "' and '" + FormatDateMM(to_date) + "' and city_id=" + Request.QueryString["city_code"] + "", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet("Table1");
            da.Fill(ds, "Table1");
            if (ds.Tables[0].Rows.Count > 0)
            {
                int Total_flights = 0;
                decimal Total_Rate = 0;
                decimal Yield_Rate = 0;
                decimal Total_Charged_Weight = 0;
                decimal Total_Excluding_MYC = 0;
                decimal Total_Including_MYC = 0;
                decimal Total_Awb = 0;
                decimal Total_Yield = 0;
                int Sno = 0;
                string count_date = "";
                int x = noOfMonths(from, to_date, 2);

                Table += @"<table border=1 width=98% align=center> ";
                Table += @"<tr align=center class=text>";
                Table += @"</tr>";
                Table += @"<tr align=center class=report_head>";
                Table += @"<td><b>Sr No.</b></td>";
                Table += @"<td><b>AWB No.</b></td>";
                Table += @"<td><b>Dstn.</b></td>";
                Table += @"<td><b>Unit Rate</b></td>";
                Table += @"<td><b>CH WT.</b></td>";

                if (Request.QueryString["airline_detail_id"].ToString() == "150")
                {
                    Table += @"<td><b>Revenue Excl. FSC|WSC|X-RAY </b></td>";
                    Table += @"<td><b>Revenue Incl. FSC|WSC|X-RAY </b></td>";
                }
                else if (Request.QueryString["airline_detail_id"].ToString() == "149")
                {
                    Table += @"<td><b>Revenue Excl. FSC|WSC|X-RAY|AWB FEE </b></td>";
                    Table += @"<td><b>Revenue Incl. FSC|WSC|X-RAY|AWB FEE </b></td>";
                }
                else
                {
                    Table += @"<td><b>Revenue Excl. MYC/ FSC </b></td>";
                    Table += @"<td><b>Revenue Incl. MYC/ FSC </b></td>";
                }

                Table += @"<td><b>Yield.</b></td>";
                Table += @"</tr>";

                con2 = new SqlConnection(strCon);
                con2.Open();
                for (int i = 0; i < x; ++i)
                {
                    //getdate(from, Convert.ToInt32(from_month) + next);
                    next++;

                    //cmd = new SqlCommand("select distinct convert(varchar,Flight_date,103)AS flight_date,Flight_no from sales  where airline_detail_id=" + Request.QueryString["airline_detail_id"] + " and Flight_date between '" + FormatDateMM(from_date) + "' and '" + FormatDateMM(to_date) + "' and city_id=" + Request.QueryString["city_code"] + "", con);

                    //SqlDataAdapter daP = new SqlDataAdapter(cmd);
                    //DataSet ds = new DataSet("Table1");
                    //daP.Fill(ds, "Table1");
                    //between '" + from + "' and '" + to + "'
                    int G_total_no_of_flights = 0;
                    decimal G_Rate = 0;
                    decimal G_Yield = 0;
                    decimal G_Charged_Weight = 0;
                    decimal G_Excluding_MYC = 0;
                    decimal G_Including_MYC = 0;
                    decimal G_AirwayBill = 0;
                    //foreach (DataRow drow in ds.Tables[0].Rows)
                    //{
                    for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                    {
                        
                        Table += @"<tr><td align=center colspan=8 class=h1 text><b>Flight Date:" + ds.Tables[0].Rows[j]["Flight_Date"].ToString() + " and Flight_No:" + ds.Tables[0].Rows[j]["Flight_No"].ToString() + "</b></td></tr>";
                        if (Request.QueryString["airline_detail_id"].ToString() == "150")
                        {
                            cmd = new SqlCommand("Weekly_report_Ascent", con);
                        }
                        else if(Request.QueryString["airline_detail_id"].ToString() == "149")
                        {
                            cmd = new SqlCommand("Weekly_report_AscentCI", con);
                        }
                        else
                        {
                            cmd = new SqlCommand("Weekly_report", con);
                        }
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(Request.QueryString["airline_detail_id"]);
                        cmd.Parameters.Add("@City_id", SqlDbType.Int).Value = int.Parse(Request.QueryString["city_code"].ToString());
                        cmd.Parameters.Add("@From_date", SqlDbType.DateTime).Value = DateTime.Parse(FormatDateMM(ds.Tables[0].Rows[j]["Flight_Date"].ToString()));
                        cmd.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ds.Tables[0].Rows[j]["Flight_No"];
                        dr = cmd.ExecuteReader();
                        if (dr.HasRows)
                        {
                            int total_no_of_flights = 0;
                            decimal Rate = 0;
                            decimal Charged_Weight = 0;
                            decimal Excluding_MYC = 0;
                            decimal Including_MYC = 0;
                            decimal Awb_no = 0;
                            while (dr.Read())
                            {
                                Sno = Sno + 1;
                                Total_sr_no = Total_sr_no + 1;
                                count_date = dr["Flight_date"].ToString();
                                Table += @"<tr class=text onclick=ChangeColor(this); >";
                                Table += @"<td  nowrap><b>" + Sno + "</b></td>";
                                Table += @"<td align=center nowrap><b>" + dr["AirWayBill_No"].ToString() + "</b></td>";
                                //Table += @"<td align=center ><b>" + dr["Flight_date"].ToString() + "</b></td>";
                                //Table += @"<td align=center nowrap><b>" + dr["Flight_No"].ToString() + "</b></td>"; 
                                Table += @"<td align=center><b>" + dr["Destination_Code"].ToString() + "</b></td>";
                                Table += @"<td align=center ><b>" + dr["Rate"].ToString() + "</b></td>";
                                Table += @"<td align=center ><b>" + dr["Charged_Weight"].ToString() + "</b></td>";
                                Table += @"<td align=center><b>" + dr["Excluding_MYC"].ToString() + "</b></td>";
                                Table += @"<td align=center><b>" + dr["Including_MYC"].ToString() + "</b></td>";
                                //Table += @"<td align=center><b>" + dr["Destination_Code"].ToString() + "</b></td>";
                                //Table += @"<td align=center><b>" + Convert.ToString(decimal.Parse(dr["Including_MYC"].ToString())/decimal.Parse(dr["Charged_Weight"].ToString()))+"</b></td>";
                                Table += @"<td align=center>&nbsp</td>";
                                Table += @"</tr>";
                                total_no_of_flights = total_no_of_flights + 1;
                                Rate = Rate + decimal.Parse(dr["Rate"].ToString());
                                Charged_Weight = Charged_Weight + decimal.Parse(dr["Charged_Weight"].ToString());
                                //Awb_no = Awb_no + decimal.Parse(dr["AirWayBill_No"].ToString());
                                Excluding_MYC = Excluding_MYC + decimal.Parse(dr["Excluding_MYC"].ToString());
                                Including_MYC = Including_MYC + decimal.Parse(dr["Including_MYC"].ToString());
                                Yield_Rate = Math.Round(Including_MYC / Charged_Weight, 4);
                            }
                            dr.Close();
                            flag = true;
                            if (flag)
                            {
                                Table += @"<tr class=h1>";
                                Table += @"<td nowrap><b>" + getMonthName(ds.Tables[0].Rows[j]["Flight_Date"].ToString()) + "</b></td>";
                                Table += @"<td align=center><b>" + Sno + "</b></td>";
                                Table += @"<td align=center>&nbsp</td>";
                                Table += @"<td><b>&nbsp;</b></td>";
                                Table += @"<td align=center><b>" + Charged_Weight + "</b></td>";
                                Table += @"<td align=center><b>" + Excluding_MYC + "</b></td>";
                                Table += @"<td align=center><b>" + Including_MYC + "</b></td>";
                                Table += @"<td align=center><b>" + Yield_Rate + "</b></td>";
                                //Table += @"<td><b>&nbsp;</b></td>";
                                Table += @"</tr>";
                                Table += @"<tr class=text>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"<td>&nbsp;</td>";
                                Table += @"</tr>";
                                Sno = 0;
                                ////////////////Calculation For Grand Total//////////////////////////
                                G_total_no_of_flights = G_total_no_of_flights + total_no_of_flights;
                                //G_AirwayBill = G_AirwayBill + Awb_no;
                                G_Rate = G_Rate + Rate;
                                G_Charged_Weight = G_Charged_Weight + Charged_Weight;
                                G_Excluding_MYC = G_Excluding_MYC + Excluding_MYC;
                                G_Including_MYC = G_Including_MYC + Including_MYC;
                                G_Yield = G_Yield + Yield_Rate;
                            }
                            dr.Close();
                        }
                        else
                        {
                            dr.Close();
                        }
                        /////////////////////////////////////////////////////////////////////////////
                    }
                    ////////////////Calculation For Grand Total//////////////////////////
                    Total_flights = Total_flights + G_total_no_of_flights;
                    //Total_Awb = Total_Awb + G_AirwayBill;
                    Total_Rate = Total_Rate + G_Rate;
                    Total_Charged_Weight = Total_Charged_Weight + G_Charged_Weight;
                    //Total_Volume_Weight = Total_Volume_Weight + G_Volume_Weight;
                    Total_Excluding_MYC = Total_Excluding_MYC + G_Excluding_MYC;
                    Total_Including_MYC = Total_Including_MYC + G_Including_MYC;
                    Total_Yield = Total_Yield + G_Yield;
                    ds.Clear();
                    flag = false;
                }
                Table += @"</tr>";
                Table += @"<tr class=h1>";
                Table += @"<td><b>Grand Total</b></td>";
                Table += @"<td align=center><b>" + Total_sr_no + "</b></td>";
                //Table += @"<td align=center><b>" + Total_Rate + "</b></td>";
                Table += @"<td align=center><b>&nbsp</b></td>";
                Table += @"<td align=center><b>&nbsp</b></td>";
                Table += @"<td align=center> <b>" + Total_Charged_Weight + "</b></td>";
                Table += @"<td align=center><b>" + Total_Excluding_MYC + "</b></td>";
                Table += @"<td align=center> <b>" + Total_Including_MYC + "</b></td>";
                Table += @"<td align=center ><b>" + Math.Round(Total_Including_MYC / Total_Charged_Weight, 4) + "</b></td>";
                Table += @"</tr>";
                Table += @"</table>";
                Label1.Text = Table;
            }
            else
            {
                Table += @"<center><span class=error><b>No Record Found</b></span></center>";
                Label1.Text = Table;
            }
        }
        catch (Exception eror)
        {

            string s = eror.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
            cmd.Dispose();

        }
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public int noOfMonths(string date, string date2, int sel)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];

        from_month = d[1];

        string[] d2 = date2.Split(new char[] { '/' });
        string strMM2 = d2[1];
        string strDD2 = d2[0];
        string strYYYY2 = d2[2];

        to_month = d2[1];

        int diff = 0;

        switch (sel)
        {
            case 1:
                diff = Convert.ToInt16(strDD2) - Convert.ToInt16(strDD);
                break;
            case 2:

                DateTime dt1 = Convert.ToDateTime(FormatDateMM(date));
                DateTime dt2 = Convert.ToDateTime(FormatDateMM(date2));
                int c_mon = 0;
                for (DateTime x = dt1; x <= dt2; x = x.AddMonths(1))
                {
                    c_mon = c_mon + 1;
                }

                diff = c_mon;


                //TimeSpan t = DateTime.Parse(to) - DateTime.Parse(from);
                // int month_diff = t.Days; 
                // int months = Convert.ToInt16(Math.Floor(Convert.ToDouble(month_diff) /30.475)) ;
                //diff = Convert.ToInt16(strMM2) - Convert.ToInt16(strMM) + 1;
                break;
            case 3:
                diff = Convert.ToInt16(strYYYY2.Substring(0, 3)) - Convert.ToInt16(strYYYY.Substring(0, 3));
                break;
        }

        return diff;
    }

    public void getdate(string date, int month_count)
    {
        string[] d = date.Split('/');
        strY = d[2];
        if (year_flag)
        {
            strY = Convert.ToString(Convert.ToInt16(strY) + 1);
        }
        else
        {
            strY = d[2];
        }


        switch (month_count)
        {
            case 1:
                from = "01/01/" + strY;
                to = "01/31/" + strY;
                year_flag = false;
                break;
            case 2:

                from = "02/01/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    to = "02/29/" + strY;
                else
                {
                    to = "02/28/" + strY;
                }
                year_flag = false;
                break;
            case 3:
                from = "03/01/" + strY;
                to = "03/31/" + strY;
                year_flag = false;
                break;
            case 4:
                from = "04/01/" + strY;
                to = "04/30/" + strY;
                year_flag = false;

                break;
            case 5:
                from = "05/01/" + strY;
                to = "05/31/" + strY;
                year_flag = false;

                break;
            case 6:
                from = "06/01/" + strY;
                to = "06/30/" + strY;
                year_flag = false;

                break;
            case 7:
                from = "07/01/" + strY;
                to = "07/31/" + strY;
                year_flag = false;
                break;
            case 8:
                from = "08/01/" + strY;
                to = "08/31/" + strY;
                year_flag = false;
                break;
            case 9:
                from = "09/01/" + strY;
                to = "09/30/" + strY;
                year_flag = false;
                break;
            case 10:
                from = "10/01/" + strY;
                to = "10/31/" + strY;
                year_flag = false;
                break;
            case 11:
                from = "11/01/" + strY;
                to = "11/30/" + strY;
                year_flag = false;
                break;
            case 12:
                from = "12/01/" + strY;
                to = "12/31/" + strY;
                year_flag = true;
                next = 0;
                from_month = "1";
                break;

        }
    }
    public string getMonthName(string month)
    {
        string[] mon = month.Split('/');
        string ret_date = "";
        strY = mon[2];
        if (year_flag)
        {
            strY = Convert.ToString(Convert.ToInt16(strY) + 1);
        }
        else
        {
            strY = mon[2];
        }
        switch (Convert.ToInt16(mon[1]))
        {
            case 1:
                ret_date = "Jan,";
                break;
            case 2:
                ret_date = "Feb,";
                break;
            case 3:
                ret_date = "Mar,";
                break;
            case 4:
                ret_date = "Apr,";
                break;
            case 5:
                ret_date = "May-";
                break;
            case 6:
                ret_date = "June,";
                break;
            case 7:
                ret_date = "Jul,";
                break;
            case 8:
                ret_date = "Aug,";
                break;
            case 9:
                ret_date = "Sep,";
                break;
            case 10:
                ret_date = "Oct,";
                break;
            case 11:
                ret_date = "Nov,";
                break;
            case 12:
                ret_date = "Dec,";
                year_flag = true;
                next = 0;
                from_month = "1";
                break;
        }
        return mon[0] + "" + ret_date + strY;
    }
    public string getMonthName1(string month)
    {
        string[] mon = month.Split('/');
        string ret_date = "";
        strY = mon[2];
        if (year_flag)
        {
            strY = Convert.ToString(Convert.ToInt16(strY) + 1);
        }
        else
        {
            strY = mon[2];
        }
        switch (Convert.ToInt16(mon[1]))
        {
            case 1:
                ret_date = "Jan,";
                break;
            case 2:
                ret_date = "Feb,";
                break;
            case 3:
                ret_date = "Mar,";
                break;
            case 4:
                ret_date = "Apr,";
                break;
            case 5:
                ret_date = "May-";
                break;
            case 6:
                ret_date = "June,";
                break;
            case 7:
                ret_date = "Jul,";
                break;
            case 8:
                ret_date = "Aug,";
                break;
            case 9:
                ret_date = "Sep,";
                break;
            case 10:
                ret_date = "Oct,";
                break;
            case 11:
                ret_date = "Nov,";
                break;
            case 12:
                ret_date = "Dec,";
                year_flag = true;
                next = 0;
                from_month = "1";
                break;
        }
        return ret_date + strY.Substring(2, 2);
    }
}
