using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

using System.IO;
using System.Net;
public partial class flight_breakup_large : System.Web.UI.Page
{

    /// <summary>
    /// 
    /// </description>
    /// <createdBy>--------SHAIKH AKHTAR RASOOL--------</createdBy>
    /// <modified by>Shaikh Akhtar Rasool </modified>
    /// <modifiedon>16-01-2008</modifiedon>
    /// </summary>






    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        String airline_access = Session["AIRLINEACCESS"].ToString();
        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");

        if (!IsPostBack)
        {


           //set Hidden field on IP Basis
            if (IPCheck())
            {
                hdnCheckIP.Value = "Internal";
            }
            else
            {
                hdnCheckIP.Value = "Outer";
                //Generate OTP on first call to page
                /////OTPPwd();
            }
            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            hdnDate.Value = first.ToString();

            DateTime DTM;
            DTM = DateTime.Now.AddMonths(6);

            txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            try
            {
                // airline_access = airline_access.Substring(0, airline_access.Length - 1);
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));
                }
                cmd.Dispose();
            }
            catch (Exception eror)
            {
                string st = eror.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
                cmd.Dispose();

            }
        }
    }

    public string GetUserIp()
    {
        string VisitorsIPAddr = string.Empty;
        //Users IP Address.
        if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
        {
            //To get the IP address of the machine and not the proxy
            VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
        }
        else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
        {
            VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
        }
        return VisitorsIPAddr;



    }
    protected void Btnload_Click(object sender, EventArgs e)
    {


        #region IPCheck
        //string IP = GetUserIp();
        //if (IP != "")
        //{
        //    string[] ip_addrs = IP.Split('.');
        //    if (ip_addrs.Length == 4)
        //    {

        //        con = new SqlConnection(strCon);
        //        con.Open();
        //        string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on)VALUES( '" + IP + "','" + DateTime.Now + "')";
        //        com = new SqlCommand(cInsert, con);
        //        com.ExecuteNonQuery();
        //        con.Close();


        //        if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
        //        {
        //        }
        //        else
        //        {
        //            ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact asrao@cargoflash.com');</script>");
        //            return;
        //        }
        //    }
        //    else
        //    {
        //        ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact asrao@cargoflash.com');</script>");
        //        return;
        //    }
        //}
        //else
        //{
        //    ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact asrao@cargoflash.com');</script>");
        //    return;
        //}
        #endregion

        if (hdnCheckIP.Value == "Outer")
        {

            //if (hdnOTP.Value == ViewState["currentOtp"].ToString())
            //{
                Session["selected_airline_text"] = ddl_airline_city.SelectedItem.Text;
                Session["selected_airline_value"] = ddl_airline_city.SelectedItem.Value;
                Session["from_date"] = txtValidFrom.Text;
                Session["to_date"] = txtValidTo.Text;
                Session["FscDem"] = RadioButtonList1.SelectedValue;



                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/flight_breakup_mal_new.aspx?query=" + rdo_ship.Text + "');</script>");

            ////}
            ////else
            ////{
            ////    ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Invalid OTP, Please Check.');</script>");
            ////}
        }
        else
        {
            Session["selected_airline_text"] = ddl_airline_city.SelectedItem.Text;
            Session["selected_airline_value"] = ddl_airline_city.SelectedItem.Value;
            Session["from_date"] = txtValidFrom.Text;
            Session["to_date"] = txtValidTo.Text;
            Session["FscDem"] = RadioButtonList1.SelectedValue;



            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/flight_breakup_mal_new.aspx?query=" + rdo_ship.Text + "');</script>");
            //string page_pop = "<SCRIPT language='javascript'>window.open('./Reports/flight_breakup_mal.aspx?query=" + rdo_ship.Text + "');</SCRIPT>";
            //Response.Write(page_pop);
        }
    }

    #region Generate Unique One Time Password
    private void OTPPwd()
    {
        string oTP = Convert.ToString(DateTime.Now.Second + 70096 + DateTime.Now.Minute);
        ViewState["currentOtp"] = oTP;

        SendSMS("Your OTP is: " + oTP + " ,Use these 5 digit's code to view the report.");

    }
    #endregion
    #region TO Check IP whether access from outside from office or not
    private Boolean IPCheck()
    {
        #region IPCheck
        string IP = GetUserIp();//"178.1.2.63";
        if (IP != "")
        {
            string[] ip_addrs = IP.Split('.');
            if (ip_addrs.Length == 4)
            {
                string currentPageName = System.IO.Path.GetFileName(Request.Url.AbsolutePath);
                con = new SqlConnection(strCon);
                con.Open();
                string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on,Email_ID,Page_Name)VALUES( '" + IP + "','" + DateTime.Now + "','" + Session["EMailID"].ToString() + "','" + currentPageName + "')";
                com = new SqlCommand(cInsert, con);
                com.ExecuteNonQuery();
                con.Close();
                ///192.168.2.18

                if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
        #endregion
    }
    #endregion

    #region For Sending Alert on SMS
    public void SendSMS(string fmessage)
    {
        try
        {

            int Status = 0;
            string StatusMessage = "";
            string str = "";
            string pushURL = "http://www.myvaluefirst.com/smpp/sendsms?username=cargoflash&password=cargohtp&to=@mobileno&from=Cargoflash&text=@message";
            pushURL = pushURL.Replace("@message", fmessage);
            pushURL = pushURL.Replace("@mobileno", GetMobileNo());
            // Get HTML data
            WebClient client = new WebClient();
            Stream data = client.OpenRead(pushURL);
            StreamReader reader = new StreamReader(data);
            str = reader.ReadToEnd();
            data.Close();
            if (str.StartsWith("0,"))
                Status = 0;
            else
                Status = 1;
            StatusMessage = str;
            str = StatusMessage.Substring(StatusMessage.IndexOf("Sent") + "Sent".Length + 1).Trim();
        }
        catch (Exception ee)
        {

        }
    }
    #endregion
    private string GetMobileNo()
    {
        string mobileNo = "";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("SELECT Mobile FROM dbo.User_Master WHERE Email='" + Convert.ToString(Session["EMailID"]) + "'", con);
            mobileNo = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
        return mobileNo;
    }


}
