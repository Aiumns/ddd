using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;

#region Created  by Mukul Chandra
/// <summary>
/// <class>Add Stock</class>
/// <description>
/// This Page intended to provides page level functionalitities and manage events
/// </description>
/// <dependency>Tables : one-one, one-many</dependency>
/// <createdBy></createdBy>
/// <createdOn></createdOn>
/// <modifications>
/// 
/// <modification>
/// <changeDescription></changeDescription>
/// <modifiedBy>Mukul Chandra</modifiedBy>
/// <modifiedOn>23/10/2007</modifiedOn>
/// <modifiedby>Mukul Chandra</modifiedby>
/// <modifiedOn></modifiedOn>
/// <changeDescription></changeDescription>
/// </modification>
/// </modifications> 
/// </summary> 
///
#endregion

public partial class AddStock : System.Web.UI.Page
{
    //SqlTransaction trans = null;//For Tracing Transaction
    SqlConnection con;//For Making Connection
    SqlCommand cmd;//For Defining Command
    SqlDataReader dr;//For Getting Records
    string strQuery;//For Sending Query.
    bool AWB = false;//For Checking AWB No Existance
    string cityid;
    string cityname;

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;//Getting Connection String For Web.config File.


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            btnAdd.Attributes.Add("onclick", "return popup()");
       
            btnReturn.Visible = false;//Making Back Button Not Visible
            lblMsgC.Visible = false;//Making Msg label Not Visible
            lblMsgR.Visible = false;//Making Msg label Not Visible
            btnAdd.Enabled = false;//Making Add Button Not Enabled
            if (!IsPostBack)//Checking PostBack Of Page.
            {
                ddlfillairlinecode();
               
                txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");//On Load Assign Present Date To Date TextBox
               
            }
        }
    }

    //Event Handler For Clear Button
    protected void btnClear_Click(object sender, EventArgs e)
    {
        lstAWB.Items.Clear();
        txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");//Displaying Current Date After Clear Entry
        ddlAWB.SelectedIndex = 0;//Set Default Value as Selected In DropDownList
        txtAWB.Text = "";//Blanking TextBoxes
        txtAWBN.Text = "";//Blanking TextBoxes  
        Label1.Visible = false;
        lblfl.Visible = false;
    }

    //Event Handler For Add Button.
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //btnAdd.Attributes.Add("onclick", " javascript: return confirm('do you want to continue ')");
        //btnAdd.Attributes.Add("onclick", "return popup()");
       
        lblMsgR.Text = null;
        if (IsValid)
        {
            string[] str = lstAWB.Text.Split('\n');//Getting AWB No in a String Array.
            int nos = lstAWB.Items.Count;//Counting Nos of AWBs
            string date = ConvertDate(txtDate.Text);//Converting Date to proper Format
            if (nos > 0)//Checking For Existence Of AWB No.
            {
                int lot = lotNoCheck() + 1;//Generating Receipt_LotNo
                //Loop For Inserting Values To DataBases.
                using (con)
                {
                    con = new SqlConnection(strCon);//Making Connection         
                    con.Open();//Open Connection
                    for (int cont = 0; cont < nos; cont++)
                    {
                        try
                        {
                            if (lstAWB.Items[cont].ToString() != "")//Checking For Blank AwbNos
                            {
                                string city = ddlAWB.SelectedItem.Text;
                                string[] citycode = city.Split(',');
                                //strQuery="select City_Id,City_name from city_master where City_Code='"+citycode[1] +"'";
                                cmd = new SqlCommand("citymatter", con);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("City_Code", SqlDbType.VarChar, 50).Value = citycode[1];
                                dr = cmd.ExecuteReader();
                                dr.Read();
                                cityid = dr["city_id"].ToString();
                                cityname = dr["City_name"].ToString();
                                dr.Close();


                                string strNeut = "";
                                if (chkNeutral.Checked == true)
                                {
                                    strNeut = "Y";
                                }
                                else
                                {
                                    strNeut = "N";
                                }
                                //strQuery = "INSERT INTO Stock_Master(AirWayBill_No,Receipt_Date,Receipt_LotNo,Status,Created_By,Created_On,City_ID) Values('" + lstAWB.Items[cont].ToString().Substring(0, 12) + "','" + date + "'," + lot + ",'8','" + Session["EMailID"] + "','" + DateTime.Now + "','" + cityid + "')";//Giving Query String For Inserting Values To Stock_Master.
                                cmd = new SqlCommand("stockinsert", con);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("@airwaybill_no", SqlDbType.VarChar, 13).Value = lstAWB.Items[cont].ToString().Substring(0, 12);
                                cmd.Parameters.Add("@Receipt_Date", SqlDbType.VarChar, 13).Value = date;

                                cmd.Parameters.Add("@Receipt_LotNo", SqlDbType.VarChar, 13).Value = lot;

                                cmd.Parameters.Add("@Status", SqlDbType.VarChar, 13).Value = 8;

                                cmd.Parameters.Add("@Created_By", SqlDbType.VarChar, 13).Value = Session["EMailID"];

                                cmd.Parameters.Add("@Created_On", SqlDbType.DateTime).Value = DateTime.Now;
                                cmd.Parameters.Add("@City_ID", SqlDbType.VarChar, 13).Value = cityid;
                                //cmd.Parameters.Add("@City_ID", SqlDbType.VarChar, 13).Value = cityid;
                                cmd.Parameters.AddWithValue("@NeutralAWB", strNeut);
                                
                                
                                //Giving Commands
                                cmd.ExecuteNonQuery();//Executing Commands
                                //strQuery = "INSERT INTO Stock_History(AirWayBill_No,Receipt_Date,Receipt_LotNo,Status,Created_By,Created_On,City_Name) Values('" + lstAWB.Items[cont].ToString().Substring(0, 12) + "','" + date + "'," + lot + ",'Unused','" + Session["EMailID"] + "  ','" + DateTime.Now + "','" + cityname + "')";//Giving Query String For Inserting Values To Stock_History.
                                //cmd = new SqlCommand(strQuery, con, trans);//Giving Commands
                                //cmd.ExecuteNonQuery();//Executing Commands
                                lblMsgR.Text += "<br/>" + lstAWB.Items[cont].ToString().Substring(0, 12) + " Successfully Added  ";//Making Label Text With AWBNo
                                lblMsgR.ForeColor = Color.Blue;
                                //trans.Commit();//Disposing Transaction
                            }
                        }
                        catch (SqlException sqlex)
                        {
                            if (sqlex.Number == 2627)
                            {
                                lblMsgR.Text += "<br/>" + lstAWB.Items[cont].ToString().Substring(0, 12) + " Already Added  ";//Making Label Text With 
                                lblMsgR.ForeColor = Color.Red;
                            }

                            //lblMsgR.Visible = true;
                            //lblMsgR.Text += "<br/>" + lstAWB.Items[cont].ToString().Substring(0, 12) + " Already Added  ";//Making Label Text With AWBNo

                            else
                            {
                                Response.Write("sql error" + sqlex.Message);
                                string err = sqlex.ToString();
                            }
                            //trans.Rollback();
                        }
                    }
                    con.Close();
                }
                stock.Visible = false;//Making table not vissible
                lblMsgC.Visible = false;
                //panAdd.Visible = false;//Making Control Not Visible            
                //lblMsgC.Visible = true;//Displaying Result.
                lblMsgR.Visible = true;
                btnReturn.Visible = true;//Displaying Return Button.
            }
        }
    }

    //Function For Genrating Receipt_LotNo.
    int lotNoCheck()
    {
        int lot = 0;//used for return integer value.
        con = new SqlConnection(strCon);//Making Connection
        cmd = new SqlCommand("maxlot", con);//Giving Connection String.
        cmd.CommandType = CommandType.StoredProcedure;
        using (con)
        {
            try
            {
                con.Open();//Open Connection
                if (Convert.IsDBNull(cmd.ExecuteScalar()))//Check For Receipt_LotNo Present or not
                    lot = 0;//If Not having any Receipt_LotNo id then return 0.
                else
                {
                    int i = Convert.ToInt16(cmd.ExecuteScalar());//Getting Receipt_LotNo
                    lot = i;//Make it return
                }
                con.Close();
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
            }
            return lot;//Returning Receipt_LotNo to calling Statement
        }
    }

    //Function For Converting Date To Proper Format
    string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }

    //Event Handler For Return Button
    protected void btnReturn_Click(object sender, EventArgs e)
    {
        //lblMessage.Visible = false;
        stock.Visible = true;
        Label1.Visible = false;
        lblfl.Visible = false;
        //panAdd.Visible = true;//Making Control Make to sheet
        txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");//Displaying Current Date After Clear Entry
        //ddlCity.SelectedIndex = 0;//Set Default Value as Selected In DropDownList
        ddlAWB.SelectedIndex = 0;//Set Default Value as Selected In DropDownList
        txtAWB.Text = "";//Blanking TextBoxes
        txtAWBN.Text = "";//Blanking TextBoxes        
        lstAWB.Items.Clear();

    }

    //Event Handler For Generate Button
    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        lblfl.Text = null;
        Label1.Text = null;
        if (IsValid)
        {
            string airlinetext = ddlAWB.SelectedItem.Text.ToString();
            string[] airlinecode = airlinetext.Split('-');

            
            //lblMessage.Visible = false;//Making Message Label Visiblity To Fslse
            lstAWB.Items.Clear();//Making List Box Where Generated AWB No Store Empty
            ArrayList ar = new ArrayList();//Creating Array For Store AWB No During Generation
            double val = Convert.ToDouble(txtAWB.Text);//Getting AWB No Lot
            //Loop For Generation Of AWBNo.
            int count = int.Parse(txtAWBN.Text);

            for (int i = 1; i <= count; i++)
            {
                if (i == 1)//Check for How Many No awb Have.
                {
                    string strI = val.ToString() + Convert.ToString(val % 7);
                    int l = strI.Length;

                    switch (l)
                    {
                        case 1:
                            strI = "0000000" + strI;
                            break;
                        case 2:
                            strI = "000000" + strI;
                            break;
                        case 3:
                            strI = "00000" + strI;
                            break;
                        case 4:
                            strI = "0000" + strI;
                            break;
                        case 5:
                            strI = "000" + strI;
                            break;
                        case 6:
                            strI = "00" + strI;
                            break;
                        case 7:
                            strI = "0" + strI;
                            break;
                    }
                    
                    //if (l == 1)
                    //    strI = "0000000" + strI;
                    //else if (l == 2)
                    //    strI = "000000" + strI;
                    //else if (l == 3)
                    //    strI = "00000" + strI;
                    //else if (l == 4)
                    //    strI = "0000" + strI;
                    //else if (l == 5)
                    //    strI = "000" + strI;
                    //else if (l == 6)
                    //    strI = "00" + strI;
                    //else if (l == 7)
                    //    strI = "0" + strI;
                    ar.Add(airlinecode[0] + "-" + strI);//Adding Value To the Array
                }

                else
                {
                    val = val + 1;
                    double val2 = val % 7; //Math.IEEERemainder(val, 7);
                    string strI = val.ToString() + Math.Abs(val2);
                    int l = strI.Length;

                    switch (l)
                    {
                        case 1:
                            strI = "0000000" + strI;
                            break;
                        case 2:
                            strI = "000000" + strI;
                            break;
                        case 3:
                            strI = "00000" + strI;
                            break;
                        case 4:
                            strI = "0000" + strI;
                            break;
                        case 5:
                            strI = "000" + strI;
                            break;
                        case 6:
                            strI = "00" + strI;
                            break;
                        case 7:
                            strI = "0" + strI;
                            break;
                    }
                    //if (l == 1)
                    //    strI = "0000000" + strI;
                    //else if (l == 2)
                    //    strI = "000000" + strI;
                    //else if (l == 3)
                    //    strI = "00000" + strI;
                    //else if (l == 4)
                    //    strI = "0000" + strI;
                    //else if (l == 5)
                    //    strI = "000" + strI;
                    //else if (l == 6)
                    //    strI = "00" + strI;
                    //else if (l == 7)
                    //    strI = "0" + strI;
                   
                         //strI;
                    ar.Add(airlinecode[0] + "-" + strI);//Adding Value To The Array
                    
                }
            } 
            lstAWB.DataSource = ar;//Binding ListBox To the Array
            lstAWB.DataBind();//Assigning Value To The ListBox
            if (lstAWB.Items.Count > 0)
            {
                lblfl.Visible = true;
                lblfl.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
            }
            if (lstAWB.Items.Count > 1)
                {
                    Label1.Visible = true;
                    lblfl.Text = "Starting AWB No:" + lstAWB.Items[0].Value;
                    Label1.Text = "Last AWB No:" + lstAWB.Items[lstAWB.Items.Count - 1].Value;
                }
            }

            if (CheckAWBNO())//Checking For Existance Of AWB
                btnAdd.Enabled = true;//Making Add Button Enabled.
            else
                btnAdd.Enabled = false;//Making Add Button Disabled.
        
    }
    //Event Handler For flight ID DropDown
    protected void ddlAWB_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }

    //Function For Checking Existance Of AWB No
    bool CheckAWBNO()
    {
        string str = "";//For Getting String
        con = new SqlConnection(strCon);//Making Connection
        try
        {
            con.Open();//Opening Connection
            AWB = true;//Making Existance is true
            //Loop For Checking Existance
            for (int i = 0; i < lstAWB.Items.Count; i++)
            {
                strQuery = "Select * From Stock_Master Where AirWayBill_No='" + lstAWB.Items[i].ToString() + "'";//Giving Sql Query
                cmd = new SqlCommand(strQuery, con);//Giving Commands 
                dr = cmd.ExecuteReader();//Getting Values to Reader
                if (dr.Read())//Reading Values From Reader
                {
                    AWB = false;//Making Existance FAlse
                   
                    if (str == "")
                        str = lstAWB.Items[i].Text;//Getting Values To String
                    else
                        str = str + "," + lstAWB.Items[i].Text;//Getting Values To String
                }
                dr.Close();//Closing The Data Reader
            }
            if (AWB == false)//Checking For Existance Of AWB No.
            {
                lblMsgC.Visible = true;//Making 
                lblMsgC.Text = "<b>Airway No Already Exists, Please recheck the series and enter again! ..</b><br><br>" + str;//Gisplaying Message To Label

            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return AWB;//Returning From Function.
    }
    protected void ddlfillairlinecode()
    {
        using (con)
        {
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            try
            
            {
                strQuery = " select Airline_Access from dbo.Login_Master where Email_ID='" + Session["EMailID"] + "'";//query for getting airline access from login master on the basis of email 
                cmd = new SqlCommand(strQuery, con);// pass argument in command  
                dr = cmd.ExecuteReader();
                dr.Read();
                string airline_access = dr["Airline_Access"].ToString();//getting value in string airline_access
                dr.Close();
                //string[] split_ac = airline_access.Split(',');//getting value in string arrey with split 
                ddlAWB.Items.Insert(0, "--Select--");// add --select--on 0 index
                ddlAWB.Items[0].Value = "0";
                strQuery = "select am.Airline_Code,am.airline_name,cm.City_Name,cm.City_Id,cm.City_code,am.Airline_ID,ad.Airline_Detail_ID from dbo.Airline_Master as am inner join airline_detail as ad on ad.airline_id=am.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City where ad.Airline_Detail_ID in (" + airline_access + ")  and am.status='2' order by am.Airline_Code asc";
                //for (int i = 0; i < split_ac.Length; i++)//loop for getting airline code on the basis of airline_id;
                //select cm.City_Code + ',' + space(2) + am.airline_name + '-'+ am.airline_code as code, ad.airline_detail_id  from airline_master as am inner join airline_detail as ad on am.airline_id=ad.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City";
                ////{
                //    if (split_ac[i] != ",")// so that , is not getting
                //    {
                        //strQuery = "select distinct am.Airline_Code,am.Airline_id from dbo.Airline_Master as am inner join airline_detail as ad on ad.airline_id=am.airline_id where ad.Airline_Detail_ID='" + split_ac[i] + "' and am.status='2' order by am.Airline_Code asc";
                        cmd = new SqlCommand(strQuery, con);
                       dr = cmd.ExecuteReader();
                        while (dr.Read())
                            ddlAWB.Items.Add(new ListItem(dr["airline_code"].ToString() + '-' + dr["Airline_name"].ToString() + ',' + dr["City_Code"].ToString(), dr["Airline_Detail_ID"].ToString()));
                            //
                            //ddlAWB.Items.Add(new ListItem(dr["airline_name"].ToString() + '-' + dr["Airline_Code"].ToString + ',' + dr["City_Name"].ToString(), dr["Airline_ID"].ToString()));
                        dr.Close();
                //    }
                //}
            }
                
     
            catch (SqlException ee)
            {
                Response.Write("sql error" + ee.Message);
            }
         finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        
        }
    }
        
   
    }

    protected void ddlAWB_SelectedIndexChanged1(object sender, EventArgs e)
    {
        lstAWB.Items.Clear();
        txtAWB.Text = null;
        txtAWBN.Text = null;
        lblfl.Text = null;
        Label1.Text = null;
        
    }
}
