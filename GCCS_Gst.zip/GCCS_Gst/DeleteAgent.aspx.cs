using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class DeleteAgent : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string Existing_AGENT_ID="";
    string Existing_AGENT_Code="";
    string Existing_AGENT_Name="";
    string New_Agent_Code="";
    string New_Agent_Name="";
    string New_Agent_Address="";
    string New_AGENT_ID="";
    string New_Agent_City="";
    string City_id="";
    string Existing_Agent_Branch_ID;
    DisplayWrap dw = new DisplayWrap();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                pnlPayment.Visible = false;
                //Existing_AGENT_ID = Convert.ToString(Request.QueryString["Agent_ID"]);
                //City_id = Convert.ToString(Request.QueryString["city"]);
                Existing_Agent_Branch_ID = Convert.ToString(Request.QueryString["Agent_Branch_ID"]);
                AgentDetails();
                FillAgent();
                btnShow.Attributes.Add("onclick", "return Confirmation_Delete()");
            }
           
        }
    }

    public void SearchAgentDetail()
    {
        using (con)
        {
            try
            {
                if (ddlAgentName.SelectedValue != "")
                {
                    string Agent = ddlAgentName.SelectedValue;
                    string[] Arr_Agent = Agent.Split('-');
                    //Existing_AGENT_ID = Convert.ToString(Request.QueryString["Agent_ID"]);
                    //City_id = Convert.ToString(Request.QueryString["city"]);
                    Existing_Agent_Branch_ID = Convert.ToString(Request.QueryString["Agent_Branch_ID"]);
                    New_AGENT_ID = Arr_Agent[0];
                    New_Agent_City = Arr_Agent[1];

                    DataTable dt_new = dw.GetAllFromQuery("SELECT	A.Agent_ID,Agent_Code,Agent_Name,Agent_Address FROM Agent_Master A INNER JOIN Agent_Branch B ON A.Agent_ID=B.Agent_ID WHERE B.Belongs_To_City='" + New_Agent_City + "' AND A.Agent_ID='" + New_AGENT_ID + "'");
                    if (dt_new.Rows.Count > 0)
                    {
                        New_Agent_Code = dt_new.Rows[0]["Agent_Code"].ToString();
                        New_Agent_Name = dt_new.Rows[0]["Agent_Name"].ToString();
                        New_Agent_Address = dt_new.Rows[0]["Agent_Address"].ToString();
                    }
                }

                //Existing_AGENT_ID = Convert.ToString(Request.QueryString["Agent_ID"]);
                //City_id = Convert.ToString(Request.QueryString["city"]);
                DataTable dt_Existing = dw.GetAllFromQuery("SELECT	A.Agent_ID,Agent_Code,Agent_Name,Agent_Address,b.belongs_to_city FROM Agent_Master A INNER JOIN Agent_Branch B ON A.Agent_ID=B.Agent_ID WHERE B.Agent_Branch_ID='" + Existing_Agent_Branch_ID + "' ");
                if (dt_Existing.Rows.Count > 0)
                {
                    Existing_AGENT_ID = dt_Existing.Rows[0]["Agent_ID"].ToString();
                    Existing_AGENT_Code = dt_Existing.Rows[0]["Agent_Code"].ToString();
                    Existing_AGENT_Name = dt_Existing.Rows[0]["Agent_Name"].ToString();
                    City_id = dt_Existing.Rows[0]["belongs_to_city"].ToString();

                }
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("DELETE_AGENT", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Existing_Agent_Branch_ID", Existing_Agent_Branch_ID);
                cmd.Parameters.AddWithValue("@Existing_AGENT_ID", Existing_AGENT_ID);
                cmd.Parameters.AddWithValue("@Existing_AGENT_Code", Existing_AGENT_Code);
                cmd.Parameters.AddWithValue("@Existing_City_id", City_id);
                cmd.Parameters.AddWithValue("@New_Agent_Code", New_Agent_Code);
                cmd.Parameters.AddWithValue("@New_Agent_Name", New_Agent_Name);
                cmd.Parameters.AddWithValue("@New_Agent_Address", New_Agent_Address);
                cmd.Parameters.AddWithValue("@New_AGENT_ID", New_AGENT_ID);
                cmd.ExecuteNonQuery();
                pnlPayment.Visible = false;
                lblMessage.Visible = true;
                lblDelete.Visible = false;
                lblMessage.ForeColor = System.Drawing.Color.Blue;
                lblMessage.Text = Existing_AGENT_Name + " Deleted Successfully.";
                if (ddlAgentName.SelectedValue != "")
                {
                    Label1.ForeColor = System.Drawing.Color.Blue;
                    Label1.Visible = true;
                    Label1.Text = "This Agent is Replaced by " + New_Agent_Name;
                }
                cmd.Dispose();
                con.Close();
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Visible = true;
                Label1.Text = "Agent Not Deleted.";
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }

    // FUNCTION FOR CHECKING : THERE IS ANY AIRWAYBILL NO EXIST AGAINST THIS AGENT
    public void AgentDetails()
    {
        DataTable dt_Existing = dw.GetAllFromQuery("SELECT	A.Agent_ID,Agent_Code,Agent_Name,Agent_Address,b.belongs_to_city FROM Agent_Master A INNER JOIN Agent_Branch B ON A.Agent_ID=B.Agent_ID WHERE B.Agent_Branch_ID='" + Existing_Agent_Branch_ID + "' ");
        if (dt_Existing.Rows.Count > 0)
        {
            Existing_AGENT_ID = dt_Existing.Rows[0]["Agent_ID"].ToString();
            City_id = dt_Existing.Rows[0]["belongs_to_city"].ToString();

            DataTable dt_Agent = dw.GetAllFromQuery("SELECT AirWayBill_No FROM Stock_Master WHERE Agent_ID='" + Existing_AGENT_ID + "' AND City_ID='" + City_id + "'");
            if (dt_Agent.Rows.Count > 0)
            {
                lblDelete.Visible = true;
                lblDelete.Text = "The deleting Agent having some AWBs.you need to transfer these awbs.Please select Agent to transfer.";
                pnlPayment.Visible = true;
            }
            else
            {
                SearchAgentDetail();
            }

        }
       
    }

    // FUNCTION FOR GETTING AGENT LIST ACCORDING TO SELECTED AIRLINE
    public void FillAgent()
    {
        con = new SqlConnection(strCon);

        string strQuery = "select a.agent_id,a.agent_Name,c.city_name,a.agent_code,b.belongs_to_city from agent_master a inner join agent_branch b on a.agent_id = b.agent_id inner join city_master c on b.belongs_to_city = c.city_id  WHERE B.Agent_Branch_ID NOT IN('" + Existing_Agent_Branch_ID + "')  order by a.Agent_name";
        con.Open();
        SqlDataReader drAgent;
        SqlCommand cmd = new SqlCommand(strQuery, con);
        drAgent = cmd.ExecuteReader();
        ddlAgentName.Items.Clear();
        ddlAgentName.Items.Add(new ListItem("--Select--", "y"));
        ddlAgentName.Items[0].Value = "0";
        while (drAgent.Read())
        {
            string aname = drAgent["agent_Name"].ToString();
            string city = drAgent["city_name"].ToString();
            string agentText = aname + "- (" + city + ")";
            ddlAgentName.Items.Add(new ListItem(agentText, drAgent["agent_id"].ToString() + "-" + drAgent["belongs_to_city"].ToString()));
        }
        drAgent.Close();
        con.Close();
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        SearchAgentDetail();
    }
    protected void ddlAgentName_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
}
