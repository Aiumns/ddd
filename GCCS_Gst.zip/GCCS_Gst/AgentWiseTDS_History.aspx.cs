using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

// This Page is Design & Coding By Alok Date:18.12.2007
public partial class AgentWiseTDS_History : System.Web.UI.Page
{
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
   
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if(!IsPostBack)
        {
          
            UserAirlineNamePlusCode();
           
        }
        Search();
    }
    //function for bind grid
    public void Search()
    {
        string s1 = ddlAirline.SelectedItem.Value;
        //string str1, AID;
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            //str1 = "select Airline_detail_id from Agentwise_Tds";
            //con = new SqlConnection(strCon);
            //con.Open();
            //com = new SqlCommand(str1, con);
            //SqlDataReader dr = com.ExecuteReader();
            //dr.Read();
            //AID = dr["Airline_detail_id"].ToString();
            //string[] str = AID.Split(',');
            string selectQ = null;
            if (txt_search.Text == "" && s1 == "0")
            {
          selectQ = "select distinct AT.Agentwise_TDS_History_ID as 'Agentwise_TDS_History_ID',AT.Agent_Name as 'Agent_Name',AT.Company_Name as 'Company_Name',AT.Airline_Detail_ID,AT.Exempted_TDS_Rate as 'Exempted_TDS_Rate',AT.TDS_Exemption_Limit as 'TDS_Exemption_Limit',(case when AT.TDS_Status_Limited='14' then 'Unlimited' else 'Limited' end ) as 'TDS_Status_Limited',cast(AT.Surcharge as numeric(18,2)) as'Surcharge',AT.Education_Cess as 'Education_Cess',convert(varchar,AT.Valid_From ,103) as 'Valid_From',convert(varchar,AT.Valid_To ,103) as 'Valid_To',AT.Entered_By as 'Entered_By',AT.Entered_On as 'Entered_On' from Agentwise_TDS_History AT order by Agent_Name";
            }

            else if (txt_search.Text != "")
           {

               selectQ = "select distinct AT.Agentwise_TDS_History_ID as 'Agentwise_TDS_History_ID',AT.Agent_Name as 'Agent_Name',AT.Company_Name as 'Company_Name',AT.Airline_Detail_ID,AT.Exempted_TDS_Rate as 'Exempted_TDS_Rate',AT.TDS_Exemption_Limit as 'TDS_Exemption_Limit',(case when AT.TDS_Status_Limited='14' then 'Unlimited' else 'Limited' end ) as 'TDS_Status_Limited',cast(AT.Surcharge as numeric(18,2)) as'Surcharge',AT.Education_Cess as 'Education_Cess',convert(varchar,AT.Valid_From ,103) as 'Valid_From',convert(varchar,AT.Valid_To ,103) as 'Valid_To',AT.Entered_By as 'Entered_By',AT.Entered_On as 'Entered_On' from Agentwise_TDS_History AT where AT.Agent_Name like '" + txt_search.Text + "%' order by Agent_Name";
            }
            else if (s1 != "0")
            {
                selectQ = "select distinct AT.Agentwise_TDS_History_ID as 'Agentwise_TDS_History_ID',AT.Agent_Name as 'Agent_Name',AT.Company_Name as 'Company_Name',AT.Airline_Detail_ID,AT.Exempted_TDS_Rate as 'Exempted_TDS_Rate',AT.TDS_Exemption_Limit as 'TDS_Exemption_Limit',(case when AT.TDS_Status_Limited='14' then 'Unlimited' else 'Limited' end ) as 'TDS_Status_Limited',cast(AT.Surcharge as numeric(18,2)) as'Surcharge',AT.Education_Cess as 'Education_Cess',convert(varchar,AT.Valid_From ,103) as 'Valid_From',convert(varchar,AT.Valid_To ,103) as 'Valid_To',AT.Entered_By as 'Entered_By',AT.Entered_On as 'Entered_On' from Agentwise_TDS_History AT where  AT.Airline_Detail_ID like '%" + ddlAirline.SelectedItem.Value + "%' order by Agent_Name ";
            }
            else if (txt_search.Text != "" && s1 != "0")
            {
                selectQ = "select distinct AT.Agentwise_TDS_History_ID as 'Agentwise_TDS_History_ID',AT.Agent_Name as 'Agent_Name',AT.Company_Name as 'Company_Name',AT.Airline_Detail_ID,AT.Exempted_TDS_Rate as 'Exempted_TDS_Rate',AT.TDS_Exemption_Limit as 'TDS_Exemption_Limit',(case when AT.TDS_Status_Limited='14' then 'Unlimited' else 'Limited' end ) as 'TDS_Status_Limited',cast(AT.Surcharge as numeric(18,2)) as'Surcharge',AT.Education_Cess as 'Education_Cess',convert(varchar,AT.Valid_From ,103) as 'Valid_From',convert(varchar,AT.Valid_To ,103) as 'Valid_To',AT.Entered_By as 'Entered_By',AT.Entered_On as 'Entered_On' from Agentwise_TDS_History AT where  AT.Airline_Detail_ID like '%" + ddlAirline.SelectedItem.Value + "%' and AT.Agent_Name like '" + txt_search.Text + "%' order by Agent_Name ";
            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdAgentTDS.DataSource = dt;
            grdAgentTDS.DataBind();
            con.Close();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void UserAirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
        
            ddlAirline.Items.Insert(0, "Select Airline(City) Name");
            ddlAirline.Items[0].Value = "0";
            strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City  order by  a.Airline_Name";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));

            }
            con.Close();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void grdAgentTDS_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdAgentTDS.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void grdAgentTDS_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            Label lblAID = (Label)e.Row.Cells[3].FindControl("Label1");
            string Airline_Access = lblAID.Text;

            string[] a = Airline_Access.Split(',');
            string str = string.Empty;
            for (int i = 0; i < a.Length; i++)
            {   // CREATING DATATABLE FOR Airline Name From Airline Master
                //

                DataTable dtAccess = dw.GetAllFromQuery("select AM.Airline_Name as 'Airline_Name',CM.City_Name as 'City_Name' from Airline_Detail AD inner join Airline_Master AM on AD.Airline_ID=AM.Airline_ID inner join City_Master CM on CM.City_ID=AD.Belongs_To_City where AD.Airline_Detail_ID = '" + a.GetValue(i).ToString() + "'");
                if (dtAccess.Rows.Count > 0)
                {
                    // STRING CONCATENATION


                    str = str + (dtAccess.Rows[0]["Airline_Name"].ToString().Trim() + "(" + dtAccess.Rows[0]["City_Name"].ToString().Trim() + ") * ");
                }

            }
            str = str.Remove(str.LastIndexOf("*"));
            e.Row.Cells[3].Text = str;
        }
    }
}
