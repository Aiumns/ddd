using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

// Hirdayanand Mishra on 22.04.2009

public partial class FlightDiscounting : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    SqlCommand com;    
    SqlDataReader red;
    SqlParameter pram;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds; 

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
           btnadd.Attributes.Add("onclick", "return CheckEmpty();");
           btnUpdate.Attributes.Add("onclick", "return CheckEmpty();");
          
            if (!IsPostBack)
            {
                
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
                if (Request.QueryString.Count > 0)
                {
                    LoadData();
                    if (Request.QueryString["f"].ToString() == "d")
                    {
                        btnadd.Visible = false;
                        btnDelete.Visible = true;
                        btnUpdate.Visible = false;
                        btncancel.Visible = false;
                        btnBack.Visible = true;

                    }
                    if (Request.QueryString["f"].ToString() == "u")
                    {
                        btnadd.Visible = false;
                        btnDelete.Visible = false;
                        btnUpdate.Visible = true;
                        btncancel.Visible = false;
                        btnBack.Visible = true;
                    }

                }
                else
                {
                    FillAirline();
                    FillDataShipment();
                    Hide();
                    TDSec.Style.Add("display", "none");
                    TDSecHead.Style.Add("display", "none");
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    btnBack.Visible = false;
                }
               
            }              

        }           
        
    }

    public void FillAirline()
    {
        string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in(" + Airline_Access + ") order by Airline_Name", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlAirlineName.DataSource = red;
        ddlAirlineName.DataTextField = "Airline";
        ddlAirlineName.DataValueField = "Airline_Detail_ID";
        ddlAirlineName.DataBind();
        con.Close();
        cmd.Dispose();
        ddlAirlineName.Items.Insert(0, new ListItem("Select Airline", "0"));
    }
    public string Rights()
    {
        string Access = "";
        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";
        con = new SqlConnection(strCon);
        try
        {
        con.Open();       
        SqlCommand cmd = new SqlCommand(sql_Access, con);
        
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Access = dr.GetValue(0).ToString();
                }

            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
         return Access;
    }
    protected void rbtnSector_CheckedChanged(object sender, EventArgs e)
    {
        lblError.Text = "";
        rbtnDes.Checked = false;
        rbtnSector.Checked = true;     
        lstSectorData(ddlAirlineName.SelectedValue.ToString(),true);
        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;
        //lblSec.Text = "Sector code";
       
    }
    protected void rbtnDes_CheckedChanged(object sender, EventArgs e)
    {
        lblError.Text = "";
        rbtnDes.Checked = true;
        rbtnSector.Checked = false;
        lstSectorData(ddlAirlineName.SelectedValue.ToString(),false);
        UnHide();    
        //lblSec.Text = "Destination Code";
      

    }
    protected void FillDataShipment()
    {
        ddlShip.Items.Clear();
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select distinct shipment_id,shipment_name from Shipment_master order by shipment_name", con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                ddlShip.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
            }
            dr.Close();
            ddlShip.SelectedValue = "8";
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void lstSectorData(string airlineDetailID,bool flag)
    {
        rbtnSector.Checked = flag;
        string searchString = null;
        con = new SqlConnection(strCon);
        if (rbtnSector.Checked == true)
        {
            searchString = "Select distinct asm.sector_name,asm.Sector_ID from airline_sector_master asm inner join Airline_Master am on am.Airline_ID=asm.Airline_ID inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join airline_sector_details asd on asd.sector_id=asm.sector_id where ad.Airline_Detail_ID='" + airlineDetailID + "'";
        }
        else
        {

            searchString = "Select distinct dm.Destination_Code,ar.Destination from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ad.Airline_Detail_ID='" + airlineDetailID + "'";
        }
        try
        {
            con.Open();
            com = new SqlCommand(searchString, con);
            SqlDataReader dr = com.ExecuteReader();
            int p = 0;
            if (rbtnSector.Checked == true)
            {
                chkSec.Items.Clear();
                chkBoxList.Items.Clear();
                if (dr.HasRows)
                {
                    chkSec.Visible = true;
                    while (dr.Read())
                    {
                        chkSec.Items.Add(new ListItem(" " + dr[0].ToString(), dr[1].ToString()));
                        p = p + 1;
                    }
                }
                else
                {
                    Hide2();
                    lblError.Text = "Sector not added for selected airline,Please select destination wise discount.";
                    lblError.Visible = true;

                }

            }
            else
            {            
                chkBoxList.Items.Clear();
                chkSec. Items.Clear();
                while (dr.Read())
                {
                    chkBoxList.Items.Add(new ListItem(" " + dr[0].ToString(), dr[1].ToString()));
                    p = p + 1;
                }
            }
            HiddSec.Value = p.ToString();
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void ddlAirlineName_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblError.Text = "";
        rbtnDes.Checked = false;
        rbtnSector.Checked = false;
        Hide();
        chkBoxList.Items.Clear();
        string query = "select * from Flight_Master where airline_detail_id='"+ddlAirlineName.SelectedValue.ToString() +"'";
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlFlight.Items.Clear();
            if (dr.HasRows)            {
               
                ddlFlight.Items.Add(new ListItem("-Select Flight No-","0"));
                ddlFlight.Items.Add(new ListItem("All Flights", "0"));
                while (dr.Read())
                {
                    ddlFlight.Items.Add(new ListItem(dr["Flight_No"].ToString(), dr["Flight_ID"].ToString()));
                }

            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        //lstSectorData(ddlAirlineName.SelectedValue.ToString(),false);
        SlabData(ddlAirlineName.SelectedValue.ToString());
        if (ddlAirlineName.SelectedValue.ToString() != "0")
        {
            TDSec.Style.Add("display", "display");
            TDSecHead.Style.Add("display", "display");
        }
        //Hide();
    }
    protected void SlabData(string airlineID)
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("select s.slab_name,s.slab_id from slab_master s inner join airline_slab a on a.slab_id=s.slab_id where a.airline_detail_id='" + airlineID + "' order by s.slab_start", con);
        SqlDataReader dr = com.ExecuteReader();
        gvSlab.DataSource = dr;
        gvSlab.DataBind();
        dr.Close();
        com.Dispose();
        con.Close();
    }
   
   
    protected void gridview1_rowdatabound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList ddl = (DropDownList)e.Row.FindControl("ddlPrefix");
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select prefix_name,prefix_id from prefix_master", con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                ddl.Items.Add(new ListItem(dr[0].ToString(), dr[1].ToString()));
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        string Destination = "";
        string ExistDest = "";
        string Exist = "";
        lblError.Text = "";
        
        int result = 0;
            for (int x = 0; x < chkBoxList.Items.Count; x++)
            {
                if (chkBoxList.Items[x].Selected == true)
                {
                   ExistDest=CheckExistsDestination(chkBoxList.Items[x].ToString());
                   if (ExistDest == "")
                   {
                       if (Destination == "")
                           Destination += chkBoxList.Items[x].Text;
                       else
                           Destination += "," + chkBoxList.Items[x].Text;
                   }
                   else
                   {
                       Exist += "," + ExistDest;

                   }


                }

            }

            con = new SqlConnection(strCon);
            SqlTransaction tr = null;            
            try
            {               
                con.Open();
                tr = con.BeginTransaction();               
                for (int i=0; i < gvSlab.Rows.Count; i++)
                {
                    GridViewRow gr = gvSlab.Rows[i];
                    Label slabID = (Label)gr.FindControl("lblSlabID");
                    DropDownList Prefix = (DropDownList)gr.FindControl("ddlPrefix");
                    TextBox txtValue = (TextBox)gr.FindControl("txtValue");
                    com = new SqlCommand("FlightDiscounting_Add", con,tr);
                    com.CommandType = CommandType.StoredProcedure;

                    com.Parameters.AddWithValue("@AirLineDetail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
                    com.Parameters.AddWithValue("@Flight_ID", int.Parse(ddlFlight.SelectedValue.ToString()));
                    com.Parameters.AddWithValue("@Shipment_ID", int.Parse(ddlShip.SelectedValue.ToString()));
                    com.Parameters.AddWithValue("@Destination_Codes", Destination);

                    com.Parameters.AddWithValue("@Slab_ID", int.Parse(slabID.Text));
                    com.Parameters.AddWithValue("@Prefix_ID", int.Parse(Prefix.SelectedValue.ToString()));
                    com.Parameters.AddWithValue("@Discounted_Value", int.Parse(txtValue.Text == "" ? "0" : txtValue.Text));

                    com.Parameters.AddWithValue("@Active", "Y");
                    com.Parameters.AddWithValue("@ValidFrom", DateTime.Parse(ConvertDate1(txtDisValidFrom.Text)));
                    com.Parameters.AddWithValue("@ValidTo", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
                    com.Parameters.AddWithValue("@EnteredBY", Session["EMailID"].ToString());
                    com.Parameters.AddWithValue("@EnteredDate", DateTime.Today);
                    if ((txtValue.Text == "" ? "0" : txtValue.Text) != "0" && Destination!="")
                   // if (Destination != "")
                    {
                        result = com.ExecuteNonQuery();
                    }
                    if (result == -1)
                    {
                        lblError.Text = "Discounted Value Can't be Added Due to Some Error";
                        tr.Rollback();
                    }

                }
                tr.Commit();
                con.Close();
                if (result == 1)
                    lblError.Text = Destination + ": Destination Discounted Value Added Successfully.";
                if(result == 1 && Exist!="")
                    lblError.Text = Destination + ": Destination Discounted Value Added Successfully." + "<br>" + Exist + ": Destination already Exists.";
                if (result == 0 && Exist != "")
                    lblError.Text = Exist + ": Destination already Exists.";
                
            }
            catch (SqlException se)
            {
                string err = se.Message;
               tr.Rollback();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        if (result == 1)
        {
            Session["msg"]=Destination + ": Destination Discounted Value Added Successfully.";
            Response.Redirect("FlightDiscountingShow.aspx?id=a");


        }
        if (result == 1 && Exist != "")
        {
            Session["msg"] = Destination + ": Destination Discounted Value Added Successfully." + "<br>" + Exist + ": Destination already Exists.";
            Response.Redirect("FlightDiscountingShow.aspx?id=a");
        }
    

    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }  
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("FlightDiscounting.aspx");

    }
    protected string CheckExistsDestination(string Dest)
    {
        string result = "";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("CheckExistDestination", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@airlineDetail_ID",int.Parse(ddlAirlineName.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@Flight_ID",int.Parse(ddlFlight.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@Shipment_ID",int.Parse(ddlShip.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@validFrom",DateTime.Parse(ConvertDate1(txtDisValidFrom.Text)));
        com.Parameters.AddWithValue("@Validto", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
        com.Parameters.AddWithValue("@Destination", Dest.Trim());

        SqlDataReader dr = com.ExecuteReader();
        
            while (dr.Read())
            {
                result = dr["Data"].ToString();
            }

        dr.Close();
        com.Dispose();
        con.Close();
        return result;

    }

    protected void sectorDestination()
    {
        string flag = "";
        con = new SqlConnection(strCon);
        con.Open();
        SqlDataReader dr = null;
        chkBoxList.Items.Clear();
        for (int k = 0; k < chkSec.Items.Count; k++)
         {
             if (chkSec.Items[k].Selected == true)
             {
                 flag ="true";
                
                com = new SqlCommand("select a.destination_id,b.destination_code from airline_sector_details a inner join destination_master b on b.destination_id=a.destination_id  where sector_id=" + chkSec.Items[k].Value + " ", con);
                dr = com.ExecuteReader();
               
                while (dr.Read())
                {
                    chkBoxList.Items.Add(new ListItem(dr["destination_code"].ToString(), dr["destination_id"].ToString()));                    
                    
                }
                dr.Dispose();
                com.Dispose();
                

            }
      
         }
        
         con.Close();
         for (int k = 0; k < chkBoxList.Items.Count; k++)             
         {
             chkBoxList.Items[k].Selected = true;

         }

    }
    protected void chkSec_SelectedIndexChanged(object sender, EventArgs e)
    {
        sectorDestination();

        if (chkBoxList.Items.Count > 0)
            UnHide();
        else
        {
            Hide2();
            chkSec.Visible = true;
        }
        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;
    }
    protected void UnHide()
    {
        VDate.Style.Add("display", "display");
        VDate1.Style.Add("display", "display");
        TDSlab.Style.Add("display", "display");
        btnadd.Visible = true;
        btncancel.Visible = true;
        chkSec.Visible = true;
        rbtnDSelect.Visible = true;
        rbtnSelectAll.Visible = true;
    }
    protected void Hide()
    {
        VDate.Style.Add("display", "none");
        VDate1.Style.Add("display", "none");
        TDSlab.Style.Add("display", "none");

        TDSec.Style.Add("display", "none");
        TDSecHead.Style.Add("display", "none");
        btnadd.Visible = false;
        btncancel.Visible =false;
        chkSec.Visible = false;
        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;
     

    }
    protected void Hide2()
    {
        VDate.Style.Add("display", "none");
        VDate1.Style.Add("display", "none");
        TDSlab.Style.Add("display", "none");

        //TDSec.Style.Add("display", "none");
       // TDSecHead.Style.Add("display", "none");
        btnadd.Visible = false;
        btncancel.Visible = false;
        chkSec.Visible = false;

        rbtnDSelect.Visible = false;
        rbtnSelectAll.Visible = false;
       

    }
    

    protected void BindFlight(string airlineID)
    {
        chkBoxList.Items.Clear();
        string query = "select * from Flight_Master where airline_detail_id='" + airlineID + "'";
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlFlight.Items.Clear();
            if (dr.HasRows)
            {

                ddlFlight.Items.Add(new ListItem("-Select Flight No-", "0"));
                ddlFlight.Items.Add(new ListItem("All Flights", "0"));
                while (dr.Read())
                {
                    ddlFlight.Items.Add(new ListItem(dr["Flight_No"].ToString(), dr["Flight_ID"].ToString()));
                }

            }
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    ///////////////
    //Delete Function imp.

    protected void LoadData()
    {
        FillAirline();
        FillDataShipment();
        if (Request.QueryString.Count > 0)
        {
            string airLIne_ID = Request.QueryString["aid"].ToString();
            string flght_ID = Request.QueryString["flt"].ToString();
            string shipment_ID = Request.QueryString["sid"].ToString();
            string destination_Code = Request.QueryString["d"].ToString();
            string validFrom = Request.QueryString["vf"].ToString();
            string validto= Request.QueryString["vt"].ToString();
            string[] dest = Request.QueryString["d"].ToString().Split(',');
            for (int i = 0; i < ddlAirlineName.Items.Count; i++)
            {
                if (ddlAirlineName.Items[i].Value == airLIne_ID)
                    ddlAirlineName.Items[i].Selected = true;
            }
            BindFlight(airLIne_ID);
            for (int x = 0; x < ddlFlight.Items.Count; x++)
            {               
              ddlFlight.Items[x].Selected = false;
            }
            for (int x = 1; x < ddlFlight.Items.Count; x++)
            {
                if (ddlFlight.Items[x].Value == flght_ID)
                    ddlFlight.Items[x].Selected = true;

            }

            for (int z1 = 0; z1 < ddlShip.Items.Count; z1++)
            {
               
                    ddlShip.Items[z1].Selected = false;

            }
            for (int z = 0; z < ddlShip.Items.Count; z++)
            {
                if (ddlShip.Items[z].Value == shipment_ID)
                    ddlShip.Items[z].Selected = true;               

            }
            TDSec.Style.Add("display", "display");
            TDSecHead.Style.Add("display", "display");

            rbtnDes.Checked = true;
            rbtnDes.Checked = true;
            rbtnSector.Checked = false;
            lstSectorData(airLIne_ID, false);
            UnHide();
            for (int k = 0; k < chkBoxList.Items.Count; k++)
            {
                for (int n = 0; n < dest.Length; n++)
                {
                    if (chkBoxList.Items[k].Text.Trim() == dest[n].ToString().Trim())
                        chkBoxList.Items[k].Selected = true;
                }                

            }

            txtDisValidFrom.Text = DateTime.Parse(validFrom).ToString("dd/MM/yyyy");
            txtDisValidTo.Text = DateTime.Parse(validto).ToString("dd/MM/yyyy");

            SlabData(airLIne_ID);

            string query = "select slab_ID,PreFix_ID,Discounted_Value from FlightDiscounting where airlineDetail_ID='"+airLIne_ID +"' and flight_ID='"+flght_ID +"' and Shipment_ID='"+shipment_ID +"' and Destination_Codes='" +destination_Code +"' and validFrom='" + DateTime.Parse(validFrom) + "' and Validto='" + DateTime.Parse(validto) + "' order by slab_ID ";
            con = new SqlConnection(strCon);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();               
                if (dr.HasRows)
                {                    
                    while (dr.Read())
                    {

                        string slabid = dr["slab_ID"].ToString();
                        string prefixid = dr["PreFix_ID"].ToString();
                        string Discounted_Value = dr["Discounted_Value"].ToString();
                        for (int i = 0; i < gvSlab.Rows.Count; i++)
                        {
                            GridViewRow gr = gvSlab.Rows[i];
                            Label lblslabID = (Label)gr.FindControl("lblSlabID");
                            if (lblslabID.Text.Trim() == slabid.Trim())
                            {
                                TextBox txtvalue = ((TextBox)gr.FindControl("txtValue"));
                                txtvalue.Text = Discounted_Value;
                                DropDownList ddlprefix = (DropDownList)gr.FindControl("ddlPrefix");
                                for (int y = 0; y < ddlprefix.Items.Count; y++)
                                {
                                    if (ddlprefix.Items[y].Value == prefixid)
                                        ddlprefix.Items[y].Selected = true;
                                }
                            }

                        }
                    }

                }
            }
            catch (SqlException se)
            {
                string err = se.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

        }
        ddlAirlineName.Enabled = false;

    }
  
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        int result = 0;
        string Destination = "";
        string ExistDest = "";
        string Exist = "";
        lblError.Text = ""; 

        string airLIne_ID = Request.QueryString["aid"].ToString();
        string flght_ID = Request.QueryString["flt"].ToString();
        string shipment_ID = Request.QueryString["sid"].ToString();
        string destination_Code = Request.QueryString["d"].ToString();
        string validFrom = Request.QueryString["vf"].ToString();
        string validto = Request.QueryString["vt"].ToString();
        string[] dest = Request.QueryString["d"].ToString().Split(',');            
       

            con = new SqlConnection(strCon);   
            SqlTransaction tr = null; 
            
            try
            {
                con.Open();
              //  tr = con.BeginTransaction();
                SqlCommand cmd = null;
                if (DateTime.Parse(validFrom) <= DateTime.Today)
                {
                     cmd = new SqlCommand("FlightDiscounting_Update", con);
                }
                else
                {
                    cmd = new SqlCommand("FlightDiscounting_Delete", con);
                }
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@New_AirLineDetail_ID", int.Parse(airLIne_ID));
                cmd.Parameters.AddWithValue("@New_Flight_ID",int.Parse(flght_ID));
                cmd.Parameters.AddWithValue("@New_Shipment_ID",int.Parse(shipment_ID));
                cmd.Parameters.AddWithValue("@New_Destination_Codes",destination_Code);
                cmd.Parameters.AddWithValue("@New_ValidFrom", DateTime.Parse(validFrom));
                cmd.Parameters.AddWithValue("@New_ValidTo",DateTime.Parse(validto));
                cmd.Parameters.AddWithValue("@ValidTo",DateTime.Today.AddDays(-1));
                 cmd.Parameters.AddWithValue("@LastModifiyDate",DateTime.Today);

                 result= cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();

                for (int x = 0; x < chkBoxList.Items.Count; x++)
                {
                    if (chkBoxList.Items[x].Selected == true)
                    {
                        ExistDest = CheckExistsUpdateDestination(chkBoxList.Items[x].ToString());
                        if (ExistDest == "")
                        {
                            if (Destination == "")
                                Destination += chkBoxList.Items[x].Text;
                            else
                                Destination += "," + chkBoxList.Items[x].Text;
                        }
                        else
                        {
                            Exist += "," + ExistDest;

                        }


                    }

                }

                if (result != 0 || result!=-1)
                {
                    con.Open();
                    for (int i = 0; i < gvSlab.Rows.Count; i++)
                    {
                        GridViewRow gr = gvSlab.Rows[i];
                        Label slabID = (Label)gr.FindControl("lblSlabID");
                        DropDownList Prefix = (DropDownList)gr.FindControl("ddlPrefix");
                        TextBox txtValue = (TextBox)gr.FindControl("txtValue");
                        com = new SqlCommand("FlightDiscounting_Add", con);
                        com.CommandType = CommandType.StoredProcedure;

                        com.Parameters.AddWithValue("@AirLineDetail_ID", int.Parse(airLIne_ID));
                        com.Parameters.AddWithValue("@Flight_ID", int.Parse(ddlFlight.SelectedValue.ToString()));
                        com.Parameters.AddWithValue("@Shipment_ID", int.Parse(ddlShip.SelectedValue.ToString()));
                        com.Parameters.AddWithValue("@Destination_Codes", Destination);

                        com.Parameters.AddWithValue("@Slab_ID", int.Parse(slabID.Text));
                        com.Parameters.AddWithValue("@Prefix_ID", int.Parse(Prefix.SelectedValue.ToString()));
                        com.Parameters.AddWithValue("@Discounted_Value",decimal.Parse(txtValue.Text == "" ? "0" : txtValue.Text));

                        com.Parameters.AddWithValue("@Active", "Y");
                        if (DateTime.Parse(validFrom) <= DateTime.Today)
                        {                            
                            com.Parameters.AddWithValue("@ValidFrom", DateTime.Today);
                        }
                        else
                        {
                            com.Parameters.AddWithValue("@ValidFrom", DateTime.Parse(ConvertDate1(txtDisValidFrom.Text)));
                        }
                        
                        com.Parameters.AddWithValue("@ValidTo", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
                        com.Parameters.AddWithValue("@EnteredBY", Session["EMailID"].ToString());
                        com.Parameters.AddWithValue("@EnteredDate", DateTime.Today);
                        if ((txtValue.Text == "" ? "0" : txtValue.Text) != "0" && Destination != "")
                        //if (Destination != "")
                        {
                           result = com.ExecuteNonQuery();
                        }
                        if (result == -1)
                        {
                            lblError.Text = "Discounted Value Can't be updated Due to Some Error";
                           // tr.Rollback();
                        }

                    }
//tr.Commit();

               }
               lblError.Text = "Discounted value Updated Successfully ";

            }             
            
            catch (SqlException se)
            {
                string err = se.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

            Session["msg"] = lblError.Text;
            Response.Redirect("FlightDiscountingShow.aspx?id=u");

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        int result = 0;
        string airLIne_ID = Request.QueryString["aid"].ToString();
        string flght_ID = Request.QueryString["flt"].ToString();
        string shipment_ID = Request.QueryString["sid"].ToString();
        string destination_Code = Request.QueryString["d"].ToString();
        string validFrom = Request.QueryString["vf"].ToString();
        string validto = Request.QueryString["vt"].ToString();
        string[] dest = Request.QueryString["d"].ToString().Split(',');

            con = new SqlConnection(strCon);   
            SqlTransaction tr = null;

            try
            {
                con.Open();
                SqlCommand cmd = null;
                tr = con.BeginTransaction();
                if (DateTime.Parse(validFrom) < DateTime.Today)
                {
                    cmd = new SqlCommand("FlightDiscounting_Update", con,tr);
                }
                else
                {
                    cmd = new SqlCommand("FlightDiscounting_Delete", con,tr);
                }
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@New_AirLineDetail_ID", int.Parse(airLIne_ID));
                cmd.Parameters.AddWithValue("@New_Flight_ID", int.Parse(flght_ID));
                cmd.Parameters.AddWithValue("@New_Shipment_ID", int.Parse(shipment_ID));
                cmd.Parameters.AddWithValue("@New_Destination_Codes",destination_Code);
                cmd.Parameters.AddWithValue("@New_ValidFrom", DateTime.Parse(validFrom));
                cmd.Parameters.AddWithValue("@New_ValidTo", DateTime.Parse(validto));
                cmd.Parameters.AddWithValue("@ValidTo", DateTime.Today.AddDays(-1));
                cmd.Parameters.AddWithValue("@LastModifiyDate",DateTime.Today);             
              
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                tr.Commit();
                
            }
            catch (SqlException se)
            {
                string err = se.Message;
                tr.Rollback();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
            if (result == 0 || result == -1)
            {
                Session["msg"] = "Discounted value can not deleted due to some error";
                //lblError.Text = "Discounted value can not deleted due to some error";
                Response.Redirect("FlightDiscountingShow.aspx?id=d");
            }
            else
            {
                Session["msg"] = "Discounted value deleted Successfully.";
                //lblError.Text = "Discounted value deleted Successfully.";
                Response.Redirect("FlightDiscountingShow.aspx?id=d");
            }



    }
    ////////////////
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("FlightDiscountingShow.aspx");

    }
    protected string CheckExistsUpdateDestination(string Dest)
    {
        string result = "";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("CheckExistDestination", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@airlineDetail_ID", int.Parse(ddlAirlineName.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@Flight_ID", int.Parse(ddlFlight.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@Shipment_ID", int.Parse(ddlShip.SelectedValue.ToString()));
        com.Parameters.AddWithValue("@validFrom",DateTime.Today);
        com.Parameters.AddWithValue("@Validto", DateTime.Parse(ConvertDate1(txtDisValidTo.Text)));
        com.Parameters.AddWithValue("@Destination", Dest.Trim());

        SqlDataReader dr = com.ExecuteReader();

        while (dr.Read())
        {
            result = dr["Data"].ToString();
        }

        dr.Close();
        com.Dispose();
        con.Close();
        return result;

    }
}
