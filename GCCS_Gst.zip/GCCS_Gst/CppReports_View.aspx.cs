using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CppReports_View : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();

    int City_ID;
    string City_Name = "";
    string From_Date = "";
    string To_date = "";
    int j;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }



        else
        {
            LoadDetails1();
        }


    }
    public void LoadDetails1()
    {
        City_Name = Request.QueryString["cityname"];
        City_ID = Convert.ToInt32(Request.QueryString["cityid"].ToString());
        From_Date = Request.QueryString["fromdate"].ToString();
        To_date = Request.QueryString["todate"].ToString();
        //Panel2.Visible = true;

        int totalDeposite = 0;
        int totalExpired = 0;
        int totalAdvanced = 0;
        int totalredeemed = 0;
        int totalreverse = 0;

        int totalDeposite1 = 0;
        int totalExpired1 = 0;
        int totalAdvanced1 = 0;
        int totalredeemed1 = 0;
        int totalopeningbal1 = 0;
        int totalclosing = 0;
        int totalreverse1 = 0;

        string table1 = "";
        string old_agent_name = "";



        //---------------------------------------------------create table1//--------------------------------------


        //DataTable dt1 = dw.GetAllFromQuery("select am.agent_name ,ct.* from cpp_tran ct inner join agent_master am on ct.agent_id=am.agent_id where ct.city_id="+City_ID +" and ct.tran_date between '" + FormatDateDD(From_Date) + "'and '" + FormatDateDD(To_date) + "' order by ct.agent_id,ct.tran_date ");
        DataTable dt1 = null;


        dt1 = dw.GetAllFromQuery("create table #tem3( agent_name varchar(250), tran_id bigint, agent_id bigint,city_id bigint,opening_bal decimal, cpp decimal,closing_bal decimal,tran_type char,tran_date datetime,remarks varchar(255),Value_Date datetime )insert into #tem3( agent_name, tran_id , agent_id ,city_id ,opening_bal , cpp ,closing_bal ,tran_type ,tran_date ,remarks,Value_Date) select am.agent_name ,ct.* from cpp_tran ct inner join agent_master am on ct.agent_id=am.agent_id where ct.city_id=" + City_ID + " order by ct.agent_id,ct.tran_date ,ct.tran_id create table #tem4( agent_name varchar(250), tran_id bigint, agent_id bigint,city_id bigint,opening_bal decimal, cpp decimal,closing_bal decimal,tran_type char,tran_date datetime,remarks varchar(255),Value_Date datetime )insert into #tem4( agent_name, tran_id , agent_id ,city_id ,opening_bal , cpp ,closing_bal ,tran_type ,tran_date ,remarks,Value_Date) select am.agent_name ,ct.* from cpp_tran ct inner join agent_master am on ct.agent_id=am.agent_id where ct.city_id=" + City_ID + " AND ct.tran_date>='" + FormatDateDD(From_Date) + "' AND ct.tran_date<='" + FormatDateDD(To_date) + "' order by ct.agent_id,ct.tran_date ,ct.tran_id create table #tem5( agent_name varchar(250), tran_id bigint, agent_id bigint,city_id bigint,opening_bal decimal, cpp decimal,closing_bal decimal,tran_type char,tran_date datetime,remarks varchar(255),Value_Date datetime)insert into #tem5( agent_name, tran_id , agent_id ,city_id ,opening_bal , cpp ,closing_bal,tran_type,tran_date ,remarks,Value_Date  )SELECT * FROM #tem3 WHERE agent_id NOT IN (SELECT agent_id FROM #tem4)DECLARE @id INT DECLARE Agentin CURSOR FOR SELECT DISTINCT agent_id FROM #tem5 WHERE tran_date<='" + FormatDateDD(From_Date) + "' OPEN Agentin FETCH NEXT FROM Agentin INTO @id WHILE @@FETCH_STATUS=0 BEGIN insert into #tem4( agent_name, tran_id , agent_id ,city_id ,opening_bal ,closing_bal, tran_type,tran_date ,remarks,Value_Date  ) SELECT TOP 1 agent_name,tran_id,agent_id,city_id,closing_bal,closing_bal,tran_type,tran_date,remarks,Value_Date  FROM #tem5 WHERE tran_date<'" + FormatDateDD(From_Date) + "' AND agent_id=@id  ORDER BY  tran_date DESC,tran_id desc FETCH NEXT FROM Agentin INTO @id END CLOSE Agentin DEALLOCATE Agentin SELECT agent_name,tran_id,agent_id,city_id,opening_bal,ISNULL(cpp,0)AS cpp,closing_bal,tran_type,tran_date,remarks,Value_Date  FROM #tem4 ORDER BY agent_name");

        //dt1 = dw.GetAllFromQuery("create table #tem3( agent_name varchar(250), tran_id bigint, agent_id bigint,city_id bigint,opening_bal decimal, cpp decimal,closing_bal decimal,tran_type char,tran_date datetime,remarks varchar(255) ) insert into #tem3( agent_name, tran_id , agent_id ,city_id ,opening_bal , cpp ,closing_bal ,tran_type ,tran_date ,remarks ) select am.agent_name ,ct.* from cpp_tran ct inner join agent_master am on ct.agent_id=am.agent_id where ct.city_id=" + City_ID + " and ct.tran_date between '" + FormatDateDD(From_Date) + "'and '" + FormatDateDD(To_date) + "'  AND am.agent_id IN (SELECT agent_id FROM sales WHERE Airline_detail_id=147 AND csr_date between '" + FormatDateDD(From_Date) + "'and '" + FormatDateDD(To_date) + "') order by ct.agent_id,ct.tran_date ,ct.tran_id   select * from #tem3 order by agent_name");

        table1 = @"<table border=1 width=100% align=center cellpading=2 > <tr class=h1 width=100%><td align=center class=boldtext width=30% colspan=10 NOWRAP><h4> Cpp Reports </h4></tr>";
        table1 += @" <tr class=h1 width=100%><td align=center class=boldtext width=30% colspan=10 NOWRAP><h4> Reports for " + City_Name + " for period of " + From_Date + " - " + To_date + "</h4></td></tr>";
        if (dt1.Rows.Count > 0)
        {

            table1 = table1 + @"<tr><td class=boldtext align=center colspan=2 widtd=10%>S.No</td><td class=boldtext >Agent Name</td><td class=boldtext nowrap widtd=15% >Opening Bal</td><td class=boldtext nowrap widtd=20%>Earned</td><td class=boldtext nowrap widtd=15%>Advance</td><td class=boldtext widtd=15% >Expired</td><td class=boldtext widtd=15% >Advance Reverse </td><td class=boldtext widtd=15% >Redeemed</td><td widtd=30% class=boldtext >Closing Bal</td></tr>";
            int i = 0;
            old_agent_name = dt1.Rows[i]["agent_name"].ToString();
            string openingbal = dt1.Rows[i]["opening_bal"].ToString();
            for (i = 0; i < dt1.Rows.Count; i++)
            {

                string agent_name = dt1.Rows[i]["agent_name"].ToString();
                if (agent_name == old_agent_name)
                {
                    if (dt1.Rows[i]["Tran_type"].ToString() == "D")
                    {
                        totalDeposite += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                    }
                    else
                    {
                        if (dt1.Rows[i]["Tran_type"].ToString() == "E")
                        {
                            totalExpired += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                        }
                        else
                        {
                            if (dt1.Rows[i]["Tran_type"].ToString() == "A")
                            {
                                totalAdvanced += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                            }
                            else
                            {
                                if (dt1.Rows[i]["Tran_type"].ToString() == "B")
                                {
                                    totalreverse += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }
                                else
                                {

                                    totalredeemed += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }

                            }
                        }
                    }

                }
                else
                {



                    j = j + 1;

                    table1 = table1 + @"<tr><td class=boldtext align=center colspan=2 >" + j + @" </td><td class=boldtext align=left>" + old_agent_name + @"</td><td class=boldtext nowrap align=right >" + openingbal + @"</td><td class=boldtext align=right nowrap>" + totalDeposite + @"</td><td align=right class=boldtext nowrap>" + totalAdvanced + @"</td><td align=right class=boldtext nowrap>" + -totalExpired + @"</td><td align=right class=boldtext >" + -totalreverse + @"</td><td align=right class=boldtext >" + -totalredeemed + @"</td><td align=right class=boldtext nowrap>" + dt1.Rows[i - 1]["closing_bal"].ToString() + @"</td></tr>";
                    totalDeposite1 += totalDeposite;
                    totalExpired1 = totalExpired1 - totalExpired;
                    totalAdvanced1 += totalAdvanced;
                    totalredeemed1 = totalredeemed1 - totalredeemed;
                    totalopeningbal1 += Convert.ToInt32(openingbal);
                    totalreverse1 = totalreverse1 - totalreverse;
                    totalclosing += Convert.ToInt32(dt1.Rows[i - 1]["closing_bal"].ToString());


                    old_agent_name = dt1.Rows[i]["agent_name"].ToString();
                    openingbal = dt1.Rows[i]["opening_bal"].ToString();

                    totalAdvanced = 0;
                    totalDeposite = 0;
                    totalExpired = 0;
                    totalredeemed = 0;
                    totalreverse = 0;
                    if (dt1.Rows[i]["Tran_type"].ToString() == "D")
                    {
                        totalDeposite += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                    }
                    else
                    {
                        if (dt1.Rows[i]["Tran_type"].ToString() == "E")
                        {
                            totalExpired += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                        }
                        else
                        {
                            if (dt1.Rows[i]["Tran_type"].ToString() == "A")
                            {
                                totalAdvanced += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                            }
                            else
                            {
                                if (dt1.Rows[i]["Tran_type"].ToString() == "B")
                                {
                                    totalreverse += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }
                                else
                                {

                                    totalredeemed += Convert.ToInt32(dt1.Rows[i]["cpp"]);
                                }

                            }
                        }
                    }


                }






            }

            table1 = table1 + @"<tr><td class=boldtext align=center colspan=2 >" + (j + 1) + @" </td><td class=boldtext align=left >" + old_agent_name + @"</td><td align=right class=boldtext nowrap >" + openingbal + @"</td><td align=right class=boldtext nowrap>" + totalDeposite + @"</td><td align=right class=boldtext nowrap>" + totalAdvanced + @"</td><td align=right class=boldtext nowrap>" + -totalExpired + @"</td><td align=right class=boldtext >" + -totalreverse + @"</td><td align=right class=boldtext >" + -totalredeemed + @"</td><td align=right class=boldtext nowrap>" + dt1.Rows[i - 1]["closing_bal"].ToString() + @"</td></tr>";
            totalDeposite1 += totalDeposite;
            totalExpired1 = totalExpired1 - totalExpired;
            totalAdvanced1 += totalAdvanced;
            totalredeemed1 = totalredeemed1 - totalredeemed;
            totalopeningbal1 += Convert.ToInt32(openingbal);
            totalclosing += Convert.ToInt32(dt1.Rows[i - 1]["closing_bal"].ToString());
            totalreverse1 = totalreverse1 - totalreverse;
            table1 = table1 + @"<tr><td class=boldtext align=center colspan=3 > </td><td align=right class=boldtext nowrap >" + totalopeningbal1 + @"</td><td align=right class=boldtext nowrap>" + totalDeposite1 + @"</td><td align=right class=boldtext nowrap>" + totalAdvanced1 + @"</td><td align=right class=boldtext nowrap>" + totalExpired1 + @"</td><td align=right class=boldtext >" + totalreverse1 + @"</td><td align=right class=boldtext >" + totalredeemed1 + @"</td><td align=right class=boldtext nowrap>" + totalclosing + @"</td></tr>";

        }
        else
        {
            table1 = table1 + @"<tr><td class=boldtext style=""color: Red;font-family:verdana;font-size:12px; text-align: center;"" colspan=6>No Reports</td></tr>";

        }


        table1 = table1 + @"</table>";
        lblreports.Text = table1;
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}