using System;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Deccan_Tds : System.Web.UI.Page
{
	// Declare public variables here 
	SqlConnection con;
	SqlCommand com;
	SqlDataAdapter da;
	DataTable dt;
	/// <summary>
	/// Making Connection from web.config
	/// </summary>
	string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
	protected void Page_Load(object sender, EventArgs e)
	{
		if (Session["EMailID"] == null)
		{
			Response.Redirect("Login.aspx");
		}
		else
		{
			Search();
		}
	}

	// function for bind grid
	public void Search()
	{
		con = new SqlConnection(strCon);
		con.Open();
		string selectQ = null;
		selectQ = "select (am.Airline_name+'('+am.airline_code+')/'+c.city_name) as Airline_name,ad.airline_detail_id, fx.Sno,fx.AirlineDetailID,fx.TDSRate,CONVERT(VARCHAR,fx.ValidFrom,103)AS ValidFrom,CONVERT(VARCHAR,fx.ValidTo,103)AS ValidTo  from deccan_Tds fx inner join airline_detail ad on fx.AirlineDetailID=ad.Airline_detail_id inner join airline_master as am on am.airline_id=ad.airline_id inner join city_master c on c.city_id=ad.belongs_to_city ";
		com = new SqlCommand(selectQ, con);
		da = new SqlDataAdapter(com);
		dt = new DataTable();
		da.Fill(dt);
		grdfixcharges.DataSource = dt;
		grdfixcharges.DataBind();
		con.Close();

	}
	protected void Modify(object sender, CommandEventArgs e)
	{
		Response.Redirect("Add_Deccan_Tds.aspx?Sno=" + e.CommandName);
	}
	protected void grdAirline_PageIndexChanging(object sender, GridViewPageEventArgs e)
	{
		grdfixcharges.PageIndex = e.NewPageIndex;
		Search();
	}
	protected void lnkAdd_Click(object sender, EventArgs e)
	{
		Response.Redirect("Add_Deccan_Tds.aspx");
	}
}
