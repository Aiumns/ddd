using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//Updation Completed By 20/11/2007 by 12PM.Done By Ajeet Mittal
public partial class DiscountFlight : System.Web.UI.Page
{
   
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataAdapter sda = null;
    SqlDataReader dr = null;
    SqlTransaction tr = null;
    public string flight_id = null;
    string shipment = null;
    public  string date = null;
    public  string[] ssinfo=new string[20];
    string flightOpenID=null;
    string str6 = "";
    string str7 = "";
    string str8 = "";
    string str9 = "",notSec="";
    string strDt1 = "", strDt2 = "", strDt3 = "", strDt4 = "";
    string s = null;
    string[] strlength = null;
    int p = 0;
    int q = 1;
    int r = 2;
    int t = 3;
    int pk = 4;
    int l = 0;
    string[] PrefixValue = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            
            date = Request.QueryString["date"].ToString();
            flight_id = Request.QueryString["fno"].ToString();
            string s = showDetails(Request.QueryString["date"].ToString(), Request.QueryString["fno"].ToString());
            ssinfo = s.Split(',');
            if (!Page.IsPostBack)
            {
                SlabData();
                lstSectorData();
                FillDataShipment();
                TextBox1.Text = Request.QueryString["cap"].ToString();
                TextBox2.Text = ssinfo[6];
                ShowAddData(flightOpenId(), 5);
                txtDisValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
                txtDisValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");

                // txtDisValidFrom.Attributes.Add("onblur", "return CompareDates()()");
               Button1.Attributes.Add("onclick", "return  CompareDt() ");
               // Button1.Attributes.Add("onclick", "return chk() ");
               
                // Button1.Attributes.Add("onclick", "return  CompareDates() ");
                hdn.Value = Session["groupid"].ToString();
                HiddenFlightDt.Value = Request.QueryString["date"].ToString();
            }
            // lblMsg.Visible = false;
            lblMsg.Text = "";
            lblMsg2.Text = "";
        }
    }
    protected DataTable MakeTable()
    {
        DataTable dt = new DataTable();
        DataColumn dc1 = new DataColumn();
        dc1.Caption = "Destination:";
        dc1.ColumnName = "Destination";
        dc1.DataType = System.Type.GetType("System.String");
        DataColumn dc2 = new DataColumn();
        dc2.Caption = "Sector";
        dc2.ColumnName = "Sector";
        dc2.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc1);
        dt.Columns.Add(dc2);
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select slab_name, from slab_master order by slab_start", con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                dt.Columns.Add(new DataColumn(dr["slab_name"].ToString(), typeof(string)));
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return dt;
    }    

    protected void lstSectorData()
    {
        
        string searchString = null;
        con = new SqlConnection(strCon);
        if (rbtnSector.Checked == true)
        {            
            searchString = "Select distinct asm.sector_name,asm.Sector_ID from airline_sector_master asm inner join Airline_Master am on am.Airline_ID=asm.Airline_ID inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join airline_sector_details asd on asd.sector_id=asm.sector_id where fm.flight_no='" + flight_id + "'";
        }
        else
        {
            //searchString = "Select distinct dm.Destination_Code,ar.Destination from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID inner join airline_sector_details asd on asd.destination_id=ar.destination where fm.flight_no='" + flight_id + "'";

            searchString = "Select distinct dm.Destination_Code,ar.Destination from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join flight_master fm on fm.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where fm.flight_no='" + flight_id + "'";
        }
        try
        {
            con.Open();
            com = new SqlCommand(searchString, con);
            SqlDataReader dr = com.ExecuteReader();
            chkBoxList.Items.Clear();
            int p = 0;
            while (dr.Read())
            {
                chkBoxList.Items.Add(new ListItem(" "+dr[0].ToString(), dr[1].ToString()));
                p = p + 1;
            }
            HiddSec.Value =p.ToString() ;
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void rbtnSector_CheckedChanged(object sender, EventArgs e)
    {
        shipment = ddlShip.SelectedItem.Text;       
        FillDataShipment();
        lstSectorData();
        ddlShip.SelectedItem.Text = shipment;
        lblSec.Text = "Sector code";
        ShowAddData(flightOpenId(), 5);   
    }
    protected void rbtnDes_CheckedChanged(object sender, EventArgs e)
    {
        shipment = ddlShip.SelectedItem.Text;      
        lstSectorData();
        FillDataShipment();
        ddlShip.SelectedItem.Text = shipment;
        lblSec.Text = "Destination Code";
        ShowAddData(flightOpenId(), 5);   
        
    }
    protected void FillDataShipment()
    {
        ddlShip.Items.Clear();
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select distinct shipment_id,shipment_name from Shipment_master order by shipment_name", con);
            SqlDataReader dr = com.ExecuteReader();          
            while (dr.Read())
            {
                ddlShip.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
            }
            dr.Close();
            ddlShip.SelectedValue = "8";
            com.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }   

    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }   

    protected void SlabData()
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("select s.slab_name,s.slab_id from slab_master s inner join airline_slab a on a.slab_id=s.slab_id where a.airline_detail_id=(select airline_detail_id from flight_master where flight_no='" + flight_id + "')order by s.slab_start", con);
        SqlDataReader dr = com.ExecuteReader();       
        gvSlab.DataSource = dr;
        gvSlab.DataBind();
        dr.Close();
        com.Dispose();
        con.Close();
    }
    protected void gridview1_rowdatabound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList ddl = (DropDownList)e.Row.FindControl("ddlPrefix");
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select prefix_name,prefix_id from prefix_master", con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                ddl.Items.Add(new ListItem(dr[0].ToString(), dr[1].ToString()));
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
    }

    protected string showDetails(string date, string fno)
    {
        string basicinfo = null;
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select m.flight_no,m.flight_type,c.city_name,d.destination_name,convert(varchar,o.flight_date,103)as flight_date,o.open_capacity,convert(varchar,o.close_date,103)as close_date,o.flight_id,Airline_Text_Code  from flight_master m inner join  Airline_Detail b on m.Airline_Detail_ID=b.Airline_Detail_ID inner join Airline_Master am on b.Airline_ID=am.Airline_ID inner join flight_open o on m.flight_id=o.flight_id inner join city_master c on c.city_id=m.origin inner join destination_master d on d.destination_id=m.destination where convert(varchar,o.flight_date,103)='" + date + "' and o.flight_id=(select flight_id from flight_master where flight_no='" + fno + "')", con);
            SqlDataReader sdr = com.ExecuteReader();
            if (sdr.Read())
                basicinfo = sdr[0].ToString() + "," + sdr[1].ToString() + "," + sdr[2].ToString() + "," + sdr[3].ToString() + "," + sdr[4].ToString() + "," + sdr[5].ToString() + "," + sdr[6].ToString() + "," + sdr[7].ToString() + "," + sdr[8].ToString();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return basicinfo;
    }
    protected void ShowAddData(string flightOpenID,int top)
    {
        Session["Cond"] = "First";        
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            //SqlDataAdapter sda = new SqlDataAdapter("select distinct top " + top + " d.destination_code,d.destination_id, g.sector_name,f.shipment_name,a.datewise_discount_id,a.sector_id,a.shipment_id from Sector_Datewise_Discount_Details a inner join Sector_Datewise_Discount b on a.Datewise_Discount_id=b.Datewise_Discount_id inner join destination_master d on d.destination_id=a.destination_id  inner join shipment_master f on f.shipment_id=a.shipment_id inner join airline_sector_master g on g.sector_id=a.sector_id where b.flight_open_id=" + flightOpenID + " ", con);
            SqlDataAdapter sda = new SqlDataAdapter("select distinct top " + top + " d.destination_code,d.destination_id,f.shipment_name,a.datewise_discount_id,a.shipment_id from Sector_Datewise_Discount_Details a inner join Sector_Datewise_Discount b on a.Datewise_Discount_id=b.Datewise_Discount_id inner join destination_master d on d.destination_id=a.destination_id  inner join shipment_master f on f.shipment_id=a.shipment_id where b.flight_open_id=" + flightOpenID + " ", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            gvDisplay.DataSource = dt;
            gvDisplay.DataBind();
            if (dt.Rows.Count < 5)
            {
                gvDisplay.FooterRow.Visible = false;
            }
            sda.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void gvDisplay_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvDisplay.PageIndex = e.NewPageIndex;
        ShowAddData(flightOpenID,5);      
    }

    protected void Button1_Click(object sender, EventArgs e)
    {        
        string ident = null;
        int sID = 0;
        flightOpenID = flightOpenId();
        string shipid = ddlShip.SelectedItem.Value;
        s = showDetails(Request.QueryString["date"].ToString(), Request.QueryString["fno"].ToString());
        string[] ss = s.Split(',');
        DateTime dt1 = DateTime.Parse(ConvertDate1(txtDisValidFrom.Text));
        DateTime dt2 = DateTime.Parse(ConvertDate1(txtDisValidTo.Text));
        con = new SqlConnection(strCon);      
        try
        {
           // con.Open();
            while (dt1 <= dt2)
            {
                SqlConnection connection = new SqlConnection(strCon);
                SqlCommand command = new SqlCommand("select flight_open_id from flight_open where flight_date='" + dt1 + "' and flight_id=" + long.Parse(ss[7]) + "", connection);
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    flightOpenID = reader["flight_open_id"].ToString();
                    reader.Dispose();
                    command.Dispose();
                    command = new SqlCommand("select flight_open_id,datewise_discount_id from Sector_Datewise_Discount where flight_open_id=" + flightOpenID + " ", connection);
                    reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        //Read datewise_discount_id from Sector_Datewise_Discount
                        ident = reader["datewise_discount_id"].ToString();
                        command.Dispose();
                        reader.Dispose();                        
                    }
                    else
                    {                       
                        //insert flight_open_id in Sector_Datewise_Discount
                        SqlConnection conn = new SqlConnection(strCon);
                        conn.Open();
                        SqlCommand comm = new SqlCommand("insert into Sector_Datewise_Discount(Flight_ID,Flight_Open_ID) values(@Flight_ID,@Flight_Open_ID)", conn);

                        comm.Parameters.Add("@Flight_ID", SqlDbType.BigInt).Value = long.Parse(ss[7]);
                        comm.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(flightOpenID);
                        comm.ExecuteNonQuery();
                        comm.Dispose();
                        //reader.Dispose();
                        comm = new SqlCommand("select ident_current('Sector_Datewise_Discount')", conn);
                        SqlDataReader reader1 = comm.ExecuteReader();
                        if (reader1.Read())
                        {
                            ident = reader1[0].ToString();
                            comm.Dispose();
                            reader1.Dispose();

                        }

                        reader.Dispose();
                        command.Dispose();

                    }
                                        
                    if (rbtnSector.Checked == true)
                    {
                        for (int k = 0; k < chkBoxList.Items.Count; k++)
                        {
                            if (chkBoxList.Items[k].Selected == true)
                            {
                                con.Open();
                                com = new SqlCommand("select a.destination_id,b.destination_code from airline_sector_details a inner join destination_master b on b.destination_id=a.destination_id  where sector_id=" + chkBoxList.Items[k].Value + " ", con);
                                dr = com.ExecuteReader();
                                while (dr.Read())
                                {
                                    string search2 = "select  flight_id,flight_open_id,shipment_id,destination_id from Sector_Datewise_Discount a inner join Sector_Datewise_Discount_details b on a.datewise_discount_id=b.datewise_discount_id where a.flight_open_id=" + flightOpenID + " and shipment_id=" + shipid + "  and destination_id=" +dr[0].ToString()+ " ";
                                   SqlConnection conn1=new SqlConnection(strCon);
                                      conn1.Open();
                                   SqlCommand comm = new SqlCommand(search2, conn1);
                                   SqlDataReader drr = comm.ExecuteReader();
                                    if (!drr.HasRows)
                                    {
                                        //str7 = str7 + " " + chkBoxList.Items[k].Value;
                                        str9 = str9 + ", " + dr[1].ToString() + "(" + ConvertDate1(dt1.ToString().Substring(0,10)) + ")";
                                        

                                        drr.Dispose();
                                        comm.Dispose();
                                        ///////////////                    
                                               
                                                for (int j = 0; j < gvSlab.Rows.Count; j++)
                                                {
                                                    GridViewRow gr = gvSlab.Rows[j];
                                                    sID = Int32.Parse(gvSlab.DataKeys[j].Value.ToString());
                                                    TextBox tt = (TextBox)gr.FindControl("txtSlab");
                                                    DropDownList dd = (DropDownList)gr.FindControl("ddlPrefix");
                                                    SqlConnection con7 = new SqlConnection(strCon);
                                                    con7.Open();
                                                    SqlCommand com7 = new SqlCommand("insert into Sector_Datewise_Discount_details(Datewise_Discount_ID,Slab_ID,Destination_ID,Prefix_ID,Price_Value,shipment_id) values(@Datewise_Discount_ID,@Slab_ID,@Destination_ID,@Prefix_ID,@Price_Value,@shipment_id)", con7);
                                                    com7.Parameters.AddWithValue("@Datewise_Discount_ID", ident);
                                                    com7.Parameters.AddWithValue("@Slab_ID", sID);
                                                    com7.Parameters.AddWithValue("@Destination_ID", dr[0].ToString());
                                                   
                                                    com7.Parameters.AddWithValue("@Prefix_ID", dd.SelectedItem.Value);
                                                    com7.Parameters.AddWithValue("@Price_Value", tt.Text);
                                                    com7.Parameters.AddWithValue("@Shipment_ID", shipid);
                                                    com7.ExecuteNonQuery();
                                                    con7.Close();
                                                   lblMsg.Text = "Discount on destination" + str9 + " Saved";
                                                   // lblMsg.Text = "Discount on destination" + RemoveDup(str9) + " Saved";
                                                    
                                                }                              
                                        
                                    }
                                    else
                                    {
                                        drr.Dispose();
                                        comm.Dispose();

                                        str6 = str6 + ", " + dr[1].ToString()+"("+ ConvertDate1(dt1.ToString().Substring(0,10))+")";
                                        lblMsg2.Text = "Discount on destination" + str6 + " already exist";
                                        //str8 = str8 + " " + chkBoxList.Items[k].Text;
                                        //Discouunt alrady addd on this destination
                                    }
                                    conn1.Close();
                                    comm.Dispose();
                             
                                }//end of while loop
                                con.Close();
                            }
                        }//end of for loop.
                    }
                    else if(rbtnDes.Checked == true)
                    {
                        for (int k = 0; k < chkBoxList.Items.Count; k++)
                        {
                            if (chkBoxList.Items[k].Selected == true)
                            {
                                string search2 = "select  flight_id,flight_open_id,shipment_id,destination_id from Sector_Datewise_Discount a inner join Sector_Datewise_Discount_details b on a.datewise_discount_id=b.datewise_discount_id where a.flight_open_id=" + flightOpenID + " and shipment_id=" + shipid + "  and destination_id=" + chkBoxList.Items[k].Value + " ";
                                 con.Open();
                                com = new SqlCommand(search2, con);
                                dr = com.ExecuteReader();
                                
                               if (!dr.HasRows)
                                
                                {
                                    str7 = str7 + " " + chkBoxList.Items[k].Value;
                                    str9 = str9 + ", " + chkBoxList.Items[k].Text + "(" + ConvertDate1(dt1.ToString().Substring(0,10))+")";

                                    dr.Close();
                                    com.Dispose(); 
                                   
                                             for (int j = 0; j < gvSlab.Rows.Count; j++)
                                                {
                                                    GridViewRow gr = gvSlab.Rows[j];
                                                    sID = Int32.Parse(gvSlab.DataKeys[j].Value.ToString());
                                                    TextBox tt = (TextBox)gr.FindControl("txtSlab");
                                                    DropDownList dd = (DropDownList)gr.FindControl("ddlPrefix");
                                                    SqlConnection con7 = new SqlConnection(strCon);
                                                    con7.Open();
                                                    SqlCommand com7 = new SqlCommand("insert into Sector_Datewise_Discount_details(Datewise_Discount_ID,Slab_ID,Destination_ID,Prefix_ID,Price_Value,shipment_id) values(@Datewise_Discount_ID,@Slab_ID,@Destination_ID,@Prefix_ID,@Price_Value,@shipment_id)", con7);
                                                    com7.Parameters.AddWithValue("@Datewise_Discount_ID", ident);
                                                    com7.Parameters.AddWithValue("@Slab_ID", sID);
                                                    com7.Parameters.AddWithValue("@Destination_ID", chkBoxList.Items[k].Value);                                                   
                                                    com7.Parameters.AddWithValue("@Prefix_ID", dd.SelectedItem.Value);
                                                    com7.Parameters.AddWithValue("@Price_Value", tt.Text);
                                                    com7.Parameters.AddWithValue("@Shipment_ID", shipid);
                                                    com7.ExecuteNonQuery();
                                                    con7.Close();
                                                    
                                                    lblMsg.Text = "Discount on destination" + str9 + " Saved";
                                                }
                                               

                                            }
                                            //dr.Close();                                 
                                    
                               else 
                               {
                                   str6 = str6 + " " + chkBoxList.Items[k].Value;
                                   str8 = str8 + " ," + chkBoxList.Items[k].Text + "(" + ConvertDate1(dt1.ToString().Substring(0,10))+")";
                                  // str6 = str6 + " " + dr[0].ToString();
                                   lblMsg2.Text = "Discount on destination" + str8 + " already exist";
                                   //discount alrsdy add.
                               }
                               con.Close();
                            }
                        }//end of for loop(dest.)
                    }//end of else (dest)

                }
                 dt1=dt1.AddDays(1);
            }//end of while loop for dt1.
            con.Open();
            com = new SqlCommand("update flight_open set open_capacity=" + Convert.ToDecimal(TextBox1.Text.Trim()) + ",close_date='" + Convert.ToDateTime(ConvertDate1(TextBox2.Text)) + "' where flight_Open_id=" + flightOpenID + " ", con);
            int result1 = com.ExecuteNonQuery();
            com.Dispose();
            con.Close();

        }//end of try .                                  
        
        catch (SqlException se)
        {
            string err = se.Message; 
           
        }
        catch (Exception be)
        {
            string err = be.Message; 
           
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        ShowAddData(flightOpenId(),5);
    }
    protected string flightOpenId()
    {
        string f = null;
          s = showDetails(Request.QueryString["date"].ToString(), Request.QueryString["fno"].ToString());
        string[] ss = s.Split(',');
        con = new SqlConnection(strCon);     
        try
        {
            con.Open();
            com = new SqlCommand("select flight_open_id from flight_open where  convert(varchar,flight_Date,103)='" + date + "' and flight_id=" + ss[7] + " ", con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
               f = dr[0].ToString();
            dr.Close();
            com.Dispose();
        }
        catch (SqlException se)
        {
            string err = se.Message;           
        }
        catch (Exception be)
        {
            string err = be.Message;           
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return f;
    }

    protected void btnPage_Click(object o, EventArgs e)
    {
        Session["Cond"] = "First";   
        LinkButton Button1 = (LinkButton)o;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;       
        Button1.Visible = true;
        con = new SqlConnection(strCon);
        try
        {
            //con.Open();
            //SqlDataAdapter sda = new SqlDataAdapter("select distinct d.destination_code,d.destination_id, g.sector_name,f.shipment_name from Sector_Datewise_Discount_Details a inner join Sector_Datewise_Discount b on a.Datewise_Discount_id=b.Datewise_Discount_id inner join destination_master d on d.destination_id=a.destination_id  inner join shipment_master f on f.shipment_id=a.shipment_id inner join airline_sector_master g on g.sector_id=a.sector_id where b.flight_open_id=" + flightOpenId() + " ", con);
            //DataTable dt = new DataTable();
            //sda.Fill(dt);
            //gvDisplay.DataSource = dt;
            //gvDisplay.DataBind();
            //sda.Dispose();
            //con.Close();
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select distinct d.destination_code,d.destination_id,f.shipment_name,a.datewise_discount_id,a.shipment_id from Sector_Datewise_Discount_Details a inner join Sector_Datewise_Discount b on a.Datewise_Discount_id=b.Datewise_Discount_id inner join destination_master d on d.destination_id=a.destination_id  inner join shipment_master f on f.shipment_id=a.shipment_id where b.flight_open_id=" + flightOpenId() + " ", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            gvDisplay.DataSource = dt;
            gvDisplay.DataBind();
            
            sda.Dispose();
            con.Close();

            LinkButton bb = (LinkButton)gvDisplay.FooterRow.FindControl("btnPage");
            bb.Visible = false;
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    } 
   
    public void makeTable(Table t1)
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand("select s.slab_name from slab_master s inner join airline_slab a on a.slab_id=s.slab_id where a.airline_detail_id=(select airline_detail_id from flight_master where flight_no='" + flight_id + "')order by s.slab_start", con);
        sda = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        sda.Fill(ds, "slab");       
        foreach (DataColumn dc in ds.Tables[0].Columns)
        {
            TableRow trow = new TableRow();
            string str = "";
            string strwidth ="";
            int i = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                Label lbl = new Label();
                lbl.ID = "head" + i;                
                lbl.Text = dr[0].ToString();
                str += lbl.Text.Length + ",";
                TableCell tcellcoldata = new TableCell();
                tcellcoldata.Controls.Add(lbl);
                tcellcoldata.Width = 75;
                trow.Cells.Add(tcellcoldata);
                i++;
            }
            t1.Rows.Add(trow);
            str = str.Substring(0, str.LastIndexOf(','));
           strlength=str.Split(',');          
           Session["Head"] = t1;           
        }        
    }

    public void makeRowTable(Table t2, string  strDest1,string strShipment)
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand("select e.slab_id,a.price_value,h.prefix_name,h.prefix_ID from Sector_Datewise_Discount_Details a inner join Sector_Datewise_Discount b on a.Datewise_Discount_id=b.Datewise_Discount_id inner join destination_master d on d.destination_id=a.destination_id inner join slab_master e on e.slab_id=a.slab_id inner join shipment_master f on f.shipment_id=a.shipment_id inner join prefix_master h on h.prefix_id=a.prefix_id where b.flight_open_id=" + flightOpenId() + " and d.destination_id='" + strDest1 + "' and f.shipment_id=" + strShipment + " order by e.slab_start ", con);

        //inner join airline_sector_master g on g.sector_id=a.sector_id
        sda = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        sda.Fill(ds, "Price");

        if (ds.Tables["Price"].Rows.Count > 0)
        {
            {
                TableRow trow = new TableRow();
                int s = 0;
                foreach (DataRow dr in ds.Tables["Price"].Rows)
                {
                    Label lbl = new Label();
                    lbl.ID = "slab" + s;
                    lbl.Text = dr[0].ToString();
                    //lbl.Width = 25;
                    TableCell tcellcoldata = new TableCell();

                    tcellcoldata.Controls.Add(lbl);
                    trow.Cells.Add(tcellcoldata);
                    s++;
                }
                t2.Rows.Add(trow);
                t2.Rows[0].Visible = false;
            }
            {
                TableRow trow = new TableRow();
                int i = 0;
                int idtex = 0;
                foreach (DataRow dr in ds.Tables["Price"].Rows)
                {
                    Label lbl = new Label();
                    lbl.ID = "Price" + idtex;
                    lbl.Text = dr[1].ToString() ;                    
                    TableCell tcellcoldata = new TableCell();
                    tcellcoldata.Width = 75;
                    tcellcoldata.Controls.Add(lbl);
                    trow.Cells.Add(tcellcoldata);
                    idtex++;                   
                }
                t2.Rows.Add(trow);
            }
            TableRow trowperfix = new TableRow();
            int k = 0;
            int idper = 0;
            foreach (DataRow dr in ds.Tables["Price"].Rows)
            {
                Label lbl = new Label();
                lbl.ID = "Prefix" + idper;
                lbl.Text = dr[2].ToString() ;
                TableCell tcellcoldata = new TableCell();                
                tcellcoldata.Controls.Add(lbl);
                tcellcoldata.Width = 75 ;
                trowperfix.Cells.Add(tcellcoldata);
                idper++;
            }
            t2.Rows.Add(trowperfix);

            TableRow perfix = new TableRow();
            int asa=0;
            int kk = 0;
            foreach (DataRow dr in ds.Tables["Price"].Rows)
            {
                Label lbl = new Label();
                lbl.ID = "PrefixID" + asa;
                lbl.Text = dr[3].ToString();
                TableCell tcellcoldata = new TableCell();
                tcellcoldata.Controls.Add(lbl);
                tcellcoldata.Width = 75 ;
                perfix.Cells.Add(tcellcoldata);
                asa++;
            }
            t2.Rows.Add(perfix);
            t2.Rows[3].Visible = false;
            //Session["Body"] = t2;
        }
    }
    public void makeTableForGrid(Table t2, string str)
    {
        string strdestID = Session["sdestID"].ToString();
        //string strsectorID = Session["ssectorID"].ToString();
        string strShipmentID = Session["sShipmentID"].ToString();
        string strdiscountID = Session["sdiscountID"].ToString();
        con = new SqlConnection(strCon);
        com = new SqlCommand("SELECT Slab_ID, Price_Value,Prefix_ID FROM Sector_Datewise_Discount_Details WHERE Datewise_Discount_ID='" + strdiscountID + "' and Destination_ID='" + strdestID + "' and Shipment_ID=" + strShipmentID + " ", con);
        //and Sector_ID='" + strsectorID + "' 
        sda = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        sda.Fill(ds, "Price");

        if (ds.Tables["Price"].Rows.Count > 0)
        {
            {
                TableRow trow = new TableRow();
                int s = 0;
                foreach (DataRow dr in ds.Tables["Price"].Rows)
                {
                    Label lbl = new Label();
                    lbl.ID = "slab" + s;
                    lbl.Text = dr[0].ToString();
                    //lbl.Width = 25;
                    TableCell tcellcoldata = new TableCell();
                    tcellcoldata.Controls.Add(lbl);
                    trow.Cells.Add(tcellcoldata);
                    s++;
                }
                t2.Rows.Add(trow);
                t2.Rows[0].Visible = false;
            }
            {
                TableRow trow = new TableRow();
                int i = 0;
                int idtex = 0;
                foreach (DataRow dr in ds.Tables["Price"].Rows)
                {
                    Label lbl = new Label();
                    lbl.ID = "Price" + idtex;
                    lbl.Text = dr[1].ToString();
                    TableCell tcellcoldata = new TableCell();
                    //tcellcoldata.Width = int.Parse(strlength[i])*7;
                    tcellcoldata.Controls.Add(lbl);
                    trow.Cells.Add(tcellcoldata);
                    idtex++;
                }
                t2.Rows.Add(trow);
            }            
            TableRow perfix = new TableRow();
            int asa = 0;
            foreach (DataRow dr in ds.Tables["Price"].Rows)
            {
                Label lbl = new Label();
                lbl.ID = "PrefixID" + asa;
                lbl.Text = dr[2].ToString();
                TableCell tcellcoldata = new TableCell();
                tcellcoldata.Controls.Add(lbl);
                //tcellcoldata.Width = int.Parse(strlength[k]) * 7;
                perfix.Cells.Add(tcellcoldata);
                asa++;
            }
            t2.Rows.Add(perfix);
           
           Session["Body"] = t2;
        }
    }     
    protected void gvDisplay_RowDataBound(object sender, GridViewRowEventArgs e)
     {
        if (e.Row.RowType == DataControlRowType.Header)
        {
                Table tab = (Table)e.Row.Cells[3].FindControl("Table2");
                makeTable(tab);              
        }        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Table tabData = (Table)e.Row.Cells[4].FindControl("Table1");
            Label code = (Label)e.Row.Cells[0].FindControl("lblDesCodeValue");
            Label code1 = (Label)e.Row.Cells[0].FindControl("lblShipmentCode");
            string strDest = code.Text;
            string strShip = code1.Text;
            makeRowTable(tabData, strDest, strShip);

            /////////////////
            LinkButton db = (LinkButton)e.Row.Cells[6].Controls[0];
           //db.OnClientClick = "return confirm('Delete Record?');";

        db.OnClientClick =string.Format("javascript: return confirm('Are you certain you want to delete ?');");

            //db.Attributes.Add("onclick", " javascript: return confirm('Are you sure,you want to delete?')");

            ///////////////

        //   Button l = (Button)e.Row.FindControl("btnDelete");
        //    Label lbl = (Label)e.Row.FindControl("lblAsset");
        //   l.Attributes.Add("onclick", " javascript: return confirm('Are you sure,you want to delete?')");

        }        
    }    
    public DataTable maketable()
    {
        DataTable dt = new DataTable();

        DataColumn dc = new DataColumn("SlabName", typeof(String));
        dt.Columns.Add(dc);

        DataColumn dc1 = new DataColumn("DiscountValue", typeof(Decimal));
        dt.Columns.Add(dc1);

        //DataColumn dc2 = new DataColumn("Prefix", typeof(String));
        //dt.Columns.Add(dc2);
        
        DataColumn dc3 = new DataColumn("SlabID", typeof(String));
        dt.Columns.Add(dc3);

        DataColumn dc4 = new DataColumn("PrefixID", typeof(String));
        dt.Columns.Add(dc4);

        return dt;
    }
    protected void gvDisplay_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        
        Table bodytab = (Table)gvDisplay.Rows[e.NewSelectedIndex].FindControl("Table1");
        
        Label destID = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("lblDesCodeValue");
      //  Label sectorID = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("lblSectorID");
        Label ShipmentID = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("lblShipmentCode");
        Label discountID = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("lbldiscountID");
        //Label prefixID = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("lblprefixID");
        Label labDest = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("lblDesCode");
       // Label lablSector = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("Label1");
        Label labShipment = (Label)gvDisplay.Rows[e.NewSelectedIndex].FindControl("lblShipment");
        lblDest.Text = labDest.Text;
        //lblSector.Text = lablSector.Text;
        lblShipment.Text = labShipment.Text;
        Table head = (Table)Session["Head"];
        
        string strdestID = destID.Text;
        //string strsectorID = sectorID.Text;
        string strShipmentID = ShipmentID.Text;
        string strdiscountID = discountID.Text;
        
        //string strprefixID = prefixID.Text;
        Session["sdestID"] = strdestID;
        //Session["ssectorID"] = strsectorID;//////////////
        Session["sShipmentID"] = strShipmentID;
        Session["sdiscountID"] = strdiscountID;
        //Session["sprefixID"] = strprefixID;
        makeTableForGrid(bodytab, strdestID);
        Table body = (Table)Session["Body"];
        
        string strSlabName="";
        string strSlabID="";
        string strPriceValue="";
        string strPrefixValue="";
        string strPrefixID = "";
        int h=head.Rows[0].Cells.Count;
       
        
        foreach(TableRow tr in head.Rows)
        {
            for(int i=0;i<tr.Cells.Count;i++)
            { 
              strSlabName=strSlabName+((Label)tr.Cells[i].FindControl("head"+i)).Text+",";
            }
        } 
            strSlabName=strSlabName.Remove(strSlabName.LastIndexOf(','));
            string[]SlabName=strSlabName.Split(',');

         for (int i = 0; i < body.Rows[0].Cells.Count; i++)
         {
             strSlabID = strSlabID + ((Label)body.Rows[0].Cells[i].FindControl("slab" + i)).Text + ",";
         }

         strSlabID = strSlabID.Remove(strSlabID.LastIndexOf(','));
         string[] SlabID = strSlabID.Split(','); 
    
            for(int i=0;i<body.Rows[0].Cells.Count;i++)
            {
                strPriceValue = strPriceValue + ((Label)body.Rows[0].Cells[i].FindControl("Price"+i)).Text + ",";
            }

            strPriceValue = strPriceValue.Remove(strPriceValue.LastIndexOf(','));
              string[]PriceValue=strPriceValue.Split(',');        
  
          //  for(int i=0;i<body.Rows[1].Cells.Count;i++)
          //  {
          //      strPrefixValue = strPrefixValue + ((Label)body.Rows[1].Cells[i].FindControl("Prefix" + i)).Text + ",";
          //  }
          //  strPrefixValue = strPrefixValue.Remove(strPrefixValue.LastIndexOf(','));
          //PrefixValue=strPrefixValue.Split(',');
          
            for (int i = 0; i < body.Rows[1].Cells.Count; i++)
          {
              strPrefixID = strPrefixID + ((Label)body.Rows[1].Cells[i].FindControl("PrefixID" + i)).Text + ",";
          }
          strPrefixID = strPrefixID.Remove(strPrefixID.LastIndexOf(','));
          string[] PrefixID = strPrefixID.Split(',');
          
         DataTable dt = maketable();
        for(int i=0;i<h;i++)
        {
            DataRow dr = dt.NewRow();
            dr[0]=SlabName[i].ToString();
            string dd=SlabName[i].ToString();
            dr[1]=decimal.Parse(PriceValue[i].ToString());
            string ff=PriceValue[i].ToString();
            //dr[2]=PrefixValue[i].ToString();
            //string hh=PrefixValue[i].ToString();
            dr[2] = SlabID[i].ToString();
            string qq = SlabID[i].ToString();
            dr[3] = PrefixID[i].ToString();
            string pp = PrefixID[i].ToString();
            dt.Rows.Add(dr);
        }
        ViewState["dtSlab"]=dt;
        ViewState["count"] = dt.Rows.Count;
        //gvSlabEdit.Visible = true;
        gvSlabEdit.DataSource =  dt;
        gvSlabEdit.DataBind();
        //btnUpdate.Visible = true;
        //btnReset.Visible = true;
        Panel1.Visible = true;
        gvDisplay.Columns[6].Visible = false;
        gvDisplay.Rows[e.NewSelectedIndex].Visible=false;
        ShowAddData(flightOpenId(), 5);
        gvSlab.Visible = false;
        Button1.Visible = false;

        

    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string strdestID = Session["sdestID"].ToString();
        //string strsectorID = Session["ssectorID"].ToString();
        string strShipmentID = Session["sShipmentID"].ToString();
        string strdiscountID = Session["sdiscountID"].ToString();
        //string strprefixID = Session["sprefixID"].ToString();

        for (int j = 0; j < gvSlabEdit.Rows.Count; j++)
        {
            GridViewRow gr = gvSlabEdit.Rows[j];
            //sID = Int32.Parse(gvSlabEdit.DataKeys[j].Value.ToString());
            Label tt = (Label)gr.FindControl("lblSlab");
            TextBox txtprice = (TextBox)gr.FindControl("txtSlab");
            Label slabID = (Label)gr.FindControl("lblSlabID");            
            DropDownList dd = (DropDownList)gr.FindControl("ddlPrefix");
            SqlConnection con7 = new SqlConnection(strCon);
            con7.Open();
            SqlCommand com7 = new SqlCommand("Update Sector_Datewise_Discount_details SET Prefix_ID=@Prefix_ID,Price_Value=@Price_Value WHERE Datewise_Discount_ID='" + strdiscountID + "'and Slab_ID='" + slabID.Text + "'and Destination_ID='" + strdestID + "' and Shipment_ID=" + strShipmentID + " ", con7);
            //and Sector_ID='" + strsectorID + "'
            com7.Parameters.AddWithValue("@Prefix_ID", dd.SelectedItem.Value);
            com7.Parameters.AddWithValue("@Price_Value", txtprice.Text);
            com7.ExecuteNonQuery();
            con7.Close();              
        }
        ShowAddData(flightOpenId(), 5);
        //gvSlabEdit.Visible = false;
        //btnUpdate.Visible = false;
        //btnReset.Visible = false;
        Panel1.Visible = false;
        gvDisplay.Columns[6].Visible = true;
        gvSlab.Visible = true;
        Button1.Visible = true;

    }
    
   protected void gvSlabEdit_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable dt= (DataTable)ViewState["dtSlab"];           
           ((Label)e.Row.Cells[p].FindControl("lblSlab")).Text = dt.Rows[l]["SlabName"].ToString();
           ((TextBox)e.Row.Cells[q].FindControl("txtSlab")).Text = dt.Rows[l]["DiscountValue"].ToString();
           //string prefix = dt.Rows[l]["Prefix"].ToString();
            DropDownList ddl=(DropDownList)e.Row.Cells[r].FindControl("ddlPrefix");
            ((Label)e.Row.Cells[pk].FindControl("lblprefixID")).Text = dt.Rows[l]["PrefixID"].ToString();
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select prefix_name,prefix_id from prefix_master", con);
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                ddl.Items.Add(new ListItem(dr[0].ToString(), dr[1].ToString()));
            }
            dr.Close();
            com.Dispose();
            con.Close();
            ddl.SelectedValue = ((Label)e.Row.Cells[pk].FindControl("lblprefixID")).Text;
            ((Label)e.Row.Cells[t].FindControl("lblSlabID")).Text = dt.Rows[l]["SlabID"].ToString();
            l++;
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        //gvSlabEdit.Visible = false;
        //btnReset.Visible = false;
        //btnUpdate.Visible = false;
        Panel1.Visible = false;

        ShowAddData(flightOpenId(), 5);
        gvDisplay.Columns[6].Visible = true;
        gvSlab.Visible = true;
        Button1.Visible = true;
    }
    
    protected void Group_type()
    {    con=new SqlConnection(strCon);
        try
        {
            con.Open();
            com = new SqlCommand("select group_type from group_master where group_id="+Session["groupid"]+" ", con);
            dr = com.ExecuteReader();
            if (dr.Read())
                hdn.Value = dr[0].ToString();
            con.Close();            

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void gvDisplay_Delete(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow grow = gvDisplay.Rows[e.RowIndex];

        string Datewise_Dis_ID = ((Label)grow.FindControl("lbldiscountID")).Text;
        string Destination_ID = ((Label)grow.FindControl("lblDesCodeValue")).Text;
        string Ship_ID = ((Label)grow.FindControl("lblShipmentCode")).Text;

        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            tr = con.BeginTransaction();
            //insert into Sector_Datewise_Discount_History
            SqlConnection conn = new SqlConnection(strCon);
            conn.Open();
            SqlCommand comm = new SqlCommand("select c.Discount_details_id,h.flight_no,b.flight_date,d.slab_name,e.destination_code,Prefix_name,c.price_value,shipment_name from Sector_Datewise_Discount a inner join flight_open b on b.flight_open_id=a.flight_open_id inner join Sector_Datewise_Discount_details c on c.Datewise_discount_id=a.Datewise_discount_id inner join slab_master d on d.slab_id=c.slab_id inner join destination_master e on e.destination_id=c.destination_id inner join Prefix_Master f on f.prefix_id=c.prefix_id inner join shipment_master g on g.shipment_id=c.shipment_id inner join flight_master h on h.flight_id=a.flight_id where a.Datewise_discount_id=" + Datewise_Dis_ID + "", conn);

            SqlDataReader sdr = comm.ExecuteReader();
            while (sdr.Read())
            {
                com = new SqlCommand("insert into Sector_Datewise_Discount_History(Discount_Details_ID,Flight_No,Flight_Date,Slab_Name,Destination_Code,Prefix_Name,Price_Value,Shipment_Name ) values(@Discount_Details_ID,@Flight_No,@Flight_Date,@Slab_Name,@Destination_Code,@Prefix_Name,@Price_Value,@Shipment_Name )", con, tr);
                com.Parameters.AddWithValue("@Discount_Details_ID", sdr["Discount_details_id"].ToString());
                com.Parameters.AddWithValue("@Flight_No", sdr["flight_no"].ToString());
                com.Parameters.AddWithValue("@Flight_Date", sdr["flight_date"].ToString());
                com.Parameters.AddWithValue("@Slab_Name", sdr["slab_name"].ToString());
                com.Parameters.AddWithValue("@Destination_Code", sdr["destination_code"].ToString());
                com.Parameters.AddWithValue("@Prefix_Name", sdr["Prefix_name"].ToString());
                com.Parameters.AddWithValue("@Price_Value", sdr["price_value"].ToString());
                com.Parameters.AddWithValue("@Shipment_Name", sdr["shipment_name"].ToString());
                com.ExecuteNonQuery();
            }
            com.Dispose();

            comm.Dispose();
            sdr.Dispose();

            com = new SqlCommand("delete  from Sector_Datewise_Discount_Details where datewise_discount_id=" + Datewise_Dis_ID + " and Shipment_ID=" + Ship_ID + " and Destination_ID=" + Destination_ID + " ", con, tr);

            com.ExecuteNonQuery();
            com.Dispose();
            tr.Commit();

            comm = new SqlCommand("select datewise_discount_id from Sector_Datewise_Discount_Details where datewise_discount_id=" + Datewise_Dis_ID + "", conn);
            sdr = comm.ExecuteReader();
            if (sdr.Read())
            {
                //tr.Commit();
                comm.Dispose();
                sdr.Dispose();
                conn.Close();

            }
            else
            {

                com = new SqlCommand("delete from Sector_Datewise_Discount where datewise_discount_id=" + Datewise_Dis_ID + "",con,tr);
                com.ExecuteNonQuery();
                // tr.Commit();
               // con.Close();
            }
           
            con.Close();
            ShowAddData(flightOpenId(), 5);
        }
        catch (SqlException se)
        {
            string err = se.Message;
            tr.Rollback();
        }
        catch (Exception be)
        {
            string err = be.Message;
            tr.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }

    //protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {
    //        // reference the Delete LinkButton
    //        LinkButton db = (LinkButton)e.Row.Cells[0].Controls[0];

    //        // Get information about the product bound to the row
    //        Northwind.ProductsRow product =
    //            (Northwind.ProductsRow)((System.Data.DataRowView)e.Row.DataItem).Row;

    //        db.OnClientClick = string.Format(
    //            "return confirm('Are you certain you want to delete the {0} product?');",
    //            product.ProductName.Replace("'", @"\'"));
    //    }
    //}

    protected string RemoveDup(string strDes)
    {
        string MsgDest = null;
        string[] Dest = strDes.Split();
        for (int s = 0; s <= Dest.Length; s++)
        {
            for (int k = 1; k <= Dest.Length - 1; k++)
            {
                if (Dest[s] == Dest[k])
                    Dest[k].Remove(k);
                MsgDest = MsgDest + Dest[s];
            }
        }
        return MsgDest;

    }
    protected void gvDisplay_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
