using System;
using System.Data;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AddTkSurvey : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  //connection string
    string sno = "";
    SqlConnection con;

    public string strLen = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        show();
    }
    public void show()
    {
        string search = null;
        con = new SqlConnection(strCon);
        if (txtsearch.Text == "")
            search = "select sno, Agentname,Position,city,Name from tksurvey ";
        else
        {
            search = "select  sno, Agentname,Position,city,Name from tksurvey where AgentName like '" + txtsearch.Text + "'+ '%' ";
        }
        con.Open();
        SqlDataAdapter sda = new SqlDataAdapter(search, con);
        DataSet ds = new DataSet();

        sda.Fill(ds);
        
        GridView1.DataSource = ds;
        GridView1.DataBind();
        con.Close();

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        show();
    }
    protected void lnkadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("TkSurvey.aspx");
    }
    protected void View(object sender, CommandEventArgs e)
    {
        Response.Redirect("TkSurveyView.aspx?sno=" + e.CommandName);

    }
    protected void View1(object sender, CommandEventArgs e)
    {
        //Response.Redirect("TkSurveyView.aspx?sno=" + e.CommandName);

    }
    protected void btnSearch_Click1(object sender, EventArgs e)
    {
        show();
    }
    protected void lblShowdata_Click(object sender, EventArgs e)
    {
        Response.Redirect("TKSurveyDetails.aspx"); 
    }
}
