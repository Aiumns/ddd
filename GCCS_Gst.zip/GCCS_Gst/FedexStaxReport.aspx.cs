﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class FedexStaxReport : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {
            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            hdnDate.Value = first.ToString();
            DateTime DTM;
            DTM = DateTime.Now.AddMonths(-1);
            Page.Form.Target = "_blank";
            txtValidFrom.Text = "01/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            ShowAirline();
            Btnload.Attributes.Add("onclick", "return CheckEmpty()");
        }
        
    }

    protected void Btnload_Click(object sender, EventArgs e)
    {

        Session["AirlineName"] = ddlAirLine.SelectedItem.Text;
        string url = "Reports/FedexStaxReport_Show.aspx?from=" + txtValidFrom.Text + "&to=" + txtValidTo.Text + "&Airline_Detail_ID=" + ddlAirLine.SelectedValue; 
        Response.Redirect(url);
        //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");
    }
    protected void ShowAirline()
    {
        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") and a.Airline_Code='023'  order by Airline_Name", con);
            dr = cmd.ExecuteReader();
            ddlAirLine.Items.Add("Select airline name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            cmd.Dispose();
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
