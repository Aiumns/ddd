using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Booking_Dimensions_History : System.Web.UI.Page
{  
    //This form is created by praveen singh
    SqlConnection cn=new SqlConnection(ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString);
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                try
                {
                    DataSet ds = new DataSet();
                    cmd = new SqlCommand("Select * from Booking_Dimensions_History", cn);
                    adp = new SqlDataAdapter(cmd);
                    adp.Fill(ds);
                    ViewState["ds"] = ds;
                    grd.DataSource = ds;
                    grd.DataBind();
                    cn.Close();
                    cmd.Dispose();
                }
                catch (Exception)
                {

                }
                finally
                {
                    if (cn != null && cn.State == ConnectionState.Open)
                        cn.Close();
                }
            }
        }

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        search();

    }
    public void search()
    {
        try
        {
            DataSet ds = new DataSet();
            if (txtAWBNo.Text == "")
            {
                cmd = new SqlCommand("Select * from Booking_Dimensions_History", cn);
            }
            else
            {
                cmd = new SqlCommand("Select * from Booking_Dimensions_History where AirWayBill_No like'" + txtAWBNo.Text + "%'", cn);
            }
            adp = new SqlDataAdapter(cmd);
            adp.Fill(ds);
            ViewState["ds"] = ds;
            grd.DataSource = ds;
            grd.DataBind();
            cn.Close();
            cmd.Dispose();
        }
        catch (Exception)
        {

        }
        finally
        {
            if (cn != null && cn.State == ConnectionState.Open)
                cn.Close();

        }
    }


    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd.PageIndex = e.NewPageIndex;
        search();
    }
}
