using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CPP_Management : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    sms SMS = null;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            SendSms();
        }
    }


    public void SendSms()
    {
   
        DataTable dt_SMS = dw.GetAllFromQuery("select * from CPP_SMS where status=2");
        string First_day = DateTime.Now.ToString("MM/01/yyyy");
        foreach (DataRow drow in dt_SMS.Rows)
        {
            string Msg = "";
            //DataTable dt_total = dw.GetAllFromQuery("select substring(convert(varchar,getdate(),106),0,8) as cppdate,sum(totalcpp) as totalcpp,sum(redeemedCPP) as  redeemedCPP ,sum(AvailableCPP) as AvailableCPP from CPP_AgentWiseTotal");
            DataTable dt_total = dw.GetAllFromQuery("select substring(convert(varchar,getdate(),106),0,8) as cppdate,sum(totalcpp) as totalcpp,sum(redeemedCPP) as  redeemedCPP ,sum(totalcpp-redeemedCPP) as AvailableCPP from CPP_AgentWiseTotal");
            Msg ="CPP as on "+ DateTime.Today.ToString("MMM-dd")+": TOTAL:" +  Math.Round(Convert.ToDecimal(dt_total.Rows[0]["totalcpp"].ToString()),MidpointRounding.AwayFromZero) + ", REDEEMED:" + Math.Round(Convert.ToDecimal(dt_total.Rows[0]["redeemedCPP"].ToString()),MidpointRounding.AwayFromZero) + ", LIABILITY:" + Math.Round(Convert.ToDecimal(dt_total.Rows[0]["AvailableCPP"].ToString()), MidpointRounding.AwayFromZero) + "";

            string Mobile_number = drow["CellNo"].ToString().Trim();
            SMS = new sms();
            if (Msg.Length > 0)
            {
                SMS.SendSMS(Mobile_number, Msg);
            }

            }

    }

}
