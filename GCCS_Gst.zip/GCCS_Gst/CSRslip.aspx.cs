using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CSRslip : System.Web.UI.Page
{
    // DESIGNED BY Shaikh Akhtar Rasool on 20 - January -2008
    //CREATED BY - MEGHA
    //STARTED ON - [21 JANUARY 2008 03:35]
    //THIS PAGE CONTAINS PAYMENT RECEIPT

    //GLOBAL VARIABLES
    SqlConnection con;
    SqlCommand com;
    
    NumberToEnglish Num = new NumberToEnglish();
    string Payment_Detail_ID;
  
    //CONNECTION STRING
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            Payment_Detail_ID = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "P_ID");
            LoadData();

        }
    }

    public void LoadData()
    {
        try
        {
            string strAgent = "SELECT Company_Name,Company_Address,Agent_Name,Paid_Amount,Cheque_No,convert(varchar,Cheque_Date,103),CONVERT(VARCHAR,Cheque_Deposit_Date,103) AS Cheque_Deposit_Date,Bank,Account_Name,reverse(substring(reverse(CSR_No),1,17)) as CSR_No FROM Payment_Details A INNER JOIN Airline_Detail B ON A.Airline_Detail_ID=B.Airline_Detail_ID INNER JOIN Company_Master C ON B.Company_ID=C.Company_ID WHERE A.Payment_Detail_ID='" + Payment_Detail_ID + "'";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read())
            {
                string csr_d = dr["CSR_No"].ToString();
                string[] arr_csr = csr_d.Split('-');
                string First_Fort = arr_csr[0];
                string Sec_Fort = arr_csr[1];
                string[] Arr_First_Fort = First_Fort.Split('/');
                string MM = Arr_First_Fort[0];
                string DD = Arr_First_Fort[1];
                string yy = Arr_First_Fort[2];
                string DDMMYYYY = DD + "/" + MM + "/" + yy;

                string[] Arr_Sec_Fort = Sec_Fort.Split('/');
                string strMM = Arr_Sec_Fort[0];
                string strDD = Arr_Sec_Fort[1];
                string stryy = Arr_Sec_Fort[2];
                string strDDMMYYYY = strDD + "/" + strMM + "/" + stryy;

                string Final_CSR_Duration = DDMMYYYY + "-" + strDDMMYYYY;

                lblcompany.Text = dr["Company_Name"].ToString();
                lblAddress.Text = dr["Company_Address"].ToString();
                lblAgent.Text = dr["Agent_Name"].ToString();
                double Amount = double.Parse(dr["Paid_Amount"].ToString());
                string Num_ToWord = Num.changeNumericToWords(Amount);
                lblrupees.Text = Num_ToWord;
                lblChequeno.Text = dr["Cheque_No"].ToString();
                lblaccount.Text = Final_CSR_Duration;
                lblbank.Text = dr["Bank"].ToString();
                lbldate.Text = dr["Cheque_Deposit_Date"].ToString();
                lblfor.Text = dr["Company_Name"].ToString();
                lblrs.Text = dr["Paid_Amount"].ToString();
            }
            dr.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
