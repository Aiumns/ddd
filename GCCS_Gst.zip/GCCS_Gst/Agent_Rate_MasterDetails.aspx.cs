using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// CREATED BY AMIT TONK - 30-OCT
/// </summary>
/// <modified by>Shaikh Akhtar Rasool </modified>
/// <modifiedon>23-01-2008</modifiedon>
///  <modified by>Shaikh Akhtar Rasool </modified>
/// <modifiedon>08-02-2008</modifiedon>
/// //last modify by hn mishra.
/// 
public partial class Agent_Rate_MasterDetails : System.Web.UI.Page
{
    int flag = 0;
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    //int searchName;

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                AirlineNamePlusCode();
                getAgentRateDetails();
                hideForAgent();
                
            }
        }
    }

    public void getAgentRateDetails()
    {
        Label2.Text = ddlAirline.SelectedItem.Text;
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            string searchName = ddlAirline.SelectedValue;
            if (searchName != "")
            {
                string strProcedure = "uspGetAgentRateDetails";
                DataSet dsAgentRate = new DataSet();
                SqlDataAdapter daAgentRate = new SqlDataAdapter(strProcedure, con);
                daAgentRate.SelectCommand.CommandType = CommandType.StoredProcedure;

                SqlParameter sqlparamSearchName = new SqlParameter("@iAirline_Detailed_Id", searchName);
                sqlparamSearchName.Direction = ParameterDirection.Input;
                sqlparamSearchName.SqlDbType = SqlDbType.Int;

                daAgentRate.SelectCommand.Parameters.Add(sqlparamSearchName);

                daAgentRate.Fill(dsAgentRate);

                if (dsAgentRate.Tables[0].Rows.Count > 0)
                {
                    lblGridMsg.Visible = false;
                    pnlAgentRate.Visible = true;
                    grdAgentRate.DataSource = dsAgentRate;
                    grdAgentRate.DataBind();
                }
                else
                {
                    pnlAgentRate.Visible = false;
                    lblGridMsg.Visible = true;
                    lblGridMsg.Text = "No Data Available... !";
                }
            }
            else
            {
                pnlAgentRate.Visible = false;
                lblGridMsg.Visible = true;
                lblGridMsg.Text = "No Data Available... !";
            }
            con.Close();
            //if (dsAgentRate.Tables[0].Rows.Count > 10)
            //{
            //    grdAgentRate.AllowPaging = true;

            //}
            //else
            //{
            //    grdAgentRate.AllowPaging = false;
            //}
        }
        catch (SqlException sqe)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

    public void AirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            strQuery = "Select Airline_Detail_ID,Airline_ID,Belongs_To_City from Airline_Detail where Airline_detail_id in (" + Session["AIRLINEACCESS"].ToString() + ")";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            //ddlAirline.Items.Insert(0, "- - Select - -");
            //ddlAirline.Items[0].Value = "0";
            while (dr.Read())
            {
                DataTable dtAirlineName = dw.GetAllFromQuery(" select Airline_Name from Airline_Master where Airline_ID=" + dr["Airline_ID"].ToString());
                DataTable dtCity = dw.GetAllFromQuery("select City_Name from City_Master where City_ID=" + dr["Belongs_To_City"].ToString());
                ddlAirline.Items.Add(new ListItem(dtAirlineName.Rows[0]["Airline_Name"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void Modify(object sender, CommandEventArgs e)
    {
        
        Response.Redirect("AgentRate.aspx?Agent_Rate_ID=" + e.CommandName);
    }

    protected void lnkAddNewRate_Click(object sender, EventArgs e)
    {
        Response.Redirect("agentrate.aspx");
    }
    protected void grdAgentRate_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdAgentRate.PageIndex = e.NewPageIndex;
        getAgentRateDetails();
        hideForAgent();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        getAgentRateDetails();
        hideForAgent();
    }
    public void Getslabs()
    {
    }
    // Create By Shaikh Akhtar Rasool To Display Slabs in The Grid.


    protected void grdAgentRate_RowDataBound(object sender,
                    GridViewRowEventArgs e)
    {
        //check the item being bound is actually a DataRow, if it is, 
        //wire up the required html events and attach the relevant JavaScripts

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            GridViewRow GDrow = e.Row;
            Label lblAccess = (Label)e.Row.Cells[2].FindControl("Label1");
            //Label lable = (Label)GDrow.FindControl("Label1");  
            Int64  RateID = Convert.ToInt64 (lblAccess.Text);
            DataTable DtSlab = dw.GetAllFromQuery("select Slab_name as SlabName,Price_value as Price from Agent_Slab_Rate inner join slab_master on Agent_Slab_Rate.Slab_ID=slab_master.Slab_ID where agent_rate_id=" + RateID + "");
            string tooltip = "";
            string table = "<table >";
            table += "<tr>";
            foreach (DataRow Drow in DtSlab.Rows)
            {
                tooltip += "" + Drow["SlabName"] + " : " + Drow["Price"] + "\n";
                table += "<td><table><tr><td class=boldtext>" + Drow["SlabName"] + "</td></tr><tr><td class=text>" + Drow["Price"] + "</td></tr></table></td>";

            }
            table += "</tr>";
            table += "</table>";
            //tooltip +="</table>";
            //if (flag >= 2)
            //{
            GDrow.Cells[3].Text = table;
            table = "";
            GDrow.Cells[0].ToolTip = tooltip ;
            GDrow.Cells[0].ToolTip.ToUpper();
            
            //GDrow.Cells[2].ToolTip = "Click here to See Slab Rates";
            //GDrow.ToolTip = "Click On Show Slab to See Slab Rates";  
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    e.Row.Attributes["onmouseover"] =
            //        "javascript:setMouseOverColor(this);";
            //    e.Row.Attributes["onmouseout"] =
            //        "javascript:setMouseOutColor(this);";
            //    e.Row.Attributes["onclick"] =
            //    ClientScript.GetPostBackClientHyperlink
            //        (this.grdAgentRate, "Select$" + e.Row.RowIndex);
            //}
        }
    }



    protected void grdAgentRate_SelectedIndexChanged(object sender, EventArgs e)
    {
        long RateID = Convert.ToInt64(grdAgentRate.SelectedDataKey.Value);
        DataTable DtSlab = dw.GetAllFromQuery("select Slab_name as SlabName,Price_value as Price from Agent_Slab_Rate inner join slab_master on Agent_Slab_Rate.Slab_ID=slab_master.Slab_ID where agent_rate_id=" + RateID + "");


        //for (int i = 0; i < grdAgentRate.Rows.Count; ++i)
        //{
        //    grdAgentRate.Rows[i].FindControl("grdslab").Visible = false; 

        //}

        GridView GVSlab = (GridView)grdAgentRate.SelectedRow.FindControl("grdslab");
        //GVSlab.Visible = true;
        GVSlab.DataSource = DtSlab;
        GVSlab.DataBind();
    }
    protected void ddlAirline_SelectedIndexChanged(object sender, EventArgs e)
    {
           
    }
    protected void hideForAgent()
    {
        if (Session["groupid"].ToString() == "5")
        {
            lnkAddNewRate.Visible = false;
            grdAgentRate.Columns[13].Visible = false;
            grdAgentRate.Columns[14].Visible = false;
        }
        else
        {
            lnkAddNewRate.Visible = true;
            grdAgentRate.Columns[13].Visible = true;
            grdAgentRate.Columns[14].Visible = true;
        }
    }
}

