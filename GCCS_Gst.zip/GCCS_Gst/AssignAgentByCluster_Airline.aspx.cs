﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class AssignAgentByCluster_Airline : System.Web.UI.Page
{
    //string Agent = "";
    string ClusterID = "";
    int Sid;
    //string CityDest = "";
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        btnsubmit.Attributes.Add("onclick", "return checkgridcontrols();return false;");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                FillCluster();
                txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
                btnsubmit.Visible = false;
                btnCancel.Visible = false;
                // ddlCluster.SelectedIndex = 0;
                ////}
            }
        }
    }
    protected void FillCluster()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("DECLARE @clusterid VARCHAR(50) SET @clusterid =(select Cluster_ID FROM dbo.Login_Master WHERE Email_ID ='" + Session["EMailID"] + "') SELECT Cluster_id,Cluster_Name FROM db_owner.Cluster_master WHERE Cluster_id IN ( SELECT value FROM String_to_Int(@clusterid))", con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlCluster.Items.Clear();
            ddlCluster.Items.Insert(0, "- -Select- -");
            ddlCluster.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlCluster.Items.Add(new ListItem(dr["Cluster_Name"].ToString(), dr["Cluster_id"].ToString()));
            }
            con.Close();
            // ddlCluster.SelectedValue = "0";
        }
        catch
        {
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void ddlCluster_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridView1.Visible = true;
        //lblmessage.Visible = false;
        ClusterID = ddlCluster.SelectedValue;
        btnCancel.Visible = true;
        con = new SqlConnection(strCon);
        con.Open();
        // string StrAgent = "SELECT am.agent_id,ab.agent_address,am.agent_name,ab.agent_branch_id,ab.Belongs_To_City FROM dbo.Login_Master lm INNER JOIN db_owner.Agent_Branch ab  ON lm.Agent_ID = ab.Agent_Branch_ID INNER JOIN dbo.Agent_Master am ON ab.Agent_ID = am.Agent_ID INNER JOIN db_owner.Cluster_master cm  ON ab.Belongs_To_City =cm.Cluster_City WHERE cm.Cluster_id=" + ClusterID + "";
        cmd = new SqlCommand("GetAgentList_Cluster", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Cluster_id", SqlDbType.Int).Value = Convert.ToInt32(ClusterID);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
        sda.Dispose();
        con.Close();
        foreach (GridViewRow gv in GridView1.Rows)
        {
            DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");
            ListBox lslAirlineDetail = (ListBox)gv.FindControl("lslAirlineDetail");
            //string strSalesPerson = "SELECT lm.User_ID,um.Full_Name  FROM dbo.Login_Master lm INNER JOIN dbo.User_Master um ON lm.User_ID=um.UserID WHERE lm.Cluster_ID=" + ClusterID + "";
            //   string strSalesPerson = "SELECT lm.User_ID,um.Full_Name  FROM dbo.Login_Master lm INNER JOIN dbo.User_Master um ON lm.User_ID=um.UserID WHERE ','+lm.Cluster_ID+',' LIKE ('%" + ddlCluster.SelectedValue + "%')";
            SqlCommand cmdiner = new SqlCommand("GetAirline_SalesPerson", con);
            cmdiner.CommandType = CommandType.StoredProcedure;
            cmdiner.Parameters.AddWithValue("@Email_ID", Session["EMailID"].ToString());
            cmdiner.Parameters.AddWithValue("@Cluster_ID", Convert.ToInt32(ddlCluster.SelectedValue));
            SqlDataAdapter SdaAirline_Sales = new SqlDataAdapter(cmdiner);
            DataSet ds = new DataSet();
            SdaAirline_Sales.Fill(ds);
            ddlSalesPerson.Items.Clear();
            ddlSalesPerson.Items.Insert(0, "- -Select- -");
            ddlSalesPerson.Items[0].Value = "0";
            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ddlSalesPerson.Items.Add(new ListItem(ds.Tables[0].Rows[i]["Full_Name"].ToString(), ds.Tables[0].Rows[i]["User_ID"].ToString()));
                }
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                {
                    lslAirlineDetail.Items.Add(new ListItem(ds.Tables[1].Rows[i]["AIrline_Name"].ToString(), ds.Tables[1].Rows[i]["Airline_Detail_ID"].ToString()));
                }
            }
            //SqlDataReader dr;
            //dr = cmdiner.ExecuteReader();
            //while (dr.Read())
            //{
            //    ddlSalesPerson.Items.Add(new ListItem(dr["Full_Name"].ToString(), dr["User_ID"].ToString()));
            //}
            Label lblAID = (Label)gv.FindControl("lblAgentID");
            int agentid = Convert.ToInt32(lblAID.Text);
            string strbind = "select sales_person_id,airline_detail_id from AgentToSalesPerson_ClusterAirlineWise where agent_id=" + agentid + " and Cluster_Id=" + ClusterID + "";
            SqlDataAdapter sdb = new SqlDataAdapter(strbind, con);
            DataTable dt2 = new DataTable();
            sdb.Fill(dt2);
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            if (dt2.Rows.Count > 0)
            {
                ChkBxItem.Checked = true;
                ddlSalesPerson.SelectedValue = dt2.Rows[0]["sales_person_id"].ToString();
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    for (int k = 0; k < lslAirlineDetail.Items.Count; k++)
                    {
                        if (lslAirlineDetail.Items[k].Value == dt2.Rows[i]["airline_detail_id"].ToString())
                        {
                            lslAirlineDetail.Items[k].Selected = true;
                        }
                    }
                    //  lslAirlineDetail.SelectedValue = dt2.Rows[i]["airline_detail_id"].ToString();
                }
            }
            ChkBxItem.Attributes.Add("onclick", " resetdropdownlist();");
        }
        btnsubmit.Visible = true;
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction Tran = con.BeginTransaction();
        try
        {
            foreach (GridViewRow gv in GridView1.Rows)
            {
                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");
                ListBox lslAirlineDetail = (ListBox)gv.FindControl("lslAirlineDetail");
                Sid = Convert.ToInt32(ddlSalesPerson.SelectedValue);
                Label lblAID = (Label)gv.FindControl("lblAgentID");
                int agentid = Convert.ToInt32(lblAID.Text);
                int i = check(agentid, Tran);
                //if (con.State == ConnectionState.Closed)
                //{
                //    con.Open();                
                //}
                if (i == 0)
                {
                    if (ChkBxItem.Checked)
                    {
                        //**** Insert Into AgentToSalesPersonCluster ****///
                        string insertQ = "";
                        DateTime effected = Convert.ToDateTime(FormatDateMM(txtValidFrom.Text));
                        for (int j = 0; j < lslAirlineDetail.Items.Count; j++)
                        {
                            if (lslAirlineDetail.Items[j].Selected == true)
                            {
                                //insertQ = "insert into AgentToSalesPerson_Cluster(Sales_Person_Id,Agent_Id,Cluster_Id,Entered_By,Entered_On)values(@Sales_Person_Id,@Agent_Id,@Cluster_Id,@Entered_By,@Entered_On)";
                                cmd = new SqlCommand("Insert_Salesperson_ClusterAirline", con, Tran);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@Sales_Person_Id", Sid);
                                cmd.Parameters.AddWithValue("@Agent_Id", int.Parse(lblAID.Text));
                                cmd.Parameters.AddWithValue("@Cluster_Id", int.Parse(ddlCluster.SelectedItem.Value));
                                cmd.Parameters.AddWithValue("@Airline_Detail_ID", lslAirlineDetail.Items[j].Value);
                                cmd.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());
                                cmd.ExecuteNonQuery();
                            }
                        }
                   }
                }
                else
                {
                    //////// For update and delete/////////
                    if (ChkBxItem.Checked)
                    {
                        ////// update the data BY CALLING PROCEDURE UPDATETO SALES ////////
                        ///// /UPDATE AGENTTOSALESPERSONCLuster AND SEND THE PREVIOUS DATA TO AGENTTOSALESPERSONCluster_HISTOEY/////////////////////
                        DateTime effected = Convert.ToDateTime(FormatDateMM(txtValidFrom.Text));
                        InsertToHistory(Tran, agentid);
                        for (int j = 0; j < lslAirlineDetail.Items.Count; j++)
                        {
                            if (lslAirlineDetail.Items[j].Selected == true)
                            {
                                cmd = new SqlCommand("Update_Salesperson_ClusterAirline", con, Tran);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@Sales_Person_Id", Sid);
                                cmd.Parameters.AddWithValue("@Agent_Id", int.Parse(lblAID.Text));
                                cmd.Parameters.AddWithValue("@Cluster_Id", int.Parse(ddlCluster.SelectedItem.Value));
                                cmd.Parameters.AddWithValue("@Airline_Detail_ID", lslAirlineDetail.Items[j].Value);
                                cmd.Parameters.AddWithValue("@Entered_By", Session["EMailID"].ToString());
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    else
                    {
                        ////  delete the data from AgentToSalesCluster//////
                        //call procedure DeleteAgentToSalesCluster
                        InsertToHistory(Tran, agentid);
                    }
                }
            }
            Tran.Commit();
            con.Close();
        }
        catch (Exception ex)
        {
            Tran.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        string strScript = "alert('Saved Successfully.');location.replace('AssignAgentByCluster_Airline.aspx');";
        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
    }
    public int check(int aid, SqlTransaction tr)
    {
        // con = new SqlConnection(strCon);
        string strcmdcheck = "select sales_person_id from AgentToSalesPerson_ClusterAirlineWise where Agent_Id=" + aid + " and Cluster_Id=" + ddlCluster.SelectedValue + "";
        cmd = new SqlCommand(strcmdcheck, con, tr);
        object i = cmd.ExecuteScalar();
        if (Convert.ToInt32(i) > 0)
            return 1;
        else
            return 0;
        //SqlDataAdapter sdac = new SqlDataAdapter(strcmdcheck, con);
        //DataTable dtc = new DataTable();
        //sdac.Fill(dtc);
        //if (dtc.Rows.Count > 0)
        //{
        //    Session["Ssid"] = dtc.Rows[0]["sales_person_id"].ToString();

        //    return 1;

        //}
        //else
        //{

        //    return 0;

        //}
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AssignAgentByCluster_Airline.aspx");
    }
    protected void InsertToHistory(SqlTransaction tr, int Agent_id)
    {
        SqlCommand cmd = new SqlCommand("Insert_AssignSales_AirlineWiseHistory", con, tr);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@agent_id", Agent_id);
        cmd.Parameters.AddWithValue("@Cluster_Id", int.Parse(ddlCluster.SelectedItem.Value));
        cmd.Parameters.AddWithValue("@Last_Updated_By", Session["EMailID"].ToString());
        cmd.Parameters.AddWithValue("@Effective_To", FormatDateMM(txtValidFrom.Text));
        cmd.ExecuteNonQuery();
    }
}
