using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;
using System.Globalization;


public partial class cpp_upload : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        getdata();
    }
    public void getdata()
    {
        string sql = "Select a.image_content,a.Img_id,a.image_type,a.image_size,a.cpp_required,case when a.model_no!='' then 'Model No- '+a.model_no end as model_no  from tbimage a inner join ImageGallery b on a.category=b.category  where  (a.cpp_required between " + Request.QueryString["start"].ToString() + " and " + Request.QueryString["end"].ToString() + ") or (a.category='Gift' and b.active='Y') order by a.cpp_required asc";
        SqlConnection con = new SqlConnection(strCon);
        SqlDataAdapter da = new SqlDataAdapter(sql, con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        DataList1.DataSource = ds;
        DataList1.DataBind();

    }
}
