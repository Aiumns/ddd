using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


//This Page is Design & Coding By Alok Date:18.11.2007
public partial class HandOver_Dimension_History : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Search();
        }

    }
    // function for bind grid
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txtsearch.Text == "")
            {
                selectQ = "select Handover_Dimension_History_ID,AirWayBill_No,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit from Handover_Dimensions_History order by AirWayBill_No";
            }

            else
            {
                selectQ = "select Handover_Dimension_History_ID,AirWayBill_No,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit from Handover_Dimensions_History where AirWayBill_No like '" + txtsearch.Text + "%' order by AirWayBill_No";
            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdHdDimension.DataSource = dt;
            grdHdDimension.DataBind();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void grdHdDimension_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdHdDimension.PageIndex = e.NewPageIndex;
        Search();
    }
}
