using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//hirdayanand mishra last md. on 05/05/08

public partial class CSRSummary : System.Web.UI.Page
{
    string CompGstNo = "07";
    string AgentGstNo = "08";
    string table = "", page_pop="";
    string pageHead="";
    string airlineId=null;
    string bID = null;
    decimal GtchrWt = 0;
    decimal GtamountPP = 0;
    decimal GtamountCC = 0;
    decimal GtDueCarr = 0;
    decimal GtagentExp = 0;
    decimal Gtcomm = 0;
    decimal Gtincentive = 0;
    decimal GtspotDiff = 0;
    decimal GtfrtDiff = 0;

    decimal GTotalCGST = 0;
    decimal GTotalSGST = 0;
    decimal GTotalIGST = 0;
    decimal GTotalGst = 0;

    decimal MHGtincentive = 0;
    decimal MHGtspotDiff = 0;
    decimal MHGtfrtDiff = 0;
    decimal GtGrandTotal = 0;
    decimal GtxrayCh = 0;
    decimal GrandTotal = 0;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
             Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
                hdnDate.Value = first.ToString();
                btnGenerate.Attributes.Add("onclick", "return CheckEmpty();");
                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 1;
                ddlMonth.Items[dt - 1].Selected = true;
                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                 ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();
                //int yy = System.DateTime.Now.Year;
                //int s = ddlyear.Items.IndexOf(ddlyear.Items.FindByValue(yy.ToString()));
                //ddlyear.Items[s].Selected = true;
                ShowAirline();               

            }

        }


    }

    protected void ShowAirline()
    {

        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            dr = com.ExecuteReader();
            ddlAirLine.Items.Add("Select airline name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            com.Dispose();
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ddlAirLine.SelectedValue.Trim() != "158" && ddlAirLine.SelectedValue.Trim() != "159" && ddlAirLine.SelectedValue.Trim() != "160")
        {
            #region Summary
            string DateWise = "flight_date";
            string comAdd = null, comName = null;
            string[] airlineName = ddlAirLine.SelectedItem.Text.Split('-');
            string airline = "A/C " + airlineName[0].ToUpper().ToString();
            string ss = "";



            if (ddlAirLine.SelectedValue.Trim() == "150" || ddlAirLine.SelectedValue.Trim() == "153")
            {
                DateWise = "awb_date";
            }


            TextBox TextBox1 = new TextBox();
            TextBox TextBox2 = new TextBox();
            TextBox TextBox3 = new TextBox();

            //string strY = DateTime.Today.Year.ToString();
            string strY = ddlyear.SelectedItem.Text.Trim();

            if (rbtnFirstFortn.Checked == true)
            {
                if (ddlMonth.SelectedItem.Text.Trim() == "January")
                {
                    TextBox1.Text = "01/01/" + strY;
                    TextBox2.Text = "01/15/" + strY;
                    TextBox3.Text = "01/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "February")
                {
                    TextBox1.Text = "02/01/" + strY;
                    TextBox2.Text = "02/15/" + strY;
                    TextBox3.Text = "02/16/" + strY;
                }
                if (ddlMonth.SelectedItem.Text.Trim() == "March")
                {
                    TextBox1.Text = "03/01/" + strY;
                    TextBox2.Text = "03/15/" + strY;
                    TextBox3.Text = "03/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "April")
                {
                    TextBox1.Text = "04/01/" + strY;
                    TextBox2.Text = "04/15/" + strY;
                    TextBox3.Text = "04/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text == "May")
                {
                    TextBox1.Text = "05/01/" + strY;
                    TextBox2.Text = "05/15/" + strY;
                    TextBox3.Text = "05/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "June")
                {
                    TextBox1.Text = "06/01/" + strY;
                    TextBox2.Text = "06/15/" + strY;
                    TextBox3.Text = "06/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "July")
                {
                    TextBox1.Text = "07/01/" + strY;
                    TextBox2.Text = "07/15/" + strY;
                    TextBox3.Text = "07/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "August")
                {
                    TextBox1.Text = "08/01/" + strY;
                    TextBox2.Text = "08/15/" + strY;
                    TextBox3.Text = "08/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "September")
                {
                    TextBox1.Text = "09/01/" + strY;
                    TextBox2.Text = "09/15/" + strY;
                    TextBox3.Text = "09/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "October")
                {
                    TextBox1.Text = "10/01/" + strY;
                    TextBox2.Text = "10/15/" + strY;
                    TextBox3.Text = "10/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "November")
                {
                    TextBox1.Text = "11/01/" + strY;
                    TextBox2.Text = "11/15/" + strY;
                    TextBox3.Text = "11/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "December")
                {
                    TextBox1.Text = "12/01/" + strY;
                    TextBox2.Text = "12/15/" + strY;
                    TextBox3.Text = "12/16/" + strY;
                }
            }

            else if (rbtnSecondFortN.Checked == true)
            {
                if (ddlMonth.SelectedItem.Text.Trim() == "January")
                {
                    TextBox1.Text = "01/16/" + strY;
                    TextBox2.Text = "01/31/" + strY;
                    TextBox3.Text = "02/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "February")
                {
                    TextBox1.Text = "02/16/" + strY;
                    if (DateTime.IsLeapYear(int.Parse(strY)))
                        TextBox2.Text = "02/29/" + strY;
                    else
                    { TextBox2.Text = "02/28/" + strY; }

                    TextBox3.Text = "03/01/" + strY;

                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "March")
                {
                    TextBox1.Text = "03/16/" + strY;
                    TextBox2.Text = "03/31/" + strY;
                    TextBox3.Text = "04/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "April")
                {
                    TextBox1.Text = "04/16/" + strY;
                    TextBox2.Text = "04/30/" + strY;
                    TextBox3.Text = "05/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "May")
                {
                    TextBox1.Text = "05/16/" + strY;
                    TextBox2.Text = "05/31/" + strY;
                    TextBox3.Text = "06/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "June")
                {
                    TextBox1.Text = "06/16/" + strY;
                    TextBox2.Text = "06/30/" + strY;
                    TextBox3.Text = "07/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "July")
                {
                    TextBox1.Text = "07/16/" + strY;
                    TextBox2.Text = "07/31/" + strY;
                    TextBox3.Text = "08/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "August")
                {
                    TextBox1.Text = "08/16/" + strY;
                    TextBox2.Text = "08/31/" + strY;
                    TextBox3.Text = "09/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "September")
                {
                    TextBox1.Text = "09/16/" + strY;
                    TextBox2.Text = "09/30/" + strY;
                    TextBox3.Text = "10/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "October")
                {
                    TextBox1.Text = "10/16/" + strY;
                    TextBox2.Text = "10/31/" + strY;
                    TextBox3.Text = "11/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "November")
                {
                    TextBox1.Text = "11/16/" + strY;
                    TextBox2.Text = "11/30/" + strY;
                    TextBox3.Text = "12/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "December")
                {
                    TextBox1.Text = "12/16/" + strY;
                    TextBox2.Text = "12/31/" + strY;
                    TextBox3.Text = "01/01/" + strY;
                }

            }

            if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
            {
                table += @"<table  border=""1"" align=""center"" class=""text""><tr class=""h5 boldtext""><th rowspan=""2"" width=""3%"">S.No</th><th rowspan=""2"" width=""25%"" >Agent</th><th rowspan=""2"">CSR NO.</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" class=""h1 boldtext"" >Commissionable</th><th rowspan=""2"">Due Carr</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"">Comm.</th><th rowspan=""2"">Incentive</th><th rowspan=""2"">Spot diff.</th><th rowspan=""2"">Frt diff.</th><th rowspan=""2"">Receivable/<font color=""red"">Payable</font></th><th rowspan=""2"" width=""8%"">X-Ray</th><th rowspan=""2"">MH Incentive</th><th rowspan=""2"">MH Spot diff.</th><th rowspan=""2""> MH Frt diff.</th></tr><tr ><th class=""h1 boldtext"">Prepaid</th><th class=""h1 boldtext"">Collect</th></tr>";
            }
            else
            {
                if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                {
                    table += @"<table  border=""1"" align=""center"" class=""text""><tr class=""h5 boldtext""><th rowspan=""2"" width=""3%"">S.No</th><th rowspan=""2"" width=""25%"" >Agent</th><th rowspan=""2"">INVOICE NO.</th><th rowspan=""2"">GST NO.</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" class=""h1 boldtext"" >Commissionable</th><th rowspan=""2"">Due Carr</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"">Discount</th><th rowspan=""2"">CGST</th><th rowspan=""2"">SGST</th><th rowspan=""2"">IGST</th><th rowspan=""2"">Total GST</th><th rowspan=""2"">Receivable/<font color=""red"">Payable</font></th><th rowspan=""2"" colspan=""6"" width=""8%"">X-Ray</th></tr><tr ><th class=""h1 boldtext"">Prepaid</th><th class=""h1 boldtext"">Collect</th></tr>";
                }
                else
                {

                    table += @"<table  border=""1"" align=""center"" class=""text""><tr class=""h5 boldtext""><th rowspan=""2"" width=""3%"">S.No</th><th rowspan=""2"" width=""25%"" >Agent</th><th rowspan=""2"">CSR NO.</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" class=""h1 boldtext"" >Commissionable</th><th rowspan=""2"">Due Carr</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"">Comm.</th><th rowspan=""2"">Incentive</th><th rowspan=""2"">Spot diff.</th><th rowspan=""2"">Frt diff.</th><th rowspan=""2"">Receivable/<font color=""red"">Payable</font></th><th rowspan=""2"" colspan=""6"" width=""8%"">X-Ray</th></tr><tr ><th class=""h1 boldtext"">Prepaid</th><th class=""h1 boldtext"">Collect</th></tr>";
                }
            }
            con = new SqlConnection(strCon);
            con.Open();
            try
            {//////
                com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                dr = com.ExecuteReader();
                if (dr.Read())
                {
                    airlineId = dr["airline_id"].ToString();
                    bID = dr["belongs_to_city"].ToString();
                }
                dr.Dispose();
                com.Dispose();
                com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ")) and city=" + bID + "", con);
                //com = new SqlCommand("select * from company_master where company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " )", con);
                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    comAdd = dr["company_address"].ToString();
                    comName = dr["company_name"].ToString();
                    string s = dr["company_address"].ToString();
                    char ch = (char)System.Windows.Forms.Keys.Return;
                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                    string ch1 = Convert.ToString(ch);
                    string ch3 = Convert.ToString(ch2);
                    string h = s.Replace(ch1, "<br>");
                    h = h.Replace(ch3, "&nbsp;");

                    pageHead += @"<p align=""center"" class=""boldtext""><font size=""2"">" + airlineName[0].ToUpper().ToString() + @"</font><br><font size=""2"">" + h + @"<br> Phone :" + dr["Phone"].ToString() + @"<br>CSR Summary Report<br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                }
                com.Dispose();
                dr.Dispose();

                //////

                com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
                dr = com.ExecuteReader();
                int sno = 1;
                while (dr.Read())
                {
                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand com1 = new SqlCommand();
                    /////// com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "  union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " ", con1);

                    com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (" + DateWise + " between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "  union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (" + DateWise + " between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " ", con1);
                    SqlDataReader dr5 = com1.ExecuteReader();
                    if (dr5.Read())
                    {
                        com1.Dispose();
                        dr5.Dispose();

                        decimal CGST = 9;
                        decimal SGST = 9;
                        decimal IGST = 18;

                        decimal TotalCGST = 9;
                        decimal TotalSGST = 9;
                        decimal TotalIGST = 18;
                        decimal TotalGst = 0;

                        ////decimal GTotalCGST = 0;
                        ////decimal GTotalSGST = 0;
                        ////decimal GTotalIGST = 0;
                        ////decimal GTotalGst = 0;

                        decimal xrayCh = 0;
                        decimal frAmount = 0;
                        decimal DueCarr = 0;
                        decimal agentExp = 0;
                        decimal comm = 0;
                        decimal incentive = 0;
                        decimal mHincentive = 0;
                        decimal spotDiff = 0;
                        decimal mHspotDiff = 0;
                        decimal frtDiff = 0;
                        decimal mHfrtDiff = 0;
                        decimal chrWt = 0;
                        decimal amountPP = 0;
                        decimal amountCC = 0;
                        decimal TotFrAmountCC = 0;
                        decimal TotFrAmount = 0;
                        decimal TotTds = 0;
                        decimal TotTax = 0, TotDiscount = 0;
                        decimal EduChrg = 0; decimal Total = 0;
                        decimal surCharge = 0;
                        string stagent = dr["agent_id"].ToString();
                        ////decimal GrandTotal = 0;
                        ////decimal GrandTotal1 = 0;
                        ////decimal GrandTotal2 = 0;
                        string csrno = "";
                        string Gstno = "";
                        decimal total_cc = 0;
                        decimal total_tds_cut = 0;

                        table += @"<tr class=""text""><td>" + sno + @"</td><td align=""left"">" + dr["agent_name"].ToString() + @"</td>";
                        //SqlConnection con1 = new SqlConnection(strCon);
                        //con1.Open();
                        if (airlineName[0].ToString().Trim() == "CHINA AIRLINESaaaa")
                        {
                            com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                        }
                        else if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                        {
                            com1 = new SqlCommand("CSR_SORT_DECCAN", con1);
                        }
                        else if (airlineName[0].ToString() == "MALAYSIAN AIRLINES")
                        {
                            if (TextBox1.Text == "04/1/2008" && TextBox2.Text == "04/15/2008")
                            {
                                com1 = new SqlCommand("CSRsort", con1);

                            }
                            else
                            {
                                com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                            }

                        }
                        else
                        {
                            if (ddlAirLine.SelectedValue.Trim() == "158" || ddlAirLine.SelectedValue.Trim() == "159" || ddlAirLine.SelectedValue.Trim() == "160")
                            {
                                if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/16/2017"))
                                {
                                    com1 = new SqlCommand("csrsort_Temp_KEIATA", con1);
                                }

                                else
                                {
                                    com1 = new SqlCommand("CSRsort", con1);
                                }
                            }
                            else
                                com1 = new SqlCommand("CSRsort", con1);
                        }

                        com1.CommandType = CommandType.StoredProcedure;
                        com1.Parameters.AddWithValue("agent_id", dr["agent_id"].ToString());
                        com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                        com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                        com1.Parameters.AddWithValue("Airline_Detail_ID", ddlAirLine.SelectedValue.Trim());
                        SqlDataReader dr1 = com1.ExecuteReader();
                        string VarDate = "07/31/2008";
                        string MH_Period = "08/15/2008";
                        ////DataTable dt = new DataTable();
                        ////dt.Load(dr1);
                        while (dr1.Read())
                        {
                            Gstno = dr1["GstNo"].ToString();
                            csrno = dr1["csr_sno"].ToString();
                            #region Financial Year
                            string Flight_date = TextBox2.Text;
                            string[] dateSplit = Flight_date.Split('/');
                            string Month = dateSplit[1].ToString();
                            string Year = dateSplit[2].ToString();
                            string Date1 = dateSplit[0].ToString();
                            ////string currentdate = Month + "/" + Date1 + "/" + Year;
                            string currentdate = Date1 + "/" + Month + "/" + Year;
                            string FinYear = Year.Substring(2, 2);
                            //// string dateCurrent = DateTime.Now.ToShortDateString();

                            /////DateTime CurrDate = DateTime.Now;
                            DateTime CurrDate = DateTime.Parse(currentdate);
                            string DateFinancial = "4/1/20" + FinYear + "";
                            DateTime FinanciaDate = DateTime.Parse(DateFinancial);

                            ////***********updated on 04 Aug 2017 : Invoice No must be sort of 16 digit


                            if (CurrDate < FinanciaDate)
                            {
                                FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            }
                            else
                            {
                                FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            }
                            #endregion end of financial Year



                            DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix + substring(Fin_Year,3,5))as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "  AND Fin_Year='" + FinYear + "'");

                            if (dtInvoice.Rows.Count > 0)
                            {
                                ///////Updated on 30 May 2017
                                ////Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();

                                csrno = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + csrno;
                            }



                            
                            if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                            {
                                total_tds_cut += Math.Round(decimal.Parse(dr1["Total_Due_PP_row"].ToString()), MidpointRounding.AwayFromZero);
                                if (DateTime.Parse(TextBox1.Text) >= DateTime.Parse("08/01/2009"))
                                {
                                    total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                                }
                                else
                                {
                                    total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr1["TDS"].ToString().Trim()) / 100;
                                }
                            }
                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                {
                                    TotDiscount += 0;
                                    comm += 0;
                                    agentExp += 0;

                                }
                                else
                                {
                                    TotDiscount += 0;
                                    comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                {

                                    TotDiscount += 0;
                                    comm += 0;
                                    agentExp += 0;

                                }
                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360")
                            {

                                TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);


                            }



                            if (dr1["Freight_type"].ToString() == "COLLECT")
                            {
                                amountPP += 0;
                                amountCC += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                TotFrAmountCC = Math.Round(amountCC, MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                amountPP += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                amountCC += 0;
                                TotFrAmount = Math.Round(amountPP, MidpointRounding.AwayFromZero);
                            }
                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() != "360")
                            {

                                TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            }


                            // calculation for incentive
                            if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    incentive += 0;
                                }
                                else
                                {
                                    incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                incentive += 0;

                            }
                            //calculation for MH Incentive
                            if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    mHincentive += 0;
                                }

                            }
                            else
                            {
                                mHincentive += 0;

                            }

                            // calculation for spot Diff.

                            if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                { spotDiff += 0; }
                                else
                                {
                                    //Freight_Diff_Amount
                                    //spotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())));
                                    spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                spotDiff += 0;
                            }
                            //cal for hm 
                            if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    // mHspotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())) / 100);
                                    mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    mHspotDiff = 0;
                                }
                            }
                            else
                            {
                                mHspotDiff += 0;
                            }

                            frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            // frtDiff += decimal.Parse(dr1["Discount"].ToString());
                            mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                            if (decimal.Parse(dr1["Freight_Amount"].ToString()) < 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -= 0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);


                                    }

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -= 0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                {

                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }


                            }
                            else
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));

                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {


                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                {



                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }



                            }
                            if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                            {
                                #region Gst CompanyGstNo
                                DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "");
                                if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
                                {
                                    CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                                }

                                #endregion end of Gst CompanyGstNo


                                DataTable dtAgentGstNo = dw.GetAllFromQuery("select top 1 (case when gstno is null then Statecode else gstno end) as GstNo from sales where csr_date between '" + DateTime.Parse(TextBox1.Text) + "' and '" + DateTime.Parse(TextBox2.Text) + "' and agent_id=" + dr["agent_id"].ToString() + " and airline_detail_Id=" + ddlAirLine.SelectedItem.Value.Trim() + "");
                                if (dtAgentGstNo != null && dtAgentGstNo.Rows.Count > 0)
                                {
                                    if (dtAgentGstNo.Rows[0]["GstNo"].ToString() != "")
                                        AgentGstNo = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                                }


                                if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                                {
                                    IGST = 0;
                                    TotalCGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount + comm)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount + comm)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount + comm)) * IGST / 100);
                                    TotalGst = TotalCGST + TotalSGST + TotalIGST;

                                    Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    /////Collect Shipment case
                                    if (Total < 0)
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount + comm)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount + comm)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount + comm)) * IGST / 100);
                                        TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                        Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    CGST = 0;
                                    SGST = 0;
                                    TotalCGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount + comm)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount + comm)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount + comm)) * IGST / 100);
                                    TotalGst = TotalCGST + TotalSGST + TotalIGST;

                                    Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    /////Collect Shipment case
                                    if (Total < 0)
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount + comm)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount + comm)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount + comm)) * IGST / 100);
                                        TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                        Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    }
                                }


                            }
                            else
                            {
                                Total = (TotFrAmount + DueCarr + TotTax) - (agentExp + TotDiscount + comm);
                            }
                            Decimal Debit_Surcharge = 0;
                            DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID='" + dr["agent_id"].ToString() + "' AND AIRLINE_DETAIL_ID=" + ddlAirLine.SelectedItem.Value + " AND (CSR_PERIOD>='" + DateTime.Parse(TextBox1.Text) + "' AND CSR_PERIOD<='" + DateTime.Parse(TextBox2.Text) + "')");

                            if (dt_Sur.Rows.Count > 0)
                            {
                                Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                if (DateTime.Parse(TextBox2.Text) <= DateTime.Parse("07/15/2017"))

                                    EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(dr1["Education_Cess"].ToString()) / 100)), MidpointRounding.AwayFromZero);
                                else
                                {
                                    if (ddlAirLine.SelectedValue.Trim() == "158" || ddlAirLine.SelectedValue.Trim() == "159" || ddlAirLine.SelectedValue.Trim() == "160")
                                        EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(dr1["Education_Cess"].ToString()) / 100)), MidpointRounding.AwayFromZero);
                                    else
                                    EduChrg = Math.Round((((surCharge + Debit_Surcharge) * decimal.Parse(dr1["Education_Cess"].ToString()) / 100)), MidpointRounding.AwayFromZero);
                                }


                            }
                            if (DateTime.Parse(TextBox2.Text) <= DateTime.Parse("07/15/2017"))
                            {
                                if (Math.Round((Total + TotTds + EduChrg + surCharge - total_tds_cut + total_cc), MidpointRounding.AwayFromZero) < 0)
                                {
                                    GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                    decimal test = (Math.Round((Total + Math.Ceiling(TotTds) + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + Math.Round(surCharge, MidpointRounding.AwayFromZero)), MidpointRounding.AwayFromZero));
                                    //GrandTotal2 = GrandTotal2 + Math.Abs(GrandTotal);
                                    ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";
                                    // GtGrandTotal -= GrandTotal;


                                }
                                else
                                {
                                    GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                    //GrandTotal1 = GrandTotal1 + Math.Abs(GrandTotal);
                                    ss = "<font color=black>" + Math.Abs(GrandTotal) + "";
                                    // GtGrandTotal += GrandTotal;
                                }
                            }

                            else
                            {
                                

                                if (Math.Round((Total + EduChrg + surCharge - total_tds_cut + total_cc), MidpointRounding.AwayFromZero) < 0)
                                {
                                    if (ddlAirLine.SelectedValue.Trim() == "158" || ddlAirLine.SelectedValue.Trim() == "159" || ddlAirLine.SelectedValue.Trim() == "160")
                                    {
                                        GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                        decimal test = (Math.Round((Total + Math.Ceiling(TotTds) + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + Math.Round(surCharge, MidpointRounding.AwayFromZero)), MidpointRounding.AwayFromZero));
                                        //GrandTotal2 = GrandTotal2 + Math.Abs(GrandTotal);
                                        ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";
                                        // GtGrandTotal -= GrandTotal;
                                    }

                                    else
                                    {
                                        GrandTotal = Math.Round((Total - total_tds_cut + total_cc + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                        decimal test = (Math.Round((Total  + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + Math.Round(surCharge, MidpointRounding.AwayFromZero)), MidpointRounding.AwayFromZero));
                                        //GrandTotal2 = GrandTotal2 + Math.Abs(GrandTotal);
                                        ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";
                                    }


                                }
                                else
                                {
                                    if (ddlAirLine.SelectedValue.Trim() == "158" || ddlAirLine.SelectedValue.Trim() == "159" || ddlAirLine.SelectedValue.Trim() == "160")
                                    {
                                        GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                        //GrandTotal1 = GrandTotal1 + Math.Abs(GrandTotal);
                                        ss = "<font color=black>" + Math.Abs(GrandTotal) + "";
                                        // GtGrandTotal += GrandTotal;
                                    }

                                    else
                                    {
                                        GrandTotal = Math.Round((Total - total_tds_cut + total_cc  + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                        //GrandTotal1 = GrandTotal1 + Math.Abs(GrandTotal);
                                        ss = "<font color=black>" + Math.Abs(GrandTotal) + "";
                                        // GtGrandTotal += GrandTotal;
                                    }
                                }
                            }

                        }

                        GtchrWt += chrWt;
                        GtamountPP += amountPP;
                        GtamountCC += amountCC;
                        GtDueCarr += DueCarr;
                        GtagentExp += agentExp;
                        Gtcomm += comm;
                        Gtincentive += incentive;
                        GtspotDiff += spotDiff;
                        GtfrtDiff += frtDiff;
                        MHGtincentive += mHincentive;
                        MHGtspotDiff += mHspotDiff;
                        MHGtfrtDiff += mHfrtDiff;
                        GtGrandTotal += GrandTotal;
                        GTotalCGST += TotalCGST;
                        GTotalSGST += TotalSGST;
                        GTotalIGST += TotalIGST;
                        GTotalGst += TotalGst;
                        // GtGrandTotal = GtGrandTotal + GrandTotal;


                        GtxrayCh += xrayCh;
                        if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                        {
                            table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + amountPP + @"</td><td align=""right"">" + amountCC + @"</td><td align=""right"">" + DueCarr + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + comm + @"</td><td align=""right"">" + incentive + @"</td><td align=""right"">" + spotDiff + @"</td><td align=""right"">" + frtDiff + @"</td><td align=""right"">" + ss + @"</td><td align=""right"">" + xrayCh + @"</td><td align=""right"">" + mHincentive + @"</td><td align=""right"">" + mHspotDiff + @"</td><td align=""right"">" + mHfrtDiff + @"</td></tr>";
                            sno = sno + 1;
                        }
                        else
                        {
                            if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                            {
                                table += @"<td align=""right"" wrap>" + csrno + @"</td><td align=""right"" wrap>" + Gstno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + amountPP + @"</td><td align=""right"">" + amountCC + @"</td><td align=""right"">" + DueCarr + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + (frtDiff + comm) + @"</td><td align=""right"">" + TotalCGST + @"</td><td align=""right"">" + TotalSGST + @"</td><td align=""right"">" + TotalIGST + @"</td><td align=""right"">" + TotalGst + @"</td><td align=""right"">" + ss + @"</td><td align=""right"">" + xrayCh + @"</td></tr>";
                            }
                            else
                            {

                                table += @"<td align=""right"" nowrap>" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + amountPP + @"</td><td align=""right"">" + amountCC + @"</td><td align=""right"">" + DueCarr + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + comm + @"</td><td align=""right"">" + incentive + @"</td><td align=""right"">" + spotDiff + @"</td><td align=""right"">" + frtDiff + @"</td><td align=""right"">" + ss + @"</td><td align=""right"">" + xrayCh + @"</td></tr>";
                            }
                            sno = sno + 1;
                        }
                    }

                    //table += @"<tr ><td rowspan=""2"" >" + airlineName[0].ToUpper().ToString() + "Total" + @"</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";

                    con1.Close();
                }
                //GtGrandTotal = (GrandTotal1 - GrandTotal2);
                if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                {
                    table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td><td>" + MHGtincentive + @"</td><td>" + MHGtspotDiff + @"</td><td>" + MHGtfrtDiff + @"</td></tr></table>";
                }
                else
                {
                    if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + (GtfrtDiff + Gtcomm) + @"</td><td>" + GTotalCGST + @"</td><td>" + GTotalSGST + @"</td><td>" + GTotalIGST + @"</td><td>" + GTotalGst + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";
                    }
                    else
                    {
                        table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td>  <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";
                    }

                }


                Session["dt"] = pageHead + table;
                if (pageHead == "")
                {
                    pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                    Session["dt"] = pageHead;
                }

            }
            catch (SqlException ex)
            {
                string strer = ex.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
            page_pop = "<SCRIPT language='javascript'>window.open('NewReportDrCr.aspx');</SCRIPT>";
            //Response.Write(page_pop);
            ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('NewReportDrCr.aspx');</script>");
            #endregion CsrSummary
        }

        else if (ddlAirLine.SelectedValue.Trim() == "158" || ddlAirLine.SelectedValue.Trim() == "159" || ddlAirLine.SelectedValue.Trim() == "160")
        {
            #region Summary
            string DateWise = "flight_date";
            string comAdd = null, comName = null;
            string[] airlineName = ddlAirLine.SelectedItem.Text.Split('-');
            string airline = "A/C " + airlineName[0].ToUpper().ToString();
            string ss = "";



            if (ddlAirLine.SelectedValue.Trim() == "150" || ddlAirLine.SelectedValue.Trim() == "153")
            {
                DateWise = "awb_date";
            }


            TextBox TextBox1 = new TextBox();
            TextBox TextBox2 = new TextBox();
            TextBox TextBox3 = new TextBox();

            //string strY = DateTime.Today.Year.ToString();
            string strY = ddlyear.SelectedItem.Text.Trim();

            if (rbtnFirstFortn.Checked == true)
            {
                if (ddlMonth.SelectedItem.Text.Trim() == "January")
                {
                    TextBox1.Text = "01/01/" + strY;
                    TextBox2.Text = "01/15/" + strY;
                    TextBox3.Text = "01/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "February")
                {
                    TextBox1.Text = "02/01/" + strY;
                    TextBox2.Text = "02/15/" + strY;
                    TextBox3.Text = "02/16/" + strY;
                }
                if (ddlMonth.SelectedItem.Text.Trim() == "March")
                {
                    TextBox1.Text = "03/01/" + strY;
                    TextBox2.Text = "03/15/" + strY;
                    TextBox3.Text = "03/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "April")
                {
                    TextBox1.Text = "04/01/" + strY;
                    TextBox2.Text = "04/15/" + strY;
                    TextBox3.Text = "04/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text == "May")
                {
                    TextBox1.Text = "05/01/" + strY;
                    TextBox2.Text = "05/15/" + strY;
                    TextBox3.Text = "05/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "June")
                {
                    TextBox1.Text = "06/01/" + strY;
                    TextBox2.Text = "06/15/" + strY;
                    TextBox3.Text = "06/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "July")
                {
                    TextBox1.Text = "07/01/" + strY;
                    TextBox2.Text = "07/15/" + strY;
                    TextBox3.Text = "07/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "August")
                {
                    TextBox1.Text = "08/01/" + strY;
                    TextBox2.Text = "08/15/" + strY;
                    TextBox3.Text = "08/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "September")
                {
                    TextBox1.Text = "09/01/" + strY;
                    TextBox2.Text = "09/15/" + strY;
                    TextBox3.Text = "09/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "October")
                {
                    TextBox1.Text = "10/01/" + strY;
                    TextBox2.Text = "10/15/" + strY;
                    TextBox3.Text = "10/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "November")
                {
                    TextBox1.Text = "11/01/" + strY;
                    TextBox2.Text = "11/15/" + strY;
                    TextBox3.Text = "11/16/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "December")
                {
                    TextBox1.Text = "12/01/" + strY;
                    TextBox2.Text = "12/15/" + strY;
                    TextBox3.Text = "12/16/" + strY;
                }
            }

            else if (rbtnSecondFortN.Checked == true)
            {
                if (ddlMonth.SelectedItem.Text.Trim() == "January")
                {
                    TextBox1.Text = "01/16/" + strY;
                    TextBox2.Text = "01/31/" + strY;
                    TextBox3.Text = "02/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "February")
                {
                    TextBox1.Text = "02/16/" + strY;
                    if (DateTime.IsLeapYear(int.Parse(strY)))
                        TextBox2.Text = "02/29/" + strY;
                    else
                    { TextBox2.Text = "02/28/" + strY; }

                    TextBox3.Text = "03/01/" + strY;

                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "March")
                {
                    TextBox1.Text = "03/16/" + strY;
                    TextBox2.Text = "03/31/" + strY;
                    TextBox3.Text = "04/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "April")
                {
                    TextBox1.Text = "04/16/" + strY;
                    TextBox2.Text = "04/30/" + strY;
                    TextBox3.Text = "05/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "May")
                {
                    TextBox1.Text = "05/16/" + strY;
                    TextBox2.Text = "05/31/" + strY;
                    TextBox3.Text = "06/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "June")
                {
                    TextBox1.Text = "06/16/" + strY;
                    TextBox2.Text = "06/30/" + strY;
                    TextBox3.Text = "07/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "July")
                {
                    TextBox1.Text = "07/16/" + strY;
                    TextBox2.Text = "07/31/" + strY;
                    TextBox3.Text = "08/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "August")
                {
                    TextBox1.Text = "08/16/" + strY;
                    TextBox2.Text = "08/31/" + strY;
                    TextBox3.Text = "09/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "September")
                {
                    TextBox1.Text = "09/16/" + strY;
                    TextBox2.Text = "09/30/" + strY;
                    TextBox3.Text = "10/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "October")
                {
                    TextBox1.Text = "10/16/" + strY;
                    TextBox2.Text = "10/31/" + strY;
                    TextBox3.Text = "11/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "November")
                {
                    TextBox1.Text = "11/16/" + strY;
                    TextBox2.Text = "11/30/" + strY;
                    TextBox3.Text = "12/01/" + strY;
                }
                else if (ddlMonth.SelectedItem.Text.Trim() == "December")
                {
                    TextBox1.Text = "12/16/" + strY;
                    TextBox2.Text = "12/31/" + strY;
                    TextBox3.Text = "01/01/" + strY;
                }

            }



            if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
            {
                table += @"<table  border=""1"" align=""center"" class=""text""><tr class=""h5 boldtext""><th rowspan=""2"" width=""3%"">S.No</th><th rowspan=""2"" width=""25%"" >Agent</th><th rowspan=""2"">CSR NO.</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" class=""h1 boldtext"" >Commissionable</th><th rowspan=""2"">Due Carr</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"">Comm.</th><th rowspan=""2"">Incentive</th><th rowspan=""2"">Spot diff.</th><th rowspan=""2"">Frt diff.</th><th rowspan=""2"">Receivable/<font color=""red"">Payable</font></th><th rowspan=""2"" width=""8%"">X-Ray</th><th rowspan=""2"">MH Incentive</th><th rowspan=""2"">MH Spot diff.</th><th rowspan=""2""> MH Frt diff.</th></tr><tr ><th class=""h1 boldtext"">Prepaid</th><th class=""h1 boldtext"">Collect</th></tr>";
            }
            else
            {
                if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                {
                    table += @"<table  border=""1"" align=""center"" class=""text""><tr class=""h5 boldtext""><th rowspan=""2"" width=""3%"">S.No</th><th rowspan=""2"" width=""25%"" >Agent</th><th rowspan=""2"">INVOICE NO.</th><th rowspan=""2"">GST NO.</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" class=""h1 boldtext"" >Commissionable</th><th rowspan=""2"">Due Carr</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"">Comm.</th><th rowspan=""2"">Incentive</th><th rowspan=""2"">Spot diff.</th><th rowspan=""2"">Frt diff.</th><th rowspan=""2"">CGST</th><th rowspan=""2"">SGST</th><th rowspan=""2"">IGST</th><th rowspan=""2"">Total GST</th><th rowspan=""2"">Receivable/<font color=""red"">Payable</font></th><th rowspan=""2"" colspan=""6"" width=""8%"">X-Ray</th></tr><tr ><th class=""h1 boldtext"">Prepaid</th><th class=""h1 boldtext"">Collect</th></tr>";
                }
                else
                {

                    table += @"<table  border=""1"" align=""center"" class=""text""><tr class=""h5 boldtext""><th rowspan=""2"" width=""3%"">S.No</th><th rowspan=""2"" width=""25%"" >Agent</th><th rowspan=""2"">CSR NO.</th><th rowspan=""2"">Chrg. Wt</th><th colspan=""2"" class=""h1 boldtext"" >Commissionable</th><th rowspan=""2"">Due Carr</th><th rowspan=""2"">Agent Expenses</th><th rowspan=""2"">Comm.</th><th rowspan=""2"">Incentive</th><th rowspan=""2"">Spot diff.</th><th rowspan=""2"">Frt diff.</th><th rowspan=""2"">Receivable/<font color=""red"">Payable</font></th><th rowspan=""2"" colspan=""6"" width=""8%"">X-Ray</th></tr><tr ><th class=""h1 boldtext"">Prepaid</th><th class=""h1 boldtext"">Collect</th></tr>";
                }
            }
            con = new SqlConnection(strCon);
            con.Open();
            try
            {//////
                com = new SqlCommand("select airline_id,belongs_to_city from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                dr = com.ExecuteReader();
                if (dr.Read())
                {
                    airlineId = dr["airline_id"].ToString();
                    bID = dr["belongs_to_city"].ToString();
                }
                dr.Dispose();
                com.Dispose();
                com = new SqlCommand("select * from company_master where (company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ") or parent_id= (select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " and belongs_to_city=" + bID + ")) and city=" + bID + "", con);
                //com = new SqlCommand("select * from company_master where company_id=(select company_id from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " )", con);
                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    comAdd = dr["company_address"].ToString();
                    comName = dr["company_name"].ToString();
                    string s = dr["company_address"].ToString();
                    char ch = (char)System.Windows.Forms.Keys.Return;
                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                    string ch1 = Convert.ToString(ch);
                    string ch3 = Convert.ToString(ch2);
                    string h = s.Replace(ch1, "<br>");
                    h = h.Replace(ch3, "&nbsp;");

                    pageHead += @"<p align=""center"" class=""boldtext""><font size=""2"">" + airlineName[0].ToUpper().ToString() + @"</font><br><font size=""2"">" + h + @"<br> Phone :" + dr["Phone"].ToString() + @"<br>CSR Summary Report<br>From " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";

                }
                com.Dispose();
                dr.Dispose();

                //////

                com = new SqlCommand("select a.agent_id,b.agent_name from agent_Branch a inner join agent_master b on b.agent_id=a.agent_id where agent_Branch_id in(select isnull(c.agent_id,0) from login_master c where airline_access like '%" + ddlAirLine.SelectedValue.Trim() + "%') and a.Belongs_To_City=" + bID + " order by b.agent_name ", con);
                dr = com.ExecuteReader();
                int sno = 1;
                while (dr.Read())
                {
                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand com1 = new SqlCommand();
                    /////// com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "  union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (Csr_Date between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " ", con1);

                    com1 = new SqlCommand("select agent_id from sales where agent_id=" + dr["agent_id"].ToString() + " and (" + DateWise + " between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "  union  select agent_id from sales_drcr where agent_id=" + dr["agent_id"].ToString() + " and (" + DateWise + " between '" + TextBox1.Text + "' and '" + TextBox2.Text + "') and airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + " ", con1);
                    SqlDataReader dr5 = com1.ExecuteReader();
                    if (dr5.Read())
                    {
                        com1.Dispose();
                        dr5.Dispose();

                        decimal CGST = 9;
                        decimal SGST = 9;
                        decimal IGST = 18;

                        decimal TotalCGST = 9;
                        decimal TotalSGST = 9;
                        decimal TotalIGST = 18;
                        decimal TotalGst = 0;

                        ////decimal GTotalCGST = 0;
                        ////decimal GTotalSGST = 0;
                        ////decimal GTotalIGST = 0;
                        ////decimal GTotalGst = 0;

                        decimal xrayCh = 0;
                        decimal frAmount = 0;
                        decimal DueCarr = 0;
                        decimal agentExp = 0;
                        decimal comm = 0;
                        decimal incentive = 0;
                        decimal mHincentive = 0;
                        decimal spotDiff = 0;
                        decimal mHspotDiff = 0;
                        decimal frtDiff = 0;
                        decimal mHfrtDiff = 0;
                        decimal chrWt = 0;
                        decimal amountPP = 0;
                        decimal amountCC = 0;
                        decimal TotFrAmountCC = 0;
                        decimal TotFrAmount = 0;
                        decimal TotTds = 0;
                        decimal TotTax = 0, TotDiscount = 0;
                        decimal EduChrg = 0; decimal Total = 0;
                        decimal surCharge = 0;
                        string stagent = dr["agent_id"].ToString();
                        ////decimal GrandTotal = 0;
                        ////decimal GrandTotal1 = 0;
                        ////decimal GrandTotal2 = 0;
                        string csrno = "";
                        string GstNo = "";
                        decimal total_cc = 0;
                        decimal total_tds_cut = 0;

                        table += @"<tr class=""text""><td>" + sno + @"</td><td align=""left"">" + dr["agent_name"].ToString() + @"</td>";
                        //SqlConnection con1 = new SqlConnection(strCon);
                        //con1.Open();
                        if (airlineName[0].ToString().Trim() == "CHINA AIRLINES")
                        {
                            com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                        }
                        else if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                        {
                            com1 = new SqlCommand("CSR_SORT_DECCAN", con1);
                        }
                        else if (airlineName[0].ToString() == "MALAYSIAN AIRLINES")
                        {
                            if (TextBox1.Text == "04/1/2008" && TextBox2.Text == "04/15/2008")
                            {
                                com1 = new SqlCommand("CSRsort", con1);

                            }
                            else
                            {
                                com1 = new SqlCommand("CSR_SORT_CHINA", con1);
                            }

                        }
                        else
                        {
                            com1 = new SqlCommand("csrsort_Temp_KEIATA", con1);
                        }

                        com1.CommandType = CommandType.StoredProcedure;
                        com1.Parameters.AddWithValue("agent_id", dr["agent_id"].ToString());
                        com1.Parameters.AddWithValue("FROM_DATE", DateTime.Parse(TextBox1.Text));
                        com1.Parameters.AddWithValue("TO_DATE", DateTime.Parse(TextBox2.Text));
                        com1.Parameters.AddWithValue("Airline_Detail_ID", ddlAirLine.SelectedValue.Trim());
                        SqlDataReader dr1 = com1.ExecuteReader();
                        string VarDate = "07/31/2008";
                        string MH_Period = "08/15/2008";
                        while (dr1.Read())
                        {
                            GstNo = dr1["GstNo"].ToString();
                            csrno = dr1["csr_sno"].ToString();


                            #region Financial Year
                            string Flight_date = TextBox2.Text;
                            string[] dateSplit = Flight_date.Split('/');
                            string Month = dateSplit[1].ToString();
                            string Year = dateSplit[2].ToString();
                            string Date1 = dateSplit[0].ToString();
                            ////string currentdate = Month + "/" + Date1 + "/" + Year;
                            string currentdate = Date1 + "/" + Month + "/" + Year;
                            string FinYear = Year.Substring(2, 2);
                            //// string dateCurrent = DateTime.Now.ToShortDateString();

                            /////DateTime CurrDate = DateTime.Now;
                            DateTime CurrDate = DateTime.Parse(currentdate);
                            string DateFinancial = "4/1/20" + FinYear + "";
                            DateTime FinanciaDate = DateTime.Parse(DateFinancial);

                            ////***********updated on 04 Aug 2017 : Invoice No must be sort of 16 digit


                            if (CurrDate < FinanciaDate)
                            {
                                FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
                            }
                            else
                            {
                                FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
                            }
                            #endregion end of financial Year



                            DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix + substring(Fin_Year,3,5))as Prifix FROM db_owner.Invoice_No where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "  AND Fin_Year='" + FinYear + "'");

                            if (dtInvoice.Rows.Count > 0)
                            {
                                ///////Updated on 30 May 2017
                                ////Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();

                                csrno = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + csrno;
                            }



                            if (airlineName[0].ToString().Trim() == "DECCAN CARGO")
                            {
                                total_tds_cut += Math.Round(decimal.Parse(dr1["Total_Due_PP_row"].ToString()), MidpointRounding.AwayFromZero);
                                if (DateTime.Parse(TextBox1.Text) >= DateTime.Parse("08/01/2009"))
                                {
                                    total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(2.266) / 100;
                                }
                                else
                                {
                                    total_cc += decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()) * Convert.ToDecimal(dr1["TDS"].ToString().Trim()) / 100;
                                }
                            }
                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                {
                                    TotDiscount += 0;
                                    comm += 0;
                                    agentExp += 0;

                                }
                                else
                                {
                                    TotDiscount += 0;
                                    comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                            {
                                if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                {

                                    TotDiscount += 0;
                                    comm += 0;
                                    agentExp += 0;

                                }
                                else
                                {
                                    TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                    comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                    agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360")
                            {

                                TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                TotDiscount += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                comm += Math.Round(decimal.Parse(dr1["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                agentExp += Math.Round(decimal.Parse(dr1["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);


                            }



                            if (dr1["Freight_type"].ToString() == "COLLECT")
                            {
                                amountPP += 0;
                                amountCC += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                TotFrAmountCC = Math.Round(amountCC, MidpointRounding.AwayFromZero);

                            }
                            else
                            {
                                amountPP += Convert.ToDecimal(dr1["Freight_Amount"].ToString());
                                amountCC += 0;
                                TotFrAmount = Math.Round(amountPP, MidpointRounding.AwayFromZero);
                            }
                            if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() != "360")
                            {

                                TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            }
                            else
                            {
                                TotTax += Math.Round(decimal.Parse(dr1["Tax"].ToString()), MidpointRounding.AwayFromZero);
                                chrWt += Math.Round(decimal.Parse(dr1["Charged_Weight"].ToString()), MidpointRounding.AwayFromZero);
                                xrayCh += Math.Round(decimal.Parse(dr1["Xray_Charges"].ToString() == "" ? "0" : dr1["Xray_Charges"].ToString()), MidpointRounding.AwayFromZero);
                                frAmount += Math.Round(decimal.Parse(dr1["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                DueCarr += Math.Round(decimal.Parse(dr1["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                            }


                            // calculation for incentive
                            if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    incentive += 0;
                                }
                                else
                                {
                                    incentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                incentive += 0;

                            }
                            //calculation for MH Incentive
                            if (decimal.Parse(dr1["Special_Commodity_Incentive"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    mHincentive += Math.Round(((decimal.Parse(dr1["Freight_Amount"].ToString()) - decimal.Parse(dr1["Commissionable_Amount"].ToString())) * decimal.Parse(dr1["Special_Commodity_Incentive"].ToString())) / 100, MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    mHincentive += 0;
                                }

                            }
                            else
                            {
                                mHincentive += 0;

                            }

                            // calculation for spot Diff.

                            if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                { spotDiff += 0; }
                                else
                                {
                                    //Freight_Diff_Amount
                                    //spotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())));
                                    spotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                spotDiff += 0;
                            }
                            //cal for hm 
                            if (decimal.Parse(dr1["Spot_Rate"].ToString()) != 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    // mHspotDiff += Math.Round(((decimal.Parse(dr1["tariff_rate"].ToString()) - decimal.Parse(dr1["Spot_Rate"].ToString())) * decimal.Parse(dr1["Charged_Weight"].ToString())) / 100);
                                    mHspotDiff += Math.Round(decimal.Parse(dr1["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    mHspotDiff = 0;
                                }
                            }
                            else
                            {
                                mHspotDiff += 0;
                            }

                            frtDiff += Math.Round(decimal.Parse(dr1["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            // frtDiff += decimal.Parse(dr1["Discount"].ToString());
                            mHfrtDiff += Math.Round(decimal.Parse(dr1["MHDiscount"].ToString()), MidpointRounding.AwayFromZero);
                            if (decimal.Parse(dr1["Freight_Amount"].ToString()) < 0)
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -= 0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);


                                    }

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                    {
                                        TotTds -= 0;
                                        surCharge -= 0;
                                        EduChrg -= 0;
                                    }
                                    else
                                    {
                                        TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                        EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {

                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                {

                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }


                            }
                            else
                            {
                                if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(VarDate))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));
                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {
                                    if (DateTime.Parse(TextBox1.Text) > DateTime.Parse(MH_Period))
                                    {
                                        TotTds += 0;
                                        surCharge += 0;
                                        EduChrg += 0;
                                    }
                                    else
                                    {
                                        TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                        surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));

                                        EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "COLLECT")
                                {


                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else if (dr1["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "360" && dr1["DueCarrier_Type"].ToString() == "PREPAID")
                                {



                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr1["only_surcharge"].ToString()));

                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr1["ONLY_TDS"].ToString())) + decimal.Parse(dr1["only_surcharge"].ToString())) * decimal.Parse(dr1["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }



                            }
                            if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                            {
                                #region Gst CompanyGstNo
                                DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "");
                                if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
                                {
                                    CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                                }

                                #endregion end of Gst CompanyGstNo


                                DataTable dtAgentGstNo = dw.GetAllFromQuery("select top 1 (case when gstno is null then Statecode else gstno end) as GstNo from sales where csr_date between '" + DateTime.Parse(TextBox1.Text) + "' and '" + DateTime.Parse(TextBox2.Text) + "' and agent_id=" + dr["agent_id"].ToString() + " and airline_detail_Id=" + ddlAirLine.SelectedItem.Value.Trim() + "");
                                if (dtAgentGstNo != null && dtAgentGstNo.Rows.Count > 0)
                                {
                                    if (dtAgentGstNo.Rows[0]["GstNo"].ToString() != "")
                                        AgentGstNo = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                                }


                                if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                                {
                                    IGST = 0;
                                    TotalCGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount)) * IGST / 100);
                                    TotalGst = TotalCGST + TotalSGST + TotalIGST;

                                    Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    /////Collect Shipment case
                                    if (Total < 0)
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount)) * IGST / 100);
                                        TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                        Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    }
                                }
                                else
                                {
                                    CGST = 0;
                                    SGST = 0;
                                    TotalCGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount)) * CGST / 100);
                                    TotalSGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount)) * SGST / 100);
                                    TotalIGST = Math.Ceiling(((TotFrAmount + DueCarr) - (TotDiscount)) * IGST / 100);
                                    TotalGst = TotalCGST + TotalSGST + TotalIGST;

                                    Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    /////Collect Shipment case
                                    if (Total < 0)
                                    {
                                        TotalCGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount)) * CGST / 100);
                                        TotalSGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount)) * SGST / 100);
                                        TotalIGST = Math.Ceiling(((TotFrAmount + TotFrAmountCC + DueCarr) - (TotDiscount)) * IGST / 100);
                                        TotalGst = TotalCGST + TotalSGST + TotalIGST;
                                        Total = Math.Round(((TotFrAmount + DueCarr + TotTax + TotalGst) - (agentExp + TotDiscount + comm)), MidpointRounding.AwayFromZero);
                                    }
                                }


                            }
                            else
                            {
                                Total = (TotFrAmount + DueCarr + TotTax) - (agentExp + TotDiscount + comm);
                            }
                            Decimal Debit_Surcharge = 0;
                            DataTable dt_Sur = dw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID='" + dr["agent_id"].ToString() + "' AND AIRLINE_DETAIL_ID=" + ddlAirLine.SelectedItem.Value + " AND (CSR_PERIOD>='" + DateTime.Parse(TextBox1.Text) + "' AND CSR_PERIOD<='" + DateTime.Parse(TextBox2.Text) + "')");

                            if (dt_Sur.Rows.Count > 0)
                            {
                                Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                if (DateTime.Parse(TextBox2.Text) <= DateTime.Parse("07/15/2017"))
                                EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * decimal.Parse(dr1["Education_Cess"].ToString()) / 100)), MidpointRounding.AwayFromZero);
                                else
                                 EduChrg = Math.Round((((surCharge + Debit_Surcharge) * decimal.Parse(dr1["Education_Cess"].ToString()) / 100)), MidpointRounding.AwayFromZero);


                            }

                            if (Math.Round((Total + TotTds + EduChrg + surCharge - total_tds_cut + total_cc), MidpointRounding.AwayFromZero) < 0)
                            {
                                if (DateTime.Parse(TextBox2.Text) <= DateTime.Parse("07/15/2017"))
                                GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                else
                                 GrandTotal = Math.Round((Total - total_tds_cut + total_cc + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);

                                if (DateTime.Parse(TextBox2.Text) <= DateTime.Parse("07/15/2017"))
                                {
                                    decimal test = (Math.Round((Total + Math.Ceiling(TotTds) + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + Math.Round(surCharge, MidpointRounding.AwayFromZero)), MidpointRounding.AwayFromZero));
                                    //GrandTotal2 = GrandTotal2 + Math.Abs(GrandTotal);
                                    ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";
                                    // GtGrandTotal -= GrandTotal;
                                }

                                else
                                {
                                    decimal test = (Math.Round((Total + Math.Round(EduChrg, MidpointRounding.AwayFromZero) + Math.Round(surCharge, MidpointRounding.AwayFromZero)), MidpointRounding.AwayFromZero));
                                    //GrandTotal2 = GrandTotal2 + Math.Abs(GrandTotal);
                                    ss = "<font color=red>(" + Math.Abs(GrandTotal) + ")";
                                    // GtGrandTotal -= GrandTotal;
                                }


                            }
                            else
                            {
                                GrandTotal = Math.Round((Total - total_tds_cut + total_cc + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                                //GrandTotal1 = GrandTotal1 + Math.Abs(GrandTotal);
                                ss = "<font color=black>" + Math.Abs(GrandTotal) + "";
                                // GtGrandTotal += GrandTotal;
                            }

                        }

                        GtchrWt += chrWt;
                        GtamountPP += amountPP;
                        GtamountCC += amountCC;
                        GtDueCarr += DueCarr;
                        GtagentExp += agentExp;
                        Gtcomm += comm;
                        Gtincentive += incentive;
                        GtspotDiff += spotDiff;
                        GtfrtDiff += frtDiff;
                        MHGtincentive += mHincentive;
                        MHGtspotDiff += mHspotDiff;
                        MHGtfrtDiff += mHfrtDiff;
                        GtGrandTotal += GrandTotal;
                        GTotalCGST += TotalCGST;
                        GTotalSGST += TotalSGST;
                        GTotalIGST += TotalIGST;
                        GTotalGst += TotalGst;
                        // GtGrandTotal = GtGrandTotal + GrandTotal;


                        GtxrayCh += xrayCh;
                        if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                        {
                            table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + amountPP + @"</td><td align=""right"">" + amountCC + @"</td><td align=""right"">" + DueCarr + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + comm + @"</td><td align=""right"">" + incentive + @"</td><td align=""right"">" + spotDiff + @"</td><td align=""right"">" + frtDiff + @"</td><td align=""right"">" + ss + @"</td><td align=""right"">" + xrayCh + @"</td><td align=""right"">" + mHincentive + @"</td><td align=""right"">" + mHspotDiff + @"</td><td align=""right"">" + mHfrtDiff + @"</td></tr>";
                            sno = sno + 1;
                        }
                        else
                        {
                            if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                            {
                                table += @"<td align=""right"" wrap>" + csrno + @"</td><td align=""right"" wrap>" + GstNo + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + amountPP + @"</td><td align=""right"">" + amountCC + @"</td><td align=""right"">" + DueCarr + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + (comm) + @"</td> <td align=""right"">" + incentive + @"</td><td align=""right"">" + spotDiff + @"</td><td align=""right"">" + frtDiff + @"</td><td align=""right"">" + TotalCGST + @"</td><td align=""right"">" + TotalSGST + @"</td><td align=""right"">" + TotalIGST + @"</td><td align=""right"">" + TotalGst + @"</td><td align=""right"">" + ss + @"</td><td align=""right"">" + xrayCh + @"</td></tr>";
                            }
                            else
                            {

                                table += @"<td align=""right"">" + csrno + @"</td><td align=""right"">" + chrWt + @"</td><td align=""right"">" + amountPP + @"</td><td align=""right"">" + amountCC + @"</td><td align=""right"">" + DueCarr + @"</td><td align=""right"">" + agentExp + @"</td><td align=""right"">" + comm + @"</td><td align=""right"">" + incentive + @"</td><td align=""right"">" + spotDiff + @"</td><td align=""right"">" + frtDiff + @"</td><td align=""right"">" + ss + @"</td><td align=""right"">" + xrayCh + @"</td></tr>";
                            }
                            sno = sno + 1;
                        }
                    }

                    //table += @"<tr ><td rowspan=""2"" >" + airlineName[0].ToUpper().ToString() + "Total" + @"</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";

                    con1.Close();
                }
                //GtGrandTotal = (GrandTotal1 - GrandTotal2);
                if (airlineName[0].ToUpper().ToString() == "MALAYSIAN AIRLINES")
                {
                    table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td><td>" + MHGtincentive + @"</td><td>" + MHGtspotDiff + @"</td><td>" + MHGtfrtDiff + @"</td></tr></table>";
                }
                else
                {
                    if (DateTime.Parse(TextBox2.Text) >= DateTime.Parse("07/01/2017"))
                    {
                        table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td><td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GTotalCGST + @"</td><td>" + GTotalSGST + @"</td><td>" + GTotalIGST + @"</td><td>" + GTotalGst + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";
                    }
                    else
                    {
                        table += @"<tr class=""h1 boldtext"" align=""right""><td colspan=""2"" >" + airlineName[0].ToUpper().ToString() + " TOTAL " + @"&nbsp;&nbsp;&nbsp;</td><td align=""right"">&nbsp;&nbsp;</td> <td>" + GtchrWt + @"</td><td>" + GtamountPP + @"</td><td>" + GtamountCC + @"</td><td>" + GtDueCarr + @"</td><td>" + GtagentExp + @"</td><td>" + Gtcomm + @"</td><td>" + Gtincentive + @"</td><td>" + GtspotDiff + @"</td><td>" + GtfrtDiff + @"</td><td>" + GtGrandTotal + @"</td><td>" + GtxrayCh + @"</td></tr></table>";
                    }

                }


                Session["dt"] = pageHead + table;
                if (pageHead == "")
                {
                    pageHead = @"<p><font color=""red"" size=""4"">Records not found in sales for selected period  " + ConvertDate1(TextBox1.Text) + " To " + ConvertDate1(TextBox2.Text) + @"</font></p>";
                    Session["dt"] = pageHead;
                }

            }
            catch (SqlException ex)
            {
                string strer = ex.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
            page_pop = "<SCRIPT language='javascript'>window.open('NewReportDrCr.aspx');</SCRIPT>";
            //Response.Write(page_pop);
            ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open('NewReportDrCr.aspx');</script>");
            #endregion CsrSummary
        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
