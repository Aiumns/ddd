﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 

public partial class CM1OfflineReport : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        String airline_access = Session["AIRLINEACCESS"].ToString();
        ////Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        Button1.Attributes.Add("onclick", "return CheckEmpty_ddl();");

        if (!IsPostBack)
        {

            DateTime DTM;
            DTM = DateTime.Now.AddMonths(6);

            txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            try
            {
                // airline_access = airline_access.Substring(0, airline_access.Length - 1);
                ////con = new SqlConnection(strCon);
                ////con.Open();
                ////////cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);

                ////cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (147,148,149,150,151,152,153,154,155,156,157,158,159,160,161)and ad.status=2 order by airline_name", con);


                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("Airline_Access", con);
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["airline_detail_id"])));
                }
                cmd.Dispose();
            }
            catch (Exception eror)
            {
                string st = eror.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
                cmd.Dispose();

            }
        }
    }
    //protected void Btnload_Click(object sender, EventArgs e)
    //{
    //    string selected_airline_text = ddl_airline_city.SelectedItem.Text;
    //    string selected_airline_value = ddl_airline_city.SelectedItem.Value;
    //    string from_date = txtValidFrom.Text;
    //    string to_date = txtValidTo.Text;



    //    string url = "CM1_Report_Agent.aspx?airline_text=" + selected_airline_text + "&airline_value=" + selected_airline_value + "&from_date=" + from_date + "&to_date=" + to_date + "";
    //    ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");
    //}
    protected void Button1_Click(object sender, EventArgs e)
    {
        string selected_airline_text = ddl_airline_city.SelectedItem.Text;
        string selected_airline_value = ddl_airline_city.SelectedItem.Value;
        string from_date = txtValidFrom.Text;
        string to_date = txtValidTo.Text;



        string url = "ViewOfflineCM1Report.aspx?airline_text=" + selected_airline_text + "&airline_value=" + selected_airline_value + "&from_date=" + from_date + "&to_date=" + to_date + "";
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");
    }
}
