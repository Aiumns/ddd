using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// Created By Rakhi on 19 Nov 2007
/// </summary>

public partial class Handover_History : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Search();
        }
    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txtsearch.Text == "")
            {
                //selectQ = "SELECT ad.Airline_Detail_ID,am.Airline_Name,am.Airline_Code, cm.City_Name,cmp.Company_Name, ad.DisBursementCharges,ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged, ad.WarSurcharge_On, ad.XRayCharge_Charged, ad.XRayCharge_On,ad.Deal, ad.AWB_Fees, ad.ACI_Fees, sm.Status_Name FROM  Airline_Detail ad inner join Airline_Master am on ad.Airline_ID=am.Airline_ID inner join City_Master cm on ad.Belongs_To_City=cm.City_Id inner join Company_Master cmp on ad.Company_ID=cmp.Company_ID inner join Status_Master sm on ad.Status=sm.Status_ID where sm.Status_Name in('Active','Inactive')";
                selectQ = "select * from Handover_History";
            }

            else
            {
                selectQ = " select * from Handover_History where AirWayBill_No like " + "'" + txtsearch.Text + "%' ";

            }
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            GridView.DataSource = ds;
            GridView.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void GridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView.PageIndex = e.NewPageIndex;
        Search();
    }
}
