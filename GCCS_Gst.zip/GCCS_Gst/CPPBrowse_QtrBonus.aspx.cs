using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CPPBrowse_QtrBonus : System.Web.UI.Page
{
    string[] Sdate;
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
           // Page.Form.Target = "_blank";

            //txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            //Sdate = txtValidFrom.Text.Split('/');
            //string month = Sdate[1];
            //string year = Sdate[2];
            //if (Sdate[1] == "01" || Sdate[1] == "02" || Sdate[1] == "03")
            //{
            //    int yy = int.Parse(year);
            //    string destdata = "31/03/" + yy.ToString();
            //    txtValidTo.Text = destdata;
            //}
            //if (Sdate[1] == "04" || Sdate[1] == "05" || Sdate[1] == "06" || Sdate[1] == "07" || Sdate[1] == "08" || Sdate[1] == "09" || Sdate[1] == "10" || Sdate[1] == "11" || Sdate[1] == "12")
            //{
            //    int yy = int.Parse(year) + 1;
            //    string destdata = "31/03/" + yy.ToString();
            //    txtValidTo.Text = destdata;
            //}
            Search();
        
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            string selectQ = null;
            if (txtValidFrom.Text == "" && txtValidTo.Text == "")
            {
                selectQ = "select  distinct Convert(varchar,startdate,103) as startdate,Convert(varchar,enddate,103) as enddate,cp.city as city  from CPP_QtrBonus CP left join city_master cm  on cp.city=cm.city_id";
            }

            else
            {
                selectQ = "select  distinct Convert(varchar,startdate,103) as startdate,Convert(varchar,enddate,103) as enddate,cp.city as city  from CPP_QtrBonus CP left join city_master cm  on cp.city=cm.city_id where '" + FormatDateMM(txtValidFrom.Text) + "' between startDate and EndDate or '" + FormatDateMM(txtValidTo.Text) + "' between startDate and EndDate  order by startdate";
            }
            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdCpp_QtrBonus.DataSource = dt;
            grdCpp_QtrBonus.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnBrowse_Click(object sender, EventArgs e)
    {
        Search();
        //string strStartDate = txtValidFrom.Text;
        //string strEndDate = txtValidTo.Text;
        //Session["StartDate"] = strStartDate;
        //Session["EndDate"] = strEndDate;
        //Response.Redirect("Cpp_BaseDetails.aspx");

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("CPP_QtrBonus.aspx?startDate=s&enddate=e");
    }
    protected void grdCpp_QtrBonus_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdCpp_QtrBonus.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void grdCpp_QtrBonus_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            Label lblAID = (Label)e.Row.Cells[3].FindControl("Label1");
            string Airline_Access = lblAID.Text;

             string[] a = Airline_Access.Split(',');
            string str = string.Empty;
            for (int i = 0; i < a.Length; i++)
            {   // CREATING DATATABLE FOR Airline Name From Airline Master
                //
                string Query = "Select * from city_master cm  where city_id='" + Convert.ToInt64(a.GetValue(i).ToString()) + "'";
                //string Query = "select  a.Airline_Name,a.airline_text_code,city_code,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City where b.Airline_Detail_ID=" + Convert.ToInt64(a.GetValue(i).ToString()) + "";
                DataTable dtAccess = dw.GetAllFromQuery(Query);
                if (dtAccess.Rows.Count > 0)
                {
                    // STRING CONCATENATION


                    str = str + (dtAccess.Rows[0]["City_code"].ToString().Trim() + ",");
                }
                else
                {
                    str = "ALL,";
                }

            }
            str = str.Remove(str.LastIndexOf(","));
            e.Row.Cells[3].Text = str;
        }
    }

}
