﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Xml;
using System.Text;
using System.IO;


public partial class HAWB_Details : System.Web.UI.Page
{

    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    public string strLen = "";
    public string strShipper="";
    public string strConsignee="";


    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand();

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
          //  strShipper = "<script>var FillShipper=new Array(" + TxtShipper() + ")</script>";
           // strConsignee = "<script>var FillConsignee=new Array(" + TxtConsignee() + ")</script>";
            btnSubmit.Attributes.Add("onclick", "return CheckEmpty();");
            btnupdate.Attributes.Add("onclick", "return CheckEmpty();");

            if (!IsPostBack)
            {
                
                //strConsignee = "<script>var FillConsignee=new Array(" + TxtConsignee() + ")</script>";
                maketable();
                lblMAWB.Visible = false;
                btnupdate.Visible = false;
                btnSubmit.Visible = false;
                pnlHAWB.Visible = false;
                pnlshipper.Visible = false;
                Button1.Visible = false;
                if (Request.QueryString.Count > 0)
                {
                    Button1.Visible = true;
                    txtMAWB.Visible = false;
                    btnupdate.Visible = true;
                    lblMAWB.Visible = true;
                    btnSubmit.Visible = false;
                    btnSearch.Visible = false;
                    pnlshipper.Visible = true;
                    FillHAWBDATA();
                    GetAirwaybill();
                    GetShipperDetails(Request.QueryString["Stock_ID"].ToString());
                    
                }

            }
        }

    }

    protected void GetAirwaybill()
    {
        DataTable dtairwaybill = dw.GetAllFromQuery("SELECT AirWayBill_No FROM dbo.Stock_Master WHERE Stock_ID=" + Convert.ToInt32(Request.QueryString["Stock_ID"].ToString()) + "");
        if (dtairwaybill.Rows.Count > 0)
        {
            lblMAWB.Text = dtairwaybill.Rows[0]["AirWayBill_No"].ToString();
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertMAWBDetails(ViewState["Stockid"].ToString());

        DataTable dtCheck_MAWB = dw.GetAllFromQuery("SELECT * FROM db_owner.HAWB_Details WHERE Stock_id=" + Convert.ToInt32(ViewState["Stockid"].ToString()) + "");
        if (dtCheck_MAWB.Rows.Count > 0)
        {
            

        }
        else
        {


            con.Open();
            try
            {
                foreach (GridViewRow gv in grdCal.Rows)
                {
                    com = new SqlCommand("Insert_HAWB_Details", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = Convert.ToInt32(ViewState["Stockid"].ToString());
                    com.Parameters.Add("@Hawb_No", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblHawbNo")).Text;
                    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblGwt")).Text);
                    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblVWT")).Text);
                    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblCWT")).Text);
                    com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblNature")).Text;
                    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperName")).Text;
                    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperAdd")).Text;
                    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee")).Text;
                    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee_Address")).Text;
                    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                    com.ExecuteNonQuery();

                }
                con.Close();
                //////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Data saved successfully." + "');</script>");
                //////Response.Redirect("ViewHAWB_Details.aspx");
                string strScript = "alert('Data saved successfully.');location.replace('ViewHAWB_Details.aspx');";
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
                ////maketable();
                ////grdCal.DataSource = (DataTable)Session["dtTemp"];
                ////grdCal.DataBind();
            }
            catch (Exception ex)
            {
                string msg = ex.ToString();
                string strScript = "alert('" + msg + "');";

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox2", strScript, true);

                /////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + msg + "');</script>");

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

        }

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (txtMAWB.Text != "")
        {
            con.Open();
            com = new SqlCommand("GetAirwaybill_ForHAWBDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airwaybill_No", SqlDbType.VarChar).Value = txtMAWB.Text;
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            DataTable dtstockid = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(com);
            sda.Fill(dtstockid);
            con.Close();
            //DataTable dtstockid = dw.GetAllFromQuery("SELECT Stock_ID FROM dbo.Stock_Master WHERE AirWayBill_No='" + txtMAWB.Text + "'");
            if (dtstockid.Rows.Count > 0)
            {
                ViewState["Stockid"] = dtstockid.Rows[0]["Stock_ID"].ToString();
                DataTable dtCheck_MAWB = dw.GetAllFromQuery("SELECT * FROM db_owner.HAWB_Details WHERE Stock_id=" + Convert.ToInt32(dtstockid.Rows[0]["Stock_ID"].ToString()) + "");
                if (dtCheck_MAWB.Rows.Count > 0)
                {
                    Button1.Visible = false;
                    //////lblMAWB.Visible = true;
                    //////lblMAWB.Text = "HAWB details have already been entered for this Airwaybill No.Please select another Airwaybill No.";
                    string strScript = "alert('HAWB details have already been entered for this Airwaybill No.Please select another Airwaybill No.');";
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox4", strScript, true);
                    txtMAWB.Text = "";
                    return;
                }
                else
                {
                    GetShipperDetails(ViewState["Stockid"].ToString());
                    pnlshipper.Visible = true;
                    lblMAWB.Visible = false;
                    pnlHAWB.Visible = true;
                    btnSubmit.Visible = true;
                    Button1.Visible = true;
                    maketable();
                    grdCal.DataSource = (DataTable)Session["dtTemp"];
                    grdCal.DataBind();
                }
            }

            else
            {
                ////lblMAWB.Visible = true;
                ////lblMAWB.Text = "Airwaybill not found.";
                string strScript = "alert('Airwaybill not found.');";
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox5", strScript, true);

                return;


            }
        }
        else
        {
            string strScript = "alert('Please enter MAWB No for searching.');";
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox6", strScript, true);

            return;
        }
    }
    public void maketable()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "HAWB_NO";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Gross_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Volume_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Charged_Weight";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Nature_and_Quantity";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Shipper_Name";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Shipper_Address";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Consignee_Name";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Consignee_Address";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);
        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "";
        dr[6] = "";
        dr[7] = "";
        dr[8] = "";
        dr[9] = "";

        dtTemp.Rows.Add(dr);
        Session["dtTemp"] = dtTemp;

    }


    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            // lblmsg.Visible = true;
        }
        else
        {
            // lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }

    }
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                break;
            }
        }
        if (dt.Rows.Count == 0)
        {
            maketable();
            dt = (DataTable)Session["dtTemp"];
        }
        else
        {
            Session["dtTemp"] = dt;
        }


        grdCal.DataSource = dt;
        grdCal.DataBind();
    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        DataTable dt = (DataTable)Session["dtTemp"];
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {

                dr[1] = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtHawbNo")).Text;
                dr[2] = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtGwt")).Text);
                dr[3] = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtVWT")).Text);
                dr[4] = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtCWT")).Text);
                dr[5] = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtNature")).Text;
                dr[6] = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtShiperName")).Text;
                dr[7] = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtShiperAdd")).Text;
                dr[8] = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtConsignee")).Text;
                dr[9] = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtConsignee_Address")).Text;
            }
        }

        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();


    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }

    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {

                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();


                dr[1] = ((TextBox)grdCal.FooterRow.FindControl("txtHawbNo")).Text;
                dr[2] = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtGwt")).Text);
                dr[3] = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtVWT")).Text);
                dr[4] = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtCWT")).Text);
                dr[5] = ((TextBox)grdCal.FooterRow.FindControl("txtNature")).Text;
                dr[6] = ((TextBox)grdCal.FooterRow.FindControl("txtShiperName")).Text;
                dr[7] = ((TextBox)grdCal.FooterRow.FindControl("txtShiperAdd")).Text;
                dr[8] = ((TextBox)grdCal.FooterRow.FindControl("txtConsignee")).Text;
                dr[9] = ((TextBox)grdCal.FooterRow.FindControl("txtConsignee_Address")).Text;

                dt.Rows.Add(dr);
                Session["dtTemp"] = dt;
                grdCal.DataSource = dt;
                grdCal.DataBind();
            }
            catch (Exception ex)
            {
            }
        }
    }


    protected void grdCal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }



    protected void FillHAWBDATA()
    {



        com = new SqlCommand("Get_HAWB_Details_Update", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["Stock_ID"].ToString());
        SqlDataAdapter sda = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        pnlHAWB.Visible = true;
        DataTable dttemp = (DataTable)Session["dtTemp"];

        if (dt.Rows.Count > 0)
        {
            

            if (dttemp.Rows[0][0].ToString() == "0")
            {
                dttemp.Rows[0].Delete();
            }
            

                for (int k = 0; k < dt.Rows.Count; k++)
                {

                    DataRow dr = dttemp.NewRow();
                    dr[1] = dt.Rows[k]["Hawb_No"].ToString();
                    dr[2] = dt.Rows[k]["Gross_Weight"].ToString();
                    dr[3] = dt.Rows[k]["Volume_Weight"].ToString();
                    dr[4] = dt.Rows[k]["Charged_Weight"].ToString();
                    dr[5] = dt.Rows[k]["Nature_and_Quantity"].ToString();
                    dr[6] = dt.Rows[k]["Shipper_Name"].ToString();
                    dr[7] = dt.Rows[k]["Shipper_Address"].ToString();
                    dr[8] = dt.Rows[k]["Consignee_Name"].ToString();
                    dr[9] = dt.Rows[k]["Consignee_Address"].ToString();

                    dttemp.Rows.Add(dr);

                }
            }
            
            Session["dtTemp"] = dttemp;
            grdCal.DataSource = dttemp;
            grdCal.DataBind();
        

    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        InsertMAWBDetails(Request.QueryString["Stock_ID"].ToString());

        try
        {
            MoveToHistory();
            con.Open();
            foreach (GridViewRow gv in grdCal.Rows)
            {
                com = new SqlCommand("Insert_HAWB_Details", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = Convert.ToInt32(Request.QueryString["Stock_ID"].ToString());
                com.Parameters.Add("@Hawb_No", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblHawbNo")).Text;
                com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblGwt")).Text);
                com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblVWT")).Text);
                com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = Convert.ToDecimal(((Label)gv.FindControl("lblCWT")).Text);
                com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblNature")).Text;
                com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperName")).Text;
                com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblShiperAdd")).Text;
                com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee")).Text;
                com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblConsignee_Address")).Text;
                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                com.ExecuteNonQuery();
            }
            con.Close();
            string strScript = "alert('Data updated successfully.');location.replace('ViewHAWB_Details.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox1", strScript, true);
            //////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Data updated successfully." + "');</script>");
            //////Response.Redirect("ViewHAWB_Details.aspx");
            ////maketable();
            ////grdCal.DataSource = (DataTable)Session["dtTemp"];
            ////grdCal.DataBind();
        }
        catch (Exception ex)
        {
            string msg = ex.ToString();
            string strScript = "alert('" + msg + "');";
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox3", strScript, true);


            ////// ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + msg + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }


    protected void MoveToHistory()
    {
        con.Open();
        com = new SqlCommand("MOVE_HAWb_History", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = Convert.ToInt32(Request.QueryString["Stock_ID"].ToString());
        com.ExecuteNonQuery();
        con.Close();


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewHAWB_Details.aspx");
    }

    protected void InsertMAWBDetails( string stock_id)
    {
        try
        {

            con.Open();
            com = new SqlCommand("Insert_Shipper_Details", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = Convert.ToInt32(stock_id);
            com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShpName.Text;
            com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShpAddress.Text;
            com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConName.Text;
            com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConAddress.Text;
            com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            com.ExecuteNonQuery();
            con.Close();


        }
        catch (Exception ex)
        {
            string msg = ex.ToString();
            string strScript = "alert('" + msg + "');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox2", strScript, true);

            /////ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + msg + "');</script>");

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }


    protected void GetShipperDetails( string Stock_Id)
    {

        con.Open();
        com = new SqlCommand("GetShipperDetails", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_Id", SqlDbType.Int).Value = Convert.ToInt32(Stock_Id);

        DataTable dtShipper = new DataTable();
        SqlDataAdapter sdaShipper = new SqlDataAdapter(com);
        sdaShipper.Fill(dtShipper);
        if (dtShipper.Rows.Count > 0)
        {
            txtShpName.Text = dtShipper.Rows[0]["Shipper_Name"].ToString();
            txtShpAddress.Text = dtShipper.Rows[0]["Shipper_Address"].ToString();
            txtConName.Text = dtShipper.Rows[0]["Consignee_Name"].ToString();
            txtConAddress.Text = dtShipper.Rows[0]["Consignee_Address"].ToString();
        
        }
        else
        { }


        con.Close();
    
    }
    public string TxtShipper()
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {

            SqlCommand com = new SqlCommand("GetShipperDetails_Dropdown", con);
            com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["Shipper_Name"]).ToString().ToUpper().Trim() + "'";// +" "+ Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Shipper_Name"]).ToString().ToUpper().Trim() + "'";//+ " " +Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }

    public string TxtConsignee()
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {
            SqlCommand com = new SqlCommand("GetConsigneeDetails_Dropdown", con);
            com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                //if (strTemp == "")
                //    strTemp = "'" + Convert.ToString(dr["Consignee_Name"]) + "'";// +" "+ Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
                //else
                //    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Consignee_Name"]) + "'";//+ " " +Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();

                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["Consignee_Name"]).ToString().ToUpper().Trim() + "'";// +" "+ Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Consignee_Name"]).ToString().ToUpper().Trim() + "'";//+ " " +Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }


    public string TxtDestinationPlusCode()
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT Destination_ID,Destination_Code,Destination_Name FROM Destination_Master";
            SqlCommand com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";// +" "+ Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";//+ " " +Convert.ToString(dr["CityName"]).ToString().ToUpper().Trim();
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }


    

}
