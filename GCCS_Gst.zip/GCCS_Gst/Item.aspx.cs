using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

public partial class item : System.Web.UI.Page
{
    public int sno = 1;
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection mycn = new SqlConnection(strCon);

            SqlDataAdapter da = new SqlDataAdapter("select category from ImageGallery order by category", mycn);
            DataSet ds = new DataSet();
            da.Fill(ds, "ImageGallery");

            ddl_category.DataSource = ds.Tables[0];
            ddl_category.DataTextField = ds.Tables[0].Columns["category"].ColumnName.ToString();
            ddl_category.DataValueField = ds.Tables[0].Columns["category"].ColumnName.ToString();
            ddl_category.DataBind();
            for (int i = 0; i < ddl_category.Items.Count; i++)
            {
                ddl_category.Items[i].Attributes.Add("style", "color:");
            }


        }


    }
    protected byte[] ReadFile2(string sPath)
    {
        //Initialize byte array with a null value initially.
        byte[] data = null;
        //Use FileInfo object to get file size.
        FileInfo fInfo = new FileInfo(sPath);
        long numBytes = fInfo.Length;
        string fname = fInfo.Name;
        //Open FileStream to read file
        FileStream fStream = new FileStream(sPath, FileMode.Open, FileAccess.Read);
        //Use BinaryReader to read file stream into byte array.
        BinaryReader br = new BinaryReader(fStream);
        //When you use BinaryReader, you need to supply number of bytes to read from file.
        //In this case we want to read entire file. So supplying total number of bytes.
        data = br.ReadBytes((int)numBytes);
        return data;
    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand("Select item_name from tbimage where item_name='" + FileUpload1.PostedFile.FileName.ToString() + "'", con);
        SqlDataReader dr = com.ExecuteReader();

        if (dr.Read())
        {
            dr.Close();
            com.Dispose();
            con.Close();
            lblerror.Visible = true;
            lblerror.Text = "Item Name already exists, Please try other Item..";
            return;
        }
        dr.Close();
        com.Dispose();

        if (FileUpload1.PostedFile != null
       && FileUpload1.PostedFile.FileName != "")
        {

            byte[] myimage = new byte[FileUpload1.PostedFile.ContentLength];
            HttpPostedFile Image = FileUpload1.PostedFile;
            Image.InputStream.Read(myimage, 0, (int)FileUpload1.PostedFile.ContentLength);

            SqlConnection myConnection = new SqlConnection(strCon);

            SqlCommand storeimage = new SqlCommand("INSERT INTO tbimage "
                + "(Image_Content, Image_Type, Image_Size,category,item_name,cpp_required,model_no) "
                + " values (@image, @imagetype, @imagesize,@category,@item_name,@cpp_required,@model_no)", myConnection);
            storeimage.Parameters.Add("@image", SqlDbType.Binary, myimage.Length).Value = myimage;
            storeimage.Parameters.Add("@imagetype", SqlDbType.VarChar, 50).Value
            = FileUpload1.PostedFile.ContentType;
            storeimage.Parameters.Add("@imagesize", SqlDbType.Int).Value
            = FileUpload1.PostedFile.ContentLength;
            storeimage.Parameters.Add("@category", SqlDbType.VarChar, 50).Value = ddl_category.SelectedValue.ToString();
            storeimage.Parameters.Add("@item_name", SqlDbType.VarChar, 50).Value = FileUpload1.PostedFile.FileName.ToString();
            storeimage.Parameters.Add("@cpp_required", SqlDbType.Int).Value = txt_cpp.Text;
            storeimage.Parameters.Add("@model_no", SqlDbType.VarChar, 50).Value = txt_model.Text;

            myConnection.Open();
            storeimage.ExecuteNonQuery();
            myConnection.Close();
        }
        txt_cpp.Text = "0";
        txt_model.Text = "";
    }

}
