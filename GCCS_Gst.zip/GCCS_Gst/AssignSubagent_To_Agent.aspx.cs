﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Net.Mail;
using System.Net;

public partial class AssignSubagent_To_Agent : System.Web.UI.Page
{
    int Sub_AgentID = 0;
    int Sid;
    //string CityDest = "";
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        // pnlShowdata.Visible = false;
        // pnlAssignAgent.Visible = false;
        btnsubmit.Attributes.Add("onclick", "return checkData();");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                tragenttab.Visible = false;
                trsubagent.Visible = false;

                LoadCompany();
                LoadCity();

            }

        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AssignSubagent_To_Agent.aspx");
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {

        con = new SqlConnection(strCon);
        SqlCommand cmd = new SqlCommand("InsertSubagentTOHistory", con);
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        cmd.Parameters.AddWithValue("@SubAgentID", int.Parse(ddlsubagent.SelectedValue));
        cmd.Parameters.AddWithValue("@Company_ID", int.Parse(ddlcompany.SelectedValue));
        cmd.ExecuteNonQuery();
        con.Close();
        string Email_id = "";
        string Agent_Name = "<table>";
        string SubAgent_EmailId = "";

        string NocNo = "";
        int k = 0;
        foreach (GridViewRow gv in grdAssignAgent.Rows)
        {
            // lblAgentEmailID
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            Label lblAgentID = (Label)gv.FindControl("lblAgentID");
            Label lblAgentName = (Label)gv.FindControl("lblAgentName");
            TextBox txtRegNo = (TextBox)gv.FindControl("txtRegNo");
            con = new SqlConnection(strCon);
            if (ChkBxItem.Checked)
            {
                k++;
                cmd = new SqlCommand("InsertAgentIntoSubagent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@AgentId", int.Parse(lblAgentID.Text));
                cmd.Parameters.AddWithValue("@SubAgentID", int.Parse(ddlsubagent.SelectedValue));
                cmd.Parameters.AddWithValue("@ReferenceNo", txtRegNo.Text);
                cmd.Parameters.AddWithValue("@Email_id", Session["EMailID"].ToString());
                cmd.Parameters.AddWithValue("@Company_ID", int.Parse(ddlcompany.SelectedValue));
                cmd.ExecuteNonQuery();
                con.Close();
                Agent_Name += @"<tr><td style='font-size:12px;font-weight:bold;color:Black;'>" + k + ":-</td><td style='font-size:12px;font-weight:bold;color:Black;'>" + lblAgentName.Text + "</td></tr>";
                NocNo = txtRegNo.Text;

            }
        }
        Agent_Name += @"</table>";
        cmd = new SqlCommand("GetMailID_City_Company", con);
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        cmd.Parameters.AddWithValue("@City_ID", int.Parse(ddlorigin.SelectedValue));
        cmd.Parameters.AddWithValue("@Company_ID", int.Parse(ddlcompany.SelectedValue));
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            Email_id = dt.Rows[0]["Email_ID"].ToString();
        }
        else
        {
            return;
        }
        cmd = new SqlCommand("GetMailID_Subagent", con);
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        cmd.Parameters.AddWithValue("@City_ID", int.Parse(ddlorigin.SelectedValue));
        cmd.Parameters.AddWithValue("@Subagent_ID", int.Parse(ddlsubagent.SelectedValue));
        SqlDataAdapter daSub = new SqlDataAdapter(cmd);
        DataTable dtSub = new DataTable();
        daSub.Fill(dtSub);
        if (dtSub.Rows.Count > 0)
        {
            SubAgent_EmailId = dtSub.Rows[0]["EmailId"].ToString();
        }
        else
        {
            return;
        }
        // sendmail("asrao@cargoflash.com", Agent_Name, ddlsubagent.SelectedItem.Text, NocNo,Email_id);
        //sendmail("msati@cargoflash.com", Agent_Name, ddlsubagent.SelectedItem.Text, NocNo,Email_id);
        //   sendmail("sarora.ascent@groupconcorde.com", Agent_Name, ddlsubagent.SelectedItem.Text, NocNo, Email_id);
        //sendmail(SubAgent_EmailId, Agent_Name, ddlsubagent.SelectedItem.Text, NocNo, Email_id);
        string strScript = "alert('Saved Successfully.');";
        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        //  rblAssignAgent.SelectedValue = "0";
        filldata();
    }

    protected void ddlsubagent_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlsubagent.SelectedValue != "0")
        {
            trsubmit.Visible = true;
            filldata();
        }
        else
        {
            tragenttab.Visible = false;
            trsubmit.Visible = false;
        }
    }

    protected void filldata()
    {
        tragenttab.Visible = true;
        con = new SqlConnection(strCon);
        SqlCommand cmd = new SqlCommand("GetAgentAccordingSubAgent", con);
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        cmd.Parameters.AddWithValue("@SubAgentID", int.Parse(ddlsubagent.SelectedItem.Value));
        cmd.Parameters.AddWithValue("@Company_ID", int.Parse(ddlcompany.SelectedItem.Value));
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lblmessage.Visible = false;
            // pnlShowdata.Visible = true;
        }
        else
        {
            // pnlShowdata.Visible = false;
            lblmessage.Visible = true;
            lblmessage.Text = "No Record Found";
        }
        GridViewForAgent.DataSource = dt;
        GridViewForAgent.DataBind();
        //cmd = new SqlCommand("GetAgentList_Citywise", con);
        cmd = new SqlCommand("GetAgentList_Companywise", con);
        cmd.CommandType = CommandType.StoredProcedure;
       // cmd.Parameters.Add("@CITY_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlorigin.SelectedValue);
        cmd.Parameters.Add("@Belongs_To_City", SqlDbType.Int).Value = Convert.ToInt32(ddlorigin.SelectedValue);
        cmd.Parameters.AddWithValue("@Company_ID", int.Parse(ddlcompany.SelectedItem.Value));
        // con.Open();
        //cmd.Parameters.AddWithValue("@Cluster_Id", int.Parse(ddlsubagent.SelectedItem.Value));
        SqlDataAdapter daagent = new SqlDataAdapter(cmd);
        DataTable dtagent = new DataTable();
        daagent.Fill(dtagent);
        if (dtagent.Rows.Count > 0)
        {
            lblmessage.Visible = false;
            // pnlAssignAgent.Visible = true;
        }
        else
        {
            // pnlAssignAgent.Visible = false;
            lblmessage.Visible = true;
            lblmessage.Text = "No Record Found";
        }
        grdAssignAgent.DataSource = dtagent;
        grdAssignAgent.DataBind();
        con.Close();
        cmd = new SqlCommand("GetAgentAccordingSubAgent", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@SubAgentID", int.Parse(ddlsubagent.SelectedValue));
        cmd.Parameters.AddWithValue("@Company_ID", int.Parse(ddlcompany.SelectedItem.Value));
        con.Open();
        SqlDataAdapter dasublist = new SqlDataAdapter(cmd);
        DataSet dsSubagent = new DataSet();
        dasublist.Fill(dsSubagent);
        DataTable dtsublist = dsSubagent.Tables[0];
        con.Close();
        foreach (GridViewRow gv in grdAssignAgent.Rows)
        {
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            Label lblAgentID = (Label)gv.FindControl("lblAgentID");
            TextBox txtRegNo = (TextBox)gv.FindControl("txtRegNo");
            txtRegNo.Attributes.Add("style", "display:none");
            txtRegNo.Text = ddlcompany.SelectedItem.Text.Substring(0, 3).ToUpper() + dsSubagent.Tables[1].Rows[0]["City_Code"].ToString() + "-" + int.Parse(ddlsubagent.SelectedValue).ToString("000");
            for (int i = 0; i < dtsublist.Rows.Count; i++)
            {
                if (dtsublist.Rows[i]["Agent_ID"].ToString() == lblAgentID.Text)
                {
                    ChkBxItem.Checked = true;
                    txtRegNo.Attributes.Add("style", "display:inline");
                    txtRegNo.Text = dtsublist.Rows[i]["ReferenceNo"].ToString();
                }
            }
            ChkBxItem.Attributes.Add("onclick", " resetTextbox(this.id);");
        }
        con.Close();
    }

    protected void FillSubAgent()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("SubAgent_GetList_CityWise", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@City_ID ", SqlDbType.Int).Value = Convert.ToInt32(ddlorigin.SelectedValue);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlsubagent.Items.Clear();
            ddlsubagent.Items.Insert(0, "- -Select- -");
            ddlsubagent.Items[0].Value = "0";
            if (dr.HasRows)
            {
                lblMessageSubagent.Visible = false;
                trsubagent.Visible = true;
                while (dr.Read())
                {
                    ddlsubagent.Items.Add(new ListItem(dr["SubAgentName"].ToString(), dr["SubAgentID"].ToString()));
                }
            }
            else
            {
                lblMessageSubagent.Visible = true;
                lblMessageSubagent.Text = "No Subagent For " + ddlcompany.SelectedItem.Text + " " + ddlorigin.SelectedItem.Text + "";
                trsubagent.Visible = false;

            }
            con.Close();
            // ddlCluster.SelectedValue = "0";
        }
        catch
        {
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadCompany()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("Company_Getlist_Cpp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();

            //com = new SqlCommand("select City_ID,City_Code,City_name from City_Master where city_ID in(SELECT DISTINCT CITYID FROM CPP_AgentwiseTotal )", con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlcompany.Items.Clear();
            ddlcompany.Items.Insert(0, "- -Select- -");
            ddlcompany.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlcompany.Items.Add(new ListItem(dr["Company_Name"].ToString(), dr["Company_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadCity()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("Get_Origin_Voucher", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            //com = new SqlCommand("select City_ID,City_Code,City_name from City_Master where city_ID in(SELECT DISTINCT CITYID FROM CPP_AgentwiseTotal )", con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlorigin.Items.Clear();
            ddlorigin.Items.Insert(0, "- -Select- -");
            ddlorigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlorigin.Items.Add(new ListItem(dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void ddlorigin_SelectedIndexChanged(object sender, EventArgs e)
    {
        tragenttab.Visible = false;
        if (ddlorigin.SelectedValue == "0")
        {
            trsubagent.Visible = false;
            trsubmit.Visible = false;
        }
        else
        {
            FillSubAgent();
        }
    }

    protected void sendmail(string email, string Agent_name, string name, string NocNo, string MailFrom)
    {
        try
        {
            MailMessage msg = new MailMessage();
            msg.IsBodyHtml = true;
            msg.Priority = MailPriority.High;
            string userName = "test@cargoflash.com";
            string password = "abc$567";//Admin$567
            string smtpHost = "cargoflash.com";
            msg.Subject = "Successfully Registered For CPP";
            msg.Priority = MailPriority.High;
            msg.To.Add(new MailAddress(email));
            msg.From = new MailAddress("" + ddlcompany.SelectedItem.Text + "<" + MailFrom + ">");
            msg.Body = "Dear Sir/Madam ," + "<br/><br/>Please note that  <b><u> " + name + " </b></u> is successfully registered for Cargo Power Points(CPP)Program, an initiative taken by " + ddlcompany.SelectedItem.Text + "<br/><br/>The Unique Code assigned to your organization is <b><u>" + NocNo + "</u></b> for the following IATA agents.<br/>" + Agent_name + "<br/>Kindly mention this code on each Airway Bill of your shipment to enable us to debit the Power Points in your account instead of the IATA's account.<br/><br/>Looking forward for your continuous support.<br/><br/>Thanks and Best Regards<br/>Marketing Department<br/>" + ddlcompany.SelectedItem.Text + " ";
            SmtpClient smtp = new SmtpClient(smtpHost, 25);
            smtp.Credentials = new NetworkCredential(userName, password);
            smtp.Send(msg);
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert(" + ex.Message + ");</script>");
        }
    }

}
