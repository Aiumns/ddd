using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;


public partial class Destination_upload : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DataSet ds1 = new DataSet("excel_table");
    DataSet ds2 = new DataSet("Table2");
    OleDbConnection connection_excel;
    OleDbDataAdapter ex_adp;
    OleDbCommand cmd_excel;
    SqlTransaction trans;
    string column_excel;
    Boolean flag_check = true;

    DataTable dt_mul = new DataTable();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }  
    }

    protected void Btnload_Click(object sender, EventArgs e)
    {
        string strFileName;
        string strFilePath = "";
        string strFolder;
        string all_Extension;
        GridView1.Visible = false;
        strFolder = Server.MapPath("./temp");
        bool com_not_avb = false;
        lbldest_mis.Visible = false;
            strFileName = FileUpload1.PostedFile.FileName;
            strFileName = System.IO.Path.GetFileName(strFileName);
            all_Extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
            //Check Allowed Extension
            if (FileUpload1.HasFile)
            {
                if (all_Extension == ".xls" || all_Extension == ".XlS")
                {
                    // Create the folder if it does not exist.
                    if (!Directory.Exists(strFolder))
                    {
                        Directory.CreateDirectory(strFolder);
                    }
                    // Save the uploaded file to the server.

                    strFilePath = strFolder + '\\' + strFileName;
                    //Deletes the file if Exists with Same name
                    if (File.Exists(strFilePath))
                    {
                        File.Delete(strFilePath);
                    }
                    else
                    {
                        Label1.Visible = false;
                        FileUpload1.PostedFile.SaveAs(strFilePath);
                        string connect_to_excel;
                        try
                        {
                            connect_to_excel = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strFilePath + ";Extended Properties=Excel 8.0;";
                            connection_excel = new OleDbConnection(connect_to_excel);
                            ex_adp = new OleDbDataAdapter();
                            cmd_excel = new OleDbCommand();
                            cmd_excel.Connection = connection_excel;
                            cmd_excel.CommandText = "select * from [Sheet1$]";
                            ex_adp.SelectCommand = cmd_excel;
                            string dest_code_miss = "";
                            string missing_excel = "";
                            string Entered_By = "";
                            string Entered_On = "";
                            int city_id = 0;
                            int airline_id;
                            int dest_id = 0;
                            string shipment_not_avb = "";
                            ex_adp.Fill(ds1, "excel_table");
                            //Deletes the file after loading the Data to DataSet
                            //Directory.Delete(strFolder, true);

                            if (File.Exists(strFilePath))
                            {
                                File.Delete(strFilePath);
                            }

                            if (validate_columns(ds1))
                            {
                                int columns_in_excel = ds1.Tables[0].Columns.Count;
                                string[] colum = column_excel.Split(',');
                                DataSet ds_comp = new DataSet();
                                con = new SqlConnection(strCon);
                                cmd = new SqlCommand();
                                SqlCommand comd = new SqlCommand();
                                con.Open();
                                bool flag = false;
                                foreach (DataRow datar in ds1.Tables[0].Rows)
                                {
                                    dt_mul = dw.GetAllFromQuery("select Destination_ID from destination_master where Destination_Code='" + datar[0].ToString() + "' or Destination_Code2='" + datar[0].ToString() + "'");
                                    if (dt_mul.Rows.Count > 0)
                                    {
                                        cmd.Connection = con;
                                        foreach (DataRow datar1 in dt_mul.Rows)
                                        {
                                            cmd.CommandText = "update Destination_master set country='" + datar[1].ToString() + "',Region='" + datar[2].ToString() + "',IATA_Area='" + datar[3].ToString() + "' where Destination_ID=" + datar1[0].ToString() + "";

                                            cmd.ExecuteNonQuery();
                                        }
                                    }
                                }
                                GridView1.Visible = true;
                                GridView1.DataSource = ds1;
                                GridView1.DataBind();
                                trans.Commit();
                                cmd.Dispose();
                                con.Close();

                            }
                            else
                            {
                                ds1.Clear();
                                GridView1.Visible = false;
                                Label1.Visible = true;
                                Label1.Text = "Plz Check the File.";
                            }
                        }
                        catch (OleDbException oledb_exc)
                        {
                            oledb_exc.ToString();
                            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Please Check the Sheet Name in Excel File It Should be Sheet1 (Default)" + "');</script>");
                            if (File.Exists(strFilePath))
                            {
                                File.Delete(strFilePath);
                            }
                        }
                        catch (System.Data.SqlClient.SqlException tou)
                        {
                            Label1.Text = "Server Timout Please try Agian";
                            Label1.Visible = true;


                        }
                        catch (Exception sqle)
                        {

                            Label1.Text = "Please Check the file Consistency..";
                            Label1.Visible = true;
                            string err = sqle.ToString();
                            if (File.Exists(strFilePath))
                            {
                                File.Delete(strFilePath);
                            }
                        }
                        finally
                        {
                            if (con != null && con.State == ConnectionState.Open)
                                con.Close();
                        }
                    }
                }
                else
                {
                    ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Please Check the file only Excel files are accepted." + "');</script>");
                    Label1.Text = "This File is not allowed plz";
                    Label1.Visible = true;
                }
            }
            else
            {
                Label1.Text = "Please Browse the file.";
                GridView1.Visible = false;
            }
    }

    bool validate_columns(DataSet ds_check)
    {
        string compare_to_column = "";
        int count = 4;
        compare_to_column = "DSTN,Country,Region,IATA_Area,";
        if (count == ds_check.Tables[0].Columns.Count)
        {
            string column = "";
            int inc = 0;
            int column_present_in_excelsheet = Convert.ToInt32(ds_check.Tables[0].Columns.Count);

            while (inc < column_present_in_excelsheet)
            {
                column = column + Convert.ToString(ds_check.Tables[0].Columns[inc]) + ",";
                inc = inc + 1;
            }
            column_excel = column;
            //if (!(compare_to_column.Equals(column)))
            //{
            //    ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "The File Formate Is Not Correct...(Check the Number of Columns should be" + count + ")" + compare_to_column + "');</script>");
            //    return false;
            //}
            return (true);
        }
        else
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Check the Column Names should be in this format:- [" + compare_to_column.Replace(',', '*') + "]" + "');</script>");
        return false;
    }


}
