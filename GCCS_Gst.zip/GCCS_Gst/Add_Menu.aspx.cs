using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Add_Menu : System.Web.UI.Page
{
    #region created by Mukul Chandra
    /// <summary>
    /// <class>Add Menu</class>
    /// <description>
    /// 
    /// </description>
    /// <dependency></dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>15 Dec</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// </modification>
        /// </modifications> 
    /// </summary> 
    /// 
    #endregion
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader rdr;
    string strquery;
    
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        using (con)
        {
            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                strquery = "select * from main_menu where menu_name='TDS' and menu_link='#'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows == true)
                {
                    lblerror.Visible = true;
                    lblerror.Text = "Given menu already Exists";
                    rdr.Close();
                    con.Close();

                }
                else
                {
                    rdr.Close();
                    strquery = "select max(Sequence) from main_menu";
                    cmd = new SqlCommand(strquery, con);
                    int j = int.Parse(cmd.ExecuteScalar().ToString());
                    cmd.Dispose();
                    strquery = "insert into Main_Menu(Menu_Name,Sequence,Menu_Link)values(@Menu_Name,@Sequence,@Menu_Link)";
                    cmd = new SqlCommand(strquery, con);
                    cmd.Parameters.AddWithValue("@Menu_Name", txtmenu.Text);

                    cmd.Parameters.AddWithValue("@Sequence", j + 1);

                    cmd.Parameters.AddWithValue("@Menu_Link", "#");
                    cmd.ExecuteNonQuery();
                    lblerror.Text = "Added Successfully";
                    txtmenu.Text = null;
                    con.Close();
                }

            }
            catch (SqlException ee)
            {
                lblerror.Visible = true;
                lblerror.Text = "sql error" + ee.Message;

            }
            catch (Exception mm)
            {
                lblerror.Visible = true;
                lblerror.Text = "Some Error Occur ::" + mm.Message;

            }
            finally
            {

                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            
            }        
        
        }

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtmenu.Text = null;
    }
}
