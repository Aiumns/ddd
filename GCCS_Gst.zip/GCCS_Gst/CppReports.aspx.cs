using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CppReports : System.Web.UI.Page
{
    int cityno;
    string cityname = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        cityno = Convert.ToInt32(ddlcity.SelectedValue.ToString());
        cityname = ddlcity.SelectedItem.ToString();
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
             cityno = Convert.ToInt32(ddlcity.SelectedValue.ToString());
           cityname = ddlcity.SelectedItem.ToString();
           
        }

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        //ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open      ('CppReports_View.aspx?fromdate=" + txtFromDate.Text.ToString() + " &todate=" + txtToDate.Text.ToString() + " &cityid=" + cityno + " &cityname="+ cityname+" ');</script>");
        ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>window.open      ('CppReports_View.aspx?fromdate=" + txtFromDate.Text.ToString() + " &todate=" + txtToDate.Text.ToString() + " &cityid=" + cityno + "');</script>");
    }
    protected void ddlcity_SelectedIndexChanged(object sender, EventArgs e)
    {
        cityno = Convert.ToInt32(ddlcity.SelectedValue.ToString());
        cityname = ddlcity.SelectedItem.ToString();

    }
}
