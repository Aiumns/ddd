using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.IO;
using System.Text;
/// <summary>
/// Summary description for sms
/// </summary>
public class sms
{
	public sms()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void SendSMS(string fmobileno, string fmessage)
    {
        try
        {
             
            int Status = 0;
            string StatusMessage = "";
            string str = "";
            string pushURL = "http://push1.maccesssmspush.com/servlet/com.aclwireless.pushconnectivity.listeners.TextListener?userId=idacent&pass=paacent&msgtype=1&contenttype=1&selfid=true&to=@mobileno&from=ASCENT&dlrreq=true&text=@message&alert=1";
            pushURL = pushURL.Replace("@message", fmessage);
            pushURL = pushURL.Replace("@mobileno", fmobileno);
            // Get HTML data
            WebClient client = new WebClient();
            Stream data = client.OpenRead(pushURL);
            StreamReader reader = new StreamReader(data);
            str = reader.ReadToEnd();
            data.Close();
            if (str.StartsWith("0,"))
                Status = 0;
            else
                Status = 1;
            StatusMessage = str;
            str = StatusMessage.Substring(StatusMessage.IndexOf("Sent") + "Sent".Length + 1).Trim();
        }
        catch (Exception eee)
        {

        }
    }
}
