using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Collections;


/// <summary>
/// Summary description for State
/// </summary>
public class Agent
{
    private int id = 0;
    private string name = "";

    public Agent()
    {

    }

    public string AgentName
    {
        set { name = value; }
        get { return name; }
    }

    public int AgentID
    {
        set { id = value; }
        get { return id; }
    }

    public static List<Agent> GetAgent()
    {
        try
        {
            string connstr = ConfigurationManager.ConnectionStrings["gccs"].ToString();
            SqlDataSource accdatasource = new SqlDataSource();
            accdatasource.ConnectionString = connstr;
            accdatasource.SelectCommand = "select import_agent_id,import_agent_name from Import_Agent_Master";
            IEnumerable enumarable = accdatasource.Select(DataSourceSelectArguments.Empty);
            IEnumerator enumarator = enumarable.GetEnumerator();
            List<Agent> Agents = new List<Agent>();

            while (enumarator.MoveNext())
            {
                DataRowView row = (DataRowView)enumarator.Current;
                Agent Agent = new Agent();
                Agent.AgentID = int.Parse(row[0].ToString());
                Agent.AgentName = row[1].ToString();
                Agents.Add(Agent);
            }

            return Agents;

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}