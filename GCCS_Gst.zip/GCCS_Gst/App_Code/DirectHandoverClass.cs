using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// CREATED BY AMIT TONK
/// </summary>
public class DirectHandoverClass
{
    public SqlConnection conAacs;
    public SqlCommand cmd;

    private void openCon()
    {
        if (conAacs == null)
        {
            string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
            conAacs = new SqlConnection(strCon);
            cmd = new SqlCommand();
            conAacs.Open();
            cmd.Connection = conAacs;
        }
    }

    public void closeCon()
    {
        conAacs.Close();
    }

    private void dispose()
    {
        if (conAacs != null)
        {
            conAacs.Dispose();
            conAacs = null;
        }
    }

    public DataSet checkAWBNo(string strCheckAWBNo)
    {
        //bool ret;
        openCon();
        SqlDataAdapter daCheckAWBNo = new SqlDataAdapter(strCheckAWBNo, conAacs);
        DataSet dsCheckAWBNo = new DataSet();
        daCheckAWBNo.Fill(dsCheckAWBNo);
        
        closeCon();
        dispose();
        return dsCheckAWBNo;
    }

	public DirectHandoverClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}
