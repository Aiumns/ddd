using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace GccSystem
{
    public interface Adddes
    {
        string p_dscode
        {
            get;
            set;
        }
        string p_dsname
        {
            get;
            set;
        }

        string p_ctcode
        {
            get;
            set;
        }

        string p_sector
        {
            get;
            set;
        }
      


    }
    public class Destination : clsConnection, Adddes
    {
        private string dscode;
        private string dsname;
        private string ctcode;
        private string sector;

        private void create_para(SqlCommand cmd, eInputType typ)
        {
            SqlParameter p1 = new SqlParameter("@dstnCd", SqlDbType.VarChar);
            SqlParameter p2 = new SqlParameter("@dstnName", SqlDbType.VarChar);
            SqlParameter p3 = new SqlParameter("@countryCd", SqlDbType.VarChar);
            SqlParameter p4 = new SqlParameter("@sector", SqlDbType.VarChar);
            if (typ == eInputType.save)
            {
                cmd.Parameters.Add(p1).Value = dscode;
                cmd.Parameters.Add(p2).Value = dsname;
                cmd.Parameters.Add(p3).Value = ctcode;
                cmd.Parameters.Add(p4).Value = sector;
            }
            else if (typ == eInputType.update)
            {
                cmd.Parameters.Add(p1).Value = dscode;
                cmd.Parameters.Add(p2).Value = dsname;
                cmd.Parameters.Add(p3).Value = ctcode;
                cmd.Parameters.Add(p4).Value = sector;
            }

            else
            {
                cmd.Parameters.Add(p1).Value = dscode;
            }
            cmd.ExecuteNonQuery();
        }
        public Destination()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region intMethods Members

        public void save()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("gccs_Dest_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            create_para(cmd, eInputType.save);
            cmd.Dispose();
            con.Close();
        }

        public void find(object alcd)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand("gccs_des_find", con);
            cmd.CommandType = CommandType.StoredProcedure;

            create_para(cmd, eInputType.find);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
              dscode = (dr["dstnCd"]).ToString();
               dsname = Convert.ToString(dr["dstnName"]);
                ctcode = Convert.ToString(dr["countryCd"]);
               sector = Convert.ToString(dr["Sector"]);
               
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }

        public void delete()
        {
            //if (con.State == ConnectionState.Closed)
            //{
            //    con.Open();
            //}
            //SqlCommand cmd = new SqlCommand("sp_deleteusermaster", con);
            //cmd.CommandType = CommandType.StoredProcedure;
            //create_para(cmd, eInputType.delete);
            //cmd.Dispose();
            //con.Close();
        }

        public void update()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("gccs_desti_update", con);
            cmd.CommandType = CommandType.StoredProcedure;
            create_para(cmd, eInputType.update);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }

        public SqlDataReader dest_select()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("gccs_dest_details", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader dr = cmd.ExecuteReader();
            cmd.Dispose();
            con.Close();
            return dr;

        }
        #endregion
        #region Adddes Members

         string Adddes.p_dscode
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

      string Adddes.p_dsname
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

       string Adddes.p_ctcode
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

         string Adddes.p_sector
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        #endregion

        #region Adddes Members
        public string p_dscode
        {
            get
            {
                return dscode;
            }
            set
            {
                dscode = value;
            }
        }

        public string p_dsname
        {
            get
            {
                return dsname;
            }
            set
            {
                dsname = value;
            }
        }

        public string p_ctcode
        {
            get
            {
                return ctcode;
            }
            set
            {
                ctcode = value;
            }
        }

        public string p_sector
        {
            get
            {
                return sector;
            }
            set
            {
                sector = value;
            }
        }
        #endregion
    }
}