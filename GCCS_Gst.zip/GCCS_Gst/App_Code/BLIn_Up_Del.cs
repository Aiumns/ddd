﻿#region All NameSpaces
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Data.SqlClient;

#endregion

/// <summary>
///Created By Hemant Sharma on 17 june 2014
///Business layer for Insert,Update and Delete 
/// </summary>
public class BLIn_Up_Del
{
    #region Business layer_for Insert,Update and Delete
    SqlConnection con;
    

    public void Insert(string Query)
    {
      
            SqlCommand com_In;
            string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
      
            con = new SqlConnection(strCon);
            con.Open();
            com_In = new SqlCommand(Query,con);
            com_In.ExecuteNonQuery();
            con.Close();
       
    }
    public void Update(string Query)
    {
            SqlCommand com_up;
            string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
          
            con = new SqlConnection(strCon);
            con.Open();
            com_up = new SqlCommand(Query,con);
            com_up.ExecuteNonQuery();
            con.Close();
    }
    public void Delete(string Query)
    {
            SqlCommand com_del;
            string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
           
            con = new SqlConnection(strCon);
            con.Open();
            com_del = new SqlCommand(Query,con);
            com_del.ExecuteNonQuery();
            con.Close();

    }
    #endregion

}
