using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// CREATED BY AMIT TONK - 18-OCT-2007
/// </summary>
public class Login_Check
{
    public SqlConnection conAacs;
    public SqlCommand cmd;
    private void openCon()
    {
        if (conAacs == null)
        {
            string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
            conAacs = new SqlConnection(strCon);
            cmd = new SqlCommand();
            conAacs.Open();
            cmd.Connection = conAacs;
        }
    }
    public void closeCon()
    {
        conAacs.Close();
    }
    private void dispose()
    {
        if (conAacs != null)
        {
            conAacs.Dispose();
            conAacs = null;
        }
    }
    public DataSet checkUser(string UserId,string Password)
    {
        string strStoredProcedure = "uspCheckLogin";
        openCon();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(strStoredProcedure, conAacs);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlparamUserId = new SqlParameter("@sLoginId", UserId);
        sqlparamUserId.Direction = ParameterDirection.Input;
        sqlparamUserId.SqlDbType = SqlDbType.NVarChar;
        sqlparamUserId.Size = 100;
        SqlParameter sqlparamPassword = new SqlParameter("@sPassword", Password);
        sqlparamPassword.Direction = ParameterDirection.Input;
        sqlparamPassword.SqlDbType = SqlDbType.NVarChar;
        sqlparamPassword.Size = 50;
        da.SelectCommand.Parameters.Add(sqlparamUserId);
        da.SelectCommand.Parameters.Add(sqlparamPassword);
        da.Fill(ds);
        closeCon();
        dispose();
        return ds;
    }
    public DataSet getloginDetail(string strQuery)
    {
        openCon();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(strQuery, conAacs);
        da.SelectCommand.CommandType = CommandType.Text;
        da.Fill(ds);
        closeCon();
        dispose();
        return ds;
    }
	public Login_Check()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}
