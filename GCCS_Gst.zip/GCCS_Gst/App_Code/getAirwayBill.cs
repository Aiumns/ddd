using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
/// <summary>
/// Summary description for getAirwayBill
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class getAirwayBill : System.Web.Services.WebService {
    public getAirwayBill () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }
    [WebMethod]
    public string[] GetairwayBill(string prefixText)
    {
        DataSet dtst = new DataSet();
        string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
        SqlConnection sqlCon = new SqlConnection(strCon);
        string strSql = "select distinct airwaybill_no from stock_master inner join agent_master on agent_master.agent_id=stock_master.agent_id inner join agent_branch on agent_master.agent_id=agent_branch.agent_id inner join booking_master on booking_master.stock_id=stock_master.stock_id inner join flight_open on booking_master.flight_open_id=flight_open.flight_open_id inner join flight_master on flight_master.flight_id=flight_open.flight_id inner join destination_master on booking_master.destination_id=destination_master.destination_id where used_date >getdate()-7  and airwaybill_no LIKE '" + prefixText + "%' order by airwaybill_no";
        SqlCommand sqlComd = new SqlCommand(strSql, sqlCon);
        sqlCon.Open();
        SqlDataAdapter sqlAdpt = new SqlDataAdapter();
        sqlAdpt.SelectCommand = sqlComd;
        sqlAdpt.Fill(dtst);
        string[] cntName = new string[dtst.Tables[0].Rows.Count];
        int i = 0;
        try
        {
            foreach (DataRow rdr in dtst.Tables[0].Rows)
            {
                cntName.SetValue(rdr["airwaybill_no"].ToString(), i);
                i++;
            }
        }
        catch { }
        finally
        {
            sqlCon.Close();
        }
        return cntName;
    }    
}

