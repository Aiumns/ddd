﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
    public int EmpID { get; set; }

    public string EmpName { get; set; }

    public decimal EmpSalary { get; set; }

    public string Dept { get; set; }
}