using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for agentNNCal
/// </summary>
public class agentNNCal
{
	public agentNNCal()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public decimal GetAgentNN(decimal tarrif_rate, decimal spot_rate, decimal incentive, decimal commission)
    {
        decimal nnAgent=0;
        decimal com = 0;
        decimal inc = 0;
        com = tarrif_rate * commission / 100;
        inc = (tarrif_rate - com)* incentive / 100;
        if (spot_rate > 0)
        {
            nnAgent = spot_rate -com -inc; 
        }
        else
        {
            nnAgent = tarrif_rate - com - inc;
        }
        return nnAgent;
    }

    
}
