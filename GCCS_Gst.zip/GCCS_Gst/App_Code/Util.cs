using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;
using System.Data.SqlClient;


/// <summary>
/// Summary description for Util
/// </summary>
public static class Util
{
    
    public static string getconstring()
    {
        return (ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString);
    }
    public static SqlConnection  getcon()
    {
      SqlConnection con  = new SqlConnection(getconstring());
        return(con);
    }
}
