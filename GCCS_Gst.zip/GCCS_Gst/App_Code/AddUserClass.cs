using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// CREATED BY AMIT KUMAR TONK - 04/OCT/2007
/// </summary>

public class AddUserClass
{
    public SqlConnection conUser;
    public SqlCommand cmd;

    private void openCon()
    {
        if (conUser == null)
        {
            string conStr = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
            conUser = new SqlConnection(conStr);
            cmd = new SqlCommand();
            conUser.Open();
            cmd.Connection = conUser;
        }
    }

    public void closeCon()
    {
        conUser.Close();
    }

    private void dispose()
    {
        if (conUser != null)
        {
            conUser.Dispose();
            conUser = null;
        }
    }

    public DataSet checkUser(string LoginName)
    {
        string strProcedure = "uspcheckUser";
        openCon();
        DataSet dsUser = new DataSet();
        SqlDataAdapter daUser = new SqlDataAdapter(strProcedure, conUser);
        daUser.SelectCommand.CommandType = CommandType.StoredProcedure;

        SqlParameter sqlparamLoginName = new SqlParameter("@sLoginName", LoginName);
        sqlparamLoginName.Direction = ParameterDirection.Input;
        sqlparamLoginName.SqlDbType = SqlDbType.NVarChar;
        sqlparamLoginName.Size = 100;

        daUser.SelectCommand.Parameters.Add(sqlparamLoginName);
        daUser.Fill(dsUser);
        closeCon();
        dispose();
        return dsUser;
    }

    public DataSet getUserDetail(string strQuery)
    {
        openCon();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(strQuery, conUser);
        da.SelectCommand.CommandType = CommandType.Text;
        da.Fill(ds);
        closeCon();
        dispose();
        return ds;
    }

    public SqlDataReader getData1(string strQuery)
    {
        openCon();
        //DataSet ds = new DataSet();
        SqlDataReader dr;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = strQuery;
        dr = cmd.ExecuteReader();

        closeCon();
        dispose();
        return dr;
    }

    public DataSet getData(string strQuery)
    {
        openCon();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(strQuery, conUser);
        da.SelectCommand.CommandType = CommandType.Text;
        da.Fill(ds);
        closeCon();
        dispose();
        return ds;
    }

    public int addNewUser(
                            string FullName,
                            string Address,
                            string Phone,
                            string Mobile,
                            string Email,
                            string Status,
                            string CreatedBy,
                            string CreatedOn,
                            string City,
                            string LoginId,
                            string Password,
                            string AirAccess,
                            Int64 GroupId
                          )
    {
        string strProcedure = "uspAddNewUser";
        openCon();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = strProcedure;

        cmd.Parameters.AddWithValue("@Full_Name", FullName);
	    cmd.Parameters.AddWithValue("@Address", Address);
	    cmd.Parameters.AddWithValue("@Phone", Phone);
	    cmd.Parameters.AddWithValue("@Mobile", Mobile);
	    cmd.Parameters.AddWithValue("@Email", Email);
	    cmd.Parameters.AddWithValue("@Status", Status);
	    cmd.Parameters.AddWithValue("@Created_By", CreatedBy); 
	    cmd.Parameters.AddWithValue("@Created_On", CreatedOn);
	    cmd.Parameters.AddWithValue("@Belongs_To_City", City);
	    cmd.Parameters.AddWithValue("@Login_id", LoginId);
	    cmd.Parameters.AddWithValue("@Login_Password", Password);
	    cmd.Parameters.AddWithValue("@Airline_Access", AirAccess);
	    //cmd.Parameters.AddWithValue("@Agent_or_User_ID", Agent_UserId);
        cmd.Parameters.AddWithValue("@Group_ID", GroupId);
        int ret = cmd.ExecuteNonQuery();

        closeCon();
        dispose();
        return ret;

    }

    public int updateUser
                            (
                            Int64 Agent_UserID,
                            string FullName,
                            string Address,
                            string Phone,
                            string Mobile,
                            string Email,
                            string Status,
                            string City,
                            string LoginId,
                            string Password,
                            string AirAccess,
                            Int64 GroupId
                          )
    {
        string strProcedure = "uspUpdateUser";
        openCon();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = strProcedure;
        
        cmd.Parameters.AddWithValue("@Full_Name", FullName);
        cmd.Parameters.AddWithValue("@Address", Address);
        cmd.Parameters.AddWithValue("@Phone", Phone);
        cmd.Parameters.AddWithValue("@Mobile", Mobile);
        cmd.Parameters.AddWithValue("@Email", Email);
        cmd.Parameters.AddWithValue("@Status", Status);
        cmd.Parameters.AddWithValue("@Belongs_To_City", City);
        cmd.Parameters.AddWithValue("@Login_id", LoginId);
        cmd.Parameters.AddWithValue("@Login_Password", Password);
        cmd.Parameters.AddWithValue("@Airline_Access", AirAccess);
        cmd.Parameters.AddWithValue("@Agent_or_User_ID", Agent_UserID);
        cmd.Parameters.AddWithValue("@Group_ID", GroupId);

        int ret = cmd.ExecuteNonQuery();

        closeCon();
        dispose();

        return ret;

    }


	public AddUserClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}
