using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace GccSystem
{
    public interface addairlinepro
    {
        Int32 p_alcd
        {
            get;
            set;
        }
        string p_Belongs2city
        {
            get;
            set;
        }
        string p_altxtcd
        {
            get;
            set;
        }
        string p_alname
        {
            get;
            set;
        }

        string p_deal
        {
            get;
            set;
        }

       Int32 p_awbda
        {
            get;
            set;
        }

        Int32 p_awbdc
        {
            get;
            set;
        }
        Int32 p_dbc
        {
            get;
            set;

        }

        string p_fsc
        {
            get;
            set;

        }
        string p_fsccharged
        {
            get;
            set;
        }

        string p_wsc
        {
            get;
            set;
        }

        string p_wsccharged
        {
            get;
            set;
            
        }

        string p_compname
        {
            get;
            set;
        }

        string p_compaddress1
        {
            get;
            set;
        }

        string p_city
        {
            get;
            set;
        }

        string p_Phone
        {
            get;
            set;
        }
        
        
    }

    public class addairline_new : clsConnection, addairlinepro
    {
        private Int32 alcd;
        private string Belongs2city;
        private string altxtcd;
        private string alname;
        private string deal;
        private Int32 awbda;
        private Int32 awbdc;
        private Int32 dbc;
        private string fsc;
        private string fsccharged;
        private string wsc;
        private string wsccharged;
        private string compname;
        private string compaddress1;
        private string city;
        private string phone;


        private void create_para(SqlCommand cmd, eInputType typ)
        {
            SqlParameter P1 = new SqlParameter("@alcd", SqlDbType.BigInt);
            SqlParameter p2 = new SqlParameter("@Belongs2city", SqlDbType.VarChar);
            SqlParameter p3 = new SqlParameter("@altxtcd", SqlDbType.VarChar);
            SqlParameter p4 = new SqlParameter("@alname", SqlDbType.VarChar);
            SqlParameter p5 = new SqlParameter("@deal", SqlDbType.VarChar);
            SqlParameter p6 = new SqlParameter("@awbda", SqlDbType.Int);
            SqlParameter p7 = new SqlParameter("@awbdc", SqlDbType.Int);
            SqlParameter p8 = new SqlParameter("@dbc", SqlDbType.Int);
            SqlParameter p9 = new SqlParameter("@fsc", SqlDbType.VarChar);
            SqlParameter p10 = new SqlParameter("@fscCharged", SqlDbType.VarChar);
            SqlParameter p11 = new SqlParameter("@wsc", SqlDbType.VarChar);
            SqlParameter p12 = new SqlParameter("@wsccharged", SqlDbType.VarChar);
            SqlParameter p13 = new SqlParameter("@compname", SqlDbType.VarChar);
            SqlParameter p14 = new SqlParameter("@compaddress1", SqlDbType.VarChar);
            SqlParameter p15 = new SqlParameter("@city", SqlDbType.VarChar);
            SqlParameter p16 = new SqlParameter("@phone", SqlDbType.VarChar);
            if (typ == eInputType.save)
            {
                
                cmd.Parameters.Add(P1).Value = alcd;
                cmd.Parameters.Add(p2).Value = Belongs2city;
                cmd.Parameters.Add(p3).Value = altxtcd;
                cmd.Parameters.Add(p4).Value = alname;
                cmd.Parameters.Add(p5).Value = deal;
                cmd.Parameters.Add(p6).Value = awbda;
                cmd.Parameters.Add(p7).Value = awbdc;
                cmd.Parameters.Add(p8).Value = dbc;
                cmd.Parameters.Add(p9).Value = fsc;
                cmd.Parameters.Add(p10).Value = fsccharged;
                cmd.Parameters.Add(p11).Value = wsc;
                cmd.Parameters.Add(p12).Value = wsccharged;
                cmd.Parameters.Add(p13).Value = compname;
                cmd.Parameters.Add(p14).Value = compaddress1;
                cmd.Parameters.Add(p15).Value = city;
                cmd.Parameters.Add(p16).Value = phone;

            }
            else if (typ == eInputType.update)
            {
                cmd.Parameters.Add(P1).Value = alcd;
                cmd.Parameters.Add(p2).Value = Belongs2city;
                cmd.Parameters.Add(p3).Value = altxtcd;
                cmd.Parameters.Add(p4).Value = alname;
                cmd.Parameters.Add(p5).Value = deal;
                cmd.Parameters.Add(p6).Value = awbda;
                cmd.Parameters.Add(p7).Value = awbdc;
                cmd.Parameters.Add(p8).Value = dbc;
                cmd.Parameters.Add(p9).Value = fsc;
                cmd.Parameters.Add(p10).Value = fsccharged;
                cmd.Parameters.Add(p11).Value = wsc;
                cmd.Parameters.Add(p12).Value = wsccharged;
                cmd.Parameters.Add(p13).Value = compname;
                cmd.Parameters.Add(p14).Value = compaddress1;
                cmd.Parameters.Add(p15).Value = city;
                cmd.Parameters.Add(p16).Value = phone;
            }
            else if (typ == eInputType.delete)
            {
                cmd.Parameters.Add(P1).Value = alcd;
            }


            else
            {
                cmd.Parameters.Add(P1).Value = alcd;
            }

            cmd.ExecuteNonQuery();
        }
        public addairline_new()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        #region intMethods Members

        public void save()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("gccs_addairline", con);
            cmd.CommandType = CommandType.StoredProcedure;
            create_para(cmd, eInputType.save);
            cmd.Dispose();
            con.Close();
        }

        public void find(object alcd)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand("gccs_Edit_Airline", con);
            cmd.CommandType = CommandType.StoredProcedure;

            create_para(cmd, eInputType.find);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                alcd = Convert.ToInt32(dr["alcd"]);
                Belongs2city = Convert.ToString(dr["Belongs2city"]);
               altxtcd = Convert.ToString(dr["altxtcd"]);
               alname = Convert.ToString(dr["alname"]);
                deal = Convert.ToString(dr["deal"]);
                awbda = Convert.ToInt32(dr["awbda"]);
                awbdc = Convert.ToInt32(dr["awbdc"]);
                dbc = Convert.ToInt32(dr["dbc"]);
                fsc = Convert.ToString(dr["fsc"]);
               fsccharged = Convert.ToString(dr["fsccharged"]);
                wsc = Convert.ToString(dr["wsc"]);
                wsccharged = Convert.ToString(dr["wsccharged"]);
                compname = Convert.ToString(dr["compname"]);
                compaddress1 = Convert.ToString(dr["compaddress1"]);
               city = Convert.ToString(dr["city"]);
                phone = Convert.ToString(dr["phone"]);
               
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }

        public void delete()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("sp_deleteusermaster", con);
            cmd.CommandType = CommandType.StoredProcedure;
            create_para(cmd, eInputType.delete);
            cmd.Dispose();
            con.Close();
        }

        public void update()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("gccs_Update_airLine", con);
            cmd.CommandType = CommandType.StoredProcedure;
            create_para(cmd, eInputType.update);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }


        #endregion
        #region addairlinepro Members

        int addairlinepro.p_alcd
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_Belongs2city
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_altxtcd
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_alname
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_deal
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        Int32 addairlinepro.p_awbda
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        Int32 addairlinepro.p_awbdc
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        Int32 addairlinepro.p_dbc
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        string addairlinepro.p_fsc
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_fsccharged
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_wsc
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_wsccharged
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_compname
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_compaddress1
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_city
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        string addairlinepro.p_Phone
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        #endregion

        #region addairlinepro Members
        public Int32 p_alcd
        {
            get
            {
                return alcd;
            }
            set
            {
                alcd = value;
            }
        }

        public string p_Belongs2city
        {
            get
            {
                return Belongs2city;
            }
            set
            {
                Belongs2city = value;
            }
        }

        public string p_altxtcd
        {
            get
            {
                return altxtcd;
            }
            set
            {
                altxtcd = value;
            }
        }

        public string p_alname
        {
            get
            {
                return alname;
            }
            set
            {
                alname = value;
            }
        }

        public string p_deal
        {
            get
            {
                return deal;
            }
            set
            {
                deal = value;
            }
        }

        public Int32 p_awbda
        {
            get
            {
                return awbda;
            }
            set
            {
                awbda = value;
            }
        }

        public Int32 p_awbdc
        {
            get
            {
                return awbdc;
            }
            set
            {
                awbdc = value;
            }
        }

       public Int32 p_dbc
        {
            get
            {
                return dbc;
            }
            set
            {
                dbc = value;
            }
        }

        public string p_fsc
        {
            get
            {
                return fsc;
            }
            set
            {
                fsc = value;
            }
        }

        public string p_fsccharged
        {
            get
            {
                return fsccharged;
            }
            set
            {
                fsccharged = value;
            }
        }

        public string p_wsc
        {
            get
            {
                return wsc;
            }
            set
            {
                wsc = value;
            }
        }

        public string p_wsccharged
        {
            get
            {
                return wsccharged;
            }
            set
            {
                wsccharged = value;
            }
        }

        public string p_compname
        {
            get
            {
                return compname;
            }
            set
            {
                compname = value;
            }
        }

        public string p_compaddress1
        {
            get
            {
                return compaddress1;
            }
            set
            {
                compaddress1 = value;
            }
        }

        public string p_city
        {
            get
            {
                return city;
            }
            set
            {
               city = value;
            }
        }

        public string p_phone
        {
            get
            {
                return phone;
            }
            set
            {
                phone = value;
            }
        }
        #endregion

    }
}