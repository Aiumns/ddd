using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace GccSystem
{
    public interface addagentint
    {
        string I_Agentname
        {
            get;
            set;
        }
        string I_Agent_Address
        {
            get;
            set;
        }
        string I_Agent_Phone
        {
            get;
            set;
        }
        string I_Agent_Fax
        {
            get;
            set;
        }

        string I_Agent_Email
        {
            get;
            set;
        }

        string I_Concern_person
        {
            get;
            set;
        }
        string I_IATANO
        {
            get;
            set;
        }
        Int32 I_IATA_COMM
        {
            get;
            set;
        }
        string I_Panno
        {
            get;
            set;
        }
        Int32 I_TDS
        {
            get;
            set;
        }
        Int32 I_Surcahrge
        {
            get;
            set;
        }
        string I_Contact_person
        {
            get;
            set;
        }
        string I_csr_email
        {
            get;
            set;
        }
        Int32 I_tds_rate
        {
            get;
            set;
        }
        Int32 I_exemption_limit
        {
            get;
            set;
        }
        string I_exmpt_date
        {
            get;
            set;
        }
        Int32 I_alcd
        {
            get;
            set;
        }
    }

    public class addagent_new : clsConnection, addagentint
    {
        private string Agentname;
        private string Agent_Address;
        private string Agent_Phone;
        private string Agent_Fax;
        private string Agent_Email;
        private string Concern_person;
        private string IATANo;
        private Int32 IATA_COMM;
        private string PANNO;
        private Int32 TDS;
        private Int32 Surcharge;
        private string Contact_Person;
        private string Csr_Email;
        private Int32 tds_rate;
        private Int32 exemption_limit;
        private string exmpt_date;
        private Int32 agentCd;


        private void create_para(SqlCommand cmd, eInputType typ)
        {
            SqlParameter P0 = new SqlParameter("@agentCd", SqlDbType.Int);
            SqlParameter P1 = new SqlParameter("@Agentname", SqlDbType.VarChar);
            SqlParameter p2 = new SqlParameter("@Agent_Address", SqlDbType.VarChar);
            SqlParameter p3 = new SqlParameter("@Agent_Phone", SqlDbType.VarChar);
            SqlParameter p4 = new SqlParameter("@Agent_Fax", SqlDbType.VarChar);
            SqlParameter p5 = new SqlParameter("@Agent_Email", SqlDbType.VarChar);
            SqlParameter p6 = new SqlParameter("@Concern_person", SqlDbType.VarChar);
            SqlParameter p7 = new SqlParameter("@IATANo", SqlDbType.VarChar);
            SqlParameter p8 = new SqlParameter("@IATA_COMM", SqlDbType.Int);
            SqlParameter p9 = new SqlParameter("@PANNO", SqlDbType.VarChar);
            SqlParameter p10 = new SqlParameter("@TDS", SqlDbType.Int);
            SqlParameter p11 = new SqlParameter("@Surcharge", SqlDbType.Int);
            SqlParameter p12 = new SqlParameter("@Contact_Person", SqlDbType.VarChar);
            SqlParameter p13 = new SqlParameter("@Csr_Email", SqlDbType.VarChar);
            SqlParameter p14 = new SqlParameter("@tds_rate", SqlDbType.Int);
            SqlParameter p15 = new SqlParameter("@exemption_limit", SqlDbType.Int);
            SqlParameter p16 = new SqlParameter("@exmpt_date", SqlDbType.VarChar);



            if (typ == eInputType.save)
            {
                //cmd.Parameters.Add(p1).Value = user_code;
                cmd.Parameters.Add(P1).Value = Agentname;
                cmd.Parameters.Add(p2).Value = Agent_Address;
                cmd.Parameters.Add(p3).Value = Agent_Phone;
                cmd.Parameters.Add(p4).Value = Agent_Fax;
                cmd.Parameters.Add(p5).Value = Agent_Email;
                cmd.Parameters.Add(p6).Value = Concern_person;
                cmd.Parameters.Add(p7).Value = IATANo;
                cmd.Parameters.Add(p8).Value = IATA_COMM;
                cmd.Parameters.Add(p9).Value = PANNO;
                cmd.Parameters.Add(p10).Value = TDS;
                cmd.Parameters.Add(p11).Value = Surcharge;
                cmd.Parameters.Add(p12).Value = Contact_Person;
                cmd.Parameters.Add(p13).Value = Csr_Email;
                cmd.Parameters.Add(p14).Value = tds_rate;
                cmd.Parameters.Add(p15).Value = exemption_limit;
                cmd.Parameters.Add(p16).Value = exmpt_date;

            }
            else if (typ == eInputType.update)
            {
                cmd.Parameters.Add(P0).Value = agentCd;
                cmd.Parameters.Add(P1).Value = Agentname;
                cmd.Parameters.Add(p2).Value = Agent_Address;
                cmd.Parameters.Add(p3).Value = Agent_Phone;
                cmd.Parameters.Add(p4).Value = Agent_Fax;
                cmd.Parameters.Add(p5).Value = Agent_Email;
                cmd.Parameters.Add(p6).Value = Concern_person;
                cmd.Parameters.Add(p7).Value = IATANo;
                cmd.Parameters.Add(p8).Value = IATA_COMM;
                cmd.Parameters.Add(p9).Value = PANNO;
                cmd.Parameters.Add(p10).Value = TDS;
                cmd.Parameters.Add(p11).Value = Surcharge;
                cmd.Parameters.Add(p12).Value = Contact_Person;
                cmd.Parameters.Add(p13).Value = Csr_Email;
                cmd.Parameters.Add(p14).Value = tds_rate;
                cmd.Parameters.Add(p15).Value = exemption_limit;
                cmd.Parameters.Add(p16).Value = exmpt_date;


            }
            else
            { cmd.Parameters.Add(P0).Value = agentCd; }
            cmd.ExecuteNonQuery();

        }

        #region intMethods Members
        public void save()
        {
            SqlTransaction tr = null;
            try
            {

                con.Open();
                tr = con.BeginTransaction();
                SqlCommand cmd = new SqlCommand("gccs_addagent", con, tr);
                cmd.CommandType = CommandType.StoredProcedure;
                create_para(cmd, eInputType.save);
                tr.Commit();
                cmd.Dispose();
                con.Close();

            }
            catch (SqlException sqle)
            {
                String err = sqle.ToString();

                tr.Rollback();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            }
        }

        public void find(object agentCd)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand("EDIT_AGENTDETAILS", con);
            cmd.CommandType = CommandType.StoredProcedure;

            create_para(cmd, eInputType.find);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();

                Agentname = Convert.ToString(dr["agentName"]);
                Agent_Address = Convert.ToString(dr["agentAdd"]);
                Agent_Phone = Convert.ToString(dr["agPhone"]);
                Agent_Fax = Convert.ToString(dr["agFax"]);
                Agent_Email = Convert.ToString(dr["agEmail"]);
                Concern_person = Convert.ToString(dr["agConcern"]);
                IATANo = Convert.ToString(dr["iataCd"]);
                IATA_COMM = Convert.ToInt32(dr["iataComm"]);
                PANNO = Convert.ToString(dr["panno"]);
                TDS = Convert.ToInt32(dr["tds"]);
                Surcharge = Convert.ToInt32(dr["surCharge"]);
                Contact_Person = Convert.ToString(dr["csr_cont_person"]);
                Csr_Email = Convert.ToString(dr["csr_email"]);
                tds_rate = Convert.ToInt32(dr["tds_rate"]);
                exemption_limit = Convert.ToInt32(dr["exemption_limit"]);
                exmpt_date = Convert.ToString(dr["exmpt_date"]);

            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }


        public void update()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("gccs_Update_Agent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            create_para(cmd, eInputType.update);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        #endregion


        #region addagentint Members
        public string I_Agentname
        {
            get
            {
                return Agentname;
            }
            set
            {
                Agentname = value;
            }
        }

        public string I_Agent_Address
        {
            get
            {
                return Agent_Address;
            }
            set
            {
                Agent_Address = value;
            }
        }

        public string I_Agent_Phone
        {
            get
            {
                return Agent_Phone;
            }
            set
            {
                Agent_Phone = value;
            }
        }

        public string I_Agent_Fax
        {
            get
            {
                return Agent_Fax;
            }
            set
            {
                Agent_Fax = value;
            }
        }

        public string I_Agent_Email
        {
            get
            {
                return Agent_Email;
            }
            set
            {
                Agent_Email = value;
            }
        }

        public string I_Concern_person
        {
            get
            {
                return Concern_person;
            }
            set
            {
                Concern_person = value;
            }
        }
        public string I_IATANO
        {
            get
            {
                return IATANo;
            }
            set
            {
                IATANo = value;
            }
        }
        public Int32 I_IATA_COMM
        {
            get
            {
                return IATA_COMM;
            }
            set
            {
                IATA_COMM = value;
            }
        }
        public string I_Panno
        {
            get
            { return PANNO; }
            set
            { PANNO = value; }
        }
        public Int32 I_TDS
        {
            get { return TDS; }
            set { TDS = value; }
        }
        public Int32 I_Surcahrge
        {
            get { return Surcharge; }
            set { Surcharge = value; }
        }
        public string I_Contact_person
        {
            get { return Contact_Person; }
            set { Contact_Person = value; }
        }
        public string I_csr_email
        {
            get { return Csr_Email; }
            set { Csr_Email = value; }
        }

        public Int32 I_tds_rate
        {
            get { return tds_rate; }
            set { tds_rate = value; }
        }
        public Int32 I_exemption_limit
        {
            get { return exemption_limit; }
            set { exemption_limit = value; }
        }
        public string I_exmpt_date
        {
            get { return exmpt_date; }
            set { exmpt_date = value; }
        }
        public Int32 I_alcd
        {
            get { return agentCd; }
            set { agentCd = value; }
        }

    }
        #endregion










}