using System;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.Security;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public class BLWrap
{
    #region declarations
    SqlConnection SqlCON = new SqlConnection();
    SqlCommand SqlCMD = new SqlCommand();
    SqlDataAdapter SqlDA = new SqlDataAdapter();
    public DataSet DS = new DataSet();
   
    #endregion declarations
    
    public BLWrap()
    {
        SqlCON = Util.getcon();
    }
    public Boolean SetDDL(DataSet DS, DropDownList DDL, string TableName, string DisplayFieldName, string PrimaryKey) 
    {
        DDL.DataSource = DS.Tables[TableName];
        DDL.DataTextField = DisplayFieldName;
        DDL.DataValueField = PrimaryKey;
        DDL.DataBind();
        DDL.Items.Insert(0, "- - Select - -");
        DDL.Items[0].Value = "0";
        return true;
    }
    public Boolean SetDropDownList(DropDownList DDL, string Query, string TableName, string DisplayFieldName, string PrimaryKey, string OrderBY)
    {
        string strSQLQuery = Query;
        if (strSQLQuery != "")
        {
            if (OrderBY != "")
            {
                strSQLQuery = strSQLQuery + " Order By " + OrderBY;
            }
            SetDataSet(DS, strSQLQuery, TableName, PrimaryKey);
            DDL.DataSource = DS.Tables[TableName];
            DDL.DataTextField = DisplayFieldName;
            DDL.DataValueField = PrimaryKey;
            DDL.DataBind();
        }
        DDL.Items.Insert(0, "- - Select - -");
        DDL.Items[0].Value = "0";
        return true;
    }

    public Boolean SetListBox(ListBox LB, string Query, string TableName, string DisplayFieldName, string PrimaryKey, string WhereCondition, string OrderBY)
    {
        string strSQLQuery = Query;
        if (strSQLQuery != "")
        {
            if (WhereCondition != "")
            {
                strSQLQuery = strSQLQuery + " Where " + WhereCondition;
            }
            if (OrderBY != "")
            {
                strSQLQuery = strSQLQuery + " Order By " + OrderBY;
            }
            SetDataSet(DS, strSQLQuery, TableName, PrimaryKey);
            LB.DataSource = DS.Tables[TableName];
            LB.DataTextField = DisplayFieldName;
            LB.DataValueField = PrimaryKey;
            LB.DataBind();
        }
        LB.Items.Insert(0, "- - Select - -");
        LB.Items[0].Value = "0";
        return true;
    }
    public void SetDataSet(DataSet DS, string SQLQuery, string TableName, string PrimaryKey)
    {
        if (DS.Tables.Contains(TableName) == false)
        {
            SqlCMD = new SqlCommand(SQLQuery, SqlCON);
            SqlDA.SelectCommand = SqlCMD;
            SqlDA.Fill(DS, TableName);
            SetPrimaryKey(TableName, PrimaryKey);
        }
    }
    public void SetPrimaryKey(string TableName, string PK_FieldName)
    {
        DataTable dt;
        dt = DS.Tables[TableName];
        dt.PrimaryKey = new DataColumn[] { dt.Columns[PK_FieldName] };
        dt.Columns[PK_FieldName].AutoIncrement = true;
    }
}