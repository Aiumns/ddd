﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Text;

/// <summary>
/// Summary description for GetCityName
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class GetCityName : System.Web.Services.WebService {

    public GetCityName () {
        GetName();
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string GetName()
    {
        StringBuilder sbCityName = new StringBuilder();
        sbCityName.AppendFormat("{0}:", "MAnoj");
        sbCityName.AppendFormat("{0}:", "MAnoj1");
        sbCityName.AppendFormat("{0}:", "MAnoj2");
        sbCityName.AppendFormat("{0}:", "MAnoj3");
        sbCityName.AppendFormat("{0}:", "MAnoj4");
        sbCityName.AppendFormat("{0}:", "MAnoj5");
        sbCityName.AppendFormat("{0}:", "MAnoj6");
        sbCityName = sbCityName.Remove(sbCityName.Length - 1, 1);
        return sbCityName.ToString();


    }
    
}

