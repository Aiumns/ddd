﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WimdowsControls.Web.UI
{
    public class RequiredTextBox : TextBox
    {
        private RequiredFieldValidator req;
        public string InvalidMessage;
        public string ClientScript = "true";

        protected override void OnInit(EventArgs e)
        {
            req = new RequiredFieldValidator();
            req.ControlToValidate = this.ID;
            req.ErrorMessage = this.InvalidMessage;
            req.EnableClientScript = (this.ClientScript.ToLower() != "false");
            Controls.Add(req);
        }

        protected override void Render(HtmlTextWriter w)
        {
            base.Render(w);
            req.RenderControl(w);
        }
    }
}