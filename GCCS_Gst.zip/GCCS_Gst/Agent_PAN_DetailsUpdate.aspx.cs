using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Agent_PAN_DetailsUpdate : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        else if (!IsPostBack && Request.QueryString["sno"].ToString() != "")
        {
            DataTable dt_agent = dw.GetAllFromQuery("SELECT pan_no,tan_no from agent_branch  where Agent_branch_ID=" + Request.QueryString["sno"].ToString() + "");
            if (dt_agent.Rows.Count > 0)
            {
                txtPAN.Text = dt_agent.Rows[0]["pan_no"].ToString();
                txtTAN.Text = dt_agent.Rows[0]["tan_no"].ToString();
            }
        }

    }
    protected void btnPANUpdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        try
        {
          con.Open();
          cmd = new SqlCommand("update Agent_Branch set Pan_no=@Pan_no,tan_no=@Tan_no where Agent_branch_id='" + Request.QueryString["sno"].ToString() + "'", con);

          cmd.Parameters.AddWithValue("@Pan_no", txtPAN.Text);
          cmd.Parameters.AddWithValue("@Tan_no", txtTAN.Text);       
          cmd.ExecuteNonQuery();
          cmd.Dispose();
          con.Close();
          Response.Redirect("Agent_PAN_Details.aspx");
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
     }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Agent_PAN_Details.aspx");

    }
}
