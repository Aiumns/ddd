﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class LoginSuccess : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand com = null;
    string TablePerformance = "";
    decimal sumPreTonnage = 0;
    decimal sumCurTonnage = 0;

    decimal SmallsumPreTonnage = 0;
    decimal SmallsumCurTonnage = 0;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        string Tables = "";


        string query_status = "select status_name from group_master inner join status_master on status_id=booking_handover_details where group_id=" + Convert.ToInt64(Session["groupid"].ToString()) + "";

        DataTable dtw = dw.GetAllFromQuery(query_status);

        if (dtw.Rows[0]["status_name"].ToString() == "Yes")
        {
            //HyperLink1.Visible = false;
            if (Session["groupid"].ToString() != "1")
            {
              //  tblPerformance.Visible = true;
                //Ascent_Performance();
                //AccountWiseTonnage();
                //CapTarGet();
            }
        }
        else
        {
            trflightstatus.Visible = false;
            ///HyperLink1.Visible = false;
            //Tables += @"<object classid=""clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"" codebase=""http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0"" width=""800"" height=""270""><param name=""movie"" value=""flash_cpp1.swf"" /><param name=""quality"" value=""high"" /><embed src=""flash_cpp1.swf"" quality=""high"" pluginspage=""http://www.macromedia.com/go/getflashplayer"" type=""application/x-shockwave-flash"" width=""735"" height=400 bgcolor=#F2FEF9 ></embed></object>";
           // Tables += @"<div style='padding-top: 20px;padding-left: 20px;'><table><tr><td><img src='images/CppAlert.gif'/></td></tr></table><div>";
            Tables += @"<div style='padding-top: 20px;padding-left: 20px;'><table><tr><td></td></tr></table><div>";
            Label3.Text = Tables;
            if (Session["groupid"].ToString() == "5")
            {
                lblAgShow.Visible = true;
                TdSMsg.Visible = true;
                string strtb = "";
                lblAgShow.Text = strtb;
                string stMsg = "<table style=font: caption; text-align: left; border-top: purple thin dotted; border-right-style: dotted; border-left-style: dotted; border-bottom-style: dotted; width=100% border=0><tr><td style=height: 20px;color: olive colspan=3>FORM-16A ARE READY, PLEASE COLLECT THE SAME AND PROVIDE US OUR FORM-16A AS EARLY AS POSSIBLE</td></tr></table>";
                lblMessage.Text = stMsg;
                DataTable stshow = dw.GetAllFromQuery("select agent_branch_id,pan_no,tan_no from Agent_master AM inner join agent_branch AB on AB.Agent_id=am.agent_id where ab.agent_branch_id=" + Session["ID"].ToString() + " and ab.belongs_to_city=" + Session["BELONG_TO_CITY"] + "");
                if (stshow.Rows.Count > 0)
                {
                    //grddetails.DataSource = stshow;
                    //grddetails.DataBind();
                }

                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Dear Sir/Mam, As decided by GST council (Government of India) meeting held on 18.06.2017, GST will be implemented wef 01.07.2017. As per Sec12(8) of IGST Act, as the service provider and the service receiver both are located in taxable territory of India, transportation of goods from India to outside India would be taxable.Accordingly wef 01.07.2017, Export Air Freight will be taxable under GST and GST will be charged @18% on Freight plus Due Carrier minus Discount. IATA commission will be shown in CSR/Tax Invoice for the calculation of Net receivable. Further IATA agent will raise invoice for IATA commission along with GST after the fortnight as it is sale/income of IATA agents in order to claim GST.');</script>");
                #region NOC Form
                //String airline_access = Session["AIRLINEACCESS"].ToString();
                //DataTable dtCompanyId = dw.GetAllFromQuery("SELECT Company_ID,Company_Name FROM db_owner.Company_Master WHERE Company_ID in (select am.Company_ID from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID INNER JOIN db_owner.Company_Master cm ON am.Company_ID=cm.Company_ID where ad.airline_Detail_id in (" + airline_access + ")  and cm.Parent_ID='0' AND cm.Company_ID NOT IN (109))");
                //if (dtCompanyId.Rows.Count > 0)
                //{
                //    for (int i = 0; i < dtCompanyId.Rows.Count; i++)
                //    {
                //        if (dtCompanyId.Rows[i]["Company_ID"].ToString() == "106")
                //        {
                //            AcumenNocForm.Visible = true;
                //        }
                //        if (dtCompanyId.Rows[i]["Company_ID"].ToString() == "108")
                //        {
                //            AscentNocForm.Visible = true;
                //        }
                //    }
                //}

                #endregion
            }
        }
    }


    protected void Modify(object sender, CommandEventArgs e)
    {
        Session["AGID"] = e.CommandName;
        Response.Redirect("Tan_Change.aspx");
    }


    protected void Ascent_Performance()
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand("Ascent_Performance", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Email_ID", Session["EMailID"].ToString());
        SqlDataAdapter sda = new SqlDataAdapter(com);
        DataSet dsPerformance = new DataSet();
        sda.Fill(dsPerformance);
        if (dsPerformance.Tables[6].Rows.Count > 0)
        {

            TablePerformance = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding><tr class=HeaderStyle2><td>Period</td><td align=center><=500</td><td>>500</td></tr><tr class=tabletd><td>" + dsPerformance.Tables[7].Rows[0]["PreviousDate"].ToString() + "(Previous Month)</td>";
            if (dsPerformance.Tables[0].Rows.Count > 0)
            {
                //string totaltonnage = dsPerformance.Tables[0].Compute("Sum(Tonnage)","").ToString();
                TablePerformance += @"<td align=right>" + dsPerformance.Tables[0].Compute("Sum(Tonnage)", "").ToString() + "</td>";
            }
            else
                TablePerformance += @"<td align=right>0</td>";
            if (dsPerformance.Tables[2].Rows.Count > 0)
                TablePerformance += @"<td align=right>" + dsPerformance.Tables[2].Compute("Sum(Tonnage)", "").ToString() + "</td>";
            else
                TablePerformance += @"<td align=right>0</td>";

            TablePerformance += @"</tr><tr class=tabletd><td >" + dsPerformance.Tables[7].Rows[0]["CurrentDate"].ToString() + "(Current Month)</td>";
            if (dsPerformance.Tables[3].Rows.Count > 0)
                TablePerformance += @"<td align=right>" + dsPerformance.Tables[3].Compute("Sum(Tonnage)", "").ToString() + "</td>";
            else
                TablePerformance += @"<td align=right>0</td>";
            if (dsPerformance.Tables[5].Rows.Count > 0)
                TablePerformance += @"<td align=right>" + dsPerformance.Tables[5].Compute("Sum(Tonnage)", "").ToString() + "</td>";
            else
                TablePerformance += @"<td align=right>0</td>";
            TablePerformance += @"</tr><tr><td colspan=3><br/></td></tr>";


            TablePerformance += @"<tr class=HeaderStyle1><td align=center>Airline Tonnage</td><td align=center>" + dsPerformance.Tables[7].Rows[0]["PreviousDate"].ToString() + "(Previous Month)</td><td align=center>" + dsPerformance.Tables[7].Rows[0]["CurrentDate"].ToString() + "(Current Month)</td></tr>";

            string oldAirlinecode = dsPerformance.Tables[6].Rows[0]["Airline_Text_Code"].ToString();
            string newAirlinecode = "";

            for (int i = 0; i < dsPerformance.Tables[6].Rows.Count; i++)
            {
                newAirlinecode = dsPerformance.Tables[6].Rows[i]["Airline_Text_Code"].ToString();

                if (oldAirlinecode == newAirlinecode)
                {
                    sumCurTonnage += dsPerformance.Tables[4].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[4].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    sumPreTonnage += dsPerformance.Tables[1].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[1].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;

                    //----for small shipment-----
                    SmallsumCurTonnage += dsPerformance.Tables[3].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[3].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    SmallsumPreTonnage += dsPerformance.Tables[0].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[0].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;

                }
                else
                {
                    TablePerformance += @"<tr class=tabletd><td>" + oldAirlinecode + " Tonnage</td><td align=right>" + sumPreTonnage.ToString("0.00") + "</td><td align=right>" + sumCurTonnage.ToString("0.00") + "</td></tr>";
                    TablePerformance += @"<tr class=tabletd><td>" + oldAirlinecode + " Small Tonnage</td><td align=right>" + SmallsumPreTonnage.ToString("0.00") + "</td><td align=right>" + SmallsumCurTonnage.ToString("0.00") + "</td></tr>";
                    oldAirlinecode = dsPerformance.Tables[6].Rows[i]["Airline_Text_Code"].ToString();
                    sumCurTonnage = 0;
                    sumPreTonnage = 0;
                    sumCurTonnage += dsPerformance.Tables[4].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[4].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    sumPreTonnage += dsPerformance.Tables[1].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[1].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;

                    //----for small shipment-----
                    SmallsumCurTonnage = 0;
                    SmallsumPreTonnage = 0;
                    SmallsumCurTonnage += dsPerformance.Tables[3].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[3].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    SmallsumPreTonnage += dsPerformance.Tables[0].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsPerformance.Tables[0].Select("Airline_Detail_ID=" + dsPerformance.Tables[6].Rows[i]["Airline_Detail_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;

                }
            }
            TablePerformance += @"<tr class=tabletd><td>" + oldAirlinecode + " Tonnage</td><td align=right>" + sumPreTonnage.ToString("0.00") + "</td><td align=right>" + sumCurTonnage.ToString("0.00") + "</td></tr>";
            TablePerformance += @"<tr class=tabletd><td>" + oldAirlinecode + " Small Tonnage</td><td align=right>" + SmallsumPreTonnage.ToString("0.00") + "</td><td align=right>" + SmallsumCurTonnage.ToString("0.00") + "</td></tr>";
            TablePerformance += @"</table>";
           // lblPerformance.Visible = true;
          //  lblPerformance.Text = TablePerformance.ToString();
        }
    }
    protected void AccountWiseTonnage()
    {
        sumCurTonnage = 0;
        sumPreTonnage = 0;
        SmallsumCurTonnage = 0;
        SmallsumPreTonnage = 0;
        con = new SqlConnection(strCon);
        com = new SqlCommand("Get_AccountWiseTonnage", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Email_ID", Session["EMailID"].ToString());
        SqlDataAdapter sda = new SqlDataAdapter(com);
        DataSet dsAccount = new DataSet();
        sda.Fill(dsAccount);
        if (dsAccount.Tables[4].Rows.Count > 0)
        {
            TablePerformance = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
            TablePerformance += @"<tr class=HeaderStyle1><td align=center>Agent Name</td><td align=center colspan=2>" + dsAccount.Tables[5].Rows[0]["PreviousDate"].ToString() + "(Previous Month)</td><td align=center colspan=2>" + dsAccount.Tables[5].Rows[0]["CurrentDate"].ToString() + "(Current Month)</td></tr><tr class=HeaderStyle2><td></td><td><=500</td><td>>500</td><td><=500</td><td>>500</td></tr>";
            string OldUserID = dsAccount.Tables[4].Rows[0]["USER_ID"].ToString();
            string NewUserID = "";
            string Name = "";
            for (int i = 0; i < dsAccount.Tables[4].Rows.Count; i++)
            {
                NewUserID = dsAccount.Tables[4].Rows[i]["USER_ID"].ToString();
                if (OldUserID == NewUserID)
                {
                    Name = dsAccount.Tables[4].Rows[i]["Full_Name"].ToString();
                    sumCurTonnage += dsAccount.Tables[1].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[1].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    sumPreTonnage += dsAccount.Tables[3].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[3].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;

                    //----for small shipment-----
                    SmallsumCurTonnage += dsAccount.Tables[0].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[0].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    SmallsumPreTonnage += dsAccount.Tables[2].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[2].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                }
                else
                {
                    TablePerformance += @"<tr class=tabletd><td>" + Name + " </td><td align=right>" + SmallsumPreTonnage.ToString("0.00") + "</td><td align=right>" + sumPreTonnage.ToString("0.00") + "</td><td align=right>" + SmallsumCurTonnage.ToString("0.00") + "</td><td align=right>" + sumCurTonnage.ToString("0.00") + "</td></tr>";
                    OldUserID = dsAccount.Tables[4].Rows[i]["USER_ID"].ToString();
                    Name = dsAccount.Tables[4].Rows[i]["Full_Name"].ToString();
                    sumCurTonnage = 0;
                    sumPreTonnage = 0;
                    sumCurTonnage += dsAccount.Tables[1].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[1].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    sumPreTonnage += dsAccount.Tables[3].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[3].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    //----for small shipment-----
                    SmallsumCurTonnage = 0;
                    SmallsumPreTonnage = 0;
                    SmallsumCurTonnage += dsAccount.Tables[0].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[0].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                    SmallsumPreTonnage += dsAccount.Tables[2].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "").Length > 0 ? decimal.Parse(dsAccount.Tables[2].Select("USER_ID=" + dsAccount.Tables[4].Rows[i]["USER_ID"].ToString() + "")[0].ItemArray[0].ToString()) : 0;
                }
            }
            TablePerformance += @"<tr class=tabletd><td>" + Name + " </td><td align=right>" + SmallsumPreTonnage.ToString("0.00") + "</td><td align=right>" + sumPreTonnage.ToString("0.00") + "</td><td align=right>" + SmallsumCurTonnage.ToString("0.00") + "</td><td align=right>" + sumCurTonnage.ToString("0.00") + "</td></tr>";
            if ((dsAccount.Tables[6].Rows.Count > 0) || (dsAccount.Tables[7].Rows.Count > 0) || (dsAccount.Tables[8].Rows.Count > 0) || (dsAccount.Tables[9].Rows.Count > 0))
            {
                TablePerformance += @"<tr class=tabletd><td>Others</td>";
                if (dsAccount.Tables[8].Rows.Count > 0)
                    TablePerformance += @"<td align=right>" + dsAccount.Tables[8].Rows[0]["Tonnage"] + " </td>";
                else
                    TablePerformance += @"<td align=right>0 </td>";
                if (dsAccount.Tables[9].Rows.Count > 0)
                    TablePerformance += @"<td align=right>" + dsAccount.Tables[9].Rows[0]["Tonnage"] + " </td>";
                else
                    TablePerformance += @"<td align=right>0 </td>";
                if (dsAccount.Tables[6].Rows.Count > 0)
                    TablePerformance += @"<td align=right>" + dsAccount.Tables[6].Rows[0]["Tonnage"] + " </td>";
                else
                    TablePerformance += @"<td align=right>0 </td>";
                if (dsAccount.Tables[7].Rows.Count > 0)
                    TablePerformance += @"<td align=right>" + dsAccount.Tables[7].Rows[0]["Tonnage"] + " </td>";
                else
                    TablePerformance += @"<td align=right>0 </td>";
                TablePerformance += @"</tr>";
            }
            TablePerformance += @"</table>";
          //  lblAccountWise.Visible = true;
           // lblAccountWise.Text = TablePerformance.ToString();
        }
    }
    protected void CapTarGet()
    {
        sumCurTonnage = 0;
        sumPreTonnage = 0;
        SmallsumCurTonnage = 0;
        SmallsumPreTonnage = 0;
        con = new SqlConnection(strCon);
        com = new SqlCommand("Get_CapTarget", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Email_ID", Session["EMailID"].ToString());
        SqlDataAdapter sda = new SqlDataAdapter(com);
        DataSet dsCapTar = new DataSet();
        sda.Fill(dsCapTar);
        if (dsCapTar.Tables[2].Rows.Count > 0)
        {
            TablePerformance = @"<table width=100%  align=center border=0 cellspacing=0 cellpadding=0 id=tdPadding>";
            TablePerformance += @"<tr class=HeaderStyle1><td colspan=3></td><td align=center colspan=2>" + dsCapTar.Tables[3].Rows[0]["PreviousDate"].ToString() + "(Previous Month)</td><td align=center colspan=2>" + dsCapTar.Tables[3].Rows[0]["CurrentDate"].ToString() + "(Current Month)</td></tr><tr class=HeaderStyle2><td>Flight No</td><td>Capacity</td><td>Target</td><td>CH.WT</td><td>% Achivement</td><td>CH.WT</td><td>% Achivement</td></tr>";
            for (int i = 0; i < dsCapTar.Tables[2].Rows.Count; i++)
            {
                sumCurTonnage += dsCapTar.Tables[0].Select("Flight_No='" + dsCapTar.Tables[2].Rows[i]["Flight_No"].ToString() + "'").Length > 0 ? decimal.Parse(dsCapTar.Tables[0].Select("Flight_No='" + dsCapTar.Tables[2].Rows[i]["Flight_No"].ToString() + "'")[0].ItemArray[0].ToString()) : 0;
                sumPreTonnage += dsCapTar.Tables[1].Select("Flight_No='" + dsCapTar.Tables[2].Rows[i]["Flight_No"].ToString() + "'").Length > 0 ? decimal.Parse(dsCapTar.Tables[1].Select("Flight_No='" + dsCapTar.Tables[2].Rows[i]["Flight_No"].ToString() + "'")[0].ItemArray[0].ToString()) : 0;
                TablePerformance += @"<tr class=tabletd><td>" + dsCapTar.Tables[2].Rows[i]["Flight_No"].ToString() + " </td><td align=right>" + dsCapTar.Tables[2].Rows[i]["Capacity"].ToString() + "</td><td align=right>0</td><td align=right>" + sumPreTonnage.ToString("0.00") + "</td><td>0</td><td align=right>" + sumCurTonnage.ToString("0.00") + "</td><td>0</td></tr>";
                sumCurTonnage = 0;
                sumPreTonnage = 0;
            }
            TablePerformance += @"</table>";
         //   lblCapTar.Visible = true;
         //   lblCapTar.Text = TablePerformance.ToString();
        }


    }
}
