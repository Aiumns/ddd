using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class LoginRecords : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Target = "_blank";
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if(!IsPostBack)
        {

            txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }
    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        Session["from"] = txtValidFrom.Text;
        Session["to"] = txtValidTo.Text;
        Session["rdbutton"] = rdorder.Text;
        Response.Redirect("LoginRecords_Show.aspx");
    }
}
