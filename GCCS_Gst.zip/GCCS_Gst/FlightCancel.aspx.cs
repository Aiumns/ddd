using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class FlightCancel : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["fltCancel"] != null)
            {
                string dd = Session["fltCancel"].ToString();
                Label1.Text = dd;
            }
            if (Request.QueryString["foid"] != null)
            {
               string table="";
                int flag = 0;
                string awb = "";
                //int fl_No = int.Parse(strFlightID.Trim());
                con = new SqlConnection(strcon);
                try
                {
                    con.Open();
                    com = new SqlCommand("select a.stock_id ,b.airwaybill_no from booking_master a inner join stock_master b on b.stock_id=a.stock_id where Flight_Open_ID=" + Request.QueryString["foid"].ToString() + " ", con);
                    SqlDataReader dr = com.ExecuteReader();

                    while (dr.Read())
                    {
                        if (awb == "")
                            awb += dr["airwaybill_no"].ToString();
                        awb += ", " + dr["airwaybill_no"].ToString();
                        flag = 1;
                    }
                    //Label1.Text = awb;
                    if (flag == 1)
                     {
                      table += "Sorry, the flight cancel by you contains AWB No. ";
                      table += awb;
                      table += " in booking. Please transfer these AWBs to another flight and then try again!";
                      Label1.Text = table;
                    //Session["fltCancel"] = table;
                       //string page_pop = "<SCRIPT language='javascript'>window.open('NewReportDrCr.aspx');</SCRIPT>";
                    //   string page_pop = "<SCRIPT language='javascript'>window.open('FlightCancel.aspx','mywin','left=20,top=20,width=300,height=200,toolbar=0,resizable=1,scrollbars=1');</SCRIPT>";
                    //    FillDataGv();
                    //    // rowColor();
                    //    com.Dispose();
                    //    dr.Dispose();
                    }
                    else
                    {
                       com.Dispose();
                        dr.Dispose();
                       // string page_pop = "<SCRIPT language='javascript'>confirm('Are you sure to Cancel? '); ;</SCRIPT>";
                       // ClientScript.RegisterStartupScript(GetType(), "", "<SCRIPT LANGUAGE='javascript'>confirm('Are you sure to Cancel? '); ;</script>");
                       // Response.Write(page_pop);

                        if (Request.QueryString["Action"].ToString() == "Cancel")
                            com = new SqlCommand("Update  flight_open set status=7,Last_Modified_By='" + Session["EMailID"].ToString() + "',Last_Modified_On='"+DateTime.Now+"' where flight_id=(select flight_id from flight_master where flight_no='" + Request.QueryString["fno"].ToString() + "') and convert(varchar,flight_Date,103)='" + Request.QueryString["fDate"].ToString() + "'", con);
                        else
                            com = new SqlCommand("Update  flight_open set status=35,Last_Modified_By='" + Session["EMailID"].ToString() + "',Last_Modified_On='" + DateTime.Now + "' where flight_id=(select flight_id from flight_master where flight_no='" + Request.QueryString["fno"].ToString() + "') and convert(varchar,flight_Date,103)='" + Request.QueryString["fDate"].ToString() + "'", con);
                        int result = com.ExecuteNonQuery();
                        com.Dispose();
                        con.Close();
                        if (result > 0)
                        {
                            if (Request.QueryString["Action"].ToString() == "Cancel")
                            Label1.Text = "Flight has been successfully Cancelled";
                            else
                                Label1.Text = "Flight has been successfully Nil manifested";
                        }
                    //    FillDataGv();
                    //    //rowColor();
                     }

                }
                catch (SqlException se)
                {
                    string err = se.Message;
                }
                catch (Exception be)
                {
                    string err = be.Message;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string page_pop = "<SCRIPT language='javascript'>window.close(); if (window.opener && !window.opener.closed){window.opener.location.reload();       }</SCRIPT>";
        Response.Write(page_pop);
    }
}
