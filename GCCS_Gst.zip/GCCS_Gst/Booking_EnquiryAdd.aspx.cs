using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Booking_EnquiryAdd : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    Int16 SRno;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        else if (!IsPostBack && Request.QueryString["sno"].ToString() != "")
        {
          
            SRno = Int16.Parse(Request.QueryString["sno"].ToString());
            DataTable dt_agent = dw.GetAllFromQuery("SELECT Ag.Agent_name as Agent_name,AB.Agent_Address as Agent_Address,Be.No_of_packages as No_of_packages,Be.commodity as commodity,convert(varchar,handover_date,103) as handover_date,be.remarks as remarks,be.ccremarks as ccremarks FROM Booking_Enquiry BE  inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join Agent_branch AB on AB.Agent_ID=AG.Agent_ID inner join City_Master CM on CM.city_id=BE.City where Booking_EnquiryNo=" + SRno + "");
            if (dt_agent.Rows.Count > 0)
            {
                Response.Write("<table width=80% align=center border=1>");
                Response.Write("<tr><td class=boldtext nowrap align=left>Agent Name</td><td class=boldtext >&nbsp;" + dt_agent.Rows[0]["Agent_Name"].ToString() + " </td></tr>");
                Response.Write("<tr><td class=boldtext nowrap>Agent Address</td><td class=boldtext >&nbsp;" + dt_agent.Rows[0]["Agent_Address"].ToString() + " </td></tr>");
                Response.Write("<tr><td class=boldtext nowrap>Pcs</td><td class=boldtext >&nbsp;" + dt_agent.Rows[0]["No_of_packages"].ToString() + " </td></tr>");
                Response.Write("<tr><td class=boldtext nowrap>Commodity</td><td class=boldtext >&nbsp;" + dt_agent.Rows[0]["commodity"].ToString() + " </td></tr>");
                Response.Write("<tr><td class=boldtext nowrap>H/O Date</td><td class=boldtext >" + dt_agent.Rows[0]["handover_date"].ToString() + " </td></tr>");
                Response.Write("<tr><td class=boldtext nowrap>Agent Remarks</td><td class=boldtext >&nbsp;" + dt_agent.Rows[0]["remarks"].ToString() + " </td></tr>");
                Response.Write("<tr><td class=boldtext nowrap>CC Remarks</td><td class=boldtext >&nbsp;" + dt_agent.Rows[0]["ccremarks"].ToString() + " </td></tr>");
                Response.Write("</table>");

            }

        }
    }
}
