using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;

public partial class FlightTo_PFM : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    string table2 = "";
    DisplayWrap dw = new DisplayWrap();
    StringBuilder strtable = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {


            if (!Page.IsPostBack)
            {
                btnTransferFlight.Attributes.Add("onclick", "return CheckEmpty_ddl();");
                btnoperation.Attributes.Add("onclick", "return TransferULD();");
                btnbulkTransfer.Attributes.Add("onclick", "return TransferBulk();");
                btntranferhandata.Attributes.Add("onclick", "return TransferGeneralcargo();");
                ShowAirline();
                //  FillGrid();
                ddltransferFlt.Visible = false;
                btnTransferFlight.Visible = false;
                pnltrnsferflighthand.Visible=false;
                rowColor(1);
                // rowColor();
            }

        }
    }
    public void FillGrid()
    {
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            com = new SqlCommand("Handover_to_pfm_getlist", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAirlineCity.SelectedValue);
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = DateTime.Parse(DateTime.Now.ToShortDateString());
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt_Hand = new DataTable();
            da.Fill(dt_Hand);
            if (dt_Hand.Rows.Count > 0)
            {
                pnlPFM.Visible = true;
                ddltransferFlt.Visible = true;
                //btnTransferFlight.Visible = true;

                GridView1.DataSource = dt_Hand;
                GridView1.DataBind();

            }
            else
            {
                pnlPFM.Visible = false;
                ddltransferFlt.Visible = false;
                btnTransferFlight.Visible = false;

                GridView1.DataSource = null;
                GridView1.DataBind();


            }
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void FillBulk()
    {


        con = new SqlConnection(strcon);

        try
        {
            con.Open();

            com = new SqlCommand("BulkDataGetList", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAirlineCity.SelectedValue);
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = DateTime.Parse(DateTime.Now.ToShortDateString());


            SqlDataAdapter da = new SqlDataAdapter(com);

            DataTable dt_Hand = new DataTable();
            da.Fill(dt_Hand);
            if (dt_Hand.Rows.Count > 0)
            {
                GridView2.DataSource = dt_Hand;
                GridView2.DataBind();
                pnlbulk.Visible = true;

            }
            else
            {
                GridView2.DataSource = null;
                GridView2.DataBind();
                pnlbulk.Visible = false;
            }
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    public void FillGridFlightwise()
    {
        con = new SqlConnection(strcon);

        try
        {
            con.Open();

            com = new SqlCommand("FlightWiseHandover_Getlist", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAirlineCity.SelectedValue);
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.Int).Value = Convert.ToInt32(ddltransferFlt.SelectedValue);
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = DateTime.Parse(DateTime.Now.ToShortDateString());


            SqlDataAdapter da = new SqlDataAdapter(com);

            DataTable dt_Hand = new DataTable();
            da.Fill(dt_Hand);
            if (dt_Hand.Rows.Count > 0)
            {
                pnlPFM.Visible = true;
                ddltransferFlt.Visible = true;
                btnTransferFlight.Visible = true;
pnltrnsferflighthand.Visible=true;
                GridView1.DataSource = dt_Hand;
                GridView1.DataBind();

            }
            else
            {
                pnlPFM.Visible = false;
                btnTransferFlight.Visible = false;
                pnltrnsferflighthand.Visible = false;
                GridView1.DataSource = null;
                GridView1.DataBind();


            }
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void ShowAirline()
    {

        ddlAirlineCity.Items.Clear();

        con = new SqlConnection(strcon);
        con.Open();
        try
        {
            com = new SqlCommand("Get_Airline", con);



            //com.Parameters.Add("@AIRLINEACCESS", SqlDbType.Int).Value = Convert.ToInt32(Session["AIRLINEACCESS"].ToString());
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            com.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineCity.Items.Add("--Select Airline--");
            ddlAirlineCity.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAirlineCity.Items.Add(new ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    public void LoadOpenFlight()
    {
        try
        {
            string strAgent = "";
            con = new SqlConnection(strcon);
            con.Open();
            com = new SqlCommand("LoadOpenFlight", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAirlineCity.SelectedValue);
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = DateTime.Parse(DateTime.Now.ToShortDateString());
            SqlDataReader dr = com.ExecuteReader();
            ddltransferFlt.Items.Clear();

            ddltransferFlt.Items.Add("--Select Airline--");
            ddltransferFlt.Items[0].Value = "0";
            ddltransferflight.Items.Clear();

            ddltransferflight.Items.Add("--Select Airline--");
            ddltransferflight.Items[0].Value = "0";
            ddlflight.Items.Clear();

            ddlflight.Items.Add("--Select Airline--");
            ddlflight.Items[0].Value = "0";

            ddlflighthand.Items.Clear();
            ddlflighthand.Items.Add("--Select Airline--");
            ddlflighthand.Items[0].Value = "0";

            //ddltransferFlt.Items.Insert(0, "0");
            while (dr.Read())
            {
                ddltransferFlt.Items.Add(new ListItem(dr["flight_No"].ToString() + ":" + dr["Flight_date"].ToString(), dr["Flight_Open_id"].ToString()));
                ddltransferflight.Items.Add(new ListItem(dr["flight_No"].ToString() + ":" + dr["Flight_date"].ToString(), dr["Flight_Open_id"].ToString()));
                ddlflight.Items.Add(new ListItem(dr["flight_No"].ToString() + ":" + dr["Flight_date"].ToString(), dr["Flight_Open_id"].ToString()));
                ddlflighthand.Items.Add(new ListItem(dr["flight_No"].ToString() + ":" + dr["Flight_date"].ToString(), dr["Flight_Open_id"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }


    public void LoadFlight()
    {
        try
        {
            string strAgent = "";
            con = new SqlConnection(strcon);
            con.Open();
            com = new SqlCommand("LoadOpenFlight", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAirlineCity.SelectedValue);
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = DateTime.Parse(DateTime.Now.ToShortDateString());
            SqlDataReader dr = com.ExecuteReader();
      

            

            ddlflighthand.Items.Clear();
            ddlflighthand.Items.Add("--Select Airline--");
            ddlflighthand.Items[0].Value = "0";

            //ddltransferFlt.Items.Insert(0, "0");
            while (dr.Read())
            {
               
                ddlflighthand.Items.Add(new ListItem(dr["flight_No"].ToString() + ":" + dr["Flight_date"].ToString(), dr["Flight_Open_id"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    
    protected void btnTransferFlight_Click(object sender, EventArgs e)
    {
        string AwbNo = "";
        foreach (GridViewRow gv in GridView1.Rows)
        {
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            Label lblairwaybill = (Label)gv.FindControl("lblhand");

            if (ChkBxItem.Checked)
            {
                AwbNo += "'" + lblairwaybill.Text + "'" + ',';
            }


        }

        if (AwbNo == "")
        {
            string strScript = "alert('Please Check shipment to transfer.');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
        }


        else if (ddltransferFlt.SelectedValue == "- -Select- -")
        {
            string strScript1 = "alert('Please select flight to transfer.');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox2", strScript1, true);
        }
        else
        {
            AwbNo = AwbNo.TrimEnd(',');

            string[] fltDate = ddltransferFlt.SelectedItem.Text.Split(':');

            string Flight_date = FormatDateMM(fltDate[1].ToString());
            string flightno = fltDate[0].ToString();
            string fltOpenID = ddltransferFlt.SelectedValue;
            DataTable dtpfmgroup = dw.GetAllFromQuery("SELECT  ISNULL(MAX(PFM_Group_ID),0) as PFM_Group_ID FROM db_owner.PFM WHERE Flight_Open_ID=" + fltOpenID + "");
            int PFM_Group_ID = Convert.ToInt32(dtpfmgroup.Rows[0]["PFM_Group_ID"].ToString());

            foreach (GridViewRow gv in GridView1.Rows)
            {

                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                if (ChkBxItem.Checked)
                {
                    SqlCommand cmd;
                    con = new SqlConnection(strcon);
                    con.Open();
                    cmd = new SqlCommand("Insert_Into_Pfm", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
                    cmd.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now.ToString();
                    cmd.Parameters.Add("@HANDOVER_ID", SqlDbType.Int).Value = ((Label)gv.FindControl("lblHID")).Text.ToString();
                    cmd.Parameters.Add("@Flight_date", SqlDbType.DateTime).Value = Flight_date;
                    cmd.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = flightno;

                    cmd.Parameters.Add("@Flight_Open_ID", SqlDbType.VarChar).Value = fltOpenID;

                    cmd.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(((Label)gv.FindControl("lblGrwt")).Text.ToString());
                    cmd.Parameters.Add("@Gross_Weight_PartShipment", SqlDbType.Decimal).Value = decimal.Parse(((Label)gv.FindControl("lblGrwtUnshipment")).Text.ToString() == "" ? "0" : ((Label)gv.FindControl("lblGrwtUnshipment")).Text.ToString());
                    cmd.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(((Label)gv.FindControl("lblVwt")).Text.ToString());
                    cmd.Parameters.Add("@Volume_Weight_PartShipment", SqlDbType.Decimal).Value = decimal.Parse(((Label)gv.FindControl("lblVwtUnshipment")).Text.ToString() == "" ? "0" : ((Label)gv.FindControl("lblVwtUnshipment")).Text.ToString());

                    cmd.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(((Label)gv.FindControl("lblPCs")).Text.ToString());
                    cmd.Parameters.Add("@No_of_Packages_PartShipment", SqlDbType.Int).Value = int.Parse(((Label)gv.FindControl("lblPartship")).Text.ToString() == "" ? "0" : ((Label)gv.FindControl("lblPartship")).Text.ToString());
                    cmd.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ((Label)gv.FindControl("lblhand")).Text.ToString();
                    cmd.Parameters.Add("@PFMGROUPID", SqlDbType.Int).Value = PFM_Group_ID + 1;
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
            }

            FillGridFlightwise();
            rowColor(1);


        }
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void ddlAirlineCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        trstatus.Visible = true;
        trmaintable.Visible = true;
        lblflightdate.Visible = true;
        ddltransferFlt.Visible = true;
        FillGrid();
        FilluldAll();
        FillBulk();
        LoadOpenFlight();
        rowColor(1);


    }
    protected void ddltransferFlt_SelectedIndexChanged(object sender, EventArgs e)
    {
        trstatus.Visible = true;
        FillGridFlightwise();
        if (ddltransferFlt.SelectedValue == "0")
        {
            FilluldAll();
            FillBulk();
        }
        else
        {
            Filluld();
            FillBulk();
        }

        rowColor(2);
    }
    protected void Filluld()
    {
        string uldnoOld = "";
        string uldnoNew = "";
        con = new SqlConnection(strcon);


        try
        {
            con.Open();

            com = new SqlCommand("GetReturn_Uld", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAirlineCity.SelectedValue);
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.Int).Value = Convert.ToInt32(ddltransferFlt.SelectedValue);
            com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = DateTime.Parse(DateTime.Now.ToShortDateString());



            SqlDataAdapter da = new SqlDataAdapter(com);

            DataTable dt_Uld = new DataTable();
            da.Fill(dt_Uld);
            if (dt_Uld.Rows.Count > 0)
            {
                truldaction.Visible = true;
                uldnoOld = dt_Uld.Rows[0]["ULD_No"].ToString();

                strtable.Append("<table width=100% border=0  cellspacing=0 cellpadding=0 id=tdPadding><tr class=h1 align=center><td class=boldtext colspan=11> Uld Details </td><tr>");

                strtable.Append("<table width=100% border=0  cellspacing=0 cellpadding=0 id=tdPadding><tr class=h1><td class=boldtext>Select Uld</td><td class=boldtext>AWBNO</td><td class=boldtext>Flight No</td><td class=boldtext>Flight Date</td><td class=boldtext> Dest</td><td class=boldtext>Pcs</td><td class=boldtext>Part Shipment Pcs</td><td class=boldtext>Gr Wt</td><td class=boldtext>Vol wt</td><td class=boldtext>LOC</td><td class=boldtext>SBNO</td><tr>");
                //strtable.Append(@"<tr align=left><td class=boldtext ><input id='chkTopicAll" + uldnoOld + "' name='checkall' type='checkbox' onclick='javascript:showButton(this.id);' value='" + uldnoOld + "' /> " + uldnoOld + "</td><td colspan=8></td><td> <input type=button name=button value='Break To PFM' class=but id='btnuld" + uldnoOld + "' onclick='javascript:Transfermanifest(this.id,1);'></td><td> <input type=button value='Transfer To Manifest' name=button id='btnhan" + uldnoOld + "' class=but onclick='javascript:Transfermanifest(this.id,2);'></td><tr>");

                strtable.Append(@"<tr align=left><td class=boldtext ><input id='checkUld" + uldnoOld + "' name='checkUld' type='checkbox'  value='" + uldnoOld + "' /> " + uldnoOld + "</td><td colspan=10></td><tr>");

                for (int i = 0; i < dt_Uld.Rows.Count; i++)
                {
                    uldnoNew = dt_Uld.Rows[i]["ULD_No"].ToString();
                    if (uldnoOld == uldnoNew)
                    {
                        strtable.Append(@"<tr ><td></td><td class=boldtext>" + dt_Uld.Rows[i]["AirWayBill_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Flight_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["flightDate1"].ToString() + "</td><td class=boldtext> " + dt_Uld.Rows[i]["Destination_Code"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "/" + dt_Uld.Rows[i]["Total_pcs"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Gross_Weight"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Volume_Weight"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Location"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Shipping_Bill_No"].ToString() + "</td><tr>");
                    }
                    else
                    {
                        ////strtable.Append(@"<tr align=left><td class=boldtext ><input id='chkTopicAll" + uldnoNew + "' name='checkall' type='checkbox' onclick='javascript:showButton(this.id);' value='" + uldnoNew + "' /> " + uldnoNew + "</td><td colspan=8></td><td> <input type=button name=button value='Break To PFM' class=but id='btnuld" + uldnoNew + "' onclick='javascript:Transfermanifest(this.id,1);'></td><td> <input type=button value='Transfer To Manifest' name=button id='btnhan" + uldnoNew + "' class=but onclick='javascript:Transfermanifest(this.id,2);'></td><tr>");


                        strtable.Append(@"<tr align=left><td class=boldtext ><input id='checkUld" + uldnoNew + "' name='checkUld' type='checkbox'  value='" + uldnoNew + "' /> " + uldnoNew + "</td><td colspan=10></td><tr>");
                        strtable.Append(@"<tr><td></td><td class=boldtext>" + dt_Uld.Rows[i]["AirWayBill_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Flight_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["flightDate1"].ToString() + "</td><td class=boldtext> " + dt_Uld.Rows[i]["Destination_Code"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "/" + dt_Uld.Rows[i]["Total_pcs"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Gross_Weight"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Volume_Weight"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Location"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Shipping_Bill_No"].ToString() + "</td><tr>");
                        uldnoOld = uldnoNew;
                    }
                }

                strtable.Append(@"</table>");

                lbluld.Visible = true;
                lbluld.Text = strtable.ToString();


            }
            else
            {
                lbluld.Visible = true;
                lbluld.Text = "No Cargo for ULD";
                truldaction.Visible = false;


            }

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void FilluldAll()
    {
        string uldnoOld = "";
        string uldnoNew = "";
        con = new SqlConnection(strcon);


        try
        {
            con.Open();

            com = new SqlCommand("GetReturn_Uld_All", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAirlineCity.SelectedValue);

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataTable dt_Uld = new DataTable();
            da.Fill(dt_Uld);
            if (dt_Uld.Rows.Count > 0)
            {
                truldaction.Visible = true;
                uldnoOld = dt_Uld.Rows[0]["ULD_No"].ToString();

                strtable.Append("<table width=100% border=0  cellspacing=0 cellpadding=0 id=tdPadding><tr class=h1 align=center><td class=boldtext colspan=11> Uld Details </td><tr>");

                strtable.Append("<table width=100% border=0  cellspacing=0 cellpadding=0 id=tdPadding><tr class=h1><td class=boldtext>Select Uld</td><td class=boldtext>AWBNO</td><td class=boldtext>Flight No</td><td class=boldtext>Flight Date</td><td class=boldtext> Dest</td><td class=boldtext>Pcs</td><td class=boldtext>Part Shipment Pcs</td><td class=boldtext>Gr Wt</td><td class=boldtext>Vol wt</td><td class=boldtext>LOC</td><td class=boldtext>SBNO</td><tr>");
                ////strtable.Append(@"<tr align=left><td class=boldtext ><input id='chkTopicAll" + uldnoOld + "' name='checkall' type='checkbox' onclick='javascript:showButton(this.id);' value='" + uldnoOld + "' /> " + uldnoOld + "</td><td colspan=8></td><td> <input type=button name=button value='Break To PFM' class=but id='btnuld" + uldnoOld + "' onclick='javascript:Transfermanifest(this.id,1);'></td><td> <input type=button value='Transfer To Manifest' name=button id='btnhan" + uldnoOld + "' class=but onclick='javascript:Transfermanifest(this.id,2);'></td><tr>");

                strtable.Append(@"<tr align=left><td class=boldtext ><input id='checkUld" + uldnoOld + "' name='checkUld' type='checkbox' value='" + uldnoOld + "' /> " + uldnoOld + "</td><td colspan=10></td><tr>");

                for (int i = 0; i < dt_Uld.Rows.Count; i++)
                {
                    uldnoNew = dt_Uld.Rows[i]["ULD_No"].ToString();
                    if (uldnoOld == uldnoNew)
                    {
                        strtable.Append(@"<tr><td></td><td class=boldtext>" + dt_Uld.Rows[i]["AirWayBill_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Flight_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["flightDate1"].ToString() + "</td><td class=boldtext> " + dt_Uld.Rows[i]["Destination_Code"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "/" + dt_Uld.Rows[i]["Total_pcs"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Gross_Weight"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Volume_Weight"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Location"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Shipping_Bill_No"].ToString() + "</td><tr>");
                    }
                    else
                    {
                        ////strtable.Append(@"<tr align=left><td class=boldtext ><input id='chkTopicAll" + uldnoNew + "' name='checkall' type='checkbox' onclick='javascript:showButton(this.id);' value='" + uldnoNew + "' /> " + uldnoNew + "</td><td colspan=8></td><td> <input type=button name=button value='Break To PFM' class=but id='btnuld" + uldnoNew + "' onclick='javascript:Transfermanifest(this.id,1);'></td><td> <input type=button value='Transfer To Manifest' name=button id='btnhan" + uldnoNew + "' class=but onclick='javascript:Transfermanifest(this.id,2);'></td><tr>");

                        strtable.Append(@"<tr align=left><td class=boldtext ><input id='checkUld" + uldnoNew + "' name='checkUld' type='checkbox'  value='" + uldnoNew + "' /> " + uldnoNew + "</td><td colspan=10></td><tr>");

                        strtable.Append(@"<tr><td></td><td class=boldtext>" + dt_Uld.Rows[i]["AirWayBill_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Flight_No"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["flightDate1"].ToString() + "</td><td class=boldtext> " + dt_Uld.Rows[i]["Destination_Code"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["No_of_Packages"].ToString() + "/" + dt_Uld.Rows[i]["Total_pcs"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Gross_Weight"].ToString() + "</td><td class=boldtext align=right>" + dt_Uld.Rows[i]["Volume_Weight"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Location"].ToString() + "</td><td class=boldtext>" + dt_Uld.Rows[i]["Shipping_Bill_No"].ToString() + "</td><tr>");

                        uldnoOld = uldnoNew;

                    }
                }

                strtable.Append(@"</table>");
                lbluld.Visible = true;
                lbluld.Text = strtable.ToString();
            }
            else
            {
                lbluld.Visible = true;
                lbluld.Text = "No Cargo for ULD";
                truldaction.Visible = false;
            }

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void rowColor(int a)
    {
        int c = GridView1.Columns.Count;
        int k = 0;
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow gr = GridView1.Rows[i];
            CheckBox chk = (CheckBox)gr.FindControl("chkMain");
            if (((Label)(gr.FindControl("lblpfmstatus"))).Text == "14" || ((Label)(gr.FindControl("lblpfmstatus"))).Text == "31")
            {
                gr.BackColor = System.Drawing.Color.LightBlue;
                k++;

            }
            else if (((Label)(gr.FindControl("lblpfmstatus"))).Text == "34")
            {
                gr.BackColor = System.Drawing.Color.RosyBrown;
                k++;

            }
            else
            {
                gr.BackColor = System.Drawing.Color.PeachPuff;
                chk.Enabled = false;
            }
            if (a == 2)
                trPfm.Visible = k == 0 ? false : true;
        }
    }
    protected void btnbulkTransfer_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow gv in GridView2.Rows)
        {
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("CheckBulkMain");
            if (ChkBxItem.Checked)
            {
                SqlCommand cmd;
                con = new SqlConnection(strcon);
                con.Open();
                cmd = new SqlCommand("Transfer_Flight_Bulk", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@HANDOVER_ID", SqlDbType.Int).Value = ((Label)gv.FindControl("lblHID")).Text.ToString();
                cmd.Parameters.Add("@Flight_Open_ID", SqlDbType.VarChar).Value = ddlflight.SelectedValue;
                cmd.ExecuteNonQuery();
                con.Close();
            }

        }
        FillBulk();
        FillGrid();
        LoadOpenFlight();
        rowColor(1);




    }
    protected void btnoperation_Click(object sender, EventArgs e)
    {
        if (ddltransferFlt.SelectedValue == "0")
        {
            FilluldAll();
            FillGrid();
        }
        else
        {
            Filluld();
            FillGridFlightwise();

        }
        FillBulk();

        rowColor(1);
    }
    protected void btntranferhandata_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow gv in GridView1.Rows)
        {
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            if (ChkBxItem.Checked)
            {

                SqlCommand cmd;
                con = new SqlConnection(strcon);
                con.Open();
                cmd = new SqlCommand("Transfer_Flight_Bulk", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@HANDOVER_ID", SqlDbType.Int).Value = ((Label)gv.FindControl("lblHID")).Text.ToString();
                cmd.Parameters.Add("@Flight_Open_ID", SqlDbType.VarChar).Value = ddlflighthand.SelectedValue;
                cmd.ExecuteNonQuery();
                con.Close();
            }

        }
       
        FillGridFlightwise();
      LoadFlight();
        rowColor(1);
    }
}
















