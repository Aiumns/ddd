﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class display_flight_Ip_NonIata : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string date = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        String airline_access = Session["AIRLINEACCESS"].ToString();
        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand("select Flight_open_id,convert(varchar,Flight_date,103) as Flight_date,Flight_no,substring(cast(flight_time as varchar),12,50)as flight_time,Flight_day,Flight_type,capacity,convert(varchar,close_date,103) as Close_date,destination_code,city_code from flight_open inner join flight_master on flight_open.Flight_id=flight_master.Flight_id inner join destination_master on destination_master.destination_id=flight_master.destination inner join city_master on city_master.city_id=flight_master.origin where airline_detail_id in (" + airline_access + ") and close_date >=getdate()", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            string table = @"<table width=90% cellpadding=1 cellspacing=0 align=center><tr class=h1 >
<td colspan=9 align=center>023</td></tr>
<tr class=h1><td class=boldtext align=center>Flt. No.</td><td class=boldtext align=center>Date</td>
<td class=boldtext align=center>Day</td><td class=boldtext align=center>Time</td>
<td class=boldtext align=center>Type</td><td class=boldtext align=center>Origin</td>
<td class=boldtext align=center>Destination</td><td class=boldtext align=center>Capacity (Kgs.)</td>
<td class=boldtext align=center>Closing Date</td></tr>";

            table += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center><form action='Add_Ip_NonIata.aspx method='post'></form></td><td class=boldtext align=left></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td></tr>";

            while (dr.Read())
            {
                string flight_no = dr["Flight_no"].ToString();
                date = dr["Flight_date"].ToString();
                table += @"<tr><td class=boldtext align=center>" + flight_no + "</td><td class=boldtext align=center><form action='Add_Ip_NonIata.aspx?par=" + date + "' method='post'><input type=hidden value=" + flight_no + " name=flhid><input type=hidden value=" + dr["Flight_open_id"].ToString() + " name=hid><input class=but type=submit value=" + date + " /></form></td><td class=boldtext align=left>" + dr["Flight_day"].ToString() + "</td><td class=boldtext align=center>" + dr["Flight_time"].ToString() + "</td><td class=boldtext align=center>" + dr["Flight_type"].ToString() + "</td><td class=boldtext align=center>" + dr["city_code"].ToString() + "</td><td class=boldtext align=center>" + dr["destination_code"].ToString() + "</td><td class=boldtext align=center>" + dr["capacity"].ToString() + "</td><td class=boldtext align=center>" + dr["Close_date"].ToString() + "</td></tr>";
            }



            table += @"<tr class=h1><td class=boldtext align=center>Flt. No.</td><td class=boldtext align=center>Date</td>
<td class=boldtext align=center>Day</td><td class=boldtext align=center>Time</td>
<td class=boldtext align=center>Type</td><td class=boldtext align=center>Origin</td>
<td class=boldtext align=center>Destination</td><td class=boldtext align=center>Capacity (Kgs.)</td>
<td class=boldtext align=center>Closing Date</td></tr>";
            table += "</table>";


            lbltable.Text = table;
        }


    }

}
