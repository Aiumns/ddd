
Partial Class _Default
    Inherits System.Web.UI.Page

    Dim unitNum(20) As String
    Dim hundredNum(20) As String
    Dim thousendNum(20) As String
    Dim myNum As String
    Dim numGroup As Integer

    Public Function NumericToWords(ByVal myNum As String) As String

        Dim units As String
        Dim numericToWordsOutPut As String
        units = numericToWordsOutPut = ""
        Dim myNumArray(myNum.Length \ numGroup) As String
        Dim index As Int16 = -1
        For Count As Int16 = 0 To myNum.Length - numGroup Step numGroup
            index += 1
            myNumArray(index) = myNum.Substring(Count, numGroup)
        Next

        For Count As Int16 = 0 To (myNum.Length \ 3) - 1
            units = thousendNum(((myNum.Length \ numGroup) - 1) - Count + 1)
            numericToWordsOutPut &= CheckUnitOutput(myNumArray(Count)).TrimEnd(" ") & " " & units & " "
        Next

        myNumArray = Nothing
        Return numericToWordsOutPut

    End Function

    Private Function CheckUnitOutput(ByVal myNum As String) As String
        Dim unitBasedOutput As String = ""
        Dim unitDigit As Int16 = Val(myNum.Substring(0, 1))
        Dim hundredDigit As Int16 = Val(myNum.Substring(1, 1))
        Dim thousendDigit As Int16 = Val(myNum.Substring(2, 1))
        If unitDigit >= 1 Then
            unitBasedOutput &= unitNum(unitDigit) & " hundred "
        End If
        If Val(myNum.Substring(1, 2)) < 20 Then
            unitBasedOutput &= unitNum(Val(myNum.Substring(1, 2)))
        End If

        If Val(myNum.Substring(1, 2)) >= 20 Then
            unitBasedOutput &= hundredNum(hundredDigit) & " " & unitNum(thousendDigit)
        End If
        Return unitBasedOutput
    End Function


    Private Sub FormatInitialization()
        thousendNum(0) = ""
        thousendNum(1) = ""
        thousendNum(2) = "Thousand"
        thousendNum(3) = "Million"
        thousendNum(4) = "Billion"
        thousendNum(5) = "Trillion"
        thousendNum(6) = "Quadrillion"
        thousendNum(7) = "Quintillion"
        thousendNum(8) = "Sextillion"
        thousendNum(9) = "Septillion"
        thousendNum(10) = "Octillion"
        thousendNum(11) = "Nonillion"
        thousendNum(12) = "Decillion"
        thousendNum(13) = "Undecillion"
        thousendNum(14) = "Duodecillion"
        thousendNum(15) = "Tredecillion"

        hundredNum(0) = ""
        hundredNum(1) = ""
        hundredNum(2) = "Twenty"
        hundredNum(3) = "Thirty"
        hundredNum(4) = "Forty"
        hundredNum(5) = "Fifty"
        hundredNum(6) = "Sixty"
        hundredNum(7) = "Seventy"
        hundredNum(8) = "Eighty"
        hundredNum(9) = "Ninety"

        unitNum(0) = ""
        unitNum(1) = "One"
        unitNum(2) = "Two"
        unitNum(3) = "Three"
        unitNum(4) = "Four"
        unitNum(5) = "Five"
        unitNum(6) = "Six"
        unitNum(7) = "Seven"
        unitNum(8) = "Eight"
        unitNum(9) = "Nine"
        unitNum(10) = "Ten"
        unitNum(11) = "Eleven"
        unitNum(12) = "Twelve"
        unitNum(13) = "Thirteen"
        unitNum(14) = "Fourteen"
        unitNum(15) = "Fifteen"
        unitNum(16) = "Sixteen"
        unitNum(17) = "Seventeen"
        unitNum(18) = "Eighteen"
        unitNum(19) = "Nineteen"
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        numGroup = 3
        FormatInitialization()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        myNum = NumericTextBox.Text
        If myNum.Length Mod numGroup <> 0 Then
            myNum = myNum.PadLeft(myNum.Length + (numGroup - (myNum.Length Mod numGroup)), "0")
        End If
        NumericToWordTextBox.Text = ""
        NumericToWordTextBox.Text = NumericToWords(myNum)

    End Sub
End Class
