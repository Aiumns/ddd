    using System;
    using System.Data;
    using System.Configuration;
    using System.Collections;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Web.UI.HtmlControls;
    using System.Data.SqlClient;
    using System.IO;
    //added
    using iTextSharp.text;
    using iTextSharp.text.html.simpleparser;
    using iTextSharp.text.pdf;
    using System.Text;
    //using System.Windows.Forms;
    using System.Drawing;
    using System.Text.RegularExpressions;
public partial class Fedex_Csr : System.Web.UI.Page
{
    static string csrFooter = null;
    static string csrFooter2 = null;

    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    //DisplayWrap dw = new DisplayWrap();
    //String strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    string StaxRate = "";
    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
    string SBCessRate = "";
    string KKCessRate = "";
    string EducationcessRate = "";
    string HEducCessRate = "";
    //SqlCommand cmd;
    //SqlConnection con;

    #region Gst Applicable
    string CompGstNo = "07";
    string AgentGstNo = "08";  
    #endregion End of Gst Applicable

    string strtable = string.Empty;

    string strtable2 = string.Empty;

    string strtable3 = string.Empty;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
                hdnDate.Value = first.ToString();
                rbtnSelectAll.Attributes.Add("onClick", "javascript :selectAll() ");
                rbtnDSelect.Attributes.Add("onClick", "javascript :dselectAll() ");
                Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
                ddlyear.Items.Clear();
                for (int year = 2006; year <= DateTime.Today.Year; year++)
                    ddlyear.Items.Add(new System.Web.UI.WebControls.ListItem(year.ToString(), year.ToString()));
                ddlyear.SelectedValue = DateTime.Today.Year.ToString();
                int dt = System.DateTime.Now.Month;
                if (dt == 1)
                    dt = 2;
                ddlMonth.Items[dt - 2].Selected = true;
                ShowAirline();
            }
        }
    }

    protected void ShowAirline()
    {
        ddlAirLine.Items.Clear();
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            dr = cmd.ExecuteReader();
            ddlAirLine.Items.Add("Select airline name");
            ddlAirLine.Items[0].Value = "";
            while (dr.Read())
            {
                ddlAirLine.Items.Add(new System.Web.UI.WebControls.ListItem(dr["airline"].ToString(), dr["Airline_Detail_ID"].ToString()));
            }
            dr.Dispose();
            cmd.Dispose();
            con.Close();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }

    protected void ddlAirLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        loadAgent();
    }

    protected void Btnload_Click(object sender, EventArgs e)
    {   
        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();
        string strY = ddlyear.SelectedItem.Text;
       
        if (rbtnFirstFortn.Checked == true)
        {
            #region if condition
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
            #endregion
        }

        else if (rbtnSecondFortN.Checked == true)
        {
            #region else if 
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }
            #endregion
        }

        string Agent_id = "";
        for (int i = 0; i < lstAgent.Items.Count; i++)
        {
            if (lstAgent.Items[i].Selected)
            {
                Agent_id = Agent_id + lstAgent.Items[i].Value + ",";
            }
        }
       
       Agent_id = Agent_id.Substring(0, Agent_id.Length-1);
       Session["Agentid"] = Agent_id;
       Session["from"] = TextBox1.Text;
       Session["to"] = TextBox2.Text;
       Session["Airline_Detail_ID"] = ddlAirLine.SelectedValue.Trim();
       Session["csr_footer"] = csrFooter;
       ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/Fedex_csr.aspx');</script>");

       //Response.Redirect("Reports/Fedex_csr.aspx");
       //string url = "Fedex_csr.aspx?Agentid=" + Agent_id  + "&amp;from=" + TextBox1.Text + "&amp;to=" + TextBox2.Text;
       //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");      
    }

    protected void pdf_Click(object sender, EventArgs e)
    {
        #region Added from button event
        TextBox TextBox1 = new TextBox();
        TextBox TextBox2 = new TextBox();
        TextBox TextBox3 = new TextBox();

        string strY = ddlyear.SelectedItem.Text;
        if (rbtnFirstFortn.Checked == true)
        {
            #region if condition
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/01/" + strY;
                TextBox2.Text = "01/15/" + strY;
                TextBox3.Text = "01/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/01/" + strY;
                TextBox2.Text = "02/15/" + strY;
                TextBox3.Text = "02/16/" + strY;
            }
            if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/01/" + strY;
                TextBox2.Text = "03/15/" + strY;
                TextBox3.Text = "03/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/01/" + strY;
                TextBox2.Text = "04/15/" + strY;
                TextBox3.Text = "04/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text == "May")
            {
                TextBox1.Text = "05/01/" + strY;
                TextBox2.Text = "05/15/" + strY;
                TextBox3.Text = "05/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/01/" + strY;
                TextBox2.Text = "06/15/" + strY;
                TextBox3.Text = "06/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/01/" + strY;
                TextBox2.Text = "07/15/" + strY;
                TextBox3.Text = "07/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/01/" + strY;
                TextBox2.Text = "08/15/" + strY;
                TextBox3.Text = "08/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/01/" + strY;
                TextBox2.Text = "09/15/" + strY;
                TextBox3.Text = "09/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/01/" + strY;
                TextBox2.Text = "10/15/" + strY;
                TextBox3.Text = "10/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/01/" + strY;
                TextBox2.Text = "11/15/" + strY;
                TextBox3.Text = "11/16/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/01/" + strY;
                TextBox2.Text = "12/15/" + strY;
                TextBox3.Text = "12/16/" + strY;
            }
            #endregion
        }
        else if (rbtnSecondFortN.Checked == true)
        {
            #region else if
            if (ddlMonth.SelectedItem.Text.Trim() == "January")
            {
                TextBox1.Text = "01/16/" + strY;
                TextBox2.Text = "01/31/" + strY;
                TextBox3.Text = "02/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "February")
            {
                TextBox1.Text = "02/16/" + strY;
                if (DateTime.IsLeapYear(int.Parse(strY)))
                    TextBox2.Text = "02/29/" + strY;
                else
                { TextBox2.Text = "02/28/" + strY; }

                TextBox3.Text = "03/01/" + strY;

            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "March")
            {
                TextBox1.Text = "03/16/" + strY;
                TextBox2.Text = "03/31/" + strY;
                TextBox3.Text = "04/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "April")
            {
                TextBox1.Text = "04/16/" + strY;
                TextBox2.Text = "04/30/" + strY;
                TextBox3.Text = "05/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "May")
            {
                TextBox1.Text = "05/16/" + strY;
                TextBox2.Text = "05/31/" + strY;
                TextBox3.Text = "06/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "June")
            {
                TextBox1.Text = "06/16/" + strY;
                TextBox2.Text = "06/30/" + strY;
                TextBox3.Text = "07/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "July")
            {
                TextBox1.Text = "07/16/" + strY;
                TextBox2.Text = "07/31/" + strY;
                TextBox3.Text = "08/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "August")
            {
                TextBox1.Text = "08/16/" + strY;
                TextBox2.Text = "08/31/" + strY;
                TextBox3.Text = "09/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "September")
            {
                TextBox1.Text = "09/16/" + strY;
                TextBox2.Text = "09/30/" + strY;
                TextBox3.Text = "10/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "October")
            {
                TextBox1.Text = "10/16/" + strY;
                TextBox2.Text = "10/31/" + strY;
                TextBox3.Text = "11/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "November")
            {
                TextBox1.Text = "11/16/" + strY;
                TextBox2.Text = "11/30/" + strY;
                TextBox3.Text = "12/01/" + strY;
            }
            else if (ddlMonth.SelectedItem.Text.Trim() == "December")
            {
                TextBox1.Text = "12/16/" + strY;
                TextBox2.Text = "12/31/" + strY;
                TextBox3.Text = "01/01/" + strY;
            }
            #endregion
        }

        string Agent_id = "";
        for (int i = 0; i < lstAgent.Items.Count; i++)
        {
            if (lstAgent.Items[i].Selected)
            {
                Agent_id = Agent_id + lstAgent.Items[i].Value + ",";
            }
        }

        Agent_id = Agent_id.Substring(0, Agent_id.Length - 1);
        Session["Agentid"] = Agent_id;

        //Session["from"] = TextBox1.Text;
        //Session["to"] = TextBox2.Text;
        //Session["Airline_Detail_ID"] = ddlAirLine.SelectedValue.Trim();
        //Session["csr_footer"] = csrFooter2;
        #endregion

        string Airline_detail_id = ddlAirLine.SelectedValue.Trim();
        string from = TextBox1.Text;
        string to = TextBox2.Text;
        string csrFooter = csrFooter2;
        #region Gst Created date

        //Gst Approved csr date
        string[] startDate = from.Split('/');
        string created_date = DateTime.Now.ToString("dd/MM/yyyy");
        if (int.Parse(startDate[1].ToString()) <= 15)
        {
            created_date = "25/" + startDate[0].ToString() + "/" + startDate[2].ToString();
        }
        else
        {
            if (startDate[0].ToString() == "12")
            {
                created_date = "10/01/" + (int.Parse(startDate[2].ToString()) + 1);
            }
            else
            {
                created_date = "10/" + (int.Parse(startDate[0].ToString()) + 1) + "/" + startDate[2].ToString();
            }
        }
        //end of Gst Approved csr date

        #endregion End of Gst Created date

        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
        ////DataTable dtStaxRate = dw.GetAllFromQuery("SELECT TDS_Id,isnull(Stax,0) as Stax ,isnull(Education_Cess,0) as Education_Cess,isnull(HigherEducation_Cess,0) as HigherEducation_Cess,isnull(SB_Cess,0) as SB_Cess FROM tds_Fedex WHERE '" + from + "' BETWEEN Valid_From AND Valid_To");

        DataTable dtStaxRate = dw.GetAllFromQuery("SELECT TDS_Id,isnull(Stax,0) as Stax ,isnull(Education_Cess,0) as Education_Cess,isnull(HigherEducation_Cess,0) as HigherEducation_Cess,isnull(SB_Cess,0) as SB_Cess,isnull(KK_Cess,0) as KK_Cess FROM tds_Fedex WHERE '" + from + "' BETWEEN Valid_From AND Valid_To");
        if (dtStaxRate.Rows.Count > 0)
        {
            #region if condition
            StaxRate = dtStaxRate.Rows[0]["Stax"].ToString();
            if (Convert.ToDateTime(to) < Convert.ToDateTime("11/16/2015"))
            {
                SBCessRate = "0.00";
            }
            else
            {

                SBCessRate = dtStaxRate.Rows[0]["SB_Cess"].ToString();
            }
            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            if (Convert.ToDateTime(to) < Convert.ToDateTime("06/01/2016"))
            {
                KKCessRate = "0.00";
            }
            else
            {
                KKCessRate = dtStaxRate.Rows[0]["KK_Cess"].ToString();
            }
            EducationcessRate = dtStaxRate.Rows[0]["Education_Cess"].ToString();
            HEducCessRate = dtStaxRate.Rows[0]["HigherEducation_Cess"].ToString();
            #endregion
        }
        else
        {
            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            #region else condition
            if (Convert.ToDateTime(to) < Convert.ToDateTime("07/01/2017"))
            {
                StaxRate = "14";
                SBCessRate = "0.5";
                KKCessRate = "0.5";
                EducationcessRate = "2";
                HEducCessRate = "1";
            }
            else
            {
                ////GST Invoicing Appplicable
                #region GST Applied from 01Apr2017
                StaxRate = "9";
                SBCessRate = "9";
                KKCessRate = "18";
                EducationcessRate = "2";
                HEducCessRate = "1";
                #endregion
            }
            #endregion
        }

        decimal total_ch_wt = 0;
        decimal total_fr = 0;
        //string agent_id = Request["Agentid"].ToString();
        //string from = Request["from"].ToString();
        //string to = Request["to"].ToString();
        string agent_id = Session["Agentid"].ToString();
        string[] agent_selected_id = agent_id.Split(',');
        ////string from = Session["from"].ToString();
        ////string to = Session["to"].ToString();        
        //table += @"<table  border=""0"" align=center style=""word-spacing:inherit"" width=""95%"" ><tr ><td  width=""75%"" align=""center""></td><td   align=""left""><font size=""2""><b>Date: " + created_date + "</b></font></td></tr></table><br>";         
        //Response.Write("<table align=left width=70%><tr><td valign=top align=left>");

        strtable = @"<table align=left width=100%><tr><td valign=top align=left>";

        string Query = "select distinct Agent_name,FedexIp.Agent_id,ad.Belongs_To_City from dbo.FedexIP inner join Agent_master on FedexIp.Agent_id=Agent_master.Agent_id INNER JOIN dbo.Airline_Detail ad ON dbo.FedexIP.Airline_Detail_ID=ad.Airline_Detail_ID where Fedexip.agent_id in (" + agent_id + ") and awbDt between '" + from + "' and '" + to + "' AND FedexIp.Airline_Detail_ID =" + Airline_detail_id.ToString() + "";
       
        DataTable dt = dw.GetAllFromQuery(Query);

        DataTable dt1 = dw.GetAllFromQuery("select * from company_master where company_id in (SELECT ad.Company_ID FROM dbo.Airline_Detail ad INNER JOIN dbo.Airline_Master am ON ad.Airline_ID = am.Airline_ID WHERE ad.Airline_Detail_ID=" + Airline_detail_id.ToString() + " AND Airline_Code=023)");
       
        if (dt.Rows.Count > 0)
        {
            #region if condition
            foreach (DataRow drow in dt.Rows)
            {
                #region for loop
                //for (int k = 0; k < agent_selected_id.Length - 1; k++)
                //{
                // agent_id = agent_selected_id[k];
                decimal CGST = 9;
                decimal SGST = 9;
                decimal IGST = 18;

                decimal TotalCGST = 9;
                decimal TotalSGST = 9;
                decimal TotalIGST = 18;
                decimal TotalGst = 0;


                int AtaShipment = 0;
                total_fr = 0;
                total_ch_wt = 0;
                decimal Total_FSCAmt = 0;
                decimal Total_Totalfrt = 0;
                decimal Total_frt = 0;
                decimal Total_frtATAAMT = 0;

                #region Gst Applied CompGstNo
                DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from Airline_detail where Airline_detail_id=" + Airline_detail_id.ToString() + "");
                if (dtCompanyGstNo != null && dtCompanyGstNo.Rows.Count > 0)
                {
                    if (dtCompanyGstNo.Rows[0]["GstNo"].ToString() != "")
                        CompGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                }



                if (DateTime.Parse(to) >= DateTime.Parse("07/01/2017"))
                {
                    //jj
                    // Response.Write("<table border=0 width=100% align=center><tr align=center><td colspan=18 align=center><font size=2><b>Invoice Date: " + created_date + "</b></font></td></tr></table>");

                    strtable2 += @"<table border=0 width=100% align=center><tr align=center><td colspan=8 align=center><font size=2><b>Invoice Date: " + created_date + "</b></font></td></tr></table>";

                    //jj
                    // Response.Write("<table border=0 width=100% align=center><tr><td colspan=5><img src='images/gclogo_new.gif'></td><td  align=left nowrap colspan=4><p align=center class=boldtext><font size=3>" + dt1.Rows[0]["company_name"].ToString().ToUpper() + @"</font><BR> Fedex Airlines<br>" + dt1.Rows[0]["Company_Address"].ToString() + @"<br> Ph :" + dt1.Rows[0]["Phone"].ToString() + @"<br><font size=1>GST No: " + CompGstNo + " </font><br><font size=1>Cargo Sales Report </font><br>From " + DateFormat(from) + "- To " + DateFormat(to) + "</p><td colspan=3>&nbsp;</td></tr>");
                    //  old images from local <img src='images/gclogo_new.gif'>
                    strtable2 += @"<table border=0 width=100% align=center><tr><td colspan=5><img src='http://pace1.cargoflash.com/Airasia/images/gclogo_new.gif'></td><td  align=left nowrap colspan=4><p align=center class=boldtext><font size=3>" + dt1.Rows[0]["company_name"].ToString().ToUpper() + @"</font><BR> Fedex Airlines<br>" + dt1.Rows[0]["Company_Address"].ToString() + @"<br> Ph :" + dt1.Rows[0]["Phone"].ToString() + @"<br><font size=1>GST No: " + CompGstNo + " </font><br><font size=1>Cargo Sales Report </font><br>From " + DateFormat(from) + "- To " + DateFormat(to) + "</p></td><td colspan=3>&nbsp;</td></tr>";

                }
                else
                {
                    /////Response.Write("<table border=0 width=100% align=center><tr align=center><td colspan=18 align=center><font size=2><b>Invoice Date: " + created_date + "</b></font></td></tr></table>");

                    //jj
                    //Response.Write("<table border=0 width=100% align=center><tr><td colspan=5><img src='images/gclogo_new.gif'></td><td  align=left nowrap colspan=4><p align=center class=boldtext><font size=3>" + dt1.Rows[0]["company_name"].ToString().ToUpper() + @"</font><BR> Fedex Airlines<br>" + dt1.Rows[0]["Company_Address"].ToString() + @"<br> Ph :" + dt1.Rows[0]["Phone"].ToString() + @"<br><br><font size=2>Cargo Sales Report </font><br><br>From " + DateFormat(from) + "- To " + DateFormat(to) + "</p><td colspan=3>&nbsp;</td></tr>");

                    strtable2 += @"<table border=0 width=100% align=center><tr><td colspan=5><img src='http://pace1.cargoflash.com/Airasia/images/gclogo_new.gif'></td><td  align=left nowrap colspan=4><p align=center class=boldtext><font size=3>" + dt1.Rows[0]["company_name"].ToString().ToUpper() + @"</font><BR> Fedex Airlines<br>" + dt1.Rows[0]["Company_Address"].ToString() + @"<br> Ph :" + dt1.Rows[0]["Phone"].ToString() + @"<br><br><font size=2>Cargo Sales Report </font><br><br>From " + DateFormat(from) + "- To " + DateFormat(to) + "</p></td><td colspan=3>&nbsp;</td></tr>";

                }
                #endregion Gst CompGst

                //DataTable dt2 = dw.GetAllFromQuery("select Agent_address,Agent_phone,Agent_contactno,Agent_fax,agent_email,Iata_code from agent_master inner join agent_branch on agent_branch.agent_id=agent_master.agent_id where agent_master.agent_id=" + Convert.ToInt64(drow["agent_id"].ToString()) + " and belongs_to_city =6");

                DataTable dt2 = dw.GetAllFromQuery("select Agent_address,Agent_phone,Agent_contactno,Agent_fax,agent_email,Iata_code from agent_master inner join agent_branch on agent_branch.agent_id=agent_master.agent_id where agent_master.agent_id=" + Convert.ToInt64(drow["agent_id"].ToString()) + " and belongs_to_city =" + Convert.ToInt64(drow["Belongs_To_City"].ToString()) + "");

                //jj
                // Response.Write("<tr><td colspan=3 class=boldtext>" + drow["agent_name"].ToString().ToUpper() + "<br>" + dt2.Rows[0]["agent_Address"].ToString().ToUpper() + "<br><br>IATA Code   " + dt2.Rows[0]["iata_code"].ToString().ToUpper() + "</td><td colspan=8>&nbsp;</td></tr>");

                strtable2 += @"<tr><td colspan=4 class=boldtext>" + drow["agent_name"].ToString().ToUpper() + "<br><br>" + dt2.Rows[0]["agent_Address"].ToString().ToUpper() + "<br>" + "IATA Code   " + dt2.Rows[0]["iata_code"].ToString().ToUpper() + "</td><td colspan=8>&nbsp;</td></tr>";

                ////////// Start:*****Modify By Hemant Sharma on 23 July 2014  for Additon of CIN NO*******************/////////////////

                //jj
                //Response.Write("<tr><td colspan=3 class=boldtext>CIN NO.U74899DL1993PTC052734</td></tr><br><br>");
                
               // strtable2 += @"<tr><td colspan=3 class=boldtext>CIN NO.U74899DL1993PTC052734</td></tr><br><br>";

                strtable2 += @"<tr><td colspan=4 class=boldtext>CIN NO.U74899DL1993PTC052734";

              
                #region GST INVoiceNO  to be applied from 01 Apr 2017
                string Invoice_No = "";
                if (DateTime.Parse(to) >= DateTime.Parse("07/01/2017"))
                {
                  #region
                    DataTable dtAgentGstNo = dw.GetAllFromQuery("select top 1 (case when gstno is null then Statecode else gstno end) as GstNo from fedexip where agent_id=" + Convert.ToInt64(drow["agent_id"].ToString()) + " and awbDt between '" + from + "' and '" + to + "' AND Airline_Detail_ID=" + Airline_detail_id.ToString() + "");
                    if (dtAgentGstNo != null && dtAgentGstNo.Rows.Count > 0)
                    {
                        if (dtAgentGstNo.Rows[0]["GstNo"].ToString() != "")
                            AgentGstNo = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                    }
                    DataTable dtInvoiceNo = dw.GetAllFromQuery("select max(GstInvNo) as GstInvNo, max(invoice_no) as Invoice_no,max(Invoice_Sno) as Invoice_Sno from FedexIP inner join Agent_master on FedexIP.Agent_id=Agent_master.Agent_id where airline_detail_id=" + Airline_detail_id + " and FedexIP.agent_id in (" + Convert.ToInt64(drow["agent_id"].ToString()) + ") and awbDt between '" + from + "' and '" + to + "'");
                    if (dtInvoiceNo.Rows.Count > 0)
                    {
                        #region if condition
                        string stateCode = "DELHI";
                        DataTable dtInvoice = dw.GetAllFromQuery("SELECT (Prifix + Replace(substring(Fin_Year,3,5),'-',''))as Prifix FROM db_owner.FedexIp_invoice_no where airline_detail_id=" + Airline_detail_id + "  AND SNo=" + dtInvoiceNo.Rows[0]["invoice_sno"].ToString() + " ");
                        if (dtInvoice.Rows.Count > 0)
                        {
                            #region if condition
                            DataTable gststateCode = dw.GetAllFromQuery("select state from GstStateCode where stateCode='" + AgentGstNo.Substring(0, 2) + "'");
                            if (gststateCode != null && gststateCode.Rows.Count > 0)
                            {
                                if (gststateCode.Rows[0]["state"].ToString() != "")
                                    stateCode = gststateCode.Rows[0]["state"].ToString();
                            }
                            //////Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + "/" + dtInvoiceNo.Rows[0]["invoice_no"].ToString();
                            if (Convert.ToDateTime(to) < Convert.ToDateTime("08/16/2017"))
                                Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + dtInvoiceNo.Rows[0]["invoice_no"].ToString();
                            else
                                Invoice_No = dtInvoice.Rows[0]["Prifix"].ToString() + dtInvoiceNo.Rows[0]["GstInvNo"].ToString();

                            //jj
                            //Response.Write("<tr><td colspan=3 class=boldtext>INVOICE No: " + Invoice_No + "</td></tr>");
                            //Response.Write("<tr><td colspan=3 class=boldtext>GST No: " + AgentGstNo + "</td></tr>");
                            //Response.Write("<tr><td colspan=3 class=boldtext>HSN Code:996812</td></tr>");
                            //Response.Write("<tr><td colspan=3 class=boldtext>State Code:" + stateCode + "</td></tr>");
                            //Response.Write("<tr><td colspan=3 class=boldtext>Place Of Delivery:" + stateCode + "</td></tr>");

                            //strtable2 += @"<tr><td colspan=3 class=boldtext>INVOICE No: " + Invoice_No + "</td></tr><br>";
                            //strtable2 += @"<tr><td colspan=3 class=boldtext>GST No: " + AgentGstNo + "</td></tr><br>";
                            //strtable2 += @"<tr><td colspan=3 class=boldtext>HSN Code:996812</td></tr><br>";
                            //strtable2 += @"<tr><td colspan=3 class=boldtext>State Code:" + stateCode + "</td></tr><br>";
                            //strtable2 += @"<tr><td colspan=3 class=boldtext>Place Of Delivery:" + stateCode + "</td></tr>";

                            strtable2 += @"<br>INVOICE No: " + Invoice_No + "<br>GST No:" + AgentGstNo + "<br>HSN Code:996812<br>State Code:" + stateCode + "<br>Place Of Delivery:" + stateCode + "";
                            #endregion
                        }
                        #endregion
                    }
                  #endregion
                }
                #endregion

               // strtable2 += @"</table>";

                strtable2 += @"</td><td colspan=8>&nbsp;</td></tr></table>";

                ////////// End:*****Modify By Hemant Sharma on 23 July 2014  for Additon of CIN NO*******************/////////////////

                strtable2 += @"<table border=0 width=100% align=center>";

                if (Convert.ToDateTime(to) < Convert.ToDateTime("07/01/2017"))
                {
                    //jj

                    //Response.Write("<tr class=h1><td class=boldtext align=center>Date</td><td class=boldtext align=center>TRK No.</td><td class=boldtext align=center>AWB No.</td><td class=boldtext align=center>Origin</td><td class=boldtext align=center>Dest</td><td class=boldtext align=center>Type</td><td class=boldtext align=center>Chrg. Wt</td><td class=boldtext align=center >NN AMT</td><td class=boldtext align=center>FSC/OTHRchrgs/DGSchrgs</td><td class=boldtext align=center >Total Amt</td><td class=boldtext align=center>Remark</td></tr>");
                    
                    strtable2 += @"<tr class=h1><td class=boldtext align=center>Date</td><td class=boldtext align=center>TRK No.</td><td class=boldtext align=center>AWB No.</td><td class=boldtext align=center>Origin</td><td class=boldtext align=center>Dest</td><td class=boldtext align=center>Type</td><td class=boldtext align=center>Chrg. Wt</td><td class=boldtext align=center >NN AMT</td><td class=boldtext align=center>FSC/OTHRchrgs/DGSchrgs</td><td class=boldtext align=center >Total Amt</td><td class=boldtext align=center>Remark</td></tr>";
                }
                else
                {
                    //jj

                    //Response.Write("<tr class=h1><td colspan=12 class=boldtext align=center>TAX INVOICE</td></tr>");

                    //Response.Write("<tr class=h1><td class=boldtext align=center>Date</td><td class=boldtext align=center>TRK No.</td><td class=boldtext align=center>AWB No.</td><td class=boldtext align=center>Origin</td><td class=boldtext align=center>Dest</td><td class=boldtext align=center>Type</td><td class=boldtext align=center>Chrg. Wt</td><td class=boldtext align=center >NN AMT</td><td class=boldtext align=center>FSC/OTHRchrgs/DGSchrgs</td><td class=boldtext align=center >Total Amt</td><td class=boldtext align=center>Remark</td><td class=boldtext align=center>Tax Status</td></tr>");
                   
                    strtable2 += @"<tr class=h1><td width=100% align=center colspan=12><font size=2><b><u>TAX INVOICE</u></b></font></td></tr>";

                    strtable2 += @"<tr class=h1><td class=boldtext align=center>Date</td><td class=boldtext align=center>TRK No.</td><td class=boldtext align=center>AWB No.</td><td class=boldtext align=center>Origin</td><td class=boldtext align=center>Dest</td><td class=boldtext align=center>Type</td><td class=boldtext align=center>Chrg. Wt</td><td class=boldtext align=center >NN AMT</td><td class=boldtext align=center>FSC/OTHRchrgs/DGSchrgs</td><td class=boldtext align=center >Total Amt</td><td class=boldtext align=center>Remark</td><td class=boldtext align=center>Tax Status</td></tr>";
                }

                //Response.Write("<tr><td class=boldtext align=center colspan=12 height=1px valign=top><hr color='#000000'></td></tr>");

                strtable2 += @"<tr><td class=boldtext align=center colspan=12 height=1px valign=top><hr color='#000000' size=1 width=100% /></td></tr>";

                DataTable dt3 = dw.GetAllFromQuery("select invoice_no,invoice_sno,trk, awbno,convert(varchar,awbdt,103) as awbdt,city_name,destination_code,country_code,isnull(chargeable_wt,0) as chargeable_wt,isnull(SellingRate,0) as SellingRate,isnull(SellingFscRate,0) as SellingFscRate,isnull(SellingStaxAmt,0) as SellingStaxAmt,isnull(sellingFscAmt,0) as sellingFscAmt,isnull(SellingOtherChrgs,0) as SellingOtherChrgs,isnull(SellingDg_Surcharge,0) as SellingDg_Surcharge,isnull(GrandSellingStaxAmt,0) as GrandSellingStaxAmt,Remarks,consignee,shptType,shipper from Fedexip inner join city_master on origin=city_id inner join destination_master on dstncd=destination_id where agent_id=" + Convert.ToInt64(drow["agent_id"].ToString()) + " and awbDt between '" + from + "' and '" + to + "' AND Airline_Detail_ID=" + ddlAirLine.SelectedValue.ToString() + "");

                foreach (DataRow drow1 in dt3.Rows)
                {
                    #region foreach Loop
                    string StaxStatus = "";
                    if (drow1["shptType"].ToString().ToUpper() == "ATA")
                    {
                        AtaShipment++;
                        StaxStatus = "NON-TAXABLE";
                    }
                    else
                    {
                        StaxStatus = "TAXABLE";
                    }

                    decimal SellingRate = 0;
                    decimal fscrate = 0;
                    decimal OtherChrgs = 0;
                    decimal Dg_Surchrgs = 0;
                    decimal ChargedWt = 0;
                    decimal FreightAmt = 0;
                    decimal FscAmt = 0;
                    decimal TotalFreightAmt = 0;
                    decimal staxamount = 0;
                    decimal SB_Cessamount = 0;
                    decimal KK_Cessamount = 0;

                    SellingRate = decimal.Parse(drow1["SellingRate"].ToString().ToUpper());
                    fscrate = decimal.Parse(drow1["SellingFscRate"].ToString().ToUpper());
                    OtherChrgs = decimal.Parse(drow1["SellingOtherChrgs"].ToString().ToUpper());
                    Dg_Surchrgs = decimal.Parse(drow1["SellingDg_Surcharge"].ToString().ToUpper());
                    ChargedWt = decimal.Parse(drow1["chargeable_wt"].ToString().ToUpper());
                    FreightAmt = Math.Round(SellingRate * ChargedWt, 2);
                    ///FscAmt = Math.Round((FreightAmt * fscrate) / 100 + OtherChrgs + Dg_Surchrgs,2);
                    FscAmt = (decimal.Parse(drow1["sellingFscAmt"].ToString().ToUpper()) + Dg_Surchrgs + OtherChrgs) * ChargedWt;
                    staxamount = Math.Round(decimal.Parse(drow1["GrandSellingStaxAmt"].ToString()) * ChargedWt, 2);
                    TotalFreightAmt = Math.Round(FreightAmt + FscAmt, 2);

                    if (drow1["shptType"].ToString().ToUpper() == "ATA")
                    {
                        Total_frtATAAMT += TotalFreightAmt;
                    }

                    if (Convert.ToDateTime(to) < Convert.ToDateTime("07/01/2011"))
                    {
                        //jj
                        // Response.Write("<tr><td class=text align=center>" + drow1["awbdt"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["trk"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["awbno"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["city_name"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["country_code"].ToString().ToUpper() + "-" + drow1["destination_code"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["shptType"].ToString().ToUpper() + "</td><td class=text align=right>" + drow1["chargeable_wt"].ToString().ToUpper() + "</td><td class=text align=right>" + Math.Round(FreightAmt) + "</td><td class=text align=right>" + Math.Round(FscAmt) + "</td><td class=text align=right>" + Math.Round(TotalFreightAmt) + "</td><td class=text align=center nowrap>" + drow1["remarks"].ToString().ToUpper() + "</td></tr>");

                        strtable2 += @"<tr><td class=text align=center>" + drow1["awbdt"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["trk"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["awbno"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["city_name"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["country_code"].ToString().ToUpper() + "-" + drow1["destination_code"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["shptType"].ToString().ToUpper() + "</td><td class=text align=right>" + drow1["chargeable_wt"].ToString().ToUpper() + "</td><td class=text align=right>" + Math.Round(FreightAmt) + "</td><td class=text align=right>" + Math.Round(FscAmt) + "</td><td class=text align=right>" + Math.Round(TotalFreightAmt) + "</td><td class=text align=center nowrap>" + drow1["remarks"].ToString().ToUpper() + "</td></tr>";
                    }
                    else
                    {
                        //jj
                        //Response.Write("<tr><td class=text align=center>" + drow1["awbdt"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["trk"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["awbno"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["city_name"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["country_code"].ToString().ToUpper() + "-" + drow1["destination_code"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["shptType"].ToString().ToUpper() + "</td><td class=text align=right>" + drow1["chargeable_wt"].ToString().ToUpper() + "</td><td class=text align=right>" + Math.Round(FreightAmt) + "</td><td class=text align=right>" + Math.Round(FscAmt) + "</td><td class=text align=right>" + Math.Round(TotalFreightAmt) + "</td><td class=text align=center nowrap>" + drow1["remarks"].ToString().ToUpper() + "</td><td class=text align=right nowrap>" + StaxStatus + "</td></tr>");

                        strtable2 += @"<tr><td class=text align=center>" + drow1["awbdt"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["trk"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["awbno"].ToString().ToUpper() + "</td><td class=text align=center nowrap>" + drow1["city_name"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["country_code"].ToString().ToUpper() + "-" + drow1["destination_code"].ToString().ToUpper() + "</td><td class=text align=center>" + drow1["shptType"].ToString().ToUpper() + "</td><td class=text align=right>" + drow1["chargeable_wt"].ToString().ToUpper() + "</td><td class=text align=right>" + Math.Round(FreightAmt) + "</td><td class=text align=right>" + Math.Round(FscAmt) + "</td><td class=text align=right>" + Math.Round(TotalFreightAmt) + "</td><td class=text align=center nowrap>" + drow1["remarks"].ToString().ToUpper() + "</td><td class=text align=right nowrap>" + StaxStatus + "</td></tr>";
                    }

                    total_ch_wt = total_ch_wt + Convert.ToDecimal(drow1["chargeable_wt"].ToString());
                    total_fr = total_fr + FreightAmt;
                    Total_FSCAmt += FscAmt;
                    Total_Totalfrt += TotalFreightAmt;
                    Total_frt += FreightAmt;
                    #endregion
                }
                //jj
                //Response.Write("<tr><td class=boldtext align=center colspan=12 height=1px valign=top><hr color='#000000'></td></tr>");
                //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round(total_ch_wt) + "</td><td class=boldtext align=right>" + Math.Round(Total_frt) + "</td><td class=boldtext align=right>" + Math.Round(Total_FSCAmt) + "</td><td class=boldtext align=right>" + Math.Round(Total_Totalfrt) + "</td><td class=boldtext align=center></td><td class=boldtext align=center></td></tr>");

                strtable2 += @"<tr><td class=boldtext align=center colspan=12 height=1px valign=top><hr color='#000000' size=1 width=100% /></td></tr>";

                strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round(total_ch_wt) + "</td><td class=boldtext align=right>" + Math.Round(Total_frt) + "</td><td class=boldtext align=right>" + Math.Round(Total_FSCAmt) + "</td><td class=boldtext align=right>" + Math.Round(Total_Totalfrt) + "</td><td class=boldtext align=center></td><td class=boldtext align=center></td></tr>";

                total_ch_wt = 0;

                //jj
                //Response.Write("<tr><td class=boldtext align=center colspan=12 height=1px valign=top><hr color='#000000'></td></tr>");
                //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext nowrap align=center>Total Amt</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round(Total_Totalfrt) + "</td><td class=boldtext align=center></td></tr>");

                strtable2 += @"<tr><td class=boldtext align=center colspan=12 height=1px valign=top><hr color='#000000' width=100%></td></tr>";

                strtable2 += @"</table>";

                strtable2 += @"<table border=0 width=100% align=center>";

                strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext colspan=2 align=left>Total Amt</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round(Total_Totalfrt) + "</td></tr>";

                strtable2 += @"<tr><td class=boldtext align=left colspan=8></td><td class=boldtext align=right colspan=2 valign=top><hr color='#000000' size=1 width=100% /></td></tr>";     
              
                decimal TotalRecievableAmt = 0;
                if (Convert.ToDateTime(to) < Convert.ToDateTime("07/01/2011"))
                {
                    TotalRecievableAmt = Math.Round(Total_Totalfrt, 2);
                }
                else
                {
                    #region else part
                    if (dt3.Rows.Count == AtaShipment)
                    {
                        Total_Totalfrt = Total_frtATAAMT;
                        TotalRecievableAmt = Total_frtATAAMT;
                    }
                    else
                    {
                        if (Convert.ToDateTime(to) < Convert.ToDateTime("07/01/2017"))
                        {
                            #region if condition
                            Total_Totalfrt = Total_Totalfrt - Total_frtATAAMT;
                            //jj
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>Service Tax @" + StaxRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((Total_Totalfrt * decimal.Parse(StaxRate)) / 100, 2) + "</td><td class=boldtext align=center></td></tr>");


                            //Just here Tax Details
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>Service Tax @" + StaxRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((Total_Totalfrt * decimal.Parse(StaxRate)) / 100, 2) + "</td><td class=boldtext align=center></td></tr>";

                            decimal StaxRateAmt = (Total_Totalfrt * (decimal.Parse(StaxRate))) / 100;

                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************

                            //jj
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>SB Cess Tax @" + SBCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((Total_Totalfrt * decimal.Parse(SBCessRate)) / 100, 2) + "</td><td class=boldtext align=center></td></tr>");
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>KK Cess Tax @" + KKCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((Total_Totalfrt * decimal.Parse(KKCessRate)) / 100, 2) + "</td><td class=boldtext align=center></td></tr>");

                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>SB Cess Tax @" + SBCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((Total_Totalfrt * decimal.Parse(SBCessRate)) / 100, 2) + "</td><td class=boldtext align=center></td></tr>";
                            
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>KK Cess Tax @" + KKCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((Total_Totalfrt * decimal.Parse(KKCessRate)) / 100, 2) + "</td><td class=boldtext align=center></td></tr>";

                            decimal SBCessAmt = (Total_Totalfrt * (decimal.Parse(SBCessRate))) / 100;
                            decimal KKCessAmt = (Total_Totalfrt * (decimal.Parse(KKCessRate))) / 100;

                            //jj
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>E. Cess @ " + EducationcessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((StaxRateAmt * (decimal.Parse(EducationcessRate))) / 100, 2) + "</td><td class=boldtext align=center></td></tr>");
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>E. Cess @ " + EducationcessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((StaxRateAmt * (decimal.Parse(EducationcessRate))) / 100, 2) + "</td><td class=boldtext align=center></td></tr>";

                            decimal EducCessRateAmt = (StaxRateAmt * (decimal.Parse(EducationcessRate))) / 100;
                            //jj
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>H.S.E.Ccess @ " + HEducCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((StaxRateAmt * (decimal.Parse(HEducCessRate))) / 100, 2) + "</td><td class=boldtext align=center></td></tr>");
                            
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>H.S.E.Ccess @ " + HEducCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((StaxRateAmt * (decimal.Parse(HEducCessRate))) / 100, 2) + "</td><td class=boldtext align=center></td></tr>";
                           
                            decimal HigherEducCessRateAmt = (StaxRateAmt * (decimal.Parse(HEducCessRate))) / 100;
                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            ////TotalRecievableAmt = Math.Round(Total_Totalfrt + StaxRateAmt +SBCessAmt + EducCessRateAmt + HigherEducCessRateAmt + Total_frtATAAMT, 2);
                            TotalRecievableAmt = Math.Round(Total_Totalfrt + StaxRateAmt + SBCessAmt + KKCessAmt + EducCessRateAmt + HigherEducCessRateAmt + Total_frtATAAMT, 2);
                            #endregion
                        }
                        else
                        {
                            #region Gst Applicable

                            if (CompGstNo.Substring(0, 2) == AgentGstNo.Substring(0, 2))
                            {
                                IGST = 0;
                                TotalCGST = Math.Round((Total_Totalfrt) * CGST / 100);
                                TotalSGST = Math.Round((Total_Totalfrt) * SGST / 100);
                                TotalIGST = Math.Round((Total_Totalfrt) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                            }
                            else
                            {
                                CGST = 0;
                                SGST = 0;
                                TotalCGST = Math.Round((Total_Totalfrt) * CGST / 100);
                                TotalSGST = Math.Round((Total_Totalfrt) * SGST / 100);
                                TotalIGST = Math.Round((Total_Totalfrt) * IGST / 100);
                                TotalGst = TotalCGST + TotalSGST + TotalIGST;
                            }

                            ////For Line Break
                            //strtable2 += @"<tr><td class=boldtext align=left colspan=8></td><td class=boldtext align=right colspan=2 valign=top><hr color='#000000' size=1 width=100% /></td></tr>";

                            /////Total_Totalfrt = Total_Totalfrt - Total_frtATAAMT;
                           
                            //jj
                             //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>CGST @" + CGST + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + TotalCGST + "</td><td class=boldtext align=center></td></tr>");
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap colspan=2>CGST @" + CGST + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + TotalCGST + "</td></tr>";

                            ///decimal StaxRateAmt = (Total_Totalfrt * (decimal.Parse(StaxRate))) / 100;

                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            
                            //jj
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>SGST @" + SGST + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + TotalSGST + "</td><td class=boldtext align=center></td></tr>");
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap colspan=2>SGST @" + SGST + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + TotalSGST + "</td></tr>";
                          
                            //jj
                           // Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>IGST @" + IGST + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + TotalIGST + "</td><td class=boldtext align=center></td></tr>");
                             strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap colspan=2>IGST @" + IGST + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + TotalIGST + "</td></tr>";

                            decimal SBCessAmt = (Total_Totalfrt * (decimal.Parse(SBCessRate))) / 100;

                            decimal KKCessAmt = (Total_Totalfrt * (decimal.Parse(KKCessRate))) / 100;

                            //jj
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>E. Cess @ " + EducationcessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((CGST * (decimal.Parse(EducationcessRate))) / 100, 2) + "</td><td class=boldtext align=center></td></tr>");
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap colspan=2>E. Cess @ " + EducationcessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((CGST * (decimal.Parse(EducationcessRate))) / 100, 2) + "</td></tr>";
                           
                            decimal EducCessRateAmt = (CGST * (decimal.Parse(EducationcessRate))) / 100;
                           
                            //jj
                            //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap>H.S.E.Ccess @ " + HEducCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((CGST * (decimal.Parse(HEducCessRate))) / 100, 2) + "</td><td class=boldtext align=center></td></tr>");
                            strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=left nowrap colspan=2>H.S.E.Ccess @ " + HEducCessRate + "%</td><td class=boldtext align=center></td><td class=boldtext align=right>" + Math.Round((CGST * (decimal.Parse(HEducCessRate))) / 100, 2) + "</td></tr>";
                            
                            decimal HigherEducCessRateAmt = (CGST * (decimal.Parse(HEducCessRate))) / 100;
                          
                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            ////TotalRecievableAmt = Math.Round(Total_Totalfrt + StaxRateAmt +SBCessAmt + EducCessRateAmt + HigherEducCessRateAmt + Total_frtATAAMT, 2);
                           
                            TotalRecievableAmt = Math.Round(Total_Totalfrt + TotalCGST + TotalSGST + TotalIGST + EducCessRateAmt + HigherEducCessRateAmt + Total_frtATAAMT, 2);
                            #endregion end of Gst Applicable
                        }
                    }
                    #endregion
                }
                //jj
                //Response.Write("<tr><td class=boldtext align=center></td><td class=boldtext align=center></td><td class=boldtext align=right colspan=6>Total Receivable from " + drow["agent_name"].ToString().ToUpper() + "</td><td class=boldtext align=right colspan=2><hr color='#000000'>INR " + Math.Round(TotalRecievableAmt) + "<hr color='#000000'></td></tr>");
                //Response.Write("<tr><td class=boldtext align=center colspan=12><br><br><br><hr></td></tr>");

                //For Line Break
                strtable2 += @"<tr><td class=boldtext align=left colspan=8></td><td class=boldtext align=right colspan=2 valign=top><hr color='#000000' size=1 width=100% /></td></tr>";

                strtable2 += @"<tr><td class=boldtext align=center></td><td class=boldtext align=right colspan=7>Total Receivable from " + drow["agent_name"].ToString().ToUpper() + "</td><td class=boldtext align=center></td><td text-align:right>INR " + Math.Round(TotalRecievableAmt) + "</td></tr>";

                //For Line Break
                strtable2 += @"<tr><td class=boldtext align=left colspan=8></td><td class=boldtext align=right colspan=2 valign=top><hr color='#000000' size=1 width=100% /></td></tr>";

                strtable2 += @"</table>";

                strtable2 += @"<table border=0 width=100% align=center>";

                ////Response.Write("<tr><td class=boldtext align=left colspan=12><span class=text>Please make payment in favour of </span><span class=boldtext>" + dt1.Rows[0]["company_name"].ToString().ToUpper() + @"</span></td></tr>");

                //jj
                //Response.Write("<tr><td class=boldtext align=left colspan=12><span class=text>Please make payment in favour of CONCORDE AIR HANDLING SERVICES PVT. LTD.<BR/> Please intimate your P.A.N. alongwith Registered office Address in writing,   on your letter head. This is required for issuing of TDS certificate.  OUR PAN NO:AAACC4245L, CIN No. U74899DL1993PTC052734. For more details contact Mr. Susheel Rautila -8376800325</span></td></tr>");

               // strtable2 += @"<tr><td class=boldtext align=center colspan=12><br></td></tr>";

                strtable2 += @"<tr><td class=boldtext align=left colspan=12><span class=text>Please make payment in favour of CONCORDE AIR HANDLING SERVICES PVT. LTD.<BR/> Please intimate your P.A.N. alongwith Registered office Address in writing,   on your letter head. This is required for issuing of TDS certificate.  OUR PAN NO:AAACC4245L, CIN No. U74899DL1993PTC052734. For more details contact Mr. Susheel Rautila -8376800325</span></td></tr>";

                strtable2 += @"<tr><td class=boldtext align=right colspan=12><hr color='#000000' size=1 width=100% /></td></tr>";

                ////Response.Write("<tr><td class=boldtext align=left colspan=12><span class=text>OUR GST NO. AAACC4245LST001.</span></td></tr>");
                // Response.Write("<tr class=heading ><td class=boldtext align=left colspan=12><marquee BEHAVIOR=ALTERNATE >::::::WE HAVE RECIEVED TDS EXEMPTION CERTIFICATE FY 2014-15 @1% w.e.f 17th June'14. PLEASE COLLECT AND DEDUCT ACCORDINGLY.:::::</marquee></td></tr>");
                /////Response.Write("</table><br><br style='page-break-before:always;'>");

                //jj
                //Response.Write("</table>");

                strtable2 += @"</table>";

                ///////Response.Write("<table  border=0 width=100% ><tr class=heading ><td styl=height: 10px;color: red colspan=3><font size=2px><b><marquee BEHAVIOR=ALTERNATE >:::::We have received TDS Exemption for the FY 2017-18 @1.00% effective from 08-05-2017 please collect the same and deduct accordingly::::</marquee></b></font></td></tr></table>");

                //jj
                //string image = "<table width=100% border=0><tr class=heading align=right><td width=70%><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'</td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table><br><br style='page-break-before:always;'>";
                //Response.Write(image);

                strtable2 += @"<table width=100% border=0><tr class=heading align=right><td width=70%><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'</td></tr><tr align=right><td><b>Authorised Signatory</b></td></tr></table><br><br style='page-break-before:always;'>";
               
                total_fr = 0;
                total_ch_wt = 0;
                ////}
                #endregion
            }
            #endregion
        }
        else
        {
            //Response.Write("<Center><span class=error> No Record Found </span></center>");
            strtable += @"<Center><span class=error> No Record Found </span></center>";
        }
        //jj
        //Response.Write("</td></tr></table>");
        strtable += strtable2;

        strtable += @"</td></tr></table>";

        #region start
        //        strtable = string.Empty;

//        strtable = @"<table align=left width=100%><tr><td valign=top align=left><table border=0 width=100% align=center>
//            <tr align=center><td colspan=8 align=center><font size=2><b>Invoice Date: 25/10/2017</b></font></td>
//            </tr>
//            </table>
//
//            <table border=0 width=100% align=center>
//                    <tr>
//                    <td colspan=5><img src='http://pace1.cargoflash.com/Airasia/images/gclogo_new.gif'></td>
//                    <td  align=left nowrap colspan=4>
//                    <p align=center class=boldtext>
//                    <font size=3>CONCORDE AIR HANDLING SERVICES PVT. LTD.</font>
//                        <BR> Fedex Airlines
//                        <br>17-B/28, 1st Floor D.B. Gupta Road Dev Nagar Karol Bagh New Delhi-11005
//                        <br> Ph :8376800325<br><font size=1>GST No: 07AAACC4245L1ZO </font>
//                        <br><font size=1>Cargo Sales Report </font>
//                        <br>From 01/10/2017- To 15/10/2017
//                    </p>
//                    </td>    
//                   </tr>
//                    <tr>
//                       <td colspan=3 class=boldtext>ASIATIC LOGISTICS PVT. LTD.<br>ADARCHINI PLAZA
//                            1ST FLOOR 93
//                            ADCHINI MAIN MEHRAULI ROAD
//                            NEW DELHI-110017
//                            NEW DELHI<br><br>IATA Code   14-3-5113
//                      </td>
//                       <td colspan=8>&nbsp;</td>
//                    </tr>
//                    <tr>
//                       <td colspan=3 class=boldtext>CIN NO.U74899DL1993PTC052734
//                            <br>INVOICE No: DELIP171873
//                            <br>GST No: 07AACCA3147P1ZH
//                            <br>HSN Code:996812
//                            <br>State Code:DELHI
//                            <br>Place Of Delivery:DELHI
//                      </td>
//                      <td colspan=8>&nbsp;</td>
//                   </tr>                    
//              </table>
//
//            <table>
//            <tr class=h1>
//               <td width=100% align=center colspan=12><font size=2><b><u>TAX INVOICE</u></b></font></td>
//            </tr>            
//            <tr>
//                <td align=center>Date</td>
//                <td align=center>TRK No.</td> 
//                <td align=center>AWB No.</td>
//                <td align=center>Origin</td>
//                <td align=center>Dest</td>
//                <td align=center>Type</td>
//                <td align=center>Chrg. Wt</td>
//                <td align=center >NN AMT</td>
//                <td align=center>FSC/OTHRchrgs/DGSchrgs</td>
//                <td align=center >Total Amt</td>
//                <td align=center>Remark</td>
//                <td align=center>Tax Status</td>
//            </tr>
//            <tr>
//               <td class=boldtext align=center colspan=12 height=2px valign=top><br/>
//                    <hr color='#000000' size=1 width=100% />
//               </td>
//            </tr>
//            <tr>
//               <td class=boldtext align=center colspan=12 height=1px valign=top>
//                    <hr color='#000000' size=1 width=100% />
//               </td>
//            </tr>
//
//            <tr>
//                <td class=boldtext align=center></td>
//                <td class=boldtext align=center></td>
//                <td class=boldtext align=center></td>
//                <td class=boldtext align=center></td>
//                <td class=boldtext align=center></td>
//                <td class=boldtext align=center></td>
//                <td class=boldtext align=right>0</td>
//                <td class=boldtext align=right>0</td>
//                 <td class=boldtext align=right>0</td>
//                <td class=boldtext align=right>0</td>
//                <td class=boldtext align=center></td>
//                <td class=boldtext align=center></td>
//            </tr>
//
//            <tr>
//               <td class=boldtext align=center colspan=12 height=1px valign=top><hr color='#000000' size=1 width=100% /></td>
//            </tr>
//            </table>
//
//            <table>
//                <tr>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext nowrap align=center>Total Amt</td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=right>0</td>                    
//                </tr> 
//               <tr>
//                    <td class=boldtext align=left colspan=8></td><td class=boldtext align=right colspan=2 valign=top><hr color='#000000' size=1 width=100% /></td>
//                </tr>  
//                <tr>   
//                    <td class=boldtext align=center></td>                          
//                    <td class=boldtext nowrap align=right colspan=7>Total Receivable from ASIATIC LOGISTICS PVT. LTD.</td>
//                    <td class=boldtext align=center></td>
//                    <td class=boldtext align=right>INR 0</td> 
//                </tr> 
//                <tr>
//                   <td class=boldtext align=left colspan=8></td><td class=boldtext align=right colspan=2 valign=top><hr color='#000000' size=1 width=100% /></td> 
//                </tr>             
//           </table>
//             <table>                
//                <tr>
//                  <td class=boldtext align=center colspan=12><br></td>
//                </tr>
//                <tr>
//                    <td class=boldtext align=left colspan=12>
//                        <span class=text>Please make payment in favour of CONCORDE AIR HANDLING SERVICES PVT. LTD.<BR/> 
//                        Please intimate your 
//                                            P.A.N. alongwith Registered office Address in writing,   on your letter head. This is required for issuing of TDS certificate. 
//                        OUR PAN NO:AAACC4245L, CIN No. 
//                                            U74899DL1993PTC052734. For more details contact Mr. Susheel Rautila -8376800325</span>
//                    </td>
//               </tr>
//                <tr>
//                   <td class=boldtext align=right colspan=12><hr color='#000000' size=1 width=100% /></td> 
//                </tr>  
//           </table>
//
//        <table width=100% border=0>
//            <tr class=heading align=right><td width=70%><img src='http://systems.cargoflash.com/images/ConCordeAirHandling.jpg'</td></tr>
//            <tr align=right><td><b>Authorised Signatory</b></td></tr>
//        </table>
//
//                <br><br style='page-break-before:always;'></td></tr></table>";
        #endregion 

        StringReader sr = new StringReader(strtable.ToString());
        Document pdfDoc = new Document(PageSize._11X17, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();      
        htmlparser.Parse(sr);        
        pdfDoc.Close();
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=CSR.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.End();
    }

    public string DateFormat(string strdate)
    {
        string[] strD = strdate.Split('/');
        return strD[1] + "/" + strD[0] + "/" + strD[2];
    }

    private void loadAgent()
    {
        rbtnDSelect.Checked = true;
        rbtnSelectAll.Checked = false;
        lstAgent.Items.Clear();
        con = new SqlConnection(strCon);
            con.Open();
            try
            {
                cmd = new SqlCommand("select airline_id,belongs_to_city,Csr_Footer from airline_detail where airline_detail_id=" + ddlAirLine.SelectedValue.Trim() + "", con);
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {                   
                    csrFooter = dr["Csr_Footer"].ToString();
                    char ch = (char)System.Windows.Forms.Keys.Return;
                    char ch2 = (char)System.Windows.Forms.Keys.Space;
                    string ch1 = Convert.ToString(ch);
                    string ch3 = Convert.ToString(ch2);
                    csrFooter = csrFooter.Replace(ch1, "<br>");
                    csrFooter = csrFooter.Replace(ch3, "&nbsp;");
                }
                dr.Dispose();
                cmd.Dispose();

                ////string query = "select * from agent_master inner join agent_branch on agent_branch.agent_id=agent_master.agent_id where belongs_to_city=6 order by agent_name";
                //string query = "select * from agent_master inner join agent_branch on agent_branch.agent_id=agent_master.agent_id where belongs_to_city in(6) order by agent_name";
                
                cmd = new SqlCommand("LoadFeedexCsrAgent_new", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Airline_Acess", ddlAirLine.SelectedValue.Trim());
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lstAgent.Items.Add(new System.Web.UI.WebControls.ListItem(dr["agent_name"].ToString(), dr["agent_id"].ToString()));
                }
            }
            catch (SqlException ex)
            {
                string strer = ex.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        
    }

    protected void hdnDate_ValueChanged(object sender, EventArgs e)
    {

    }

    protected void hdnDate_ValueChanged1(object sender, EventArgs e)
    {

    }
}
