using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AgentSMSDetails : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string strQueryString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }

        else if (!IsPostBack && Request.QueryString["DATA"].ToString() != "")
        {
            strQueryString = ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "id");
             DataTable dt_agent = dw.GetAllFromQuery("SELECT AM.Agent_Name as Agent_Name,CM.City_code+'-'+Cm.city_name  as city,Ab.Agent_phone as Agent_phone From Agent_Master AM inner join Agent_Branch AB on Ab.Agent_ID=AM.Agent_ID inner join City_master CM on CM.city_id=AB.belongs_to_city where Ab.agent_branch_id=" + strQueryString + "");
            if (dt_agent.Rows.Count > 0)
            {
                lblAgent.Text = dt_agent.Rows[0]["Agent_Name"].ToString();
                lblCity.Text = dt_agent.Rows[0]["city"].ToString();
                txtMobNo.Text = dt_agent.Rows[0]["Agent_phone"].ToString();
            }
        }

    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            string strquery = " update  Agent_Branch set Agent_phone=@Agent_phone where Agent_branch_id=" + ParamUtils.WebParam.GetQuery(Request.Params["DATA"].ToString(), "id");
            cmd = new SqlCommand(strquery, con);
            cmd.Parameters.AddWithValue("@Agent_phone", txtMobNo.Text);
            cmd.ExecuteNonQuery();
            Response.Redirect("AgentSms.aspx");
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }



    }
    protected void brnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AgentSms.aspx");
    }
}
