using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class BookingEnquiry_AwbCancell : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DisplayWrap dw = new DisplayWrap();
    SqlTransaction trans;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        else if (!IsPostBack && Request.QueryString["sno"].ToString() != "")
        {
            //DataTable dt_agent = dw.GetAllFromQuery("SELECT Ag.Agent_name as Agent_name,AB.Agent_Address as Agent_Address,Be.No_of_packages as No_of_packages,Be.commodity as commodity,convert(varchar,handover_date,103) as handover_date,be.remarks as remarks,be.ccremarks as ccremarks FROM Booking_Enquiry BE  inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join Agent_branch AB on AB.Agent_ID=AG.Agent_ID inner join City_Master CM on CM.city_id=BE.City where Booking_EnquiryNo=" + SRno + "");
            DataTable dt_agent = dw.GetAllFromQuery("SELECT Ag.Agent_name as Agent_name,AB.Agent_Address as Agent_Address,Be.No_of_packages as No_of_packages,Be.awb_no as awb_no,convert(varchar,handover_date,103) as handover_date,be.remarks as remarks,be.ccremarks as ccremarks FROM Booking_Enquiry BE  inner join Agent_master AG on AG.Agent_ID=BE.Agent_ID inner join Agent_branch AB on AB.Agent_ID=AG.Agent_ID inner join City_Master CM on CM.city_id=BE.City where Booking_EnquiryNo=" + Request.QueryString["sno"].ToString() + "");
            if (dt_agent.Rows.Count > 0)
            {
           lblAwbno.Text=dt_agent.Rows[0]["awb_no"].ToString();
            }
        }
    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
    Update();
    }
    public void Update()
    {
        string stradd = "";
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            trans = con.BeginTransaction();

     cmd = new SqlCommand("update stock_master set status=@status where airwaybill_no='" + lblAwbno.Text + "'", con,trans);

            cmd.Parameters.AddWithValue("@Status", '8');           
            cmd.ExecuteNonQuery();
         cmd = new SqlCommand("update booking_enquiry set ccremarks=@ccremarks,status=@status where booking_enquiryNo='" + Request.QueryString["sno"].ToString() + "'", con, trans);

            cmd.Parameters.AddWithValue("@ccremarks", txtRemarks.Text);
            cmd.Parameters.AddWithValue("@Status", 'C');      
            cmd.ExecuteNonQuery();
            trans.Commit();
            cmd.Dispose();
            con.Close();
            Response.Redirect("Booking_enquiryDetails.aspx");
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            trans.Rollback();
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
}
