using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Issue_Can_Edit : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    SqlTransaction trans;
    string Import_AWB_ID;
    string Import_AWB_No;
    string Import_Origin;
    string No_of_Packages;
    string Gross_Weight;
    string Import_Flight_No;
    string Flight_Date;
    string IGM_No;
    string IGM_Date;
    string Import_Flight_Open_ID;
    string Nature_of_Goods;

    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {

            if (!IsPostBack && Request.QueryString["Import_AWB_ID"] != null)
            {
                //btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                Import_AWB_ID = Convert.ToString(Request.QueryString["Import_AWB_ID"]);
                string str1 = "select IFO.Import_Flight_Open_ID as 'Import_Flight_Open_ID',IA.Import_AWB_No as 'Import_AWB_No',DM.Destination_Name as 'Destination_Name',IA.No_of_Packages as 'No_of_Packages',IA.Gross_Weight as 'Gross_Weight',IFO.Import_Flight_No as'Import_Flight_No',convert(varchar,IFO.Flight_Date,103) as 'Flight_Date',IFO.IGM_No as 'IGM_No',convert(varchar,IFO.IGM_Date,103) as 'IGM_Date',IA.Nature_of_Goods as 'Nature_of_Goods',IA.CAN_Status as 'CAN_Status',IA.Delivery_Order as 'Delivery_Order',IA.No_of_Houses as 'No_of_Houses',IA.Freight_Type as 'Freight_Type',IA.Delivery_Order_Rate_House as 'Delivery_Order_Rate_House',IA.Delivery_Order_Rate_Master as 'Delivery_Order_Rate_Master',CN.Freight_Charges as 'Freight_Charges',CN.Exchange_Rate as Exchange_Rate,CN.Currency as 'Currency',CN.Currency_Adjustment_Factor as 'Currency_Adjustment_Factor',CN.Service_Tax_Amount as 'Service_Tax_Amount',IA.Concerned_Person as 'Concerned_Person' from Import_AWB IA inner join Import_Flight_Open IFO on IA.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID inner join CAN CN  on CN.Import_Flight_Open_ID=IFO.Import_Flight_Open_ID inner join Destination_Master DM on IFO.Import_Origin=DM.Destination_ID where IA.Import_AWB_ID='" + Import_AWB_ID + "'";
                    con = new SqlConnection(strCon);
                    con.Open();
                    com = new SqlCommand(str1, con);
                    dr = com.ExecuteReader();
                    dr.Read();
                    txtAwb.Text=dr["Import_AWB_No"].ToString();
                    //txtOrigin.Text = dr["Import_Origin"].ToString();
                    txtPcs.Text = dr["No_of_Packages"].ToString();
                    txtGw.Text = dr["Gross_Weight"].ToString();
                    txtFltNo.Text = dr["Import_Flight_No"].ToString();
                    txtFlDate.Text = dr["Flight_Date"].ToString();
                    txtIgmNo.Text = dr["IGM_No"].ToString();
                    txtIgmDate.Text = dr["IGM_Date"].ToString();
                    txtContents.Text = dr["Nature_of_Goods"].ToString();
                    txtFrChg.Text = dr["Freight_Charges"].ToString();
                    txtExRate.Text = dr["Exchange_Rate"].ToString();
                    txtCurrency.Text = dr["Currency"].ToString();
                    txtCaf.Text = dr["Currency_Adjustment_Factor"].ToString();
                    txtServiceTax.Text = dr["Service_Tax_Amount"].ToString();
                    txtcustomer.Text = dr["Concerned_Person"].ToString();
                    txtFrChg.ReadOnly = true;
                    txtExRate.ReadOnly = true;
                    txtCurrency.ReadOnly = true;
                    txtCaf.ReadOnly = true;
                    txtServiceTax.ReadOnly = true;
                    con.Close();

                }

            }
        }
   
    public void issue()
    {
        //btnUpdate.Attributes.Add("onclick", "return CheckEmpty();");        
        con = new SqlConnection(strCon);//Making Connection  
        if (lblStaus.Text == "14")
        {
            if (lblFreightType.Text == "Collect")
            {
                string insertQ, SelectQ, UpdateQ, UpdateQ1;
                try
                {
                    con.Open();
                    trans = con.BeginTransaction();

                    // Insert into CAN
                    {
                        string S_charge = "select Service_Tax from Fix_Charges";
                        com = new SqlCommand(S_charge, con, trans);
                        double S_Tax = Convert.ToDouble(com.ExecuteScalar().ToString());
                        com.ExecuteNonQuery();
                        insertQ = "insert into CAN(Import_AWB_ID,Import_Flight_Open_ID,Freight_Charges,Exchange_Rate,Currency,Currency_Adjustment_Factor,Service_Tax_Amount) values('" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "','" + lblFlID.Text + "','" + txtFrChg.Text.Trim() + "','" + txtExRate.Text.Trim() + "','" + txtCurrency.Text.Trim() + "','" + txtCaf.Text.Trim() + "','" + txtServiceTax.Text.Trim() + "')";

                        com = new SqlCommand(insertQ, con, trans);
                        com.ExecuteNonQuery();
                        //select Identity From CAN Table
                        SelectQ = "select max(CAN_ID) From CAN ";
                        com = new SqlCommand(SelectQ, con, trans);
                        int CID = Convert.ToInt16(com.ExecuteScalar().ToString());
                        //string Fr_Charge = dr["Freight_Charges"].ToString();
                        //string Ex_Rate = dr["Exchange_Rate"].ToString();
                        //string Fr_Charge = dr["Currency_Adjustment_Factor"].ToString();
                        com.ExecuteNonQuery();
                        double Total_Amount;
                        double A = double.Parse(txtFrChg.Text.Trim()) * double.Parse(txtExRate.Text.Trim());
                        double B = double.Parse(txtCaf.Text.Trim()) * A;

                        double C = double.Parse(lblNoOfHouses.Text.Trim()) * double.Parse(lblDlhouseRate.Text.Trim());
                        double D = 1 * double.Parse(lblDlRateMaster.Text.Trim());
                        double E = ((A + B + C + D) * S_Tax) / 100;
                        Total_Amount = A + B + C + D + E;

                        //Update Import_AWB table
                        UpdateQ = "update Import_AWB set CAN_Status='13',Payable_Amount='" + Total_Amount + "' where Import_AWB_ID='" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "'";
                        com = new SqlCommand(UpdateQ, con, trans);
                        com.ExecuteNonQuery();

                        UpdateQ1 = "update CAN set Service_Tax_Amount='" + E + "' where CAN_ID='" + CID + "'";
                        com = new SqlCommand(UpdateQ1, con, trans);
                        com.ExecuteNonQuery();

                    }

                    trans.Commit();
                    con.Close();
                    Response.Redirect("Browse_ImportAwb.aspx");

                }
                catch (SqlException se)
                {
                    string err = se.Message;
                    trans.Rollback();
                    lblmsg.Text = err;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            else if (lblFreightType.Text == "Prepaid")
            {
                string insertQ, SelectQ, UpdateQ, UpdateQ1;
                try
                {
                    con.Open();
                    trans = con.BeginTransaction();

                    // Insert into CAN
                    {
                        string S_charge = "select Service_Tax from Fix_Charges";
                        com = new SqlCommand(S_charge, con, trans);
                        double S_Tax = Convert.ToDouble(com.ExecuteScalar().ToString());
                        com.ExecuteNonQuery();
                        insertQ = "insert into CAN(Import_AWB_ID,Import_Flight_Open_ID,Freight_Charges,Exchange_Rate,Currency,Currency_Adjustment_Factor,Service_Tax_Amount) values('" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "','" + lblFlID.Text + "','" + txtFrChg.Text.Trim() + "','" + txtExRate.Text.Trim() + "','" + txtCurrency.Text.Trim() + "','" + txtCaf.Text.Trim() + "','" + txtServiceTax.Text.Trim() + "')";

                        com = new SqlCommand(insertQ, con, trans);
                        com.ExecuteNonQuery();
                        //select Identity From CAN Table
                        SelectQ = "select max(CAN_ID) From CAN ";
                        com = new SqlCommand(SelectQ, con, trans);
                        int CID = Convert.ToInt16(com.ExecuteScalar().ToString());
                        //string Fr_Charge = dr["Freight_Charges"].ToString();
                        //string Ex_Rate = dr["Exchange_Rate"].ToString();
                        //string Fr_Charge = dr["Currency_Adjustment_Factor"].ToString();
                        com.ExecuteNonQuery();
                        double Total_Amount;
                        double A = double.Parse(txtFrChg.Text.Trim()) * double.Parse(txtExRate.Text.Trim());
                        double B = double.Parse(txtCaf.Text.Trim()) * A;

                        double C = double.Parse(lblNoOfHouses.Text.Trim()) * double.Parse(lblDlhouseRate.Text.Trim());
                        double D = 1 * double.Parse(lblDlRateMaster.Text.Trim());
                        double E = ((A + B + C + D) * S_Tax) / 100;
                        Total_Amount = C + D + E;

                        //Update Import_AWB table
                        UpdateQ = "update Import_AWB set CAN_Status='13',Payable_Amount='" + Total_Amount + "' where Import_AWB_ID='" + Convert.ToString(Request.QueryString["Import_AWB_ID"]) + "'";
                        com = new SqlCommand(UpdateQ, con, trans);
                        com.ExecuteNonQuery();

                        UpdateQ1 = "update CAN set Service_Tax_Amount='" + E + "' where CAN_ID='" + CID + "'";
                        com = new SqlCommand(UpdateQ1, con, trans);
                        com.ExecuteNonQuery();

                    }

                    trans.Commit();
                    con.Close();
                    Response.Redirect("Browse_ImportAwb.aspx");

                }
                catch (SqlException se)
                {
                    string err = se.Message;
                    trans.Rollback();
                    lblmsg.Text = err;
                }
                finally
                {
                    if (con != null && con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Browse_ImportAwb.aspx");
    }
    protected void btnIssue_Click(object sender, EventArgs e)
    {
        issue();

    }
}
