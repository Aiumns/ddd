using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Net;
/// <summary>
/// created by Rakhi on 2 Jan 2008
/// </summary>

public partial class AWB_Fee_Report : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adp;
    SqlCommand com = null;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        btnsearch.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
        {
            //set Hidden field on IP Basis
            if (IPCheck())
            {
                hdnCheckIP.Value = "Internal";
            }
            else
            {
                hdnCheckIP.Value = "Outer";
                //Generate OTP on first call to page
                OTPPwd();
            }
            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            hdnDate.Value = first.ToString();
            txtfromdate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txttodate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            AirlineNamePlusCode();
        }
    }
    public void AirlineNamePlusCode()
    {
        try
        {
            String airline_access = Session["AIRLINEACCESS"].ToString();
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ddlairlinename.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["airline_detail_id"])));

            }
            cmd.Dispose();
        }
        catch (Exception eror)
        {
            string st = eror.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
            cmd.Dispose();

        }
    }
  
    public void showdata()
    {
        con = new SqlConnection(strCon);
        DataSet ds = new DataSet();        
        //cmd = new SqlCommand("select a.Import_Flight_No, a.Flight_Date, b.Import_AWB_No,b.Gross_Weight,(SELECT Exchange_Rate FROM Exchange_Rate WHERE From_Date<='" + FormatDateDD(TextBox1.Text) + "' AND To_Date>='" + FormatDateDD(txttodate.Text) + "') AS Exchange_Rate from Import_Flight_Open a inner join Import_AWB b on a.Import_Flight_Open_ID=b.Import_Flight_Open_ID where a.Flight_Date between '" + FormatDateDD(TextBox1.Text) + "' and '" + FormatDateDD(txttodate.Text) + "' and a.Airline_Detail_ID='" + ddlairlinename.SelectedValue + "' ", con);
        cmd = new SqlCommand("select s.AirWayBill_No,convert(varchar,s.AWB_Date,103) as 'AWB_Date',s.Charged_Weight,s.Destination_Code,(case when s.DueCarrier_Type='PREPAID' then s.AWB_Fees else 0 end )as Prepaid_AWB_Fees,(case when s.DueCarrier_Type='Collect' then s.AWB_Fees else 0 end )as Collect_AWB_Fees from sales s where s.AWB_Date between '" + FormatDateDD(txtfromdate.Text) + "' and '" + FormatDateDD(txttodate.Text) + "' and s.Airline_Detail_ID='" + ddlairlinename.SelectedValue + "'", con); 
        adp = new SqlDataAdapter(cmd);
        adp.Fill(ds);
        grd.DataSource = ds;
        grd.DataBind();
        countRecord();
        cmd.Dispose();
        con.Close();
    }
    private void countRecord()
    {

        decimal ch_wt = 0;
        decimal awb_pp = 0;
        decimal awb_cc = 0;

        for (int i = 0; i < grd.Rows.Count; i++)
        {
            GridViewRow gr = grd.Rows[i];

            ch_wt = ch_wt + decimal.Parse(((Label)(gr.FindControl("Label1"))).Text);
            awb_pp = awb_pp + decimal.Parse(((Label)(gr.FindControl("Label2"))).Text);
            awb_cc = awb_cc + decimal.Parse(((Label)(gr.FindControl("Label3"))).Text);

            ((Label)(grd.FooterRow.FindControl("lblFootercwt"))).Text = ch_wt.ToString();
            ((Label)(grd.FooterRow.FindControl("lblFooterawb_pp"))).Text = awb_pp.ToString();
            ((Label)(grd.FooterRow.FindControl("lblFooterawb_cc"))).Text = awb_cc.ToString();

        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split('/');
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string GetUserIp()
    {
        string VisitorsIPAddr = string.Empty;
        //Users IP Address.
        if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
        {
            //To get the IP address of the machine and not the proxy
            VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
        }
        else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
        {
            VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
        }
        return VisitorsIPAddr;



    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        #region IPCheck
        //string IP = GetUserIp();
        //if (IP != "")
        //{
        //    string[] ip_addrs = IP.Split('.');
        //    if (ip_addrs.Length == 4)
        //    {

        //        con = new SqlConnection(strCon);
        //        con.Open();
        //        string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on)VALUES( '" + IP + "','" + DateTime.Now + "')";
        //        com = new SqlCommand(cInsert, con);
        //        com.ExecuteNonQuery();
        //        con.Close();


        //        if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
        //        {
        //        }
        //        else
        //        {
        //            //ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');</script>");

        //            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');", true);
        //            return;
        //        }
        //    }
        //    else
        //    {
        //        //ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');</script>");

        //        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');", true);
        //        return;
        //    }
        //}
        //else
        //{
        //    //ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');</script>");

        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Sorry, Your are not Authorized to view this report. For access pls contact asrao@cargoflash.com');", true);
        //    return;
        //}
        #endregion

        if (hdnCheckIP.Value == "Outer")
        {

            if (hdnOTP.Value == ViewState["currentOtp"].ToString())
            {
            }
            else
            {
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Invalid OTP, Please Check.');</script>");
            }
        }
        showdata();
    }
    #region Generate Unique One Time Password
    private void OTPPwd()
    {
        string oTP = Convert.ToString(DateTime.Now.Second + 70096 + DateTime.Now.Minute);
        ViewState["currentOtp"] = oTP;

        SendSMS("Your OTP is: " + oTP + " ,Use these 5 digit's code to view the report.");

    }
    #endregion
    #region TO Check IP whether access from outside from office or not
    private Boolean IPCheck()
    {
        #region IPCheck
        string IP = GetUserIp();//"178.1.2.63";
        if (IP != "")
        {
            string[] ip_addrs = IP.Split('.');
            if (ip_addrs.Length == 4)
            {
                string currentPageName = System.IO.Path.GetFileName(Request.Url.AbsolutePath);
                con = new SqlConnection(strCon);
                con.Open();
                string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on,Email_ID,Page_Name)VALUES( '" + IP + "','" + DateTime.Now + "','" + Session["EMailID"].ToString() + "','" + currentPageName + "')";
                com = new SqlCommand(cInsert, con);
                com.ExecuteNonQuery();
                con.Close();


                if ((ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
        #endregion
    }
    #endregion

    #region For Sending Alert on SMS
    public void SendSMS(string fmessage)
    {
        try
        {

            int Status = 0;
            string StatusMessage = "";
            string str = "";
            string pushURL = "http://www.myvaluefirst.com/smpp/sendsms?username=cargoflash&password=cargohtp&to=@mobileno&from=Cargoflash&text=@message";
            pushURL = pushURL.Replace("@message", fmessage);
            pushURL = pushURL.Replace("@mobileno", GetMobileNo());
            // Get HTML data
            WebClient client = new WebClient();
            Stream data = client.OpenRead(pushURL);
            StreamReader reader = new StreamReader(data);
            str = reader.ReadToEnd();
            data.Close();
            if (str.StartsWith("0,"))
                Status = 0;
            else
                Status = 1;
            StatusMessage = str;
            str = StatusMessage.Substring(StatusMessage.IndexOf("Sent") + "Sent".Length + 1).Trim();
        }
        catch (Exception ee)
        {

        }
    }
    #endregion
    private string GetMobileNo()
    {
        string mobileNo = "";
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            cmd = new SqlCommand("SELECT Mobile FROM dbo.User_Master WHERE Email='" + Convert.ToString(Session["EMailID"]) + "'", con);
            mobileNo = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
        return mobileNo;
    }
}
