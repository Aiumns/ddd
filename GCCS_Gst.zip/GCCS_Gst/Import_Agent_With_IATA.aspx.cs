﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data.OleDb;
using System.IO;
using System.Collections.Generic;
using Excel;
using System.Net;
using System.Linq;
public partial class Import_Agent_With_IATA : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand com;
    SqlTransaction trans = null;
    DataSet ds;
    string TodayDate, LoginID, sessionValue;
    public string strLen = "";
    int agentID, BranchID;
    int CityId;
    string ts1, loginid;
    DataTable dtall;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  // ConnectionString
    bool finaltransStatus = false;
    string finaltransStatusstr = string.Empty;
    bool Agentflag = false;
    DataTable Exceldt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            TodayDate = DateTime.Now.ToShortDateString();           
            loginid = Session["EMailID"].ToString();
            if (!IsPostBack)
            {
                CityName();
                OfflineCityName();
            }
        }
    }
    protected void btnSample_Click(object sender, EventArgs e)
    {
        try
        {
            string strURL = "Sample/Sample_Format_IATA.xlsx";         
            WebClient req = new WebClient();
            HttpResponse response = HttpContext.Current.Response;
            response.Clear();
            response.ClearContent();
            response.ClearHeaders();
            response.Buffer = true;
            response.AddHeader("Content-Disposition", "attachment;filename=\"" + Server.MapPath(strURL) + "\"");
            byte[] data = req.DownloadData(Server.MapPath(strURL));
            response.BinaryWrite(data);
            response.End();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
        }
    }
    public static string RemoveWhitespace(string input)
    {
        return new string(input.ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());
    }
    protected DataTable RemoveEmptyRows(DataTable dt)
    {
        DataTable validData = dt.Copy();
        //DataTable invalidData=dt.Clone();
        int index = 0;
        int indx = 0;
        if (dt.Columns[0].ColumnName.Any(char.IsWhiteSpace) == true || dt.Columns[1].ColumnName.Any(char.IsWhiteSpace) == true ||
                 dt.Columns[2].ColumnName.Any(char.IsWhiteSpace) == true || dt.Columns[3].ColumnName.Any(char.IsWhiteSpace) == true ||
                 dt.Columns[4].ColumnName.Any(char.IsWhiteSpace) == true || dt.Columns[5].ColumnName.Any(char.IsWhiteSpace) == true ||
                 dt.Columns[6].ColumnName.Any(char.IsWhiteSpace) == true || dt.Columns[7].ColumnName.Any(char.IsWhiteSpace) == true ||
                 dt.Columns[8].ColumnName.Any(char.IsWhiteSpace) == true || dt.Columns[9].ColumnName.Any(char.IsWhiteSpace) == true ||
                 dt.Columns[10].ColumnName.Any(char.IsWhiteSpace) == true || dt.Columns[11].ColumnName.Any(char.IsWhiteSpace) == true ||
                 dt.Columns[12].ColumnName.Any(char.IsWhiteSpace) == true)
           {
            //These all array item sample of Excell Sheet column If Update column in existing sample sheet then must update here also     
              String[] arr2 = {"Agent_Name","IATA_Code","IATA_Commission","Credit_Limit","Agent_Address","Agent_Phone", "Agent_Contactno", "Agent_Fax",
                                   "Agent_Email", "Concerned_Person","CSR_Contact_Person", "CSR_Email", "Tan_No", "Pan_No"};
            foreach (DataColumn dc in validData.Columns)
            {
                //Remove All white Space From Column Name
                validData.Columns[indx].ColumnName = RemoveWhitespace(validData.Columns[indx].ColumnName.ToString());
                //Check Column Name With Existing Saple Excell Sheet And Update 
                if (validData.Columns[indx].ColumnName != arr2[indx])
                {
                    validData.Columns[indx].ColumnName = arr2[indx];
                }
                validData.AcceptChanges();
                indx = indx + 1;
            }
        }
        foreach (DataRow row in validData.Rows)
        {
            if (String.IsNullOrEmpty(row["Agent_Name"].ToString()) && String.IsNullOrEmpty(row["IATA_Code"].ToString()) && String.IsNullOrEmpty(row["IATA_Commission"].ToString())
             && String.IsNullOrEmpty(row["Credit_Limit"].ToString()) && String.IsNullOrEmpty(row["Agent_Address"].ToString())
             && String.IsNullOrEmpty(row["Agent_Phone"].ToString()) && String.IsNullOrEmpty(row["Agent_Contactno"].ToString())
             && String.IsNullOrEmpty(row["Agent_Fax"].ToString()) && String.IsNullOrEmpty(row["Agent_Email"].ToString())
             && String.IsNullOrEmpty(row["Concerned_Person"].ToString()) && String.IsNullOrEmpty(row["CSR_Contact_Person"].ToString())
             && String.IsNullOrEmpty(row["CSR_Email"].ToString()) && String.IsNullOrEmpty(row["Tan_No"].ToString())
             && String.IsNullOrEmpty(row["Pan_No"].ToString()))
              {
                //Remove Empty Row                
                validData.Rows.RemoveAt(index);
                index = index - 1;
              }
            index += 1;
        }
        return validData;
    }
    protected void ReceiveExcelsheet()
    {      
        string Extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
        List<string> message = new List<string>();
        IExcelDataReader excelReader;
        if (Extension == ".xls")
        {
            //for excel 2003
            excelReader = ExcelReaderFactory.CreateBinaryReader(FileUpload1.PostedFile.InputStream);
        }
        else
        {
            // for Excel 2007
            excelReader = ExcelReaderFactory.CreateOpenXmlReader(FileUpload1.PostedFile.InputStream);
        }
        excelReader.IsFirstRowAsColumnNames = true;
        //excelReader.Read();
        DataSet result = excelReader.AsDataSet();
        excelReader.IsFirstRowAsColumnNames = true;
        if (result.Tables[0].Rows.Count > 0)
        {
            Session["ExcelSSSS"] = null;
            Session["ExcelSSSS"] = RemoveEmptyRows(result.Tables[0]);
        }
        else
        {
            Session["ExcelSSSS"] = null;
            excelReader.Close();
        }
        excelReader.Close();
    }
    public bool IsUserIdExist(DataTable dtparam,string AgentEmailId,string CsrEmailid)     // check for Login Id Exists or Not
      {
        try
        {
            DataTable dt_copy = dtparam.Copy();
            if (dt_copy.Columns.Count > 11)
            {
                dt_copy.Columns.Remove("IATA_Code");
                dt_copy.Columns.Remove("IATA_Commission");
                dt_copy.Columns.Remove("Credit_Limit");
                dt_copy.AcceptChanges();
            }
            con = new SqlConnection(strCon);
            con.Open();
            string selectloginid;
            selectloginid = "UseridExist";
            com = new SqlCommand(selectloginid, con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@BulkImport", dt_copy);
            com.Parameters.AddWithValue("@AgentEmailId", AgentEmailId);
            com.Parameters.AddWithValue("@CSR_Email", CsrEmailid);
            SqlDataReader sdr = com.ExecuteReader();
            if (sdr.Read())
            {
                if (sdr["Email_ID"].ToString() == "" || sdr["Email_ID"].ToString() == null)
                {
                    con.Close();
                    sdr.Close();
                    return false;

                }
                else
                {
                    con.Close();
                    sdr.Close();      
                    return true;
                }
            }
            else
            {
                con.Close();
                sdr.Close();                    
                return false;
            }            
            
        }
        catch (Exception)
        {
            return false;
        }       
    }
    public bool IsAgentNameExist(DataTable dtparam,string Agentname)        // Check Agent Name Exists.
    {
        try
        {          
            DataTable dt_copy = dtparam.Copy();
            if (dt_copy.Columns.Count > 11)
            {
                dt_copy.Columns.Remove("IATA_Code");
                dt_copy.Columns.Remove("IATA_Commission");
                dt_copy.Columns.Remove("Credit_Limit");
                dt_copy.AcceptChanges();
            }          
            con = new SqlConnection(strCon);
            con.Open();
            string query = "AgentNameExist";
            com = new SqlCommand(query, con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@BulkImport", dt_copy);
            com.Parameters.AddWithValue("@Agentname", Agentname);
            SqlDataReader reader = com.ExecuteReader();
            if (reader.Read())
            {
                if (reader["Agent_Name"].ToString() == "" || reader["Agent_Name"].ToString() == null)
                {
                    Agentflag = false;
                }
                else
                {
                    Agentflag = true;
                }
            }
            con.Close();
            reader.Close();
        }
        catch (Exception)
        {
            Agentflag = false;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return Agentflag;    
    }
    protected string FindCityName()        // Split City Name
    {
        string str = txtCity.SelectedItem.Text;
        string str1;
        int j = str.IndexOf("-") + 1;
        int k = str.Length;
        str1 = str.Substring(j);
        return str1;
    }
    public bool checkCityName()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string citycode = txtCity.SelectedItem.Text;
        string OfflineCityCode = ddlOfflineCity.SelectedItem.Text;
        int m = citycode.IndexOf("-");
        if (m > 0)
        {
            string city_code = citycode.Substring(0, m - 1);
            string selectloginid;
            selectloginid = "select City_Code+'-'+City_Name from City_Master  where City_Code=@cityName or City_Name=@City_CodeId";
            com = new SqlCommand(selectloginid, con);
            com.Parameters.AddWithValue("@cityName", city_code);
            com.Parameters.AddWithValue("@City_CodeId", FindCityName());
            SqlDataReader sdr = com.ExecuteReader();
            if (sdr.Read())
            {
                con.Close();
                con.Open();
                return true;
            }
            else
            {
                con.Close();
                con.Open();
                return false;
            }
        }
        else
        {
            lblMessage.Text = "select Valid City";
            lblMessage.Visible = true;
            return false;
        }
    }
    protected string DataUpload(DataTable dtlist)
    {
        try
           {
                finaltransStatusstr = string.Empty; 
                for (int ii = 0; ii < dtlist.Rows.Count; ii++)
                {
                    if(!IsUserIdExist(dtlist, Convert.ToString(dtlist.Rows[ii]["Agent_Email"]), Convert.ToString(dtlist.Rows[ii]["CSR_Email"])))
                      {
                         if (!IsAgentNameExist(dtlist, Convert.ToString(dtlist.Rows[ii]["Agent_Name"])))
                            {                           
                            ts1 = string.Empty;
                            string insertQ, insertQ2, insertQ3;
                            con = new SqlConnection(strCon);
                            con.Open();
                            for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // values store in listbox
                            {
                                if (CheckAirlineAccess.Items[i].Selected)
                                {
                                    ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
                                }
                            }
                            ts1 = ts1.Remove(ts1.LastIndexOf(","));
                            trans = con.BeginTransaction();
                            string strquery = string.Empty;
                            string str = txtCity.SelectedItem.Text;
                            // string str = "ADD-Addis Ababa";
                            string OfflineCity = ddlOfflineCity.SelectedValue;
                            string str1;
                            int j = str.IndexOf("-") + 1;
                            int k = str.Length;
                            str1 = str.Substring(0, j - 1);
                            string id = "00001";
                            SqlCommand cmd = new SqlCommand("select isnull(max(Agent_Code),0) from Agent_Master where Agent_Code like '" + str1 + "%'", con, trans);
                            SqlDataReader dr = cmd.ExecuteReader();
                            if (dr.Read() && dr[0].ToString() != "0")
                            {
                                string str2 = dr[0].ToString().Substring(0, dr[0].ToString().Length);
                                string ch1 = str2.Substring(3);
                                int i = Convert.ToInt32(ch1) + 1;
                                string si = i.ToString();
                                if (si.Length == 1)
                                {
                                    id = str1.ToUpper() + "0000" + i;
                                }
                                else if (si.Length == 2)
                                {
                                    id = str1.ToUpper() + "000" + i;
                                }
                                else if (si.Length == 3)
                                {
                                    id = str1.ToUpper() + "00" + i;
                                }
                                else if (si.Length == 4)
                                    id = str1.ToUpper() + "0" + i;
                            }
                            else
                            {
                                id = str1.ToUpper() + id;
                            }
                            dr.Close();
                            insertQ = "insert into dbo.Agent_Master(Agent_Name,Agent_Code,Agent_Type,IATA_Code,IATA_Commission,Credit_Limit,Entered_By,Entered_On,Offline_Agent,Offline_City)values(@Agent_Name,@Agent_Code,@Agent_Type,@IATA_Code,@IATA_Commission,@Credit_Limit,@Entered_By,@Entered_On,@Offline_Agent,@Offline_City)";
                            cmd = new SqlCommand(insertQ, con, trans);
                            cmd.CommandType = CommandType.Text;
                            cmd.Parameters.AddWithValue("@agent_name", dtlist.Rows[ii]["Agent_Name"]);
                            cmd.Parameters.AddWithValue("@Agent_Code", id);
                            cmd.Parameters.Add("@Agent_Type", SqlDbType.Int).Value = 21;
                            cmd.Parameters.AddWithValue("@IATA_Code", dtlist.Rows[ii]["IATA_Code"]);
                            cmd.Parameters.Add("@IATA_Commission", SqlDbType.Int).Value = Convert.ToInt32(dtlist.Rows[ii]["IATA_Commission"]);
                            cmd.Parameters.Add("@Credit_Limit", SqlDbType.Int).Value = Convert.ToInt32(dtlist.Rows[ii]["Credit_Limit"]);
                            cmd.Parameters.AddWithValue("@Entered_By", loginid);
                            cmd.Parameters.AddWithValue("@Entered_On", TodayDate);
                            if (chkOffline.Checked == true)
                            {
                                cmd.Parameters.AddWithValue("@Offline_Agent", "Y");
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@Offline_Agent", "N");
                            }
                            if (ddlOfflineCity.SelectedValue == "0")
                            {
                                cmd.Parameters.AddWithValue("@Offline_City", "");
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@Offline_City", ddlOfflineCity.SelectedValue);
                            }
                            cmd.ExecuteNonQuery();
                            // Find Agent_ID
                            string selectQ;
                            selectQ = "select max(Agent_ID) From Agent_Master";
                            cmd = new SqlCommand(selectQ, con, trans);
                            agentID = Convert.ToInt32(cmd.ExecuteScalar().ToString());
                            // Find City name
                            string citycode = txtCity.SelectedItem.Text;
                            string Offlinecitycode = ddlOfflineCity.SelectedItem.Text;
                            //string citycode = "ADD-Addis Ababa";
                            int m = citycode.IndexOf("-") + 1;
                            citycode = citycode.Substring(0, m - 1);
                            cmd = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con, trans);
                            SqlDataReader dr1 = cmd.ExecuteReader();
                            while (dr1.Read())
                            {
                                CityId = Convert.ToInt32(dr1["City_ID"].ToString());
                            }
                            dr1.Close();
                            //Insert Agent_Branch
                            //Insert Agent_Branch
                            insertQ3 = @"insert into Agent_Branch(Agent_ID,Branch_Status,Belongs_To_City,Agent_Address,Agent_Phone,Agent_Contactno,Agent_Fax,Agent_Email,Concerned_Person,CSR_Contact_Person,CSR_Email,Pan_No,Tan_No,Credit_Limit,Status,AutoNeutral,Offline_City) values(@Agent_ID,@Branch_Status,@Belongs_To_City,@Agent_Address,@Agent_Phone,@Agent_Contactno,@Agent_Fax,@Agent_Email,@Concerned_Person,@CSR_Contact_Person,@CSR_Email,@Pan_No,@Tan_No,@Credit_Limit,@Status,@AutoNeutral,@Offline_City)";
                            cmd = new SqlCommand(insertQ3, con, trans);
                            cmd.CommandType = CommandType.Text;
                            cmd.Parameters.AddWithValue("@Agent_ID", agentID);
                            cmd.Parameters.AddWithValue("@Branch_Status", 18);
                            cmd.Parameters.AddWithValue("@Belongs_To_City", CityId);
                            cmd.Parameters.AddWithValue("@Credit_Limit", dtlist.Rows[ii]["Credit_Limit"]);
                            cmd.Parameters.AddWithValue("@Agent_Address", dtlist.Rows[ii]["Agent_Address"]);
                            cmd.Parameters.AddWithValue("@Agent_Phone", dtlist.Rows[ii]["Agent_Phone"]);
                            cmd.Parameters.AddWithValue("@Agent_Contactno", dtlist.Rows[ii]["Agent_Contactno"]);
                            cmd.Parameters.AddWithValue("@Agent_Fax", dtlist.Rows[ii]["Agent_Fax"]);
                            cmd.Parameters.AddWithValue("@Agent_Email", dtlist.Rows[ii]["Agent_Email"]);
                            cmd.Parameters.AddWithValue("@Concerned_Person", dtlist.Rows[ii]["Concerned_Person"]);
                            cmd.Parameters.AddWithValue("@CSR_Contact_Person", dtlist.Rows[ii]["CSR_Contact_Person"]);
                            cmd.Parameters.AddWithValue("@CSR_Email", dtlist.Rows[ii]["CSR_Email"]);
                            cmd.Parameters.AddWithValue("@Tan_No", dtlist.Rows[ii]["Tan_No"]);
                            cmd.Parameters.AddWithValue("@Pan_No", dtlist.Rows[ii]["Pan_No"]);
                            cmd.Parameters.AddWithValue("@Status", 2);
                            cmd.Parameters.AddWithValue("@AutoNeutral", "Y");
                            if (ddlOfflineCity.SelectedValue == "0")
                            {
                                cmd.Parameters.AddWithValue("@Offline_City", "");
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@Offline_City", ddlOfflineCity.SelectedValue);
                            }
                            cmd.ExecuteNonQuery();
                            string selectQ1;
                            selectQ1 = "select max(Agent_Branch_ID) From Agent_Branch";
                            cmd = new SqlCommand(selectQ1, con, trans);
                            BranchID = Convert.ToInt32(cmd.ExecuteScalar().ToString());
                            //insertQ2 = "SP_ImportLogin_Master";
                            insertQ2 = "insert into Login_Master(Email_ID,Login_Password,Agent_ID,Group_ID,Airline_Access)values(@Email_ID,@Login_Password,@Agent_ID,@Group_ID,@Airline_Access)";
                            cmd = new SqlCommand(insertQ2, con, trans);
                            cmd.CommandType = CommandType.Text;
                            //cmd.Parameters.AddWithValue("@BulkImport", dtlist);
                            cmd.Parameters.AddWithValue("@Email_ID", dtlist.Rows[ii]["Agent_Email"]);
                            cmd.Parameters.AddWithValue("@Login_Password", "123");
                            cmd.Parameters.AddWithValue("@Agent_ID", BranchID);
                            cmd.Parameters.AddWithValue("@Airline_Access", ts1);
                            cmd.Parameters.AddWithValue("@Group_ID", 5);
                            cmd.ExecuteNonQuery();
                            string csremailid = Convert.ToString(dtlist.Rows[ii][8].ToString());  //Convert.ToString(dtlist.Rows[0]["CSR_Email"]);
                            if (csremailid != "")
                            {
                                if (csremailid != loginid)
                                {
                                    //string insertCSR = "SP_ImportLogin_Master_CSR";
                                    string insertCSR = "insert into Login_Master_CSR(Email_ID,Login_Password,Agent_Branch_ID,Group_ID,Airline_Access )values(@Email_ID,@Login_Password,@Agent_Branch_ID,@Group_ID,@Airline_Access)";
                                    cmd = new SqlCommand(insertCSR, con, trans);
                                    cmd.CommandType = CommandType.Text;
                                    //cmd.Parameters.AddWithValue("@BulkImport", dtlist);
                                    cmd.Parameters.AddWithValue("@Email_ID", dtlist.Rows[ii]["Agent_Email"]);
                                    cmd.Parameters.AddWithValue("@Login_Password", "123");
                                    cmd.Parameters.AddWithValue("@Agent_Branch_ID", BranchID);
                                    cmd.Parameters.AddWithValue("@Airline_Access", ts1);
                                    cmd.Parameters.AddWithValue("@Group_ID", 5);
                                    cmd.ExecuteNonQuery();
                                    finaltransStatusstr = "Success";
                                }
                            }
                            trans.Commit();
                        }
                        else 
                        {
                            finaltransStatusstr = "DuplicateAgentName";                           
                            break;                          
                        }
                    }
                    else
                    {
                        finaltransStatusstr = "DuplicateAgentid";                        
                        break;
                    }
                }           
        }
        catch (Exception ex)
        {
            finaltransStatusstr = "Failed";
        }
        return finaltransStatusstr;    
    }  
    public void CityName()
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master where City_ID in(select distinct belongs_to_city from airline_detail) order by city_code", con);
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        txtCity.DataSource = ds;
        txtCity.DataTextField = "CodeName";
        txtCity.DataValueField = "City_ID";
        txtCity.DataBind();
        txtCity.Items.Insert(0, new ListItem("--Select--", "0"));
        con.Close();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string Uploadstatus=string.Empty;
        if (CheckFile())
        {
            ReceiveExcelsheet();
            lblMessage.Text = "Please Wait...";
            if (chkOffline.Checked == true && ddlOfflineCity.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(GetType(), "alert", "<SCRIPT LANGUAGE='javascript'>alert('Please select Offline City');</script>");
                lblMessage.Visible = true;
                lblMessage.Text = "Please select Offline City";
                ddlOfflineCity.Focus();
                return;
            }
            else
            {
                #region
                if (Session["ExcelSSSS"] !=null)
                {
                       #region if session exists
                        Exceldt = new DataTable();
                        Exceldt = (DataTable)Session["ExcelSSSS"];
                        if (IsUserIdExist(Exceldt,"",""))
                        {
                            lblMessage.Visible = true;
                            lblMessage.Text = "Login ID Already Exists";
                            return;
                        }
                        else if (IsAgentNameExist(Exceldt,""))
                        {
                            lblMessage.Text = "Agent Name Already Exists.";
                            lblMessage.Visible = true;
                            return;
                        }
                        else if (checkCityName())
                        {
                            #region else if
                            int m = CheckAirlineAccess.Items.Count;
                            bool isChecked = false;
                            for (int i = 0; i < m; i++)
                                if (CheckAirlineAccess.Items[i].Selected)
                                    isChecked = true;
                            if (!isChecked)
                            {
                                lblMessage.Text = "Please Check AtLeast One Airline Access";
                                lblMessage.Visible = true;
                                return;
                            }
                            else
                            {                                
                                if (IsPostBack)
                                {
                                    #region IsPostBack
                                    lblMessage.Text = "Please Wait...";
                                    try
                                    {
                                        Uploadstatus=DataUpload(Exceldt);
                                        if (Uploadstatus == "Success")
                                        {
                                            lblMessage.Text = "File uploaded Successfully!";
                                            lblMessage.Visible = true;
                                            return;
                                        }
                                        else if (Uploadstatus == "DuplicateAgentName")
                                        {
                                            lblMessage.Text = "Duplicate Agent Name Exist in your Excel Sheet";
                                            lblMessage.Visible = true;
                                            return;
                                        }
                                        else if (Uploadstatus == "DuplicateAgentid")
                                        {
                                            lblMessage.Visible = true;
                                            lblMessage.Text = "Duplicate Agent Id Exist in your Excel Sheet";
                                            return;
                                        }
                                        else
                                        {
                                            lblMessage.Text = "Invalid Data, Please Check!";
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        lblMessage.Text = "File could not be uploaded.";
                                    }
                                   #endregion
                                }                               
                            }
                            #endregion
                        }
                        else
                        {
                            lblMessage.Text = "Select Valid City";
                            lblMessage.Visible = true;
                        }
                    #endregion
                }
                #endregion
            }               
        }
        else
        {
            lblMessage.Text = "Cannot accept files of this type.";
        }   
    }   
    public DataSet AirlineAccess()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectQ;
        selectQ = "select (a.Airline_Code+'-'+a.Airline_Name+'('+c.City_Code+')') as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where b.Status=2";
        com = new SqlCommand(selectQ, con);
        com.Connection = con;
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        return ds;
    }
    public Boolean CheckFile()
    {
        Boolean fileOK = false;
        if (FileUpload1.HasFile)
        {
            String fileExtension = Path.GetExtension(FileUpload1.FileName).ToLower();
            String[] allowedExtensions = { ".xls", ".xlsx" };
            for (int i = 0; i < allowedExtensions.Length; i++)
            {
                if (fileExtension == allowedExtensions[i])
                {
                    fileOK = true;
                }
            }
        }
        return fileOK;
    } 
    public void OfflineCityName()
    {
        con = new SqlConnection(strCon);
        con.Open();
        //com = new SqlCommand("Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master where offline='Y' order by city_code", con);
        com = new SqlCommand("Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master where offline='Y' and City_ID in(select distinct belongs_to_city from airline_detail)  order by city_code", con);
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        ddlOfflineCity.DataSource = ds;
        ddlOfflineCity.DataTextField = "CodeName";
        ddlOfflineCity.DataValueField = "City_ID";
        ddlOfflineCity.DataBind();
        ddlOfflineCity.Items.Insert(0, new ListItem("--Select--", "0"));
        con.Close();
    }   
    public void BindAirlineAccess()  // Bind Airline_Access
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectQ;
        string citycode = txtCity.SelectedItem.Text;
        string OfflineCityCode = ddlOfflineCity.SelectedItem.Text;
        int m = citycode.IndexOf("-") + 1;
        string city_code = citycode.Substring(0, m - 1);
        //*********************Modify On 31_DEC_2010******************* City Free Airline***************

        //selectQ = "select (a.Airline_Code+'-'+a.Airline_Name) as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where c.City_Code='" + city_code + "' and b.Status=2";

        selectQ = "select (a.Airline_Code+'-'+a.Airline_Name+'('+c.City_Code+')') as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where b.Status=2";


        //***************************End Of Modification***************************


        com = new SqlCommand(selectQ, con);
        com.Connection = con;
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);

        CheckAirlineAccess.DataSource = ds;
        CheckAirlineAccess.DataTextField = "NameCode";
        CheckAirlineAccess.DataValueField = "Airline_detail_ID";
        CheckAirlineAccess.DataBind();
        CheckBoxList chk = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            chk.Items[i].Selected = true;
        }

        com.Dispose();
        con.Close();
        //rakhi
        if (ds.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                lblAccesss.Visible = false;
                pnlCheck.Visible = true;
                CheckAirlineAccess.Items[i].Selected = true;
            }
        }
        else
        {
            lblAccesss.Visible = true;
            lblAccesss.Text = "No Airline Exist For " + txtCity.SelectedItem.Text.Trim() + ", Please select Another City";
            pnlCheck.Visible = false;
        }
        //rakhi
    }
    protected void txtCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAirlineAccess();
    }
    protected void chkOffline_CheckedChanged1(object sender, EventArgs e)
    {
        if (chkOffline.Checked == true)
        {
            Offline.Visible = true;
            OfflineCityName();
        }
        else
        {
            OfflineCityName();
            Offline.Visible = false;
            //ddlOfflineCity.Items.Clear();
            //ddlOfflineCity.SelectedValue = "0";
            ddlOfflineCity.SelectedItem.Value = "0";
        }
    }
  
}