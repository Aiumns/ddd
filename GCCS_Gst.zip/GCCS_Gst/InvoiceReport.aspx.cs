using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class InvoiceReport : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand com = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
        {
            //////// Start: Modified by Hemant Sharma for applying restriction for Months On 20'th October 2014///////////////////////
            DateTime first = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(Convert.ToInt32(Session["TimeLimit"].ToString())));
            hdnDate.Value = first.ToString();
            //////// End: Modified by Hemant Sharma for applying restriction for Months On 20'th October 2014///////////////////////

            DateTime DTM;
            //DTM = DateTime.Now.AddMonths(6);
            DTM = DateTime.Now.AddDays(-7);

            txtValidFrom.Text = DTM.ToString("dd/MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            try
            {
                String airline_access = Session["AIRLINEACCESS"].ToString();
                //airline_access = airline_access.Substring(0, airline_access.Length - 1);
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));
                }
                cmd.Dispose();
            }
            catch (Exception eror)
            {
                string st = eror.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
                cmd.Dispose();
                dr.Close();
            }
        }
    }

    protected void Btnload_Click(object sender, EventArgs e)
    {
          #region IPCheck
          string IP = GetUserIp();
          if (IP != "")
          {
                string[] ip_addrs = IP.Split('.');
                if (ip_addrs.Length == 4)
                {
                      con = new SqlConnection(strCon);
                      con.Open();
                      string cInsert = "INSERT INTO db_owner.IP_Check(Ip,updated_on)VALUES( '" + IP + "','" + DateTime.Now + "')";
                      com = new SqlCommand(cInsert, con);
                      com.ExecuteNonQuery();
                      con.Close();
                      DataTable dt = dw.GetAllFromQuery("select * from ip where ip='" + IP + "'");
                      if (dt.Rows.Count > 0 || (ip_addrs[0].ToString() == "192") && (ip_addrs[1].ToString() == "168") && ((ip_addrs[2].ToString() == "0") || (ip_addrs[2].ToString() == "1") || (ip_addrs[2].ToString() == "2")))
                      {
                      }
                      else
                      {
                            ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact ddalal@cargoflash.com');</script>");
                            return;
                      }
                }
                else
                {
                      ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact ddalal@cargoflash.com');</script>");
                      return;
                }
          }
          else
          {
                ClientScript.RegisterStartupScript(GetType(), "MessageAlert", "<SCRIPT LANGUAGE='javascript'>alert('Sorry, Your are not Authorized to view this report.For access pls contact ddalal@cargoflash.com');</script>");
                return;
          }
          #endregion 
        string[] airline_name_city_text = ddl_airline_city.SelectedItem.Text.Split('/');
        string[] airline_name_city_value = ddl_airline_city.SelectedItem.Value.Split(',');
        string date_from = txtValidFrom.Text;
        string date_to = txtValidTo.Text;
        if (ddl_airline_city.SelectedItem.Value == "0,0")
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Please Choose Airline/City.');</script>");
        }
        else
        {
            Session["FromDate"] = date_from;
            Session["ToDate"] = date_to;
            Session["AirlineID"] = airline_name_city_value[1];
            Session["CityCode"] = airline_name_city_value[0];
            Session["AirlineCode"] = airline_name_city_value[2];
            Session["AirlineName"] = airline_name_city_text[0];
            Session["CityName"] = airline_name_city_text[1];
            string url = "ViewInvoiceReport.aspx";
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( '" + url + "');</script>");

        }
    }

    public string GetUserIp()
    {
          string VisitorsIPAddr = string.Empty;
          //Users IP Address.
          if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
          {
                //To get the IP address of the machine and not the proxy
                VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
          }
          else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
          {
                VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
          }
          return VisitorsIPAddr;
    }
}
