using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AgentSMS : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    DisplayWrap dw = new DisplayWrap();
    sms SMS = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btndetails.Attributes.Add("onclick", "return CheckEmpty();");
            LoadOrigin();
        }
      
    }
    public void LoadOrigin()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select City_ID,City_Code,City_name from City_Master where city_ID in(SELECT DISTINCT CITYID FROM CPP_AgentwiseTotal )", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Clear();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void SndSMS_Click(object sender, EventArgs e)
    {
        string strmobno = "";
        string Ag_name="";
        foreach (GridViewRow gv in grdAgentDetails.Rows)
        {
            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            strmobno = ((Label)gv.FindControl("lblMobNo")).Text.ToString();
            if (ChkBxItem.Checked && strmobno.ToString().Trim()!="")
            {
                string Msg = "";
                Ag_name = Ag_name+((Label)gv.FindControl("lblAgent")).Text.ToString()+"<br>";
                Msg = "Your current CPP balance as on " + DateTime.Today.ToString("MMM-dd") + " is " + Math.Round(Convert.ToDecimal(((Label)gv.FindControl("lblBalance")).Text.ToString()), MidpointRounding.AwayFromZero) + ".Redeem them for  Exciting Prizes and Gift Vouchers.Log on to http://www.groupconcorde.com";

                SMS = new sms();
                if (Msg.Length > 0)
                {
                    SMS.SendSMS(strmobno, Msg);
                }

            }

        }
        //Ag_name = Ag_name.Remove(Ag_name.LastIndexOf(","));
        lblmsg.Visible = true;
        lblmsg.Text = "Message successfully send to the following Agents:<br><font color=teal size=2>"+Ag_name.ToString()+"</font>";
        grdAgentDetails.Visible = false;
        compshow.Visible = false;
        SndSMS.Visible = false;
      
    }
    protected void btndetails_Click(object sender, EventArgs e)
    {
        lblmsg.Visible = false;
        grdAgentDetails.DataSource = null;
        try
        {
            DataTable dt_agent;
            if (txtCPP.Text == "")
            {
                dt_agent = dw.GetAllFromQuery("SELECT distinct AGENT_NAME,AB.Agent_branch_ID as Agent_branch_ID,AB.Agent_phone as Agent_phone,sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP,(sum(ISNULL(TotalCPP,0))-sum(ISNULL(RedeemedCPP,0))) as balance_CPP FROM cpp_agentwisetotal CQ INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=CQ.AGENTID INNER JOIN AGENT_BRANCH AB ON AB.Agent_ID=CQ.AgentID and AB.Belongs_to_city=CQ.CityID WHERE CITYID=" + ddlOrigin.SelectedItem.Value + "  group by AGENT_NAME,AB.Agent_branch_ID,AB.Agent_phone  ORDER BY (sum(ISNULL(TotalCPP,0))-sum(ISNULL(RedeemedCPP,0))) DESC");
            }
            else
            {
                dt_agent = dw.GetAllFromQuery("SELECT distinct AGENT_NAME,AB.Agent_branch_ID as Agent_branch_ID,AB.Agent_phone as Agent_phone,sum(ISNULL(TotalCPP,0)) AS TotalCPP,sum(ISNULL(RedeemedCPP,0)) AS RedeemedCPP,(sum(ISNULL(TotalCPP,0))-sum(ISNULL(RedeemedCPP,0))) as balance_CPP FROM cpp_agentwisetotal CQ INNER JOIN AGENT_MASTER AM ON AM.AGENT_ID=CQ.AGENTID INNER JOIN AGENT_BRANCH AB ON AB.Agent_ID=CQ.AgentID and AB.Belongs_to_city=CQ.CityID  WHERE CITYID=" + ddlOrigin.SelectedItem.Value + " group by AGENT_NAME,AB.Agent_branch_ID,AB.Agent_phone having  (sum(ISNULL(TotalCPP,0))-sum(ISNULL(RedeemedCPP,0)))>=" + txtCPP.Text + " ORDER BY (sum(ISNULL(TotalCPP,0))-sum(ISNULL(RedeemedCPP,0))) DESC");
 
            }

            grdAgentDetails.DataSource = dt_agent;
            grdAgentDetails.DataBind();
            if (grdAgentDetails.Rows.Count > 0)
            {
                grdAgentDetails.Visible = true;
                SndSMS.Visible = true;
                compshow.Visible = true;
            
                
            }
            else
            {
                grdAgentDetails.Visible = false; ;
                SndSMS.Visible = false;
                compshow.Visible = false;
            }

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chkheader = new CheckBox();
        chkheader = (CheckBox)grdAgentDetails.HeaderRow.FindControl("chkSelectAll");

        foreach (GridViewRow rw in grdAgentDetails.Rows)
        {
            CheckBox chkMain = new CheckBox();
            chkMain = (CheckBox)rw.FindControl("chkMain");

            if (chkheader.Checked == true)
            {
                chkMain.Checked = true;


            }

            else
            {
                chkMain.Checked = false;

            }


        }

    }
    protected void lnkmodify_Command(object sender, CommandEventArgs e)
    {
        string d = ParamUtils.WebParam.Encode(new Pair("id", e.CommandName));
        string d1 = ParamUtils.WebParam.Encode(new Pair("id", e.CommandName));
        Response.Redirect("AgentSMSDetails.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("id", e.CommandName)));
    }
}
