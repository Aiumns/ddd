using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AgentReason : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand cmd;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  // ConnectionString
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            if (Request.QueryString["sno"].ToString() != "")
            {
                DataTable dt_TempFill = dw.GetAllFromQuery("select * from Agent_temp where Agent_Temp_ID='" + Request.QueryString["sno"].ToString() + "'");
                if (dt_TempFill.Rows.Count > 0)
                {
                    txtReason.Text = dt_TempFill.Rows[0]["remarks"].ToString();
                }
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            if (Request.QueryString["sno"].ToString() != "")
            {
                string update_reason = "update agent_temp set remarks=@remarks,status=@status where Agent_temp_id='" + Request.QueryString["sno"].ToString() + "'";
                cmd = new SqlCommand(update_reason, con);
                cmd.Parameters.AddWithValue("@remarks", txtReason.Text);
                cmd.Parameters.AddWithValue("@status", "N");
                cmd.ExecuteNonQuery();
                Response.Redirect("NewAgent_RegisterDetails.aspx");
            }

            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("NewAgent_RegisterDetails.aspx");
    }
}
