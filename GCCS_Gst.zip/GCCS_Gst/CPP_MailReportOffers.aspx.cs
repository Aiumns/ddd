using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Data.SqlClient;
using System.Net.Mail;

public partial class CPP_MailReportOffers : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    //SqlTransaction trans = null;
    SqlDataAdapter da = null;
    DataTable dt = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    decimal total_ch_wt = 0;
    decimal total_cpp = 0;
    decimal total_total_ch_wt = 0;
    decimal total_total_cpp = 0;
    string ci_ID="";
    decimal total_total_row = 0;
    decimal total_used_row = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
            BindCPP();
        
    }
    public void BindCPP()
    {

        con = new SqlConnection(strCon);
        string selectQ = "";
        con.Open();
        try
        {
            selectQ = "SELECT distinct City_code,CM.City_ID as City_ID  from City_master CM inner join CPP_AgentwiseTotal CA on CA.CityID=CM.City_id order by City_code";

            cmd = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            GrdCPP.DataSource = dt;
            GrdCPP.DataBind();
            con.Close();
            GrdCPP.Columns[1].Visible = false;
         
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void GrdCPP_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        total_total_ch_wt = 0;
        total_total_cpp = 0;
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            GridView grdAgent1 = ((GridView)(e.Row.Cells[0].FindControl("grdAirline")));
            string cityCode = ((Label)(e.Row.Cells[0].FindControl("lblCity"))).Text;
            ci_ID = ((Label)(e.Row.Cells[0].FindControl("lblCItyID"))).Text; 

            //SQL QUERY USING PARAMETER cityCode

            con = new SqlConnection(strCon);
            string selectQ = "";
            con.Open();
            try
            {
                selectQ = "SELECT am.Agent_name AS Agent_name,CA.Member as member,ISNULL(sum(CA.TotalCPP),0) as TotalCPP,ISNULL(sum(CA.RedeemedCPP),0) as RedeemedCPP,ca.agentid as agentid,ca.cityid as cityid from Agent_master AM inner join CPP_AgentwiseTotal CA on CA.AgentID=AM.Agent_ID Inner join city_master CM on CM.City_id=CA.CityID  where cm.city_code='" + cityCode + "' group by am.Agent_name,CA.Member,ca.agentid,ca.cityid order by TotalCPP desc  ";

                cmd = new SqlCommand(selectQ, con);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                grdAgent1.DataSource = dt;
                grdAgent1.DataBind();
                con.Close();
               grdAgent1.Columns[4].Visible = false;
               grdAgent1.Columns[5].Visible = false;
               if (grdAgent1.Rows.Count > 0)
               {
                   grdAgent1.FooterRow.Cells[2].Text = Convert.ToString(Math.Round(total_total_row, MidpointRounding.AwayFromZero));
                   grdAgent1.FooterRow.Cells[2].Wrap = false;
                   grdAgent1.FooterRow.Cells[3].Text = Convert.ToString(Math.Round(total_used_row, MidpointRounding.AwayFromZero));
                   grdAgent1.FooterRow.Cells[3].Wrap = false;
                   grdAgent1.FooterRow.Cells[7].Text = Convert.ToString(Math.Round(total_total_ch_wt, MidpointRounding.AwayFromZero));
                   grdAgent1.FooterRow.Cells[7].Wrap = false;
                   grdAgent1.FooterRow.Cells[8].Text = Convert.ToString(Math.Round(total_total_cpp, MidpointRounding.AwayFromZero));
                   grdAgent1.FooterRow.Cells[8].Wrap = false;
                   total_total_row = 0;
                   total_used_row = 0;
               }
            }
            catch (SqlException ex)
            {
                string err = ex.Message;

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

            //

        }
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void grdAirline_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        DataTable dt_testq = dw.GetAllFromQuery("Select convert(varchar,dateadd(dd,1,max(enddate)),103) as enddate,convert(varchar,dateadd(dd,1,max(enddate)),106) as showdate from cpp_agentwisetotal");
        total_ch_wt = 0;
        total_cpp = 0;
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            GridView grdSlab1 = ((GridView)(e.Row.Cells[6].FindControl("grdSlabAirline")));
            string agentID = e.Row.Cells[4].Text;
            total_total_row += decimal.Parse(e.Row.Cells[2].Text);
            total_used_row += decimal.Parse(e.Row.Cells[3].Text);
            //SQL QUERY USING PARAMETER agentID           
            con = new SqlConnection(strCon);
            string selectQ = "";
            con.Open();
            try
            {
                selectQ = "select * from CPP_Base where startdate<='" + FormatDateDD(dt_testq.Rows[0]["enddate"].ToString()) + "' and enddate>=getdate() ";
                //selectQ = "select * from CPP_Slabwise where agentcppno='1199'";
                cmd = new SqlCommand(selectQ, con);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                grdSlab1.DataSource = dt;
                grdSlab1.DataBind();
                con.Close();

                for (int i = 0; i < grdSlab1.Rows.Count; i++)
                {
                    GridViewRow grdrow = grdSlab1.Rows[i];
                    string aid = grdrow.Cells[0].Text;
                    string sl1 = grdrow.Cells[1].Text;
                    string sl2 = grdrow.Cells[4].Text;
                    string select1 = "";
                    if (aid.ToString() == "0.00" && sl1.ToString() == "0.00")
                    {
                        select1 = "select isnull(sum(charged_weight),0) as charged_weight,isnull(count(airwaybill_no),0) as airwaybill_no,(isnull(sum(charged_weight),0)*.01)* " + sl2 + " as CPPpoints from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where sales.status <> 12 and awb_date between '" + FormatDateDD(dt_testq.Rows[0]["enddate"].ToString()) + "' and getdate()  and airline_code<> 023 and  city_id=" + ci_ID + " and agent_master.agent_id='" + agentID + "' and agent_min_status='13'";
                    }
                    else
                    {
                        select1 = "select isnull(sum(charged_weight),0)  as charged_weight,isnull(count(airwaybill_no),0) as airwaybill_no,(isnull(sum(charged_weight),0)*.01)* " + sl2 + "  as CPPpoints from sales inner join agent_master on sales.agent_id=agent_master.agent_id inner join airline_detail on sales.airline_detail_id=airline_detail.airline_detail_id inner join airline_master on airline_detail.airline_id=airline_master.airline_id where  sales.status <> 12 and awb_date between '" + FormatDateDD(dt_testq.Rows[0]["enddate"].ToString()) + "' and getdate()  and airline_code<> 023 and  city_id=" + ci_ID + " and agent_master.agent_id='" + agentID + "'  and charged_weight between  " + aid + " and " + sl1 + " and agent_min_status='14'";

                    }
                    DataTable dv = dw.GetAllFromQuery(select1);
                    //decimal sp_rate = (txtSpot.Text.Trim() == "" ? 0 : decimal.Parse(txtSpot.Text));
                    grdrow.Cells[3].Text = dv.Rows[0]["charged_weight"].ToString().Trim();
                    grdrow.Cells[4].Text = dv.Rows[0]["airwaybill_no"].ToString().Trim();
                    grdrow.Cells[5].Text = Convert.ToString(Math.Round(decimal.Parse(dv.Rows[0]["CPPpoints"].ToString().Trim()), 2));
                    total_ch_wt += Math.Round(decimal.Parse(dv.Rows[0]["charged_weight"].ToString().Trim()), 2);
                    total_cpp += Math.Round(decimal.Parse(dv.Rows[0]["CPPpoints"].ToString().Trim()), 2);
                    total_total_ch_wt += Math.Round(decimal.Parse(dv.Rows[0]["charged_weight"].ToString().Trim()), 2);
                    total_total_cpp += Math.Round(decimal.Parse(dv.Rows[0]["CPPpoints"].ToString().Trim()), 2);

                }

            }
            catch (SqlException ex)
            {
                string err = ex.Message;

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
            e.Row.Cells[7].Text = Convert.ToString(Math.Round(total_ch_wt, 2));
            e.Row.Cells[8].Text = Convert.ToString(Math.Round(total_cpp, 2));


            //}
        }
    }
 
}
