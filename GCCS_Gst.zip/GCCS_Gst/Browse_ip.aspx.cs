using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Browse_ip : System.Web.UI.Page
{
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }


        if (!IsPostBack)
        {
            if (Request["cub"] != null)
            {
                Label3.Text = "Record Sucessfully Booked";
                Label3.Visible = true;
                TableToDisplay("");
            }
            else if (Request["upd"] != null)
            {
                Label3.Text = "Record Sucessfully Updated.";
                Label3.Visible = true;
                TableToDisplay("");
            }
            else
            {
                Label3.Visible = false;
                TableToDisplay("");
            }
        }




    }

    private void TableToDisplay(string query_concate)
    {
        ////string query = "select sno,awbno,Convert(varchar,awbdt,103) as awbdt,status=case when awbdt<getdate()-15 then 1 else 0 end ,agent_name,destination_code,city_code,chargeable_wt,Convert(varchar,handoverdt,103) as handoverdt,buyingAmt,sellingAmt,fltno,Convert(varchar,fltdt,103) as fltdt,shptType from FedexIP inner join agent_master on FedexIP.Agent_id=agent_master.Agent_id inner join destination_master on FedexIP.dstncd=destination_master.destination_id inner join city_master on FedexIP.origin=city_master.city_id " + query_concate + "  order by awbdt desc";


        ////string query = "select sno,awbno,Convert(varchar,awbdt,103) as awbdt,status=case when awbdt<getdate()-15 then 1 else 0 end ,agent_name,destination_code,city_code,chargeable_wt,Convert(varchar,handoverdt,103) as handoverdt,GrandBuyingAmt,GrandSellingAmt,fltno,Convert(varchar,fltdt,103) as fltdt,shptType from FedexIP inner join agent_master on FedexIP.Agent_id=agent_master.Agent_id inner join destination_master on FedexIP.dstncd=destination_master.destination_id inner join city_master on FedexIP.origin=city_master.city_id " + query_concate + "  order by awbdt desc";

        string query = "select sno,awbno,Convert(varchar,awbdt,103) as awbdt,status=0 ,agent_name,destination_code,city_code,chargeable_wt,Convert(varchar,handoverdt,103) as handoverdt,GrandBuyingAmt,GrandSellingAmt,fltno,Convert(varchar,fltdt,103) as fltdt,shptType from FedexIP inner join agent_master on FedexIP.Agent_id=agent_master.Agent_id inner join destination_master on FedexIP.dstncd=destination_master.destination_id inner join city_master on FedexIP.origin=city_master.city_id " + query_concate + "  and awbDt between dateadd(day, -45, getdate()) and GETDATE()  order by awbdt desc";


        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand(query, con);
        dr = cmd.ExecuteReader();

        string table = @"<table border=1 width=100% cellpadding=1 cellspacing=0><tr class=h5><td class=boldtext align=center>Modify</td><td class=boldtext align=center>Date</td><td class=boldtext align=center>AWB No.</td><td class=boldtext align=center>Agent</td><td class=boldtext align=center>Dest.</td><td class=boldtext align=center>Ch. Wt.</td><td class=boldtext align=center>Type</td><td class=boldtext align=center>Handover</td><td class=boldtext align=center>Buying</td><td class=boldtext align=center>Selling</td><td class=boldtext align=center >Flt No.</td><td class=boldtext align=center>Flt Dt</td></tr>";
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                string link = "";
                if (dr["status"].ToString() == "0")
                {
                    link = "<a href='add_ip.aspx?sno=" + dr["sno"].ToString() + "'>Modify</a>";
                }
                else
                {
                    link = "<a href='view_ip.aspx?sno=" + dr["sno"].ToString() + "'>View</a>";
                }
                table += @"<tr><td class=boldtext align=center>" + link + "</td><td class=boldtext align=center>" + dr["awbdt"].ToString() + "</td><td class=boldtext align=center>" + dr["awbno"].ToString() + "</td><td class=boldtext align=center>" + dr["agent_name"].ToString() + "</td><td class=boldtext align=center>" + dr["destination_code"].ToString() + "</td><td class=boldtext align=center>" + dr["chargeable_wt"].ToString() + "</td><td class=boldtext align=center>" + dr["shptType"].ToString() + "</td><td class=boldtext align=center>" + dr["handoverdt"].ToString() + "</td><td class=boldtext align=center>" + dr["GrandBuyingAmt"].ToString() + "</td><td class=boldtext align=center>" + dr["GrandSellingAmt"].ToString() + "</td><td class=boldtext align=center nowrap>" + dr["fltno"].ToString() + "</td><td class=boldtext align=center>" + dr["fltdt"].ToString() + "</td></tr>";
            }
            Label2.CssClass = "text";
        }
        else
        {

            table = "<center>No Record Found</center>";
            Label2.CssClass = "error"; 

        }

            dr.Close();
            con.Close();
        
        table += "</table>";
        Label2.Text = table;  
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Label3.Visible = false;
        string query = "where agent_name  like '%" + txtsearch.Text.Trim() + "%' or awbno like '%" + txtsearch.Text.Trim() + "%'";
        TableToDisplay(query);
    }
}
