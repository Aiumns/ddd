using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Created By Rakhi on 2 Nov 2007
/// </summary>

public partial class Booking_Void : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlTransaction tr = null;
    SqlCommand com;
    string AirWayBill_No;
    string strquery;
    DisplayWrap dw = new DisplayWrap();

    protected void Page_Load(object sender, EventArgs e)
    {       
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            AirWayBill_No = Request.QueryString["AirWayBill_No"].ToString();
            btnVoid.Attributes.Add("onclick", "return CheckEmpty()");
            if (!Page.IsPostBack && Request.QueryString["AirWayBill_No"] != null)
            {
                search();
            }
        }
    }
    public void search()
    {
        try
        {
            string id = Request.QueryString["AirWayBill_No"].ToString();
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmd = new SqlCommand("Booking_Select", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AirWayBill_No", id);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Label1.Text = dr["AirWayBill_No"].ToString();

                }
            }

            con.Close();
            cmd.Dispose();
        }
        catch (Exception)
        {
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    private void VoidFns()
    {
        long BookingID = long.Parse(Request.QueryString["booking_id"].ToString());
        DataTable dtStock = dw.GetAllFromQuery("select Used_Date,Stock_ID,Agent_ID from stock_Master where AirWayBill_No='" + Label1.Text + "'");

        DataTable dtCityID = dw.GetAllFromQuery("select City_ID,flight_date from Booking_Master where Booking_ID=" + BookingID);
        ViewState["City_ID"] = dtCityID.Rows[0]["City_ID"].ToString();
        ViewState["flight_date"] = dtCityID.Rows[0]["flight_date"].ToString();
        DataTable dtCityCode = dw.GetAllFromQuery("select City_Code from City_Master where City_ID=" + dtCityID.Rows[0]["City_ID"].ToString());
        ViewState["City_Code"] = dtCityCode.Rows[0]["City_Code"].ToString();

        string[] dd = Label1.Text.Split(new char[] { '-' });
        string AirlineCode = dd[0];
        DataTable dtAirlineDetailID = dw.GetAllFromQuery("select ad.Airline_Detail_ID from Airline_Master am inner join Airline_Detail ad on am.Airline_ID=ad.Airline_ID where am.Airline_Code=" + dd[0] + " and ad.Belongs_To_City=" + int.Parse(ViewState["City_ID"].ToString()));
        ViewState["AirlineDetailID"] = dtAirlineDetailID.Rows[0]["Airline_Detail_ID"].ToString();
        con = new SqlConnection(strCon);
        con.Open();
        tr = con.BeginTransaction();
        string AirWayBill_No = Request.QueryString["AirWayBill_No"].ToString();        
        try
        {
            string insertQuery = "";            

            insertQuery = "Update Stock_Master set Status='" + 12 + "',Remarks='" + txtRemarks.Text + "' where AirWayBill_No='" + AirWayBill_No + "' ";
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();

            insertQuery = "Insert Into Stock_History(AirWayBill_No,City_Name,Receipt_Date,Receipt_LotNo,Agent_Name,Issue_Date,Issue_LotNo,Status,Remarks,Used_Date,Created_By,Created_On) SELECT  sm.AirWayBill_No, cm.City_Name, sm.Receipt_Date, sm.Receipt_LotNo,am.Agent_Name, sm.Issue_Date, sm.Issue_LotNo, stm.Status_Name, sm.Remarks, sm.Used_Date,'" + Session["EMailID"].ToString() + "',getdate() FROM Stock_Master sm INNER JOIN City_Master cm ON sm.City_ID = cm.City_ID INNER JOIN Agent_Master am ON sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON sm.Status = stm.Status_ID where AirWayBill_No='" + AirWayBill_No + "'";
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();


            ////***************hanover table delete data due to void AWB's on 4th March 2014**********/////////

            //string hnd_Query = "DELETE FROM db_owner.Handover WHERE Stock_ID=(select Stock_ID from stock_Master where AirWayBill_No='" + AirWayBill_No + "')";
            //com = new SqlCommand(hnd_Query, con, tr);
            //com.ExecuteNonQuery();

            com = new SqlCommand("Void_Case_Handover_delete", con, tr);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airwaybill_no", SqlDbType.VarChar).Value = AirWayBill_No;
            com.ExecuteNonQuery();
            tr.Commit();
           

            Insert_Sales(tr, con, dtStock);
            Update_AgentLimit(tr, con);

           
            insertQuery = "Update Booking_Master set Status='" + 12 + "' where Stock_ID=(select Stock_ID from stock_Master where AirWayBill_No='" + AirWayBill_No + "')";
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();
            com.Dispose();

            insertQuery = "Insert Into Booking_History(Booking_ID,Booking_Date,AirWayBill_No,Airline_Name,Flight_No,Origin,Destination,Agent_Code,Special_Commodity_Name,Shipment_Name,Flight_Date,No_of_Packages,Measurement_Unit,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Agent_Deal_Remarks,Expected_Handover_Date,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Handovered_Status,Status,Entered_By,Entered_On) SELECT bm.Booking_ID,bm.Booking_Date,sm.AirWayBill_No,alm.Airline_Name, fm.Flight_No,  cm.City_Name, dm.Destination_Name, am.Agent_Code, scm.Special_Commodity_Name, shm.Shipment_Name,bm.Flight_Date, bm.No_of_Packages, bm.Measurement_Unit, bm.Gross_Weight, bm.Volume_Weight, bm.Charged_Weight, bm.Spot_Rate, bm.Commission, bm.Special_Commodity_Incentive, bm.Agent_Deal_Remarks, bm.Expected_Handover_Date, bm.Freight_Type, bm.Tariff_Rate, bm.Freight_Amount, bm.Special_Rate, bm.Special_Amount, stm1.Status_Name as Handover_status ,stm.Status_Name as Status,'" + Session["EMailID"].ToString() + "',getdate() FROM Booking_Master bm INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Flight_Master fm ON fo.Flight_ID = fm.Flight_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Special_Commodity_Master scm ON bm.Special_Commodity_ID = scm.Special_Commodity_ID INNER JOIN Shipment_Master shm ON bm.Shipment_ID = shm.Shipment_ID INNER JOIN City_Master cm ON bm.City_ID = cm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Agent_Master am ON bm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON bm.Status = stm.Status_ID INNER JOIN Status_Master stm1 on bm.Handovered_Status=stm1.Status_ID inner join Airline_Master alm on substring(sm.AirWayBill_No,1,3)=alm.Airline_Code where AirWayBill_No='" + AirWayBill_No + "'";
            //insertQuery = "Insert Into Booking_History SELECT  bm.Booking_ID, fm.Flight_No, bm.Booking_Date,sm.AirWayBill_No,alm.Airline_Name, scm.Special_Commodity_Name, shm.Shipment_Name, cm.City_Name, dm.Destination_Name, am.Agent_Code, bm.Flight_Date, bm.No_of_Packages, bm.Measurement_Unit, bm.Gross_Weight, bm.Volume_Weight, bm.Charged_Weight, bm.Spot_Rate, bm.Commission, bm.Special_Commodity_Incentive, bm.Agent_Deal_Remarks, bm.Expected_Handover_Date, bm.Freight_Type, bm.Tariff_Rate, bm.Freight_Amount, bm.Special_Rate, bm.Special_Amount, bm.Entered_By, bm.Entered_On, stm.Status_Name as Status, stm1.Status_Name as Handover_status FROM Booking_Master bm INNER JOIN Flight_Open fo ON bm.Flight_Open_ID = fo.Flight_Open_ID INNER JOIN Flight_Master fm ON fo.Flight_ID = fm.Flight_ID INNER JOIN Stock_Master sm ON bm.Stock_ID = sm.Stock_ID INNER JOIN Special_Commodity_Master scm ON bm.Special_Commodity_ID = scm.Special_Commodity_ID INNER JOIN Shipment_Master shm ON bm.Shipment_ID = shm.Shipment_ID INNER JOIN City_Master cm ON bm.City_ID = cm.City_ID INNER JOIN Destination_Master dm ON bm.Destination_ID = dm.Destination_ID INNER JOIN Agent_Master am ON bm.Agent_ID = am.Agent_ID AND sm.Agent_ID = am.Agent_ID INNER JOIN Status_Master stm ON bm.Status = stm.Status_ID INNER JOIN Status_Master stm1 on bm.Handovered_Status=stm1.Status_ID inner join Airline_Master alm on substring(sm.AirWayBill_No,1,3)=alm.Airline_Code where AirWayBill_No='" + AirWayBill_No + "'"; 
            
            com = new SqlCommand(insertQuery, con, tr);
            //com = new SqlCommand(insertQuery, con);
            com.ExecuteNonQuery();

            con.Close();
        }

        catch (Exception ex)
        {
            tr.Rollback();
            Response.Write(ex.Message);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    #region Update_AgentLimit
    public void Update_AgentLimit(SqlTransaction tr, SqlConnection con)
    {
        string update;
        DataTable dtUsedLimit = dw.GetAllFromQuery("select isnull(Used_Limit,0)as Used_Limit from agent_master where Agent_ID = " + ViewState["Agent_ID"].ToString());
       if (dtUsedLimit.Rows.Count > 0)
       {
           decimal Used_Limit = 0;

           Used_Limit = decimal.Parse(dtUsedLimit.Rows[0]["Used_Limit"].ToString() == "" ? "0" : dtUsedLimit.Rows[0]["Used_Limit"].ToString()) + decimal.Parse(ViewState["AWB_Fees"].ToString());
           update = "update Agent_Master set Used_Limit=" + Used_Limit + " where Agent_ID=" + ViewState["Agent_ID"].ToString();
           SqlCommand com = new SqlCommand(update, con, tr);
           com.CommandType = CommandType.Text;
           com.ExecuteNonQuery();
       }
       else
       {
           update = "update Agent_Master set Used_Limit=" + decimal.Parse(ViewState["AWB_Fees"].ToString()) + " where Agent_ID=" + ViewState["Agent_ID"].ToString();
           SqlCommand com = new SqlCommand(update, con, tr);
           com.CommandType = CommandType.Text;
           com.ExecuteNonQuery();
       
       }
    }


    #endregion

    #region Insert_Sales
    public void Insert_Sales(SqlTransaction tr, SqlConnection con, DataTable dtStock)
    {
        string insert;

        insert = "insert into Sales(Booking_ID,Handover_ID,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,City_ID,City_Code,Destination_ID,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,FSCRate,WSCRate,XRayRate,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Other_DueCarrier,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Remarks,TDS,Surcharge,Education_Cess,CSR_SNo,Sales_Added_Date,Add_To_Deal,Status,Entered_By,Entered_On) values(@Booking_ID,@Handover_ID,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@City_ID,@City_Code,@Destination_ID,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Other_DueCarrier,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Remarks,@TDS,@Surcharge,@Education_Cess,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Status,@Entered_By,@Entered_On)";

        //SqlCommand com = new SqlCommand(insert, con, tr);
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand com = new SqlCommand(insert,con);
        com.CommandType = CommandType.Text;

        long BookingID = long.Parse(Request.QueryString["booking_id"].ToString());
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = 0;
        //com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = txtFlightNo.Text.Trim();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value =0;
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = Label1.Text.Trim();
              
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(dtStock.Rows[0]["Used_Date"].ToString());
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(dtStock.Rows[0]["Used_Date"].ToString());
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = ViewState["flight_date"].ToString();
      
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(dtStock.Rows[0]["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(dtStock.Rows[0]["Agent_ID"].ToString());
        ViewState["Agent_ID"] = dtStock.Rows[0]["Agent_ID"].ToString();
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = 0;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = 0;

        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ViewState["City_Code"].ToString();
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
         
        
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = 0;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = 0;

        DataTable dtAWB = dw.GetAllFromQuery("select AWB_Fees from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtAWB.Rows[0]["AWB_Fees"].ToString());
        ViewState["AWB_Fees"] = dtAWB.Rows[0]["AWB_Fees"].ToString();
       com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = 0;
       com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = 0;
       com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = 0;
       com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = 0;
       com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = 0;
       DataTable dtDueType=dw.GetAllFromQuery("select DueCarrier_Type from Booking_AWB where Booking_ID=" + BookingID);
       com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = dtDueType.Rows[0]["DueCarrier_Type"].ToString();

       
          com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = 0;
          com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = 0;
      

       com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtAWB.Rows[0]["AWB_Fees"].ToString());
       if (dtDueType.Rows[0]["DueCarrier_Type"].ToString() == "PREPAID")
       {
           com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtAWB.Rows[0]["AWB_Fees"].ToString());
           com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = 0;
       }
       else
       {
           com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = 0;
           com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtAWB.Rows[0]["AWB_Fees"].ToString());
       }
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value =0;
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = 0;
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value =0;
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = "";
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = 0;

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = 0;


        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = 0;
       
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = 0;


        DataTable dtBooking_AWBDetails = dw.GetAllFromQuery("select Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value from Booking_AWB where Booking_ID=" + BookingID);

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Custom_Value"].ToString();

        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = 0;
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = 0;

        #region Generating CSR Serial Auto Number
                
        DateTime UsedDate=DateTime.Parse(dtStock.Rows[0]["Used_Date"].ToString());
        string UD=UsedDate.ToString("dd/MM/yyyy");
        string CSR_Date = UD;

        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }

        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion

        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
       
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 12;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

        com.ExecuteNonQuery();
    }
    #endregion

    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        VoidFns();
        Response.Redirect("HandoverDetails.aspx?id1=" + AirWayBill_No);
        //lblMsg.Text = "Has been Void";
    }
   
}
