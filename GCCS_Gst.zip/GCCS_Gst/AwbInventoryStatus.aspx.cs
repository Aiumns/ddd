﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AwbInventoryStatus : System.Web.UI.Page
{
    //--- Declare Public Variables Here ----
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    // ---- Make Connection From Web.Config File ----
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        // ---- Checking  Validation from Java Script

        Btnload.Attributes.Add("onclick", "return CheckEmpty_ddl();");
        if (!IsPostBack)
        {

            txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            ShowAirline();
        }
    }
    // ---- This Function is used to  bind Airline in dropdown ----
    protected void ShowAirline()
    {

        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID  order by airline_name", con);
            dr = com.ExecuteReader();
            ddl_airline_city.Items.Add(new ListItem("Select Airline Name"));
            while (dr.Read())
            {
                ddl_airline_city.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));
            }
            com.Dispose();
        }
        catch (Exception eror)
        {
            string st = eror.ToString();
        }
        finally
        {
            con.Close();
            com.Dispose();
            dr.Close();
        }

    }

    // ---- Button event for generating and open new window with the help of java script ----
    protected void Btnload_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            Session["airline_city_value"] = ddl_airline_city.SelectedItem.Value;
            Session["airline_city_text"] = ddl_airline_city.SelectedItem.Text;
            Session["from_date"] = txtValidFrom.Text;
            Session["to_date"] = txtValidTo.Text;

            ClientScript.RegisterStartupScript(GetType(), " ", "<SCRIPT LANGUAGE='javascript'>window.open( 'ViewAWBInventoryStatus.aspx');</script>");
            //Response.Write(page_pop);
        }
    }
}
