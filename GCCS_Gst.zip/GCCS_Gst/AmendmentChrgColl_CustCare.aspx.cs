using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//This page is view only in cust. care 
//Hirdayanand Mishra (12/02/2008).

public partial class AmendmentChrgColl_CustCare : System.Web.UI.Page
{
    string htmlTable = "";
    public  string strFalg = "";
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlConnection conn = null;
    SqlCommand comm = null;
    string PageFlag = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                ShowAmendmentRequest();
            }
        }

    }
    protected void ShowAmendmentRequest()
    {
        strFalg = "N";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {
               // string query = "select b.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,Status from Collection_Charges a INNER JOIN agent_master b on a.agent_ID=b.Agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and Status='Requested' and CashStatus is null order by b.agent_Name, addedDate desc";
                string query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Requested' and CashStatus is null order by am.agent_Name, addedDate desc";

                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                     Drow[6] = dr["Airline"].ToString().ToUpper();
                     Drow[7] = "";
                     Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }
            
            GridView1.DataSource = Dt;
            GridView1.DataBind();
           hideGridRow_New();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, System.EventArgs e)
    {

    }
    protected DataTable CustTable()
    {
        DataColumn dc1 = new DataColumn();
        dc1.Caption = "SNo";
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.String");

        DataColumn dc2 = new DataColumn();
        dc2.Caption = "AWBNo";
        dc2.ColumnName = "AWBNo";
        dc2.DataType = System.Type.GetType("System.String");

        DataColumn dc3 = new DataColumn();
        dc3.Caption = "Request";
        dc3.ColumnName = "Request";
        dc3.DataType = System.Type.GetType("System.String");

        DataColumn dc4 = new DataColumn();
        dc4.Caption = "Remarks";
        dc4.ColumnName = "Remarks";
        dc4.DataType = System.Type.GetType("System.String");

        DataColumn dc5 = new DataColumn();
        dc5.Caption = "AddedDate";
        dc5.ColumnName = "AddedDate";
        dc5.DataType = System.Type.GetType("System.String");

        DataColumn dc6 = new DataColumn();
        dc6.Caption = "Status";
        dc6.ColumnName = "Status";
        dc6.DataType = System.Type.GetType("System.String");

        DataColumn dc7 = new DataColumn();
        dc7.Caption = "Airline";
        dc7.ColumnName = "Airline";
        dc7.DataType = System.Type.GetType("System.String");

        DataColumn dc8 = new DataColumn();
        dc8.Caption = "agent_Name";
        dc8.ColumnName = "agent_Name";
        dc8.DataType = System.Type.GetType("System.String");
        //new Amendment 
        DataColumn dc9 = new DataColumn();
        dc9.Caption = "Ch_amt";
        dc9.ColumnName = "Ch_amt";
        dc9.DataType = System.Type.GetType("System.String");

        DataColumn dc10 = new DataColumn();
        dc10.Caption = "Rcd_amt";
        dc10.ColumnName = "Rcd_amt";
        dc10.DataType = System.Type.GetType("System.String");

        DataColumn dc11 = new DataColumn();
        dc11.Caption = "Rcd_date";
        dc11.ColumnName = "Rcd_date";
        dc11.DataType = System.Type.GetType("System.String");

        DataColumn dc12 = new DataColumn();
        dc12.Caption = "RcptNo";
        dc12.ColumnName = "RcptNo";
        dc12.DataType = System.Type.GetType("System.String");

        DataTable dt = new DataTable();
        dt.Columns.Add(dc1);
        dt.Columns.Add(dc2);
        dt.Columns.Add(dc3);
        dt.Columns.Add(dc4);
        dt.Columns.Add(dc5);
        dt.Columns.Add(dc6);
        dt.Columns.Add(dc7);
        dt.Columns.Add(dc8);
        dt.Columns.Add(dc9);
        dt.Columns.Add(dc10);
        dt.Columns.Add(dc11);
        dt.Columns.Add(dc12);  
        return dt;
    }

    protected void hideGridRow_New()
    {
        if(GridView1.Rows.Count>0)
        {
        HtmlTableCell th =  (HtmlTableCell)GridView1.HeaderRow.FindControl("ChH");
        HtmlTableCell th2 = (HtmlTableCell)GridView1.HeaderRow.FindControl("RcdH");
        HtmlTableCell th3 = (HtmlTableCell)GridView1.HeaderRow.FindControl("RcdDateH");
        HtmlTableCell th4 = (HtmlTableCell)GridView1.HeaderRow.FindControl("RcptNo");
        th.Visible = false;
        th2.Visible = false;
        th3.Visible = false;
        th4.Visible = false;
        }

        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow Grow = GridView1.Rows[i];

            Label lblSNo = (Label)Grow.FindControl("lblSNo");
            Label lblAwb = (Label)Grow.FindControl("Label3");
            Label lblAirLine = (Label)Grow.FindControl("lblAirLine");
            HtmlTable tab = (HtmlTable)Grow.FindControl("Tab1");
            HtmlTable tab2 = (HtmlTable)Grow.FindControl("Tab2");
            HtmlTableCell ChRow = (HtmlTableCell)Grow.FindControl("ChRow");
            HtmlTableCell RcdRow = (HtmlTableCell)Grow.FindControl("RcdRow");
            HtmlTableCell RcdRow2 = (HtmlTableCell)Grow.FindControl("RcdDateRow");
            HtmlTableCell RcdRow3 = (HtmlTableCell)Grow.FindControl("RcptNoRow");
            ChRow.Visible = false;
            RcdRow.Visible = false;
            RcdRow2.Visible = false;
            RcdRow3.Visible = false;
            string dd = Grow.Cells[2].Text;
            if (lblSNo.Text == "")
            {

                tab2.Style.Add("display", "none");

            }
            if (lblAwb.Text == "")
            {
                tab.Style.Add("display", "none");
            }


        }

    }

    protected void hideGridRow_Unpaid()
    {
        if (GridView1.Rows.Count > 0)
        {
            HtmlTableCell th = (HtmlTableCell)GridView1.HeaderRow.FindControl("RcdH");
            HtmlTableCell th2 = (HtmlTableCell)GridView1.HeaderRow.FindControl("RcdDateH");
            HtmlTableCell th3 = (HtmlTableCell)GridView1.HeaderRow.FindControl("RcptNo");

            th.Visible = false;
            th2.Visible = false;
            th3.Visible = false;
        }

        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow Grow = GridView1.Rows[i];

            Label lblSNo = (Label)Grow.FindControl("lblSNo");
            Label lblAwb = (Label)Grow.FindControl("Label3");
            Label lblAirLine = (Label)Grow.FindControl("lblAirLine");
            HtmlTable tab = (HtmlTable)Grow.FindControl("Tab1");
            HtmlTable tab2 = (HtmlTable)Grow.FindControl("Tab2");
            HtmlTableCell tc = (HtmlTableCell)Grow.FindControl("RcdRow");
            HtmlTableCell tc2 = (HtmlTableCell)Grow.FindControl("RcdDateRow");
            HtmlTableCell tc3 = (HtmlTableCell)Grow.FindControl("RcptNoRow"); 

            tc.Visible = false;
            tc2.Visible = false;
            tc3.Visible = false;
            string dd = Grow.Cells[2].Text;
            if (lblSNo.Text == "")
            {

                tab2.Style.Add("display", "none");

            }
            if (lblAwb.Text == "")
            {
                tab.Style.Add("display", "none");
            }


        }

    }
    protected void hideGridRow()
    {
       
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow Grow = GridView1.Rows[i];

            Label lblSNo = (Label)Grow.FindControl("lblSNo");
            Label lblAwb = (Label)Grow.FindControl("Label3");
             Label lblAirLine = (Label)Grow.FindControl("lblAirLine");
             HtmlTable tab = (HtmlTable)Grow.FindControl("Tab1");
             HtmlTable tab2 = (HtmlTable)Grow.FindControl("Tab2");            
            string dd = Grow.Cells[2].Text; 
            if (lblSNo.Text == "")
            {
              
               tab2.Style.Add("display", "none");

            }
            if (lblAwb.Text == "" )
            {
              tab.Style.Add("display", "none");
            }
            

        }

    }
    protected void hideGridRow3()
    {
        for (int i = 0; i < GridView3.Rows.Count; i++)
        {
            GridViewRow Grow = GridView3.Rows[i];

            Label lblSNo = (Label)Grow.FindControl("lblSNo");
            Label lblAwb = (Label)Grow.FindControl("Label3");
            Label lblAirLine = (Label)Grow.FindControl("lblAirLine");
            HtmlTable tab = (HtmlTable)Grow.FindControl("Tab1");
            HtmlTable tab4 = (HtmlTable)Grow.FindControl("Tab4");

            string dd = Grow.Cells[2].Text;
            if (lblSNo.Text == "")
            {
                tab4.Style.Add("display", "none");


            }
            if (lblAwb.Text == "")
            {
                tab.Style.Add("display", "none");
            }
            


        }

    }
    protected void hideGridRow2()
    {
        for (int i = 0; i < GridView2.Rows.Count; i++)
        {
            GridViewRow Grow = GridView2.Rows[i];

            Label lblSNo = (Label)Grow.FindControl("lblSNo");
            Label lblAwb = (Label)Grow.FindControl("Label3");
            Label lblAirLine = (Label)Grow.FindControl("lblAirLine");
            HtmlTable tab = (HtmlTable)Grow.FindControl("Tab1");
            HtmlTable tab3 = (HtmlTable)Grow.FindControl("Tab3");


            string dd = Grow.Cells[2].Text;
            if (lblSNo.Text == "")
            {

                tab3.Style.Add("display", "none");


            }
            if (lblAwb.Text == "")
            {
                tab.Style.Add("display", "none");
            }



        }

    }        
  
    protected void lnkNew_Click(object sender, EventArgs e)
    {
        strFalg = "N";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {
                string query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Requested' and CashStatus is null order by am.agent_Name, addedDate desc";
                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                    Drow[6] = dr["Airline"].ToString().ToUpper();
                    Drow[7] = "";
                    Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }
            GridView1.Visible = true;
            GridView3.Visible = false;
            GridView2.Visible = false;

            GridView1.DataSource = Dt;
            GridView1.DataBind();
            hideGridRow_New();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        
    }
    protected void lnkUnpaid_Click(object sender, EventArgs e)
    {
        strFalg = "up";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {  

                string query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status,a.Chargeable_Amount,a.Received_Amount from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Approved for action,payment pending' and CashStatus is null order by am.agent_Name, addedDate desc";

                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                    Drow[6] = dr["Airline"].ToString().ToUpper();
                    Drow[7] = "";
                    Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Drow2[8] = drr["Chargeable_Amount"].ToString();                      
                        Drow2[9] = "";
                        Drow2[10] = "";
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }
            GridView1.Visible = true;
            GridView3.Visible = false;
            GridView2.Visible = false;

            GridView1.DataSource = Dt;
            GridView1.DataBind();
            hideGridRow_Unpaid();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }




    }
    protected void lnkpaid_Click(object sender, EventArgs e)
    {
        strFalg = "P";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {
                //string query = "select b.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,Status from Collection_Charges a INNER JOIN agent_master b on a.agent_ID=b.Agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and Status='Action pending,payment received' and CashStatus='Paid' order by b.agent_Name, addedDate desc";

                string query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status,a.Chargeable_Amount,a.Received_Amount,convert(varchar,a.Rcd_Amt_UpdatedDate,103) as Rcd_Amt_UpdatedDate,a.reciptNo from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Action pending,payment received' and CashStatus='Paid' order by am.agent_Name, addedDate desc";
                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                    Drow[6] = dr["Airline"].ToString().ToUpper();
                    Drow[7] = "";
                    Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Drow2[8] = drr["Chargeable_Amount"].ToString();
                        Drow2[9] = drr["Received_Amount"].ToString();
                        Drow2[10] = drr["Rcd_Amt_UpdatedDate"].ToString();
                        Drow2[11] = drr["reciptNo"].ToString();
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }

            GridView1.Visible = true;
            GridView3.Visible = false;
            GridView2.Visible = false;

            GridView1.DataSource = Dt;
            GridView1.DataBind();
            hideGridRow();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void lnkCom_Click(object sender, EventArgs e)
    {
        strFalg = "c";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {

                string query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status,a.Received_Amount,convert(varchar,a.Rcd_Amt_UpdatedDate,103) as Rcd_Amt_UpdatedDate,a.Chargeable_Amount from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Done' and CashStatus='Paid' order by am.agent_Name, addedDate desc";
                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                    Drow[6] = dr["Airline"].ToString().ToUpper();
                    Drow[7] = "";
                    Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Drow2[8] = drr["Chargeable_Amount"].ToString();
                        Drow2[9] = drr["Received_Amount"].ToString();
                        Drow2[10] = drr["Rcd_Amt_UpdatedDate"].ToString();
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }

            GridView1.Visible = false;
            GridView3.Visible = false;
            GridView2.Visible = true;

            GridView2.DataSource = Dt;
            GridView2.DataBind();
            hideGridRow2();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void lnkCnacel_Click(object sender, EventArgs e)
    {
        strFalg = "can";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {
               
                string query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Request rejected' and CashStatus is null order by am.agent_Name, addedDate desc";


                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                    Drow[6] = dr["Airline"].ToString().ToUpper();
                    Drow[7] = "";
                    Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }
            GridView1.Visible = false;
            GridView3.Visible = true;
            GridView2.Visible = false;
            
            GridView3.DataSource = Dt;
            GridView3.DataBind();
            hideGridRow3();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        BindData();

    }

    protected void BindData()
    {
       // strFalg = "up";
         string query="";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {
       query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Request rejected' and CashStatus is null order by am.agent_Name, addedDate desc";
                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                    Drow[6] = dr["Airline"].ToString().ToUpper();
                    Drow[7] = "";
                    Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }

            GridView3.DataSource = Dt;
            GridView3.DataBind();
            //hideGridRow3();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void GridView3_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        
        GridView3.PageIndex = e.NewPageIndex;
        BindData();

    }
    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView2.PageIndex = e.NewPageIndex;
        BindData2();

    }
    protected void BindData2()
    {
        // strFalg = "up";
        string query = "";
        htmlTable = @"<table width=90% border=1 cellpadding=0 cellspacing=1 align=left>";
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and c.status=2 and C.Airline_Detail_ID in (" + Session["AIRLINEACCESS"].ToString() + ") order by Airline_Name", con);
            SqlDataReader dr = com.ExecuteReader();
            DataTable Dt = CustTable();
            while (dr.Read())
            {
                 query = "select am.agent_Name,SNo,AWBNo,Request,Remarks,Convert(varchar,AddedDate,103) as AddedDate ,a.Status from Collection_Charges a INNER JOIN Agent_Branch b on a.agent_ID=b.Agent_Branch_ID inner join agent_master am on am.agent_ID=b.agent_ID where airline_detail_ID=" + dr["Airline_Detail_ID"].ToString() + " and a.Status='Done' and CashStatus='Paid' order by am.agent_Name, addedDate desc";
                conn = new SqlConnection(strCon);
                conn.Open();
                comm = new SqlCommand(query, conn);
                SqlDataReader drr = comm.ExecuteReader();
                if (drr.HasRows)
                {
                    DataRow Drow = Dt.NewRow();
                    Drow[0] = "";
                    Drow[1] = "";
                    Drow[2] = "";
                    Drow[3] = "";
                    Drow[4] = "";
                    Drow[5] = "";
                    Drow[6] = dr["Airline"].ToString().ToUpper();
                    Drow[7] = "";
                    Dt.Rows.Add(Drow);

                    while (drr.Read())
                    {
                        string RemarksTemp = drr["Remarks"].ToString();
                        char ch = (char)System.Windows.Forms.Keys.Return;
                        char ch2 = (char)System.Windows.Forms.Keys.Space;
                        string ch1 = Convert.ToString(ch);
                        string ch3 = Convert.ToString(ch2);
                        RemarksTemp = RemarksTemp.Replace(ch1, "<br>");
                        RemarksTemp = RemarksTemp.Replace(ch3, "&nbsp;");

                        DataRow Drow2 = Dt.NewRow();
                        Drow2[0] = drr["SNo"].ToString();
                        Drow2[1] = drr["AWBNo"].ToString();
                        Drow2[2] = drr["Request"].ToString();
                        Drow2[3] = RemarksTemp;
                        Drow2[4] = drr["AddedDate"].ToString();
                        Drow2[5] = drr["Status"].ToString();
                        Drow2[6] = "";
                        Drow2[7] = drr["agent_Name"].ToString();
                        Dt.Rows.Add(Drow2);
                    }
                    conn.Close();
                    comm.Dispose();

                }

            }

            GridView2.DataSource = Dt;
            GridView2.DataBind();
            //hideGridRow3();

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}
