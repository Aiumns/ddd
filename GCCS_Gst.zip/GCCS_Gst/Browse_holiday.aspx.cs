using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

public partial class browse_holiday : System.Web.UI.Page
{
    public int sno = 1;

    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        GridView1.DataSource = FetchAllImagesInfo();
        GridView1.DataBind();

    }
    public DataTable FetchAllImagesInfo()
    {
        string sql = "Select * from tblholiday order by city";
        SqlDataAdapter da = new SqlDataAdapter(sql, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

}
