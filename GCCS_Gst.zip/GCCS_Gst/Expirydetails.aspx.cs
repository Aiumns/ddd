using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Expirydetails : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    string Agent_Id = "";
    string City_ID = "";
    string Agent_Name = "";
    string City_Name = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }



        else
        {
            LoadDetails();
        }


    }
    public void LoadDetails()
    { 
        
        SqlConnection con=new SqlConnection(strCon);
    
        SqlCommand cmd = new SqlCommand("getExpireList", con);
        cmd.CommandType = CommandType.StoredProcedure;
        DataTable dt = new DataTable();
        SqlDataAdapter  da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        string table1;
    
        
        table1 = @"<table border=1 width=100%  align=left> <tr class=h1  width=100%><td align=center class=boldtext width=30% colspan=7 NOWRAP><h4> Expire List  </h4></td></tr>";

        if (dt.Rows.Count>0)
        {
            table1 = table1 + @"<tr><td class=boldtext nowrap >Agent </td><td  class=boldtext nowrap>City</td><td  class=boldtext nowrap>Total CPP</td> <td  class=boldtext nowrap>Expired CPP</td><td  class=boldtext nowrap>Expired Date</td></tr>";
        
               for(int i=0;i<dt.Rows.Count;i++)
               {
                if (int.Parse(dt.Rows[i]["city_id"].ToString()) == 6 )
                {

                    table1 += @"<tr><td class=boldtext nowrap align=left >" + dt.Rows[i]["agent_name"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[i]["city_name"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[i]["closingbal"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[i]["availablecpp"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[i]["edate"].ToString() + "</td></tr>";
                   
                }
                
            }
            table1 += @" <tr class=h1  width=100%><td align=center class=boldtext width=30% colspan=7 NOWRAP><h5> For Mumbai  </h5></td></tr>";


          
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                if (int.Parse(dt.Rows[j]["city_id"].ToString()) == 18)
                {

                    table1 += @"<tr><td class=boldtext nowrap align=left >" + dt.Rows[j]["agent_name"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[j]["city_name"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[j]["closingbal"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[j]["availablecpp"].ToString() + "</td><td  class=boldtext nowrap align=left >" + dt.Rows[j]["edate"].ToString() + "</td></tr>";
                   
                }
             
            }
            

        
        }
        else
        {
            table1 = table1 + @"<tr><td class=boldtext style=""color: Red;font-family:verdana;font-size:12px;  text-align: center;"" colspan=6>No Expiry Found for Agents</td></tr>";

        }
        table1 += @"</table>";


        lblexpire.Text = table1;
    
    }
}
