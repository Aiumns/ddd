using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Add_TDS : System.Web.UI.Page
{
    SqlConnection con;
    public bool check;
    public bool chec;
    SqlCommand cmd;
    SqlDataReader rdr;
    SqlDataAdapter sda;
    string[] Sdate;
    string strquery;
    SqlTransaction trans;
    string idd;

    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Add TDS</class>
    /// <description>

    /// </description>
    /// <dependency></dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>10 Dec</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// <modifiedby></modifiedby>
    /// <modifiedOn></modifiedOn>
    /// <changeDescription></changeDescription>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion

    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack  )
            {
                
                txtfromdate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                 Sdate = txtfromdate.Text.Split('/');
               
                string month = Sdate[1];
                string year = Sdate[2];
                if (Sdate[1] == "01" || Sdate[1] == "02" || Sdate[1] == "03")
                {
                    int yy = int.Parse(year);
                    string destdata = "31/03/" + yy.ToString();

                    txtvalidto.Text = destdata;
                    
                }


                if (Sdate[1] == "04" || Sdate[1] == "05" || Sdate[1] == "06" || Sdate[1] == "07" || Sdate[1] == "08" || Sdate[1] == "09" || Sdate[1] == "10" || Sdate[1] == "11" || Sdate[1] == "12")
                {
                    int yy = int.Parse(year) + 1;
                    string destdata = "31/03/" + yy.ToString();

                    txtvalidto.Text = destdata;
                }

            }
            if (!IsPostBack && Request.QueryString["tds_id"] != null)
            {
                title.Text = "Edit TDS";
                btnsubmit.Visible = false;
                Button3.Visible = false;
                
                using (con)
                {
                    con = new SqlConnection(strCon);
                    con.Open();
                    string tdsid = Request.QueryString["tds_id"].ToString();
                    strquery = "select TDS,Education_Cess,convert(varchar,Valid_From,103)as Valid_From ,convert(varchar,Valid_To,103) as Valid_To, SurCharge,Company_SurCharge_Limit,NonCompany_SurCharge_Limit  from tds where tds_id='" + tdsid + "'";
                    cmd = new SqlCommand(strquery, con);
                    rdr = cmd.ExecuteReader();
                    rdr.Read();
                    txtdeductionsc.Text = rdr["TDS"].ToString();
                    txteducation.Text = rdr["Education_Cess"].ToString();
                    txtfromdate.Text = rdr["Valid_From"].ToString();
                    txtvalidto.Text = rdr["Valid_To"].ToString();
                    txtsircharge.Text = rdr["SurCharge"].ToString();
                    txtcomslimit.Text = rdr["Company_SurCharge_Limit"].ToString();
                    txtnoncomscharge.Text = rdr["NonCompany_SurCharge_Limit"].ToString();
                    rdr.Close();
                    con.Close();

                }
            }
            else
            {
                title.Text = "Add TDS";
                btnsubmit.Visible = true;
                btnupdate.Visible = false;
                Button3.Visible = true;
            
            }
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        bool flag=false; 

        using (con)
        {

            DateTime dt1=DateTime.Parse(ConvertDate(txtfromdate.Text));
            DateTime dt2 = DateTime.Parse(ConvertDate(txtvalidto.Text));

            con = new SqlConnection(strCon);
            con.Open();

            string dd = "Select ident_current('TDS') as TDS_ID";
            SqlCommand dd1 = new SqlCommand(dd, con);
            //dd1.CommandText = CommandType.Text;
            int j = Convert.ToInt16(dd1.ExecuteScalar());
            Label1.Text = j.ToString();
            idd = Label1.Text;
            dd1.Dispose();
           
            while(dt1< dt2)
            {
                
            strquery = "select * from TDS where '"+dt1 +"' between Valid_From and Valid_To";
            cmd = new SqlCommand(strquery, con);
            rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                flag=true;
                rdr.Close();
                break;
            }
            cmd.Dispose();
            rdr.Dispose();
                dt1=dt1.AddDays(1);
            }
            if(flag==false)
            {
                  rdr.Close();
                  try
                  {
                      trans = con.BeginTransaction();
                      strquery = "insert into TDS(Tds,SurCharge,Company_SurCharge_Limit,NonCompany_SurCharge_Limit,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,HigherEducation_Cess,Stax) values(@Tds,@SurCharge,@Company_SurCharge_Limit,@NonCompany_SurCharge_Limit,@Education_Cess,@Valid_From,@Valid_To,@Entered_By,@Entered_On,@HigherEducation_Cess,@Stax)";
                      cmd = new SqlCommand(strquery, con, trans);
                      cmd.Parameters.AddWithValue("@Tds", txtdeductionsc.Text);
                      cmd.Parameters.AddWithValue("@SurCharge", txtsircharge.Text);
                      cmd.Parameters.AddWithValue("@Education_Cess", txteducation.Text);
                      cmd.Parameters.AddWithValue("@Valid_From", ConvertDate(txtfromdate.Text));
                      cmd.Parameters.AddWithValue("@Entered_By", Session["EMailID"]);
                      cmd.Parameters.AddWithValue("@Entered_On", System.DateTime.Now);
                      cmd.Parameters.AddWithValue("@Valid_To", ConvertDate(txtvalidto.Text));

                      cmd.Parameters.AddWithValue("@Company_SurCharge_Limit", txtcomslimit.Text);

                      cmd.Parameters.AddWithValue("@NonCompany_SurCharge_Limit", txtnoncomscharge.Text);

                      cmd.Parameters.AddWithValue("@HigherEducation_Cess", txthigherEduCess.Text);
                      cmd.Parameters.AddWithValue("@Stax", txtStax.Text);

                      cmd.ExecuteNonQuery();



                      strquery = "Select ident_current('TDS') as TDS_ID";
                      cmd = new SqlCommand(strquery, con, trans);
                      int f = Convert.ToInt16(cmd.ExecuteScalar());
                      strquery = "insert into db_owner.TDS_History(TDS_Id,TDS,SurCharge,Company_SurCharge_Limit,NonCompany_SurCharge_Limit,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,HigherEducation_Cess,Stax)values(@TDS_Id,@TDS,@SurCharge,@Company_SurCharge_Limit,@NonCompany_SurCharge_Limit,@Education_Cess,@Valid_From,@Valid_To,@Entered_By,@Entered_On,@HigherEducation_Cess,@Stax)";
                      cmd = new SqlCommand(strquery, con, trans);
                      cmd.Parameters.AddWithValue("@TDS_Id", f.ToString());
                      cmd.Parameters.AddWithValue("@Tds", txtdeductionsc.Text);
                      cmd.Parameters.AddWithValue("@SurCharge", txtsircharge.Text);
                      cmd.Parameters.AddWithValue("@Education_Cess", txteducation.Text);
                      cmd.Parameters.AddWithValue("@Valid_From", ConvertDate(txtfromdate.Text));
                      cmd.Parameters.AddWithValue("@Entered_By", Session["EMailID"]);
                      cmd.Parameters.AddWithValue("@Entered_On", System.DateTime.Now);
                      cmd.Parameters.AddWithValue("@Valid_To", ConvertDate(txtvalidto.Text));
                      cmd.Parameters.AddWithValue("@Company_SurCharge_Limit", txtcomslimit.Text);

                      cmd.Parameters.AddWithValue("@NonCompany_SurCharge_Limit", txtnoncomscharge.Text);

                      cmd.Parameters.AddWithValue("@HigherEducation_Cess", txthigherEduCess.Text);
                      cmd.Parameters.AddWithValue("@Stax", txtStax.Text);

                      cmd.ExecuteNonQuery();
                      trans.Commit();
                      iderror.Visible = true;
                      iderror.Text = "Record Added Successfully";


                      iderror.Visible = true;
                      txtdeductionsc.Text = null;
                      txteducation.Text = null;
                      //txtfromdate.Text = null;
                      txtsircharge.Text = null;
                      //txtvalidto.Text = null;
                      txtnoncomscharge.Text = null;
                      txtcomslimit.Text = null;

                  }
                  catch (SqlException ee)
                  {
                      trans.Rollback();
                      iderror.Visible = true;
                      iderror.Text = "Sql Error" + ee.Message;

                  }
                  catch (Exception m)
                  {

                      iderror.Visible = true;
                      iderror.Text = "Error Occur" + m.Message;
                  }
                  finally
                  {
                      if (con != null || con.State == ConnectionState.Open)
                      {
                          con.Close();
                      }
                  }
                  con.Close();

                // Data Insert here loop;
            }
            else
            {
                iderror.Visible = true;
                iderror.Text = "TDS already exists between "+ txtfromdate.Text +" and   " + txtvalidto.Text+"";
                flightopen.Visible = false;
                Button4.Visible = true;               
                //Response.Redirect("TDS_formodify.aspx?DATA=" + ParamUtils.WebParam.Encode(new Pair("id", idd)));

                // Show Massge for Data Already exist;
            }
          
        }
    }
    public  string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void Button1_ServerClick(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        iderror.Visible = false;
        txtdeductionsc.Text = null;
        txteducation.Text = null;
        //txtfromdate.Text = null;
        txtsircharge.Text = null;
        //txtvalidto.Text = null;
        
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("tds_details.aspx");
    }
    protected void txtfromdate_TextChanged(object sender, EventArgs e)
    {

    }
  
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        using (con)
        {
            string qid=Request.QueryString["tds_id"].ToString();
            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                trans = con.BeginTransaction();
                strquery = "update tds set TDS=@TDS,SurCharge=SurCharge,Company_SurCharge_Limit=@Company_SurCharge_Limit,NonCompany_SurCharge_Limit=@NonCompany_SurCharge_Limit,Education_Cess=@Education_Cess,Valid_From=@Valid_From,Valid_To=@Valid_To,HigherEducation_Cess=@HigherEducation_Cess,Stax=@Stax where tds_id='" + qid + "'";
                cmd = new SqlCommand(strquery, con, trans);
                cmd.Parameters.AddWithValue("@TDS", txtdeductionsc.Text);
                cmd.Parameters.AddWithValue("@SurCharge", txtsircharge.Text);
                cmd.Parameters.AddWithValue("@Education_Cess", txteducation.Text);
                cmd.Parameters.AddWithValue("@Valid_From", ConvertDate(txtfromdate.Text));
                cmd.Parameters.AddWithValue("@Valid_To", ConvertDate(txtvalidto.Text));
                cmd.Parameters.AddWithValue("@Company_SurCharge_Limit", txtcomslimit.Text);

                cmd.Parameters.AddWithValue("@NonCompany_SurCharge_Limit", txtnoncomscharge.Text);

                cmd.Parameters.AddWithValue("@HigherEducation_Cess", txthigherEduCess.Text);
                cmd.Parameters.AddWithValue("@Stax", txtStax.Text);

                cmd.ExecuteNonQuery();
                string querysting = Convert.ToString(Request.QueryString["tds_id"]);
                strquery = "insert into db_owner.TDS_History(TDS_Id,TDS,SurCharge,Company_SurCharge_Limit,NonCompany_SurCharge_Limit,Education_Cess,Valid_From,Valid_To,Entered_By,Entered_On,HigherEducation_Cess,Stax)values(@TDS_Id,@TDS,@SurCharge,@Company_SurCharge_Limit,@NonCompany_SurCharge_Limit,@Education_Cess,@Valid_From,@Valid_To,@Entered_By,@Entered_On,@HigherEducation_Cess,@Stax)";
                cmd = new SqlCommand(strquery, con, trans);
                cmd.Parameters.AddWithValue("@TDS_Id", querysting);
                cmd.Parameters.AddWithValue("@Tds", txtdeductionsc.Text);
                cmd.Parameters.AddWithValue("@SurCharge", txtsircharge.Text);
                cmd.Parameters.AddWithValue("@Education_Cess", txteducation.Text);
                cmd.Parameters.AddWithValue("@Valid_From", ConvertDate(txtfromdate.Text));
                cmd.Parameters.AddWithValue("@Entered_By", Session["EMailID"]);
                cmd.Parameters.AddWithValue("@Entered_On", System.DateTime.Now);
                cmd.Parameters.AddWithValue("@Valid_To", ConvertDate(txtvalidto.Text));
                cmd.Parameters.AddWithValue("@Company_SurCharge_Limit", txtcomslimit.Text);

                cmd.Parameters.AddWithValue("@NonCompany_SurCharge_Limit", txtnoncomscharge.Text);

                cmd.Parameters.AddWithValue("@HigherEducation_Cess", txthigherEduCess.Text);
                cmd.Parameters.AddWithValue("@Stax", txtStax.Text);

                cmd.ExecuteNonQuery();
                trans.Commit();
                con.Close();
                Response.Redirect("tds_details.aspx");

            }
            catch (SqlException ss)
            {
                iderror.Text = "sql error" + ss.Message;
                trans.Rollback();

            }
            catch (Exception yy)
            {

                Response.Write("Sorry , There is Error");
            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }       
        
        }
    }
}
