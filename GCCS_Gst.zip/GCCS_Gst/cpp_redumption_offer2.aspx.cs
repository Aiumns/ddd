using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;
using System.Globalization;

public partial class cpp_redumption_offer2 : System.Web.UI.Page
{
   string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

        lblmessage.Visible = false;
        
        DataList1.DataSource = FetchAllImagesInfo();
        DataList1.DataBind();
    }

    public DataTable FetchAllImagesInfo()
    {
        string sql = "Select Image_Content,img_id,category from ImageGallery";
        SqlDataAdapter da = new SqlDataAdapter(sql, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if(txtstart.Text=="" ||txtend.Text == "")            
        {
            lblmessage.Visible = true;
                lblmessage.Text = "Please Enter CPP Rate.";
         }
         else if ((Convert.ToInt32(txtstart.Text)) > (Convert.ToInt32(txtend.Text)))
         {
             lblmessage.Visible = true;
             lblmessage.Text = "Please Enter above Starting CPP.";
         }
         else if ((Convert.ToInt32(txtstart.Text)) < 100)
         {
             lblmessage.Visible = true;
             lblmessage.Text = "Please Enter above 100";
         }
         else
         {
             string URL = "cpp_upload.aspx?start=" + txtstart.Text + "&end=" + txtend.Text + "";
             Response.Redirect(URL);
         }   
    }
}
