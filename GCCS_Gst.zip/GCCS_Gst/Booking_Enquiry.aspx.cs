using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class Booking_Enquiry : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    public string strLen = "";
    public string strLen1 = "";
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader red;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            strLen = "<script>var FillDest =new Array(" + Dest() + ")</script>";
            if (!IsPostBack)
            {
                FillAirline();
                
            }
        }
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public void Add()
    {
        string stradd = "";
        con = new SqlConnection(strCon);
        try
        {
                con.Open();        
                string[] strDestination = txtDestination.Text.Trim().Split('-');
                string[] strAirline= ddlAirlineName.SelectedItem.Text.Split('-');
                DataTable dtAgentID = dw.GetAllFromQuery("select a.agent_name as agent_name,a.agent_id as Agent_id,b.belongs_to_city as belongs_to_city from Agent_Master a inner join Agent_Branch b on a.Agent_ID = b.Agent_ID where b.Agent_Branch_ID=" + Session["ID"].ToString());
                if (dtAgentID.Rows.Count > 0)
                {
                    SqlCommand cmd = new SqlCommand("insert into booking_enquiry(Agent_ID,city,Airline_Detail_ID,dest_code,Gross_Weight,Volume_Weight,No_of_Packages,Commodity,Handover_date,Remarks,Status,Requested_by,Requested_at) values(@Agent_ID,@city,@Airline_Detail_ID,@dest_code,@Gross_Weight,@Volume_Weight,@No_of_Packages,@Commodity,@Handover_date,@Remarks,@status,@Requested_by,@Requested_at)", con);
           
                    cmd.Parameters.AddWithValue("@Agent_ID", dtAgentID.Rows[0]["Agent_ID"].ToString());
                    cmd.Parameters.AddWithValue("@City", dtAgentID.Rows[0]["belongs_to_city"].ToString());
                    cmd.Parameters.AddWithValue("@Airline_Detail_ID", ddlAirlineName.SelectedItem.Value);
                    cmd.Parameters.AddWithValue("@dest_code", strDestination[0].ToString());
                    cmd.Parameters.AddWithValue("@Gross_Weight", txtgrosswt.Text);
                    cmd.Parameters.AddWithValue("@Volume_Weight", txtvolwt.Text);
                    cmd.Parameters.AddWithValue("@No_of_Packages", txtpcs.Text);
                    cmd.Parameters.AddWithValue("@Commodity", txtcommodity.Text);
                    cmd.Parameters.AddWithValue("@Handover_date", FormatDateMM(txtHandDate.Text));
                    cmd.Parameters.AddWithValue("@Remarks", txtRemarks.Text);
                    cmd.Parameters.AddWithValue("@Status", 'U');
                    cmd.Parameters.AddWithValue("@Requested_by", Session["EMailID"].ToString());
                    cmd.Parameters.AddWithValue("@Requested_at",DateTime.Now);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    con.Close();
                    Response.Redirect("Bookingenquiry_AgentDetails.aspx");
                }

            
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        Add();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Bookingenquiry_AgentDetails.aspx");
    }
    public void FillAirline()
    {
        string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in(" + Airline_Access + ") order by Airline_Name", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlAirlineName.DataSource = red;
        ddlAirlineName.DataTextField = "Airline";
        ddlAirlineName.DataValueField = "Airline_Detail_ID";
        ddlAirlineName.DataBind();
        con.Close();
        cmd.Dispose();
        ddlAirlineName.Items.Insert(0, new ListItem("Select Airline", "-1"));
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        return Access;
    }
    public string Dest()
    {
        string strTemp = "";
        con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT * FROM Destination_Master";
            cmd = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")

                    strTemp = "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";
                else

                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";
            }
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }
}
