using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
public partial class FlightSchedule : System.Web.UI.Page
{
     /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    #region Declare Global Variables Here 
    private static string carriercode;
    private static string controlCity;
    private static string destination;
    private static string flightno;
    private static string origin;
    private static string routing;
    protected string flag = "";
    protected string id = "";
    private Int32 m_iRowIdx;
    string strmsg = "";
    public string strCity = "";
    int SNo;
    string FlightNo = "";
    string Route = "";
    string CAO = "";
    string ControlCity = "";
    string EnteredBy = "";
    #endregion
    #region All Connections Here
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    private static DataTable dt = new DataTable();
    DisplayWrap dw = new DisplayWrap();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        strCity = "<script>var CityArray=new Array(" + City() + ")</script>";
        sdsAircraft.ConnectionString =sdsFlightType.ConnectionString = sdsBoundStatus.ConnectionString = strCon;
        if (!IsPostBack)
        {
            bindControls();
            checkForQueryString();
            lblUpdate.Text = "";
            if (Session["Routing"] != null)
                hiddenRouting.Value = Session["Routing"].ToString();
            if (Session["dt"] != null)
            {
                gvFlightLegs.DataSource = null;
                gvFlightLegs.DataBind();
                dt = (DataTable) (Session["dt"]);
                Session["dt"] = null;
                if (Request.QueryString.Count > 0)
                id = Request.QueryString["Id"];
                calVF.RequiredDate = false;
                calVT.RequiredDate = false;
                btnAddSchedule.Visible = false;
                btnDelete.Visible = false;
                btnUpdate.Visible = true;
                btnValidate.Visible = true;
                panelRoute.Enabled = false;
                txtVF.Text = DateTime.Now.ToShortDateString();
                txtVto.Text = DateTime.Now.ToShortDateString();
                panelDetails.Style.Add("display", "none");
                gvFlightLegs.DataSource = dt;
                gvFlightLegs.DataBind();
                for (int i = 0; i < gvFlightLegs.Rows.Count; i++)
                {
                    GridViewRow row = gvFlightLegs.Rows[i];
                    DataRow DTR = dt.Rows[i];
                    for (int c = 0; c < ((CheckBoxList) row.FindControl("chkDays")).Items.Count; c++)
                    {
                        if (
                            DTR["DaysofOperation"].ToString().Contains(
                                ((CheckBoxList) row.FindControl("chkDays")).Items[c].Value))
                            ((CheckBoxList) row.FindControl("chkDays")).Items[c].Selected = true;
                    }
                }
                if (Request.QueryString.Count > 0)
                {
                    GetFlightMasterDetails(int.Parse(id));
                    rdbCAO.SelectedValue = CAO;
                }
                else
                {
                    FlightNo = flightno;
                    Route = routing;
                    ControlCity = controlCity;
                }
                string[] flight = FlightNo.Split('-');
                for (int i = 0; i < ddlAirline.Items.Count; i++)
                {
                    if (ddlAirline.Items[i].Text.Trim().ToUpper() == flight[0].ToUpper())
                    {
                        ddlAirline.SelectedIndex = i;
                        break;
                    }
                }
                txtFlightNo.Text = flight[1];
                btnAddDetails.Visible = false;
                string[] routs = Route.Split('-');
                txtOrigin.Text = routs[0];
                txtDestination.Text = routs[routs.Length - 1];
                txtRouting.Text = Route;
                txtControlCity.Text = ControlCity;
                hiddenRouting.Value = txtRouting.Text.ToUpper();
            }   
            if (dt.Columns.Count == 0)
                dt = GridDataTable();
            if (gvFlightLegs.Rows.Count <= 0)
            {
                gvFlightLegs.DataSource = dt;
                gvFlightLegs.DataBind();
            }
            txtFlightNo.Focus();
            txtVF.Text = DateTime.Now.ToString("MMM-dd-yyyy");
            txtVto.Text = DateTime.Now.ToString("MMM-dd-yyyy");
            if (gvFlightLegs.Rows.Count > 0)
            {
                txtDestination.Text = destination;
                txtOrigin.Text = origin;
                txtControlCity.Text = controlCity;
                txtRouting.Text = routing;
                txtFlightNo.Text = flightno;
                for (int i = 0; i < ddlAirline.Items.Count; i++)
                {
                    if (ddlAirline.Items[i].Text.Trim().ToUpper() == carriercode.ToUpper())
                    {
                        ddlAirline.SelectedIndex = i;
                        break;
                    }
                }
                ddlAirline.Text = carriercode;
                lblRouting.Visible = true;
                txtRouting.Visible = false;
                lblRouting.Text = txtRouting.Text;
                txtVF.Text = DateTime.Now.ToShortDateString();
                txtVto.Text = DateTime.Now.ToShortDateString();
                panelRoute.Enabled = false;
                panelDetails.Style.Add("display", "none");
                destination = origin = controlCity = routing = flightno = carriercode = "";
            }
            else
            {
                txtFlightNo.Focus();
                lblRouting.Visible = false;
                txtRouting.Visible = true;
                btnValidate.Visible = false;
                btnAddSchedule.Visible = false;
            }
        }
        dt.Clear();
        if (Session["Routing"] != null)
            hiddenRouting.Value = Session["Routing"].ToString();
    }

    #region Bind City In Origin
    public string City()
    {
        string strTemp1 = "";
        con = new SqlConnection(strCon);
        try
        {
             cmd = new SqlCommand("Alc_BindCity", con);
             cmd.CommandType = CommandType.StoredProcedure; ;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp1 == "")
                    strTemp1 = "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strTemp1 = strTemp1 + "," + "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
            }
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp1;
    }
    #endregion

    #region BindControls
    private void bindControls()
    {
        con = new SqlConnection(strCon);

        // *********************************************Bind Flight No *********************************************
        cmd = new SqlCommand("Alc_BindFlight", con);
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        dr = cmd.ExecuteReader();
        ddlAirline.DataSource = dr;
        ddlAirline.DataTextField = "CarrierCode";
        ddlAirline.DataValueField = "SNo";
        ddlAirline.DataBind();
        dr.Dispose();
        cmd.Dispose();
        //**********************************************End of bind flight No ***************************************

        //***********************************************Bind data in in Aircraft***********************************
        cmd = new SqlCommand("Alc_BindAircraft", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dr = cmd.ExecuteReader();
        ddlAircraftType.DataSource = dr;
        ddlAircraftType.DataTextField = "Aircrafttype";
        ddlAircraftType.DataValueField = "SNo";
        ddlAircraftType.DataBind();
        dr.Dispose();
        cmd.Dispose();
        //********************************************** End of bind data in in Aircraft ***************************

        //*********************************************Bind flight type*********************************************
        cmd = new SqlCommand("Alc_BindFlightType", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dr = cmd.ExecuteReader();
        ddlFlightType.DataSource = dr;
        ddlFlightType.DataTextField = "flighttype";
        ddlFlightType.DataValueField = "SNo";
        ddlFlightType.DataBind();
        dr.Dispose();
        cmd.Dispose();
        // ********************End of Bind flight type **************************************************

        //*********************Bind Status Here ****************************************************************
        cmd = new SqlCommand("Alc_BindStatus", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dr = cmd.ExecuteReader();
        ddlBoundStatus.DataSource = dr;
        ddlBoundStatus.DataTextField = "Status";
        ddlBoundStatus.DataValueField = "SNo";
        ddlBoundStatus.DataBind();
        dr.Dispose();
        cmd.Dispose();
        con.Close();
        // *********************End ofBind Status Here *********************************************************

    }
    #endregion

    private void checkForQueryString()
    {
        if (Request.QueryString.Count > 0)
        {
            id = Request.QueryString[0];
            calVF.RequiredDate = false;
            calVT.RequiredDate = false;
            flag = Request.QueryString[1];
            if (flag == "E")
            {
                gvFlightLegs.DataSource = null;
                gvFlightLegs.DataBind();
                if (Session["dt"] == null)
                 fillSchedule();
                btnAddSchedule.Visible = false;
                btnDelete.Visible = false;
                btnUpdate.Visible = true;
                btnValidate.Visible = true;
                panelRoute.Enabled = false;
                txtVF.Text = DateTime.Now.ToShortDateString();
                txtVto.Text = DateTime.Now.ToShortDateString();
                panelDetails.Style.Add("display", "none");
            }
            else if (flag == "D")
            {
                gvFlightLegs.DataSource = null;
                gvFlightLegs.DataBind();
                if (Session["dt"] == null)
                    fillSchedule();
                gvFlightLegs.Enabled = false;
                txtControlCity.Enabled = false;
                btnAddSchedule.Visible = false;
                btnDelete.Visible = true;
                btnUpdate.Visible = false;
                btnValidate.Visible = false;
                panelRoute.Enabled = false;
                txtVF.Text = DateTime.Now.ToShortDateString();
                txtVto.Text = DateTime.Now.ToShortDateString();
                panelDetails.Style.Add("display", "none");
                btnValidate.Visible = false;
            }
        }
        else
        {
            Session["dt"] = null;
            gvFlightLegs.DataSource = null;
            gvFlightLegs.DataBind();
            btnDelete.Visible = false;
            btnUpdate.Visible = false;
            panelRoute.Enabled = true;
            btnValidate.Visible = true;
            txtVF.Text = "";
            txtVto.Text = "";
            panelDetails.Style.Add("display", "block");
        }
    }
    protected void fillSchedule()
    {
        Boolean flightExists = CheckFlightNoBySNo(int.Parse(id));
        if (flightExists)
        {
            calVF.Enabled = false;
            calVT.Enabled = false;
            GetFlightMasterDetails(int.Parse(id));
            string[] flight = FlightNo.Split('-');
            rdbCAO.SelectedValue = CAO;
            string[] routs = Route.Split('-');
            flightno = flight[1];
            carriercode = flight[0];
            for (int i = 0; i < ddlAirline.Items.Count; i++)
            {
                if (ddlAirline.Items[i].Text.Trim().ToUpper() == flight[0].ToUpper())
                {
                    ddlAirline.SelectedIndex = i;
                    break;
                }
            }
            origin = routs[0];
            destination = routs[routs.Length - 1];
            routing = Route;
            controlCity = ControlCity;
            hiddenRouting.Value = routing.ToUpper();
            string prevOrigin = "", prevDestination = "";
            bool link;
            dt = GridDataTable();
            con = new SqlConnection(strCon);
            con.Open();
             cmd = new SqlCommand("Alc_FindFlight", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FlightNo", FlightNo);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                string[] ETA = dr["ETA"].ToString().Split(':');
                string[] ETD = dr["ETD"].ToString().Split(':');

                link = false;

                if ((prevOrigin == dr["Origin"].ToString()) && (prevDestination == dr["Destination"].ToString()))
                    link = true;

                DataRow drow = dt.NewRow();
                drow["Origin"] = dr["Origin"].ToString();
                drow["Destination"] = dr["Destination"].ToString();
                drow["ETA"] = ETA[0] + ETA[1];
                drow["ETAZone"] = "GMT";
                drow["ETD"] = ETD[0] + ETD[1];
                drow["ETDZone"] = "GMT";
                drow["Active"] = dr["Active"].ToString();
                drow["DayDifference"] = dr["DayDifference"].ToString();
                drow["ValidFrom"] = DateTime.Parse(dr["ValidFrom"].ToString()).ToString("MMM-dd-yyyy");
                drow["ValidTo"] = DateTime.Parse(dr["ValidTo"].ToString()).ToString("MMM-dd-yyyy");
                drow["AircraftType"] = dr["AircraftSNo"].ToString();
                drow["Allocation"] = dr["Allocation"].ToString();
                drow["DaysofOperation"] = dr["Days"].ToString();
                drow["FlightType"] = dr["FlightTypeSNo"].ToString();
                drow["BoundStatus"] = dr["FlightBoundStatus"].ToString();
                drow["Stops"] = dr["Stops"].ToString();
                drow["Pallets"] = dr["Pallets"].ToString();
                drow["Duplicate"] = link;
                drow["MaxGr"] = dr["PieceMaxGross"].ToString();
                string volUnit = dr["VolumeUnit"].ToString();
                double volume = Convert.ToDouble(dr["Volume"].ToString());
                double MaxVol = Convert.ToDouble(dr["PieceMaxVolume"].ToString());
                double cbm = volume / 166;
                double maxCBM = MaxVol / 166;
                if (volUnit == "cbf")
                {
                    cbm = cbm / 35.3147;
                    maxCBM = maxCBM / 35.3147;
                }
                drow["Volume"] = Convert.ToString(Math.Round(volume, 2));
                drow["MaxVol"] = Convert.ToString(Math.Round(MaxVol, 2));
                drow["CBM"] = Convert.ToString(Math.Round(cbm, 2));
                drow["MaxCBM"] = Convert.ToString(Math.Round(maxCBM, 2));
                drow["VolumeUnit"] = volUnit;

                dt.Rows.Add(drow);

                prevOrigin = dr["Origin"].ToString();
                prevDestination = dr["Destination"].ToString();
            }
            gvFlightLegs.DataSource = null;
            gvFlightLegs.DataSource = dt;
            gvFlightLegs.DataBind();

            for (int i = 0; i < gvFlightLegs.Rows.Count; i++)
            {
                GridViewRow row = gvFlightLegs.Rows[i];
                DataRow DTR = dt.Rows[i];

                for (int c = 0; c < ((CheckBoxList)row.FindControl("chkDays")).Items.Count; c++)
                {
                    if (
                        DTR["DaysofOperation"].ToString().Contains(
                            ((CheckBoxList)row.FindControl("chkDays")).Items[c].Value))
                        ((CheckBoxList)row.FindControl("chkDays")).Items[c].Selected = true;
                }
            }
            showLabels(FlightNo + " Flight No Retrieved Successfully For Flight Schedule  ");
        }
        else
        {
            showLabels("Flight Schedule doesn't exists");
            return;
        }
    }
    public bool CheckFlightNoBySNo(int sno)
    {
        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand("Alc_CheckFlightNoBySNo", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Sno", sno);
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            return true;
        }
        else
        {
            return false;
        }
        cmd.Dispose();
        dr.Dispose();
        con.Close();
    }

    public DataTable GridDataTable()
    {
        DataColumn dc1 = new DataColumn();
        dc1.Caption = "Origin";
        dc1.ColumnName = "Origin";
        dc1.DataType = Type.GetType("System.String");

        DataColumn dc2 = new DataColumn();
        dc2.Caption = "Destination";
        dc2.ColumnName = "Destination";
        dc2.DataType = Type.GetType("System.String");

        DataColumn dc3 = new DataColumn();
        dc3.Caption = "ETA";
        dc3.ColumnName = "ETA";
        dc3.DataType = Type.GetType("System.String");

        DataColumn dc4 = new DataColumn();
        dc4.Caption = "ETAZone";
        dc4.ColumnName = "ETAZone";
        dc4.DataType = Type.GetType("System.String");

        DataColumn dc5 = new DataColumn();
        dc5.Caption = "ETD";
        dc5.ColumnName = "ETD";
        dc5.DataType = Type.GetType("System.String");

        DataColumn dc6 = new DataColumn();
        dc6.Caption = "ETDZone";
        dc6.ColumnName = "ETDZone";
        dc6.DataType = Type.GetType("System.String");

        DataColumn dc7 = new DataColumn();
        dc7.Caption = "Active";
        dc7.ColumnName = "Active";
        dc7.DataType = Type.GetType("System.String");

        DataColumn dc8 = new DataColumn();
        dc8.Caption = "DayDifference";
        dc8.ColumnName = "DayDifference";
        dc8.DataType = Type.GetType("System.String");

        DataColumn dc9 = new DataColumn();
        dc9.Caption = "ValidFrom";
        dc9.ColumnName = "ValidFrom";
        dc9.DataType = Type.GetType("System.String");

        DataColumn dc10 = new DataColumn();
        dc10.Caption = "ValidTo";
        dc10.ColumnName = "ValidTo";
        dc10.DataType = Type.GetType("System.String");

        DataColumn dc11 = new DataColumn();
        dc11.Caption = "AircraftType";
        dc11.ColumnName = "AircraftType";
        dc11.DataType = Type.GetType("System.String");

        DataColumn dc12 = new DataColumn();
        dc12.Caption = "Allocation";
        dc12.ColumnName = "Allocation";
        dc12.DataType = Type.GetType("System.String");

        DataColumn dc13 = new DataColumn();
        dc13.Caption = "DaysofOperation";
        dc13.ColumnName = "DaysofOperation";
        dc13.DataType = Type.GetType("System.String");

        DataColumn dc14 = new DataColumn();
        dc14.Caption = "FlightType";
        dc14.ColumnName = "FlightType";
        dc14.DataType = Type.GetType("System.String");

        DataColumn dc15 = new DataColumn();
        dc15.Caption = "BoundStatus";
        dc15.ColumnName = "BoundStatus";
        dc15.DataType = Type.GetType("System.String");

        DataColumn dc16 = new DataColumn();
        dc16.Caption = "Duplicate";
        dc16.ColumnName = "Duplicate";
        dc16.DataType = Type.GetType("System.Boolean");

        DataColumn dc17 = new DataColumn();
        dc17.Caption = "Stops";
        dc17.ColumnName = "Stops";
        dc17.DataType = Type.GetType("System.String");

        DataColumn dc18 = new DataColumn();
        dc18.Caption = "Pallets";
        dc18.ColumnName = "Pallets";
        dc18.DataType = Type.GetType("System.String");

        DataColumn dc19 = new DataColumn();
        dc19.Caption = "Volume";
        dc19.ColumnName = "Volume";
        dc19.DataType = Type.GetType("System.String");

        //DataColumn dc20 = new DataColumn();
        //dc20.Caption = "ULDValue";
        //dc20.ColumnName = "ULDValue";
        //dc20.DataType = Type.GetType("System.String");

        DataColumn dc21 = new DataColumn();
        dc21.Caption = "MaxVol";
        dc21.ColumnName = "MaxVol";
        dc21.DataType = Type.GetType("System.String");

        DataColumn dc22 = new DataColumn();
        dc22.Caption = "MaxGr";
        dc22.ColumnName = "MaxGr";
        dc22.DataType = Type.GetType("System.String");

        DataColumn dc23 = new DataColumn();
        dc23.Caption = "CBM";
        dc23.ColumnName = "CBM";
        dc23.DataType = Type.GetType("System.String");

        DataColumn dc24 = new DataColumn();
        dc24.Caption = "VolumeUnit";
        dc24.ColumnName = "VolumeUnit";
        dc24.DataType = Type.GetType("System.String");

        DataColumn dc25 = new DataColumn();
        dc25.Caption = "MaxCBM";
        dc25.ColumnName = "MaxCBM";
        dc25.DataType = Type.GetType("System.String");

        DataTable dt = new DataTable();
        dt.Columns.Add(dc1);
        dt.Columns.Add(dc2);
        dt.Columns.Add(dc3);
        dt.Columns.Add(dc4);
        dt.Columns.Add(dc5);
        dt.Columns.Add(dc6);
        dt.Columns.Add(dc7);
        dt.Columns.Add(dc8);
        dt.Columns.Add(dc9);
        dt.Columns.Add(dc10);
        dt.Columns.Add(dc11);
        dt.Columns.Add(dc12);
        dt.Columns.Add(dc13);
        dt.Columns.Add(dc14);
        dt.Columns.Add(dc15);
        dt.Columns.Add(dc16);
        dt.Columns.Add(dc17);
        dt.Columns.Add(dc18);
        dt.Columns.Add(dc19);
        //dt.Columns.Add(dc20);
        dt.Columns.Add(dc21);
        dt.Columns.Add(dc22);
        dt.Columns.Add(dc23);
        dt.Columns.Add(dc24);
        dt.Columns.Add(dc25);
        return dt;
    }
 
    protected void showLabels(string messageString)
    {
        lblMessage.Visible = lblGridMessage.Visible = true;
        lblMessage.Text = lblGridMessage.Text = messageString;
    }

    protected void hideLabels()
    {
        lblMessage.Visible = lblGridMessage.Visible = false;
        lblMessage.Text = lblGridMessage.Text = "";
    }
    public bool CheckCity(string croute)
    {
         con = new SqlConnection(strCon);
         con.Open();
         cmd = new SqlCommand("Alc_CheckCity", con);
         cmd.CommandType = CommandType.StoredProcedure;
         cmd.Parameters.AddWithValue("@city_code", croute);
         dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            return true;
        }
        else
        {
            return false;
        }
        cmd.Dispose();
        dr.Dispose();
        con.Close();
        
    }

    public void GetFlightMasterDetails(int sno)
    {
        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand("Alc_FlightMaster_SelectBySNo", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_SNo", sno);
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            SNo = int.Parse(dr["SNo"].ToString());
            FlightNo = dr["FlightNo"].ToString();
            Route = dr["Route"].ToString();
            CAO = dr["CAO"].ToString();
            ControlCity = dr["ControlCity"].ToString();
            EnteredBy = dr["EnteredBy"].ToString();
        }
        cmd.Dispose();
        dr.Dispose();
        con.Close();
    }
    protected void btnAddDetails_Click(object sender, EventArgs e)
    {
        gvFlightLegs.DataSource = null;
        gvFlightLegs.DataBind();
        dt = GridDataTable();
        if (txtRouting.Text == "")
        {
            showLabels("Please Plan a route to Add Flight Schedule");
            txtOrigin.Focus();
            return;
        }

        string[] route = txtRouting.Text.ToUpper().Split('-');
        for (int i = 0; i < route.Length; i++)
        {
            if (CheckCity(route[i]) == false)
            {
                showLabels(route[i] + " is not a valid City Code");
                return;
            }
        }

        if (CheckCity(txtControlCity.Text.Substring(0, 3)) == false)
        {
            showLabels(txtControlCity.Text.Substring(0, 3) + " is not a valid City Code");
            txtControlCity.Focus();
            return;
        }

        hiddenRouting.Value = txtRouting.Text.ToUpper();
        hideLabels();
        Session["Routing"] = txtRouting.Text.ToUpper();
        for (int i = 0; i < route.Length; i++)
        {
            for (int j = i + 1; j <= route.Length - 1; j++)
            {
                DataRow drow = dt.NewRow();
                drow["Origin"] = route[i];
                drow["Destination"] = route[j];
                drow["ETA"] = "";
                //drow["ETAZone"] = GetTimeZone(route[j]);
                drow["ETAZone"] = "GMT";
                drow["ETD"] = "";
                //drow["ETDZone"] = GetTimeZone(route[i]);
                drow["ETDZone"] = "GMT";
                drow["Active"] = "Y";
                drow["DayDifference"] = "0";
                drow["ValidFrom"] = txtVF.Text;
                drow["ValidTo"] = txtVto.Text;
                drow["AircraftType"] = ddlAircraftType.SelectedValue;
                drow["Allocation"] = "0";
                drow["Volume"] = "0";
                drow["DaysofOperation"] = "";
                drow["FlightType"] = ddlFlightType.SelectedValue;
                drow["BoundStatus"] = ddlBoundStatus.SelectedValue;
                drow["Stops"] = Convert.ToString(j - i - 1);
                drow["Pallets"] = "0";
                drow["Duplicate"] = false;
                drow["MaxVol"] = "0";
                drow["MaxGr"] = "0";
                drow["CBM"] = "0";
                drow["VolumeUnit"] = "cbm";
                drow["MaxCBM"] = "0";
                dt.Rows.Add(drow);
            }
        }
        carriercode = ddlAirline.SelectedValue;
        flightno = txtFlightNo.Text;
        controlCity = txtControlCity.Text;
        routing = txtRouting.Text;
        origin = txtOrigin.Text;
        destination = txtDestination.Text;
        Response.Redirect("FlightSchedule.aspx");
    }

    protected void gvFlightLegs_SelectedIndexChanged(object sender, EventArgs e)
    {
        int gridRowIndex = gvFlightLegs.SelectedIndex;

        GridViewRow grow = gvFlightLegs.SelectedRow;

        dt = GridDataTable();
        for (int i = 0; i < gvFlightLegs.Rows.Count; i++)
        {
            string days = "";
            GridViewRow oldrows = gvFlightLegs.Rows[i];
            for (int c = 0; c < ((CheckBoxList) oldrows.FindControl("chkDays")).Items.Count; c++)
            {
                if (((CheckBoxList) oldrows.FindControl("chkDays")).Items[c].Selected)
                    if (days == "")
                        days = ((CheckBoxList) oldrows.FindControl("chkDays")).Items[c].Value;
                    else
                        days = days + "," + ((CheckBoxList) oldrows.FindControl("chkDays")).Items[c].Value;
            }
            string link = (grow.FindControl("linkDelete")).Visible.ToString();
            if (i == gridRowIndex)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (j == 1)
                    {
                        days = "";
                        link = "true";
                    }
                    DataRow drow = dt.NewRow();
                    drow["Origin"] = ((Label) grow.FindControl("lblOrigin")).Text;
                    drow["Destination"] = ((Label) grow.FindControl("lblDestination")).Text;
                    drow["ETA"] = ((TextBox) grow.FindControl("txtETA")).Text;
                    drow["ETAZone"] = ((Label) grow.FindControl("lblOriginZone")).Text;
                    drow["ETD"] = ((TextBox) grow.FindControl("txtETD")).Text;
                    drow["ETDZone"] = ((Label) grow.FindControl("lblDestinationZone")).Text;
                    drow["Active"] = ((TextBox) grow.FindControl("txtActive")).Text;
                    drow["DayDifference"] = ((TextBox) grow.FindControl("txtDayDifference")).Text;
                    drow["ValidFrom"] = ((TextBox) grow.FindControl("txtFrom")).Text;
                    drow["ValidTo"] = ((TextBox) grow.FindControl("txtTo")).Text;
                    drow["AircraftType"] = ((DropDownList) grow.FindControl("ddlAircraftType")).SelectedValue;
                    drow["Allocation"] = ((TextBox) grow.FindControl("txtCapacity")).Text;
                    drow["Volume"] = ((TextBox) grow.FindControl("txtVolume")).Text;
                    drow["DaysofOperation"] = days;
                    drow["FlightType"] = ((DropDownList) grow.FindControl("ddlFlightType")).SelectedValue;
                    drow["BoundStatus"] = ((DropDownList) grow.FindControl("ddlBoundStatus")).SelectedValue;
                    drow["Duplicate"] = Convert.ToBoolean(link);
                    drow["Stops"] = ((TextBox) grow.FindControl("txtStops")).Text;
                    drow["Pallets"] = ((TextBox) grow.FindControl("txtPallets")).Text;
                    drow["MaxVol"] = ((TextBox) grow.FindControl("txtMaxVol")).Text;
                    drow["MaxGr"] = ((TextBox) grow.FindControl("txtMaxGr")).Text;
                    drow["CBM"] = ((TextBox) grow.FindControl("txtCBM")).Text;
                    drow["VolumeUnit"] = ((DropDownList) grow.FindControl("ddlCBM")).SelectedValue;
                    drow["MaxCBM"] = ((TextBox) grow.FindControl("txtMaxCBM")).Text;
                     dt.Rows.Add(drow);
                }
            }
            else
            {
                DataRow drow = dt.NewRow();
                drow["Origin"] = ((Label) oldrows.FindControl("lblOrigin")).Text;
                drow["Destination"] = ((Label) oldrows.FindControl("lblDestination")).Text;
                drow["ETA"] = ((TextBox) oldrows.FindControl("txtETA")).Text;
                drow["ETAZone"] = ((Label) oldrows.FindControl("lblOriginZone")).Text;
                drow["ETD"] = ((TextBox) oldrows.FindControl("txtETD")).Text;
                drow["ETDZone"] = ((Label) oldrows.FindControl("lblDestinationZone")).Text;
                drow["Active"] = ((TextBox) oldrows.FindControl("txtActive")).Text;
                drow["DayDifference"] = ((TextBox) oldrows.FindControl("txtDayDifference")).Text;
                drow["ValidFrom"] = ((TextBox) oldrows.FindControl("txtFrom")).Text;
                drow["ValidTo"] = ((TextBox) oldrows.FindControl("txtTo")).Text;
                drow["AircraftType"] = ((DropDownList) oldrows.FindControl("ddlAircraftType")).SelectedValue;
                drow["Allocation"] = ((TextBox) oldrows.FindControl("txtCapacity")).Text;
                drow["Volume"] = ((TextBox) oldrows.FindControl("txtVolume")).Text;
                drow["DaysofOperation"] = days;
                drow["FlightType"] = ((DropDownList) oldrows.FindControl("ddlFlightType")).SelectedValue;
                drow["BoundStatus"] = ((DropDownList) oldrows.FindControl("ddlBoundStatus")).SelectedValue;
                drow["Duplicate"] = (oldrows.FindControl("linkDelete")).Visible;
                drow["Stops"] = ((TextBox) oldrows.FindControl("txtStops")).Text;
                drow["Pallets"] = ((TextBox) oldrows.FindControl("txtPallets")).Text;
                drow["MaxVol"] = ((TextBox) oldrows.FindControl("txtMaxVol")).Text;
                drow["MaxGr"] = ((TextBox) oldrows.FindControl("txtMaxGr")).Text;
                drow["CBM"] = ((TextBox) oldrows.FindControl("txtCBM")).Text;
                drow["VolumeUnit"] = ((DropDownList) grow.FindControl("ddlCBM")).SelectedValue;
                drow["MaxCBM"] = ((TextBox) oldrows.FindControl("txtMaxCBM")).Text;

                dt.Rows.Add(drow);
            }
        }
        carriercode = ddlAirline.SelectedValue;
        flightno = txtFlightNo.Text;
        controlCity = txtControlCity.Text;
        routing = txtRouting.Text;
        origin = txtOrigin.Text;
        destination = txtDestination.Text;
        Session["dt"] = dt;
        if (Request.QueryString.Count > 0)
            Response.Redirect("FlightSchedule.aspx?Id=" + Request.QueryString["Id"] + "&st=E");
        else
            Response.Redirect("FlightSchedule.aspx");
    }

    protected void gvFlightLegs_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        dt = GridDataTable();
        for (int i = 0; i < gvFlightLegs.Rows.Count; i++)
        {
            string days = "";
            GridViewRow gRow = gvFlightLegs.Rows[i];
            for (int c = 0; c < ((CheckBoxList) gRow.FindControl("chkDays")).Items.Count; c++)
            {
                if (((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Selected)
                    if (days == "")
                        days = ((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Value;
                    else
                        days = days + "," + ((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Value;
            }
            DataRow drow = dt.NewRow();
            drow["Origin"] = ((Label) gRow.FindControl("lblOrigin")).Text;
            drow["Destination"] = ((Label) gRow.FindControl("lblDestination")).Text;
            drow["ETA"] = ((TextBox) gRow.FindControl("txtETA")).Text;
            drow["ETAZone"] = ((Label) gRow.FindControl("lblOriginZone")).Text;
            drow["ETD"] = ((TextBox) gRow.FindControl("txtETD")).Text;
            drow["ETDZone"] = ((Label) gRow.FindControl("lblDestinationZone")).Text;
            drow["Active"] = ((TextBox) gRow.FindControl("txtActive")).Text;
            drow["DayDifference"] = ((TextBox) gRow.FindControl("txtDayDifference")).Text;
            drow["ValidFrom"] = ((TextBox) gRow.FindControl("txtFrom")).Text;
            drow["ValidTo"] = ((TextBox) gRow.FindControl("txtTo")).Text;
            drow["AircraftType"] = ((DropDownList) gRow.FindControl("ddlAircraftType")).SelectedValue;
            drow["Allocation"] = ((TextBox) gRow.FindControl("txtCapacity")).Text;
            drow["Volume"] = ((TextBox) gRow.FindControl("txtVolume")).Text;
            drow["DaysofOperation"] = days;
            drow["FlightType"] = ((DropDownList) gRow.FindControl("ddlFlightType")).SelectedValue;
            drow["BoundStatus"] = ((DropDownList) gRow.FindControl("ddlBoundStatus")).SelectedValue;
            drow["Duplicate"] = (gRow.FindControl("linkDelete")).Visible;
            drow["Stops"] = ((TextBox) gRow.FindControl("txtStops")).Text;
            drow["Pallets"] = ((TextBox) gRow.FindControl("txtPallets")).Text;
            drow["MaxVol"] = ((TextBox) gRow.FindControl("txtMaxVol")).Text;
            drow["MaxGr"] = ((TextBox) gRow.FindControl("txtMaxGr")).Text;
            drow["CBM"] =
                Convert.ToString(Math.Round((Convert.ToDecimal(((TextBox) gRow.FindControl("txtVolume")).Text)/166), 2));
            drow["VolumeUnit"] = ((DropDownList) gRow.FindControl("ddlCBM")).SelectedValue;
            dt.Rows.Add(drow);
        }

        dt.Rows[e.RowIndex].Delete();
        carriercode = ddlAirline.SelectedValue;
        flightno = txtFlightNo.Text;
        controlCity = txtControlCity.Text;
        routing = txtRouting.Text;
        origin = txtOrigin.Text;
        destination = txtDestination.Text;
        Session["dt"] = dt;
        if (Request.QueryString.Count > 0)
            Response.Redirect("FlightSchedule.aspx?Id=" + Request.QueryString["Id"] + "&st=E");
        else
            Response.Redirect("FlightSchedule.aspx");
    }

    protected Boolean checkSchedule()
    {
        if (gvFlightLegs.Rows.Count < 1)
        {
            showLabels("Please Add Schedule Details to Validate");
            return false;
        }

        if (txtFlightNo.Text == "")
        {
            showLabels("Enter Flight No");
            return false;
        }

        string FlightNo = ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text;

        if (txtRouting.Text == "")
        {
            showLabels("Please replan Flight Schedule Routing for Flight No " + FlightNo);
            txtOrigin.Focus();
            return false;
        }

        if (txtRouting.Text != hiddenRouting.Value)
        {
            showLabels("Flight Schedule Routing for Flight No " + FlightNo + " has changed, Please replan routing");
            txtOrigin.Focus();
            return false;
        }

        if (txtControlCity.Text == "")
        {
            showLabels("Enter Control City of the Flight Schedule for Flight No " + FlightNo);
            txtControlCity.Focus();
            return false;
        }

        string prevOrigin = "", prevDestination = "", prevDays = "", prevStartDate = "", prevEndDate = "";

        for (int i = 0; i < gvFlightLegs.Rows.Count; i++)
        {
            GridViewRow gRow = gvFlightLegs.Rows[i];
            string Origin = ((Label) gRow.FindControl("lblOrigin")).Text;
            string Destination = ((Label) gRow.FindControl("lblDestination")).Text;
            string StartDate = ((TextBox) gRow.FindControl("txtFrom")).Text;
            string EndDate = ((TextBox) gRow.FindControl("txtTo")).Text;
            string leg = Origin + " - " + Destination;
            if (((TextBox) gRow.FindControl("txtETD")).Text == "")
            {
                showLabels("Enter ETD for " + leg + " leg");
                (gRow.FindControl("txtETD")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if (((TextBox) gRow.FindControl("txtETD")).Text.Length != 4)
            {
                showLabels("ETD for " + leg + " leg is not in correct format");
                (gRow.FindControl("txtETD")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if (((TextBox) gRow.FindControl("txtETA")).Text == "")
            {
                showLabels("Enter ETA for " + leg + " leg");
                (gRow.FindControl("txtETA")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if (((TextBox) gRow.FindControl("txtETA")).Text.Length != 4)
            {
                showLabels("ETA for " + leg + " leg is not in correct format");
                (gRow.FindControl("txtETA")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if (
                !((((TextBox) gRow.FindControl("txtDayDifference")).Text == "-1") ||
                  (((TextBox) gRow.FindControl("txtDayDifference")).Text == "0") ||
                  (((TextBox) gRow.FindControl("txtDayDifference")).Text == "1")))
            {
                showLabels("Day Difference for " + leg + " leg is invalid");
                (gRow.FindControl("txtDayDifference")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if ((int.Parse(((TextBox) gRow.FindControl("txtETD")).Text.Substring(0, 2)) >
                 (int.Parse(((TextBox) gRow.FindControl("txtETA")).Text.Substring(0, 2)))) &&
                (int.Parse(((TextBox) gRow.FindControl("txtDayDifference")).Text) < 1))
                ((TextBox) gRow.FindControl("txtDayDifference")).Text = "1";

            if (((TextBox) gRow.FindControl("txtFrom")).Text == "")
            {
                showLabels("Enter Start Date of Schedule for " + leg + " leg");
                (gRow.FindControl("txtFrom")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if (((TextBox) gRow.FindControl("txtTo")).Text == "")
            {
                showLabels("Enter End Date of Schedule for " + leg + " leg");
                (gRow.FindControl("txtTo")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if (((TextBox) gRow.FindControl("txtStops")).Text == "")
            {
                showLabels("Enter No. of Stops for " + leg + " leg, for Direct Flight enter '0'");
                (gRow.FindControl("txtStops")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if (((TextBox) gRow.FindControl("txtPallets")).Text == "")
            {
                showLabels("Enter No. of Pallets for " + leg + " leg");
                (gRow.FindControl("txtPallets")).Focus();
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            string days = "";

            for (int c = 0; c < ((CheckBoxList) gRow.FindControl("chkDays")).Items.Count; c++)
            {
                if (((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Selected)
                    if (days == "")
                        days = ((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Value;
                    else
                        days = days + "," + ((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Value;
            }

            if (days == "")
            {
                showLabels("Select Days of Operation for " + leg + " leg");
                gRow.BackColor = Color.SandyBrown;
                return false;
            }

            if ((prevOrigin == Origin) && (prevDestination == Destination) && (prevStartDate == StartDate) &&
                (prevEndDate == EndDate))
            {
                string[] previousDays = prevDays.Split(',');

                for (int p = 0; p < previousDays.Length; p++)
                    if (days.Contains(previousDays[p]))
                    {
                        {
                            showLabels("Days of Operation overlaps for " + leg + " leg");
                            gRow.BackColor = Color.SandyBrown;
                            return false;
                        }
                    }
            }
            prevOrigin = Origin;
            prevDestination = Destination;
            prevStartDate = StartDate;
            prevEndDate = EndDate;
            prevDays = days;

            gRow.BackColor = Color.FromArgb(255, 247, 228);
        }
        showLabels("No Errors detected in Flight Schedule, Please proceed to ");
        return true;
    }
    public bool CheckFlightNo(string croute)
    {
        con = new SqlConnection(strCon);
        con.Open();
        cmd = new SqlCommand("Alc_CheckFlightNo", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@FlightNo", croute);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            return true;
        }
        else
        {
            return false;
        }
        cmd.Dispose();
        dr.Dispose();
        con.Close();

    }
    protected void addSchedule()
    {
        Boolean flightExists = CheckFlightNo(ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text);

        if (!flightExists)
        {
            if (!checkSchedule())
            {
                return;
            }
            lblGridMessage.Text += " Add Schedule";

            lblGridMessage.Visible = lblMessage.Visible = false;
            FlightNo = ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text;
            Route = (lblRouting.Text == "") ? txtRouting.Text : lblRouting.Text;
            ControlCity = txtControlCity.Text;
            CAO = rdbCAO.SelectedValue;
            EnteredBy = Session["emailid"].ToString();

            SqlConnection con = new SqlConnection(strCon);
            SqlTransaction tr = null;
            try

            {
                con.Open();
                tr = con.BeginTransaction();
                SqlCommand cmd = new SqlCommand("Alc_FlightMaster_Insert", con,tr);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@_FlightNo", FlightNo);
                cmd.Parameters.AddWithValue("@_Route", Route);
                cmd.Parameters.AddWithValue("@_ControlCity", ControlCity);
                cmd.Parameters.AddWithValue("@_CAO", CAO);
                cmd.Parameters.AddWithValue("@_EnteredBy", EnteredBy);
                cmd.ExecuteNonQuery();
                for (int i = 0; i < gvFlightLegs.Rows.Count; i++)
                {
                    GridViewRow gRow = gvFlightLegs.Rows[i];

                    string FlightNo1 = ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text;
                    string Origin = ((Label) gRow.FindControl("lblOrigin")).Text;
                    string Destination = ((Label) gRow.FindControl("lblDestination")).Text;
                    string ETA = ((TextBox) gRow.FindControl("txtETA")).Text.Substring(0, 2) + ":" +
                                 ((TextBox) gRow.FindControl("txtETA")).Text.Substring(2, 2);
                    string ETD = ((TextBox) gRow.FindControl("txtETD")).Text.Substring(0, 2) + ":" +
                                 ((TextBox) gRow.FindControl("txtETD")).Text.Substring(2, 2);
                    DateTime ValidFrom = DateTime.Parse(((TextBox) gRow.FindControl("txtFrom")).Text);
                    DateTime ValidTo = DateTime.Parse(((TextBox) gRow.FindControl("txtTo")).Text);
                    int AircraftType = int.Parse(((DropDownList) gRow.FindControl("ddlAircraftType")).SelectedValue);
                    decimal Allocation = decimal.Parse(((TextBox) gRow.FindControl("txtCapacity")).Text);

                    string DaysofOperation = "";
                    for (int c = 0; c < ((CheckBoxList) gRow.FindControl("chkDays")).Items.Count; c++)
                    {
                        if (((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Selected)
                            if (DaysofOperation == "")
                                DaysofOperation = ((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Value;
                            else
                                DaysofOperation = DaysofOperation + "," +
                                                  ((CheckBoxList) gRow.FindControl("chkDays")).Items[c].Value;
                    }
                    int FlightType = int.Parse(((DropDownList) gRow.FindControl("ddlFlightType")).SelectedValue);
                    int BoundStatus = int.Parse(((DropDownList) gRow.FindControl("ddlBoundStatus")).SelectedValue);
                    int DayDifference = int.Parse(((TextBox) gRow.FindControl("txtDayDifference")).Text);
                    string Active = ((TextBox) gRow.FindControl("txtActive")).Text.ToUpper();
                    int Stops = int.Parse(((TextBox) gRow.FindControl("txtStops")).Text);
                    int Pallets = int.Parse(((TextBox) gRow.FindControl("txtPallets")).Text);
                    decimal volume = decimal.Parse(((TextBox) gRow.FindControl("txtVolume")).Text);
                    string volumeUnit = ((DropDownList) gRow.FindControl("ddlCBM")).SelectedValue;
                    decimal PieceMaxVolume =
                        decimal.Parse(((TextBox) gRow.FindControl("txtMaxVol")).Text == ""
                                          ? "0"
                                          : ((TextBox) gRow.FindControl("txtMaxVol")).Text);
                    decimal PieceMaxGross =
                        decimal.Parse(((TextBox) gRow.FindControl("txtMaxGr")).Text == ""
                                          ? "0"
                                          : ((TextBox) gRow.FindControl("txtMaxGr")).Text);

                     //con.Open();
                    SqlCommand cmd1 = new SqlCommand("alc_FlightTrans_Insert", con, tr);
                    cmd1.CommandType = CommandType.StoredProcedure;
                    cmd1.Parameters.AddWithValue("@_FlightNo", FlightNo);
                    cmd1.Parameters.AddWithValue("@_Origin", Origin);
                    cmd1.Parameters.AddWithValue("@_Destination", Destination);
                    cmd1.Parameters.AddWithValue("@_ETD", ETD);
                    cmd1.Parameters.AddWithValue("@_ETA", ETA);
                    cmd1.Parameters.AddWithValue("@_ValidFrom", ValidFrom);
                    cmd1.Parameters.AddWithValue("@_ValidTo", ValidTo);
                    cmd1.Parameters.AddWithValue("@_AircraftSNo", AircraftType);
                    cmd1.Parameters.AddWithValue("@_Allocation", Allocation);
                    cmd1.Parameters.AddWithValue("@_Days", DaysofOperation);
                    cmd1.Parameters.AddWithValue("@_FlightTypeSNo", FlightType);
                    cmd1.Parameters.AddWithValue("@_FlightBoundStatus", BoundStatus);
                    cmd1.Parameters.AddWithValue("@_DayDifference", DayDifference);
                    cmd1.Parameters.AddWithValue("@_Active", Active);
                    cmd1.Parameters.AddWithValue("@_EnteredBy", Session["emailid"]);
                    cmd1.Parameters.AddWithValue("@_Stops", Stops);
                    cmd1.Parameters.AddWithValue("@_Pallets", Pallets);
                    cmd1.Parameters.AddWithValue("@_VolumeUnit", volumeUnit);
                    cmd1.Parameters.AddWithValue("@_Volume", volume);
                    cmd1.Parameters.AddWithValue("@_PieceMaxVolume", PieceMaxVolume);
                    cmd1.Parameters.AddWithValue("@_PieceMaxGross", PieceMaxGross);
                    int ident  = cmd1.ExecuteNonQuery();
                }
                tr.Commit();
                con.Close();
                showLabels("Flight Schedule added sucessfully for Flight No " + FlightNo);
                lblUpdate.Text = "Flight Schedule added sucessfully for Flight No " + FlightNo +
                                 ". Being redirected to Flight Schedule Details in few seconds";
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "key",
                                                        "<script language='javascript'>alert('Flight Schedule added sucessfully for Flight No " +
                                                        FlightNo +
                                                        ".');</script>", false);

                Response.Redirect("DisplayFlightSchedule.aspx?ID=" + FlightNo + "&st="+strmsg);
            }
            catch (SqlException)
            {
                if (tr != null) tr.Rollback();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
        else
        {
            showLabels("Flight Schedule already exists for Flight No " + FlightNo);
            return;
        }
    }
    protected void updateSchedule()
    {
        Boolean flightExists = CheckFlightNo(ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text);

        if (flightExists)
        {
            if (!checkSchedule())
                return;
            lblGridMessage.Text += " Update Schedule";

            hideLabels();
            SNo = int.Parse(id);
            FlightNo = ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text;
            Route = txtRouting.Text;
            ControlCity = txtControlCity.Text;
            CAO = rdbCAO.SelectedValue;
            EnteredBy = Session["emailid"].ToString();

            SqlConnection con = new SqlConnection(strCon);
            SqlTransaction tr = null;
            try
            {
                con.Open();
                tr = con.BeginTransaction();
                SqlCommand cmd = new SqlCommand("Alc_FlightMaster_Update", con, tr);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@_SNo", ControlCity);
                cmd.Parameters.AddWithValue("@_ControlCity", ControlCity);
                cmd.Parameters.AddWithValue("@_CAO", CAO);
                cmd.Parameters.AddWithValue("@_EnteredBy", EnteredBy);
                cmd.ExecuteNonQuery();
                for (int i = 0; i < gvFlightLegs.Rows.Count; i++)
                {
                    GridViewRow gRow = gvFlightLegs.Rows[i];

                    //string Fltno = ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text;
                    string Origin = ((Label)gRow.FindControl("lblOrigin")).Text;
                    string Destination = ((Label)gRow.FindControl("lblDestination")).Text;
                    string ETA = ((TextBox)gRow.FindControl("txtETA")).Text.Substring(0, 2) + ":" +
                                 ((TextBox)gRow.FindControl("txtETA")).Text.Substring(2, 2);
                    string ETD = ((TextBox)gRow.FindControl("txtETD")).Text.Substring(0, 2) + ":" +
                                 ((TextBox)gRow.FindControl("txtETD")).Text.Substring(2, 2);

                    DateTime ValidFrom = DateTime.Parse(((TextBox)gRow.FindControl("txtFrom")).Text);
                    DateTime ValidTo = DateTime.Parse(((TextBox)gRow.FindControl("txtTo")).Text);
                    int AircraftType = int.Parse(((DropDownList)gRow.FindControl("ddlAircraftType")).SelectedValue);
                    decimal Allocation = decimal.Parse(((TextBox)gRow.FindControl("txtCapacity")).Text);

                    string DaysofOperation = "";
                    for (int c = 0; c < ((CheckBoxList)gRow.FindControl("chkDays")).Items.Count; c++)
                    {
                        if (((CheckBoxList)gRow.FindControl("chkDays")).Items[c].Selected)
                            if (DaysofOperation == "")
                                DaysofOperation = ((CheckBoxList)gRow.FindControl("chkDays")).Items[c].Value;
                            else
                                DaysofOperation = DaysofOperation + "," +
                                                  ((CheckBoxList)gRow.FindControl("chkDays")).Items[c].Value;
                    }
                    int FlightType = int.Parse(((DropDownList)gRow.FindControl("ddlFlightType")).SelectedValue);
                    int BoundStatus = int.Parse(((DropDownList)gRow.FindControl("ddlBoundStatus")).SelectedValue);
                    int DayDifference = int.Parse(((TextBox)gRow.FindControl("txtDayDifference")).Text);
                    string Active = ((TextBox)gRow.FindControl("txtActive")).Text;
                    int Stops = int.Parse(((TextBox)gRow.FindControl("txtStops")).Text);
                    int Pallets = int.Parse(((TextBox)gRow.FindControl("txtPallets")).Text);
                    decimal volume = decimal.Parse(((TextBox)gRow.FindControl("txtVolume")).Text);
                    string volumeUnit = ((DropDownList)gRow.FindControl("ddlCBM")).SelectedValue;
                    decimal PieceMaxVolume =
                        decimal.Parse(((TextBox)gRow.FindControl("txtMaxVol")).Text == ""
                                          ? "0"
                                          : ((TextBox)gRow.FindControl("txtMaxVol")).Text);
                    decimal PieceMaxGross =
                        decimal.Parse(((TextBox)gRow.FindControl("txtMaxGr")).Text == ""
                                          ? "0"
                                          : ((TextBox)gRow.FindControl("txtMaxGr")).Text);
                    SqlCommand cmd1 = new SqlCommand("alc_FlightTrans_Insert", con, tr);
                    cmd1.CommandType = CommandType.StoredProcedure;
                    cmd1.Parameters.AddWithValue("@_FlightNo", FlightNo);
                    cmd1.Parameters.AddWithValue("@_Origin", Origin);
                    cmd1.Parameters.AddWithValue("@_Destination", Destination);
                    cmd1.Parameters.AddWithValue("@_ETD", ETD);
                    cmd1.Parameters.AddWithValue("@_ETA", ETA);
                    cmd1.Parameters.AddWithValue("@_ValidFrom", ValidFrom);
                    cmd1.Parameters.AddWithValue("@_ValidTo", ValidTo);
                    cmd1.Parameters.AddWithValue("@_AircraftSNo", AircraftType);
                    cmd1.Parameters.AddWithValue("@_Allocation", Allocation);
                    cmd1.Parameters.AddWithValue("@_Days", DaysofOperation);
                    cmd1.Parameters.AddWithValue("@_FlightTypeSNo", FlightType);
                    cmd1.Parameters.AddWithValue("@_FlightBoundStatus", BoundStatus);
                    cmd1.Parameters.AddWithValue("@_DayDifference", DayDifference);
                    cmd1.Parameters.AddWithValue("@_Active", Active);
                    cmd1.Parameters.AddWithValue("@_EnteredBy", Session["emailid"]);
                    cmd1.Parameters.AddWithValue("@_Stops", Stops);
                    cmd1.Parameters.AddWithValue("@_Pallets", Pallets);
                    cmd1.Parameters.AddWithValue("@_VolumeUnit", volumeUnit);
                    cmd1.Parameters.AddWithValue("@_Volume", volume);
                    cmd1.Parameters.AddWithValue("@_PieceMaxVolume", PieceMaxVolume);
                    cmd1.Parameters.AddWithValue("@_PieceMaxGross", PieceMaxGross);
                    int ident = cmd1.ExecuteNonQuery();

  
                }
                tr.Commit();
                con.Close();
                showLabels("Flight Schedule updated sucessfully for Flight No " + FlightNo);
                lblUpdate.Text = "Flight Schedule updated sucessfully for Flight No " + FlightNo +
                                 ". Being redirected to Flight Schedule Details in few seconds";
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "key",
                                                        "<script language='javascript'>alert('Flight Schedule updated sucessfully for Flight No " +
                                                        FlightNo +
                                                        ". ');</script>", false);
                Response.Redirect("DisplayFlightSchedule.aspx");
            }
            catch (SqlException)
            {
                if (tr != null) tr.Rollback();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
        else
        {
            showLabels("Flight Schedule doesn't exists");
            return;
        }
    }



    public void DeleteSchedule(int sno,string addedby)
    {
            SqlConnection con = new SqlConnection(strCon);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Alc_FlightSchedule_Delete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@_SNo", sno);
                cmd.Parameters.AddWithValue("@_EnteredBy", addedby);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (SqlException ex)
            {
                string str = ex.ToString();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
    }
    protected void deleteScheduleBeforeUpdate()
    {
        Boolean flightExists = CheckFlightNo(ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text);

        if (flightExists)
        {
            hideLabels();
            SNo = int.Parse(Request.QueryString[0]);
            FlightNo = ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text;
            EnteredBy = Session["EmailId"].ToString();
            DeleteSchedule(SNo, EnteredBy);
        }
        else
        {
            showLabels("Flight Schedule doesn't exists");
            return;
        }
    }
    protected void deleteSchedule()
    {
        Boolean flightExists = CheckFlightNo(ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text);

        if (flightExists)
        {
            hideLabels();
            SNo = int.Parse(Request.QueryString[0]);
            FlightNo = ddlAirline.SelectedItem.Text + "-" + txtFlightNo.Text;
            EnteredBy = Session["emailid"].ToString();
            DeleteSchedule(SNo, EnteredBy);

            lblUpdate.Text = "Flight Schedule deleted sucessfully for Flight No " + FlightNo +
                             ". Being redirected to Flight Schedule Details in few seconds";
            Response.Redirect("DisplayFlightSchedule.aspx?ID=" + FlightNo + "&st=" + strmsg);
        }
        else
        {
            showLabels("Flight Schedule doesn't exists");
            return;
        }
    }

    protected void btnValidate_Click(object sender, EventArgs e)
    {
        checkSchedule();
    }

    protected void btnAddSchedule_Click(object sender, EventArgs e)
    {
        strmsg = "AF";
        addSchedule();
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        strmsg = "UF";
        deleteScheduleBeforeUpdate();
        addSchedule();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        strmsg = "DF";
        deleteSchedule();
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("DisplayFlightSchedule.aspx");
    }

    protected void gvFlightLegs_PreRender(object sender, EventArgs e)
    {
        ClientScriptManager cs = Page.ClientScript;
        foreach (GridViewRow grdrow in gvFlightLegs.Rows)
        {
            Label lblOrg = (Label) grdrow.FindControl("lblOrigin");
            TextBox txtEtd = (TextBox) grdrow.FindControl("txtetd");
            Label lblDest = (Label) grdrow.FindControl("lblDestination");
            TextBox txtEta = (TextBox) grdrow.FindControl("txteta");
            TextBox txtVol = (TextBox) grdrow.FindControl("txtVolume");
            TextBox txtCbm = (TextBox) grdrow.FindControl("txtCBM");
            TextBox txtMaxVol = (TextBox) grdrow.FindControl("txtMaxVol");
            TextBox txtMaxCbm = (TextBox) grdrow.FindControl("txtMaxCBM");
            DropDownList ddlCbm = (DropDownList) grdrow.FindControl("ddlCBM");

            cs.RegisterArrayDeclaration("grd_Org", String.Concat("'", lblOrg.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_Etd", String.Concat("'", txtEtd.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_Dest", String.Concat("'", lblDest.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_Eta", String.Concat("'", txtEta.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_Vol", String.Concat("'", txtVol.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_CBM", String.Concat("'", txtCbm.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_MaxVol", String.Concat("'", txtMaxVol.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_MaxCBM", String.Concat("'", txtMaxCbm.ClientID, "'"));
            cs.RegisterArrayDeclaration("grd_ddlCBM", String.Concat("'", ddlCbm.ClientID, "'"));
        }
    }

    protected void gvFlightLegs_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onclick", "onGridViewRowSelected('" + m_iRowIdx + "')");
        }
        m_iRowIdx++;
    }
}