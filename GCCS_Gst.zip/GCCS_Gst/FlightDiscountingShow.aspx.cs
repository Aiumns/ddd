using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
// Hirdayanand Mishra 23.04.2009

public partial class FlightDiscountingShow : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    SqlCommand com;
    SqlDataReader red;
    SqlParameter pram;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    DisplayWrap dw = new DisplayWrap();
    string table1 = "";
    public string MainTab = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                lblmsg.Text = "";
                if (Request.QueryString.Count > 0)
                {
                    if (Session["msg"] != null)
                    {
                        lblmsg.Text = Session["msg"].ToString();
                        Session["msg"] = null;
                    }
                    else
                        lblmsg.Text = "";

                }
                  
                ShowAirline();
            }

        }

    }

    public void ShowAirline()
    {        
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in(select distinct Airline_Detail_ID from Gd_Dest_Master) order by Airline_Name", con);
        con.Open();
        red = cmd.ExecuteReader();
        while (red.Read())
        {
            string table = "";    
            SqlConnection con1 = new SqlConnection(strCon);
            SqlCommand cmdSlab = new SqlCommand("select s.slab_name,s.slab_id from slab_master s inner join airline_slab a on a.slab_id=s.slab_id where a.airline_detail_id='" + red["Airline_Detail_ID"].ToString() + "' order by s.slab_id", con1);
            con1.Open();
            SqlDataReader dr = cmdSlab.ExecuteReader();
            int i = 7;
            string slabHead = @"<td class=boldtext>Edit</td> <td class=boldtext>Del</td><td class=boldtext>FlightNo</td><td class=boldtext>Shipment</td>";
            while (dr.Read())
            {
                slabHead += @"<td class=boldtext> " + dr["slab_name"].ToString() + @"</td>";
                i++;
            }
            table += @"<table width=100%><tr> <td class=""h1"" align=center colspan=" + i + @">" + red["Airline"].ToString().ToUpper() + @"</td></tr><tr class=h5>" + slabHead + @"<td class=boldtext>Destinations</td><td class=boldtext> ValidFrom</td><td class=boldtext> validTo</td></tr>";
            dr.Dispose();
            cmdSlab.Dispose();
            cmdSlab = new SqlCommand("select distinct Shipment_Name,FD.Shipment_ID,Destination,valid_From ,Valid_to,convert(varchar,valid_From,103)validFrom1, convert(varchar,Valid_to,103)Validto1 from Gd_Dest_Master FD INNER JOIN db_owner.GD_Rate_Master GDR ON gdr.GD_Rate_ID=fd.gd_rate_id  inner join shipment_master sp on sp.Shipment_ID=FD.Shipment_ID where AirLine_Detail_ID='" + red["Airline_Detail_ID"].ToString() + "'", con1);
            dr = cmdSlab.ExecuteReader();
            while (dr.Read())
            {

                DataTable dt1 = dw.GetAllFromQuery("select gdm.Destination,Slab_name as SlabName,Price_value as Price from GD_Rate_master inner join slab_master on GD_Rate_master.Slab_ID=slab_master.Slab_ID INNER JOIN db_owner.GD_Dest_Master gdm ON gdm.GD_Rate_ID=GD_Rate_master.GD_Rate_ID where gdm.Airline_Detail_id=151");

                table1 = table1 + @"<table><tr>";

                for (int k = 0; k < dt1.Rows.Count; k++)
                {
                    DataRow[] drSlab = dt1.Select("Destination='" + dt1.Rows[k]["Destination"].ToString() + "'");
                    DataTable dtSlab = drSlab.CopyToDataTable();
                    for (int j = 0; j < dtSlab.Rows.Count; j++)
                    {
                        table1 = table1 + @"<tr><td class=boldtext  align=center colspan=2 >" + dt1.Rows[i]["Sno"].ToString() + @" </td><td class=boldtext >" + dt1.Rows[i]["Value Date"].ToString() + @"</td><td class=boldtext nowrap >" + dt1.Rows[i]["Start Date"].ToString() + @"</td><td  class=boldtext nowrap>" + dt1.Rows[i]["End Date"].ToString() + @"</td><td  class=boldtext nowrap>" + dt1.Rows[i]["cpp"].ToString() + @"</td><td  class=boldtext nowrap>" + dt1.Rows[i]["Reedeem CPP"].ToString() + @"</td><td  class=boldtext nowrap>" + dt1.Rows[i]["Available CPP"].ToString() + @"</td><td width=30% class=boldtext >" + dt1.Rows[i]["Redeemed ID"].ToString() + @"</td><td class=boldtext nowrap>" + dt1.Rows[i]["Expiry Date"].ToString() + @"</td></tr>";

                    }

                }
                //lblBindTable.Text = table1 + "<table>";

                //end read slab id and fetch discounted value..
               // SqlCommand cmd2 = new SqlCommand("select slab_ID,PreFix_ID,Discounted_Value from FlightDiscounting where airlineDetail_ID='" + red["Airline_Detail_ID"].ToString() + "' and flight_ID='" + (dr["flight_ID"].ToString() == null ? "0" : dr["flight_ID"].ToString()) + "' and Shipment_ID='" + dr["Shipment_ID"].ToString() + "' and Destination_Codes='" + dr["Destination_Codes"].ToString() + "' and validFrom='" + DateTime.Parse(dr["validFrom"].ToString()) + "' and Validto='" + DateTime.Parse(dr["Validto"].ToString()) + "' order by slab_ID", con2);              
               // SqlDataReader dr2 = cmd2.ExecuteReader();                
                ////while (dr2.Read())
                ////{
                ////    table += @"<td class=text>" + dr2["Discounted_Value"].ToString() + @"</td>";
                    
                ////}
               // dr2.Dispose();
               // cmd2.Dispose();
              //  con2.Close();
                table += @"<td>" + dr["Destination_Codes"].ToString() + @"</td><td>" + dr["validFrom1"].ToString() + @"</td> <td>" + dr["validto1"].ToString() + @"</td></tr>";


            }
            dr.Dispose();
            cmdSlab.Dispose();
            MainTab += table;
        }
        red.Dispose();
        cmd.Dispose();
        con.Close();
        Label1.Text = MainTab;
       
    }
}
