using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class add_exchange_rate : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr=null;
    SqlTransaction tr = null;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            btnAdd.Visible = true;
            if (!IsPostBack)
            {
                btnAdd.Attributes.Add("onclick", "return  CompareDt() ");
                ShowData();               
                btnCancel.Visible = false;
                btnUpdate.Visible = false;                     


            }
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            InsertData();
        }
    }
    protected void InsertData()
    {
        DateTime fromDt = DateTime.Parse(ConvertDate1(txtFromDt.Text));
        DateTime toDt = DateTime.Parse(ConvertDate1(txtToDt.Text));
        con = new SqlConnection(strCon);
        con.Open();
        bool flag = false;
        try
        {
            while (fromDt <= toDt)
            {
                com = new SqlCommand("select Exchange_Rate_ID,From_Date,To_Date Exchange_Rate from exchange_rate where '" + fromDt + "' between From_Date and To_Date", con);
                dr = com.ExecuteReader();
                if (dr.Read())
                {
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                    lblMsg.Text = "$ Exchange Rate already exist.";
                    flag = true;
                    break;
                }
                fromDt = fromDt.AddDays(1);
                com.Dispose();
                dr.Dispose();
            }
            com.Dispose();
            dr.Dispose();

            if (flag==false)
            {
               fromDt = DateTime.Parse(ConvertDate1(txtFromDt.Text));
               toDt = DateTime.Parse(ConvertDate1(txtToDt.Text));

               com = new SqlCommand("insert into exchange_rate(From_Date,To_Date,Exchange_Rate,Entered_By,Entered_On) values(@From_Date,@To_Date,@Exchange_Rate,@Entered_By,@Entered_On)  ", con);
           
                com.Parameters.Add("@From_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(fromDt);
                com.Parameters.Add("@To_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(toDt);
                com.Parameters.Add("@Exchange_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtExchangeRate.Text);
                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EmailID"].ToString();
                com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                com.ExecuteNonQuery();
                com.Dispose();
                con.Close();
                lblMsg.ForeColor = System.Drawing.Color.Blue;
                lblMsg.Text = "$ Exchange Rate Successfully added.";
                ShowData();
            }
           

         }
      
        catch (SqlException se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
 
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    protected void ShowData()
    {
        con = new SqlConnection(strCon);
        con.Open();        
        try
        {
            SqlDataAdapter sda = new SqlDataAdapter("select Exchange_Rate_ID,convert(varchar,From_Date,103) as From_Date ,convert(varchar,To_Date,103) as To_Date,Exchange_Rate from exchange_rate", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            gvExchangeRate.DataSource = dt;
            gvExchangeRate.DataBind();           
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        UpdatePanel1.Update();
        uptdate.Update();
        uptgrid.Update();
        
    }
    protected void btnDelete_ExchaneRate(object sender, EventArgs e)
    {
        
        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblID = (Label)grdRow.FindControl("lblID");
        
        try
        {
            SqlConnection con1 = new SqlConnection(strCon);
            con1.Open();
           
         SqlCommand   com1 = new SqlCommand("select Exchange_Rate_ID,From_Date,To_Date, Exchange_Rate from exchange_rate where Exchange_Rate_ID=" + lblID.Text.Trim() + " ", con1);
            dr = com1.ExecuteReader();
            if (dr.Read())
            {
                con = new SqlConnection(strCon);
                con.Open();
                tr = con.BeginTransaction();

                com = new SqlCommand("insert into Exchange_Rate_History(Exchange_Rate_ID,From_Date,To_Date,Exchange_Rate,Entered_By,Entered_On) values(@Exchange_Rate_ID,@From_Date,@To_Date,@Exchange_Rate,@Entered_By,@Entered_On)  ", con, tr);

                com.Parameters.Add("@Exchange_Rate_ID", SqlDbType.Int).Value = int.Parse(dr["Exchange_Rate_ID"].ToString());

                com.Parameters.Add("@From_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(dr["From_Date"].ToString());

                com.Parameters.Add("@To_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(dr["To_Date"].ToString());

                com.Parameters.Add("@Exchange_Rate", SqlDbType.Decimal).Value = decimal.Parse(dr["Exchange_Rate"].ToString());

                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EmailID"].ToString();

                com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                com.ExecuteNonQuery();

                com.Dispose();

                com = new SqlCommand("delete from exchange_rate where Exchange_Rate_ID=" + lblID.Text.Trim() + " ", con, tr);
                com.ExecuteNonQuery();
                tr.Commit();
                con.Close();
            }
            con1.Close();
           
            ShowData();
       
        }
        catch (SqlException se)
        {
            string err = se.Message;
            tr.Rollback();
            Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            tr.Rollback();
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }        

    }
    protected void OnClick_btnModify(object sender, EventArgs e)
    {
        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblID = (Label)grdRow.FindControl("lblID");
        con = new SqlConnection(strCon);
        con.Open();
        try
        {
            com = new SqlCommand("select Exchange_Rate_ID,convert(varchar,From_Date,103) as FromDate ,convert(varchar,To_Date,103) as ToDate,Exchange_Rate,From_Date,To_Date from exchange_rate where Exchange_Rate_ID=" + lblID.Text.Trim() + " ", con);
            dr = com.ExecuteReader();
            if (dr.Read())
            {
                txtFromDt.Text = dr["FromDate"].ToString();
                txtToDt.Text = dr["ToDate"].ToString();
                txtExchangeRate.Text = dr["Exchange_Rate"].ToString();
                //UpdateID = int.Parse(dr["Exchange_Rate_ID"].ToString());
                HiddenField1.Value=dr["Exchange_Rate_ID"].ToString();
                hdnFDt.Value=dr["From_Date"].ToString();
                hdnTDt.Value=dr["To_Date"].ToString();
                hdnValue.Value = dr["Exchange_Rate"].ToString();

            }           
            con.Close();
            Button btn = (Button)grdRow.FindControl("btnModify");            
           // ShowData();
            gvExchangeRate.Columns[4].Visible = false;
            gvExchangeRate.Columns[5].Visible = false;
            btnAdd.Visible = false;           
            btnUpdate.Visible = true;
            btnCancel.Visible = true;
           // UpdatePanel1.Update();
           

        }
        catch (SqlException se)
        {
            string err = se.Message;
            Response.Write(err);
        }
        catch (Exception be)
        {
            string err = be.Message;
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }


        UpdatePanel1.Update();
        uptdate.Update();
        uptgrid.Update();
        

    }

    protected void gvExchangeRate_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button db = (Button)e.Row.Cells[5].FindControl("btnDelete");
            //db.OnClientClick = "return confirm('Delete Record?');";
            //db.Attributes.Add = "javascript: return confirm('Are you certain you want to delete ?');";
           db.OnClientClick = string.Format("javascript: return confirm('Are you certain, you want to delete ?');");
        }

    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("add_exchange_rate.aspx");
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            DateTime fromDt1 = DateTime.Parse(ConvertDate1(txtFromDt.Text));
            DateTime toDt2 = DateTime.Parse(ConvertDate1(txtToDt.Text));
            con = new SqlConnection(strCon);
            con.Open();
            try
            {
                tr = con.BeginTransaction();

                com = new SqlCommand("insert into Exchange_Rate_History(Exchange_Rate_ID,From_Date,To_Date,Exchange_Rate,Entered_By,Entered_On) values(@Exchange_Rate_ID,@From_Date,@To_Date,@Exchange_Rate,@Entered_By,@Entered_On)  ", con, tr);

                com.Parameters.Add("@Exchange_Rate_ID", SqlDbType.Int).Value = int.Parse(HiddenField1.Value);

                com.Parameters.Add("@From_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(hdnFDt.Value);

                com.Parameters.Add("@To_Date", SqlDbType.DateTime).Value = Convert.ToDateTime(hdnTDt.Value);


                com.Parameters.Add("@Exchange_Rate", SqlDbType.Decimal).Value = decimal.Parse(hdnValue.Value);


                com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EmailID"].ToString();

                com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
                com.ExecuteNonQuery();
                com.Dispose();


                com = new SqlCommand("update exchange_rate set From_Date='" + fromDt1 + "',To_Date='" + toDt2 + "',Exchange_Rate=" + txtExchangeRate.Text.Trim() + " where Exchange_Rate_ID=" + HiddenField1.Value + " ", con, tr);
                com.ExecuteNonQuery();
                tr.Commit();
                con.Close();

                //Server.Transfer("add_exchange_rate.aspx");
            }
            catch (SqlException se)
            {
                string err = se.Message;
                tr.Rollback();
                Response.Write(err);
            }
            catch (Exception be)
            {
                string err = be.Message;
                tr.Rollback();
                Response.Write(err);
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
            Response.Redirect("add_exchange_rate.aspx");
        }

    }
    protected void gvExchangeRate_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvExchangeRate.PageIndex = e.NewPageIndex;
        ShowData();
        uptdate.Update();
        uptgrid.Update();


    }
}
