﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class CppBreakupReport_CSr : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    string Agent_Id = "";
    string City_ID = "";
    string Agent_Name = "";
    string City_Name = "";
    string SubAgent_ID = "";
    string table;
    DataTable dtM;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        btnSearch.Attributes.Add("onclick", "return CheckEmpty()");
        if (!IsPostBack)
        {

            Panel1.Visible = true;
            LoadOrigin();
            LoadCompany();

        }

    }
    public void LoadCompany()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("Company_Getlist_Cpp", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();

            //com = new SqlCommand("select City_ID,City_Code,City_name from City_Master where city_ID in(SELECT DISTINCT CITYID FROM CPP_AgentwiseTotal )", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlcompany.Items.Clear();
            ddlcompany.Items.Insert(0, "- -Select- -");
            ddlcompany.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlcompany.Items.Add(new ListItem(dr["Company_Name"].ToString(), dr["Company_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadAgentName()
    {
        try
        {
            //string strAgent = "select AM.Agent_ID,AM.Agent_Name from Agent_Master AM INNER JOIN AGENT_BRANCH AB ON AB.AGENT_ID=AM.AGENT_ID where AB.BELONGS_TO_CITY=" + ddlOrigin.SelectedItem.Value + "  order by AM.Agent_Name asc";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("CppAgent_GetList", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@City_Id", SqlDbType.Int).Value = Convert.ToInt32(ddlOrigin.SelectedItem.Value);
            SqlDataReader dr = com.ExecuteReader();
            ddlAgentName.Items.Clear();
            ddlAgentName.Items.Insert(0, "- -Select- -");
            ddlAgentName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAgentName.Items.Add(new ListItem(dr["Agent_Name"].ToString(), dr["Agent_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void rblType_SelectedIndexChanged(object sender, EventArgs e)
    {

        
        btnSearch.Visible = true;
        // btnTransaction.Visible = true;
        if (rblType.SelectedValue == "0")
        {
            tragent.Visible = true;
            trSubagent.Visible = false;

        }
        else
        {
            tragent.Visible = false;
            trSubagent.Visible = true;
        }

    }
    public void hideCppDetails()
    {

       


    }
    public void LoadSubAgentName()
    {
        try
        {
            //string strAgent = "select AM.Agent_ID,AM.Agent_Name from Agent_Master AM INNER JOIN AGENT_BRANCH AB ON AB.AGENT_ID=AM.AGENT_ID where AB.BELONGS_TO_CITY=" + ddlOrigin.SelectedItem.Value + "  order by AM.Agent_Name asc";
            con = new SqlConnection(strCon);
            con.Open();
            //  com = new SqlCommand("CppSubAgent_GetList", con);
            com = new SqlCommand("CppSubAgent_GetList_City", con);
            com.CommandType = CommandType.StoredProcedure;
            //com.Parameters.Add("@Agent_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlAgentName.SelectedItem.Value);
            com.Parameters.Add("@City_ID", SqlDbType.Int).Value = Convert.ToInt32(ddlOrigin.SelectedItem.Value);
            com.Parameters.Add("@Company_Id", SqlDbType.Int).Value = Convert.ToInt32(ddlcompany.SelectedItem.Value);
            SqlDataReader dr = com.ExecuteReader();
            ddlsubagent.Items.Clear();
            ddlsubagent.Items.Insert(0, "- -Select- -");
            ddlsubagent.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlsubagent.Items.Add(new ListItem(dr["SubAgentName"].ToString(), dr["SubAgentID"].ToString()));

            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnSearch_Click1(object sender, EventArgs e)
    {
        if(rblType.SelectedValue=="0")
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( 'CPP_Breakup_Report.aspx?Company_id=" + ddlcompany.SelectedValue + "&StartDate=" + txtFromDate.Text + "&EndDate=" + txtToDate.Text + "&City_ID=" + ddlOrigin.SelectedValue + "&AgentID=" + ddlAgentName.SelectedValue + "&SubAgentID=0');</script>"); 
        else
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( 'CPP_Breakup_Report.aspx?Company_id=" + ddlcompany.SelectedValue + "&StartDate=" + txtFromDate.Text + "&EndDate=" + txtToDate.Text + "&City_ID=" + ddlOrigin.SelectedValue + "&AgentID=0&SubAgentID=" + ddlsubagent.SelectedValue + "');</script>"); 

    }

    protected void ddlOrigin_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadAgentName();
        LoadSubAgentName();
        hideCppDetails();
    }

    public void LoadOrigin()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("Get_Origin_Voucher", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Email_ID", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
            //com = new SqlCommand("select City_ID,City_Code,City_name from City_Master where city_ID in(SELECT DISTINCT CITYID FROM CPP_AgentwiseTotal )", con);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Clear();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
}
