using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Delete_Stock : System.Web.UI.Page
{

    #region variable declaration

    string Agentid;
    string iss;
    string isss;
    string airwaybillno;
    string Status;
    string agentname;
    string ff;
    string cc;
    string dd;
    string cityid;
    string cityname;
    string[] airlinecode;
    int z;
    string recieptdate;
    string updateairlineaccess;
    string Airlineaccess;
    string Receiptlotno;

    string s;
    bool airlinea = false;

    string createdby;
    string createdon;
    SqlTransaction trans;
    string issueawb;
    //string ddlcityvalue = null;
    //string ddlcitytext = null;
    string strquery;
    SqlCommand cmd;
    bool citycheck = false;
    SqlDataReader rdr;
    SqlConnection con;
    SqlDataAdapter sda;
    string acid;
    string agcid;
    string ccid;
    string[] strCityAirline = null;
    string[] strCityAgent = null;
    string[] strAirlineAccesss = null;


    int ss;
    bool AWB = false;

    #endregion

    #region Created by Mukul Chandra
    /// <summary>
    /// <class>Delete Stock</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Mukul Chandra</createdBy>
    /// <createdOn>25 jan 08</createdOn>
    /// <modifications>
    /// 
    /// <modification>
    /// <changeDescription></changeDescription>
    /// <modifiedBy></modifiedBy>
    /// <modifiedOn></modifiedOn>
    /// <modifiedby></modifiedby>
    /// <modifiedOn></modifiedOn>
    /// <changeDescription></changeDescription>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    ///
    #endregion
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;//Getting Connection String For Web.config File.

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            


            if (!IsPostBack)
            {
                txt_Date.Text = DateTime.Now.ToString("dd/MM/yyyy");//On Load Assign Present Date To Date TextBox

                ddlfillairlinecode();//function for bind airline code
               

            }
        }
    }
    public void bindg()
    {
        try
        {
            citymatter();

            if (!(txtAWB.Text == "") && !(txtAWBN.Text == ""))
            {
                using (con)
                {

                    if (IsValid)
                    {
                        string airlinetext = ddlAirlinecode.SelectedItem.Text.ToString();
                        string[] airlinecode = airlinetext.Split('-');



                        ArrayList ar = new ArrayList();//Creating Array For Store AWB No During Generation
                        ArrayList ar1 = new ArrayList();

                        double val = Convert.ToDouble(txtAWB.Text);//Getting AWB No Lot
                        //Loop For Generation Of AWBNo.
                        for (int i = 1; i <= int.Parse(txtAWBN.Text); i++)
                        {
                            if (i == 1)//Check for How Many No awb Have.
                            {
                                string strI = val.ToString() + Convert.ToString(val % 7);
                                int l = strI.Length;
                                if (l == 1)
                                    strI = "0000000" + strI;
                                else if (l == 2)
                                    strI = "000000" + strI;
                                else if (l == 3)
                                    strI = "00000" + strI;
                                else if (l == 4)
                                    strI = "0000" + strI;
                                else if (l == 5)
                                    strI = "000" + strI;
                                else if (l == 6)
                                    strI = "00" + strI;
                                else if (l == 7)
                                    strI = "0" + strI;

                                ar.Add(airlinecode[0] + "-" + strI);//Adding Value To the Array


                            }

                            else
                            {
                                val = val + 1;
                                double val2 = val % 7; //Math.IEEERemainder(val, 7);
                                string strI = val.ToString() + Math.Abs(val2);
                                int l = strI.Length;
                                if (l == 1)
                                    strI = "0000000" + strI;
                                else if (l == 2)
                                    strI = "000000" + strI;
                                else if (l == 3)
                                    strI = "00000" + strI;
                                else if (l == 4)
                                    strI = "0000" + strI;
                                else if (l == 5)
                                    strI = "000" + strI;
                                else if (l == 6)
                                    strI = "00" + strI;
                                else if (l == 7)
                                    strI = "0" + strI;

                                ar.Add(airlinecode[0] + "-" + strI);//Adding Value To The Array


                            }

                        }


                        con = new SqlConnection(strCon);//intialise connection  
                        con.Open();//connection open   
                        string a = cityid;
                        try
                        {
                            lblMsgR.Text = null;
                            foreach (string c in ar)
                            {
                                string finall = "'" + c + "',";
                                ff = ff + finall;
                                dd = ff.Remove(ff.LastIndexOf(','));
                            }

                            //cc = "'" + c + "'";
                            strquery = "select  sm.AirWayBill_No,sm.stock_id,stm.status_name from stock_master as sm inner join status_master as stm on sm.status=stm.status_id where AirWayBill_No in (" + dd + ") ";
                            rdr.Close();
                            cmd = new SqlCommand(strquery, con);// pass argument in command  

                            rdr = cmd.ExecuteReader();
                            lstAWB.Visible = true;
                            lstAWB.DataSource = rdr;
                            lstAWB.DataBind();

                        }
                        catch (SqlException ee)
                        {
                            //Response.Write("sql error" + ee.Message);
                        }
                    }
                }
            }

        }
        catch (Exception ee)
        {
            ee.ToString();

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    
    }
    #region to bind airlinecode in dropdown list
    protected void ddlfillairlinecode()
    {
        using (con)
        {
            con = new SqlConnection(strCon);//intialise connection  
            con.Open();//connection open    
            try
            {
                strquery = " select Airline_Access from dbo.Login_Master where Email_ID='" + Session["EMailID"] + "'";//query for getting airline access from login master on the basis of email 
                cmd = new SqlCommand(strquery, con);// pass argument in command  
                rdr = cmd.ExecuteReader();
                rdr.Read();
                string airline_access = rdr["Airline_Access"].ToString();//getting value in string airline_access
                rdr.Close();
                //string[] split_ac = airline_access.Split(',');//getting value in string arrey with split 
                ddlAirlinecode.Items.Insert(0, "--Select--");// add --select--on 0 index
                ddlAirlinecode.Items[0].Value = "0";

                strquery = "select  am.Airline_Code,am.airline_name,cm.City_Code,ad.Airline_Detail_ID from dbo.Airline_Master as am inner join airline_detail as ad on ad.airline_id=am.airline_id inner join city_master as cm on cm.city_id=ad.Belongs_To_City where ad.Airline_Detail_ID in (" + airline_access + ")  and am.status='2' order by am.Airline_Code asc";

                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                    ddlAirlinecode.Items.Add(new ListItem(rdr["airline_code"].ToString() + '-' + rdr["Airline_name"].ToString() + ',' + rdr["City_Code"].ToString(), rdr["Airline_Detail_ID"].ToString()));
                rdr.Close();

            }
            catch (SqlException ee)
            {
                Response.Write("sql error" + ee.Message);
            }
        }
    }
    #endregion
   


    #region task done on selected index changed of ddlagent so that city bound on the basis of both airline code and agent name(regarding cityid)
    protected void ddlagentindexchanged(object sender, EventArgs e)
    {
       
    }
    #endregion
    #region function to fetch lot issue_lotno
    int lotNoCheck()
    {
        int lot = 0;//used for return integer value.
        con = new SqlConnection(strCon);//Making Connection
        cmd = new SqlCommand("Select Max(Issue_LotNo) From Stock_Master", con);//Giving Connection String.
        using (con)
        {
            try
            {
                con.Open();//Open Connection
                if (Convert.IsDBNull(cmd.ExecuteScalar()))//Check For Receipt_LotNo Present or not
                    lot = 0;//If Not having any Receipt_LotNo id then return 0.
                else
                {
                    int i = Convert.ToInt16(cmd.ExecuteScalar());//Getting Receipt_LotNo
                    lot = i;//Make it return
                }
            }
            catch (SqlException sqlex)
            {
                string err = sqlex.ToString();
                Response.Write(err);
            }
            return lot;//Returning Receipt_LotNo to calling Statement
        }
    }
    #endregion
    
    

    #region on click event of btnissue

    protected void btnissue_Click(object sender, EventArgs e)
    {
        //rdr.Close();
        con = new SqlConnection(strCon);
        con.Open();
        //rdr.Close();
        //cmd.Dispose();
        for (int index = 0; index <= lstAWB.Rows.Count - 1; index++)
        {
            CheckBox chk = (CheckBox)lstAWB.Rows[index].FindControl("deleteRec");
            if (chk.Checked)
            {
                citymatter();
                con = new SqlConnection(strCon);
                con.Open();
                int i = int.Parse(lstAWB.DataKeys[index].Value.ToString());
                strquery = "select * from dbo.Stock_Master where stock_id=" + i + "";
                cmd = new SqlCommand(strquery, con, trans);
                SqlDataReader rdr1 = cmd.ExecuteReader();
                 //rdr = cmd.ExecuteReader();

                rdr1.Read();
                recieptdate = rdr1["Receipt_Date"].ToString();
                Receiptlotno = rdr1["Receipt_LotNo"].ToString();
                createdby = rdr1["Created_By"].ToString();
                createdon = rdr1["Created_On"].ToString();

                Status = rdr1["Status"].ToString();
                airwaybillno = rdr1["AirWayBill_No"].ToString();

                rdr1.Close();
                strquery = "insert into db_owner.Stock_History(AirWayBill_No,City_Name,Receipt_Date,Receipt_LotNo,Created_By,Created_On,Status,Deleted_by,Deleted_on)values(@AirWayBill_No,@City_Name,@Receipt_Date,@Receipt_LotNo,@Created_By,@Created_On,@Status,@Deleted_by,@Deleted_on) ";
                cmd = new SqlCommand(strquery, con, trans);
                cmd.Parameters.AddWithValue("@AirWayBill_No", airwaybillno);
                cmd.Parameters.AddWithValue("@City_Name", cityname);
                cmd.Parameters.AddWithValue("@Receipt_Date", recieptdate);
                cmd.Parameters.AddWithValue("@Receipt_LotNo", Receiptlotno);
                cmd.Parameters.AddWithValue("@Created_By", createdby);
                cmd.Parameters.AddWithValue("@Created_On", createdon);
               
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@Deleted_by", Session["EMailID"]);
                cmd.Parameters.AddWithValue("@Deleted_on", ConvertDate(txt_Date.Text));
                cmd.ExecuteNonQuery();

                string deletesql = "delete from stock_master where stock_id=@stock_id";
                SqlCommand cm = new SqlCommand(deletesql, con);
                cm.Parameters.Add("@stock_id", i);
                cm.ExecuteNonQuery();
                //bindgrid();
               

            }

        }
        bindg();

        
        //bindgrid();
        
        con.Close();


    
    }
    #endregion
    #region function for convert date whatever taken in txt_date into true format
    string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    #endregion

  

 
    protected void Button3_Click(object sender, EventArgs e)
    
    {
        try
        {
            citymatter();

            if (!(txtAWB.Text == "") && !(txtAWBN.Text == ""))
            {
                using (con)
                {

                    if (IsValid)
                    {
                        string airlinetext = ddlAirlinecode.SelectedItem.Text.ToString();
                        string[] airlinecode = airlinetext.Split('-');



                        ArrayList ar = new ArrayList();//Creating Array For Store AWB No During Generation
                        ArrayList ar1 = new ArrayList();

                        double val = Convert.ToDouble(txtAWB.Text);//Getting AWB No Lot
                        //Loop For Generation Of AWBNo.
                        for (int i = 1; i <= int.Parse(txtAWBN.Text); i++)
                        {
                            if (i == 1)//Check for How Many No awb Have.
                            {
                                string strI = val.ToString() + Convert.ToString(val % 7);
                                int l = strI.Length;
                                if (l == 1)
                                    strI = "0000000" + strI;
                                else if (l == 2)
                                    strI = "000000" + strI;
                                else if (l == 3)
                                    strI = "00000" + strI;
                                else if (l == 4)
                                    strI = "0000" + strI;
                                else if (l == 5)
                                    strI = "000" + strI;
                                else if (l == 6)
                                    strI = "00" + strI;
                                else if (l == 7)
                                    strI = "0" + strI;

                                ar.Add(airlinecode[0] + "-" + strI);//Adding Value To the Array


                            }

                            else
                            {
                                val = val + 1;
                                double val2 = val % 7; //Math.IEEERemainder(val, 7);
                                string strI = val.ToString() + Math.Abs(val2);
                                int l = strI.Length;
                                if (l == 1)
                                    strI = "0000000" + strI;
                                else if (l == 2)
                                    strI = "000000" + strI;
                                else if (l == 3)
                                    strI = "00000" + strI;
                                else if (l == 4)
                                    strI = "0000" + strI;
                                else if (l == 5)
                                    strI = "000" + strI;
                                else if (l == 6)
                                    strI = "00" + strI;
                                else if (l == 7)
                                    strI = "0" + strI;

                                ar.Add(airlinecode[0] + "-" + strI);//Adding Value To The Array


                            }

                        }


                        con = new SqlConnection(strCon);//intialise connection  
                        con.Open();//connection open   
                        string a = cityid;
                        try
                        {
                            lblMsgR.Text = null;
                            foreach (string c in ar)
                            {
                                string finall = "'" + c + "',";
                                ff = ff + finall;
                                dd = ff.Remove(ff.LastIndexOf(','));
                            }

                                //cc = "'" + c + "'";
                            strquery = "select  sm.AirWayBill_No,sm.stock_id,stm.status_name from stock_master as sm inner join status_master as stm on sm.status=stm.status_id where AirWayBill_No in (" + dd + ") ";
                                rdr.Close();
                                cmd = new SqlCommand(strquery, con);// pass argument in command  

                                rdr = cmd.ExecuteReader();
                                lstAWB.Visible = true;
                                lstAWB.DataSource = rdr;
                                lstAWB.DataBind();
                            
                        }
                        catch (SqlException ee)
                        {
                            //Response.Write("sql error" + ee.Message);
                        }
                    }
                }
            }

        }
        catch (Exception ee)
        {
            ee.ToString();

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
   
    protected void  airlindecodesindexchanged(object sender, EventArgs e)
{
        
        //topawbno();
}
      public void bindgrid()
    {

        using (con)
        {
            try
            {

                con = new SqlConnection(strCon);//intialise connection  
                con.Open();//connection open    


                string airlinetext = ddlAirlinecode.SelectedItem.Text.ToString();
                string[] citycode = airlinetext.Split(',');
                string[] airlinecode = citycode[0].Split('-');
                strquery = "select city_id, city_name from city_master where city_code='" + citycode[1] + "'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    cityid = rdr["city_id"].ToString();
                    cityname = rdr["city_name"].ToString();
                }
                rdr.Dispose();
                //con.Close();

                strquery = " select top 10 AirWayBill_No,stock_id from stock_master where City_ID='" + cityid + "' and AirWayBill_No like '" + airlinecode[0] + "%' ";//query for getting airline access from login master on the basis of email 
                cmd = new SqlCommand(strquery, con);// pass argument in command                  
                rdr = cmd.ExecuteReader();
                //lstAWB.Dispose();
                lstAWB.DataSource = rdr;
                lstAWB.DataBind();
            }
            catch (Exception ee)
            {
                ee.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            }
    }

}
    public void citymatter()
    {
        using (con)
        {
            try
            {
                con = new SqlConnection(strCon);//intialise connection  
                con.Open();//connection open    

                string airlinetext = ddlAirlinecode.SelectedItem.ToString();
                string[] citycode = airlinetext.Split(',');
                airlinecode = airlinetext.Split('-');
                strquery = "select city_id, city_name from city_master where city_code='" + citycode[1] + "'";
                cmd = new SqlCommand(strquery, con);
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    cityid = rdr["city_id"].ToString();
                    cityname = rdr["city_name"].ToString();
                }
                rdr.Close();
                con.Close();
            }
            catch (Exception ee)
            {
                ee.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();

            }


        }
    }

    protected void ddlAirlincode_PreRender(object sender, EventArgs e)
    {

    }


    protected void arlindecodesindexchanged(object sender, EventArgs e)
    {

    }
    protected void ddlAirlinecode_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblMsgR.Text = null;
        lstAWB.Visible = false;
        txtAWB.Text = null;
        txtAWBN.Text = null;
    }

    protected void lstAWB_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
           
            Label status = (Label)e.Row.Cells[2].FindControl("Label1");
            Label lblairwaybill =(Label) e.Row.Cells[1].FindControl("Label2");
            string status_active = status.Text;
            string airwaybill = lblairwaybill.Text;

           
                DataTable dtstatus = dw.GetAllFromQuery("select status from stock_master where airwaybill_no='" + airwaybill + "'");
                if (dtstatus.Rows.Count > 0)
                {
                    for (int i = 0; i < dtstatus.Rows.Count; i++)
                    {
                        string truestatus = dtstatus.Rows[i]["status"].ToString();

                        //e.Row.CssClass = "text";
                        
                        if (truestatus == "8")
                        {
                            e.Row.Cells[3].Text = null;
                            
                        }
                        if (truestatus == "17")
                        {
                            e.Row.Cells[3].Text = null;
                        }
                        if (truestatus == "16")
                        {
                            e.Row.Cells[0].Text = null;
                            e.Row.ForeColor = System.Drawing.Color.Red;
                        }
                        if (truestatus == "9")
                        {
                            e.Row.Cells[0].Text = null;
                            e.Row.ForeColor = System.Drawing.Color.Red;
                            //e.Row.Cells[2].ForeColor = System.Drawing.Color.Red;
                        }
                        if (truestatus == "11")
                        {
                            e.Row.Cells[0].Text = null;
                            e.Row.ForeColor = System.Drawing.Color.Red;
                            //e.Row.Cells[2].ForeColor = System.Drawing.Color.Red;
                        }
                        if (truestatus =="10")
                        {
                            e.Row.Cells[0].Text = null;
                            //e.Row.Cells[2].ForeColor = System.Drawing.Color.Red;
                            e.Row.ForeColor = System.Drawing.Color.Red;
                        }

                        if (truestatus =="12")
                        {
                            e.Row.Cells[0].Text = null;
                            //e.Row.Cells[2].ForeColor = System.Drawing.Color.Red;
                            e.Row.ForeColor = System.Drawing.Color.Red;
                        }
                    }
                   
                }
            }
        

        
    }
}
    
  


