using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class CPP_PromoDetails : System.Web.UI.Page
{
    private string gvUniqueID = String.Empty;
    string gvSortExpr = String.Empty;
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string[] Sdate;
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        dataOrigin.ConnectionString = strCon;
        datadest.ConnectionString = strCon;
        dataAirline.ConnectionString = strCon;
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {

                Session["dthold"] = maketable();
                DataTable dt = (DataTable)Session["dthold"];
                grdCpp.DataSource = (DataTable)Session["dthold"];
                grdCpp.DataBind();
                grdCpp.Rows[0].Visible = false;
                if (dt.Rows[0][0].ToString() == "0")
                {
                    ((TextBox)grdCpp.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = "0";
                    ((TextBox)grdCpp.FooterRow.Cells[1].FindControl("txtStartvalue")).ReadOnly = true;

                }

                if (Request.QueryString["startDate"].ToString().Trim() == "s" && Request.QueryString["enddate"].ToString().Trim() == "e")
                {
                    txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    Sdate = txtValidFrom.Text.Split('/');
                    string month = Sdate[1];
                    string year = Sdate[2];
                    if (Sdate[1] == "01" || Sdate[1] == "02" || Sdate[1] == "03")
                    {
                        int yy = int.Parse(year);
                        string destdata = "31/03/" + yy.ToString();
                        txtValidTo.Text = destdata;
                    }
                    if (Sdate[1] == "04" || Sdate[1] == "05" || Sdate[1] == "06" || Sdate[1] == "07" || Sdate[1] == "08" || Sdate[1] == "09" || Sdate[1] == "10" || Sdate[1] == "11" || Sdate[1] == "12")
                    {
                        int yy = int.Parse(year) + 1;
                        string destdata = "31/03/" + yy.ToString();
                        txtValidTo.Text = destdata;
                    }

                    btnupdate.Visible = false;
                    btnSubmit.Visible = true;

                }
                else
                {
                    FillData();
                    btnupdate.Visible = true;
                    btnSubmit.Visible = false;
                    //DataTable dt_checkpromo = dw.GetAllFromQuery("Select min(startdate) as startdate,max(enddate) as enddate,sum(ISNULL(TotalPromo,0)) AS TotalPromo from CPP_AgentwiseTotal where   StartDate between '" + FormatDateMM(Request.QueryString["startDate"].ToString().Trim()) + "' AND '" + FormatDateMM(Request.QueryString["enddate"].ToString().Trim()) + "'");
                    DataTable dt_checkpromo = dw.GetAllFromQuery("select min(startdate) as startdate,max(enddate) as enddate,sum(ISNULL(TotalPromo,0)) AS TotalPromo from cpp_agentwisetotal where ('" + FormatDateMM(Request.QueryString["startDate"].ToString().Trim()) + "' between startdate and enddate) or ('" + FormatDateMM(Request.QueryString["enddate"].ToString().Trim()) + "' between startdate and enddate)");
                    if (dt_checkpromo.Rows[0]["startdate"].ToString().Trim() != "")
                    {
                        if (decimal.Parse(dt_checkpromo.Rows[0]["TotalPromo"].ToString()) > 0)
                        {
                            //btnFrom.Visible = false;
                            //btnTo.Visible = true;
                            lblmsg.Visible = true;
                            txtValidFrom.ReadOnly = true;
                            lblmsg.Text = " Promo CPP already Transffered  in period between " + FormatDateDD(dt_checkpromo.Rows[0]["startdate"].ToString().Trim()) + " and " + FormatDateDD(dt_checkpromo.Rows[0]["enddate"].ToString().Trim()) + "";
                            //txtValidTo.Text = FormatDateDD(dt_checkbase.Rows[0]["Enddate"].ToString().Trim());
                            grdCpp.FooterRow.Visible = false;
                            grdCpp.Columns[9].Visible = false;
                        }
                        else
                        {
                            //btnFrom.Visible = true;
                            //btnTo.Visible = true;
 
                        }
                    }
                    else
                    {
                        //btnFrom.Visible = true;
                        //btnTo.Visible = true;
                    }
                }

            }
        }


    }
    public void FillData()
    {
        con = new SqlConnection(strCon);
        con.Open();
        if (Request.QueryString["startDate"].ToString().Trim() != "" && Request.QueryString["enddate"].ToString().Trim() != "")
        {
            txtValidFrom.Text = Request.QueryString["startDate"].ToString().Trim();
            txtValidTo.Text = Request.QueryString["enddate"].ToString().Trim();
            DataTable dtDetails = dw.GetAllFromQuery("select * from CPP_PromoBonus where startDate='" + FormatDateMM(Request.QueryString["startDate"].ToString().Trim()) + "' and EndDate='" + FormatDateMM(Request.QueryString["enddate"].ToString().Trim()) + "' order by startvalue");
            DataTable dt = (DataTable)Session["dthold"];
            if (dt.Rows[0][0].ToString() == "0")
            {
                dt.Rows[0].Delete();
            }
            for (int k = 0; k < dtDetails.Rows.Count; k++)
            {
                DataRow dr = dt.NewRow();
                string strSno = dtDetails.Rows[k]["Sno"].ToString();
                string strStartvalue = dtDetails.Rows[k]["Startvalue"].ToString();
                string strEndValue = dtDetails.Rows[k]["EndValue"].ToString();
                string strPoints = dtDetails.Rows[k]["points"].ToString();
                string strtimesfactor = dtDetails.Rows[k]["timesfactor"].ToString();
                string strorigin = dtDetails.Rows[k]["origin"].ToString();
                string strdestiantion = dtDetails.Rows[k]["destination"].ToString();
                string strairline = dtDetails.Rows[k]["airline"].ToString();
                string strshipment = dtDetails.Rows[k]["shipment"].ToString();
                dr[0] = strSno.ToString();
                dr[1] = strStartvalue.ToString();
                dr[2] = strEndValue.ToString();
                dr[3] = strPoints.ToString();
                dr[4] = strtimesfactor.ToString();
                dr[5] = strorigin.ToString();
                dr[6] = strdestiantion.ToString();
                dr[7] = strairline.ToString();
                dr[8] = strshipment.ToString();
                dt.Rows.Add(dr);
            }
            Session["dthold"] = dt;
            grdCpp.DataSource = dt;
            grdCpp.DataBind();

        }
    }
    public DataTable maketable()
    {
        DataTable dt = new DataTable();
        DataColumn dc3 = new DataColumn("Sno", typeof(Int32));
        dc3.AutoIncrement = true;
        dc3.AutoIncrementStep = 1;
        dc3.AutoIncrementSeed = 1;
        dt.Columns.Add(dc3);
        DataColumn dc = new DataColumn("Startvalue", typeof(String));
        dt.Columns.Add(dc);

        DataColumn dc1 = new DataColumn("EndValue", typeof(String));
        dt.Columns.Add(dc1);

        DataColumn dc2 = new DataColumn("Points", typeof(String));
        dt.Columns.Add(dc2);

        DataColumn dc4 = new DataColumn("TimesFactor", typeof(String));
        dt.Columns.Add(dc4);

        DataColumn dc5 = new DataColumn("Origin", typeof(String));
        dt.Columns.Add(dc5);

        DataColumn dc6 = new DataColumn("Destination", typeof(String));
        dt.Columns.Add(dc6);

        DataColumn dc7 = new DataColumn("Airline", typeof(String));
        dt.Columns.Add(dc7);

        DataColumn dc8 = new DataColumn("Shipment", typeof(String));
        dt.Columns.Add(dc8);

        DataRow dr = dt.NewRow();

        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dr[6] = "0";
        dr[7] = "0";
        dr[8] = "0";
        dt.Rows.Add(dr);
        return dt;
    }
    public void DeleteRecords()
    {
        DataTable dt_del = (DataTable)Session["dthold"];
        for (int i = 0; i < dt_del.Rows.Count; i++)
        {
            con = new SqlConnection(strCon);
            try
            {
                DataRow rw = dt_del.Rows[i];
                con.Open();
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand("[CPP_PromoDELETE]", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@Sno", SqlDbType.BigInt).Value = long.Parse(rw["sno"].ToString());
                com.ExecuteNonQuery();
                con.Close();
                com.Connection.Close();
            }
            catch (SqlException sqlex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Error');</script>");
                string ss = sqlex.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
    public void ADDDATA()
    {

        DataTable dt = (DataTable)Session["dthold"];
        //  dt.Rows[0].Delete();
        string Sno = Convert.ToString(Request.QueryString["Sno"]);
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            DataRow rw = dt.Rows[i];
            con = new SqlConnection(strCon);
            try
            {
                con.Open();
                con = new SqlConnection(strCon);
                con.Open();
                com = new SqlCommand("[Cpp_PromoInsert]", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("@StartValue", SqlDbType.Decimal).Value = Convert.ToDecimal(rw["startvalue"].ToString());
                com.Parameters.Add("@EndValue", SqlDbType.Decimal).Value = Convert.ToDecimal(rw["endvalue"].ToString());
                com.Parameters.Add("@startDate", SqlDbType.DateTime).Value = FormatDateMM(txtValidFrom.Text);
                com.Parameters.Add("@EndDate", SqlDbType.DateTime).Value = FormatDateMM(txtValidTo.Text);
                com.Parameters.Add("@Points", SqlDbType.Decimal).Value = Convert.ToDecimal(rw["points"].ToString());
                com.Parameters.Add("@timesfactor", SqlDbType.Decimal).Value = Convert.ToDecimal(rw["timesfactor"].ToString());
                com.Parameters.Add("@origin", SqlDbType.VarChar).Value = rw["origin"].ToString();
                com.Parameters.Add("@Destination", SqlDbType.VarChar).Value = rw["Destination"].ToString();
                com.Parameters.Add("@Airline", SqlDbType.VarChar).Value = rw["airline"].ToString();
                com.Parameters.Add("@Shipment", SqlDbType.Int).Value = Convert.ToInt64(rw["Shipment"].ToString()); 
                com.ExecuteNonQuery();
                con.Close();
                com.Connection.Close();
            }
            catch (SqlException sqlex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Error');</script>");
                string ss = sqlex.Message;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
        }
        Response.Redirect("CppBrowse_PromoDetails.aspx?startDate=s&enddate=e");
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void grdCpp_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        CppBaseShow.Visible = false;
        grdCpp.EditIndex = -1;
        grdCpp.DataSource = (DataTable)Session["dthold"];
        grdCpp.DataBind();

    }
    protected void grdCpp_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            grdCpp.ShowFooter = false;
        }
        else
        {
            grdCpp.ShowFooter = true;
        }
        if (e.CommandName == "Add")
        {
            string origin_val = "";
            string origin_val_array = "";
            string dest_val = "";
            string dest_val_array = "";
            string al_val = "";
            string al_val_array = "";
            try
            {             
                string str_startvalue = ((TextBox)grdCpp.FooterRow.FindControl("txtstartvalue")).Text;
                string str_endvalue = ((TextBox)grdCpp.FooterRow.FindControl("txtendvalue")).Text;
                string pointsValue = ((TextBox)grdCpp.FooterRow.FindControl("txtPoints")).Text;
                string timesFactorValue = ((TextBox)grdCpp.FooterRow.FindControl("txttimesFactor")).Text;
                string originvalue = ((ListBox)grdCpp.FooterRow.FindControl("lstOrigin")).SelectedValue;
                string originTest = ((ListBox)grdCpp.FooterRow.FindControl("lstOrigin")).ToString();
                string destvalue = ((ListBox)grdCpp.FooterRow.FindControl("lstDest")).SelectedItem.Value;
                string DestTest = ((ListBox)grdCpp.FooterRow.FindControl("lstDest")).SelectedItem.Text;
                string Airlinevalue = ((ListBox)grdCpp.FooterRow.FindControl("lstAirline")).SelectedItem.Value;
                string AirlineTest = ((ListBox)grdCpp.FooterRow.FindControl("lstAirline")).SelectedItem.Text;
                string str_Shipment = ((TextBox)grdCpp.FooterRow.FindControl("txtShipment")).Text;

                // Check value for Origin
                foreach (int i in ((ListBox)grdCpp.FooterRow.FindControl("lstOrigin")).GetSelectedIndices()) 
                {
                    if (((ListBox)grdCpp.FooterRow.FindControl("lstOrigin")).Items[i].Selected)
                    {
                        origin_val = ((ListBox)grdCpp.FooterRow.FindControl("lstOrigin")).Items[i].Value + ",";
                        origin_val_array = origin_val_array + origin_val;
                    }

                }
               string origin_val1 = origin_val_array.Substring(0, origin_val_array.LastIndexOf(','));
                string[] origin_val2 = origin_val1.Split(',');
                if (origin_val2[0].ToString().Trim() == "0")
                {
                    if (origin_val2.Length > 1)
                    {
                        //CppBaseShow.Visible = true;
                        //CppBaseShow.Text = "The City Code could not select if All is selected!!";
                        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('The City Code could not select if All is selected!!');</script>");
                        return;

                    }
                }

                // Check value for destination
                foreach (int i in ((ListBox)grdCpp.FooterRow.FindControl("lstDest")).GetSelectedIndices())
                {
                    if (((ListBox)grdCpp.FooterRow.FindControl("lstDest")).Items[i].Selected)
                    {
                        dest_val = ((ListBox)grdCpp.FooterRow.FindControl("lstDest")).Items[i].Value + ",";
                        dest_val_array = dest_val_array + dest_val;
                    }

                }
                string dest_val1 = dest_val_array.Substring(0, dest_val_array.LastIndexOf(','));
                string[] dest_val2 = dest_val1.Split(',');

                if (dest_val2[0].ToString().Trim() == "0")
                {
                    if (dest_val2.Length > 1)
                    {
                        //CppBaseShow.Visible = true;
                        //CppBaseShow.Text = "The City Code could not select if All is selected!!";
                        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('The Destination Code could not select if All is selected!!');</script>");
                        return;

                    }
                }

                foreach (int i in ((ListBox)grdCpp.FooterRow.FindControl("lstAirline")).GetSelectedIndices())
                {
                    if (((ListBox)grdCpp.FooterRow.FindControl("lstAirline")).Items[i].Selected)
                    {
                        al_val = ((ListBox)grdCpp.FooterRow.FindControl("lstAirline")).Items[i].Value + ",";
                        al_val_array = al_val_array + al_val;
                    }

                }
                string al_val1 = al_val_array.Substring(0, al_val_array.LastIndexOf(','));
                string[] al_val2 = al_val1.Split(',');
                if (al_val2[0].ToString().Trim() == "0")
                {
                    if (al_val2.Length > 1)
                    {
                        //CppBaseShow.Visible = true;
                        //CppBaseShow.Text = "The City Code could not select if All is selected!!";
                        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('The Airline Code could not select if All is selected!!');</script>");
                        return;

                    }
                }
                DataTable dt = (DataTable)Session["dthold"];
                if (dt.Rows[0][0].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }

                bool Flag = false;
                foreach (DataRow rw in dt.Rows)
                {
                    string p = rw["Endvalue"].ToString();
                    ViewState["p"] = rw["Endvalue"].ToString();
                    if (Convert.ToDecimal(str_startvalue.Trim().ToString()) != 0 && Convert.ToDecimal(p.Trim().ToString()) != 0)
                    {
                        if (Convert.ToDecimal(str_startvalue.Trim().ToString()) <= Convert.ToDecimal(p.Trim().ToString()))
                        {
                            Flag = true;
                        }
                    }
                }
                if (Flag == false)
                {
                    DataRow dr = dt.NewRow();
                    dr[1] = str_startvalue;
                    dr[2] = str_endvalue;
                    dr[3] = pointsValue;
                    dr[4] = timesFactorValue;
                    dr[5] = origin_val1;
                    dr[6] = dest_val1;
                    dr[7] = al_val1;
                    dr[8] = str_Shipment;
                    dt.Rows.Add(dr);
                    Session["dthold"] = dt;
                    grdCpp.DataSource = (DataTable)Session["dthold"];
                    grdCpp.DataBind();
                    for (int i = 0; i < grdCpp.Rows.Count - 1; i++)
                    {
                        ((LinkButton)(grdCpp.Rows[i].FindControl("LinkButtonEdit"))).Visible = false;
                        ((LinkButton)(grdCpp.Rows[i].FindControl("LinkButtonDelete"))).Visible = false;
                    }
                    ((TextBox)grdCpp.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(str_endvalue)));
                    CppBaseShow.Visible = false;
                    ((TextBox)grdCpp.FooterRow.FindControl("txtendvalue")).Focus();
                }
                else
                {
                    CppBaseShow.Visible = true;
                    CppBaseShow.Text = "The Start value always be greater than end value of previous slab";
                    ((TextBox)grdCpp.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["p"].ToString())));
                    ((TextBox)grdCpp.FooterRow.FindControl("txtendvalue")).Text = "";
                    ((TextBox)grdCpp.FooterRow.FindControl("txtPoints")).Text = "";
                    ((TextBox)grdCpp.FooterRow.FindControl("txtendvalue")).Focus();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + "Please enter details " + "');</script>");
            }
        }
    }
    protected void grdCpp_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.Exception != null)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + e.Exception.Message.ToString().Replace("'", "") + "');</script>");
            e.ExceptionHandled = true;
        }
    }
    protected void grdCpp_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        GridViewRow row1 = grdCpp.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["dthold"];
        DataRow[] drp;
        drp = dt.Select("sno =  '" + ((Label)row1.FindControl("lblsno")).Text + "'");
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                    row.Delete();
            }
        }
        Session["dthold"] = dt;
        if (dt.Rows.Count == 0)
        {
            Session["dthold"] = maketable();
            grdCpp.DataSource = (DataTable)Session["dthold"];
            grdCpp.DataBind();
            grdCpp.Rows[0].Visible = false;
        }
        else
        {
            grdCpp.DataSource = (DataTable)Session["dthold"];
            grdCpp.DataBind();

        }
        ((TextBox)grdCpp.FooterRow.Cells[0].FindControl("txtendvalue")).Focus();

    }
    protected void grdCpp_RowEditing(object sender, GridViewEditEventArgs e)
    {

        CppBaseShow.Visible = false;
        grdCpp.EditIndex = e.NewEditIndex;
        grdCpp.DataSource = (DataTable)Session["dthold"];
        grdCpp.DataBind();


    }
    protected void grdCpp_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        //Check if there is any exception while deleting
        if (e.Exception != null)
        {
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + e.Exception.Message.ToString().Replace("'", "") + "');</script>");
            e.ExceptionHandled = true;
        }
    }
    protected void grdCpp_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row1 = grdCpp.Rows[e.RowIndex];
        DataTable dt = (DataTable)Session["dthold"];
        DataRow[] drp;
        drp = dt.Select("Sno =  '" + ((Label)row1.FindControl("lblSno")).Text + "'");
        string h = "";
        h = ((TextBox)row1.FindControl("txtStartvalue")).Text;
        bool Flag = false;
        string p = "";
        for (int i = 0; i < dt.Rows.Count - 1; i++)
        {
            DataRow rw = dt.Rows[i];
            p = rw["endValue"].ToString();
            if (Convert.ToDecimal(h.Trim().ToString()) <= Convert.ToDecimal(p.Trim().ToString()))
            {
                Flag = true;
                ViewState["p"] = rw["endValue"].ToString();

            }
        }
        if (drp.Length > 0)
        {
            foreach (DataRow row in drp)
            {
                if (row[0].ToString() != "1")
                {
                    row.BeginEdit();
                    row[1] = ((TextBox)row1.FindControl("txtStartvalue")).Text;

                    //row[1] = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["p"].ToString())));
                    row[2] = ((TextBox)row1.FindControl("txtEndvalue")).Text;
                    row[3] = ((TextBox)row1.FindControl("txtPoints")).Text;
                    row[4] = ((TextBox)row1.FindControl("txttimesfactor")).Text;
                    row[8] = ((TextBox)row1.FindControl("txtshipment")).Text;
                    ViewState["end_value"] = row[2].ToString();
                    if (row[1].ToString() == "") break;
                    if (row[2].ToString() == "") break;
                    if (row[3].ToString() == "") break;
                    if (row[4].ToString() == "") break;
                    if (row[8].ToString() == "") break;

                    row.EndEdit();

                }
            }
        }

        if (Flag == false)
        {
            grdCpp.EditIndex = -1;
            grdCpp.DataSource = (DataTable)Session["dthold"];
            grdCpp.DataBind();

            ((TextBox)grdCpp.FooterRow.Cells[0].FindControl("txtStartValue")).Focus();
            ((TextBox)grdCpp.FooterRow.Cells[0].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["end_value"].ToString())));
            CppBaseShow.Visible = false;
        }
        else
        {
            CppBaseShow.Visible = true;
            CppBaseShow.Text = "The Start value always be greater than end value of previous slab";
            ((TextBox)row1.FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["p"].ToString())));
        }
    }
    protected void grdCpp_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        grdCpp.Columns[0].Visible = false;

        //Check if this is our Blank Row being databound, if so make the row invisible
        if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowState.ToString() != "Edit" && e.Row.RowState.ToString() != "Alternate, Edit")
        {
            //-----------------------------------For Bind data According to the ID ---------------


            //Bind City Code based on City ID

            Label lblcity_id = (Label)e.Row.Cells[5].FindControl("lblOrigin");
            string ct_id = lblcity_id.Text;
            string[] c = ct_id.Split(',');
            string str_Empty_City = string.Empty;
            for (int i = 0; i < c.Length; i++)
            {
                // CREATING DATATABLE FOR City Code From City Master

                string strCity = "Select * from city_master where city_id='" + Convert.ToInt64(c.GetValue(i).ToString()) + "'";
                DataTable dtCity_code = dw.GetAllFromQuery(strCity);

                if (dtCity_code.Rows.Count > 0)
                {
                    // STRING CONCATENATION
                    str_Empty_City = str_Empty_City + (dtCity_code.Rows[0]["City_code"].ToString().Trim() + ",");
                }
                else
                {
                    str_Empty_City = "ALL,";
                }

            }
            str_Empty_City = str_Empty_City.Remove(str_Empty_City.LastIndexOf(","));
            e.Row.Cells[5].Text = str_Empty_City;

            //Bind CDest Code based on Dest ID

            Label lbldest_id = (Label)e.Row.Cells[6].FindControl("lbldest");
            string dt_id = lbldest_id.Text;
            string[] d = dt_id.Split(',');
            string str_Empty_dest = string.Empty;
            for (int i = 0; i < d.Length; i++)
            {
                // CREATING DATATABLE FOR Dest Code From Desination Master

                string strDest = "Select * from Destination_master where destination_id='" + Convert.ToInt64(d.GetValue(i).ToString()) + "'";
                DataTable dtdesty_code = dw.GetAllFromQuery(strDest);
                if (dtdesty_code.Rows.Count > 0)
                {
                    // STRING CONCATENATION
                    str_Empty_dest = str_Empty_dest + (dtdesty_code.Rows[0]["destination_code"].ToString().Trim() + ",");
                }
                else
                {
                    str_Empty_dest = "ALL,";
                }

            }
            str_Empty_dest = str_Empty_dest.Remove(str_Empty_dest.LastIndexOf(","));
            e.Row.Cells[6].Text = str_Empty_dest;



            //Bind Airline name with city Code based on Airline detail ID

            Label lblairline_id = (Label)e.Row.Cells[7].FindControl("lblairline");
            string airline_id = lblairline_id.Text;
            string[] a = airline_id.Split(',');
            string str_Empty_airline = string.Empty;
            for (int i = 0; i < a.Length; i++)
            {
                // CREATING DATATABLE FOR Dest Code From Desination Master


                string str_airline = "select  a.Airline_Name,a.airline_text_code,city_code,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City where b.Airline_Detail_ID=" + Convert.ToInt64(a.GetValue(i).ToString()) + "";
                DataTable dtairline_code = dw.GetAllFromQuery(str_airline);
                if (dtairline_code.Rows.Count > 0)
                {
                    // STRING CONCATENATION
                    str_Empty_airline = str_Empty_airline + (dtairline_code.Rows[0]["airline_text_code"].ToString().Trim() + "-" + dtairline_code.Rows[0]["city_code"].ToString().Trim() + ",");
                }
                else
                {
                    str_Empty_airline = "ALL,";
                }

            }
            str_Empty_airline = str_Empty_airline.Remove(str_Empty_airline.LastIndexOf(","));
            e.Row.Cells[7].Text = str_Empty_airline;

            //--------------------------------------------------------------------------------------
        }

      if (e.Row.RowType == DataControlRowType.DataRow)
      {
            for (int i = 0; i < grdCpp.Rows.Count; i++)
            {
                ((LinkButton)(grdCpp.Rows[i].FindControl("LinkButtonEdit"))).Visible = false;
                ((LinkButton)(grdCpp.Rows[i].FindControl("LinkButtonDelete"))).Visible = false;
            }
            if (((DataRowView)e.Row.DataItem)["Sno"].ToString() == String.Empty) e.Row.Visible = false;

            if (grdCpp.EditIndex == e.Row.RowIndex)
            {
                TextBox Start_Value = (TextBox)e.Row.FindControl("txtStartValue");
                TextBox end_value = (TextBox)e.Row.FindControl("txtEndValue");
                TextBox points_value = (TextBox)e.Row.FindControl("txtPoints");
                TextBox timesfactor_value = (TextBox)e.Row.FindControl("txtTimesFactor");
                TextBox shipment_value = (TextBox)e.Row.FindControl("txtShipment");
                ListBox lstOrigin_value = (ListBox)e.Row.FindControl("lstOrigin");
                ListBox lstdest_value = (ListBox)e.Row.FindControl("lstdest");
                ListBox lstairline_value = (ListBox)e.Row.FindControl("lstairline");

                string kk = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Sno"].ToString();
                if (Session["dthold"] != null)
                {
             

                    lstOrigin_value.Items.Insert(0, "ALL");
                    lstOrigin_value.Items[0].Value = "0";

                    lstdest_value.Items.Insert(0, "ALL");
                    lstdest_value.Items[0].Value = "0";

                    lstairline_value.Items.Insert(0, "ALL");
                    lstairline_value.Items[0].Value = "0";

                    ViewState["Estartvalue"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["StartValue"].ToString();
                    ViewState["Eendvalue"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["EndValue"].ToString();
                    ViewState["Epoints"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Points"].ToString();
                    ViewState["Etimesfactor"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["TimesFactor"].ToString();
                    ViewState["Eshipment"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["shipment"].ToString();
                    ViewState["Ecity"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["origin"].ToString();
                    ViewState["Edestt"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["destination"].ToString();
                    ViewState["Eairline"] = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["airline"].ToString();
                    string strcc = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Origin"].ToString();

                    string[] arrCity = strcc.Split(new char[] { ',' });

                    for (int j = 0; j < arrCity.Length; j++)
                    {
                        for (int i = 0; i <= (lstOrigin_value.Items.Count - 1); i++)
                        {
                            if (lstOrigin_value.Items[i].Value == arrCity[j])
                            {
                                lstOrigin_value.Items[i].Selected = true;
                            }
                        }
                    }
                   
                    string strdest = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["destination"].ToString();

                    string[] arrdest = strdest.Split(new char[] { ',' });

                    for (int j = 0; j < arrdest.Length; j++)
                    {
                        for (int i = 0; i <= (lstdest_value.Items.Count - 1); i++)
                        {
                            if (lstdest_value.Items[i].Value == arrdest[j])
                            {
                                lstdest_value.Items[i].Selected = true;
                            }
                        }
                    }

                    string strairline = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["airline"].ToString();

                    string[] arrairline = strairline.Split(new char[] { ',' });

                    for (int j = 0; j < arrairline.Length; j++)
                    {
                        for (int i = 0; i <= (lstairline_value.Items.Count - 1); i++)
                        {
                            if (lstairline_value.Items[i].Value == arrairline[j])
                            {
                                lstairline_value.Items[i].Selected = true;
                            }
                        }
                    }

                    if (((DataTable)Session["dthold"]).Rows[0][0].ToString() == "0" || ((DataTable)Session["dthold"]).Rows.Count.ToString() == "1")
                    {
                        Start_Value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["StartValue"].ToString();
                        Start_Value.ReadOnly = true;

                    }
                    else
                    {
                        Start_Value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["StartValue"].ToString();
                    }


                    end_value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["EndValue"].ToString();
                    points_value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["Points"].ToString();
                    timesfactor_value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["TimesFactor"].ToString();
                    shipment_value.Text = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["shipment"].ToString();


                    //lstOrigin_value.SelectedItem.Value = ((DataTable)Session["dthold"]).Rows[e.Row.RowIndex]["origin"].ToString();

                    ((TextBox)grdCpp.FooterRow.Cells[1].FindControl("txtStartvalue")).Text = Convert.ToString(Math.Ceiling(Convert.ToDecimal(ViewState["Eendvalue"])));

                }
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        DataTable dt = (DataTable)Session["dthold"];
        if (dt.Rows.Count == 1)
        {
            if (dt.Rows[0][0].ToString() == "0")
            {
                CppBaseShow.Visible = true;
                CppBaseShow.Text = "Pls Add at least One Row";
            }
            else
            {
                ADDDATA();
                CppBaseShow.Visible = false;
            }
        }
        else
        {
            ADDDATA();
            CppBaseShow.Visible = false;
        }
    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CppBrowse_PromoDetails.aspx");
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["StartDate"].ToString().Trim() != "s" && Request.QueryString["EndDate"].ToString().Trim() != "e")
        {
            DeleteRecords();
        }
        DataTable dt = (DataTable)Session["dthold"];
        if (dt.Rows.Count == 1)
        {
            if (dt.Rows[0][1].ToString() == "0")
            {
                CppBaseShow.Visible = true;
                CppBaseShow.Text = "Pls Add at least One Row";
            }
            else
            {
                ADDDATA();
                CppBaseShow.Visible = false;
            }
        }
        else
        {
            ADDDATA();
            CppBaseShow.Visible = false;
        }
    }
    protected void linkAddOrder_Click(object sender, EventArgs e)
    {

    }
    protected void grdCpp_PreRender(object sender, EventArgs e)
    {
        DataTable dt = (DataTable)Session["dthold"];
        if (dt.Rows[0][0].ToString() == "0")
        {
            chkGridValue.Value = "0"; ;
        }
        else
            chkGridValue.Value = "1";
        ClientScriptManager cs = Page.ClientScript;
        TextBox txtStValue = (TextBox)grdCpp.FooterRow.FindControl("txtStartvalue");
        TextBox txtenValue = (TextBox)grdCpp.FooterRow.FindControl("txtEndValue");
        cs.RegisterArrayDeclaration("grd_startvalueFooter", String.Concat("'", txtStValue.ClientID, "'"));
        cs.RegisterArrayDeclaration("grd_endvalueFooter", String.Concat("'", txtenValue.ClientID, "'"));
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY.Substring(0, 4);
        return strMMDDYYYY;
    }
    protected void grdCpp_DataBound(object sender, EventArgs e)
    {
        // Insert Origin  
        GridViewRow gvrorigin = grdCpp.FooterRow;
        ListBox lstOrigins = (ListBox)gvrorigin.Cells[0].FindControl("lstOrigin");
        lstOrigins.Items.Insert(0, "ALL");
        lstOrigins.Items[0].Value = "0";
        lstOrigins.Items[0].Selected = true;

        GridViewRow gvrdest = grdCpp.FooterRow;
        ListBox lstdestinatios = (ListBox)gvrdest.Cells[0].FindControl("lstDest");
        lstdestinatios.Items.Insert(0, "ALL");
        lstdestinatios.Items[0].Value = "0";
        lstdestinatios.Items[0].Selected = true;

        GridViewRow gvrAirline = grdCpp.FooterRow;
        ListBox lstAirlines = (ListBox)gvrAirline.Cells[0].FindControl("lstAirline");
        lstAirlines.Items.Insert(0, "ALL");
        lstAirlines.Items[0].Value = "0";
        lstAirlines.Items[0].Selected = true;
    }
}
