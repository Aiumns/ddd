using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Created By Megha Goel On Dated 29 Dec 2008
/// </summary>
public partial class addPayment : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    string var_Airline ;
    string[] Arr_Airline ;
    string var_Airline_Detail_ID ;
    string AirlineID;
    string Access;
    string Arl_Access;
    DisplayWrap dw = new DisplayWrap();
    string Final_Payment_ID;
    decimal Final_Paid_Amount;
    decimal Final_short_excess;
    int Paid_Status;
    string existing_paymentid;
    decimal existing_paidamt;
    decimal existing_short_excess;
    decimal Total_Payable_amt;
    int CSR_Detail_ID;
    string CSR_No;
    DateTime CSR_From;
    DateTime CSR_To;
    string Agent_Code;
    string Agent_Name;
    string Agent_Address;
    decimal Total_Paid_Amount;
    decimal Agent_Paid_Amount;
    decimal Paid_Amount;
    decimal TDS_Cut_By_Agent;
    decimal Service_Tax_Cut_By_Agent;
    decimal SBCess_Cut_By_Agent;
    decimal KKCess_Cut_By_Agent;
    decimal Adjusted_Amount;
    decimal Short_Excess;
    int High_Value;
    string Bank;
    string Bank_Branch;
    string Cheque_No;
    DateTime Cheque_Date;
    DateTime Cheque_Deposit_Date;
    string Account_Name;
    string Account_No;
    string Remarks;
    int Status;
    string Entered_By;
    DateTime Entered_On;
  
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage.Visible = false;
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                //***** DEFAULT DATE INTO DATE & CHEQUE DEPOSITE DATE AS CURRENT_DATE*********************

               txtAmount.Attributes.Add("onblur", "return chk_Amount();");
                btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
                DateTime dtDate = DateTime.Now.Date;
                string str = Convert.ToString(dtDate.ToShortDateString());
                txtDate.Text = FormatDateMM(str);
                txtDepositeDate.Text = FormatDateMM(str);
                //****************************************************************************************
                lblMessage.Visible = false;
                pnlPayment.Visible = true;
                pnlShowDetails.Visible = false;
                //airlineDetails();
                UserAirlineNamePlusCode();

            }
        }
       

    }
    
    // FUNCTION FOR GETTING AIRLINE NAME LIST
    #region Display Airline/City in  ADD Case
    public void UserAirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            string Airline_Access = Rights();
            ddlAirlineName.Items.Clear();

            strQuery = "select  a.Airline_ID,a.Airline_Name,b.Airline_Detail_ID,c.City_Name,b.Belongs_To_City from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City  where b.Airline_Detail_ID in" + "(" + Airline_Access + ") order by  a.Airline_Name";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineName.Items.Insert(0, "Select Airline");
            ddlAirlineName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAirlineName.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString() + "-" + dr["Airline_ID"].ToString() + "-" + dr["Belongs_To_City"].ToString()));

            }
            con.Close();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string Rights()
    {
        string sql_Access = "";
        if (Session["groupid"].ToString() == "5")
        {

            sql_Access = "select Airline_Access from Agent_Master a inner join Agent_Branch b on a.Agent_ID=b.agent_id inner join login_master c on b.Agent_Branch_ID=c.Agent_ID where a.agent_id=" + Session["ID"].ToString();
        }
        else
        {
            sql_Access = "SELECT Airline_Access FROM USER_MASTER A INNER JOIN login_master B ON A.UserID=B.User_ID where a.UserID=" + Session["ID"].ToString();

        }

        con = new SqlConnection(strCon);
        con.Open();

        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }
        }

        if (Access == null)
        {
            

        }
        else
        {
           /**************MODIFIED MY MEGHA[17 JAN 2008]NO NEED TO REMOVE COMMA**************/
            //int Split_Acces = Access.Length;
            //Arl_Access = Access.Substring(0, (Split_Acces - 1));
            Arl_Access = Access;

        }
        return Arl_Access;

    }
    #endregion 

  

    // FUNCTION FOR GETTING AGENT LIST ACCORDING TO SELECTED AIRLINE
    public void AgentDetails()
    {

        
        con = new SqlConnection(strCon);
         var_Airline = ddlAirlineName.SelectedValue;
         Arr_Airline = var_Airline.Split('-');
         var_Airline_Detail_ID = Arr_Airline[0];
         AirlineID = Arr_Airline[1];
         string city_id = Arr_Airline[2];

         string s1 = "%," + var_Airline_Detail_ID + ",%";
         string s2 =  var_Airline_Detail_ID;
         string s3 = "%," + var_Airline_Detail_ID;
         string s4 =  var_Airline_Detail_ID+",%";

         //string s1 = "%," + var_Airline_Detail_ID + "%";
         //string s2 = var_Airline_Detail_ID + "%";
         string strQuery = "select a.agent_id,a.agent_Name,c.city_name from agent_master a inner join agent_branch b on a.agent_id = b.agent_id inner join city_master c on b.belongs_to_city = c.city_id inner join login_master l on b.agent_branch_id = l.agent_id where (airline_access like '" + s1 + "' or airline_access like '" + s2 + "' or airline_access like '" + s3 + "' or airline_access like '" + s4 + "') and l.group_id =5 and b.belongs_to_city='" + city_id + "' order by a.Agent_name";

        con.Open();
        SqlDataReader drAgent;
        SqlCommand cmd = new SqlCommand(strQuery, con);
        drAgent = cmd.ExecuteReader();
        ddlAgentName.Items.Clear();
        ddlAgentName.Items.Add(new ListItem("--Select--", "y"));
        ddlAgentName.Items[0].Value = "0";
        while (drAgent.Read())
        {
            string aname = drAgent["agent_Name"].ToString();
            string city = drAgent["city_name"].ToString();
            string agentText = aname + "- (" + city + ")";
            ddlAgentName.Items.Add(new ListItem(agentText, drAgent["agent_id"].ToString()));
        }
        drAgent.Close();
        con.Close();
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    protected void btnShow_Click(object sender, EventArgs e)
    {
        try
        {
            pnlShowDetails.Visible = true;
            btnShow.Visible = false;
            var_Airline = ddlAirlineName.SelectedValue;
            Arr_Airline = var_Airline.Split('-');
            var_Airline_Detail_ID = Arr_Airline[0];
            AirlineID = Arr_Airline[1];
            string city_id = Arr_Airline[2];
            string agent_id = ddlAgentName.SelectedValue;
            con = new SqlConnection(strCon);
            con.Open();

            string SQL_AmountCheck = "SELECT Agent_code,CSR_No,Amount_Including_TDS AS ACTUAL_AMOUNT,Paid_Amount,(Amount_Including_TDS-Paid_Amount) AS TOBE_PAID FROM CSR_Details  WHERE  Agent_ID='" + agent_id + "' AND  Airline_Detail_ID='" + var_Airline_Detail_ID + "' AND (Amount_Including_TDS-Paid_Amount)<>0";
            SqlDataReader drAmountCheck;
            SqlCommand cmd = new SqlCommand(SQL_AmountCheck, con);
            drAmountCheck = cmd.ExecuteReader();


            //DataTable dtAmountCheck = dw.GetAllFromQuery("SELECT Agent_code,CSR_No,Amount_Including_TDS AS ACTUAL_AMOUNT,Paid_Amount,(Amount_Including_TDS-Paid_Amount) AS TOBE_PAID FROM CSR_Details  WHERE  Agent_ID='" + agent_id + "' AND  Airline_Detail_ID='" + var_Airline_Detail_ID + "'");

            if (drAmountCheck.HasRows)
            {
                while (drAmountCheck.Read())
                {
                    string Agent_code = drAmountCheck["Agent_code"].ToString();
                    string CSR_No = drAmountCheck["CSR_No"].ToString();
                    string[] Airline_Code = CSR_No.Split('-');
                    string Final_Airline_Code = Airline_Code[1];
                    if (decimal.Parse(drAmountCheck["ACTUAL_AMOUNT"].ToString()) <= decimal.Parse(drAmountCheck["Paid_Amount"].ToString()))
                    {
                        //string Agent_code = dtAmountCheck.Rows[0]["Agent_code"].ToString();
                        //string CSR_No = dtAmountCheck.Rows[0]["CSR_No"].ToString();
                        //string[] Airline_Code = CSR_No.Split('-');
                        //string Final_Airline_Code = Airline_Code[1];
                        lblMessage.Visible = true;
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        lblMessage.Text = "There are no pending CSRs for " + Agent_code + " for Airline " + Final_Airline_Code;
                        pnlShowDetails.Visible = false;

                    }
                    else
                    {
                        pnlShowDetails.Visible = true;
                        lblMessage.Visible = false;
                        Fill_ddlCSR(agent_id, var_Airline_Detail_ID);
                        Fill_ddlAccount();
                        ddlAirlineName.Enabled = false;
                        ddlAgentName.Enabled = false;


                    }
                }
            }
            else
            {
                pnlShowDetails.Visible = false;
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "There are no pending CSRs For This Agent";
            }
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
       
        
    }

    //FUNCTION TO FILL PENDING CSR IN DROPDOWN -AGENTWISE 
    public void Fill_ddlCSR(string agent_id, string var_Airline_Detail_ID)
    {
        
        con = new SqlConnection(strCon);
        con.Open();

        string SQL_CSR = "SELECT CSR_Detail_ID,convert(varchar,CSR_From ,106) AS CSR_From,convert(varchar,CSR_To ,106)AS CSR_To ,Amount_Including_TDS AS ACTUAL_AMOUNT,Paid_Amount,(Amount_Including_TDS-Paid_Amount) AS TOBE_PAID FROM CSR_Details  WHERE  Agent_ID='" + agent_id + "' AND  Airline_Detail_ID='" + var_Airline_Detail_ID + "' AND (Amount_Including_TDS-Paid_Amount)<>0";
        SqlDataReader drCSR;
        SqlCommand cmd = new SqlCommand(SQL_CSR, con);
        drCSR = cmd.ExecuteReader();
        
        ddlCSR.Items.Clear();
        ddlCSR.Items.Add(new ListItem("--Select One--"));
        ddlCSR.Items[0].Value = "0";
        while (drCSR.Read())
        {
            //string CSR_value = drCSR["CSR_From"].ToString() + " - " + drCSR["CSR_To"].ToString() + "(" + "Actual: " + drCSR["ACTUAL_AMOUNT"].ToString() + "," + "Paid Amount: " + drCSR["Paid_Amount"].ToString() + "," + " To Be Paid: " + drCSR["TOBE_PAID"].ToString() + ")";

            string CSR_value = drCSR["CSR_From"].ToString() + " - " + drCSR["CSR_To"].ToString() + "(" + "Actual: " + Math.Round(decimal.Parse(drCSR["ACTUAL_AMOUNT"].ToString())) + "," + "Paid Amount: " + Math.Round(decimal.Parse(drCSR["Paid_Amount"].ToString())) + "," + " To Be Received: " + Math.Round(decimal.Parse(drCSR["TOBE_PAID"].ToString())) + ")";

            ddlCSR.Items.Add(new ListItem(CSR_value, drCSR["CSR_Detail_ID"].ToString()));
            
        }
        drCSR.Close();
        con.Close();
    }

    public void Fill_ddlAccount()
    {
        var_Airline = ddlAirlineName.SelectedValue;
        Arr_Airline = var_Airline.Split('-');
        var_Airline_Detail_ID = Arr_Airline[0];
        AirlineID = Arr_Airline[1];
        string city_id = Arr_Airline[2];
        con = new SqlConnection(strCon);
        con.Open();
        string agent_id = ddlAgentName.SelectedValue;
        string SQL_CSR = "SELECT Acc_Name,Acc_No,CONVERT(VARCHAR,ValidFrom,103) AS ValidFrom,CONVERT(VARCHAR,ValidTo,103) AS ValidTo FROM Airline_Bank_Details WHERE  Airline_Detail_ID='" + var_Airline_Detail_ID + "'";
        SqlDataReader drCSR;
        SqlCommand cmd = new SqlCommand(SQL_CSR, con);
        drCSR = cmd.ExecuteReader();
        ddlAccountName.Items.Clear();
        ddlAccountName.Items.Add(new ListItem("--Select One--"));
        ddlAccountName.Items[0].Value = "0";
        if (drCSR.HasRows)
        {
            while (drCSR.Read())
            {

                if (drCSR["Acc_Name"].ToString() == "" && drCSR["Acc_No"].ToString() == "")
                {
                }
                else
                {
                    ddlAccountName.Items.Add(new ListItem(drCSR["Acc_Name"] + "-" + drCSR["Acc_No"] + "-(" + drCSR["ValidFrom"] + "-" + drCSR["ValidTo"] + ")", drCSR["Acc_No"].ToString()));
                }

            }
        }
        cmd.Dispose();
        drCSR.Dispose();
        // SQL_CSR = "SELECT B.Acc_Name,B.Acc_No FROM Airline_Detail A INNER JOIN Company_Master B ON A.Company_ID=B.Company_ID where Airline_detail_id='" + var_Airline_Detail_ID + "'";
        
        // cmd = new SqlCommand(SQL_CSR, con);
        //drCSR = cmd.ExecuteReader();
        //if (drCSR.HasRows)
        //{
        //    while (drCSR.Read())
        //    {

        //        if (drCSR["Acc_Name"].ToString() == "" && drCSR["Acc_No"].ToString() == "")
        //        {
        //        }
        //        else
        //        {
        //            ddlAccountName.Items.Add(new ListItem(drCSR["Acc_Name"] + "-" + drCSR["Acc_No"], drCSR["Acc_No"].ToString()));
        //        }

        //    }
        //}
        //drCSR.Close();
        con.Close();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {

        btnAdd.Attributes.Add("onclick", "return CheckEmpty();");
        Total_Paid_Amount = decimal.Parse(txtAmount.Value) + decimal.Parse(txtTDSCutAgent.Text) + decimal.Parse(txtservicetaxcut.Text) + decimal.Parse(txtSBCess.Text) + decimal.Parse(txtKKCess.Text) + (decimal.Parse(txtAdjAmt.Text));
        pnlPayment.Visible = false;
        Insert_Payment();

    }
    public void Insert_Payment()
    {
        SqlTransaction Trans = null;
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string agent_id = ddlAgentName.SelectedValue;
            var_Airline = ddlAirlineName.SelectedValue;
            Arr_Airline = var_Airline.Split('-');
            var_Airline_Detail_ID = Arr_Airline[0];
            string csrid = ddlCSR.SelectedValue;
            string SQL_Pay = "SELECT CSR_Detail_ID, CSR_No,CSR_From, CSR_To,Agent_Code,Agent_Name,Agent_Address FROM CSR_Details  WHERE  CSR_Detail_ID='" + csrid + "' and Agent_ID='" + agent_id + "' AND  Airline_Detail_ID='" + var_Airline_Detail_ID + "'";
            SqlDataReader drPay;
            SqlCommand cmd = new SqlCommand(SQL_Pay, con);
            drPay = cmd.ExecuteReader();
            if (drPay.Read())
            {

                CSR_Detail_ID = int.Parse(drPay["CSR_Detail_ID"].ToString());
                CSR_No = drPay["CSR_No"].ToString();
                CSR_From = DateTime.Parse(drPay["CSR_From"].ToString());
                CSR_To = DateTime.Parse(drPay["CSR_To"].ToString());
                Agent_Code = drPay["Agent_Code"].ToString();
                Agent_Name = drPay["Agent_Name"].ToString();
                Agent_Address = drPay["Agent_Address"].ToString();

                Total_Paid_Amount = decimal.Parse(txtAmount.Value) + decimal.Parse(txtTDSCutAgent.Text) + decimal.Parse(txtservicetaxcut.Text) + decimal.Parse(txtSBCess.Text) + decimal.Parse(txtKKCess.Text) + (decimal.Parse(txtAdjAmt.Text));
                Paid_Amount = decimal.Parse(txtAmount.Value);
                TDS_Cut_By_Agent = decimal.Parse(txtTDSCutAgent.Text);
                Service_Tax_Cut_By_Agent = decimal.Parse(txtservicetaxcut.Text);
                SBCess_Cut_By_Agent = decimal.Parse(txtSBCess.Text);
                KKCess_Cut_By_Agent = decimal.Parse(txtKKCess.Text);
                Adjusted_Amount = decimal.Parse(txtAdjAmt.Text);
                Short_Excess = decimal.Parse(txtShortExcess.Text);
                if (chkHighValue.Checked == true)
                {
                    High_Value = 13;
                }
                else
                {
                    High_Value = 14;
                }

                Bank = txtBankName.Text;
                Bank_Branch = txtBranchName.Text;
                Cheque_No = txtCheque.Text;
                Cheque_Date = DateTime.Parse(FormatDateDD(txtDate.Text));
                Cheque_Deposit_Date = DateTime.Parse(FormatDateDD(txtDepositeDate.Text));
                string Account = ddlAccountName.SelectedItem.Text;
                string[] arr_Account = Account.Split('-');

                Account_Name = arr_Account[0];
                Account_No = arr_Account[1];
                Remarks = txtRemarks.Text;
                Status = 32;
                Entered_By = Session["EMailID"].ToString();
                Entered_On = DateTime.Now;
            }


            drPay.Close();
            cmd.Dispose();
                
           

            DataTable DT_CSR = dw.GetAllFromQuery("SELECT Payment_ID,Paid_Amount,Short_Excess_Amount,Amount_Including_TDS as Total_Payable_amt FROM CSR_Details WHERE CSR_Detail_ID='" + CSR_Detail_ID + "'");
            if (DT_CSR.Rows.Count > 0)
            {
                decimal Agent_Branch_Paid_amount = 0;
                existing_paymentid = DT_CSR.Rows[0]["Payment_ID"].ToString();
                existing_paidamt = decimal.Parse(DT_CSR.Rows[0]["Paid_Amount"].ToString());
                DataTable DT_AGENT_TOTAL = dw.GetAllFromQuery("SELECT SUM(PAID_AMOUNT) AS Paid_Amount FROM CSR_Details WHERE AGENT_ID='" + agent_id + "' AND AIRLINE_DETAIL_ID='" + var_Airline_Detail_ID + "' GROUP BY AIRLINE_DETAIL_ID");
                if (DT_AGENT_TOTAL.Rows.Count > 0)
                {
                    Agent_Branch_Paid_amount = decimal.Parse(DT_AGENT_TOTAL.Rows[0]["Paid_Amount"].ToString());
                }
                existing_short_excess = decimal.Parse(DT_CSR.Rows[0]["Short_Excess_Amount"].ToString());
                Total_Payable_amt = decimal.Parse(DT_CSR.Rows[0]["Total_Payable_amt"].ToString());
                Agent_Paid_Amount = Total_Paid_Amount + Agent_Branch_Paid_amount;
                //Agent_Paid_Amount = Total_Paid_Amount + existing_paidamt;
               
            }
            string Belongs_To_City = Arr_Airline[2];

            Trans=con.BeginTransaction();
            SqlCommand strcom = new SqlCommand("ADD_PAYMENT", con, Trans);
            strcom.CommandType = CommandType.StoredProcedure;

            strcom.Parameters.AddWithValue("@Belongs_To_City", Belongs_To_City);
            strcom.Parameters.AddWithValue("@Airline_Detail_ID", var_Airline_Detail_ID);
            strcom.Parameters.AddWithValue("@CSR_Detail_ID", CSR_Detail_ID);  
            strcom.Parameters.AddWithValue("@Agent_Paid_Amount", Agent_Paid_Amount);    
            strcom.Parameters.AddWithValue("@AGENT_ID", agent_id);
            strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
            strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
            strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
            strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
            strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
            strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
            strcom.Parameters.AddWithValue("@Total_Paid_Amount", Total_Paid_Amount);
            strcom.Parameters.AddWithValue("@Paid_Amount", Paid_Amount);
            strcom.Parameters.AddWithValue("@TDS_Cut_By_Agent", TDS_Cut_By_Agent);
            strcom.Parameters.AddWithValue("@Service_Tax_Cut_By_Agent", Service_Tax_Cut_By_Agent);
            strcom.Parameters.AddWithValue("@SB_Cess_Cut_By_Agent", SBCess_Cut_By_Agent);
            strcom.Parameters.AddWithValue("@KK_Cess_Cut_By_Agent", KKCess_Cut_By_Agent);
            strcom.Parameters.AddWithValue("@Adjusted_Amount", Adjusted_Amount);
            strcom.Parameters.AddWithValue("@Short_Excess", Short_Excess);
            strcom.Parameters.AddWithValue("@High_Value", High_Value);
            strcom.Parameters.AddWithValue("@Bank", Bank);
            strcom.Parameters.AddWithValue("@Bank_Branch", Bank_Branch);
            strcom.Parameters.AddWithValue("@Cheque_No", Cheque_No);
            strcom.Parameters.AddWithValue("@Cheque_Date", Cheque_Date);
            strcom.Parameters.AddWithValue("@Cheque_Deposit_Date", Cheque_Deposit_Date);
            strcom.Parameters.AddWithValue("@Account_Name", Account_Name);
            strcom.Parameters.AddWithValue("@Account_No", Account_No);
            strcom.Parameters.AddWithValue("@Remarks", Remarks);
            strcom.Parameters.AddWithValue("@Status", Status);
            strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
            strcom.Parameters.AddWithValue("@Entered_Date", Entered_On);
          
            
            strcom.ExecuteNonQuery();

            DataTable dt;
            dt = dw.GetAllFromQuery("select ident_current('Payment_Details') as Payment_ID");
            string add_Paymentid = dt.Rows[0]["Payment_ID"].ToString();



            if (existing_paymentid == "")
            {
                Final_Payment_ID =  add_Paymentid;
            }
            else
            {
                Final_Payment_ID = existing_paymentid + "," + add_Paymentid;
            }
            
            Final_Paid_Amount = existing_paidamt + Total_Paid_Amount;
            Final_short_excess = existing_short_excess + Short_Excess;
            //Final_Payment_ID = add_Paymentid;
            //Final_Paid_Amount = Total_Paid_Amount;
            //Final_short_excess = Short_Excess;
             
              if (Total_Payable_amt > Final_Paid_Amount)
              {
                  Paid_Status = 26;
              
              }
              else if (Total_Payable_amt <= Final_Paid_Amount)
                  {
                      Paid_Status = 27;
                  }
                  Update_CSR_Details(Trans, con, CSR_Detail_ID);

               
          


            Trans.Commit();
            lblMessage.Visible = true;
            lblMessage.Text = "Payment Details Entered Successfully";

            //con_str.Close();
            strcom.Dispose();
            con.Close();






        }

        catch (Exception sqe)
        {
            string err = sqe.ToString();
            Trans.Rollback();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void Update_CSR_Details(SqlTransaction tr, SqlConnection con, int CSR_Detail_ID)
    {
        
         string update;
         update = "Update CSR_Details set Payment_ID='" + Final_Payment_ID + "',Paid_Status='" + Paid_Status + "',Paid_Amount='" + Final_Paid_Amount + "',Short_Excess_Amount='" + Final_short_excess + "' where CSR_Detail_ID='" + CSR_Detail_ID + "' ";
        SqlCommand com1 = new SqlCommand(update, con, tr);
        com1.CommandType = CommandType.Text;
        com1.ExecuteNonQuery();
        
    }
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblMessage.Visible = false;
        Response.Redirect("addPayment.aspx");
    }

    protected void ddlAirlineName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAirlineName.SelectedValue == "0")
        {
            ddlAgentName.Items.Clear();
        }
        else
        {
            pnlShowDetails.Visible = false;
            btnShow.Visible = true;
            AgentDetails();
        }
       
    }

    protected void ddlCSR_SelectedIndexChanged(object sender, EventArgs e)
    {
        string CSRDetailID = ddlCSR.SelectedValue;
        DataTable DT_CSR = dw.GetAllFromQuery("SELECT Amount_Including_TDS as Total_Payable_amt,(Amount_Including_TDS-Paid_Amount) AS TOBE_PAID FROM CSR_Details WHERE CSR_Detail_ID='" + CSRDetailID + "'");
        if (DT_CSR.Rows.Count > 0)
        {
  
           //Hidden1.Value =DT_CSR.Rows[0]["Total_Payable_amt"].ToString();
            decimal TOBE_PAID = Math.Round(decimal.Parse(DT_CSR.Rows[0]["TOBE_PAID"].ToString()));
            Hidden1.Value = TOBE_PAID.ToString();


        }
        
    }
}
