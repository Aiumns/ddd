using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


///This Page is Design & Coding By Alok Date:18.11.2007
 ///<modified by>Shaikh Akhtar Rasool </modified>
/// <modifiedon>09-02-2008</modifiedon>
public partial class Agent_RateMaster_History : System.Web.UI.Page
{
    // Declare public variables here 
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt;
    DisplayWrap dw = new DisplayWrap();
    public string strAgent = "";
    /// <summary>
    /// Making Connection from web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            strAgent = "<script>var FillAgent=new Array(" + getAgentName() + ")</script>";
            Search();
        }

    }
    public string getAgentName()
    {
        string strAgentName = "";
        con = new SqlConnection(strCon);
        try
        {

            string selectGroupName = "SELECT distinct(Airline_Name) FROM Airline_Master";
            com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strAgentName == "")
                    strAgentName = "'" + Convert.ToString(dr["Airline_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strAgentName = strAgentName + "," + "'" + Convert.ToString(dr["Airline_Name"]).ToString().ToUpper().Trim() + "'";
            }
            dr.Close();
            com.Dispose();
            con.Close();


        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strAgentName;
    }
    // function for bind grid
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txtsearch.Text == "")
            {
                selectQ = "select Agent_Rate_ID,Agent_Rate_History_ID,Airline_Name,Shipment_Name,Special_Commodity_Name,Origin,Destination,Min,Normal,Freight_SurCharge,Security_SurCharge,XRay_Charges,convert(varchar,Valid_From,103) as 'valid_from',convert(varchar,Valid_To,103) as 'Valid_To',Status,Entered_By,convert(varchar,Entered_On,103) as 'Entered_On' from Agent_Rate_Master_History order by Airline_Name";
            }

            else
            {
                selectQ = "select Agent_Rate_ID,Agent_Rate_History_ID,Airline_Name,Shipment_Name,Special_Commodity_Name,Origin,Destination,Min,Normal,Freight_SurCharge,Security_SurCharge,XRay_Charges,convert(varchar,Valid_From,103) as 'valid_from',convert(varchar,Valid_To,103) as 'Valid_To',Status,Entered_By,convert(varchar,Entered_On,103) as 'Entered_On'from Agent_Rate_Master_History  where Airline_Name like '" + txtsearch.Text + "%' order by Airline_Name";
            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            dt = new DataTable();
            da.Fill(dt);
            grdAgRatemaster.DataSource = dt;
            grdAgRatemaster.DataBind();

        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void grdAgRatemaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdAgRatemaster.PageIndex = e.NewPageIndex;
        Search();
    }
    // Create By Shaikh Akhtar Rasool To Display Slabs in The Grid.


    protected void grdAgentRate_RowDataBound(object sender,
                    GridViewRowEventArgs e)
    {
        //check the item being bound is actually a DataRow, if it is, 
        //wire up the required html events and attach the relevant JavaScripts

        if (e.Row.RowType == DataControlRowType.DataRow)
        {


            GridViewRow GDrow = e.Row;

            Label lblAccess = (Label)e.Row.Cells[2].FindControl("Label1");
            //Label lable = (Label)GDrow.FindControl("Label1");  
            Int64 RateID = Convert.ToInt64(lblAccess.Text);
            DataTable DtSlab = dw.GetAllFromQuery("select  Slab_name as SlabName,Price_value as Price from agent_Slab_Rate_history where agent_rate_id=" + RateID + "");
            string tooltip = "";
            string table = "<table >";
            table += "<tr>";
            foreach (DataRow Drow in DtSlab.Rows)
            {
                tooltip += "" + Drow["SlabName"] + " : " + Drow["Price"] + "\n";
                table += "<td><table><tr><td class=boldtext>" + Drow["SlabName"] + "</td></tr><tr><td class=text>" + Drow["Price"] + "</td></tr></table></td>";

            }
            table += "</tr>";
            table += "</table>";
            //tooltip +="</table>";
            //if (flag >= 2)
            //{
            GDrow.Cells[4].Text = table;
            table = "";
            //GDrow.Cells[0].ToolTip = tooltip;
            //GDrow.Cells[0].ToolTip.ToUpper();


            //if (flag >= 2)
            //{
            //    GDrow.Cells[1].Text = "";
            //}
            //else
            //{
            //    flag = flag + 1;
            //}
            GDrow.Cells[2].ToolTip = tooltip;
            GDrow.Cells[2].ToolTip.ToUpper();

            //GDrow.Cells[2].ToolTip = "Click here to See Slab Rates";
            //GDrow.ToolTip = "Click On Show Slab to See Slab Rates";  
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    e.Row.Attributes["onmouseover"] =
            //        "javascript:setMouseOverColor(this);";
            //    e.Row.Attributes["onmouseout"] =
            //        "javascript:setMouseOutColor(this);";
            //    e.Row.Attributes["onclick"] =
            //    ClientScript.GetPostBackClientHyperlink
            //        (this.grdAgentRate, "Select$" + e.Row.RowIndex);
            //}
        }
    }





}
