﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class DestinationWiseDealShow : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    SqlCommand com;
    SqlDataReader red;
    SqlParameter pram;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    public string MainTab = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                lblmsg.Text = "";
                if (Request.QueryString.Count > 0)
                {
                    if (Session["msg"] != null)
                    {
                        lblmsg.Text = Session["msg"].ToString();
                        Session["msg"] = null;
                    }
                    else
                        lblmsg.Text = "";

                }

                ShowAirline();
            }

        }

    }

    public void ShowAirline()
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in(select distinct AirlineDetail_ID from FlightDiscounting) order by Airline_Name", con);
        con.Open();
        red = cmd.ExecuteReader();
        while (red.Read())
        {
            string table = "";
            SqlConnection con1 = new SqlConnection(strCon);
            SqlCommand cmdSlab = new SqlCommand("select s.slab_name,s.slab_id from slab_master s inner join airline_slab a on a.slab_id=s.slab_id where a.airline_detail_id='" + red["Airline_Detail_ID"].ToString() + "' order by s.slab_id", con1);
            con1.Open();
            SqlDataReader dr = cmdSlab.ExecuteReader();
            int i = 7;
            string slabHead = @"<td class=boldtext>Edit</td> <td class=boldtext>Del</td><td class=boldtext>FlightNo</td><td class=boldtext>Shipment</td>";
            while (dr.Read())
            {
                slabHead += @"<td class=boldtext> " + dr["slab_name"].ToString() + @"</td>";
                i++;
            }
            table += @"<table width=100%><tr> <td class=""h1"" align=center colspan=" + i + @">" + red["Airline"].ToString().ToUpper() + @"</td></tr><tr class=h5>" + slabHead + @"<td class=boldtext>Destinations</td><td class=boldtext> ValidFrom</td><td class=boldtext> validTo</td></tr>";
            dr.Dispose();
            cmdSlab.Dispose();
            cmdSlab = new SqlCommand("select distinct isnull(Flight_NO,'0')as flt,Shipment_Name,FD.Shipment_ID,Destination_Codes,validFrom ,Validto,FD.flight_ID,convert(varchar,validFrom,103)validFrom1, convert(varchar,Validto,103)Validto1 from FlightDiscounting FD left outer join Flight_master Fm on FM.flight_ID=FD.flight_ID inner join shipment_master sp on sp.Shipment_ID=FD.Shipment_ID where AirLineDetail_ID='" + red["Airline_Detail_ID"].ToString() + "'", con1);
            dr = cmdSlab.ExecuteReader();
            while (dr.Read())
            {

                table += @"<tr class=text><td><a href='DestinationWiseDeal.aspx?flt=" + dr["flight_ID"].ToString() + "&sid=" + dr["Shipment_ID"].ToString() + "&d=" + dr["Destination_Codes"].ToString() + "&vf=" + dr["validFrom"].ToString() + "&vt=" + dr["validto"].ToString() + "&aid=" + red["Airline_Detail_ID"].ToString() + "&f=u" + @"'><img  src=""images/edit.gif"" border=""0""  /> </a></td><td><a href='FlightDiscounting.aspx?flt=" + dr["flight_ID"].ToString() + "&sid=" + dr["Shipment_ID"].ToString() + "&d=" + dr["Destination_Codes"].ToString() + "&vf=" + dr["validFrom"].ToString() + "&vt=" + dr["validto"].ToString() + "&aid=" + red["Airline_Detail_ID"].ToString() + "&f=d" + @"'><img src=""images/cross.gif"" border=""0""  /> </a></td><td>" + (dr["flt"].ToString() == "0" ? "All Flights" : dr["flt"].ToString()) + @"</td> <td>" + dr["Shipment_Name"].ToString() + @"</td>";
                SqlConnection con2 = new SqlConnection(strCon);
                con2.Open();
                // read slab id and fetch discounted value..
                SqlCommand cmdSlabID = new SqlCommand("select s.slab_name,s.slab_id from slab_master s inner join airline_slab a on a.slab_id=s.slab_id where a.airline_detail_id='" + red["Airline_Detail_ID"].ToString() + "' order by s.slab_id", con2);
                SqlDataReader drSlabID = cmdSlabID.ExecuteReader();
                while (drSlabID.Read())
                {
                    SqlConnection con3 = new SqlConnection(strCon);
                    con3.Open();

                    SqlCommand cmd3 = new SqlCommand("select slab_ID,PreFix_ID,Discounted_Value from FlightDiscounting where airlineDetail_ID='" + red["Airline_Detail_ID"].ToString() + "' and flight_ID='" + (dr["flight_ID"].ToString() == null ? "0" : dr["flight_ID"].ToString()) + "' and Shipment_ID='" + dr["Shipment_ID"].ToString() + "' and Destination_Codes='" + dr["Destination_Codes"].ToString() + "' and validFrom='" + DateTime.Parse(dr["validFrom"].ToString()) + "' and Validto='" + DateTime.Parse(dr["Validto"].ToString()) + "' and slab_ID='" + drSlabID["slab_id"].ToString() + "' order by slab_ID", con3);
                    SqlDataReader dr3 = cmd3.ExecuteReader();

                    if (dr3.HasRows)
                    {
                        while (dr3.Read())
                        {
                            table += @"<td class=text>" + dr3["Discounted_Value"].ToString() + @"</td>";

                        }
                        dr3.Dispose();
                        cmd3.Dispose();
                        con3.Close();
                    }
                    else
                    {
                        // table += @"<td class=text>nahi_hai</td>";
                        table += @"<td class=text>0.00</td>";

                    }
                }
                drSlabID.Dispose();
                cmdSlabID.Dispose();
                con2.Close();

                //end read slab id and fetch discounted value..
                // SqlCommand cmd2 = new SqlCommand("select slab_ID,PreFix_ID,Discounted_Value from FlightDiscounting where airlineDetail_ID='" + red["Airline_Detail_ID"].ToString() + "' and flight_ID='" + (dr["flight_ID"].ToString() == null ? "0" : dr["flight_ID"].ToString()) + "' and Shipment_ID='" + dr["Shipment_ID"].ToString() + "' and Destination_Codes='" + dr["Destination_Codes"].ToString() + "' and validFrom='" + DateTime.Parse(dr["validFrom"].ToString()) + "' and Validto='" + DateTime.Parse(dr["Validto"].ToString()) + "' order by slab_ID", con2);              
                // SqlDataReader dr2 = cmd2.ExecuteReader();                
                ////while (dr2.Read())
                ////{
                ////    table += @"<td class=text>" + dr2["Discounted_Value"].ToString() + @"</td>";

                ////}
                // dr2.Dispose();
                // cmd2.Dispose();
                //  con2.Close();
                table += @"<td>" + dr["Destination_Codes"].ToString() + @"</td><td>" + dr["validFrom1"].ToString() + @"</td> <td>" + dr["validto1"].ToString() + @"</td></tr>";


            }
            dr.Dispose();
            cmdSlab.Dispose();
            MainTab += table;
        }
        red.Dispose();
        cmd.Dispose();
        con.Close();
        Label1.Text = MainTab;

    }
}
