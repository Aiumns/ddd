using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//Created by Rakhi on 21 Oct 2007
public partial class Airline_Details : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Search();
        }
    }

    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Airlines_Details_Add1.aspx");
    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try
        {

            string selectQ = null;
            if (txtsearch.Text == "")
            {
                //selectQ = "SELECT  ad.Airline_Detail_Id,am.Airline_Name, cm.City_Name, ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged,ad.WarSurcharge_On,cb.Branch_Name, ad.DisBursementCharges,ad.Deal,sm.Status_Name FROM  Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN Company_Branch cb ON ad.Company_Branch_ID = cb.Company_Branch_ID INNER JOIN Status_Master sm ON cb.Status = sm.Status_ID INNER JOIN City_Master cm ON am.Airline_ID = cm.City_ID ";
                selectQ = "SELECT ad.Airline_Detail_ID,am.Airline_Name,am.Airline_Code, cm.City_Name,cmp.Company_Name, ad.DisBursementCharges,ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged, ad.WarSurcharge_On, ad.XRayCharge_Charged, ad.XRayCharge_On,ad.Deal, ad.AWB_Fees, ad.ACI_Fees, sm.Status_Name FROM  Airline_Detail ad inner join Airline_Master am on ad.Airline_ID=am.Airline_ID inner join City_Master cm on ad.Belongs_To_City=cm.City_Id inner join Company_Master cmp on ad.Company_ID=cmp.Company_ID inner join Status_Master sm on ad.Status=sm.Status_ID order by  am.Airline_Name";//where sm.Status_Name in('Active','Inactive')";               
            }

            else
            {
                //selectQ = "SELECT  ad.Airline_Detail_Id,am.Airline_Name, cm.City_Name, ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged,ad.WarSurcharge_On,cb.Branch_Name, ad.DisBursementCharges,ad.Deal,sm.Status_Name FROM  Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN Company_Branch cb ON ad.Company_Branch_ID = cb.Company_Branch_ID INNER JOIN Status_Master sm ON cb.Status = sm.Status_ID INNER JOIN City_Master cm ON am.Airline_ID = cm.City_ID and am.Airline_Name like " + "'" + txtsearch.Text + "%'";
                //selectQ = "SELECT am.Airline_Name, cm.City_Name, ad.DisBursementCharges, ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged, ad.WarSurcharge_On, ad.XRayCharge_Charged, ad.XRayCharge_On, ad.AWB_Fees, ad.ACI_Fees, cmp.Company_Name, ad.Deal, sm.Status_Name FROM  Airline_Detail ad INNER JOIN Airline_Master am ON ad.Airline_ID = am.Airline_ID INNER JOIN Company_Master cmp ON ad.Company_ID = cmp.Company_ID INNER JOIN Status_Master sm ON ad.Status = sm.Status_ID INNER JOIN City_Master cm ON ad.Belongs_To_City = cm.City_ID  and am.Airline_Name like " + "'" + txtsearch.Text + "%'";
                selectQ = "SELECT ad.Airline_Detail_ID,am.Airline_Name,am.Airline_Code,cm.City_Name,cmp.Company_Name, ad.DisBursementCharges,ad.FreightSurCharge_Charged, ad.FreightSurCharge_On,ad.WarSurCharge_Charged, ad.WarSurcharge_On, ad.XRayCharge_Charged, ad.XRayCharge_On,ad.Deal, ad.AWB_Fees, ad.ACI_Fees, sm.Status_Name FROM  Airline_Detail ad inner join Airline_Master am on ad.Airline_ID=am.Airline_ID inner join City_Master cm on ad.Belongs_To_City=cm.City_Id inner join Company_Master cmp on ad.Company_ID=cmp.Company_ID inner join Status_Master sm on ad.Status=sm.Status_ID where sm.Status_Name in('Active','Inactive') and am.Airline_Name like " + "'" + txtsearch.Text + "%' ";                
            }

            com = new SqlCommand(selectQ, con);
            da = new SqlDataAdapter(com);
            ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Search();
    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        GridView1.PageIndex = e.NewSelectedIndex;
        Search();
    }
    protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Search();
    }
}
