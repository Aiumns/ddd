using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class BookingEnquiry_AgentDetails : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
         if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else if (!IsPostBack)
        {
            Search();
        }
    }
    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Booking_Enquiry.aspx");
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        dr.Close();
        return Access;
    }
    public void Search()
    {
        con = new SqlConnection(strCon);
        con.Open();
        string strAirline_Access = Rights();
        try
        {

            string selectQ = null;
            DataTable dtAgentID = dw.GetAllFromQuery("select a.agent_name as agent_name,a.agent_id as Agent_id,b.belongs_to_city as belongs_to_city from Agent_Master a inner join Agent_Branch b on a.Agent_ID = b.Agent_ID where b.Agent_Branch_ID=" + Session["ID"].ToString());
            if (dtAgentID.Rows.Count > 0)
            {
                if (txtsearch.Text == "")
                {
                    selectQ = "SELECT BE.Booking_EnquiryNo as Booking_EnquiryNo,BE.Airline_Detail_Id as Airline_Detail_Id,AM.Airline_name as Airline_name,BE.Dest_code as dest_code,BE.Gross_Weight as Gross_Weight,BE.Volume_Weight,BE.No_of_Packages as No_of_Packages,BE.Commodity as Commodity,convert(varchar,BE.Handover_date,103) as Handover_date,BE.Remarks as Remarks FROM Booking_Enquiry BE Inner join Airline_Detail AD on AD.Airline_detail_id=BE.Airline_Detail_ID inner join Airline_Master AM on Am.Airline_ID=AD.Airline_ID where Agent_id='" + dtAgentID.Rows[0]["Agent_ID"].ToString() + "' and BE.City='" + dtAgentID.Rows[0]["belongs_to_city"].ToString() + "' and AD.Airline_Detail_ID in(" + strAirline_Access + ") order By  Airline_Name";
                }

                else
                {
                    selectQ = "SELECT BE.Booking_EnquiryNo as Booking_EnquiryNo,BE.Airline_Detail_Id as Airline_Detail_Id,AM.Airline_name as Airline_name,BE.Dest_code as dest_code,BE.Gross_Weight as Gross_Weight,BE.Volume_Weight,BE.No_of_Packages as No_of_Packages,BE.Commodity as Commodity,convert(varchar,BE.Handover_date,103) as Handover_date,BE.Remarks as Remarks FROM Booking_Enquiry BE Inner join Airline_Detail AD on AD.Airline_detail_id=BE.Airline_Detail_ID inner join Airline_Master AM on Am.Airline_ID=AD.Airline_ID where Agent_id='" + dtAgentID.Rows[0]["Agent_ID"].ToString() + "' and BE.City='" + dtAgentID.Rows[0]["belongs_to_city"].ToString() + "' and Dest_code like '" + txtsearch.Text + "%' and AD.Airline_Detail_ID in(" + strAirline_Access + ") order By  Airline_Name";
                }

                com = new SqlCommand(selectQ, con);
                SqlDataAdapter da = new SqlDataAdapter(com);
                DataSet ds = new DataSet();
                da.Fill(ds);
                grdBookingEnquiry.DataSource = ds;
                grdBookingEnquiry.DataBind();
                con.Close();
            }
        }
        catch (SqlException ex)
        {
            string err = ex.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();

    }
}
