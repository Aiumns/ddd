using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AllocationSpace : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        datacity.ConnectionString = strCon;
        if (!IsPostBack)
        {
            FillAlocation();
        }

    }
    public void FillAlocation()
    {

        con = new SqlConnection(strCon);
        cmd = new SqlCommand("Alc_FillAllocation", con);
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        ddlcity.Items.Add("Select City");
        ddlcity.Items[0].Value = "";
        while (dr.Read())
        {
            ddlcity.Items.Add(new ListItem(dr["city_code"].ToString(), dr["city_id"].ToString()));
        }
        cmd.Dispose();
        dr.Dispose();
        con.Close();

    }
    public DataTable maketable()
    {
        DataTable dt = new DataTable();
        DataColumn dc1 = new DataColumn("Sno", typeof(Int32));
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        dc1.AutoIncrementSeed = 1;
        dt.Columns.Add(dc1);

        DataColumn dc2 = new DataColumn("City", typeof(String));
        dt.Columns.Add(dc2);

        DataColumn dc3 = new DataColumn("Allocation", typeof(String));
        dt.Columns.Add(dc3);

        DataRow dr = dt.NewRow();

        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dt.Rows.Add(dr);
        return dt;
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        Session["dthold"] = maketable();
        DataTable dt = (DataTable)Session["dthold"];
        grdAllocation.DataSource = (DataTable)Session["dthold"];
        grdAllocation.DataBind();
        grdAllocation.Rows[0].Visible = false;
        string strcity = ddlcity.SelectedItem.Text;
        //GridViewRow gvrallocation = grdAllocation.FooterRow;
        //DropDownList ddlAllocations = (ListBox)gvrallocation.Cells[0].FindControl("ddlAllocation");


    }
    protected void grdAllocation_PreRender(object sender, EventArgs e)
    {

    }
    protected void grdAllocation_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {

    }
    protected void grdAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }

    protected void grdAllocation_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {

    }
    protected void grdAllocation_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void grdAllocation_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
   
}
