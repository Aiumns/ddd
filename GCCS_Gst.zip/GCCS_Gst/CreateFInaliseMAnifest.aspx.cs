﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Text;


public partial class CreateFInaliseMAnifest : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string Entered_By;
    DateTime Entered_On;
    StringBuilder strtable = new StringBuilder();

    string fno = "";
    string date = "";
    string Air_code = "";
    string CITY_ID = "";
    string Flight_Open_Id = "";
    string Air_Detail_Id = "";
    string FLIGHT_DATE = "";
    string strCon = ConfigurationManager.ConnectionStrings["gccs"].ConnectionString;
    string postback;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            string url = Request.Url.Query;
            hdnQuery.Value = url.Substring(1, url.Length - 1);
            hdnemail.Value = Session["EMailID"].ToString();

            btnFinalise.Attributes.Add("onclick", "return checkUlddata();return false;");
            btnoffloaduld.Attributes.Add("onclick", "return ReturnUld();return false;");
            // btnReturn_hnd.Attributes.Add("onclick", "return chkhanddata();return false;");
            btnofflodbulk.Attributes.Add("onclick", "return ReturnBulk();return false");

            FillDetails();

        }


    }


    public void FillDetails()
    {
        try
        {

            Air_code = Request.QueryString["Airline_code"];
            CITY_ID = Request.QueryString["city_id"];
            Flight_Open_Id = Request.QueryString["fid"];
            hdnFlight_open_ID.Value = Flight_Open_Id;
            Air_Detail_Id = Request.QueryString["AID"];
            FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
            date = Request.QueryString["date"];
            fno = Request.QueryString["fno"];
            string uld_id_old = "";
            string uld_id_new = "";
            string Package = "";
            int pcs = 0;
            int k = 0;
            string rowcolor = "";
            int TotalPCs = 0;
            decimal TotalGwt = 0;
            int GrandTotal = 0;
            decimal GrandTotalGrWt = 0;





            btnprint.Attributes.Add("onclick", "javascript:window.open('Finalisemainefest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes');return false;");
            btnshipingmanifest.Attributes.Add("onclick", "javascript:window.open('ShippingBillManifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id + "',null,'left=162px, top=134px, width=1050px, height=800px, status=yes,resizable= yes, scrollbars=yes, toolbar=yes,minimize=yes,location=yes, menubar=yes');return false;");
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("MAnifest_Checklist", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FLIGHT_OPEN_ID", SqlDbType.Int).Value = Convert.ToInt32(Flight_Open_Id);
            SqlDataAdapter daCheck = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            daCheck.Fill(ds);
            DataTable dt_Check = new DataTable();
            dt_Check = ds.Tables[0];
            DataTable dt_CheckFinalise = new DataTable();
            dt_CheckFinalise = ds.Tables[1];
            if (Convert.ToInt32(dt_Check.Rows[0]["checkNo"].ToString()) > 0)
            {
                hdnpfmexist.Value = "Yes";
                //btnFinalise.Visible=false;
                //btnoffloaduld.Visible=false;
                //btnofflodbulk.Visible=false;

            }
            else
            {
                hdnpfmexist.Value = "NO";
            }
            if (Convert.ToInt32(dt_CheckFinalise.Rows[0]["checkUld"].ToString()) == 0)
            {
                btnFinalise.Visible = false;
                btnoffloaduld.Visible = false;
                btnofflodbulk.Visible = false;

            }


            com = new SqlCommand("MAnifest_getlist", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FLIGHT_OPEN_ID", SqlDbType.Int).Value = Convert.ToInt32(Flight_Open_Id);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt_Hand = new DataTable();
            da.Fill(dt_Hand);

            com = new SqlCommand("EGM_getlist", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FLIGHT_OPEN_ID", SqlDbType.Int).Value = Convert.ToInt32(Flight_Open_Id);
            SqlDataAdapter daegm = new SqlDataAdapter(com);
            DataTable dt_Egm = new DataTable();
            daegm.Fill(dt_Egm);

            com = new SqlCommand("Airline_Name", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FLIGHT_OPEN_ID", SqlDbType.Int).Value = Convert.ToInt32(Flight_Open_Id);
            SqlDataAdapter da1 = new SqlDataAdapter(com);
            DataTable dt_Hand1 = new DataTable();
            da1.Fill(dt_Hand1);

            com = new SqlCommand("Get_Flight_Details", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@FLIGHT_OPEN_ID", SqlDbType.Int).Value = Convert.ToInt32(Flight_Open_Id);
            SqlDataAdapter daflight = new SqlDataAdapter(com);
            DataTable dt_Handflight = new DataTable();
            daflight.Fill(dt_Handflight);


            if (dt_Hand.Rows.Count > 0)
            {

                uld_id_old = dt_Hand.Rows[0]["ULD_No"].ToString();
                strtable.Append("<div id='mainprint'><table width=100% border=0 cellspacing=0 cellpadding=0 id=tdPadding ><tr class=MainHeader><td colspan=10 align=center >" + dt_Hand1.Rows[0]["Airline_Name"].ToString() + "</td></tr>");


                if (dt_Egm.Rows.Count > 0)
                {

                    strtable.Append(@"<tr class=HeaderStyle2><td colspan=2></td><td  nowrap>Owner or Operator  :</td><td colspan=2>" + dt_Hand1.Rows[0]["Airline_Name"].ToString() + " </td><td >EGM : </td><td colspan=4><input type=text size=50px name=txt style='font-size: 11px; color: black;'  id=txtegmno value=" + dt_Egm.Rows[0]["EGM_No"].ToString() + " Disabled > </td></tr>");
                    strtable.Append(@"<tr class=HeaderStyle2><td colspan=2></td><td  nowrap colspan=9>Marks of Nationality and Registration: <input type=text size=50px style='font-size: 11px; color: black;' name=txt value=" + dt_Egm.Rows[0]["Nationality_And_Registration"].ToString() + "  id=txtMarksOfNamtionality Disabled ></td></tr>");
                }

                else
                {

                    strtable.Append(@"<tr class=HeaderStyle2><td colspan=2></td><td  nowrap>Owner or Operator  :</td><td colspan=2>" + dt_Hand1.Rows[0]["Airline_Name"].ToString() + " </td><td >EGM : </td><td colspan=4><input type=text size=25px name=txt  id=txtegmno></td></tr>");
                    strtable.Append(@"<tr class=HeaderStyle2><td colspan=2></td><td  nowrap colspan=9>Marks of Nationality and Registration: <input type=text size=25px name=txt  id=txtMarksOfNamtionality></td></tr>");

                }
                strtable.Append(@"<tr class=HeaderStyle2><td colspan=2></td><td  nowrap>FLT NO :</td><td>" + dt_Handflight.Rows[0]["Flight_No"].ToString() + " </td><td></td><td></td><td></td><td></td><td  nowrap>DATE : </td><td nowrap>" + dt_Hand.Rows[0]["FLIGHT_DATE"].ToString() + "</td></tr>");
                strtable.Append(@"<tr class=HeaderStyle2><td colspan=2></td><td  nowrap>Point of lading:</td><td>" + dt_Handflight.Rows[0]["origin"].ToString() + " </td><td></td><td></td><td></td><td></td><td  nowrap>Point of unlading: </td><td>" + dt_Handflight.Rows[0]["destination"].ToString() + "</td></tr>");

                strtable.Append(@"<tr class=HeaderStyle2><td colspan=2></td><td  nowrap rowspan=2>Airway Bill NO.</td><td  nowrap rowspan=2>Number of Packages</td><td  nowrap rowspan=2>Nature of Goods</td><td></td><td  nowrap colspan=4>For use by Owner Operator only</td></tr><tr class=HeaderStyle2><td></td><td></td><td></td><td  nowrap >Spcl</td><td  nowrap >Gross Wt</td><td  nowrap>Final Dstn</td><td>S.B.No.</td></tr>");
                strtable.Append(@"<tr class=HeaderStyle2><td><input id='chkTopicAll' name='checkallmain' type='checkbox' onclick='javascript:AllCheck(this);'/></td><td colspan=10 align=left >Select All</td></tr>");

                if (dt_Hand.Rows[0]["CargoType"].ToString() == "U")
                {
                    if (dt_Hand.Rows[0]["Finalise"].ToString() == "14")
                    {

                        strtable.Append(@"<tr ><td  align=left  colspan=2 style='background: pink; font-size:15px;font-family:bold;'> <input id='chkTopicAll" + Regex.Replace(dt_Hand.Rows[0]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' name='checkall' type='checkbox' onclick='javascript:checkboxcheck(this.id);' value='" + dt_Hand.Rows[0]["ULD_No"].ToString() + "' /> " + uld_id_old + "<span id='CargoType" + Regex.Replace(dt_Hand.Rows[0]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' style='visibility: hidden;'>U</span> </td><td><input id='chkupdateuld" + Regex.Replace(dt_Hand.Rows[0]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' name='checkuld' type='checkbox' onclick='javascript:showuldcontrol(this.id);' value='" + dt_Hand.Rows[0]["ULD_No"].ToString() + "' />Update ULD NO</td><td><input type=text size=25px name=txtupdate  id='txtuldnew" + Regex.Replace(dt_Hand.Rows[0]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "'  Class=uppercase></td><td><button type=button name=btnupdate id='btnupdate" + Regex.Replace(dt_Hand.Rows[0]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' onclick='javascript:UpdateULD(this.id);' >Update</button></td><td colspan=5></td></tr>");
                    }
                    else
                    {
                        strtable.Append(@"<tr ><td  align=left  colspan=10 style='background: pink; font-size:15px;font-family:bold;'>" + uld_id_old + " <span id='CargoType" + Regex.Replace(dt_Hand.Rows[0]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' style='visibility: hidden;'>U</span> </td></tr>");

                    }
                }
                for (int i = 0; i < dt_Hand.Rows.Count; i++)
                {
                    rowcolor = dt_Hand.Rows[i]["Finalise"].ToString() == "13" ? " PeachPuff" : "LightBlue";

                    uld_id_new = dt_Hand.Rows[i]["ULD_No"].ToString();


                    pcs = int.Parse(dt_Hand.Rows[i]["TotalPkg"].ToString()) - int.Parse(dt_Hand.Rows[i]["No_of_Packages"].ToString());

                    if (pcs == 0)
                        Package = dt_Hand.Rows[i]["No_of_Packages"].ToString();
                    else
                        Package = dt_Hand.Rows[i]["No_of_Packages"].ToString() + "/" + dt_Hand.Rows[i]["TotalPkg"].ToString();




                    if (dt_Hand.Rows[i]["CargoType"].ToString() == "B")
                    {

                        k++;
                        if (k == 1)
                        {
                            GrandTotal += TotalPCs;
                            GrandTotalGrWt += TotalGwt;
                            strtable.Append(@"<tr><td colspan=3>Total</td><td colspan=1 align=left>" + TotalPCs + "</td><td colspan=3>&nbsp;</td><td align=right>" + TotalGwt.ToString("0.00") + "</td><td colspan=2></td></tr><tr><td colspan=10>&nbsp;</td></tr><tr ><td  align=left  colspan=10 style='background: pink; font-size:15px;font-family:bold;'>Bulk Cargo</td></tr>");

                            TotalPCs = 0;
                            TotalGwt = 0;
                        }
                        TotalPCs += Convert.ToInt32(dt_Hand.Rows[i]["No_of_Packages"].ToString());
                        TotalGwt += Math.Round(decimal.Parse(dt_Hand.Rows[i]["Gross_Weight"].ToString()), 2);
                        if (dt_Hand.Rows[i]["Finalise"].ToString() == "14")
                        {


                            strtable.Append(@"<tr style='background:" + rowcolor + "'><td><input id='chkTopicAll" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' name='checkall' type='checkbox' onclick='javascript:checkboxcheck(this.id);' value='" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' /> <span id='CargoType" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' style='visibility: hidden;'>B</span></td><td> <button id=btnpfm" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " value=" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " onclick='javascript:PfmReturn(this.id);'>Return To Pfm</button> </td><td>" + dt_Hand.Rows[i]["AirWayBill_No"].ToString() + "</td><td><span id='lblpkgpart" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' >" + Package + "</span><span id='lbl" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' style='visibility: hidden;' >" + dt_Hand.Rows[i]["No_of_Packages"].ToString() + "</span><span id='lbluid" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' style='visibility: hidden;'>" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "</span><span id='lblpart" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' style='visibility: hidden;'></span></td><td>" + dt_Hand.Rows[i]["Nature_and_Quantity"].ToString() + "</td><td><span id=RadioButtonList" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " class=radioButtonList vertical><input id=RadioButtonListyes" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " name=RadioButtonList" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " type=radio onclick='javascript:RadioeventYes(this.id);' value=0 tabindex=0 /><label for=RadioButtonListyes'" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "'>Yes</label><span><input id=RadioButtonListno" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " name=RadioButtonList" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " type=radio onclick='javascript:RadioeventNo(this.id);' value=1 checked tabindex=0 /><label for=RadioButtonListno" + dt_Hand.Rows[i]["ULD_ID"].ToString() + ">No</label></span></br><input type=text size=5px name=textbox onblur='javascript:showpartpcs(this.id);' id=txt" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "><span  name=lable id='lblpartpcs" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "'></span> <span id='lblpartial" + dt_Hand.Rows[i]["ULD_ID"].ToString() + "' style='visibility: hidden;'>" + dt_Hand.Rows[i]["partpackage"].ToString() + "</span></td><td>&nbsp;</td><td align=right>" + dt_Hand.Rows[i]["Gross_Weight"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Destination_Code"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Shipping_Bill_No"].ToString() + "</td></tr>");
                        }
                        else
                        {
                            strtable.Append(@"<tr style='background:" + rowcolor + "'><td></td><td></td><td>" + dt_Hand.Rows[i]["AirWayBill_No"].ToString() + "</td><td>" + Package + "</td><td>" + dt_Hand.Rows[i]["Nature_and_Quantity"].ToString() + "</td><td></td><td>&nbsp;</td><td align=right>" + dt_Hand.Rows[i]["Gross_Weight"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Destination_Code"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Shipping_Bill_No"].ToString() + "</td></tr>");

                        }

                    }


                    else
                    {

                        if (uld_id_old != uld_id_new)
                        {


                            if (dt_Hand.Rows[i]["Finalise"].ToString() == "14")
                            {
                                GrandTotal += TotalPCs;
                                GrandTotalGrWt += TotalGwt;

                                strtable.Append(@"<tr><td colspan=3>Total</td><td colspan=1 align=left>" + TotalPCs + "</td><td colspan=3>&nbsp;</td><td align=right>" + TotalGwt.ToString("0.00") + "</td><td colspan=2></td></tr><tr><td colspan=10>&nbsp;</td></tr><tr ><td  align=left  colspan=2 style='background: pink; font-size:15px;font-family:bold;'> <input id='chkTopicAll" + Regex.Replace(dt_Hand.Rows[i]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' name='checkall' type='checkbox' onclick='javascript:checkboxcheck(this.id);' value='" + dt_Hand.Rows[i]["ULD_No"].ToString() + "' /> " + uld_id_new + " <span id='CargoType" + Regex.Replace(dt_Hand.Rows[i]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' style='visibility: hidden;'>U</span></td><td><input id='chkupdateuld" + Regex.Replace(dt_Hand.Rows[i]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' name='checkuld' type='checkbox' onclick='javascript:showuldcontrol(this.id);' value='" + dt_Hand.Rows[i]["ULD_No"].ToString() + "' />Update ULD NO</td><td><input type=text size=25px name=txtupdate  id='txtuldnew" + Regex.Replace(dt_Hand.Rows[i]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' Class=uppercase ></td><td><button type=button name=btnupdate id='btnupdate" + Regex.Replace(dt_Hand.Rows[i]["ULD_No"].ToString(), @"[\[\]\ \\^\$\.\|\?\*\+\(\)\{\}%,;><!@#&\-\+=]", "") + "' onclick='javascript:UpdateULD(this.id);'>Update</button></td><td colspan=5></td></tr>");

                                TotalPCs = 0;
                                TotalGwt = 0;
                            }
                            else
                            {
                                GrandTotal += TotalPCs;
                                GrandTotalGrWt += TotalGwt;
                                strtable.Append(@"<tr><td colspan=3>Total</td><td colspan=1 align=left>" + TotalPCs + "</td><td colspan=3>&nbsp;</td><td align=right>" + TotalGwt.ToString("0.00") + "</td><td colspan=2></td></tr><tr><td colspan=10>&nbsp;</td></tr><tr ><td  align=left  colspan=9 style='background: pink; font-size:15px;font-family:bold;'>" + uld_id_new + " <span id='CargoType" + dt_Hand.Rows[i]["ULD_No"].ToString() + "' style='visibility: hidden;'>U</span></td></tr>");

                                TotalPCs = 0;
                                TotalGwt = 0;
                            }

                            uld_id_old = uld_id_new;
                        }

                        if (dt_Hand.Rows[i]["Finalise"].ToString() == "14")
                        {

                            strtable.Append(@"<tr style='background:" + rowcolor + "'><td></td><td><button id=btnpfm" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " value=" + dt_Hand.Rows[i]["ULD_ID"].ToString() + " onclick='javascript:PfmReturn(this.id);'>Return To Pfm</button></td><td>" + dt_Hand.Rows[i]["AirWayBill_No"].ToString() + "</td><td>" + Package + "</td><td>" + dt_Hand.Rows[i]["Nature_and_Quantity"].ToString() + "</td><td></td><td>&nbsp;</td><td align=right>" + dt_Hand.Rows[i]["Gross_Weight"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Destination_Code"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Shipping_Bill_No"].ToString() + "</td></tr>");
                        }
                        else
                        {
                            strtable.Append(@"<tr style='background:" + rowcolor + "'><td></td><td></td><td>" + dt_Hand.Rows[i]["AirWayBill_No"].ToString() + "</td><td>" + Package + "</td><td>" + dt_Hand.Rows[i]["Nature_and_Quantity"].ToString() + "</td><td></td><td>&nbsp;</td><td align=right>" + dt_Hand.Rows[i]["Gross_Weight"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Destination_Code"].ToString() + "</td><td>" + dt_Hand.Rows[i]["Shipping_Bill_No"].ToString() + "</td></tr>");
                        }
                        TotalPCs += Convert.ToInt32(dt_Hand.Rows[i]["No_of_Packages"].ToString());
                        TotalGwt += Math.Round(decimal.Parse(dt_Hand.Rows[i]["Gross_Weight"].ToString()), 2);



                    }
                }
                GrandTotal += TotalPCs;
                GrandTotalGrWt += TotalGwt;
                strtable.Append(@"<tr><td colspan=3>Total</td><td colspan=1 align=left>" + TotalPCs + "</td><td colspan=3>&nbsp;</td><td align=right>" + TotalGwt.ToString("0.00") + "</td><td colspan=2></td></tr><tr><td colspan=10></td></tr><tr class=FinalTotal><td colspan=3>GrandTotal</td><td colspan=1 align=left>" + GrandTotal + "</td><td colspan=3>&nbsp;</td><td align=right>" + GrandTotalGrWt.ToString("0.00") + "</td><td colspan=2></td></tr></table></div>");
                lblmanifest.Text = strtable.ToString();
            }
            else
            {
                btnprint.Visible = false;
                btnReturn_hnd.Visible = false;
                btnFinalise.Visible = false;
                troffload.Visible = false;

                lblmanifest.Text = "No Data for Finalise";

            }


        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();


        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void btnFinalise_Click(object sender, EventArgs e)
    {
        Air_code = Request.QueryString["Airline_code"];
        CITY_ID = Request.QueryString["city_id"];
        Flight_Open_Id = Request.QueryString["fid"];
        Air_Detail_Id = Request.QueryString["AID"];
        FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
        date = Request.QueryString["date"];
        fno = Request.QueryString["fno"];
        Response.Redirect("CreateFInaliseMAnifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id);
    }
    protected void btnReturn_hnd_Click(object sender, EventArgs e)
    {
        Air_code = Request.QueryString["Airline_code"];
        CITY_ID = Request.QueryString["city_id"];
        Flight_Open_Id = Request.QueryString["fid"];
        Air_Detail_Id = Request.QueryString["AID"];
        FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
        date = Request.QueryString["date"];
        fno = Request.QueryString["fno"];
        Response.Redirect("CreateFInaliseMAnifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id);
    }
    protected void btnoffloaduld_Click(object sender, EventArgs e)
    {
        Air_code = Request.QueryString["Airline_code"];
        CITY_ID = Request.QueryString["city_id"];
        Flight_Open_Id = Request.QueryString["fid"];
        Air_Detail_Id = Request.QueryString["AID"];
        FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
        date = Request.QueryString["date"];
        fno = Request.QueryString["fno"];
        Response.Redirect("CreateFInaliseMAnifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id);
    }
    protected void btnofflodbulk_Click(object sender, EventArgs e)
    {
        Air_code = Request.QueryString["Airline_code"];
        CITY_ID = Request.QueryString["city_id"];
        Flight_Open_Id = Request.QueryString["fid"];
        Air_Detail_Id = Request.QueryString["AID"];
        FLIGHT_DATE = DateTime.Now.ToString("MM/dd/yyyy");
        date = Request.QueryString["date"];
        fno = Request.QueryString["fno"];
        Response.Redirect("CreateFInaliseMAnifest.aspx?fno=" + fno + "&city_id=" + CITY_ID + "&date=" + date + "&Airline_code=" + Air_code + "&fid=" + Flight_Open_Id + "&AID=" + Air_Detail_Id);

    }
}
