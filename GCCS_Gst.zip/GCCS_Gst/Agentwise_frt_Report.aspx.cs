using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 

public partial class Agentwise_frt_Report : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        String airline_access = Session["AIRLINEACCESS"].ToString();
        Btnload.Attributes.Add("onclick", "return CheckEmpty();");

        if (!IsPostBack)
        {
            txtValidFrom.Text = "01" + "/" + DateTime.Now.ToString("MM/yyyy");
            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            try
            {
                con = new SqlConnection(strCon);
                con.Open();
                cmd = new SqlCommand("select airline_name,airline_detail_id,Belongs_To_City,City_Name,Airline_Code from airline_master am inner join airline_detail ad  on  ad.airline_id =am.airline_id INNER JOIN city_master ON Belongs_To_City=City_ID where ad.airline_Detail_id in (" + airline_access + ") order by airline_name", con);
                dr = cmd.ExecuteReader();
                ddlairlines.Items.Add("Select Airline Name");
                ddlairlines.Items[0].Value = "";
                while (dr.Read())
                {
                    ddlairlines.Items.Add(new ListItem(Convert.ToString(dr["airline_name"]) + "( " + Convert.ToString(dr["Airline_Code"]) + " )" + "/" + Convert.ToString(dr["City_Name"]), Convert.ToString(dr["Belongs_To_City"] + "," + Convert.ToString(dr["airline_detail_id"]) + "," + Convert.ToString(dr["Airline_Code"]) + "," + Convert.ToString(dr["Airline_name"]))));
                }
                cmd.Dispose();
            }
            catch (Exception eror)
            {
                string st = eror.ToString();
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
                cmd.Dispose();

            }
        }
    }
    protected void Btnload_Click(object sender, EventArgs e)
    {
        Session["airline_city_value"] = ddlairlines.SelectedItem.Value;
        Session["airline_city_text"] = ddlairlines.SelectedItem.Text;
        Session["from_date"] = txtValidFrom.Text;
        Session["to_date"] = txtValidTo.Text;
        Session["SelectDate"] = rdodate.SelectedItem.Value;
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( 'AgentWise_Freight_Report_Show.aspx');</script>");
        

    }
}
