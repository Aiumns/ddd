using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Agent_PAN_Details : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string table = null;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            AgentDetails();
        }
    }
    public void AgentDetails()
    {
        try
        {
            // table header create
            con = new SqlConnection(strCon);
            con.Open();

            com = new SqlCommand("select distinct City_id,City_Code,City_Name from City_Master CM inner join Agent_Branch AB on AB.Belongs_to_city=CM.City_ID", con);

            int ip = 1;
            int count = 0;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow drx in ds.Tables[0].Rows)
            {
                //table Row Create daynamically.
                if (txtAgentName.Text == "")
                {
                    com = new SqlCommand("SELECT AM.Agent_Name,AM.IATA_CODE,AB.Agent_branch_ID,AB.Agent_Address,Ab.Agent_Email,AB.Pan_No,Ab.TAN_NO,Ab.Agent_phone,Agent_contactNo,Ab.Concerned_person,Ab.CSR_Contact_Person,Ab.CSR_Email FROM Agent_Master AM INNER JOIN Agent_Branch AB ON AM.Agent_ID = AB.Agent_ID INNER JOIN Login_Master LM ON AB.Agent_Branch_ID = LM.Agent_ID  where AB.Belongs_To_City='" + drx[0].ToString() + "' ORDER BY AM.Agent_Name ", con);
                }
                else
                {
                    com = new SqlCommand("SELECT AM.Agent_Name,AM.IATA_CODE,AB.Agent_branch_ID,AB.Agent_Address,Ab.Agent_Email,AB.Pan_No,Ab.TAN_NO,Ab.Agent_phone,Agent_contactNo,Ab.Concerned_person,Ab.CSR_Contact_Person,Ab.CSR_Email FROM Agent_Master AM INNER JOIN Agent_Branch AB ON AM.Agent_ID = AB.Agent_ID INNER JOIN Login_Master LM ON AB.Agent_Branch_ID = LM.Agent_ID where AB.Belongs_To_City='" + drx[0].ToString() + "' and AM.Agent_Name like '" + txtAgentName.Text.Trim() + "%'  ORDER BY AM.Agent_Name ", con);
                }
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {

                    table += @"<table table width=""100%"" id=""Table1"" border=""1""><th align=""center"" colspan=""12"" class=""h1 boldtext"" style=""text-transform: uppercase;"">" + drx[2].ToString() + "(" + drx[1].ToString() + ")" + @"</th><tr class=""h1 boldtext""><td  align=""center"" nowrap>SNo</td><td  align=""center"" nowrap>Agnet Name</td><td  align=""center"" nowrap>IATA Code</td><td  align=""center"" nowrap>Address</td><td  align=""center"" nowrap>Agent Email</td><td  align=""center"" nowrap>Agent ContactNo</td><td  align=""center"" nowrap>Concerned Person</td><td  align=""center"" nowrap>CSR Contact Person</td><td  align=""center"" nowrap>CSR Email</td><td  align=""center"" nowrap>PAN</td><td  align=""center"" nowrap>TAN No</td><td>&nbsp;</td></tr></th>";
                    while (dr1.Read())
                    {
                        count++;
                        table += @"<tr><td align=left class=text>" + count + @"</td><td align=left class=text>" + dr1["Agent_Name"].ToString() + @"</td><td align=""left"" class=text>" + dr1["IATA_CODE"].ToString() + @"</td><td align=""left"" class=text>" + dr1["Agent_Address"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Agent_Email"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Agent_contactNo"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["Concerned_person"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["CSR_Contact_Person"].ToString() + @"</td><td align=""left"" class=text>&nbsp;" + dr1["CSR_Email"].ToString() + @"</td><td align=""left"" class=text nowrap>&nbsp;" + dr1["Pan_No"].ToString() + @"</td><td align=""left"" class=text nowrap>&nbsp;" + dr1["TAN_NO"].ToString() + @"</td><td><a style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px; font-weight:bold;' href='Agent_PAN_DetailsUpdate.aspx?sno=" + dr1["Agent_branch_ID"].ToString() + "'>Edit</a></td></tr>";
                    }
                }
                else
                {

                    //table += @"<tr><td align=""center"" colspan=""11""></td></tr>";
                }


                dr1.Close();
                ip = ip + 1;
                count = 0;
                table += @"<br>";
            }
            table += @"</table>";
            Label1.Text = table;

            //mulTable = mulTable + table;//end of if cond.
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {

    }
}
