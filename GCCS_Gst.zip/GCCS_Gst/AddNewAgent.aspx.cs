using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
public partial class Default4 : System.Web.UI.Page
{
    /// <summary>
    /// <class>Add New Agent</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>-------SAROJ KUMAR GUPTA------------</createdBy>
    /// <createdOn>---Oct 17 OCT 2007--------</createdOn>
    /// <modifications>
    /// <modificat
    /// <changeDescription></changeDescription>
    /// <modifiedBy>-------SAROJ KUMAR GUPTA-----</modifiedBy>
    /// <modifiedOn> 18,19,22 OCT 2007</modifiedOn>
    /// <modifiedBy>--------RAKHI on 11 Dec---------</modifiedBy>
    /// </modification>
    /// </modifications> 
    /// </summary> 
    SqlConnection con; 
    SqlDataAdapter da;
    SqlCommand com;
    SqlTransaction trans = null;
    DataSet ds;
    string TodayDate, LoginID, sessionValue;
    public string strLen = "";
    int agentID,BranchID;
    int CityId;
    string  ts1,loginid;
    //string pass="";
    //string InCrp = "";
    //string mno="";
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;  // ConnectionString

    protected void Page_Load(object sender, EventArgs e)
    {
        //rb1.SelectedValue = "21";
        btnAdd.Attributes.Add("onclick", "return CheckEmpty()");
        btnUpdate.Attributes.Add("onclick", "return CheckEmpty()");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            
            TodayDate = DateTime.Now.ToShortDateString();
            //strLen = "<script>var FillCity=new Array(" + City() + ")</script>"; // call for CityName & CityCode
            loginid = Session["EMailID"].ToString();

            //ViewState["pwd"] = txtPassword.Text;
            //Response.Write(pass);

            if (!IsPostBack)
            {
                CityName();
                OfflineCityName();
                //BindAirlineAccess();  // Call for Bind Airline Access
                BindGroupName();        // Call for Bind Group ID  
                //if(Request.QueryString["sno"].ToString()!="")
                //{
                //    DataTable dt_TempFill = dw.GetAllFromQuery("select * from Agent_temp where Agent_Temp_ID='" + Request.QueryString["sno"].ToString() + "'");
                //    if (dt_TempFill.Rows.Count > 0)
                //    {
                //        txtLogin.Text = dt_TempFill.Rows[0]["Agent_Email"].ToString();
                //        txtPassword.Text = dt_TempFill.Rows[0]["Agent_Password"].ToString();
                //        txtAgentName.Text = dt_TempFill.Rows[0]["Agent_Name"].ToString();
                //        txtAddress.Text = dt_TempFill.Rows[0]["Agent_Address"].ToString();
                //        if (dt_TempFill.Rows[0]["Agent_Type"].ToString().Trim() == "Company")
                //        {
                //            rb1.SelectedValue = "21";
                //        }
                //        else
                //        {
                //            rb1.SelectedValue = "22";
                //        }
                //        txtcontactno.Text = dt_TempFill.Rows[0]["Agent_Phone"].ToString();
                //        txtPhone.Text = dt_TempFill.Rows[0]["Agent_MobNo"].ToString();
                //        txtFax.Text = dt_TempFill.Rows[0]["Agent_Fax"].ToString();
                //        txtConcernPerson.Text = dt_TempFill.Rows[0]["concerned_person"].ToString();
                //        txtPanNo.Text = dt_TempFill.Rows[0]["pan_no"].ToString();
                //        txtIATACode.Text = dt_TempFill.Rows[0]["iata_code"].ToString();
                //    }
                //}

            }
        }
    }

    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        ddlStatus.SelectedIndex = 0;
        txtLogin.Text = "";
        txtPassword.Text = "";     
        ddlGroupName.SelectedItem.Text = "Agent";
        txtAgentName.Text = "";
        txtAddress.Text = "";
        txtCity.SelectedIndex = 0;
        ddlOfflineCity.SelectedIndex = 0;
        CheckAirlineAccess.Items.Clear();
        txtContactPerson.Text = "";
        txtPhone.Text = "";
        txtFax.Text = "";
        txtConcernPerson.Text = "";
        //ddlStatus.SelectedItem.Text = "--Select--";
        //txtTDSExemLimit.Text = "";
        txtCsrEmailID.Text = "";
        txtIATAComm.Text = "";
        txtPanNo.Text = "";
        //txtSurcharge.Text = "";
        //txtTDSDeducSource.Text = "";
        txtCreditLimit.Text = "";
        txtIATACode.Text = "";
        lblMessage.Visible = false;
        lblAccesss.Visible = false;

    }
    public void CityName()
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master order by city_code", con);
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        txtCity.DataSource = ds;
        txtCity.DataTextField = "CodeName";
        txtCity.DataValueField = "City_ID";
        txtCity.DataBind();
        txtCity.Items.Insert(0, new ListItem("--Select--", "0"));
        con.Close();
    }
    public void OfflineCityName()
    {
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand("Select (City_Code+'-'+City_Name) as CodeName,City_ID from City_Master where offline='Y' order by city_code", con);
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        ddlOfflineCity.DataSource = ds;
        ddlOfflineCity.DataTextField = "CodeName";
        ddlOfflineCity.DataValueField = "City_ID";
        ddlOfflineCity.DataBind();
        ddlOfflineCity.Items.Insert(0, new ListItem("--Select--", "0"));
        con.Close();
    }
    public void BindAirlineAccess()  // Bind Airline_Access
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectQ;
        string citycode = txtCity.SelectedItem.Text;
        string OfflineCityCode = ddlOfflineCity.SelectedItem.Text;
        int m = citycode.IndexOf("-") + 1;
        string city_code = citycode.Substring(0, m - 1);
        //*********************Modify On 31_DEC_2010******************* City Free Airline***************

        //selectQ = "select (a.Airline_Code+'-'+a.Airline_Name) as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where c.City_Code='" + city_code + "' and b.Status=2";

        selectQ = "select (a.Airline_Code+'-'+a.Airline_Name+'('+c.City_Code+')') as NameCode,b.Airline_detail_ID from Airline_Master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on b.Belongs_To_City=c.City_ID where b.Status=2";


        //***************************End Of Modification***************************


        com = new SqlCommand(selectQ, con);
        com.Connection = con;
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);

        CheckAirlineAccess.DataSource = ds;
        CheckAirlineAccess.DataTextField = "NameCode";
        CheckAirlineAccess.DataValueField = "Airline_detail_ID";

        CheckAirlineAccess.DataBind();
        CheckBoxList chk = (CheckBoxList)pnlCheck.FindControl("CheckAirlineAccess");
        for(int i=0;i<ds.Tables[0].Rows.Count;i++)
        {
            chk.Items[i].Selected = true;
        }
            
        com.Dispose();
        con.Close();
        //rakhi
        if (ds.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                lblAccesss.Visible = false;
                pnlCheck.Visible = true;
                CheckAirlineAccess.Items[i].Selected = true;
            }            
        }
        else
        {
            lblAccesss.Visible = true;
            lblAccesss.Text = "No Airline Exist For " + txtCity.SelectedItem.Text.Trim() + ", Please select Another City";
            pnlCheck.Visible = false;
        }
        //rakhi
    }
 
    public void BindGroupName()     // Bind Group_Name
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectQ;
        selectQ = "select Group_Name,Group_ID from Group_Master where Group_Type='Agent'";
        com = new SqlCommand(selectQ, con);
        com.Connection = con;
        da = new SqlDataAdapter(com);
        ds = new DataSet();
        da.Fill(ds);
        ddlGroupName.DataSource = ds;
        ddlGroupName.DataTextField = "Group_Name";
        ddlGroupName.DataValueField = "Group_ID";
        ddlGroupName.DataBind();

       ddlCsrGroupName.DataSource = ds;
       ddlCsrGroupName.DataTextField = "Group_Name";
       ddlCsrGroupName.DataValueField = "Group_ID";
      ddlCsrGroupName.DataBind();
        com.Dispose();
        con.Close();
    }
    public string City() // Bind City_Code and City_Name
    {
        string strTemp = "";
        SqlConnection con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT City_Name,City_Code  FROM City_Master";
            SqlCommand com = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")
                    strTemp = "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
            }
            dr.Close();
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.Message;
            lblMessage.Text = err;
            lblMessage.Visible = true;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }
  
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (chkOffline.Checked == true && ddlOfflineCity.SelectedValue == "0")
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "<SCRIPT LANGUAGE='javascript'>alert('Please select Offline City');</script>");
            lblMessage.Visible = true;
            lblMessage.Text = "Please select Offline City";
            ddlOfflineCity.Focus();
            return;
        }
        else
        {
           
            if (check())
            {
                lblMessage.Visible = true;
                lblMessage.Text = "Login ID Already Exists";
            }
            else if (checkAgentName())
            {
                lblMessage.Text = "Agent Name Already Exists.";
                lblMessage.Visible = true;
            }            
          
           else if (checkCityName())
            {
                int m = CheckAirlineAccess.Items.Count;
                bool isChecked = false;
                for (int i = 0; i < m; i++)
                    if (CheckAirlineAccess.Items[i].Selected)
                        isChecked = true;

                if (!isChecked)
                {
                    lblMessage.Text = "Please Check AtLeast One Airline Access";
                    lblMessage.Visible = true;
                    return;
                }
                for (int i = 0; i < m; i++)
                {
                    CheckBoxList chk1 = CheckAirlineAccess;


                    if (chk1.Items[i].Selected)
                    {
                        con = new SqlConnection(strCon);
                        con.Open();
                        string Agent_ID1 = Convert.ToString(Request.QueryString["Agent_ID"]);
                        string Iata_Code = txtIATACode.Text.Trim();



                        FillData();   // call for Insert data into all Table
                        lblMessage.Text = "Records Added Successfully";
                        lblMessage.Visible = true;



                    }
                }
            }
            else
            {
                lblMessage.Text = "Select Valid City";
                lblMessage.Visible = true;
            }
        }
    }
  public bool checkCityName()
    {
         
        con = new SqlConnection(strCon);
        con.Open();
      
         string citycode = txtCity.SelectedItem.Text;
         string OfflineCityCode = ddlOfflineCity.SelectedItem.Text;
         int m = citycode.IndexOf("-");
         if (m > 0)
         {
             string city_code = citycode.Substring(0, m - 1);
             string selectloginid;
             selectloginid = "select City_Code+'-'+City_Name from City_Master  where City_Code=@cityName or City_Name=@City_CodeId";
             com = new SqlCommand(selectloginid, con);
             com.Parameters.AddWithValue("@cityName", city_code);
             com.Parameters.AddWithValue("@City_CodeId", FindCityName());
             SqlDataReader sdr = com.ExecuteReader();
             if (sdr.Read())
             {
                 con.Close();
                 con.Open();
                 return true;
             }
             else
             {
                 con.Close();
                 con.Open();
                 return false;
             }
         }
         else
         {
             lblMessage.Text = "select Valid City";
             lblMessage.Visible=true;
             return false;
         }          
     
        
    }
   protected string  FindCityName()        // Split City Name
    {
        string str = txtCity.SelectedItem.Text;
        string str1;
        int j = str.IndexOf("-") + 1;
        int k = str.Length;
        str1 = str.Substring(j);
        return str1;
    }
    public bool check()     // check for Login Id Exists or Not
    {
        con = new SqlConnection(strCon);
        con.Open();
        string selectloginid;
        selectloginid = "SELECT Email_ID FROM Login_Master_CSR  WHERE (EMAIL_ID=@EmailID OR EMAIL_ID=@CSREmailID) UNION SELECT Email_ID FROM Login_Master WHERE (EMAIL_ID=@EmailID OR EMAIL_ID=@CSREmailID)";
        com = new SqlCommand(selectloginid, con);
        com.Parameters.AddWithValue("@EmailID",txtLogin.Text);
        com.Parameters.AddWithValue("@CSREmailID", txtCsrEmailID.Text);
        SqlDataReader sdr = com.ExecuteReader();
        if (sdr.Read())
        {
            if (sdr["Email_ID"].ToString() == "" || sdr["Email_ID"].ToString() == null)
            {
                con.Close();
                con.Open();

                return false;
            }
            else
            {

                con.Close();
                con.Open();

                return true;
            }
        }
        else
        {
             con.Close();
             con.Open();
            return false;
        }        
     }
    public bool checkAgentName()        // Check Agent Name Exists.
    {
        con = new SqlConnection(strCon);
        con.Open();
        string txtAgent = "";

        //*************************Modified***Shaikh Akhtar Rasool*****************************//

        txtAgent = txtAgentName.Text;
        txtAgent = txtAgent.Replace("P.", "PRIVATE");
        txtAgent = txtAgent.Replace('.', ' ');
        txtAgent = txtAgent.Replace("&", "And");
        txtAgent = Regex.Replace(txtAgent, "\\s+", "");
        txtAgent = txtAgent.Replace("PVT", "PRIVATE");
        txtAgent = txtAgent.Replace("LTD", "LIMITED");

        string query = "select replace(replace(replace(replace(replace(replace(replace(Agent_Name,'P.','PRIVATE'),'.',''),' ',''),'+',''),'&','and'),'PVT','PRIVATE'),'Ltd','LIMITED') as Agent_Name from Agent_Master";
        com = new SqlCommand(query, con);
        SqlDataReader reader = com.ExecuteReader();

        while (reader.Read())
        {
            if (reader["Agent_Name"].ToString() == "")
            {
                return false;

            }
            
            else if (reader["Agent_Name"].ToString() == txtAgent)
            {
                return true;

            }
        }
        reader.Close();
        com.Dispose();
        return false;





        //****************************************************************//
        //string selectloginid;
        //selectloginid = "select Agent_Name from Agent_Master where Agent_Name=@AgentName";
        //com = new SqlCommand(selectloginid, con);
        //com.Parameters.AddWithValue("@AgentName", txtAgentName.Text);
        //SqlDataReader sdr = com.ExecuteReader();
        //if (sdr.Read())
        //{
        //    con.Close();
        //    con.Open();
        //    return true;
        //}
        //else
        //{
        //    con.Close();
        //    con.Open();
        //    return false;
        //}
    }
    public void FillData()      // insert Data in All Table
    {       
            con = new SqlConnection(strCon);
            con.Open();
            string insertQ, insertQ1, insertQ2, insertQ3;

            //string password = Session["pwd"].ToString(); 
            try
            {
                trans = con.BeginTransaction();
                string str = txtCity.SelectedItem.Text;
                string OfflineCity = ddlOfflineCity.SelectedValue;
                string str1;
                int j = str.IndexOf("-") + 1;
                int k = str.Length;
                str1 = str.Substring(0, j - 1);
                // Response.Write(str1);
                string id = "00001";
                //string username = txtAgentName.Text;
                //string ch = username.Substring(0, 1);
                //SqlConnection con = new SqlConnection(strCon);
                //con.Open();
                SqlCommand cmd = new SqlCommand("select isnull(max(Agent_Code),0) from Agent_Master where Agent_Code like '" + str1 + "%'", con, trans);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read() && dr[0].ToString() != "0")
                {
                    string str2 = dr[0].ToString().Substring(0, dr[0].ToString().Length);
                    string ch1 = str2.Substring(3);

                    int i = Convert.ToInt32(ch1) + 1;
                    string si = i.ToString();
                    if (si.Length == 1)
                    {
                        id = str1.ToUpper() + "0000" + i;
                    }
                    else if (si.Length == 2)
                    {
                        id = str1.ToUpper() + "000" + i;
                    }
                    else if (si.Length == 3)
                    {
                        id = str1.ToUpper() + "00" + i;
                    }
                    else if (si.Length == 4)
                        id = str1.ToUpper() + "0" + i;

                }
                else
                {
                    id = str1.ToUpper() + id;

                }
                dr.Close();
                //con.Close();
                //con.Open();
                // insert into Agent_Master

                //insertQ = "insert into dbo.Agent_Master(Agent_Code,Agent_Name,IATA_Code,IATA_Commission,TaxDeductiononSource,TDS_Exemption_Limit,Credit_Limit,SurCharge,Entered_By,Entered_On)values(@Agent_Code,@Agent_Name,@IATA_Code,@IATA_Commission,@TaxDeductiononSource,@TDS_Exemption_Limit,@Credit_Limit,@SurCharge,@Entered_By,@Entered_On)";
                string strNeut = "";
                if (chkNeutral.Checked == true)
                {
                    strNeut = "Y";
                }
                else
                {
                    strNeut = "N";
                }
                //////insertQ = "insert into dbo.Agent_Master(Agent_Code,Agent_Name,Agent_Type,IATA_Code,IATA_Commission,Entered_By,Entered_On)values(@Agent_Code,@Agent_Name,@Agent_Type,@IATA_Code,@IATA_Commission,@Entered_By,@Entered_On)";

                //********Added On 14 Apr 2011 :New column Offline_Agent*************
                insertQ = "insert into dbo.Agent_Master(Agent_Code,Agent_Name,Agent_Type,IATA_Code,IATA_Commission,Entered_By,Entered_On,Offline_Agent,Offline_City)values(@Agent_Code,@Agent_Name,@Agent_Type,@IATA_Code,@IATA_Commission,@Entered_By,@Entered_On,@Offline_Agent,@Offline_City)";
                cmd = new SqlCommand(insertQ, con, trans);
                cmd.Parameters.AddWithValue("@Agent_Code", id);
                cmd.Parameters.AddWithValue("@Agent_Name", txtAgentName.Text.Replace("'", "`"));
                //cmd.Parameters.Add("@Agent_Type", SqlDbType.Int).Value = val;
                if (rb1.SelectedItem.Text == "Company")
                {
                    //com.Parameters.Add("@FreightSurCharge_Charged", SqlDbType.TinyInt).Value = 13;
                    cmd.Parameters.Add("@Agent_Type", SqlDbType.Int).Value = 21;
                    //cmd.Parameters.AddWithValue("@Agent_Type", rb1.SelectedValue).Value = 21;                
                }
                else
                {
                    //cmd.Parameters.AddWithValue("@Agent_Type", rb1.SelectedValue).Value = 22;
                    cmd.Parameters.Add("@Agent_Type", SqlDbType.Int).Value = 22;
                }
                cmd.Parameters.AddWithValue("@IATA_Code", txtIATACode.Text);
                cmd.Parameters.AddWithValue("IATA_Commission", txtIATAComm.Text);
                //cmd.Parameters.AddWithValue("@TaxDeductiononSource", txtTDSDeducSource.Text);
                //cmd.Parameters.AddWithValue("@TDS_Exemption_Limit",txtTDSExemLimit.Text);

                //cmd.Parameters.AddWithValue("@SurCharge", txtSurcharge.Text); 

                cmd.Parameters.AddWithValue("@Entered_By", loginid);
                cmd.Parameters.AddWithValue("@Entered_On", TodayDate);
                //*********Added On 14 Ape 2011************
                if (chkOffline.Checked == true)
                {
                    cmd.Parameters.AddWithValue("Offline_Agent", "Y");
                }
                else
                {
                    cmd.Parameters.AddWithValue("Offline_Agent", "N");
                }
                if (ddlOfflineCity.SelectedValue == "0")
                {
                    cmd.Parameters.AddWithValue("Offline_City", "");
                }
                else
                {
                    cmd.Parameters.AddWithValue("Offline_City", ddlOfflineCity.SelectedValue);
                }
                
                cmd.ExecuteNonQuery();
                // Find Agent_ID
                string selectQ;
                selectQ = "select max(Agent_ID) From Agent_Master";
                cmd = new SqlCommand(selectQ, con, trans);
                agentID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

                // Find City name
                string citycode = txtCity.SelectedItem.Text;
                string Offlinecitycode = ddlOfflineCity.SelectedItem.Text;
                int m = citycode.IndexOf("-") + 1;
                citycode = citycode.Substring(0, m - 1);
                cmd = new SqlCommand("select City_ID from City_Master where City_Code='" + citycode + "'", con, trans);
                SqlDataReader dr1 = cmd.ExecuteReader();
                while (dr1.Read())
                {
                    CityId = Convert.ToInt32(dr1["City_ID"].ToString());
                }
                //con.Close();
                //con.Open();
                dr1.Close();

                //Insert Agent_Branch
                insertQ3 = "insert into Agent_Branch(Agent_ID,Branch_Status,Belongs_To_City,Agent_Address,Agent_Phone,Agent_Contactno,Agent_Fax,Agent_Email,Concerned_Person,CSR_Contact_Person,CSR_Email,Pan_No,Tan_No,Credit_Limit,Status,AutoNeutral,Offline_City)values(@Agent_ID,@Branch_Status,@Belongs_To_City,@Agent_Address,@Agent_Phone,@Agent_Contactno,@Agent_Fax,@Agent_Email,@Concerned_Person,@CSR_Contact_Person,@CSR_Email,@Pan_No,@Tan_No,@Credit_Limit,@Status,@AutoNeutral,@Offline_City)";
                cmd = new SqlCommand(insertQ3, con, trans);
                cmd.Parameters.AddWithValue("@Agent_ID", agentID);
                cmd.Parameters.AddWithValue("@Branch_Status", 18);
                cmd.Parameters.AddWithValue("@Belongs_To_City", CityId);
                cmd.Parameters.AddWithValue("@Agent_Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@Agent_Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Agent_Contactno", txtcontactno.Text);
                cmd.Parameters.AddWithValue("@Agent_Fax", txtFax.Text);
                cmd.Parameters.AddWithValue("@Agent_Email", txtLogin.Text);
                cmd.Parameters.AddWithValue("@Concerned_Person", txtConcernPerson.Text);
                cmd.Parameters.AddWithValue("@CSR_Contact_Person", txtContactPerson.Text);
                cmd.Parameters.AddWithValue("@CSR_Email", txtCsrEmailID.Text);
                cmd.Parameters.AddWithValue("@Pan_No", txtPanNo.Text);
                cmd.Parameters.AddWithValue("@Tan_No", txtTanNo.Text);
                cmd.Parameters.AddWithValue("@Credit_Limit", txtCreditLimit.Text);
                cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@AutoNeutral", strNeut);

                if (ddlOfflineCity.SelectedValue == "0")
                {
                    cmd.Parameters.AddWithValue("Offline_City", "");
                }
                else
                {
                    cmd.Parameters.AddWithValue("Offline_City", ddlOfflineCity.SelectedValue);
                }
               //// cmd.Parameters.AddWithValue("@Offline_City", ddlOfflineCity.SelectedValue);
                cmd.ExecuteNonQuery();

                string selectQ1;
                selectQ1 = "select max(Agent_Branch_ID) From Agent_Branch ";
                cmd = new SqlCommand(selectQ1, con, trans);
                BranchID = Convert.ToInt32(cmd.ExecuteScalar().ToString());
                insertQ2 = "insert into Login_Master(Email_ID,Login_Password,Agent_ID,Group_ID,Airline_Access )values(@Email_ID,@Login_Password,@Agent_ID,@Group_ID,@Airline_Access)";
                cmd = new SqlCommand(insertQ2, con, trans);


                for (int i = 0; i < CheckAirlineAccess.Items.Count; i++)    // values store in listbox
                {
                    if (CheckAirlineAccess.Items[i].Selected)
                    {

                        ts1 = ts1 + CheckAirlineAccess.Items[i].Value + ",";
                    }

                }
                ts1 = ts1.Remove(ts1.LastIndexOf(","));
                cmd.Parameters.AddWithValue("@Email_ID", txtLogin.Text);
                cmd.Parameters.AddWithValue("@Login_Password", txtPassword.Text);
                cmd.Parameters.AddWithValue("@Agent_ID", BranchID);
                cmd.Parameters.AddWithValue("@Airline_Access", ts1);
                cmd.Parameters.AddWithValue("@Group_ID", ddlGroupName.SelectedValue);
                cmd.ExecuteNonQuery();
                if (txtCsrEmailID.Text != "")
                {
                    if (txtPassCSR.Text != "")
                    {
                        if (txtCsrEmailID.Text != txtLogin.Text)
                        {
                            string insertCSR = "insert into Login_Master_CSR(Email_ID,Login_Password,Agent_Branch_ID,Group_ID,Airline_Access )values(@Email_ID,@Login_Password,@Agent_Branch_ID,@Group_ID,@Airline_Access)";
                            cmd = new SqlCommand(insertCSR, con, trans);
                            cmd.Parameters.AddWithValue("@Email_ID", txtCsrEmailID.Text);
                            cmd.Parameters.AddWithValue("@Login_Password", txtPassCSR.Text);
                            cmd.Parameters.AddWithValue("@Agent_Branch_ID", BranchID);
                            cmd.Parameters.AddWithValue("@Airline_Access", ts1);
                            cmd.Parameters.AddWithValue("@Group_ID", ddlCsrGroupName.SelectedValue);
                            cmd.ExecuteNonQuery();
                        }
                    }

                }
                //if (Request.QueryString["sno"].ToString() != "")
                //{
                //    string insertAgentTemp = "update agent_temp set Status=@Status where Agent_temp_id='" + Request.QueryString["sno"].ToString() + "'";
                //    cmd = new SqlCommand(insertAgentTemp, con, trans);
                //    cmd.Parameters.AddWithValue("@Status", "Y");
                //    cmd.ExecuteNonQuery();
                //}
                trans.Commit();

                con.Close();
            }
            catch (SqlException se)
            {
                string err = se.Message;
                lblMessage.Text = err;
                lblMessage.Visible = true;
                trans.Rollback();

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }
            Response.Redirect("ViewAgent.aspx");       
    }

    protected void txtCity_SelectedIndexChanged(object sender, EventArgs e)
    {
     
        BindAirlineAccess();
       
    }
    protected void btn_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewAgent.aspx");
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {

    }   
    protected void chkOffline_CheckedChanged1(object sender, EventArgs e)
    {
        if (chkOffline.Checked == true)
        {
            Offline.Visible = true;
            OfflineCityName();
        }
        else
        {
            OfflineCityName();
            Offline.Visible = false;
            //ddlOfflineCity.Items.Clear();
            //ddlOfflineCity.SelectedValue = "0";
            ddlOfflineCity.SelectedItem.Value = "0";
        }
    }
}



