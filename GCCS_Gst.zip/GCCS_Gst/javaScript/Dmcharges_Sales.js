﻿function Dmchrgs() {

    var DmChrgs = document.getElementById("ctl00_ContentPlaceHolder1_txtDmcharges").value;
    if (DmChrgs != 0) {
        DmChrgs = document.getElementById("ctl00_ContentPlaceHolder1_txtDmcharges").value;
    }
    else {
        DmChrgs = 0;
    }
    //  var ABC = document.getElementById("ctl00_ContentPlaceHolder1_Hidden3").value;
    var FSC = document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value;
    var WSC = document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value;
    var XRAY = document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value;
    var ACIFee = document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    var AWBFee = document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    var DBCharges = document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value;
    var Catrage = document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value;
    var Others = document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value;
    var DueCarrier = parseFloat(FSC) + parseFloat(WSC) + parseFloat(XRAY) + parseFloat(ACIFee) + parseFloat(AWBFee) + parseFloat(DBCharges) + parseFloat(Catrage) + parseFloat(Others) + parseFloat(DmChrgs);
    document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = parseFloat(DueCarrier);
    var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_lblFreightAmount").value;
    document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = parseFloat(FreightAmount) + parseFloat(DueCarrier);
}