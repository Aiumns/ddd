﻿// JScript File

function blockNonNumbers(obj, e, allowDecimal, allowNegative) {
    var key;
    var isCtrl = false;
    var keychar;
    var reg;

    if (window.event) {
        key = e.keyCode;
        isCtrl = window.event.ctrlKey
    }
    else if (e.which) {
        key = e.which;
        isCtrl = e.ctrlKey;
    }

    if (isNaN(key)) return true;

    keychar = String.fromCharCode(key);

    // check for backspace or delete, or if Ctrl was pressed
    if (key == 8 || isCtrl) {
        return true;
    }

    reg = /\d/;
    var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
    var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;

    return isFirstN || isFirstD || reg.test(keychar);
}

function CheckTelePhoneNo(obj, e, allowDecimal, allowNegative) {
    var key;
    var isCtrl = false;
    var keychar;
    var reg;

    if (window.event) {
        key = e.keyCode;
        isCtrl = window.event.ctrlKey
    }
    else if (e.which) {
        key = e.which;
        isCtrl = e.ctrlKey;
    }

    if (isNaN(key)) return true;

    keychar = String.fromCharCode(key);

    // check for backspace or delete, or if Ctrl was pressed
    if (key == 8 || isCtrl) {
        return true;
    }

    reg = /\d/;
    var isFirstN = allowNegative ? keychar == '-' : false;
    var isFirstD = allowDecimal ? keychar == ',' : false;

    return isFirstN || isFirstD || reg.test(keychar);
}


//.....................End Of Function blockNonNumbers........................//


function Grosscal()
{

document.getElementById("ctl00_ContentPlaceHolder1_txtchwt").value=document.getElementById("ctl00_ContentPlaceHolder1_txtGrwt").value

}
//.....................Start Of Function blockNonNumbers........................//
function CheckEmpty_ddl() {

if (document.getElementById("ctl00_ContentPlaceHolder1_txtawbno").value == '') {
        alert("Please Enter  Airwaybill ");
        document.getElementById("ctl00_ContentPlaceHolder1_txtawbno").focus();
        return false;
    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_txtTRK").value =='') {
        alert("Please Enter TRK ");
        document.getElementById("ctl00_ContentPlaceHolder1_txtTRK").focus();
        return false;
    }
     else if (document.getElementById("ctl00_ContentPlaceHolder1_txtUpliftmentDate").value =='') {
        alert("Please Enter Upliftment  ");
        document.getElementById("ctl00_ContentPlaceHolder1_txtUpliftmentDate").focus();
        return false;
    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_txtAccount").value =='') {
        alert("Please Enter Account No  ");
        document.getElementById("ctl00_ContentPlaceHolder1_txtAccount").focus();
        return false;
    }
     else if (document.getElementById("ctl00_ContentPlaceHolder1_txtchwt").value =='') {
        alert("Please Enter Ch.Wt  ");
        document.getElementById("ctl00_ContentPlaceHolder1_txtchwt").focus();
        return false;
    }
     else if (document.getElementById("ctl00_ContentPlaceHolder1_txtchwt").value =='0') {
        alert("Ch.Wt can not be Zero ");
        document.getElementById("ctl00_ContentPlaceHolder1_txtchwt").focus();
        return false;
    }
   else if (document.getElementById("ctl00_ContentPlaceHolder1_ddlAgentName").selectedIndex <= 0) {
        alert("Please Select Agent Name ");
        document.getElementById("ctl00_ContentPlaceHolder1_ddlAgentName").focus();
        return false;
    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_dllspt").selectedIndex <= 0) {
        alert("Please Select Shipment Type. ");
        document.getElementById("ctl00_ContentPlaceHolder1_dllspt").focus();
        return false;


    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_dlldest").selectedIndex <= 0) {
        alert("Please Select Destination.");
        document.getElementById("ctl00_ContentPlaceHolder1_dlldest").focus();
        return false;


    }

    else {
        return true;
    }
}





function Calculate() {
    var srvice_type = document.getElementById('ctl00_ContentPlaceHolder1_dllspt').value;

    if (srvice_type != "ATA") 
    {
        //Bying Region
        
        
        var basic_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value);
        var Buyingfsc_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCRate').value);
        var Buyingfsc_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value);
        var BuyingDg_surAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBuyDgSurcharge').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBuyDgSurcharge').value);
        var BuyingOtherChrgs = (document.getElementById('ctl00_ContentPlaceHolder1_txtBOther').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBOther').value);
        var Buyingstax_Rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtBStaxRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBStaxRate').value);
        var Buyingstax_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBServiceTaxAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBServiceTaxAmount').value);


        var BuyingSBCess_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtBSBcesRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBSBcesRate').value);
        var BuyingSBCess_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBSBcessTaxAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBSBcessTaxAmount').value);

        var BuyingKKCess_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtBKKcesRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBKKcesRate').value);
        var BuyingKKCess_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBKKcessTaxAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBKKcessTaxAmount').value);
      
        
        var ch_wt = (document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value);
        var buying_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value);

        var BuyingEduCessRate = (document.getElementById('ctl00_ContentPlaceHolder1_txtBeduCessRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBeduCessRate').value);
        var BuyingEduCessAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBEduCessAmt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBEduCessAmt').value);
        var BuyingHEduCessRate = (document.getElementById('ctl00_ContentPlaceHolder1_txtBHeduCessRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBHeduCessRate').value);
        var BuyingHEduCessAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBHEduCessAmt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBHEduCessAmt').value);
        
        
        var BuyingGrandStaxAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBuyingStaxAmt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBuyingStaxAmt').value);
        var BuyingGrandAmount = (document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value);



        var Buyingfsc_total = (parseFloat(basic_rate) * parseFloat(Buyingfsc_rate)) / 100;

        var BuyingAmtBeforeStaxAmt = (parseFloat(basic_rate) + parseFloat(Buyingfsc_total) + parseFloat(BuyingDg_surAmt) + parseFloat(BuyingOtherChrgs))

        var BuyingStaxRateAmt = (parseFloat(BuyingAmtBeforeStaxAmt) * parseFloat(Buyingstax_Rate)) / 100;

        var BuyingSBCessRateAmt = (parseFloat(BuyingAmtBeforeStaxAmt) * parseFloat(BuyingSBCess_rate)) / 100;

        var BuyingKKCessRateAmt = (parseFloat(BuyingAmtBeforeStaxAmt) * parseFloat(BuyingKKCess_rate)) / 100;

        var BuyingEduCessRateAmt = (parseFloat(BuyingStaxRateAmt) * parseFloat(BuyingEduCessRate)) / 100;

        var BuyingHEduCessRateAmt = (parseFloat(BuyingStaxRateAmt) * parseFloat(BuyingHEduCessRate)) / 100;

        var BuyingGrandTotalStaxAmt = (parseFloat(BuyingStaxRateAmt) + parseFloat(BuyingEduCessRateAmt) + parseFloat(BuyingHEduCessRateAmt) + parseFloat(BuyingSBCessRateAmt) + parseFloat(BuyingKKCessRateAmt))

        var BuyingGrandTotalAmount = (parseFloat(BuyingAmtBeforeStaxAmt) + parseFloat(BuyingGrandTotalStaxAmt))



        document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value = Buyingfsc_total.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value = BuyingAmtBeforeStaxAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtBServiceTaxAmount').value = BuyingStaxRateAmt.toFixed(2);


        document.getElementById('ctl00_ContentPlaceHolder1_txtBSBcessTaxAmount').value = BuyingSBCessRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtBKKcessTaxAmount').value = BuyingKKCessRateAmt.toFixed(2);
        
        document.getElementById('ctl00_ContentPlaceHolder1_txtBEduCessAmt').value = BuyingEduCessRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtBHEduCessAmt').value = BuyingHEduCessRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtBuyingStaxAmt').value = BuyingGrandTotalStaxAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value = BuyingGrandTotalAmount.toFixed(2);



        //End Selling region


        //Bying Region
//////        var sell_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value);
//////        var Sellingfsc_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCRate').value);
//////        var Sellingfsc_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value);
//////        var SellingDg_surAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value);
//////        var SellingOtherChrgs = (document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value);
//////        var Sellingstax_Rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellStaxRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellStaxRate').value);
//////        var Sellingstax_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellServiceTaxAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellServiceTaxAmount').value);
//////        var ch_wt = (document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value);
//////        var Selling_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value);

//////        var SellingEduCessRate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSelEduCessRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSelEduCessRate').value);
//////        var SellingEduCessAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellEduCessAmt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellEduCessAmt').value);
//////        var SellingHEduCessRate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSelHEduCessRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSelHEduCessRate').value);
//////        var SellingHEduCessAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellHEduCess').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellHEduCess').value);
//////        var SellingGrandStaxAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellingStaxAmt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellingStaxAmt').value);
//////        var SellingGrandAmount = (document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value);


//////        var Sellingfsc_total = (parseFloat(sell_rate) * parseFloat(Sellingfsc_rate)) / 100;

//////        var SellingAmtBeforeStaxAmt = (parseFloat(sell_rate) + parseFloat(Sellingfsc_total) + parseFloat(SellingDg_surAmt) + parseFloat(SellingOtherChrgs))

//////        var SellingStaxRateAmt = (parseFloat(SellingAmtBeforeStaxAmt) * parseFloat(Sellingstax_Rate)) / 100;

//////        var SellingEduCessRateAmt = (parseFloat(SellingStaxRateAmt) * parseFloat(SellingEduCessRate)) / 100;

//////        var SellingHEduCessRateAmt = (parseFloat(SellingStaxRateAmt) * parseFloat(SellingHEduCessRate)) / 100;

//////        var SellingGrandTotalStaxAmt = (parseFloat(SellingStaxRateAmt) + parseFloat(SellingEduCessRateAmt) + parseFloat(SellingHEduCessRateAmt))

//////        var SellingGrandTotalAmount = (parseFloat(SellingAmtBeforeStaxAmt) + parseFloat(SellingGrandTotalStaxAmt))





        //End Selling region

    }
    else
     {
         //Bying Region
         var basic_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value);
         var Buyingfsc_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCRate').value);
         var Buyingfsc_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value);
         var BuyingDg_surAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtBuyDgSurcharge').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBuyDgSurcharge').value);
         var BuyingOtherChrgs = (document.getElementById('ctl00_ContentPlaceHolder1_txtBOther').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtBOther').value);
         var ch_wt = (document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value);
         var buying_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value);

         
         var BuyingGrandAmount = (document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value);


         var Buyingfsc_total = (parseFloat(basic_rate) * parseFloat(Buyingfsc_rate)) / 100;

         var BuyingAmtBeforeStaxAmt = (parseFloat(basic_rate) + parseFloat(Buyingfsc_total) + parseFloat(BuyingDg_surAmt) + parseFloat(BuyingOtherChrgs))
    
         var BuyingGrandTotalAmount = (parseFloat(BuyingAmtBeforeStaxAmt))

         document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value = Buyingfsc_total.toFixed(2);
         document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value = BuyingAmtBeforeStaxAmt.toFixed(2);
         document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value = BuyingGrandTotalAmount.toFixed(2);



      



      



         //End buying region
    
    }
    FILLSalesField();
   
}



function FILLSalesField()
{
 var srvice_type = document.getElementById('ctl00_ContentPlaceHolder1_dllspt').value;
  if (srvice_type != "ATA") 
    {
    
//    document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value =  document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value; 
//        document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value =  document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value;
      document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value =document.getElementById('ctl00_ContentPlaceHolder1_txtBOther').value;
       document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value = document.getElementById('ctl00_ContentPlaceHolder1_txtBuyDgSurcharge').value;
        document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value = document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value;
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellServiceTaxAmount').value = document.getElementById('ctl00_ContentPlaceHolder1_txtBServiceTaxAmount').value;

        document.getElementById('ctl00_ContentPlaceHolder1_txtSellSBCessTaxAmount').value = document.getElementById('ctl00_ContentPlaceHolder1_txtSellSBCessTaxAmount').value;

        document.getElementById('ctl00_ContentPlaceHolder1_txtSellKKCessTaxAmount').value = document.getElementById('ctl00_ContentPlaceHolder1_txtSellKKCessTaxAmount').value;
        
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellEduCessAmt').value = document.getElementById('ctl00_ContentPlaceHolder1_txtBEduCessAmt').value;
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellHEduCess').value = document.getElementById('ctl00_ContentPlaceHolder1_txtBHEduCessAmt').value;
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellingStaxAmt').value = document.getElementById('ctl00_ContentPlaceHolder1_txtBuyingStaxAmt').value;
        document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value = document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value;
       
 
     }
     else
     {
//      document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value =  document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value;  
//      document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCRate').value =  document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCRate').value; 
   document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value =  document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value;
      document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value =document.getElementById('ctl00_ContentPlaceHolder1_txtBOther').value;
       document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value = document.getElementById('ctl00_ContentPlaceHolder1_txtBuyDgSurcharge').value;
        document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value = document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value;
        
           document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value = document.getElementById('ctl00_ContentPlaceHolder1_txtTotalBuyingAmtStax').value;
     
     }


}


function CalculateSales()
{
var srvice_type = document.getElementById('ctl00_ContentPlaceHolder1_dllspt').value;

if(parseInt(document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value)< parseInt(document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value))
{
alert('Selling rate Can not be less than buying rate');
document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value=document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value
}
if(parseInt(document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value)< parseInt(document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value))
{
alert('Selling FSC amount Can not be less than buying FSC amount');
document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value=document.getElementById('ctl00_ContentPlaceHolder1_txtBFSCAmount').value
}

if (srvice_type != "ATA") 
    {
    
     var sell_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value);
        var Sellingfsc_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCRate').value);
        var Sellingfsc_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value);
        var SellingDg_surAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value);
        var SellingOtherChrgs = (document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value);
        var Sellingstax_Rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellStaxRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellStaxRate').value);
        var Sellingstax_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellServiceTaxAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellServiceTaxAmount').value);


        var SellingSBCess_Rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellSBcesRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellSBcesRate').value);
        var SellingSBCess_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellSBCessTaxAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellSBCessTaxAmount').value);

        var SellingKKCess_Rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellKKcesRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellKKcesRate').value);
        var SellingKKCess_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellKKCessTaxAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellKKCessTaxAmount').value);
       
        
        var ch_wt = (document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value);
        var Selling_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value);

        var SellingEduCessRate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSelEduCessRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSelEduCessRate').value);
        var SellingEduCessAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellEduCessAmt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellEduCessAmt').value);
        var SellingHEduCessRate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSelHEduCessRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSelHEduCessRate').value);
        var SellingHEduCessAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellHEduCess').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellHEduCess').value);
        var SellingGrandStaxAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellingStaxAmt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellingStaxAmt').value);
        var SellingGrandAmount = (document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value);



         Sellingfsc_amt = (parseFloat(sell_rate) * parseFloat(Sellingfsc_rate)) / 100;
        var SellingAmtBeforeStaxAmt = (parseFloat(sell_rate) + parseFloat(Sellingfsc_amt) + parseFloat(SellingDg_surAmt) + parseFloat(SellingOtherChrgs))

        var SellingStaxRateAmt = (parseFloat(SellingAmtBeforeStaxAmt) * parseFloat(Sellingstax_Rate)) / 100;

        var SellingSBCessRateAmt = (parseFloat(SellingAmtBeforeStaxAmt) * parseFloat(SellingSBCess_Rate)) / 100;
        var SellingKKCessRateAmt = (parseFloat(SellingAmtBeforeStaxAmt) * parseFloat(SellingKKCess_Rate)) / 100;

        var SellingEduCessRateAmt = (parseFloat(SellingStaxRateAmt) * parseFloat(SellingEduCessRate)) / 100;

        var SellingHEduCessRateAmt = (parseFloat(SellingStaxRateAmt) * parseFloat(SellingHEduCessRate)) / 100;

        var SellingGrandTotalStaxAmt = (parseFloat(SellingStaxRateAmt) + parseFloat(SellingEduCessRateAmt) + parseFloat(SellingHEduCessRateAmt) + parseFloat(SellingSBCessRateAmt) + parseFloat(SellingKKCessRateAmt))
        

        var SellingGrandTotalAmount = (parseFloat(SellingAmtBeforeStaxAmt) + parseFloat(SellingGrandTotalStaxAmt))


        document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value = Sellingfsc_amt;
        document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value = SellingAmtBeforeStaxAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellServiceTaxAmount').value = SellingStaxRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellSBCessTaxAmount').value = SellingSBCessRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellKKCessTaxAmount').value = SellingKKCessRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellEduCessAmt').value = SellingEduCessRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellHEduCess').value = SellingHEduCessRateAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtSellingStaxAmt').value = SellingGrandTotalStaxAmt.toFixed(2);
        document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value = SellingGrandTotalAmount.toFixed(2);
        

    
    }
    else
    {
    
          var sell_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value);
         var Sellingfsc_rate = (document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCRate').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCRate').value);
         var Sellingfsc_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value);
         var SellingDg_surAmt = (document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSellingDgSurcharge').value);
         var SellingOtherChrgs = (document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtSOther').value);
         var ch_wt = (document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value);
         var Selling_amt = (document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value);
         var SellingGrandAmount = (document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value == '' ? '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value);


         Sellingfsc_amt = (parseFloat(sell_rate) * parseFloat(Sellingfsc_rate)) / 100;

         var SellingAmtBeforeStaxAmt = (parseFloat(sell_rate) + parseFloat(Sellingfsc_amt) + parseFloat(SellingDg_surAmt) + parseFloat(SellingOtherChrgs))

        
         var SellingGrandTotalAmount = (parseFloat(SellingAmtBeforeStaxAmt))

          document.getElementById('ctl00_ContentPlaceHolder1_txtSFSCAmount').value = Sellingfsc_amt;

         document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value = SellingAmtBeforeStaxAmt.toFixed(2);
         document.getElementById('ctl00_ContentPlaceHolder1_txtTotalSellingAmtStax').value = SellingGrandTotalAmount.toFixed(2);
    
    }

}
 



