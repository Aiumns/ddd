﻿// JScript File


// Airline  Master Validation
function AirlineCheck()
{
       if(document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineCode").value=="")
		{
		alert("Enter AirlineCode");
		document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineCode").focus();
		return false; 
	    }
	    if(document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineCode").value!="")
		{
	
		   var DestinationCode_val=document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineCode").value;
		         
		    for(i=0;i<DestinationCode_val.length;i++)
		     {
		      if(!((DestinationCode_val.charCodeAt(i)>=48) && (DestinationCode_val.charCodeAt(i)<=57)))
		        {
		        alert(" Enter maximum three digit AirlineCode ");
		        document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineCode").value="";
		        document.getElementById ("ctl00$ContentPlaceHolder1$txtAirlineCode").focus();
		        return false; 
		        }
		           
		     }
	    }
	    
	      if(document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineTextCode").value=="")
		{
		alert("Enter Airline Text Code");
		document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineTextCode").focus();
		return false; 
	    }
	  //****************** should contain only alphabet*******************************************
	    if(document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineTextCode").value!="")
		 {  
		    var str=document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineTextCode").value;
		    for(i=0;i<str.length;i++)
		     {
		      if(!((str.charCodeAt(i)>=65 && str.charCodeAt(i)<=90)||(str.charCodeAt(i)>=97 && str.charCodeAt(i)<=122)||(str.charCodeAt(i)==32)))
		      {
		       alert("Airline Text Code should contain only Alphabets");
		       document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineTextCode").value=""; 
		       document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineTextCode").focus();
		       return false;
		       } 
		     }
		  }
	    
	    
	    if(document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineName").value=="")
		{
		alert("Enter Airline Name");
		document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineName").focus();
		return false; 
	    }
	  //****************** should contain only alphabet*******************************************
	    if(document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineName").value!="")
		 {  
		    var str=document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineName").value;
		    for(i=0;i<str.length;i++)
		     {
		      if(!((str.charCodeAt(i)>=65 && str.charCodeAt(i)<=90)||(str.charCodeAt(i)>=97 && str.charCodeAt(i)<=122)||(str.charCodeAt(i)==32)))
		      {
		       alert("Airline Name should contain only Alphabets");
		       document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineName").value=""; 
		       document.getElementById("ctl00$ContentPlaceHolder1$txtAirlineName").focus();
		       return false;
		       } 
		     }
		  }
		  
		  if( document.getElementById("ctl00$ContentPlaceHolder1$ddlStatus").selectedIndex <= 0)
		  {
		   alert("Please Select Status value");
		   document.getElementById("ctl00$ContentPlaceHolder1$ddlStatus").focus();
		   return false;
		  }
}
// Airline Detail Validation

function blockNonNumbers(obj, e, allowDecimal, allowNegative)
        {
            var key;
            var isCtrl = false;
            var keychar;
            var reg;

            if(window.event) {
            key = e.keyCode;
            isCtrl = window.event.ctrlKey
            }
            else if(e.which) {
            key = e.which;
            isCtrl = e.ctrlKey;
            }

            if (isNaN(key)) return true;

            keychar = String.fromCharCode(key);

            // check for backspace or delete, or if Ctrl was pressed
            if (key == 8 || isCtrl)
            {
            return true;
            }

            reg = /\d/;
            var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
            var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;

            return isFirstN || isFirstD || reg.test(keychar);
        }

function AirlineDetailCheck()
{
    if( document.getElementById("ctl00$ContentPlaceHolder1$ddlAirlineCode").selectedIndex <= 0)
	{
	  alert("Please Select any Airline");
	  document.getElementById("ctl00$ContentPlaceHolder1$ddlAirlineCode").focus();
	  return false;
	}
	if( document.getElementById("ctl00$ContentPlaceHolder1$ddlCity").selectedIndex <= 0)
	{
	  alert("Please Select any City");
	   document.getElementById("ctl00$ContentPlaceHolder1$ddlCity").focus();
	  return false;
	}
	 if(document.getElementById("ctl00$ContentPlaceHolder1$txtDueAgent").value=="")
	 {
		alert("Enter Due Agent");
		document.getElementById("ctl00$ContentPlaceHolder1$txtDueAgent").focus();
		return false; 
	 }
	 if(document.getElementById("ctl00$ContentPlaceHolder1$txtDueCarrier").value=="")
	 {
		alert("Enter Due Carrier");
		document.getElementById("ctl00$ContentPlaceHolder1$txtDueCarrier").focus();
		return false; 
	  }
	  if(document.getElementById("ctl00$ContentPlaceHolder1$txtDisBursementCharges").value=="")
	 {
		alert("Enter DisBursement Charges");
		document.getElementById("ctl00$ContentPlaceHolder1$txtDisBursementCharges").focus();
		return false; 
	  }
	if( document.getElementById("ctl00$ContentPlaceHolder1$ddlCompany").selectedIndex <= 0)
	{
	  alert("Please Select any Company");
	  document.getElementById("ctl00$ContentPlaceHolder1$ddlCompany").focus();
	  return false;
	}
	if( document.getElementById("ctl00$ContentPlaceHolder1$ddlDeal").selectedIndex <= 0)
	{
	  alert("Please Select Deal Type");
	   document.getElementById("ctl00$ContentPlaceHolder1$ddlDeal").focus();
	  return false;
	}
	if( document.getElementById("ctl00$ContentPlaceHolder1$ddlStatus").selectedIndex <= 0)
	{
	  alert("Please Select any Status");
	  document.getElementById("ctl00$ContentPlaceHolder1$ddlStatus").focus();
	  return false;
	}
}