﻿
function Check()
{ 
var count=0;  
         var repeat=0;
          var txtCost=0;
            if(document.getElementById("txtCost").value == ' ')
            {
            document.getElementById("txtCost").value=0;
            }
            else
            {
            txtCost=document.getElementById("txtCost").value;        
            }
           if( txtCost>3)
           {
              document.getElementById("txtCost").value='';  
             alert("Please Enter less than 4.....") 
           }   
                  if( count>=3)
           {
              document.getElementById("txtCost").value='';  
           }
           if(txtCost!=0)
            {
            
           count=count+1;       
            } 
  var txtProfessional=0;
            if(document.getElementById("txtProfessional").value == ' ')
            {
            document.getElementById("txtProfessional").value=0;
            }
            else
            {
            txtProfessional=document.getElementById("txtProfessional").value;
    
            } 
                  if( txtProfessional>3)
           {
              document.getElementById("txtProfessional").value='';  
             alert("Please Enter less than 4.....") 
           }    
                 if( count>=3)
           {
              document.getElementById("txtProfessional").value='';  
           }    
            if(txtProfessional!=0)
            {
           count=count+1;       
            } 

  var txtConsistent=0;
            if(document.getElementById("txtConsistent").value == ' ')
            {
            document.getElementById("txtConsistent").value=0;
            }
            else
            {
            txtConsistent=document.getElementById("txtConsistent").value;
     
            } 
                        if( txtConsistent>3)
           {
              document.getElementById("txtConsistent").value='';  
             alert("Please Enter less than 4.....") 
           }     
                   if( count>=3)
           {
              document.getElementById("txtConsistent").value='';  
           }    
           if(txtConsistent!=0)
            {
           count=count+1;       
            } 
  var txtReliability=0;
            if(document.getElementById("txtReliability").value == ' ')
            {
            document.getElementById("txtReliability").value=0;
            }
            else
            {
            txtReliability=document.getElementById("txtReliability").value;
 
            } 
                                 if( txtReliability>3)
           {
              document.getElementById("txtReliability").value='';  
             alert("Please Enter less than 4.....") 
           }    
                       if( count>=3)
           {
              document.getElementById("txtReliability").value='';  
           }     
         if(txtReliability!=0)
            {
           count=count+1;       
            } 
  var txtNetwork=0;
            if(document.getElementById("txtNetwork").value == ' ')
            {
            document.getElementById("txtNetwork").value=0;
            }
            else
            {
            txtNetwork=document.getElementById("txtNetwork").value;
            } 
                                            if( txtNetwork>3)
           {
              document.getElementById("txtNetwork").value='';  
             alert("Please Enter less than 4.....") 
           }     
                             if( count>=3)
           {
              document.getElementById("txtNetwork").value='';  
           }    
           if(txtNetwork!=0)
            {
           count=count+1;       
            } 
             var txtOther=0;
            if(document.getElementById("txtOther").value == ' ')
            {
            document.getElementById("txtOther").value=0;
            }
            else
            {
            txtOther=document.getElementById("txtOther").value;
            } 
                                                       if( txtOther>3)
           {
              document.getElementById("txtOther").value='';  
             alert("Please Enter less than 4.....") 
           }      
                                   if( count>=3)
           {
              document.getElementById("txtOther").value='';  
           }   
           if(txtOther!=0)
            {
           count=count+1;       
            } 
             var txtSpeed=0;
            if(document.getElementById("txtSpeed").value == ' ')
            {
            document.getElementById("txtSpeed").value=0;
            }
            else
            {
            txtSpeed=document.getElementById("txtSpeed").value;
            } 
                                                                 if( txtSpeed>3)
           {
              document.getElementById("txtSpeed").value='';  
             alert("Please Enter less than 4.....") 
           }    
                                    if( count>=3)
           {
              document.getElementById("txtSpeed").value='';  
           }    
           if(txtSpeed!=0)
            {
           count=count+1;       
            }   
                 var txtExperience=0;
            if(document.getElementById("txtExperience").value == ' ')
            {
            document.getElementById("txtExperience").value=0;
            }
            else
            {
            txtExperience=document.getElementById("txtExperience").value;
            } 
         if( txtExperience>3)
           {
              document.getElementById("txtExperience").value='';  
             alert("Please Enter less than 4.....") 
           }     
              if( count>=3)
           {
              document.getElementById("txtExperience").value='';  
           } 
           if(txtExperience!=0)
            {
           count=count+1;       
            }   

           if(txtCost!="")
           {
                if((txtCost==txtProfessional) || (txtCost==txtConsistent)|| (txtCost==txtReliability)|| (txtCost==txtNetwork)|| (txtCost==txtOther)|| (txtCost==txtSpeed)|| (txtCost==txtExperience)  )  
              {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
   //       alert("You are Authorized upto thee Selection only... ")
           }    
           }
           if(txtProfessional!="")
           {
 if((txtCost==txtProfessional) || (txtProfessional==txtConsistent)|| (txtProfessional==txtReliability)|| (txtProfessional==txtNetwork)|| (txtProfessional==txtOther)|| (txtProfessional==txtSpeed)|| (txtProfessional==txtExperience)  )  
           {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
    //      alert("You are Authorized upto thee Selection only... ")
           }
           } 
               if(txtConsistent!="")
           {
 if((txtCost==txtConsistent) || (txtProfessional==txtConsistent)|| (txtConsistent==txtReliability)|| (txtConsistent==txtNetwork)|| (txtConsistent==txtOther)|| (txtConsistent==txtSpeed)|| (txtConsistent==txtExperience)  )  
           {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
       //  alert("You are Authorized upto thee Selection only... ")
           }
           } 
                   if(txtReliability!="")
           {
 if((txtCost==txtReliability) || (txtProfessional==txtReliability)|| (txtConsistent==txtReliability)|| (txtReliability==txtNetwork)|| (txtReliability==txtOther)|| (txtReliability==txtSpeed)|| (txtReliability==txtExperience)  )  
           {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
     //   alert("You are Authorized upto thee Selection only... ")
           }
           } 
                         if(txtNetwork!="")
           {
 if((txtCost==txtNetwork) || (txtProfessional==txtNetwork)|| (txtConsistent==txtNetwork)|| (txtReliability==txtNetwork)|| (txtNetwork==txtOther)|| (txtNetwork==txtSpeed)|| (txtNetwork==txtExperience)  )  
           {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
    // alert("You are Authorized upto thee Selection only... ")
           }
           } 
                               if(txtOther!="")
           {
 if((txtCost==txtOther) || (txtProfessional==txtOther)|| (txtConsistent==txtOther)|| (txtReliability==txtOther)|| (txtNetwork==txtOther)|| (txtOther==txtSpeed)|| (txtOther==txtExperience)  )  
           {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
   //   alert("You are Authorized upto thee Selection only... ")
           }
           } 
                                     if(txtSpeed!="")
           {
 if((txtCost==txtSpeed) || (txtProfessional==txtSpeed)|| (txtConsistent==txtSpeed)|| (txtReliability==txtSpeed)|| (txtNetwork==txtSpeed)|| (txtOther==txtSpeed)|| (txtSpeed==txtExperience)  )  
           {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
//alert("You are Authorized upto thee Selection only... ")
           }
           } 
                                                if(txtExperience!="")
           {
 if((txtCost==txtExperience) || (txtProfessional==txtExperience)|| (txtConsistent==txtExperience)|| (txtReliability==txtExperience)|| (txtNetwork==txtExperience)|| (txtOther==txtExperience)|| (txtSpeed==txtExperience)  )  
           {
            document.getElementById("txtCost").value=''; 
            document.getElementById("txtProfessional").value=''; 
            document.getElementById("txtConsistent").value=''; 
            document.getElementById("txtReliability").value=''; 
            document.getElementById("txtNetwork").value=''; 
            document.getElementById("txtOther").value=''; 
            document.getElementById("txtSpeed").value=''; 
            document.getElementById("txtExperience").value=''; 
   // alert("You are Authorized upto thee Selection only... ")
           }
           } 
         
            if( count>3)
             {
                   alert("Sorry:-- You have already filled three options....");      
             } 

 }


function Check2()
{ 
var count=0;  
     
          var txtExpensive=0;
            if(document.getElementById("txtExpensive").value == ' ')
            {
            document.getElementById("txtExpensive").value=0;
            }
            else
            {
            txtExpensive=document.getElementById("txtExpensive").value;        
            } 
                     if( txtExpensive>3)
           {
              document.getElementById("txtExpensive").value='';  
             alert("Please Enter less than 4.....") 
           }     
              if( count>=3)
           {
              document.getElementById("txtExpensive").value='';  
           }   
           if(txtExpensive!=0)
            {
           count=count+1;       
            } 
  var txtUnprofessional=0;
            if(document.getElementById("txtUnprofessional").value == ' ')
            {
            document.getElementById("txtUnprofessional").value=0;
            }
            else
            {
            txtUnprofessional=document.getElementById("txtUnprofessional").value;
    
            } 
                                if( txtUnprofessional>3)
           {
              document.getElementById("txtUnprofessional").value='';  
             alert("Please Enter less than 4.....") 
           }   
                 if( count>=3)
           {
              document.getElementById("txtUnprofessional").value='';  
           }    
            if(txtUnprofessional!=0)
            {
           count=count+1;       
            } 

  var txtInconsistent=0;
            if(document.getElementById("txtInconsistent").value == ' ')
            {
            document.getElementById("txtInconsistent").value=0;
            }
            else
            {
            txtInconsistent=document.getElementById("txtInconsistent").value;
     
            } 
                                        if( txtInconsistent>3)
           {
              document.getElementById("txtInconsistent").value='';  
             alert("Please Enter less than 4.....") 
           }    
                   if( count>=3)
           {
              document.getElementById("txtInconsistent").value='';  
           }    
           if(txtInconsistent!=0)
            {
           count=count+1;       
            } 
  var txtUnreliable=0;
            if(document.getElementById("txtUnreliable").value == ' ')
            {
            document.getElementById("txtUnreliable").value=0;
            }
            else
            {
            txtUnreliable=document.getElementById("txtUnreliable").value;
 
            } 
                                                   if( txtUnreliable>3)
           {
              document.getElementById("txtUnreliable").value='';  
             alert("Please Enter less than 4.....") 
           }     
                       if( count>=3)
           {
              document.getElementById("txtUnreliable").value='';  
           }     
         if(txtUnreliable!=0)
            {
           count=count+1;       
            } 
  var txtNetwork1=0;
            if(document.getElementById("txtNetwork1").value == ' ')
            {
            document.getElementById("txtNetwork1").value=0;
            }
            else
            {
            txtNetwork1=document.getElementById("txtNetwork1").value;
            } 
                                                              if( txtNetwork1>3)
           {
              document.getElementById("txtNetwork1").value='';  
             alert("Please Enter less than 4.....") 
           }      
                             if( count>=3)
           {
              document.getElementById("txtNetwork1").value='';  
           }    
           if(txtNetwork1!=0)
            {
           count=count+1;       
            } 
             var txtOther1=0;
            if(document.getElementById("txtOther1").value == ' ')
            {
            document.getElementById("txtOther1").value=0;
            }
            else
            {
            txtOther1=document.getElementById("txtOther1").value;
            } 
                                                                         if( txtOther1>3)
           {
              document.getElementById("txtOther1").value='';  
             alert("Please Enter less than 4.....") 
           }    
                                   if( count>=3)
           {
              document.getElementById("txtOther1").value='';  
           }   
           if(txtOther1!=0)
            {
           count=count+1;       
            } 
             var txtSpeed1=0;
            if(document.getElementById("txtSpeed1").value == ' ')
            {
            document.getElementById("txtSpeed1").value=0;
            }
            else
            {
            txtSpeed1=document.getElementById("txtSpeed1").value;
            } 
                                                                                    if( txtSpeed1>3)
           {
              document.getElementById("txtSpeed1").value='';  
             alert("Please Enter less than 4.....") 
           }     
                                    if( count>=3)
           {
              document.getElementById("txtSpeed1").value='';  
           }    
           if(txtSpeed1!=0)
            {
           count=count+1;       
            }   
                 var txtInexperienced=0;
            if(document.getElementById("txtInexperienced").value == ' ')
            {
            document.getElementById("txtInexperienced").value=0;
            }
            else
            {
            txtInexperienced=document.getElementById("txtInexperienced").value;
            } 
                                                                                               if( txtInexperienced>3)
           {
              document.getElementById("txtInexperienced").value='';  
             alert("Please Enter less than 4.....") 
           }      
              if( count>=3)
           {
              document.getElementById("txtInexperienced").value='';  
           } 
           if(txtInexperienced!=0)
            {
           count=count+1;       
            }   
//                               if(txtExpensive!="")
//           {
// if((txtExpensive==txtUnprofessional) || (txtExpensive==txtInconsistent)|| (txtExpensive==txtUnreliable)|| (txtExpensive==txtNetwork1)|| (txtExpensive==txtOther1)|| (txtExpensive==txtSpeed1)|| (txtReliability==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 
//                                    if(txtUnprofessional!="")
//           {
// if((txtExpensive==txtUnprofessional) || (txtUnprofessional==txtInconsistent)|| (txtUnprofessional==txtUnreliable)|| (txtUnprofessional==txtNetwork1)|| (txtUnprofessional==txtOther1)|| (txtUnprofessional==txtSpeed1)|| (txtUnprofessional==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 
//                                        if(txtInconsistent!="")
//           {
// if((txtExpensive==txtInconsistent) || (txtUnprofessional==txtInconsistent)|| (txtInconsistent==txtUnreliable)|| (txtInconsistent==txtNetwork1)|| (txtInconsistent==txtOther1)|| (txtInconsistent==txtSpeed1)|| (txtInconsistent==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 
//                                               if(txtUnreliable!="")
//           {
// if((txtExpensive==txtUnreliable) || (txtUnprofessional==txtUnreliable)|| (txtUnreliable==txtUnreliable)|| (txtUnreliable==txtNetwork1)|| (txtUnreliable==txtOther1)|| (txtUnreliable==txtSpeed1)|| (txtUnreliable==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 
//                                                          if(txtNetwork1!="")
//           {
// if((txtExpensive==txtNetwork1) || (txtUnprofessional==txtNetwork1)|| (txtUnreliable==txtNetwork1)|| (txtUnreliable==txtNetwork1)|| (txtNetwork1==txtOther1)|| (txtNetwork1==txtSpeed1)|| (txtNetwork1==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 
//                                                                    if(txtNetwork1!="")
//           {
// if((txtExpensive==txtOther1) || (txtUnprofessional==txtOther1)|| (txtUnreliable==txtOther1)|| (txtUnreliable==txtOther1)|| (txtNetwork1==txtOther1)|| (txtOther1==txtSpeed1)|| (txtOther1==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 
//                                                                               if(txtNetwork1!="")
//           {
// if((txtExpensive==txtSpeed1) || (txtUnprofessional==txtSpeed1)|| (txtUnreliable==txtSpeed1)|| (txtUnreliable==txtSpeed1)|| (txtNetwork1==txtSpeed1)|| (txtOther1==txtSpeed1)|| (txtSpeed1==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 
//                                                                                       if(txtNetwork1!="")
//           {
// if((txtExpensive==txtInexperienced) || (txtUnprofessional==txtInexperienced)|| (txtUnreliable==txtInexperienced)|| (txtUnreliable==txtInexperienced)|| (txtNetwork1==txtInexperienced)|| (txtOther1==txtInexperienced)|| (txtSpeed1==txtInexperienced)  )  
//           {
//            document.getElementById("txtExpensive").value=''; 
//            document.getElementById("txtUnprofessional").value=''; 
//            document.getElementById("txtInconsistent").value=''; 
//            document.getElementById("txtUnreliable").value=''; 
//            document.getElementById("txtNetwork1").value=''; 
//            document.getElementById("txtOther1").value=''; 
//            document.getElementById("txtSpeed1").value=''; 
//            document.getElementById("txtInexperienced").value=''; 
////           alert("You are Authorized upto thee Selection only... ")
//           }
//           } 

            if( count>3)
             {
                   alert("Sorry:-- You have already filled three options....");      
             } 
     
 } 
