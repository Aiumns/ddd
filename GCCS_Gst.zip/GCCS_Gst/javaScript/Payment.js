﻿// JScript File

function blockNonNumbers(obj, e, allowDecimal, allowNegative)
        {
            var key;
            var isCtrl = false;
            var keychar;
            var reg;

            if(window.event) {
            key = e.keyCode;
            isCtrl = window.event.ctrlKey
            }
            else if(e.which) {
            key = e.which;
            isCtrl = e.ctrlKey;
            }

            if (isNaN(key)) return true;

            keychar = String.fromCharCode(key);

            // check for backspace or delete, or if Ctrl was pressed
            if (key == 8 || isCtrl)
            {
            return true;
            }

            reg = /\d/;
            var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
            var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;

            return isFirstN || isFirstD || reg.test(keychar);
        }


       function isDigit(c) 
        {
            var test=c; 
            if(test=="0"||test=="1" ||test=="2"||test=="3"||test=="4" ||test=="5"||test=="6"||test== "7"||test=="8"||               test=="9"||test== ".") 
            {
             return true; 
            }
            else 
            return false; 
        }
//    function CheckEmpty()
//    {
//       
//           if (document.getElementById("ctl00$ContentPlaceHolder1$ddlAirline").value == 'y')
//           {
//             alert("Please Select Airline");
//             document.getElementById("ctl00$ContentPlaceHolder1$ddlAirline").focus();
//             return false;
//           }   

//         else
//         {
//            return true;
//         }
//        
//    }
    
    function CheckEmpty()
    {
  if(document.getElementById('<%=ddlCSR.ClientID %>').selectedIndex<=0)
		    {
		        alert("Please Select CSR ");
		        document.getElementById('<%=ddlCSR.ClientID %>').focus();
		        return false;
		    }
		         
        
  if (document.getElementById('<%=txtAmount.ClientID %>').value == '')
         {
            alert("Please Enter Amount");
            document.getElementById('<%=txtAmount.ClientID %>').focus();
            return false;
        }
        
            if (document.getElementById('<%=txtTDSCutAgent.ClientID %>').value == '')
           {
             alert("Please Enter TDS Cut By Agent");
             document.getElementById('<%=txtTDSCutAgent.ClientID %>').focus();
             return false;
           }
            
  	 
     if (document.getElementById("ctl00$ContentPlaceHolder1$txtCheque").value == '')
           {
             alert("Please enter Cheque No.");
             document.getElementById("ctl00$ContentPlaceHolder1$txtCheque").focus();
             return false;
           }
   if (document.getElementById("ctl00$ContentPlaceHolder1$txtBankName").value == '')
           {
             alert("Please Enter Bank Name");
             document.getElementById("ctl00$ContentPlaceHolder1$txtBankName").focus();
             return false;
           }
           
//             

             if (document.getElementById("ctl00$ContentPlaceHolder1$txtBranchName").value == '')
           {
             alert("Please Enter Branch Name");
             document.getElementById("ctl00$ContentPlaceHolder1$txtBranchName").focus();
             return false;
           }  
           if (document.getElementById("ctl00$ContentPlaceHolder1$ddlAccountName").selectedIndex<=0)
         {
            alert("Please Select Account Name ");
            document.getElementById("ctl00$ContentPlaceHolder1$ddlAccountName").focus();
            return false;
        }                   
        
        var amount=document.getElementById("ctl00$ContentPlaceHolder1$txtAmount").value;
        var TDSCutAgent=document.getElementById("ctl00$ContentPlaceHolder1$txtTDSCutAgent").value  ; 
        var ServiceTaxCutAgent=document.getElementById("ctl00$ContentPlaceHolder1$txtservicetaxcut").value;
        var ShortExcess=document.getElementById("ctl00$ContentPlaceHolder1$txtAdjAmt").value;
        var Paid_amount =parseFloat(amount)+parseFloat(TDSCutAgent)+parseFloat(ServiceTaxCutAgent)+parseFloat(ShortExcess);

        var Total_Amount=document.getElementById("ctl00_ContentPlaceHolder1_Hidden1").value;
//        alert(Paid_amount);
//        alert(Total_Amount);
//        if(Paid_amount>Total_Amount)      
//        {
//        alert('Received Amount is Greater than Invoice Amount.Please Update It.');
//        return false;
//        } 
        if(Paid_amount<Total_Amount)      
        {
        var short_amt=Total_Amount-Paid_amount;
        var status=confirm('This Entry Contains Rs. '+short_amt+ ' of Short Payment.Do you want to Continue?')
        if(status)
        {
        return true ;
        }
        else
        {
         return false;
        }
        }     

        else
        {
            return true;
        }
    }
    
        //FUNCTION FOR CONFIRMATION ON PAYMENT DECLINED    
        
        function declined_confirmation()
        {
                var status=confirm('Are you sure you want to mark this payment as declined?');
                if(status)
                {
                    return true ;
                }
                else
                {
                    return false;
                }
        }
    
function chk_Amount()
{
//   var Paid_amount = document.getElementById("ctl00$ContentPlaceHolder1$txtAmount").value;

        var amount=document.getElementById("ctl00$ContentPlaceHolder1$txtAmount").value;
        var TDSCutAgent=document.getElementById("ctl00$ContentPlaceHolder1$txtTDSCutAgent").value  ; 
        var ServiceTaxCutAgent=document.getElementById("ctl00$ContentPlaceHolder1$txtservicetaxcut").value;
        var txtAdjAmt=document.getElementById("ctl00$ContentPlaceHolder1$txtAdjAmt").value;
        var Paid_amount =parseFloat(amount)+parseFloat(TDSCutAgent)+parseFloat(ServiceTaxCutAgent)+parseFloat(txtAdjAmt);
  var Total_Amount=document.getElementById("ctl00_ContentPlaceHolder1_Hidden1").value;
//alert(Paid_amount);
//   alert(Total_Amount);
   
   //Excess
   if(Paid_amount>Total_Amount)
   {
        var short_excess= Paid_amount-Total_Amount;
        document.getElementById("ctl00$ContentPlaceHolder1$txtShortExcess").value =parseFloat(short_excess);
       
   }
   //Short
   else if(Paid_amount<Total_Amount)
    {
        var short_amt= parseFloat(Total_Amount-Paid_amount);
         document.getElementById("ctl00$ContentPlaceHolder1$txtShortExcess").value = -short_amt;
//        if(short_amt<100)
//        {
//        document.getElementById("ctl00$ContentPlaceHolder1$txtShortExcess").value = -short_amt;
//        }
//        else
//        {
//         document.getElementById("ctl00$ContentPlaceHolder1$txtShortExcess").value =0;
//        }
    }
    else
    {
     document.getElementById("ctl00$ContentPlaceHolder1$txtShortExcess").value = 0;
    }
    
   
   
   return true;
}
    


