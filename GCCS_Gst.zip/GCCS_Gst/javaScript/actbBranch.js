function actbBranch(obj,ca){
	/* ---- Public Variables ---- */
	this.actbBranch_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbBranch_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbBranch_firstText = false; // should the auto complete be limited to the beginning of keyword?
	this.actbBranch_mouse = true; // Enable Mouse Support
	this.actbBranch_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbBranch_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbBranch_bgColor = '#F1F0F0';
	this.actbBranch_textColor = '#D60000';
	this.actbBranch_hColor = '#FFFFFF';
	this.actbBranch_fFamily = 'Verdana';
	this.actbBranch_fSize = '11px';
	this.actbBranch_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbBranch_delimwords = new Array();
	var actbBranch_cdelimword = 0;
	var actbBranch_delimchar = new Array();
	var actbBranch_display = false;
	var actbBranch_pos = 0;
	var actbBranch_total = 0;
	var actbBranch_curr = null;
	var actbBranch_rangeu = 0;
	var actbBranch_ranged = 0;
	var actbBranch_bool = new Array();
	var actbBranch_pre = 0;
	var actbBranch_toid;
	var actbBranch_tomake = false;
	var actbBranch_getpre = "";
	var actbBranch_mouse_on_list = 1;
	var actbBranch_kwcount = 0;
	var actbBranch_caretmove = false;
	this.actbBranch_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbBranch_keywords = ca;
	var actbBranch_self = this;

	actbBranch_curr = obj;
	
	addEvent(actbBranch_curr,"focus",actbBranch_setup);
	function actbBranch_setup(){
		addEvent(document,"keydown",actbBranch_checkkey);
		addEvent(actbBranch_curr,"blur",actbBranch_clear);
		addEvent(document,"keypress",actbBranch_keypress);
	}

	function actbBranch_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbBranch_checkkey);
		removeEvent(actbBranch_curr,"blur",actbBranch_clear);
		removeEvent(document,"keypress",actbBranch_keypress);
		actbBranch_removedisp();
	}
	function actbBranch_parse(n){
		if (actbBranch_self.actbBranch_delimiter.length > 0){
			var t = actbBranch_delimwords[actbBranch_cdelimword].addslashes();
			var plen = actbBranch_delimwords[actbBranch_cdelimword].length;
		}else{
			var t = actbBranch_curr.value.addslashes();
			var plen = actbBranch_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbBranch_self.actbBranch_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbBranch_self.actbBranch_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbBranch_generate(){
		if (document.getElementById('tat_table')){ actbBranch_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbBranch_kwcount == 0){
			actbBranch_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbBranch_curr) + actbBranch_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbBranch_curr) + "px";
		a.style.backgroundColor=actbBranch_self.actbBranch_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbBranch_self.actbBranch_mouse){
			a.onmouseout = actbBranch_table_unfocus;
			a.onmouseover = actbBranch_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbBranch_self.actbBranch_keywords.length;i++){
			if (actbBranch_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbBranch_tomake){
					r.style.backgroundColor = actbBranch_self.actbBranch_hColor;
					first = false;
					actbBranch_pos = counter;
				}else if(actbBranch_pre == i){
					r.style.backgroundColor = actbBranch_self.actbBranch_hColor;
					first = false;
					actbBranch_pos = counter;
				}else{
					r.style.backgroundColor = actbBranch_self.actbBranch_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbBranch_self.actbBranch_textColor;
				c.style.fontFamily = actbBranch_self.actbBranch_fFamily;
				c.style.fontSize = actbBranch_self.actbBranch_fSize;
				c.innerHTML = actbBranch_parse(actbBranch_self.actbBranch_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbBranch_self.actbBranch_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbBranch_mouseclick;
					c.onmouseover = actbBranch_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbBranch_self.actbBranch_lim && j < actbBranch_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbBranch_self.actbBranch_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbBranch_self.actbBranch_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbBranch_self.actbBranch_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbBranch_self.actbBranch_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbBranch_mouse_down;
				}
				break;
			}
		}
		actbBranch_rangeu = 1;
		actbBranch_ranged = j-1;
		actbBranch_display = true;
		if (actbBranch_pos <= 0) actbBranch_pos = 1;
	}
	function actbBranch_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbBranch_curr) + actbBranch_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbBranch_curr) + "px";
		a.style.backgroundColor=actbBranch_self.actbBranch_bgColor;
		a.id = 'tat_table';
		if (actbBranch_self.actbBranch_mouse){
			a.onmouseout= actbBranch_table_unfocus;
			a.onmouseover=actbBranch_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbBranch_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbBranch_self.actbBranch_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbBranch_self.actbBranch_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbBranch_self.actbBranch_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbBranch_self.actbBranch_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbBranch_mouse_up;
			}
		}
		for (i=0;i<actbBranch_self.actbBranch_keywords.length;i++){
			if (actbBranch_bool[i]){
				if (j >= actbBranch_rangeu && j <= actbBranch_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbBranch_self.actbBranch_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbBranch_self.actbBranch_textColor;
					c.style.fontFamily = actbBranch_self.actbBranch_fFamily;
					c.style.fontSize = actbBranch_self.actbBranch_fSize;
					c.innerHTML = actbBranch_parse(actbBranch_self.actbBranch_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbBranch_self.actbBranch_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbBranch_mouseclick;
						c.onmouseover = actbBranch_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbBranch_ranged) break;
		}
		if (j-1 < actbBranch_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbBranch_self.actbBranch_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbBranch_self.actbBranch_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbBranch_self.actbBranch_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbBranch_self.actbBranch_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbBranch_mouse_down;
			}
		}
	}
	function actbBranch_goup(){
		if (!actbBranch_display) return;
		if (actbBranch_pos == 1) return;
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_bgColor;
		actbBranch_pos--;
		if (actbBranch_pos < actbBranch_rangeu) actbBranch_moveup();
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_hColor;
		if (actbBranch_toid) clearTimeout(actbBranch_toid);
		if (actbBranch_self.actbBranch_timeOut > 0) actbBranch_toid = setTimeout(function(){actbBranch_mouse_on_list=0;actbBranch_removedisp();},actbBranch_self.actbBranch_timeOut);
	}
	function actbBranch_godown(){
		if (!actbBranch_display) return;
		if (actbBranch_pos == actbBranch_total) return;
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_bgColor;
		actbBranch_pos++;
		if (actbBranch_pos > actbBranch_ranged) actbBranch_movedown();
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_hColor;
		if (actbBranch_toid) clearTimeout(actbBranch_toid);
		if (actbBranch_self.actbBranch_timeOut > 0) actbBranch_toid = setTimeout(function(){actbBranch_mouse_on_list=0;actbBranch_removedisp();},actbBranch_self.actbBranch_timeOut);
	}
	function actbBranch_movedown(){
		actbBranch_rangeu++;
		actbBranch_ranged++;
		actbBranch_remake();
	}
	function actbBranch_moveup(){
		actbBranch_rangeu--;
		actbBranch_ranged--;
		actbBranch_remake();
	}

	/* Mouse */
	function actbBranch_mouse_down(){
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_bgColor;
		actbBranch_pos++;
		actbBranch_movedown();
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_hColor;
		actbBranch_curr.focus();
		actbBranch_mouse_on_list = 0;
		if (actbBranch_toid) clearTimeout(actbBranch_toid);
		if (actbBranch_self.actbBranch_timeOut > 0) actbBranch_toid = setTimeout(function(){actbBranch_mouse_on_list=0;actbBranch_removedisp();},actbBranch_self.actbBranch_timeOut);
	}
	function actbBranch_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_bgColor;
		actbBranch_pos--;
		actbBranch_moveup();
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_hColor;
		actbBranch_curr.focus();
		actbBranch_mouse_on_list = 0;
		if (actbBranch_toid) clearTimeout(actbBranch_toid);
		if (actbBranch_self.actbBranch_timeOut > 0) actbBranch_toid = setTimeout(function(){actbBranch_mouse_on_list=0;actbBranch_removedisp();},actbBranch_self.actbBranch_timeOut);
	}
	function actbBranch_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbBranch_display) return;
		actbBranch_mouse_on_list = 0;
		actbBranch_pos = this.getAttribute('pos');
		actbBranch_penter();
	}
	function actbBranch_table_focus(){
		actbBranch_mouse_on_list = 1;
	}
	function actbBranch_table_unfocus(){
		actbBranch_mouse_on_list = 0;
		if (actbBranch_toid) clearTimeout(actbBranch_toid);
		if (actbBranch_self.actbBranch_timeOut > 0) actbBranch_toid = setTimeout(function(){actbBranch_mouse_on_list = 0;actbBranch_removedisp();},actbBranch_self.actbBranch_timeOut);
	}
	function actbBranch_table_highlight(){
		actbBranch_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_bgColor;
		actbBranch_pos = this.getAttribute('pos');
		while (actbBranch_pos < actbBranch_rangeu) actbBranch_moveup();
		while (actbBranch_pos > actbBranch_ranged) actbBranch_movedown();
		document.getElementById('tat_tr'+actbBranch_pos).style.backgroundColor = actbBranch_self.actbBranch_hColor;
		if (actbBranch_toid) clearTimeout(actbBranch_toid);
		if (actbBranch_self.actbBranch_timeOut > 0) actbBranch_toid = setTimeout(function(){actbBranch_mouse_on_list = 0;actbBranch_removedisp();},actbBranch_self.actbBranch_timeOut);
	}
	/* ---- */

	function actbBranch_insertword(a){
		if (actbBranch_self.actbBranch_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbBranch_delimwords.length;i++){
				if (actbBranch_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbBranch_delimwords[i].length;++j){
						if (actbBranch_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbBranch_delimwords[i].length-1;j>=0;--j){
						if (actbBranch_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbBranch_delimwords[i];
				}
				if (i != actbBranch_delimwords.length - 1){
					str += actbBranch_delimchar[i];
				}
			}
			actbBranch_curr.value = str;
			setCaret(actbBranch_curr,l);
		}else{
			actbBranch_curr.value = a;
		}
		actbBranch_mouse_on_list = 0;
		actbBranch_removedisp();
	}
	function actbBranch_penter(){
		if (!actbBranch_display) return;
		actbBranch_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbBranch_self.actbBranch_keywords.length;i++){
			if (actbBranch_bool[i]) c++;
			if (c == actbBranch_pos){
				word = actbBranch_self.actbBranch_keywords[i];
				break;
			}
		}
		actbBranch_insertword(word);
		l = getCaretStart(actbBranch_curr);
	}
	function actbBranch_removedisp(){
		if (actbBranch_mouse_on_list==0){
			actbBranch_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbBranch_toid) clearTimeout(actbBranch_toid);
		}
	}
	function actbBranch_keypress(e){
		if (actbBranch_caretmove) stopEvent(e);
		return !actbBranch_caretmove;
	}
	function actbBranch_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbBranch_curr);
		actbBranch_caretmove = 0;
		switch (a){
			case 38:
				actbBranch_goup();
				actbBranch_caretmove = 1;
				return false;
				break;
			case 40:
				actbBranch_godown();
				actbBranch_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbBranch_display){
					actbBranch_caretmove = 1;
					actbBranch_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbBranch_tocomplete(a)},50);
				break;
		}
	}

	function actbBranch_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbBranch_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbBranch_self.actbBranch_keywords.length;i++){
				if (actbBranch_bool[i]) c++;
				if (c == actbBranch_pos){
					word = i;
					break;
				}
			}
			actbBranch_pre = word;
		}else{ actbBranch_pre = -1};
		
		if (actbBranch_curr.value == ''){
			actbBranch_mouse_on_list = 0;
			actbBranch_removedisp();
			return;
		}
		if (actbBranch_self.actbBranch_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbBranch_curr);
			caret_pos_end = getCaretEnd(actbBranch_curr);
			
			delim_split = '';
			for (i=0;i<actbBranch_self.actbBranch_delimiter.length;i++){
				delim_split += actbBranch_self.actbBranch_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbBranch_delimwords = new Array();
			actbBranch_delimwords[0] = '';
			for (i=0,j=actbBranch_curr.value.length;i<actbBranch_curr.value.length;i++,j--){
				if (actbBranch_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbBranch_curr.value.substr(i,j).match(delim_split_rx);
					actbBranch_delimchar[c] = ma[1];
					c++;
					actbBranch_delimwords[c] = '';
				}else{
					actbBranch_delimwords[c] += actbBranch_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbBranch_cdelimword = -1;
			for (i=0;i<actbBranch_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbBranch_delimwords[i].length){
					actbBranch_cdelimword = i;
				}
				l+=actbBranch_delimwords[i].length + 1;
			}
			var ot = actbBranch_delimwords[actbBranch_cdelimword]; 
			var t = actbBranch_delimwords[actbBranch_cdelimword].addslashes();
		}else{
			var ot = actbBranch_curr.value;
			var t = actbBranch_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbBranch_mouse_on_list = 0;
			actbBranch_removedisp();
		}
		if (ot.length < actbBranch_self.actbBranch_startcheck) return this;
		if (actbBranch_self.actbBranch_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbBranch_total = 0;
		actbBranch_tomake = false;
		actbBranch_kwcount = 0;
		for (i=0;i<actbBranch_self.actbBranch_keywords.length;i++){
			actbBranch_bool[i] = false;
			if (re.test(actbBranch_self.actbBranch_keywords[i])){
				actbBranch_total++;
				actbBranch_bool[i] = true;
				actbBranch_kwcount++;
				if (actbBranch_pre == i) actbBranch_tomake = true;
			}
		}

		if (actbBranch_toid) clearTimeout(actbBranch_toid);
		if (actbBranch_self.actbBranch_timeOut > 0) actbBranch_toid = setTimeout(function(){actbBranch_mouse_on_list = 0;actbBranch_removedisp();},actbBranch_self.actbBranch_timeOut);
		actbBranch_generate();
	}
	return this;
}