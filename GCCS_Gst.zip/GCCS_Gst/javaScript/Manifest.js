﻿
function ReturnPfm(obj,obj1,obj3)
{
$.ajax({
                        url: "Handler/Returnpfm.ashx",
                        data: "&ULD_ID=" + obj + "&Email="+obj1,
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
         __doPostBack(this,"");
          
                     }
                        }
                    }); 

}


function UpdateULDNew(obj,obj1,obj2)
{
 $.ajax({
                        url: "Handler/UldNoUpdate.ashx",
                        data: "&OldUldno=" + obj + "&NewUldNo="+obj1+"&Flight_Open_Id="+obj2,
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
            
            location.reload();
          
                     }
                        }
                    }); 


}



function TransferManifest(obj,obj1)
{

 $.ajax({
                        url: "Handler/UldTransfer.ashx",
                        data: "&Uldno=" + obj + "&Id="+obj1,
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
          
                     }
                        }
                    }); 

}


function UldOperation(obj,Operation,FlightId)
{

$.ajax({
                        url: "Handler/UldTransfer.ashx",
                        data: "&Uldno=" + obj + "&Id="+Operation+"&Flight_Open_ID="+FlightId,
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
          
                     }
                        }
                    }); 
}





function manifest(obj,obj1,CargoType)
{


var array = obj.split(',');
var Partshipment="";
var Partpcs="";
var totalpcs="";
var pfm_id_value="";

var uld=document.getElementById("ctl00_ContentPlaceHolder1_txtuldno").value.toUpperCase(); 
for(var a=0;a<array.length;a++)
{


var RadioButtonListyes=$("#RadioButtonListyes"+array[a]+"").attr("checked");
var txt= $("#txt"+array[a]+"").val();
if(txt=='')
{
txt=0;
}
var radiovalue=0;
      if(RadioButtonListyes)
                              {
                              radiovalue=1;
                              }
                               var lblPCs = $("#lbl"+array[a]+"").text();
                               var pfm_id=$("#lblpid"+array[a]+"").text()
                                var hid= array[a];
                            Partshipment += radiovalue + ",";
                            Partpcs += txt + ",";
                            totalpcs += lblPCs + ","; 
                            pfm_id_value +=pfm_id + ","; 
                               

}
  $.ajax({
                        url: "Handler/Manifest.ashx",
                        data: "&HID=" + obj + "&Partshipment=" + Partshipment + "&Partpcs=" + Partpcs + "&totalpcs=" + totalpcs+"&uld="+uld+"&mailid="+obj1+"&pid="+pfm_id_value+"&CargoType="+CargoType,
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
          
                     }
                        }
                    }); 


}




function OffloadBulk(obj,obj1)
{

var array = obj.split(',');
var Partshipment="";
var Partpcs="";
var totalpcs="";

for(var a=0;a<array.length;a++)
{


var RadioButtonListyes=$("#RadioButtonListyes"+array[a]+"").attr("checked");
var txt= $("#txt"+array[a]+"").val();
if(txt=='')
{
txt=0;
}
var radiovalue=0;
      if(RadioButtonListyes)
                              {
                              radiovalue=1;
                              }
                               var lblPCs = $("#lbl"+array[a]+"").text();
                                                             var hid= array[a];
                            Partshipment += radiovalue + ",";
                            Partpcs += txt + ",";
                            totalpcs += lblPCs + ","; 
                         
  }




var Rem=document.getElementById("ctl00_ContentPlaceHolder1_txtremarks").value; 
 $.ajax({
                        url: "Handler/OffloadCargo.ashx",
                        data: "&Uldno=" + obj + "&Id="+obj1+"&Partshipment=" + Partshipment + "&Partpcs=" + Partpcs + "&totalpcs=" + totalpcs+"&Remarks="+Rem+"&CargoType=B",
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
          
                     }
                        }
                    }); 

}



function OffloadUld(obj,obj1)
{

var Rem=document.getElementById("ctl00_ContentPlaceHolder1_txtremarks").value; 
 $.ajax({
                        url: "Handler/OffloadCargo.ashx",
                        data: "&Uldno=" + obj + "&Id="+obj1+"&Remarks="+Rem+"&CargoType=U",
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
          
                     }
                        }
                    }); 

}


function finalise(obj,CargoType,obj1)
{

var array = obj.split(',');
var arraycargo=CargoType.split(',');
var Partshipment="";
var Partpcs="";
var totalpcs="";

var egm=$("#txtegmno").val();
var txtMarksOfNationality =$("#txtMarksOfNamtionality").val();

for(var a=0;a<array.length;a++)
{


var RadioButtonListyes=$("#RadioButtonListyes"+array[a]+"").attr("checked");
var txt="";
if(arraycargo[a]=='U')
{
txt=0;
}
else
{
txt= $("#txt"+array[a]+"").val();
}

if(txt=='')
{
txt=0;
}
var radiovalue=0;
      if(RadioButtonListyes)
                              {
                              radiovalue=1;
                              }
                               var lblPCs = $("#lbl"+array[a]+"").text();
                                                          
                            Partshipment += radiovalue + ",";
                            Partpcs += txt + ",";
                            totalpcs += lblPCs + ","; 
                         
                               

}

  $.ajax({
          url: "Handler/FinaliseManifest.ashx",
            data: "&Uid=" + obj + "&Partshipment=" + Partshipment + "&Partpcs=" + Partpcs + "&totalpcs=" + totalpcs+"&mailid="+obj1+"&egmno="+egm+"&txtMarksOfNationality="+txtMarksOfNationality+"&cargotype="+CargoType,
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 
            {
                     }
                        }
                    }); 
}
function returntoPFM(obj,obj1)
{
//$("#txtegmno").val()
//  $("#txtMarksOfNamtionality").val()

var array = obj.split(',');
var Partshipment="";
var Partpcs="";
var totalpcs="";
var pfm_id_value="";
var pfm="true";


for(var a=0;a<array.length;a++)
{


var RadioButtonListyes=$("#RadioButtonListyes"+array[a]+"").attr("checked");
var txt= $("#txt"+array[a]+"").val();

if(txt=='')
{
txt=0;
}
var radiovalue=0;
      if(RadioButtonListyes)
                              {
                              radiovalue=1;
                              }
                               var lblPCs = $("#lbl"+array[a]+"").text();
                                                          
                            Partshipment += radiovalue + ",";
                            Partpcs += txt + ",";
                            totalpcs += lblPCs + ","; 
                         
                               

}






  $.ajax({
          url: "Handler/FinaliseManifest.ashx",
            data: "&Uid=" + obj + "&Partshipment=" + Partshipment + "&Partpcs=" + Partpcs + "&totalpcs=" + totalpcs+"&mailid="+obj1+"&pid="+pfm,
                        cache: false,
                        async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
          
                     }
                        }
                    }); 


}



function returntohandover(obj,obj1)
{

var array = obj.split(',');
var pfm_id_value="";

var Partshipment="";
var Partpcs = "";


var Remarks = document.getElementById("ctl00_ContentPlaceHolder1_txtRemarks").value; 

for(var a=0;a<array.length;a++)
{
var RadioButtonListyes=$("#RadioButtonListyes"+array[a]+"").attr("checked");
var txt= $("#txt"+array[a]+"").val();
if(txt=='')
{
txt=0;
}
var radiovalue=0;
      if(RadioButtonListyes)
                              {
                              radiovalue=1;
                              }
                               var lblPCs = $("#lbl"+array[a]+"").text();
                               var pfm_id=$("#lblpid"+array[a]+"").text()
                                var hid= array[a];
                            Partshipment += radiovalue + ",";
                            Partpcs += txt + ",";
                           
                            pfm_id_value +=pfm_id + ",";

                        
                               
                               

}
  $.ajax({
  url: "Handler/ReturnToHandover.ashx",
                        data: "&HID=" + obj + "&Partshipment=" + Partshipment + "&Partpcs=" + Partpcs + "&mailid="+obj1+"&pid="+pfm_id_value+"&Remarks="+Remarks,
                        cache: false,
                         async:false,
                        dataType: "text",
                        success: function(data) {
                            if (data != null) 


            {
          
                     }
                        }
                    }); 


}







 