﻿
function btnnext_ValidationCheck()
	{
		
	// Numeric Validation
//var str= document.getElementById("ctl00_ContentPlaceHolder1_txtsurchrg").value;
//       
//		var dot="."
//		
//		var lstr=str.length
//		var ldot=str.indexOf(dot)
//		
//		if (str.indexOf(dot)+1==lstr){
//		    alert("Invalid E-mail ID")
//		    return false
//		    }

//		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
//		    alert("Invalid E-mail ID")
//		    return false
//		    }

//		 if (str.indexOf(dot,(lat+2))==-1){
//		    alert("Invalid E-mail ID")
//		    return false
//		    }
//		
//		 if (str.indexOf(" ")!=-1){
//		    alert("Invalid E-mail ID")
//		    return false
//		    }

 			
	//// end of Numeric validation    	
		
		
		
		
		
//		     //only Numeric values
//		      
//         if(document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value!="")
//		  {
//		   var AirlineCode_val=document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value;
//		         
//  
//		          for(i=0;i<AirlineCode_val.length;i++)
//		          {
//		          if(!((AirlineCode_val.charCodeAt(i)>=48) && (AirlineCode_val.charCodeAt(i)<=57)))
//		            {
//		            alert(" Enter only Numeric values ");
//		            document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value="";
//		            document.getElementById ("ctl00_ContentPlaceHolder1_AirlineCode").focus();
//		            return false; 
//		            }
//		          }
//		          
//		           if((AirlineCode_val.length)<3)
//		         {
//		        alert(" Enter 3 digit Airline Code ");
//		        document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value=""; 
//		        document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").focus();
//		        return false; 
//		        }
//		          
//		      }
		      
//  Second.. Airline Line Code Text
          
//          if(document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value=="")
//		{
//		alert("Enter AirlineCode Text");
//		document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").focus();
//		return false; 
//	    }
// 
// 
//		 if(document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value!="")
//		 { 
//		 var str=document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value;
//		 for(i=0;i<str.length;i++)
//		 {
//		 // name starting with space
//		 
//		   if(i==0 && str.charCodeAt(i)==32)
//		    {
//		     alert(" AirlineCode Text should not start with Space");
//		     document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value="";
//		     document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").focus();
//		     return false;
//		     }
		    
		    // should contain only alphabet
		    
//		      if(!((str.charCodeAt(i)>=65 && str.charCodeAt(i)<=90)||(str.charCodeAt(i)>=97 && str.charCodeAt(i)<=122)||(str.charCodeAt(i)==32)))
//		      {
//		       alert("AirlineCode Text should contain only Alphabets");
//		       document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value=""; 
//		       document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").focus();
//		       return false;
//		       } 
//		     
//		 }
//		 }


//  Company name

    if(document.getElementById("ctl00_ContentPlaceHolder1_txtCOMNAME").value=="")
		{
		alert("Enter Company Name");
		document.getElementById("ctl00_ContentPlaceHolder1_txtCOMNAME").focus();
		return false; 
	    }


//address

       if(document.getElementById("ctl00_ContentPlaceHolder1_txtcomaddress").value=="")
		{
		alert("Enter Address ");
		document.getElementById("ctl00_ContentPlaceHolder1_txtcomaddress").focus();
		return false; 
	    }

// phone      
	    
	    
    if(document.getElementById("ctl00_ContentPlaceHolder1_txtphone").value=="")
		{
		alert("Enter Phone No.");
		document.getElementById("ctl00_ContentPlaceHolder1_txtphone").focus();
		return false; 
	    }
	    
// sur Charge

       if(document.getElementById("ctl00_ContentPlaceHolder1_txtsurchrg").value=="")
		{
		alert("Enter SurCharge ");
		document.getElementById("ctl00_ContentPlaceHolder1_txtsurchrg").focus();
		return false; 
	    }	

//txt Deduction   txttxtDeduction

	  if(document.getElementById("ctl00_ContentPlaceHolder1_txttxtDeduction").value=="")
		{
		alert("Enter Deduction Source ");
		document.getElementById("ctl00_ContentPlaceHolder1_txttxtDeduction").focus();
		return false; 
	    }	
	    
	    
//Email validations

var str=document.getElementById("ctl00_ContentPlaceHolder1_txtcompmail").value;
       var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

 		    	   
     	      
   }     

function filterInput(filterType, evt, allowDecimal, allowCustom)
{ 
    var keyCode, Char, inputField, filter = ''; 
    var alpha = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&()_-+=`~[]{}":;<,>.?/'; 
    var num   = '0123456789'; 
    // Get the Key Code of the Key pressed if possible else - allow 
    if(window.event)
    { 
        keyCode = window.event.keyCode; 
        evt = window.event; 
    }else if (evt)keyCode = evt.which; 
    else return true; 
    // Setup the allowed Character Set 
    if(filterType == 0) filter = alpha; 
    else if(filterType == 1) filter = num; 
    else if(filterType == 2) filter = alpha + num; 
    if(allowCustom)filter += allowCustom; 
    if(filter == '')return true; 
    // Get the Element that triggered the Event 
    inputField = evt.srcElement ? evt.srcElement : evt.target || evt.currentTarget; 
    // If the Key Pressed is a CTRL key like Esc, Enter etc - allow 
    if((keyCode==null) || (keyCode==0) || (keyCode==8) || (keyCode==9) || (keyCode==13) || (keyCode==27) || (keyCode==32))return true; 
    // Get the Pressed Character 
    Char = String.fromCharCode(keyCode); 
    // If the Character is a number - allow 
    if((filter.indexOf(Char) > -1)) return true; 
    // Else if Decimal Point is allowed and the Character is '.' - allow 
    else if(filterType == 1 && allowDecimal && (Char == '.') && inputField.value.indexOf('.') == -1)return true; 
    else return false; 
}


function filterInput_airlinetext(filterType, evt, allowDecimal, allowCustom)
{ 
    var keyCode, Char, inputField, filter = ''; 
    var alpha = '0123456789'; 
    var num   = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
    // Get the Key Code of the Key pressed if possible else - allow 
    if(window.event)
    { 
        keyCode = window.event.keyCode; 
        evt = window.event; 
    }else if (evt)keyCode = evt.which; 
    else return true; 
    // Setup the allowed Character Set 
    if(filterType == 0) filter = alpha; 
    else if(filterType == 1) filter = num; 
    else if(filterType == 2) filter = alpha + num; 
    if(allowCustom)filter += allowCustom; 
    if(filter == '')return true; 
    // Get the Element that triggered the Event 
    inputField = evt.srcElement ? evt.srcElement : evt.target || evt.currentTarget; 
    // If the Key Pressed is a CTRL key like Esc, Enter etc - allow 
    if((keyCode==null) || (keyCode==0) || (keyCode==8) || (keyCode==9) || (keyCode==13) || (keyCode==27) || (keyCode==32))return true; 
    // Get the Pressed Character 
    Char = String.fromCharCode(keyCode); 
    // If the Character is a number - allow 
    if((filter.indexOf(Char) > -1)) return true; 
    // Else if Decimal Point is allowed and the Character is '.' - allow 
    else if(filterType == 1 && allowDecimal && (Char == '.') && inputField.value.indexOf('.') == -1)return true; 
    else return false; 
}

//email validation

function validate_email(field,alerttxt)
{
with (field)
{
apos=value.indexOf("@")
dotpos=value.lastIndexOf(".")
if (apos<1||dotpos-apos<2) 
  {alert(alerttxt);return false}
else {return true}
}
}