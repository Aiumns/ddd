function actbDest(obj,ca){
	/* ---- Public Variables ---- */
	this.actbCity_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbCity_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbCity_firstText = false; // should the auto complete be limited to the beginning of keyword?
	this.actbCity_mouse = true; // Enable Mouse Support
	this.actbCity_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbCity_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbCity_bgColor = '#F1F0F0';
	this.actbCity_textColor = 'navy';
	this.actbCity_hColor = '#FFFFFF';
	this.actbCity_fFamily = 'Verdana';
	this.actbCity_fSize = '11px';
	this.actbCity_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbCity_delimwords = new Array();
	var actbCity_cdelimword = 0;
	var actbCity_delimchar = new Array();
	var actbCity_display = false;
	var actbCity_pos = 0;
	var actbCity_total = 0;
	var actbCity_curr = null;
	var actbCity_rangeu = 0;
	var actbCity_ranged = 0;
	var actbCity_bool = new Array();
	var actbCity_pre = 0;
	var actbCity_toid;
	var actbCity_tomake = false;
	var actbCity_getpre = "";
	var actbCity_mouse_on_list = 1;
	var actbCity_kwcount = 0;
	var actbCity_caretmove = false;
	this.actbCity_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbCity_keywords = ca;
	var actbCity_self = this;

	actbCity_curr = obj;
	
	addEvent(actbCity_curr,"focus",actbCity_setup);
	function actbCity_setup(){
		addEvent(document,"keydown",actbCity_checkkey);
		addEvent(actbCity_curr,"blur",actbCity_clear);
		addEvent(document,"keypress",actbCity_keypress);
	}

	function actbCity_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbCity_checkkey);
		removeEvent(actbCity_curr,"blur",actbCity_clear);
		removeEvent(document,"keypress",actbCity_keypress);
		actbCity_removedisp();
	}
	function actbCity_parse(n){
		if (actbCity_self.actbCity_delimiter.length > 0){
			var t = actbCity_delimwords[actbCity_cdelimword].addslashes();
			var plen = actbCity_delimwords[actbCity_cdelimword].length;
		}else{
			var t = actbCity_curr.value.addslashes();
			var plen = actbCity_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbCity_self.actbCity_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbCity_self.actbCity_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbCity_generate(){
		if (document.getElementById('tat_table')){ actbCity_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbCity_kwcount == 0){
			actbCity_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbCity_curr) + actbCity_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbCity_curr) + "px";
		a.style.backgroundColor=actbCity_self.actbCity_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbCity_self.actbCity_mouse){
			a.onmouseout = actbCity_table_unfocus;
			a.onmouseover = actbCity_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbCity_self.actbCity_keywords.length;i++){
			if (actbCity_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbCity_tomake){
					r.style.backgroundColor = actbCity_self.actbCity_hColor;
					first = false;
					actbCity_pos = counter;
				}else if(actbCity_pre == i){
					r.style.backgroundColor = actbCity_self.actbCity_hColor;
					first = false;
					actbCity_pos = counter;
				}else{
					r.style.backgroundColor = actbCity_self.actbCity_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbCity_self.actbCity_textColor;
				c.style.fontFamily = actbCity_self.actbCity_fFamily;
				c.style.fontSize = actbCity_self.actbCity_fSize;
				c.innerHTML = actbCity_parse(actbCity_self.actbCity_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbCity_self.actbCity_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbCity_mouseclick;
					c.onmouseover = actbCity_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbCity_self.actbCity_lim && j < actbCity_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbCity_self.actbCity_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbCity_self.actbCity_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbCity_self.actbCity_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbCity_self.actbCity_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbCity_mouse_down;
				}
				break;
			}
		}
		actbCity_rangeu = 1;
		actbCity_ranged = j-1;
		actbCity_display = true;
		if (actbCity_pos <= 0) actbCity_pos = 1;
	}
	function actbCity_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbCity_curr) + actbCity_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbCity_curr) + "px";
		a.style.backgroundColor=actbCity_self.actbCity_bgColor;
		a.id = 'tat_table';
		if (actbCity_self.actbCity_mouse){
			a.onmouseout= actbCity_table_unfocus;
			a.onmouseover=actbCity_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbCity_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbCity_self.actbCity_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbCity_self.actbCity_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbCity_self.actbCity_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbCity_self.actbCity_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbCity_mouse_up;
			}
		}
		for (i=0;i<actbCity_self.actbCity_keywords.length;i++){
			if (actbCity_bool[i]){
				if (j >= actbCity_rangeu && j <= actbCity_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbCity_self.actbCity_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbCity_self.actbCity_textColor;
					c.style.fontFamily = actbCity_self.actbCity_fFamily;
					c.style.fontSize = actbCity_self.actbCity_fSize;
					c.innerHTML = actbCity_parse(actbCity_self.actbCity_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbCity_self.actbCity_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbCity_mouseclick;
						c.onmouseover = actbCity_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbCity_ranged) break;
		}
		if (j-1 < actbCity_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbCity_self.actbCity_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbCity_self.actbCity_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbCity_self.actbCity_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbCity_self.actbCity_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbCity_mouse_down;
			}
		}
	}
	function actbCity_goup(){
		if (!actbCity_display) return;
		if (actbCity_pos == 1) return;
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_bgColor;
		actbCity_pos--;
		if (actbCity_pos < actbCity_rangeu) actbCity_moveup();
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_hColor;
		if (actbCity_toid) clearTimeout(actbCity_toid);
		if (actbCity_self.actbCity_timeOut > 0) actbCity_toid = setTimeout(function(){actbCity_mouse_on_list=0;actbCity_removedisp();},actbCity_self.actbCity_timeOut);
	}
	function actbCity_godown(){
		if (!actbCity_display) return;
		if (actbCity_pos == actbCity_total) return;
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_bgColor;
		actbCity_pos++;
		if (actbCity_pos > actbCity_ranged) actbCity_movedown();
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_hColor;
		if (actbCity_toid) clearTimeout(actbCity_toid);
		if (actbCity_self.actbCity_timeOut > 0) actbCity_toid = setTimeout(function(){actbCity_mouse_on_list=0;actbCity_removedisp();},actbCity_self.actbCity_timeOut);
	}
	function actbCity_movedown(){
		actbCity_rangeu++;
		actbCity_ranged++;
		actbCity_remake();
	}
	function actbCity_moveup(){
		actbCity_rangeu--;
		actbCity_ranged--;
		actbCity_remake();
	}

	/* Mouse */
	function actbCity_mouse_down(){
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_bgColor;
		actbCity_pos++;
		actbCity_movedown();
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_hColor;
		actbCity_curr.focus();
		actbCity_mouse_on_list = 0;
		if (actbCity_toid) clearTimeout(actbCity_toid);
		if (actbCity_self.actbCity_timeOut > 0) actbCity_toid = setTimeout(function(){actbCity_mouse_on_list=0;actbCity_removedisp();},actbCity_self.actbCity_timeOut);
	}
	function actbCity_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_bgColor;
		actbCity_pos--;
		actbCity_moveup();
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_hColor;
		actbCity_curr.focus();
		actbCity_mouse_on_list = 0;
		if (actbCity_toid) clearTimeout(actbCity_toid);
		if (actbCity_self.actbCity_timeOut > 0) actbCity_toid = setTimeout(function(){actbCity_mouse_on_list=0;actbCity_removedisp();},actbCity_self.actbCity_timeOut);
	}
	function actbCity_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbCity_display) return;
		actbCity_mouse_on_list = 0;
		actbCity_pos = this.getAttribute('pos');
		actbCity_penter();
	}
	function actbCity_table_focus(){
		actbCity_mouse_on_list = 1;
	}
	function actbCity_table_unfocus(){
		actbCity_mouse_on_list = 0;
		if (actbCity_toid) clearTimeout(actbCity_toid);
		if (actbCity_self.actbCity_timeOut > 0) actbCity_toid = setTimeout(function(){actbCity_mouse_on_list = 0;actbCity_removedisp();},actbCity_self.actbCity_timeOut);
	}
	function actbCity_table_highlight(){
		actbCity_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_bgColor;
		actbCity_pos = this.getAttribute('pos');
		while (actbCity_pos < actbCity_rangeu) actbCity_moveup();
		while (actbCity_pos > actbCity_ranged) actbCity_movedown();
		document.getElementById('tat_tr'+actbCity_pos).style.backgroundColor = actbCity_self.actbCity_hColor;
		if (actbCity_toid) clearTimeout(actbCity_toid);
		if (actbCity_self.actbCity_timeOut > 0) actbCity_toid = setTimeout(function(){actbCity_mouse_on_list = 0;actbCity_removedisp();},actbCity_self.actbCity_timeOut);
	}
	/* ---- */

	function actbCity_insertword(a){
		if (actbCity_self.actbCity_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbCity_delimwords.length;i++){
				if (actbCity_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbCity_delimwords[i].length;++j){
						if (actbCity_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbCity_delimwords[i].length-1;j>=0;--j){
						if (actbCity_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbCity_delimwords[i];
				}
				if (i != actbCity_delimwords.length - 1){
					str += actbCity_delimchar[i];
				}
			}
			actbCity_curr.value = str;
			setCaret(actbCity_curr,l);
		}else{
			actbCity_curr.value = a;
		}
		actbCity_mouse_on_list = 0;
		actbCity_removedisp();
	}
	function actbCity_penter(){
		if (!actbCity_display) return;
		actbCity_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbCity_self.actbCity_keywords.length;i++){
			if (actbCity_bool[i]) c++;
			if (c == actbCity_pos){
				word = actbCity_self.actbCity_keywords[i];
				break;
			}
		}
		actbCity_insertword(word);
		l = getCaretStart(actbCity_curr);
	}
	function actbCity_removedisp(){
		if (actbCity_mouse_on_list==0){
			actbCity_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbCity_toid) clearTimeout(actbCity_toid);
		}
	}
	function actbCity_keypress(e){
		if (actbCity_caretmove) stopEvent(e);
		return !actbCity_caretmove;
	}
	function actbCity_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbCity_curr);
		actbCity_caretmove = 0;
		switch (a){
			case 38:
				actbCity_goup();
				actbCity_caretmove = 1;
				return false;
				break;
			case 40:
				actbCity_godown();
				actbCity_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbCity_display){
					actbCity_caretmove = 1;
					actbCity_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbCity_tocomplete(a)},50);
				break;
		}
	}

	function actbCity_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbCity_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbCity_self.actbCity_keywords.length;i++){
				if (actbCity_bool[i]) c++;
				if (c == actbCity_pos){
					word = i;
					break;
				}
			}
			actbCity_pre = word;
		}else{ actbCity_pre = -1};
		
		if (actbCity_curr.value == ''){
			actbCity_mouse_on_list = 0;
			actbCity_removedisp();
			return;
		}
		if (actbCity_self.actbCity_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbCity_curr);
			caret_pos_end = getCaretEnd(actbCity_curr);
			
			delim_split = '';
			for (i=0;i<actbCity_self.actbCity_delimiter.length;i++){
				delim_split += actbCity_self.actbCity_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbCity_delimwords = new Array();
			actbCity_delimwords[0] = '';
			for (i=0,j=actbCity_curr.value.length;i<actbCity_curr.value.length;i++,j--){
				if (actbCity_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbCity_curr.value.substr(i,j).match(delim_split_rx);
					actbCity_delimchar[c] = ma[1];
					c++;
					actbCity_delimwords[c] = '';
				}else{
					actbCity_delimwords[c] += actbCity_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbCity_cdelimword = -1;
			for (i=0;i<actbCity_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbCity_delimwords[i].length){
					actbCity_cdelimword = i;
				}
				l+=actbCity_delimwords[i].length + 1;
			}
			var ot = actbCity_delimwords[actbCity_cdelimword]; 
			var t = actbCity_delimwords[actbCity_cdelimword].addslashes();
		}else{
			var ot = actbCity_curr.value;
			var t = actbCity_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbCity_mouse_on_list = 0;
			actbCity_removedisp();
		}
		if (ot.length < actbCity_self.actbCity_startcheck) return this;
		if (actbCity_self.actbCity_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbCity_total = 0;
		actbCity_tomake = false;
		actbCity_kwcount = 0;
		for (i=0;i<actbCity_self.actbCity_keywords.length;i++){
			actbCity_bool[i] = false;
			if (re.test(actbCity_self.actbCity_keywords[i])){
				actbCity_total++;
				actbCity_bool[i] = true;
				actbCity_kwcount++;
				if (actbCity_pre == i) actbCity_tomake = true;
			}
		}

		if (actbCity_toid) clearTimeout(actbCity_toid);
		if (actbCity_self.actbCity_timeOut > 0) actbCity_toid = setTimeout(function(){actbCity_mouse_on_list = 0;actbCity_removedisp();},actbCity_self.actbCity_timeOut);
		actbCity_generate();
	}
	return this;
}