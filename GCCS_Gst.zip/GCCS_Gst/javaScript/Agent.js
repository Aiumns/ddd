﻿// JScript File

function CheckTelePhoneNo(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-'  : false;
	var isFirstD = allowDecimal ? keychar == ','  : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}
    
    function blockNonNumbers(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
	var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}
        
        //.....................End Of Function blockNonNumbers........................//
        //.....................Start Of Function blockNonNumbers........................//
    
    function CheckTelePhoneNo(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-'  : false;
	var isFirstD = allowDecimal ? keychar == ','  : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}
        
        //.....................End Of Function blockNonNumbers........................//      
        
        //.....................Start Of Function blockNonNumbers........................//
          function CheckEmpty()
          {    
          
           if (document.getElementById("ctl00$ContentPlaceHolder1$txtAddress").value == '')
          {            
             alert("Please Enter Address");
             document.getElementById("ctl00$ContentPlaceHolder1$txtAddress").focus();
             return false;
          } 
//          if (document.getElementById("ctl00$ContentPlaceHolder1$txtFax").value == '')
//          {            
//             alert("Please Enter Fax");
//             document.getElementById("ctl00$ContentPlaceHolder1$txtFax").focus();
//             return false;
//          }           
          
          if (document.getElementById("ctl00$ContentPlaceHolder1$txtCsrEmailID").value == '')
          {            
             alert("Please Enter Email Id");
             document.getElementById("ctl00$ContentPlaceHolder1$txtCsrEmailID").focus();
             return false;
          } 
                 
        		    if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(document.getElementById("ctl00$ContentPlaceHolder1$txtCsrEmailID").value))
            {
alert("Enter Valid Email Address");
document.getElementById("ctl00$ContentPlaceHolder1$txtCsrEmailID").focus();
return false;
		}          
          if (document.getElementById("ctl00$ContentPlaceHolder1$txtIATACode").value == '')
          {            
             alert("Please Enter IATA Code");
             document.getElementById("ctl00$ContentPlaceHolder1$txtIATACode").focus();
             return false;
          } 
          if (document.getElementById("ctl00$ContentPlaceHolder1$txtIATAComm").value == '')
          {            
             alert("Please Enter IATA Comm");
             document.getElementById("ctl00$ContentPlaceHolder1$txtIATAComm").focus();
             return false;
          } 
           if (document.getElementById("ctl00$ContentPlaceHolder1$txtCreditLimit").value == '')
          {            
             alert("Please Enter Credit Limit");
             document.getElementById("ctl00$ContentPlaceHolder1$txtCreditLimit").focus();
             return false;
          } 
           if (document.getElementById("ctl00$ContentPlaceHolder1$txtPassword").value == '')
          {            
             alert("Please Enter Password");
             document.getElementById("ctl00$ContentPlaceHolder1$txtPassword").focus();
             return false;
          } 
             
             var hh=document.getElementById("ctl00_ContentPlaceHolder1_Hidden1").value;
        if(document.getElementById("ctl00_ContentPlaceHolder1_Hidden1").value<>'A')      
        {
        
          
            var status=confirm('This IATA Code is already Exist.Do you want to Continue?')
            if(status)
            {
            return true ;
            }
            else
            {
             return false;
            }
        } 
         else
        {
            return true;
        }
        
    }       
        //.....................End Of Function blockNonNumbers........................//
    

