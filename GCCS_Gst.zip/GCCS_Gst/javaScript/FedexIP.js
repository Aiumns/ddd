﻿// JScript File

function blockNonNumbers(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
	var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}
 
    function CheckTelePhoneNo(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-'  : false;
	var isFirstD = allowDecimal ? keychar == ','  : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}
        
  
        //.....................End Of Function blockNonNumbers........................//
        //.....................Start Of Function blockNonNumbers........................//
        function CheckEmpty_ddl()
    {
     
if(document.getElementById("ctl00$ContentPlaceHolder1$ddlAgentName").selectedIndex<=0)
    {
        alert("Please Select Agent Name ");
        document.getElementById("ctl00$ContentPlaceHolder1$ddlAgentName").focus();
        return false;
    }
 else if(document.getElementById("ctl00$ContentPlaceHolder1$dllspt").selectedIndex<=0)
 
 {
  alert("Please Select Shipment Type. ");
        document.getElementById("ctl00$ContentPlaceHolder1$dllspt").focus();
        return false;
 
 
 }   
    else if(document.getElementById("ctl00$ContentPlaceHolder1$dlldest").selectedIndex<=0)
 
 {
  alert("Please Select Destination.");
        document.getElementById("ctl00$ContentPlaceHolder1$dlldest").focus();
        return false;
 
 
 }    
    
   else
        {
            return true;
        }
}  
     
    
        
        
function Calculate()
{   
   var srvice_type= document.getElementById('ctl00_ContentPlaceHolder1_dllspt').value;
   if(srvice_type!="ATA")
   {
   var basic_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value);
     var buy_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtbuyrate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbuyrate').value);
   var sell_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value);
     var fsc_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtFSCRate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtFSCRate').value);
      var fsc_amt=(document.getElementById('ctl00_ContentPlaceHolder1_txtFSCAmount').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtFSCAmount').value);
         var stax_count=(document.getElementById('ctl00_ContentPlaceHolder1_txtStaxRate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtStaxRate').value);
            var stax_amt=(document.getElementById('ctl00_ContentPlaceHolder1_txtServiceTaxAmount').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtServiceTaxAmount').value);
               var ch_wt=(document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value);
                var sell_amt=(document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value);
                 var buying_amt=(document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value);
                 var Dg_surAmt=(document.getElementById('ctl00_ContentPlaceHolder1_txtDgSurcharge').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtDgSurcharge').value); 
                 
   var fsc_total=(parseFloat(basic_rate)*parseFloat(fsc_rate))/100;
   var s_tax_total=((parseFloat(basic_rate)+parseFloat(fsc_total)+parseFloat(Dg_surAmt))*parseFloat(stax_count))/100;
   var total_sell_amt=parseFloat(sell_rate)*parseFloat(ch_wt);
   var total_buy_rate=parseFloat(basic_rate)+parseFloat(fsc_total)+parseFloat(s_tax_total)+parseFloat(Dg_surAmt);
   var total_buy_amt=total_buy_rate*parseFloat(ch_wt);
    var total_profit=parseFloat(total_buy_amt)-parseFloat(total_sell_amt);
   
  document.getElementById('ctl00_ContentPlaceHolder1_txtFSCAmount').value =fsc_total.toFixed(2); 
  document.getElementById('ctl00_ContentPlaceHolder1_txtServiceTaxAmount').value =s_tax_total.toFixed(2); 
  document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value =total_sell_amt.toFixed(0); 
  document.getElementById('ctl00_ContentPlaceHolder1_txtbuyrate').value =total_buy_rate.toFixed(2); 
  document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value =total_buy_amt.toFixed(0); 
  }
  else
   {
   var basic_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbasicRate').value);
     var buy_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtbuyrate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbuyrate').value);
   var sell_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtselrate').value);
     var fsc_rate=(document.getElementById('ctl00_ContentPlaceHolder1_txtFSCRate').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtFSCRate').value);
      var fsc_amt=(document.getElementById('ctl00_ContentPlaceHolder1_txtFSCAmount').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtFSCAmount').value);
         
               var ch_wt=(document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtchwt').value);
                var sell_amt=(document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value);
                 var buying_amt=(document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value);
                  var Dg_surAmt=(document.getElementById('ctl00_ContentPlaceHolder1_txtDgSurcharge').value == '' ?  '0' : document.getElementById('ctl00_ContentPlaceHolder1_txtDgSurcharge').value); 
                 
   var fsc_total=(parseFloat(basic_rate)*parseFloat(fsc_rate))/100;
   var total_sell_amt=parseFloat(sell_rate)*parseFloat(ch_wt);
   var total_buy_rate=parseFloat(basic_rate)+parseFloat(fsc_total)+parseFloat(Dg_surAmt);
   var total_buy_amt=total_buy_rate*parseFloat(ch_wt);
    var total_profit=parseFloat(total_buy_amt)-parseFloat(total_sell_amt);
   
  document.getElementById('ctl00_ContentPlaceHolder1_txtFSCAmount').value =fsc_total.toFixed(2); 
  document.getElementById('ctl00_ContentPlaceHolder1_txtsamount').value =total_sell_amt.toFixed(0); 
  document.getElementById('ctl00_ContentPlaceHolder1_txtbuyrate').value =total_buy_rate.toFixed(2); 
  document.getElementById('ctl00_ContentPlaceHolder1_txtbuyamt').value =total_buy_amt.toFixed(0); 
  }
 }
 



