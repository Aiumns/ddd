﻿// JScript File

function blockNonNumbers(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
	var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}
 
    function CheckTelePhoneNo(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-'  : false;
	var isFirstD = allowDecimal ? keychar == ','  : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}
        
       

  
        //.....................End Of Function blockNonNumbers........................//
        //.....................Start Of Function blockNonNumbers........................//
        
        
        //Function For Check Existing AWBNO
        
//        function CheckAwbNo()
//        {
//            
//            var AWBNo=document.getElementById('ctl00_ContentPlaceHolder1_txtAwbNo').value;
//          
//            var m=AWBNo.indexOf('-');
//            var awlen=AWBNo.lenght;
//            var subawb=AWBNo.substring(m+1,awlen);
//            var sublens=subawb.length;
//            if(!(sublens==8&&m==3))
//            {
//                alert('Please Enter Valid AWB No');
//                document.getElementById('ctl00_ContentPlaceHolder1_txtAwbNo').focus();
//            }
//        }
        
        //END
        
//           function validateChar()
//            {
//            
//               var nodGood=document.getElementById('ctl00_ContentPlaceHolder1_txtNatuteGood').value;               
//                for(i=0;i<nodGood.length;i++)
//                {
//                  if(!((nodGood.charCodeAt(i)>=65 && nodGood.charCodeAt(i)<=90)||(nodGood.charCodeAt(i)>=97 && nodGood.charCodeAt(i)<=122)||(nodGood.charCodeAt(i)==32)))
//		          {
//		           alert('Enter nature of Good only Alphabets');   	
//		          
//		            document.getElementById("ctl00_ContentPlaceHolder1_txtNatuteGood").value="";
//		            document.getElementById("ctl00_ContentPlaceHolder1_txtNatuteGood").focus();
//		         } 
//		         
//		         
//               }
//            }

function Calculate()
{   
   var city_code= document.getElementById('ctl00_ContentPlaceHolder1_hndcity_code').value;
   if(city_code=="DEL")
   {
      var do_chg = document.getElementById('ctl00_ContentPlaceHolder1_txtDoChg').value;
    var Hdo_chg = document.getElementById('ctl00_ContentPlaceHolder1_txtHawbDO').value;   
   var total_amount1 = document.getElementById('ctl00_ContentPlaceHolder1_txtTotalAmt').value;
   var stax_count = document.getElementById('ctl00_ContentPlaceHolder1_txtstax').value;
   var stax_amt= document.getElementById('ctl00_ContentPlaceHolder1_txtServiceTax').value;
   var tds_cut_by_agent= document.getElementById('ctl00_ContentPlaceHolder1_txtTdsDeductedByAgent').value;
   var grand_total= document.getElementById('ctl00_ContentPlaceHolder1_txtGrandTotal').value;
  var total_rec_amt= document.getElementById('ctl00_ContentPlaceHolder1_txtGrandTotal').value;
     
   //For Deleivery Order Data (mawb)
   if ( document.getElementById('ctl00_ContentPlaceHolder1_txtDoChg').value == '')
   {
    do_chg='0';
   }
   else
   {
     do_chg=do_chg;
   }
   
      //For Deleivery Order Data(hawb)
   if ( document.getElementById('ctl00_ContentPlaceHolder1_txtHawbDO').value == '')
   {
    Hdo_chg='0';
   }
   else
   {
     Hdo_chg=Hdo_chg;
   }
   
               //For STAX Count
      if ( document.getElementById('ctl00_ContentPlaceHolder1_txtstax').value == '')
   {
    stax_count='12.36';
   }
   else
   {
     stax_count=stax_count;
   }
   
   //For TDS CUT BY AGENT

      if ( document.getElementById('ctl00_ContentPlaceHolder1_txtTdsDeductedByAgent').value == '')
   {
    tds_cut_by_agent='0';
   }
   else
   {
     tds_cut_by_agent=tds_cut_by_agent;
   }
   
   
   var t_amt=parseFloat(do_chg)+parseFloat(Hdo_chg);
   var s_tax_total=Math.round((t_amt*stax_count)/100,0);
   var total_pay_amt=Math.round(parseFloat(s_tax_total)+parseFloat(t_amt),0)-parseFloat(tds_cut_by_agent);
  document.getElementById('ctl00_ContentPlaceHolder1_txtTotalAmt').value =t_amt;
     document.getElementById('ctl00_ContentPlaceHolder1_txtstax').value =stax_count;
  document.getElementById('ctl00_ContentPlaceHolder1_txtServiceTax').value =s_tax_total;
  document.getElementById('ctl00_ContentPlaceHolder1_txtGrandTotal').value =total_pay_amt;
  document.getElementById('ctl00_ContentPlaceHolder1_txtrecAmount').value =total_pay_amt;
   }
   
   
   // for MUM 
   else if(city_code=="MUM")
   {
    var do_chg = document.getElementById('ctl00_ContentPlaceHolder1_txtDoChg').value;
    var Hdo_chg = document.getElementById('ctl00_ContentPlaceHolder1_txtHawbDO').value;
   var dp_chg = document.getElementById('ctl00_ContentPlaceHolder1_txtDpChg').value;
   var comm_chg = document.getElementById('ctl00_ContentPlaceHolder1_txtCommChg').value;
   var crt_chg_count= document.getElementById('ctl00_ContentPlaceHolder1_txtctcount').value;
   var crt_chg = document.getElementById('ctl00_ContentPlaceHolder1_txtcartageChg').value;
   
   var total_amount1 = document.getElementById('ctl00_ContentPlaceHolder1_txtTotalAmt').value;
   var stax_count = document.getElementById('ctl00_ContentPlaceHolder1_txtstax').value;
   var stax_amt= document.getElementById('ctl00_ContentPlaceHolder1_txtServiceTax').value;
   var tds_cut_by_agent= document.getElementById('ctl00_ContentPlaceHolder1_txtTdsDeductedByAgent').value;
   var grand_total= document.getElementById('ctl00_ContentPlaceHolder1_txtGrandTotal').value;
   var total_rec_amt =document.getElementById('ctl00_ContentPlaceHolder1_txtrecAmount').value;
     
     
   //For Deleivery Order Data (mawb)
   if ( document.getElementById('ctl00_ContentPlaceHolder1_txtDoChg').value == '')
   {
    do_chg='0';
   }
   else
   {
     do_chg=do_chg;
   }
   
      //For Deleivery Order Data(hawb)
   if ( document.getElementById('ctl00_ContentPlaceHolder1_txtHawbDO').value == '')
   {
    Hdo_chg='0';
   }
   else
   {
     Hdo_chg=Hdo_chg;
   }
   
      //For Data Processing Charges
   if (document.getElementById('ctl00_ContentPlaceHolder1_txtDpChg').value == '')
   {
    dp_chg='0';
   }
   else
   {
     dp_chg=dp_chg;
   }
   
   //For Communication Charges
      if (document.getElementById('ctl00_ContentPlaceHolder1_txtCommChg').value == '')
   {
    comm_chg='0';
   }
   else
   {
     comm_chg=comm_chg;
   }
                  //For cartage charges count
      if ( document.getElementById('ctl00_ContentPlaceHolder1_txtctcount').value == '')
   {
    crt_chg_count='1.00';
   }
   else
   {
     crt_chg_count=crt_chg_count;
   }
   
      //For cartage Charges
      if (document.getElementById('ctl00_ContentPlaceHolder1_txtcartageChg').value == '')
   {
    crt_chg='0';
   }
   else
   {
     crt_chg=crt_chg;
   }
   
               //For STAX Count
      if ( document.getElementById('ctl00_ContentPlaceHolder1_txtstax').value == '')
   {
    stax_count='12.36';
   }
   else
   {
     stax_count=stax_count;
   }
   
   //For TDS CUT BY AGENT

      if ( document.getElementById('ctl00_ContentPlaceHolder1_txtTdsDeductedByAgent').value == '')
   {
    tds_cut_by_agent='0';
   }
   else
   {
     tds_cut_by_agent=tds_cut_by_agent;
   }
   
   
   var t_amt=parseFloat(do_chg)+parseFloat(Hdo_chg)+parseFloat(dp_chg)+parseFloat(comm_chg)+parseFloat(crt_chg);
   var s_tax_total=Math.round((t_amt*stax_count)/100,0);
   var total_pay_amt=Math.round(parseFloat(s_tax_total)+parseFloat(t_amt),0)-parseFloat(tds_cut_by_agent);
   document.getElementById('ctl00_ContentPlaceHolder1_txtctcount').value=crt_chg_count;
  document.getElementById('ctl00_ContentPlaceHolder1_txtcartageChg').value =crt_chg;
  document.getElementById('ctl00_ContentPlaceHolder1_txtTotalAmt').value =t_amt;
     document.getElementById('ctl00_ContentPlaceHolder1_txtstax').value =stax_count;
  document.getElementById('ctl00_ContentPlaceHolder1_txtServiceTax').value =s_tax_total;
  document.getElementById('ctl00_ContentPlaceHolder1_txtGrandTotal').value =total_pay_amt;
  document.getElementById('ctl00_ContentPlaceHolder1_txtrecAmount').value =total_pay_amt;
  }
}

