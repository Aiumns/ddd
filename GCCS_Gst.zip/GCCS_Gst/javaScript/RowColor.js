﻿// JScript File
 function ChangeColor( x )
 { 
 if ( x.style ) 
 {

if( x.style.backgroundColor=='lightblue')
{
x.style.backgroundColor='';
 x.style.color ='black';

}
else
{
x.style.backgroundColor='lightblue';
 x.style.color ='blue';
}
}
}

