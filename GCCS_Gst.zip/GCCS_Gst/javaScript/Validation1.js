﻿
function btnnext_ValidationCheck()
	{
		// check blank Airline Code
		
//		if(document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value=="")
//		{
//		alert("Enter Airline Code");
//		document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").focus();
//		return false; 
//	    }
//	
//		     //only Numeric values
//		      
//         if(document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value!="")
//		  {
//		   var AirlineCode_val=document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value;
//		         
//  
//		          for(i=0;i<AirlineCode_val.length;i++)
//		          {
//		          if(!((AirlineCode_val.charCodeAt(i)>=48) && (AirlineCode_val.charCodeAt(i)<=57)))
//		            {
//		            alert(" Enter only Numeric values ");
//		            document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value="";
//		            document.getElementById ("ctl00_ContentPlaceHolder1_AirlineCode").focus();
//		            return false; 
//		            }
//		          }
//		          
//		           if((AirlineCode_val.length)<3)
//		         {
//		        alert(" Enter 3 digit Airline Code ");
//		        document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").value=""; 
//		        document.getElementById("ctl00_ContentPlaceHolder1_AirlineCode").focus();
//		        return false; 
//		        }
//		          
//		      }
		      
//  Second.. Airline Line Code Text
          
//          if(document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value=="")
//		{
//		alert("Enter AirlineCode Text");
//		document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").focus();
//		return false; 
//	    }
// 
// 
//		 if(document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value!="")
//		 { 
//		 var str=document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value;
//		 for(i=0;i<str.length;i++)
//		 {
//		 // name starting with space
//		 
//		   if(i==0 && str.charCodeAt(i)==32)
//		    {
//		     alert(" AirlineCode Text should not start with Space");
//		     document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value="";
//		     document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").focus();
//		     return false;
//		     }
		    
		    // should contain only alphabet
		    
//		      if(!((str.charCodeAt(i)>=65 && str.charCodeAt(i)<=90)||(str.charCodeAt(i)>=97 && str.charCodeAt(i)<=122)||(str.charCodeAt(i)==32)))
//		      {
//		       alert("AirlineCode Text should contain only Alphabets");
//		       document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").value=""; 
//		       document.getElementById("ctl00_ContentPlaceHolder1_AirlineCodeText").focus();
//		       return false;
//		       } 
//		     
//		 }
//		 }

// sur Charge

if(document.getElementById("ctl00_ContentPlaceHolder1_txtsurchrg").value=="")
		{
		alert("Enter SurCharge ");
		document.getElementById("ctl00_ContentPlaceHolder1_txtsurchrg").focus();
		return false; 
	    }	

//txt Deduction   txttxtDeduction

	  if(document.getElementById("ctl00_ContentPlaceHolder1_txttxtDeduction").value=="")
		{
		alert("Enter Deduction Source ");
		document.getElementById("ctl00_ContentPlaceHolder1_txttxtDeduction").focus();
		return false; 
	    }	


//  Company name

    if(document.getElementById("ctl00_ContentPlaceHolder1_txtCOMNAME").value=="")
		{
		alert("Enter Company Name");
		document.getElementById("ctl00_ContentPlaceHolder1_txtCOMNAME").focus();
		return false; 
	    }
	    
	    
// phone      
	    
	    
    if(document.getElementById("ctl00_ContentPlaceHolder1_txtphone").value=="")
		{
		alert("Enter Phone No.");
		document.getElementById("ctl00_ContentPlaceHolder1_txtphone").focus();
		return false; 
	    }
//address

       if(document.getElementById("ctl00_ContentPlaceHolder1_txtcomaddress").value=="")
		{
		alert("Enter Address ");
		document.getElementById("ctl00_ContentPlaceHolder1_txtcomaddress").focus();
		return false; 
	    }
	    
	    
//Email

        if(document.getElementById("ctl00_ContentPlaceHolder1_txtcompmail").value=="")
		{
		alert("Enter Email Address ");
		document.getElementById("ctl00_ContentPlaceHolder1_txtcompmail").focus();
		return false; 
	    }	    	    	      
		      
      
// SurCharge

		
	         	      
		   }     

function filterInput(filterType, evt, allowDecimal, allowCustom)
{ 
    var keyCode, Char, inputField, filter = ''; 
    var alpha = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&()_-+=`~[]{}":;<,>.?/'; 
    var num   = '0123456789'; 
    // Get the Key Code of the Key pressed if possible else - allow 
    if(window.event)
    { 
        keyCode = window.event.keyCode; 
        evt = window.event; 
    }else if (evt)keyCode = evt.which; 
    else return true; 
    // Setup the allowed Character Set 
    if(filterType == 0) filter = alpha; 
    else if(filterType == 1) filter = num; 
    else if(filterType == 2) filter = alpha + num; 
    if(allowCustom)filter += allowCustom; 
    if(filter == '')return true; 
    // Get the Element that triggered the Event 
    inputField = evt.srcElement ? evt.srcElement : evt.target || evt.currentTarget; 
    // If the Key Pressed is a CTRL key like Esc, Enter etc - allow 
    if((keyCode==null) || (keyCode==0) || (keyCode==8) || (keyCode==9) || (keyCode==13) || (keyCode==27) || (keyCode==32))return true; 
    // Get the Pressed Character 
    Char = String.fromCharCode(keyCode); 
    // If the Character is a number - allow 
    if((filter.indexOf(Char) > -1)) return true; 
    // Else if Decimal Point is allowed and the Character is '.' - allow 
    else if(filterType == 1 && allowDecimal && (Char == '.') && inputField.value.indexOf('.') == -1)return true; 
    else return false; 
}


function filterInput_airlinetext(filterType, evt, allowDecimal, allowCustom)
{ 
    var keyCode, Char, inputField, filter = ''; 
    var alpha = '0123456789'; 
    var num   = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
    // Get the Key Code of the Key pressed if possible else - allow 
    if(window.event)
    { 
        keyCode = window.event.keyCode; 
        evt = window.event; 
    }else if (evt)keyCode = evt.which; 
    else return true; 
    // Setup the allowed Character Set 
    if(filterType == 0) filter = alpha; 
    else if(filterType == 1) filter = num; 
    else if(filterType == 2) filter = alpha + num; 
    if(allowCustom)filter += allowCustom; 
    if(filter == '')return true; 
    // Get the Element that triggered the Event 
    inputField = evt.srcElement ? evt.srcElement : evt.target || evt.currentTarget; 
    // If the Key Pressed is a CTRL key like Esc, Enter etc - allow 
    if((keyCode==null) || (keyCode==0) || (keyCode==8) || (keyCode==9) || (keyCode==13) || (keyCode==27) || (keyCode==32))return true; 
    // Get the Pressed Character 
    Char = String.fromCharCode(keyCode); 
    // If the Character is a number - allow 
    if((filter.indexOf(Char) > -1)) return true; 
    // Else if Decimal Point is allowed and the Character is '.' - allow 
    else if(filterType == 1 && allowDecimal && (Char == '.') && inputField.value.indexOf('.') == -1)return true; 
    else return false; 
}
