﻿// JScript File

var  Minimum="N";

function AWB() {
    document.getElementById("ctl00$ContentPlaceHolder1$txtAWBDate").readOnly = true;
    document.getElementById("Button3").disabled = true;
}
function Default() {
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtSpotRate").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtSpotRate").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtSCR_Incentive").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtSCR_Incentive").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtSurcharge").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtSurcharge").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtIATACommission").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtIATACommission").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtTDS").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtTDS").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtEducationalCess").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtEducationalCess").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value = 0;
    }
    else {
        document.getElementById("ctl00_ContentPlaceHolder1_lblFreightAmount").value = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value = 0;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtPSpotRate").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtPSpotRate").value = 0;
    }
}
function OnOff() {

var Airline_Detail_ID = document.getElementById("ctl00_ContentPlaceHolder1_hdnAirlineDetailId").value;
if(Airline_Detail_ID=="148" || Airline_Detail_ID=="147")
      MH_Aendment();
      
    //   if(document.getElementById("ctl00_ContentPlaceHolder1_rbCalculate_0").checked == true)
    //    {
    ////    alert("On");

    ////    document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").disabled=true;
    ////    document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").disabled=true
    ////    document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").disabled=true;
    //    
    //   
    //     var DueAgentP=document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
    //     var DueAgentC=document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
    //     var TotalDueAgent=parseFloat(DueAgentP)+parseFloat(DueAgentC);
    //     document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgent").value=TotalDueAgent;
    //    
    //    //**************DueCarrier Calculation******************
    //     var FSC=document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value;
    //     var WSC=document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value;
    //     var XRAY=document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value;
    //     var ACI=document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    //     var AWB=document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    //     var DBCharges=document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value;
    //     var Catrage=document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value;
    //     var Others=document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value;
    //     
    //     
    //     
    //     var ABC=parseFloat(FSC)+parseFloat(WSC)+parseFloat(XRAY);
    //     var DueCarrier= parseFloat(ABC)+parseFloat(ACI)+parseFloat(AWB)+parseFloat(DBCharges)+parseFloat(Catrage)+parseFloat(Others);
    //    document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value=parseFloat(DueCarrier);
    //    DueFreightType();

    //    }
    //    if(document.getElementById("ctl00_ContentPlaceHolder1_rbCalculate_1").checked == true)
    //    {
    //     alert("Off");
    //********DueAgent Calculation**************************
    //    document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").disabled=false;
    //    document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").disabled=false
    //    document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").disabled=false;

    //var DueAgentP=document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
    var DueAgentP = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value = 0;
    }
    else {
        DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
    }
    // var DueAgentC=document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
    var DueAgentC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value = 0;
    }
    else {
        DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
    }
    var TotalDueAgent = parseFloat(DueAgentP) + parseFloat(DueAgentC);
    document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgent").value = TotalDueAgent;

    //**************DueCarrier Calculation******************
    //var FSC=document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value;
    var FSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value = 0;
    }
    else {
        FSC = document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value;
    }
    //var WSC=document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value;
    var WSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value = 0;
    }
    else {
        WSC = document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value;
    }
    //var XRAY=document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value;
    var XRAY = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value = 0;
    }
    else {
        XRAY = document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value;
    }
    var ET = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtET").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtET").value = 0;
    }
    else {
        ET = document.getElementById("ctl00_ContentPlaceHolder1_txtET").value;
    }
        //var MSC
           var MSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value = 0;
    }
    else {
        MSC = document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value;
    }
        // var ACI=document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    var ACI = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value = 0;
    }
    else {
        ACI = document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    }
    //var AWB=document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    var AWB = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value = 0;
    }
    else {
        AWB = document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    }
    //var DBCharges=document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value;
    var DBCharges = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value = 0;
    }
    else {
        DBCharges = document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value;
    }
    //var Catrage=document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value;
    var Catrage = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value = 0;
    }
    else {
        Catrage = document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value;
    }
    //var Others=document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value;
    var Others = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value = 0;
    }
    else {
        Others = document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value;
    }
    var ABC = parseFloat(FSC) + parseFloat(WSC) + parseFloat(XRAY) + parseFloat(MSC) + parseFloat(ET);
    var DueCarrier = parseFloat(ABC) + parseFloat(ACI) + parseFloat(AWB) + parseFloat(DBCharges) + parseFloat(Catrage) + parseFloat(Others);
    DueCarrier = Math.round(DueCarrier);
    document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = parseFloat(DueCarrier);
    DueFreightTypeForOnOFF();
}

function Other() {
    var FSC = document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value;
    var WSC = document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value;
    var XRAY = document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value;
    var MSC = document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value;
    var ET = document.getElementById("ctl00_ContentPlaceHolder1_txtET").value;
    var ABC = parseFloat(FSC) + parseFloat(WSC) + parseFloat(XRAY) + parseFloat(MSC) + parseFloat(ET);
    var ACI = document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    var AWB = document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    var DBCharges = document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value;
    var Catrage = document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value;
    var Others = document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value;
    
    var DueCarrier = parseFloat(ABC) + parseFloat(ACI) + parseFloat(AWB) + parseFloat(DBCharges) + parseFloat(Catrage) + parseFloat(Others);
    document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = parseFloat(DueCarrier);
    DueFreightType();
}

function Rates() {
    var Pieces = document.getElementById("ctl00_ContentPlaceHolder1_txtPieces").value;
    var cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
    var gw = document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value;
    var Volwt = document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value;
    var HFSC = document.getElementById("ctl00_ContentPlaceHolder1_HiddenFSC").value;
    var HWSC = document.getElementById("ctl00_ContentPlaceHolder1_HiddenWSC").value;
    var HXRAY = document.getElementById("ctl00_ContentPlaceHolder1_HiddenXRay").value;
    var HET = document.getElementById("ctl00_ContentPlaceHolder1_hdnET").value;
    //var FSC = document.getElementById("ctl00_ContentPlaceHolder1_txtRFSC").value;
    var FSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtRFSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtRFSC").value = 0;
    }
    else {
        FSC = document.getElementById("ctl00_ContentPlaceHolder1_txtRFSC").value;
    }
    
    //var MSC
       //var FSC = document.getElementById("ctl00_ContentPlaceHolder1_txtRFSC").value;
    var MSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value = 0;
    }
    else {
        MSC = document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value;
    }
    
    
    //var WSC = document.getElementById("ctl00_ContentPlaceHolder1_txtRWSC").value;
    var WSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtRWSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtRWSC").value = 0;
    }
    else {
        WSC = document.getElementById("ctl00_ContentPlaceHolder1_txtRWSC").value;
    }
    // var XRAY = document.getElementById("ctl00_ContentPlaceHolder1_txtRXRAY").value;
    var XRAY = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtRXRAY").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtRXRAY").value = 0;
    }
    else {
        XRAY = document.getElementById("ctl00_ContentPlaceHolder1_txtRXRAY").value;
    }
    var ET = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtET").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtET").value = 0;
    }
    else {
        ET = document.getElementById("ctl00_ContentPlaceHolder1_txtET").value;
    }
    if (HFSC == "C") {
        var cFSC = parseFloat(FSC) * parseFloat(cw);
        cFSC = Math.round(cFSC);
        document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value = cFSC;
        document.getElementById("ctl00_ContentPlaceHolder1_FSC").value = cFSC;
    }
    if (HFSC == "G") {
        var gFSC = parseFloat(FSC) * parseFloat(gw);
        gFSC = Math.round(gFSC);
        document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value = gFSC;
        document.getElementById("ctl00_ContentPlaceHolder1_FSC").value = gFSC;
    }
    if (HWSC == "C") {
        var cWSC = parseFloat(WSC) * parseFloat(cw);
        cWSC = Math.round(cWSC);



        document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value = cWSC;
        document.getElementById("ctl00_ContentPlaceHolder1_WSC").value = cWSC;
    }
    if (HWSC == "G") {
        var gWSC = parseFloat(WSC) * parseFloat(gw);
        gWSC = Math.round(gWSC);
        document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value = gWSC;
        document.getElementById("ctl00_ContentPlaceHolder1_WSC").value = gWSC;
    }
    if (HXRAY == "C") {
        var cXRAY = parseFloat(XRAY) * parseFloat(cw);
        var hndfixCH = parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_hndXray_fixCharges").value);
        cXRAY = Math.round(cXRAY);
        if (cXRAY < hndfixCH) {
            cXRAY = hndfixCH;
        }
        else {
            cXRAY = cXRAY;
        }
        document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value = cXRAY;
        document.getElementById("ctl00_ContentPlaceHolder1_XRay").value = cXRAY;
    }
    if (HXRAY == "G") {
        var gXRAY = parseFloat(XRAY) * parseFloat(gw);
        var hndfixCH = parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_hndXray_fixCharges").value);
        gXRAY = Math.round(gXRAY);
        if (gXRAY < hndfixCH) {
            gXRAY = hndfixCH;
        }
        else {
            gXRAY = gXRAY;
        }
        document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value = gXRAY;
        document.getElementById("ctl00_ContentPlaceHolder1_XRay").value = gXRAY;
    }
    DueFreightType();

}

function CommonAirlineDetailCharge() {

    // var Pieces = document.getElementById("ctl00_ContentPlaceHolder1_txtPieces").value;
    var Pieces = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtPieces").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtPieces").value = 0;
    }
    else {
        Pieces = document.getElementById("ctl00_ContentPlaceHolder1_txtPieces").value;
    }

    // var cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
    var cw = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value = 0;
    }
    else {
        cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
    }
    //     var gw = document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value;
    var gw = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value = 0;
    }
    else {
        gw = document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value;
    }
    //     var Volwt = document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value;
    var Volwt = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value = 0;
    }
    else {
        Volwt = document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value;
    }
    //     var HFSC = document.getElementById("ctl00_ContentPlaceHolder1_HiddenFSC").value;
    var HFSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_HiddenFSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_HiddenFSC").value = 0;
    }
    else {
        HFSC = document.getElementById("ctl00_ContentPlaceHolder1_HiddenFSC").value;
    }
    //     var HWSC = document.getElementById("ctl00_ContentPlaceHolder1_HiddenWSC").value;
    var HWSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_HiddenWSC").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_HiddenWSC").value = 0;
    }
    else {
        HWSC = document.getElementById("ctl00_ContentPlaceHolder1_HiddenWSC").value;
    }
    //     var HXRAY = document.getElementById("ctl00_ContentPlaceHolder1_HiddenXRay").value;
    var HXRAY = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_HiddenXRay").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_HiddenXRay").value = 0;
    }
    else {
        HXRAY = document.getElementById("ctl00_ContentPlaceHolder1_HiddenXRay").value;
    }

    //     var FSC = document.getElementById("ctl00_ContentPlaceHolder1_HTextBox1").value;
    var FSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_HTextBox1").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_HTextBox1").value = 0;
    }
    else {
        FSC = document.getElementById("ctl00_ContentPlaceHolder1_HTextBox1").value;
    }
    //     var WSC = document.getElementById("ctl00_ContentPlaceHolder1_HTextBox2").value;
    var WSC = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_HTextBox2").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_HTextBox2").value = 0;
    }
    else {
        WSC = document.getElementById("ctl00_ContentPlaceHolder1_HTextBox2").value;
    }
    //     var XRAY = document.getElementById("ctl00_ContentPlaceHolder1_HTextBox3").value;
    var XRAY = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_HTextBox3").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_HTextBox3").value = 0;
    }
    else {
        XRAY = document.getElementById("ctl00_ContentPlaceHolder1_HTextBox3").value;
    }
    var ET = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtET").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtET").value = 0;
    }
    else {
        ET = document.getElementById("ctl00_ContentPlaceHolder1_txtET").value;
    }
    if (HFSC == "C") {
        //         alert("CFSC");
        var cFSC = parseFloat(FSC) * parseFloat(cw);
        cFSC = Math.round(cFSC * 100) / 100
        document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value = cFSC;
        document.getElementById("ctl00_ContentPlaceHolder1_FSC").value = cFSC;
    }
    if (HFSC == "G") {
        //         alert("gFSC");
        var gFSC = parseFloat(FSC) * parseFloat(gw);
        gFSC = Math.round(gFSC * 100) / 100
        document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value = gFSC;
        document.getElementById("ctl00_ContentPlaceHolder1_FSC").value = gFSC;
    }
    if (HWSC == "C") {
        //         alert("CWSC");
        var cWSC = parseFloat(WSC) * parseFloat(cw);
        cWSC = Math.round(cWSC * 100) / 100
        document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value = cWSC;
        document.getElementById("ctl00_ContentPlaceHolder1_WSC").value = cWSC;
    }
    if (HWSC == "G") {
        //          alert("GWSC");
        var gWSC = parseFloat(WSC) * parseFloat(gw);
        gWSC = Math.round(gWSC * 100) / 100
        document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value = gWSC;
        document.getElementById("ctl00_ContentPlaceHolder1_WSC").value = gWSC;
    }
    if (HXRAY == "C") {
        //          alert("CXRay");
        var cXRAY = parseFloat(XRAY) * parseFloat(cw);
        cXRAY = Math.round(cXRAY * 100) / 100
        document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value = cXRAY;
        document.getElementById("ctl00_ContentPlaceHolder1_XRay").value = cXRAY;
    }
    if (HXRAY == "G") {
        //          alert("GXRay");
        var gXRAY = parseFloat(XRAY) * parseFloat(gw);
        gXRAY = Math.round(gXRAY * 100) / 100
        document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value = gXRAY;
        document.getElementById("ctl00_ContentPlaceHolder1_XRay").value = gXRAY;
    }
    var TFSC = document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value;
    var TWSC = document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value;
    var TXRAY = document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value;
    var TACI = document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    var TAWB = document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    var TDB = document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value;
    var TCAT = document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value;
    var TOther = document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value;
      var TMSC = document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value;

    var Result = parseFloat(TFSC) + parseFloat(TWSC) + parseFloat(TXRAY) + parseFloat(TACI) + parseFloat(TAWB) + parseFloat(TDB) + parseFloat(TCAT) + parseFloat(TOther)+parseFloat(TMSC)+parseFloat(ET);
    document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = Result;
    chk_greater();
    DueFreightType();
    // var FreightAmount=parseInt(TariffRate)*parseInt(cw);
}

function FreightAmountCalculate() {
    //     var TariffRate = document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value;
    //     var cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
    var TariffRate = 0, cw = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value = 0;
    }
    else {
        TariffRate = document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value = 0;
    }
    else {
        cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
    }

    var FreightAmount = parseFloat(TariffRate) * parseFloat(cw);
    FreightAmount = Math.round(FreightAmount);
    document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value = FreightAmount;
    document.getElementById("ctl00_ContentPlaceHolder1_lblFreightAmount").value = FreightAmount;
    //****************************
    //     var SpecialRate =  document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value;
    var SpecialRate = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value = 0;
    }
    else {
        SpecialRate = document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value;
    }
    var SpecialAmount = parseFloat(SpecialRate) * parseFloat(cw);
    // document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value=SpecialAmount;
    //****************************
    //     var PRate=document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value;
    var PRate = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value = 0;
    }
    else {
        PRate = document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value;
    }
    var PAmt = parseFloat(PRate) * parseFloat(cw);
    PAmt = Math.round(PAmt);
    document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value = PAmt;
    if (document.getElementById('ctl00_ContentPlaceHolder1_ChkMinAgent').checked == true) {
        var TariffRate = document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value;
        document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value = TariffRate;
        document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value = TariffRate;
        document.getElementById("ctl00_ContentPlaceHolder1_lblFreightAmount").value = TariffRate;
        document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value = TariffRate;
    }
    if (document.getElementById('ctl00_ContentPlaceHolder1_ChkMinAirline').checked == true) {
        //      var PRate=document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value;
        var PRate = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value = 0;
        }
        else {
            PRate = document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value;
        }
        PRate = Math.round(PRate);
        document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value = PRate;
    }
    PrincipalAmountCalculate();
    DueFreightType();
}

function PrincipalAmountCalculate() {
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtPSpotRate").value == 0) {
        //    var PRate=document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value;
        //var Cw=document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
        var PRate = 0, Cw = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value = 0;
        }
        else {
            PRate = document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value;
        }
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value = 0;
        }
        else {
            Cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
        }
        if (document.getElementById('ctl00_ContentPlaceHolder1_ChkMinAirline').checked == true) {
            var PRate = 0;
            if (document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value == '') {
                document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value = 0;
            }
            else {
                PRate = document.getElementById("ctl00_ContentPlaceHolder1_txtPRate").value;
            }
            document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value = PRate;

        }
        else {
            var PrincipalAmt = parseFloat(PRate) * parseFloat(Cw);
            PrincipalAmt = Math.round(PrincipalAmt);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value = PrincipalAmt;
        }
    }
    else {
        //    var PSRate=document.getElementById("ctl00_ContentPlaceHolder1_txtPSpotRate").value;
        //    var Cw=document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;

        var PSRate = 0, Cw = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtPSpotRate").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtPSpotRate").value = 0;
        }
        else {
            PSRate = document.getElementById("ctl00_ContentPlaceHolder1_txtPSpotRate").value;
        }

        if (document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value = 0;
        }
        else {
            Cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
        }
        if (document.getElementById('ctl00_ContentPlaceHolder1_ChkMinAirline').checked == true) {
            document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value = PSRate;
        }
        else {
            var PrincipalAmt = parseFloat(PSRate) * parseFloat(Cw);
            PrincipalAmt = Math.round(PrincipalAmt);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPAmount").value = PrincipalAmt;
        }
    }
}

function chk_greater() {
    //   var vw = document.getElementById("ctl00_ContentPlaceHolder1_txtVolumeWt").value;
    //   var gw = document.getElementById("ctl00_ContentPlaceHolder1_txtGrossWt").value;
    var vw = 0, gw = 0;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value = 0;
    }
    else {
        vw = document.getElementById("ctl00_ContentPlaceHolder1_txtVolwt").value;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value = 0;
    }
    else {
        gw = document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value;
    }
    if (parseInt(vw) > 200000 || parseInt(gw) > 200000) {
        alert("Pls Enter Valid Weight.");
    }
    else {
        if (parseInt(vw) >= parseInt(gw)) {

            document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value = vw;
            //          document.getElementById("ctl00_ContentPlaceHolder1_txtPieces").focus();
        }
        else
            if (parseInt(gw) >= parseInt(vw)) {
                document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value = gw;
            //             document.getElementById("ctl00_ContentPlaceHolder1_txtPieces").focus();
        }
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value != '') {
        var chrgwt = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
        var Dest = document.getElementById("ctl00_ContentPlaceHolder1_ddlDestination").value;
        var Shipment = document.getElementById("ctl00_ContentPlaceHolder1_ddlShipmentType").value;
        var AirlineDetailID = document.getElementById("ctl00_ContentPlaceHolder1_hdnAirlineDetailId").value;
        var TariffRate = document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value;
        var SpRate = document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value;
        var dt = 0;
        $.ajax({
        
            url: "Handler/TariffRateOnCw.ashx",
            data: "&ChWt=" + chrgwt + "&Dest=" + Dest + "&AirlineDetailID=" + AirlineDetailID + "&Shipment=" + Shipment,
            cache: false,
            async: false,
            success: function(data) {
                if (data != null) {
                    $.each(data.items, function(i, item) {
                        if (item) {
                            TariffRate = item.Tariff;
                            if (item.Status == "N") {
                                var FreightAmount = parseFloat(TariffRate) * parseFloat(chrgwt);
                                var SpAmt = parseFloat(chrgwt) * parseFloat(TariffRate);
                            }
                            else {
                                var FreightAmount = parseFloat(TariffRate);
                                var SpAmt = parseFloat(TariffRate);
                            }
                            FreightAmount = Math.round(FreightAmount);
                            SpAmt = Math.round(SpAmt);
                            document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value = SpAmt;
                            document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value = TariffRate;
                            document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value = TariffRate;
                            document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value = FreightAmount;
                            document.getElementById("ctl00_ContentPlaceHolder1_lblFreightAmount").value = FreightAmount;
                            var totalduecarrieer = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
                            totalduecarrieer = parseFloat(FreightAmount) + parseFloat(totalduecarrieer);
                            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = totalduecarrieer;
                        }
                    });
                    Duecarrier_Claculate();
                }
            }
        });
    }
    return true;
}

function blockNonNumbers(obj, e, allowDecimal, allowNegative) {
    var key;
    var isCtrl = false;
    var keychar;
    var reg;

    if (window.event) {
        key = e.keyCode;
        isCtrl = window.event.ctrlKey
    }
    else if (e.which) {
        key = e.which;
        isCtrl = e.ctrlKey;
    }

    if (isNaN(key)) return true;

    keychar = String.fromCharCode(key);

    // check for backspace or delete, or if Ctrl was pressed
    if (key == 8 || isCtrl) {
        return true;
    }

    reg = /\d/;
    var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
    var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;

    return isFirstN || isFirstD || reg.test(keychar);
}

function DueFreightType() {
    //**************FOR PREPAID************************
    if (document.getElementById("ctl00_ContentPlaceHolder1_rbDueFreight_0").checked == true) {
        // alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').value);

        // var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
        var DueCarrier = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = 0;
        }
        else {
            DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
        }
        // var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        // var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var ValuationCharge = 0, Tax = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value = 0;
        }
        else {
            ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        }
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value = 0;
        }
        else {
            Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        }
        var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
        var Total_Prepaid = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentP);

        if (document.getElementById("ctl00_ContentPlaceHolder1_rbFType_0").checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;

            Total_Prepaid = parseFloat(Total_Prepaid) + parseFloat(FreightAmount);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
        }
        else {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Collect = parseFloat(FreightAmount) + parseFloat(DueAgentC);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
        }
    }
    //**************FOR COLLECT************************
    if (document.getElementById("ctl00_ContentPlaceHolder1_rbDueFreight_1").checked == true) {
        //alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_1').value);

        // var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
        var DueCarrier = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = 0;
        }
        else {
            DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
        }
        //var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        // var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var ValuationCharge = 0, Tax = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value = 0;
        }
        else {
            ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        }
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value = 0;
        }
        else {
            Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        }
        var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;

        var Total_Collect = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentC);


        if (document.getElementById("ctl00_ContentPlaceHolder1_rbFType_0").checked == true) {
            var collect = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
            var Total_Prepaid = parseFloat(collect) + parseFloat(DueAgentP);

            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
        }
        else {

            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;

            Total_Collect = parseFloat(Total_Collect) + parseFloat(FreightAmount);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

        }

    }
}
function acifee() {
    //    if(document.getElementById("ctl00_ContentPlaceHolder1_rbCalculate_1").checked == true)
    //    {       
    //    OnOff();
    //    }
    //    else
    //    {

    var vw = document.getElementById("ctl00_ContentPlaceHolder1_Hidden1").value;
    //var gw = document.getElementById("ctl00_ContentPlaceHolder1_txtHouses").value;
    var gw = 0;

    if (document.getElementById("ctl00_ContentPlaceHolder1_txtHouses").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtHouses").value = 0;
    }
    else {
        gw = document.getElementById("ctl00_ContentPlaceHolder1_txtHouses").value;
    }

    var Result = parseFloat(vw) * parseFloat(gw);
    document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value = Result;
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtHouses").value == 1) {
        document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value = document.getElementById("ctl00_ContentPlaceHolder1_Hidden1").value;
    }
    var FSC = document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value;
    var WSC = document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value;
    var XRAY = document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value;
        var MSC = document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value;
        var ET = document.getElementById("ctl00_ContentPlaceHolder1_txtET").value;
        var ABC = parseFloat(FSC) + parseFloat(WSC) + parseFloat(XRAY) + parseFloat(MSC) + parseFloat(ET);
    //   alert(ABC);
    var ACI = document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    var AWB = document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    var DBCharges = document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value;
    var Catrage = document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value;
    var Others = document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value;

    var DueCarrier = parseFloat(ABC) + parseFloat(ACI) + parseFloat(AWB) + parseFloat(DBCharges) + parseFloat(Catrage) + parseFloat(Others);
    DueCarrier = Math.round(DueCarrier);
    document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = parseFloat(DueCarrier);
    DueFreightType();
    //   }
    //                           //alert(Result)
    // var Result=(vw * 1) * (gw * 1);
    // alert(Result);
    // alert(parseFloat(vw)*parseFloat(gw));
    //document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value = 5;

}
function Valuation() {
    if (document.getElementById("ctl00_ContentPlaceHolder1_rbDueFreight_0").checked == true) {
        var ValuationCharge = 0, Tax = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value = 0;
        }
        else {
            ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        }
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value = 0;
        }
        else {
            Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        }
        //*******************************************************************************
        if (document.getElementById("ctl00_ContentPlaceHolder1_rbFType_0").checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

            var Total_Prepaid = parseFloat(FreightAmount) + parseFloat(Duecarrier) + parseFloat(DueAgentP) + parseFloat(ValuationCharge) + parseFloat(Tax);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
        }
        else {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

            //pls chek var collect=document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Prepaid = parseFloat(Duecarrier) + parseFloat(DueAgentP) + parseFloat(ValuationCharge) + parseFloat(Tax);

            var Total_Collect = parseFloat(FreightAmount) + parseFloat(DueAgentC);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;

        }

    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_rbDueFreight_1").checked == true) {
        var ValuationCharge = 0, Tax = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value = 0;
        }
        else {
            ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        }
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value = 0;
        }
        else {
            Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        }
        //********************************************************************************
        if (document.getElementById("ctl00_ContentPlaceHolder1_rbFType_0").checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;

            var Total_Collect = parseFloat(Duecarrier) + parseFloat(DueAgentC) + parseFloat(ValuationCharge) + parseFloat(Tax);
            var Total_Prepaid = parseFloat(FreightAmount) + parseFloat(DueAgentP);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
        }
        else {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

            //pls chek var collect=document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Collect = parseFloat(Duecarrier) + parseFloat(DueAgentC) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(FreightAmount);

            var Total_Prepaid = parseFloat(DueAgentP);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;

        }

    }

} //End of Valuation
function Tax() {
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').checked == true) {
        var ValuationCharge = 0, Tax = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value = 0;
        }
        else {
            ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        }
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value = 0;
        }
        else {
            Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        }
        //***********************************************************************
        if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

            var Total_Prepaid = parseFloat(FreightAmount) + parseFloat(Duecarrier) + parseFloat(DueAgentP) + parseFloat(ValuationCharge) + parseFloat(Tax);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
        }
        else {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

            //pls chek//var collect=document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Prepaid = parseFloat(Duecarrier) + parseFloat(DueAgentP) + parseFloat(ValuationCharge) + parseFloat(Tax);

            var Total_Collect = parseFloat(FreightAmount) + parseFloat(DueAgentC);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
        }
    }
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_1').checked == true) {
        var ValuationCharge = 0, Tax = 0;
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value = 0;
        }
        else {
            ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        }
        if (document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value == '') {
            document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value = 0;
        }
        else {
            Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        }

        if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;

            var Total_Collect = parseFloat(Duecarrier) + parseFloat(DueAgentC) + parseFloat(ValuationCharge) + parseFloat(Tax);
            var Total_Prepaid = parseFloat(FreightAmount) + parseFloat(DueAgentP);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
        }
        else {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var Duecarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

            //pls chek //var collect=document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Collect = parseFloat(Duecarrier) + parseFloat(DueAgentC) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(FreightAmount);

            var Total_Prepaid = parseFloat(DueAgentP);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;

        }

    }

}


function FreightType(obj) {
    //**************FOR PREPAID************************
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true) {
        // alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').value);

        var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
        var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
        var Total_Prepaid = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentP);

        if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;

            Total_Prepaid = parseFloat(Total_Prepaid) + parseFloat(FreightAmount);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
        }
        else {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Collect = parseFloat(DueCarrier) + parseFloat(DueAgentC);
            var Total_Prepaid = parseFloat(FreightAmount) + parseFloat(DueAgentP);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
        }
    }
    //**************FOR COLLECT************************
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_1').checked == true) {
        //alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_1').value);

        var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
        var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;

        var Total_Collect = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentC);


        if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
            var Total_Collect = parseFloat(FreightAmount) + parseFloat(DueAgentC);
            var Total_Prepaid = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentP);

            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
        }
        else {

            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;

            Total_Collect = parseFloat(Total_Collect) + parseFloat(FreightAmount);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

        }

    }
}

function DueFreightType(obj) {
    //**************FOR PREPAID************************
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').checked == true) {
        // alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').value);

        //           var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
        document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value = "0";
        var DueCarrier = parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtET").value);


        var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
        var Total_Prepaid = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentP);

        document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = DueCarrier;

        if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;

            Total_Prepaid = parseFloat(Total_Prepaid) + parseFloat(FreightAmount);
            Total_Prepaid = Total_Prepaid.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
        }
        else {
            var collect = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Collect = parseFloat(collect) + parseFloat(DueAgentC);
            Total_Collect = Total_Collect.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            Total_Prepaid = Total_Prepaid.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
        }
    }
    //**************FOR COLLECT************************
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_1').checked == true) {
        //alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_1').value);

        //           var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;

        var DisBursmentCharges = document.getElementById("ctl00_ContentPlaceHolder1_Hidden2").value;


        document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value = DisBursmentCharges;

        var DueCarrier = parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtET").value);

        var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;

        var Total_Collect = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentC);



        document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = DueCarrier;

        if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true) {
            var collect = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
            var Total_Prepaid = parseFloat(collect) + parseFloat(DueAgentP);
            Total_Prepaid = Total_Prepaid.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            Total_Collect = Total_Collect.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
        }
        else {

            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            Total_Collect = parseFloat(Total_Collect) + parseFloat(FreightAmount);
            Total_Collect = Total_Collect.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

        }

    }

}

function DueFreightTypeForOnOFF() {
    //**************FOR PREPAID************************
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').checked == true) {
        // alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_0').value);

        //           var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;

        var DueCarrier = parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtET").value);


        var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
        var Total_Prepaid = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentP);

        document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = DueCarrier;

        if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true) {
            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;

            Total_Prepaid = parseFloat(Total_Prepaid) + parseFloat(FreightAmount);
            Total_Prepaid = Total_Prepaid.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
        }
        else {
            var collect = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
            var Total_Collect = parseFloat(collect) + parseFloat(DueAgentC);
            Total_Collect = Total_Collect.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            Total_Prepaid = Total_Prepaid.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
        }
    }
    //**************FOR COLLECT************************
    if (document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_1').checked == true) {
        //alert(document.getElementById('ctl00_ContentPlaceHolder1_rbDueFreight_1').value);

        //           var DueCarrier = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;

        var DueCarrier = parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtMSC").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtDisbursmentCharges").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtCatrage").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value) + parseFloat(document.getElementById("ctl00_ContentPlaceHolder1_txtET").value);

        var ValuationCharge = document.getElementById("ctl00_ContentPlaceHolder1_txtValuationCharge").value;
        var Tax = document.getElementById("ctl00_ContentPlaceHolder1_txtTax").value;
        var DueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;

        var Total_Collect = parseFloat(DueCarrier) + parseFloat(ValuationCharge) + parseFloat(Tax) + parseFloat(DueAgentC);



        document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value = DueCarrier;

        if (document.getElementById('ctl00_ContentPlaceHolder1_rbFType_0').checked == true) {
            var collect = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;
            var DueAgentP = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;
            var Total_Prepaid = parseFloat(collect) + parseFloat(DueAgentP);
            Total_Prepaid = Total_Prepaid.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = Total_Prepaid;
            Total_Collect = Total_Collect.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
        }
        else {

            var FreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value;

            Total_Collect = parseFloat(Total_Collect) + parseFloat(FreightAmount);
            Total_Collect = Total_Collect.toFixed(2);
            document.getElementById("ctl00_ContentPlaceHolder1_txtCollect").value = Total_Collect;
            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentP").value;

        }

    }
}

function FreightAmountCalculate1() {
   
    var TariffRate = 0, cw = 0;
    var TRate = 0
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value = 0;
    }
    else {
        TariffRate = document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value == '') {
        document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value = 0;
    }
    else {
        cw = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value != '') {
        var chrgwt = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
        var Dest = document.getElementById("ctl00_ContentPlaceHolder1_ddlDestination").value;
        var Shipment = document.getElementById("ctl00_ContentPlaceHolder1_ddlShipmentType").value;
        var FlightDate = document.getElementById("ctl00_ContentPlaceHolder1_txtFlightDate").value;
        var AirlineDetailID = document.getElementById("ctl00_ContentPlaceHolder1_hdnAirlineDetailId").value;
        var dt = 0;
        $.ajax({
        url: "Handler/TariffRateOnCw.ashx",
            data: "&ChWt=" + chrgwt + "&Dest=" + Dest + "&AirlineDetailID=" + AirlineDetailID + "&Shipment=" + Shipment,
            cache: false,
            async: false,
            success: function(data) {
                if (data != null) {
                    $.each(data.items, function(i, item) {
                        if (item) {
                            TariffRate = item.Tariff;
                            if (document.getElementById('ctl00_ContentPlaceHolder1_ChkMinAgent').checked == true) {
                                var FreightAmount = parseFloat(TariffRate);
                            }
                            else {

                                var FreightAmount = parseFloat(TariffRate) * parseFloat(cw);
                            }
                            FreightAmount = Math.round(FreightAmount);
       document.getElementById("ctl00_ContentPlaceHolder1_txtTariffRate").value = TariffRate;
        document.getElementById("ctl00_ContentPlaceHolder1_txtSpRate").value = TariffRate;
      document.getElementById("ctl00_ContentPlaceHolder1_txtSpAmt").value = FreightAmount;

      document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value = FreightAmount;
               document.getElementById("ctl00_ContentPlaceHolder1_lblFreightAmount").value = FreightAmount;
                            //                            var totalduecarrieer = document.getElementById("ctl00_ContentPlaceHolder1_txtDueCarrier").value;
                            //                            totalduecarrieer = parseFloat(FreightAmount) + parseFloat(totalduecarrieer);
                            //                            document.getElementById("ctl00_ContentPlaceHolder1_txtPrepaid").value = totalduecarrieer;


                       }
                    });
                    Duecarrier_Claculate();
                }
            }
        });
    }
}

function Duecarrier_Claculate() {

    var chrgwt = document.getElementById("ctl00_ContentPlaceHolder1_txtCw").value;
    var Dest = document.getElementById("ctl00_ContentPlaceHolder1_ddlDestination").value;
    var Shipment = document.getElementById("ctl00_ContentPlaceHolder1_ddlShipmentType").value;
    var txtACIFee = document.getElementById("ctl00_ContentPlaceHolder1_txtACIFee").value;
    var txtDueAgentC = document.getElementById("ctl00_ContentPlaceHolder1_txtDueAgentC").value;
    var txtFreightAmount = document.getElementById("ctl00_ContentPlaceHolder1_txtFreightAmount").value;

    var txtAWBFee = document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value;
    if (document.getElementById("ctl00_ContentPlaceHolder1_rbDueFreight_0").checked == true) {
        var rbDueFreight = "PREPAID";

    }
    else {

        var rbDueFreight = "COLLECT";

    }
    
     if (document.getElementById('ctl00_ContentPlaceHolder1_ChkMinAgent').checked == true) {
                               Minimum="Y";
                            }
                            else {

                                 Minimum="N";
                            }

    var AirlineDetailID = document.getElementById("ctl00_ContentPlaceHolder1_hdnAirlineDetailId").value;
    var Grossgwt = document.getElementById("ctl00_ContentPlaceHolder1_txtGw").value;
    $.ajax({
    url: "Handler/DueCarrierSales.ashx",
        data: "&ChWt=" + chrgwt + "&Dest=" + Dest + "&AirlineDetailID=" + AirlineDetailID + "&txtFreightAmount=" + txtFreightAmount + "&Shipment=" + Shipment + "&txtACIFee=" + txtACIFee + "&txtDueAgentC=" + txtDueAgentC + "&txtAWBFee=" + txtAWBFee + "&rbDueFreight=" + rbDueFreight + "&Grossgwt=" + Grossgwt+"&Minimum="+Minimum,
        cache: false,
        async: false,
        success: function(data) {

            if (data != null) {

                $.each(data.items, function(i, item) {
                    if (item) {
                        document.getElementById("ctl00_ContentPlaceHolder1_txtRFSC").value = parseFloat(item.FSCRate).toFixed(2);
                        document.getElementById("ctl00_ContentPlaceHolder1_txtRWSC").value = parseFloat(item.WSCRate).toFixed(2);
                        document.getElementById("ctl00_ContentPlaceHolder1_txtRXRAY").value = parseFloat(item.XRAYRate).toFixed(2);
                        document.getElementById("ctl00_ContentPlaceHolder1_txtFSC").value = parseFloat(item.FSC).toFixed(2);
                        document.getElementById("ctl00_ContentPlaceHolder1_txtWSC").value = parseFloat(item.WSC).toFixed(2);
                        document.getElementById("ctl00_ContentPlaceHolder1_txtXRAY").value = parseFloat(item.XRAY).toFixed(2);
                        document.getElementById("ctl00_ContentPlaceHolder1_txtAWBFee").value = parseFloat(item.AWBFEE).toFixed(2);
                    }
                });

            }

        }

    });
if(AirlineDetailID=="148"&&AirlineDetailID=="147")
      MH_Aendment();
    OnOff();
}
function MH_Aendment()
{
var check="7thfeb2013";
var Dest = document.getElementById("ctl00_ContentPlaceHolder1_ddlDestination").value;
    var Shipment = document.getElementById("ctl00_ContentPlaceHolder1_ddlShipmentType").value;
                           if(Dest=="1717"||Dest=="1815"||Dest=="2077"||Dest=="2265"||Dest=="2679")
                           document.getElementById("ctl00_ContentPlaceHolder1_txtOthers").value="0";
                          
}




