function actbAgent(obj,ca){
	/* ---- Public Variables ---- */
	this.actbAgent_timeOut = -1; // Autocomplete Timeout in ms (-1: autocomplete never time out)
	this.actbAgent_lim = 20;    // Number of elements autocomplete can show (-1: no limit)
	this.actbAgent_firstText = false; // should the auto complete be limited to the beginning of keyword?
	this.actbAgent_mouse = true; // Enable Mouse Support
	this.actbAgent_delimiter = new Array(';',',');  // Delimiter for multiple autocomplete. Set it to empty array for single autocomplete
	this.actbAgent_startcheck = 1; // Show widget only after this number of characters is typed in.
	/* ---- Public Variables ---- */

	/* --- Styles --- */
	this.actbAgent_bgColor = '#F1F0F0';
	this.actbAgent_textColor = '#D60000';
	this.actbAgent_hColor = '#FFFFFF';
	this.actbAgent_fFamily = 'Verdana';
	this.actbAgent_fSize = '11px';
	this.actbAgent_hStyle = 'text-decoration:underline;font-weight="bold"';
	/* --- Styles --- */

	/* ---- Private Variables ---- */
	var actbAgent_delimwords = new Array();
	var actbAgent_cdelimword = 0;
	var actbAgent_delimchar = new Array();
	var actbAgent_display = false;
	var actbAgent_pos = 0;
	var actbAgent_total = 0;
	var actbAgent_curr = null;
	var actbAgent_rangeu = 0;
	var actbAgent_ranged = 0;
	var actbAgent_bool = new Array();
	var actbAgent_pre = 0;
	var actbAgent_toid;
	var actbAgent_tomake = false;
	var actbAgent_getpre = "";
	var actbAgent_mouse_on_list = 1;
	var actbAgent_kwcount = 0;
	var actbAgent_caretmove = false;
	this.actbAgent_keywords = new Array();
	/* ---- Private Variables---- */
	
	this.actbAgent_keywords = ca;
	var actbAgent_self = this;

	actbAgent_curr = obj;
	
	addEvent(actbAgent_curr,"focus",actbAgent_setup);
	function actbAgent_setup(){
		addEvent(document,"keydown",actbAgent_checkkey);
		addEvent(actbAgent_curr,"blur",actbAgent_clear);
		addEvent(document,"keypress",actbAgent_keypress);
	}

	function actbAgent_clear(evt){
		if (!evt) evt = event;
		removeEvent(document,"keydown",actbAgent_checkkey);
		removeEvent(actbAgent_curr,"blur",actbAgent_clear);
		removeEvent(document,"keypress",actbAgent_keypress);
		actbAgent_removedisp();
	}
	function actbAgent_parse(n){
		if (actbAgent_self.actbAgent_delimiter.length > 0){
			var t = actbAgent_delimwords[actbAgent_cdelimword].addslashes();
			var plen = actbAgent_delimwords[actbAgent_cdelimword].length;
		}else{
			var t = actbAgent_curr.value.addslashes();
			var plen = actbAgent_curr.value.length;
		}
		var tobuild = '';
		var i;

		if (actbAgent_self.actbAgent_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}
		var p = n.search(re);
				
		for (i=0;i<p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "<font style='"+(actbAgent_self.actbAgent_hStyle)+"'>"
		for (i=p;i<plen+p;i++){
			tobuild += n.substr(i,1);
		}
		tobuild += "</font>";
			for (i=plen+p;i<n.length;i++){
			tobuild += n.substr(i,1);
		}
		return tobuild;
	}
	function actbAgent_generate(){
		if (document.getElementById('tat_table')){ actbAgent_display = false;document.body.removeChild(document.getElementById('tat_table')); } 
		if (actbAgent_kwcount == 0){
			actbAgent_display = false;
			return;
		}
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbAgent_curr) + actbAgent_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbAgent_curr) + "px";
		a.style.backgroundColor=actbAgent_self.actbAgent_bgColor;
		a.id = 'tat_table';
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbAgent_self.actbAgent_mouse){
			a.onmouseout = actbAgent_table_unfocus;
			a.onmouseover = actbAgent_table_focus;
		}
		var counter = 0;
		for (i=0;i<actbAgent_self.actbAgent_keywords.length;i++){
			if (actbAgent_bool[i]){
				counter++;
				r = a.insertRow(-1);
				if (first && !actbAgent_tomake){
					r.style.backgroundColor = actbAgent_self.actbAgent_hColor;
					first = false;
					actbAgent_pos = counter;
				}else if(actbAgent_pre == i){
					r.style.backgroundColor = actbAgent_self.actbAgent_hColor;
					first = false;
					actbAgent_pos = counter;
				}else{
					r.style.backgroundColor = actbAgent_self.actbAgent_bgColor;
				}
				r.id = 'tat_tr'+(j);
				c = r.insertCell(-1);
				c.style.color = actbAgent_self.actbAgent_textColor;
				c.style.fontFamily = actbAgent_self.actbAgent_fFamily;
				c.style.fontSize = actbAgent_self.actbAgent_fSize;
				c.innerHTML = actbAgent_parse(actbAgent_self.actbAgent_keywords[i]);
				c.id = 'tat_td'+(j);
				c.setAttribute('pos',j);
				if (actbAgent_self.actbAgent_mouse){
					c.style.cursor = 'pointer';
					c.onclick=actbAgent_mouseclick;
					c.onmouseover = actbAgent_table_highlight;
				}
				j++;
			}
			if (j - 1 == actbAgent_self.actbAgent_lim && j < actbAgent_total){
				r = a.insertRow(-1);
				r.style.backgroundColor = actbAgent_self.actbAgent_bgColor;
				c = r.insertCell(-1);
				c.style.color = actbAgent_self.actbAgent_textColor;
				c.style.fontFamily = 'arial narrow';
				c.style.fontSize = actbAgent_self.actbAgent_fSize;
				c.align='center';
				replaceHTML(c,'\\/');
				if (actbAgent_self.actbAgent_mouse){
					c.style.cursor = 'pointer';
					c.onclick = actbAgent_mouse_down;
				}
				break;
			}
		}
		actbAgent_rangeu = 1;
		actbAgent_ranged = j-1;
		actbAgent_display = true;
		if (actbAgent_pos <= 0) actbAgent_pos = 1;
	}
	function actbAgent_remake(){
		document.body.removeChild(document.getElementById('tat_table'));
		a = document.createElement('table');
		a.cellSpacing='1px';
		a.cellPadding='2px';
		a.style.position='absolute';
		a.style.top = eval(curTop(actbAgent_curr) + actbAgent_curr.offsetHeight) + "px";
		a.style.left = curLeft(actbAgent_curr) + "px";
		a.style.backgroundColor=actbAgent_self.actbAgent_bgColor;
		a.id = 'tat_table';
		if (actbAgent_self.actbAgent_mouse){
			a.onmouseout= actbAgent_table_unfocus;
			a.onmouseover=actbAgent_table_focus;
		}
		document.body.appendChild(a);
		var i;
		var first = true;
		var j = 1;
		if (actbAgent_rangeu > 1){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbAgent_self.actbAgent_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbAgent_self.actbAgent_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbAgent_self.actbAgent_fSize;
			c.align='center';
			replaceHTML(c,'/\\');
			if (actbAgent_self.actbAgent_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbAgent_mouse_up;
			}
		}
		for (i=0;i<actbAgent_self.actbAgent_keywords.length;i++){
			if (actbAgent_bool[i]){
				if (j >= actbAgent_rangeu && j <= actbAgent_ranged){
					r = a.insertRow(-1);
					r.style.backgroundColor = actbAgent_self.actbAgent_bgColor;
					r.id = 'tat_tr'+(j);
					c = r.insertCell(-1);
					c.style.color = actbAgent_self.actbAgent_textColor;
					c.style.fontFamily = actbAgent_self.actbAgent_fFamily;
					c.style.fontSize = actbAgent_self.actbAgent_fSize;
					c.innerHTML = actbAgent_parse(actbAgent_self.actbAgent_keywords[i]);
					c.id = 'tat_td'+(j);
					c.setAttribute('pos',j);
					if (actbAgent_self.actbAgent_mouse){
						c.style.cursor = 'pointer';
						c.onclick=actbAgent_mouseclick;
						c.onmouseover = actbAgent_table_highlight;
					}
					j++;
				}else{
					j++;
				}
			}
			if (j > actbAgent_ranged) break;
		}
		if (j-1 < actbAgent_total){
			r = a.insertRow(-1);
			r.style.backgroundColor = actbAgent_self.actbAgent_bgColor;
			c = r.insertCell(-1);
			c.style.color = actbAgent_self.actbAgent_textColor;
			c.style.fontFamily = 'arial narrow';
			c.style.fontSize = actbAgent_self.actbAgent_fSize;
			c.align='center';
			replaceHTML(c,'\\/');
			if (actbAgent_self.actbAgent_mouse){
				c.style.cursor = 'pointer';
				c.onclick = actbAgent_mouse_down;
			}
		}
	}
	function actbAgent_goup(){
		if (!actbAgent_display) return;
		if (actbAgent_pos == 1) return;
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_bgColor;
		actbAgent_pos--;
		if (actbAgent_pos < actbAgent_rangeu) actbAgent_moveup();
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_hColor;
		if (actbAgent_toid) clearTimeout(actbAgent_toid);
		if (actbAgent_self.actbAgent_timeOut > 0) actbAgent_toid = setTimeout(function(){actbAgent_mouse_on_list=0;actbAgent_removedisp();},actbAgent_self.actbAgent_timeOut);
	}
	function actbAgent_godown(){
		if (!actbAgent_display) return;
		if (actbAgent_pos == actbAgent_total) return;
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_bgColor;
		actbAgent_pos++;
		if (actbAgent_pos > actbAgent_ranged) actbAgent_movedown();
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_hColor;
		if (actbAgent_toid) clearTimeout(actbAgent_toid);
		if (actbAgent_self.actbAgent_timeOut > 0) actbAgent_toid = setTimeout(function(){actbAgent_mouse_on_list=0;actbAgent_removedisp();},actbAgent_self.actbAgent_timeOut);
	}
	function actbAgent_movedown(){
		actbAgent_rangeu++;
		actbAgent_ranged++;
		actbAgent_remake();
	}
	function actbAgent_moveup(){
		actbAgent_rangeu--;
		actbAgent_ranged--;
		actbAgent_remake();
	}

	/* Mouse */
	function actbAgent_mouse_down(){
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_bgColor;
		actbAgent_pos++;
		actbAgent_movedown();
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_hColor;
		actbAgent_curr.focus();
		actbAgent_mouse_on_list = 0;
		if (actbAgent_toid) clearTimeout(actbAgent_toid);
		if (actbAgent_self.actbAgent_timeOut > 0) actbAgent_toid = setTimeout(function(){actbAgent_mouse_on_list=0;actbAgent_removedisp();},actbAgent_self.actbAgent_timeOut);
	}
	function actbAgent_mouse_up(evt){
		if (!evt) evt = event;
		if (evt.stopPropagation){
			evt.stopPropagation();
		}else{
			evt.cancelBubble = true;
		}
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_bgColor;
		actbAgent_pos--;
		actbAgent_moveup();
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_hColor;
		actbAgent_curr.focus();
		actbAgent_mouse_on_list = 0;
		if (actbAgent_toid) clearTimeout(actbAgent_toid);
		if (actbAgent_self.actbAgent_timeOut > 0) actbAgent_toid = setTimeout(function(){actbAgent_mouse_on_list=0;actbAgent_removedisp();},actbAgent_self.actbAgent_timeOut);
	}
	function actbAgent_mouseclick(evt){
		if (!evt) evt = event;
		if (!actbAgent_display) return;
		actbAgent_mouse_on_list = 0;
		actbAgent_pos = this.getAttribute('pos');
		actbAgent_penter();
	}
	function actbAgent_table_focus(){
		actbAgent_mouse_on_list = 1;
	}
	function actbAgent_table_unfocus(){
		actbAgent_mouse_on_list = 0;
		if (actbAgent_toid) clearTimeout(actbAgent_toid);
		if (actbAgent_self.actbAgent_timeOut > 0) actbAgent_toid = setTimeout(function(){actbAgent_mouse_on_list = 0;actbAgent_removedisp();},actbAgent_self.actbAgent_timeOut);
	}
	function actbAgent_table_highlight(){
		actbAgent_mouse_on_list = 1;
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_bgColor;
		actbAgent_pos = this.getAttribute('pos');
		while (actbAgent_pos < actbAgent_rangeu) actbAgent_moveup();
		while (actbAgent_pos > actbAgent_ranged) actbAgent_movedown();
		document.getElementById('tat_tr'+actbAgent_pos).style.backgroundColor = actbAgent_self.actbAgent_hColor;
		if (actbAgent_toid) clearTimeout(actbAgent_toid);
		if (actbAgent_self.actbAgent_timeOut > 0) actbAgent_toid = setTimeout(function(){actbAgent_mouse_on_list = 0;actbAgent_removedisp();},actbAgent_self.actbAgent_timeOut);
	}
	/* ---- */

	function actbAgent_insertword(a){
		if (actbAgent_self.actbAgent_delimiter.length > 0){
			str = '';
			l=0;
			for (i=0;i<actbAgent_delimwords.length;i++){
				if (actbAgent_cdelimword == i){
					prespace = postspace = '';
					gotbreak = false;
					for (j=0;j<actbAgent_delimwords[i].length;++j){
						if (actbAgent_delimwords[i].charAt(j) != ' '){
							gotbreak = true;
							break;
						}
						prespace += ' ';
					}
					for (j=actbAgent_delimwords[i].length-1;j>=0;--j){
						if (actbAgent_delimwords[i].charAt(j) != ' ') break;
						postspace += ' ';
					}
					str += prespace;
					str += a;
					l = str.length;
					if (gotbreak) str += postspace;
				}else{
					str += actbAgent_delimwords[i];
				}
				if (i != actbAgent_delimwords.length - 1){
					str += actbAgent_delimchar[i];
				}
			}
			actbAgent_curr.value = str;
			setCaret(actbAgent_curr,l);
		}else{
			actbAgent_curr.value = a;
		}
		actbAgent_mouse_on_list = 0;
		actbAgent_removedisp();
	}
	function actbAgent_penter(){
		if (!actbAgent_display) return;
		actbAgent_display = false;
		var word = '';
		var c = 0;
		for (var i=0;i<=actbAgent_self.actbAgent_keywords.length;i++){
			if (actbAgent_bool[i]) c++;
			if (c == actbAgent_pos){
				word = actbAgent_self.actbAgent_keywords[i];
				break;
			}
		}
		actbAgent_insertword(word);
		l = getCaretStart(actbAgent_curr);
	}
	function actbAgent_removedisp(){
		if (actbAgent_mouse_on_list==0){
			actbAgent_display = 0;
			if (document.getElementById('tat_table')){ document.body.removeChild(document.getElementById('tat_table')); }
			if (actbAgent_toid) clearTimeout(actbAgent_toid);
		}
	}
	function actbAgent_keypress(e){
		if (actbAgent_caretmove) stopEvent(e);
		return !actbAgent_caretmove;
	}
	function actbAgent_checkkey(evt){
		if (!evt) evt = event;
		a = evt.keyCode;
		caret_pos_start = getCaretStart(actbAgent_curr);
		actbAgent_caretmove = 0;
		switch (a){
			case 38:
				actbAgent_goup();
				actbAgent_caretmove = 1;
				return false;
				break;
			case 40:
				actbAgent_godown();
				actbAgent_caretmove = 1;
				return false;
				break;
			case 13: case 9:
				if (actbAgent_display){
					actbAgent_caretmove = 1;
					actbAgent_penter();
					return false;
				}else{
					return true;
				}
				break;
			default:
				setTimeout(function(){actbAgent_tocomplete(a)},50);
				break;
		}
	}

	function actbAgent_tocomplete(kc){
		if (kc == 38 || kc == 40 || kc == 13) return;
		var i;
		if (actbAgent_display){ 
			var word = 0;
			var c = 0;
			for (var i=0;i<=actbAgent_self.actbAgent_keywords.length;i++){
				if (actbAgent_bool[i]) c++;
				if (c == actbAgent_pos){
					word = i;
					break;
				}
			}
			actbAgent_pre = word;
		}else{ actbAgent_pre = -1};
		
		if (actbAgent_curr.value == ''){
			actbAgent_mouse_on_list = 0;
			actbAgent_removedisp();
			return;
		}
		if (actbAgent_self.actbAgent_delimiter.length > 0){
			caret_pos_start = getCaretStart(actbAgent_curr);
			caret_pos_end = getCaretEnd(actbAgent_curr);
			
			delim_split = '';
			for (i=0;i<actbAgent_self.actbAgent_delimiter.length;i++){
				delim_split += actbAgent_self.actbAgent_delimiter[i];
			}
			delim_split = delim_split.addslashes();
			delim_split_rx = new RegExp("(["+delim_split+"])");
			c = 0;
			actbAgent_delimwords = new Array();
			actbAgent_delimwords[0] = '';
			for (i=0,j=actbAgent_curr.value.length;i<actbAgent_curr.value.length;i++,j--){
				if (actbAgent_curr.value.substr(i,j).search(delim_split_rx) == 0){
					ma = actbAgent_curr.value.substr(i,j).match(delim_split_rx);
					actbAgent_delimchar[c] = ma[1];
					c++;
					actbAgent_delimwords[c] = '';
				}else{
					actbAgent_delimwords[c] += actbAgent_curr.value.charAt(i);
				}
			}

			var l = 0;
			actbAgent_cdelimword = -1;
			for (i=0;i<actbAgent_delimwords.length;i++){
				if (caret_pos_end >= l && caret_pos_end <= l + actbAgent_delimwords[i].length){
					actbAgent_cdelimword = i;
				}
				l+=actbAgent_delimwords[i].length + 1;
			}
			var ot = actbAgent_delimwords[actbAgent_cdelimword]; 
			var t = actbAgent_delimwords[actbAgent_cdelimword].addslashes();
		}else{
			var ot = actbAgent_curr.value;
			var t = actbAgent_curr.value.addslashes();
		}
		if (ot.length == 0){
			actbAgent_mouse_on_list = 0;
			actbAgent_removedisp();
		}
		if (ot.length < actbAgent_self.actbAgent_startcheck) return this;
		if (actbAgent_self.actbAgent_firstText){
			var re = new RegExp("^" + t, "i");
		}else{
			var re = new RegExp(t, "i");
		}

		actbAgent_total = 0;
		actbAgent_tomake = false;
		actbAgent_kwcount = 0;
		for (i=0;i<actbAgent_self.actbAgent_keywords.length;i++){
			actbAgent_bool[i] = false;
			if (re.test(actbAgent_self.actbAgent_keywords[i])){
				actbAgent_total++;
				actbAgent_bool[i] = true;
				actbAgent_kwcount++;
				if (actbAgent_pre == i) actbAgent_tomake = true;
			}
		}

		if (actbAgent_toid) clearTimeout(actbAgent_toid);
		if (actbAgent_self.actbAgent_timeOut > 0) actbAgent_toid = setTimeout(function(){actbAgent_mouse_on_list = 0;actbAgent_removedisp();},actbAgent_self.actbAgent_timeOut);
		actbAgent_generate();
	}
	return this;
}