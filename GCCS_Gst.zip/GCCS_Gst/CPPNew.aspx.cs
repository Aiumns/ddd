using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CPPNew : System.Web.UI.Page
{
    /// <summary>
    /// <createdBy>ALOK KUMAR SHARMA</createdBy>
    /// <date></date>
    /// </summary>
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlTransaction trans = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        if (!IsPostBack)
        {
            string Query = "select distinct agent_master.agent_name,agent_branch.agent_id from agent_master inner join agent_branch on agent_branch.agent_id=agent_master.agent_id inner join login_master on agent_branch.agent_branch_id=login_master.agent_id order by agent_master.agent_name";

            DataTable dt_agent = dw.GetAllFromQuery(Query);

            DropDownList1.Items.Add(new ListItem("--All Agents--", "0"));

            foreach (DataRow dr_agent in dt_agent.Rows)
            {
                DropDownList1.Items.Add(new ListItem(dr_agent["agent_name"].ToString(), dr_agent["agent_id"].ToString()));

            }
        }
    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        string query_part = "";

        if (DropDownList1.Items[0].Selected)
        {
            query_part = " ";

        }
        else
        {

            query_part = " and AM.agent_id=" + DropDownList1.SelectedValue.ToString();

        }

        string url = "CPPNew_View.aspx?query_part=" + query_part + "";
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");

    }
}
