using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CppRedem : System.Web.UI.Page
{ // --- Declare Public Variables here ---
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con;
    SqlCommand com;
    string Table = "";
    string FinalTable = "";
    /// <summary>
    /// Make Connection From Web.config
    /// </summary>
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
           
            htmlTableSimple();
        }

    }
    public void htmlTableSimple()
    {
       
        string from_date = Request.QueryString["fromdate"];
        string to_date = Request.QueryString["todate"];
        //string city_Name = Request.QueryString["cityname"];
        //string city_Id = Request.QueryString["cityid"];
        string airline_name ="";
        string airline_code = "";
        string airline_detail_id ="";
        string City_Id = "";
        string AirlineCity = Request.QueryString["a"];
        if (Request.QueryString["a"] != "--All--")
        {
            airline_name = Request.QueryString["airline_name"];
            airline_code = Request.QueryString["airline_code"];
            airline_detail_id = Request.QueryString["airline_detail_id"];

            string[] CityId = Request.QueryString["a"].Split('/');
            City_Id = CityId[1].ToString();
            DataTable dt = dw.GetAllFromQuery("select city_Id from city_master where city_name='" + City_Id.ToString().Trim() + "'");
            if (dt.Rows.Count > 0)
            {
                City_Id = dt.Rows[0]["city_Id"].ToString();
            }
        }
        else
        {
            AirlineCity = "All Airline City";
        }
        try
        {
            int Sno = 0;

            int ip = 0;
            con = new SqlConnection(strCon);
            con.Open();

            decimal Total_Redeem_cpp = 0;
            decimal GrandTotal_RedeemCpp = 0;
            decimal GrandTotalForAllCity_RedeemCpp = 0;
            DataTable dt1=null;
            if (Request.QueryString["a"] == "--All--")
            {
                DataTable dtCityid = dw.GetAllFromQuery("Select Distinct city_id,City_Name from city_master");
                if (dtCityid.Rows.Count > 0)
                {
                    for (int k = 0; k < dtCityid.Rows.Count; k++)
                    {
                       

                        dt1 = dw.GetAllFromQuery("SELECT am.Agent_Name,rd.Redeemed_CPP,rd.gift_send_to,rd.gift_send_to_phone_no,rd.remarks,status FROM redeem_cppNew rd INNER JOIN agent_master am ON rd.agent_id=am.agent_id inner join city_master cm on rd.city_id=cm.city_id WHERE CONVERT(VARCHAR,rd.entered_on,103)>='" + FormatDateMM(from_date.Trim()) + "' AND CONVERT(VARCHAR,rd.entered_on,103)<='" + FormatDateMM(to_date.Trim()) + "' and cm.city_id ="+ dtCityid.Rows[k]["city_id"].ToString()+" order by am.agent_name");


                        string old_agent_name = "";
                        if (dt1.Rows.Count > 0)
                        {
                            Table += @"<h5><p align=center>Reddem cpp Report for " + dtCityid.Rows[k]["city_Name"].ToString() + " <br>" + FormatDateMM(Request.QueryString["fromdate"]) + " - " + FormatDateMM(Request.QueryString["todate"]) + "</p></h5>";
                            Table += @"<Table align=center width=80% border=1 cellspacing=0>";

                            Table += @"<tr class=h1 align=left><th>Agent Name</th><th nowrap>Redeemed CPP</th><th>Gift send to</th><th>MobNo</th><th>Remarks</th><th>Status</th></tr>";


                            string agent_name = "";
                            for (int i = 0; i < dt1.Rows.Count; i++)
                            {


                                old_agent_name = dt1.Rows[i]["agent_name"].ToString();
                                if (agent_name != old_agent_name)
                                {
                                    if (i != 0)
                                    {
                                        Table += @"<tr class=h1><td align=left class=text nowrap=true  colspan=1>Total</td><td align=right class=text nowrap=true >" + Total_Redeem_cpp + @"</td><td colspan=4>&nbsp;</td></tr>";
                                    }

                                    Total_Redeem_cpp = 0;
                                    Table += @"<tr><td align=left class=text nowrap=true >" + dt1.Rows[i]["Agent_Name"].ToString() + @"</td><td align=right class=text nowrap=true>" + dt1.Rows[i]["Redeemed_CPP"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to_phone_no"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["remarks"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["status"].ToString() + @"</td></tr>";
                                    agent_name = dt1.Rows[i]["agent_name"].ToString();
                                    Total_Redeem_cpp = Total_Redeem_cpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());

                                    ip++;
                                    GrandTotal_RedeemCpp = GrandTotal_RedeemCpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());
                                    //GrandTotalForAllCity_RedeemCpp += GrandTotal_RedeemCpp;
                                }
                                else
                                {
                                    Table += @"<tr><td align=left class=text nowrap=true  colspan=1></td><td align=right class=text nowrap=true >" + dt1.Rows[i]["Redeemed_CPP"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to_phone_no"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["remarks"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["status"].ToString() + @"</td></tr>";

                                    agent_name = dt1.Rows[i]["agent_name"].ToString();
                                    Total_Redeem_cpp = Total_Redeem_cpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());
                                    GrandTotal_RedeemCpp = GrandTotal_RedeemCpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());

                                    //GrandTotalForAllCity_RedeemCpp += GrandTotal_RedeemCpp;
                                }

                            }
                            Table += @"<tr class=h1><td align=left class=text nowrap=true  colspan=1>Total</td><td align=right class=text nowrap=true >" + Total_Redeem_cpp + @"</td><td colspan=4>&nbsp;</td></tr>";

                            //GrandTotal_RedeemCpp = GrandTotal_RedeemCpp + Total_Redeem_cpp;
                           
                            GrandTotalForAllCity_RedeemCpp += GrandTotal_RedeemCpp;

                            Table += @"<tr class=h1><td align=left class=text nowrap=true  colspan=1>Grand Total</td><td align=right class=text nowrap=true >" + GrandTotal_RedeemCpp + @"</td><td colspan=4>&nbsp;</td></tr>";

                            Table += "</Table>";
                            FinalTable += Table;
                            GrandTotal_RedeemCpp = 0;
                            Table = "";
                        }
                    }
                }
                FinalTable +="<br/><Table align=center width=50% border=1 cellspacing=0><tr class=h1 align=left><td>OverAll Total</td><td nowrap>" + GrandTotalForAllCity_RedeemCpp + "</td></tr></Table>"; ;
                Label1.Text = FinalTable; 

            }
            else if (Request.QueryString["a"] != "--All--")
            {
                Table += @"<h5><p align=center>Reddem cpp Report for " + AirlineCity + " <br>" + FormatDateMM(Request.QueryString["fromdate"]) + " - " + FormatDateMM(Request.QueryString["todate"]) + "</p></h5>";
                Table += @"<Table align=center width=80% border=1 cellspacing=0>";
                
                dt1 = dw.GetAllFromQuery("SELECT am.Agent_Name,rd.Redeemed_CPP,rd.gift_send_to,rd.gift_send_to_phone_no,rd.remarks,status FROM redeem_cppNew rd INNER JOIN agent_master am ON rd.agent_id=am.agent_id inner join city_master cm on rd.city_id=cm.city_id WHERE CONVERT(VARCHAR,rd.entered_on,103)>='" + FormatDateMM(from_date.Trim()) + "' AND CONVERT(VARCHAR,rd.entered_on,103)<='" + FormatDateMM(to_date.Trim()) + "' and cm.city_id=" + City_Id + " AND am.agent_id IN (SELECT agent_id FROM sales WHERE Airline_detail_id=" + Request.QueryString["airline_detail_id"] + " AND csr_date >='" + FormatDateMM(from_date) + "' AND csr_date <='" + FormatDateMM(to_date) + "') order by am.agent_name");
            //}

         
            string old_agent_name = "";
            if (dt1.Rows.Count > 0)
            {
                Table += @"<tr class=h1 align=left><th>Agent Name</th><th nowrap>Redeemed CPP</th><th>Gift send to</th><th>MobNo</th><th>Remarks</th><th>Status</th></tr>";
               
               
                string agent_name = "";
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                   
                   
                    old_agent_name = dt1.Rows[i]["agent_name"].ToString();
                    if (agent_name != old_agent_name)
                    {
                        if (i != 0)
                        {
                            Table += @"<tr class=h1><td align=left class=text nowrap=true  colspan=1>Total</td><td align=right class=text nowrap=true >" + Total_Redeem_cpp + @"</td><td colspan=4>&nbsp;</td></tr>";
                        }
                        
                        Total_Redeem_cpp = 0;
                        Table += @"<tr><td align=left class=text nowrap=true >" + dt1.Rows[i]["Agent_Name"].ToString() + @"</td><td align=right class=text nowrap=true>" + dt1.Rows[i]["Redeemed_CPP"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to_phone_no"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["remarks"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["status"].ToString() + @"</td></tr>";
                            agent_name = dt1.Rows[i]["agent_name"].ToString();
                            Total_Redeem_cpp = Total_Redeem_cpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());

                            ip++;
                            GrandTotal_RedeemCpp = GrandTotal_RedeemCpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());
                    }
                    else
                    {
                        Table += @"<tr><td align=left class=text nowrap=true  colspan=1></td><td align=right class=text nowrap=true >" + dt1.Rows[i]["Redeemed_CPP"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["gift_send_to_phone_no"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["remarks"].ToString() + @"</td><td align=left class=text nowrap=true>" + dt1.Rows[i]["status"].ToString() + @"</td></tr>";

                        agent_name = dt1.Rows[i]["agent_name"].ToString();
                        Total_Redeem_cpp = Total_Redeem_cpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());
                        GrandTotal_RedeemCpp = GrandTotal_RedeemCpp + decimal.Parse(dt1.Rows[i]["Redeemed_CPP"].ToString());
                    }
                    
                }
                Table += @"<tr class=h1><td align=left class=text nowrap=true  colspan=1>Total</td><td align=right class=text nowrap=true >" + Total_Redeem_cpp + @"</td><td colspan=4>&nbsp;</td></tr>";

                //GrandTotal_RedeemCpp = GrandTotal_RedeemCpp + Total_Redeem_cpp;

                Table += @"<tr class=h1><td align=left class=text nowrap=true  colspan=1>Grand Total</td><td align=right class=text nowrap=true >" + GrandTotal_RedeemCpp + @"</td><td colspan=4>&nbsp;</td></tr>";

                Label1.Text = Table + "</Table>";
            }
            else
            {
                Table += @"<Table align=center width=80% border=1><tr>&nbsp;<center><span class=error><b>No Record Found</b></span></center></tr></Table>";
                Label1.Text = Table;
            }
            }

            //else
            //{
            //    Table += @"<Table align=center width=80% border=1><tr>&nbsp;<center><span class=error><b>No Record Found</b></span></center></tr></Table>";
            //    Label1.Text = Table;
            //}

        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
