using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
// ******************************************************
//          Created BY      :       Rajesh Parbat
//          Date            :       17/11/2007
//Modified by Rakhi on 3 Dec 2007
//*******************************************************
/// </summary>
public partial class _Default : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    int AID = 0;
    DataSet ds = null;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        //Button3.Attributes.Add("onclick", "return Validation();");// Calling javascript function;
        Button3.Attributes.Add("onclick","return Validation()");
        Button3.Attributes.Add("onclick", "return CheckEmpty()");
        Label1.Visible = false;
        

        if (!IsPostBack)
        {
            UserAirlineNamePlusCode();
            //ddlAiline();
            ////ddlCity();
            //ddlCity();
        }
       
    }
    //************************************************
    // Function to vonvert date in mm/dd/yy formate
    //************************************************
    protected string ConvertDate1(string strD)
    {
        string[] Sdate = strD.Split('/');
        return Sdate[1] + "/" + Sdate[0] + "/" + Sdate[2];
    }
    //************************************************
    // Function to Fill GridView
    //************************************************
    void fillgrid()
    {
        string strQ = null;
        if (ddlAirlineName.SelectedIndex == 0)
        {
            Label1.Visible = true;
            Label1.Text = "Please Select Airline Name ";
        }
        else
        {
            string AirlineDetail_id = (ddlAirlineName.SelectedValue);
            string[] Arr_Id = AirlineDetail_id.Split('-');
            string A_id = Arr_Id[0];
            string city_id = Arr_Id[1];

            int x=int.Parse(A_id);
            string _count;
            string sss = AirCode(x);// to find AirlineCode
            //string FromDate = txtFromDate.Text;
            //DateTime ToDate = DateTime.Parse(txtToDate.Text);
            //string frmdate = ConvertDate(FromDate);
            string _From = txtFromDate.Text;
            string _To = txtToDate.Text;
           
            string awbno = txtAwbno.Text.Trim();
            
            if (_From == "" && _To == "")
            {
                con = new SqlConnection(strCon);
                if (awbno == "")
                {
                    strQ = "select AirWayBill_No,convert(varchar,Receipt_Date,103) as Receipt_Date ,Receipt_LotNo from Stock_Master where substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "' ";

                    _count = "select count(distinct(AirWayBill_No)) as Total from Stock_Master where  substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "' ";
                    con.Open();
                    com = new SqlCommand(_count, con);
                    SqlDataReader dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        lblTotal.Text = dr["Total"].ToString();
                    }
                    else
                    {
                        lblTotal.Text = "0";
                    }
                    com.Dispose();
                    dr.Close();
                    con.Close();
                }
                else
                {
                    strQ = "select AirWayBill_No,convert(varchar,Receipt_Date,103) as Receipt_Date ,Receipt_LotNo from Stock_Master where  substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "' and AirWayBill_No like '%" + awbno + "%'";
                    _count = "select count(distinct(AirWayBill_No)) as Total from Stock_Master where  substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "'  and AirWayBill_No like '%" + awbno + "%'";

                    con.Open();
                    com = new SqlCommand(_count, con);
                    SqlDataReader dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        lblTotal.Text = dr["Total"].ToString();
                    }
                    else
                    {
                        lblTotal.Text = "0";
                    }
                    com.Dispose();
                    dr.Close();
                    con.Close();
                }
                //       select AirWayBill_No,convert(varchar,Receipt_Date,103) as Receipt_Date ,Receipt_LotNo from Stock_Master where Receipt_Date between '12/4/2007 12:00:00 AM' and '12/4/2007 12:00:00 AM' and substring(AirWayBill_No,0,4)='058' and (Status=8 or Status=17) and City_ID='18'
                ds = new DataSet();
                com = new SqlCommand(strQ, con);
                SqlDataAdapter da = new SqlDataAdapter(com);
                con.Open();
                da.Fill(ds);
                GridView1.DataSource = ds;
                GridView1.DataBind();

                com.Dispose();
                con.Close();
            }
            else
            {
                
                DateTime dt1 = DateTime.Parse(ConvertDate1(txtFromDate.Text));
                
                DateTime  dt2 = DateTime.Parse(ConvertDate1(txtToDate.Text));
              
                if (dt1 <= dt2)
                {
                    con = new SqlConnection(strCon);
                    if (awbno == "")
                    {
                        strQ = "select AirWayBill_No,convert(varchar,Receipt_Date,103) as Receipt_Date ,Receipt_LotNo from Stock_Master where (Receipt_Date >='" + dt1 + "' and Receipt_Date<='" + dt2 + "' and substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "') ";

                        _count = "select count(distinct(AirWayBill_No)) as Total from Stock_Master where (Receipt_Date >='" + dt1 + "' and Receipt_Date<='" + dt2 + "' and substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "') ";
                        con.Open();
                        com = new SqlCommand(_count, con);
                        SqlDataReader dr = com.ExecuteReader();
                        if (dr.Read())
                        {
                            lblTotal.Text = dr["Total"].ToString();
                        }
                        else
                        {
                            lblTotal.Text = "0";
                        }
                        com.Dispose();
                        dr.Close();
                        con.Close();
                    }
                    else
                    {
                        strQ = "select AirWayBill_No,convert(varchar,Receipt_Date,103) as Receipt_Date ,Receipt_LotNo from Stock_Master where (Receipt_Date >='" + dt1 + "' and Receipt_Date<='" + dt2 + "' and substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "') and AirWayBill_No like '%" + awbno + "%'";
                        _count = "select count(distinct(AirWayBill_No)) as Total from Stock_Master where (Receipt_Date >='" + dt1 + "' and Receipt_Date<='" + dt2 + "' and substring(AirWayBill_No,0,4)='" + sss + "' and (Status=8 or Status=17) and City_ID='" + city_id + "')  and AirWayBill_No like '%" + awbno + "%'";

                        con.Open();
                        com = new SqlCommand(_count, con);
                        SqlDataReader dr = com.ExecuteReader();
                        if (dr.Read())
                        {
                            lblTotal.Text = dr["Total"].ToString();
                        }
                        else
                        {
                            lblTotal.Text = "0";
                        }
                        com.Dispose();
                        dr.Close();
                        con.Close();
                    }
                    //       select AirWayBill_No,convert(varchar,Receipt_Date,103) as Receipt_Date ,Receipt_LotNo from Stock_Master where Receipt_Date between '12/4/2007 12:00:00 AM' and '12/4/2007 12:00:00 AM' and substring(AirWayBill_No,0,4)='058' and (Status=8 or Status=17) and City_ID='18'
                    ds = new DataSet();
                    com = new SqlCommand(strQ, con);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    con.Open();
                    da.Fill(ds);
                    GridView1.DataSource = ds;
                    GridView1.DataBind();

                    com.Dispose();
                    con.Close();


                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "From Date'" + dt1 + "' Should Be Less Than or Equal To '" + dt2 + "' To Date";
                }
            }
        } 
    }
    //************************************************
    // Function to find Airlinecode
    //************************************************
    string AirCode(int d)
    {
        string x = null; ;
        con = new SqlConnection(strCon);
        string str="select Airline_Code from Airline_master where Airline_ID='"+d+"'";
        com=new SqlCommand(str,con);
        con.Open();
        SqlDataReader dr=com.ExecuteReader();
        if(dr.Read())
        {
         x = dr["Airline_Code"].ToString();
        }
        return x;
    
    }
    protected string ConvertDate(string strD)
    {
        string[] Sdate = strD.Split('/');
        if (Sdate[0].Substring(0, 1) == "0")
            Sdate[0] = Sdate[0].Substring(1, 1);
        else
        { Sdate[0] = Sdate[0]; }

        return Sdate[0];
    }
    //************************************************
    // Function to fill Dropdown for Airline Name
    //************************************************
    //UPDATED BY MEGHA[30 JAN 2008]
    #region Display Airline/City in  ADD Case
    public void UserAirlineNamePlusCode()
    {
        try
        {
            string strQuery = "";
            string Airline_Access = Session["AIRLINEACCESS"].ToString();
            ddlAirlineName.Items.Clear();

            strQuery = "select  a.Airline_ID,a.Airline_Name,b.Airline_Detail_ID,c.City_Name,b.Belongs_To_City  from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City  where b.Airline_Detail_ID in" + "(" + Airline_Access + ") order by  a.Airline_Name";

            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com = new SqlCommand(strQuery, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirlineName.Items.Insert(0, "Select Airline");
            ddlAirlineName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlAirlineName.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_ID"].ToString() + "-" + dr["Belongs_To_City"].ToString()));

            }
            con.Close();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    
    #endregion 


    //void ddlAiline()
    //{
    //    try
    //    {
    //        string strQuery = "select Airline_ID,Airline_Name from Airline_Master Where Status=2 ";
    //        con = new SqlConnection(strCon);
    //        com = new SqlCommand(strQuery,con);
    //        con.Open();
    //        SqlDataReader dr = com.ExecuteReader();
    //        //ddlAirlineName.Items.Insert(0,"y");
    //        ddlAirlineName.Items.Add(new ListItem("--Select--", "y"));
    //        while (dr.Read())
    //        {
    //            ddlAirlineName.Items.Add(new ListItem(dr["Airline_Name"].ToString(),dr["Airline_ID"].ToString()));
    //            AID = int.Parse(dr["Airline_ID"].ToString());
    //        }
    //        dr.Close();
    //        con.Close();
    //        com.Dispose();
    //    }
    //    catch(SqlException sqe)
    //    {
    //        string err = sqe.ToString();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }

    //}
    ////************************************************
    //// Function to Fill Dropdown for City
    ////************************************************
    //void ddlCity()
    //{
    //    ddlCityName.Items.Clear();
    //    try
    //    {
    //        if (ddlAirlineName.SelectedValue.Equals("y"))
    //        {
    //            ddlCityName.Enabled = false;
    //        }
    //        else
    //        {
    //            ddlCityName.Enabled=true;
    //            string strQuery = "SELECT dbo.City_Master.City_Name,dbo.City_Master.City_ID FROM dbo.Airline_Detail INNER JOIN dbo.City_Master ON dbo.Airline_Detail.Belongs_To_City = dbo.City_Master.City_ID WHERE dbo.Airline_Detail.Airline_ID ='" + ddlAirlineName.SelectedValue + "' and dbo.Airline_Detail.Status=2";
    //            con = new SqlConnection(strCon);
    //            com = new SqlCommand(strQuery, con);
    //            con.Open();
    //            SqlDataReader dr = com.ExecuteReader();
    //            //ddlCityName.Items.Clear();


    //            while (dr.Read())
    //            {
    //                ddlCityName.Items.Add(new ListItem(dr["City_Name"].ToString(), dr["City_ID"].ToString()));
    //            }
    //            dr.Close();
    //            con.Close();
    //            com.Dispose();
    //        }
    //    }
    //    catch (SqlException sqe)
    //    {
    //        string err = sqe.ToString();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }

    //}
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            Label5.Visible = true;
            GridView1.Visible = true;
            fillgrid();
        }
       
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        //GridView1.PageIndex = e.NewPageIndex;
        //fillgrid();
    }
    protected void ddlAirlineName_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        //ddlCity();
        //GridView1.Visible = false;
        //ds.Tables.Clear();
    }
}
