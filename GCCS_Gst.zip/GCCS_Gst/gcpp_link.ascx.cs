using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class gcpp_link : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ////if (Session["groupid"].ToString() == "1" )
        ////{
        ////   HyperLink1.Visible = true;
        ////}
        ////if (Session["groupid"].ToString() == "45")
        ////{
        ////    HyperLink1.Visible = true;

        ////}
        if (Session["groupid"].ToString() == "1")
        {
            pnl_cont.Visible = true;
        }
        if (Session["groupid"].ToString() == "45")
        {
            pnl_cont.Visible = true;

        }
       

    }
}
