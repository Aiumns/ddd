using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CPP_Accounts : System.Web.UI.Page
{
 
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataAdapter da = null;
    DataTable dt = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    string startDate = "";
    string endDate = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        if (!IsPostBack)
        {
            BindCity();
            int dt = System.DateTime.Now.Month;
            if (dt == 1)
                dt = 1;
            ddlFromMonth.Items[dt].Selected = true;
            ddlToMonth.Items[dt].Selected = true;
            ddlFromYear.Items.Clear();
            ddlToYear.Items.Clear();
            for (int year = 2006; year <= DateTime.Today.Year; year++)
            {
                ddlFromYear.Items.Add(new ListItem(year.ToString(), year.ToString()));
                ddlToYear.Items.Add(new ListItem(year.ToString(), year.ToString()));
            }
            ddlFromYear.SelectedValue = DateTime.Today.Year.ToString();
            ddlToYear.SelectedValue = DateTime.Today.Year.ToString();


        }

    }
    protected void BindCity()
    {
        ddlCity.Items.Clear();
        con = new SqlConnection(strCon);
        try
        {
            con.Open();
            string search = "select * from city_master";
            cmd = new SqlCommand(search, con);
            SqlDataReader dr = cmd.ExecuteReader();
            ddlCity.Items.Add(new ListItem("--All City--", "0"));
            ddlCity.Items[0].Value = "";
            while (dr.Read())
            {
                ddlCity.Items.Add(new ListItem(dr["City_name"].ToString() + "(" + dr["City_code"].ToString() + ")", dr["City_ID"].ToString()));
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        startDate = ddlFromMonth.SelectedValue + "/" + "01" + "/" + ddlFromYear.SelectedValue;

        endDate = ddlToMonth.SelectedValue + "/" + (Convert.ToDateTime(ddlToMonth.SelectedValue + "/1/" + ddlToYear.SelectedValue).AddMonths(1).AddDays(-1).Day.ToString()) + "/" + ddlToYear.SelectedValue;
        string query_part = "";

        if (ddlCity.Items[0].Selected)
        {
            query_part = " ";

        }
        else
        {

            query_part = ddlCity.SelectedValue.ToString();

        }
        Session["startDate"] = startDate.ToString();
        Session["endDate"] = endDate.ToString();
        string url = "CPPAccounts_View.aspx?query_part=" + query_part + "";
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/" + url + "');</script>");

    }

}
