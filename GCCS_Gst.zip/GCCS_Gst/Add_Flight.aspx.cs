using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Designed by praveen singh
/// this form coded by praveen singh
/// </summary>
///

public partial class Add_Flight : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;

    SqlCommand cmd;
    DisplayWrap dw = new DisplayWrap();
    SqlDataReader red;
    SqlParameter pram;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    public string strLen = "";
    public string strLen1 = "";  
    string loginid;
    string TodayDate;
    string destID;
    string originID;
    string strUpdate;
    string flightID;
    string fltno;  
    protected void Page_Load(object sender, EventArgs e)
    {
        lbltest.Text = "";
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            strLen = "<script>var FillDest =new Array(" + Dest() + ")</script>";
            strLen1 = "<script>var FillCity =new Array(" + City() + ")</script>";      
            if (!IsPostBack && Request.QueryString["Flight_ID"] == null)
            {
                btnadd.Attributes.Add("onclick", "return CheckEmpty();");
                btnadd.Visible = true;
                lblpagename.Text = "Add Flight";
                btnupdate.Visible = false;
                FillAirline();
                ddlAirlineName.Enabled = true;
                FillStatus();
                TodayDate = DateTime.Now.ToShortDateString();
                loginid = Session["EMailID"].ToString();
            }
            else if (!IsPostBack && Request.QueryString["Flight_ID"] != null)
            {
                if (!IsPostBack)
                {
                    btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                    btnadd.Visible = false;
                    btnupdate.Visible = true;
                    lblpagename.Text = "Update Flight Details";
                    FillAirline();
                    ddlAirlineName.Enabled = false;
                    FillStatus();
                    search();
                    TodayDate = DateTime.Now.ToShortDateString();
                    loginid = Session["EMailID"].ToString();
                }
            }
        }    
    }
    public void FillAirline()
    {
        string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select A.Airline_Name+'-'+B.City_Name as Airline ,C.Airline_Detail_ID from Airline_Master A,City_Master B,Airline_Detail C where A.Airline_ID=C.Airline_ID and B.City_ID=C.Belongs_To_City and Airline_Detail_ID in("+Airline_Access+") order by Airline_Name", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlAirlineName.DataSource = red;
         ddlAirlineName.DataTextField = "Airline";
         ddlAirlineName.DataValueField = "Airline_Detail_ID";
        ddlAirlineName.DataBind();
        con.Close();
        cmd.Dispose();
        ddlAirlineName.Items.Insert(0, new ListItem("Select Airline", "-1"));
    }
    public string Rights()
    {

        string sql_Access = "select Airline_Access from Login_Master where Email_ID='" + Session["EMailID"].ToString() + "'";


        con = new SqlConnection(strCon);
        con.Open();
        string Access = "";
        SqlCommand cmd = new SqlCommand(sql_Access, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                Access = dr.GetValue(0).ToString();
            }

        }
        return Access;
    }
    public void FillStatus()
    {

        con = new SqlConnection(strCon);
        SqlCommand com = new SqlCommand("select * from Status_Master where Status_Name in ('Active','Inactive')", con);
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        //ddlststus.Items.Add("Select Status");
        //ddlststus.Items[0].Value = "";
        while (dr.Read())
        {
            ddlststus.Items.Add(new ListItem(dr["Status_Name"].ToString(), dr["Status_ID"].ToString()));
        }
        con.Close();

    }

    public string City()
    {
        string strTemp1 = "";
        con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT * FROM City_Master";
            cmd = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp1 == "")
                    strTemp1 = "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
                else
                    strTemp1 = strTemp1 + "," + "'" + Convert.ToString(dr["City_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["City_Name"]).ToString().ToUpper().Trim() + "'";
            }
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp1;
    }

    public string Dest()
    {
        string strTemp = "";
        con = new SqlConnection(strCon);
        try
        {
            string selectGroupName = "SELECT * FROM Destination_Master";
            cmd = new SqlCommand(selectGroupName, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp == "")

                    strTemp = "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";
                else

                    strTemp = strTemp + "," + "'" + Convert.ToString(dr["Destination_Code"]).ToString().ToUpper().Trim() + "-" + Convert.ToString(dr["Destination_Name"]).ToString().ToUpper().Trim() + "'";
            }
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp;
    }
    
    void reset()
    {
        txtorigin.Text = "";
        txtFlightNo.Text = "";
        txtDestination.Text = "";
        txtcapacity.Text = "";
        ddlAirlineName.SelectedIndex = -1;
        ddlFlightType.SelectedIndex = 0;
        ddlststus.SelectedIndex = 0;
    }

    protected void ddlAirlineName_SelectedIndexChanged(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        if (ddlAirlineName.SelectedIndex <= 0)
        {
           txtFlightNo.Text = "";
           Label1.Visible = false;
           lblError.Visible = true;
           lblError.Text = "Please Select Airline Name";
           ddlAirlineName.Focus();
           
        }
        else
        {
         txtFlightNo.Text = "";
         lblError.Visible = false;
         string[] strAwb = ddlAirlineName.SelectedItem.Text.Split('-');
        //int AW = strAwb.IndexOf("-");
        //string strAwb1 = strAwb.Substring(0, AW);
        string str11 = "select Airline_Text_Code from Airline_Master where Airline_Name='" + strAwb[0] + "'";
        SqlCommand com = new SqlCommand(str11, con);
        SqlDataReader dr11 = com.ExecuteReader();
        dr11.Read();
        string ATC = dr11["Airline_Text_Code"].ToString();
        Label1.Visible = true;
        Label1.Text = ATC+"-";
        }
        con.Close();
    }
    public void flightCode()
    {
        con = new SqlConnection(strCon);
        con.Open();
        try//try block add by hn mishra
        {
            string[] strAwb = ddlAirlineName.SelectedItem.Text.Split('-');
            //int AW = strAwb.IndexOf("-");
            //string strAwb1 = strAwb.Substring(0, AW);
            string str11 = "select Airline_Text_Code from Airline_Master where Airline_Name='" + strAwb[0] + "'";
            SqlCommand com = new SqlCommand(str11, con);
            SqlDataReader dr11 = com.ExecuteReader();
            dr11.Read();
            string ATC = dr11["Airline_Text_Code"].ToString();
            Label1.Visible = true;
            Label1.Text = ATC + "-";
            //add by hn mishra.
            com.Dispose();
            con.Close();
        }
        catch(SqlException se)
        {
            string err = se.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }

    }
    public void search()
    {
        int idfl;
        idfl = Int32.Parse(Request.QueryString["Flight_ID"].ToString());
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand("Flight_Select", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Flight_ID", idfl);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                string aaa = dr["Flight_Type"].ToString();
                ddlAirlineName.Text = dr["Airline_Detail_ID"].ToString();
                txtFlightNo.Text = dr["Flight_No"].ToString().Substring(3,dr["Flight_No"].ToString().Length-3);
                lblFlightNo.Text = dr["Flight_No"].ToString().Substring(3, dr["Flight_No"].ToString().Length - 3);
                ddlFlightType.Text = dr["Flight_Type"].ToString();
                txtDestination.Text = dr["Destination"].ToString();
                txtorigin.Text = dr["Origin"].ToString();
                txtcapacity.Text = dr["Capacity"].ToString();
                ddlststus.Text = dr["Status"].ToString();
                ddlFlightType.SelectedIndex = ddlFlightType.Items.IndexOf(ddlFlightType.Items.FindByText(aaa));
                Label1.Visible = true;
                flightCode();
                //Label1.Text = dr["Flight_No"].ToString().Substring(0, dr["Flight_No"].ToString().Length - 1);
            }
        }

        con.Close();
        cmd.Dispose();
    }

    public void Add()
     {
        string insert1;

         con = new SqlConnection(strCon);
        try
        {
            con.Open();         
            string str1 = "";
            str1 = "select * from Flight_Master where Flight_No='" + Label1.Text+txtFlightNo.Text + "'";
            da = new SqlDataAdapter(str1, con);
            ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblError.Text = "Flight Number " + Label1.Text + txtFlightNo.Text + " Already Exists.";
                lblError.Visible = false;
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + lblError.Text + "');</script>");
            }
            else
            {
                 string[] strDestination = txtDestination.Text.Trim().Split('-');
                 //strDestination = strDestination.Substring(0, 3);
                 DataTable dtDestination = dw.GetAllFromQuery("select Destination_ID from Destination_Master where Destination_Code='" + strDestination[0] + "'");
                if (dtDestination.Rows.Count > 0)
                {
                    destID = dtDestination.Rows[0]["Destination_ID"].ToString();
                }

                string[] strOrigin = txtorigin.Text.Trim().Split('-');
                //strOrigin = strOrigin.Substring(0, 3);
                DataTable dtOrigin = dw.GetAllFromQuery("select City_ID from city_Master where City_Code='" + strOrigin[0] + "'");
                if (dtDestination.Rows.Count > 0)
                {
                    originID = dtOrigin.Rows[0]["City_ID"].ToString();
                }
                con.Open(); 
                string[] strAwb = ddlAirlineName.SelectedItem.Text.Split('-');
                //int AW = strAwb.IndexOf("-");
                //string strAwb1 = strAwb.Substring(0, AW);
                string str11 = "select Airline_Text_Code from Airline_Master where Airline_Name='" + strAwb[0] + "'";
                 SqlCommand com = new SqlCommand(str11, con);
                 SqlDataReader dr11 = com.ExecuteReader();
                 dr11.Read();
                 string ATC = dr11["Airline_Text_Code"].ToString();
                 txtFlightNo.Text = ATC + '-' + txtFlightNo.Text;
                 con.Close();
                 con.Open();
                string enterBy = Session["EMailID"].ToString();
                //TodayDate = DateTime.Now;
                //con = new SqlConnection(strCon);
                string str = "";
                str = "insert into Flight_Master(Airline_Detail_ID,Flight_No,Flight_Type,Destination,Origin,Capacity,Status,Entered_By,Entered_On) values('" + ddlAirlineName.SelectedValue + "','" + txtFlightNo.Text+"','" + ddlFlightType.SelectedItem.Text + "','" + destID + "','" + originID + "','" + txtcapacity.Text + "','" + ddlststus.SelectedValue + "','" + enterBy + "','" + DateTime.Now + "')";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Redirect("ShowAddFlight.aspx");
                
            }
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            //Response.Write(er);
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }      

    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        Add();
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowAddFlight.aspx");
    }

    public void Update()
    {
        //string insert1;
        
        con = new SqlConnection(strCon);
        try
        {
            flightID = Request.QueryString["Flight_ID"].ToString();
            string a = txtorigin.Text;

            string oldFNo = lblFlightNo.Text;
            string newFno = txtFlightNo.Text;
            string enterBy = Session["EMailID"].ToString();
            //TodayDate = DateTime.Now;
            if (String.Compare(oldFNo, newFno) == 0)
            {
                string[] strDestination = txtDestination.Text.Trim().Split('-');
                //strDestination = strDestination.Substring(0, 3);
                DataTable dtDestination = dw.GetAllFromQuery("select Destination_ID from Destination_Master where Destination_Code='" + strDestination[0] + "'");
                if (dtDestination.Rows.Count > 0)
                {
                    destID = dtDestination.Rows[0]["Destination_ID"].ToString();
                }

                string[] strOrigin = txtorigin.Text.Trim().Split('-');
                //strOrigin = strOrigin.Substring(0, 3);
                DataTable dtOrigin = dw.GetAllFromQuery("select City_ID from city_Master where City_Code='" + strOrigin[0] + "'");
                if (dtOrigin.Rows.Count > 0)
                {
                    originID = dtOrigin.Rows[0]["City_ID"].ToString();
                }
                con.Open();
                string[] strAwb = ddlAirlineName.SelectedItem.Text.Split('-');
                //int AW = strAwb.IndexOf("-");
                //string strAwb1 = strAwb.Substring(0, AW);
                string str11 = "select Airline_Text_Code from Airline_Master where Airline_Name='" + strAwb[0] + "'";
                SqlCommand com = new SqlCommand(str11, con);
                SqlDataReader red1 = com.ExecuteReader();
                red1.Read();
           
                string ATC = red1["Airline_Text_Code"].ToString();
                txtFlightNo.Text = ATC + '-' + txtFlightNo.Text;
                con.Close();
                con.Open();
                string st = ddlststus.SelectedValue;
                strUpdate = "update Flight_Master set Flight_No='" + txtFlightNo.Text + "',Flight_Type='" + ddlFlightType.SelectedItem.Text + "',Destination='" + destID + "',Origin='" + originID + "',Capacity='" + txtcapacity.Text + "',Status='" + ddlststus.SelectedValue + "',Entered_By='" + enterBy + "',Entered_On='" + DateTime.Now + "' where Flight_ID = '" + flightID + "'";
                SqlCommand cmd = new SqlCommand(strUpdate, con);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Redirect("ShowAddFlight.aspx");          
            }
            else
            {
                string str1 = "";
                str1 = "select * from Flight_Master where Flight_No='"+Label1.Text+txtFlightNo.Text + "'";
                da = new SqlDataAdapter(str1, con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    lblError.Text = "Flight Number " + Label1.Text + txtFlightNo.Text + " Already Exists.";
                    lblError.Visible = false;
                    ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + lblError.Text + "');</script>");
                    
                }
                else
                {
                    string[] strDestination = txtDestination.Text.Trim().Split('-');
                    //strDestination = strDestination.Substring(0, 3);
                    DataTable dtDestination = dw.GetAllFromQuery("select Destination_ID from Destination_Master where Destination_Code='" + strDestination[0] + "'");
                    if (dtDestination.Rows.Count > 0)
                    {
                        destID = dtDestination.Rows[0]["Destination_ID"].ToString();
                    }

                    string[] strOrigin = txtorigin.Text.Trim().Split('-');
                    //strOrigin = strOrigin.Substring(0, 3);
                    DataTable dtOrigin = dw.GetAllFromQuery("select City_ID from city_Master where City_Code='" + strOrigin[0] + "'");
                    if (dtOrigin.Rows.Count > 0)
                    {
                        originID = dtOrigin.Rows[0]["City_ID"].ToString();
                    }
                    con.Open();
                    string[] strAwb = ddlAirlineName.SelectedItem.Text.Split('-');
                    //int AW = strAwb.IndexOf("-");
                    //string strAwb1 = strAwb.Substring(0, AW);
                    string str11 = "select Airline_Text_Code from Airline_Master where Airline_Name='" + strAwb[0] + "'";
                    SqlCommand com = new SqlCommand(str11, con);
                    SqlDataReader red1 = com.ExecuteReader();
                    red1.Read();
                
                    string ATC = red1["Airline_Text_Code"].ToString();
                    txtFlightNo.Text = ATC + '-' + txtFlightNo.Text;
                    con.Close();
                    con.Open();
                    strUpdate = "update Flight_Master set Flight_No='" + txtFlightNo.Text + "',Flight_Type='" + ddlFlightType.SelectedItem.Text + "',Destination='" + destID + "',Origin='" + originID + "',Capacity='" + txtcapacity.Text + "',Status='" + ddlststus.SelectedValue + "',Entered_By='" + loginid + "',Entered_On='" + TodayDate + "' where Flight_ID = '" + flightID + "'";

                    SqlCommand cmd = new SqlCommand(strUpdate, con);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    con.Close();
                    Response.Redirect("ShowAddFlight.aspx");   
                }
            }
        }

        
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            //Response.Write(er);
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        Update();
    }

}
