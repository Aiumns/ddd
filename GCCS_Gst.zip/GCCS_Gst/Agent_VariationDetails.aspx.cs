using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Agent_VariationDetails : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {
            //DateTime DTM;
            //DTM = DateTime.Now.AddMonths(-1);

            txtValidTo.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txtValidFrom.Text = DateTime.Now.ToString("01/MM/yyyy");
            TextBox1.Text = "20";
        }

    }
    protected void btngenerate_Click(object sender, EventArgs e)
    {
        Session["from"] = txtValidFrom.Text;
        Session["to"] = txtValidTo.Text;
        ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>window.open( './Reports/Agent_VariationDetails_Show.aspx?top=" + TextBox1.Text + "');</script>");
    }
}
