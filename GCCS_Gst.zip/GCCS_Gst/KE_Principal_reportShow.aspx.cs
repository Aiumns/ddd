﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class KE_Principal_reportShow : System.Web.UI.Page
{
    public string page_pop = "";
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con = null;
    SqlCommand com = null;
    SqlDataReader dr = null;
    DisplayWrap dw = new DisplayWrap();
    string table = "";
    decimal sid=0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("./Login.aspx");
        }
        else
        {
            htmlTableSimple();
        }
    }
    public void htmlTableSimple()
    {
        string agnetID = "";
        string[] airline_name_city_text = Session["airline_name"].ToString().Split(',');
        string airline_name_city_value = Session["airline_value"].ToString();
        ////string[] agent_selected_id = Session["Agent_List_value"].ToString().Split('~');
        ////string[] agent_selected_name = Session["Agent_list_Text"].ToString().Split('~');
        string from_date = Session["from_date"].ToString().Trim();
        string to_date = Session["to_date"].ToString().Trim();
        //string rdbtn = Session["rdbtn1"].ToString();
        try
        {
            int Sno = 0;
          //  string DateWise = Session["Date"].ToString();
            string Charged_Weight = "";
            string Gross_Weight = "";
            decimal Total_Chargedwt = 0;
            decimal Total_Grosswt = 0;
            decimal GrandTotal_Grosswt = 0;
            decimal GranTotal_Chargedwt = 0;
            int awbcount = 0;
            // Table header create
            DataTable dtairlinename=dw.GetAllFromQuery("SELECT City_Name FROM dbo.City_Master WHERE City_ID='"+airline_name_city_text[0].ToString()+"'");

            table += @"<h5><p align=center>Principal CSR Report for " +airline_name_city_text[3].ToString()+"-" + dtairlinename.Rows[0]["City_Name"].ToString() + "  <br>" + from_date + " - " + to_date + "</p></h5>";
            ////table += @"<Table align=center width=80% border=1 cellspacing=0><tr><th colspan=10 align=center class=BOLDTEXT>" + airline_name_city_text[0] + "/" + airline_name_city_text[1] + "</th></tr></table>";

               int ip = 0;
              
                //con = new SqlConnection(strCon);
                //con.Open();
                //com = new SqlCommand("SELECT ag.Agent_name,AirWayBill_No,destination_code,CONVERT (VARCHAR,flight_date,103) AS flight_date,gross_weight,charged_weight,s.* FROM sales s INNER JOIN agent_master ag ON s.agent_id=ag.agent_id  WHERE Airline_Detail_ID='" + airline_name_city_value + "' AND " + rdbtn + " BETWEEN '" + from_date + "' AND '" + to_date + "' and s.agent_id=" + agnetID + " order by s." + rdbtn + "", con);
               if (Convert.ToDateTime(FormatDateMM(to_date)) < Convert.ToDateTime("07/01/2017"))
               {
                   con = new SqlConnection(strCon);
                   con.Open();
                   com = new SqlCommand("Principal_Report_KE", con);
                   com.CommandType = CommandType.StoredProcedure;
                   com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(airline_name_city_text[1].ToString());
                   com.Parameters.AddWithValue("FROM_DATE", FormatDateMM(from_date));
                   com.Parameters.AddWithValue("TO_DATE", FormatDateMM(to_date));
               }
               else
               {
                   con = new SqlConnection(strCon);
                   con.Open();
                   com = new SqlCommand("Principal_Report_KE_GST", con);
                   com.CommandType = CommandType.StoredProcedure;
                   com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(airline_name_city_text[1].ToString());
                   com.Parameters.AddWithValue("FROM_DATE", FormatDateMM(from_date));
                   com.Parameters.AddWithValue("TO_DATE", FormatDateMM(to_date));
               }
                //con.Open();
                SqlDataReader dr1 = com.ExecuteReader();
                if (dr1.HasRows)
                {
                    if (Convert.ToDateTime(FormatDateMM(to_date)) < Convert.ToDateTime("07/01/2017"))
                    {
                        table += @"<Table align=center width=80% border=1 cellspacing=0><tr class=h1 align=left><th>Sno</th><th>Awb No.</th><th >Awb.Date</th><th nowrap >Flt No</th><th>Flt Date</th><th>Org</th><th>Dest</th><th>PP/CC</th><th align=right>Pcs</th><th align=right>Gr.wt</th><th align=right>Ch.wt</th><th align=right>Pub Rate</th><th align=right>Frt Amt</th><th align=right nowrap>Val Chrgs</th><th align=right nowrap>IATA COM-AMT</th><th align=right nowrap>Due Carrier</th><th align=right nowrap>Due Agent</th><th align=right nowrap>NET NET Rate</th><th align=right nowrap>Adc-COMM</th><th align=right nowrap>S.Tax on IATA COM</th><th align=right nowrap>SB Cess on IATA COM</th><th align=right nowrap>KK Cess on IATA COM</th><th align=right>Net Due</th></tr>";
                    }
                    else
                    {
                        table += @"<Table align=center width=80% border=1 cellspacing=0><tr class=h1 align=left><th>Sno</th><th>Awb No.</th><th >Awb.Date</th><th nowrap >Flt No</th><th>Flt Date</th><th>Org</th><th>Dest</th><th>PP/CC</th><th align=right>Pcs</th><th align=right>Gr.wt</th><th align=right>Ch.wt</th><th align=right>Pub Rate</th><th align=right>Frt Amt</th><th align=right nowrap>Val Chrgs</th><th align=right nowrap>IATA COM-AMT</th><th align=right nowrap>Due Carrier</th><th align=right nowrap>Due Agent</th><th align=right nowrap>NET NET Rate</th><th align=right nowrap>Adc-COMM</th><th align=right nowrap>CGST</th><th align=right nowrap>SGST</th><th align=right nowrap>IGST</th><th align=right>Net Due</th></tr>";
                    }
                    while (dr1.Read())
                    {
                       
                        decimal Adc_Com = 0;
                        Sno++;
                        decimal netdue=0;
                        ip = ip + 1;
                        table += @"<tr onclick=ChangeColor(this);><td align=left class=text nowrap=true>" + ip + @"</td><td align=left class=text nowrap=true>" + dr1["AirWayBill_No"].ToString() + @"</td><td align=left class=text>" + dr1["Awb_Date"].ToString() + @"</td><td align=left class=text nowrap>" + dr1["flight_no"].ToString() + @"</td><td align=left class=text nowrap=true>" + dr1["Flt_date"].ToString() + @"</td><td align=left class=text>" + dr1["City_Code"].ToString() + @"</td><td align=left class=text>" + dr1["destination_code"].ToString() + @"</td><td align=left class=text>" + dr1["Freight_Type"].ToString() + @"</td><td align=right class=text idx='pkg'>" + dr1["No_Of_Packages"].ToString() + @"</td><td align=right class=text nowrap=true idx='Gross_Weight' >" + dr1["Gross_Weight"].ToString() + @"</td><td align=right class=text idx='cwt'>" + dr1["Charged_Weight"].ToString() + @"</td><td align=right class=text idx='tariff'>" + dr1["tariff_rate"].ToString() + @"</td><td align=right class=text idx='famount'>" + dr1["Freight_Amount"].ToString() + @"</td><td align=right class=text idx='valution'>" + dr1["Valuation_charges"].ToString() + @"</td><td align=right class=text idx='IATA_Comm'>" + Math.Ceiling(decimal.Parse(dr1["IATA_COMM"].ToString())).ToString("0.00") + @"</td><td align=right class=text idx='total_Duecarrier'>" + dr1["total_Duecarrier"].ToString() + @"</td><td align=right class=text idx='Due_Agent'>" + dr1["Due_Agent"].ToString() + @"</td>";
                        string P_Rate="0";
                        if (decimal.Parse(dr1["Principle_Spot_Rate"].ToString()) > 0 && decimal.Parse(dr1["principle_rate"].ToString()) > 0)
                        {
                            P_Rate = dr1["Principle_Spot_Rate"].ToString();
                            table += "<td align=right class=text idx='Principle_Spot_Rate'>" + P_Rate + @"</td>";
                        }
                        else if (decimal.Parse(dr1["principle_rate"].ToString()) > 0 && decimal.Parse(dr1["Principle_Spot_Rate"].ToString()) == 0)
                        {
                            P_Rate = dr1["principle_rate"].ToString();
                            table += "<td align=right class=text idx='Principle_Spot_Rate'>" + P_Rate + @"</td>";
                        }
                        else if (decimal.Parse(dr1["principle_rate"].ToString()) == 0 && decimal.Parse(dr1["Principle_Spot_Rate"].ToString()) > 0)
                        {
                            P_Rate = dr1["Principle_Spot_Rate"].ToString();
                            table += "<td align=right class=text idx='Principle_Spot_Rate'>" + P_Rate + @"</td>";
                        }
                        else
                        {
                            table += "<td align=right class=text idx='Principle_Spot_Rate'>" + P_Rate + @"</td>";
                        }
                        //table+="<td align=right class=text idx='Spot_Rate'>" + dr1["Spot_Rate"].ToString() + @"</td>";
                        if (decimal.Parse(dr1["special_rate"].ToString()) > 0)
                        {
                            //if (decimal.Parse(dr1["tariff_rate"].ToString()) <= 600)
                            //{
                                ////Adc_Com = (decimal.Parse(dr1["Charged_Weight"].ToString()) * (decimal.Parse(dr1["tariff_rate"].ToString()) * 95 / 100 - decimal.Parse(dr1["special_rate"].ToString()));
                                Adc_Com = (decimal.Parse(dr1["Charged_Weight"].ToString()) * ((decimal.Parse(dr1["tariff_rate"].ToString()) * 95 / 100 - decimal.Parse(P_Rate))));
                            //}
                        }
                        netdue = decimal.Parse(dr1["Freight_Amount"].ToString()) + decimal.Parse(dr1["total_Duecarrier"].ToString()) - decimal.Parse(dr1["IATA_COMM"].ToString()) - Adc_Com - decimal.Parse(dr1["Stax_On_IATA"].ToString());
                        if (Convert.ToDateTime(FormatDateMM(to_date)) < Convert.ToDateTime("11/15/2015 12:00:00 AM"))
                        {
                            table += "<td align=right class=text idx='Adc_Com'>" + Math.Ceiling(Adc_Com).ToString("0.00") + @"</td><td align=right class=text idx='Stax_On_IATA'>" + Math.Ceiling(decimal.Parse(dr1["Stax"].ToString())).ToString("0.00") + @"</td><td align=right class=text idx='SBCESS_On_IATA'>0.00</td><td align=right class=text idx='KKCESS_On_IATA'>0.00</td><td align=right class=text idx='netdue'>" + Math.Ceiling(netdue).ToString("0.00") + "</td><td colspan=2><a style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px; font-weight:bold;' href='PrincipalFedexReport_Edit.aspx?sno=" + dr1["Sales_ID"] + "&amp;awb_no=" + dr1["AirWayBill_No"] + "&amp;spl_rate=" + P_Rate + "&amp;pr_remarks=" + dr1["Principle_Spot_Rate_Remarks"].ToString().Trim() + "&amp;crate=" + Convert.ToDecimal(dr1["gsacomm_rate"].ToString()) + "&amp;aid=" + airline_name_city_text[1].ToString() + "&amp;fdate=" + from_date + "&amp;tdate=" + to_date + "' class=hideWhilePrinting >Edit</a></td></tr>";
                        }
                        else if (Convert.ToDateTime(FormatDateMM(to_date)) < Convert.ToDateTime("06/01/2016 12:00:00 AM"))
                        {
                            table += "<td align=right class=text idx='Adc_Com'>" + Math.Ceiling(Adc_Com).ToString("0.00") + @"</td><td align=right class=text idx='Stax_On_IATA'>" + Math.Ceiling(decimal.Parse(dr1["Stax"].ToString())).ToString("0.00") + @"</td><td align=right class=text idx='SBCESS_On_IATA'>" + Math.Ceiling(decimal.Parse(dr1["SB_CESS"].ToString())).ToString("0.00") + @"</td><td align=right class=text idx='KKCESS_On_IATA'>0.00</td><td align=right class=text idx='netdue'>" + Math.Ceiling(netdue).ToString("0.00") + "</td><td colspan=2><a style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px; font-weight:bold;' href='PrincipalFedexReport_Edit.aspx?sno=" + dr1["Sales_ID"] + "&amp;awb_no=" + dr1["AirWayBill_No"] + "&amp;spl_rate=" + P_Rate + "&amp;pr_remarks=" + dr1["Principle_Spot_Rate_Remarks"].ToString().Trim() + "&amp;crate=" + Convert.ToDecimal(dr1["gsacomm_rate"].ToString()) + "&amp;aid=" + airline_name_city_text[1].ToString() + "&amp;fdate=" + from_date + "&amp;tdate=" + to_date + "' class=hideWhilePrinting >Edit</a></td></tr>";
                        }
                        else 
                        {
                            table += "<td align=right class=text idx='Adc_Com'>" + Math.Ceiling(Adc_Com).ToString("0.00") + @"</td><td align=right class=text idx='Stax_On_IATA'>" + Math.Ceiling(decimal.Parse(dr1["Stax"].ToString())).ToString("0.00") + @"</td><td align=right class=text idx='SBCESS_On_IATA'>" + Math.Ceiling(decimal.Parse(dr1["SB_CESS"].ToString())).ToString("0.00") + @"</td><td align=right class=text idx='KKCESS_On_IATA'>" + Math.Ceiling(decimal.Parse(dr1["KK_CESS"].ToString())).ToString("0.00") + @"</td><td align=right class=text idx='netdue'>" + Math.Ceiling(netdue).ToString("0.00") + "</td><td colspan=2><a style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; color:#666666; padding-left:5px; font-weight:bold;' href='PrincipalFedexReport_Edit.aspx?sno=" + dr1["Sales_ID"] + "&amp;awb_no=" + dr1["AirWayBill_No"] + "&amp;spl_rate=" + P_Rate + "&amp;pr_remarks=" + dr1["Principle_Spot_Rate_Remarks"].ToString().Trim() + "&amp;crate=" + Convert.ToDecimal(dr1["gsacomm_rate"].ToString()) + "&amp;aid=" + airline_name_city_text[1].ToString() + "&amp;fdate=" + from_date + "&amp;tdate=" + to_date + "' class=hideWhilePrinting >Edit</a></td></tr>";
                        }
                        ////Charged_Weight = dr1["Charged_Weight"].ToString();
                        ////Gross_Weight = dr1["Gross_Weight"].ToString();
                        ////Total_Chargedwt = Total_Chargedwt + (decimal.Parse(Charged_Weight));
                        ////Total_Grosswt += (decimal.Parse(Gross_Weight));
                    }
                    table += @"<tr><td align=left class=boldtext colspan=8>Total</td><td align=left class=text > <span tsv='pkg'></span></td><td align=right class=text nowrap=true  ><span tsv='Gross_Weight'></td><td align=right class=text ><span tsv='cwt'></td><td align=right class=text ><span tsv='tariff'></td><td align=right class=text ><span tsv='famount'></td><td align=right class=text ><span tsv='valution'></td><td align=right class=text ><span tsv='IATA_Comm'></td><td align=right class=text ><span tsv='total_Duecarrier'></td><td align=right class=text ><span tsv='Due_Agent'></td><td align=right class=text ><span tsv='Principle_Spot_Rate'></td><td align=right class=text ><span tsv='Adc_Com'></td><td align=right class=text ><span tsv='Stax_On_IATA'></td><td align=right class=text ><span tsv='Sb_Cess_On_IATA'></td><td align=right class=text ><span tsv='KK_Cess_On_IATA'></td><td align=right class=text><span tsv='netdue'></td></tr>";
                    table += @"</tr></table>";
                    Label1.Text = table;
                    ////table += @"<tr class=h1>";

                    //////table += @"<td colspan=4><b>Total</b></td>";
                    //////table += @"<td align=right><b>&nbsp;" + Convert.ToDecimal(Total_Grosswt).ToString("#,##0.00") + "</b></td>";
                    //////table += @"<td align=right><b>&nbsp;" + Convert.ToDecimal(Total_Chargedwt).ToString("#,##0.00") + "</b></td>";
                    //table += @"<td colspan=2 align=right><b>&nbsp;</td>";

                    ////table += @"</tr></table><br/><br/>";
                    ////GrandTotal_Grosswt += Total_Grosswt;
                    ////GranTotal_Chargedwt += Total_Chargedwt;
                    ////Total_Chargedwt = 0;
                    ////Total_Grosswt = 0;
                    ////awbcount += ip;

                }
        }
        catch (SqlException ex)
        {
            string strer = ex.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

    }
   
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[1];
        string strDD = d[0];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
}
