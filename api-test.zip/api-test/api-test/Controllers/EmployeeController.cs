﻿using api_test.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
namespace api_test.Controllers
{
    public class EmployeeController : Controller
    {
        //private GccTestEntities db = new GccTestEntities();
        // GET: /Employee/
        public ActionResult Index()
        {
            //var num = 1;
            ////After action was completed;
            //if (num == 1)
            //{
            //    ViewData["msg"] = "Action completed successfully";
            //}
            //else
            //{
            //    ViewData["msg"] = "OOps Action not completed";
            //}
            return View();
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult create(Employee employee)
        {
            using (var client = new HttpClient())
            {
                string msg = string.Empty;
                client.BaseAddress = new Uri("http://localhost:62536/api/EmployeeApi/create");
                
                //HTTP POST
                var postTask = client.PostAsJsonAsync<Employee>("employee", employee);
                

                var result = postTask.Result;
                int code = Convert.ToInt32(result.StatusCode);
                switch (code)
                {
                    case 200:
                        TempData["msg"] = "success";
                        break;
                    case 406:
                        TempData["msg"] = "NoAccepted";
                        break;
                    default:
                        TempData["msg"] = "NotFound";
                        break;
                }
                return RedirectToAction("create");
            }
            //ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
            //return View(employee);            
        }
	}
}