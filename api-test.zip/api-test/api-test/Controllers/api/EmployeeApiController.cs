﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using api_test.Models;
using System.Text;
using System.Net.Http.Headers;

namespace api_test.Controllers.api
{
    public class EmployeeApiController : ApiController
    {
        private PacePowerTestEntities db = new PacePowerTestEntities();

        // GET api/EmployeeApi
        public IQueryable<Employee> GetEmployees()
        {
            return db.Employees;
        }

        // GET api/EmployeeApi/5
        [ResponseType(typeof(Employee))]
        public HttpResponseMessage GetEmployee(int id)
        {
            try
            {
                Employee employee = db.Employees.Find(id);
                if (employee != null)
                {
                    //return Ok(employee);
                    //return Request.CreateResponse<Employee>(HttpStatusCode.OK, employee);
                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, employee);
                    //response.Content = new StringContent(employee, Encoding.Unicode);                    
                    response.Headers.CacheControl = new CacheControlHeaderValue()
                    {
                        MaxAge = TimeSpan.FromMinutes(20)
                    };
                    return response;
                }
                else
                {
                    //return NotFound();
                    HttpError myCustommsg = new HttpError("It has no content or rows to process.") { { "StatusCode", 400 } };
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, myCustommsg);
                }            
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message); 
            }           
        }

        // PUT api/EmployeeApi/5
        public IHttpActionResult PutEmployee(int id, Employee employee)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != employee.id)
            {
                return BadRequest();
            }

            db.Entry(employee).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/EmployeeApi
        
        [ResponseType(typeof(Employee))]
        [Route("api-test")]
        public HttpResponseMessage PostEmployee(Employee employee)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    HttpError Myerror = new HttpError("BadRequest") { { "Status Code", 400 } };
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, Myerror);
                }
                using (var ctx = new PacePowerTestEntities())
                {
                    int statusCode = Convert.ToString(employee.employee_name) == "" || Convert.ToString(employee.Gender) == "" || Convert.ToInt32(employee.employee_age) == 0 || Convert.ToDecimal(employee.employee_salary) == 0 ? 406: 200;
                    if (statusCode == 406)
                    {
                        HttpError myErr = new HttpError("Wrong Content.") { { "ErrorCode", 406 } };
                        return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myErr);
                    }
                    ctx.Employees.Add(new Employee()
                    {                     
                       // id = employee.id,
                        employee_name = employee.employee_name,
                        dept_name = employee.dept_name,
                        employee_salary =employee.employee_salary, 
                        employee_age=employee.employee_age,
                        Gender = employee.Gender,
                    });

                    ctx.SaveChanges();
                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, "Success");
                    response.Content = new StringContent("hello", Encoding.Unicode);
                    response.Headers.CacheControl = new CacheControlHeaderValue()
                    {
                        MaxAge = TimeSpan.FromMinutes(20)
                    };
                    return response;
                    //return Request.CreateResponse(HttpStatusCode.Created, "Created successfully");
                }
            }
            catch (Exception)
            {
               throw;
            }
            finally
            {

            }

            //return Ok();
            ////try
            ////{
            ////    if (!ModelState.IsValid)
            ////    {
            ////        return BadRequest(ModelState);
            ////        HttpError myCustommsg = new HttpError("The file has no content or rows to process.") { { "CustomErrorCode", 42 } };
            ////        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, myCustommsg);
            ////    }
            ////    else
            ////    {
            ////        db.Employees.Add(employee);
            ////        db.SaveChanges();
            ////        HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, "Success");
            ////        response.Content = new StringContent("hello", Encoding.Unicode);
            ////        response.Headers.CacheControl = new CacheControlHeaderValue()
            ////        {
            ////            MaxAge = TimeSpan.FromMinutes(20)
            ////        };
            ////        return response;
            ////        return Request.CreateResponse(HttpStatusCode.Created, "Created successfully");
            ////    }
            ////}
            ////catch (Exception ex)
            ////{
            ////    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            ////}
            // return CreatedAtRoute("DefaultApi", new { id = employee.id }, employee);
        }

        // DELETE api/EmployeeApi/5
        [ResponseType(typeof(Employee))]
        public IHttpActionResult DeleteEmployee(int id)
        {
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }
            db.Employees.Remove(employee);
            db.SaveChanges();
            return Ok(employee);            
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool EmployeeExists(int id)
        {
            return db.Employees.Count(e => e.id == id) > 0;
        }
    }
}