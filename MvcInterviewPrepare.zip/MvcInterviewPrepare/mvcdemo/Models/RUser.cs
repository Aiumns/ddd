﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace mvcdemo.Models
{
   public class RUser
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        [DataType(DataType.ImageUrl)]
        public string UserProfile { get; set; }  //File Upload
        public string Address { get; set; }
        [DataType(DataType.PhoneNumber)]
        public string ContactNo { get; set; }
        [DataType(DataType.EmailAddress)]
        public string EmailId { get; set; }
        [DisplayName("Date of Birth")]       
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MMM/yyyy}")]  
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; } //DateCalender        
        public Genders Gender { get; set; } //Radio Button
        public string UserType { get; set; } ///Option button  
                                            
        // public SelectList Country { get; set; }
        public IEnumerable<SelectListItem> Countries { get; set; }
        public int CountryId { get; set; }

        //public int CountryId { get; set; }
        //public IEnumerable<Country> Countries { get; set; }
        //public List<Country> CountryList { get; set; }
        public int StateId { get; set; }
        //public List<State> StateList { get; set; }
        public int CityId { get; set; }
        //public List<City> CityList { get; set; }
        [DataType(DataType.PostalCode)]
        public string Pincode { get; set; }       
        public bool IsActive { get; set; }  // checkBox button
    }
   public enum Genders
    {
       [Display(Name = "Male")]
       Male = 1,
       [Display(Name = "Female")]
       Female = 2,
       [Display(Name = "Other")]
       Other = 3
    }
    public class Country
    {
        public int CountryId { get; set; }
        public string CountryName { get; set; }
    }

    public class State
    {
        public int StateId { get; set; }
        public string StateName { get; set; }
    }

    public class City
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
    }
}