﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace mvcdemo.Controllers
{
    public class TestController : Controller
    {
        //1 ViewResult
        //2 PartialViewResult
        //3 ActionResult
        //4 RedirectResult  
        //5jsonresult
        //6RedirectToRouteResult
        //7ContentResult
        //8
        public ViewResult ViewResultTest()
        {
            return View("ViewResultTest");           
        }
        public PartialViewResult PartialViewResultTest()
        {
            return PartialView("PartialViewResultTest");           
        }
        //public ActionResult RedirectResultTest()
        //{
        //    return Redirect("http://www.google.com/");
        //}
        public RedirectResult RedirectResultTest()
        {
            return Redirect("http://www.google.com/");
        }

        public RedirectToRouteResult RedirectToRouteResultTest(int? Id)
        {
            return new RedirectToRouteResult(new System.Web.Routing.RouteValueDictionary(new { controller = "Home", action = "Index", Id = new int?() }));
        }

        public ContentResult ContentResultTest()
        {
            return Content("Hello My Friend!");
        }

        public JsonResult JsonResultTest()
        {
            return Json("Hello My Friend!");
        }
	}
}