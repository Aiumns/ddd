using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Xml;
using System.Net.Mail;
using System.Net;


public partial class Booking_Edit : System.Web.UI.Page
{
    #region Summary
    /// <summary>
    /// <class>Sales</class>
    /// <class>Sales Edit</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Rajinder Singh Lamba</createdBy>
    /// <createdOn>DEC 22, 2007</createdOn>
    /// <modifications>
    ///		<modification>
    ///			<changeDescription></changeDescription>
    ///			<modifiedBy>Rajinder Singh Lamba</modifiedBy>
    ///			<modifiedOn>FEB 23, 2008</modifiedOn>
    ///		</modification>
    /// </modifications>			
    /// </summary>		
    #endregion
   
    DisplayWrap dw = new DisplayWrap();
    BLWrap bw = new BLWrap();
    SqlConnection con;
    SqlCommand com;
    SqlCommand cmd;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    public string calendarControl = "";
    int NA = 0;
    int invoiceNo = 0;
    int Lastinvoiceno = 0;
    int invoicesno = 0;
    public string strCity = "";
    protected void Page_Init(object sender, EventArgs e)
    {
        
        string GroupID = "";       
        DataTable dtGroupId = dw.GetAllFromQuery("SELECT Group_ID FROM dbo.Login_Master WHERE Email_ID='" + Session["EMailID"] + "'");
        if (dtGroupId.Rows.Count > 0)
        {
            GroupID = dtGroupId.Rows[0]["Group_ID"].ToString(); 
            ViewState["GroupID"] = GroupID;
        }

       
        //if (GroupID != "13" )
        //{
        if (Request.QueryString["Sales_ID"] != null)
            {
                FillBuyingRouteDetails();
            }
       // }
    }
    protected void Page_Load(object sender, EventArgs e)
    {     
        HtmlGenericControl body = (HtmlGenericControl)Page.Master.FindControl("MyBody");
        // body.Attributes.Add("onload", "OnOff()");
        Button1.Attributes.Add("onclick", "return CheckEmpty();");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            //////*****************Added On 18 Apr 2011****************
            //// if (Session["groupid"].ToString() == "1" || Session["groupid"].ToString() == "9" || Session["groupid"].ToString() == "49" || Session["groupid"].ToString() == "56")
            //// {

            ////     PricipalePannel.Visible = true;
            //// }
            //////*****************End*********************************

            lblawbfee.Visible = false;
            txtAwbfee.Visible = false;
            hdnDimension.Value = Session["groupid"].ToString();

            //*****************Added On 18 Apr 2011****************
            PricipalePannel.Attributes.Add("style", "display:none");
            if (Session["groupid"].ToString() == "1" || Session["groupid"].ToString() == "9" || Session["groupid"].ToString() == "49" || Session["groupid"].ToString() == "56")
            {
                ////LblprinTxt.Visible = true;
                ////lblbrc.Visible = true;
                ////ChkMinAirline.Visible = true;
                ////txtPRate.Visible = true;
                ////lblbrc2.Visible = true;
                //PricipalePannel.Visible = true;                                                           
                PricipalePannel.Attributes.Add("style", "display:block");
            }
            //*****************End*********************************

           


            ViewState["edit"] = "0";
            ViewState["et"] = "1";

            if (!IsPostBack)
            {
                //DataTable dtCarrier = dw.GetAllFromQuery("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
                GridView1.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
                GridView1.DataBind();

                grdCal.DataSource = (DataTable)Session["dtTemp"];
                grdCal.DataBind();

               // CreateTextBoxesInTable();    
               // fillddl();
                fillGatewayDpr();
                ////Session["dtOtherCharges"] = null;
                ////Session["dtTemp"] = null;
                ////Session["dtTem"] = null;
                ////Session["dtOther"] = null;  
                rbCal.SelectedValue = "Cm";
                LoadACS();
                string SalesID = "";
                DataTable dtSalesEdit = new DataTable();
                if (Request.QueryString["Sales_ID"] != null)
                {
                    SalesID = Request.QueryString["Sales_ID"];
                    dtSalesEdit = dw.GetAllFromQuery("Select status,Approved_for_CSR,CSR_DATE,CSR_Remarks from sales where status in(11,12) and Sales_ID=" + SalesID);
                    fillVolumeDimension(SalesID);
                }
                else
                {
                    maketable();
                    grdCal.DataSource = (DataTable)Session["dtTemp"];
                    grdCal.DataBind();

                    //DataTable sumdt=(DataTable)Session["dtTemp"];
                    
                 
                }

                if (dtSalesEdit.Rows.Count > 0)
                {
                    if (dtSalesEdit.Rows[0]["Approved_for_CSR"].ToString() == "28")
                    {
                        ////ddlAwbNo.Attributes.Add("Enable","false");
                        ddlAwbNo.Enabled = false;
                        ddlAirline.Enabled = false;
                        ddlAgentName.Enabled = false;
                        ddlOrigin.Enabled = false;
                        //body.Attributes.Add("onload", "AWB()");
                        FillSalesFields();
                        DateTime CSR_DATE = Convert.ToDateTime(dtSalesEdit.Rows[0]["CSR_DATE"].ToString());
                        txtCSRDate.Text = FormatDateDD(CSR_DATE.ToShortDateString()); txtCSRDate.Enabled = false;
                        txtCSRRemarks.Text = Convert.ToString(dtSalesEdit.Rows[0]["CSR_Remarks"]);
                        tdCSRRemarks.Visible = true;
                        tdTextCSR.Visible = true;
                        //Button2.Visible = false;
                        btnSModify.Visible = true;
                        UpdateSales.Visible = false;
                        Label1.Text = "* The CSR is already approved,If u made any change it will create CR/DR Note. *";
                        Label1.ForeColor = System.Drawing.Color.Red;
                        tdTextCSR.Visible = true;
                        tdCSRRemarks.Visible = true;

                    }
                    else
                    {
                        // ddlAwbNo.Attributes.Add("Enable", "false");
                        ddlAwbNo.Enabled = false;
                        ddlAirline.Enabled = false;
                        ddlAgentName.Enabled = false;
                        ddlOrigin.Enabled = false;
                        btnSModify.Visible = false;
                        UpdateSales.Visible = true;
                        tdCSRDate.Visible = false;
                        tdtxtCSRDate.Visible = false;
                        FillSalesFields();
                    }
                    Button1.Visible = false;

                }
                else
                {
                    tdCSRDate.Visible = false;
                    tdtxtCSRDate.Visible = false;
                    Button1.Visible = true;
                    UpdateSales.Visible = false;
                    /////////FillAllFields();
                }
                ////maketable();
                ////grdCal.DataSource = (DataTable)Session["dtTemp"];
                ////grdCal.DataBind();
            }
            if (Session["table"] != null)
            {
                phRouteDetail.Controls.Clear();
                phRouteDetail.Controls.Add((Table)Session["table"]);
            }
        }
    }
    public string City()
    {
        string strTemp1 = "";
        con = new SqlConnection(strCon);
        try
        {
            string[] DestCode = ddlDestination.SelectedItem.Value.Split('-');
            cmd = new SqlCommand("Route", con);
            cmd.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@destination", SqlDbType.VarChar).Value = DestCode[0].ToString();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp1 == "")
                    strTemp1 = "'" + Convert.ToString(dr["Routing"]).ToString().ToUpper().Trim() + "'";

            }
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp1;
    }
    public DataTable tableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Route";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Origin_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Destination_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "rate";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Flight_no";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Flight_date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Carrier";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Currency";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        Session["dtTem"] = dtTemp;
        return dtTemp;
    }
    public void maketableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Route";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Origin_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Destination_code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "rate";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "flight_no";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "flight_date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Carrier";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Currency";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dr[6] = "0";
        dr[7] = "0";
        dr[8] = "0";
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
    }
    public void fillVolumeDimension(string Id)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            //////strQuery = "select * from Sales_Trans where Stock_id = '" + Id + "'";
            DisplayWrap de = new DisplayWrap();
            DataTable dttrans = de.GetAllFromQuery("Select stock_id from Sales where sales_id=" + Id + " ");
            if (dttrans.Rows.Count > 0)
            {
                strQuery = "select * from Sales_Trans where Stock_id=" + dttrans.Rows[0]["stock_id"].ToString();
            }
            
        }


        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = tableVolumewt();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            ////if (dr["Measurement_Unit"].ToString() != "" || dr["Measurement_Unit"].ToString() != null)
            ////    rbCal.SelectedValue = dr["Measurement_Unit"].ToString();
            dw = dt.NewRow();
            dw[0] = i++;

            string len = dr["Route"].ToString();
            string width = dr["Origin_Code"].ToString();
            string Height = dr["Destination_Code"].ToString();

            string l = dr["Route"].ToString();
            string w = dr["Origin_Code"].ToString();
            string h = dr["Destination_Code"].ToString();

            ////decimal l = System.Math.Round(decimal.Parse(len), MidpointRounding.AwayFromZero);
            ////decimal w = System.Math.Round(decimal.Parse(width), MidpointRounding.AwayFromZero);
            ////decimal h = System.Math.Round(decimal.Parse(Height), MidpointRounding.AwayFromZero);

            dw[1] = l;
            dw[2] = w;
            dw[3] = h;
            dw[4] = dr["rate"].ToString();
            dw[5] = dr["flight_no"].ToString();
            dw[6] = dr["flight_date"].ToString();
            dw[7] = dr["Carrier"].ToString();
            dw[8] = dr["Currency"].ToString();

            dt.Rows.Add(dw);

        }
        if (dt.Rows.Count > 0)
        {
            grdCal.DataSource = dt;
            grdCal.DataBind();
            Session["dtTemp"] = dt;
        }
        else
        {
            Session["dtTemp"] = null;
            maketableVolumewt();
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        con.Close();
    }
    public void maketable()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Route";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Origin_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Destination_code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "rate";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "flight_no";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "flight_date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Carrier";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Currency";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dr[6] = "0";
        dr[7] = "0";
        dr[8] = "0";
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
        ViewState["dtBeginCharges"] = dtTemp;
    }
    //================================================Added By:Pradeep Sharma======================
    protected void rbtnGateWay_CheckedChanged(object sender, EventArgs e)
    {
        //////Route_type.Visible = true;
    }
    protected void rbtnGateWay2_CheckedChanged(object sender, EventArgs e)
    {
        //////Route_type.Visible = true;
    }
    //interline
    protected void rbtnRouteType1_CheckedChanged(object sender, EventArgs e)
    {

        txtCenturionRoute.Text = "";
        phRouteDetail.Controls.Clear();
        SetPrincipalToDefault();
        ////PnlCarrier.Visible = true;
        RouteEnter.Visible = false;
        lblOrigin.Text = ddlOrigin.SelectedValue.Split('-')[0];
        lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
        fillddl("Y");
       
    }
    public void fillddl(string interline)
    {
        //===========================================Added BY:Pradeep Sharma==================
        con = new SqlConnection(strCon);
        com = new SqlCommand("SpAK_PH_FillCarrier", con);
        com.CommandType = CommandType.StoredProcedure;
        ////if (rbtnRouteType1.Checked == true)
        ////{
        ////    com.Parameters.AddWithValue("@Interline", interline);
        ////}
        ////else
        ////{
            com.Parameters.AddWithValue("@Interline", interline);
        ////}
        con.Open();
        SqlDataAdapter adp = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        //////selCarrier.Items.Clear();
        if (dt.Rows.Count > 0)
        {
           ///// selCarrier.Items.Insert(0, new ListItem("--Select--", "0"));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //////selCarrier.Items.Add(new ListItem(dt.Rows[i]["CarrierCode"].ToString(), dt.Rows[i]["CarrierCode"].ToString()));
            }

        }
        con.Close();


    }
    public void fillGatewayDpr()
    {
        DataTable dtGateway = dw.GetAllFromQuery("select GatewayCode from gateway");
        ////rbtnGateWay.DataSource = dtGateway;
        ////rbtnGateWay.DataTextField = "GatewayCode";
        ////rbtnGateWay.DataValueField = "GatewayCode";
        ////rbtnGateWay.DataBind();

    }
    protected void rbtnGateWay_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        ////rbtnRouteType1.Checked = false;
        ////rbtnRouteType2.Checked = false;
       //// selCarrier.SelectedValue = "0";
        txtCenturionRoute.Text = "";
        SetPrincipalToDefault();
        phRouteDetail.Controls.Clear();
        ////Route_type.Visible = true;
      /////  PnlCarrier.Visible = false;
        RouteEnter.Visible = false;

    }
    //non-interline
    protected void rbtnRouteType2_CheckedChanged(object sender, EventArgs e)
    {      
            txtCenturionRoute.Text = "";
            phRouteDetail.Controls.Clear();
          ////  PnlCarrier.Visible = false;
            RouteEnter.Visible = true;
            lblOrigin.Text = ddlOrigin.SelectedItem.ToString().Split('-')[0];
            lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
            fillddl("N");   

    }
    protected void selCarrier_SelectedIndexChanged(object sender, EventArgs e)
    {
        //phRouteDetail.Controls.Clear();
        //SetPrincipalToDefault();     
        //if (selCarrier.SelectedValue == "0")
        //{
        //    RouteEnter.Visible = false;
        //}
        //else
        //{
        //    RouteEnter.Visible = true;
        //    lblOrigin.Text = ddlOrigin.SelectedItem.ToString().Split('-')[0];//txtOrigin.Text.Split('-')[0];
        //    lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
        //}
    }
    protected void btnSearchRates_Click(object sender, EventArgs e)
    {      
        CreateTextBoxesInTable();       
    }
    public void CreateTextBoxesInTable()
    {
            phRouteDetail.Controls.Clear();
            SetPrincipalToDefault();    
            double sumRate = 0, sumAmt = 0;           
            DataTable dtCurrency = dw.GetAllFromQuery("SELECT DISTINCT CurrencyCode as Currency FROM dbo.CurrencyMaster");
            DataTable dtCarrier = dw.GetAllFromQuery("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");           
            var route = GenerateRoute();
            //======================FlightNo in GridDropdown:By Pradeep Sharma=====================
            string FltNo = "";
            FltNo = "SELECT DISTINCT fm.Flight_No,fm.flight_id FROM flight_master fm INNER JOIN dbo.Flight_Details fd ON fm.Flight_ID = fd.Flight_ID WHERE fm.Airline_Detail_ID=" + ddlAirline.SelectedValue + " AND fm.Status=2";
            con = new SqlConnection(strCon);
            con.Open();
            SqlDataAdapter adp = new SqlDataAdapter(FltNo, con);
            DataTable dtFlightNo = new DataTable();
            adp.Fill(dtFlightNo);
            
            //=======================End===============================================
            int icount =Convert.ToInt32(txtCarrier.Text);
            double rate = 0, amt = 0;
            for (int i = 0; i < icount; i++)//for (int i = 0; i < route.Length - 1; i++)
            {
                Table table = new Table();
                table.Attributes["border"] = "1";
                table.Attributes["width"] = "90%";
                table.Attributes["cellSpacing"] = "0";
                table.Attributes["cellPadding"] = "0";
                table.Attributes["style"] = "margin:10px 10px 10px 10px; ";
                TableHeaderRow headerRow = new TableHeaderRow();
                TableCell[] headerCells = new TableCell[9];
                for (int jj = 0; jj <= headerCells.Length - 1; jj++)
                {
                    headerCells[jj] = new TableCell();
                }
                headerCells[0].Text = "Route";
                headerCells[1].Text = "Origin";
                headerCells[2].Text = "Destination";
                headerCells[3].Text = "Rate";
                headerCells[4].Text = "Amount";
                headerCells[5].Text = "Flight No";
                headerCells[6].Text = "Flight Date";
                headerCells[7].Text = "Currency";
                headerCells[8].Text = "Carrier";
                // headerCells[8].Text = "Carrier";

                headerRow.Cells.AddRange(headerCells);
                table.Rows.Add(headerRow);
                table.ID = "dynamicRouteTable" + i;
                TableRow tr = new TableRow();
                TableCell[] trCells = new TableCell[9];
                for (int j = 0; j <= trCells.Length - 1; j++)
                {
                    trCells[j] = new TableCell();
                }
                ////using (con = new SqlConnection(strCon))
                ////{
                ////    con.Open();
                ////    com = new SqlCommand("spAK_PH_GetPrincipalRate", con);
                ////    com.CommandType = CommandType.StoredProcedure;
                ////    com.Parameters.AddWithValue("@origin", route[i]);
                ////    com.Parameters.AddWithValue("@destination", route[i + 1]);
                ////    com.Parameters.AddWithValue("@interline", rbtnRouteType1.Checked ? "Y" : rbtnRouteType2.Checked ? "N" : "N/A");
                ////    com.Parameters.AddWithValue("@airlineCode", ddlAwbNo.SelectedItem.Text.Split('-')[0]);
                ////    if (txtCw.Text == "" || txtCw.Text == "0" || txtCw.Text == "0.00")
                ////    {
                ////        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "errorCW", " jAlert('Please Enter Chargeable weight')", true);
                ////        return;
                ////    }
                ////    else
                ////    {
                ////        com.Parameters.AddWithValue("@chwRate", txtCw.Text);
                ////    }
                ////    com.Parameters.AddWithValue("@carrierCode", selCarrier.SelectedValue);
                ////    rate = Convert.ToDouble(com.ExecuteScalar());
                ////}
                if (rate != 0)
                {
                    #region if part
                    if (txtPSpotRate.Text == "" || txtPSpotRate.Text == "0.00" || txtPSpotRate.Text == "0")
                    {
                        amt = rate * Convert.ToDouble(txtCw.Text);
                    }
                    else
                    {
                        amt = Convert.ToDouble(txtPSpotRate.Text) * Convert.ToDouble(txtCw.Text);
                    }
                    TextBox rout = new TextBox();
                    rout.Attributes.Add("id", "rout_" + i.ToString());
                    trCells[0].Controls.Add(rout);
                    //trCells[1].Text = route[i];
                    //trCells[2].Text = route[i + 1];

                    TextBox origin = new TextBox();
                    origin.Attributes.Add("id", "origin_" + i.ToString());
                    origin.Text = ddlOrigin.SelectedItem.Text.Split('-')[0];
                    trCells[1].Controls.Add(origin);//route[i];

                    TextBox destination = new TextBox();
                    destination.Attributes.Add("id", "destination_" + i.ToString());
                    destination.Text = ddlDestination.SelectedItem.Text.Split('-')[0];
                    trCells[2].Controls.Add(destination);//route[i];

                    //trCells[2].Text = ddlDestination.SelectedItem.Text.Split('-')[0];//route[i + 1];
                    TextBox rateTextBox = new TextBox();
                    rateTextBox.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
                    ////if (rbtnRouteType2.Checked)
                    ////{
                    ////    if (route[i] == "MIA" || route[i] == "AMS" || route[i] == "JFK")
                    ////    {
                    ////        txtPRate.Text = Convert.ToString(rate);
                    ////        txtPAmount.Text = Convert.ToString(Math.Round(amt, 2));
                    ////        rateTextBox.Attributes.Add("onFocusOut", "ChangePrinciple(this.id)");
                    ////    }
                    ////    else
                    ////    {
                    ////        rateTextBox.Attributes.Add("onFocusOut", "CalculateAmt(this.id)");
                    ////    }
                    ////}
                    ////if (rbtnRouteType1.Checked)
                    ////{
                    ////    //sum rate and amount
                    ////    sumRate += rate;
                    ////    sumAmt += amt;
                    ////    txtPRate.Text = Convert.ToString(sumRate);
                    ////    txtPAmount.Text = Convert.ToString(Math.Round(sumAmt, 2));
                    ////    rateTextBox.Attributes.Add("onFocusOut", "InterlineCalculateRateAmt(this.id)");
                    ////}
                    rateTextBox.Attributes.Add("id", "Rate_" + i.ToString());
                    rateTextBox.Text = Convert.ToString(rate);
                    trCells[3].Controls.Add(rateTextBox);
                    TextBox amtTextBox = new TextBox();
                    amtTextBox.Attributes.Add("id", "Amt_" + i.ToString());
                    amtTextBox.Enabled = false;
                    amtTextBox.Text = Convert.ToString(Math.Round(amt, 2));
                    trCells[4].Controls.Add(amtTextBox);
                    TextBox FlightNo = new TextBox();
                    FlightNo.Attributes["class"] = "text";
                    trCells[5].Controls.Add(FlightNo);
                    TextBox flightDate = new TextBox();
                    flightDate.Attributes["class"] = "date-pick dp-applied";
                    trCells[6].Controls.Add(flightDate);

                    DropDownList currency = new DropDownList();
                    currency.DataSource = dtCurrency;
                    currency.Attributes["class"] = "text";
                    currency.DataTextField = "Currency";
                    currency.DataValueField = "Currency";
                    currency.DataBind();
                    currency.SelectedValue = "USD";
                    trCells[7].Controls.Add(currency);

                    DropDownList couriers = new DropDownList();
                    couriers.Attributes["class"] = "text";
                    couriers.DataSource = dtCarrier;
                    couriers.DataTextField = "CarrierName";
                    couriers.DataValueField = "CarrierName";
                    couriers.DataBind();
                    couriers.SelectedValue = "--Select--";
                    trCells[8].Controls.Add(couriers);

                    tr.Cells.AddRange(trCells);
                    table.Rows.Add(tr);
                    rate = 0;
                    #endregion
                }
                else
                {
                    #region else  part

                    TextBox rout = new TextBox();
                    rout.Attributes.Add("id", "rout_" + i.ToString());
                    trCells[0].Controls.Add(rout);

                    TextBox origin = new TextBox();
                    origin.Attributes.Add("id", "origin_" + i.ToString());
                    origin.Text = ddlOrigin.SelectedItem.Text.Split('-')[0];
                    trCells[1].Controls.Add(origin);//route[i];

                    //trCells[1].Text = ddlOrigin.SelectedItem.Text.Split('-')[0];//route[i];

                    TextBox destination = new TextBox();
                    destination.Attributes.Add("id", "destination_" + i.ToString());
                    destination.Text = ddlDestination.SelectedItem.Text.Split('-')[0];
                    trCells[2].Controls.Add(destination);//route[i];
                    //trCells[2].Text = ddlDestination.SelectedItem.Text.Split('-')[0];//route[i + 1];
                    TextBox rateTextBox = new TextBox();
                    rateTextBox.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
                    ////if (rbtnRouteType2.Checked)
                    ////{
                    ////    if (route[i] == "MIA" || route[i] == "AMS" || route[i] == "JFK")
                    ////    {
                    ////        rateTextBox.Attributes.Add("onFocusOut", "ChangePrinciple(this.id)");
                    ////    }
                    ////    else
                    ////    {
                    ////        rateTextBox.Attributes.Add("onFocusOut", "CalculateAmt(this.id)");
                    ////    }
                    ////}
                    ////if (rbtnRouteType1.Checked)
                    ////{
                    ////    rateTextBox.Attributes.Add("onChange", "InterlineCalculateRateAmt(this.id)");
                    ////}
                    rateTextBox.Attributes.Add("id", "Rate_" + i.ToString());
                    rateTextBox.Text = "0";
                    trCells[3].Controls.Add(rateTextBox);
                    TextBox amtTextBox = new TextBox();
                    amtTextBox.Text = "0";
                    amtTextBox.Attributes.Add("id", "Amt_" + i.ToString());
                    amtTextBox.Enabled = false;
                    trCells[4].Controls.Add(amtTextBox);

                    TextBox FlightNo = new TextBox();
                    FlightNo.Attributes["class"] = "text";
                    trCells[5].Controls.Add(FlightNo);

                    TextBox flightDate = new TextBox();
                    flightDate.Attributes["class"] = "date-pick dp-applied";
                    trCells[6].Controls.Add(flightDate);

                    DropDownList currency = new DropDownList();
                    currency.Attributes["class"] = "text";
                    currency.DataSource = dtCurrency;
                    currency.DataTextField = "Currency";
                    currency.DataValueField = "Currency";
                    currency.DataBind();
                    currency.SelectedValue = "USD";
                    trCells[7].Controls.Add(currency);

                    DropDownList couriers = new DropDownList();
                    couriers.Attributes["class"] = "text";
                    couriers.DataSource = dtCarrier;
                    couriers.DataTextField = "CarrierName";
                    couriers.DataValueField = "CarrierName";
                    couriers.DataBind();
                    couriers.SelectedValue = "--Select--";
                    trCells[8].Controls.Add(couriers);

                    tr.Cells.AddRange(trCells);
                    table.Rows.Add(tr);
                    table.Rows.Add(tr);
                    #endregion
                }
                //phRouteDetail.Controls.Clear();
                phRouteDetail.Controls.Add(table);
                Session["table"] = table;
            }   
    }
    public string[] GenerateRoute()
    {

        return (lblOrigin.Text + "-" + txtCenturionRoute.Text.Trim() + "-" + lblDestination.Text).ToUpper().Split('-');

        ////if (rbtnGateWay.SelectedValue.Trim().ToUpper() == "JFK")//rbtnGateWay.SelectedValue.Trim()
        ////{
        ////    string middleroute = "";
        ////    foreach (string origin in txtCenturionRoute.Text.Trim().ToUpper().Split('-'))
        ////    {
        ////        if (IsGateway(origin))
        ////        {
        ////            middleroute += "-" + origin;
        ////        }
        ////        else
        ////        {
        ////            middleroute += "";
        ////        }

        ////    }
        ////    return (lblOrigin.Text + middleroute + "-" + lblDestination.Text).ToUpper().Split('-');
        ////}
        ////else
        ////{
        ////    return (lblOrigin.Text + "-" + rbtnGateWay.SelectedValue.Trim() + "-" + lblDestination.Text).ToUpper().Split('-');
        ////    //rbtnGateWay.SelectedValue.Trim()
        ////}
    }
    public Boolean IsGateway(string originCode)
    {
        Boolean bit = false;
        using (con = new SqlConnection(strCon))
        {
            con.Open();
            com = new SqlCommand("spAK_PH_IsGateway", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Origin", originCode);
            bit = Convert.ToBoolean(com.ExecuteScalar());
            return bit;
        }

    }
    //public void fillddl()
    //{
    //    DataTable dt = dw.GetAllFromQuery("SELECT CarrierName,CarrierCode FROM db_owner.tblCarrier");
    //    if (dt.Rows.Count > 0)
    //    {
    //        selCarrier.DataSource = dt;
    //        selCarrier.DataTextField = "CarrierCode";
    //        selCarrier.DataValueField = "CarrierCode";
    //        //selCarrier.Items.Insert(0, new ListItem("--Select--", "0"));
    //        //selCarrier.SelectedValue = "0";
    //        selCarrier.DataBind();
    //    }
    //}
    //fill Buying Roue Details on Sales Edit
    public void FillBuyingRouteDetails()
    {
        string stockID = "", chwt = "", interline = "",carrier="";
        DataTable dtSales = dw.GetAllFromQuery("SELECT stock_id,Charged_Weight,Interline,Carrier  FROM Sales where Sales_ID=" + Request.QueryString["Sales_ID"].ToString());
        if (dtSales.Rows.Count > 0)
        {
            stockID = dtSales.Rows[0]["stock_id"].ToString();
            chwt = dtSales.Rows[0]["Charged_Weight"].ToString();
            interline = dtSales.Rows[0]["Interline"].ToString();
            carrier = dtSales.Rows[0]["Carrier"].ToString();
        }
        DataTable dt = dw.GetAllFromQuery("SELECT Stock_ID,AirwayBill_no,Flight_No,CONVERT(VARCHAR,Flight_Date,103) AS Flight_Date,Origin_Code,Destination_Code ,Currency,Rate,Amount FROM db_owner.Sales_Trans WHERE Stock_ID=" + stockID);
        if (dt.Rows.Count > 0)
        {
            GenerateRouteTable(dt, chwt,interline,carrier);
        }
    }    
    //Generate Buying Detail Dynamic Route table For Edit
    public void GenerateRouteTable(DataTable dt, string chwt, string interline, string carrier)
    {
        Table table = new Table();
        table.Attributes["border"] = "1";
        table.Attributes["width"] = "90%";
        table.Attributes["cellSpacing"] = "0";
        table.Attributes["cellPadding"] = "0";
        table.Attributes["style"] = "margin:10px 10px 10px 10px; ";
        DataTable dtCurrency = dw.GetAllFromQuery("SELECT DISTINCT CurrencyCode as Currency FROM dbo.CurrencyMaster");
        
       
        TableHeaderRow headerRow = new TableHeaderRow();
        TableCell[] headerCells = new TableCell[7];
        for (int i = 0; i <= headerCells.Length - 1; i++)
        {
            headerCells[i] = new TableCell();
        }
        headerCells[0].Text = "Origin";
        headerCells[1].Text = "Destination";
        headerCells[2].Text = "Rate";
        headerCells[3].Text = "Amount";
        headerCells[4].Text = "Flight No";
        headerCells[5].Text = "Flight Date";
        headerCells[6].Text = "Currency";
        headerRow.Cells.AddRange(headerCells);
        table.Rows.Add(headerRow);
        table.ID = "dynamicRouteTable";
        double amt = 0;
        foreach (DataRow rw in dt.Rows)
        {
            TableRow tr = new TableRow();
            TableCell[] trCells = new TableCell[7];
            for (int j = 0; j <= trCells.Length - 1; j++)
            {
                trCells[j] = new TableCell();
            }

            //DataTable dtRate = dw.GetAllFromQuery("SELECT psr.Price_Value as Rate FROM db_owner.Principle_Rate_Master arm INNER JOIN db_owner.Destination_Master dm ON arm.Destination=dm.Destination_ID INNER JOIN dbo.City_Master cm ON cm.City_ID=arm.Origin inner join db_owner.Principle_Slab_Rate psr on psr.Rate_id=arm.Rate_ID inner join  db_owner.Slab_Master sm on sm.Slab_id=psr.Slab_id where " + chwt + " BETWEEN sm.Slab_Start AND sm.Slab_End and psr.airline_detail_id = (select top 1 ad.airline_detail_id from airline_detail ad inner join airline_master am on am.airline_id=ad.airline_id inner join city_master cm on ad.belongs_to_city=cm.city_id where am.airline_code='" + AwbCode + "' and cm.city_code='" + rw["Origin_Code"].ToString() + "') and dm.destination_code='" + rw["Destination_Code"].ToString() + "' and cm.city_code='" + rw["Origin_Code"].ToString() + "'");
            //if (dtRate.Rows.Count > 0)
            //    rate = Convert.ToDouble(dtRate.Rows[0][0].ToString());

            amt = Convert.ToDouble(rw["Amount"].ToString());
            trCells[0].Text = rw["Origin_Code"].ToString();
            trCells[1].Text = rw["Destination_Code"].ToString();
            //trCells[2].Text = Convert.ToString(rw["Rate"]);
            TextBox rateTextBox = new TextBox();
            rateTextBox.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
            //Non-Interline
            if (interline.Trim().ToUpper() == "N")
            {
                if (rw["Origin_Code"].ToString() == "MIA" || rw["Origin_Code"].ToString() == "AMS" || rw["Origin_Code"].ToString() == "JFK")
                {
                    rateTextBox.Attributes.Add("onFocusOut", "ChangePrinciple(this.id)");
                }
                else
                {
                    rateTextBox.Attributes.Add("onFocusOut", "CalculateAmt(this.id)");
                }
            }
            //interline
            if (interline.Trim().ToUpper() == "Y")
            {
                //sum rate and amount
                rateTextBox.Attributes.Add("onFocusOut", "InterlineCalculateRateAmt(this.id)");
            }
            rateTextBox.Attributes.Add("id", "Rate_" + dt.Rows.IndexOf(rw).ToString());
            rateTextBox.Text = Convert.ToString(rw["Rate"]);
            trCells[2].Controls.Add(rateTextBox);
            //trCells[3].Text = Convert.ToString(Math.Round(amt, 2));
            TextBox amtTextBox = new TextBox();
            amtTextBox.Text = Convert.ToString(rw["Amount"]);
            amtTextBox.Attributes.Add("id", "Amt_" + dt.Rows.IndexOf(rw).ToString());
            amtTextBox.Attributes["disabled"] = "disabled";
            trCells[3].Controls.Add(amtTextBox);
            TextBox flightNo = new TextBox();
            flightNo.Text = rw["Flight_No"].ToString();
            flightNo.TabIndex = 32;
            trCells[4].Controls.Add(flightNo);
            TextBox flightDate = new TextBox();
            flightDate.TabIndex = 33;
            flightDate.Text = rw["Flight_Date"].ToString();
            flightDate.Attributes["class"] = "date-pick dp-applied";
            trCells[5].Controls.Add(flightDate);

            DropDownList currency = new DropDownList();
            currency.TabIndex = 34;
            currency.Attributes["class"] = "text";
            currency.DataSource = dtCurrency;
            currency.DataTextField = "Currency";
            currency.DataValueField = "Currency";
            currency.DataBind();
            currency.SelectedValue = rw["Currency"].ToString();
            trCells[6].Controls.Add(currency);
            tr.Cells.AddRange(trCells);
            table.Rows.Add(tr);          
        }
        phRouteDetail.Controls.Clear();
        phRouteDetail.Controls.Add(table);      
    }
    public void InsertSalesTrans(SqlTransaction trans, SqlConnection con)
    {
        ////if (ViewState["Stock_ID"] != null && Request.QueryString["Sales_ID"] != null)
        ////{
        ////    com = new SqlCommand("DELETE FROM db_owner.Sales_Trans WHERE Stock_ID=" + ViewState["Stock_ID"].ToString(), con, trans);
        ////    com.ExecuteNonQuery();
        ////}
        ////try
        ////{

        ////    if (phRouteDetail.Controls.Count > 0)
        ////    {
        ////        ////////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");

        ////        Table dynamicTable = (Table)Session["table"];
        ////        if (dynamicTable != null)
        ////        {
        ////            int r = 1;
        ////            foreach (TableRow tr in dynamicTable.Rows)
        ////            {
        ////                if (r != 1)
        ////                {
        ////                    com = new SqlCommand("INSERT INTO db_owner.Sales_Trans( Stock_ID ,AirwayBill_no ,Flight_No ,Flight_Date ,Origin_Code,Destination_Code ,Currency ,Rate ,Amount,Carrier,Route,Airline_detail_id)VALUES  ( (SELECT TOP 1 Stock_ID FROM dbo.Stock_Master WHERE AirWayBill_No=@AirwayBill_no),@AirwayBill_no,@Flight_No,@Flight_Date,@Origin_Code,@Destination_Code,@Currency,@Rate,@Amount,@Carrier,@Route,@Airline_detail_id)", con, trans);//spCenturionCargo_InsertSalesTrans
        ////                    //com.CommandType = CommandType.StoredProcedure;
        ////                    com.Parameters.AddWithValue("@AirwayBill_no", ddlAwbNo.SelectedItem.Text);
        ////                    com.Parameters.AddWithValue("@Origin_Code", tr.Cells[1].Text);//for Origin
        ////                    com.Parameters.AddWithValue("@Destination_Code", tr.Cells[2].Text);// For Destination    
        ////                    if (tr.Cells[2].HasControls())
        ////                    {
        ////                        com.Parameters.AddWithValue("@Rate", Convert.ToDouble(((TextBox)tr.Cells[3].Controls[0]).Text));//Rate
        ////                    }
        ////                    else
        ////                    {
        ////                        com.Parameters.AddWithValue("@Rate", Convert.ToDouble(tr.Cells[3].Text));//Rate
        ////                    }
        ////                    double amt = Convert.ToDouble(((TextBox)tr.Cells[3].Controls[0]).Text) * Convert.ToDouble(txtCw.Text);
        ////                    if (tr.Cells[4].HasControls())
        ////                    {
        ////                        com.Parameters.AddWithValue("@Amount", amt);//amount
        ////                    }
        ////                    else
        ////                    {
        ////                        com.Parameters.AddWithValue("@Amount", amt);//amount
        ////                    }
        ////                    com.Parameters.AddWithValue("@Flight_No", ((TextBox)tr.Cells[5].Controls[0]).Text);//flight No
        ////                    com.Parameters.AddWithValue("@Flight_Date", FormatDateMM(((TextBox)tr.Cells[6].Controls[0]).Text));//flight_Date
        ////                    com.Parameters.AddWithValue("@Currency", ((DropDownList)tr.Cells[7].Controls[0]).SelectedValue);//currency

        ////                    com.Parameters.AddWithValue("@Carrier", ((TextBox)tr.Cells[8].Controls[0]).Text);//Carrier

        ////                    com.Parameters.AddWithValue("@Route", ((TextBox)tr.Cells[0].Controls[0]).Text);//Carrier

        ////                    com.Parameters.AddWithValue("@Airline_Detail_id", Convert.ToInt64(ddlAirline.SelectedValue));//Carrier
        ////                    com.ExecuteNonQuery();
        ////                }
        ////                r++;
        ////            }
        ////            Session["table"] = null;

        ////        }
        ////    }

        ////}
        ////catch (SqlException ex)
        ////{

        ////}


        string insert;
        //con = new SqlConnection(strCon);
        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {

            com = new SqlCommand("DELETE FROM db_owner.Sales_Trans WHERE Stock_ID=" + ViewState["Stock_ID"].ToString(), con, trans);
            com.ExecuteNonQuery();
            com.Dispose();
            

            dtDimension = (DataTable)Session["dtTemp"];

            for (int i = 0; i < dtDimension.Rows.Count; i++)
            {

                insert = "INSERT INTO db_owner.Sales_Trans( Stock_ID ,AirwayBill_no ,Flight_No ,Flight_Date ,Origin_Code,Destination_Code ,Currency ,Rate ,Amount,Carrier,Route,Airline_detail_id)VALUES  ( (SELECT TOP 1 Stock_ID FROM dbo.Stock_Master WHERE AirWayBill_No=@AirwayBill_no),@AirwayBill_no,@Flight_No,@Flight_Date,@Origin_Code,@Destination_Code,@Currency,@Rate,@Amount,@Carrier,@Route,@Airline_detail_id)";

                SqlCommand com1 = new SqlCommand(insert, con, trans);
                com1.CommandType = CommandType.Text;
                com1.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = ViewState["Stock_ID"].ToString();
                com1.Parameters.Add("@AirwayBill_no", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text;
                com1.Parameters.Add("@Origin_Code", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Origin_Code"].ToString();
                com1.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Destination_Code"].ToString();
                com1.Parameters.Add("@Rate", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Rate"].ToString();
                com1.Parameters.Add("@Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(Convert.ToDecimal(dtDimension.Rows[i]["Rate"].ToString()) * Convert.ToDecimal(txtCw.Text));
                com1.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Flight_No"].ToString();
                com1.Parameters.Add("@Flight_Date", SqlDbType.Date).Value = Convert.ToDateTime(FormatDateDD(dtDimension.Rows[i]["Flight_Date"].ToString()));
                com1.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Currency"].ToString();
                com1.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Carrier"].ToString();
                com1.Parameters.Add("@Route", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Route"].ToString();
                com1.Parameters.Add("@Airline_Detail_id", SqlDbType.Int).Value = Convert.ToInt64(ddlAirline.SelectedValue);
               com1.ExecuteNonQuery();
            }
        }


    }
    protected void btnChangePrincipal_Click(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtPRate.Text = hdnRate.Value;
            if (txtPSpotRate.Text == "" || txtPSpotRate.Text == "0.00" || txtPSpotRate.Text == "0")
            {
                txtPAmount.Text = hdnAmt.Value;
            }
        }

    }
    public void SetPrincipalToDefault()
    {
        txtPRate.Text = "0";

        if (txtPSpotRate.Text == "" || txtPSpotRate.Text == "0.00" || txtPSpotRate.Text == "0")
        {
            txtPAmount.Text = "0";
        }
    }
    //================================================End==========================================
    protected DataTable MakeTableCharges()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "Sno";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "FeeName";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "Fee";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "PaymentType";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        DataRow dr = dt.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dt.Rows.Add(dr);
        //*******Added on 3 may 2011(Only to show zero on displaying grd-grid)*********
        Session["dtdisplayChargesZero"] = dt;
        //********End***********************

        return dt;
        //Session["dtOtherCharges"] = dt;
        //ViewState["dtBeginCharges"] = dt;

    } 
  
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                ////int Pieces = 0;
                ////decimal VoulmeWt = 0;
                ////foreach (DataRow rw in dt.Rows)
                ////{
                ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                ////}
                ////str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                ////txtPieces.Text = Pieces.ToString();
                ////if (txtGw.Text != "")
                ////{
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////    if (decimal.Parse(txtGw.Text) > VoulmeWt)
                ////    {
                ////        txtCw.Text = txtGw.Text;
                ////    }
                ////    else
                ////    {
                ////        txtCw.Text = VoulmeWt.ToString();
                ////    }
                ////}
                ////else
                ////{
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////}
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            ///////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
        }
        else
        {
            maketable();
            DataTable dtBeginCharges = (DataTable)ViewState["dtBeginCharges"];
            Session["dtTemp"] = dtBeginCharges;
            grdCal.DataSource = dtBeginCharges;
            grdCal.DataBind();
        }


    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
 
    protected void lnkCal_Click(object sender, EventArgs e)
    {
        grdCal.Visible = true;
        rbCal.Visible = true;
    }
    protected void grdCal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    #region Insert_BookingDimesion
    public void Insert_BookingDimesion(SqlTransaction tr, SqlConnection con, long SalesID)
    {
        //string insert;
        ////con = new SqlConnection(strCon);
        //DataTable dtDimension = new DataTable();
        //if (Session["dtTemp"] != null)
        //{
        //    dtDimension = (DataTable)Session["dtTemp"];

        //    for (int i = 0; i < dtDimension.Rows.Count; i++)
        //    {

        //        insert = "insert into Sales_Dimensions(Sales_ID,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit) values(@Sales_ID,@No_of_Packages,@Length,@Breadth,@Height,@Total,@Measurement_Unit)";

        //        SqlCommand com = new SqlCommand(insert, con, tr);
        //        com.CommandType = CommandType.Text;
        //        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        //        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
        //        com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
        //        com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
        //        com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
        //        com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
        //        if (rbCal.SelectedValue == "")
        //        {
        //            com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = "CM";
        //        }
        //        else
        //        {
        //            com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = rbCal.SelectedValue;
        //        }
        //        com.ExecuteNonQuery();
        //    }
        //}
    }
    #endregion
    #region Update_BookingDimesion
    public void Update_BookingDimesion(SqlTransaction tr, SqlConnection con, long SalesID)
    {
        string update;

        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {
            dtDimension = (DataTable)Session["dtTemp"];

            for (int i = 0; i < dtDimension.Rows.Count; i++)
            {


                update = "update Sales_Dimensions set Sales_ID=@Sales_ID,No_of_Packages=@No_of_Packages,Length=@Length,Breadth=@Breadth,Height=@Height,Total=@Total,Measurement_Unit=@Measurement_Unit where Sales_ID=@Sales_ID";

                SqlCommand com = new SqlCommand(update, con, tr);
                com.CommandType = CommandType.Text;
                ////com.Parameters.Add("@Sales_Dimension_ID", SqlDbType.Int).Value = SalesID;
                com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
                com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
                com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
                com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
                com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
                if (rbCal.SelectedValue == "")
                {
                    com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = "CM";
                }
                else
                {
                    com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = rbCal.SelectedValue;
                }
                com.ExecuteNonQuery();

            }
        }
    }
    #endregion
    public void FillSalesFields()
    {
       
        Invtext.Visible = true;
        InvValue.Visible = true;
        string SalesID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            SalesID = Request.QueryString["Sales_ID"];
        }
        DateTime CurrentDate = DateTime.Now;
        string strCurrentDate = CurrentDate.ToShortDateString();
        txtCSRDate.Text = FormatDateDD(strCurrentDate);

        //*****************Added On 28 Apr 2011   (Invoice No picked)  ******************
        DataTable dtinvoice = dw.GetAllFromQuery("SELECT s.Invoice_No,ino.Prifix,ino.Fin_Year FROM db_owner.Invoice_No ino INNER JOIN db_owner.Sales s ON ino.SNo=s.Invoice_SNO WHERE Sales_ID=" + SalesID);
       ////// lblInvoiceNo.Text = dtinvoice.Rows[0]["Prifix"].ToString() + "/" + dtinvoice.Rows[0]["Fin_Year"].ToString() + "/" + dtinvoice.Rows[0]["Invoice_No"].ToString();   

        lblInvoiceNo.Text = "12334";

        //******************End Of invoice No***************************
        DataTable dtSales = dw.GetAllFromQuery("SELECT * FROM Sales where Sales_ID=" + SalesID);
        if (dtSales.Rows.Count > 0)
        {
            //*************************Added on 27 feb 2017 : Added new colum HB as Hard block shipment in PH system ************//

            ddlHB.SelectedValue = dtSales.Rows[0]["HB"].ToString();

            //************************End of HB shipment*************************************************************************//

            //=========================Added By :Pradeep Sharma=================
            #region if Route Available
            if (phRouteDetail.Controls.Count > 0)
            {            
              
                //if (Convert.ToString(ViewState["GroupID"]) != "13" && dtSales.Rows[0]["AirWayBill_No"].ToString().Split('-')[0] == "307")
                //{
                if (dtSales.Rows[0]["AirWayBill_No"].ToString().Split('-')[0] == "435")
                {
                    trBuyingDetails.Visible = true; 
                    trRoutingDetails.Visible = true;
                    ////trhide.Visible = true;
                   
                }
                else
                {
                    trBuyingDetails.Visible = false; ;
                    trRoutingDetails.Visible = false;
                }
                fillddl(dtSales.Rows[0]["Interline"].ToString());
                   ///// Route_type.Visible = true;
                    //////PnlCarrier.Visible = true;
                    RouteEnter.Visible = true;
                    lblOrigin.Text = dtSales.Rows[0]["City_Code"].ToString();
                    txtCenturionRoute.Text = dtSales.Rows[0]["Inner_Route"].ToString().Substring(4, dtSales.Rows[0]["Inner_Route"].ToString().Length - 8);
                    lblDestination.Text = dtSales.Rows[0]["Destination_Code"].ToString();
                }
            if (dtSales.Rows[0]["Gateway"].ToString().TrimEnd() != "N/A")
                {
                ///////////.Start:..........Mofify by Hemant Sharma on 8 Oct 2014.........///////////////////////////
                   ///// rbtnGateWay.SelectedValue = dtSales.Rows[0]["Gateway"].ToString().TrimEnd();
                    ///////////End:..........Mofify by Hemant Sharma on 8 Oct 2014.........///////////////////////////


                    //for (int r = 0; r < rbtnGateWay.Items.Count; r++)
                    //{
                    //    if ((rbtnGateWay.Items[r].ToString()) == (dtSales.Rows[0]["Gateway"].ToString().TrimEnd()))
                    //    {
                    //        rbtnGateWay.SelectedIndex = r;
                    //        break;

                    //    }
                    //    else if ((rbtnGateWay.Items[r].ToString()) == (dtSales.Rows[0]["Gateway"].ToString().TrimEnd()))
                    //    {
                    //        rbtnGateWay.SelectedIndex = r;
                    //        break;
                    //    }
                    //    else if ((rbtnGateWay.Items[r].ToString()) == (dtSales.Rows[0]["Gateway"].ToString().TrimEnd()))
                    //    {
                    //        rbtnGateWay.SelectedIndex = r;
                    //        break;
                    //    }

                    //} 
                ////if (dtSales.Rows[0]["Interline"].ToString() == "Y")
                ////    {
                ////        selCarrier.SelectedValue = dtSales.Rows[0]["Carrier"].ToString();
                ////        ////rbtnRouteType1.Checked = true;
                ////    }
                ////    else
                ////    {
                ////        selCarrier.SelectedValue = dtSales.Rows[0]["Carrier"].ToString();
                ////        ////rbtnRouteType2.Checked = true;
                ////    }
                }        
                
            }
            #endregion

            DataTable dtAirlineID = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + dtSales.Rows[0]["Airline_Detail_Id"].ToString() + "");
            LoadACS();
            ddlAgentName.SelectedValue = dtSales.Rows[0]["Agent_Id"].ToString();
            ddlAgentName.Enabled = false;
            LoadUserOrigin();
            ddlOrigin.SelectedValue = dtSales.Rows[0]["City_ID"].ToString();
            UserAirlineNamePlusCode();
            ddlAirline.SelectedValue = dtSales.Rows[0]["Airline_Detail_Id"].ToString();
            LoadDestination();
            ddlDestination.SelectedValue = dtSales.Rows[0]["Destination_Id"].ToString();
            txtRoute.Text = dtSales.Rows[0]["Routing"].ToString();
            //////txtTruckchrgs.Text = dtSales.Rows[0]["Trucking_chrgs"].ToString();
            //////txtTruckShareChrgs.Text = dtSales.Rows[0]["Truckingchrgs_Share"].ToString();
            //////txtHandlingChrgs.Text = dtSales.Rows[0]["Handling_Chrgs"].ToString();
            if (dtAirlineID.Rows[0]["Airline_ID"].ToString() == "2")
            {
                lblrate.Visible = false;
                txtrate.Visible = false;
            }
            else
            {

                txtUSDToPHP.Text = dtSales.Rows[0]["ConversionRateToPHP"].ToString();

            }
            txtCSRRemarks.Text = dtSales.Rows[0]["csr_remarks"].ToString();
            LoadFlight();
         /////string temapVal = ddlAirline.SelectedItem.Text.Substring(0,9).TrimStart();

            string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
         if (temapVal == "PREMIER")
        {      
           
            ddlfltNo.SelectedItem.Text = dtSales.Rows[0]["flight_no"].ToString();
            tdflighNo.Visible = false;
            ddlfltNo.Visible = false;
        }
        else
        {
            ddlfltNo.SelectedItem.Text = dtSales.Rows[0]["flight_no"].ToString();
            tdflighNo.Visible = true;
            ddlfltNo.Visible = true;
        }
            LoadAgentStock();
            ViewState["Stock_ID"] = dtSales.Rows[0]["Stock_ID"].ToString();
            ViewState["City_ID"] = dtSales.Rows[0]["City_ID"].ToString();
            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select AirWayBill_No,Agent_ID from stock_Master where Stock_ID=" + dtSales.Rows[0]["Stock_ID"].ToString());
            DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + dtAirWayBillNo.Rows[0]["Agent_ID"].ToString());
            if (dtAgent.Rows.Count > 0)
            {
                ViewState["Agent_ID"] = dtAirWayBillNo.Rows[0]["Agent_ID"].ToString();
                ddlAgentName.SelectedItem.Text = dtAgent.Rows[0]["Agent_Name"].ToString();
            }

            if (dtAirWayBillNo.Rows.Count > 0)
            {
                ddlAwbNo.SelectedItem.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
                string AirlineCode = ddlAwbNo.SelectedItem.Text.Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
                //**************Added on 16 Nov 2010*******************************
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Belongs_To_City=" + ViewState["City_ID"].ToString());
                DataTable dtOriginatedAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Belongs_To_City=" + ViewState["City_ID"].ToString());

                if (dtOriginatedAirlineDetail.Rows.Count > 0 || dtOriginatedAirlineDetail != null)
                {
                    ViewState["Originated_Airline_Detail_ID"] = dtOriginatedAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
                }
                long City_ID = long.Parse(dtSales.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                DataTable dtCity = dw.GetAllFromQuery("select City_ID,City_Code,City_Name from City_Master where City_ID=" + dtSales.Rows[0]["City_ID"].ToString());
                if (dtCity.Rows.Count > 0)
                {
                    ////txtOrigin.Text = dtCity.Rows[0]["City_Code"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString();
                    ddlOrigin.SelectedValue = dtCity.Rows[0]["City_ID"].ToString();
                }
                DataTable dtBooking_City = dw.GetAllFromQuery("select City_Code,City_Name from City_Master where City_ID=" + dtSales.Rows[0]["Booking_City_ID"].ToString());
                if (dtBooking_City.Rows.Count > 0)
                {
                    ////////////txtBooking_Origin.Text = dtBooking_City.Rows[0]["City_Code"].ToString() + "-" + dtBooking_City.Rows[0]["City_Name"].ToString();
                    ViewState["Booking_City_Id"] = dtSales.Rows[0]["Booking_City_ID"].ToString();
                }



                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    ViewState["AirlineDetailID"] = AirlineDetailID;
                }
            }
            ///////////fillOtherCharges(ViewState["Booking_ID"].ToString());
            LOAD_SCD();
            int i = CheckSubAgentStatus(Convert.ToInt32(ViewState["Agent_ID"].ToString()));
            ViewState["SubAgentStatus"] = i >= 1 ? "Y" : "N"; 
            if (i >= 1)
            {
                trSubagent.Visible = true;
                txtSubAgentName.Text = dtSales.Rows[0]["SubAgent_Name"].ToString();
                txtSubAgent_address.Text = dtSales.Rows[0]["SubAgent_Adress"].ToString();
            }
            ddlDestination.SelectedValue = dtSales.Rows[0]["Destination_ID"].ToString();
            ddlShipmentType.SelectedValue = dtSales.Rows[0]["Shipment_ID"].ToString();
            ddlScr.SelectedValue = dtSales.Rows[0]["Special_Commodity_ID"].ToString();
            DateTime AWB_Date = DateTime.Parse(dtSales.Rows[0]["AWB_Date"].ToString());
            txtAWBDate.Text = FormatDateDD(AWB_Date.ToShortDateString());
            ViewState["Flight_Open_ID"] = dtSales.Rows[0]["Flight_Open_ID"].ToString();
            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtSales.Rows[0]["Flight_Open_ID"].ToString());
            if (dtFlight.Rows.Count > 0)
            {
                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

                if (dtFlightNo.Rows.Count > 0)
                {
                    //txtFlightNo.Text = dtFlightNo.Rows[0]["Flight_No"].ToString();
                }
            }

            ////ddlfltNo.SelectedItem.Text = dtSales.Rows[0]["Flight_No"].ToString();
            DateTime FlightDate = Convert.ToDateTime(dtSales.Rows[0]["Flight_Date"].ToString());
            txtFlightDate.Text = FormatDateDD(FlightDate.ToShortDateString());
            txtShipper.Text = dtSales.Rows[0]["Shipper_Name"].ToString();
            txtShipperAddress.Text = dtSales.Rows[0]["Shipper_Address"].ToString();
            txtConsignee.Text = dtSales.Rows[0]["Consignee_Name"].ToString();
            txtConsigneeAddress.Text = dtSales.Rows[0]["Consignee_Address"].ToString();

            txtPieces.Text = dtSales.Rows[0]["No_of_Packages"].ToString();
            txtVolwt.Text = dtSales.Rows[0]["Volume_Weight"].ToString();
            txtGw.Text = dtSales.Rows[0]["Gross_Weight"].ToString();
            txtCw.Text = dtSales.Rows[0]["Charged_Weight"].ToString();

            rbFType.SelectedValue = dtSales.Rows[0]["Freight_Type"].ToString();

            //////txtTrfRate.Text = dtSales.Rows[0]["Tariff_Rate"].ToString();
            //////txtTariffFrtAmt.Text = dtSales.Rows[0]["Freight_Amount"].ToString();

            //////txtTariffRate.Text = dtSales.Rows[0]["Selling_Rate"].ToString();
            //////txtSpAmt.Text = dtSales.Rows[0]["SellingFrtAmt"].ToString();
            if (dtSales.Rows[0]["SellingRate_MinStatus"].ToString() == "13")
            {
                CheckTariff.Checked = true;
            }
            else
            {
                CheckTariff.Checked = false;
            }
            //****Modify by Hemant Sharma on 10'th Oct 2013****////
            //DataTable dttxtawbfee = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue+ "");
            if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
            {
                if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
                {
                    lblawbfee.Visible = true;
                    txtAwbfee.Visible = true;
                    txtAwbfee.Text = (dtSales.Rows[0]["AWB_Fees"].ToString() == "" ? 0 : decimal.Parse( dtSales.Rows[0]["AWB_Fees"].ToString())).ToString();
                }
                else
                {
                    lblawbfee.Visible = false;
                    txtAwbfee.Visible = false;
                    txtAwbfee.Text = null;

                }
            }
            else
            {
                txtAwbfee.Text = null;

            }
            txtTrfRate.Text = dtSales.Rows[0]["Selling_Rate"].ToString();
            txtTariffFrtAmt.Text = dtSales.Rows[0]["SellingFrtAmt"].ToString();

            txtTariffRate.Text = dtSales.Rows[0]["Tariff_Rate"].ToString();
            txtSpAmt.Text = dtSales.Rows[0]["Freight_Amount"].ToString();
            DataTable dtFix_Charges = dw.GetAllFromQuery("select * from fix_charges where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            {
                if (dtFix_Charges.Rows.Count > 0)
                {
                    hndXray_fixCharges.Value = dtFix_Charges.Rows[0]["Min_XRay_Charges"].ToString();
                }
            }
            //*********** From Sales Table***************
            DataTable dtSalesField = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
            if (dtSalesField.Rows.Count > 0)
            {

                if (dtSalesField.Rows[0]["Agent_Min_Status"].ToString() == "13")
                {
                    ChkMinAgent.Checked = true;
                }
                else
                {
                    ChkMinAgent.Checked = false;
                }

                ////if (decimal.Parse(txtCw.Text) < 45)
                ////{
                ////    //15% less of tarrif Rate in Spot Rate(only in case of Min and Normal)
                ////    txtSpotRate.Text = Convert.ToString(Math.Round((decimal.Parse(txtTariffRate.Text) - (decimal.Parse(txtTariffRate.Text)*15/100)),2));
                ////}


                ////////txtIATACommission.Text = dtSalesField.Rows[0]["Commission"].ToString();
                //////////// txtSCR_Incentive.Text = dtSalesField.Rows[0]["Special_Commodity_Incentive"].ToString();

                //*****************Added ON 29_Sep_2010************New column Value 'Deal colour'
                ///////////// ddlDealColour.SelectedValue = dtSalesField.Rows[0]["Deal_Colour"].ToString();
                //******************End***********************************************************



                //////txtdepart_Airport.Text = dtSalesField.Rows[0]["City_Code"].ToString();

                txtdepart_Airport.Text = dtSalesField.Rows[0]["DeptAirportOrg"].ToString();

                if (dtSalesField.Rows[0]["Principle_Min_Status"].ToString() == "13")
                {
                    ChkMinAirline.Checked = true;
                }
                else
                {
                    ChkMinAirline.Checked = false;
                }



                txtPRate.Text = dtSalesField.Rows[0]["Principle_Rate"].ToString();
                txtPAmount.Text = dtSalesField.Rows[0]["Principle_Amount"].ToString();

                txtPSpotRate.Text = dtSalesField.Rows[0]["Principle_Spot_Rate"].ToString();
                txtSpotRateRemarks.Text = dtSalesField.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
                ///////////txtRemarks.Text = dtSalesField.Rows[0]["Other_Remarks"].ToString();
            }
            //*********End From Sales Table***************

            //********Added on 21 June 2011 :EURtoGBP_Exchange Rate*******
            txtUSDToPHP.Text = dtSales.Rows[0]["ConversionRateToPHP"].ToString();
            //**********END of ExchangeRate*******************************


        }    
    public DataSet ConvertXMLToDataSet(StringBuilder xmlData)
    {
        StringReader stream = null;
        XmlTextReader reader = null;
        try
        {
            string s1 = @"<?xml version=""1.0"" encoding=""UTF-8""?><tabledata xmlns:sql=""urn:schemas-microsoft-com:xml-sql"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">";
            string s2 = @"</tabledata>";
            DataSet xmlDS = new DataSet();
            stream = new StringReader(s1 + xmlData.ToString() + s2);
            reader = new XmlTextReader(stream);
            xmlDS.ReadXml(reader);
            return xmlDS;
        }
        catch
        {
            return null;
        }
        finally
        {
            if (reader != null) reader.Close();
        }
    }
    public void LOAD_SCD()
    {
        try
        {
            con = new SqlConnection(strCon);
            com = new SqlCommand("LOAD_SCD", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            StringBuilder xmlData = new StringBuilder(dt.Rows[0]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlShipmentType, "Shipment_Master", "Shipment_Name", "Shipment_ID");
            xmlData = new StringBuilder(dt.Rows[1]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlScr, "Special_Commodity_Master", "Special_Commodity_Name", "Special_Commodity_ID");
            xmlData = new StringBuilder(dt.Rows[2]["Data"].ToString());
            ////////ddlDestination.DataSource = ConvertXMLToDataSet(xmlData).Tables[0];
            ////////ddlDestination.DataTextField = "Destination";
            ////////ddlDestination.DataValueField = "Destination_ID";
            ////////ddlDestination.DataBind();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadCommodity()
    {
        try
        {
            string strAgent = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlScr.Items.Insert(0, "- -Select- -");
            ddlScr.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadShipmentType()
    {
        try
        {
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlShipmentType.Items.Insert(0, "- -Select- -");
            ddlShipmentType.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlShipmentType.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataTable dtCompany = dw.GetAllFromQuery("select Company_ID from Airline_Detail where Airline_Detail_ID=" + ddlAirline.SelectedValue);
        if (dtCompany.Rows.Count > 0)
        {
            ViewState["CompanyID"] = dtCompany.Rows[0]["Company_ID"].ToString();
        }

        DataTable dtStock_Id = dw.GetAllFromQuery("Select Stock_Id from Stock_Master where Airwaybill_No='" + ddlAwbNo.SelectedItem.Text + "'");
        if (dtStock_Id.Rows.Count > 0)
        {
            ViewState["Stock_ID"] = dtStock_Id.Rows[0]["Stock_ID"].ToString();
        }
        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction tranupdate = con.BeginTransaction();
        DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Sales where AirWayBill_No='" + ddlAwbNo.SelectedItem.Text.Trim() + "'");
        if (dtAWBCheck.Rows.Count <= 0)
        {
            try
            {
                long SalesID = 0;
                Insert_Sales(tranupdate, con);
                InsertSalesTrans(tranupdate, con);
                DataTable dtSalesID = dw.GetAllFromQuery("select ident_current('Sales') as SalesID");
                SalesID = long.Parse(dtSalesID.Rows[0]["SalesID"].ToString());
               Update_AWBDate(tranupdate, con);
               Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());
                //*****************Added For Dimensions*************************
                DataTable dtTemp = new DataTable();
                if (Session["dtTemp"] != null)
                {
                    dtTemp = (DataTable)Session["dtTemp"];
                    if (dtTemp.Rows[0]["SNo"].ToString() == "0")
                    {
                        dtTemp.Rows[0].Delete();
                    }
                }
                if (dtSalesID.Rows.Count > 0 && dtTemp.Rows.Count > 0)
                {
                   Insert_BookingDimesion(tranupdate, con, SalesID);

                }

                //****************END*******************************************
                tranupdate.Commit();
                con.Close();

                //******************Added On 15 oct 2011 For FFR:EDI CODE to ACCS********************
                DataTable dtAWBConfirm = dw.GetAllFromQuery("select * from Sales where AirWayBill_No='" + ddlAwbNo.SelectedItem.Text.Trim() + "'");


                if (dtAWBConfirm.Rows.Count > 0)
                {

                    ////////////////EDICommunication(dtAWBConfirm.Rows[0]["AirWayBill_No"].ToString());
                }
                //******************End**************************************************************
                ////////////Label1.Text = Label1.Text.Replace("\n", " ");
                ////////////string strScript1 = "alert('" + Label1.Text + "');location.replace('salesEdit.aspx');";
                ////////////ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox1", strScript1, true);
                /////Response.Redirect("salesEdit.aspx");
                string strScript = "alert('Sales added sucessfully');location.replace('salesEdit.aspx');";
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Save", strScript, true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                tranupdate.Rollback();
                Label1.Visible = true;
                Label1.Text = ex.Message;
  }
 //////Response.Redirect("salesEdit.aspx");
        }
        else
        {
            lblSales.Visible = true;
        }
 }
    #region Update_AWBDate
    public void Update_AWBDate(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Stock_Master set Used_Date='" + FormatDateMM(txtAWBDate.Text) + "'" + "  where Stock_ID=" + ViewState["Stock_ID"].ToString();
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }
    #endregion
    #region Update_Stock
    public void Update_Stock(SqlTransaction tr, SqlConnection con, string StockID)
    {
        string update;

        update = "update Stock_Master set Status=11" + "  where Stock_ID=" + StockID;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion
    #region Insert_Sales
    public void Insert_Sales(SqlTransaction tr, SqlConnection con)
    {
        #region Generate Invoice No

        string Flight_date = txtFlightDate.Text;
        string[] dateSplit = Flight_date.Split('/');
        string Month = dateSplit[1].ToString();
        string Year = dateSplit[2].ToString();
        string Date1 = dateSplit[0].ToString();
        string currentdate = Month + "/" + Date1 + "/" + Year;
        string FinYear = Year.Substring(2, 2);
        // string dateCurrent = DateTime.Now.ToShortDateString();

        DateTime CurrDate = Convert.ToDateTime(currentdate);
        //****************Updated on 16 Apr 2018 as New year from Jan i/o Apr
        ////string DateFinancial = "4/1/20" + FinYear + "";
        string DateFinancial = "1/1/20" + FinYear + "";
        //****************End of Updated on 16 Apr 2018 as New year from Jan i/o Apr
        DateTime FinanciaDate = DateTime.Parse(DateFinancial);

        //****************Updated on 16 Apr 2018 as year 2018 i/o 2017-18
        ////if (CurrDate < FinanciaDate)
        ////{
        ////    //****************Updated on 16 Apr 2018 as year 2018 i/o 2017-18
        ////    ////FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
        ////    FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1);
        ////    //****************End of Updated on 16 Apr 2018 as year 2018 i/o 2017-18
        ////}
        ////else
        ////{
        ////    //****************Updated on 16 Apr 2018 as year 2018 i/o 2017-18
        ////    ////FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
        ////    FinYear = "20" + FinYear;
        ////    //****************End of Updated on 16 Apr 2018 as year 2018 i/o 2017-18
        ////}

        
        FinYear = "20" + FinYear;
        //****************End of Updated on 16 Apr 2018 as year 2018 i/o 2017-18
        //*********************End***************************************************************

        //*******************End****************************************

             string Lastdate = "";
        bool flagInvoice = false;
        if (int.Parse(Date1) < 16)
        {
            Date1 = "1";
            flagInvoice = true;
        }
        else
        {
            Date1 = "16";
        }

        //for (int year = 2006; year <= DateTime.Today.Year; year++)
        //    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
        // string Year = DateTime.Today.Year.ToString();

        string startDate = Month + "/" + Date1 + "/" + Year;
        string endDate = Month + "/" + (flagInvoice ? "15" : (Convert.ToDateTime(Month + "/1/" + Year).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + Year;

        ////DataTable dtInvPrFx = dw.GetAllFromQuery("select prifix from Invoice_no where airline_detail_id=" + ddlAirline.SelectedValue + "");

        ///**************************************end of invoice function **********************************
        #endregion

        string insert;
        //****Modify by Hemant Sharma on 10'th Oct 2013****////
        //*****************Added on 27 Feb 2017 : New column in Table HB*******************//
        ////insert = "insert into Sales(Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route) values(@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route)";
        insert = "insert into Sales(Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route,HB) values(@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route,@HB)";
        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        //======================In Case of PREMIER TRANS AIRE flight no insert by grid:pradeep sharma============== 
     
        //if (phRouteDetail.Controls.Count > 0)
        //{
            
        //    //////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");

        //    Table dynamicTable = (Table)Session["table"];
        //    if (dynamicTable != null)
        //    {               int r=1;
        //        int tempval = 0;
        //        string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
        //        foreach (TableRow tbr in dynamicTable.Rows)
        //        {
        //            if (r != 1 && temapVal == "PREMIER" && tempval == 0)
        //            {
        //                com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[5].Controls[0]).Text;
        //                ViewState["GridFlightNo"] = ((TextBox)tbr.Cells[5].Controls[0]).Text;
        //                tempval++;
                       
        //            }
        //            r++;
        //        }
        //    }
        //}
        //else
        //{

           //     string name = grdCal.SelectedRow.Cells[0].Text;
 
        //Accessing TemplateField Column controls
       // string txtfltno = (grdCal.SelectedRow.FindControl("txtfltno") as TextBox).Text;

       
        TextBox txtfltno = (TextBox)grdCal.Rows[0].Cells[5].FindControl("txtfltno");

        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = txtfltno.Text; //"WE-123";

        //////}
        if (ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart() == "PREMIER")
        {
            //string tempval = ViewState["GridFlightNo"].ToString();
            //DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + tempval + "') ");

            ////com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = 1234;
            string dest = "";
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
            if (dtDestination.Rows.Count > 0)
            {
                dest = dtDestination.Rows[0]["Destination_Code"].ToString();
            }

            com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dest;
            com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = ddlDestination.SelectedValue;
            //DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            //if (dtSectorDest.Rows.Count > 0)
            //{
            //    com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

            //    com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            //}
            //else
            //{
                //com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = "";

                //com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            //}

        }
        else
        {

            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + ddlfltNo.SelectedItem.Text + "') ");
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString());
            DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            if (dtSectorDest.Rows.Count > 0)
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            }
            else
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = ddlDestination.SelectedValue; 

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            }
        }
        //=======================END==============================================
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        string strOrgin = "";
        DataTable dtOrigin = dw.GetAllFromQuery("select city_Code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strOrgin = dtOrigin.Rows[0]["city_Code"].ToString();
        }
        #region For BuyingDetails
        //==============Added By:Pradeep Sharma===========================
        ////if (Convert.ToString(ViewState["GroupID"]) != "13" )
        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            string  Inter_NonInterline = "";
           
            ////if (rbtnRouteType1.Checked)///Interline
            ////{
            ////    Inter_NonInterline = "Y";
                
            ////}
            ////////if (rbtnRouteType2.Checked)//Non-Interline
            ////{
            ////    Inter_NonInterline = "N";
                
            ////}
            //////com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = selCarrier.SelectedValue;
            /////com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = rbtnGateWay.SelectedValue;
           /////// com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = Inter_NonInterline;
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value ="Y";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;
        }
        else
        {
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
        }
        #endregion
        ////strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = "";
        DataTable dtDest = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strDestination = dtDest.Rows[0]["Destination_Code"].ToString();
        }
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "USD";
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        #region Generating CSR Serial Auto Number
        string CSR_Date;
        CSR_Date = (txtFlightDate.Text);
        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";
        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }

        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ddlAgentName.SelectedValue + " and Airline_Detail_ID=" + ddlAirline.SelectedValue + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ddlAirline.SelectedValue + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion
        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtcity_Code.Rows.Count > 0)
        {

            com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
        }

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //******************Added on 29_Sep_2010**********************************
        ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value = ddlDealColour.SelectedValue;
        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));
        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));
        ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        //****Modify by Hemant Sharma on 10'th Oct 2013****////
           DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
        if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
        {
        //if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
        //{
        //    if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
        //    {
                com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAwbfee.Text;
            //}
            //else
            //{
            //    com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = null;

            //}
        }
        else
        {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

        }
        //com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(hdninvno.Value);
        //com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(hdnInvsno.Value);
        com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
       
        com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        if (CheckTariff.Checked == true)
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        }
        //************added on 27 Feb 2017 : New column HB***************//
        com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        //************End of 27 Feb 2017 : New column HB***************//
    //============================== Sub agent ===================================//
        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y"?txtSubAgentName.Text:(object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
         com.ExecuteNonQuery();
        #region Invoiceno Generation
        DataTable dtInvoiceNo = new DataTable();
        //con = new SqlConnection(strCon);
        //con.Open();
        SqlCommand cmd;
        cmd = new SqlCommand("InsertInvoiceno", con, tr);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@agent_id ", SqlDbType.BigInt).Value = int.Parse(ddlAgentName.SelectedValue);
        cmd.Parameters.Add("@startDate ", SqlDbType.VarChar).Value = startDate;
        cmd.Parameters.Add("@endDate ", SqlDbType.VarChar).Value = endDate;
        cmd.Parameters.Add("@Fin_Year ", SqlDbType.VarChar).Value = FinYear;
        cmd.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        cmd.Parameters.Add("@AirlineID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
         cmd.ExecuteNonQuery();
        #endregion
    }
    #endregion
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void ddlScr_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    #region Edit_Sales
    public void Edit_Sales(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;
        //****Modify by Hemant Sharma on 10'th Oct 2013****//// 
        update = "update Sales set CSR_SNo=@CSR_SNo,Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_Name=@Shipment_Name,Shipment_ID=@Shipment_ID,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Approved_for_CSR=@Approved_for_CSR,Sales_Added_Date=@Sales_Added_Date,Agent_Min_Status=@Agent_Min_Status,CSR_Remarks=@CSR_Remarks,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Last_Modified_By=@Last_Modified_By,Last_Modified_On=@Last_Modified_On,Booking_City_ID=@Booking_City_ID,Booking_City_Code=@Booking_City_Code,Originated_Airline_Detail_ID=@Originated_Airline_Detail_ID,ConversionRateToPHP=@ConversionRateToPHP,Selling_Rate=@Selling_Rate,SellingFrtAmt=@SellingFrtAmt,Routing=@Routing,DeptAirportOrg=@DeptAirportOrg,Total_DueCarrier=@Total_DueCarrier,spot_rate=@spot_rate,SellingRate_MinStatus=@SellingRate_MinStatus,SubAgent_Name=@SubAgent_Name,SubAgent_Adress=@SubAgent_Adress,AWB_Fees=@AWB_Fees,Gateway=@Gateway,Interline=@Interline,Inner_Route=@Inner_Route,Carrier=@Carrier,HB=@HB where Sales_ID=@Sales_ID";
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(SalesID);
        #region Generating CSR Serial Auto Number
        string CSR_Date;
        CSR_Date = (txtFlightDate.Text);
        //if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297")
        //{
        //    CSR_Date = (txtFlightDate.Text);

        //}
        //else
        //{
        //     CSR_Date = (txtAWBDate.Text);
        //}
        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }

        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ddlAgentName.SelectedValue + " and Airline_Detail_ID=" + ddlAirline.SelectedValue + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ddlAirline.SelectedValue + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion


        //======================In Case of PREMIER TRANS AIRE flight no insert by grid:pradeep sharma============== 

        if (phRouteDetail.Controls.Count > 0)
        {
            ////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");
            Table dynamicTable = (Table)Session["table"];
            if (dynamicTable != null)
            {
                int r = 1;
                int tempval = 0;
                string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
                foreach (TableRow tbr in dynamicTable.Rows)
                {
                    if (r != 1 && temapVal == "PREMIER" && tempval == 0)
                    {
                        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[4].Controls[0]).Text;
                        tempval++;

                    }
                    r++;
                }
            }
        }
        else
        {
            com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();

        }
        //=======================END==============================================

        DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");

        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
        }
        else
        {
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        }
        //com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
        string Sales_ID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            Sales_ID = Request.QueryString["Sales_ID"];
        }
        DataTable dtSales_ID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + Sales_ID);
        if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
        }
        else
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        }
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        //com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["Booking_City_Id"].ToString()); 

        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


        string strOrgin = "";
        DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtcity_Code.Rows.Count > 0)
        {
            strOrgin = dtcity_Code.Rows[0]["city_code"].ToString();
        }
        ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;

        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;

        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;

        string strDestination = "";

        DataTable dtDest_Code = dw.GetAllFromQuery("select Destination_code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
        if (dtDest_Code.Rows.Count > 0)
        {
            strDestination = dtDest_Code.Rows[0]["Destination_code"].ToString();
        }
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        ////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        {
            com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 28;
        }
        else
        {
            com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 29;
        }
        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = status;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@CSR_Remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Last_Modified_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Last_Modified_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        DataTable dtcity = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtcity_Code.Rows.Count > 0)
        {
            com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity.Rows[0]["city_code"].ToString();
        }
        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        //**********************************Added On 29_Sep_2010*******************
        ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value =ddlDealColour.SelectedValue;
        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));

        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

        ////////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));


        //////////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


       

        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));


        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));


        com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));

        //*********************Added on 27 FEB 2017: New Column HB added************//
        com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        //*********************END of 27 FEB 2017: New Column HB added************//

        if (CheckTariff.Checked == true)
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
        //****Modify by Hemant Sharma on 10'th Oct 2013****////

        if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
        {
            if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
            {
                com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAwbfee.Text;
            }
            else
            {
                com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

            }
        }
        else
        {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

        }
        #region For BuyingDetails
        ////if (Convert.ToString(ViewState["GroupID"]) != "7" || Convert.ToString(ViewState["GroupID"]) != "8")
        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            ////string Gateway = rbtnGateWay.SelectedValue, Inter_NonInterline = "";

            ////if (rbtnRouteType1.Checked)///Interline
            ////{
            ////    Inter_NonInterline = "Y";
            ////    //com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = selCarrier.SelectedValue;
            ////}
            ////if (rbtnRouteType2.Checked)//Non-Interline
            ////{
            ////    Inter_NonInterline = "N";
            ////    //com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            ////}
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "Y";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;

        }
        else
        {
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
        }
        #endregion
        com.ExecuteNonQuery();
    }
    #endregion
    #region Insert_Sales_History
    public void Insert_Sales_History(SqlTransaction tr, SqlConnection con, DataTable dtSales)
    {
        string insert;

        insert = "insert into Sales_History(Sales_ID,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,SubAgent_Name,SubAgent_Adress) values(@Sales_ID,@CSR_SNo,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@SubAgent_Name,@SubAgent_Adress)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Sales_ID"].ToString());
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["CSR_SNo"].ToString());

        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["Flight_No"].ToString();
        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
        }
        else
        {
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Flight_Open_ID"].ToString());
        }
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["AirWayBill_No"].ToString();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["AWB_Date"].ToString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["CSR_Date"].ToString();
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Flight_Date"].ToString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Special_Commodity_ID"].ToString());
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Shipment_ID"].ToString());

        //DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ViewState["Booking_City_Id"].ToString() + "");
        //if (dtcity_Code.Rows.Count > 0)
        //{

        //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["City_Code"].ToString(); dtcity_Code.Rows[0]["city_code"].ToString();
        //}


        //com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["Booking_City_Id"].ToString()); 

        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["City_ID"].ToString());
        string strOrgin = "";
        DataTable dtOrigin = dw.GetAllFromQuery("select city_code from city_master where city_id=" + dtSales.Rows[0]["City_ID"].ToString() + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strOrgin = dtOrigin.Rows[0]["city_code"].ToString();
        }
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        // com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Destination_ID"].ToString());
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Airline_Detail_ID"].ToString());

        ////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_Prepaid"].ToString());

        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Charged_Weight"].ToString());


        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtSales.Rows[0]["Freight_Type"].ToString();


        ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));

        ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));

        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));

        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));

        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Spot_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Principle_Spot_Rate"].ToString();

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtSales.Rows[0]["Currency"].ToString();

        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Address"].ToString();
        ////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Remarks"].ToString();

        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Sales_Added_Date"].ToString();
        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Agent_Min_Status"].ToString());

        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Principle_Min_Status"].ToString());
        int adddeal = (dtSales.Rows[0]["Add_To_Deal"].ToString() == "" ? 14 : int.Parse(dtSales.Rows[0]["Add_To_Deal"].ToString()));
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = adddeal;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Status"].ToString());
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = dtSales.Rows[0]["Entered_By"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = dtSales.Rows[0]["Entered_On"].ToString();


        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Booking_City_Id"].ToString());

        DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + dtSales.Rows[0]["Booking_City_Id"].ToString() + "");
        if (dtcity_Code.Rows.Count > 0)
        {

            com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
        }

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Originated_Airline_Detail_ID"].ToString());

        //****************************Added On 29_Sep_2010*****************

        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));

        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
        com.ExecuteNonQuery();
    }
    #endregion
    protected void UpdateSales_Click(object sender, EventArgs e)
    {
        long Sales_ID = 0;
        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction tranupdate = con.BeginTransaction();
        string SalesID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            SalesID = Request.QueryString["Sales_ID"];
        }
        DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
        Sales_ID = long.Parse(dtHandoverID.Rows[0]["Sales_ID"].ToString());
        try
        {
            Edit_Sales(tranupdate, con, SalesID);
            InsertSalesTrans(tranupdate, con);
            Insert_Sales_History(tranupdate, con, dtHandoverID);
            //***************Updating Dimensions****************
            DataTable dtTemp = new DataTable();
            if (Session["dtTemp"] != null)
            {
                dtTemp = (DataTable)Session["dtTemp"];
                if (dtTemp.Rows.Count > 0)
                {
                    if (dtTemp.Rows[0]["SNo"].ToString() == "0")
                    {
                        dtTemp.Rows[0].Delete();
                    }
                }
            }
            if (dtHandoverID.Rows.Count > 0 && dtTemp.Rows.Count > 0)
            {
                Update_BookingDimesion(tranupdate, con, Sales_ID);

            }
            //*************End***********************************
            tranupdate.Commit();
            con.Close();
            //******************Added On 15 oct 2011 For FFR:EDI CODE to ACCS********************
            ////DataTable dtAWBConfirm = dw.GetAllFromQuery("select FFR_Remarks,* from Sales where AirWayBill_No='" + ddlAwbNo.SelectedItem.Text.Trim() + "'");

            ////string Booked = "";

            ////if (dtAWBConfirm.Rows.Count > 0)
            ////{
            ////    //if (dtAWBConfirm.Rows[0]["FFR_Remarks"].ToString().Contains("OSI/SUCESS"))
            ////    //{
            ////    //    Booked = "Y";
            ////    //}
            ////    //else
            ////    //{
            ////    //////////////////////EDICommunication(dtAWBConfirm.Rows[0]["AirWayBill_No"].ToString());
            ////    //}
            ////}
            //******************End**************************************************************
            //if (Booked != "Y")
            //{
            ////////Label1.Text = Label1.Text.Replace("\n", " ");
            ////////string strScript = "alert('" + Label1.Text + "');location.replace('salesEdit.aspx');";

            ////////ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
            //}
            //else
            //    Response.Redirect("salesEdit.aspx");

            string strScript = "alert('Sales Updated sucessfully');location.replace('salesEdit.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Update", strScript, true);


        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            tranupdate.Rollback();
            Label1.Visible = true;
            Label1.Text = ex.Message;
        }

        /////////////Response.Redirect("SalesEdit.aspx");
    }
    protected void btnSModify_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strCon);
        con.Open();
        SqlTransaction tranupdate = con.BeginTransaction();

        string SalesID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            SalesID = Request.QueryString["Sales_ID"];
        }
        DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
        ViewState["Stock_ID"] = dtHandoverID.Rows[0]["Stock_ID"].ToString();
        string AWBDate = txtAWBDate.Text;
        string CSRdate = txtCSRDate.Text;
        string[] d = AWBDate.Split(new char[] { '/' });
        string strD = d[0];
        int D = Convert.ToInt32(d[0]);
        string strM = d[1];
        int M = Convert.ToInt32(d[1]);
        string strYY = d[2];
        int YY = Convert.ToInt32(d[2]);

        string[] g = CSRdate.Split(new char[] { '/' });
        string strDD = g[0];
        int DD = Convert.ToInt32(g[0]);
        string strMM = g[1];
        int MM = Convert.ToInt32(g[1]);
        string strYYYY = g[2];
        int YYYY = Convert.ToInt32(g[2]);
        string strDate = "";
        if (D <= 15)
        {
            strDate = "16/" + strM + "/" + strYY;
            strDate = FormatDateMM(strDate);

        }
        else
        {
            int Month = M + 1;
            int Year = YY;
            if (Month == 13)
            {
                Month = 1;
                Year = YY + 1;
            }
            strDate = "01/" + Month.ToString() + "/" + Year.ToString();
            strDate = FormatDateMM(strDate);
        }
        CSRdate = FormatDateMM(CSRdate);
        //if (DateTime.Parse(CSRdate) >= DateTime.Parse(strDate))
        //{
        try
        {
            Edit_Sales(tranupdate, con, SalesID);
            Insert_Sales_History(tranupdate, con, dtHandoverID);
            long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
            Update_AWBDate(tranupdate, con);
            tranupdate.Commit();
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            tranupdate.Rollback();
        }
        if (dtHandoverID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        {
            con = new SqlConnection(strCon);
            con.Open();
            SqlTransaction tr = con.BeginTransaction();
            try
            {
                UpdateApproveStatus(tr, con, SalesID);
                InsertSalesTrans(tranupdate, con);
                Insert_Sales_DrCr1(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                Insert_Sales_DrCr2(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                tr.Commit();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                tr.Rollback();
            }
        }
        Response.Redirect("SalesEdit.aspx");

    }//End of UpdateSalesClick
    #region UpdateApproveStatus
    public void UpdateApproveStatus(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;
        update = "update Sales set Approved_for_CSR=29 , Sales_type='CRDR' where Sales_ID=" + SalesID;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }
    #endregion
    #region Insert_Sales_DrCr1

    public void Insert_Sales_DrCr1(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {

        string insert;

       ///// insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

         ////insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

         insert = "insert into Sales(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route,HB) values(@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route,@HB)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
        DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
        DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        string strOrgin = "";
        DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtCityCode.Rows.Count > 0)
        {
            strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
        }
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);



        ////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());

        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Selling_Rate"].ToString());
        //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["SellingFrtAmt"].ToString());



        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["txtTariffRate"].ToString());

        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        /////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

        com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

        com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


        DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));


        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));


        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

        com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));

        //*************************Added on 09 March 2017 **************//

        com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));



        if (CheckTariff.Checked == true)
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        }


        //************added on 27 Feb 2017 : New column HB***************//
        com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        //************End of 27 Feb 2017 : New column HB***************//
        //============================== Sub agent ===================================//
        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;

        com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());

        //**********************End Of 09 March 2017********************//



        com.ExecuteNonQuery();

    }

    public void Insert_Sales_DrCrNew(SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {

        string insert;

        ///// insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        ////insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        insert = "insert into Sales_DRCR(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route,HB,Invoice_No,Invoice_SNo,CRDR) values(@Sales_ID,@Sales_type,@CSR_SNo,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route,@HB,@Invoice_No,@Invoice_SNo,@CRDR)";

        SqlCommand com = new SqlCommand(insert, con);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

        if (phRouteDetail.Controls.Count > 0)
        {
            ////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");
            Table dynamicTable = (Table)Session["table"];
            if (dynamicTable != null)
            {
                int r = 1;
                int tempval = 0;
                string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
                foreach (TableRow tbr in dynamicTable.Rows)
                {
                    if (r != 1 && temapVal == "PREMIER" && tempval == 0)
                    {
                        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        ViewState["GridFlightNo"] = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        tempval++;

                    }
                    r++;
                }
            }
        }
        else
        {
            com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();

        }
        if (ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart() == "PREMIER")
        {
            string tempval = ViewState["GridFlightNo"].ToString();
            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + tempval + "') ");

            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
            string dest = "";
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
            if (dtDestination.Rows.Count > 0)
            {
                dest = dtDestination.Rows[0]["Destination_Code"].ToString();
            }

            com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dest;
            com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = ddlDestination.SelectedValue;
            //DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            //if (dtSectorDest.Rows.Count > 0)
            //{
            //    com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

            //    com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            //}
            //else
            //{
            //com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = "";

            //com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            //}

        }
        else
        {

            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + ddlfltNo.SelectedItem.Text + "') ");
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString());
            DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            if (dtSectorDest.Rows.Count > 0)
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            }
            else
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = ddlDestination.SelectedValue;

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            }
        }
        //=======================END==============================================
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        string strOrgin = "";
        DataTable dtOrigin = dw.GetAllFromQuery("select city_Code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strOrgin = dtOrigin.Rows[0]["city_Code"].ToString();
        }
        #region For BuyingDetails
        //==============Added By:Pradeep Sharma===========================
        ////if (Convert.ToString(ViewState["GroupID"]) != "13" )
        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            string Inter_NonInterline = "";

            ////if (rbtnRouteType1.Checked)///Interline
            ////{
            ////    Inter_NonInterline = "Y";

            ////}
            ////if (rbtnRouteType2.Checked)//Non-Interline
            ////{
            ////    Inter_NonInterline = "N";

            ////}
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "Y";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;
        }
        else
        {
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
        }
        #endregion
        ////strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = "";
        DataTable dtDest = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strDestination = dtDest.Rows[0]["Destination_Code"].ToString();
        }
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "USD";
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;


        com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());


        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtcity_Code.Rows.Count > 0)
        {

            com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
        }

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //******************Added on 29_Sep_2010**********************************
        ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value = ddlDealColour.SelectedValue;
        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));
        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));
        ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        //****Modify by Hemant Sharma on 10'th Oct 2013****////
        DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
        if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
        {
            //if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
            //{
            //    if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
            //    {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAwbfee.Text;
            //}
            //else
            //{
            //    com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = null;

            //}
        }
        else
        {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

        }
        //com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(hdninvno.Value);
        //com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(hdnInvsno.Value);
        com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;

        com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        if (CheckTariff.Checked == true)
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        }
        //************added on 27 Feb 2017 : New column HB***************//
        com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;

        com.Parameters.Add("@CRDR", SqlDbType.Char).Value = ddlCrDr.SelectedItem.Text;
        //************End of 27 Feb 2017 : New column HB***************//
        //============================== Sub agent ===================================//
        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
        com.ExecuteNonQuery();

        //////com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
        //////DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
        //////com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        //////com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        //////DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        //////DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
        //////com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        //////com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
        //////DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        //////com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();
        //////com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        //////com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        //////com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        //////com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        //////com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        //////string strOrgin = "";
        //////DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        //////if (dtCityCode.Rows.Count > 0)
        //////{
        //////    strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
        //////}
        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        //////com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        ////////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        //////com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();
        //////com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        //////com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);



        //////////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());

        //////com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        //////com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        //////com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        //////com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());

        //////com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        ////////////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Selling_Rate"].ToString());
        ////////////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["SellingFrtAmt"].ToString());



        //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["txtTariffRate"].ToString());

        //////com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        //////com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        //////com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

        //////com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

        //////com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";
        //////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        //////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        //////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        //////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        ///////////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

        //////com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        //////com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        //////if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////// com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

        //////com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        //////com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        //////com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        //////com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


        //////DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

        //////com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //////com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        //////////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        //////////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


        //////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));


        //////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));


        //////////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        //////////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

        //////////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

        //////com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        //////com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));

        ////////*************************Added on 09 March 2017 **************//

        //////com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        //////com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        //////com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));



        //////if (CheckTariff.Checked == true)
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        //////}


        ////////************added on 27 Feb 2017 : New column HB***************//
        //////com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        ////////************End of 27 Feb 2017 : New column HB***************//
        ////////============================== Sub agent ===================================//
        //////com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        //////com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;

        //////com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        //////com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());

        ////////**********************End Of 09 March 2017********************//



        //////com.ExecuteNonQuery();

    }

    public void Edit_Sales_DrCrNew(SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {

        string update;

        ///// insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        ////insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        update = "update Sales_DRCR set Sales_ID=@Sales_ID,Sales_type=@Sales_type,CSR_SNo=@CSR_SNo,Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_ID=@Shipment_ID,Shipment_Name=@Shipment_Name,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Currency=@Currency,Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Sales_Added_Date=@Sales_Added_Date,Add_To_Deal=@Add_To_Deal,Agent_Min_Status=@Agent_Min_Status,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Last_Modified_BY=@Last_Modified_BY,Last_Modified_On=@Last_Modified_On,Booking_City_ID=@Booking_City_ID,Booking_City_code=@Booking_City_code,Originated_Airline_Detail_ID=@Originated_Airline_Detail_ID,ConversionRateToPHP=@ConversionRateToPHP,Selling_Rate=@Selling_Rate,SellingFrtAmt=@SellingFrtAmt,csr_remarks=@csr_remarks,SectorDestCode=@SectorDestCode,SectorDestID=@SectorDestID,Routing=@Routing,DeptAirportOrg=@DeptAirportOrg,Total_DueCarrier=@Total_DueCarrier,spot_rate=@spot_rate,SellingRate_MinStatus=@SellingRate_MinStatus,SubAgent_Name=@SubAgent_Name,SubAgent_Adress=@SubAgent_Adress,AWB_Fees=@AWB_Fees,Gateway=@Gateway,Interline=@Interline,Carrier=@Carrier,Inner_Route=@Inner_Route,HB=@HB,Invoice_No=@Invoice_No,Invoice_SNo=@Invoice_SNo,CRDR=@CRDR where Sales_ID=@Sales_ID";

        SqlCommand com = new SqlCommand(update, con);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

        if (phRouteDetail.Controls.Count > 0)
        {
            ////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");

            Table dynamicTable = (Table)Session["table"];
            if (dynamicTable != null)
            {
                int r = 1;
                int tempval = 0;
                string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
                foreach (TableRow tbr in dynamicTable.Rows)
                {
                    if (r != 1 && temapVal == "PREMIER" && tempval == 0)
                    {
                        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        ViewState["GridFlightNo"] = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        tempval++;

                    }
                    r++;
                }
            }
        }
        else
        {
            com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();

        }
        if (ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart() == "PREMIER")
        {
            string tempval = ViewState["GridFlightNo"].ToString();
            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + tempval + "') ");

            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
            string dest = "";
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
            if (dtDestination.Rows.Count > 0)
            {
                dest = dtDestination.Rows[0]["Destination_Code"].ToString();
            }

            com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dest;
            com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = ddlDestination.SelectedValue;
            //DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            //if (dtSectorDest.Rows.Count > 0)
            //{
            //    com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

            //    com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            //}
            //else
            //{
            //com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = "";

            //com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            //}

        }
        else
        {

            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + ddlfltNo.SelectedItem.Text + "') ");
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString());
            DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            if (dtSectorDest.Rows.Count > 0)
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            }
            else
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = ddlDestination.SelectedValue;

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            }
        }
        //=======================END==============================================
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        string strOrgin = "";
        DataTable dtOrigin = dw.GetAllFromQuery("select city_Code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strOrgin = dtOrigin.Rows[0]["city_Code"].ToString();
        }
        #region For BuyingDetails
        //==============Added By:Pradeep Sharma===========================
        ////if (Convert.ToString(ViewState["GroupID"]) != "13" )
        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            string Inter_NonInterline = "";

            ////if (rbtnRouteType1.Checked)///Interline
            ////{
            ////    Inter_NonInterline = "Y";

            ////}
            ////if (rbtnRouteType2.Checked)//Non-Interline
            ////{
            ////    Inter_NonInterline = "N";

            ////}
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "Y";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;
        }
        else
        {
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
        }
        #endregion
        ////strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = "";
        DataTable dtDest = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strDestination = dtDest.Rows[0]["Destination_Code"].ToString();
        }
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "USD";
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;


        com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());


        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Last_Modified_BY", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Last_Modified_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtcity_Code.Rows.Count > 0)
        {

            com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
        }

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //******************Added on 29_Sep_2010**********************************
        ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value = ddlDealColour.SelectedValue;
        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));
        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));
        ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));
        //****Modify by Hemant Sharma on 10'th Oct 2013****////
        DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
        if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
        {
            //if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
            //{
            //    if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
            //    {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAwbfee.Text;
            //}
            //else
            //{
            //    com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = null;

            //}
        }
        else
        {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

        }
        //com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(hdninvno.Value);
        //com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(hdnInvsno.Value);
        com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;

        com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));
        if (CheckTariff.Checked == true)
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        }
        //************added on 27 Feb 2017 : New column HB***************//
        com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        com.Parameters.Add("@CRDR", SqlDbType.Char).Value = ddlCrDr.SelectedItem.Text;
        //************End of 27 Feb 2017 : New column HB***************//
        //============================== Sub agent ===================================//
        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
        com.ExecuteNonQuery();

        //////com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
        //////DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
        //////com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        //////com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        //////DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        //////DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
        //////com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        //////com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
        //////DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        //////com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();
        //////com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        //////com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        //////com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        //////com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        //////com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        //////string strOrgin = "";
        //////DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        //////if (dtCityCode.Rows.Count > 0)
        //////{
        //////    strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
        //////}
        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        //////com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        ////////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        //////com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();
        //////com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        //////com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);



        //////////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());

        //////com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        //////com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        //////com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        //////com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());

        //////com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        ////////////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Selling_Rate"].ToString());
        ////////////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["SellingFrtAmt"].ToString());



        //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["txtTariffRate"].ToString());

        //////com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        //////com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        //////com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

        //////com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

        //////com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";
        //////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        //////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        //////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        //////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        ///////////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

        //////com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        //////com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        //////if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////// com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

        //////com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        //////com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        //////com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        //////com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


        //////DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

        //////com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //////com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        //////////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        //////////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


        //////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));


        //////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));


        //////////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        //////////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

        //////////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

        //////com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        //////com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));

        ////////*************************Added on 09 March 2017 **************//

        //////com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        //////com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        //////com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));



        //////if (CheckTariff.Checked == true)
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        //////}


        ////////************added on 27 Feb 2017 : New column HB***************//
        //////com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        ////////************End of 27 Feb 2017 : New column HB***************//
        ////////============================== Sub agent ===================================//
        //////com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        //////com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;

        //////com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        //////com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());

        ////////**********************End Of 09 March 2017********************//



        //////com.ExecuteNonQuery();

    }
    #endregion
    #region Insert_Sales_DrCr2
    public void Insert_Sales_DrCr2(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {
        string insert;

        insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";


        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
        DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtCSRDate.Text);
        DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        string strOrgin = "";
        DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtCityCode.Rows.Count > 0)
        {
            strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
        }
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();

        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();

        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);


        ////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());


        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());


        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Freight_Amount"].ToString());


        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";

        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        ////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();


        com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        // com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


        DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);


        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));



        ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));

        ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTrfRate.Text == "" ? 0 : decimal.Parse(txtTrfRate.Text));


        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtTariffFrtAmt.Text == "" ? 0 : decimal.Parse(txtTariffFrtAmt.Text));

        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));

        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

        com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;

        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDataFee.Text == "" ? 0 : decimal.Parse(txtDataFee.Text));

        com.ExecuteNonQuery();
    }
    #endregion
    public void LoadACS()
    {
        try
        {
            con = new SqlConnection(strCon);
            com = new SqlCommand("LOADACS", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            StringBuilder xmlData = new StringBuilder(dt.Rows[0]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlAgentName, "Agent_Master", "Agent_Name", "Agent_ID");
            xmlData = new StringBuilder(dt.Rows[1]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlScr, "Special_Commodity_Master", "Special_Commodity_Name", "Special_Commodity_ID");

            xmlData = new StringBuilder(dt.Rows[2]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlShipmentType, "Shipment_Master", "Shipment_Name", "Shipment_ID");
            ddlScr.SelectedValue = "35";
            ddlShipmentType.SelectedValue = "8";
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadUserOrigin()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("LOAD_ORIGIN", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);

            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Clear();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadAgentStock()
    {
        string strAgent = "select Stock_ID,AirWayBill_No FROM dbo.Stock_Master sm INNER JOIN dbo.Airline_Master am ON SUBSTRING(sm.AirWayBill_No,1,3)=SUBSTRING(am.Airline_Code,1,3) INNER JOIN dbo.Airline_Detail ad ON am.Airline_ID = ad.Airline_ID where sm.Status=16 and sm.Agent_ID=" + ddlAgentName.SelectedValue + " and Airline_Detail_ID="+ddlAirline.SelectedValue+" ";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand(strAgent, con);
        SqlDataReader dr = com.ExecuteReader();
        ddlAwbNo.Items.Clear();
        ddlAwbNo.Items.Insert(0, "- -Select- -");
        ddlAwbNo.Items[0].Value = "0";
        while (dr.Read())
        {
            ddlAwbNo.Items.Add(new ListItem(dr["AirWayBill_No"].ToString(), dr["Stock_ID"].ToString()));
        }
        dr.Dispose();
        con.Close();
    }
    protected void ddlAgent_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        ddlOrigin.Items.Clear();
        ddlAirline.Items.Clear();
        ddlDestination.Items.Clear();
        LoadUserOrigin();      
        int i=CheckSubAgentStatus(Convert.ToInt32(ddlAgentName.SelectedValue));        
        ViewState["SubAgentStatus"] = i >= 1 ? "Y" : "N"; 
        trSubagent.Visible = i >= 1 ? true : false; 
    }
    protected int  CheckSubAgentStatus(int Agent_ID)
    {
        com = new SqlCommand("CheckSubAgentStatus", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("Agent_ID", SqlDbType.BigInt).Value = Agent_ID;
        con.Open();
        SqlDataAdapter sda = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        sda.Fill(ds);
        con.Close();
        return ds.Tables[0].Rows.Count;
    }
    protected void ddlOrigin_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOrigin.SelectedValue == "0")
        {
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
        }
        else
        {
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
            UserAirlineNamePlusCode();
            ViewState["AirlineDetailID"] = ddlAgentName.SelectedValue;
            //LoadDestination();
        }
    }
    public void UserAirlineNamePlusCode()
    {
        try
        {
            //string strQuery = "";
            //string Airline_Access = Rights();
            //strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City where b.Airline_Detail_ID in" + "(" + Airline_Access + ") and Belongs_To_City =" + ddlOrigin.SelectedValue;

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("LOAD_AIRLINE", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Belongs_To_City", SqlDbType.Int).Value = long.Parse(ddlOrigin.SelectedValue);
            com.Parameters.Add("@agent_id", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirline.Items.Clear();
            ddlAirline.Items.Insert(0, "- -Select- -");
            ddlAirline.Items[0].Value = "0";

            while (dr.Read())
            {

                ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));
                //total_airlines = total_airlines + dr["Airline_Detail_ID"].ToString()+",";

            }
            //all_airlines = total_airlines;
            //int len_airline = all_airlines.Length;
            //Fill_Airline = all_airlines.Substring(0, (len_airline-1));
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void ddlAirline_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        if (ddlAirline.SelectedItem.Text == "ZEST AIR(I)(MANILA)")
        {
            trBuyingDetails.Visible = false;
            trRoutingDetails.Visible = false;
        }
        string temapVal = ddlAirline.SelectedItem.Text.Substring(0,7).TrimStart();
        if (temapVal == "PREMIER")
        {
            //trBuyingDetails.Visible = true; ;
            trRoutingDetails.Visible = true;
            /////trhide.Visible = true;
            ddlfltNo.Visible = false;
            tdflighNo.Visible = false;
           
        }
        else
        {           
            trRoutingDetails.Visible = false;
           ////// trhide.Visible = false;
            ddlfltNo.Visible = true;
            tdflighNo.Visible =true;
        }
        LoadDestination();
        LoadAgentStock();
        LoadFlight();        //Rate();
        DataTable dtAirlineID = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue + "");
        hdnAirlineID.Value = dtAirlineID.Rows[0]["Airline_ID"].ToString();
        if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
        {
            lblrate.Visible = false;
            txtrate.Visible = false;
        }
        else
        {
            lblrate.Visible = true;
            txtrate.Visible = true;
        }
        //****Modify by Hemant Sharma on 10'th Oct 2013////
        DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
        if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
        {
            //if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
            //{
                lblawbfee.Visible = true;
                txtAwbfee.Visible = true;
                DataTable dt = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue + "");
                txtAwbfee.Text = dt.Rows[0]["AWB_Fees"].ToString();
            //}
            //else
            //{
            //    lblawbfee.Visible = false;
            //    txtAwbfee.Visible = false;
            //}

        }
        else
        {
            lblawbfee.Visible = false;
            txtAwbfee.Visible = false;
        }

    }    
    public void Rate()
    {
        DataTable dtAirlineID = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue + "");

        hdnAirlineID.Value = dtAirlineID.Rows[0]["Airline_ID"].ToString();

        if (dtAirlineID.Rows[0]["Airline_ID"].ToString() == "2")
        {
            //if (ddlDestination.SelectedValue == "1489" || ddlDestination.SelectedValue == "349" || ddlDestination.SelectedValue == "1499" || ddlDestination.SelectedValue == "1017")
            //{
                lblrate.Visible = false;
                txtrate.Visible = false;
            //}
            //else
            //{
                lblrate.Visible = false;
                txtrate.Visible = false;
            //}
        }
        else if (ddlAirline.SelectedValue=="10")
        {
            lblrate.Visible = false;
            txtrate.Visible = false;
        }
        else
        {
            lblrate.Visible = true;
            txtrate.Visible = true;
        }
       
    }  
    public void LoadFlight()
    {
        try
        {
            string FltNo = "";
            FltNo = "SELECT DISTINCT fm.Flight_No,fm.flight_id FROM flight_master fm INNER JOIN dbo.Flight_Details fd ON fm.Flight_ID = fd.Flight_ID WHERE fm.Airline_Detail_ID=" + ddlAirline.SelectedValue + " AND fm.Status=2";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(FltNo, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlfltNo.Items.Clear();
            ddlfltNo.Items.Insert(0, "- -Select- -");
            ddlfltNo.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlfltNo.Items.Add(new ListItem(dr["Flight_No"].ToString(), dr["flight_id"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadDestination()
    {
        try
        {
            string strAgent = "";
            strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + ddlAirline.SelectedValue + " order by dm.Destination_Code";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Clear();
            ddlDestination.Items.Add("--Select--");
            ddlDestination.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }     
   // protected void ddlDestination_SelectedIndexChanged1(object sender, EventArgs e)
    //{
        //DataTable dtDestCODE = dw.GetAllFromQuery("SELECT Routing FROM db_owner.Destination_Master WHERE Destination_Id=" + ddlDestination.SelectedValue + " and Routing is not null");
        //if (dtDestCODE.Rows.Count > 0)
        //{
        //    txtRoute.Text = dtDestCODE.Rows[0]["Routing"].ToString();
        //}
   // }
    //protected void ddlDestination_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    DataTable dtAirlineID = dw.GetAllFromQuery("SELECT Airline_ID FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue + "");
    //    if (dtAirlineID.Rows[0]["Airline_ID"].ToString() == "2")
    //    {
    //        if ((ddlDestination.SelectedValue == "1489" || ddlDestination.SelectedValue == "349" || ddlDestination.SelectedValue == "1499" || ddlDestination.SelectedValue == "1017"))
    //        {
    //            lblrate.Visible = false;
    //            txtrate.Visible = false;
    //        }
    //        else if (ddlAirline.SelectedValue == "10")
    //        {
    //            lblrate.Visible = false;
    //            txtrate.Visible = false;
    //        }
    //        else
    //        {
    //            lblrate.Visible = true;
    //            txtrate.Visible = true;
    //        }
    //    }
    //    else
    //    {
    //        lblrate.Visible = true;
    //        txtrate.Visible = true;
    //    }
        
    //}  
    protected void btnDrCr_Click(object sender, EventArgs e)
    {
        string note = ddlCrDr.SelectedItem.Text;  
        long Sales_ID = 0;
        con = new SqlConnection(strCon);
        con.Open();
        ////SqlTransaction tranupdate = con.BeginTransaction();
        string SalesID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            SalesID = Request.QueryString["Sales_ID"];
        }
        DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
        Sales_ID = long.Parse(dtHandoverID.Rows[0]["Sales_ID"].ToString());
        try
        {
            if (dtHandoverID.Rows.Count > 0)
            {
                DataTable dtSalesDRCR = dw.GetAllFromQuery("select * from Sales_DRCR where Sales_ID=" + SalesID);
                if (dtSalesDRCR.Rows.Count > 0)
                {
                    Edit_Sales_DrCrNew(con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                }
                else
                {
                    Insert_Sales_DrCrNew(con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                }
            
            con.Close();


            string strScript = "alert('CRDR generated sucessfully');location.replace('SalesEditDRCR.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Update", strScript, true);

            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            //tranupdate.Rollback();
            Label1.Visible = true;
            Label1.Text = ex.Message;
        }

    }
    protected void ddlCrDr_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCrDr.SelectedItem.Text == "Select")
        {
            btnDrCr.Visible = false;
        }
        else
        {
            btnDrCr.Visible = true;
        }
    }
    //protected void ddlDestination_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    lblOrigin.Text = ddlOrigin.SelectedItem.ToString().Split('-')[0];
    //    lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
    //}
    protected void ddlDestination_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblOrigin.Text = ddlOrigin.SelectedItem.ToString().Split('-')[0];
        lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
        CreateTextBoxesInTable();        
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
       // gvChain.EditIndex = e.NewEditIndex
        //gvChain.DataBind()
        grdCal.EditIndex = e.NewEditIndex;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();

        DropDownList ddlcarr = (DropDownList)GridView1.Rows[e.NewEditIndex].FindControl("ddlcarr");
        ddlcarr.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
        ddlcarr.DataTextField = "CarrierCode";
        ddlcarr.DataValueField = "CarrierCode";
        ddlcarr.DataBind();
        //Add Default Item in the DropDownList.
        ddlcarr.Items.Insert(0, new ListItem("Please select"));
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //Find the DropDownList in the Row.
            DropDownList ddlCountries = (e.Row.FindControl("ddlCountries") as DropDownList);
            ddlCountries.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            ddlCountries.DataTextField = "CarrierCode";
            ddlCountries.DataValueField = "CarrierCode";
            ddlCountries.DataBind();
            //Add Default Item in the DropDownList.
            ddlCountries.Items.Insert(0, new ListItem("Please select"));
            //Select the Country of Customer in DropDownList.
            //string country = (e.Row.FindControl("lblCountry") as Label).Text;
            //ddlCountries.Items.FindByValue(country).Selected = true;
        }
    }

    int total = 0;
    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();
                //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames
                ////Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtl")).Text)
                string L = ((TextBox)grdCal.FooterRow.FindControl("txtl")).Text;
                string W = ((TextBox)grdCal.FooterRow.FindControl("txtw")).Text;
                string H = ((TextBox)grdCal.FooterRow.FindControl("txth")).Text;
                decimal P = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);

                string fltno = ((TextBox)grdCal.FooterRow.FindControl("txtfltno")).Text;
                string fltdt = ((TextBox)grdCal.FooterRow.FindControl("txtfltdt")).Text;
                string Carrier = ((DropDownList)grdCal.FooterRow.FindControl("ddlcarr")).SelectedValue;

                string Currency = ((DropDownList)grdCal.FooterRow.FindControl("ddlCurr")).SelectedValue;
                //Prepare the Insert Command of the DataSource control
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = fltno;
                dr[6] = fltdt;
                dr[7] = Carrier;
                dr[8] = Currency;
                dt.Rows.Add(dr);

                Session["dtTemp"] = dt;
                grdCal.DataSource = dt;
                grdCal.DataBind();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }  
    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && grdCal.EditIndex == e.Row.RowIndex)
        {
            //Label ddlcarr = (e.Row.FindControl("lblcarr") as Label);
            DropDownList ddlcarr = (e.Row.FindControl("ddlcarr") as DropDownList);
            ddlcarr.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            ddlcarr.DataTextField = "CarrierCode";
            ddlcarr.DataValueField = "CarrierCode";
            ddlcarr.DataBind();
            //Add Default Item in the DropDownList.
           // Label lblcarr = (e.Row.FindControl("lblcarr") as Label);
           // HiddenField hfStatus = (e.Row.FindControl("hfcarr") as HiddenField);
           // string selectedCarrier = (e.Row.FindControl("lblcarr") as Label).Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            string Carrier = (e.Row.DataItem as DataRowView)["Carrier"].ToString();
            ddlcarr.Items.FindByValue(Carrier).Selected = true;


            //Bind Currency
            DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            ddlcarrency.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            ddlcarrency.DataTextField = "CarrierCode";
            ddlcarrency.DataValueField = "CarrierCode";
            ddlcarrency.DataBind();
           // ddlcarrency.Items.Insert(0, new ListItem("Please select"));
            //Add Default Item in the DropDownList.
            //string selectedcurrency = (e.Row.FindControl("ddlCurr") as DropDownList).SelectedItem.Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            //ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;
            string selectedcurrency = (e.Row.DataItem as DataRowView)["Currency"].ToString();
            ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;

            /////////
            total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//
            txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList ddlcarr = (e.Row.FindControl("ddlcarr") as DropDownList);
            ddlcarr.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            ddlcarr.DataTextField = "CarrierCode";
            ddlcarr.DataValueField = "CarrierCode";
            ddlcarr.DataBind();
            //Add Default Item in the DropDownList.
            ddlcarr.Items.Insert(0, new ListItem("Please select"));


            //Bind Currency
            DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            ddlcarrency.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            ddlcarrency.DataTextField = "CarrierCode";
            ddlcarrency.DataValueField = "CarrierCode";
            ddlcarrency.DataBind();
            ddlcarrency.Items.Insert(0, new ListItem("Please select"));    

            /////////
            total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//Convert.ToInt32(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);;//
            txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }
    }
    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        else
        {
            lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        //string [] Key = {"SNo"}; 
        //grdCal.DataKeyNames = Key;
        //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames
        // int SNo = Convert.ToInt16(((TextBox)grdCal.FindControl("txtSNo")).Text);
        /////Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text);
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        string L = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text;
        string W = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtw")).Text;
        string H = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txth")).Text;
        decimal P = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtp")).Text);

        string fltno = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtfltno")).Text;

        string fltdt = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtfltdt")).Text;

        string Carrier = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlcarr")).SelectedValue;

        string Currency = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlCurr")).SelectedValue;

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = fltno;
                dr[6] = fltdt;
                dr[7] = Carrier;
                dr[8] = Currency;
                //////dt.Rows.Add(dr);
            }
        }
        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();
        ////int Pieces = 0;
        ////decimal VoulmeWt = 0;
        ////foreach (DataRow rw in dt.Rows)
        ////{
        ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
        ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
        ////}
        ////string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
        ////txtPieces.Text = Pieces.ToString();
        ////VoulmeWt = Math.Round(VoulmeWt, 3);
        ////txtVolwt.Text = VoulmeWt.ToString();
        /////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
    }
    private DataSet GetData(string query)
    {
        string conString =ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;
                sda.SelectCommand = cmd;
                using (DataSet ds = new DataSet())
                {
                    sda.Fill(ds);
                    return ds;
                }
            }
        }
    }
}
