using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class SalesEdit : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
           
                ShowData();
            
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ShowData();

    }
    protected void btnNoShow_Click(object sender, EventArgs e)
    {

    }
    protected void btnAddToDeal_Click(object sender, EventArgs e)
    {
        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblhnd_ID = (Label)grdRow.FindControl("lblHandoverID");
        string strField1 = lblhnd_ID.Text;
        Response.Redirect("Sales_New.aspx?Sales_ID=" + strField1 + " ");

    }
    protected void btnVoid_Click(object sender, EventArgs e)
    {

    }
    protected void ShowData()
    {
         con = new SqlConnection(strCon);
         con.Open();
         try
         {
          if (txtSearch.Text == "" )
                    {

                        ////com = new SqlCommand("SELECT Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12)", con);

                        com = new SqlCommand("SELECT up.Image_Name, Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales LEFT JOIN db_owner.Upload_Airwaybill_Image Up ON sales.Airwaybill_no=Up.Airwaybill_no INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12)", con);


                    }
                    else
                    {
                        if (ddlSerach.SelectedValue == "0")
                            ////com = new SqlCommand("SELECT Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12) and Stock_Master.AirWayBill_No like " + "'%" + txtSearch.Text + "%' ", con);

                            if (txtSearch.Text.Substring(0, 3) == "307")
                            {
                                com = new SqlCommand("SELECT up.Image_Name, Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales LEFT JOIN db_owner.Upload_Airwaybill_Image Up ON sales.Airwaybill_no=Up.Airwaybill_no  INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12) and Stock_Master.AirWayBill_No like " + "'%" + txtSearch.Text + "%' ", con);
                            }
                            else
                            {
                                com = new SqlCommand("SELECT up.Image_Name, Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales LEFT JOIN db_owner.Upload_Airwaybill_Image Up ON sales.Airwaybill_no=Up.Airwaybill_no  INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12) and Stock_Master.AirWayBill_No like " + "'%" + txtSearch.Text + "%' ", con);
                            }

                        }

                        if (ddlSerach.SelectedValue == "1")
                        {
                            ////com = new SqlCommand("SELECT Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12) and Agent_Master.Agent_Name like " + "'" + txtSearch.Text + "%' ", con);

                            com = new SqlCommand("SELECT up.Image_Name,, Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales LEFT JOIN db_owner.Upload_Airwaybill_Image Up ON sales.Airwaybill_no=Up.Airwaybill_no  INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12) and Agent_Master.Agent_Name like " + "'" + txtSearch.Text + "%' ", con);

                        }
                        if (ddlSerach.SelectedValue == "2")
                        {

                            ////com = new SqlCommand("SELECT Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12) and Flight_Master.Flight_No like " + "'" + txtSearch.Text + "%' ", con);

                            com = new SqlCommand("SELECT up.Image_Name, Sales.Sales_ID, Stock_Master.AirWayBill_No, Agent_Master.Agent_Name, convert(varchar,Sales.Flight_Date,103) as 'Flight_Date',Sales.Flight_No, City_Master.City_Code as Origin, Destination_Master.Destination_Code as Destination,Sales.No_of_Packages, Sales.Gross_Weight, Sales.Volume_Weight, Sales.Charged_Weight FROM Sales LEFT JOIN db_owner.Upload_Airwaybill_Image Up ON sales.Airwaybill_no=Up.Airwaybill_no  INNER JOIN Stock_Master ON Sales.Stock_ID = Stock_Master.Stock_ID INNER JOIN Agent_Master ON Stock_Master.Agent_ID = Agent_Master.Agent_ID INNER JOIN Flight_Open ON Sales.Flight_Open_ID = Flight_Open.Flight_Open_ID INNER JOIN Flight_Master ON Flight_Open.Flight_ID = Flight_Master.Flight_ID INNER JOIN City_Master ON Sales.City_ID = City_Master.City_ID INNER JOIN Destination_Master ON Sales.Destination_ID = Destination_Master.Destination_ID where Sales.status in(11,12) and Flight_Master.Flight_No like " + "'" + txtSearch.Text + "%' ", con);

                        }
                        SqlDataAdapter da = new SqlDataAdapter(com);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        grdHandoverDetails.DataSource = dt;
                        grdHandoverDetails.DataBind();
                        con.Close();

        }
        catch (SqlException se)
        {
            string err = se.Message;
        }
        catch (Exception be)
        {
            string err = be.Message;
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void grdHandoverDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdHandoverDetails.PageIndex = e.NewPageIndex;
        ShowData();
    }
    protected void grdHandoverDetails_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdHandoverDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            for (int i = 0; i < grdHandoverDetails.Columns.Count; i++)
            {
                e.Row.Cells[i].Style.Add("white-space", "nowrap");
            }
            long GroupID = Convert.ToInt64(Session["groupid"]);

            if (GroupID == 1)
            {
                e.Row.Cells[12].Visible = true;
            }
            else
            {
                e.Row.Cells[12].Visible = false;
            }

            if (GroupID == 1 || GroupID == 10 || GroupID == 13)
            {
                e.Row.Cells[0].Visible = true;
            }
            else
            {
                e.Row.Cells[0].Visible = false;
            }

        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            for(int i = 0; i < grdHandoverDetails.Columns.Count; i++)
            {
                e.Row.Cells[i].Style.Add("white-space", "nowrap");
              //GridView1.Rows[i].Cells[j].Style.Add("white-space", "nowrap");
            }
           long GroupID=Convert.ToInt64(Session["groupid"]);
           if (GroupID == 1)
           {
               Label lblSalesID = (Label)e.Row.Cells[1].FindControl("lblHandoverID");
               DataTable dtChek = dw.GetAllFromQuery("select status,isnull(Approved_for_CSR,0) as Approved_for_CSR from Sales where Sales_ID=" + lblSalesID.Text);
               if (int.Parse(dtChek.Rows[0]["status"].ToString()) == 12 || int.Parse(dtChek.Rows[0]["status"].ToString()) == 28)
               {
                   Button btnV = (Button)e.Row.Cells[12].FindControl("btnVoid");
                   btnV.Visible = false;
               }
               e.Row.Cells[12].Visible = true;
           }
           else
           {
               e.Row.Cells[12].Visible = false;
           }
           if (GroupID == 1 || GroupID == 10 || GroupID == 13)
           {
               e.Row.Cells[0].Visible = true;
           }
           else
           {
               e.Row.Cells[0].Visible = false;
           }

          


        }
    }
    protected void ViewSales_Click(object sender, EventArgs e)
    {
        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblhnd_ID = (Label)grdRow.FindControl("lblHandoverID");
        string strField1 = lblhnd_ID.Text;
        Response.Redirect("ViewAWB2.aspx?SalesID=" + strField1 + " ");

    }
    protected void btnVoid_Click1(object sender, EventArgs e)
    {
        Button Button1 = (Button)sender;
        GridViewRow grdRow = (GridViewRow)Button1.Parent.Parent;
        Label lblSales_ID = (Label)grdRow.FindControl("lblSalesID");
        Label lblAWB = (Label)grdRow.FindControl("lblAWBNo");
        string Sales_ID = lblSales_ID.Text;
        Response.Redirect("Sales_Void.aspx?SalesID=" + Sales_ID + "&AWBNo=" + lblAWB.Text);
    }
}
