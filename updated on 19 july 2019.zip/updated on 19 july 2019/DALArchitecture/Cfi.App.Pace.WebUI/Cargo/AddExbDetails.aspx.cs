﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web.UI;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net;
using iTextSharp.text.html.simpleparser;
public partial class Cargo_AddExbDetails : System.Web.UI.Page
{
    private AppControls_Messages ucMessage = null;
    BAgentMaster bAgent = new BAgentMaster();
    BBookingConfirmed BC = new BBookingConfirmed();
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand com = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string SnoEx="";
    string strCon = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
    /// <summary>
    /// The action click handler.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="actionAndCancelButtonEventArgs">
    /// The action and cancel button event args.
    /// </param>
    public delegate void ActionClickHandler(object sender, ActionEventArgs actionAndCancelButtonEventArgs);

    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
    public event ActionClickHandler ActionClick;

    protected void Page_Load(object sender, EventArgs e)
    {
        
        //ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages");
        if (!IsPostBack)
        {
            LoadData();
            LoadCountry();
            //LoadSalesPerson();
            NetworkName();
            pnlVisitingCustomer.Visible = false;
            cmdAction.Text = "";
            cmdAction.Text = "Save";
            txtDate.Text = "";
            txtDate.Text = Convert.ToString(DateTime.Now.ToString());
            //lblTitle.Text = string.Empty;
            //lblTitle.Text = "Add Visitor Customer";
        }
    }

    void LoadSalesPerson()
    {
        try
        {
            BC.CompBrSNo = int.Parse(Session["CompBrSno"].ToString());
            SqlDataReader drSales = BC.getSalesPerson();
            ddlSales.AppendDataBoundItems = true;
            ddlSales.Items.Insert(0, new ListItem("Select Sales", "0"));
            while (drSales.Read())
            {
                ddlSales.Items.Add(new ListItem("" + drSales["DisplayName"].ToString() + "", "" + drSales["Sno"].ToString() + ""));
                //strData.Append("<option value='" + drSales["Sno"].ToString().ToUpper() + "'>" + drSales["DisplayName"].ToString().ToUpper() + "</option>");
            }
        }
        catch (Exception)
        {
            
            throw;
        }
    }

    void LoadCountry()
    {
        try
        {
            SqlDataReader drCountry = bAgent.CountryCode_Show();
            ddlCountry.AppendDataBoundItems = true;
            ddlCountry.Items.Insert(0, new ListItem("Select Country","0"));

            ddlExbOrgCountry.AppendDataBoundItems = true;
            ddlExbOrgCountry.Items.Insert(0, new ListItem("Select Country", "0"));
            while (drCountry.Read())
            {
                ddlCountry.Items.Add(new ListItem("" + drCountry["CountryName"].ToString() + "", "" + drCountry["CountryCode"].ToString() + ""));
                ddlExbOrgCountry.Items.Add(new ListItem("" + drCountry["CountryName"].ToString() + "", "" + drCountry["CountryCode"].ToString() + ""));
            }                
            //strData.Append("<option value='" + drCountry["CountryCode"].ToString() + "'>" + drCountry["CountryName"].ToString() + "</option>");
        }
        catch (Exception)
        {
            
            throw;
        }
    }

    void LoadData()
    {
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter("select CONVERT(char(20),Date,106) as VDate,* from FairDetails_Ex where compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY date", con);
        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            //gridview2.DataSource = ds;
            //gridview2.DataBind();
            //Session["VisitData"] = null;
            //Session["VisitData"] = ds.Tables[0];
            Session["SnoFromExbDetails"] = null;
            gridview1.Attributes.Clear();
            gridview1.DataSource = ds;
            gridview1.DataBind();


        }
    }

    //protected void cmdAction_ExportpdfClick(object sender, EventArgs e)
    //{
    //    if (CfiddlTypesearch.SelectedValue == "AllType")
    //    {
    //        Response.Redirect("Visitor_rpt.aspx", false);
    //    }

    //}

    protected void cmdAction_SearchClick(object sender, EventArgs e)
    {
        try
        {
            string strque = string.Empty;
            string strdatesearch = string.Empty;
            string fromdt = string.Empty;
            string todt = string.Empty;
            if (txtTodate.Text != "" && txtFromdate.Text != "")
            {
                DateTime Fromdate = Convert.ToDateTime(txtFromdate.Text.ToString());
                DateTime todates = Convert.ToDateTime(txtTodate.Text.ToString());
                fromdt = Fromdate.ToString("MM/dd/yyyy");
                todt = todates.ToString("MM/dd/yyyy");
                strdatesearch = "and Date Between '" + fromdt + "' and '" + todt + "'";
            }
            else if (txtTodate.Text == "" && txtFromdate.Text != "")
            {
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "Please Enter Valid date!", true);
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Please Enter Valid date!');", true);
                return;
            }
            else if (txtTodate.Text != "" && txtFromdate.Text == "")
            {
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "Please Enter Valid date!", true);
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Please Enter Valid date!');", true);
                return;
            }
            else if (txtTodate.Text == "" && txtFromdate.Text == "")
            {
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "Please Enter Valid date!", true);
                //ScriptManager.RegisterStartupScript(Page, typeof(Page), "alert", "Please Enter Valid date!", true);
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Please Enter Valid date!');", true);
                return;
            } 
            if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text == "")
            {
                strque = "where compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text != "")
            {
                strque = "where exname like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            else if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text == "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            else if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text != "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and exname like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text == "")
            {
                strque = "where compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text != "")
            {
                strque = "where dest like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text == "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text != "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and Sales_Person like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }

            else if (Cfiddlsearch.SelectedValue == "Select" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text != "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            else if (Cfiddlsearch.SelectedValue == "Select" && CfiddlTypesearch.SelectedValue == "B")
            {
                strque = "where compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }
            else if (Cfiddlsearch.SelectedValue == "Select" && CfiddlTypesearch.SelectedValue != "B")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + " ";
            }

            if (strque != "" && strdatesearch != "")
            {
                strque = strque + strdatesearch;
            }
            else if (strque != "" && strdatesearch == "")
            {
                strque = strque + "";
            }
            else if (strque == "" && strdatesearch != "")
            {
                strque = strque + "where Date Between '" + fromdt + "' and '" + todt + "'";
            }
            else if (strque == "" && strdatesearch == "")
            {
                strque = "";
            }


            if (strque != "")
            {
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(constr);
                SqlDataAdapter ad = new SqlDataAdapter("select CONVERT(char(20),Date,106) as VDate,* from FairDetails_Ex " + strque + " ORDER BY date", con);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gridview1.Attributes.Clear();
                    gridview1.DataSource = ds;
                    gridview1.DataBind();
                }
                else
                {
                    gridview1.Attributes.Clear();
                    gridview1.DataSource = ds;
                    gridview1.DataBind();
                }
            }
            else
            {
                gridview1.Attributes.Clear();
                gridview1.DataSource = null;
                gridview1.DataBind();
            }
            #region commented
            //if (Cfiddlsearch.SelectedValue != "Select")
            //{
            //    if (Cfiddlsearch.SelectedValue == "Customer")
            //    {
            //        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //        SqlConnection con = new SqlConnection(constr);
            //        SqlDataAdapter ad = new SqlDataAdapter("select CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where CustomerName like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY SNO DESC", con);
            //        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //        DataSet ds = new DataSet();
            //        ad.Fill(ds);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            //gridview2.DataSource = ds;
            //            //gridview2.DataBind();
            //            //Session["VisitData"] = null;
            //            //Session["VisitData"] = ds.Tables[0];
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //        else
            //        {
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //    }
            //    else if (Cfiddlsearch.SelectedValue == "Sales")
            //    {
            //        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //        SqlConnection con = new SqlConnection(constr);
            //        SqlDataAdapter ad = new SqlDataAdapter("select  CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where Sales_Person like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + "  ORDER BY SNO DESC", con);
            //        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //        DataSet ds = new DataSet();
            //        ad.Fill(ds);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            //gridview2.DataSource = ds;
            //            //gridview2.DataBind();
            //            //Session["VisitData"] = null;
            //            //Session["VisitData"] = ds.Tables[0];
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //        else
            //        {
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //    }
            //    else
            //    {
            //        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //        SqlConnection con = new SqlConnection(constr);
            //        SqlDataAdapter ad = new SqlDataAdapter("select CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY SNO DESC", con);
            //        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //        DataSet ds = new DataSet();
            //        ad.Fill(ds);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            //gridview2.DataSource = ds;
            //            //gridview2.DataBind();
            //            //Session["VisitData"] = null;
            //            //Session["VisitData"] = ds.Tables[0];
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //        else
            //        {
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //    }
            //Cfiddlsearch.ClearSelection();
            //Cfiddlsearch.Items.FindByText("Select").Selected = true;
            //CfitxtSearch.Text = "";
            //}
            //else
            //{
            //    string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //    SqlConnection con = new SqlConnection(constr);
            //    SqlDataAdapter ad = new SqlDataAdapter("select CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY SNO DESC", con);
            //    // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //    DataSet ds = new DataSet();
            //    ad.Fill(ds);
            //    if (ds.Tables[0].Rows.Count > 0)
            //    {
            //        //gridview2.DataSource = ds;
            //        //gridview2.DataBind();
            //        //Session["VisitData"] = null;
            //        //Session["VisitData"] = ds.Tables[0];
            //        gridview1.DataSource = ds;
            //        gridview1.DataBind();
            //    }
            //    Cfiddlsearch.ClearSelection();
            //    Cfiddlsearch.Items.FindByText("Select").Selected = true;
            //    CfitxtSearch.Text = "";
            //}
            #endregion
        }
        catch (Exception)
        {
            throw;
        }
    }

    public DataTable LoadGetData(int Sno)
    {
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter("SELECT CONVERT(char(20),Date,106) as VDate ,CONVERT(char(20),EndDate,106) as vEndDate,* from FairDetails_Ex where sno=" + Sno + "", con);
        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        return ds.Tables[0];
    }

    protected void Row_Selected(object sender, EventArgs e)
    {
        try
        {
            //Get the Button reference.
            Button btnSelect = (sender as Button);
            //Get the Command Name.
            string commandName = btnSelect.CommandName;
            if (commandName == "Selected")
            {
                //Get the Row reference in which Button was clicked.
                GridViewRow row = (btnSelect.NamingContainer as GridViewRow);
                int rowIndex = row.RowIndex;
                //Get the Row Index.
                //StringBuilder strQue = new StringBuilder();

                //Get the Command Argument.
                int Sno = Convert.ToInt32(btnSelect.CommandArgument.ToString());
                SnoEx=Convert.ToString(Sno);
                hdnPrimaryKeyValue.Value = Convert.ToString(Sno);
                //LoadGetData(Sno);
                if (LoadGetData(Sno) != null)
                {
                    if (LoadGetData(Sno).Rows.Count > 0)
                    {
                        //General Information
                        txtName.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Exname"]);
                        txtDest.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Dest"]);
                        txtRemarks.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["remarks"]);  
                        txtDate.Text = LoadGetData(Sno).Rows[0]["vDate"].ToString();
                        txtEndDate.Text = LoadGetData(Sno).Rows[0]["vEndDate"].ToString();
                        ddlCountry.SelectedItem.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Country"]);
                        txtSource.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Source"]);                         
                        ddlSales.SelectedItem.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["SalesPerson"]);
                        txtCommodity.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Commodity"]);
                        txtOffAgent.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["OfficialAgent"]); 
                        txtUsedAgent.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Agentused"]);
                        //Exhibition Organization Information
                        txtExbOrgName.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgName"]);
                        txtExbOrgContactPerson.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgContactperson"]);
                        txtExbOrgEmail.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgContactEmail"]);
                        txtExbOrgRemarks.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgRemarks"]);
                        txtExbOrgContactNumer.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgContactNumber"]);
                        ddlExbOrgCountry.SelectedItem.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgCountry"]);
                        txtExbOrgState.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgState"]);                         

                        //txtCity.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["City"]);
                        //txtMobile.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ContactNo"]);
                        //txtDesignation.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Designation"]);
                        //txtEMailId.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["EmailID"]);
                        //txtStatus.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Status"]);
                        //lblselectedfilename.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["FileName"]);

                        //ddllbltype.ClearSelection();
                        //if (ddllbltype.Items.FindByValue(LoadGetData(Sno).Rows[0]["Type"].ToString()) != null)
                        //    ddllbltype.Items.FindByValue(LoadGetData(Sno).Rows[0]["Type"].ToString()).Selected = true;

                        //ddlCustomerType.ClearSelection();
                        //if (ddlCustomerType.Items.FindByText(LoadGetData(Sno).Rows[0]["CustomerType"].ToString()) != null)
                        //    ddlCustomerType.Items.FindByText(LoadGetData(Sno).Rows[0]["CustomerType"].ToString()).Selected = true;

                        //ddlNetworkType.ClearSelection();
                        //if (ddlNetworkType.Items.FindByText(LoadGetData(Sno).Rows[0]["NetworkType"].ToString()) != null)
                        //    ddlNetworkType.Items.FindByText(LoadGetData(Sno).Rows[0]["NetworkType"].ToString()).Selected = true;

                        //ddlNetworkName.ClearSelection();
                        //if (ddlNetworkName.Items.FindByText(LoadGetData(Sno).Rows[0]["Sales_Person"].ToString()) != null)
                        //    ddlNetworkName.Items.FindByText(LoadGetData(Sno).Rows[0]["Sales_Person"].ToString()).Selected = true;

                        ////Discussion Points
                        //txtLocationStrength.Text = LoadGetData(Sno).Rows[0]["LocationStrength"].ToString();
                        //txtDiscussion.Text = LoadGetData(Sno).Rows[0]["Discussion"].ToString();
                        //txtToDo.Text = LoadGetData(Sno).Rows[0]["ToDo"].ToString();
                        //txtFollowUp.Text = LoadGetData(Sno).Rows[0]["FollowUp"].ToString();
                        //txtMeetingDate.Text = LoadGetData(Sno).Rows[0]["MeetingDate"].ToString();

                        //Final
                        lblTitle.Text = string.Empty;
                        lblTitle.Text = "Update Exhibition Details";
                        pnlVisitingCustomer.Visible = true;
                        div1id.Visible = false;
                        pnlgrid.Visible = false;
                        cmdAction.Text = "";
                        cmdAction.Text = "Update";
                    }
                }
            }
            else
            {
                lblTitle.Text = string.Empty;
                lblTitle.Text = "Add Exhibition Details";
                cmdAction.Text = "";
                cmdAction.Text = "Save";
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {

        }
    }

    protected void cmdCancel_Click(object sender, EventArgs e)
    {
        pnlVisitingCustomer.Visible = false;
        div1id.Visible = true;
        pnlgrid.Visible = true;
        LoadData();
        txtName.Text = string.Empty;
        txtRemarks.Text = "";
        txtSource.Text = string.Empty;
        txtDest.Text = string.Empty;
        
        txtDate.Text = Convert.ToString(DateTime.Now.ToString());
        lblTitle.Text = "Add Exhibition Customer";
        cmdAction.Text = "";
        cmdAction.Text = "Save";
        /////NetworkName();

        //ddlNetworkName.ClearSelection();
        //ddlNetworkName.Items.FindByText("Select").Selected = true;

        Cfiddlsearch.ClearSelection();
        Cfiddlsearch.Items.FindByText("Select").Selected = true;
        CfitxtSearch.Text = "";
        //txtMeetingDate.Text = "";
        //txtMeetingDate.Text = Convert.ToString(DateTime.Now.ToString());
    }

    protected void cmdAction_Click(object sender, EventArgs e)
    {
        try
        {
            if (cmdAction.Text == "Save")
            {
                SaveData(e);
            }
            if (cmdAction.Text == "Update")
            {
                UpdateData(e);
            }
        }
        catch (Exception)
        {

            throw;
        }
        finally
        {

        }
        //switch (hdnUIModeType.Value)
        //{
        //    case "New":      

        //   break;
        //   case "Update":

        //   break;
        //   case "Delete":
        //   DeleteData(e);
        //   break;
        //}
    }

    private void SaveData(EventArgs e)
    {
        try
        {
            if (Session["LoginSNo"] != null)
            {
                if (txtName.Text == "")
                {
                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Enter Exhibition Name!');", true);
                    return;
                }

                if (txtDate.Text == "")
                {
                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Enter Exhibition Name!');", true);
                    return;
                }

                con = new SqlConnection(strCon);
                con.Open();
                //string cInsert = "INSERT INTO FairDetails_Ex(exname,dest,country,source,date,compbrsno,UpdatedOn,UpdatedBy,remarks,SalesPerson)VALUES( '" + txtName.Text + "','" + txtDest.Text + "','" + ddlCountry.SelectedItem.Text + "','" + txtSource.Text + "','" + txtDate.Text + "','" + Session["CompBrSNo"].ToString() + "','" + DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])) + "','" + Session["DisplayName"].ToString() + "','" + txtRemarks.Text + "','" + ddlSales.SelectedItem.Text + "')";
                com = new SqlCommand("InsertUpdt_FairDetails_Ex", con);
                com.Parameters.AddWithValue("@Sno",0);
                com.Parameters.AddWithValue("@Exname", txtName.Text);
                com.Parameters.AddWithValue("@Dest", txtDest.Text);
                com.Parameters.AddWithValue("@Country", ddlCountry.SelectedItem.Text);
                com.Parameters.AddWithValue("@Source", txtSource.Text);                
                com.Parameters.AddWithValue("@Date", txtDate.Text);
                com.Parameters.AddWithValue("@Compbrsno", Session["CompBrSNo"].ToString());
                com.Parameters.AddWithValue("@UpdatedOn", DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])));
                com.Parameters.AddWithValue("@UpdatedBy", Session["DisplayName"].ToString());
                //com.Parameters.AddWithValue("@Active", 1);
                //com.Parameters.AddWithValue("@Type","");
                com.Parameters.AddWithValue("@remarks", txtRemarks.Text);              
                com.Parameters.AddWithValue("@SalesPerson", ddlSales.SelectedItem.Text);
                com.Parameters.AddWithValue("@Commodity", txtCommodity.Text);
                com.Parameters.AddWithValue("@StartDate",txtDate.Text);
                com.Parameters.AddWithValue("@EndDate", txtEndDate.Text);
                com.Parameters.AddWithValue("@OfficialAgent",txtOffAgent.Text);
                com.Parameters.AddWithValue("@Agentused", txtUsedAgent.Text);             
                com.Parameters.AddWithValue("@ExbOrgName",txtExbOrgName.Text);
                com.Parameters.AddWithValue("@ExbOrgContactperson",txtExbOrgContactPerson.Text);
                com.Parameters.AddWithValue("@ExbOrgContactNumber", txtExbOrgContactNumer.Text);
                com.Parameters.AddWithValue("@ExbOrgContactEmail", txtExbOrgEmail.Text);
                com.Parameters.AddWithValue("@ExbOrgState", txtExbOrgState.Text);
                com.Parameters.AddWithValue("@ExbOrgCountry", ddlExbOrgCountry.SelectedItem.Text);
                com.Parameters.AddWithValue("@ExbOrgRemarks", txtExbOrgRemarks.Text);
                com.CommandType = CommandType.StoredProcedure;
                int a=com.ExecuteNonQuery();
                con.Close();
                if (a>0)
                {
                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Record updated successfully...!');", true);
                    Response.Redirect("AddExbDetails.aspx");
                }
            }

        }
        catch (Exception ex)
        {
            // ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            // CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            // cfiException.InsertExceptionIntoDatabase(true);
            //  ucMessage.Message = "Data could not be saved.";
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('" + ex.Message.ToString() + "')", true);
            return;
        }
        finally
        {

        }
    }

    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    private void UpdateData(EventArgs e)
    {
        try
        {
            if (!string.IsNullOrEmpty(hdnPrimaryKeyValue.Value))
            {
                if (Session["LoginSNo"] != null)
                {                    
                    //string update;
                    //update = "update FairDetails_Ex set exname='" + txtName.Text + "',dest='" + txtDest.Text + "',country='" + ddlCountry.SelectedItem.Text + "',source='" + txtSource.Text + "',date='" + txtDate.Text + "',Compbrsno='" + Session["CompBrSNo"].ToString() + "',updatedOn='" + DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])) + "',updatedBy='" + Session["DisplayName"].ToString() + "',remarks='" + txtRemarks.Text + "' ,SalesPerson='" + ddlSales.SelectedItem.Text + "' where sno=" + Convert.ToString(hdnPrimaryKeyValue.Value) + "";
                    //con = new SqlConnection(strCon);
                    //con.Open();
                    //SqlCommand com = new SqlCommand(update, con);
                    //com.CommandType = CommandType.Text;
                    //int a=com.ExecuteNonQuery();
                    //con.Close();
                    con = new SqlConnection(strCon);
                    con.Open();                  
                    com = new SqlCommand("InsertUpdt_FairDetails_Ex", con);
                    com.Parameters.AddWithValue("@Sno", Convert.ToInt32(hdnPrimaryKeyValue.Value));
                    com.Parameters.AddWithValue("@Exname", txtName.Text);
                    com.Parameters.AddWithValue("@Dest", txtDest.Text);
                    com.Parameters.AddWithValue("@Country", ddlCountry.SelectedItem.Text);
                    com.Parameters.AddWithValue("@Source", txtSource.Text);
                    com.Parameters.AddWithValue("@Date", txtDate.Text);
                    com.Parameters.AddWithValue("@Compbrsno", Session["CompBrSNo"].ToString());
                    com.Parameters.AddWithValue("@UpdatedOn", DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])));
                    com.Parameters.AddWithValue("@UpdatedBy", Session["DisplayName"].ToString());
                    //com.Parameters.AddWithValue("@Active", 1);
                    //com.Parameters.AddWithValue("@Type","");
                    com.Parameters.AddWithValue("@remarks", txtRemarks.Text);
                    com.Parameters.AddWithValue("@SalesPerson", ddlSales.SelectedItem.Text);
                    com.Parameters.AddWithValue("@Commodity", txtCommodity.Text);
                    com.Parameters.AddWithValue("@StartDate", txtDate.Text);
                    com.Parameters.AddWithValue("@EndDate", txtEndDate.Text);
                    com.Parameters.AddWithValue("@OfficialAgent", txtOffAgent.Text);
                    com.Parameters.AddWithValue("@Agentused", txtUsedAgent.Text);
                    com.Parameters.AddWithValue("@ExbOrgName", txtExbOrgName.Text);
                    com.Parameters.AddWithValue("@ExbOrgContactperson", txtExbOrgContactPerson.Text);
                    com.Parameters.AddWithValue("@ExbOrgContactNumber", txtExbOrgContactNumer.Text);
                    com.Parameters.AddWithValue("@ExbOrgContactEmail", txtExbOrgEmail.Text);
                    com.Parameters.AddWithValue("@ExbOrgState", txtExbOrgState.Text);
                    com.Parameters.AddWithValue("@ExbOrgCountry", ddlExbOrgCountry.SelectedItem.Text);
                    com.Parameters.AddWithValue("@ExbOrgRemarks", txtExbOrgRemarks.Text);
                    com.CommandType = CommandType.StoredProcedure;
                    int a = com.ExecuteNonQuery();
                    con.Close();
                    if(a==1)
                    {
                        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Record updated successfully...!');", true);
                        Response.Redirect("AddExbDetails.aspx");
                    }                  
                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "Alert('Session Expired!')", true);
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            //ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            //CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            //cfiException.InsertExceptionIntoDatabase(true);
            //ucMessage.Message = "Action Not Performed"; ;
            //return;
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('" + ex.Message.ToString() + "')", true);
            return;
        }
    }

    private void NetworkName123()
    {
        //try
        //{
        //    ddlNetworkName.Items.Clear();
        //    using (CommonBusiness login = new CommonBusiness())
        //    {
        //        DataTable dtLogin = login.GetList("Login", "distinct DisplayName", "Active='Y' Order By DisplayName ASC");
        //        if (dtLogin != null && dtLogin.Rows.Count > 0)
        //        {
        //            Cfi.SoftwareFactory.Common.CommonFunctions.FillDropDownListFromTable(ref ddlNetworkName, dtLogin, "1", "DisplayName", string.Empty, "---Select---", true);
        //        }
        //    }
        //}
        //catch (Exception)
        //{
        //    throw;
        //}
        //finally
        //{

        //}
    }

    public void NetworkName()
    {
        try
        {
            DataTable dtSalesPerson = dw.GetAllFromQuery("select distinct DisplayName from login where LoginType='SALES-PERSON' and Active='Y' order by DisplayName");
            if (dtSalesPerson.Rows.Count > 0)
            {
                for (int i = 0; i < dtSalesPerson.Rows.Count; i++)
                {
                    if (i == 0)
                    {
                        ddlSales.Items.Add(new ListItem("Select", "0", true));
                    }
                    ddlSales.Items.Add(new ListItem(dtSalesPerson.Rows[i]["DisplayName"].ToString()));
                }
            }

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {

        }
    }

    protected void lnkbtn_Click(object sender, EventArgs e)
    {
        pnlVisitingCustomer.Visible = true;
        div1id.Visible = false;
        pnlgrid.Visible = false;
        //txtCompName.Text = string.Empty;
        txtSource.Text = string.Empty;
        txtDest.Text = string.Empty;

        txtDate.Text = string.Empty;
        //txtCity.Text = string.Empty;
        //txtMobile.Text = string.Empty;
        //txtEMailId.Text = string.Empty;
        //txtDesignation.Text = string.Empty;
        //txtMeetingDate.Text = string.Empty;
        //txtLocationStrength.Text = string.Empty;
        //txtDiscussion.Text = string.Empty;
        //txtToDo.Text = string.Empty;
        //txtFollowUp.Text = string.Empty;
        //txtMeetingName.Text = string.Empty;
        //txtStatus.Text = string.Empty;
        //lblselectedfilename.Text = string.Empty;
        //txtMeetingDate.Text = "";
        //txtMeetingDate.Text = Convert.ToString(DateTime.Now.ToString());
        //ddlCustomerType.ClearSelection();
        //ddlCustomerType.Items.FindByText("Select").Selected = true;
        //ddllbltype.ClearSelection();
        //ddllbltype.Items.FindByText("Select").Selected = true;
        //NetworkName();
    }

    // Export to Excel
    //protected void imgbtnExcel_Click(object sender, ImageClickEventArgs e)
    //{
    //    Response.ClearContent();
    //    Response.ContentType = "application/ms-excel";
    //    string htmlMarkUp = lblData.Text;// outputString;
    //    ////string htmlMarkUp = litCM1Report.Text;// outputString;
    //    Response.AppendHeader("content-disposition", "attachment;filename=CM1AsPerJEReport.xls");
    //    Response.Charset = string.Empty;
    //    Response.Write(htmlMarkUp);
    //    Response.End();
    //}
    //// Export to Word
    //protected void imgbtnWord_Click(object sender, ImageClickEventArgs e)
    //{
    //    Response.Clear();
    //    Response.Buffer = true;
    //    Response.AddHeader("content-disposition", "attachment;filename=CM1AsPerJEReport.doc");
    //    Response.Charset = string.Empty;
    //    Response.ContentType = "application/vnd.ms-word ";
    //    Response.Output.Write(lblData.Text);
    //    ////Response.Output.Write(litCM1Report.Text);
    //    Response.Flush();
    //    Response.End();
    //}
}