﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;
using System.Data.SqlClient;
using System.Text;
using Cfi.App.Pace.Business;
using System.Web.UI.DataVisualization.Charting;
using System.Drawing;
public partial class Cargo_NewDashboard :  BasePage
{
    public string menuItemsString = "", year = "", sno = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }
        else
        {

            
            string[] AllaccessPages = Session["AllCompBrSNo"].ToString().Split(',');
            if (AllaccessPages.Length > 1 && Session["LoginType"].ToString() != "SUPER ADMIN")
            {
                iBtnChangeCompany.Visible = true;
            }
            else
            {
                iBtnChangeCompany.Visible = false;
            }

            
            if (Session["CompBrSNo"].ToString() == string.Empty)
            {
                imgCompLogo.ImageUrl = "~/Images/pace_trans_logo.gif";
            }
            try
            {
                if (Session["LoginType"].ToString() == "PNP")
                {
                    //lblCompName.Text = Session["DisplayName"].ToString().ToUpper();
                }
                else
                {
                    //lblCompName.Text = Session["CompName"].ToString().ToUpper();
                }
            }
            catch
            {
                //lblCompName.Text = "";
            }


            menuItemsString = Session["Menu"].ToString();
            if (!IsPostBack)
            {
                LoadCompany(Session["UserId"].ToString());

                string strCompBrSno = Session["CompBrSno"].ToString();
                ddlCompany.SelectedValue = strCompBrSno;


                TimeSpan ts = new TimeSpan(1, 0, 0, 0);
                DateTime date = DateTime.Today.Subtract(ts);
                txtDate.Text = date.ToString("MMM-dd-yyyy");
               
               LoadMgmtRecord(Int64.Parse(strCompBrSno), date);
               
              //BindAttributes();
                ////lblMarquee.Text = DisplayMarquee(ddlCompany.SelectedItem.Text);
             

                menuItemsString = Session["Menu"].ToString();
                //lblHeader.Text = GetCurrentPageName();
                //lblHeader.Visible = true;
                year = DateTime.Today.Year.ToString();
                GetHelp(Request.Url.AbsolutePath);
                string lastLogin = "";
                if (Session["LastLogin"].ToString() != "")
                {
                    lastLogin = "<br>Last Visit : " + Session["LastLogin"].ToString();
                }
                string str = "<B>" + Session["DisplayName"].ToString().ToUpper() + "</B>" + "[" + Session["LoginType"].ToString().ToUpper() + "]" + "<br>" + System.DateTime.Now.ToLongDateString() + lastLogin;
                spanUserDetail.InnerHtml = str;
            }
            LoadGraph();
            BindAttributes();
            CompanyLogo();
            //lbtnCurrentUser.Text = Application["SessionCount"].ToString();
        }
    }
    private void CompanyLogo()
    {
        string comp = ddlCompany.SelectedItem.Text;
        comp = comp.Split(' ')[0];
        if (comp == "THREE")
        {
            imgCompLogo.ImageUrl = "~/Images/360_trans_logo.gif";
        }
       else
        {
            imgCompLogo.ImageUrl = "~/Images/"+comp+"_trans_logo.gif";
        }
        //GeneralFunction GF = new GeneralFunction();
        //SqlConnection con = new SqlConnection(GF.ConnectionString);
        //try
        //{

        //    SqlCommand com = new SqlCommand("Select (case when logo=0x or logo is null then 1 end)  as Logo from CompanyDetails where Sno=" + Session["CompBrSNo"], con);
        //    con.Open();
        //    SqlDataReader dr = com.ExecuteReader();
        //    if (dr.Read())
        //    {
        //        try
        //        {
        //            if (dr["Logo"].ToString() != "1")
        //            {
        //                imgCompLogo.Visible = true;

        //            }
        //            else
        //            {
        //                imgCompLogo.Visible = false;
        //            }

        //        }
        //        catch
        //        {
        //        }
        //    }
        //    dr.Close();
        //    com.Dispose();
        //    con.Close();
        //}
        //catch (SqlException sqe)
        //{
        //    string err = sqe.ToString();
        //}
        //finally
        //{
        //    if (con != null && con.State == ConnectionState.Open)
        //        con.Close();
        //}
    }
    public string GetCurrentPageName()
    {
        //string sPath = System.Web.HttpContext.Current.Request.Url.AbsolutePath;


        //System.IO.FileInfo oInfo = new System.IO.FileInfo(sPath);


        //string sRet = oInfo.Name;


        //return sRet;
        string sPath = System.Web.HttpContext.Current.Request.Url.AbsolutePath;
        System.IO.FileInfo oInfo = new System.IO.FileInfo(sPath);
        string sRet = oInfo.Name;

        DataSet ds = getPageDetails(sRet);
        if (ds.Tables[0].Rows.Count > 0)
        {
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                sRet = "" + dr["header"].ToString() + " &gt;&gt; " + dr["pageNAme"].ToString();
            }
        }
        else
        {
            sRet = "" + "Home";
        }
        return sRet;
    }
    public static DataSet getPageDetails(string parameter)
    {
        SqlParameter[] rParam = { new SqlParameter("@pageLink", parameter) };
        return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetPageName", rParam);
    }
    public static string getpagesno(string parameter)
    {
        SqlParameter[] rParam = { new SqlParameter("@pagename", parameter) };
        return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "checkpage", rParam));

    }

    protected void imgHelp_Click(object sender, ImageClickEventArgs e)
    {
        GetHelp(Request.Url.AbsolutePath);
    }

    public void GetHelp(string urlString)
    {
        string[] getUrl = urlString.Split('/');

        string strPage = "";

        if (getUrl[getUrl.Length - 1].ToString().Contains("?"))
        {
            string[] param = getUrl[getUrl.Length - 1].ToString().Split('?');
            strPage = param[0].ToString();
        }
        else
            strPage = getUrl[getUrl.Length - 1].ToString();

        sno = DAPages.RestrictPage(strPage);
    }
    protected void imghome_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["LoginType"].ToString() == "MANAGER")
        {

            Response.Redirect("NewDashboard.aspx");
        }
        else if (Session["LoginType"].ToString() == "ACCOUNTS MANAGER" || Session["LoginType"].ToString() == "ACCOUNTS EXECUTIVE")
            Response.Redirect("~/Cargo/DashBoardAccount.aspx", false);
        else
            Response.Redirect("Home.aspx");
    }
    protected void imgchpwd_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ChangePass.aspx");
    }
    protected void imglogout_Click(object sender, ImageClickEventArgs e)
    {
        Session.Abandon();
        Response.Redirect("../Login.aspx");

    }
    protected void iBtnChangeCompany_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ChangeCompany.aspx");
    }
    private void CheckSessionTimeout()
    {
        string pp = Request.Url.AbsoluteUri.ToString();
        string msgSession = "Warning: Your session is going to expire in next few seconds. Please save data to prevent loss of unsaved data. ";

        //time to remind, 3 minutes before session ends
        int int_MilliSecondsTimeReminder = (this.Session.Timeout * 60000) - 3 * 60000;
        //time to redirect, 5 milliseconds before session ends
        int int_MilliSecondsTimeOut = (this.Session.Timeout * 60000) - 1 * 60000;

        string str_Script = @"
            var myTimeReminder, myTimeOut; 
            clearTimeout(myTimeReminder); 
            clearTimeout(myTimeOut); " +
                "var sessionTimeReminder = " +
            int_MilliSecondsTimeReminder.ToString() + "; " +
                "var sessionTimeout = " + int_MilliSecondsTimeOut.ToString() + ";" +
                "function doReminder(){ alert('" + msgSession + "'); }" +
                "function doRedirect(){ window.location.href='../Login.aspx?path='+'" + pp + "'; }" + @"
            myTimeReminder=setTimeout('doReminder()', sessionTimeReminder); 
            myTimeOut=setTimeout('doRedirect()', sessionTimeout); ";

        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(),
              "CheckSessionOut", str_Script, true);
    }

 
    protected string F1ForHelp()
    {
        StringBuilder s = new StringBuilder();

        s.Append(@"<script language=""JavaScript"" type=""text/javascript""><!--");
        s.Append("\n");
        s.Append(@"document.onkeydown = keyhandler;");
        s.Append("\n");
        s.Append(@"function keyhandler(e) {");
        s.Append("\n");
        s.Append(@"    var Key = (window.event) ? event.keyCode : e.keyCode;");
        s.Append("\n");
        s.Append(@"   if (Key != 0)");
        //s.Append("\n");
        //s.Append(@"      alert('Key pressed! ASCII-value: ' + Key);");
        s.Append("\n");
        s.Append(@"   if (Key == 113)");
        //s.Append("\n");
        //s.Append(@"      alert('Help!');return false;");
        s.Append("\n");
        s.Append(@"event.returnValue=false;");
        s.Append("\n");
        s.Append(@"event.cancel = true;");
        s.Append("\n");
        s.Append(@"}");
        s.Append("\n");
        s.Append(@"document.onhelp = function() {window.open('Help.aspx?ID=" + sno + "','nWin',' Width=400,toolbar=no,scrollbars=yes,location=no,directories=no,status=no,copyhistory=no,screenX=0,screenY=0,left=0,top=0,resizeable=no'); return false;};");
        s.Append(@"//--></script>");

        return s.ToString();
    }

    protected override void Render(HtmlTextWriter writer)
    {
        if (!IsPostBack)
        {
            Response.Clear();
            Response.ClearContent();
        }
        base.Render(writer);
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            LoadMgmtRecord(Convert.ToInt64(ddlCompany.SelectedValue), Convert.ToDateTime(txtDate.Text));

            ////lblMarquee.Text = DisplayMarquee(ddlCompany.SelectedItem.Text);

           LoadGraph();

            BMgmt objMgmt = new BMgmt();
            objMgmt.CompBrSno = Convert.ToInt32(ddlCompany.SelectedValue);
            DataSet dsHO = objMgmt.getCompVariables();
            Session["CompBrSNo"] = dsHO.Tables[0].Rows[0]["CompBrSNo"].ToString();
            Session["InvoicePrefix"] = dsHO.Tables[0].Rows[0]["InvoicePrefix"].ToString();
            Session["CompBrType"] = dsHO.Tables[0].Rows[0]["CompBrType"].ToString();
            Session["CityCode"] = dsHO.Tables[0].Rows[0]["CityCode"].ToString();
            Session["PlaceName"] = dsHO.Tables[0].Rows[0]["PlaceName"].ToString();
            Session["CompName"] = dsHO.Tables[0].Rows[0]["CompName"].ToString();

            string[] accessPages = Session["CompBrSNo"].ToString().Split(',');
            if (accessPages.Length > 1)
            {
                imgCompLogo.Visible = false;
            }
            else
            {
                imgCompLogo.Visible = true;
                string[] compBrSNo = Session["CompBrSNo"].ToString().Split(',');
                imgCompLogo.ImageUrl = Page.ResolveClientUrl("~/Services/DisplayCompanyLogo.ashx?CompanyBranchSNo=" + compBrSNo[0]);
            }
        }
        catch { }
    }
    protected void LoadCompany(string strUser)
    {
        try
        {
            BMgmt objMgmt = new BMgmt();
            DataSet dsCompany = objMgmt.GetAssignedCompany(strUser);
            if (dsCompany.Tables[0].Rows.Count > 0)
            {
                ddlCompany.DataSource = dsCompany;
                ddlCompany.DataTextField = "Company";
                ddlCompany.DataValueField = "SNo";
                ddlCompany.DataBind();



            }
        }
        catch { }
    }
    protected void btnShow_Click(object sender, ImageClickEventArgs e)
    {
        try
        {


            Int64 intCompBrSno = Convert.ToInt64(ddlCompany.SelectedValue);
            Session["CompBrSNo"] = intCompBrSno;
            LoadMgmtRecord(intCompBrSno, Convert.ToDateTime(txtDate.Text));
            LoadGraph();

        }
        catch { }
    }
    //public string DisplayMarquee(string strCompany)
    //{
    //    //string strText = "<marquee onmouseover='stop();' onmouseout='start();' scrollAmount='2' scrollDelay= '30' direction='left'  Width='100%'>Welcome To " + strCompany + " DashBoard </marquee>";
    //    strCompany = strCompany.Replace("--","<br/>");
    //    string strText = "Welcome To <br/>" + strCompany + " -- DashBoard";

    //    return strText;
    //}
    protected void LoadGraph()
    {
        try
        {


            BCHA chart = new BCHA();
            DateTime date = Convert.ToDateTime(txtDate.Text);
            chart.BookingDate = date;
            chart.CompBrSNo = ddlCompany.SelectedValue;
            DataSet ds = chart.BookingDetail();
            DataTable dt = ds.Tables[0];
            chrtColumn.Series[0].ChartType = SeriesChartType.FastLine;
            chrtColumn.Series[1].ChartType = SeriesChartType.FastLine;
            //chrtColumn.ChartAreas[0].Area3DStyle.Enable3D = true;
            chrtColumn.DataSource = dt;
            chrtColumn.DataBind();

            Series series = chrtColumn.Series[0];
            Series series3 = chrtColumn.Series[1];
            for (int pointIndex = 0; pointIndex < series.Points.Count; pointIndex++)
            {

                series.Points[pointIndex].MapAreaAttributes = @"onmouseover=""DisplayTooltip('" + "<table><tr><td>" +
                                                             dt.Rows[pointIndex]["ExpBooking"] +
                                                              "</td></tr></table>" +
                                                              @"');"" onmouseout=""DisplayTooltip('');""";


                series.Points[pointIndex].Url = "BrowseProcessedBookings.aspx";
            }

            for (int pointIndex3 = 0; pointIndex3 < series3.Points.Count; pointIndex3++)
            {

                series3.Points[pointIndex3].MapAreaAttributes = @"onmouseover=""DisplayTooltip('" + "<table><tr><td>" +
                                                             dt.Rows[pointIndex3]["ImpBooking"] +
                                                              "</td></tr></table>" +
                                                              @"');"" onmouseout=""DisplayTooltip('');""";


                series3.Points[pointIndex3].Url = "BrowseProcessedBookings.aspx";
            }
            chart.AWBDate = date;
            chart.CompBrSNo = ddlCompany.SelectedValue;
            DataSet ds1 = chart.Awbdetail();
            DataTable dt1 = ds1.Tables[0];
            Chart1.Series[0].ChartType = SeriesChartType.FastLine;
            Chart1.Series[1].ChartType = SeriesChartType.FastLine;
            //Chart1.ChartAreas[0].Area3DStyle.Enable3D = true;
            Chart1.DataSource = dt1;
            Chart1.DataBind();



            Series series1 = Chart1.Series[0];
            Series series4 = Chart1.Series[1];
            for (int pointIndex1 = 0; pointIndex1 < series1.Points.Count; pointIndex1++)
            {

                series1.Points[pointIndex1].MapAreaAttributes = @"onmouseover=""DisplayTooltip1('" + "<table><tr><td>" +
                                                             dt1.Rows[pointIndex1]["ExpBooking"] +
                                                              "</td></tr></table>" +
                                                              @"');"" onmouseout=""DisplayTooltip1('');""";


                series1.Points[pointIndex1].Url = "BrowseImportAwbNew.aspx";
            }
            for (int pointIndex4 = 0; pointIndex4 < series4.Points.Count; pointIndex4++)
            {

                series4.Points[pointIndex4].MapAreaAttributes = @"onmouseover=""DisplayTooltip1('" + "<table><tr><td>" +
                                                             dt1.Rows[pointIndex4]["ImpBooking"] +
                                                              "</td></tr></table>" +
                                                              @"');"" onmouseout=""DisplayTooltip1('');""";


                series4.Points[pointIndex4].Url = "BrowseImportAwbNew.aspx";
            }
           
            if (ds.Tables[1].Rows.Count > 0)
            {
                Chart2.Visible = true;
                DataTable dt2 = ds.Tables[1];
                Chart2.Series[0].ChartType = SeriesChartType.Column;
                Chart2.ChartAreas[0].Area3DStyle.Enable3D = true;
                Chart2.DataSource = dt2;
                Chart2.DataBind();

                Series series2 = Chart2.Series[0];

                for (int pointIndex2 = 0; pointIndex2 < series2.Points.Count; pointIndex2++)
                {

                    series2.Points[pointIndex2].MapAreaAttributes = @"onmouseover=""DisplayTooltip2('" + "<table><tr><td>" +
                                                                 dt2.Rows[pointIndex2]["Rec"] +
                                                                  "</td></tr></table>" +
                                                                  @"');"" onmouseout=""DisplayTooltip2('');""";


                    //series2.Points[pointIndex2].Url = "BrowseProcessedBookings.aspx";
                }
            }
            else
                Chart2.Visible = false;
           
           
            if (ds.Tables[2].Rows.Count > 0)
               {
                 //Populate series data
                   double[] yValues = new double[ds.Tables[2].Rows.Count];
                   string[] xValues = new string[ds.Tables[2].Rows.Count];
                   for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                    {
                    xValues[i] = ds.Tables[2].Rows[i]["inv_type"].ToString();
                    yValues[i] = Convert.ToDouble(ds.Tables[2].Rows[i]["Number"]);
                    }
                FunnelProduct.Series[0].Points.DataBindXY(xValues, yValues);
                   //FunnelProduct.DataSource = ds.Tables[2];
                   //FunnelProduct.DataBind();
                for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                {
                    FunnelProduct.Series[0].Points[i].LegendText = ds.Tables[2].Rows[i]["inv_type"].ToString();
                }

                // Set funnel style
                FunnelProduct.Series[0]["FunnelStyle"] = "YIsHeight";

                // Set funnel data point labels style
                FunnelProduct.Series[0]["FunnelLabelStyle"] = "Inside";
                FunnelProduct.Series["Default"]["FunnelOutsideLabelPlacement"] = "Center";
                // Set gap between points
                FunnelProduct.Series["Default"]["FunnelPointGap"] = "2";

                // Set minimum point height
                FunnelProduct.Series["Default"]["FunnelMinPointHeight"] = "0";

                // Set 3D mode
                FunnelProduct.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;

                // Set 3D angle
                FunnelProduct.Series["Default"]["Funnel3DRotationAngle"] = "5";

                // Set 3D drawing style
                FunnelProduct.Series["Default"]["Funnel3DDrawingStyle"] = "CircularBase";

                this.FunnelProduct.Legends[0].Enabled = true;
                this.FunnelProduct.Legends[0].Alignment = StringAlignment.Far;
            }
            BReport objReport = new BReport();
            DataSet dsChart = objReport.GetChartData(date, Session["AllCompBrSNo"].ToString());
            if (dsChart.Tables[1].Rows.Count > 0)
            {
                // Populate series data
                double[] yValues = new double[dsChart.Tables[1].Rows.Count];
                string[] xValues = new string[dsChart.Tables[1].Rows.Count];
                for (int i = 0; i < dsChart.Tables[1].Rows.Count; i++)
                {
                    xValues[i] = dsChart.Tables[1].Rows[i]["Company"].ToString();
                    yValues[i] = Convert.ToDouble(dsChart.Tables[1].Rows[i]["GrossWt"]);
                }
                DoughnutTonnage.Series[0].Points.DataBindXY(xValues, yValues);
                for (int i = 0; i < dsChart.Tables[1].Rows.Count; i++)
                {
                    DoughnutTonnage.Series[0].Points[i].LegendText = dsChart.Tables[1].Rows[i]["Company"].ToString();
                }

                // Set Doughnut hole size
                DoughnutTonnage.Series[0]["DoughnutRadius"] = "50";
                this.DoughnutTonnage.Legends[0].Enabled = true;
                this.DoughnutTonnage.Legends[0].Alignment = StringAlignment.Far;
            }
            if (dsChart.Tables[0].Rows.Count > 0)
            {
                // Populate series data
                double[] yValues = new double[dsChart.Tables[0].Rows.Count];
                string[] xValues = new string[dsChart.Tables[0].Rows.Count];
                for (int i = 0; i < dsChart.Tables[0].Rows.Count; i++)
                {
                    xValues[i] = dsChart.Tables[0].Rows[i]["Company"].ToString();
                    yValues[i] = Convert.ToDouble(dsChart.Tables[0].Rows[i]["Number"]);
                }
                ColumnBills.Series["Series1"].Points.DataBindXY(xValues, yValues);

                // Set series chart type
                ColumnBills.Series["Series1"].ChartType = SeriesChartType.Bar;
                ColumnBills.Series["Series1"]["DrawingStyle"] = "Cylinder";
                ColumnBills.Titles[0].Text = "Branch Wise Bills";

                // Show/Hide X axis end labels
                ColumnBills.ChartAreas["ChartArea1"].AxisX.LabelStyle.IsEndLabelVisible = true;

                // Set point  Width of the series
                ColumnBills.Series["Series1"]["Point Width"] = "0.6";

                ColumnBills.ChartAreas["ChartArea1"].Area3DStyle.IsRightAngleAxes = true;
                ColumnBills.ChartAreas["ChartArea1"].Area3DStyle.IsClustered = true;

                // Set chart area 3D rotation
                ColumnBills.ChartAreas["ChartArea1"].Area3DStyle.Inclination = 10;
                ColumnBills.ChartAreas["ChartArea1"].Area3DStyle.Rotation = 10;

            }
            if (ds.Tables[1].Rows.Count > 0)
                DoughnutRevenue.Visible = false;
            else
            {
                if (dsChart.Tables[2].Rows.Count > 0)
                {
                    // Populate series data
                    double[] yValues = new double[dsChart.Tables[2].Rows.Count];
                    string[] xValues = new string[dsChart.Tables[2].Rows.Count];
                    for (int i = 0; i < dsChart.Tables[2].Rows.Count; i++)
                    {
                        xValues[i] = dsChart.Tables[2].Rows[i]["Company"].ToString();
                        yValues[i] = Convert.ToDouble(dsChart.Tables[2].Rows[i]["Income"]);
                    }
                    DoughnutRevenue.Series[0].Points.DataBindXY(xValues, yValues);
                    for (int i = 0; i < dsChart.Tables[2].Rows.Count; i++)
                    {
                        DoughnutRevenue.Series[0].Points[i].LegendText = dsChart.Tables[2].Rows[i]["Company"].ToString();
                    }

                    // Set Doughnut hole size
                    DoughnutRevenue.Series[0]["DoughnutRadius"] = "60";
                    this.DoughnutRevenue.Legends[0].Enabled = true;
                    this.DoughnutRevenue.Legends[0].Alignment = StringAlignment.Far;
                }
            }

        }
        catch { }
    }
    protected void LoadMgmtRecord(Int64 intCompBrSno, DateTime date)
    {
        try
        {
            BMgmt objMgmt = new BMgmt();
            objMgmt.CompBrSno = intCompBrSno;
            objMgmt.Date = date;
            DataSet dsRecord = objMgmt.GetDashBoardCount();
            if (dsRecord.Tables[0].Rows.Count > 0)
            {
                btnExpOpenJob.Text = dsRecord.Tables[0].Rows[0]["OpenJob"].ToString();
                btnExpHAWB.Text = dsRecord.Tables[0].Rows[0]["ExpHAWB"].ToString();
                btnExpMAWB.Text = dsRecord.Tables[0].Rows[0]["ExpMAWB"].ToString();
                btnExpInvJobs.Text = dsRecord.Tables[0].Rows[0]["InvoicedJob"].ToString();
                btnExpInvUpdated.Text = dsRecord.Tables[0].Rows[0]["ExpInvUpdated"].ToString();
                lblExpOutstandingBills.Text = dsRecord.Tables[0].Rows[0]["OutstandingBills"].ToString();
                btnExpOutstandingBillsCount.Text = dsRecord.Tables[0].Rows[0]["OutstandingBillsCount"].ToString();
                btnExpQueRec.Text = dsRecord.Tables[0].Rows[0]["RFQ"].ToString();
                btnExpRFQConfirme.Text = dsRecord.Tables[0].Rows[0]["RFQConfirmed"].ToString();
                btnExpRFQReject.Text = dsRecord.Tables[0].Rows[0]["RFQRejected"].ToString();
                btnExpRFQPending.Text = dsRecord.Tables[0].Rows[0]["RFQPending"].ToString();
                btnExpCHAShipBill.Text = dsRecord.Tables[0].Rows[0]["CHAShippBill"].ToString();
                btnCHACharges.Text = dsRecord.Tables[0].Rows[0]["CHACharges"].ToString();
                //***********Count of Pending Deal************
                System.Data.SqlClient.SqlConnection
                myConnection = new SqlConnection(ConnectionString);
                System.Data.SqlClient.SqlDataAdapter da;
                da = new SqlDataAdapter("SELECT COUNT(*) AS Requested from BookingConfirmed bc inner join CustomerBranch cb on bc.CustBranchId=cb.SNo INNER JOIN UpdateDeal ud ON bc.SNo=ud.BookingConfirmSNo  where bc.CompBrSNo=1 AND ud.[status]='Requested'  ", myConnection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    btnPendingDeal.Text = ds.Tables[0].Rows[0]["Requested"].ToString();
                }
                else
                {
                    btnPendingDeal.Text ="0";
                }
                //*************END********************************

                btnImpOpenJob.Text = dsRecord.Tables[0].Rows[0]["ImpOpenJob"].ToString();
                btnImpHAWB.Text = dsRecord.Tables[0].Rows[0]["ImpHAWB"].ToString();
                btnImpMAWB.Text = dsRecord.Tables[0].Rows[0]["ImpMAWB"].ToString();
                btnImpCANIssue.Text = dsRecord.Tables[0].Rows[0]["CAN"].ToString();
                btnImpCANUpdated.Text = dsRecord.Tables[0].Rows[0]["ImpCANUpdated"].ToString();
                btnImpDOIssue.Text = dsRecord.Tables[0].Rows[0]["CAN"].ToString();
                btnImpPodissued.Text = dsRecord.Tables[0].Rows[0]["POD"].ToString();
                lblImpOutStandBills.Text = dsRecord.Tables[0].Rows[0]["ImpOutstandingBills"].ToString();
                btnImpOutStandBillsCount.Text = dsRecord.Tables[0].Rows[0]["ImpOutstandingBillsCount"].ToString();

                //btnSeaExpGoodsRec.Text = dsRecord.Tables[0].Rows[0]["SeaExpGoodsRec"].ToString();
                lnkSeaExpOpenJobs.Text = dsRecord.Tables[0].Rows[0]["SeaExpOpenJobs"].ToString();
                btnSeaExpHbl.Text = dsRecord.Tables[0].Rows[0]["SeaExpHBL"].ToString();
                btnSeaExpMBL.Text = dsRecord.Tables[0].Rows[0]["SeaExpMBL"].ToString();
                btnSeaExpInvCreated.Text = dsRecord.Tables[0].Rows[0]["SeaExpInvCreated"].ToString();
                btnSeaExpInvUpdated.Text = dsRecord.Tables[0].Rows[0]["SeaExpInvUpdated"].ToString();
                lnkOceanExpOutstanding.Text = dsRecord.Tables[0].Rows[0]["SeaExpOutstanding"].ToString();
                lblSeaExpOutAmt.Text = dsRecord.Tables[0].Rows[0]["SeaExpOutstandingAmt"].ToString();
                lnkSeaImpOpenJobs.Text = dsRecord.Tables[0].Rows[0]["SeaImpOpenJobs"].ToString();
                btnSeaImpMBL.Text = dsRecord.Tables[0].Rows[0]["SeaImpMBL"].ToString();
                btnSeaImpHBL.Text = dsRecord.Tables[0].Rows[0]["SeaImpHBL"].ToString();
                btnSeaImpInvCreated.Text = dsRecord.Tables[0].Rows[0]["SeaImpInvCreated"].ToString();
                btnSeaImpInvUpdated.Text = dsRecord.Tables[0].Rows[0]["SeaImpInvUpdated"].ToString();
                lnkOceanImpOutstanding.Text = dsRecord.Tables[0].Rows[0]["SeaImpOutstanding"].ToString();
                lblSeaImpOutAmt.Text = dsRecord.Tables[0].Rows[0]["SeaImpOutstandingAmt"].ToString();

                btnPayReceive.Text = dsRecord.Tables[0].Rows[0]["PaymentRec"].ToString();
                btnPayMade.Text = dsRecord.Tables[0].Rows[0]["PaymentMade"].ToString();
                lbtnPendingWriteOff.Text = dsRecord.Tables[0].Rows[0]["PendingWriteOff"].ToString();
                btnExpiredCreditLimit.Text = dsRecord.Tables[0].Rows[0]["CrLimExpired"].ToString();
                btnConditionalCrLmt.Text = dsRecord.Tables[0].Rows[0]["ConditionalApproval"].ToString();
                int intCheqBounce = Convert.ToInt32(dsRecord.Tables[0].Rows[0]["BounceCheque"].ToString());
                if (intCheqBounce > 10)
                    btnCheqBounce.Text = "10";
                else
                    btnCheqBounce.Text = intCheqBounce.ToString();

                btnNewCustomer.Text = dsRecord.Tables[0].Rows[0]["NewCustomer"].ToString();
                int intBlackListed = Convert.ToInt32(dsRecord.Tables[0].Rows[0]["BlackList"].ToString());
                if (intCheqBounce > 10)
                    btnBlackListed.Text = "10";
                else
                    btnBlackListed.Text = intBlackListed.ToString();


            }

        }
        catch
        {

        }
    }
    protected void BindAttributes()
    {
        btnExpOpenJob.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ExpOpenJob" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpInvJobs.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ExpInvoicedJob" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpOutstandingBillsCount.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ExpOutstandBills" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpInvUpdated.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ExpInvUpdated" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpCHAShipBill.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ExpCHAShipBill" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnImpOpenJob.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpOpenJob" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnImpHAWB.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpHAWB" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnImpMAWB.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpMAWB" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpHAWB.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ExpHAWB" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpMAWB.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ExpMAWB" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
       btnImpCANIssue.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpCAN" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
       btnImpCANUpdated.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpCANUpdated" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnImpDOIssue.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpDO" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnImpPodissued.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpPOD" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnCHACharges.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=CHACharges" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnImpOutStandBillsCount.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ImpOutstandBills" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnPayReceive.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=PayRec" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnPayMade.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=PayMade" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        lbtnPendingWriteOff.Attributes.Add("onClick", "javascript:window.open('PaymentReceiptManage.aspx" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnNewCustomer.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=NewCustomer" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnCheqBounce.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=ChequeBounce" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnBlackListed.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=CustBlackList" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpQueRec.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=RFQ" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpRFQConfirme.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=RFQConfirm" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpRFQReject.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=RFQReject" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpRFQPending.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=RFQPending" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnExpiredCreditLimit.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=CrLimExpired" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        //btnSeaExpGoodsRec.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaExpGoodsRec" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        lnkSeaExpOpenJobs.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaExpOpenJobs" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaExpHbl.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaExpHBL" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaExpMBL.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaExpMBL" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaExpInvCreated.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaExpInvCreated" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaExpInvUpdated.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaExpInvUpdated" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        lnkOceanExpOutstanding.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaExpOutstandingAmt" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");

        lnkSeaImpOpenJobs.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaImpOpenJobs" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaImpMBL.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaImpMBL" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaImpHBL.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaImpHBL" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaImpInvCreated.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaImpInvCreated" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        btnSeaImpInvUpdated.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaImpInvUpdated" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        lnkOceanImpOutstanding.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=SeaImpOutstandingAmt" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");

        lbtnCurrentUser.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=Users" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");

        //*****************************For Pending Deal*********************
        btnPendingDeal.Attributes.Add("onClick", "javascript:window.open('DashBoardDetails.aspx?CompBrSno=" + ddlCompany.SelectedValue + "&Date=" + txtDate.Text + "&From=PendingDeal" + "',null,'left=162px, top=134px,  Width=650px, height=500px, status=no,resizable= no, scrollbars=yes, toolbar=no,minimize=no,location=no, menubar=no');");
        //*****************************End**********************************

    }
    private string ConnectionString
    {
        get { return PaceCommon.ConnectionString; }
    }

    protected void btnShow_Click(object sender, EventArgs e)
    {

        try
        {


            Int64 intCompBrSno = Convert.ToInt64(ddlCompany.SelectedValue);
            Session["CompBrSNo"] = intCompBrSno;
            LoadMgmtRecord(intCompBrSno, Convert.ToDateTime(txtDate.Text));
            LoadGraph();

        }
        catch { }
    }
}
