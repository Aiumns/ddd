﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web.UI;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net;
using iTextSharp.text.html.simpleparser;
public partial class Cargo_Add_ExbArabPlast : System.Web.UI.Page
{
   // private AppControls_Messages ucMessage = null;
    BAgentMaster bAgent = new BAgentMaster();
    BBookingConfirmed BC = new BBookingConfirmed();
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand com = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    string SnoEx = "";
    string strCon = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;

    /// <summary>
    /// The action click handler.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="actionAndCancelButtonEventArgs">
    /// The action and cancel button event args.
    /// </param>
    public delegate void ActionClickHandler(object sender, ActionEventArgs actionAndCancelButtonEventArgs);

    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
    public event ActionClickHandler ActionClick;

    string strWhereg = "";   

    //protected override void OnPreRender(EventArgs e)
    //  {
    //    base.OnPreRender(e);
    //    string strDisAbleBackButton;
    //    strDisAbleBackButton = "<script language='javascript'>\n";
    //    strDisAbleBackButton += "window.history.forward(1);\n";
    //    strDisAbleBackButton += "\n</script>";
    //    ClientScript.RegisterClientScriptBlock(this.Page.GetType(), "clientScript", strDisAbleBackButton);
    //  }   

    int SnoFromExbDetails = 0;
    int SnoFromExbitor = 0;
    int SnoFromArabPlastOnCancel = 0;
    int SnoBackFromExbAssign = 0;
    int SnoBackFromExbTrack = 0;
    int SnoBackFromExbTrackOnCancel = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SnoFromExbDetails"] == null)
        {
            if (Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbDetails"]))!=0)
            {
               Session["SnoFromExbDetails"] = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbDetails"]));
               SnoFromExbDetails = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbDetails"]));
            }
        }
        else
        {
            SnoFromExbDetails = Convert.ToInt32(Session["SnoFromExbDetails"]);
        }
        SnoFromExbitor = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoBackFromExbitor"]));
        SnoFromArabPlastOnCancel = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromArabPlastOnCancel"]));
        SnoBackFromExbAssign = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoBackFromExbAssign"]));
        SnoBackFromExbTrack = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoBackFromExbTrack"]));
        SnoBackFromExbTrackOnCancel = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoBackFromExbTrackOnCancel"]));
        if (!this.IsPostBack)
        {            
            //string name = Convert.ToString(HttpUtility.UrlDecode(Request.QueryString["strExName"]));
           
            // int SnoFromExbDetails = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbDetails"]));
           
            // int SnoBackFromExbTrackOnCancel = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoBackFromExbTrackOnCancel"]));
            //
             LoadSelectedExbitionById(SnoFromExbDetails);
             //Session["SnoFromExbDetails"] = SnoFromExbDetails;
             ViewState["SnoBackFromExbAssign"] = SnoBackFromExbAssign;
             ViewState["SnoBackFromExbTrack"] = SnoBackFromExbTrack;
             ViewState["SnoFromExbitor"] = SnoFromExbitor;
             ViewState["SnoFromArabPlastOnCancel"] = SnoFromArabPlastOnCancel;
             ViewState["SnoBackFromExbTrackOnCancel"] = SnoBackFromExbTrackOnCancel;
             if (SnoFromExbDetails != 0)
             {
                 //strWhereg = "f.Sno=" + SnoFromExbDetails + "";
                 //LoadExhibitorsListByExbitionId(SnoFromExbDetails); 
                 LoadAssignAllExhibitor(SnoFromExbDetails);
             }
             else if (SnoBackFromExbAssign != 0)
             {
                 //LoadExhibitorsListByExbitionId(SnoBackFromExbAssign); 
                 LoadAssignAllExhibitor(SnoBackFromExbAssign);
             }
             else if (SnoFromExbitor!=0)
             {
                 //LoadExhibitorsListByExbitionId(SnoFromExbitor); 
                 LoadAssignAllExhibitor(SnoFromExbitor);
             }
             else if (SnoBackFromExbTrack != 0)
             {
                 //LoadExhibitorsListByExbitionId(SnoBackFromExbTrack);  
                 LoadAssignAllExhibitor(SnoBackFromExbTrack);
             }
             else if (SnoFromArabPlastOnCancel != 0)
             {
                 //LoadExhibitorsListByExbitionId(SnoFromArabPlastOnCancel);
                 LoadAssignAllExhibitor(SnoFromArabPlastOnCancel);
             }
             else if (SnoBackFromExbTrackOnCancel != 0)
             {
                 //LoadExhibitorsListByExbitionId(SnoBackFromExbTrackOnCancel);
                 LoadAssignAllExhibitor(SnoBackFromExbTrackOnCancel);
             }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (SnoFromExbDetails != 0)
        {
            Session["SnoFromExbDetails"] = null;         
            Response.Redirect("AddExbDetails.aspx", false);
        }
        //if (Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbDetails"])) != 0)
        //{
        //    Session["SnoFromExbDetails"] = null;
        //    Response.Redirect("AddExbDetails.aspx", false);
        //}
        
    }
    
    public DataTable LoadGetData(int Sno)
    {
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter("select * from ExhibitorsList where sno=" + Sno + "", con);     
        DataSet ds = new DataSet();
        ad.Fill(ds);
        return ds.Tables[0];
    }

    protected void Row_Selected(object sender, EventArgs e)
    {
        try
        {
            //Get the Button reference.
            Button btnSelect = (sender as Button);
            //Get the Command Name.
            string commandName = btnSelect.CommandName;
            if (commandName == "Selected")
            {
                //Get the Row reference in which Button was clicked.
                GridViewRow row = (btnSelect.NamingContainer as GridViewRow);
                int rowIndex = row.RowIndex;              
                int Sno = Convert.ToInt32(btnSelect.CommandArgument.ToString());
                SnoEx = Convert.ToString(Sno);              
                if (LoadGetData(Sno) != null)
                {
                    if (LoadGetData(Sno).Rows.Count > 0)
                    {
                        //General Information
                        //txtName.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Exname"]);
                        //txtDest.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Dest"]);
                        //txtRemarks.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["remarks"]);
                        //txtDate.Text = LoadGetData(Sno).Rows[0]["vDate"].ToString();
                        //txtEndDate.Text = LoadGetData(Sno).Rows[0]["vEndDate"].ToString();
                        //ddlCountry.SelectedItem.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Country"]);
                        //txtSource.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Source"]);
                        //ddlSales.SelectedItem.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["SalesPerson"]);
                        //txtCommodity.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Commodity"]);
                        //txtOffAgent.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["OfficialAgent"]);
                        //txtUsedAgent.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["Agentused"]);                      
                        //txtExbOrgName.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgName"]);
                        //txtExbOrgContactPerson.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgContactperson"]);
                        //txtExbOrgEmail.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgContactEmail"]);
                        //txtExbOrgRemarks.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgRemarks"]);
                        //txtExbOrgContactNumer.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgContactNumber"]);
                        //ddlExbOrgCountry.SelectedItem.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgCountry"]);
                        //txtExbOrgState.Text = Convert.ToString(LoadGetData(Sno).Rows[0]["ExbOrgState"]);
                    }
                }
            }
            else
            {
               
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {

        }
    }

    void LoadAssignAllExhibitor(int Exhibitions)
    {
        try
        {
            string[] strsss;            
            DataTable dtAssignExbToExhibitors = dw.GetAllFromQuery("select ExbSno,ExhibitorSno,SalesPerson from AssignExbToExhibitors where ExbSno=" + Exhibitions + "");
            if (dtAssignExbToExhibitors.Rows.Count > 0)
            {
                strsss = Convert.ToString(dtAssignExbToExhibitors.Rows[0]["ExhibitorSno"]).Split(',');
                string ExbitorSnolist = "";
                foreach (string Exid in strsss)
                {
                    if (Exid !="")
                    {
                        ExbitorSnolist += Exid + ",";
                    }                   
                }
                ExbitorSnolist = ExbitorSnolist.TrimEnd(',');
                //Load Assigned  Exhibitor
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(constr);
                SqlDataAdapter ad = new SqlDataAdapter("select e.Sno,e.ExbName," + Exhibitions + " as FairSno,e.FairName,e.remarks,e.ContactPerson,e.Email,e.Country,e.Address,e.State,isnull(e.ExhibitionSno,0) [ExhibitionSno] from ExhibitorsList e where e.sno in(" + ExbitorSnolist + ")", con);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gridview1.Visible = true;
                    gridview1.Attributes.Clear();
                    gridview1.DataSource = ds;
                    gridview1.DataBind();
                }
            }          
        }
        catch (Exception)
        {

            throw;
        }
    }

    void LoadExhibitorsListByExbitionId(int Sno)
    {
        string Query="";     
        if (Convert.ToString(Session["SnoFromExbDetails"]) != "0")
        {
            int Id = Convert.ToInt32(Session["SnoFromExbDetails"]);           
            Query = "select e.Sno,e.ExbName," + Id + " as FairSno,e.FairName,e.remarks,e.ContactPerson,e.Email,e.Country,e.Address,e.State,isnull(e.ExhibitionSno,0) [ExhibitionSno] from ExhibitorsList e inner join AssignExbToExhibitors a on isnull(e.ExhibitionSno,0)=a.ExbSno where a.ExbSno=" + Id + "  ORDER BY Exbname";
        }
        else if (Convert.ToString(ViewState["SnoBackFromExbTrack"])!= "0")
        {
            int Id = Convert.ToInt32(ViewState["SnoBackFromExbTrack"]);
            Query = "select e.Sno,e.ExbName," + Id + " as FairSno,e.FairName,e.remarks,e.ContactPerson,e.Email,e.Country,e.Address,e.State,isnull(e.ExhibitionSno,0) [ExhibitionSno] from ExhibitorsList e inner join AssignExbToExhibitors a on isnull(e.ExhibitionSno,0)=a.ExbSno where a.ExbSno=" + Sno + "  ORDER BY Exbname";  
        }
        else if (Convert.ToString(ViewState["SnoFromArabPlastOnCancel"]) != "0")
        {
            int Id = Convert.ToInt32(ViewState["SnoFromArabPlastOnCancel"]);
            Query = "select e.Sno,e.ExbName," + Id + " as FairSno,e.FairName,e.remarks,e.ContactPerson,e.Email,e.Country,e.Address,e.State,isnull(e.ExhibitionSno,0) [ExhibitionSno] from ExhibitorsList e inner join AssignExbToExhibitors a on isnull(e.ExhibitionSno,0)=a.ExbSno where a.ExbSno=" + Sno + "  ORDER BY Exbname";
        }
        else if (Convert.ToString(ViewState["SnoBackFromExbTrackOnCancel"]) != "0")
        {
            int Id = Convert.ToInt32(ViewState["SnoBackFromExbTrackOnCancel"]);
            Query = "select e.Sno,e.ExbName," + Id + " as FairSno,e.FairName,e.remarks,e.ContactPerson,e.Email,e.Country,e.Address,e.State,isnull(e.ExhibitionSno,0) [ExhibitionSno] from ExhibitorsList e inner join AssignExbToExhibitors a on isnull(e.ExhibitionSno,0)=a.ExbSno where a.ExbSno=" + Sno + "  ORDER BY Exbname";
        } 
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter(Query, con);       
        DataSet ds = new DataSet();
        ad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridview1.Visible = true;
            gridview1.Attributes.Clear();
            gridview1.DataSource = ds;
            gridview1.DataBind();
        }
    }
    void LoadSelectedExbitionById(int Id)
    {
        string strwhere = "";
        strwhere = "Sno=" + Id + " and"; 
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter("select CONVERT(char(20),Date,106) as VDate,* from FairDetails_Ex where " + strwhere + " compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY date", con);  
        DataSet ds = new DataSet();
        ad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            //ni ana chihiye
            ViewState["ExbSno"] = Convert.ToString(ds.Tables[0].Rows[0]["Sno"]);
            Session["a"] = Convert.ToString(ds.Tables[0].Rows[0]["Exname"]);
            Session["b"] = Convert.ToString(ds.Tables[0].Rows[0]["remarks"]);
            Session["c"] = Convert.ToString(ds.Tables[0].Rows[0]["Dest"]);
            Session["d"] = Convert.ToString(ds.Tables[0].Rows[0]["VDate"]);
            Session["e"] = Convert.ToString(ds.Tables[0].Rows[0]["Country"]);
            Session["f"] = Convert.ToString(ds.Tables[0].Rows[0]["Source"]);
            Session["g"] = Convert.ToString(ds.Tables[0].Rows[0]["SalesPerson"]);

            lblexbname.Text = Convert.ToString(ds.Tables[0].Rows[0]["Exname"]);
            lblremarks.Text = Convert.ToString(ds.Tables[0].Rows[0]["remarks"]);
            lblvenue.Text = Convert.ToString(ds.Tables[0].Rows[0]["Dest"]);
            lblDate.Text = Convert.ToString(ds.Tables[0].Rows[0]["VDate"]);
            lblcountry.Text = Convert.ToString(ds.Tables[0].Rows[0]["Country"]);
            lblteam.Text = Convert.ToString(ds.Tables[0].Rows[0]["Source"]);
            lblsalesperson.Text = Convert.ToString(ds.Tables[0].Rows[0]["SalesPerson"]);
            lblHeaderexbname.Text = Convert.ToString(ds.Tables[0].Rows[0]["Exname"]);

            gridview1.Visible = false;
        }
        else 
        {
            lblexbname.Text = Convert.ToString(Session["a"]);
            lblremarks.Text = Convert.ToString(Session["b"]);
            lblvenue.Text = Convert.ToString(Session["c"]);
            lblDate.Text = Convert.ToString(Session["d"]);
            lblcountry.Text = Convert.ToString(Session["e"]);
            lblteam.Text = Convert.ToString(Session["f"]);
            lblsalesperson.Text = Convert.ToString(Session["g"]);
            lblHeaderexbname.Text = Convert.ToString(Session["a"]);
            gridview1.Visible = true; 
        }
    }
    
    protected void LnkbtnAdd_Click(object sender, EventArgs e)
    {      
        if (Convert.ToInt32(Session["SnoFromExbDetails"]) != 0)
        {            
            Response.Redirect("~/Cargo/AddExhibitors.aspx?ExhibitorSnoFromArabPlastForUpdate=0");
        }     
        //else
        //{
        //    Response.Redirect("~/Cargo/Add_ExbArabPlast.aspx?SnoFromArabPlast=" + ExbSnoval + "");
        //}
        //if (Convert.ToInt32(ViewState["ExbSno"]) != 0)
        //{
        //    ExbSnoval = Convert.ToInt32(ViewState["ExbSno"]);
        //    Response.Redirect("~/Cargo/AddExhibitors.aspx?SnoFromArabPlast=" + ExbSnoval + "");
        //}
        //else if (Convert.ToInt32(ViewState["SnoFromExbDetails"]) != 0)
        //{
        //    ExbSnoval = Convert.ToInt32(ViewState["SnoFromExbDetails"]);
        //    Response.Redirect("~/Cargo/Add_ExbArabPlast.aspx?SnoFromArabPlast=" + ExbSnoval + "");
        //}
        //else
        //{
        //    Response.Redirect("~/Cargo/Add_ExbArabPlast.aspx?SnoFromArabPlast=" + ExbSnoval + "");
        //}
       
    }

    protected void LnkbtnAssignExh_Click(object sender, EventArgs e)
    {
        int ExbSnoval = 0;
        if (Convert.ToInt32(Session["SnoFromExbDetails"]) != 0)
        {
            ExbSnoval = Convert.ToInt32(Session["SnoFromExbDetails"]);
            Response.Redirect("~/Cargo/AssignExbitionToExhibitors.aspx?SnoFromArabPlast=" + ExbSnoval + "");
        }
    }
}