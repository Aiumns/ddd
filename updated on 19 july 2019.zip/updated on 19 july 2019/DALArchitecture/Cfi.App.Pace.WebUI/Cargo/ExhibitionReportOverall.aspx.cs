﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Cfi.App.Pace.Business;
using Cfi.App.Pace.Data;
using System.Text;
using Cfi.App.CRM.Business;

public partial class Cargo_ExhibitionReportOverall : System.Web.UI.Page
{
    //string Agent = "";
    int Exhibitions = 0;
    int Sid;
    //string CityDest = "";
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    //string SnoFromExbArabPlast = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                LoadExName();
                fillSalesPerson();
                if (Convert.ToInt32(Request.QueryString["SnoBackFromExbTrackOnCancel"]) != 0)
                {
                    int fairSno = Convert.ToInt32((Request.QueryString["SnoBackFromExbTrackOnCancel"].ToString()));
                    ddlExhibitions.SelectedIndex = ddlExhibitions.Items.IndexOf(ddlExhibitions.Items.FindByValue(fairSno.ToString()));
                    Show_Click(sender, e);
                }
            }
        }
    }

    void LoadExhibitorsListByExbitionId(int Sno)
    {
        string Query = "";
        Query = "select e.Sno," + Convert.ToInt32(ddlExhibitions.SelectedItem.Value) + " as FairSno,e.ExbName,e.FairName,e.remarks,e.ContactPerson,e.Email,e.Country,e.Address,e.State,isnull(e.ExhibitionSno,0) [ExhibitionSno] from ExhibitorsList e inner join AssignExbToExhibitors a on isnull(e.ExhibitionSno,0)=a.ExbSno where a.ExbSno=" + Sno + "  ORDER BY Exbname";
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter(Query, con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridview1.Attributes.Clear();
            gridview1.DataSource = ds;
            gridview1.DataBind();
        }
    }

    void LoadExName()
    {
        try
        {
            string strExbName = "select distinct Sno,Exname from FairDetails_Ex where ISNULL(Exname,'')!='' order by Exname";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmdiner = new SqlCommand(strExbName, con);
            SqlDataReader dr;
            dr = cmdiner.ExecuteReader();
            ddlExhibitions.Items.Clear();
            ddlExhibitions.Items.Insert(0, "- -Select- -");
            ddlExhibitions.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlExhibitions.Items.Add(new ListItem(dr["Exname"].ToString(), dr["Sno"].ToString()));
            }
            con.Close();
        }
        catch (Exception)
        {
            throw;
        }
    }

    void LoadExbitor()
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            string StrAgent = "select * from ExhibitorsList order by Exbname";
            SqlDataAdapter sda = new SqlDataAdapter(StrAgent, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            //GridView1.DataSource = dt;
            //GridView1.DataBind();
            sda.Dispose();
            con.Close();
        }
        catch (Exception)
        {

            throw;
        }
    }

    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public void fillSalesPerson()
    {
        DataTable dtsales = dw.GetAllFromQuery("select DISTINCT upper(DisplayName) AS DisplayName,Sno from Login where Active='Y' and UPPER(LoginType) LIKE'%SALES-PERSON%'");
        //BBookingConfirmed BC = new BBookingConfirmed();
        //BC.CompBrSNo = int.Parse(Session["CompBrSNo"].ToString());
        //SqlDataReader dr = BC.getSalesPerson();
        //chksalesperson.Items.Clear();
        //chksalesperson.Items.Add(new ListItem("Select", "0"));
        foreach (DataRow row in dtsales.Rows)
        {
            //chksalesperson.Items.Add(new ListItem(row["DisplayName"].ToString(), row["Sno"].ToString()));
            //// lstsalesperson.Items.Add(new ListItem(row["DisplayName"].ToString(), row["Sno"].ToString()));
        }
    }

    protected void Show_Click(object sender, EventArgs e)
    {
        lblReport.Text = string.Empty;
        //int Exhibitions = Convert.ToInt32(ddlExhibitions.SelectedValue);
        //LoadExhibitorByExhibition(Exhibitions);
        string table = "";
        string Innertable = "";
        //string InnerRow = "";
        DataTable dt = new DataTable();
        string salesName = "";
        string whereclous = "";
        string whereclous2 = "";

        string strque = string.Empty;
        //string strdatesearch = string.Empty;
        string fromdt = string.Empty;
        string todt = string.Empty;
        if (txtDate.Text != "" && txtEndDate.Text != "")
        {
            DateTime Fromdate = Convert.ToDateTime(txtDate.Text.ToString());
            DateTime todates = Convert.ToDateTime(txtEndDate.Text.ToString());
            fromdt = Fromdate.ToString("MM/dd/yyyy");
            todt = todates.ToString("MM/dd/yyyy");
            whereclous =  " and Date Between '" + fromdt + "' and '" + todt + "'";
            whereclous2 = " where f.exname<>'' and f.Date Between '" + fromdt + "' and '" + todt + "'";
        }
        ////else
        ////{
        ////    whereclous = "where F.Exname='" + ddlExhibitions.SelectedItem.Text + "'";
        ////}
        dt = dw.GetAllFromQuery("Select * from FairDetails_Ex where exname<>'' " + whereclous + " order by Exname ");
        if (dt.Rows.Count > 0)
        {
            string tableExhName = "";
            string tableExb = "";
            string tableExbHISTORY = "";
            tableExhName += "<table border=1 background-color: #FFFFF><tr><td><b><font size=3>Exhibition Details</font></b></td><td colspan=5></td></tr>";
            tableExhName += "<tr background-color: #FFFFF><td>NAME</td><td>DEST</td><td>COUNTRY</td><td>SOURCE</td><td>REMARKS</td></tr>";
            for (int b = 0; b < dt.Rows.Count; b++)
            {

                tableExhName += "<tr><td>" + dt.Rows[b]["Exname"].ToString() + "</td><td>" + dt.Rows[b]["DEST"].ToString() + "</td><td>" + dt.Rows[b]["Country"].ToString() + "</td><td>" + dt.Rows[b]["Source"].ToString() + "</td><td>" + dt.Rows[b]["Remarks"].ToString() + "</td></tr>";

            }
            tableExhName += "</table>";

            tableExb += "<table border=1><tr background-color: #FFFFF><td><b><font size=3>EXHIBITORS LIST Details</font></b></td><td colspan=7></td></tr>";
            tableExb += "<tr background-color: #FFFFF><td>EXHIBITOR NAME</td><td>ADDRESS</td><td>EXHIBITION NAME</td><td>EMAIL</td><td>CONTACT NO</td><td>CONTACT PERSON</td><td>SALES PERSON</td><td>REMARKS</td></tr>";

            DataTable dtExbitor = dw.GetAllFromQuery("select * from ExhibitorsList e inner join FairDetails_Ex f on e.ExhibitionSno=f.Sno  " + whereclous2 + " order by e.Exbname");
            if (dtExbitor.Rows.Count > 0)
            {

                for (int C = 0; C < dtExbitor.Rows.Count; C++)
                {
                    tableExb += "<tr><td>" + dtExbitor.Rows[C]["Exbname"].ToString() + "</td><td>" + dtExbitor.Rows[C]["Address"].ToString() + "</td><td>" + dtExbitor.Rows[C]["Fairname"].ToString() + "</td><td>" + dtExbitor.Rows[C]["Email"].ToString() + "</td><td>" + dtExbitor.Rows[C]["ContactNo"].ToString() + "</td><td>" + dtExbitor.Rows[C]["ContactPerson"].ToString() + "</td>";
                    DataTable dtSaleperson = dw.GetAllFromQuery("select displayname from login where sno in (" + dtExbitor.Rows[C]["SalesPerson"].ToString() + ")");
                    string sperson = "";
                    if (dtSaleperson.Rows.Count > 0)
                    {
                        for (int g = 0; g < dtSaleperson.Rows.Count; g++)
                        {
                            sperson += dtSaleperson.Rows[g]["displayname"].ToString() + ",";
                        }

                        sperson = sperson.TrimEnd(',');
                        tableExb += "<td>" + sperson + "</td><td>" + dtExbitor.Rows[C]["Remarks"].ToString() + "</td></tr>";
                    }

                }
                tableExb += "</table>";
            }

            tableExbHISTORY += "<table border=1 background-color: #FFFFF;><tr><td><b><font size=3>EXHIBITORS HISTORY</font></b></td><td colspan=6></td></tr>";
            tableExbHISTORY += "<tr><td>EXHIBITOR NAME</td><td>ADRESS</td><td>EXHIBITION NAME</td><td>COMMUNICATION</td><td>DATE</td><td>SALES PERSON</td><td>REMARKS</td></tr>";


            DataTable dtExbitorHistory = dw.GetAllFromQuery("select fx.exname,el.ExbName,el.Address,Communication,convert(varchar,AE.Date,105) as Date,SalesPersonSno,AE.Remarks from ExhibitorsCommunication AE inner join FairDetails_Ex fx on AE.ExhibitionSno=fx.Sno inner join ExhibitorsList el on AE.ExbitorSno=el.Sno order by fx.Exname");
            if (dtExbitorHistory.Rows.Count > 0)
            {

                for (int d = 0; d < dtExbitorHistory.Rows.Count; d++)
                {
                    tableExbHISTORY += "<tr><td>" + dtExbitorHistory.Rows[d]["ExbName"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Address"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["exname"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Communication"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Date"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["SalespersonSno"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Remarks"].ToString() + "</td></tr>";
                    //DataTable dtSaleperson = dw.GetAllFromQuery("select displayname from login where sno in (" + dtExbitorHistory.Rows[d]["SalesPerson"].ToString() + ")");
                    //string sperson = "";
                    //if (dtSaleperson.Rows.Count > 0)
                    //{
                    //    for (int h = 0; dtSaleperson.Rows.Count > 0; h++)
                    //    {
                    //        sperson += dtSaleperson.Rows[h]["displayname"].ToString() + ",";
                    //    }

                    //    sperson = sperson.TrimEnd(',');
                    //    tableExbHISTORY += "<td>" + sperson + "</td><td>" + dtExbitorHistory.Rows[d]["Remarks"].ToString() + "</td></tr>";
                    //}

                }
                tableExbHISTORY += "</table>";
            }


            ////table += "</table>";
            lblReport.Text = tableExhName + "<br/><br/>" + tableExb + "<br/><br/>" + tableExbHISTORY + "";
        }

        if (lblReport.Text != "")
        {
            Response.ClearContent();
            Response.ContentType = "application/ms-excel";
            string htmlMarkUp = lblReport.Text;// outputString;
            ////string htmlMarkUp = litCM1Report.Text;// outputString;
            Response.AppendHeader("content-disposition", "attachment;filename=OverallExhibitionReport.xls");
            //Response.Charset = string.Empty;
            Response.Write(htmlMarkUp);
            Response.End();
        }
    }

    protected void Generate_Click(object sender, EventArgs e)
    {
        lblReport.Text = string.Empty;
        int Exhibitions = Convert.ToInt32(ddlExhibitions.SelectedValue);
        LoadExhibitorByExhibition(Exhibitions);
        //string table = "";
        //string Innertable = "";
        //string InnerRow = "";
        DataTable dt = new DataTable();
        //string salesName = "";
        string whereclous = "";
        string whereclous2 = "";
        string strque = string.Empty;
        //string strdatesearch = string.Empty;
        string fromdt = string.Empty;
        string todt = string.Empty;
        if (txtDate.Text != "" && txtEndDate.Text != "")
        {
            DateTime Fromdate = Convert.ToDateTime(txtDate.Text.ToString());
            DateTime todates = Convert.ToDateTime(txtEndDate.Text.ToString());
            fromdt = Fromdate.ToString("MM/dd/yyyy");
            todt = todates.ToString("MM/dd/yyyy");
            whereclous = " and Date Between '" + fromdt + "' and '" + todt + "'";
            whereclous2 = " where f.exname<>'' and f.Date Between '" + fromdt + "' and '" + todt + "'";
        }
        ////else
        ////{
        ////    whereclous = "where F.Exname='" + ddlExhibitions.SelectedItem.Text + "'";
        ////}
        dt = dw.GetAllFromQuery("Select * from FairDetails_Ex where exname<>'' " + whereclous + "  order by Exname ");
        if (dt.Rows.Count > 0)
        {
            string tableExhName = "";
            string tableExb = "";
            string tableExbHISTORY = "";
            tableExhName += "<button type='button' class='btn btn-info' data-toggle='collapse' data-target='#Exh'>Show Exhibition Details</button></br>";
            tableExhName += "<div id='Exh' class='collapse' style='overflow: auto; overflow-x: auto; width: 1000px;'><table border=1 background-color: #FFFFF><tr><td><b><font size=3>Exhibition Details</font></b></td><td colspan=5></td></tr>";
            tableExhName += "<tr background-color: #FFFFF><td>NAME</td><td>DEST</td><td>COUNTRY</td><td>SOURCE</td><td>REMARKS</td></tr>";
            for (int b = 0; b<dt.Rows.Count; b++)
            {                
                tableExhName += "<tr><td>" + dt.Rows[b]["Exname"].ToString() + "</td><td>" + dt.Rows[b]["DEST"].ToString() + "</td><td>" + dt.Rows[b]["Country"].ToString() + "</td><td>" + dt.Rows[b]["Source"].ToString() + "</td><td>" + dt.Rows[b]["Remarks"].ToString() + "</td></tr>";
            }
            tableExhName += "</table></div>";

            tableExb += "<button type='button' class='btn btn-info' data-toggle='collapse' data-target='#Exb'>Show Exhibitor Details</button></br>";
            tableExb += "<div id='Exb' class='collapse' style='height: 200px; overflow: auto; overflow-x: auto; width: 1000px;'><table border=1><tr background-color: #FFFFF><td><b><font size=3>EXHIBITORS LIST Details</font></b></td><td colspan=7></td></tr>";
            tableExb += "<tr background-color: #FFFFF><td>EXHIBITOR NAME</td><td>ADDRESS</td><td>EXHIBITION NAME</td><td>EMAIL</td><td>CONTACT NO</td><td>CONTACT PERSON</td><td>SALES PERSON</td><td>REMARKS</td></tr>";

            DataTable dtExbitor = dw.GetAllFromQuery("select * from ExhibitorsList e inner join FairDetails_Ex f on e.ExhibitionSno=f.Sno  " + whereclous2 + " order by e.Exbname");
            if (dtExbitor.Rows.Count > 0)
            {                
                for (int C = 0; C<dtExbitor.Rows.Count; C++)
                {
                                        tableExb += "<tr><td>" + dtExbitor.Rows[C]["Exbname"].ToString() + "</td><td>" + dtExbitor.Rows[C]["Address"].ToString() + "</td><td>" + dtExbitor.Rows[C]["Fairname"].ToString() + "</td><td>" + dtExbitor.Rows[C]["Email"].ToString() + "</td><td>" + dtExbitor.Rows[C]["ContactNo"].ToString() + "</td><td>" + dtExbitor.Rows[C]["ContactPerson"].ToString() + "</td>";
                    DataTable dtSaleperson = dw.GetAllFromQuery("select displayname from login where sno in (" + dtExbitor.Rows[C]["SalesPerson"].ToString() + ")");
                    string sperson = "";
                    if (dtSaleperson.Rows.Count > 0)
                    {
                        for (int g = 0; g<dtSaleperson.Rows.Count; g++)
                        {
                            sperson += dtSaleperson.Rows[g]["displayname"].ToString() + ",";
                        }

                        sperson = sperson.TrimEnd(',');
                        tableExb += "<td>" + sperson + "</td><td>" + dtExbitor.Rows[C]["Remarks"].ToString() + "</td></tr>";
                    }

                }
                tableExb += "</table></div>";
            }

            tableExbHISTORY += "<button type='button' class='btn btn-info' data-toggle='collapse' data-target='#Exbhistory'>Show Exhibitor History</button></br>";
            tableExbHISTORY += "<div id='Exbhistory' class='collapse'><table border=1 background-color: #FFFFF;><tr><td><b><font size=3>EXHIBITORS HISTORY</font></b></td><td colspan=6></td></tr>";
            tableExbHISTORY += "<tr><td>EXHIBITOR NAME</td><td>ADRESS</td><td>EXHIBITION NAME</td><td>COMMUNICATION</td><td>DATE</td><td>SALES PERSON</td><td>REMARKS</td></tr>";
                   

            DataTable dtExbitorHistory = dw.GetAllFromQuery("select fx.exname,el.ExbName,el.Address,Communication,convert(varchar,AE.Date,105) as Date,SalesPersonSno,AE.Remarks from ExhibitorsCommunication AE inner join FairDetails_Ex fx on AE.ExhibitionSno=fx.Sno inner join ExhibitorsList el on AE.ExbitorSno=el.Sno order by fx.Exname");
            if (dtExbitorHistory.Rows.Count > 0)
            {

                for (int d = 0; d<dtExbitorHistory.Rows.Count; d++)
                {
                  tableExbHISTORY += "<tr><td>" + dtExbitorHistory.Rows[d]["ExbName"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Address"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["exname"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Communication"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Date"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["SalespersonSno"].ToString() + "</td><td>" + dtExbitorHistory.Rows[d]["Remarks"].ToString() + "</td></tr>";
                    //DataTable dtSaleperson = dw.GetAllFromQuery("select displayname from login where sno in (" + dtExbitorHistory.Rows[d]["SalesPerson"].ToString() + ")");
                    //string sperson = "";
                    //if (dtSaleperson.Rows.Count > 0)
                    //{
                    //    for (int h = 0; dtSaleperson.Rows.Count > 0; h++)
                    //    {
                    //        sperson += dtSaleperson.Rows[h]["displayname"].ToString() + ",";
                    //    }

                    //    sperson = sperson.TrimEnd(',');
                    //    tableExbHISTORY += "<td>" + sperson + "</td><td>" + dtExbitorHistory.Rows[d]["Remarks"].ToString() + "</td></tr>";
                    //}

                }
                tableExbHISTORY += "</table></div>";
            }

            ////table += "</table>";
            lblReport.Text = tableExhName+"<br/><br/>"+tableExb+"<br/><br/>"+tableExbHISTORY+"";
        }
        ////if (lblReport.Text != "")
        ////{
        ////    Response.ClearContent();
        ////    Response.ContentType = "application/ms-excel";
        ////    string htmlMarkUp = lblReport.Text;// outputString;
        ////    ////string htmlMarkUp = litCM1Report.Text;// outputString;
        ////    Response.AppendHeader("content-disposition", "attachment;filename=ExhibitionReport.xls");
        ////    //Response.Charset = string.Empty;
        ////    Response.Write(htmlMarkUp);
        ////    Response.End();
        ////}
        //string table = "";
        //DataTable dt = new DataTable();
        //string salesName = "";
        //dt = dw.GetAllFromQuery("Select F.Sno,E.Sno as exbitorsno, E.ExbName,E.Address,E.state,E.Email,E.ContactNo,ISNULL(E.SalesPerson,'') SalesPerson,F.Dest,F.Country,F.Source,F.ExbOrgName,f.ExbOrgContactperson,f.remarks from FairDetails_Ex F inner join ExhibitorsList E on F.sno=E.ExhibitionSno inner join AssignExbToExhibitors A on F.Sno=A.ExbSno where F.Exname='" + ddlExhibitions.SelectedItem.Text + "'");
        //if (dt.Rows.Count > 0)
        //{
        //    DataTable dtsales = new DataTable();
        //    table += "<table border=1 style='font-family: sans-serif; border-collapse: collapse; width: 1450px; font-size: initial; font-weight: 700; background-color: #9a1413; color: white;'><tr><td>Exb Name :" + ddlExhibitions.SelectedItem.Text + "</td><td>DEST:" + Convert.ToString(dt.Rows[0]["Dest"]) + "</td><td>COUNTRY:" + Convert.ToString(dt.Rows[0]["Country"]) + "</td><td>VENUE:" + Convert.ToString(dt.Rows[0]["Source"]) + "</td><td>Organiser:" + Convert.ToString(dt.Rows[0]["ExbOrgName"]) + "</td><td>Contact Person:" + Convert.ToString(dt.Rows[0]["ExbOrgContactperson"]) + "</td><td>Remarks:" + Convert.ToString(dt.Rows[0]["remarks"]) + "</td></tr></table>";
        //    table += "<table  border=1 style='font-family: arial, sans-serif;border-collapse: collapse;width: 100%;font-size: initial;font-weight: 800;background-color: bisque;text-decoration: underline;'><tr><td>EHIBITORS DETAILS</td></tr></table>";
        //    //table += "<table><tr style='font-family: sans-serif; border-collapse: collapse; width: 1450px; font-size: initial; font-weight: 700; background-color: #9a1413; color: white;'><td>EHIBITORS NAME</td><td>EHIBITORS ADDRESS</td><td>EMAIl</td><td>CONTACT No</td><td>SalesPerson</td></tr>";
        //    table += "<table class='GridViewStyle' cellspacing=0 rules=all border=1 id='ctl00_ContentPlaceHolderMain_gridview1' style='border-collapse:collapse;'>";

        //    table += "<tbody><tr class='HeaderStyle' style='color:White;background-color:#646464;font-size:16px;height:25px;'><th scope='col'>Exhibitors Name</th><th scope='col'>Remarks</th><th scope='col'>Contact Person</th><th scope='col'>Email</th><th scope='col'>Country</th><th scope='col'>Address</th><th scope='col'>State</th><th scope='col'>SalesPerson</th></tr>";
        //    for (int ii = 0; ii < dt.Rows.Count; ii++)
        //    {
        //        dtsales = dw.GetAllFromQuery("select DISTINCT upper(DisplayName) AS DisplayName,Sno from Login where sno in(" + Convert.ToString(dt.Rows[ii]["SalesPerson"]) + ") and Active='Y' and UPPER(LoginType) LIKE'%SALES-PERSON%'");
        //        if (dtsales.Rows.Count > 0)
        //        {
        //            salesName = "";
        //            foreach (DataRow dr in dtsales.Rows)
        //            {
        //                salesName += dr["DisplayName"].ToString() + ",";
        //            }
        //            salesName = salesName.TrimEnd(',');
        //        }
        //        //table += "<tr><td style='style='border: 1px solid #dddddd;  text-align: left;  padding: 8px;'><a href=ExhibitorsTrackToExhibition.aspx?ExSno=" + Convert.ToString(dt.Rows[ii]["Sno"]) + "&ExbSno=" + Convert.ToString(dt.Rows[ii]["exbitorsno"]) + ">" + Convert.ToString(dt.Rows[ii]["ExbName"]) + "</a></td><td style='style='border: 1px solid #dddddd;  text-align: left;  padding: 8px;'>" + Convert.ToString(dt.Rows[ii]["Address"]) + "</td><td style='style='border: 1px solid #dddddd;  text-align: left;  padding: 8px;'>" + Convert.ToString(dt.Rows[ii]["Email"]) + "</td><td style='style='border: 1px solid #dddddd;  text-align: left;  padding: 8px;'>" + Convert.ToString(dt.Rows[ii]["ContactNo"]) + "</td><td>" + salesName + "</td></tr>";
        //        table += "<tr class='RowStyle'><td><a id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblExname' href=ExhibitorsTrackToExhibition.aspx?ExSno=" + Convert.ToString(dt.Rows[ii]["Sno"]) + "&ExbSno=" + Convert.ToString(dt.Rows[ii]["exbitorsno"]) + ">" + Convert.ToString(dt.Rows[ii]["ExbName"]) + "</a></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblRe'>" + Convert.ToString(dt.Rows[ii]["remarks"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblContPerson'>" + Convert.ToString(dt.Rows[ii]["ExbOrgContactperson"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lbldate'>" + Convert.ToString(dt.Rows[ii]["Email"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblCountry'>" + Convert.ToString(dt.Rows[ii]["Country"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblAddress'>" + Convert.ToString(dt.Rows[ii]["Address"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblstate'>" + Convert.ToString(dt.Rows[ii]["state"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblstate'>" + salesName + "</span></td></tr>";
        //    }
        //    table += "</tbody></table>";
        //    lblReport.Text = table;


        //LoadExhibitorsListByExbitionId(Convert.ToInt32(ddlExhibitions.SelectedItem.Value));
        //}
    }

    protected void ddlExhibitions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblReport.Text = string.Empty;
            int Exhibitions = Convert.ToInt32(ddlExhibitions.SelectedValue);
            LoadExhibitorByExhibition(Exhibitions);
            string table = "";
            string Innertable = "";
            //string InnerRow = "";
            DataTable dt = new DataTable();
            string salesName = "";
            string whereclous = "";
            string strque = string.Empty;
            //string strdatesearch = string.Empty;
            string fromdt = string.Empty;
            string todt = string.Empty;
            if (txtDate.Text != "" && txtEndDate.Text != "")
            {
                DateTime Fromdate = Convert.ToDateTime(txtDate.Text.ToString());
                DateTime todates = Convert.ToDateTime(txtEndDate.Text.ToString());
                fromdt = Fromdate.ToString("MM/dd/yyyy");
                todt = todates.ToString("MM/dd/yyyy");
                whereclous = "where F.Exname='" + ddlExhibitions.SelectedItem.Text + "' and F.Date Between '" + fromdt + "' and '" + todt + "'";
            }
            else
            {
                whereclous = "where F.Exname='" + ddlExhibitions.SelectedItem.Text + "'";
            }
            dt = dw.GetAllFromQuery("Select F.Sno,E.Sno as exbitorsno, E.ExbName,E.Address,E.state,E.Email,E.ContactNo,ISNULL(E.SalesPerson,'') SalesPerson,F.Dest,F.Country,F.Source,F.ExbOrgName,f.ExbOrgContactperson,f.remarks from FairDetails_Ex F inner join ExhibitorsList E on F.sno=E.ExhibitionSno inner join AssignExbToExhibitors A on F.Sno=A.ExbSno " + whereclous + "");
            if (dt.Rows.Count > 0)
            {
                table += "<table border='1' style='font-family: sans-serif; border-collapse: collapse; width: 1450px; font-size: initial; font-weight: 700; background-color: #FFFFF; color: black;'><tr><td>Exb Name :" + ddlExhibitions.SelectedItem.Text + "</td><td>DEST:" + Convert.ToString(dt.Rows[0]["Dest"]) + "</td><td>COUNTRY:" + Convert.ToString(dt.Rows[0]["Country"]) + "</td><td>VENUE:" + Convert.ToString(dt.Rows[0]["Source"]) + "</td><td>Organiser:" + Convert.ToString(dt.Rows[0]["ExbOrgName"]) + "</td><td>Contact Person:" + Convert.ToString(dt.Rows[0]["ExbOrgContactperson"]) + "</td><td>Remarks:" + Convert.ToString(dt.Rows[0]["remarks"]) + "</td></tr></table>";
                table += "<table  border='1' style='font-family: arial, sans-serif;border-collapse: collapse;width: 100%;font-size: initial;font-weight: 800;background-color: bisque;text-decoration: underline;'><tr><td>EHIBITORS DETAILS</td></tr></table>";
                table += "<table class='GridViewStyle' cellspacing=0 rules=all border=1 id='ctl00_ContentPlaceHolderMain_gridview1' style='border-collapse:collapse;'>";
                table += "<tbody><tr class='HeaderStyle' style='color:White;background-color:#646464;font-size:16px;height:25px;'><th scope='col'>Exhibitors Name</th><th scope='col'>Remarks</th><th scope='col'>Contact Person</th><th scope='col'>Email</th><th scope='col'>Country</th><th scope='col'>Address</th><th scope='col'>State</th><th scope='col'>SalesPerson</th></tr>";
                Innertable += "<table class='GridViewStyle' cellspacing='0' rules=all border='1' id=ctl00_ContentPlaceHolderMain_Gv_Coominication style=height:1px;width:100%;border-collapse:collapse;><tbody><tr class=HeaderStyle><th scope=col>Sr.No</th><th scope=col>Communication</th><th scope='col'>Date</th><th scope='col'>Sales Person</th><th scope='col'>Remarks</th></tr>";
                DataTable dtsales = new DataTable();
                for (int ii = 0; ii < dt.Rows.Count; ii++)
                {
                    DataTable dtiiner = dw.GetAllFromQuery("select Sno,Communication,CONVERT(char(20),Date,106) as [Date],SalesPersonSno,Remarks,ExhibitionSno,ExbitorSno from [dbo].[ExhibitorsCommunication] where ExbitorSno=" + Convert.ToInt32(dt.Rows[ii]["exbitorsno"]) + "");
                    dtsales = dw.GetAllFromQuery("select DISTINCT upper(DisplayName) AS DisplayName,Sno from Login where sno in(" + Convert.ToString(dt.Rows[ii]["SalesPerson"]) + ") and Active='Y' and UPPER(LoginType) LIKE'%SALES-PERSON%'");
                    if (dtsales.Rows.Count > 0)
                    {
                        salesName = "";
                        foreach (DataRow dr in dtsales.Rows)
                        {
                            salesName += dr["DisplayName"].ToString() + ",";
                        }
                        salesName = salesName.TrimEnd(',');
                    }
                    //table += "<tr class='RowStyle'><td><a id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblExname' href=ExhibitorsTrackToExhibition.aspx?ExSno=" + Convert.ToString(dt.Rows[ii]["Sno"]) + "&ExbSno=" + Convert.ToString(dt.Rows[ii]["exbitorsno"]) + ">" + Convert.ToString(dt.Rows[ii]["ExbName"]) + "</a></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblRe'>" + Convert.ToString(dt.Rows[ii]["remarks"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblContPerson'>" + Convert.ToString(dt.Rows[ii]["ExbOrgContactperson"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lbldate'>" + Convert.ToString(dt.Rows[ii]["Email"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblCountry'>" + Convert.ToString(dt.Rows[ii]["Country"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblAddress'>" + Convert.ToString(dt.Rows[ii]["Address"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblstate'>" + Convert.ToString(dt.Rows[ii]["state"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblstate'>" + salesName + "</span></td></tr>";
                    table += "<tr class='RowStyle'><td>" + Convert.ToString(dt.Rows[ii]["ExbName"]) + "</td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblRe'>" + Convert.ToString(dt.Rows[ii]["remarks"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblContPerson'>" + Convert.ToString(dt.Rows[ii]["ExbOrgContactperson"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lbldate'>" + Convert.ToString(dt.Rows[ii]["Email"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblCountry'>" + Convert.ToString(dt.Rows[ii]["Country"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblAddress'>" + Convert.ToString(dt.Rows[ii]["Address"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblstate'>" + Convert.ToString(dt.Rows[ii]["state"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_gridview1_ctl02_lblstate'>" + salesName + "</span></td></tr>";

                    if (dtiiner.Rows.Count > 0)
                    {
                        table += "<tr><td colspan='8' style='text-align=left;font-size: 16px; font-weight: 900;'>History Of Exhibitor: [" + Convert.ToString(dt.Rows[ii]["ExbName"]) + "]</td></tr>";
                        table += "<tr><td colspan='8' style='text-align=left'>" + Innertable + "";
                        for (int jjj = 0; jjj < dtiiner.Rows.Count; jjj++)
                        {
                            table += "<tr class='RowStyle' style='background-color: bisque;'><td>" + Convert.ToString(jjj + 1) + "</td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lblcomm'>" + Convert.ToString(dtiiner.Rows[jjj]["Communication"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lbldate'>" + Convert.ToString(dtiiner.Rows[jjj]["Date"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lblsales'>" + Convert.ToString(dtiiner.Rows[jjj]["SalesPersonSno"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lblremarks'>" + Convert.ToString(dtiiner.Rows[jjj]["Remarks"]) + "</span></td></tr>";
                        }
                        table += "</tbody></table></td></tr>";
                        table += "<tr><td colspan='8' style='border-bottom-width: thick;border-bottom-color: #0055e5;'></td></tr>";
                    }
                    //if (dtiiner.Rows.Count > 0)
                    //{
                    //    for (int jjj = 0; jjj < dtiiner.Rows.Count; jjj++)
                    //    {
                    //        table += "<tr class='RowStyle'><td>" + Convert.ToString(jjj) + "</td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lblcomm'>" + Convert.ToString(dtiiner.Rows[jjj]["Communication"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lbldate'>" + Convert.ToString(dtiiner.Rows[jjj]["Date"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lblsales'>" + Convert.ToString(dtiiner.Rows[jjj]["SalesPersonSno"]) + "</span></td><td><span id='ctl00_ContentPlaceHolderMain_Gv_Coominication_ctl02_lblremarks'>" + Convert.ToString(dtiiner.Rows[jjj]["Remarks"]) + "</span></td></tr>";
                    //    }
                    //    table += "</tbody></table></td></tr>";
                    //    table += "<tr><td colspan='8' style='border-bottom-width: thick;border-bottom-color: #0055e5;'></br></br></td></tr>";
                    //} 
                }
                table += "</tbody></table>";
                lblReport.Text = table;
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    void LoadExhibitorByExhibition(int Exhibitions)
    {
        try
        {
            //string[] strsss;
            // string[] strsales;

            DataTable dtAssignExbToExhibitors = dw.GetAllFromQuery("select top 1 ExbSno,ExhibitorSno,SalesPerson from AssignExbToExhibitors where ExbSno=" + Exhibitions + "");
            if (dtAssignExbToExhibitors.Rows.Count > 0)
            {

            }
        }
        catch (Exception)
        {

            throw;
        }
    }
}