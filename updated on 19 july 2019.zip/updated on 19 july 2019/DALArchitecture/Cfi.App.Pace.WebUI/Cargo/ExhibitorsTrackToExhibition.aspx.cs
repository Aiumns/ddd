﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Xml;
using System.Globalization;

public partial class Cargo_ExhibitorsTrackToExhibition : BasePage
{
    DisplayWrap obj = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    DataTable dtTemp = null;
    DataTable dtCarr = null;
    public StringBuilder strData = new StringBuilder();
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        //ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        //if (Session["txtcleitnid"] != null)
        //{
        //    TextBox txt = (TextBox)Session["txtcleitnid"];
        //    strData.Append("<a href='javascript:void(0);'  onClick=\"setYears(1947, " + (DateTime.Now.Year + 1) + ");showCalender(this, '" + txt.ClientID + "');\"> <img  src='../Images/calender.png'></a>");
        //    strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        //}
        if (!IsPostBack)
        {
            int SnoFromArabPlast = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromArabPlast"]));
            int SnoFromArabPlast2 = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["FairSno"]));
            ViewState["SnoFromArabPlast"] = SnoFromArabPlast;
            ViewState["FairSno"] = SnoFromArabPlast2;
            if (SnoFromArabPlast != 0)
            {
                LoadExhibitorsCommunicationByExhibitor(SnoFromArabPlast);
                LoadSelectedData(SnoFromArabPlast);
            }
            //From Report Page
            int ExSno = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["ExSno"]));
            int ExbSno = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["ExbSno"]));
           
            if(ExSno!=0)
               {                    
                    ViewState["FairSnoFromReport"] = ExSno;
               }             
           if (ExbSno != 0)
            {
                LoadExhibitorsCommunicationByExhibitor(ExbSno);
                LoadSelectedData(ExbSno);
            }
            maketable();
        }
    }

    void LoadExhibitorByExhibition(int Exhibitions)
    {
        try
        {
            string[] strsales;
            DataTable dtAssignExbToExhibitors = dw.GetAllFromQuery("select top 1 ExbSno,ExhibitorSno,SalesPerson from AssignExbToExhibitors where ExbSno=" + Exhibitions + "");
            if (dtAssignExbToExhibitors.Rows.Count > 0)
            {
                strsales = Convert.ToString(dtAssignExbToExhibitors.Rows[0]["SalesPerson"]).Split(',');
                foreach (string salesid in strsales)
                {
                    //for (int icount = 0; icount < lstsalesperson.Items.Count; icount++)
                    //{
                    //    if (salesid == lstsalesperson.Items[icount].Value.ToString())
                    //    {
                    //        lstsalesperson.Items[icount].Selected = true;
                    //    }
                    //}
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    void LoadExhibitorsCommunicationByExhibitor(int id)
    {
        DataTable dt=obj.GetAllFromQuery("select * from [dbo].[ExhibitorsCommunication] where ExbitorSno="+ id +""); 
        if(dt.Rows.Count>0)
        {
            Gv_Coominication.Attributes.Clear();
            Gv_Coominication.DataSource = obj.GetAllFromQuery("select * from [dbo].[ExhibitorsCommunication] where ExbitorSno="+ id +"");      
            Gv_Coominication.DataBind();     
        }
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }

    void LoadSelectedData(int Exhibitorid)
    {
        string strwhere = "";
        if (Exhibitorid != 0)
        {
            strwhere = "Sno=" + Exhibitorid + " and";
        }
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter("select * from ExhibitorsList where  SNO=" + Exhibitorid + "", con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0 && Exhibitorid != 0)
        {
            //ViewState["ExbSno"] = Convert.ToString(ds.Tables[0].Rows[0]["Sno"]);
            //Session["a"] = Convert.ToString(ds.Tables[0].Rows[0]["Exname"]);
            //Session["b"] = Convert.ToString(ds.Tables[0].Rows[0]["remarks"]);
            //Session["c"] = Convert.ToString(ds.Tables[0].Rows[0]["Dest"]);
            //Session["d"] = Convert.ToString(ds.Tables[0].Rows[0]["VDate"]);
            //Session["e"] = Convert.ToString(ds.Tables[0].Rows[0]["Country"]);
            //Session["f"] = Convert.ToString(ds.Tables[0].Rows[0]["Source"]);
            //Session["g"] = Convert.ToString(ds.Tables[0].Rows[0]["SalesPerson"]);

            lblexbname.Text = Convert.ToString(ds.Tables[0].Rows[0]["ExbName"]);
            lblremarks.Text = Convert.ToString(ds.Tables[0].Rows[0]["remarks"]);
            lblcontactperson.Text = Convert.ToString(ds.Tables[0].Rows[0]["ContactPerson"]);
            lblemail.Text = Convert.ToString(ds.Tables[0].Rows[0]["Email"]);
            lblcountry.Text = Convert.ToString(ds.Tables[0].Rows[0]["Country"]);
            lblstate.Text = Convert.ToString(ds.Tables[0].Rows[0]["State"]);
            lbladdress.Text = Convert.ToString(ds.Tables[0].Rows[0]["Address"]);
            lblHeaderexbname.Text = Convert.ToString(ds.Tables[0].Rows[0]["ExbName"]);
            //gridview1.Visible = false;
        }
        else { 
           // gridview1.Visible = true; 
        }
    }
    protected void cmdCancel_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ViewState["FairSno"]) != 0)
        {
            int id = Convert.ToInt32(ViewState["FairSno"]);
            Response.Redirect("Add_ExbArabPlast.aspx?SnoBackFromExbTrackOnCancel=" + id + "");
        }
        else if (Convert.ToInt32(ViewState["FairSnoFromReport"]) != 0)
        {
            int id = Convert.ToInt32(ViewState["FairSnoFromReport"]);
            //Response.Redirect("ExhibitionReportManagment.aspx?SnoBackToReportOnCancel=" + id + "");
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "window.location ='ExhibitionReportManagment.aspx?SnoBackFromExbTrackOnCancel=" + id + "';", true);
        }
        else
        {
            Response.Redirect("AddExhibitors.aspx");
        }
    }

    public void maketable()
    {
        dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Communication";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "SalesPersonSno";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Remarks";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dtTemp.Rows.Add(dr);
        Session["dtTemp"] = dtTemp;
        ViewState["dtBeginCharges"] = dtTemp;

        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();

        //dc1 = new DataColumn();
        //dc1.ColumnName = "Origin_Code";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "Destination_code";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "rate";
        //dc1.DataType = System.Type.GetType("System.Decimal");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "flight_no";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "flight_date";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "Carrier";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);       
    }
    //public DataTable GetCarrLoad()
    //{
    //    dtCarr = new DataTable();
    //    DataColumn dc1 = new DataColumn();

    //    dc1 = new DataColumn();
    //    dc1.ColumnName = "SNo";
    //    dc1.DataType = System.Type.GetType("System.Int16");
    //    dc1.AutoIncrement = true;
    //    dc1.AutoIncrementStep = 1;
    //    //dc1.AutoIncrementSeed = 1;
    //    dtCarr.Columns.Add(dc1);

    //    dc1 = new DataColumn();
    //    dc1.ColumnName = "CarrierCode";
    //    dc1.DataType = System.Type.GetType("System.String");
    //    dtCarr.Columns.Add(dc1);


    //    DataRow dr = dtCarr.NewRow();
    //    dr[0] = 1;
    //    dr[1] = "jitendra";
    //    dtCarr.Rows.Add(dr);

    //    DataRow dr2 = dtCarr.NewRow();
    //    dr2[1] = "Manish";
    //    dtCarr.Rows.Add(dr2);
    //    Session["Carrdll"] = dtCarr;
    //    return dtCarr;
    //}
    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            //lblmsg.Visible = true;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        else
        {
            //lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
    }
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            ///////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
        }
        else
        {
            maketable();
            DataTable dtBeginCharges = (DataTable)ViewState["dtBeginCharges"];
            Session["dtTemp"] = dtBeginCharges;
            grdCal.DataSource = dtBeginCharges;
            grdCal.DataBind();
        }
    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        string ddlcomm = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlcomm")).SelectedValue;
        string txtdate = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtdate")).Text;
        string SalesPersonSno = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlsales")).SelectedValue;
        string txtremarks = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtremarks")).Text;
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = ddlcomm;
                dr[2] = txtdate;
                dr[3] = SalesPersonSno;
                dr[4] = txtremarks;
            }
        }
        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();
    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();
                //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames                
                string ddlcomm = ((DropDownList)grdCal.FooterRow.FindControl("ddlcomm")).SelectedValue;
                string txtdate = ((TextBox)grdCal.FooterRow.FindControl("txtdate")).Text;
               
                string ddlsales = ((DropDownList)grdCal.FooterRow.FindControl("ddlsales")).SelectedValue;
                string txtremarks = ((TextBox)grdCal.FooterRow.FindControl("txtremarks")).Text;

                dr[1] = ddlcomm;
                dr[2] = txtdate;
                dr[3] = ddlsales;
                dr[4] = txtremarks;
                dt.Rows.Add(dr);
                Session["dtTemp"] = dt;
                grdCal.DataSource = dt;
                grdCal.DataBind();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }
    protected void grdCal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && grdCal.EditIndex == e.Row.RowIndex)
        {
            DropDownList ddlsales = (DropDownList)e.Row.FindControl("ddlsales");
            ddlsales.DataSource = obj.GetAllFromQuery("select distinct DisplayName as SalespersonSno from Login where LoginType='SALES-PERSON' and Active='Y' order by DisplayName");
            ddlsales.DataTextField = "SalespersonSno";
            ddlsales.DataValueField = "SalespersonSno";
            ddlsales.DataBind();
            string Carrier = (e.Row.DataItem as DataRowView)["SalesPersonSno"].ToString();
            ddlsales.Items.FindByValue(Carrier).Selected = true;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            //Session["txtcleitnid"] = ((TextBox)grdCal.FooterRow.FindControl("txtdate"));
            DropDownList ddlsales = (DropDownList)e.Row.FindControl("ddlsales");
            ddlsales.DataSource = obj.GetAllFromQuery("select distinct DisplayName as SalespersonSno from Login where LoginType='SALES-PERSON' and Active='Y' order by DisplayName");
            ddlsales.DataTextField = "SalespersonSno";
            ddlsales.DataValueField = "SalespersonSno";
            ddlsales.DataBind();
            //Add Default Item in the DropDownList.
            ddlsales.Items.Insert(0, new ListItem("Please select"));
        }
    }
    protected void grdCal_DataBound(object sender, EventArgs e)
    {

    }
   
    protected void btnid_Click(object sender, EventArgs e)
    {
        int status = 0;
        //int counter = 0;
        int Exbitorid = 0;
        if (ViewState["SnoFromArabPlast"] != null)
        {
            Exbitorid = Convert.ToInt32(ViewState["SnoFromArabPlast"]);
        }       
        con = new SqlConnection(strCon);
        try
        {          
            con.Open();
            if (grdCal.Rows.Count > 0)
            {  
                foreach (GridViewRow row in grdCal.Rows)
                {
                    //counter++;
                    Label lblcomm = row.FindControl("lblcomm") as Label;
                    Label lbldate = row.FindControl("lbldate") as Label;
                    Label lblremarks = row.FindControl("lblremarks") as Label;
                    Label lblsales = row.FindControl("lblsales") as Label;
                    string strddt = FormatDateMM(lbldate.Text);
                    DateTime oDate = Convert.ToDateTime(strddt);
                    com = new SqlCommand("INSERT INTO [dbo].[ExhibitorsCommunication]([ExbitorSno],[Communication],[Date],[SalesPersonSno],[Remarks],[ExhibitionSno]) values(@ExbitorSno,@Communication,@Date,@SalesPersonSno,@Remarks,@ExhibitionSno)", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@ExbitorSno", Exbitorid);
                    com.Parameters.AddWithValue("@Communication", lblcomm.Text);
                    com.Parameters.AddWithValue("@Date", oDate);
                    com.Parameters.AddWithValue("@SalesPersonSno", lblsales.Text);
                    com.Parameters.AddWithValue("@Remarks", lblremarks.Text);
                    com.Parameters.AddWithValue("@ExhibitionSno",Convert.ToInt32(ViewState["FairSno"])); 
                    status = com.ExecuteNonQuery();
                }               
            }
            con.Close();
            if (status == 1)
            {
                 //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Record updated successfully...!');", true);
                //Response.Redirect("AddExhibitors.aspx");
                int Fairid = 0;
                if (ViewState["FairSno"] != null)
                {
                    Fairid = Convert.ToInt32(ViewState["FairSno"]);
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record updated successfully...');window.location ='Add_ExbArabPlast.aspx?SnoBackFromExbTrack=" + Fairid + "';", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record updated successfully...');window.location ='AddExhibitors.aspx';", true);
                } 
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record updated successfully...');window.location ='AddExhibitors.aspx';", true);
            }
        }
        catch (Exception)
        {

            throw;
        }  
    }
}