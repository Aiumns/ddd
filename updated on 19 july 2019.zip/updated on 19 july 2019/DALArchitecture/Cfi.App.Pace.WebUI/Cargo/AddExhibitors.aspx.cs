﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web.UI;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net;
using iTextSharp.text.html.simpleparser;
using Cfi.App.Pace.Business;

public partial class Cargo_AddExhibitors : BasePage
{
    private AppControls_Messages ucMessage = null;
    DisplayWrap dw = new DisplayWrap();
    SqlConnection con = null;
    SqlCommand com = null;
    SqlCommand cmd = null;
    SqlDataReader dr = null;
    BAgentMaster bAgent = new BAgentMaster();
    BBookingConfirmed BC = new BBookingConfirmed();  
    string SnoEx = "";
    string strCon = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
    /// <summary>
    /// The action click handler.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="actionAndCancelButtonEventArgs">
    /// The action and cancel button event args.
    /// </param>    
    public delegate void ActionClickHandler(object sender, ActionEventArgs actionAndCancelButtonEventArgs);
    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
    public event ActionClickHandler ActionClick;
    int SnoFromExbDetails = 0;
    int ExhibitorSnoFromArabPlast = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        //string SnoFromArabPlast = Convert.ToString(HttpUtility.UrlDecode(Request.QueryString["SnoFromArabPlast"]));
        //Session["SnoFromExbDetails"] = Convert.ToString(HttpUtility.UrlDecode(Request.QueryString["SnoFromArabPlast"]));
        if (Session["SnoFromExbDetails"] == null)
        {
            Session["SnoFromExbDetails"] = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbDetails"]));
            SnoFromExbDetails = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbDetails"]));
        }
        else
        {
            SnoFromExbDetails = Convert.ToInt32(Session["SnoFromExbDetails"]);
        }
        //Getting Exbitor Sno From Arab Plast For Edit   

        ExhibitorSnoFromArabPlast = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["ExhibitorSnoFromArabPlastForUpdate"]));
        ViewState["ExhibitorSnoFromArabPlastForUpdate"] = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["ExhibitorSnoFromArabPlastForUpdate"]));

        if (!IsPostBack)
        {          
            fillSalesPerson();
            //if (ExhibitorSnoFromArabPlast != 0)
            //{
            //    LoadExhibitorByExhibition(SnoFromExbDetails);
            //}           
            LoadExhibitorsList();
            LoadCountry();
            LoadExName(); 
           //string SnoFromExbitionTrack = Convert.ToString(HttpUtility.UrlDecode(Request.QueryString["SnoFromExbitionTrack"]));
            if (SnoFromExbDetails != 0 && ExhibitorSnoFromArabPlast==0)
            {
                ddlExbName.SelectedIndex = ddlExbName.Items.IndexOf(ddlExbName.Items.FindByValue(SnoFromExbDetails.ToString()));
                div1id.Visible = false;
                pnlgrid.Visible = false;
                pnlVisitingCustomer.Visible = true;
                cmdAction.Text = "";
                cmdAction.Text = "Save";
            }
            else if (SnoFromExbDetails != 0 && ExhibitorSnoFromArabPlast != 0)
            {
                SelectedSalesByExhibition(SnoFromExbDetails, ExhibitorSnoFromArabPlast);
                //LoadExhibitorByExhibition(SnoFromExbDetails);
                div1id.Visible = false;
                pnlgrid.Visible = false;
                pnlVisitingCustomer.Visible = true;
                if (ExhibitorSnoFromArabPlast != 0)
                {
                    if (LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows.Count > 0)
                    {
                        //General Information
                        hdnPrimaryKeyValue.Value = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["Sno"]);
                        txtName.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["exbname"]);
                        txtRemarks.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["remarks"]);
                        txtEmail.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["Email"]);
                        txtState.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["State"]);
                        txtAddress.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["Address"]);
                        txtContactNo.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["ContactNo"]);
                        //ddlExbName.SelectedItem.Text = Convert.ToString(LoadGetData(ExhibitorSnoFromArabPlast).Rows[0]["FairName"]);
                        string strdatajjj = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["FairName"]);
                        ddlExbName.SelectedIndex = ddlExbName.Items.IndexOf(ddlExbName.Items.FindByText(strdatajjj));
                        txtContPerson.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["ContactPerson"]);
                        ddlCountry.SelectedItem.Text = Convert.ToString(LoadExhibitorByExbSno(ExhibitorSnoFromArabPlast).Rows[0]["Country"]);                   
                    }
                }
                cmdAction.Text = "";
                cmdAction.Text = "Update";
            }
            else
            {             
                div1id.Visible = true;
                pnlgrid.Visible = true;
                pnlVisitingCustomer.Visible = false;
            }   
        }

    }

    void SelectedSalesByExhibition(int Exhibitions,int exhibitorSno)
    {
        try
        {           
            string[] strsales;
            DataTable dtAssignExbToExhibitors = dw.GetAllFromQuery("select sno, SalesPerson from ExhibitorsList where ExhibitionSno=" + Exhibitions + " and sno=" + exhibitorSno + "");
            if (dtAssignExbToExhibitors.Rows.Count > 0)
            {
                strsales = Convert.ToString(dtAssignExbToExhibitors.Rows[0]["SalesPerson"]).Split(',');
                foreach (string salesid in strsales)
                {
                    for (int icount = 0; icount < lstsalesperson.Items.Count; icount++)
                    {
                        if (salesid == lstsalesperson.Items[icount].Value.ToString())
                        {
                            lstsalesperson.Items[icount].Selected = true;
                        }
                    }
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    public void fillSalesPerson()
    {
        DataTable dtsales = dw.GetAllFromQuery("select DISTINCT upper(DisplayName) AS DisplayName,Sno from Login where Active='Y' and UPPER(LoginType) LIKE'%SALES-PERSON%'");
        //BBookingConfirmed BC = new BBookingConfirmed();
        //BC.CompBrSNo = int.Parse(Session["CompBrSNo"].ToString());
        //SqlDataReader dr = BC.getSalesPerson();
        //chksalesperson.Items.Clear();
        //chksalesperson.Items.Add(new ListItem("Select", "0"));
        foreach (DataRow row in dtsales.Rows)
        {
            //chksalesperson.Items.Add(new ListItem(row["DisplayName"].ToString(), row["Sno"].ToString()));
            lstsalesperson.Items.Add(new ListItem(row["DisplayName"].ToString(), row["Sno"].ToString()));
        }
    }

    void LoadExName()
    {
        try
        {
            string strExbName = "select distinct Sno,Exname from FairDetails_Ex where ISNULL(Exname,'')!='' order by Exname";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmdiner = new SqlCommand(strExbName, con);
            SqlDataReader dr;
            dr = cmdiner.ExecuteReader();
            ddlExbName.Items.Clear();
            ddlExbName.Items.Insert(0, "- -Select- -");
            ddlExbName.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlExbName.Items.Add(new ListItem(dr["Exname"].ToString(), dr["Sno"].ToString()));
            }
            con.Close();
        }
        catch (Exception)
        {
            throw;
        }
    }
    void LoadCountry()
    {
        try
        {
            SqlDataReader drCountry = bAgent.CountryCode_Show();
            ddlCountry.AppendDataBoundItems = true;
            ddlCountry.Items.Insert(0, new ListItem("Select Country", "0"));
            while (drCountry.Read())
            {
                ddlCountry.Items.Add(new ListItem("" + drCountry["CountryName"].ToString() + "", "" + drCountry["CountryCode"].ToString() + ""));               
            }          
        }
        catch (Exception)
        {

            throw;
        }
    }
    void LoadExhibitorsList()
    {
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter("select * from ExhibitorsList ORDER BY Exbname", con);    
        DataSet ds = new DataSet();
        ad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridview1.Attributes.Clear();
            gridview1.DataSource = ds;
            gridview1.DataBind();
        }
    }
    //protected void cmdAction_ExportpdfClick(object sender, EventArgs e)
    //{
    //    if (CfiddlTypesearch.SelectedValue == "AllType")
    //    {
    //        Response.Redirect("Visitor_rpt.aspx", false);
    //    }

    //}
    protected void cmdAction_SearchClick(object sender, EventArgs e)
    {
        try
        {
            string strque = string.Empty;


            string strdatesearch = string.Empty;
            string fromdt = string.Empty;
            string todt = string.Empty;
            if (txtTodate.Text != "" && txtFromdate.Text != "")
            {
                DateTime Fromdate = Convert.ToDateTime(txtFromdate.Text.ToString());
                DateTime todates = Convert.ToDateTime(txtTodate.Text.ToString());
                fromdt = Fromdate.ToString("MM/dd/yyyy");
                todt = todates.ToString("MM/dd/yyyy");
                strdatesearch = "and Date Between '" + fromdt + "' and '" + todt + "'";
            }
            else if (txtTodate.Text == "" && txtFromdate.Text != "")
            {
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "alert", "Please Enter Valid date!", true);
                return;
            }
            else if (txtTodate.Text != "" && txtFromdate.Text == "")
            {
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "alert", "Please Enter Valid date!", true);
                return;
            }
            else if (txtTodate.Text == "" && txtFromdate.Text == "")
            {
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "alert", "Please Enter Valid date!", true);
                return;
            }



            if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text == "")
            {
                strque = "where compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text != "")
            {
                strque = "where exbname like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text == "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Exhibition" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text != "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and exbname like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text == "")
            {
                strque = "where compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text != "")
            {
                strque = "where dest like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text == "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Venue" && CfiddlTypesearch.SelectedValue != "B" && CfitxtSearch.Text != "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and Sales_Person like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }

            else if (Cfiddlsearch.SelectedValue == "Select" && CfiddlTypesearch.SelectedValue == "B" && CfitxtSearch.Text != "")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Select" && CfiddlTypesearch.SelectedValue == "B")
            {
                strque = "where compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }
            else if (Cfiddlsearch.SelectedValue == "Select" && CfiddlTypesearch.SelectedValue != "B")
            {
                strque = "where type='" + CfiddlTypesearch.SelectedValue + "' and compbrsno=" + Session["CompBrSNo"].ToString() + "";
            }




            if (strque != "" && strdatesearch != "")
            {
                strque = strque + strdatesearch;
            }
            else if (strque != "" && strdatesearch == "")
            {
                strque = strque + "";
            }
            else if (strque == "" && strdatesearch != "")
            {
                strque = strque + "where Date Between '" + fromdt + "' and '" + todt + "'";
            }
            else if (strque == "" && strdatesearch == "")
            {
                strque = "";
            }


            if (strque != "")
            {
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(constr);
                SqlDataAdapter ad = new SqlDataAdapter("select CONVERT(char(20),Date,106) as VDate,* from FairDetails_Ex " + strque + " ORDER BY date", con);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gridview1.Attributes.Clear();
                    gridview1.DataSource = ds;
                    gridview1.DataBind();
                }
                else
                {
                    gridview1.Attributes.Clear();
                    gridview1.DataSource = ds;
                    gridview1.DataBind();
                }
            }
            else
            {
                gridview1.Attributes.Clear();
                gridview1.DataSource = null;
                gridview1.DataBind();
            }
            #region commented
            //if (Cfiddlsearch.SelectedValue != "Select")
            //{
            //    if (Cfiddlsearch.SelectedValue == "Customer")
            //    {
            //        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //        SqlConnection con = new SqlConnection(constr);
            //        SqlDataAdapter ad = new SqlDataAdapter("select CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where CustomerName like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY SNO DESC", con);
            //        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //        DataSet ds = new DataSet();
            //        ad.Fill(ds);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            //gridview2.DataSource = ds;
            //            //gridview2.DataBind();
            //            //Session["VisitData"] = null;
            //            //Session["VisitData"] = ds.Tables[0];
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //        else
            //        {
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //    }
            //    else if (Cfiddlsearch.SelectedValue == "Sales")
            //    {
            //        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //        SqlConnection con = new SqlConnection(constr);
            //        SqlDataAdapter ad = new SqlDataAdapter("select  CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where Sales_Person like '%" + CfitxtSearch.Text + "%' and compbrsno=" + Session["CompBrSNo"].ToString() + "  ORDER BY SNO DESC", con);
            //        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //        DataSet ds = new DataSet();
            //        ad.Fill(ds);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            //gridview2.DataSource = ds;
            //            //gridview2.DataBind();
            //            //Session["VisitData"] = null;
            //            //Session["VisitData"] = ds.Tables[0];
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //        else
            //        {
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //    }
            //    else
            //    {
            //        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //        SqlConnection con = new SqlConnection(constr);
            //        SqlDataAdapter ad = new SqlDataAdapter("select CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY SNO DESC", con);
            //        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //        DataSet ds = new DataSet();
            //        ad.Fill(ds);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            //gridview2.DataSource = ds;
            //            //gridview2.DataBind();
            //            //Session["VisitData"] = null;
            //            //Session["VisitData"] = ds.Tables[0];
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //        else
            //        {
            //            gridview1.Attributes.Clear();
            //            gridview1.DataSource = ds;
            //            gridview1.DataBind();
            //        }
            //    }
            //Cfiddlsearch.ClearSelection();
            //Cfiddlsearch.Items.FindByText("Select").Selected = true;
            //CfitxtSearch.Text = "";
            //}
            //else
            //{
            //    string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //    SqlConnection con = new SqlConnection(constr);
            //    SqlDataAdapter ad = new SqlDataAdapter("select CustomerName,CompanyName,CustomerAddress,Country,Type,City,ContactNo,EmailID,Sno,FileName,Sales_Person from RegistrationVisitingCustomer where compbrsno=" + Session["CompBrSNo"].ToString() + " ORDER BY SNO DESC", con);
            //    // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
            //    DataSet ds = new DataSet();
            //    ad.Fill(ds);
            //    if (ds.Tables[0].Rows.Count > 0)
            //    {
            //        //gridview2.DataSource = ds;
            //        //gridview2.DataBind();
            //        //Session["VisitData"] = null;
            //        //Session["VisitData"] = ds.Tables[0];
            //        gridview1.DataSource = ds;
            //        gridview1.DataBind();
            //    }
            //    Cfiddlsearch.ClearSelection();
            //    Cfiddlsearch.Items.FindByText("Select").Selected = true;
            //    CfitxtSearch.Text = "";
            //}
            #endregion
        }
        catch (Exception)
        {
            throw;
        }
    }
    public DataTable LoadExhibitorByExbSno(int Sno)
    {
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter ad = new SqlDataAdapter("SELECT * from ExhibitorsList where sno=" + Sno + "", con);
        // SqlDataAdapter ad = new SqlDataAdapter("SELECT TOP 2 * FROM [dbo].[tblFileUpload] order by sno desc", con);
        DataTable dt = new DataTable();
        ad.Fill(dt);
        return dt;
    }
    protected void Row_Selected(object sender, EventArgs e)
    {
        try
        {
            //Get the Button reference.
            Button btnSelect = (sender as Button);
            //Get the Command Name.
            string commandName = btnSelect.CommandName;
            if (commandName == "Selected")
            {
                //Get the Row reference in which Button was clicked.
                GridViewRow row = (btnSelect.NamingContainer as GridViewRow);
                int rowIndex = row.RowIndex;
                //Get the Row Index.
                //StringBuilder strQue = new StringBuilder();

                //Get the Command Argument.
                int Sno = Convert.ToInt32(btnSelect.CommandArgument.ToString());
                SnoEx = Convert.ToString(Sno);
                hdnPrimaryKeyValue.Value = Convert.ToString(Sno);
                //LoadGetData(Sno);
                if (LoadExhibitorByExbSno(Sno) != null)
                {
                    if (LoadExhibitorByExbSno(Sno).Rows.Count > 0)
                    {
                        //General Information
                        txtName.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["exbname"]);
                        txtRemarks.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["remarks"]);
                        txtEmail.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["Email"]);
                        txtState.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["State"]);
                        txtAddress.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["Address"]);
                        txtContactNo.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["ContactNo"]);
                        ddlExbName.SelectedItem.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["FairName"]);
                        txtContPerson.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["ContactPerson"]);
                        ddlCountry.SelectedItem.Text = Convert.ToString(LoadExhibitorByExbSno(Sno).Rows[0]["Country"]);                           
                        //Final
                        lblTitle.Text = string.Empty;
                        lblTitle.Text = "Update Exhibitors Details";
                        pnlVisitingCustomer.Visible = true;
                        div1id.Visible = false;
                        pnlgrid.Visible = false;
                        cmdAction.Text = "";
                        cmdAction.Text = "Update";
                    }
                }
            }
            else
            {
                lblTitle.Text = string.Empty;
                lblTitle.Text = "Add Exhibitors Details";
                cmdAction.Text = "";
                cmdAction.Text = "Save";
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {

        }
    }
    protected void cmdCancel_Click(object sender, EventArgs e)
    {
        pnlVisitingCustomer.Visible = false;
        div1id.Visible = true;
        pnlgrid.Visible = true;
        LoadExhibitorsList();
        txtName.Text = string.Empty;
        txtRemarks.Text = "";
        //txtSource.Text = string.Empty;
        txtContPerson.Text = string.Empty;

        //txtDate.Text = Convert.ToString(DateTime.Now.ToString());
        lblTitle.Text = "Add Exhibition Customer";
        cmdAction.Text = "";
        cmdAction.Text = "Save";
        /////NetworkName();

        //ddlNetworkName.ClearSelection();
        //ddlNetworkName.Items.FindByText("Select").Selected = true;

        Cfiddlsearch.ClearSelection();
        Cfiddlsearch.Items.FindByText("Select").Selected = true;
        CfitxtSearch.Text = "";
        //txtMeetingDate.Text = "";
        //txtMeetingDate.Text = Convert.ToString(DateTime.Now.ToString());    
       if (ViewState["ExhibitorSnoFromArabPlastForUpdate"] != null)  
        {
            //int FairSno=Convert.ToInt32(ViewState["FromArabPlast"]);
            //Response.Redirect("Add_ExbArabPlast.aspx?SnoFromArabPlastOnCancel=" + FairSno + "");
            int id = Convert.ToInt32(ViewState["ExhibitorSnoFromArabPlastForUpdate"]);
            if (id == 0)
            {
                Response.Redirect("Add_ExbArabPlast.aspx");
            }
            else if (id > 0)
            {
                Response.Redirect("Add_ExbArabPlast.aspx");
            }
            else
            {
                Response.Redirect("AddExhibitors.aspx"); 
            }
        }
        //else if (Session["FromArabPlast"] == null) 
        //{
        //    Response.Redirect("AddExhibitors.aspx");  
        //}
    }
    protected void cmdAction_Click(object sender, EventArgs e)
    {
        try
        {
            if (cmdAction.Text == "Save")
            {
                SaveData(e);
            }
            if (cmdAction.Text == "Update")
            {
                UpdateData(e);
            }
        }
        catch (Exception)
        {

            throw;
        }
        finally
        {

        }
        //switch (hdnUIModeType.Value)
        //{
        //    case "New": 
        //   break;
        //   case "Update":

        //   break;
        //   case "Delete":
        //   DeleteData(e);
        //   break;
        //}
    }
    private void SaveData(EventArgs e)
    {
        try
        {
           
            if (Session["LoginSNo"] != null)
            {
                if (txtName.Text == "")
                {
                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Enter Exhibition Name!');", true);
                    return;
                }
                string strsales = "";
                foreach (ListItem item in lstsalesperson.Items)
                {
                    if (item.Selected)
                    {
                        strsales += item.Value + ",";
                    }
                }
                strsales = strsales.TrimEnd(',');
                //con = new SqlConnection(strCon);
                //con.Open();
                //string cInsert = "INSERT INTO ExhibitorsList(exbname,country,ContactPerson,Email,ContactNo,remarks,Address,compbrsno,updatedOn,updatedBy)VALUES( '" + txtName.Text + "','" + txtContPerson.Text + "','" + ddlCountry.SelectedItem.Text + "','" + txtEmail.Text + "','" + txtContactNo.Text + "','" + txtRemarks.Text + "','" + txtAddress.Text + "','" + Session["CompBrSNo"].ToString() + "','" + DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])) + "','" + Session["DisplayName"].ToString() + "')";
                //com = new SqlCommand(cInsert, con);
                //int a = com.ExecuteNonQuery();
                //con.Close();
                con = new SqlConnection(strCon);
                con.Open();              
                com = new SqlCommand("InsertUpdt_Exhibitors", con);
                com.Parameters.AddWithValue("@Sno", 0);
                com.Parameters.AddWithValue("@exbname", txtName.Text);
                com.Parameters.AddWithValue("@country", ddlCountry.SelectedItem.Text);    
                com.Parameters.AddWithValue("@state", txtState.Text);
                com.Parameters.AddWithValue("@ContactPerson", txtContPerson.Text);
                com.Parameters.AddWithValue("@Email", txtEmail.Text);
                com.Parameters.AddWithValue("@ContactNo", txtContactNo.Text);
                com.Parameters.AddWithValue("@Address", txtAddress.Text);
                com.Parameters.AddWithValue("@FairName", ddlExbName.SelectedItem.Text); 
                com.Parameters.AddWithValue("@Compbrsno", Session["CompBrSNo"].ToString());
                com.Parameters.AddWithValue("@UpdatedOn", DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])));
                com.Parameters.AddWithValue("@UpdatedBy", Session["DisplayName"].ToString());            
                com.Parameters.AddWithValue("@remarks", txtRemarks.Text);
                com.Parameters.AddWithValue("@SalesPerson", strsales);
                com.Parameters.AddWithValue("@ExhibitionSno", ddlExbName.SelectedItem.Value); 
                com.CommandType = CommandType.StoredProcedure;
                int a = com.ExecuteNonQuery();
                con.Close();
                if (a >0)
                {
                    if (ExhibitorSnoFromArabPlast == 0)
                    {
                        string SnoFromArabPlast = Convert.ToString(HttpUtility.UrlDecode(Request.QueryString["SnoFromArabPlast"]));
                        //Response.Redirect("Add_ExbArabPlast.aspx?SnoBackFromExbitor=" + SnoFromArabPlast + "");
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record Saved successfully...!');window.location ='Add_ExbArabPlast.aspx';", true);
                    }
                    //else if (ViewState["ExhibitorSnoFromArabPlast"] != null)
                    //{
                    //    if (Convert.ToInt32(ViewState["ExhibitorSnoFromArabPlast"]) != 0)
                    //    {
                    //        int ExhibitorSnoFromArabPlast = Convert.ToInt32(HttpUtility.UrlDecode(Request.QueryString["ExhibitorSnoFromArabPlast"]));
                    //        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record Saved successfully...!');window.location ='Add_ExbArabPlast.aspx';", true);
                    //    }
                    //}
                    else
                    {
                        //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Record updated successfully...!');", true);
                        //Response.Redirect("AddExhibitors.aspx");
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record Saved successfully...!');window.location ='AddExhibitors.aspx';", true);
                    }
                }
            }

        }
        catch (Exception ex)
        {
            // ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            // CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            // cfiException.InsertExceptionIntoDatabase(true);
            //  ucMessage.Message = "Data could not be saved.";
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('" + ex.Message.ToString() + "')", true);
            return;
        }
        finally
        {

        }
    }
    private void UpdateData(EventArgs e)
    {
        try
        {
            if (!string.IsNullOrEmpty(hdnPrimaryKeyValue.Value))
            {
                if (Session["LoginSNo"] != null)
                {
                    //string update;
                    //update = "update ExhibitorsList set exbname='" + txtName.Text + "',contactperson='" + txtContPerson.Text + "',country='" + ddlCountry.SelectedItem.Text + "',Compbrsno='" + Session["CompBrSNo"].ToString() + "',updatedOn='" + DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])) + "',updatedBy='" + Session["DisplayName"].ToString() + "',remarks='" + txtRemarks.Text + "' ,Email='" + txtEmail.Text + "',Address='" + txtAddress.Text + "' where sno=" + Convert.ToString(hdnPrimaryKeyValue.Value) + "";
                    //con = new SqlConnection(strCon);
                    //con.Open();
                    //SqlCommand com = new SqlCommand(update, con);
                    //com.CommandType = CommandType.Text;
                    //int a = com.ExecuteNonQuery();
                    //con.Close();
                    string strsales = "";
                    foreach (ListItem item in lstsalesperson.Items)
                    {
                        if (item.Selected)
                        {
                            strsales += item.Value + ",";
                        }
                    }
                    strsales = strsales.TrimEnd(',');

                    con = new SqlConnection(strCon);
                    con.Open();
                    com = new SqlCommand("InsertUpdt_Exhibitors", con);
                    com.Parameters.AddWithValue("@Sno", Convert.ToInt32(hdnPrimaryKeyValue.Value));
                    com.Parameters.AddWithValue("@exbname", txtName.Text);
                    com.Parameters.AddWithValue("@country", ddlCountry.SelectedItem.Text);
                    com.Parameters.AddWithValue("@state", txtState.Text);
                    com.Parameters.AddWithValue("@ContactPerson", txtContPerson.Text);
                    com.Parameters.AddWithValue("@Email", txtEmail.Text);
                    com.Parameters.AddWithValue("@ContactNo", txtContactNo.Text);
                    com.Parameters.AddWithValue("@Address", txtAddress.Text);
                    com.Parameters.AddWithValue("@FairName", ddlExbName.SelectedItem.Text);
                    com.Parameters.AddWithValue("@Compbrsno", Session["CompBrSNo"].ToString());
                    com.Parameters.AddWithValue("@UpdatedOn", DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"])));
                    com.Parameters.AddWithValue("@UpdatedBy", Session["DisplayName"].ToString());
                    com.Parameters.AddWithValue("@remarks", txtRemarks.Text);
                    com.Parameters.AddWithValue("@SalesPerson", strsales);
                    com.Parameters.AddWithValue("@ExhibitionSno",Convert.ToInt32(ddlExbName.SelectedItem.Value)); 
                    com.CommandType = CommandType.StoredProcedure;
                    int a = com.ExecuteNonQuery();
                    con.Close();
                    if (a > 0)
                    {
                        //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Record updated successfully...!');", true);
                        //Response.Redirect("AddExhibitors.aspx");
                        if (ViewState["ExhibitorSnoFromArabPlastForUpdate"] != null)
                        {
                            if (Convert.ToInt32(ViewState["ExhibitorSnoFromArabPlastForUpdate"]) != 0)
                            {
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record Saved successfully...!');window.location ='Add_ExbArabPlast.aspx';", true);
                            }                           
                        }                       
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Record updated successfully...!');window.location ='AddExhibitors.aspx';", true);
                        }
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "Alert('Session Expired!')", true);
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            //ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            //CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            //cfiException.InsertExceptionIntoDatabase(true);
            //ucMessage.Message = "Action Not Performed"; ;
            //return;
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('" + ex.Message.ToString() + "')", true);
            return;
        }
    }
    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    private void NetworkName123()
    {
        //try
        //{
        //    ddlNetworkName.Items.Clear();
        //    using (CommonBusiness login = new CommonBusiness())
        //    {
        //        DataTable dtLogin = login.GetList("Login", "distinct DisplayName", "Active='Y' Order By DisplayName ASC");
        //        if (dtLogin != null && dtLogin.Rows.Count > 0)
        //        {
        //            Cfi.SoftwareFactory.Common.CommonFunctions.FillDropDownListFromTable(ref ddlNetworkName, dtLogin, "1", "DisplayName", string.Empty, "---Select---", true);
        //        }
        //    }
        //}
        //catch (Exception)
        //{
        //    throw;
        //}
        //finally
        //{

        //}
    }
    public void NetworkName()
    {
        //try
        //{
        //    DataTable dtSalesPerson = dw.GetAllFromQuery("select distinct DisplayName from login where LoginType='SALES-PERSON' and Active='Y' order by DisplayName");
        //    if (dtSalesPerson.Rows.Count > 0)
        //    {
        //        for (int i = 0; i < dtSalesPerson.Rows.Count; i++)
        //        {
        //            if (i == 0)
        //            {
        //                ddlNetworkName.Items.Add(new ListItem("Select", "0", true));
        //            }
        //            ddlNetworkName.Items.Add(new ListItem(dtSalesPerson.Rows[i]["DisplayName"].ToString()));
        //        }
        //    }

        //}
        //catch (SqlException sqe)
        //{
        //    string err = sqe.ToString();
        //}
        //finally
        //{

        //}
    }
    protected void lnkbtn_Click(object sender, EventArgs e)
    {
        pnlVisitingCustomer.Visible = true;
        div1id.Visible = false;
        pnlgrid.Visible = false;
        //txtCompName.Text = string.Empty;
       //// txtSource.Text = string.Empty;
        txtContPerson.Text = string.Empty;

       //// txtDate.Text = string.Empty;
        //txtCity.Text = string.Empty;
        //txtMobile.Text = string.Empty;
        //txtEMailId.Text = string.Empty;
        //txtDesignation.Text = string.Empty;
        //txtMeetingDate.Text = string.Empty;
        //txtLocationStrength.Text = string.Empty;
        //txtDiscussion.Text = string.Empty;
        //txtToDo.Text = string.Empty;
        //txtFollowUp.Text = string.Empty;
        //txtMeetingName.Text = string.Empty;
        //txtStatus.Text = string.Empty;
        //lblselectedfilename.Text = string.Empty;
        //txtMeetingDate.Text = "";
        //txtMeetingDate.Text = Convert.ToString(DateTime.Now.ToString());
        //ddlCustomerType.ClearSelection();
        //ddlCustomerType.Items.FindByText("Select").Selected = true;
        //ddllbltype.ClearSelection();
        //ddllbltype.Items.FindByText("Select").Selected = true;
        //NetworkName();
    }
    // Export to Excel
    //protected void imgbtnExcel_Click(object sender, ImageClickEventArgs e)
    //{
    //    Response.ClearContent();
    //    Response.ContentType = "application/ms-excel";
    //    string htmlMarkUp = lblData.Text;// outputString;
    //    ////string htmlMarkUp = litCM1Report.Text;// outputString;
    //    Response.AppendHeader("content-disposition", "attachment;filename=CM1AsPerJEReport.xls");
    //    Response.Charset = string.Empty;
    //    Response.Write(htmlMarkUp);
    //    Response.End();
    //}
    //// Export to Word
    //protected void imgbtnWord_Click(object sender, ImageClickEventArgs e)
    //{
    //    Response.Clear();
    //    Response.Buffer = true;
    //    Response.AddHeader("content-disposition", "attachment;filename=CM1AsPerJEReport.doc");
    //    Response.Charset = string.Empty;
    //    Response.ContentType = "application/vnd.ms-word ";
    //    Response.Output.Write(lblData.Text);
    //    ////Response.Output.Write(litCM1Report.Text);
    //    Response.Flush();
    //    Response.End();
    //}

}