﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using System.Web.UI;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Data.SqlClient;
using System.Net.Mail;

public partial class CRM_AppControls_Reports_testl : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}