﻿using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.WebControls;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

public partial class CRM_AppControls_Common_cfiGridIdea : System.Web.UI.UserControl
{

    /// <summary>
    /// User control which is used to display the message on this page.
    /// </summary>
    private AppControls_Messages ucMessage;

    /// <summary>
    /// Get or set the displaying of the header of the input repeater.
    /// </summary>
    private bool DisplayHeader = false;

    /// <summary>
    /// Gets or sets FieldDataSource.
    /// </summary>
    private DataTable FieldDataSource = null;

    /// <summary>
    /// Gets or sets DataTableToFilter.
    /// </summary>
    private DataTable DataTableToFilter = null;

    /// <summary>
    /// Gets or sets PrimaryKeyColumns.
    /// </summary>
    private string PrimaryKeyColumns = string.Empty;

    /// <summary>
    /// Gets or sets GridViewIdToBindFilteredDataTo.
    /// </summary>
    private string GridViewIdToBindFilteredDataTo = string.Empty;

    /// <summary>
    /// Gets HTStringDataTypes.
    /// </summary>
    private Hashtable HTStringDataTypes { get { return new Hashtable { { "CHAR", "CHAR" }, { "NCHAR", "NCHAR" }, { "VARCHAR", "VARCHAR" }, { "VARCHAR2", "VARCHAR2" }, { "NVARCHAR", "NVARCHAR2" }, { "NVARCHAR2", "NVARCHAR2" }, { "STRING", "STRING" }}; } }

    /// <summary>
    /// Gets HTLikeDataTypes.
    /// </summary>
    private Hashtable HTLikeDataTypes { get { return new Hashtable { { "Contains", "LIKE" }, { "Begins With", "LIKE" }, { "Ends With", "LIKE" }}; } }

    /// <summary>
    /// Gets HTNumericDataTypes.
    /// </summary>
    private Hashtable HTNumericDataTypes { get { return new Hashtable { { "NUMBER", "NUMBER" }, { "INTEGER", "INTEGER" }, { "DECIMAL", "DECIMAL" }, { "INT64", "INT64" }, { "INT32", "INT32" }, { "DOUBLE", "DOUBLE" }, { "FLOAT", "FLOAT" }}; } }


    /// <summary>
    /// Gets HTNumericDataTypes.
    /// </summary>
    private Hashtable HTBooleanDataTypes { get { return new Hashtable { { "BOOL", "BOOL" }, { "BOOLEAN", "BOOLEAN" }}; } }

    /// <summary>
    /// Gets HTDateDataTypes.
    /// </summary>
    private Hashtable HTDateDataTypes { get { return new Hashtable { { "DATE", "DATE" }, { "DATETIME", "DATETIME" }}; } }

    /// <summary>
    /// Gets or sets DataTableInput.
    /// </summary>
    private DataTable DataTableInput = null;

    /// <summary>
    /// Get or ser the name of the report to be used in the saved filter for storing the filter per report.
    /// </summary>
    private string ReportName = string.Empty;

    /// <summary>
    /// Get or ser the page no of the report to be saved.
    /// </summary>
    private string PageNo { get { return txtPageNo.Text == string.Empty ? Session["PageNo"].ToString() : txtPageNo.Text; } set { txtPageNo.Text = value; } }

    /// <summary>
    /// Get or ser the page size of the report to be saved.
    /// </summary>
    private string PageSize { get { return ddlPageSize.SelectedValue; } set { Cfi.SoftwareFactory.Common.CommonFunctions.SetDropDownListSelectedValue(ref ddlPageSize, value, true); } }

    /// <summary>
    /// Get or ser the page size of the report to be saved.
    /// </summary>
    private string TotalNoOfPages { set { lblTotalNoOfPages.Text = value; } }

    /// <summary>
    /// Gets or sets ControlsToRender.
    /// </summary>
    private string ControlsToRender = string.Empty;


    /// <summary>
    /// Get or set EmptyText to be display in the page if table is blank.
    /// </summary>
    public string EmptyText { get { return ViewState["EmptyText"] == null ? string.Empty : ViewState["EmptyText"].ToString(); } set { ViewState["EmptyText"] = value; } }

    /// <summary>
    /// Get or set the querystring if prdefine querystring is required.
    /// </summary>
    public string QueryString { get { return ViewState["QueryString"] == null ? string.Empty : ViewState["QueryString"].ToString(); } set { ViewState["QueryString"] = value; } }

    /// <summary>
    /// Get or set the WhereCondition for passing condition. The conditions here are passed in case the user is an agent or office so that data pervailing to them are displayed.
    /// </summary>
    public string WhereCondition { get { return ViewState["WhereCondition"] == null ? string.Empty : ViewState["WhereCondition"].ToString(); } set { ViewState["WhereCondition"] = value; } }

    /// <summary>
    /// Get or ser the ClassName for binding the realted list data.
    /// </summary>
    public string ClassName { get { return ViewState["ClassName"] == null ? string.Empty : ViewState["ClassName"].ToString(); } set { ViewState["ClassName"] = value; } }

    /// <summary>
    /// Get or set the display modifiers. i.e weather the columns 'View, Update, Delete are to be displayed.
    /// </summary>
    public ArrayList TemplateCollection { get { return (ArrayList)ViewState["TemplateCollection"]; } set { ViewState["TemplateCollection"] = value; } }

    /// <summary>
    /// Get or set the text on click of which  the user will be redirected. Used to display in the page if table is blank and there is no search and new hyperlinks. For example in issue stock to office module.
    /// </summary>
    public string GoToText { get { return ViewState["GoToText"] == null ? string.Empty : ViewState["GoToText"].ToString(); } set { ViewState["GoToText"] = value; } }

    /// <summary>
    /// Get or set the link where the user will be redirected. Used to display in the page if table is blank and there is no search and new hyperlinks. For example in issue stock to office module.
    /// </summary>
    public string GoToLink { get { return ViewState["GoToLink"] == null ? string.Empty : ViewState["GoToLink"].ToString(); } set { ViewState["GoToLink"] = value; } }

    /// <summary>
    /// Gets or sets the title of the empty message. i.e when there is no data in the grid to display.
    /// </summary>
    public string EmptyDataMessageTitle { get { return ViewState["EmptyDataMessageTitle"] == null ? string.Empty : ViewState["EmptyDataMessageTitle"].ToString(); } set { ViewState["EmptyDataMessageTitle"] = value; } }

    /// <summary>
    /// Gets or sets the description of the empty message. i.e when there is no data in the grid to display.
    /// </summary>
    public string EmptyDataMessageDescription { get { return ViewState["EmptyDataMessageDescription"] == null ? string.Empty : ViewState["EmptyDataMessageDescription"].ToString(); } set { ViewState["EmptyDataMessageDescription"] = value; } }


    /// <summary>
    /// Method to bind the grid to the appropriate datasource.
    /// </summary>
    public void BindGridView()
    {
        if (this.ucMessage == null)
            this.ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages");
        try
        {
            SearchFilter searchFilterClass = new SearchFilter { PageNo = PageNo, PageSize = PageSize, NameSpacePrefix = ClassName };
            string whereCondition = this.WhereCondition;

            // In case of the booking and  handover we have single page, so in order to bifercate the data in the list according to query string, the condition is built.
            if (!string.IsNullOrEmpty(this.QueryString))
                if (!string.IsNullOrEmpty(this.WhereCondition))
                    whereCondition = this.QueryString + " AND " + this.WhereCondition;
                else
                    whereCondition = this.QueryString;

            lstGrid.Text = string.Empty;
            lblEmptyDataDescription.Text = string.Empty;
            pnlSearch.Visible = false;
            searchFilterClass.WhereCondition = whereCondition;
            searchFilterClass.OrderBy = String.Empty;
            DataTable dt = searchFilterClass.GetList();
            Literal literalControlforShow = (Literal)CommonFunctions.FindControlRecursive(Page, "literalControl");
            if (literalControlforShow != null)
                literalControlforShow.Visible = true;
            bool haveData = dt != null && dt.Rows.Count > 0;
            if (!haveData)
            {
               
                    tblMessage.Visible = true;
                    LinkButton cmdNew = (LinkButton)CommonFunctions.FindControlRecursive(Page, "cmdNew");
                    Literal literalControl = (Literal)CommonFunctions.FindControlRecursive(Page, "literalControl");
                    if (literalControl != null)
                        literalControl.Visible = false;
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "HideSearchLink" + ClientID, @"$(document).ready(function() {document.getElementById('aSearch').style.display='none';});", true);

                    // Setting the appropriate message ...
                    if (this.EmptyDataMessageTitle != string.Empty)
                    {
                        lblEmptyDataTitle.Text = this.EmptyDataMessageTitle;
                        lblEmptyDataDescription.Text = this.EmptyDataMessageDescription;
                    }
                    else
                    {
                        if (cmdNew != null)
                        {
                            lblEmptyDataTitle.Text = "No " + this.EmptyText + " yet.";
                            lblEmptyDataDescription.Text = "No " + this.EmptyText + " has been added yet, to add a new " + this.EmptyText + " click on the [<a href=\"javascript:" + Page.ClientScript.GetPostBackEventReference(cmdNew, cmdNew.CommandName) + "\">New</a>] link button.";
                        }
                        else
                        {
                            lblEmptyDataTitle.Text = "No " + this.EmptyText + " yet.";
                            lblEmptyDataDescription.Text = "No " + this.EmptyText + " has been added yet, to achieve this go to [<a href='" + this.GoToLink + "'>" + this.GoToText + "</a>].";
                        }
                    }
               
            }
            else
            {
                tblMessage.Visible = false;

            }


            if (string.IsNullOrEmpty(lblEmptyDataDescription.Text))
            {
                pnlSearch.Visible = true;
                // Invoke method to set gdvSearchGrid TemplateCollection Accessbility
               this.SetAccessRights();

                // IsExtraBinding = false;
                // Getting the columns which are needed to hide in the grid view along with the creation of the list of the columns which is to be displayed in the search filter...
                string columnsToDisplayInSearchFilter = string.Empty;
                string columnsToHideFromSearchFilter = string.Empty;

                foreach (object objCfiTemplate in this.TemplateCollection)
                {
                    CfiTemplate cfiTemplate = (CfiTemplate)objCfiTemplate;
                    string[,] primaryKeyColumnWithHideAttribute = cfiTemplate.PrimaryKeyColumnWithHideAttribute;
                    for (int i = 0; i < primaryKeyColumnWithHideAttribute.GetLength(0); i++)
                    {
                        if (!columnsToHideFromSearchFilter.Contains(primaryKeyColumnWithHideAttribute[i, 0]) && bool.Parse(primaryKeyColumnWithHideAttribute[i, 1]))
                            columnsToHideFromSearchFilter += primaryKeyColumnWithHideAttribute[i, 0] + ",";
                        else if (!columnsToDisplayInSearchFilter.Contains(primaryKeyColumnWithHideAttribute[i, 0]) && !bool.Parse(primaryKeyColumnWithHideAttribute[i, 1]))
                            columnsToDisplayInSearchFilter += primaryKeyColumnWithHideAttribute[i, 0] + ",";
                    }
                }

                columnsToDisplayInSearchFilter = columnsToDisplayInSearchFilter.Contains(",") ? columnsToDisplayInSearchFilter.Substring(0, columnsToDisplayInSearchFilter.LastIndexOf(",")).ToLower() : string.Empty;
                columnsToHideFromSearchFilter = columnsToHideFromSearchFilter.Contains(",") ? columnsToHideFromSearchFilter.Substring(0, columnsToHideFromSearchFilter.LastIndexOf(",")).ToLower() : string.Empty;
                PrimaryKeyColumns = columnsToHideFromSearchFilter == "" ? columnsToDisplayInSearchFilter : columnsToHideFromSearchFilter;


                //Making Grid Header along with column
                System.Text.StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append("<table class=\"GridViewStyle\"><tbody><tr class=\"HeaderStyle\">");
                for (int i = 0; i < TemplateCollection.Count; i++)
                {
                    if (i == 0)
                        stringBuilder.Append("<th><span class=\"ActionHeaderStyle\">Action</span></th>");
                    else
                        stringBuilder.Append("<th>&nbsp;</th>");
                }
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (!columnsToHideFromSearchFilter.Contains(dt.Columns[i].ColumnName.ToLower()))
                        stringBuilder.Append("<th><a href=\"javascript:void(0);\">" + dt.Columns[i].ColumnName + "</a></th>");
                }
                stringBuilder.Append("</tr>");

                //Making Grid Row along with value and action
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i % 2 == 0)
                        stringBuilder.Append("<tr class=\"RowStyle\">");
                    else
                        stringBuilder.Append("<tr class=\"AltRowStyle\">");
                    if (dt.Rows[i]["Status"].ToString() == "Pending")
                    {
                       
                        if (TemplateCollection != null)
                            foreach (CfiTemplate cfiTemplate in TemplateCollection)
                            {
                                string primaryKeyValues = string.Empty;
                                for (int j = 0; j < cfiTemplate.PrimaryKeyColumnWithHideAttribute.GetLength(0); j++)
                                {
                                    string currentColumn = cfiTemplate.PrimaryKeyColumnWithHideAttribute[j, 0];
                                    if (primaryKeyValues == "")
                                        primaryKeyValues = dt.Rows[i][currentColumn].ToString();
                                    else
                                        primaryKeyValues += "," + dt.Rows[i][currentColumn].ToString();
                                }
                                if (!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Blank)
                                    stringBuilder.Append("<td class=\"ActionButton\"><a href=\"javascript:void(0);\" onclick=\"" + String.Format("javascript:window.open('{0}','{1}','{2}');return false;", cfiTemplate.Hyperlink + primaryKeyValues, "_blank", string.Empty) + "\" >" + (cfiTemplate.Text ?? cfiTemplate.ColumnType.ToString()) + "</a></td>");
                                else if (!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Self)
                                    stringBuilder.Append("<td class=\"ActionButton\"><a target='_self' href=" + cfiTemplate.Hyperlink + primaryKeyValues + " >" + (cfiTemplate.Text ?? cfiTemplate.ColumnType.ToString()) + "</a></td>");
                                else
                                    stringBuilder.Append("<td class=\"ActionButton\"><a href=\"javascript:void(0);\" onclick=\"OnAction('" + (cfiTemplate.Mode.ToString() ?? cfiTemplate.ColumnType.ToString()) + "','" + primaryKeyValues + "')\" >" + (cfiTemplate.Text ?? cfiTemplate.ColumnType.ToString()) + "</a></td>");
                            }


                        for (int j = 0; j < dt.Columns.Count; j++)
                            if (!columnsToHideFromSearchFilter.Contains(dt.Columns[j].ColumnName.ToLower()))
                            {
                                DataColumn dcDataSource = dt.Columns[j];
                                if (dcDataSource.DataType == typeof(bool))
                                    stringBuilder.Append(dt.Rows[i][j].ToString() == "True" ? "<td>Yes" : "<td>No" + "</td>");
                                else if (dcDataSource.DataType == typeof(DateTime))
                                    stringBuilder.Append("<td>" + ((DateTime)dt.Rows[i][j]).ToShortDateString() + "</td>");
                                else
                                    stringBuilder.Append("<td>" + dt.Rows[i][j] + "</td>");
                            }

                        stringBuilder.Append("</tr>");
                    }
                }
                
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i % 2 == 0)
                        stringBuilder.Append("<tr class=\"RowStyle\">");
                    else
                        stringBuilder.Append("<tr class=\"AltRowStyle\">");
                    if (dt.Rows[i]["Status"].ToString() != "Pending")
                    {
                        
                        if (TemplateCollection != null)
                            foreach (CfiTemplate cfiTemplate in TemplateCollection)
                            {
                                string primaryKeyValues = string.Empty;
                                for (int j = 0; j < cfiTemplate.PrimaryKeyColumnWithHideAttribute.GetLength(0); j++)
                                {
                                    string currentColumn = cfiTemplate.PrimaryKeyColumnWithHideAttribute[j, 0];
                                    if (primaryKeyValues == "")
                                        primaryKeyValues = dt.Rows[i][currentColumn].ToString();
                                    else
                                        primaryKeyValues += "," + dt.Rows[i][currentColumn].ToString();
                                }
                                if (cfiTemplate.Mode.ToString() == "View")
                                {
                                    if (!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Blank)
                                        stringBuilder.Append("<td class=\"ActionButton\"><a href=\"javascript:void(0);\" onclick=\"" + String.Format("javascript:window.open('{0}','{1}','{2}');return false;", cfiTemplate.Hyperlink + primaryKeyValues, "_blank", string.Empty) + "\" >" + (cfiTemplate.Text ?? cfiTemplate.ColumnType.ToString()) + "</a></td>");
                                    else if (!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Self)
                                        stringBuilder.Append("<td class=\"ActionButton\"><a target='_self' href=" + cfiTemplate.Hyperlink + primaryKeyValues + " >" + (cfiTemplate.Text ?? cfiTemplate.ColumnType.ToString()) + "</a></td>");
                                    else
                                        stringBuilder.Append("<td class=\"ActionButton\"><a href=\"javascript:void(0);\" onclick=\"OnAction('" + (cfiTemplate.Mode.ToString() ?? cfiTemplate.ColumnType.ToString()) + "','" + primaryKeyValues + "')\" >" + (cfiTemplate.Text ?? cfiTemplate.ColumnType.ToString()) + "</a></td>");
                                }
                                else 
                                {
                                    if (!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Blank)
                                        stringBuilder.Append("<td class=\"ActionButton\" ></td>");
                                    else if (!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Self)
                                        stringBuilder.Append("<td class=\"ActionButton\"></td>");
                                    else
                                        stringBuilder.Append("<td class=\"ActionButton\" ></td>");
                                
                                }
                            }


                        for (int j = 0; j < dt.Columns.Count; j++)
                            if (!columnsToHideFromSearchFilter.Contains(dt.Columns[j].ColumnName.ToLower()))
                            {
                                DataColumn dcDataSource = dt.Columns[j];
                                if (dcDataSource.DataType == typeof(bool))
                                    stringBuilder.Append(dt.Rows[i][j].ToString() == "True" ? "<td>Yes" : "<td>No" + "</td>");
                                else if (dcDataSource.DataType == typeof(DateTime))
                                    stringBuilder.Append("<td>" + ((DateTime)dt.Rows[i][j]).ToShortDateString() + "</td>");
                                else
                                    stringBuilder.Append("<td>" + dt.Rows[i][j] + "</td>");
                            }

                        stringBuilder.Append("</tr>");
                    }
                }
                stringBuilder.Append("</tbody></table>");
                lstGrid.Text = stringBuilder.ToString();

                // Making HTML Search Control
                if (string.IsNullOrEmpty(hdnSearchControlHTML.Value))
                    ltSearchControl.Text = this.GetSearchControl(dt, columnsToHideFromSearchFilter);
                else
                    ltSearchControl.Text = Server.HtmlDecode(hdnSearchControlHTML.Value);

                // For setting the data table to filter. This is used to get the column names of the grid.
                DataTableToFilter = dt;
                TotalNoOfPages = searchFilterClass.TotalNoOfPages;
                //UpdateSearch();
                upUserControlSub.Update();
                upUserControlMain.Update();
                upSearchGrid.Update();
            }
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = ex.Message;
            return;
        }
    }

    private string GetSearchControl(DataTable dt, string columnsToHideFromSearchFilter)
    {
        StringBuilder htmlTableString = new StringBuilder();
        if (dt != null && dt.Rows.Count > 0)
        {
            htmlTableString.Append("<table id=\"tblSearchControl\" class=\"formInsideTable\">");
            htmlTableString.Append("<tr id=\"trHeaderSearch\" class=\"searchHeader\">");
            htmlTableString.Append("<th class=\"grdTableHeader\">");
            htmlTableString.Append("Field");
            htmlTableString.Append("</th>");
            htmlTableString.Append("<th class=\"grdTableHeader\">");
            htmlTableString.Append("Condition");
            htmlTableString.Append("</th>");
            htmlTableString.Append("<th class=\"grdTableHeader\">");
            htmlTableString.Append("Keyword");
            htmlTableString.Append("</th>");
            htmlTableString.Append("<th class=\"grdTableHeader\">");
            htmlTableString.Append("Operator");
            htmlTableString.Append("</th>");
            htmlTableString.Append("<th class=\"grdTableHeader\">");
            htmlTableString.Append("Action");
            htmlTableString.Append("</th>");
            htmlTableString.Append("</tr>");
            htmlTableString.Append("<tr id=\"trSearch_1\">");
            htmlTableString.Append("<td class=\"grdTableRow\">");
            htmlTableString.Append("<select id=\"ddlSearchField_1\" class=\"selectDropDownList\" onchange=\"FillSearchField(this.id);\">");
            foreach (DataColumn dc in dt.Columns)
                if (!columnsToHideFromSearchFilter.Contains(dc.ColumnName.ToLower()))
                    htmlTableString.Append("<option value=\"" + dc.DataType.Name + "`[" + dc.ColumnName + "]\">" + dc.ColumnName + "</option>");
            htmlTableString.Append("</select>");
            htmlTableString.Append("</td>");
            htmlTableString.Append("<td class=\"grdTableRow\">");
            htmlTableString.Append("<select id=\"ddlSearchCondition_1\" class=\"selectDropDownList\">");
            string columnDataType = string.Empty;
            foreach (DataColumn dc in dt.Columns)
                if (!columnsToHideFromSearchFilter.Contains(dc.ColumnName.ToLower()))
                {
                    columnDataType = dc.DataType.Name.ToUpper();
                    break;
                }

            if (HTNumericDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<option value=\"=\">Equals</option>");
                htmlTableString.Append("<option value=\">\">Greater Than</option>");
                htmlTableString.Append("<option value=\"<\">Less Than</option>");
                htmlTableString.Append("<option value=\">=\">Greater Than Or Equal To</option>");
                htmlTableString.Append("<option value=\"<=\">Less Than Or Equal To</option>");
            }
            else if (HTStringDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<option value=\"Contains`LIKE\">Contains</option>");
                htmlTableString.Append("<option value=\"Begins With`LIKE\">Begins With</option>");
                htmlTableString.Append("<option value=\"Ends With`LIKE\">Ends With</option>");
                htmlTableString.Append("<option value=\"=\">Equals</option>");
            }
            else if (HTDateDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<option value=\"BETWEEN\">Between</option>");
                htmlTableString.Append("<option value=\"<\">Less Than</option>");
                htmlTableString.Append("<option value=\">\">Greater Than</option>");
            }
            else if (HTBooleanDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<option value=\"=\">Equals</option>");
            }
            htmlTableString.Append("</select>");
            htmlTableString.Append("</td>");
            htmlTableString.Append("<td id=\"tdKeyword_1\" class=\"grdTableRow\">");
            if (HTNumericDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<input type=\"text\" class=\"inputTextBox\" id=\"txtSearch_1\" style=\"text-transform: uppercase;\" onkeydown=\"checkNumeric(this.id);\">");
            }
            else if (HTStringDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<input type=\"text\" class=\"inputTextBox\" id=\"txtSearch_1\" style=\"text-transform: uppercase;\" onkeydown=\"checkAlphaNumeric(this.id);\">");
            }
            else if (HTDateDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<input type=\"text\" class=\"inputTextBox\" id=\"txtSearch_1\" style=\"text-transform: uppercase;\" onkeydown=\"checkDate(this.id);\">");
            }
            else if (HTBooleanDataTypes.Contains(columnDataType.ToUpper()))
            {
                htmlTableString.Append("<select id=\"txtSearch_1\" class=\"selectDropDownList\">");
                htmlTableString.Append("<option value=\"1\">True</option>");
                htmlTableString.Append("<option value=\"0\">False</option>");
                htmlTableString.Append("</select>");
            }
            htmlTableString.Append("</td>");
            htmlTableString.Append("<td class=\"grdTableRow\">");
            htmlTableString.Append("<select id=\"ddlOperator_1\" style=\"display:none;\">");
            htmlTableString.Append("<option value=\"AND\">And</option>");
            htmlTableString.Append("<option value=\"OR\">Or</option>");
            htmlTableString.Append("</select>");
            htmlTableString.Append("</td>");
            htmlTableString.Append("<td class=\"grdTableRow\">");
            htmlTableString.Append("<a id=\"btnAdd_1\" href=\"javascript:void(0);\" onclick=\"SplitSearch('trSearch_1',1);\">Add</a>");
            htmlTableString.Append("<span id=\"spna_1\" style=\"display: none\">&nbsp;|&nbsp;</span><a id=\"btnRemove_1\" href=\"javascript:void(0);\" onclick=\"RemoveSearch('trSearch_1');\" style=\"display:none;\">Remove</a>");
            htmlTableString.Append("</td>");
            htmlTableString.Append("</tr>");
            htmlTableString.Append("</table>");
        }
        return htmlTableString.ToString();
    }
    /// <summary>
    /// Method to set the access rights by deleting or removing the appropriate CfiTemplate.
    /// </summary>
    private void SetAccessRights()
    {
        try
        {
            // if (IsExtraBinding) return;
            using (Cfi.App.CRM.Business.Login login = new Cfi.App.CRM.Business.Login())
            {
                int currentPageSNo = 0;
                currentPageSNo = !string.IsNullOrEmpty(this.QueryString) ? int.Parse((new ApplicationPage()).GetList("Page", "SNo", "HyperLink='" + Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower() + "/", string.Empty) + "?" + this.QueryString + "'").Rows[0]["SNo"].ToString()) : int.Parse((new ApplicationPage()).GetList("Page", "SNo", "HyperLink='" + Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower() + "/", string.Empty) + "'").Rows[0]["SNo"].ToString());

                DataTable dtLoginPageDetails = login.GetLoginPageAccessDetail(((UserLogin)Session["LoginDetails"]).SNo.ToString(), currentPageSNo);

                // If the data in the login page trans for the specified table does not exists then return with clearing all the access...
                if (dtLoginPageDetails == null || dtLoginPageDetails.Rows.Count == 0)
                {
                    WebControl linkBtnNew = (WebControl)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(Page, "cmdNew");
                    if (linkBtnNew != null)
                    {
                        Literal literalControl = (Literal)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(linkBtnNew.Parent, "literalControl");
                        if (literalControl != null)
                            literalControl.Visible = false;
                        linkBtnNew.Visible = false;
                    }

                    //gdvSearchGrid.TemplateCollection = null;
                    return;
                }

                DataRow dr = dtLoginPageDetails.Rows[0];
                bool canView = (bool)dr["CanView"];
                bool canEdit = (bool)dr["CanUpDate"];
                bool canDelete = (bool)dr["CanDelete"];
                bool canInsert = (bool)dr["CanInsert"];
                if (!canInsert)
                {
                    // Hiding the New Button...
                    WebControl linkBtnNew = (WebControl)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(Page, "cmdNew");
                    if (linkBtnNew != null)
                    {
                        Literal literalControl = (Literal)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(linkBtnNew.Parent, "literalControl");
                        if (literalControl != null)
                            literalControl.Visible = false;
                        linkBtnNew.Visible = false;
                    }
                }
                else
                {
                    // Invoke method to set page object access..
                    using (PageObjectAccess pageObjectAcess = new PageObjectAccess())
                        pageObjectAcess.SetPageObjectAcessRight();
                }

                ArrayList tempTemplateCollection = new ArrayList();
                foreach (object obj in TemplateCollection)
                {
                    CfiTemplate cfiTemplate = (CfiTemplate)obj;
                    if (cfiTemplate.Mode.ToString() == UIMode.View.ToString() && canView)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.Update.ToString() && canEdit)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.Delete.ToString() && canDelete)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.Handover.ToString() && canEdit)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.Print.ToString() && canView)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.Label.ToString() && canView)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.CCA.ToString() && canView)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.Receipt.ToString() && canView)
                        tempTemplateCollection.Add(cfiTemplate);
                    else if (cfiTemplate.Mode.ToString() == UIMode.Plan.ToString() && canView)
                        tempTemplateCollection.Add(cfiTemplate);
                }

                this.TemplateCollection = tempTemplateCollection;
            }
        }
        catch (Exception ex)
        {

            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }
    }

    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">
    /// The sender of the page load event.
    /// </param>
    /// <param name="e">
    /// The arguments of the page load event.
    /// </param>
    protected void Page_Load(object sender, EventArgs e)
    {
        ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages");
        try
        {
            if (!Page.IsPostBack)
            {
                cmdSearch.Attributes.Add("onclick", "javascript:return submitSearchFormValue();");
                FieldDataSource = null;
                DataTableInput = null;
                //HideAllValueFields(txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue, ddlIsActive);
                CreateDataTableInput();
                UpdateSearch();
                // Setting the field header text after the loading of the grid view...
                //GridView gv = (GridView)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(Parent, GridViewIdToBindFilteredDataTo);
                //gv.Load += UpdateSearch;

                // Fill the saved drop down list...
                //FillSavedDropDownList();
                //trHeader.Visible = DisplayHeader;
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ShowHideSearch", @"$(document).ready(function() {
                    //Set the toggle event of the search button...
                    $('a[ShowHideSearch]').attr('onclick','ToggleSearch(""" + hdnShowHideSearchVariable.ClientID + @""");');});", true);
            }

            var strJavascript = new StringBuilder();

            strJavascript.Append("var hdnShowHideSearchVariable='" + hdnShowHideSearchVariable.ClientID + "';");
            strJavascript.Append("var GridButton1='" + Button1.ClientID + "';");
            strJavascript.Append("var hdnSearchConditions='" + hdnSearchConditions.ClientID + "';");
            strJavascript.Append("var hdnSearchControlHTML='" + hdnSearchControlHTML.ClientID + "';");
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "initializeClientSearchVariables", strJavascript.ToString(), true);

            // Set the javascript to check the text box empty...
            //cmdSaveSearchFilter.Attributes.Add("onclick", "CheckSavedSearch('" + txtSearchName.ClientID + "')");
            //cmdRemoveSavedSearch.Attributes.Add("onclick", "jConfirm('" + GetLocalResourceObject("AreYouSureWantToDeleteThisFilter") + "','" + GetLocalResourceObject("ConfirmationDialog") + "',function(r){if(r)" + Page.ClientScript.GetPostBackEventReference(cmdRemoveSavedSearch, cmdRemoveSavedSearch.CommandName) + ";}); return false;");
            Page.Form.Attributes.Add("onsubmit", "return submitForm;");
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }
    }

    /// <summary>
    /// The fill saved drop down list.
    /// </summary>
    //private void FillSavedDropDownList()
    //{
    //    try
    //    {
    //        ddlCookiesSavedSearch.Visible = false;
    //        cmdRemoveSavedSearch.Visible = false;
    //        lblSavedSearch.Visible = false;
    //        ddlDatabaseSavedSearch.Visible = false;
    //        if (!IsPostBack || rblSaveSearchFilter.SelectedIndex == 0)
    //        {
    //            ddlDatabaseSavedSearch.Items.Clear();

    //            // creation of obj to IsaveSearch class
    //            SearchFilter saveSearchFilter = new SearchFilter();
    //            int currentPageSNo = int.Parse((new ApplicationPage()).GetList("Page", "SNo", "HyperLink='" + Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower()+"/", string.Empty) + "'").Rows[0]["SNo"].ToString());
    //            DataTable dtSaveSearchFilter = saveSearchFilter.GetList("SearchFilter", "FilterName,PageSNo,SNo", "PageSNo=" + currentPageSNo);
    //            if (dtSaveSearchFilter.Rows.Count > 0)
    //            {
    //                for (int i = 0; i < dtSaveSearchFilter.Rows.Count; i++)
    //                    ddlDatabaseSavedSearch.Items.Add(new System.Web.UI.WebControls.ListItem(dtSaveSearchFilter.Rows[i]["FilterName"].ToString(), dtSaveSearchFilter.Rows[i]["FilterName"].ToString() + '~' + dtSaveSearchFilter.Rows[i]["PageSNo"] + '~' + dtSaveSearchFilter.Rows[i]["SNo"]));
    //                ddlDatabaseSavedSearch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", string.Empty));
    //                lblSavedSearch.Visible = true;
    //                ddlDatabaseSavedSearch.Visible = true;
    //                rblSaveSearchFilter.SelectedIndex = 0;
    //            }
    //            else
    //            {
    //                lblSavedSearch.Visible = false;
    //                ddlDatabaseSavedSearch.Visible = false;
    //            }
    //        }

    //        if (!IsPostBack || rblSaveSearchFilter.SelectedIndex == 1)
    //        {
    //            ddlCookiesSavedSearch.Items.Clear();
    //            HttpCookie httpCookies = Request.Cookies[((UserLogin)Session["LoginDetails"]).SNo.ToString()];

    //            if (httpCookies != null)
    //            {
    //                // Setting the saved search in the drop downlist and displaying the search panel...
    //                foreach (string val in httpCookies.Values)
    //                {
    //                    if (val != null && val.EndsWith((new ApplicationPage()).GetList("Page", "SNo", "HyperLink='" + Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower()+"/", string.Empty) + "'").Rows[0]["SNo"].ToString()))
    //                        ddlCookiesSavedSearch.Items.Add(new System.Web.UI.WebControls.ListItem(val.Split("`".ToCharArray())[0], val));
    //                }

    //                if (ddlCookiesSavedSearch.Items.Count > 0)
    //                {
    //                    ddlCookiesSavedSearch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", string.Empty));
    //                    lblSavedSearch.Visible = true;
    //                    ddlCookiesSavedSearch.Visible = !IsPostBack ? !ddlDatabaseSavedSearch.Visible : true;
    //                }
    //                else
    //                {
    //                    lblSavedSearch.Visible = lblSavedSearch.Visible ? true : false;
    //                    cmdRemoveSavedSearch.Visible = cmdRemoveSavedSearch.Visible ? true : false;
    //                }

    //                if (ddlCookiesSavedSearch.Visible)
    //                    rblSaveSearchFilter.SelectedIndex = 1;
    //            }
    //            else
    //            {
    //                lblSavedSearch.Visible = lblSavedSearch.Visible ? true : false;
    //                ddlCookiesSavedSearch.Visible = false;
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    /// <summary>
    /// The update search.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void UpdateSearch()
    {
        try
        {
            CreateFieldDataSource();
            //Cfi.SoftwareFactory.Common.CommonFunctions.FillDropDownListFromTable(ref ddlField, FieldDataSource, null, null, false);
            //SetRelevantCondition(ddlField, ddlCondition, txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue, ddlIsActive);
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The set saved cookie search filter.
    /// </summary>
    /// <param name="cookieName">
    /// The cookie name.
    /// </param>
    /// <param name="searchKey">
    /// The search key.
    /// </param>
    //private void SetSavedCookieSearchFilter(string cookieName, string searchKey)
    //{
    //    try
    //    {
    //        // Setting the saved search in the filter...
    //        DataTableInput.Rows.Clear();

    //        // Get the search xml from the cookies...
    //        HttpCookie httpCookie = Request.Cookies[cookieName];
    //        if (httpCookie != null)
    //        {
    //            StringReader sw = new StringReader(HttpUtility.UrlDecode(httpCookie.Values[searchKey]));
    //            DataTableInput.ReadXml(sw);
    //            SetSavedSearch(ddlCookiesSavedSearch);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    ///// <summary>
    ///// The set saved database search filter.
    ///// </summary>
    ///// <param name="cookieName">
    ///// The cookie name.
    ///// </param>
    ///// <param name="searchKey">
    ///// The search key.
    ///// </param>
    //private void SetSavedDatabaseSearchFilter(string cookieName, string searchKey)
    //{
    //    try
    //    {
    //        // Setting the saved search in the filter...
    //        DataTableInput.Rows.Clear();
    //        if (ddlDatabaseSavedSearch.SelectedIndex != 0)
    //        {
    //            string[] filterNameAndReportName = searchKey.Split("~".ToCharArray());

    //            // creation of obj to IsaveSearch class
    //            SearchFilter saveSearchFilter = new SearchFilter { UserId = cookieName, ReportName = filterNameAndReportName[1], FilterName = filterNameAndReportName[0], PageNo = "1", PageSize = "-1" };
    //            DataTable dtSaveSearchFilter = saveSearchFilter.GetList("SearchFilter", "*", "LoginSno='" + cookieName + "' and FilterName='" + filterNameAndReportName[0] + "'");
    //            StringReader sw = new StringReader(dtSaveSearchFilter.Rows[0]["FilterXml"].ToString());
    //            DataTableInput.ReadXml(sw);
    //            SetSavedSearch(ddlDatabaseSavedSearch);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    /// <summary>
    /// The set saved search.
    /// </summary>
    /// <param name="ddl">
    /// The ddl.
    /// </param>
    private void SetSavedSearch(DropDownList ddl)
    {
        try
        {
            //DataTable dt = DataTableInput;
            //DataRow dr = dt.Rows[dt.Rows.Count - 1];
            //ddlField.SelectedValue = dr["FieldDataType"].ToString();

            //// SetRelevantCondition(ddlField, ddlCondition, txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue);
            //SetRelevantCondition(ddlField, ddlCondition, txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue, ddlIsActive);
            //ddlCondition.SelectedValue = dr["ConditionValue"].ToString();
            //txtValue.Text = dr["Value"].ToString();
            //txtNumericValue.Text = dr["NumericValue"].ToString();
            //txtStartDateValue.Text = dr["StartDateValue"].ToString();
            //txtEndDateValue.Text = dr["EndDateValue"].ToString();
            //dt.Rows.RemoveAt(dt.Rows.Count - 1);
            //rptFieldInput.DataSource = dt;
            //rptFieldInput.DataBind();
            //lblOperator.Visible = dt.Rows.Count > 0; // Added by Chandra Prakash
            //DataTableInput = dt;


            //if (SearchFilterDropDownListSelectedIndexChange != null)
            //    SearchFilterDropDownListSelectedIndexChange(ddl, null);
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The create field data source.
    /// </summary>
    /// <returns>
    /// </returns>
    private DataTable CreateFieldDataSource()
    {
        FieldDataSource = GetFieldData();

        // This next line is commented, because the columns now will not contain the header text of the grid rather they will contain the column name as they come from the sql query.
        // FieldDataSource = RemoveEmptyRecords(FieldDataSource);
        return FieldDataSource;
    }

    /// <summary>
    /// Method to remove the filds from the fields dropdown so that only the one in the associated grid view are visible.
    /// </summary>
    /// <param name="dtFields">
    /// The datatable whic contains the information of the fileds.
    /// </param>
    /// <returns>
    /// A datatable free from unwanted fields.
    /// </returns>
    protected DataTable RemoveEmptyRecords(DataTable dtFields)
    {
        DataTable dtTempFields = null;
        if (dtFields != null)
        {
            // For checking if the text is some how null and empty.
            for (int i = 0; i < dtFields.Rows.Count; i++)
            {
                if (dtFields.Rows[i]["Text"].ToString() == string.Empty)
                    dtFields.Rows[i].Delete();
            }

            dtTempFields = dtFields.Clone();

            // For checking if the existing fields exists in the gridview header and visible, and removing the unwanted ones.
            GridView gv = (GridView)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(Page, GridViewIdToBindFilteredDataTo);
            for (int i = 0; i < dtFields.Rows.Count; i++)
            {
                foreach (DataControlField bc in gv.Columns)
                {
                    if ((bc.AccessibleHeaderText == dtFields.Rows[i]["Text"].ToString()) && bc.Visible)
                    {
                        DataRow dr = dtTempFields.NewRow();
                        dr["Value"] = dtFields.Rows[i]["Value"].ToString();
                        dr["Text"] = bc.HeaderText;
                        dtTempFields.Rows.Add(dr);
                    }
                }
            }
        }

        return dtTempFields;
    }

    /// <summary>
    /// The create data table input.
    /// </summary>
    /// <returns>
    /// </returns>
    private DataTable CreateDataTableInput()
    {
        DataTable dtInput = new DataTable("Input");
        dtInput.Columns.Add(new DataColumn("Field"));
        dtInput.Columns.Add(new DataColumn("ConditionValue"));
        dtInput.Columns.Add(new DataColumn("ConditionText"));
        dtInput.Columns.Add(new DataColumn("Value"));
        dtInput.Columns.Add(new DataColumn("NumericValue"));
        dtInput.Columns.Add(new DataColumn("StartDateValue"));
        dtInput.Columns.Add(new DataColumn("EndDateValue"));
        dtInput.Columns.Add(new DataColumn("LogicalOperator"));
        dtInput.Columns.Add(new DataColumn("FieldDataType"));
        DataTableInput = dtInput;
        return dtInput;
    }

    /// <summary>
    /// The cmd add input_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void cmdAddInput_Click(object sender, EventArgs e)
    {
        try
        {
            //SetTheSelectedFieldInputRepeaterData();
            //DataTable dt = DataTableInput;
            //DataRow dr = dt.NewRow();
            //dr["Field"] = ddlField.SelectedValue.ToUpper().Split("`".ToCharArray())[0];
            //dr["ConditionValue"] = ddlCondition.SelectedValue;
            //dr["Value"] = txtValue.Text;
            //dr["NumericValue"] = txtNumericValue.Text;
            //dr["StartDateValue"] = txtStartDateValue.Text;
            //dr["EndDateValue"] = txtEndDateValue.Text;
            //dr["LogicalOperator"] = "0";
            //dr["FieldDataType"] = ddlField.SelectedValue;
            //dt.Rows.Add(dr);
            //DataTableInput = dt;
            //BindInputRepeater();
            //ddlField.SelectedIndex = 0;
            //ddlCondition.SelectedIndex = 0;
            //txtValue.Text = string.Empty;
            //txtNumericValue.Text = string.Empty;
            //txtStartDateValue.Text = string.Empty;
            //txtEndDateValue.Text = string.Empty;
            //ddlField.Focus();
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The cmd search_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (Page.IsValid)
            {
                string searchVal = hdnSearchConditions.Value;
                // Added by Chandra Prakash on 16 Dec 2009 
                int currentPageNo = int.Parse(txtPageNo.Text);
                int totalNoOfPages = int.Parse(lblTotalNoOfPages.Text);
                if ((currentPageNo > totalNoOfPages) && (totalNoOfPages != 0))
                    txtPageNo.Text = lblTotalNoOfPages.Text;
                else if (currentPageNo < 1)
                    txtPageNo.Text = "1";

                // The next function is commented, because now we do not need to search from the existing data in the data table, rather from the data base itself.
                // SearchGridView();
                this.WhereCondition = GenerateWhereCondition();

                // Set the event while this button is clicked.
                BindGridView();


                // For Showing the Clear Search Button
                tdClearSearchPipe.Visible = true;
                tdClearSearchButton.Visible = true;
                upUserControlSub.Update();
            }
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    private string GenerateWhereCondition()
    {
        string whereCondition = string.Empty;
        try
        {
            string[] conditions = hdnSearchConditions.Value.Split('^');
            string currentCondition = string.Empty;
            foreach (string str in conditions)
            {
                if (str.Contains("Contains") || str.Contains("Begins") || str.Contains("Ends"))
                {
                    currentCondition = str;
                }
                else
                {
                    if (!string.IsNullOrEmpty(currentCondition))
                    {
                        whereCondition += " " + GetCondition(currentCondition, str);
                        currentCondition = string.Empty;
                    }
                    else
                        whereCondition += " " + str;
                }
            }
        }
        catch (Exception)
        { }
        return whereCondition;
    }

    private string GetCondition(string searchCondition, string searchText)
    {
        string whereCondition = string.Empty;
        try
        {
            switch (searchCondition)
            {
                case "Contains`LIKE":
                    whereCondition = "LIKE '%" + searchText + "%'";
                    break;
                case "Begins With`LIKE":
                    whereCondition = "LIKE '" + searchText + "%'";
                    break;
                case "Ends With`LIKE":
                    whereCondition = "LIKE '%" + searchText + "'";
                    break;
                default:
                    break;
            }
        }
        catch (Exception)
        { }
        return whereCondition;
    }

    /// <summary>
    /// Method to get the columns in the drop down list of the filter, only those whose primary key columns are not hidden.
    /// </summary>
    /// <returns>
    /// Returns a datatable to bind with the drop down list containing the fields to be bound with.
    /// </returns>
    private DataTable GetFieldData()
    {
        DataTable dtFields = new DataTable();
        DataColumn dcText = new DataColumn("Text");
        DataColumn dcValue = new DataColumn("Value");
        dtFields.Columns.Add(dcValue);
        dtFields.Columns.Add(dcText);
        if (DataTableToFilter != null)
        {
            foreach (DataColumn dataColumn in DataTableToFilter.Columns)
            {
                if (!PrimaryKeyColumns.Trim().ToUpper().Contains(dataColumn.ColumnName.Trim().ToUpper()))
                {
                    DataRow dr = dtFields.NewRow();
                    dr["Text"] = dataColumn.ColumnName;
                    dr["Value"] = (dataColumn.ColumnName.Contains("[") && dataColumn.ColumnName.Contains("]") ? dataColumn.ColumnName : "[" + dataColumn.ColumnName + "]") + "`" + dataColumn.DataType.Name.ToUpper();
                    dtFields.Rows.Add(dr);
                }
            }
        }

        return dtFields;
    }

    ///// <summary>
    ///// Get or set the WhereCondition for passing condition.
    ///// </summary>
    //public string WhereCondition { get { return ViewState["WhereCondition"] == null ? "" : ViewState["WhereCondition"].ToString(); } set { ViewState["WhereCondition"] = value; } }

    /// <summary>
    /// The get query string.
    /// </summary>
    /// <returns>
    /// The get query string.
    /// </returns>
    //public string GetQueryString()
    //{
    //    SetTheSelectedFieldInputRepeaterData();
    //    string whereCondition;
    //    try
    //    {
    //        //DataTable dt = DataTableInput;
    //        //string ddlFieldDataValue = ddlField.SelectedValue.ToUpper().Split("`".ToCharArray())[1];
    //        //string ddlColumnName = ddlField.SelectedValue.ToUpper().Split("`".ToCharArray())[0];
    //        //string ddlConditionSelectedValue = ddlCondition.SelectedValue.Contains("`") ? ddlCondition.SelectedValue.Split("`".ToCharArray())[1] : ddlCondition.SelectedValue;
    //        //string ddlConditionSelectedText = ddlCondition.SelectedItem.Text;
    //        //whereCondition = ddlColumnName + " " + ddlConditionSelectedValue + " " + (HTStringDataTypes.Contains(ddlFieldDataValue) ? (ddlConditionSelectedValue == "LIKE") ? "'" + (ddlConditionSelectedText == "Contains" || ddlConditionSelectedText == "Ends With" ? "%" : string.Empty) + txtValue.Text.Replace("'", "''").ToUpper() + (ddlConditionSelectedText == "Contains" || ddlConditionSelectedText == "Begins With" ? "%" : string.Empty) + "'" : "'" + txtValue.Text.Replace("'", "''").ToUpper() + "'" : HTNumericDataTypes.Contains(ddlFieldDataValue) ? txtNumericValue.Text : (HTLikeDataTypes.Contains(ddlFieldDataValue)) ? "'%" + txtValue + "%'" : (HTDateDataTypes.Contains(ddlFieldDataValue)) ? ddlCondition.SelectedValue == "BETWEEN" ? "  '" + txtStartDateValue.Text + "' AND  '" + txtEndDateValue.Text + "'" : "  '" + txtStartDateValue.Text + "'" : (HTBooleanDataTypes.Contains(ddlFieldDataValue)) ? ddlIsActive.SelectedValue : string.Empty);
    //        //foreach (DataRow dr in dt.Rows)
    //        //{
    //        //    ddlConditionSelectedValue = dr["ConditionValue"].ToString();
    //        //    ddlConditionSelectedText = dr["ConditionText"].ToString();
    //        //    ddlConditionSelectedValue = ddlConditionSelectedValue.Contains("`") ? ddlConditionSelectedValue.Split("`".ToCharArray())[1] : ddlConditionSelectedValue;

    //        //    ddlFieldDataValue = dr["FieldDataType"].ToString();
    //        //    whereCondition += @" " + dr["LogicalOperator"] + " " + dr["Field"] + " " + ddlConditionSelectedValue + " " + (HTStringDataTypes.Contains(ddlFieldDataValue.Contains("`") ? ddlFieldDataValue.Split("`".ToCharArray())[1] : ddlFieldDataValue) ? (ddlConditionSelectedValue == "LIKE") ? "'" + (ddlConditionSelectedText == "Contains" || ddlConditionSelectedText == "Ends With" ? "%" : string.Empty) + dr["Value"].ToString().Replace("'", "''").ToUpper() + (ddlConditionSelectedText == "Contains" || ddlConditionSelectedText == "Begins With" ? "%" : string.Empty) + "'" : "'" + dr["Value"].ToString().Replace("'", "''").ToUpper() + "'" : HTNumericDataTypes.Contains(ddlFieldDataValue.Contains("`") ? ddlFieldDataValue.Split("`".ToCharArray())[1] : ddlFieldDataValue) ? dr["NumericValue"] : (HTDateDataTypes.Contains(ddlFieldDataValue.Contains("`") ? ddlFieldDataValue.Split("`".ToCharArray())[1] : ddlFieldDataValue)) ? dr["ConditionValue"].ToString().Trim() == "BETWEEN" ? "  '" + dr["StartDateValue"] + "' AND  '" + dr["EndDateValue"] + "'" : "  '" + dr["StartDateValue"] + "'" : string.Empty);
    //        //}
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return string.Empty;
    //    }


    //    return whereCondition;
    //}

    /// <summary>
    /// The ddl field_ selected index changed.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    //protected void ddlField_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        DropDownList ddlField = (DropDownList)sender;
    //        DropDownList ddlCondition = (DropDownList)ddlField.Parent.FindControl("ddlCondition");
    //        TextBox txtValue = (TextBox)ddlField.Parent.FindControl("txtValue");
    //        TextBox txtNumericValue = (TextBox)ddlField.Parent.FindControl("txtNumericValue");
    //        TextBox txtStartDateValue = (TextBox)ddlField.Parent.FindControl("txtStartDateValue");
    //        TextBox txtEndDateValue = (TextBox)ddlField.Parent.FindControl("txtEndDateValue");
    //        CfiRequiredFieldValidator rfvTxtValue = (CfiRequiredFieldValidator)ddlField.Parent.FindControl("rfvTxtValue");
    //        CfiRequiredFieldValidator rfvTxtNumericValue = (CfiRequiredFieldValidator)ddlField.Parent.FindControl("rfvTxtNumericValue");
    //        CfiRequiredFieldValidator rfvTxtStartDateValue = (CfiRequiredFieldValidator)ddlField.Parent.FindControl("rfvTxtStartDateValue");
    //        CfiRequiredFieldValidator rfvTxtEndDateValue = (CfiRequiredFieldValidator)ddlField.Parent.FindControl("rfvTxtEndDateValue");
    //        SetRelevantCondition(ddlField, ddlCondition, txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue, ddlIsActive);
    //        ddlField.Focus();
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    /// <summary>
    /// The set relevant condition.
    /// </summary>
    /// <param name="ddlField">
    /// The ddl field.
    /// </param>
    /// <param name="ddlCondition">
    /// The ddl condition.
    /// </param>
    /// <param name="txtValue">
    /// The txt value.
    /// </param>
    /// <param name="txtNumericValue">
    /// The txt numeric value.
    /// </param>
    /// <param name="txtStartDateValue">
    /// The txt start date value.
    /// </param>
    /// <param name="txtEndDateValue">
    /// The txt end date value.
    /// </param>
    /// <param name="rfvTxtValue">
    /// The rfv txt value.
    /// </param>
    /// <param name="rfvTxtNumericValue">
    /// The rfv txt numeric value.
    /// </param>
    /// <param name="rfvTxtStartDateValue">
    /// The rfv txt start date value.
    /// </param>
    /// <param name="rfvTxtEndDateValue">
    /// The rfv txt end date value.
    /// </param>
    private void SetRelevantCondition(DropDownList ddlField, DropDownList ddlCondition, TextBox txtValue, TextBox txtNumericValue, TextBox txtStartDateValue, TextBox txtEndDateValue, CfiRequiredFieldValidator rfvTxtValue, CfiRequiredFieldValidator rfvTxtNumericValue, CfiRequiredFieldValidator rfvTxtStartDateValue, CfiRequiredFieldValidator rfvTxtEndDateValue, DropDownList ddlIsActive)
    {
        try
        {
            RemoveAllConditions(ddlCondition);

            // if(ddlField.SelectedIndex > 0)
            // {
            string dataType = ddlField.SelectedValue.Split("`".ToCharArray())[1];
            if (HTNumericDataTypes.Contains(dataType))
            {
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Equals", "="));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Greater Than", ">"));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Less Than", "<"));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Greater Than Or Equal To", ">="));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Less Than Or Equal To", "<="));
            }
            else if (HTStringDataTypes.Contains(dataType))
            {
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Contains", "Contains`LIKE"));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Begins With", "Begins With`LIKE"));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Ends With", "Ends With`LIKE"));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Equals", "="));
            }
            else if (HTDateDataTypes.Contains(dataType))
            {
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Between", "BETWEEN"));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Less Than", "<"));
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Greater Than", ">"));
            }
            else if (HTBooleanDataTypes.Contains(dataType))
            {
                ddlCondition.Items.Add(new System.Web.UI.WebControls.ListItem("Equals", "="));
            }

            // DiaplayRelevantValueFields(dataType, txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, pcStartDate, pcEndDate, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue);
            DiaplayRelevantValueFields(dataType, ddlCondition, txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue);

            // }
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The diaplay relevant value fields.
    /// </summary>
    /// <param name="dataType">
    /// The data type.
    /// </param>
    /// <param name="ddlCondition">
    /// The ddl condition.
    /// </param>
    /// <param name="txtValue">
    /// The txt value.
    /// </param>
    /// <param name="txtNumericValue">
    /// The txt numeric value.
    /// </param>
    /// <param name="txtStartDateValue">
    /// The txt start date value.
    /// </param>
    /// <param name="txtEndDateValue">
    /// The txt end date value.
    /// </param>
    /// <param name="rfvTxtValue">
    /// The rfv txt value.
    /// </param>
    /// <param name="rfvTxtNumericValue">
    /// The rfv txt numeric value.
    /// </param>
    /// <param name="rfvTxtStartDateValue">
    /// The rfv txt start date value.
    /// </param>
    /// <param name="rfvTxtEndDateValue">
    /// The rfv txt end date value.
    /// </param>
    private void DiaplayRelevantValueFields(string dataType, DropDownList ddlCondition, TextBox txtValue, TextBox txtNumericValue, TextBox txtStartDateValue, TextBox txtEndDateValue, CfiRequiredFieldValidator rfvTxtValue, CfiRequiredFieldValidator rfvTxtNumericValue, CfiRequiredFieldValidator rfvTxtStartDateValue, CfiRequiredFieldValidator rfvTxtEndDateValue)
    {
        try
        {
            // HideAllValueFields(txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, pcStartDate, pcEndDate, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue);
            //HideAllValueFields(txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue, ddlIsActive);
            //if (dataType == "NUMBER" || dataType == "INT64" || dataType == "INT32" || dataType == "INTEGER" || dataType == "DECIMAL")
            //{
            //    txtNumericValue.Visible = true;
            //    rfvTxtNumericValue.Visible = true;
            //}
            //else if (dataType == "VARCHAR2" || dataType == "NVARCHAR2" || dataType == "VARCHAR" || dataType == "NVARCHAR" || dataType == "STRING")
            //{
            //    txtValue.Visible = true;
            //    rfvTxtValue.Visible = true;
            //}
            //else if (dataType == "DATE" || dataType == "DATETIME")
            //{
            //    txtStartDateValue.Visible = true;
            //    rfvTxtStartDateValue.Visible = true;
            //    if (txtEndDateValue.Text != string.Empty)
            //    {
            //        txtEndDateValue.Visible = true;
            //        rfvTxtEndDateValue.Visible = true;
            //    }

            //    // pcStartDate.Visible = true;
            //    // pcEndDate.Visible = true;
            //}
            //else if (dataType == "BOOL" || dataType == "BOOLEAN")
            //{
            //    ddlIsActive.Visible = true;
            //}
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The hide all value fields.
    /// </summary>
    /// <param name="txtValue">
    /// The txt value.
    /// </param>
    /// <param name="txtNumericValue">
    /// The txt numeric value.
    /// </param>
    /// <param name="txtStartDateValue">
    /// The txt start date value.
    /// </param>
    /// <param name="txtEndDateValue">
    /// The txt end date value.
    /// </param>
    /// <param name="rfvTxtValue">
    /// The rfv txt value.
    /// </param>
    /// <param name="rfvTxtNumericValue">
    /// The rfv txt numeric value.
    /// </param>
    /// <param name="rfvTxtStartDateValue">
    /// The rfv txt start date value.
    /// </param>
    /// <param name="rfvTxtEndDateValue">
    /// The rfv txt end date value.
    /// </param>
    private void HideAllValueFields(TextBox txtValue, TextBox txtNumericValue, TextBox txtStartDateValue, TextBox txtEndDateValue, CfiRequiredFieldValidator rfvTxtValue, CfiRequiredFieldValidator rfvTxtNumericValue, CfiRequiredFieldValidator rfvTxtStartDateValue, CfiRequiredFieldValidator rfvTxtEndDateValue, DropDownList ddlIsActive)
    {
        try
        {
            txtValue.Visible = false;
            rfvTxtValue.Visible = false;
            txtNumericValue.Visible = false;
            rfvTxtNumericValue.Visible = false;
            txtStartDateValue.Visible = false;
            rfvTxtStartDateValue.Visible = false;
            txtEndDateValue.Visible = false;
            rfvTxtEndDateValue.Visible = false;
            ddlIsActive.Visible = false;
            // pcStartDate.Visible = false;
            // pcEndDate.Visible = false;
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The remove all conditions.
    /// </summary>
    /// <param name="ddl">
    /// The ddl.
    /// </param>
    protected void RemoveAllConditions(DropDownList ddl)
    {
        try
        {
            ddl.Items.Clear();

            // ddl.Items.Add(new ListItem("Select", "0"));
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The rpt field input_ item command.
    /// </summary>
    /// <param name="source">
    /// The source.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    //protected void rptFieldInput_ItemCommand(object source, RepeaterCommandEventArgs e)
    //{
    //    try
    //    {
    //        if (e.CommandName.Equals("DeleteInput"))
    //        {
    //            DataTable dt = DataTableInput;
    //            dt.Rows[e.Item.ItemIndex].Delete();
    //            DataTableInput = dt;
    //            BindInputRepeater();
    //            ddlField.Focus();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    /// <summary>
    /// The rpt field input_ item data bound.
    /// </summary>
    /// <param name="source">
    /// The source.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    //protected void rptFieldInput_ItemDataBound(object source, RepeaterItemEventArgs e)
    //{
    //    try
    //    {
    //        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
    //        {
    //            DropDownList ddlField = (DropDownList)e.Item.FindControl("ddlField");
    //            Cfi.SoftwareFactory.Common.CommonFunctions.FillDropDownListFromTable(ref ddlField, FieldDataSource, "0` ", "Select", true);

    //            ddlField.SelectedValue = DataTableInput.Rows[e.Item.ItemIndex]["FieldDataType"].ToString();
    //            DropDownList ddlCondition = (DropDownList)e.Item.FindControl("ddlCondition");
    //            TextBox txtValue = (TextBox)e.Item.FindControl("txtValue");
    //            TextBox txtNumericValue = (TextBox)e.Item.FindControl("txtNumericValue");
    //            TextBox txtStartDateValue = (TextBox)e.Item.FindControl("txtStartDateValue");
    //            TextBox txtEndDateValue = (TextBox)e.Item.FindControl("txtEndDateValue");
    //            CfiRequiredFieldValidator rfvTxtValue = (CfiRequiredFieldValidator)e.Item.FindControl("rfvTxtValue");
    //            CfiRequiredFieldValidator rfvTxtNumericValue = (CfiRequiredFieldValidator)e.Item.FindControl("rfvTxtNumericValue");
    //            CfiRequiredFieldValidator rfvTxtStartDateValue = (CfiRequiredFieldValidator)e.Item.FindControl("rfvTxtStartDateValue");
    //            CfiRequiredFieldValidator rfvTxtEndDateValue = (CfiRequiredFieldValidator)e.Item.FindControl("rfvTxtEndDateValue");
    //            SetRelevantCondition(ddlField, ddlCondition, txtValue, txtNumericValue, txtStartDateValue, txtEndDateValue, rfvTxtValue, rfvTxtNumericValue, rfvTxtStartDateValue, rfvTxtEndDateValue, ddlIsActive);
    //            ddlCondition.SelectedValue = DataTableInput.Rows[e.Item.ItemIndex]["ConditionValue"].ToString();
    //            DropDownList ddlLogicalOperator = (DropDownList)e.Item.FindControl("ddlLogicalOperator");
    //            ddlLogicalOperator.SelectedValue = DataTableInput.Rows[e.Item.ItemIndex]["LogicalOperator"].ToString();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    /// <summary>
    /// Method to bind the current entity.
    /// </summary>
    private void BindInputRepeater()
    {
        try
        {
            // For Showing the Delete Button on the last Row
            //if (DataTableInput.Rows.Count > 0)
            //    cmdDeleteInput.Visible = true;
            //else
            //    cmdDeleteInput.Visible = false;

            //rptFieldInput.DataSource = DataTableInput;
            //rptFieldInput.DataBind();
            //lblOperator.Visible = DataTableInput.Rows.Count > 0;
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The set the selected field input repeater data.
    /// </summary>
    //private void SetTheSelectedFieldInputRepeaterData()
    //{
    //    try
    //    {
    //        DataTable dt = CreateDataTableInput();
    //        foreach (RepeaterItem ri in rptFieldInput.Items)
    //        {
    //            DropDownList ddlLogicalOperator = (DropDownList)ri.FindControl("ddlLogicalOperator");
    //            DropDownList ddlField = (DropDownList)ri.FindControl("ddlField");
    //            DropDownList ddlCondition = (DropDownList)ri.FindControl("ddlCondition");
    //            TextBox txtValue = (TextBox)ri.FindControl("txtValue");
    //            TextBox txtNumericValue = (TextBox)ri.FindControl("txtNumericValue");
    //            TextBox txtStartDateValue = (TextBox)ri.FindControl("txtStartDateValue");
    //            TextBox txtEndDateValue = (TextBox)ri.FindControl("txtEndDateValue");
    //            DataRow dr = dt.NewRow();
    //            dr["Field"] = ddlField.SelectedValue.ToUpper().Split("`".ToCharArray())[0];
    //            dr["ConditionValue"] = ddlCondition.SelectedValue;
    //            dr["ConditionText"] = ddlCondition.SelectedItem.Text;
    //            dr["Value"] = txtValue.Text;
    //            dr["NumericValue"] = txtNumericValue.Text;
    //            dr["StartDateValue"] = txtStartDateValue.Text;
    //            dr["EndDateValue"] = txtEndDateValue.Text;
    //            dr["LogicalOperator"] = ddlLogicalOperator.SelectedValue;
    //            dr["FieldDataType"] = ddlField.SelectedValue;
    //            dt.Rows.Add(dr);
    //        }

    //        DataTableInput = dt;
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    /// <summary>
    /// The cmd save search filter_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void cmdSaveSearchFilter_Click(object sender, EventArgs e)
    {
        try
        {
            //    this.WhereCondition = this.GetQueryString();

            //    if (txtSearchName.Text != string.Empty)
            //    {
            //        this.SetTheSelectedFieldInputRepeaterData();
            //        DataTable dt = this.DataTableInput;
            //        DataRow dr = dt.NewRow();
            //        dr["Field"] = ddlField.SelectedValue.ToUpper().Split("`".ToCharArray())[0];
            //        dr["ConditionValue"] = ddlCondition.SelectedValue;
            //        dr["Value"] = txtValue.Text;
            //        dr["NumericValue"] = txtNumericValue.Text;
            //        dr["StartDateValue"] = txtStartDateValue.Text;
            //        dr["EndDateValue"] = txtEndDateValue.Text;
            //        dr["LogicalOperator"] = "0";
            //        dr["FieldDataType"] = ddlField.SelectedValue;
            //        dt.Rows.Add(dr);
            //        this.DataTableInput = dt;
            //        if (rblSaveSearchFilter.SelectedIndex == 0)
            //            this.SaveSearchFilter();
            //        if (rblSaveSearchFilter.SelectedIndex == 1)
            //        {
            //            string cookieValue = txtSearchName.Text + "`" + int.Parse((new ApplicationPage()).GetList("Page", "SNo", "HyperLink='" + Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower()+"/", string.Empty) + "'").Rows[0]["SNo"].ToString());
            //            HttpCookie httpCookies = Request.Cookies[((UserLogin)Session["LoginDetails"]).SNo.ToString()];
            //            if (httpCookies == null)
            //                httpCookies = new HttpCookie(((UserLogin)Session["LoginDetails"]).SNo.ToString()) { Expires = DateTime.MaxValue };
            //            else if (httpCookies.Values[cookieValue] != null)
            //                httpCookies.Values.Remove(cookieValue);
            //            httpCookies.Values.Add(cookieValue, HttpUtility.UrlEncode(Cfi.SoftwareFactory.Common.CommonFunctions.GetXMLFromDataTable(this.DataTableInput)));

            //            Response.Cookies.Add(httpCookies);
            //        }

            //        //// Set the event while this button is clicked.
            //        //this.SearchFilterSaveButtonClick(cmdSaveSearchFilter, e);

            //        // Fill the saved drop down list again...
            //        this.FillSavedDropDownList();
            //        txtSearchName.Text = string.Empty;
            // }
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

        finally
        {
            //cmdRemoveSavedSearch.Visible = false;
        }
    }

    /// <summary>
    /// The save search filter.
    /// </summary>
    private void SaveSearchFilter()
    {
        try
        {
            using (SearchFilter searchSearch = new SearchFilter())
            {
                //searchSearch.UserId = ((UserLogin)Session["LoginDetails"]).SNo.ToString();
                //searchSearch.ReportName = ReportName;
                //searchSearch.FilterName = txtSearchName.Text;
                //DataTable dt = searchSearch.GetNew();
                //dt.Rows[0]["PageSNo"] = int.Parse((new ApplicationPage()).GetList("Page", "SNo", "HyperLink='" + Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower()+"/", string.Empty) + "'").Rows[0]["SNo"].ToString());
                //dt.Rows[0]["LoginSNo"] = ((UserLogin)Session["LoginDetails"]).SNo.ToString();
                //dt.Rows[0]["FilterName"] = txtSearchName.Text;
                //dt.Rows[0]["FilterXml"] = Cfi.SoftwareFactory.Common.CommonFunctions.GetXMLFromDataTable(DataTableInput);
                //dt.Rows[0]["PageNo"] = PageNo;
                //dt.Rows[0]["PageSize"] = PageSize;
                //searchSearch.DoCreate(dt);
                //if (searchSearch.ErrorNumber > 0)
                //{
                //    if (searchSearch.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                //    {
                //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                //        ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", searchSearch.ErrorMessage.Split(':')[1]);
                //    }
                //    else
                //    {
                //        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                //        ucMessage.Message = (string)GetLocalResourceObject(searchSearch.ErrorMessage.Split(':')[1]);
                //    }
                //    return;
                //}

            }
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The ddl saved search_ selected index changed.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    //protected void ddlSavedSearch_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        this.WhereCondition = GetQueryString();

    //        // Setting the last saved search...
    //        if (ddlCookiesSavedSearch.Visible)
    //        {
    //            // Show or hide the delete filter button depending upon the selected index...
    //            cmdRemoveSavedSearch.Visible = ddlCookiesSavedSearch.SelectedIndex != 0;

    //            if (ddlCookiesSavedSearch.SelectedValue != string.Empty)
    //            {
    //                SetSavedCookieSearchFilter(((UserLogin)Session["LoginDetails"]).SNo.ToString(), ddlCookiesSavedSearch.SelectedValue);

    //                //// Set the event while this button is clicked.
    //                //if (SearchFilterDropDownListSelectedIndexChange != null)
    //                //    SearchFilterDropDownListSelectedIndexChange(ddlCookiesSavedSearch, e);
    //            }
    //        }
    //        else if (ddlDatabaseSavedSearch.Visible)
    //        {
    //            // Show or hide the delete filter button depending upon the selected index...
    //            cmdRemoveSavedSearch.Visible = ddlDatabaseSavedSearch.SelectedIndex != 0;

    //            SetSavedDatabaseSearchFilter(((UserLogin)Session["LoginDetails"]).SNo.ToString(), ddlDatabaseSavedSearch.SelectedValue);

    //            // Set the event while this button is clicked.
    //            //if (SearchFilterDropDownListSelectedIndexChange != null)
    //            //    SearchFilterDropDownListSelectedIndexChange(ddlDatabaseSavedSearch, e);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //}

    /// <summary>
    /// The rbl save search filter_ selected index changed.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    //protected void rblSaveSearchFilter_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (rblSaveSearchFilter.SelectedIndex == 0)
    //        {
    //            ddlDatabaseSavedSearch.Visible = true;
    //            FillSavedDropDownList();
    //            ddlCookiesSavedSearch.Visible = false;
    //        }
    //        else
    //        {
    //            ddlDatabaseSavedSearch.Visible = false;
    //            ddlCookiesSavedSearch.Visible = true;
    //            FillSavedDropDownList();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }

    //    finally
    //    {
    //        cmdRemoveSavedSearch.Visible = false;
    //    }
    //}

    /// <summary>
    /// The cmd remove saved search_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void cmdRemoveSavedSearch_Click(object sender, EventArgs e)
    {
        try
        {
            //if (rblSaveSearchFilter.SelectedIndex == 0)
            //{
            //    SearchFilter saveSearchFilter = new SearchFilter();
            //    saveSearchFilter.DoDelete(int.Parse(ddlDatabaseSavedSearch.SelectedValue.Split("~".ToCharArray())[2]));
            //    FillSavedDropDownList();
            //}
            //else
            //{
            //    HttpCookie httpCookies = Request.Cookies[((UserLogin)Session["LoginDetails"]).SNo.ToString()];
            //    if (httpCookies != null)
            //    {
            //        if (httpCookies.Values[ddlCookiesSavedSearch.SelectedValue] != null)
            //        {
            //            httpCookies.Values.Remove(ddlCookiesSavedSearch.SelectedValue);
            //            Response.Cookies.Add(httpCookies);
            //        }

            //        FillSavedDropDownList();
            //    }
            //}
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The lbl first_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void lblFirst_Click(object sender, EventArgs e)
    {
        try
        {
            txtPageNo.Text = "1";
            BindGridView();

        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The lb previous_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void lbPrevious_Click(object sender, EventArgs e)
    {
        try
        {
            int currentPageNo = int.Parse(txtPageNo.Text);
            if (currentPageNo > 1)
            {
                txtPageNo.Text = (currentPageNo - 1) + string.Empty;

                // The next function is commented, becaue now we do not need to search from the existing data in the data table, rather from the data base itself.
                // SearchGridView();
                // Set the event while this button is clicked.
                BindGridView();

            }
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The lb next_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void lbNext_Click(object sender, EventArgs e)
    {
        try
        {
            int totalNoOfPages = int.Parse(lblTotalNoOfPages.Text);
            int currentPageNo = int.Parse(txtPageNo.Text);
            if (currentPageNo < totalNoOfPages)
            {
                txtPageNo.Text = (currentPageNo + 1) + string.Empty;

                // The next function is commented, becaue now we do not need to search from the existing data in the data table, rather from the data base itself.
                // SearchGridView();
                // Set the event while this button is clicked.
                BindGridView();

            }
            else if (totalNoOfPages <= currentPageNo)
                lbNext.Enabled = false;
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The lbl last_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void lblLast_Click(object sender, EventArgs e)
    {
        try
        {
            txtPageNo.Text = lblTotalNoOfPages.Text;

            // The next function is commented, becaue now we do not need to search from the existing data in the data table, rather from the data base itself.
            // SearchGridView();
            // Set the event while this button is clicked.
            BindGridView();

        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The ddl page size_ selected index changed.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            int currentPageNo = int.Parse(txtPageNo.Text);
            int totalNoOfPages = int.Parse(lblTotalNoOfPages.Text);
            if (currentPageNo > totalNoOfPages)
                txtPageNo.Text = lblTotalNoOfPages.Text;
            else if (currentPageNo < 1)
                txtPageNo.Text = "1";

            // The next function is commented, becaue now we do not need to search from the existing data in the data table, rather from the data base itself.
            // SearchGridView();
            // Set the event while this button is clicked.
            BindGridView();

        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    // Added by Chandra prakash on 16 Dec 2009 for Delete the Last Row
    /// <summary>
    /// The cmd delete input_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void cmdDeleteInput_Click(object sender, EventArgs e)
    {
        try
        {
            //SetTheSelectedFieldInputRepeaterData();
            //DataTable dt = DataTableInput;
            //RepeaterItem rpt = rptFieldInput.Items[dt.Rows.Count - 1];

            //DropDownList ddlFieldrepeater = (DropDownList)rpt.FindControl("ddlField");
            //ddlField.SelectedValue = ddlFieldrepeater.SelectedValue;

            //DropDownList ddlConditionrepeater = (DropDownList)rpt.FindControl("ddlCondition");
            //ddlCondition.SelectedValue = ddlConditionrepeater.SelectedValue;

            //TextBox txtValuerepeater = (TextBox)rpt.FindControl("txtValue");
            //TextBox txtNumericValuerepeater = (TextBox)rpt.FindControl("txtNumericValue");
            //TextBox txtStartDateValuerepeater = (TextBox)rpt.FindControl("txtStartDateValue");
            //TextBox txtEndDateValuerepeater = (TextBox)rpt.FindControl("txtEndDateValue");

            //txtValue.Text = txtValuerepeater.Text;
            //txtNumericValue.Text = txtNumericValuerepeater.Text;
            //txtStartDateValue.Text = txtStartDateValuerepeater.Text;
            //txtEndDateValue.Text = txtEndDateValuerepeater.Text;

            //dt.Rows.Remove(dt.Rows[dt.Rows.Count - 1]);
            //rptFieldInput.DataSource = dt;
            //rptFieldInput.DataBind();
            //lblOperator.Visible = dt.Rows.Count > 0; // Added by Chandra Prakash
            //DataTableInput = dt;
            //if (dt.Rows.Count == 0)
            //    cmdDeleteInput.Visible = false;
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    // Added by Chandra prakash on 16 Dec 2009 for Delete the Last Row

    /// <summary>
    /// The cmd clear search_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void cmdClearSearch_Click(object sender, EventArgs e)
    {
        try
        {
            this.WhereCondition = string.Empty;
            hdnSearchControlHTML.Value = string.Empty;
            hdnSearchConditions.Value = string.Empty;
            tdClearSearchPipe.Visible = false;
            tdClearSearchButton.Visible = false;
            this.BindGridView();
            upUserControlSub.Update();
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The txt page no_ changed.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void txtPageNo_Changed(object sender, EventArgs e)
    {
        try
        {
            if (int.Parse(txtPageNo.Text) < 1)
            {
                ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                ucMessage.Message = "Page Number should be greater than 0";
                txtPageNo.Text = "1";
            }
            else if (int.Parse(txtPageNo.Text) > int.Parse(lblTotalNoOfPages.Text))
            {
                ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                ucMessage.Message = "Page Number can not be greater than " + lblTotalNoOfPages.Text;
                txtPageNo.Text = lblTotalNoOfPages.Text;
            }

            int totalNoOfPages = int.Parse(lblTotalNoOfPages.Text);
            int currentPageNo = int.Parse(txtPageNo.Text);
            if (currentPageNo <= totalNoOfPages)
                BindGridView();
            else if (totalNoOfPages == currentPageNo)
                lbNext.Enabled = false;
        }
        catch (Exception ex)
        {
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }

    }

    /// <summary>
    /// The img export to excel_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void imgExportToExcel_Click(object sender, ImageClickEventArgs e)
    {
        Response.ClearContent();
        string htmlMarkUp = RenderHtml();
        Response.AppendHeader("content-disposition", "attachment;filename=Report.xls");
        Response.Charset = String.Empty;
        Response.Write(htmlMarkUp);
        Response.End();
    }


    /// <summary>
    /// The img export to pdf_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void imgExportToPdf_Click(object sender, ImageClickEventArgs e)
    {
        Response.ClearContent();
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Report.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        var sr = new StringReader(RenderHtml());
        var pdfDoc = new Document(iTextSharp.text.PageSize.A4, 10f, 10f, 10f, 0f);
        var htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }

    /// <summary>
    /// The img export to word_ click.
    /// </summary>
    /// <param name="sender">
    /// The sender.
    /// </param>
    /// <param name="e">
    /// The e.
    /// </param>
    protected void imgExportToWord_Click(object sender, ImageClickEventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=Report.doc");
        Response.Charset = string.Empty;
        Response.ContentType = "application/vnd.ms-word ";
        Response.Output.Write(RenderHtml());
        Response.Flush();
        Response.End();
    }

    /// <summary>
    /// Method to Render all server control into html string type
    /// </summary>
    /// <returns>
    /// string html
    /// </ret
    /// urns>
    public DataTable GridViewData { get { return (DataTable)ViewState["GridViewData"]; } set { ViewState["GridViewData"] = value; } }

    private string RenderHtml()
    {
        ControlsToRender = this.GridViewIdToBindFilteredDataTo;

        SearchFilter searchFilterClass = new SearchFilter { PageNo = PageNo, PageSize = PageSize, NameSpacePrefix = ClassName };
        string whereCondition = this.WhereCondition;

        if (!string.IsNullOrEmpty(this.QueryString))
            if (!string.IsNullOrEmpty(this.WhereCondition))
                whereCondition = this.QueryString + " AND " + this.WhereCondition;
            else
                whereCondition = this.QueryString;

        searchFilterClass.WhereCondition = whereCondition;
        searchFilterClass.OrderBy = String.Empty;
        DataTable dt = searchFilterClass.GetList();

        this.SetAccessRights();

        // IsExtraBinding = false;
        // Getting the columns which are needed to hide in the grid view along with the creation of the list of the columns which is to be displayed in the search filter...
        string columnsToDisplayInSearchFilter = string.Empty;
        string columnsToHideFromSearchFilter = string.Empty;
        foreach (object objCfiTemplate in this.TemplateCollection)
        {
            CfiTemplate cfiTemplate = (CfiTemplate)objCfiTemplate;
            string[,] primaryKeyColumnWithHideAttribute = cfiTemplate.PrimaryKeyColumnWithHideAttribute;
            for (int i = 0; i < primaryKeyColumnWithHideAttribute.GetLength(0); i++)
            {
                if (!columnsToHideFromSearchFilter.Contains(primaryKeyColumnWithHideAttribute[i, 0]) && bool.Parse(primaryKeyColumnWithHideAttribute[i, 1]))
                    columnsToHideFromSearchFilter += primaryKeyColumnWithHideAttribute[i, 0] + ",";
                else if (!columnsToDisplayInSearchFilter.Contains(primaryKeyColumnWithHideAttribute[i, 0]) && !bool.Parse(primaryKeyColumnWithHideAttribute[i, 1]))
                    columnsToDisplayInSearchFilter += primaryKeyColumnWithHideAttribute[i, 0] + ",";
            }
        }

        columnsToDisplayInSearchFilter = columnsToDisplayInSearchFilter.Contains(",") ? columnsToDisplayInSearchFilter.Substring(0, columnsToDisplayInSearchFilter.LastIndexOf(",")).ToLower() : string.Empty;
        columnsToHideFromSearchFilter = columnsToHideFromSearchFilter.Contains(",") ? columnsToHideFromSearchFilter.Substring(0, columnsToHideFromSearchFilter.LastIndexOf(",")).ToLower() : string.Empty;
        PrimaryKeyColumns = columnsToHideFromSearchFilter == "" ? columnsToDisplayInSearchFilter : columnsToHideFromSearchFilter;


        //Making Grid Header along with column
        System.Text.StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.Append("<table class=\"GridViewStyle\"><tbody><tr class=\"HeaderStyle\">");

        for (int i = 0; i < dt.Columns.Count; i++)
        {
            if (!columnsToHideFromSearchFilter.Contains(dt.Columns[i].ColumnName.ToLower()))
                stringBuilder.Append("<th><a href=\"javascript:void(0);\")\">" + dt.Columns[i].ColumnName + "</a></th>");
        }
        stringBuilder.Append("</tr>");

        //Making Grid Row along with value and action
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            if (i % 2 == 0)
                stringBuilder.Append("<tr class=\"RowStyle\">");
            else
                stringBuilder.Append("<tr class=\"AltRowStyle\">");

            for (int j = 0; j < dt.Columns.Count; j++)
                if (!columnsToHideFromSearchFilter.Contains(dt.Columns[j].ColumnName.ToLower()))
                {
                    DataColumn dcDataSource = dt.Columns[j];
                    if (dcDataSource.DataType == typeof(bool))
                        stringBuilder.Append(dt.Rows[i][j].ToString() == "True" ? "<td>Yes" : "<td>No" + "</td>");
                    else if (dcDataSource.DataType == typeof(DateTime))
                        stringBuilder.Append("<td>" + ((DateTime)dt.Rows[i][j]).ToShortDateString() + "</td>");
                    else
                        stringBuilder.Append("<td>" + dt.Rows[i][j] + "</td>");
                }
            stringBuilder.Append("</tr>");
        }
        stringBuilder.Append("</tbody></table>");
        return stringBuilder.ToString();
    }


    /// <summary>
    /// Method to remove anchor tags.
    /// </summary>
    /// <param name="html">The html from which to remove the anchor tag.</param>
    /// <returns>The html without anchor tags.</returns>
    private string RemoveAnchorTags(string html)
    {
        string httpPattern = @"</?a+((\s+\w+(\s*=\s*(?:"".*?""|'.*?'|[^'"">\s]+))?)+\s*|\s*)/?>";
        Regex anchorTextExtractor = new Regex(httpPattern);
        MatchCollection objCol = anchorTextExtractor.Matches(html);
        foreach (Match m in objCol)
            if (m.Success)
                html = html.Replace(m.Value, String.Empty);
        return html;
    }

    private string SetImageAbsolutePath(string html)
    {
        return html.Replace("../images", Server.MapPath("."));
    }

    protected void upUserControlMain_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}