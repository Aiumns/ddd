﻿/* LeftControl UserControl Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This class implements  leftcontrol at home page.(This class is basically a replica of existing cargo/home.aspx with some code cleaning exercises)
 * Created By           :   Dhiraj kumar
 * Created On           :   31 May 2010.
 */
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cfi.App.Pace.Business;
using System.Text;
public partial class CRM_AppControls_Common_LeftControl : System.Web.UI.UserControl
{

    /// <summary>
    /// Delclaration of global vaiables and intitializing Login  and management business classes
    /// </summary>
    public string IP = "";
    BLLogin bl = new BLLogin();
    BMgmt bm = new BMgmt();
   
    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">
    /// The sender of the page load event.
    /// </param>
    /// <param name="e">
    /// The arguments of the page load event.
    /// </param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
            Response.Redirect("Login.aspx");
        
        lblName.Text = "Welcome " + Session["DisplayName"].ToString();
        IP = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
        string[] compBrSNo = Session["AllCompBrSNo"].ToString().Split(',');
        if (!IsPostBack)
        {
            try
            {
              
                if (compBrSNo.Length > 1 && Session["LoginType"].ToString().Trim() != "SUPER ADMIN")
                {
                    foreach(string t in compBrSNo)
                    {
                        DataSet dsCompDetails = bl.getCustBranchBySNo(Convert.ToInt32(t));
                        if (dsCompDetails.Tables[0].Rows.Count > 0)
                        {
                            string companyName = dsCompDetails.Tables[0].Rows[0]["Name"] + "--" + dsCompDetails.Tables[0].Rows[0]["City"] + "--" + dsCompDetails.Tables[0].Rows[0]["Place"];
                            string compSNo = dsCompDetails.Tables[0].Rows[0]["compBrSNo"].ToString();
                            ddlCompany.Items.Add(new ListItem(companyName, compSNo));
                        }
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(Session["compBrSNo"].ToString()))
                    {
                        string compBrSno = Session["compBrSNo"].ToString().Substring(0, Session["compBrSNo"].ToString().IndexOf(','));
                        string[] Type = bl.getCompTypeNew(compBrSno).Split('~');
                        Session["CompBrType"] = Type[0].ToString();
                        Session["CompName"] = Type[1].ToString();
                        Session["InvoicePrefix"] = Type[2].ToString();
                    }
                    //BAgentMaster BA = new BAgentMaster();
                    //string Chklogin = BA.CheckRights(Session["LoginType"].ToString());
                }

              
            }
             
            catch
            {

            }
           
        }
        if (compBrSNo.Length > 1)
        {
            if (Session["CheckFirstTimeLoad"] == null)
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "dialogBox", "ShowDialog();GetCompanyLogo('imgCompanyLogoView');", true);
          
           
        }

        if (Session["RFBCount"] != null)
        {
            StringBuilder stringBuilder = new StringBuilder();
            string count = Session["RFBCount"].ToString();
            stringBuilder.Append("$(function(){");
            stringBuilder.Append("$('#lbnRFBCount').text('" + Session["RFBCount"].ToString() + "');");
            stringBuilder.Append("});");
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "RFBCount", stringBuilder.ToString(), true);
        }

       
    }
    
}
