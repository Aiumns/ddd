﻿//==========================================================================================
// Copyright © 2008 by Cargo Flash Infotech Pvt. Ltd. All Rights Reserved.
// Project              : CFCS
// File Name            : CfiTextBox.ascx
// Program Description  : CfiTextBox control, used to prevent the validation controls.
// Programmed By        : Chandra Prakash
// Programmed On        : March 04,2010
// Updated By           : Sudhir Yadav
// Updated On           : 12 Mar 2010
// Description          : Removed NumericWithZero
//==========================================================================================

using System;
using System.Globalization;
using System.Web.UI;
using Cfi.SoftwareFactory.WebControls;
using System.Web.UI.WebControls;

public partial class AppControls_Common_NumericTextBox : System.Web.UI.UserControl
{
    public enum ValueTypes
    {
        Default,
        ULDCapacity,
        ACCapacity,
        AWBGrossWeight,
        AWBVolumeWeight,
        Dimension,
        Percentage
    }
    public enum CfiTextBoxTypes
    {
        Default,
        Numeric,
        Alphabet,
        AlphaNumeric,
        AlphaNumericUpperCase,
        AlphabetUpperCase,
        DefaultUpperCase,
        NumericWithHyphen
    }

    //public AppControls_Common_NumericTextBox()
    //{
    //    MinLength = 0;
    //}

    /// <summary>
    /// Gets or sets ErrorMessage.
    /// </summary>
    private string rangeErrorMessage;
    public string RangeErrorMessage
    {
        get { return rangeErrorMessage; }
        set { rangeErrorMessage = value;}
    }

    private string lengthErrorMessage;
    public string LengthErrorMessage
    { get { return lengthErrorMessage; }
        set { lengthErrorMessage = value; }
    }

    private string customErrorMessage;
    public string CustomErrorMessage
    { get { return customErrorMessage; }
        set { customErrorMessage = value; }
    }

    private string rangeType;
    public string RangeType
    { get { return rangeType; }
        set{ rangeType = value;} }

    private string minimumValue;
    public string MinimumValue
    { get { return minimumValue; }
        set { minimumValue = value; }
    }
    private string maximumValue;
    public string MaximumValue
    { get { return maximumValue; }
        set { maximumValue = value; }
    }

    private string customClientFunction;
    public string CustomClientFunction
    { get{ return customClientFunction;} set{ customClientFunction = value;} }

    private string requiredErrorMessage;
    public string RequiredErrorMessage
    { get { return requiredErrorMessage; }
        set { requiredErrorMessage = value; }
    }

    private bool isRequired;
    public bool IsRequired
    { get { return isRequired; }
        set { isRequired = value; }
    }

    private bool isRanged;
    public bool IsRanged
    { get{ return isRanged;} set{ isRanged = value;} }

    private bool isCustomValidate;
    public bool IsCustomValidate
    {
        get { return isCustomValidate; }
        set { isCustomValidate = value;}
    }

    private string validationGroup;
    public string ValidationGroup
    {
        get { return validationGroup; }
        set { validationGroup = value; }
    }

    private CfiTextBoxTypes cfiTextBoxType;
    public CfiTextBoxTypes CfiTextBoxType
    {
        get { return cfiTextBoxType; }
        set { cfiTextBoxType = value;}
    }

    public AutoCompleteType AutoCompleteType
    {
        get
        {
            return this.txtValue.AutoCompleteType;
        }
        set
        {
            this.txtValue.AutoCompleteType = value;
        }
    }

    private ValueTypes cfiValueType;
    public ValueTypes CfiValueType
    { get{ return cfiValueType;} set{ cfiValueType = value;} }

    public System.Web.UI.WebControls.Unit Width
    {
        get
        {
            return this.txtValue.Width;
        }
        set
        {
            this.txtValue.Width = value;
        }

    }


    public int PlacesofDecimal
    {
        get
        {
            return this.txtValue.PlacesOfDecimal;
        }
        set
        {
            this.txtValue.PlacesOfDecimal = value;
        }
    }

    public string Text
    {
        get
        {
            return this.txtValue.Text;
        }
        set
        {
            this.txtValue.Text = value;
        }
    }

    public int MaxLength
    {
        get
        {
            return this.txtValue.MaxLength;
        }
        set
        {
            this.txtValue.MaxLength = value;
        }
    }

    private int minLength;
    public int MinLength
    {
        get{ return minLength;}
        set{ minLength = value;}
    }

    public short TabIndex
    {
        get
        {
            return this.txtValue.TabIndex;
        }
        set
        {
            this.txtValue.TabIndex = value;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        CultureInfo c = new CultureInfo("en-US");
        System.Threading.Thread.CurrentThread.CurrentCulture = c;
        //if(CfiTextBoxType == CfiTextBoxTypes.NumericWithHyphen)
        //    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Numeric" + txtValue.ClientID, " $ (document).ready(function(){$('#" + txtValue.ClientID + "').numeric({ allow: 'a' });});", true);
        //else
        txtValue.CfiTextBoxType = (CfiTextBox.CfiTextBoxTypes)this.CfiTextBoxType;

        if(IsRequired)
        {
            CfiRequiredFieldValidator requiredFieldValidator = new CfiRequiredFieldValidator();

            requiredFieldValidator.ControlToValidate = "txtValue";
            requiredFieldValidator.ErrorMessage = this.RequiredErrorMessage;
            requiredFieldValidator.SetFocusOnError = true;
            requiredFieldValidator.Display = ValidatorDisplay.None;
            requiredFieldValidator.ValidationGroup = this.ValidationGroup;
            requiredFieldValidator.ID = "rfvtxtValue";
                                                               
            this.Controls.Add(requiredFieldValidator);
        }
        if(IsRanged)
        {
            CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
            switch(this.CfiValueType)
            {
                case ValueTypes.Dimension:
                    this.MinimumValue = "1.00";
                    this.MaximumValue = "999.99";
                    break;
                case ValueTypes.Percentage:
                    if(string.IsNullOrEmpty(this.MinimumValue))
                        this.MinimumValue = "0.01";
                    this.MaximumValue = "100.00";
                    break;
                case ValueTypes.ULDCapacity:
                    this.MinimumValue = "1.00";
                    this.MaximumValue = "9999.99";
                    break;
                case ValueTypes.ACCapacity:
                    this.MinimumValue = "1.00";
                    this.MaximumValue = "999999.99";
                    break;
                case ValueTypes.AWBGrossWeight:
                    this.MinimumValue = "1.00";
                    this.MaximumValue = "99999.99";
                    break;
                case ValueTypes.AWBVolumeWeight:
                    this.MinimumValue = "0.01";
                    this.MaximumValue = "99999.99";
                    break;
            }

            CfiRangeValidator rangeValidator = new CfiRangeValidator();

            rangeValidator.ControlToValidate = "txtValue";
            rangeValidator.ErrorMessage = this.RangeErrorMessage;
            rangeValidator.SetFocusOnError = true;
            rangeValidator.MinimumValue = this.MinimumValue;
            rangeValidator.MaximumValue = this.MaximumValue;
            rangeValidator.CultureInvariantValues = true;
            rangeValidator.Display = ValidatorDisplay.None;
            rangeValidator.Type = ValidationDataType.Currency;
            rangeValidator.ValidationGroup = this.ValidationGroup;
            rangeValidator.ID = "rvtxtValue";
                                                
            this.Controls.Add(rangeValidator);
        }
        
        if(IsCustomValidate)
        {
            CfiCustomValidator customValidator = new CfiCustomValidator();

            customValidator.ControlToValidate = "txtValue";
            customValidator.ErrorMessage = CustomErrorMessage;
            customValidator.SetFocusOnError = true;
            customValidator.Display = ValidatorDisplay.Dynamic;
            customValidator.ValidationGroup = this.ValidationGroup;
            customValidator.ClientValidationFunction = CustomClientFunction;
            customValidator.ID = "cvtxtValue";
                                                  
            this.Controls.Add(customValidator);
        }
    }
}
