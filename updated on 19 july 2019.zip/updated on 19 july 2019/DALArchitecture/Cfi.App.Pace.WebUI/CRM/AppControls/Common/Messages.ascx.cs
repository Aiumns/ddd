﻿/* Messages UserControl Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   User Control used to display text messages on the top of the page.
 * Created By           :   Sudhir Yadav.
 * Created On           :   15 Sep 2009.
 * Modified By          :   Sudhir Yadav.
 * Modified On          :   03 Mar 2010.
 * Description          :   Changed the autohide functionality to work with javascript for this control rahter then postbacks. Removed AutoHide property. 
 *                          Woking with AutoHideInterval property only. It's '0' value will indicate that we do not wish to auto hide this control.
 */
using System;
using System.Collections;
using System.Web.UI;
using AjaxControlToolkit;
using Cfi.SoftwareFactory.Common;

/// <summary>
/// Class used to display text messages on the top of the page.
/// </summary>
public partial class AppControls_Messages : UserControl
{
    #region UIMessageType enum
    /// <summary>
    /// Enum to set the type of the message.
    /// </summary>
    public enum UIMessageType
    {
        Success,
        Information,
        Error
    }
    #endregion

    /// <summary>
    /// Get or set the trigger for the update panel containing this control, using the Hashtable. The hashtable will contain key as the control id ( in the form of the control's UniqueID) and the event of the control on which the trigger will be fired.
    /// </summary>
    public Hashtable ControlIdEventPair
    {
        get { return ViewState["ControlIdEventPair"] == null ? new Hashtable() : (Hashtable)ViewState["ControlIdEventPair"]; }
        set
        {
            ViewState["ControlIdEventPair"] = value;
            IDictionaryEnumerator iDictionaryEnumerator = value.GetEnumerator();
            while (iDictionaryEnumerator.MoveNext())
            {
                AsyncPostBackTrigger asyncPostBackTrigger = new AsyncPostBackTrigger();
                asyncPostBackTrigger.ControlID = iDictionaryEnumerator.Key.ToString();
                asyncPostBackTrigger.EventName = iDictionaryEnumerator.Value.ToString();
                upUserControlMain.Triggers.Add(asyncPostBackTrigger);
            }
        }
    }

    /// <summary>
    /// Get or set the css class of the label which will display the message.
    /// </summary>
    public string CssClass { set { lblMessage.CssClass = value; } }

    /// <summary>
    /// Get or set the SkinId of the label which will display the message.
    /// </summary>
    public string SkinId { set { lblMessage.SkinID = value; } }

    /// <summary>
    /// Get or set the auto hide interval (in seconds) of the label after which it will not be seen. 0, for not hiding automatically.
    /// </summary>
    public int AutoHideInterval { set { ViewState["AutoHideInterval"] = value; } get { return (ViewState["AutoHideInterval"] == null ? 10 : (int)ViewState["AutoHideInterval"]); } }

    /// <summary>
    /// Get or set the message that will be displayed.
    /// </summary>
    public string Message
    {
        set
        {

            string estring = "";
            if (!string.IsNullOrEmpty(value))
            {
                if (MessageType != null)
                {
                    if (MessageType == UIMessageType.Information)
                        estring =
                            "<div id=\"divMesg\" style=\"background-color:#D6ECFF;padding-top:8px;padding-bottom:8px; border:solid 1px green; \"><table><tr><td><img src= \"" + Page.ResolveClientUrl("~/Images/success.png") + "\" alt=\"\" /></td><td class=\"SuccessMsgContent\">" +
                            value + "</td></tr><table></div>";

                    else if (MessageType == UIMessageType.Error)

                        estring =
                            "<div id=\"divMesg\" style=\"background-color:#D6ECFF; border:solid 1px red;\"><table><tr><td><img src= \"" + Page.ResolveClientUrl("~/Images/Error.png") + "\"  alt=\"\" /></td><td class=\"ErrorMsgContent\">" +
                            value +
                            "</td></tr></table></div>";
                    else if (MessageType == UIMessageType.Success)
                        estring =
                            "<div id=\"divMesg\" style=\"background-color:#D6ECFF; border:solid 1px blue; \"><table><tr><td><img src= \"" + Page.ResolveClientUrl("~/Images/info.png") + "\"  alt=\"\" /></td><td class=\"InformationMsgContent\">" +
                            value +
                            "</td></tr></table></div>";
                }
            }
            lblMessage.Text = estring;
            lblMessage.Visible = true;
        }
    }

    /// <summary>
    /// Get or set weather to auto hide the message box.
    /// </summary>
   
    public UIMessageType MessageType { set { ViewState["UIMessageType"] = value; } get { return (UIMessageType)ViewState["UIMessageType"]; } }

   
    public string RedirectPage { get { return ViewState["RedirectPage"] == null ? "" : ViewState["RedirectPage"].ToString(); } set { ViewState["RedirectPage"] = value; } }

    /// <summary>
    /// Set the active tab container id
    /// </summary>
    public string PageTabContainerID { set { ViewState["PageTabContainerID"] = value; } get { return ViewState["PageTabContainerID"] == null ? "" : ViewState["PageTabContainerID"].ToString(); } }

    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">The sender of the page load event.</param>
    /// <param name="e">The arguments of the page load event.</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        Message = String.Empty;
//        ScriptManager.RegisterStartupScript(Page, typeof(Page), "RoundDivForMsg", @"$(function () {
//                $('#divMesg').corners('5px');
//            });", true);
        if (AutoHideInterval != 0)
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "HideMessageBox", " setTimeout(\"$('#" + lblMessage.ClientID + "').hide('slow');\", " + AutoHideInterval * 1000 + ");", true);
    }


   
}