﻿/* AppControls_Common_Report Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   Use Control to display the report.
 * Created By           :   Sudhir Yadav.
 * Created On           :   23 Feb 2010.
*/

using System;
using System.Collections.Specialized;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using Cfi.App.Pace.WebUI;
using Microsoft.Reporting.WebForms;
using System.Configuration;

/// <summary>
/// Use Control to display the report.
/// </summary>
public partial class AppControls_Common_Report : System.Web.UI.UserControl
{
    /// <summary>
    /// Delegate to handle the Save/Update/Delete action button.
    /// </summary>
    /// <param name="sender">The action button which is delegating the method.</param>
    /// <param name="actionAndCancelButtonEventArgs">The arguments returned when the event is raised.</param>
    public delegate void ActionClickHandler(object sender, ActionEventArgs actionAndCancelButtonEventArgs);

    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
    public event ActionClickHandler ActionClick;

    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">The sender of the page load event.</param>
    /// <param name="e">The arguments of the page load event.</param>
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    /// <summary>
    /// Method to display the local server in the report viewer.
    /// </summary>
    /// <param name="reportParameters">The parameters of the report.</param>
    /// <param name="reportName">The name of the report from where the report is picked.</param>
    public void DisplayReport(ReportParameter[] reportParameters, string reportName)
    {
        reportViewer.Reset();
        reportViewer.ServerReport.ReportServerCredentials = new ReportServerCredential();
        reportViewer.ProcessingMode = ProcessingMode.Remote;
        reportViewer.ShowParameterPrompts = false;
        reportViewer.SizeToReportContent = true;
        reportViewer.Width = new System.Web.UI.WebControls.Unit(100, UnitType.Percentage);
        //reportViewer.ServerReport.ReportPath = ConfigurationManager.AppSettings["ReportServerReportPath"] + reportName;

        Uri uri = new Uri(ConfigurationManager.AppSettings["ReportServerURI"]);
        reportViewer.ServerReport.ReportServerUrl = uri;
        reportViewer.ServerReport.SetParameters(reportParameters);
        reportViewer.ServerReport.Refresh();
        reportViewer.AsyncRendering = false;
        if(reportViewer.Enabled)
            reportViewer.CurrentPage = 1;
    }

    /// <summary>
    /// Method to display the local report in the report viewer.
    /// </summary>
    /// <param name="reportParameters">The parameters of the report.</param>
    /// <param name="reportDataSource">The data source of the report that is used.</param>
    /// <param name="reportPath">The path of the report from where the report is picked up along with the report name.</param>
    public void DisplayReport(ReportParameter[] reportParameters, ReportDataSource reportDataSource, string reportPath)
    {
        reportViewer.Reset();
        reportViewer.SizeToReportContent = true;
        reportViewer.Width = new System.Web.UI.WebControls.Unit(100, UnitType.Percentage);
        reportViewer.LocalReport.ReportPath = reportPath;
        reportViewer.LocalReport.SetParameters(reportParameters);
        reportViewer.LocalReport.DataSources.Clear();
        reportViewer.LocalReport.DataSources.Add(reportDataSource);
        reportViewer.DataBind();
        reportViewer.LocalReport.Refresh();
        reportViewer.AsyncRendering = false;
        if(reportViewer.Enabled)
            reportViewer.CurrentPage = 1;
    }

    protected void cmdBack_Click(object sender, EventArgs e)
    {
        if(ActionClick != null)
            ActionClick(sender, new ActionEventArgs(ActionType.Cancel, e));
    }

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        this.Page.PreRenderComplete += OnPagePreRender;
    }

    protected void OnPagePreRender(object sender, EventArgs eventArgs)
    {
        ListDictionary scripts = this.Page.ClientScript.GetType().GetField("_registeredClientScriptBlocks", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(this.Page.ClientScript) as ListDictionary;

        foreach(object key in scripts.Keys)
        {
            Type type = key.GetType().GetField("_type", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(key) as Type;
            if(type.Namespace.StartsWith("Microsoft.Reporting.WebForms"))
            {
                string registeredKey = key.GetType().GetField("_key", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(key) as string;
                ScriptManager.RegisterClientScriptBlock(Page, type, registeredKey, scripts[key] as string, true);
            }
        }
    }
   
}
