﻿/* Competitor UserControl Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This class implements the functionality related to Competitor.
 * Created By           :   Dhiraj  Kumar.
 * Created On           :   21 May 2010.

 */
using System;
using System.Data;
using System.Text;
using System.Web.UI;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
using System.Web.UI.WebControls;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Data.SqlClient;

/// <summary>
/// Class to implement the functionality related to Competitor. This class inherits UserControl class.
/// </summary>
public partial class CRM_AppControls_Common_Competitor : UserControl
{
    #region Delegates

    /// <summary>
    /// Delegate to handle the Save/Update/Delete action button.
    /// </summary>
    /// <param name="sender">
    /// The action button which is delegating the method.
    /// </param>
    /// <param name="actionAndCancelButtonEventArgs">
    /// The arguments returned when the event is raised.
    /// </param>
    public delegate void ActionClickHandler(object sender, ActionEventArgs actionAndCancelButtonEventArgs);

    #endregion

    /// <summary>
    /// String object name that is the Competitor name, which is being operated.
    /// </summary>
    private string currentTitle = string.Empty;

    /// <summary>
    /// User control which is used to display the message on this page.
    /// </summary>
    private AppControls_Messages ucMessage;


    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
    public event ActionClickHandler ActionClick;

    /// <summary>
    /// Get or set the Competitor Item Index.
    /// </summary>
    public int CompetitorMovementItemIndex { get { return Convert.ToInt32(ViewState["CompetitorMovementItemIndex"]); } set { ViewState["CompetitorMovementItemIndex"] = value; } }


    /// <summary>
    /// Get or set the CompetitorMovement Table.
    /// </summary>
    public DataTable CompetitorMovementTable { get { return (DataTable)ViewState["dtCompetitorMovementList"]; } set { ViewState["dtCompetitorMovementList"] = value; } }

    /// <summary>
    /// Get or set the CompetitorMovement Mode.
    /// </summary>
    public string CompetitorMovementMode { get { return ViewState["CompetitorMovementMode"].ToString(); } set { ViewState["CompetitorMovementMode"] = value; } }

    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">
    /// The sender of the page load event.
    /// </param>
    /// <param name="e">
    /// The arguments of the page load event.
    /// </param>
    protected void Page_Load(object sender, EventArgs e)
    {
        ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages");

    }

    /// <summary>
    /// Method for Creating Form Controls and according to UIMode(like add/modify/delete/view)
    /// </summary>
    /// <param name="uiMode">
    /// To set mode like New/Edit/View/Delete 
    /// </param>
    /// <summary>
    /// Method for creating the form and loading the data according to the mode.
    /// </summary>
    /// <param name="uiMode">
    /// To set mode like New/Edit/View/Delete for the form being generated. 
    /// </param>
    public void CreateForm(UIMode uiMode, string primaryKeyValue)
    {
        try
        {
            hdnUIModeType.Value = uiMode.ToString();
            if (hdnUIModeType.Value != "New")
                hdnPrimaryKeyValue.Value = primaryKeyValue;
            LoadJavaScript();
            cmdAction.Visible = true;
            lblTitle.Text = string.Empty;
            BindCompetitor();
            switch (hdnUIModeType.Value)
            {
                case "View":
                    cmdAction.Visible = false; cmdCancel.Text = "Back"; cmdCancel.CssClass = "buttonRegular";
                    lblTitle.Text = "View Competitor: " + txtCompanyName.Text;
                    this.ToggleDiv(pnlCompetitorMovementInformation, "Competitor Movement Information", "divCompetitorMovement", true);
                    break;
                case "New":
                    cmdAction.Text = "Save";
                    CompetitorMovementMode = "New";
                    lblTitle.Text = "New Competitor: ";
                    txtCompanyName.Focus();
                    if (this.CompetitorMovementTable == null)
                    {
                        using (CompetitorMovement competitorMovement = new CompetitorMovement())
                        {
                            this.CompetitorMovementTable = competitorMovement.GetNew();
                            this.CompetitorMovementTable.Rows.Clear();
                            this.CompetitorMovementTable.Columns.Add("Id", typeof(Int32));
                            this.CompetitorMovementTable.Columns.Add("CompanyName", typeof(string));
                            this.CompetitorMovementTable.Columns["Id"].AutoIncrement = true;
                            this.CompetitorMovementTable.Columns["Id"].AutoIncrementSeed = 1;
                        }
                    }
                    rptCompetitorMovementTrans.DataSource = this.CompetitorMovementTable;
                    rptCompetitorMovementTrans.DataBind();
                    if (CompetitorMovementTable.Rows.Count < 1)
                    {
                        rptCompetitorMovementTrans.Visible = false;
                        ucDisplayEmptyMessageCompetitorMovement.Visible = true;
                    }
                    else
                    {
                        rptCompetitorMovementTrans.Visible = true;
                        ucDisplayEmptyMessageCompetitorMovement.Visible = false;
                    }
                    upAddCompetitorMovement.Update();
                    ucDisplayEmptyMessageCompetitorMovement.Visible = true;
                    ucDisplayEmptyMessageCompetitorMovement.DataText = "Competitor Movement Information";
                    this.ToggleDiv(pnlCompetitorMovementInformation, "Competitor Movement Information", "divCompetitorMovement", false);
                    break;
                case "Update":
                    cmdAction.Text = "Update";
                    lblTitle.Text = "Update Competitor: " + txtCompanyName.Text;
                    this.ToggleDiv(pnlCompetitorMovementInformation, "Competitor Movement Information", "divCompetitorMovement", false);
                    CompetitorMovementMode = "New";
                    break;
                case "Delete":
                    cmdAction.Attributes.Add("onclick",
                                             "jConfirm('" + currentTitle + "Are your Sure to delete?','Competitor',function(r){if(r)" +
                                             Page.ClientScript.GetPostBackEventReference(cmdAction,
                                                                                         cmdAction.CommandName) +
                                             ";}); return false;");
                    cmdAction.Text = "Delete";
                    lblTitle.Text = "Delete Competitor: " + txtCompanyName.Text;

                    break;
            }

            lblTitle.Visible = true;
            if (hdnUIModeType.Value == "View" || hdnUIModeType.Value == "Delete")
                CommonFunctions.ChangeControlsToLabel(null, pnlContent);
            else
            {
                cmdAction.Attributes.Add("onclick", "IsValidateForm('SaveAndUpdate','" + cmdAction.ClientID + "');");
                cmdAddCompetitorMovement.Attributes.Add("onclick", "IsValidateForm('AddMovement','" + cmdAddCompetitorMovement.ClientID + "');");
            }
        }
        catch (Exception ex)
        {
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            //  //cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }
    }

    /// <summary>
    /// Method to bind the current entity.
    /// </summary>
    private void BindCompetitor()
    {
        try
        {
            if (!string.IsNullOrEmpty(hdnPrimaryKeyValue.Value))
            {
                using (Competitor competitor = new Competitor())
                {
                    competitor.RecordID = hdnPrimaryKeyValue.Value;
                    DataTable dtCompetitor = competitor.GetRecord();
                    if (dtCompetitor != null && dtCompetitor.Rows.Count > 0)
                    {
                        txtCompanyName.Text = dtCompetitor.Rows[0]["CompanyName"].ToString();
                        txtEmail.Text = dtCompetitor.Rows[0]["Email"].ToString();
                        txtState.Text = dtCompetitor.Rows[0]["State"].ToString();
                        txtCityCode.Text = dtCompetitor.Rows[0]["CityCode"].ToString();
                        txtCountryCode.Text = dtCompetitor.Rows[0]["CountryCode"].ToString();
                        txtAddress.Text = dtCompetitor.Rows[0]["Address"].ToString();
                        txtPhoneNo.Text = dtCompetitor.Rows[0]["Phone"].ToString();
                        txtFax.Text = dtCompetitor.Rows[0]["Fax"].ToString();
                        txtPinCode.Text = dtCompetitor.Rows[0]["PinCode"].ToString();
                        txtWebsite.Text = dtCompetitor.Rows[0]["Website"].ToString();
                        txtProductDescription.Text = dtCompetitor.Rows[0]["ProductDescription"].ToString();
                        txtProductUSPs.Text = dtCompetitor.Rows[0]["ProductUSPs"].ToString();
                        txtAdditionalInfo.Text = dtCompetitor.Rows[0]["AdditionalInfo"].ToString();
                        txtCampaign.Text = dtCompetitor.Rows[0]["Campaign"].ToString();
                        txtCountryCode.Text = dtCompetitor.Rows[0]["CountryCode"].ToString();
                        txtNewProductLaunch.Text = dtCompetitor.Rows[0]["NewProductLaunch"].ToString();
                    }

                    if (competitor.ErrorNumber > 0)
                    {

                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                        if (competitor.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                            ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", competitor.ErrorMessage.Split(':')[1]);
                        else
                            ucMessage.Message = (string)GetLocalResourceObject(competitor.ErrorMessage.Split(':')[1]);
                        return;
                    }
                }
                using (CompetitorMovement competitorMovement = new CompetitorMovement())
                {
                    competitorMovement.PrimaryKeyField = "CRMCompetitorSNo";
                    competitorMovement.RecordID = hdnPrimaryKeyValue.Value;
                    DataTable dtCompetitorMovement = competitorMovement.GetRecord();
                    if (!dtCompetitorMovement.Columns.Contains("Id"))
                        dtCompetitorMovement.Columns.Add("Id", typeof(Int32));
                    if (!dtCompetitorMovement.Columns.Contains("CompanyName"))
                        dtCompetitorMovement.Columns.Add("CompanyName", typeof(string));
                    dtCompetitorMovement.Columns["Id"].AutoIncrement = true;
                    dtCompetitorMovement.Columns["Id"].AutoIncrementSeed = 1;
                    ucDisplayEmptyMessageCompetitorMovement.Visible = !(dtCompetitorMovement.Rows.Count > 0);
                    rptCompetitorMovementTrans.Visible = dtCompetitorMovement.Rows.Count > 0;
                    rptCompetitorMovementTrans.DataSource = dtCompetitorMovement;
                    CompetitorMovementTable = dtCompetitorMovement;
                    rptCompetitorMovementTrans.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            //cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return;
        }
    }

    /// <summary>
    /// Method to handle the cancel button click.
    /// </summary>
    /// <param name="sender">
    /// The sender of the cancel event that is the cancel button.
    /// </param>
    /// <param name="e">
    /// The arguments of the sender that is the cancel button.
    /// </param>
    protected void cmdCancel_Click(object sender, EventArgs e)
    {
        ucMessage.Message = string.Empty;

        if (CompetitorMovementTable.Rows.Count > 0)
            CompetitorMovementTable.Rows.Clear();
        CommonFunctions.ClearControlValues(null, pnlContent);
        if (ActionClick != null)
            ActionClick(sender, new ActionEventArgs(ActionType.Cancel, e));
    }

    /// <summary>
    /// Method to handle the action button that is the Save/Update/Delete etc button.
    /// </summary>
    /// <param name="sender">
    /// In this case the cancel button.
    /// </param>
    /// <param name="e">
    /// The arguments of the sender that is the action button.
    /// </param>
    protected void cmdAction_Click(object sender, EventArgs e)
    {
        switch (hdnUIModeType.Value)
        {
            case "New":
                SaveData(e);
                break;
            case "Update":
                UpdateData(e);
                break;
            case "View":
                break;
            case "Delete":
                DeleteData(e);
                break;
        }
    }

    /// <summary>
    /// Method to Insert New Competitor
    /// </summary>
    /// <summary>
    /// Method to save new data of the current form.
    /// </summary>
    /// <param name="e">
    /// The event argument of the button that called this method, so as to use in the action click handler delegate for ActionEventArgs event.
    /// </param>
    private void SaveData(EventArgs e)
    {
        SqlTransaction tr = SqlHelper.CreateSqlTransaction(ConnectionString.WebConfigConnectionString);
        try
        {
            int competitorSNo = 0;
            using (Competitor competitor = new Competitor(tr))
            {
                DataTable dtCompetitor = competitor.GetNew();
                dtCompetitor.Rows[0]["CompanyName"] = txtCompanyName.Text;
                dtCompetitor.Rows[0]["Email"] = txtEmail.Text;
                dtCompetitor.Rows[0]["State"] = txtState.Text;
                dtCompetitor.Rows[0]["CityCode"] = txtCityCode.Text;
                dtCompetitor.Rows[0]["CountryCode"] = txtCountryCode.Text;
                dtCompetitor.Rows[0]["Address"] = txtAddress.Text;
                dtCompetitor.Rows[0]["Phone"] = txtPhoneNo.Text;
                dtCompetitor.Rows[0]["Fax"] = txtFax.Text;
                dtCompetitor.Rows[0]["PinCode"] = txtPinCode.Text;
                dtCompetitor.Rows[0]["Website"] = txtWebsite.Text;
                dtCompetitor.Rows[0]["ProductDescription"] = txtProductDescription.Text;
                dtCompetitor.Rows[0]["ProductUSPs"] = txtProductUSPs.Text;
                dtCompetitor.Rows[0]["AdditionalInfo"] = txtAdditionalInfo.Text;
                dtCompetitor.Rows[0]["Campaign"] = txtCampaign.Text;
                dtCompetitor.Rows[0]["CountryCode"] = txtCountryCode.Text;
                dtCompetitor.Rows[0]["NewProductLaunch"] = txtNewProductLaunch.Text;
                dtCompetitor.Rows[0]["UpdatedOn"] = DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"]));
                dtCompetitor.Rows[0]["UpdatedBy"] = Convert.ToInt32(((UserLogin)Session["LoginDetails"]).SNo);
                competitor.DoCreate(dtCompetitor);
                if (competitor.ErrorNumber > 0)
                {
                    tr.Rollback();
                    if (competitor.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                    {
                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                        ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", competitor.ErrorMessage.Split(':')[1]);
                    }
                    else
                    {
                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                        ucMessage.Message = (string)GetLocalResourceObject(competitor.ErrorMessage.Split(':')[1]);
                    }
                    return;
                }
                competitorSNo = competitor.SequenceName;
            }
            using (CompetitorMovement competitorMovement = new CompetitorMovement(tr))
            {

                DataTable dtCompetitorMovement = competitorMovement.GetNew();
                dtCompetitorMovement.Rows.Clear();
                DataTable dtCM = CompetitorMovementTable.Copy();
                foreach (DataRow dr in dtCM.Rows)
                {
                    DataRow drCompetitorMovement = dtCompetitorMovement.NewRow();
                    drCompetitorMovement["CRMCompetitorSNo"] = competitorSNo;
                    drCompetitorMovement["Description"] = dr["Description"].ToString();
                    drCompetitorMovement["UpdatedOn"] = DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"]));
                    drCompetitorMovement["UpdatedBy"] = Convert.ToInt32(((UserLogin)Session["LoginDetails"]).SNo);
                    dtCompetitorMovement.Rows.Add(drCompetitorMovement);
                }
                if (dtCompetitorMovement != null && dtCompetitorMovement.Rows.Count > 0)
                    competitorMovement.DoCreate(dtCompetitorMovement);
                if (competitorMovement.ErrorNumber > 0)
                {
                    tr.Rollback();
                    if (competitorMovement.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                    {
                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                        ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", competitorMovement.ErrorMessage.Split(':')[1]);
                    }
                    else
                    {
                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                        ucMessage.Message = (string)GetLocalResourceObject(competitorMovement.ErrorMessage.Split(':')[1]);
                    }
                    return;
                }

            }
            tr.Commit();

            if (ActionClick != null)
                ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
            ucMessage.Message = "Record Saved Successfully.";
            ucMessage.PageTabContainerID = "CompetitorMovement";
            CommonFunctions.ClearControlValues(null, pnlContent);
            CompetitorMovementTable = null;
            rptCompetitorMovementTrans.Visible = false;
        }

        catch (Exception ex)
        {
            tr.Rollback();
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            //cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            if (ActionClick != null)
                ActionClick(cmdAction, new ActionEventArgs(ActionType.Failure, e));
            //return;
        }
    }

    /// <summary>
    /// Method to update the existing current form data.
    /// </summary>
    /// <param name="e">
    /// The event argument of the button that called this method, so as to use in the action click handler delegate for ActionEventArgs event.
    /// </param>
    private void UpdateData(EventArgs e)
    {
        SqlTransaction tr = SqlHelper.CreateSqlTransaction(ConnectionString.WebConfigConnectionString);
        try
        {

            if (!string.IsNullOrEmpty(hdnPrimaryKeyValue.Value))
            {
                using (Competitor competitor = new Competitor(tr))
                {
                    competitor.RecordID = hdnPrimaryKeyValue.Value;
                    DataTable dtCompetitor = competitor.GetRecord();
                    dtCompetitor.Rows[0]["CompanyName"] = txtCompanyName.Text;
                    dtCompetitor.Rows[0]["Email"] = txtEmail.Text;
                    dtCompetitor.Rows[0]["State"] = txtState.Text;
                    dtCompetitor.Rows[0]["CityCode"] = txtCityCode.Text;
                    dtCompetitor.Rows[0]["CountryCode"] = txtCountryCode.Text;
                    dtCompetitor.Rows[0]["Address"] = txtAddress.Text;
                    dtCompetitor.Rows[0]["Phone"] = txtPhoneNo.Text;
                    dtCompetitor.Rows[0]["Fax"] = txtFax.Text;
                    dtCompetitor.Rows[0]["PinCode"] = txtPinCode.Text;
                    dtCompetitor.Rows[0]["Website"] = txtWebsite.Text;
                    dtCompetitor.Rows[0]["ProductDescription"] = txtProductDescription.Text;
                    dtCompetitor.Rows[0]["ProductUSPs"] = txtProductUSPs.Text;
                    dtCompetitor.Rows[0]["AdditionalInfo"] = txtAdditionalInfo.Text;
                    dtCompetitor.Rows[0]["Campaign"] = txtCampaign.Text;
                    dtCompetitor.Rows[0]["CountryCode"] = txtCountryCode.Text;
                    dtCompetitor.Rows[0]["NewProductLaunch"] = txtNewProductLaunch.Text;
                    dtCompetitor.Rows[0]["UpdatedOn"] = DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"]));
                    dtCompetitor.Rows[0]["UpdatedBy"] = Convert.ToInt32(((UserLogin)Session["LoginDetails"]).SNo);
                    competitor.DoUpdate(dtCompetitor);
                    if (competitor.ErrorNumber > 0)
                    {
                        tr.Rollback();
                        if (competitor.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                            ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", competitor.ErrorMessage.Split(':')[1]);
                        }
                        else
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                            ucMessage.Message = (string)GetLocalResourceObject(competitor.ErrorMessage.Split(':')[1]);
                        }
                        return;
                    }

                }
                using (CompetitorMovement competitorMovement = new CompetitorMovement(tr))
                {
                    DataTable dtCompetitorMovement = competitorMovement.GetNew();
                    dtCompetitorMovement.Rows.Clear();
                    DataTable dtCM = CompetitorMovementTable.Copy();

                    foreach (DataRow dr in dtCM.Rows)
                    {
                        competitorMovement.PrimaryKeyField = "CRMCompetitorSNo";
                        if (!string.IsNullOrEmpty(dr["CRMCompetitorSNo"].ToString()))
                            if (!string.IsNullOrEmpty(dr["SNo"].ToString()))
                                competitorMovement.DoDelete(dr["CRMCompetitorSNo"].ToString());
                        if (competitorMovement.ErrorNumber > 0)
                        {
                            tr.Rollback();
                            if (competitorMovement.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                            {
                                ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                                ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", competitorMovement.ErrorMessage.Split(':')[1]);
                            }
                            else
                            {
                                ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                                ucMessage.Message = (string)GetLocalResourceObject(competitorMovement.ErrorMessage.Split(':')[1]);
                            }
                            return;
                        }
                        DataRow drCompetitorMovement = dtCompetitorMovement.NewRow();
                        drCompetitorMovement["CRMCompetitorSNo"] = Convert.ToInt32(hdnPrimaryKeyValue.Value);
                        drCompetitorMovement["Description"] = dr["Description"].ToString();
                        drCompetitorMovement["UpdatedOn"] = DateTime.Now.AddMilliseconds(Convert.ToDouble(Application["ServerTimeDifference"]));
                        drCompetitorMovement["UpdatedBy"] = Convert.ToInt32(((UserLogin)Session["LoginDetails"]).SNo);
                        dtCompetitorMovement.Rows.Add(drCompetitorMovement);
                    }
                    competitorMovement.PrimaryKeyField = "SNo";
                    if (dtCompetitorMovement != null && dtCompetitorMovement.Rows.Count > 0)
                        competitorMovement.DoCreate(dtCompetitorMovement);
                    if (competitorMovement.ErrorNumber > 0)
                    {
                        tr.Rollback();
                        if (competitorMovement.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                            ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", competitorMovement.ErrorMessage.Split(':')[1]);
                        }
                        else
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                            ucMessage.Message = (string)GetLocalResourceObject(competitorMovement.ErrorMessage.Split(':')[1]);
                        }
                        return;
                    }
                }
                tr.Commit();               
                if (ActionClick != null)
                    ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
                ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
                ucMessage.Message = "Record Updated Successfully";
                ucMessage.PageTabContainerID = "Competitor";
                CommonFunctions.ClearControlValues(null, pnlContent);

            }
        }

        catch (Exception ex)
        {
            tr.Rollback();
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            //cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            if (ActionClick != null)
                ActionClick(cmdAction, new ActionEventArgs(ActionType.Failure, e));
            return;
        }
    }
    /// <summary>
    /// Method to Delete Selected Competitor
    /// </summary>
    /// <summary>
    /// Method to delete the existing current form data.
    /// </summary>
    /// <param name="e">
    /// The event argument of the button that called this method, so as to use in the action click handler delegate for ActionEventArgs event.
    /// </param>
     
    private void DeleteData(EventArgs e)
    {
         int countCompetitorMovement = 0;
        try
        {
            if (!string.IsNullOrEmpty(hdnPrimaryKeyValue.Value))
            {

      //*******Updated On 20 Oct 2010: Deleting Foreign reference Record First(if any) from table CRMCompetitorMovement******

                using (CompetitorMovement competitormovement = new CompetitorMovement())
                {
                    countCompetitorMovement = competitormovement.GetRecordCount("CRMCompetitorMovement", "*", "CRMCompetitorSNo=" + hdnPrimaryKeyValue.Value + "");
                    if (countCompetitorMovement > 0)
                    {
                        competitormovement.PrimaryKeyField = "CRMCompetitorSNo";
                        competitormovement.DoDelete(hdnPrimaryKeyValue.Value);
                    }
                    if (competitormovement.ErrorNumber > 0)
                    {
                        //SqlHelper.RollbackSqlTransaction();
                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                        ucMessage.Message = competitormovement.ErrorMessage.Split(':')[1].ToString();
                        return;
                    }
                }

                
                
                
                
                using (Competitor competitor = new Competitor())
                 {
                    competitor.DoDelete(hdnPrimaryKeyValue.Value);
                    if (competitor.ErrorNumber > 0)
                    {
                        if (competitor.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                            ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", competitor.ErrorMessage.Split(':')[1]);
                        }
                        else
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                            ucMessage.Message = (string)GetLocalResourceObject(competitor.ErrorMessage.Split(':')[1]);
                        }
                        if (ActionClick != null)
                            ActionClick(cmdAction, new ActionEventArgs(ActionType.Information, e));
                        return;
                    }
                    else
                    {
                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
                        if (ActionClick != null)
                            ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
                        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "RecordDeletedSuccessfully").ToString();
                        ucMessage.PageTabContainerID = "competitor.aspx";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            //cfiException.InsertExceptionIntoDatabase(true);
            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            if (ActionClick != null)
                ActionClick(cmdAction, new ActionEventArgs(ActionType.Failure, e));
            return;
        }
    }

    /// <summary>
    /// Method to load javascript for the ajax enabled functions.
    /// </summary>
    /// <param name="uiMode">
    /// The mode of the current form.
    /// </param>
    private void LoadJavaScript()
    {
        StringBuilder strJavaScript = new StringBuilder();
        // Add the script for the tabs...
        if (hdnUIModeType.Value == "New" || hdnUIModeType.Value == "Update")
        {

            strJavaScript.Append(@"
        function validateCompanyName(controlID)
                {
                   var isValidate =false;
                   var val = $('#'+controlID).val();
                   $.ajax({
                    url: '../../Services/CustomValidation.ashx',
                    cache: false,
                    async: false,
                    data: 'Entity=CRMCompetitor&Columns=ComapanyName&WhereCondition=ComapanyName=^' + val + '^',
                     success: function(data) {
                   isValidate= data!=null && data.items.length<=0;
                    if (!isValidate)
                        {
                            $('#' + controlID).attr('customErrorMessage','Company Name already exists.');
                        }
                        else {
                            $('#' + controlID).attr('customErrorMessage','');
                            }
                }
                 });
                    return isValidate;   
                    }onCustomValidation2=validateCompanyName;");

            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "AutoCompleteOptions", strJavaScript.ToString(), true);
        }
    }

    /// <summary>
    /// This method return the string to provide add button.
    /// </summary>
    /// <param name="panelId">
    /// The panel id.
    /// </param>
    /// <param name="groupText">
    /// panel group text
    /// </param>
    /// <param name="toggleDiv">
    /// Div Id to toggle
    /// </param>
    /// <param name="removeButton">
    /// The remove Button.
    /// </param>
    private void ToggleDiv(Panel panelId, string groupText, string toggleDiv, bool removeButton)
    {
        StringBuilder toggleScript = new StringBuilder();
        if (!removeButton)
        {
            toggleScript.Append(groupText + ":");
            toggleScript.Append("<a href=\"#\"");
            toggleScript.Append(" onclick=\" $('#" + toggleDiv + "').toggle('slow');$('#" + txtDescription.ClientID + "').focus(); ");
            toggleScript.Append("if($(this).text()=='[Add]')");
            toggleScript.Append("{");
            toggleScript.Append("$(this).text('');");
            toggleScript.Append("}");
            toggleScript.Append("else{");
            toggleScript.Append("$(this).text('[Add]');");
            toggleScript.Append("}");
            toggleScript.Append("\"");
            toggleScript.Append("/>[Add]</a>");
        }
        else
            toggleScript.Append(groupText);

        panelId.GroupingText = toggleScript.ToString();
    }

    /// <summary>
    /// Method to handle the Add CompetitorMovement button event for Save/Update/Delete.
    /// </summary>
    /// <param name="sender">
    /// button control as a sender.
    /// </param>
    /// <param name="e">
    /// The arguments of the sender that is the action button.
    /// </param>
    protected void cmdAddCompetitorMovement_Click(object sender, EventArgs e)
    {

        if (rptCompetitorMovementTrans.Items.Count >= 4)
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "QuickSearch", "$('input#txtQuickSearchCompetitorMovement').attr('style','display:block');$('span#spanLoadingCompetitorMovement').attr('style','display:block');$('input#txtQuickSearchCompetitorMovement').watermark('Quick Search');$('input#txtQuickSearchCompetitorMovement').quicksearch('table#tblCompetitorMovement tbody tr',{'loader':'span#spanLoadingCompetitorMovement'});", true);
        pnlCompetitorMovementInformation.Visible = true;
        DataTable dtCMTrans = CompetitorMovementTable;
        if (CompetitorMovementMode == "Update")
        {
            dtCMTrans.Rows.RemoveAt(CompetitorMovementItemIndex);
            dtCMTrans.AcceptChanges();
            LinkButton lbnEdit = (LinkButton)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lbnEdit");
            LinkButton lbnDelete = (LinkButton)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lbnDelete");
            Label lblPipe = (Label)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lblPipe");
            lblPipe.Text = "|";
            lbnEdit.Visible = true;
            lbnDelete.Visible = true;
            cmdAddCompetitorMovement.Text = "Add";
            CompetitorMovementMode = "New";
        }
        if (CompetitorMovementMode != "Delete")
        {
            DataRow drCMTrans = dtCMTrans.NewRow();
            drCMTrans["CompanyName"] = txtCompanyName.Text;
            drCMTrans["Description"] = txtDescription.Text;
            dtCMTrans.Rows.InsertAt(drCMTrans, CompetitorMovementItemIndex);
            dtCMTrans.AcceptChanges();
            CompetitorMovementTable = dtCMTrans;

        }
        if (CompetitorMovementMode == "Delete")
        {
            dtCMTrans.Rows.RemoveAt(CompetitorMovementItemIndex);
            dtCMTrans.AcceptChanges();
            CompetitorMovementTable = dtCMTrans;
            cmdAddCompetitorMovement.Text = "Add";
            CompetitorMovementMode = "New";
        }
        if (dtCMTrans != null && dtCMTrans.Rows.Count > 0)
        {
            ucDisplayEmptyMessageCompetitorMovement.Visible = false;
            rptCompetitorMovementTrans.Visible = true;
            rptCompetitorMovementTrans.DataSource = dtCMTrans;
            rptCompetitorMovementTrans.DataBind();
        }
        else
        {
            ucDisplayEmptyMessageCompetitorMovement.Visible = true;
            rptCompetitorMovementTrans.Visible = false;
        }

        txtDescription.Text = "";
        LoadJavaScript();
    }

    /// <summary>
    /// Method to handle the Add CompetitorMovement button event for Save/Update/Delete.
    /// </summary>
    /// <param name="sender">
    /// button control as a sender.
    /// </param>
    /// <param name="e">
    /// The arguments of the sender that is the action button.
    /// </param>
    protected void cmdCancelCompetitorMovement_Click(object sender, EventArgs e)
    {
        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "HideDiv", "$('#divCompetitorMovement').hide()", true);

        txtDescription.Text = "";
        if (this.CompetitorMovementItemIndex > 0)
        {
            LinkButton lbnEdit =
                (LinkButton)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lbnEdit");
            LinkButton lbnDelete =
                (LinkButton)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lbnDelete");
            Label lblPipe =
                (Label)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lblPipe");

            lblPipe.Text = "|";
            lbnEdit.Visible = true;
            lbnDelete.Visible = true;
        }
        cmdAddCompetitorMovement.Text = "Add";
        CompetitorMovementMode = "New";
        LoadJavaScript();
    }

    /// <summary>
    /// Repeater for Add/Update/Delete transaction data
    /// </summary>
    /// <param name="source"></param>
    /// <param name="e"></param>
    protected void rptCompetitorMovementTrans_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        this.CompetitorMovementItemIndex = e.Item.ItemIndex;
        LinkButton lbnEdit = (LinkButton)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lbnEdit");
        LinkButton lbnDelete = (LinkButton)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lbnDelete");
        Label lblPipe = (Label)rptCompetitorMovementTrans.Items[this.CompetitorMovementItemIndex].FindControl("lblPipe");
        if (rptCompetitorMovementTrans.Items.Count > 4)
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "QuickSearch", "$('input#txtQuickSearchCompetitorMovementTrans').attr('style','display:block');$('span#spanLoadingOfficeAirlineTrans').attr('style','display:block');$('input#txtQuickSearchOfficeAirlineTrans').watermark('Quick Search');$('input#txtQuickSearchOfficeAirlineTrans').quicksearch('table#tblOfficeAirlineTrans tbody tr',{'loader':'span#spanLoadingOfficeAirlineTrans'});", true);
        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ShowDiv", "$('#divCompetitorMovement').show()", true);
        pnlCompetitorMovementInformation.Visible = true;
        int i = int.Parse(e.CommandArgument.ToString());
        DataTable dtCMTrans = CompetitorMovementTable;
        string condition = "Id=" + i;
        DataRow[] drCMTrans = dtCMTrans.Select(condition);
        txtDescription.Text = drCMTrans[0].ItemArray[2].ToString();
        lbnEdit.Visible = false;
        lbnDelete.Visible = false;
        if (e.CommandName == "Edit")
        {
            cmdAddCompetitorMovement.Text = "Update";
            lblPipe.Text = "Updating....";
            CompetitorMovementMode = "Update";
        }
        if (e.CommandName == "Delete")
        {
            cmdAddCompetitorMovement.Text = "Delete";
            lblPipe.Text = "Delete....";
            CompetitorMovementMode = "Delete";
            CommonFunctions.ChangeControlsToLabel(null, pnlCMData, true);
        }
        upAddCompetitorMovement.Update();
        LoadJavaScript();
    }
}