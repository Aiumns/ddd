﻿using System;
using System.Web.UI;

/// <summary>
/// Class used to display text messages on the page.
/// </summary>
public partial class AppControls_EmptyDataFormat : UserControl
{
    /*
    *****************************************************************************
     * File Name: EmptyDataFormat.ascx.cs
     * Description: Control used to display empty text messages on the  page.
     * Created By: Vipin Kumar
     * Created On: 23 Dec 2009
    *****************************************************************************
	*/

    /// <summary>
    /// Get or set the message that will be displayed.
    /// </summary>
    public string DataText
    {
        get { return lblDefaultMessage.Text; }
        set
        {
            string userMessage = "";
            userMessage = value;
            if (string.IsNullOrEmpty(value))
                lblDefaultMessage.Text = "No Data Has Been Added Yet To Add New Data Click OnThe New Button";
            else
                // lblDefaultMessage.Text = "No " + userMessage + " has been added yet, to add a new " + userMessage + " click on the New Button.";
                lblDefaultMessage.Text = "No " + userMessage + " has been added yet.To add a new " + userMessage + " click on the Add Button";
         
        }
    }

    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">The sender of the page load event.</param>
    /// <param name="e">The arguments of the page load event.</param>
    protected void Page_Load(object sender, EventArgs e) {
      
  
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "RoundivForMsg", @"$(document).ready(function () {  $('#divOuterRoundForMsg').corners('5px');
        $('#divInnnerRoundForMsg').corners('5px');
    });", true);
      
    }
}