﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Activation;

/// <summary>
/// Summary description for SingleHostHeader
/// </summary>
public class SingleHostHeader : ServiceHostFactory
{
    public SingleHostHeader()
    {

    }

    protected override ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
    {
        List<Uri> addresses = new List<Uri>();
        addresses.Add(baseAddresses[0]);
        return base.CreateServiceHost(serviceType, addresses.ToArray());
    }
}
