using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Threading;
using System.Data.SqlClient;
using System.Data;
using Cfi.App.Pace.Common;
using System.Net;
using System.Net.Mail;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]

public class MailService : System.Web.Services.WebService {
    
    System.Threading.ThreadStart ts= null;
    System.Threading.Thread t = null;
    string strCon = Cfi.App.Pace.Common.PaceCommon.ConnectionString;
    int mailStartDate = 1;
    
    public MailService()
    {

        ts = new System.Threading.ThreadStart(sendSubscribedUsers);
        t = new System.Threading.Thread(ts);
        t.Start();
    }

    public class SubscribedUsers
    {
        int id = 0;
        string fullName = "";
        string eMail = "";
        int mailSubscription = 0;
        public SubscribedUsers(int id, string fullName, string eMail, int mailSubscription)
        {
            this.id = id;
            this.fullName = fullName;
            this.eMail = eMail;
            this.mailSubscription = mailSubscription;
        }
    }

    protected void sendSubscribedUsers()
    {
        SqlConnection con = null;
        ArrayList al = new ArrayList();
        try
        {
            con = new SqlConnection(strCon);
            //Select the subscribd users to send mail to...
            //And that too those whose mailing day have reached...
            //string searchString = "SELECT Id, FullName, Email, MailSubscription FROM JobSeekerDetails WHERE " + (mailStartDate++).ToString() + "%MailSubscription=0";
            string searchString = "SELECT Id FROM JobSeekerDetails WHERE MailSubscription!=0 AND " + (mailStartDate++).ToString() + "%MailSubscription=0";
            SqlCommand com = new SqlCommand(searchString, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while(dr.Read())
            {
                al.Add(dr["Id"].ToString());
            }
            dr.Close();
            com.Dispose();
            con.Close();
            int alLength = al.Count;
            while (alLength > -1)
            {
                selectTheJobsToSend(int.Parse(al[--alLength].ToString()));
            }
            //Sleep for one day...
            //Thread.Sleep(8640000);
        }
        catch (SqlException sqle)
        {
            String err = sqle.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void selectTheJobsToSend(int sentId)
    {
        SqlConnection con = null;
        try
        {
            con = new SqlConnection(strCon);
            string sendMailString = "<table><tr><td>";
            string searchString = "SELECT JSD.FullName, JSD.MailSubscription, JSD.Email, JSD.Username, JSD.Password, JSPD.Name AS 'JSPDName' FROM " + 
                " JobSeekerDetails AS JSD INNER JOIN JobSeekerProfileDetails AS JSPD ON JSD.ID=JSPD.JobSeekerDetailsId WHERE JSD.Id=" + sentId;
            SqlCommand com = new SqlCommand(searchString, con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            string whereClause = "";
            int noOfTimes = 0;
            string sendingEMailId = "";
            int mailSubscription = 0;
            while (dr.Read())
            {
                if (noOfTimes++ == 0)
                {
                    sendMailString += "Dear " + dr["FullName"].ToString() + "<br>Matching Jobs:<br>";
                    sendingEMailId = dr["EMail"].ToString();
                    mailSubscription=int.Parse(dr["MailSubscription"].ToString());
                }
                whereClause += " JDPD.Name LIKE '%" + dr["JSPDName"].ToString() + "%' OR ";
            }
            dr.Close();
            whereClause = " WHERE " + whereClause + " JDPD.Name LIKE '%Does not exists%'";
            sendMailString += "</td></tr></table><br><table>";

            if (noOfTimes > 0)
            {
                //Select only those jobs which have no tbeen sent previously and their start date is 
                //MailSubscription times greater then sending date i.e geDate()...
                string selectJobs = "SELECT JD.CompanyName FROM JobDetails AS JD INNER JOIN JobDetailsProfileDetails AS JDPD " +
                    " ON JD.id=JDPD.JobDetailsId INNER JOIN JobApply AS JA ON JA.JobSeekerId=JD.Id " + whereClause + " AND JD.StartDate>getDate()-" + mailSubscription +
                    " AND JA.JobSeekerId!=" + sentId;
                com.CommandText = selectJobs;
                dr = com.ExecuteReader();
                int noOfJobs=0;
                while (dr.Read())
                {
                    noOfJobs++;
                    sendMailString += "<tr><td>" + dr["CompanyName"].ToString() + " </td></tr>";
                }
                sendMailString += "</table>";
                if(noOfJobs>0)
                    sendMail(sendingEMailId, sendMailString);
            }
            dr.Close();            
            com.Dispose();
            con.Close();
        }
        catch (SqlException sqle)
        {
            String err = sqle.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void sendMail(string emailAddress,string body)
    {
        MailMessage msg = new MailMessage();
        //msg.To = "syadav.ascent@groupconcorde.com";
        //msg.To = "er.sudhir.yadav@gmail.com";
        msg.To.Add(emailAddress);
        msg.From = new MailAddress("cargoflash@placementoffice.com"); ;
        msg.Subject = "Sample Jobs";
        msg.IsBodyHtml = true;
        msg.Body = body;
        try
        {
            //SmtpMail.SmtpServer = "mail.pacexpress.net";
            //SmtpMail.Send(msg);
            SmtpClient smtp = new SmtpClient("cargoflash.com");
            string userName = "test@cargoflash.com";
            string password = "abc$567";
            smtp.Credentials = new NetworkCredential(userName, password);
            smtp.Send(msg);
        }
        catch (HttpException ex)
        {
        }
        catch (Exception ex)
        {
        }
        t.Abort();
    }
    
}

