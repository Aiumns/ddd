using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

//<summary>
//Summary description for dbdata
//</summary>
//public class dbdata
//{
////    protected DropDownList drpfillData(string tablename, string controlname)
////    {
////        SqlConnection con = null;
////        try
////        {
////            con = new SqlConnection(strCon);
////            SqlCommand com = new SqlCommand("SELECT * from '" + tablename, con);
////            con.Open();
////            SqlDataReader dr = com.ExecuteReader();
////            controlname.Items.Clear();
////            controlname.Items.Add("Select");
////            controlname.Items[0].Value = "";

////            while (dr.Read())
////            {
////                controlname.Items.Add(new ListItem(dr["Country"].ToString(), dr["Country"].ToString()));
////            }
////            dr.Close();
////            com.Dispose();
////            con.Close();
////        }
////        catch (SqlException sqle)
////        {
////            String err = sqle.ToString();
////            txtAddress.Text = err.ToString();
////        }
////        finally
////        {
////            if (con != null && con.State == ConnectionState.Open)
////                con.Close();
////        }
////    }
////    public dbdata()
////    {
////        //
////        // TODO: Add constructor logic here
////        //
////    }
////}