#region All NameSpaces
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Data.SqlClient;

#endregion


public class DisplayWrap
{

    #region GetAllFromQuery
    SqlConnection con;
    SqlCommand  com;
    SqlDataAdapter da;
    DataTable dt;

    public DataTable GetAllFromQuery(string Query)
    {
        try
        {

            string strCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            dt = new DataTable();
            con = new SqlConnection(strCon);
            com = new SqlCommand(Query);
            com.Connection = con;
            da = new SqlDataAdapter(com);
            da.Fill(dt);
         }
        catch (SqlException sqlex)
        {
            string err = sqlex.ToString();
        }
        finally
         {
               if (con != null && con.State == ConnectionState.Open)
                con.Close();
         }
        return dt;
    }

    #endregion
}
