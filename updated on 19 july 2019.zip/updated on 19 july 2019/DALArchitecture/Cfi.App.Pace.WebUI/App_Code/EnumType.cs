﻿/* EnumType Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This enum type is successor of the enumtype in the application. This is made to represent the enum types used in the application.
 * Created By           :   Aditya Kumar.
 * Created On           :   25 May 2010.
 * Modify By            :   Ashutosh Kumar.
 * Modify On            :   07 July 2010.
 */

namespace Cfi.App.Pace.WebUI
{
   

    /// <summary>
    /// This enum use for showing the success or failure message of any operation in the application.
    /// </summary>
    public enum ResultType
    {
        /// <summary>
        /// The success.
        /// </summary>
        Success = 0, // Shows when the result is success for any query or operation.
        /// <summary>
        /// The failed.
        /// </summary>
        Failed = 1, // Shows when the result is failure for any query or operation.
    }

    /// <summary>
    /// This enum use for showing the success or failure message of any operation in the application.
    /// </summary>
    public enum GroupType
    {
        /// <summary>
        /// The success.
        /// </summary>
        Internal = 0, // Shows when the result is success for any query or operation.
        /// <summary>
        /// The failed.
        /// </summary>
        External = 1, // Shows when the result is failure for any query or operation.
    }
    /// <summary>
    /// This enum use for Payment Status.
    /// </summary>
    public enum BillStatus
    {
        /// <summary>
        /// The success.
        /// </summary>
        UnPaid = 0, // Shows when the result is success for any query or operation.
        /// <summary>
        /// The failed.
        /// </summary>
        Paid = 1, // Shows when the result is failure for any query or operation.
    }
    /// <summary>
    /// This enum use for Bill Type.
    /// </summary>
    public enum BillType
    {
        /// <summary>
        /// The success.
        /// </summary>
        Estimated = 0, // Shows when the result is success for any query or operation.
        /// <summary>
        /// The failed.
        /// </summary>
        Actual = 1, // Shows when the result is failure for any query or operation.
    }

    /// <summary>
    /// This enum use for set the DataOperation enum.
    /// </summary>
    public enum DataOperation
    {
        /// <summary>
        /// The create.
        /// </summary>
        Create = 1, // this is used for Create Record.
        /// <summary>
        /// The update.
        /// </summary>
        Update = 2, // this is used for Update Record.
        /// <summary>
        /// The delete.
        /// </summary>
        Delete = 3, // this is used for Delete.
        /// <summary>
        /// The view.
        /// </summary>
        View = 4, // this is used for Read.
    } // End of Enum


    /// <summary>
    /// Enum describing anything is active or not.
    /// </summary>
    public enum Active
    {
        /// <summary>
        /// The yes.
        /// </summary>
        Yes = 1,

        /// <summary>
        /// The no.
        /// </summary>
        No = 0
    }
    /// <summary>
    /// Enum describing anything is valid or not.
    /// </summary>
    public enum Validate
    {
        /// <summary>
        /// The yes.
        /// </summary>
        Valid = 1,

        /// <summary>
        /// The no.
        /// </summary>
        Invalid = 0
    }


    /// <summary>
    /// Enum for the Airway bill type.
    /// </summary>
    public enum AWBType
    {
        /// <summary>
        /// The electronic.
        /// </summary>
        Electronic = 0,

        /// <summary>
        /// The manual.
        /// </summary>
        Manual = 1
    }
    /// <summary>
    /// Enum for the Incentive type.
    /// </summary>
    public enum IncentiveType
    {
        /// <summary>
        /// The electronic.
        /// </summary>
        Fixed = 0,

        /// <summary>
        /// The manual.
        /// </summary>
        Percentage_of_CM1 = 1
    }

    /// <summary>
    /// Enum for the status of the stock.
    /// </summary>
    public enum StockStatus
    {
        /// <summary>
        /// The created.
        /// </summary>
        Created = 0,

        /// <summary>
        /// The office.
        /// </summary>
        Office = 1,

        /// <summary>
        /// The agent branch.
        /// </summary>
        AgentBranch = 2,

        /// <summary>
        /// The booked.
        /// </summary>
        Booked = 3,

        /// <summary>
        /// The handed over.
        /// </summary>
        HandedOver = 4,

        /// <summary>
        /// The manifest.
        /// </summary>
        Manifest = 5,

        /// <summary>
        /// The delivered.
        /// </summary>
        Delivered = 6,

        /// <summary>
        /// The void.
        /// </summary>
        Void = 7,

        /// <summary>
        /// The blacklist.
        /// </summary>
        Blacklist = 8
    }

   

    /// <summary>
    /// Enum for the freight type in case of booking and elsewhere. In database it is defined as IsPrepaid mostly.
    /// </summary>
    public enum FreightType
    {
        /// <summary>
        /// The collect.
        /// </summary>
        Collect = 0,

        /// <summary>
        /// The prepaid.
        /// </summary>
        Prepaid = 1
    }

    /// <summary>
    /// The payment type.
    /// </summary>
    public enum PaymentType
    {
        /// <summary>
        /// The cash.
        /// </summary>
        Cash = 0,

        /// <summary>
        /// The cheque.
        /// </summary>
        Cheque = 1,

        /// <summary>
        /// Bank Transfer Method.
        /// </summary>
        BankTransfer = 2,

        /// <summary>
        /// Others method.
        /// </summary>
        Others = 3
    }

    /// <summary>
    /// The Target type.
    /// </summary>
    public enum TargetType
    {
        /// <summary>
        /// The cash.
        /// </summary>
        Annual = 0,

        /// <summary>
        /// The cheque.
        /// </summary>
        Half_Yearly = 1,

        /// <summary>
        /// Bank Transfer Method.
        /// </summary>
        Quartely = 2,

        /// <summary>
        /// Others method.
        /// </summary>
       

        Monthly=3,
        Special = 4
    }


    /// <summary>
    /// Enum return True/False
    /// </summary>
    public enum BoolType
    {
        /// <summary>
        /// The true.
        /// </summary>
        True = 1,

        /// <summary>
        /// The false.
        /// </summary>
        False = 0
    }

    

    /// <summary>
    /// Enum for the Location Type in WareHouse
    /// </summary>
    public enum LocationType
    {
        /// <summary>
        /// The export.
        /// </summary>
        Export = 0,

        /// <summary>
        /// The import.
        /// </summary>
        Import = 1,

        /// <summary>
        /// The transhipment.
        /// </summary>
        Transhipment = 3
    }

    /// <summary>
    /// This enum use for set the Value Unit in Charge Head.
    /// </summary>
    public enum Units
    {
        /// <summary>
        /// The kg.
        /// </summary>
        Kg = 1,

        /// <summary>
        /// The piece.
        /// </summary>
        Piece = 2,

        /// <summary>
        /// The awb.
        /// </summary>lo
        AWB = 3,

        /// <summary>
        /// The flight.
        /// </summary>
        Flight = 4
    } // End of Enum

    /// <summary>
    /// Enum to bind Dashboard Report Type
    /// </summary>
    public enum ShowReportFor
    {
        /// <summary>
        /// The country.
        /// </summary>
        Country,

        /// <summary>
        /// The office.
        /// </summary>
        Office,

        /// <summary>
        /// The origin.
        /// </summary>
        Origin,

        /// <summary>
        /// The agent.
        /// </summary>
        Agent,

        /// <summary>
        /// The sector.
        /// </summary>
        Sector,

        /// <summary>
        /// The destination.
        /// </summary>
        Destination,

        /// <summary>
        /// The uld.
        /// </summary>
        Uld,

        /// <summary>
        /// The none.
        /// </summary>
        None
    }

    /// <summary>
    /// Enum for Login Type 
    /// </summary>
    public enum LoginType
    {
        /// <summary>
        /// The admin.
        /// </summary>
        Admin = 0,

        /// <summary>
        /// The office.
        /// </summary>
        Office = 1,

        /// <summary>
        /// The agent.
        /// </summary>
        Agent = 2,

        /// <summary>
        /// The CTO.
        /// </summary>
        CTO = 3
    }

  /// <summary>
  /// Enum for Campaign Status
  /// </summary>
    public enum CampaignStatus
    {
        Aborted = 0,
        Planned = 1,
        In_Process = 2,
        Completed = 3
    }


    /// <summary>
    /// Enum for HR Search Information
    /// </summary>
    public enum HRCriteria
    {
        Company_Wise =0,
        Branch_Wise = 1,
        Sales_Person_Wise = 2 
    }

    /// <summary>
    /// Enum for HR Period
    /// </summary>
    public enum HRPeriod
    {
        Half_Yearly = 0,
        Quaterly = 1,
        Monthly = 2
    }

    /// <summary>
    /// Enum for find Value of Period Half Yearly
    /// </summary>
    public enum HRPeriodHalfYearly
    {
        First = 0,
        Second = 1
    }

    /// <summary>
    /// Enum for find Value of Period Quaterly
    /// </summary>
    public enum HRPeriodQuaterly
    {
        First = 0,
        Second = 1,
        Third = 2,
        Forth = 3
    }


    /// <summary>
    /// Enum for find Value of Period Monthly
    /// </summary>
    public enum MonthName
    {
        January = 0,
        February = 1,
        March = 2,
        April = 3,
        May = 4,
        June = 5,
        July = 6,
        August = 7,
        September = 8,
        October = 9,
        November = 10,
        December = 11

    }
    
    /// <summary>
    /// For Full week day name.
    /// </summary>
    public enum WeekDays
    {

        Sunday = 0,
        Monday = 1,
        Tuesday = 2,
        Wednesday = 3,
        Thrusday = 4,
        Friday = 5,
        Saturday = 6
    }
    /// <summary>
    /// For CRM Case source.
    /// </summary>
    public enum CaseSource
    {
        Phone = 1,
        Email = 2,
        Fax = 3
    }
    /// <summary>
    /// For CRM Case Status
    /// </summary>
    public enum CaseStatus
    {

        New = 1,
        OnHold = 2
    }
    /// <summary>
    /// For CRM case Type
    /// </summary>
    public enum CaseType
    {
        Problem = 1,
        FeatureRequest = 2,
        Other = 3
    }
    /// <summary>
    /// For CRM Case Priority
    /// </summary>
    public enum CasePriority
    {
        High = 1,
        Medium = 2,
        Low = 3
    }
    /// <summary>
    /// For Email Marketing email send type.
    /// </summary>
    public enum ScheduleAlertType
    {
        EMail = 0,
        PopUp = 1
    }
    /// <summary>
    /// Used for CRM email marketing schedule repeat type.
    /// </summary>
    public enum ScheduleRepeat
    {
       Daily=0, 
       Weekly=1,
       Monthly=2,
       Yearly=3
    }
}