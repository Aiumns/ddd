﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using Cfi.SoftwareFactory.BaseBusiness;

namespace Cfi.App.Pace.WebUI
{
    /// <summary>
    /// Summary description for CfiTemplate
    /// </summary>
    [Serializable]
    public class CfiTemplate : ITemplate, INamingContainer
    {
        #region GridViewDataControlFieldType enum
        /// <summary>
        /// Enum that contains the common type of template that we already have in our application. Rest can be added on demand.
        /// </summary>
        public enum GridViewDataControlFieldType
        {
            View,
            Update,
            Delete,
            Print,
            Label,
            Handover,
            CCA,
            Receipt,
            Plan
        }
        #endregion

        #region HyperlinkTargetType enum
        /// <summary>
        /// Enum that specifies the target type of the hyperlink that it will be opened in. Blank means in new window. Self means in the same window.
        /// </summary>
        public enum HyperlinkTargetType
        {
            Blank,
            Self
        }
        #endregion

        /// <summary>
        /// Get or set the type of the column of enum typeof(GridViewDataControlFieldType).
        /// </summary>
        private GridViewDataControlFieldType _columnType;
        public GridViewDataControlFieldType ColumnType
        {
            get
            {
                return _columnType;
            }
            set
            {
                _columnType = value;
            }
        }

        /// <summary>
        /// Get or set the type of the target of enum typeof(HyperlinkTargetType).
        /// </summary>
        private HyperlinkTargetType _targetType;
        public HyperlinkTargetType TargetType
        {
            get
            {
                return _targetType;
            }
            set
            {
                _targetType = value;
            }
        }

        /// <summary>
        /// Get or set the name of the primary key column, against which each row will be uniquely identified.
        /// </summary>
        private string[,] _primaryKeyColumnWithHideAttribute;
        public string[,] PrimaryKeyColumnWithHideAttribute
        {
            get
            {
                return _primaryKeyColumnWithHideAttribute;
            }
            set
            {
                _primaryKeyColumnWithHideAttribute = value;
            }
        }

        /// <summary>
        /// Get or set the hyper link that will be opened. Leave if not required.
        /// </summary>
        private string _hyperlink;
        public string Hyperlink
        {
            get
            {
                return _hyperlink;
            }
            set
            {
                _hyperlink = value;
            }
        }

        /// <summary>
        /// Get or set the UIMode New, View, Update or Delete.
        /// </summary>
        private UIMode _mode;
        public UIMode Mode
        {
            get
            {
                return _mode;
            }
            set
            {
                _mode = value;
            }
        }

        /// <summary>
        /// Get or set the tooltip on the webcontrol in the template.
        /// </summary>
        private string _tooltip;
        public string Tooltip
        {
            get
            {
                return _tooltip;
            }
            set
            {
                _tooltip = value;
            }
        }
        /// <summary>
        /// Get or set the text that needs to be displayed on the webcontrol in the template.
        /// </summary>
        private string _text;
        public string Text
        {
            get
            {
                return _text;
            }
            set
            {
                _text = value;
            }
        }

        /// <summary>
        /// Get or set the css class of the webcontrol in the template.
        /// </summary>
        private string _cssClass;
        public string CssClass
        {
            get
            {
                return _cssClass;
            }
            set
            {
                _cssClass = value;
            }
        }

        public void InstantiateIn(Control container) { }
    }
}