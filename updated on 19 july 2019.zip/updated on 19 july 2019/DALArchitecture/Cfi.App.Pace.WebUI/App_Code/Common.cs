﻿/* BasePage Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This class is used to make common functions for the application.
 * Created By           :   Aditya Kumar.
 * Created On           :   29 March 2010.
*/

#region Using Region
using System;
using System.Collections.Generic;
using System.Data;

using System.Security.Cryptography;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Configuration;
using Cfi.SoftwareFactory.Common;
using System.Xml;
#endregion

namespace Cfi.App.Pace.WebUI
{
    /// <summary>
    /// Summary description for Common
    /// </summary>
    public class Common : IDisposable
    {
        public Common() { }
        /// <summary>
        /// Method used for sending the mail.
        /// </summary>
        /// <param name="mailTo">The recepent's mail id.</param>
        /// <param name="body">The body of the mail.</param>
        public void SendMail(string receiverMail, string subject, string body)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(new MailAddress(receiverMail));
            mail.From = new MailAddress(ConfigurationManager.AppSettings["MailuserName"], "CRM", Encoding.UTF8);
            mail.Subject = subject;
            mail.SubjectEncoding = Encoding.UTF8;
            mail.BodyEncoding = Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;

            mail.Body = body;
            mail.IsBodyHtml = true;
            SmtpClient Client = new SmtpClient(ConfigurationManager.AppSettings["MailServer"], 25);
            Client.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["MailuserName"], ConfigurationManager.AppSettings["Mailpassword"]);
            try
            {
                Client.Send(mail);
            }
            catch { }
        }

        #region IDisposable Members

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
