﻿using System;
using System.Collections;
using System.Data;
using System.Web.UI;
using System.Web;
using System.Web.UI.WebControls;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.WebControls;
using Cfi.SoftwareFactory.Common;
using Cfi.App.CRM.Business;



namespace Cfi.App.Pace.WebUI
{
    #region PageObjectAccess Class Description

    /*
    *****************************************************************************
	Class Name:	      PageObjectAccess      
	Purpose:		  This class implements the functionality of page object acess.
	Company:		  CargoFlash Infotech
	Author:			  Vipin kumar
	Created On:		  2 Dec 2009
	Approved By:      
	Approved On:      
    *****************************************************************************
	*/

    #endregion

    public class PageObjectAccess : BasePage
    {

        /// <summary>
        /// Method to set the  page object access rights by hide or update the appropriate object.
        /// </summary>
        /// 

        public void SetPageObjectAcessRight()
        {
            string requestPath = HttpContext.Current.Request.Url.AbsolutePath;
            string extension = System.IO.Path.GetExtension(requestPath);
            string pagename = System.IO.Path.GetFileNameWithoutExtension(requestPath);
            bool isAspx = extension.Equals(".aspx");

            Page currentPage = (Page)HttpContext.Current.Handler;
            using (Cfi.App.CRM.Business.Login login = new Cfi.App.CRM.Business.Login())
            {
                int currentPageSNo =
                int.Parse(
                    (new ApplicationPage()).GetList("Page", "SNo",
                                                    "HyperLink='" + HttpContext.Current.Request.Url.PathAndQuery.ToLower().Replace(HttpContext.Current.Request.ApplicationPath.ToLower()+"/", "") +
                                                    "'").Rows[0]["SNo"].ToString());

                //  Get DataTable to access the  page object details

                UserLogin userLogin = (UserLogin)Session["LoginDetails"];
                DataTable dtPageObjectDetails = login.GetPageObjectAccessDetail(userLogin.SNo.ToString(), currentPageSNo);

                //get DataTable to access the  page  details
                DataTable dtLoginPageDetails = login.GetLoginPageAccessDetail(userLogin.SNo.ToString(), currentPageSNo);

                if ((dtLoginPageDetails != null && dtLoginPageDetails.Rows.Count > 0) && (dtPageObjectDetails != null && dtPageObjectDetails.Rows.Count > 0))
                {
                    //get datarow for page access Details
                    DataRow dr = dtLoginPageDetails.Rows[0];

                    bool canView = (bool)dr["CanView"];
                    bool canEdit = (bool)dr["CanUpDate"];
                    bool canDelete = (bool)dr["CanDelete"];
                    bool canInsert = (bool)dr["CanInsert"];

                    //get datarow for page object access Details
                    DataRow drpageObject = dtPageObjectDetails.Rows[0];

                    bool canViewobj = (bool)drpageObject["CanView"];
                    bool canEditobj = (bool)drpageObject["CanUpDate"];

                    UserControl userControlNew = null;
                    UserControl userControlView = null;
                    UserControl userControlEdit = null;
                    if (isAspx)
                    {
                        // Find userControlNew for Insert access
                        if (canInsert)
                        {
                            string controlNew = "uc" + pagename + "New";
                            userControlNew = (UserControl)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(currentPage, controlNew);
                        }

                        // Find userControlView for View access
                        if (canView)
                        {
                            string controlView = "uc" + pagename + "View";
                            userControlView = (UserControl)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(currentPage, controlView);
                        }

                        // Find userControlEdit for Update access
                        if (canEdit)
                        {
                            string controlEdit = "uc" + pagename + "Update";
                            userControlEdit = (UserControl)Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(currentPage, controlEdit);
                        }

                        WebControl webControlNew = null;
                        WebControl webControlView = null;
                        WebControl webControlEdit = null;

                        for (int i = 0; i < dtPageObjectDetails.Rows.Count; i++)
                        {
                            if (userControlNew != null)
                            {
                                // Find webControl from userControlNew
                                webControlNew =
                                   (WebControl)
                                   Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(userControlNew,
                                                                  dtPageObjectDetails.Rows[i]["ObjectName"].ToString().Trim());

                            }

                            // Find webControl from userControlView
                            if (userControlView != null)
                            {
                                webControlView =
                                   (WebControl)
                                   Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(userControlView,
                                                                  dtPageObjectDetails.Rows[i]["ObjectName"].ToString().Trim());
                            }

                            // Find webControl from userControlEdit
                            if (userControlEdit != null)
                            {
                                webControlEdit =
                                    (WebControl)
                                    Cfi.SoftwareFactory.Common.CommonFunctions.FindControlRecursive(userControlEdit,
                                                                   dtPageObjectDetails.Rows[i]["ObjectName"].ToString().Trim());
                            }

                            //set accessbility of all webControl

                            if ((!canViewobj) && (!canEditobj))
                            {
                                if (webControlNew != null)
                                    webControlNew.Visible = false;
                                if (webControlView != null)
                                    webControlView.Visible = false;
                                if (webControlEdit != null)
                                    webControlEdit.Visible = false;
                            }
                            else if ((canViewobj) && (canEditobj))
                            {
                                if (webControlNew != null)
                                    webControlNew.Visible = true;
                                if (webControlView != null)
                                    webControlView.Visible = true;
                                if (webControlEdit != null)
                                    webControlEdit.Visible = true;
                            }
                            else if ((canViewobj) && (!canEditobj))
                            {
                                if (webControlNew != null)
                                    webControlNew.Visible = true;
                                if (webControlView != null)
                                    webControlView.Visible = true;
                                if (webControlEdit != null)
                                    webControlEdit.Visible = true;
                            }
                        }
                    }
                }

            }

        }
    }

}