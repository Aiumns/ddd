﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Data;
using System.ServiceModel.Activation;
using Cfi.App.CRM.Business;

[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class DashboardService
{
	[OperationContract]
    public List<DashboardDataMember> GetAccountsData(int compBrSno,string showReportType, DateTime startDate, DateTime endDate, int topRowCount, string ascOrdesc)
    {
        Dashboard dashboard = new Dashboard();
        DataSet dsAccount = dashboard.GetDashboardAccountData(compBrSno, showReportType,startDate, endDate, topRowCount, ascOrdesc); 
        List<DashboardDataMember> dataMemberList = new List<DashboardDataMember>();
        foreach (DataRow dr in dsAccount.Tables[0].Rows)
        {
            DashboardDataMember dashboardDataMember = new DashboardDataMember 
            {

                DependentValue = Convert.ToDecimal(dr[0]), 
              InDependentValue = (string)dr[1], 
              
            };
            dataMemberList.Add(dashboardDataMember);
        }


        return dataMemberList;
    }



	// Add more operations here and mark them with [OperationContract]
}
