﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Data;
using Cfi.App.CRM.Business;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
/// <summary>
/// Summary description for WebServiceForTargerCustomer
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class WebServiceForTargetCustomer : System.Web.Services.WebService {

    public WebServiceForTargetCustomer () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    [WebMethod]
    public DataTable getdataforTargetCustomer()
    {
       
         using (CommonBusiness commonBusiness = new CommonBusiness())
            {
                commonBusiness.PrimaryEntity = "RegistrationDet";
                commonBusiness.PrimaryKeyField = "SNo";
                DataTable dtRegistrationDet = commonBusiness.GetNew();
                return dtRegistrationDet;
            }
     
    }
     [WebMethod]
    public string SaveTargetCustomerdata(DataTable Getdt)
    {
        string message;
        using (CommonBusiness commonBusiness = new CommonBusiness())
        {
            commonBusiness.PrimaryEntity = "RegistrationDet";
            commonBusiness.PrimaryKeyField = "SNo";
            DataTable dtRegistrationDet = commonBusiness.GetNew();
            dtRegistrationDet.Rows[0]["CompanyName"] = Getdt.Rows[0]["CompanyName"];
            dtRegistrationDet.Rows[0]["Street"] = Getdt.Rows[0]["Street"];
            dtRegistrationDet.Rows[0]["Place"] = Getdt.Rows[0]["Place"];
            dtRegistrationDet.Rows[0]["State"] = Getdt.Rows[0]["State"];
            dtRegistrationDet.Rows[0]["PostCode"] = Getdt.Rows[0]["PostCode"];
            dtRegistrationDet.Rows[0]["CountryCode"] = Getdt.Rows[0]["CountryCode"];
            dtRegistrationDet.Rows[0]["City"] = Getdt.Rows[0]["City"];
            dtRegistrationDet.Rows[0]["WebSite"] = Getdt.Rows[0]["WebSite"];
            dtRegistrationDet.Rows[0]["Phone"] = Getdt.Rows[0]["Phone"];
            dtRegistrationDet.Rows[0]["MobileNo"] = Getdt.Rows[0]["MobileNo"];
            dtRegistrationDet.Rows[0]["Fax"] = Getdt.Rows[0]["Fax"];
            dtRegistrationDet.Rows[0]["Email"] = Getdt.Rows[0]["Email"];
            dtRegistrationDet.Rows[0]["ADCode"] = Getdt.Rows[0]["ADCode"];
            dtRegistrationDet.Rows[0]["IECNo"] = Getdt.Rows[0]["IECNo"];
            dtRegistrationDet.Rows[0]["BankName"] = Getdt.Rows[0]["BankName"];
            dtRegistrationDet.Rows[0]["BankAccNo"] = Getdt.Rows[0]["BankAccNo"];
            dtRegistrationDet.Rows[0]["BankAdress"] = Getdt.Rows[0]["BankAdress"];
            dtRegistrationDet.Rows[0]["PANNo"] = Getdt.Rows[0]["PANNo"];
            dtRegistrationDet.Rows[0]["Currency"] = Getdt.Rows[0]["Currency"];
            dtRegistrationDet.Rows[0]["IATANo"] = Getdt.Rows[0]["IATANo"];
            dtRegistrationDet.Rows[0]["CompBrSNo"] = Getdt.Rows[0]["CompBrSNo"];
            dtRegistrationDet.Rows[0]["EnteredDate"] = Getdt.Rows[0]["EnteredDate"];
            if (dtRegistrationDet.Columns.Contains("SNo"))
                dtRegistrationDet.Columns.Remove("SNo");
            commonBusiness.DoCreate(dtRegistrationDet);
            if (commonBusiness.ErrorNumber > 0)
            {
                //ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                message = "Data could not be saved.";

            }
            else
            {

                message = "Record Saved Successfully";
            }
            return message;

        }
    }

}
