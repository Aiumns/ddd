﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
/// <summary>
/// Summary description for DashboardDataMember
/// </summary>
[DataContract(Namespace = "http://www.finance.com/StockQuote")]
public class DashboardDataMember
{
   

    [DataMember]
    public int CustomerCount { get; set; }

    [DataMember]
    public string CustomerType { get; set; }

    [DataMember]
    public Decimal DependentValue { get; set; }

    [DataMember]
    public string InDependentValue { get; set; }

    [DataMember]
    public string AscDesc { get; set; }

    [DataMember]
    public string MonthName { get; set; }

    [DataMember]
    public string YearName { get; set; }



}