﻿/* BasePage Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   Base class inherting the page class. So, that all the page related things can be done here, like cheking of the access and the loading of the javascript                            .
 * Created By           :  
 * Created On           :  
*/

#region Using Region
using System;
using System.Collections;
using System.Configuration;
using System.Globalization;
using System.Reflection;
using System.Threading;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
#endregion



/// <summary>
/// Base class inherting the page class. So, that all the page related things can be done here, like cheking of the access and the loading of the javascript.
/// </summary>
public class BasePage : Page
{
    protected override void OnLoad(EventArgs e)
    {
        if(Session["LoginDetails"] == null)
        {
            // Changed to redirect to the login page on session expire, not in the current iframe but on the parent page.
            Response.Redirect(ResolveClientUrl("~") + "Login.aspx?fp=i&t=l");
        }
        if(!IsPostBack)
        {
            try
            {
                using(LoginPageTrans loginPageTrans = new LoginPageTrans())
                {
                    int currentPageSNo = 0;
                    if(Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower(), string.Empty).IndexOf("home") < 0)
                    {
                        currentPageSNo =
                            int.Parse(
                                (new ApplicationPage()).GetList("Page", "SNo", "HyperLink='" + Request.FilePath.ToLower().Replace(Request.ApplicationPath.ToLower(), string.Empty) + "'").Rows[0]["SNo"].ToString());

                        if(loginPageTrans.GetRecordCount("LoginPageTrans", "SNo", "LoginSNo=" + ((UserLogin)Session["LoginDetails"]).SNo + " AND PageSNo=" + currentPageSNo) < 1)
                            Response.Redirect(ResolveClientUrl("~") + "Unauthorised.aspx");
                    }

                }
            }
            catch(Exception ex)
            {

            }
        }
        LoadJavascriptAndCss();
        /// TODO: Implement this functionality, till now it is giving the error of there is no row at position 0. Will see later. Commented By: Sudhir Yadav.
        //else
        //    (new PageObjectAccess()).SetPageObjectAcessRight();
        //Check the page object permission if exits...

        base.OnLoad(e);
    }

    /// <summary>
    /// Method to load the javascipt and the css files per page depending open the page being loaded.
    /// </summary>
    private void LoadJavascriptAndCss()
    {

        InitializePage ip = new InitializePage();
        // Adding the css...
        try
        {
            IEnumerator ie = ip.GetStyleSheetMasterPageReference().GetEnumerator();
            while(ie.MoveNext())
            {
                HtmlLink cssHtmlLink = new HtmlLink();
                cssHtmlLink.Attributes["type"] = "text/css";
                cssHtmlLink.Attributes["rel"] = "stylesheet";
                cssHtmlLink.Href = ie.Current.ToString();
                Page.Header.Controls.Add(cssHtmlLink);
            }
        }
        catch
        {
        }

        // Adding the javascript...
        try
        {
            IEnumerator ie = ip.GetJavaScriptMasterPageReference().GetEnumerator();
            while(ie.MoveNext())
            {
                HtmlGenericControl jsHtmlGenericControl = new HtmlGenericControl("script");
                jsHtmlGenericControl.Attributes["type"] = "text/javascript";
                jsHtmlGenericControl.Attributes["src"] = ie.Current.ToString();
                Page.Header.Controls.Add(jsHtmlGenericControl);
            }
        }
        catch
        {
        }

    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }

    protected override void InitializeCulture()
    {
        if(Session["CurrentCulture"] != null)
        {
            string currentCulture = Session["CurrentCulture"].ToString();

            // Retrieve culture information from session
            string culture = Convert.ToString(Session["CurrentCulture"]);

            // Check whether a culture is stored in the session
            Culture = !string.IsNullOrEmpty(culture) ? culture : "en-US";

            // Set culture to current thread
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(culture);
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture);

            base.InitializeCulture();
        }

        base.InitializeCulture();
    }
}
