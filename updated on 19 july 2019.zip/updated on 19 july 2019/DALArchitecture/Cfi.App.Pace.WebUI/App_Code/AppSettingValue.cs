﻿#region AppSettingValue Class Description
/*
    *****************************************************************************
	Class Name  : AppSettingValue.      
	Purpose     : This class implements the functionality related to AppSetting and AppValue table.
	Company     : CargoFlash Infotech.
	Author      : Chandra Prakash.
	Created On  : 21 Jan, 2010.
    Update by   : Dilip Kumar.
    Update On   : 15 Mar 2010.
    Description : Correct The ErrorMessage.
    Update By   : Dilip Kumar.
    Update On   : 1 Apr 2010.
    Description : Change error message.
	Approved By:      
	Approved On:      
    *****************************************************************************
	*/
#endregion

using System;
using System.Data;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;

namespace Cfi.App.Pace.WebUI
{

    public class AppSettingValue : BaseBusinessSecureObject
    {
        private string errorDescription = string.Empty;

        public AppSettingValue() { InitializeEntity(); }

        public void InitializeEntity()
        {
            PrimaryEntity = "AppSettingValue";
            PrimaryKeyField = "SNo";
            PrimaryKeyValue = "0";
            UpdateFieldToExclude = "SNo";
            ConnectionString = SoftwareFactory.Data.ConnectionString.WebConfigConnectionString;
            NameSpacePrefix = "AppSettingValue";
            DateFormat = "yyyy-MM-dd HH:mm:ss";
            WhereConditionField = "SNo";
        }

        /// <summary>
        /// Method is used to update the LoggedIn status of User
        /// </summary>
        /// <param name="LoginSNo">SNo of Current User</param>
        /// <param name="EntityName">Pass the Entity Name which value has to be get from AppSetting</param>
        public DataTable GetAppSettingValues(int LoginSNo, string EntityName)
        {
            DataTable dt = null;
            try
            {
                SqlParameter[] sqlParameters = new SqlParameter[2];
                SqlParameter param1 = new SqlParameter("@LoginSNo", LoginSNo);
                SqlParameter param2 = new SqlParameter("@EntityName", EntityName);
                sqlParameters[0] = param1;
                sqlParameters[1] = param2;

                DataSet ds = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "AppSettingValues", sqlParameters);
                dt = ds.Tables[0];
                return dt;
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return dt;
            }
        }


        /// <summary>
        /// Method is used to insert the AppSettingValues for New User
        /// </summary>
        /// <param name="LoginSNo">SNo of Current User</param>
        /// <param name="LoginNewSNo">LoginSNo of New User </param>
        public void InsertAppValueList(int LoginSNo, int LoginNewSNo)
        {
            try
            {
                SqlParameter[] sqlParameters = new SqlParameter[2];
                SqlParameter param1 = new SqlParameter("@LoginSNo", LoginSNo);
                SqlParameter param2 = new SqlParameter("@LoginNewSNo", LoginNewSNo);
                sqlParameters[0] = param1;
                sqlParameters[1] = param2;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "InsertAppValueList", sqlParameters);
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
            }
        }


        /// <summary>
        /// Method is used to update a OfficeAirlineTrans.
        /// When error occures check OfficeAirlineTrans.ErrorNo and OfficeAirlineTrans.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing updated values</param>
        /// <returns >0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {
            
            try
            {
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get update DML string to be used for update statement by Sys_ProcessDocument API
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        dt.WhereConditionField = WhereConditionField;
                        string[] updateDML = dt.TableToUpdateWhereDML();

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        //Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML[0], updateDML[1], "U");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                WhereCondition = null;
                errorDescription = null;
            }
        }
    }
}