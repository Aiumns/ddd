﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

public class SaveFile
{
    public byte[] ComInvoice { set; get; }
    public byte[] ComPackList { set; get; }
    public byte[] Consolmanifest { set; get; }

    public string SaveFileToDB()
    {
        using (SqlConnection conn = new SqlConnection("Data Source=APPSERVER\\SQLEXPRESS;" +
             "Initial Catalog=pace;Integrated Security=True;User ID=pp3new;Password=pp3robust;Pooling=False"))
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "insertWareHouse";
            cmd.Connection = conn;

            cmd.Parameters.AddWithValue("@ComInvoice", ComInvoice);
            cmd.Parameters.AddWithValue("@ComPackList", ComPackList);
            cmd.Parameters.AddWithValue("@Consolmanifest", Consolmanifest);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                return "File stored Successfully!!!";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                conn.Close();
                cmd.Dispose();
                conn.Dispose();
            }
        }
    }
}






//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

///// <summary>
///// Summary description for WMS
///// </summary>
//public class WMS
//{
//    public WMS()
//    {
//        //
//        // TODO: Add constructor logic here
//        //
//    }
//}