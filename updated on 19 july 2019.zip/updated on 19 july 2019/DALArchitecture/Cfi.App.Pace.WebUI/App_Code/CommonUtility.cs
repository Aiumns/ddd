using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Cfi.App.Pace.Common;
/// <summary>
/// Summary description for CommonUtility
/// </summary>
public class CommonUtility
{
    SqlDataAdapter da;
    DataSet ds;
    SqlConnection con = new SqlConnection(Cfi.App.Pace.Common.PaceCommon.ConnectionString);
    SqlCommand cmd;
    public DataSet getDS(string strQ)
    {
        //str could be query or procedure with parameter
        da = new SqlDataAdapter(strQ,Cfi.App.Pace.Common.PaceCommon.ConnectionString );
        ds = new DataSet();
        da.Fill(ds);
        return ds;
    }
    public String ExecuteScalar(string strQ)
    {
        string str = string.Empty;
        try
        {            
            cmd = new SqlCommand(strQ, con);
            con.Open();
            str = cmd.ExecuteScalar().ToString();
            return str;
        }
        catch (Exception ex)
        {
            return ex.ToString();
        }
        finally
        {
            con.Close();
        }
    }
    public CommonUtility()
    {
    }


}
