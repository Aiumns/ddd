﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class AppControls_Common_CfiRichTextEditor : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fckEditor.ToolbarSet = Funtionality.ToString();
    }

    public string Text
    {
        get
        {
            return fckEditor.Value;
        }
        set
        {
            fckEditor.Value = value;
        }
    }

    public System.Web.UI.WebControls.Unit Width
    {
        get
        {
            return fckEditor.Width;
        }
        set
        {
            fckEditor.Width = value;
        }
    }
    public System.Web.UI.WebControls.Unit Height
    {
        get
        {
            return fckEditor.Height;
        }
        set
        {
            fckEditor.Height = value;
        }
    }

    public Editor Funtionality
    {
        get
        {
            return (Editor)ViewState["Editor"];
        }
        set
        {
            ViewState["Editor"] = value;
        }
    }

    public enum Editor
    {
        NoControls,
        Minimal,
        Regular,
        Complete
    }
}