﻿/*
   *****************************************************************************
   Control Name     : Permission.
   Purpose          : This control provides functionality to Insert/View/Update/Delete the Permission Information for LoginType.					
   Company          : CargoFlash Infotech.
   Approved By:      
   Approved On:      
   *****************************************************************************
   */

// Using Namespace
using System;
using System.Configuration;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.WebControls;
using System.Web.UI.HtmlControls;

using LoginType = Cfi.App.CRM.Business.LoginType;





public partial class AppControls_Manage_Permission : System.Web.UI.UserControl
{
    private int i = 2;
    public int SNo1 = 1;
    public int SNo2 = 2;
    public string strPageTable = "";
    public string strPermissionTable = "";
    public string strUIModeType = "";
    string MainItemName = string.Empty;
    string SubItemName = string.Empty;
    UIMode uiMode;
    string primaryKeyValue = ""; 
    string permissionFor="";

  
    /// <summary>
    /// User control which is used to display the message on this page.
    /// </summary>
   // private AppControls_Messages ucMessage;

    /// <summary>
    /// Get or Set Permission table
    /// </summary>
    public DataTable PermissionTable { get { return (DataTable)ViewState["dtPermission"]; } set { ViewState["dtPermission"] = value; } }
    DataTable dtPermissionTable { get { return (DataTable)ViewState["dtPermissionTable"]; } set { ViewState["dtPermissionTable"] = value; } }
    /// <summary>
    /// Get or Set Page table
    /// </summary>
    public DataTable PageTable { get { return (DataTable)ViewState["dtPage"]; } set { ViewState["dtPage"] = value; } }

    /// <summary>
    /// Get or Set Page Empty table
    /// </summary>
    public DataTable NewPageTable { get { return (DataTable)ViewState["dtNewPage"]; } set { ViewState["dtNewPage"] = value; } }

    /// <summary>
    /// Delegate to handle the Save/Update/Delete action button.
    /// </summary>
    /// <param name="sender">The action button which is delegating the method.</param>
    /// <param name="actionAndCancelButtonEventArgs">The arguments returned when the event is raised.</param>
    public delegate void ActionClickHandler(object sender, ActionEventArgs actionAndCancelButtonEventArgs);

    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
    public event ActionClickHandler ActionClick;


    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">The sender of the page load event.</param>
    /// <param name="e">The arguments of the page load event.</param>
  protected void Page_Load(object sender, EventArgs e) {


      if (!IsPostBack)
      {

         // BindPermission();
          if (Session["TempVal"] == null)
          {
              //ClearTextbox();
              //btnSubmit.Text = "Submit";
          }
          else
          {
              if (Request.QueryString.Count > 1)
              {
                  //ClearTextbox();
                  string[] str = Session["TempVal"].ToString().Split('#');
                  hdnUIModeType.Value = uiMode.ToString();
                 hdnPermissionFor.Value = permissionFor;
                      if (hdnUIModeType.Value != "New")
                        hdnPrimaryKeyValue.Value = primaryKeyValue;

                     gridPage.RowCreated += gridPage_RowCreated;
                     cmdAction.Visible = true;
                  if (str[1] == "E")
                  {
                      hdnPrimaryKeyValue.Value = (Request.QueryString[0].ToString() == "" ? "0" : Request.QueryString[0].ToString());
                      BindPermission();
                     //pnlPermissionInformation.GroupingText = (hdnPermissionFor.Value == "Login" ? "Login" : "Login Type") + " Information";
                      pnlPermissionInformation.GroupingText = "";
                     Cfi.SoftwareFactory.Common.CommonFunctions.SetRequiredFieldsSkin(null, pnlPermission, "imtb");
                      strUIModeType = "Edit";
                      cmdAction.Text = "Update";
                      lblTitle.Text = "Update " + this.GetLoginName(this.hdnPrimaryKeyValue.Value) + " Permission";
                        
                      cmdAction.Text = "Update";
                      if (Request.QueryString["p"] == "lp")
                      {
                          hdnvalue.Value = "lp";
                      }
                      else
                      {
                          hdnvalue.Value = " ";
                      }
                  }
                  if (str[1] == "V")
                  {
                      hdnPrimaryKeyValue.Value = (Request.QueryString[0].ToString() == "" ? "0" : Request.QueryString[0].ToString());

                      BindPermission();
                    pnlPermissionInformation.GroupingText = (hdnPermissionFor.Value == "Login" ? "Login" : "Login Type") + " Information";
                    
                      Cfi.SoftwareFactory.Common.CommonFunctions.ChangeControlsToLabel(null, pnlPermission);
                     
                      strUIModeType = "View";
                      cmdAction.Visible = false; cmdCancel.Text = "Back"; cmdCancel.CssClass = "buttonRegular";
                      lblTitle.Text = "View " + this.GetLoginName(this.hdnPrimaryKeyValue.Value) + " Permission";
                     
                       
                      foreach (Control c in this.Page.Controls)
                      {
                          if (c is CheckBox)
                              ((CheckBox)(c)).Enabled = false;
                      }

                      cmdAction.Text = "Back";
                  }
              }

          }
      }    
      
      
      
      
      
      ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages"); 
  
  
  
  
  }

    /// <summary>
    /// Method for Creating Form Controls and according to UIMode(like add/modify/delete/view)
    /// </summary>
    /// <param name="hdnUIModeType.Value">To set mode like New/Edit/View/Delete </param>
    /// <summary>
    /// Method for creating the form and loading the data according to the mode.
    /// </summary>
    /// <param name="hdnUIModeType.Value">To set mode like New/Edit/View/Delete for the form being generated. </param>
    //public void CreateForm(UIMode uiMode, string primaryKeyValue, string permissionFor)
    //{
    //    try
    //    {
    //        hdnUIModeType.Value = uiMode.ToString();
    //        hdnPermissionFor.Value = permissionFor;
    //        if (hdnUIModeType.Value != "New")
    //            hdnPrimaryKeyValue.Value = primaryKeyValue;

    //        gridPage.RowCreated += gridPage_RowCreated;
    //        cmdAction.Visible = true;
    //        switch (hdnUIModeType.Value)
    //        {
    //            case "View":
    //                strUIModeType = "View";
    //                cmdAction.Visible = false; cmdCancel.Text = "Back"; cmdCancel.CssClass = "buttonRegular";
    //                lblTitle.Text = "View " + this.GetLoginName(this.hdnPrimaryKeyValue.Value) + " Permission";

    //                foreach (Control c in this.Page.Controls)
    //                {
    //                    if (c is  CheckBox)
    //                        ((CheckBox)(c)).Enabled = false;
    //                }

                       
    //                break;
    //            case "Update":
    //                strUIModeType = "Edit";
    //                cmdAction.Text = "Update";
    //                lblTitle.Text = "Update " + this.GetLoginName(this.hdnPrimaryKeyValue.Value) + " Permission";
    //                break;
    //        }
    //        BindPermission();
    //        //pnlPermissionInformation.GroupingText = (hdnPermissionFor.Value == "Login" ? "Login" : "Login Type") + " Information";
    //        //if (hdnUIModeType.Value == "View")
    //        // Cfi.SoftwareFactory.Common.CommonFunctions.ChangeControlsToLabel(null, pnlPermission);
    //        //else
    //        //    Cfi.SoftwareFactory.Common.CommonFunctions.SetRequiredFieldsSkin(null, pnlPermission, "imtb");
    //    }
    //    catch (Exception ex)
    //    {
    //      ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //       ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }
    //}

    /// <summary>
    /// Method to bind the current entity.
    /// </summary>
    private void BindPermission()
    {
        try
        {
            if (hdnPermissionFor.Value == "Login")
            {
                using (LoginPageTrans loginPageTrans = new LoginPageTrans())
                {
                    loginPageTrans.RecordID = hdnPrimaryKeyValue.Value;
                    PermissionTable = loginPageTrans.GetRecord();
                }
            }
            else
            {
                using (LoginTypePageTrans loginTypePageTrans = new LoginTypePageTrans())
                {
                    loginTypePageTrans.NameSpacePrefix = "LoginTypePageTrans";
                    loginTypePageTrans.RecordID = hdnPrimaryKeyValue.Value;
                    PermissionTable = loginTypePageTrans.GetRecord();

                    dtPermissionTable = PermissionTable;

                }
            }

            DataTable dtPageMain = null;
            using (CommonBusiness commonBusiness = new CommonBusiness())
            {

                string loginTypeSNo = string.Empty;
                commonBusiness.PrimaryEntity = "Page";
                commonBusiness.NameSpacePrefix = "Page";
                DataTable dtLoginType = commonBusiness.GetList("Login", "LoginType", string.Format("SNo={0}", this.hdnPrimaryKeyValue.Value));
                if (dtLoginType != null && dtLoginType.Rows.Count > 0)
                    loginTypeSNo = dtLoginType.Rows[0][0].ToString();
                DataTable dtPageTable = commonBusiness.GetList("Page", "*", "");

                if (this.hdnPermissionFor.Value != "Login")
                {
                    this.PageTable = commonBusiness.GetList("Page", "*", string.Empty);
                    foreach (DataRow drPage in dtPageTable.Rows)
                    {
                        DataRow[] drP = this.PermissionTable.Select(string.Format("PageSNo={0}", drPage["Sno"]));
                        if (drP.Length <= 0)
                        {
                            DataRow drPermission = this.PermissionTable.NewRow();
                            drPermission["LoginTypeSno"] = int.Parse(this.hdnPrimaryKeyValue.Value);
                            drPermission["PageSNo"] = int.Parse(drPage["SNo"].ToString());
                            drPermission["CanView"] = false;
                            drPermission["CanInsert"] = false;
                            drPermission["CanUpdate"] = false;
                            drPermission["CanDelete"] = false;
                            this.PermissionTable.Rows.Add(drPermission);
                        }
                    }
                }
                else
                {
                    DataTable dtUserLogin = commonBusiness.GetList("UserGroup", "SNo", "GroupName = '" + loginTypeSNo + "'");

                    if (dtUserLogin != null && dtUserLogin.Rows.Count > 0)
                    {

                        loginTypeSNo = dtUserLogin.Rows[0]["SNo"].ToString();
                        this.PageTable = commonBusiness.GetList("vLoginPermissoinPage", "*",
                                                                string.Format("LoginTypeSNo={0}", loginTypeSNo));
                        DataRow drPageTable = null;
                        string condition = string.Empty;

                        foreach (DataRow drPage in dtPageTable.Rows)
                        {
                            //if (drPage["SNo"].ToString() == "214")
                            //{
                            //    string a = "";
                            //}
                            DataRow[] drP = this.PermissionTable.Select(string.Format("PageSNo={0}", drPage["Sno"]));
                            if (drP.Length <= 0)
                            {
                                DataRow drPermission = this.PermissionTable.NewRow();
                                drPermission["LoginSno"] = int.Parse(this.hdnPrimaryKeyValue.Value);
                                drPermission["PageSNo"] = int.Parse(drPage["SNo"].ToString());
                                drPermission["CanView"] = false;
                                drPermission["CanInsert"] = false;
                                drPermission["CanUpdate"] = false;
                                drPermission["CanDelete"] = false;
                                this.PermissionTable.Rows.Add(drPermission);
                                //condition = "SNo='" + int.Parse(drPage["SNo"].ToString()) + "'";
                                condition = "SNo is null And PageSNo='" + int.Parse(drPermission["PageSNo"].ToString()) + "'";
                                DataRow[] drGetPage = PermissionTable.Select(condition);
                                if (drGetPage != null && drGetPage[0]["SNo"].ToString() == "")
                                {
                                    drPageTable = PageTable.NewRow();
                                    drPageTable["SNo"] = drPage["SNo"];
                                    drPageTable["Name"] = drPage["Name"];
                                    drPageTable["Hyperlink"] = drPage["Hyperlink"];
                                    drPageTable["MenuSNo"] = drPage["MenuSNo"];
                                    drPageTable["DisplayOrder"] = drPage["DisplayOrder"];
                                    drPageTable["Description"] = drPage["Description"];
                                    drPageTable["IsDeleted"] = drPage["IsDeleted"];
                                    drPageTable["LoginTypeSNo"] = loginTypeSNo;

                                    DataRow[] drPermissionTablePage = PermissionTable.Select("PageSNo=" + drPage["SNo"]);

                                    if (drPermissionTablePage.Length > 0)
                                        drPageTable["CanView"] = drPermissionTablePage[0]["CanView"];
                                    PageTable.Rows.Add(drPageTable);
                                }
                            }
                            else
                            {
                                //if (drPage["SNo"].ToString() == "214")
                                //{
                                //    string a = "";
                                //}
                                string conditionNew = string.Empty;
                                conditionNew = "SNo='" + int.Parse(drPage["SNo"].ToString()) + "'";
                                DataRow[] drGetPageDetails = PageTable.Select(conditionNew);
                                if (drGetPageDetails.Length <= 0)
                                {
                                    condition = string.Empty;
                                    condition = "SNo='" + int.Parse(drPage["SNo"].ToString()) + "'";
                                    DataRow[] drGetPage = dtPageTable.Select(condition);
                                    drPageTable = PageTable.NewRow();
                                    drPageTable["SNo"] = drPage["SNo"];
                                    drPageTable["Name"] = drGetPage[0]["Name"];
                                    drPageTable["Hyperlink"] = drGetPage[0]["Hyperlink"];
                                    drPageTable["MenuSNo"] = drGetPage[0]["MenuSNo"];
                                    drPageTable["DisplayOrder"] = drGetPage[0]["DisplayOrder"];
                                    drPageTable["Description"] = drGetPage[0]["Description"];
                                    drPageTable["IsDeleted"] = drGetPage[0]["IsDeleted"];
                                    drPageTable["LoginTypeSNo"] = loginTypeSNo;
                                    drPageTable["CanView"] = 0;
                                    PageTable.Rows.Add(drPageTable);
                                }
                            }
                        }
                    }
                }

                DataRow[] drModule = PageTable.Select("MenuSno IS NULL AND HyperLink IS NULL", "DisplayOrder ASC");
                NewPageTable = commonBusiness.GetNew();
                NewPageTable.Rows.Clear();
                if (NewPageTable.Columns.Contains("HasObject"))
                    NewPageTable.Columns.Remove("HasObject");
                dtPageMain = NewPageTable.Copy();
                foreach (DataRow dr in drModule)
                    dtPageMain.ImportRow(dr);


                gridPage.DataSource = dtPageMain;
                gridPage.DataBind();
            }
        }
        catch(Exception ex)
        {
        
        }
    }

    /// <summary>
    /// Method to handle the action button that is the Save/Update/Delete etc button.
    /// </summary>
    /// <param name="sender">In this case the cancel button.</param>
    /// <param name="e">The arguments of the sender that is the action button.</param>
    protected void cmdAction_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow grow in gridPage.Rows)
        {
            Label hfSno = (Label)grow.FindControl("lblSno");
            CheckBox chkview = (CheckBox)grow.FindControl("chkView");
            CheckBox chkNew = (CheckBox)grow.FindControl("chkNew");
            CheckBox chkEdit = (CheckBox)grow.FindControl("chkEdit");
            CheckBox chkDelete = (CheckBox)grow.FindControl("chkDelete");
            CheckBox chkPrint = (CheckBox)grow.FindControl("chkPrint");
            GridView gridSubPage = (GridView)grow.FindControl("gridPageDetails");
            DataRow[] drModule = PermissionTable.Select("PageSNo=" + hfSno.Text);
            if (drModule.Length > 0)
            {
                drModule[0]["CanView"] = chkview.Checked;
                drModule[0]["CanInsert"] = chkNew.Checked;
                drModule[0]["CanUpdate"] = chkEdit.Checked;
                drModule[0]["CanDelete"] = chkDelete.Checked;
                //drModule[0]["Flag"] = "A";
            }
            PermissionTable.AcceptChanges();
            foreach (GridViewRow growSub in gridSubPage.Rows)
            {
                Label lblSno1 = (Label)growSub.FindControl("hfSno");
                chkview = (CheckBox)growSub.FindControl("chkView");
                chkNew = (CheckBox)growSub.FindControl("chkNew");
                chkEdit = (CheckBox)growSub.FindControl("chkEdit");
                chkDelete = (CheckBox)growSub.FindControl("chkDelete");
                chkPrint = (CheckBox)growSub.FindControl("chkPrint");
                GridView gridSubSubPage = (GridView)growSub.FindControl("gridPageDetails1");
                drModule = PermissionTable.Select("PageSNo=" + lblSno1.Text);
                if (drModule.Length > 0)
                {
                    drModule[0]["CanView"] = chkview.Checked;
                    drModule[0]["CanInsert"] = chkNew.Checked;
                    drModule[0]["CanUpdate"] = chkEdit.Checked;
                    drModule[0]["CanDelete"] = chkDelete.Checked;
                    //drModule[0]["Flag"] = "A";
                }
                PermissionTable.AcceptChanges();

                if (gridSubSubPage != null)
                {
                    foreach (GridViewRow growSubSub in gridSubSubPage.Rows)
                    {
                        Label lblSno2 = (Label)growSubSub.FindControl("hfSno");
                        chkview = (CheckBox)growSubSub.FindControl("chkView");
                        chkNew = (CheckBox)growSubSub.FindControl("chkNew");
                        chkEdit = (CheckBox)growSubSub.FindControl("chkEdit");
                        chkDelete = (CheckBox)growSubSub.FindControl("chkDelete");
                        chkPrint = (CheckBox)growSubSub.FindControl("chkPrint");
                        drModule = PermissionTable.Select("PageSNo=" + lblSno2.Text);
                        if (drModule.Length > 0)
                        {
                            drModule[0]["CanView"] = chkview.Checked;
                            drModule[0]["CanInsert"] = chkNew.Checked;
                            drModule[0]["CanUpdate"] = chkEdit.Checked;
                            drModule[0]["CanDelete"] = chkDelete.Checked;
                            //drModule[0]["Flag"] = "A";
                        }
                        PermissionTable.AcceptChanges();
                    }
                }
            }
        }

        if (hdnPermissionFor.Value == "Login")
        {
            using (LoginPageTrans loginPageTrans = new LoginPageTrans())
            {
                if (gridPage.Rows.Count > 0)
                {
                    loginPageTrans.RecordID = hdnPrimaryKeyValue.Value;
                    if (PermissionTable.Columns.Contains("ID"))
                        PermissionTable.Columns.Remove("ID");
                    DataTable dt = PermissionTable.Clone();
                    DataTable dtLoginPageTransCreate = PermissionTable.Clone();
                    foreach (DataRow dr in PermissionTable.Rows)
                    {
                        dt.Rows.Clear();
                        dt.ImportRow(dr);
                        int loginSno = Convert.ToInt32(PermissionTable.Rows[0]["LoginSNo"]);
                        DataTable dtLoginPageTrans = loginPageTrans.GetList("LoginPageTrans", "*", string.Format("LoginSno={0} And PageSNo={1}", loginSno, dr["PageSNo"]));
                        if (dtLoginPageTrans.Rows.Count > 0)
                            loginPageTrans.DoUpdate(dt);
                        else
                            dtLoginPageTransCreate.ImportRow(dr);
                    }
                    if (dtLoginPageTransCreate.Rows.Count > 0)
                        loginPageTrans.DoCreate(dtLoginPageTransCreate);
                    if (loginPageTrans.ErrorNumber > 0)
                    {
                        if (loginPageTrans.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                            ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", loginPageTrans.ErrorMessage.Split(':')[1]);
                        }
                        else
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                            ucMessage.Message = (string)GetLocalResourceObject(loginPageTrans.ErrorMessage.Split(':')[1]);
                        }
                        return;
                    }
                    // hdnErrMsg.Value = "Record updated Successfully!!!";
                    //  ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;

                    if (ActionClick != null)
                        ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
                    //  hdnErrMsg.Value = "Record updated Successfully!!!";
                    // ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "RecordUpdatedSuccessfully").ToString();
                    // ucMessage.PageTabContainerID = "Permission";
                }
            }
        }
        else
        {
            using (LoginTypePageTrans loginTypePageTrans = new LoginTypePageTrans())
            {
                if (gridPage.Rows.Count > 0)
                {
                    PermissionTable.Columns.Remove("ID");
                    DataTable dt = PermissionTable.Clone();
                    foreach (DataRow dr in PermissionTable.Rows)
                    {
                        dt.Rows.Clear();
                        dt.ImportRow(dr);
                        if (dr["SNo"].ToString() == "")
                        {
                            if (dt.Columns.Contains("SNo"))
                                dt.Columns.Remove("SNo");
                            loginTypePageTrans.DoCreate(dt);
                        }
                        else
                            loginTypePageTrans.DoUpdate(dt);

                        using (CommonBusiness commonBusiness = new CommonBusiness())
                        {
                            DataTable dtCommonBusiness = commonBusiness.GetList("vGetLoginType", "*", "UserGroupSNo = '" + hdnPrimaryKeyValue.Value + "' order by LoginSNo");
                            if (dtCommonBusiness != null && dtCommonBusiness.Rows.Count > 0)
                            {
                                DataTable dtLoginPageTrans = null;
                                DataRow drLoginPageTrans = null;
                                for (int i = 0; i < dtCommonBusiness.Rows.Count; i++)
                                {
                                    dtLoginPageTrans = null;
                                    using (LoginPageTrans loginPageTrans = new LoginPageTrans())
                                    {
                                        //if (dt.Rows[0]["PageSNo"].ToString() == "250" && dtCommonBusiness.Rows[i]["LoginSNo"].ToString() == "168")
                                        //{
                                        //    string a = "";
                                        //}
                                        dtLoginPageTrans = loginPageTrans.GetList("LoginPageTrans", "*", "LoginSNo='" + dtCommonBusiness.Rows[i]["LoginSNo"] + "' And PageSNo = '" + dt.Rows[0]["PageSNo"] + "'");
                                        if (dtLoginPageTrans != null && dtLoginPageTrans.Rows.Count > 0)
                                        {
                                            if (dt.Rows[0]["CanView"].ToString() == "False" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "False")
                                            {
                                                dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
                                                dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
                                                dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
                                                dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
                                            }
                                            else if (dt.Rows[0]["CanView"].ToString() == "False" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True")
                                            {
                                                DataRow[] dRow = null;
                                                dRow = dtPermissionTable.Select("PageSNo='" + dt.Rows[0]["PageSNo"].ToString() + "'");
                                                if (((dt.Rows[0]["CanView"].ToString() == "False") && (dt.Rows[0]["CanInsert"].ToString() == "False") && (dt.Rows[0]["CanUpdate"].ToString() == "False") && (dt.Rows[0]["CanDelete"].ToString() == "False")) && ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "False") && (dtLoginPageTrans.Rows[0]["CanInsert"].ToString() == "False") && (dtLoginPageTrans.Rows[0]["CanUpdate"].ToString() == "False") && (dtLoginPageTrans.Rows[0]["CanDelete"].ToString() == "False")))
                                                {
                                                    dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
                                                    dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
                                                    dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
                                                    dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
                                                }
                                                else if (((dt.Rows[0]["CanView"].ToString() == "False") && (dt.Rows[0]["CanInsert"].ToString() == "False") && (dt.Rows[0]["CanUpdate"].ToString() == "False") && (dt.Rows[0]["CanDelete"].ToString() == "False")) && ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True") || (dtLoginPageTrans.Rows[0]["CanInsert"].ToString() == "True") || (dtLoginPageTrans.Rows[0]["CanUpdate"].ToString() == "True") || (dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True")))
                                                {
                                                    //Check if current and previous logintype difference
                                                    if ((dRow[0]["CanView"] == dt.Rows[0]["CanView"]) || (dRow[0]["CanInsert"] == dt.Rows[0]["CanInsert"]) || (dRow[0]["CanUpdate"] == dt.Rows[0]["CanUpdate"]) || (dRow[0]["CanDelete"] == dt.Rows[0]["CanDelete"]))
                                                    {
                                                        dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
                                                        dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
                                                        dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
                                                        dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
                                                    }
                                                    else if ((dtLoginPageTrans.Rows[0]["CanView"].ToString() != "True") && (dt.Rows[0]["CanView"].ToString() == "False") && (dRow[0]["CanView"].ToString() == "False"))
                                                    {
                                                        dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
                                                        dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
                                                        dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
                                                        dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
                                                    }
                                                    else if ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True") && (dt.Rows[0]["CanView"].ToString() == "False" && dRow[0]["CanView"].ToString() == "False"))
                                                    {

                                                    }
                                                    else if ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True") && (dt.Rows[0]["CanView"].ToString() == "False" && dRow[0]["CanView"].ToString() == "True"))
                                                    {
                                                        dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
                                                        dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
                                                        dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
                                                        dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];

                                                    }
                                                }
                                            }
                                            else if (dt.Rows[0]["CanView"].ToString() == "True" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "False")
                                            {
                                                dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
                                                dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
                                                dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
                                                dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
                                            }

                                            else if (dt.Rows[0]["CanView"].ToString() == "True" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True")
                                            {

                                            }
                                            loginPageTrans.DoUpdate(dtLoginPageTrans);
                                            if (loginPageTrans.ErrorNumber > 0)
                                            {
                                                if (loginPageTrans.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                                                {
                                                    ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                                                    ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", loginPageTrans.ErrorMessage.Split(':')[1]);
                                                }
                                                else
                                                {
                                                    ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                                                    ucMessage.Message = (string)GetLocalResourceObject(loginPageTrans.ErrorMessage.Split(':')[1]);
                                                }
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            drLoginPageTrans = dtLoginPageTrans.NewRow();
                                            drLoginPageTrans["LoginSNo"] = dtCommonBusiness.Rows[i]["LoginSNo"];
                                            drLoginPageTrans["PageSNo"] = dt.Rows[0]["PageSNo"];
                                            drLoginPageTrans["CanView"] = dt.Rows[0]["CanView"];
                                            drLoginPageTrans["CanInsert"] = dt.Rows[0]["CanInsert"];
                                            drLoginPageTrans["CanUpdate"] = dt.Rows[0]["CanUpdate"];
                                            drLoginPageTrans["CanDelete"] = dt.Rows[0]["CanDelete"];
                                            drLoginPageTrans["IsDeleted"] = 0;
                                            dtLoginPageTrans.Rows.Add(drLoginPageTrans);

                                            loginPageTrans.DoCreate(dtLoginPageTrans);
                                        }
                                    }
                                }
                            }

                        }
                    }
                    if (loginTypePageTrans.ErrorNumber > 0)
                    {
                        if (loginTypePageTrans.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
                            ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", loginTypePageTrans.ErrorMessage.Split(':')[1]);
                        }
                        else
                        {
                            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
                            ucMessage.Message = (string)GetLocalResourceObject(loginTypePageTrans.ErrorMessage.Split(':')[1]);
                        }
                        return;
                    }
                    ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
                    if (ActionClick != null)
                        ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
                    if (Request.QueryString["l"] == "lp")
                    {
                        hdnvalue.Value = "lp";
                        hdnErrMsg.Value = "Record Updated Successfully!!!";
                        ucMessage.PageTabContainerID = "Permission";
                    }
                    else
                    {
                        hdnvalue.Value ="";
                        hdnErrMsg.Value = "Record Updated Successfully!!!";
                        ucMessage.PageTabContainerID = "Permission";
                    }
                }
            }
        }      
               
       
    }

    /// <summary>
    /// Method to update the existing current form data.
    /// </summary>
    /// <param name="e">The event argument of the button that called this method, so as to use in the action click handler delegate for ActionEventArgs event.</param>
    private void UpdateData(EventArgs e)
    {

        //foreach (GridViewRow grow in gridPage.Rows)
        //{
        //    Label hfSno = (Label)grow.FindControl("lblSno");
        //    CheckBox chkview = (CheckBox)grow.FindControl("chkView");
        //    CheckBox chkNew = (CheckBox)grow.FindControl("chkNew");
        //    CheckBox chkEdit = (CheckBox)grow.FindControl("chkEdit");
        //    CheckBox chkDelete = (CheckBox)grow.FindControl("chkDelete");
        //    CheckBox chkPrint = (CheckBox)grow.FindControl("chkPrint");
        //    GridView gridSubPage = (GridView)grow.FindControl("gridPageDetails");
        //    DataRow[] drModule = PermissionTable.Select("PageSNo=" + hfSno.Text);
        //    if (drModule.Length > 0)
        //    {
        //        drModule[0]["CanView"] = chkview.Checked;
        //        drModule[0]["CanInsert"] = chkNew.Checked;
        //        drModule[0]["CanUpdate"] = chkEdit.Checked;
        //        drModule[0]["CanDelete"] = chkDelete.Checked;
        //        //drModule[0]["Flag"] = "A";
        //    }
        //    PermissionTable.AcceptChanges();
        //    foreach (GridViewRow growSub in gridSubPage.Rows)
        //    {
        //        Label lblSno1 = (Label)growSub.FindControl("hfSno");
        //        chkview = (CheckBox)growSub.FindControl("chkView");
        //        chkNew = (CheckBox)growSub.FindControl("chkNew");
        //        chkEdit = (CheckBox)growSub.FindControl("chkEdit");
        //        chkDelete = (CheckBox)growSub.FindControl("chkDelete");
        //        chkPrint = (CheckBox)growSub.FindControl("chkPrint");
        //        GridView gridSubSubPage = (GridView)growSub.FindControl("gridPageDetails1");
        //        drModule = PermissionTable.Select("PageSNo=" + lblSno1.Text);
        //        if (drModule.Length > 0)
        //        {
        //            drModule[0]["CanView"] = chkview.Checked;
        //            drModule[0]["CanInsert"] = chkNew.Checked;
        //            drModule[0]["CanUpdate"] = chkEdit.Checked;
        //            drModule[0]["CanDelete"] = chkDelete.Checked;
        //            //drModule[0]["Flag"] = "A";
        //        }
        //        PermissionTable.AcceptChanges();

        //        if (gridSubSubPage != null)
        //        {
        //            foreach (GridViewRow growSubSub in gridSubSubPage.Rows)
        //            {
        //                Label lblSno2 = (Label)growSubSub.FindControl("hfSno");
        //                chkview = (CheckBox)growSubSub.FindControl("chkView");
        //                chkNew = (CheckBox)growSubSub.FindControl("chkNew");
        //                chkEdit = (CheckBox)growSubSub.FindControl("chkEdit");
        //                chkDelete = (CheckBox)growSubSub.FindControl("chkDelete");
        //                chkPrint = (CheckBox)growSubSub.FindControl("chkPrint");
        //                drModule = PermissionTable.Select("PageSNo=" + lblSno2.Text);
        //                if (drModule.Length > 0)
        //                {
        //                    drModule[0]["CanView"] = chkview.Checked;
        //                    drModule[0]["CanInsert"] = chkNew.Checked;
        //                    drModule[0]["CanUpdate"] = chkEdit.Checked;
        //                    drModule[0]["CanDelete"] = chkDelete.Checked;
        //                    //drModule[0]["Flag"] = "A";
        //                }
        //                PermissionTable.AcceptChanges();
        //            }
        //        }
        //    }
        //}

        //if (hdnPermissionFor.Value == "Login")
        //{
        //    using (LoginPageTrans loginPageTrans = new LoginPageTrans())
        //    {
        //        if (gridPage.Rows.Count > 0)
        //        {
        //            loginPageTrans.RecordID = hdnPrimaryKeyValue.Value;
        //            if (PermissionTable.Columns.Contains("ID"))
        //                PermissionTable.Columns.Remove("ID");
        //            DataTable dt = PermissionTable.Clone();
        //            DataTable dtLoginPageTransCreate = PermissionTable.Clone();
        //            foreach (DataRow dr in PermissionTable.Rows)
        //            {
        //                dt.Rows.Clear();
        //                dt.ImportRow(dr);
        //                int loginSno = Convert.ToInt32(PermissionTable.Rows[0]["LoginSNo"]);
        //                DataTable dtLoginPageTrans = loginPageTrans.GetList("LoginPageTrans", "*", string.Format("LoginSno={0} And PageSNo={1}", loginSno, dr["PageSNo"]));
        //                if (dtLoginPageTrans.Rows.Count > 0)
        //                    loginPageTrans.DoUpdate(dt);
        //                else
        //                    dtLoginPageTransCreate.ImportRow(dr);
        //            }
        //            if (dtLoginPageTransCreate.Rows.Count > 0)
        //                loginPageTrans.DoCreate(dtLoginPageTransCreate);
        //            if (loginPageTrans.ErrorNumber > 0)
        //            {
        //                if (loginPageTrans.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
        //                {
        //                  ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
        //                  ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", loginPageTrans.ErrorMessage.Split(':')[1]);
        //                }
        //                else
        //                {
        //                   ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
        //                   ucMessage.Message = (string)GetLocalResourceObject(loginPageTrans.ErrorMessage.Split(':')[1]);
        //                }
        //                return;
        //            }
        //           // hdnErrMsg.Value = "Record updated Successfully!!!";
        //       //  ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
                      
        //            if (ActionClick != null)
        //                ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
        //          //  hdnErrMsg.Value = "Record updated Successfully!!!";
        //           // ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "RecordUpdatedSuccessfully").ToString();
        //           // ucMessage.PageTabContainerID = "Permission";
        //        }
        //    }
        //}
        //else
        //{
        //    using (LoginTypePageTrans loginTypePageTrans = new LoginTypePageTrans())
        //    {
        //        if (gridPage.Rows.Count > 0)
        //        {
        //            PermissionTable.Columns.Remove("ID");
        //            DataTable dt = PermissionTable.Clone();
        //            foreach (DataRow dr in PermissionTable.Rows)
        //            {
        //                dt.Rows.Clear();
        //                dt.ImportRow(dr);
        //                if (dr["SNo"].ToString() == "")
        //                {
        //                    if (dt.Columns.Contains("SNo"))
        //                        dt.Columns.Remove("SNo");
        //                    loginTypePageTrans.DoCreate(dt);
        //                }
        //                else
        //                    loginTypePageTrans.DoUpdate(dt);

        //                using (CommonBusiness commonBusiness = new CommonBusiness())
        //                {
        //                    DataTable dtCommonBusiness = commonBusiness.GetList("vGetLoginType", "*", "UserGroupSNo = '" + hdnPrimaryKeyValue.Value + "' order by LoginSNo");
        //                    if (dtCommonBusiness != null && dtCommonBusiness.Rows.Count > 0)
        //                    {
        //                        DataTable dtLoginPageTrans = null;
        //                        DataRow drLoginPageTrans = null;
        //                        for (int i = 0; i < dtCommonBusiness.Rows.Count; i++)
        //                        {
        //                            dtLoginPageTrans = null;
        //                            using (LoginPageTrans loginPageTrans = new LoginPageTrans())
        //                            {
        //                                //if (dt.Rows[0]["PageSNo"].ToString() == "250" && dtCommonBusiness.Rows[i]["LoginSNo"].ToString() == "168")
        //                                //{
        //                                //    string a = "";
        //                                //}
        //                                dtLoginPageTrans = loginPageTrans.GetList("LoginPageTrans", "*", "LoginSNo='" + dtCommonBusiness.Rows[i]["LoginSNo"] + "' And PageSNo = '" + dt.Rows[0]["PageSNo"] + "'");
        //                                if (dtLoginPageTrans != null && dtLoginPageTrans.Rows.Count > 0)
        //                                {
        //                                    if (dt.Rows[0]["CanView"].ToString() == "False" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "False")
        //                                    {
        //                                        dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
        //                                        dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
        //                                        dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
        //                                        dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
        //                                    }
        //                                    else if (dt.Rows[0]["CanView"].ToString() == "False" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True")
        //                                    {
        //                                        DataRow[] dRow = null;
        //                                        dRow = dtPermissionTable.Select("PageSNo='" + dt.Rows[0]["PageSNo"].ToString() + "'");
        //                                        if (((dt.Rows[0]["CanView"].ToString() == "False") && (dt.Rows[0]["CanInsert"].ToString() == "False") && (dt.Rows[0]["CanUpdate"].ToString() == "False") && (dt.Rows[0]["CanDelete"].ToString() == "False")) && ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "False") && (dtLoginPageTrans.Rows[0]["CanInsert"].ToString() == "False") && (dtLoginPageTrans.Rows[0]["CanUpdate"].ToString() == "False") && (dtLoginPageTrans.Rows[0]["CanDelete"].ToString() == "False")))
        //                                        {
        //                                            dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
        //                                            dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
        //                                            dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
        //                                            dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
        //                                        }
        //                                        else if (((dt.Rows[0]["CanView"].ToString() == "False") && (dt.Rows[0]["CanInsert"].ToString() == "False") && (dt.Rows[0]["CanUpdate"].ToString() == "False") && (dt.Rows[0]["CanDelete"].ToString() == "False")) && ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True") || (dtLoginPageTrans.Rows[0]["CanInsert"].ToString() == "True") || (dtLoginPageTrans.Rows[0]["CanUpdate"].ToString() == "True") || (dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True")))
        //                                        {
        //                                            //Check if current and previous logintype difference
        //                                            if ((dRow[0]["CanView"] == dt.Rows[0]["CanView"]) || (dRow[0]["CanInsert"] == dt.Rows[0]["CanInsert"]) || (dRow[0]["CanUpdate"] == dt.Rows[0]["CanUpdate"]) || (dRow[0]["CanDelete"] == dt.Rows[0]["CanDelete"]))
        //                                            {
        //                                                dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
        //                                                dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
        //                                                dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
        //                                                dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
        //                                            }
        //                                            else if ((dtLoginPageTrans.Rows[0]["CanView"].ToString() != "True") && (dt.Rows[0]["CanView"].ToString() == "False") && (dRow[0]["CanView"].ToString() == "False"))
        //                                            {
        //                                                dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
        //                                                dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
        //                                                dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
        //                                                dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
        //                                            }
        //                                            else if ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True") && (dt.Rows[0]["CanView"].ToString() == "False" && dRow[0]["CanView"].ToString() == "False"))
        //                                            {

        //                                            }
        //                                            else if ((dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True") && (dt.Rows[0]["CanView"].ToString() == "False" && dRow[0]["CanView"].ToString() == "True"))
        //                                            {
        //                                                dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
        //                                                dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
        //                                                dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
        //                                                dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];

        //                                            }
        //                                        }
        //                                    }
        //                                    else if (dt.Rows[0]["CanView"].ToString() == "True" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "False")
        //                                    {
        //                                        dtLoginPageTrans.Rows[0]["CanView"] = dt.Rows[0]["CanView"];
        //                                        dtLoginPageTrans.Rows[0]["CanInsert"] = dt.Rows[0]["CanInsert"];
        //                                        dtLoginPageTrans.Rows[0]["CanUpdate"] = dt.Rows[0]["CanUpdate"];
        //                                        dtLoginPageTrans.Rows[0]["CanDelete"] = dt.Rows[0]["CanDelete"];
        //                                    }

        //                                    else if (dt.Rows[0]["CanView"].ToString() == "True" && dtLoginPageTrans.Rows[0]["CanView"].ToString() == "True")
        //                                    {

        //                                    }
        //                                    loginPageTrans.DoUpdate(dtLoginPageTrans);
        //                                    if (loginPageTrans.ErrorNumber > 0)
        //                                    {
        //                                        if (loginPageTrans.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
        //                                        {
        //                                           ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
        //                                         ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", loginPageTrans.ErrorMessage.Split(':')[1]);
        //                                        }
        //                                        else
        //                                        {
        //                                          ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
        //                                          ucMessage.Message = (string)GetLocalResourceObject(loginPageTrans.ErrorMessage.Split(':')[1]);
        //                                        }
        //                                        return;
        //                                    }
        //                                }
        //                                else
        //                                {
        //                                    drLoginPageTrans = dtLoginPageTrans.NewRow();
        //                                    drLoginPageTrans["LoginSNo"] = dtCommonBusiness.Rows[i]["LoginSNo"];
        //                                    drLoginPageTrans["PageSNo"] = dt.Rows[0]["PageSNo"];
        //                                    drLoginPageTrans["CanView"] = dt.Rows[0]["CanView"];
        //                                    drLoginPageTrans["CanInsert"] = dt.Rows[0]["CanInsert"];
        //                                    drLoginPageTrans["CanUpdate"] = dt.Rows[0]["CanUpdate"];
        //                                    drLoginPageTrans["CanDelete"] = dt.Rows[0]["CanDelete"];
        //                                    drLoginPageTrans["IsDeleted"] = 0;
        //                                    dtLoginPageTrans.Rows.Add(drLoginPageTrans);
                                            
        //                                    loginPageTrans.DoCreate(dtLoginPageTrans);
        //                                }
        //                            }
        //                        }
        //                    }

        //                }
        //            }
        //            if (loginTypePageTrans.ErrorNumber > 0)
        //            {
        //                if (loginTypePageTrans.ErrorMessage.Split(':')[0] == "GetGlobalResourceObject")
        //                {
        //                ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
        //                    ucMessage.Message = (string)GetGlobalResourceObject("GlobalCSAndJSMsg", loginTypePageTrans.ErrorMessage.Split(':')[1]);
        //                }
        //                else
        //                {
        //                  ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
        //                    ucMessage.Message = (string)GetLocalResourceObject(loginTypePageTrans.ErrorMessage.Split(':')[1]);
        //                }
        //                return;
        //            }
        //            ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
        //            if (ActionClick != null)
        //                ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
        //                  hdnErrMsg.Value = "Record Updated Successfully!!!!";
        //            ucMessage.PageTabContainerID = "Permission";
        //        }
        //    }
        //}
    }

    /// <summary>
    /// Method to handle the cancel button click.
    /// </summary>
    /// <param name="sender">The sender of the cancel event that is the cancel button.</param>
    /// <param name="e">The arguments of the sender that is the cancel button.</param>
    protected void cmdCancel_Click(object sender, EventArgs e)
    {
        if (ActionClick != null)
            ActionClick(sender, new ActionEventArgs(ActionType.Cancel, e));
        Session["TempVal"] = null;

        if (Request.QueryString["p"] == "lp")
        {
            hdnvalue.Value = "lp";
            Response.Redirect("LoginPermission.aspx");
        }
        else
        {
            Response.Redirect("LoginTypePermission.aspx");
        }

       
    }

    /// <summary>
    /// Return JQuery String for Checked and Unchecked elements
    /// </summary>
    /// <param name="ObjectName">Name of the object like (ViewAll,NewAll,EditAll etc...)</param>
    /// <param name="ObjectId">Autoincrement Id like (1,2,3,4,5 ....)</param>
    /// <returns>complete jquery function</returns>
   public string GetCheckJQuery(string ObjectName, string ObjectId, bool SubParent, string subObjectId)
    {
        StringBuilder rString = new StringBuilder();

        try
        {
            rString.Append("var chk;");
            rString.Append("var currentElement=$(this);");
            rString.Append("$(\"span[" + ObjectName + ObjectId + "]\").each(");
            //Start Function
            rString.Append("function(){");
            rString.Append("chk=$(this).find('input');");
            //Start if Condition
            rString.Append("if(currentElement[0].checked == true){");
            rString.Append("chk.attr('checked', 'checked');");
            if (!ObjectId.Contains("Parent"))
            {
                rString.Append(";}else{");
                rString.Append("chk.attr('checked', '');");
            }

            // End if Condition
            rString.Append(";}");
            //End Function
            rString.Append(";});");

            if (ObjectName == "ViewAll" && !ObjectId.Contains("Parent"))
            {
                //Unchecked all New Elements
                rString.Append("$(\"span[NewAll" + ObjectId + "]\").each(");
                rString.Append("function(){");
                rString.Append("chk=$(this).find('input');");
                rString.Append("if(currentElement[0].checked == false){");
                rString.Append("chk.attr('checked', '');");
                rString.Append(";}");
                rString.Append(";});");

                //Unchecked all Edit Elements
                rString.Append("$(\"span[EditAll" + ObjectId + "]\").each(");
                rString.Append("function(){");
                rString.Append("chk=$(this).find('input');");
                rString.Append("if(currentElement[0].checked == false){");
                rString.Append("chk.attr('checked', '');");
                rString.Append(";}");
                rString.Append(";});");

                //Unchecked all Delete Elements
                rString.Append("$(\"span[DeleteAll" + ObjectId + "]\").each(");
                rString.Append("function(){");
                rString.Append("chk=$(this).find('input');");
                rString.Append("if(currentElement[0].checked == false){");
                rString.Append("chk.attr('checked', '');");
                rString.Append(";}");
                rString.Append(";});");

                //Unchecked all Print Elements
                rString.Append("$(\"span[PrintAll" + ObjectId + "]\").each(");
                rString.Append("function(){");
                rString.Append("chk=$(this).find('input');");
                rString.Append("if(currentElement[0].checked == false){");
                rString.Append("chk.attr('checked', '');");
                rString.Append(";}");
                rString.Append(";});");
            }
            else if (ObjectName != "ViewAll")
            {
                rString.Append("$(\"span[ViewAll" + ObjectId + "]\").each(");
                rString.Append("function(){");
                rString.Append("chk=$(this).find('input');");
                rString.Append("if(currentElement[0].checked == true){");
                rString.Append("chk.attr('checked', 'checked');");
                rString.Append(";}");
                rString.Append(";});");
            }

            if (SubParent)
            {
                //ObjectId = "Sub" + ObjectId;
                rString.Append("var chk;");
                rString.Append("var currentElement=$(this);");
                rString.Append("$(\"span[" + ObjectName + subObjectId + "]\").each(");
                //Start Function
                rString.Append("function(){");
                rString.Append("chk=$(this).find('input');");
                //Start if Condition
                rString.Append("if(currentElement[0].checked == true){");
                rString.Append("chk.attr('checked', 'checked');");
                //End if Condition
                rString.Append(";}");
                //End Function
                rString.Append(";});");

                if (ObjectName != "ViewAll")
                {
                    rString.Append("$(\"span[ViewAll" + subObjectId + "]\").each(");
                    rString.Append("function(){");
                    rString.Append("chk=$(this).find('input');");
                    rString.Append("if(currentElement[0].checked == true){");
                    rString.Append("chk.attr('checked', 'checked');");
                    rString.Append(";}");
                    rString.Append(";});");
                }
            }

            rString.Append("return;");
        }
        catch (Exception ex)
        {
           // ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
           // ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();

        }
        return rString.ToString();
    }

    /// <summary>
    /// Check or Uncheck gridview checkbox according to Permission Table
    /// </summary>
    /// <param name="dr">Current Data Row</param>
    /// <param name="chkView">CheckBox View</param>
    /// <param name="chkNew">CheckBox New</param>
    /// <param name="chkEdit">CheckBox Edit</param>
    /// <param name="chkDelete">CheckBox Delete</param>
    private void SetCheckValue(DataRow dr, CheckBox chkView, CheckBox chkNew, CheckBox chkEdit, CheckBox chkDelete)
    {
        string PageSNo = dr["SNo"].ToString();
        if (PermissionTable.Rows.Count > 0)
        {
            DataRow[] drModule = PermissionTable.Select("PageSNo=" + PageSNo);
            if (drModule.Length > 0)
            {
                chkView.Checked = bool.Parse(drModule[0]["CanView"].ToString());
                chkNew.Checked = bool.Parse(drModule[0]["CanInsert"].ToString());
                chkEdit.Checked = bool.Parse(drModule[0]["CanUpdate"].ToString());
                chkDelete.Checked = bool.Parse(drModule[0]["CanDelete"].ToString());
            }
        }
    }

    protected void gridPage_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox chkview = (CheckBox)e.Row.FindControl("chkView");
            CheckBox chkNew = (CheckBox)e.Row.FindControl("chkNew");
            CheckBox chkEdit = (CheckBox)e.Row.FindControl("chkEdit");
            CheckBox chkDelete = (CheckBox)e.Row.FindControl("chkDelete");
            CheckBox chkPrint = (CheckBox)e.Row.FindControl("chkPrint");
            Label lblSNo = (Label)e.Row.FindControl("lblSno");

            GridView gridPageDetails = e.Row.FindControl("gridPageDetails") as GridView;
            DataRow dataRow = (e.Row.DataItem as DataRowView).Row;
            DataRow[] drModule = PageTable.Select("MenuSno = " + dataRow[0]);
            DataTable dtPageSub = NewPageTable.Copy();
            foreach (DataRow dr in drModule)
                dtPageSub.ImportRow(dr);
            lblSNo.Text = dataRow["SNo"].ToString();
            SetCheckValue(dataRow, chkview, chkNew, chkEdit, chkDelete);

            gridPageDetails.DataSource = dtPageSub;
            gridPageDetails.DataBind();
        }
    }

    protected void gridPageDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            GridView gridPageDetails1 = e.Row.FindControl("gridPageDetails1") as GridView;

            CheckBox chkview = (CheckBox)e.Row.FindControl("chkView");
            CheckBox chkNew = (CheckBox)e.Row.FindControl("chkNew");
            CheckBox chkEdit = (CheckBox)e.Row.FindControl("chkEdit");
            CheckBox chkDelete = (CheckBox)e.Row.FindControl("chkDelete");
            CheckBox chkPrint = (CheckBox)e.Row.FindControl("chkPrint");
            Label lblSNo = (Label)e.Row.FindControl("hfSNo");

            DataRow dataRow = (e.Row.DataItem as DataRowView).Row;
            DataRow[] drModule = PageTable.Select("MenuSno = " + dataRow[0]);
            DataTable dtPageSubSub = NewPageTable.Copy();
            foreach (DataRow dr in drModule)
                dtPageSubSub.ImportRow(dr);

            lblSNo.Text = dataRow["SNo"].ToString();
            SetCheckValue(dataRow, chkview, chkNew, chkEdit, chkDelete);
            gridPageDetails1.DataSource = dtPageSubSub;
            gridPageDetails1.DataBind();
        }
    }

    protected void gridPageDetails1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox chkview = (CheckBox)e.Row.FindControl("chkView");
            CheckBox chkNew = (CheckBox)e.Row.FindControl("chkNew");
            CheckBox chkEdit = (CheckBox)e.Row.FindControl("chkEdit");
            CheckBox chkDelete = (CheckBox)e.Row.FindControl("chkDelete");
            CheckBox chkPrint = (CheckBox)e.Row.FindControl("chkPrint");
            Label lblSNo = (Label)e.Row.FindControl("hfSNo");

            DataRow dataRow = (e.Row.DataItem as DataRowView).Row;
            lblSNo.Text = dataRow["SNo"].ToString();
            SetCheckValue(dataRow, chkview, chkNew, chkEdit, chkDelete);
        }
    }

    private void gridPage_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            MainItemName = string.Empty;
            CheckBox chkview = (CheckBox)e.Row.FindControl("chkView");
            CheckBox chkNew = (CheckBox)e.Row.FindControl("chkNew");
            CheckBox chkEdit = (CheckBox)e.Row.FindControl("chkEdit");
            CheckBox chkDelete = (CheckBox)e.Row.FindControl("chkDelete");
            CheckBox chkPrint = (CheckBox)e.Row.FindControl("chkPrint");
            Label lblSNo = (Label)e.Row.FindControl("lblSno");
            Table tbl = (Table)e.Row.FindControl("tbl1");

            GridView gridPageDetails = e.Row.FindControl("gridPageDetails") as GridView;
            gridPageDetails.RowCreated += gridPageDetails_RowCreated;

            DataRow dataRow = (e.Row.DataItem as DataRowView).Row;

            DataRow[] drModule = PageTable.Select("MenuSno = " + dataRow[0]);
            DataTable dtPageSub = NewPageTable.Copy();
            foreach (DataRow dr in drModule)
                dtPageSub.ImportRow(dr);

            if (dtPageSub.Rows.Count > 0)
            {
                e.Row.CssClass = "subHeader";
                MainItemName = dataRow[1].ToString();
                if (hdnUIModeType.Value == "Update")
                {
                    chkview.Attributes.Add("onclick", GetCheckJQuery("ViewAll", i.ToString(), false, string.Empty));
                    chkNew.Attributes.Add("onclick", GetCheckJQuery("NewAll", i.ToString(), false, string.Empty));
                    chkEdit.Attributes.Add("onclick", GetCheckJQuery("EditAll", i.ToString(), false, string.Empty));
                    chkDelete.Attributes.Add("onclick", GetCheckJQuery("DeleteAll", i.ToString(), false, string.Empty));
                    chkPrint.Attributes.Add("onclick", GetCheckJQuery("PrintAll", i.ToString(), false, string.Empty));
                }
            }

            chkview.Attributes.Add("ViewAll", "ViewAll");
            chkview.Attributes.Add("ViewAll" + i, "ViewAll" + i);
            chkview.Attributes.Add("ViewAllParent" + MainItemName + i, "ViewAllParent" + i);

            chkNew.Attributes.Add("NewAll", "NewAll");
            chkNew.Attributes.Add("NewAll" + i, "NewAll" + i);
            chkNew.Attributes.Add("NewAllParent" + MainItemName + i, "NewAllParent" + i);

            chkEdit.Attributes.Add("EditAll", "EditAll");
            chkEdit.Attributes.Add("EditAll" + i, "EditAll" + i);
            chkEdit.Attributes.Add("EditAllParent" + MainItemName + i, "EditAllParent" + i);

            chkDelete.Attributes.Add("DeleteAll", "DeleteAll");
            chkDelete.Attributes.Add("DeleteAll" + i, "DeleteAll" + i);
            chkDelete.Attributes.Add("DeleteAllParent" + MainItemName + i, "DeleteAllParent" + i);

            chkPrint.Attributes.Add("PrintAll", "PrintAll");
            chkPrint.Attributes.Add("PrintAll" + i, "PrintAll" + i);
            chkPrint.Attributes.Add("PrintAllParent" + MainItemName + i, "PrintAllParent" + i);

            (e.Row as CfiGridViewRow).ShowExpand = dtPageSub.Rows.Count > 0;
            SNo1 = i;
            i = i + 2;
            SNo2 = 1;
        }
        else if (e.Row.RowType == DataControlRowType.Header)
        {
            CheckBox chkview = (CheckBox)e.Row.FindControl("chkViewAll");
            CheckBox chkNew = (CheckBox)e.Row.FindControl("chkNewAll");
            CheckBox chkEdit = (CheckBox)e.Row.FindControl("chkEditAll");
            CheckBox chkDelete = (CheckBox)e.Row.FindControl("chkDeleteAll");
            CheckBox chkPrint = (CheckBox)e.Row.FindControl("chkPrintAll");

            chkview.Attributes.Add("ViewAll", "ViewAll");
            chkNew.Attributes.Add("NewAll", "NewAll");
            chkEdit.Attributes.Add("EditAll", "EditAll");
            chkDelete.Attributes.Add("DeleteAll", "DeleteAll");
            chkPrint.Attributes.Add("PrintAll", "PrintAll");

            chkview.Attributes.Add("onclick", GetCheckJQuery("ViewAll", "", false, string.Empty));
            chkNew.Attributes.Add("onclick", GetCheckJQuery("NewAll", "", false, string.Empty));
            chkEdit.Attributes.Add("onclick", GetCheckJQuery("EditAll", "", false, string.Empty));
            chkDelete.Attributes.Add("onclick", GetCheckJQuery("DeleteAll", "", false, string.Empty));
            chkPrint.Attributes.Add("onclick", GetCheckJQuery("PrintAll", "", false, string.Empty));
        }
    }

    public void gridPageDetails_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            SubItemName = string.Empty;
            GridView gridPageDetails1 = e.Row.FindControl("gridPageDetails1") as GridView;
            gridPageDetails1.RowCreated += gridPageDetails1_RowCreated;

            CheckBox chkview = (CheckBox)e.Row.FindControl("chkView");
            CheckBox chkNew = (CheckBox)e.Row.FindControl("chkNew");
            CheckBox chkEdit = (CheckBox)e.Row.FindControl("chkEdit");
            CheckBox chkDelete = (CheckBox)e.Row.FindControl("chkDelete");
            CheckBox chkPrint = (CheckBox)e.Row.FindControl("chkPrint");
            Label lblSNo = (Label)e.Row.FindControl("hfSNo");
            Table tbl = (Table)e.Row.FindControl("tbl1");

            DataRow dataRow = (e.Row.DataItem as DataRowView).Row;

            lblSNo.Text = dataRow["SNo"].ToString();
            DataRow[] drModule = PageTable.Select("MenuSno = " + dataRow[0]);
            DataTable dtPageSubSub = NewPageTable.Copy();
            foreach (DataRow dr in drModule)
                dtPageSubSub.ImportRow(dr);

            if (dtPageSubSub.Rows.Count > 0)
            {
                e.Row.CssClass = "subHeader";
                SubItemName = dataRow[1].ToString();
                if (hdnUIModeType.Value == "Update")
                {
                    chkview.Attributes.Add("onclick", GetCheckJQuery("ViewAll", "Sub" + SubItemName + SNo2, false, string.Empty));
                    chkNew.Attributes.Add("onclick", GetCheckJQuery("NewAll", "Sub" + SubItemName + SNo2, false, string.Empty));
                    chkEdit.Attributes.Add("onclick", GetCheckJQuery("EditAll", "Sub" + SubItemName + SNo2, false, string.Empty));
                    chkDelete.Attributes.Add("onclick", GetCheckJQuery("DeleteAll", "Sub" + SubItemName + SNo2, false, string.Empty));
                    chkPrint.Attributes.Add("onclick", GetCheckJQuery("PrintAll", "Sub" + SubItemName + SNo2, false, string.Empty));
                }
                else
                    tbl.Visible = false;
            }
            else
            {
                if (hdnUIModeType.Value == "Update")
                {
                    chkview.Attributes.Add("onclick", GetCheckJQuery("ViewAll", "Parent" + MainItemName + (i - 2), false, string.Empty));
                    chkNew.Attributes.Add("onclick", GetCheckJQuery("NewAll", "Parent" + MainItemName + (i - 2), false, string.Empty));
                    chkEdit.Attributes.Add("onclick", GetCheckJQuery("EditAll", "Parent" + MainItemName + (i - 2), false, string.Empty));
                    chkDelete.Attributes.Add("onclick", GetCheckJQuery("DeleteAll", "Parent" + MainItemName + (i - 2), false, string.Empty));
                    chkPrint.Attributes.Add("onclick", GetCheckJQuery("PrintAll", "Parent" + MainItemName + (i - 2), false, string.Empty));
                }
            }

            chkview.Attributes.Add("ViewAll", "ViewAll");
            chkview.Attributes.Add("ViewAll" + (i - 2), "ViewAll" + (i - 2));
            chkview.Attributes.Add("ViewAllSub" + SubItemName + SNo2, "ViewAllSub" + SubItemName + SNo2);
            chkview.Attributes.Add("ViewAllSubParent" + SubItemName + SNo2, "ViewAllSubParent" + SubItemName + SNo2);

            chkNew.Attributes.Add("NewAll", "NewAll");
            chkNew.Attributes.Add("NewAll" + (i - 2), "NewAll" + (i - 2));
            chkNew.Attributes.Add("NewAllSub" + SubItemName + SNo2, "NewAllSub" + SubItemName + SNo2);
            chkNew.Attributes.Add("NewAllSubParent" + SubItemName + SNo2, "NewAllSubParent" + SubItemName + SNo2);

            chkEdit.Attributes.Add("EditAll", "EditAll");
            chkEdit.Attributes.Add("EditAll" + (i - 2), "EditAll" + (i - 2));
            chkEdit.Attributes.Add("EditAllSub" + SubItemName + SNo2, "EditAllSub" + SubItemName + SNo2);
            chkEdit.Attributes.Add("EditAllSubParent" + SubItemName + SNo2, "EditAllSubParent" + SubItemName + SNo2);

            chkDelete.Attributes.Add("DeleteAll", "DeleteAll");
            chkDelete.Attributes.Add("DeleteAll" + (i - 2), "DeleteAll" + (i - 2));
            chkDelete.Attributes.Add("DeleteAllSub" + SubItemName + SNo2, "DeleteAllSub" + SubItemName + SNo2);
            chkDelete.Attributes.Add("DeleteAllSubParent" + SubItemName + SNo2, "DeleteAllSubParent" + SubItemName + SNo2);

            chkPrint.Attributes.Add("PrintAll", "PrintAll");
            chkPrint.Attributes.Add("PrintAll" + (i - 2), "PrintAll" + (i - 2));
            chkPrint.Attributes.Add("PrintAllSub" + SubItemName + SNo2, "PrintAllSub" + SubItemName + SNo2);
            chkPrint.Attributes.Add("PrintAllSubParent" + SubItemName + SNo2, "PrintAllSubParent" + SubItemName + SNo2);

            (e.Row as CfiGridViewRow).ShowExpand = dtPageSubSub.Rows.Count > 0;
            SNo2++;
        }
    }

    public  void gridPageDetails1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox chkview = (CheckBox)e.Row.FindControl("chkView");
            CheckBox chkNew = (CheckBox)e.Row.FindControl("chkNew");
            CheckBox chkEdit = (CheckBox)e.Row.FindControl("chkEdit");
            CheckBox chkDelete = (CheckBox)e.Row.FindControl("chkDelete");
            CheckBox chkPrint = (CheckBox)e.Row.FindControl("chkPrint");
            Label lblSNo = (Label)e.Row.FindControl("hfSNo");

            chkview.Attributes.Add("ViewAll", "ViewAll");
            chkview.Attributes.Add("ViewAll" + (i - 2), "ViewAll" + (i - 2));
            chkview.Attributes.Add("ViewAllSub" + SubItemName + (SNo2 - 1), "ViewAllSub" + SubItemName + (SNo2 - 1));
            //chkview.Attributes.Add("ViewAllSubParent" + SubItemName + (SNo2 - 1), "ViewAllSubParent" + SubItemName + (SNo2 - 1));

            chkNew.Attributes.Add("NewAll", "NewAll");
            chkNew.Attributes.Add("NewAll" + (i - 2), "NewAll" + (i - 2));
            chkNew.Attributes.Add("NewAllSub" + SubItemName + (SNo2 - 1), "NewAllSub" + SubItemName + (SNo2 - 1));
            //chkNew.Attributes.Add("NewAllSubParent" + SubItemName + (SNo2 - 1), "NewAllSubParent" + SubItemName + (SNo2 - 1));

            chkEdit.Attributes.Add("EditAll", "EditAll");
            chkEdit.Attributes.Add("EditAll" + (i - 2), "EditAll" + (i - 2));
            chkEdit.Attributes.Add("EditAllSub" + SubItemName + (SNo2 - 1), "EditAllSub" + SubItemName + (SNo2 - 1));
            //chkEdit.Attributes.Add("EditAllSubParent" + SubItemName + (SNo2 - 1), "EditAllSubParent" + SubItemName + (SNo2 - 1));

            chkDelete.Attributes.Add("DeleteAll", "DeleteAll");
            chkDelete.Attributes.Add("DeleteAll" + (i - 2), "DeleteAll" + (i - 2));
            chkDelete.Attributes.Add("DeleteAllSub" + SubItemName + (SNo2 - 1), "DeleteAllSub" + SubItemName + (SNo2 - 1));
            //chkDelete.Attributes.Add("DeleteAllSubParent" + SubItemName + (SNo2 - 1), "DeleteAllSubParent" + SubItemName + (SNo2 - 1));

            chkPrint.Attributes.Add("PrintAll", "PrintAll");
            chkPrint.Attributes.Add("PrintAll" + (i - 2), "PrintAll" + (i - 2));
            chkPrint.Attributes.Add("PrintAllSub" + SubItemName + (SNo2 - 1), "PrintAllSub" + SubItemName + (SNo2 - 1));
            //chkPrint.Attributes.Add("PrintAllSubParent" + SubItemName + (SNo2 - 1), "PrintAllSubParent" + SubItemName + (SNo2 - 1));

            if (this.hdnUIModeType.Value == "Update")
            {
                chkview.Attributes.Add("onclick", GetCheckJQuery("ViewAll", "Parent" + MainItemName + (i - 2), true, "SubParent" + SubItemName + (SNo2 - 1)));
                chkNew.Attributes.Add("onclick", GetCheckJQuery("NewAll", "Parent" + MainItemName + (i - 2), true, "SubParent" + SubItemName + (SNo2 - 1)));
                chkEdit.Attributes.Add("onclick", GetCheckJQuery("EditAll", "Parent" + MainItemName + (i - 2), true, "SubParent" + SubItemName + (SNo2 - 1)));
                chkDelete.Attributes.Add("onclick", GetCheckJQuery("DeleteAll", "Parent" + MainItemName + (i - 2), true, "SubParent" + SubItemName + (SNo2 - 1)));
                chkPrint.Attributes.Add("onclick", GetCheckJQuery("PrintAll", "Parent" + MainItemName + (i - 2), true, "SubParent" + SubItemName + (SNo2 - 1)));
            }
        }
    }

    /// <summary>
    /// Method use to provide LoginName according to hdnPermissionFor.Value like (Login or LoginType)
    /// </summary>
    /// <param name="loginId">
    /// The login id.
    /// </param>
    /// <returns>
    /// string object login name.
    /// </returns>
    public string GetLoginName(string loginId)
    {
        string loginName = string.Empty;
        try
        {
            using (LoginType loginType = new LoginType())
            {
                if (this.hdnPermissionFor.Value == "Login")
                {
                    DataTable dtLogin = loginType.GetList("Login", "LoginId", string.Format("SNo={0}", loginId));
                    if (dtLogin.Rows.Count > 0)
                    {
                        loginName = dtLogin.Rows[0][0].ToString();
                    }
                }
                else
                {
                    DataTable dtLogin = loginType.GetList("UserGroup", "GroupName", string.Format("SNo={0}", loginId));
                    if (dtLogin.Rows.Count > 0)
                    {
                        loginName = dtLogin.Rows[0][0].ToString();
                    }
                }
            }

            return loginName;
        }
        catch (Exception ex)
        {
           // ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
            cfiException.InsertExceptionIntoDatabase(true);
           // ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
            return string.Empty;
        }
    }

    public AppControls_Messages ucMessage { get; set; }
}