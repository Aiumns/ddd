﻿/* Login UserControl Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This class implements the functionality related to Department.
 * Created By           :   Aditya Kumar.
 * Created On           :   21 Oct 2009.
 */


using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Cfi.App.Pace.Common;
using System.IO;
using Cfi.App.Pace.Business;
using System.Text;
using Cfi.App.CRM.Business;



public partial class AppControls_Manage_Login : System.Web.UI.UserControl
{
    /// <summary>
    /// String object name that is the department name, which is being operated.
    /// </summary>
    private string currentTitle = string.Empty;
    /// <summary>
    /// User control which is used to display the message on this page.
    /// </summary>
    private AppControls_Messages ucMessage;
    /// <summary>   
    /// Set Login Type SNo
    /// <summary>
    /// Get or set the Login Type SNo
    /// </summary>
    public int LoginTypeSNo { get { return Convert.ToInt16(ViewState["LoginTypeSNo"].ToString()); } set { ViewState["LoginTypeSNo"] = value; } }

   

    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
  //  public event ActionClickHandler ActionClick;

    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">The sender of the page load event.</param>
    /// <param name="e">The arguments of the page load event.</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        //this.ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages");
        //ddlLoginType.Attributes.Add("onchange", "SelectCustomHouseAgent('" + ddlLoginType.ClientID + "');");
        //if (hdnUIModeType.Value == "View" || hdnUIModeType.Value == "Delete")
        //    cmdAction.Attributes.Add("onclick", "jConfirm('Are you sure you want to delete.','Record Delete',function(r){if(r)" + Page.ClientScript.GetPostBackEventReference(cmdAction, cmdAction.CommandName) + ";}); return false;");
        //else
        //{
        //    cmdAction.Attributes.Add("onclick", "IsValidateForm('SaveAndUpdate','" + cmdAction.ClientID + "');");
        //}


        if (!IsPostBack)
        {
            rblIsActive.Visible = true;
            BindLoginType();
            bindlistbox();
            BindChaDetails();

            if (Session["TempVal"] == null)
            {
                //ClearTextbox();
                //btnSubmit.Text = "Submit";
            }
            else
            {
                if (Request.QueryString.Count > 1)
                {
                    //ClearTextbox();
                    string[] str = Session["TempVal"].ToString().Split('#');
                    if (str[1] == "E")
                    {
                    BindRecord();
                    cmdAction.Text = "Update";
                    }
                    if (str[1] == "D")
                    {
                        ddlLoginType.Enabled = false;
                        txtEMailId.Enabled = false;
                        txtName.Enabled = false;
                        txtPassword.Enabled = false;
                        txtPasswordRe.Enabled = false;
                        rblIsActive.Enabled = false;
                        ddlMultiCity.Enabled = false;
                        lstCompanyName.Enabled = false;

                      BindRecord();
                      cmdAction.Text = "Delete";
                    }
                }

            }
        }

    }

    public void BindRecord()
    {
         BLLogin blogin=new BLLogin();
        DataSet dsbinreecord = new DataSet();

         string str1 = Request.QueryString[0].ToString();
           int ShipD = int.Parse(str1 == "" ? "0" : str1);
           dsbinreecord = blogin.getAlldata(ShipD);
           if (dsbinreecord.Tables[0].Rows.Count > 0)
           {
               ddlLoginType.SelectedItem.Text = dsbinreecord.Tables[0].Rows[0]["LoginType"].ToString();
               txtLoginId.Text = dsbinreecord.Tables[0].Rows[0]["LoginId"].ToString();
                   
                     ASCIIEncoding enc = new ASCIIEncoding();
                     if (enc.GetString((byte[])dsbinreecord.Tables[0].Rows[0]["Password"]) != "")
                     {
                         txtPassword.Text = enc.GetString((byte[])dsbinreecord.Tables[0].Rows[0]["Password"]);
                         txtPasswordRe.Text = enc.GetString((byte[])dsbinreecord.Tables[0].Rows[0]["Password"]);
                     }
                     else
                     {
                         txtPassword.Text = "";
                         txtPasswordRe.Text = "";
                     }
                  
                txtEMailId.Text = dsbinreecord.Tables[0].Rows[0]["EmailID"].ToString();
                txtName.Text = dsbinreecord.Tables[0].Rows[0]["DisplayName"].ToString();
                ddlMultiCity.SelectedValue = dsbinreecord.Tables[0].Rows[0]["Active"].ToString();
                rblIsActive.SelectedValue = dsbinreecord.Tables[0].Rows[0]["Active"].ToString() == "Y" ? "1" : "0";
                if (rblIsActive.SelectedValue == "1")
                {
                   rblIsActive.Visible = true;
                }
               using (CompanyDetails companyDetails = new CompanyDetails())
               {
                   string[] compSno = null;

                   if (dsbinreecord.Tables[0].Rows[0]["CompSno"].ToString() != null)
                   {
                       compSno = dsbinreecord.Tables[0].Rows[0]["CompSno"].ToString().Split(',');
                   }

                   DataTable dtCompanyDetails = null;
                   if (compSno.Length > 0)
                   {
                       for (int i = 0; i < compSno.Length; i++)
                       {
                           if (compSno[i] == "") break;
                           dtCompanyDetails = companyDetails.GetList("CompanyDetails", "SNo", "SNo=" + int.Parse(compSno[i].ToString()));
                           lstCompanyName.Items.FindByValue(dtCompanyDetails.Rows[0]["SNo"].ToString()).Selected = true;
                       }
                   }
               }
              // lstCompanyName.Text=
               
               
           }
    }

    public void BindLoginType()
    {
        BLLogin bllogin = new BLLogin();
        DataSet ds = new DataSet();
        ds = bllogin.BindLoginType();
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlLoginType.Items.Clear();
            ddlLoginType.DataSource = ds;
            ddlLoginType.DataTextField ="GroupName";
            ddlLoginType.DataValueField = "SNo";
           
            ddlLoginType.DataBind();

        }
        else
        {
            ddlLoginType.Dispose();
            ddlLoginType.DataBind();
            
        }
        ds.Dispose();
    }

    public void BindChaDetails()
    {
        BLLogin blogin = new BLLogin();
        DataSet dschadetails = new DataSet();
        dschadetails = blogin.GetChaDetails();
        if (dschadetails.Tables[0].Rows.Count > 0)
        {
            ddlCHA.Items.Clear();
            ddlCHA.DataSource = dschadetails;
            ddlCHA.DataTextField = "CHAName";
            ddlCHA.DataValueField = "SNo";
            ddlCHA.DataBind();

        }
        else
        {
            ddlCHA.Dispose();
            ddlCHA.DataBind();
        }
        dschadetails.Dispose();
    }


    public void bindlistbox()
    {
        BLLogin blogin = new BLLogin();
        DataSet dsbindlistbox = blogin.getlistboxdata();
        if (dsbindlistbox.Tables[0].Rows.Count > 0)
        {
            lstCompanyName.Items.Clear();
            lstCompanyName.DataSource = dsbindlistbox.Tables[0];
            lstCompanyName.DataTextField = "CompanyName";
            lstCompanyName.DataValueField = "SNo";
            lstCompanyName.DataBind();
        }
    }
    //Bind the controls with value during Page Load Event
    /// <summary>
    /// Method to bind the current entity.
    /// </summary>
    //private void BindLogin()
    //{
    //    try
    //    {
    //        rblIsActive.Items.Clear();
    //        try
    //        {

    //            // Bind LoginType from LoginType Enum
    //            using (LoginType loginType = new LoginType())
    //            {
    //                DataTable dtLoginType = loginType.GetList("UserGroup", "distinct(GroupName), SNo", "GroupType= 'I'");
    //                if (dtLoginType != null && dtLoginType.Rows.Count > 0)
    //                {
    //                    Cfi.SoftwareFactory.Common.CommonFunctions.FillDropDownListFromTable(ref ddlLoginType, dtLoginType, "SNo", "GroupName", string.Empty, "---Select---", true);
    //                }
    //                else
    //                {
    //                    ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //                    ucMessage.Message = "Login type not found.";
    //                    return;
    //                }
    //            }
    //            using (CHADetails chaDetails = new CHADetails())
    //            {
    //                DataTable dtCHADetails = chaDetails.GetList("CHADetails", "SNo,CHAName", "");
    //                if (dtCHADetails != null && dtCHADetails.Rows.Count > 0)
    //                {
    //                    Cfi.SoftwareFactory.Common.CommonFunctions.FillDropDownListFromTable(ref ddlCHA, dtCHADetails, "SNo", "CHAName", string.Empty, "---Select---", true);
    //                }
    //            }
    //            using (CompanyDetails companyDetails = new CompanyDetails())
    //            {
    //                DataTable dtCompanyDetails = companyDetails.GetList("CompanyDetails", "distinct name +' - '+ Place as CompanyName, SNo", "");
    //                if (dtCompanyDetails != null && dtCompanyDetails.Rows.Count > 0)
    //                {
    //                    lstCompanyName.Items.Clear();
    //                    lstCompanyName.DataSource = dtCompanyDetails;
    //                    lstCompanyName.DataTextField = "CompanyName";
    //                    lstCompanyName.DataValueField = "SNo";
    //                    lstCompanyName.DataBind();
    //                }
    //                else
    //                {
    //                    ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //                    ucMessage.Message = "Company name not found.";
    //                    return;
    //                }
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //            cfiException.InsertExceptionIntoDatabase(true);
    //            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //            return;
    //        }

    //        Cfi.SoftwareFactory.Common.CommonFunctions.FillRadioButtonListFromEnum(rblIsActive, typeof(Active), null, null, false);
    //        if (hdnUIModeType.Value == "New")
    //        {
    //            rblIsActive.SelectedValue = "1";
    //        }
    //        else
    //        {
    //            rblIsActive.SelectedIndex = -1;
    //        }

    //        if (hdnUIModeType.Value != "New" || !string.IsNullOrEmpty(this.hdnPrimaryKeyValue.Value))
    //        {
    //            using (Login login = new Login())
    //            {
    //                login.RecordID = this.hdnPrimaryKeyValue.Value;
    //                DataTable dtlogin = login.GetRecord();
    //                if (dtlogin != null && dtlogin.Rows.Count > 0)
    //                {
    //                    lblTitle.Text = lblTitle.Text + dtlogin.Rows[0]["LoginId"];
    //                    this.currentTitle = dtlogin.Rows[0]["LoginId"].ToString();
    //                    divLoginID.Visible = hdnUIModeType.Value == "Update";
    //                    txtEMailId.Text = dtlogin.Rows[0]["EMailID"].ToString();

    //                    DataTable dtloginType = login.GetList("UserGroup", "SNo", "GroupName='" + dtlogin.Rows[0]["LoginType"] + "'");
    //                    if (dtloginType != null && dtloginType.Rows.Count > 0)
    //                        this.LoginTypeSNo = int.Parse(dtloginType.Rows[0]["SNo"].ToString());

    //                    ddlLoginType.SelectedValue = this.LoginTypeSNo.ToString();

    //                    txtLoginId.Text = dtlogin.Rows[0]["LoginId"].ToString();

    //                    if ((dtlogin.Rows[0]["CHASNo"] != null) && (int.Parse(dtlogin.Rows[0]["CHASNo"].ToString()) > 0))
    //                    {
    //                        ddlCHA.SelectedValue = dtlogin.Rows[0]["CHASNo"].ToString();
    //                        if (ddlLoginType.SelectedItem.Text == "CUSTOMHOUSE-AGENT")
    //                            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "showCHADetails", "$('#divCHA').show();", true);
    //                    }
    //                    else
    //                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "hideCHADetails", "$('#divCHA').hide();", true);

    //                    ASCIIEncoding enc = new ASCIIEncoding();
    //                    txtPassword.Text = enc.GetString((byte[])dtlogin.Rows[0]["Password"]);
    //                    txtPasswordRe.Text = enc.GetString((byte[])dtlogin.Rows[0]["Password"]);

    //                    txtName.Text = dtlogin.Rows[0]["DisplayName"].ToString();
    //                    rblIsActive.SelectedValue = dtlogin.Rows[0]["Active"].ToString() == "Y" ? "1" : "0";

    //                    using (CompanyDetails companyDetails = new CompanyDetails())
    //                    {
    //                        string[] compSno = null;

    //                        if (dtlogin.Rows[0]["CompSno"].ToString() != null)
    //                        {
    //                            compSno = dtlogin.Rows[0]["CompSno"].ToString().Split(',');
    //                        }

    //                        DataTable dtCompanyDetails = null;
    //                        if (compSno.Length > 0)
    //                        {
    //                            for (int i = 0; i < compSno.Length; i++)
    //                            {
    //                                if (compSno[i] == "") break;
    //                                dtCompanyDetails = companyDetails.GetList("CompanyDetails", "SNo", "SNo=" + int.Parse(compSno[i].ToString()));
    //                                lstCompanyName.Items.FindByValue(dtCompanyDetails.Rows[0]["SNo"].ToString()).Selected = true;
    //                            }
    //                        }
    //                    }


    //                }
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }
    //}

    /// <summary>
    /// Method for setting visibiltity of label and textbox showing data.
    /// </summary>
//    private void LoadJavaScript()
//    {



//        string strCondition = string.Empty;
//        if (!string.IsNullOrEmpty(this.hdnPrimaryKeyValue.Value))
//            strCondition = "SNo!=" + this.hdnPrimaryKeyValue.Value;

//        //  Validate the login id...
//        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "LoginIDValidate", @"
//function ValidateEmailID(controlID)
//                {
//                   var isValidate =false;
//                   var val = $('#'+controlID).val();
//                     $.ajax({
//                    url: '../Services/CustomValidation.ashx',
//                    cache: false,
//                    async: false,
//                    data: 'Entity=Login&Columns=EmailID&WhereCondition=" + (strCondition == String.Empty ? string.Empty : strCondition + @" AND ") + @"EmailID=^' + val + '^',
//                    success: function(data) {
//                   isValidate =  data!=null && data.items.length<=0;
//                    if (!isValidate)
//                        {
//                            $('#' + controlID).attr('customErrorMessage','Email ID already exists.');
//                        }
//                        else {
//                            $('#' + controlID).attr('customErrorMessage','');
//                            }
//                }
//                 });
//                    return isValidate;
//                }onCustomValidation=ValidateEmailID;
//
//", true);
//    }

    /// <summary>
    /// Method for creating the form and loading the data according to the mode.
    /// </summary>
    /// <param name="uiMode">To set mode like New/Edit/View/Delete for the form being generated. </param>
    //public void CreateForm(UIMode uiMode, string primaryKeyValue)
    //{
    //    try
    //    {
    //        hdnUIModeType.Value = uiMode.ToString();

    //        if (hdnUIModeType.Value != "New")
    //            hdnPrimaryKeyValue.Value = primaryKeyValue;

    //        cmdAction.Visible = true;
    //        lblTitle.Text = string.Empty;
    //        this.BindLogin();
    //        switch (hdnUIModeType.Value)
    //        {
    //            case "View":
    //                cmdAction.Visible = false; cmdCancel.Text = "Back"; cmdCancel.CssClass = "buttonRegular";
    //                lblTitle.Text = "View Login: ";
    //                break;
    //            case "New":
    //                this.LoadJavaScript();
    //                cmdAction.Text = "Save";
    //                lblTitle.Text = "New Login: ";
    //                break;
    //            case "Update":
    //                this.LoadJavaScript();
    //                cmdAction.Text = "Update";
    //                lblTitle.Text = "Edit Login: ";
    //                break;
    //            case "Delete":
    //                cmdAction.Text = "Delete";
    //                lblTitle.Text = "Delete Login: ";
    //                break;
    //        }

    //        lblTitle.Visible = true;

    //        if (hdnUIModeType.Value == "View" || hdnUIModeType.Value == "Delete")
    //        {
    //            Cfi.SoftwareFactory.Common.CommonFunctions.ChangeControlsToLabel(null, pnlLogin);
    //            cmdAction.Attributes.Add("onclick", "jConfirm('" + currentTitle + GetGlobalResourceObject("GlobalCSAndJSMsg", "Areyousurewanttodelete").ToString() + "','" + GetGlobalResourceObject("GlobalCSAndJSMsg", "ConfirmationDialogue").ToString() + "',function(r){if(r)" + Page.ClientScript.GetPostBackEventReference(cmdAction, cmdAction.CommandName) + ";}); return false;");

    //        }
    //        else
    //        {
    //            ScriptManager.RegisterStartupScript(Page, typeof(Page), "RegisterlblLoginPassword", "var lblLoginPassword = '" + lblLoginPassword.ClientID + "';", true);
    //            ScriptManager.RegisterStartupScript(Page, typeof(Page), "RegisterTxtPassword", "var txtPassword = '" + txtPassword.ClientID + "';", true);
    //            ScriptManager.RegisterStartupScript(Page, typeof(Page), "RegisterTxtPasswordRe", "var txtPasswordRe = '" + txtPasswordRe.ClientID + "';", true);
    //            ScriptManager.RegisterStartupScript(Page, typeof(Page), "RegisterHdnPassword", "var hdnPassword = '" + hdnPassword.ClientID + "';", true);

    //            txtPassword.Attributes.Add("onblur", "CheckPassword();");
    //            txtPasswordRe.Attributes.Add("onblur", "CheckPassword();");
    //            Cfi.SoftwareFactory.Common.CommonFunctions.SetRequiredFieldsSkin(null, pnlLogin, "imtb");
    //            cmdAction.Attributes.Add("onclick", "IsValidateForm('SaveAndUpdate','" + cmdAction.ClientID + "');");
    //        }
    //        if (hdnUIModeType.Value == "Update")
    //            Cfi.SoftwareFactory.Common.CommonFunctions.ChangeControlsToLabel(null, pnlLoginType);
    //        //Cfi.SoftwareFactory.Common.CommonFunctions.ChangeControlsToLabel(null, upLoginType);
    //    }
    //    catch (Exception ex)
    //    {
    //        ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }
    //}

    /// <summary>
    /// Method to handle the action button that is the Save/Update/Delete etc button.
    /// </summary>
    /// <param name="sender">In this case the cancel button.</param>
    /// <param name="e">The arguments of the sender that is the action button.</param>
    //protected void cmdAction_Click(object sender, EventArgs e)
    //{
    //    switch (hdnUIModeType.Value)
    //    {
    //        case "New":
    //            SaveData(e);
    //            break;
    //        case "Update":
    //            UpdateData(e);
    //            break;
    //        case "View":
    //            break;
    //        case "Delete":
    //            DeleteData(e);
    //            break;
    //    }
    //}


    //Save All Office Details in Login Table, OfficeCityTrnas Table and OfficeAirlineTrans Table
    /// <summary>
    /// Method to save new data of the current form.
    /// </summary>
    /// <param name="e">The event argument of the button that called this method, so as to use in the action click handler delegate for ActionEventArgs event.</param>
    //private void SaveData(EventArgs e)
    //{
    //    SqlTransaction tr = SqlHelper.CreateSqlTransaction(ConnectionString.WebConfigConnectionString);

    //    try
    //    {
    //        if (txtPassword.Text.Trim() != txtPasswordRe.Text.Trim())
    //        {
    //            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //            ucMessage.Message = "Re-confirm password should be same.";
    //            return;
    //        }

    //        int countUser = 0;
    //        using (Login login = new Login())
    //        {
    //            countUser = login.GetRecordCount("Login", "*", "Loginid='" + txtLoginId.Text.Trim() + "'");
    //            if (countUser > 0)
    //            {
    //                ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //                ucMessage.Message = "User already existed, please enter another login id.";
    //                return;
    //            }
    //        }

    //        using (Login login = new Login(tr))
    //        {
    //            int loginSno = 0;
    //            byte[] getNewPassword = (new ASCIIEncoding()).GetBytes(txtPassword.Text.Trim());
    //            string newPassword = txtPassword.Text.Trim();

    //            string compSNo = string.Empty;
    //            for (int i = 0; i < lstCompanyName.Items.Count; i++)
    //            {
    //                if (lstCompanyName.Items[i].Selected)
    //                {
    //                    compSNo += lstCompanyName.Items[i].Value + ",";
    //                }
    //            }
    //            int chasno = 0;
    //            if ((ddlCHA.SelectedValue != "") && (int.Parse(ddlCHA.SelectedValue) > 0))
    //                chasno = int.Parse(ddlCHA.SelectedValue);

          // loginSno = login.InsertLoginDetails(ddlLoginType.SelectedItem.Text, txtLoginId.Text.Trim(), getNewPassword, txtEMailId.Text, txtName.Text.Trim(), compSNo, rblIsActive.SelectedIndex == 0 ? "Y" : "N", chasno);

    //            if (login.ErrorNumber > 0 || loginSno <= 0)
    //            {
    //                SqlHelper.RollbackSqlTransaction(tr);
    //                ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //                ucMessage.Message = "Server link failed, Try again later.";
    //                return;
    //            }

    //            using (LoginPageTrans loginPageTrans = new LoginPageTrans(tr))
    //            {
    //                using (CommonBusiness commonBussiness = new CommonBusiness())
    //                {
    //                    DataTable dtLoginPageTrans = loginPageTrans.GetNew();
    //                    dtLoginPageTrans.Clear();
    //                    DataTable dtLoginTypePageTrans = loginPageTrans.GetList("LoginTypePageTrans", "*", string.Format("LoginTypeSNo={0}", int.Parse(ddlLoginType.SelectedValue)));
    //                    DataRow drLoginPageTrans = dtLoginPageTrans.NewRow();
    //                    foreach (DataRow dr in dtLoginTypePageTrans.Rows)
    //                    {
    //                        drLoginPageTrans = dtLoginPageTrans.NewRow();
    //                        drLoginPageTrans["LoginSNo"] = loginSno;
    //                        drLoginPageTrans["PageSNo"] = dr["PageSno"];
    //                        drLoginPageTrans["CanView"] = dr["CanView"];
    //                        drLoginPageTrans["CanInsert"] = dr["CanInsert"];
    //                        drLoginPageTrans["CanUpdate"] = dr["CanUpdate"];
    //                        drLoginPageTrans["CanDelete"] = dr["CanDelete"];
    //                        dtLoginPageTrans.Rows.Add(drLoginPageTrans);
    //                    }
    //                    if (dtLoginPageTrans.Rows.Count > 0)
    //                        loginPageTrans.DoCreate(dtLoginPageTrans);
    //                    if (loginPageTrans.ErrorNumber > 0)
    //                    {
    //                        SqlHelper.RollbackSqlTransaction(tr);
    //                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //                        ucMessage.Message = "Server link failed, Try again later.";
    //                        return;
    //                    }

    //                }
    //            }

    //            tr.Commit();
    //            StringBuilder mailBody = new StringBuilder();
    //            mailBody.Append("Your Login Id is " + txtLoginId.Text);
    //            mailBody.Append("<br/>");
    //            mailBody.Append("Password - " + newPassword);

    //            using (Common common = new Common())
    //                common.SendMail(txtEMailId.Text, "Login Details", mailBody.ToString());

    //            ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
    //            if (this.ActionClick != null)
    //                this.ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
    //            ucMessage.Message = "Record Saved Successfully";
    //            ucMessage.PageTabContainerID = "Login";
    //            Cfi.SoftwareFactory.Common.CommonFunctions.ClearControlValues(null, pnlLogin);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        SqlHelper.RollbackSqlTransaction(tr);
    //        ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }
    //}



    //This method update the existing data from login Table,LoginAirlineTrans Table
    /// <summary>
    /// Method to update the existing current form data.
    /// </summary>
    /// <param name="e">The event argument of the button that called this method, so as to use in the action click handler delegate for ActionEventArgs event.</param>
    //private void UpdateData(EventArgs e)
    //{
    //    AppControls_Messages ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages");
    //    SqlTransaction tr = SqlHelper.CreateSqlTransaction(ConnectionString.WebConfigConnectionString);
    //    try
    //    {
    //        if (txtPassword.Text.Trim() != txtPasswordRe.Text.Trim())
    //        {
    //            ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //            ucMessage.Message = "Re-confirm password should be same.";
    //            return;
    //        }

    //        string newPassword = txtPassword.Text.Trim();
    //        byte[] getNewPassword = (new ASCIIEncoding()).GetBytes(txtPassword.Text.Trim());

    //        using (Login login = new Login(tr))
    //        {
    //            int loginSno = 0;
    //            string compSNo = string.Empty;
    //            for (int i = 0; i < lstCompanyName.Items.Count; i++)
    //            {
    //                if (lstCompanyName.Items[i].Selected)
    //                    compSNo += lstCompanyName.Items[i].Value + ",";
    //            }

    //            int chasno = 0;
    //            if ((ddlCHA.SelectedValue != "") && (int.Parse(ddlCHA.SelectedValue) > 0))
    //                chasno = int.Parse(ddlCHA.SelectedValue);

    //            loginSno = login.UpdateLoginDetails(int.Parse(hdnPrimaryKeyValue.Value), txtLoginId.Text.Trim(), getNewPassword, txtEMailId.Text, txtName.Text.Trim(), compSNo, rblIsActive.SelectedIndex == 0 ? "Y" : "N", chasno);

    //            DataTable dtLogin = login.GetList("Login", "LoginType", "SNo = '" + hdnPrimaryKeyValue.Value + "' ");
    //            DataTable dtLoginType = null;
    //            using (LoginType loginType = new LoginType())
    //            {
    //                dtLoginType = loginType.GetList("UserGroup", "SNo", "GroupName='" + dtLogin.Rows[0]["LoginType"] + "'");
    //            }

    //            if (login.ErrorNumber > 0 && loginSno <= 0)
    //            {
    //                SqlHelper.RollbackSqlTransaction(tr);
    //                ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //                ucMessage.Message = "Server link failed, Try again later.";
    //                return;
    //            }

    //            using (LoginPageTrans loginPageTrans = new LoginPageTrans(tr))
    //            {
    //                DataTable dtLoginPageTrans = loginPageTrans.GetNew();
    //                dtLoginPageTrans.Clear();

    //                DataTable dtLoginTypePageTrans = loginPageTrans.GetList("LoginTypePageTrans", "*", string.Format("LoginTypeSNo={0}", int.Parse(dtLoginType.Rows[0]["SNo"].ToString())));
    //                foreach (DataRow dr in dtLoginTypePageTrans.Rows)
    //                {
    //                    DataRow drLoginPageTrans = dtLoginPageTrans.NewRow();
    //                    drLoginPageTrans["LoginSNo"] = loginSno;
    //                    drLoginPageTrans["PageSNo"] = dr["PageSno"];
    //                    drLoginPageTrans["CanView"] = dr["CanView"];
    //                    drLoginPageTrans["CanInsert"] = dr["CanInsert"];
    //                    drLoginPageTrans["CanUpdate"] = dr["CanUpdate"];
    //                    drLoginPageTrans["CanDelete"] = dr["CanDelete"];
    //                    dtLoginPageTrans.Rows.Add(drLoginPageTrans);
    //                }

    //                loginPageTrans.DoCreate(dtLoginPageTrans);
    //                if (login.ErrorNumber > 0)
    //                {
    //                    SqlHelper.RollbackSqlTransaction(tr);
    //                    ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //                    ucMessage.Message = "Server link failed, Try again later.";
    //                    return;
    //                }
    //            }

    //            tr.Commit();
    //            if (this.ActionClick != null)
    //                this.ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
    //            ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
    //            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "RecordUpdatedSuccessfully").ToString();
    //            ucMessage.PageTabContainerID = "Login";

    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        tr.Rollback();
    //        ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //        CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //        cfiException.InsertExceptionIntoDatabase(true);
    //        ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //        return;
    //    }
    //}

    //This Method Delete a particular row from Login Table
    /// <summary>
    /// Method to delete the existing current form data.
    /// </summary>
    /// <param name="e">The event argument of the button that called this method, so as to use in the action click handler delegate for ActionEventArgs event.</param>
    //private void DeleteData(EventArgs e)
    //{
    //    if (!string.IsNullOrEmpty(this.hdnPrimaryKeyValue.Value))
    //    {
    //        try
    //        {
    //            AppControls_Messages ucMessage = (AppControls_Messages)Page.Master.FindControl("ucMessages");
    //            SqlTransaction tr = SqlHelper.CreateSqlTransaction(ConnectionString.WebConfigConnectionString);
    //            int countLoginPageTrans = 0;
    //            using (LoginPageTrans loginPageTrans = new LoginPageTrans(tr))
    //            {
    //                countLoginPageTrans = loginPageTrans.GetRecordCount("LoginPageTrans", "*", "loginSNo=" + this.hdnPrimaryKeyValue.Value + "");
    //            }
    //            using (LoginPageTrans loginPageTrans = new LoginPageTrans(tr))
    //            {
    //                if (countLoginPageTrans > 0)
    //                {
    //                    loginPageTrans.WhereCondition = "LoginSNo=" + int.Parse(this.hdnPrimaryKeyValue.Value);
    //                    loginPageTrans.DoDelete(int.Parse(this.hdnPrimaryKeyValue.Value));
    //                    if (loginPageTrans.ErrorNumber > 0)
    //                    {
    //                        SqlHelper.RollbackSqlTransaction(tr);
    //                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //                        ucMessage.Message = "Server link failed, Try again later.";
    //                        return;
    //                    }
    //                }
    //                using (Login login = new Login(tr))
    //                {
    //                    login.DoDelete(int.Parse(this.hdnPrimaryKeyValue.Value));
    //                    if (login.ErrorNumber > 0)
    //                    {
    //                        SqlHelper.RollbackSqlTransaction(tr);
    //                        ucMessage.MessageType = AppControls_Messages.UIMessageType.Information;
    //                        ucMessage.Message = "Server link failed, Try again later.";
    //                        return;
    //                    }

    //                    tr.Commit();
    //                    ucMessage.MessageType = AppControls_Messages.UIMessageType.Success;
    //                    if (this.ActionClick != null)
    //                        this.ActionClick(cmdAction, new ActionEventArgs(ActionType.Success, e));
    //                    ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "RecordDeletedSuccessfully").ToString();
    //                    ucMessage.PageTabContainerID = "Login";
    //                }
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            ucMessage.MessageType = AppControls_Messages.UIMessageType.Error;
    //            CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
    //            cfiException.InsertExceptionIntoDatabase(true);
    //            ucMessage.Message = GetGlobalResourceObject("GlobalCSAndJSMsg", "GlobalCatchErrorMessage").ToString();
    //            return;
    //        }
    //    }
    //}


    /// <summary>
    /// Method to handle the cancel button click.
    /// </summary>
    /// <param name="sender">The sender of the cancel event that is the cancel button.</param>
    /// <param name="e">The arguments of the sender that is the cancel button.</param>
    //protected void cmdCancel_Click(object sender, EventArgs e)
    //{
    //    if (ActionClick != null)
    //    {
    //        ucMessage.Message = string.Empty;
    //        ActionClick(sender, new ActionEventArgs(ActionType.Cancel, e));
    //        Cfi.SoftwareFactory.Common.CommonFunctions.ClearControlValues(null, pnlLogin);
    //    }
    //}




    protected void cmdAction_Click(object sender, EventArgs e)
    {

        BLLogin bllogin = new BLLogin();
        if (txtPassword.Text.Trim() != txtPasswordRe.Text.Trim())
        {
          
            return;
        }

        bllogin.LoginId = txtLoginId.Text.Trim();
        bllogin.Name = txtName.Text;
        //byte[] getNewPassword = (new ASCIIEncoding()).GetBytes(txtPassword.Text);
        bllogin.Password = txtPassword.Text.Trim();
     
      
      
       
        bllogin.loginType = ddlLoginType.SelectedItem.Text.ToString();
        string compSNo = string.Empty;
        for (int i = 0; i < lstCompanyName.Items.Count; i++)
        {
            if (lstCompanyName.Items[i].Selected)
            {
                compSNo += lstCompanyName.Items[i].Value + ",";
            }
        }

        bllogin.Companysno = compSNo;

        bllogin.Email = txtEMailId.Text;
      
        bllogin.Active = ddlMultiCity.SelectedItem.Value;
        bllogin.ChaName =  Convert.ToInt32( ddlCHA.SelectedItem.Value);

        if (Request.QueryString.Count > 1)
        {
            if (Request.QueryString[1].ToString() == "E")
            {
             
                 bllogin.Lsno   = Int32.Parse(Request.QueryString[0].ToString());
                 string updated = bllogin.UpdateAdminLoginDetailModified(Int32.Parse(Request.QueryString[0].ToString()));
                 if (updated != "")
                 {
                     hdnErrMsg.Value = updated.ToString();

                 }
                 else
                 {
                     hdnErrMsg.Value = "Record Not Updated!!!";
                 }
                //goMsg = @"<META HTTP-EQUIV=""Refresh"" CONTENT=""2; URL=DisplayCommodity.aspx"">";
            }
            else if (Request.QueryString[1].ToString() == "D")
            {
                bllogin.Lsno = Int32.Parse(Request.QueryString[0].ToString());
                string Deleted = bllogin.Deletemodified(Int32.Parse(Request.QueryString[0].ToString()));
                if (Deleted != "")
                {
                    hdnErrMsg.Value = Deleted.ToString();

                }
                else
                {
                    hdnErrMsg.Value = "Record Not Deleted!!!";
                }
            }
        }
        else
        {

            string inserted = bllogin.AddLoginModified();
            if (inserted != "")
            {
                hdnErrMsg.Value = inserted;
            }
            else
            {
                 hdnErrMsg.Value="Record Not Saved SuccessFully!!!";
            }
             
        }

 
    }
    protected void cmdCancel_Click(object sender, EventArgs e)
    {
        Session["TempVal"] = null;
        Response.Redirect("Login.aspx");
    }
    protected void ddlMultiCity_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}