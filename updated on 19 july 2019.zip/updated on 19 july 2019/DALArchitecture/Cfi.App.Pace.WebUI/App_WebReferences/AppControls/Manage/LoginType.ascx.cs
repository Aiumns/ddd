/*
    *****************************************************************************
	Control Name        : CampaignType   
	Purpose             : This control provides functionality to Insert/View/Update/Delete the
                          CampaignType Information  of current users. 					
	Company             : CargoFlash Infotech.
	Created By          : Aditya Kumar
	Created On          : 19 May 2010.
    *****************************************************************************
	*/

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Cfi.App.Pace.Common;
using System.IO;
using Cfi.App.Pace.Business;
using System.Text;
using Cfi.App.CRM.Business;



public partial class AppControls_Manage_LoginType : System.Web.UI.UserControl
{


    /// <summary>
    /// String object name that is the department name, which is being operated.
    /// </summary>
    private string currentTitle = string.Empty;
    /// <summary>
    /// User control which is used to display the message on this page.
    /// </summary>
    private AppControls_Messages ucMessage;

    /// <summary>
    /// Delegate to handle the Save/Update/Delete action button.
    /// </summary>
    /// <param name="sender">The action button which is delegating the method.</param>
    /// <param name="actionAndCancelButtonEventArgs">The arguments returned when the event is raised.</param>
    //  public delegate void ActionClickHandler(object sender, ActionEventArgs actionAndCancelButtonEventArgs);

    /// <summary>
    /// Event raised when the Save/Update/Delete action button is clicked.
    /// </summary>
    //public event ActionClickHandler ActionClick;

    /// <summary>
    /// Method to handle page load event.
    /// </summary>
    /// <param name="sender">The sender of the page load event.</param>
    /// <param name="e">The arguments of the page load event.</param>
    BPages bpage = new BPages();
    GeneralFunction gf = new GeneralFunction();
    public string[] arr;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            DataSet ds = gf.GetGroupName();
        
          

            if (Session["OutVal"] != null)
            {
                lblOutput.Text = Session["OutVal"].ToString();
                Session["OutVal"] = null;
            }

            if (Request.QueryString.Count > 1)
            {
                if (Request.QueryString[1].ToString() == "E")
                {

                    Session["TempVal"] = Request.QueryString[0].ToString() + "#E";
                }
                else if (Request.QueryString[1].ToString() == "D")
                {

                    Session["TempVal"] = Request.QueryString[0].ToString() + "#D";
                }
                else if (Request.QueryString[1].ToString() == "A")
                {

                    Session["TempVal"] = Request.QueryString[0].ToString() + "#A";
                }
                else
                {

                    Session["TempVal"] = null;
                }
            }
            else
            {
                if (Session["TempVal"] == null)
                {

                    Session["TempVal"] = null;

                }
            }

            if (Session["TempVal"] == null)
            {
                btnAdd.Visible = true;
                btnDelete.Visible = false;
                btnUpdate.Visible = false;
            }
            else
            {
                if (Request.QueryString.Count > 1)
                {
                    string id = Request.QueryString[0].ToString();

                    string[] str = Session["TempVal"].ToString().Split('#');
                    if (str[1] == "E")
                    {
                        btnUpdate.Visible = true;
                        btnAdd.Visible = false;
                        btnDelete.Visible = false;
                        txtGrpName.Enabled = true;
                        ddlGroupType.Enabled = true;
                       
                        getPagesForGroup(id);
                    }
                    if (str[1] == "D")
                    {
                        btnDelete.Visible = true;
                        btnUpdate.Visible = false;
                        btnAdd.Visible = false;
                        txtGrpName.ReadOnly = true;
                      
                        txtGrpName.Enabled = false;
                      
                        ddlGroupType.Enabled = false;
                      
                        getPagesForGroup(id);
                    }
                    if (str[1] == "A")
                    {
                        btnDelete.Visible = false;
                        btnUpdate.Visible = false;
                        btnAdd.Visible = true;
                    }
                }
            }
        }


       
    }

    public void getPagesForGroup(string id)
    {
        try
        {
            id = (Request.QueryString[0].ToString() == "" ? "0" : Request.QueryString[0].ToString());
            bpage.SNo = Convert.ToInt32(id);

            DataSet ds = new DataSet();
            ds = bpage.RetriveGroupPageDetail();

            txtGrpName.Text = ds.Tables[0].Rows[0]["GroupName"].ToString();
            ddlMultiCity.SelectedValue = ds.Tables[0].Rows[0]["MultiCity"].ToString();
            ddlGroupType.SelectedValue = ds.Tables[0].Rows[0]["GroupType"].ToString();
         
            DataSet dsallowedlistbox = new DataSet();
            int SNo = Convert.ToInt32(id);
           
            string LoginId = Session["UserID"].ToString();
            dsallowedlistbox = bpage.shopageview(SNo);  //bpage.shopageview(SNo);
          
            DataSet dsrestricted = new DataSet();
          
        }
        catch
        {
            Session["OutVal"] = "Check your input value!!!!";
            hdnErrMsg.Value = Session["OutVal"].ToString();
            Session["TempVal"] = null;
            Response.Redirect("LoginType.aspx");
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {

          
        bpage.GroupName = txtGrpName.Text.Trim().ToUpper();
        bpage.GroupType = ddlGroupType.SelectedValue;
        bpage.MultiCity = Convert.ToChar(ddlMultiCity.SelectedValue);
        string insertGroup = bpage.insertLoginType();
        if (insertGroup != " ")
        {
            hdnErrMsg.Value = insertGroup;

            Session["OutVal"] = insertGroup;

            Session["TempVal"] = null;
             
        }

        
       


    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        BPages bpage = new BPages();
     
        string id1 = (Request.QueryString[0].ToString() == "" ? "0" : Request.QueryString[0].ToString());

        bpage.SNo = Convert.ToInt32(id1.ToString());
        bpage.GroupName = txtGrpName.Text;
        bpage.GroupType = ddlGroupType.SelectedValue;

        bpage.MultiCity = Convert.ToChar(ddlMultiCity.SelectedValue);

        string Updated = bpage.updategrouppage().ToString();

       

        if (Updated == "")
        {
            hdnErrMsg.Value = "Record Update Suceesfully!!!";
        }

        else
        {
            hdnErrMsg.Value = "Try Again!!!";
           
        }



  
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (HiddenValue.Value == "false")
        {
            Session["OutVal"] = "Group Name Deletion Cancelled.";
            hdnErrMsg.Value = Session["OutVal"].ToString();
            Session["TempVal"] = null;
            btnDelete.Visible = false;
           
            return;
        }
        BPages bpage = new BPages();
        decimal id = decimal.Parse(Request.QueryString[0].ToString());
        bpage.SNo = Convert.ToInt32(id);
        string Deleted = bpage.RemoveGroupPages();

        if (Deleted.IndexOf("Try Again with valid value") < 0)
        {
            Session["OutVal"] = Deleted;
            hdnErrMsg.Value = Session["OutVal"].ToString();
            Session["TempVal"] = null;
            btnDelete.Visible = false;
           
        }
        else
        {
            lblMsg.Text = Deleted;
            hdnErrMsg.Value = lblMsg.Text;
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session["OutVal"] = null;
        Session["TempVal"] = null;
        Response.Redirect("LoginType.aspx");

    }
    protected void ddlGroupType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlMultiCity_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
 