﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class AppControls_FCK_User_Control_AdminTextEditorControl : System.Web.UI.UserControl
{
    public string Text { get { return FCKeditor1.Value; } set { FCKeditor1.Value = value; } }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}