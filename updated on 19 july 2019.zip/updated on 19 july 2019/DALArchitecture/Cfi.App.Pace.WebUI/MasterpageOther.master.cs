﻿using System;
using System.Data;
using System.Collections;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.Common;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;
using System.Data.SqlClient;
using System.Text;
using Cfi.App.Pace.Business;
using Cfi.App.CRM.Business;

public partial class MasterpageOther : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
}
