/* Login Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright � 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   The functionality on the login page.          .
 * Created By           :   Unknown.
 * Created On           :   Unknown.
 * Modified By          :   Sudhir Yadav.
 * Modified On          :   08 Jul 2010.
 * Desc                 :   Added a alert data to UserDetails class Alerts property.
*/

using System;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.Business;
using System.Text;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using System.Web.UI.WebControls;
using System.IO;
using System.Configuration;
using System.Collections;
using System.Threading;

public partial class Login : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["UserID"] = null;
            Session["Menu"] = "";
            Session["CaptchaImageText"] = Guid.NewGuid().ToString().Substring(0, 6).ToLower();
            txtUserName.Attributes.Add("autocomplete", "off");
            txtPassword.Attributes.Add("autocomplete", "off");
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {

        try
        {
            BLLogin BL = new BLLogin();
            BL.LoginId = txtUserName.Text;
            BL.Password = txtPassword.Text;
            BL.RemoteHostName = HttpContext.Current.Request.ServerVariables["SERVER_NAME"];
            BL.RemoteIPAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            BL.LocalIPAddress = HttpContext.Current.Request.ServerVariables["REMOTE_USER"] + "/" +
                                HttpContext.Current.Request.ServerVariables["SERVER_PORT"];

            String LO = BL.Login();
            if (LO.Trim() == "0")
            {
                lblMessage.Text = "Incorrect UserID or Password, Try again!";
                txtUserName.Focus();
            }
            else
            {
                BL.RetrieveUserDetail();
                 
                String[] data = LO.Split('?');
                if (Session["UserID"] == null)
                    Session["UserID"] = data[0];
                Session["CityCode"] = data[1];
                Session["LoginType"] = data[2];
                Session["DisplayName"] = data[3];
                Session["CountryCode"] = data[4];
                Session["CurrencyCode"] = data[5];
                Session["LastLogin"] = data[6];
                Session["Address"] = data[7];
                Session["CityCodeAccess"] = data[8];
                Session["AllCompBrSNo"] = data[9].TrimEnd(',');
                Session["CompBrSNo"] = data[9].TrimEnd(',');
                Session["CustBrID"] = data[10];
                Session["EmailID"] = data[11];
                Session["CompBrSNoFORPNP"] = data[12];
                Session["ID"] = data[13];
                Session["AdminId"] = data[14];
                Session["Project"] = "PACE";
                if (Request.QueryString["RedirectTo"] != null)
                {
                    string pageURL = HttpContext.Current.Request.Url.AbsoluteUri;
                    string redirectURL = FormsAuthentication.Decrypt(HttpContext.Current.Request.Url.AbsoluteUri.Split('?')[1].Split('&')[2].Split('=')[1]).Name;
                    Response.Redirect("~/" + redirectURL,false);
                }
                using (Cfi.App.CRM.Business.Login login = new Cfi.App.CRM.Business.Login())
                {
                    DataTable dtLogin = login.GetList("Login", "*", "LoginId='" + data[0] + "'");
                    if (dtLogin.Rows.Count > 0 && dtLogin != null)
                    {
                        Session["LoginSNo"] = dtLogin.Rows[0]["SNo"];
                    }
                    if (dtLogin != null && dtLogin.Rows.Count > 0)
                    {
                        using (UserLogin userLogin = new UserLogin())
                        {
                            userLogin.SNo = (int)dtLogin.Rows[0]["SNo"];
                            userLogin.SNo = (int)dtLogin.Rows[0]["SNo"];
                            Session["LoginDetails"] = userLogin;
                        }
                    }
                }
                InitializePage ip = new InitializePage();
                Session["Menu"] = ip.GenerateMenu(this);

                if (Request.QueryString["path"] != null)
                {
                    if (Session["UserID"] != null)
                    {
                        if (Session["LoginType"].ToString() == "MANAGER" || Session["LoginType"].ToString() == "ACCOUNTS MANAGER" || Session["LoginType"].ToString() == "ACCOUNTS EXECUTIVE")
                        {
                            BL.LoginId = txtUserName.Text;
                            DataSet dsHO = BL.getHOCompBrSNo();
                            try
                            {
                                Session["CompBrSNo"] = dsHO.Tables[0].Rows[0]["CompBrSNo"].ToString();
                                Session["InvoicePrefix"] = dsHO.Tables[0].Rows[0]["InvoicePrefix"].ToString();
                                Session["CompBrType"] = dsHO.Tables[0].Rows[0]["CompBrType"].ToString();
                                Session["CityCode"] = dsHO.Tables[0].Rows[0]["CityCode"].ToString();
                                Session["PlaceName"] = dsHO.Tables[0].Rows[0]["PlaceName"].ToString();
                                Session["CompName"] = dsHO.Tables[0].Rows[0]["CompName"].ToString();
                                if (Session["LoginType"].ToString() == "ACCOUNTS MANAGER" ||
                                    Session["LoginType"].ToString() == "ACCOUNTS EXECUTIVE")
                                    Response.Redirect("~/Cargo/DashBoardAccount.aspx", false);
                                else
                                    Response.Redirect("Home.aspx", false);
                            }
                            catch (Exception j)
                            {
                                Response.Redirect("Home.aspx");
                            }
                        }
                        else
                            Response.Redirect("Home.aspx");
                    }
                    String path = Request.QueryString["path"];
                    Response.Redirect(path);
                }
                else
                {
                    //Response.Redirect("Home.aspx");
                    if (Session["LoginType"].ToString() == "MANAGER" ||
                        Session["LoginType"].ToString() == "ACCOUNTS MANAGER" ||
                        Session["LoginType"].ToString() == "ACCOUNTS EXECUTIVE")
                    {
                        BL.LoginId = txtUserName.Text;
                        DataSet dsHO = BL.getHOCompBrSNo();
                        try
                        {
                            Session["CompBrSNo"] = dsHO.Tables[0].Rows[0]["CompBrSNo"].ToString();
                            Session["InvoicePrefix"] = dsHO.Tables[0].Rows[0]["InvoicePrefix"].ToString();
                            Session["CompBrType"] = dsHO.Tables[0].Rows[0]["CompBrType"].ToString();

                            Session["CityCode"] = dsHO.Tables[0].Rows[0]["CityCode"].ToString();
                            Session["PlaceName"] = dsHO.Tables[0].Rows[0]["PlaceName"].ToString();
                            Session["CompName"] = dsHO.Tables[0].Rows[0]["CompName"].ToString();

                            if (Session["LoginType"].ToString() == "ACCOUNTS MANAGER" ||
                                Session["LoginType"].ToString() == "ACCOUNTS EXECUTIVE")
                                Response.Redirect("~/Cargo/DashBoardAccount.aspx", false);
                            else
                                //Response.Redirect("~/Cargo/NewDashboard.aspx", false);

                                Response.Redirect("~/Cargo/AddExbDetails.aspx", false);
                        }
                        catch
                        {
                            Response.Redirect("Home.aspx"); 
                        }
                    }
                    else
                        Response.Redirect("Home.aspx", false);

                }
            }

        }
        catch (Exception ee)
        {
            Response.Redirect("Login.aspx");
        }
    }

    public string GenerateMenu(Page page)
    {
        bool menu = false;
        string path = string.Empty;

        if (HttpContext.Current.Request.Path.Contains("Login.aspx") || HttpContext.Current.Request.Path.Contains("Login.aspx") || HttpContext.Current.Request.Path.Contains("Login.aspx"))
        {
            path = HttpContext.Current.Request.Path.Replace("/Login.aspx", string.Empty).Replace("/Login.aspx", string.Empty).Replace("/Login.aspx", string.Empty);
            path = path.Replace("/Common", "").Replace("/common", "").Replace("/COMMON", "");
        }
        else
            return string.Empty;


        //if (HttpContext.Current.Request.Path.Contains("Default.aspx") || HttpContext.Current.Request.Path.Contains("default.aspx") || HttpContext.Current.Request.Path.Contains("DEFALUT.aspx"))
        //  path = HttpContext.Current.Request.Path.Replace("/Login.aspx", string.Empty).Replace("/Login.aspx", string.Empty).Replace("/Login.aspx", string.Empty);
        //else
        //  return string.Empty;
        StringBuilder strMenu = new StringBuilder();

        using (StoredProcedure myMenu = new StoredProcedure())
        {
            strMenu.Append("<div class=\"menuHeader\" id=\"divMenuHeader\">");
            strMenu.Append("<table class=\"menuTable\" >");
            strMenu.Append("<tr>");
            //strMenu.Append("<td>");
            //strMenu.Append("<div class=\"menuHomeDiv\" > <a href='Home.aspx'> ");
            //strMenu.Append("<img src=\"" + page.ResolveUrl("~/Images/home.png") + "\" border=0 /></a>");
            //strMenu.Append("</div>");
            //strMenu.Append("</td>");
            strMenu.Append("<td class=\"menuTdWidth\" >");
            strMenu.Append("<ul id=\"qm0\" class=\"qmmc\">");

            int i = 0;

            DataTable dtGetMenuList = myMenu.GetList("vPage", "distinct *", "LoginSno=" + ((UserLogin)HttpContext.Current.Session["LoginDetails"]).SNo);

            // DataTable dtGetMenuList = myMenu.GetList("Page", "*", "");
            DataRow[] drModuleArray = dtGetMenuList.Select("MenuSno IS NULL AND HyperLink IS NULL", "DisplayOrder ASC");

            foreach (DataRow drModule in drModuleArray)
            {
                i++;
                DataRow[] drAppCheck = dtGetMenuList.Select("MenuSno = " + drModule["Sno"], "DisplayOrder ASC");
                if (drAppCheck.Length > 0)
                {
                    if (menu == false)
                    {
                        strMenu.Append("<li><a href=\"javascript:void(0)\" style=\"font-weight:600;\">" + drModule["Name"] + "</a>");
                        menu = true;
                    }
                    else
                    {
                        strMenu.Append("<li><span class=\"qmdivider qmdividery\"></span></li>");
                        strMenu.Append("<li><a href=\"javascript:void(0)\" style=\"font-weight:600;\">" + drModule["Name"] + "</a>");
                    }

                    int menuID = Convert.ToInt32(drModule["Sno"]);
                    getSubMenu(menuID, ref dtGetMenuList, ref strMenu, path, page);
                }
            }

            strMenu.Append("</li><li class=\"qmclear\">&nbsp;</li></ul>");
            strMenu.Append("</td></tr></table></div><script type=\"text/javascript\">qm_create(0,false,0,250,false,false,false,false);</script>");
        }

        return strMenu.ToString();
    }

    private void getSubMenu(int MenuID, ref DataTable dtGetMenuList, ref StringBuilder strMenu, string path, Page page)
    {
        strMenu.Append("<ul type='Fixed'>");
        DataRow[] drSubMenuArray = dtGetMenuList.Select("MenuSno = " + MenuID.ToString(), "DisplayOrder ASC");
        foreach (DataRow drSubMenu in drSubMenuArray)
        {
            if (drSubMenu["HyperLink"].ToString() == string.Empty)
            {
                strMenu.Append("<li><a href=\"javascript:void(0)\">" + drSubMenu["Name"] + " <img src=\"" + page.ResolveUrl("~/Images/ci_weather_rightarrow.gif") + "\" style=\"border:0;\" /></a>");
                //strMenu.Append("<li><a href=\"javascript:void(0)\" style=\"font-weight:600;\">" + drSubMenu["Name"] + "</a>");
                getSubMenu(Convert.ToInt32(drSubMenu["SNo"]), ref dtGetMenuList, ref strMenu, path, page);
                strMenu.Append("</li>");
            }
            else
                strMenu.Append("<li><a href=" + path + drSubMenu["HyperLink"] + ">" + drSubMenu["Name"] + "</a></li>");
        }
        strMenu.Append("</ul>");
    }

    //protected void lnkBtnManualDownload_Click(object sender, EventArgs e)
    //{
    //    string filePath = Server.MapPath("./Cargo/Download/User Manual For Pace Power Application - Air Export.docx");
    //    string[] strarray = Path.GetFileName(filePath).Split('.');
    //    fileDownload(Path.GetFileName(filePath), filePath);
    //}
    //private void fileDownload(string fileName, string fileUrl)
    //{
    //    Page.Response.Clear();
    //    bool success = ResponseFile(Page.Request, Page.Response, fileName, fileUrl, 1024000);
    //    if (!success)
    //        Response.Write("Downloading Error!");
    //    Page.Response.End();

    //}
    //public static bool ResponseFile(HttpRequest _Request, HttpResponse _Response, string _fileName, string _fullPath, long _speed)
    //{
    //    try
    //    {
    //        FileStream myFile = new FileStream(_fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
    //        BinaryReader br = new BinaryReader(myFile);
    //        try
    //        {
    //            _Response.AddHeader("Accept-Ranges", "bytes");
    //            _Response.Buffer = false;
    //            long fileLength = myFile.Length;
    //            long startBytes = 0;

    //            int pack = 10240; //10K bytes
    //            int sleep = (int)Math.Floor((double)(1000 * pack / _speed)) + 1;
    //            if (_Request.Headers["Range"] != null)
    //            {
    //                _Response.StatusCode = 206;
    //                string[] range = _Request.Headers["Range"].Split(new char[] { '=', '-' });
    //                startBytes = Convert.ToInt64(range[1]);
    //            }
    //            _Response.AddHeader("Content-Length", (fileLength - startBytes).ToString());
    //            if (startBytes != 0)
    //            {
    //                _Response.AddHeader("Content-Range", string.Format(" bytes {0}-{1}/{2}", startBytes, fileLength - 1, fileLength));
    //            }
    //            _Response.AddHeader("Connection", "Keep-Alive");
    //            _Response.ContentType = "application/octet-stream";
    //            _Response.AddHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(_fileName, System.Text.Encoding.UTF8));

    //            br.BaseStream.Seek(startBytes, SeekOrigin.Begin);
    //            int maxCount = (int)Math.Floor((double)((fileLength - startBytes) / pack)) + 1;

    //            for (int i = 0; i < maxCount; i++)
    //            {
    //                if (_Response.IsClientConnected)
    //                {
    //                    _Response.BinaryWrite(br.ReadBytes(pack));
    //                    Thread.Sleep(sleep);
    //                }
    //                else
    //                {
    //                    i = maxCount;
    //                }
    //            }
    //        }
    //        catch
    //        {
    //            return false;
    //        }
    //        finally
    //        {
    //            br.Close();
    //            myFile.Close();
    //        }
    //    }
    //    catch
    //    {
    //        return false;
    //    }
    //    return true;
    //}
   
}

