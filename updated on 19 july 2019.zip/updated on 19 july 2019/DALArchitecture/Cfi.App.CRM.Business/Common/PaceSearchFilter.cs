﻿#region SeachFilter Class Description
/*
    *****************************************************************************
	Class Name      : SearchFilter      
	Purpose         : This class implements the functionality related to Search Filter information of current users.
					  This class provides functionality to Read/Create/Update/Delete the Search Filter Information  of current users.
	Company         : CargoFlash Infotech.
	Author          : Sudhir Yadav.
	Created On      : 19 Oct 2009.
    Update by       : Dilip Kumar.
    Update On       : 15 Mar 2010.
    Description     : Correct The ErrorMessage.    
	Approved By     : Sudhir Yadav.
	Approved On     : 20 Sep 2009.
    Update by       : Dilip KUmar.
    Update On       : 03 Apr 2010.
    Description     : Change error message.
    *****************************************************************************
	*/
#endregion



/// <summary>
///  This class provides attributes/properties and function which is used in save filter search.
/// </summary>

using System;
using System.Data;
using System.Collections;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Configuration;

namespace Cfi.App.CRM.Business
{

    /// <summary>
    /// This class implements the functionality related to Search Filter information of current users. This class provides functionality to Read/Create/Update/Delete the Search Filter Information  of current users.
    /// </summary>
    public class PaceSearchFilter : BaseBusinessSecureObject
    {
        public PaceSearchFilter()
        {
            InitializeEntity();
        }

        /// <summary>
        /// Method to set the default properties of the base entity i.e. BaseBusinessSecureObject.
        /// </summary>
        private void InitializeEntity()
        {
            PrimaryEntity = "SearchFilter";
            PrimaryKeyField = "SNo";
            PrimaryKeyValue = "0";
            UpdateFieldToExclude = "SNo";
            ConnectionString = ConfigurationManager.ConnectionStrings["RateConnectionString"].ConnectionString;
            NameSpacePrefix = "SearchFilter";
            DateFormat = "yyyy-MM-dd HH:mm:ss";
        }
        private string errorDescription;

        public string UserId { get; set; }

        public string ReportName { get; set; }

        public string FilterName { get; set; }

        public string FilterXml { get; set; }

        /// <summary>
        /// Method is used to create a New SearchFilter.
        /// When error occurs check SearchFilter.ErrorNo and SearchFilter.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing values of new record to be created</param>
        /// <returns>0 - (int)ResultType.Success,
        /// 1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public override int DoCreate(DataTable dtCurrentRecord)
        {

            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordisNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordnotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get the table schema structure for create statement in Sys_ProcessDocument method
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.TableSource.Columns.Remove(PrimaryKeyField);
                        dt.DateFormat = DateFormat;
                        string schema = dt.GetColumnSchema();

                        //Get the record values from the current table to be used in Sys_ProcessDocument method
                        string recordValues = dt.GetDMLRecordValues();

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }
                        //Call Sys_ProcessDocument method to Create a new record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, schema, recordValues, "A");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to update a SearchFilter.
        /// When error occures check SearchFilter.ErrorNo and SearchFilter.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing updated values</param>
        /// <returns >0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message 
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordisNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordnotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get update DML string to be used for update statement by Sys_ProcessDocument API
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        string updateDML = dt.TableToUpdateDML();

                        //Frame where condition for updating the record in the database
                        WhereCondition = PrimaryKeyField + "=" + PrimaryKeyValue;

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        //Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML, WhereCondition, "U");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a SearchFilter. 
        /// When error occures check SearchFilter.ErrorNo and SearchFilter.errorDescription 
        /// for actual error. 
        /// </summary>    
        /// <param name="Sno">FeatureID of Current SeachFilter</param> 
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public override int DoDelete(int Sno)
        {
            try
            {
                //Check if Sno is less than 1 then reflect error number and error message
                if (Sno <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:InvalidSno";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Frame where condition for checking the non existence of Current SeachFilter in the database
                    WhereCondition = PrimaryKeyField + "=" + Sno;

                    //Call method Sys_GetRecordCount to check whether Current SeachFilter doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);

                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if Current SeachFilter doesn't exists in the database then reflect error number and error message
                    if (dtRecord.Rows.Count == 0)
                    {
                        ErrorMessage = "GetLocalResourceObject:SnonotExist";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }
                    if (TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }
                    //Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, "", WhereCondition, "D");

                    //Check if ResultValue is failed then reflect error number and error message
                    if (resultValue == (int)ResultType.Failed)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = "GetLocalResourceObject:" + ErrorNumber;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to get a SeachFilter List for a Client. 
        /// When error occurs check SearchFilter.ErrorNo and SearchFilter.errorDescription for actual error. 
        /// </summary>
        /// <param name="sNo">SNo of Current Table</param>
        /// <returns>DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.</returns>
        public override DataTable DoRead(int sNo)
        {
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();
                try
                {
                    //Frame where condition for getting the SeachFilter record from the database
                    WhereCondition = PrimaryKeyField + "=" + sNo;

                    //Call method GetList to get the SeachFilter record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:dtisNull";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }
    }
}