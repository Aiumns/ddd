﻿using System;
using System.Data;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Configuration;

namespace Cfi.App.CRM.Business.Common
{
    public class WalkingCustomers : BaseBusinessSecureObject
    {
        private string errorDescription = string.Empty;

        /// <summary>
        /// Constructor: Initializes a new instance of WalkingCustomers class. 
        /// </summary>
        public WalkingCustomers() { InitializeEntity(); }

        /// <summary>
        /// Constructor: Initializes a new instance of the Cfi.SoftwareFactory.Application.StoredProcedure class.
        /// </summary>
        /// <param name="sqlTransaction"></param>
        public WalkingCustomers(SqlTransaction sqlTransaction)
        {
            InitializeEntity();

            //if Connection string is blank raise error
            if (string.IsNullOrEmpty(ConnectionString))
                throw new Exception("ConnectionString string is blank! ConnectionString string is required.");

            //if Transaction is noting or is empty raise error
            if (sqlTransaction == null)
                throw new Exception("NULL sqlTransaction! sqlTransaction is required.");

            //Set sqlTransaction to Transaction
            Transaction = sqlTransaction;

            //Set Enabled the Transaction
            TransactionEnabled = true;
        }

        ///<summary>
        /// Destructor: Cleanup the WalkingCustomers Objects 
        /// </summary>
        ~WalkingCustomers()
        {
            //Cleanup of the Enviroment Objects
            Dispose();
        }

        /// <summary>
        /// Dispose all objects of WalkingCustomers class.  
        /// </summary>
        public override void Dispose()
        {
            //Calling dispose method of BaseBusinessSecureObject Class to release memory occupied 
            //by WalkingCustomers class objects.
            base.Dispose();
            //Prevent the clean-up code for the objects from being called twice
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Method to set the default properties of the base entity i.e. BaseBusinessSecureObject.
        /// </summary>
        private void InitializeEntity()
        {
            PrimaryEntity = "WalkinCustomers";
            PrimaryKeyField = "SNo";
            PrimaryKeyValue = "0";
            UpdateFieldToExclude = "SNo";
            //string connectionString = ConfigurationManager.ConnectionStrings["RateConnectionString"].ConnectionString;
            //SqlConnection con = new SqlConnection(connectionString);
            //con.Open();
            ConnectionString = ConfigurationManager.ConnectionStrings["RateConnectionString"].ConnectionString;
            DateFormat = "yyyy-MM-dd HH:mm:ss";
            WhereConditionField = UpdateFieldToExclude;
        }

        /// <summary>
        /// Method is used to create a New WalkingCustomers.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing values of new record to be created</param>
        /// <returns>0 - (int)ResultType.Success,
        /// 1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public override int DoCreate(DataTable dtCurrentRecord)
        {
            string schema;
            string recordValues;
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message
                if (dtCurrentRecord == null)
                {
                    errorDescription = "WalkingCustomers.DoCreate:WalkingCustomers can not be left blank.";
                    GetErrorMessage(errorDescription);
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    errorDescription = "WalkingCustomers.DoCreate:Record not Found.";
                    GetErrorMessage(errorDescription);
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get the table schema structure for create statement in Sys_ProcessDocument method
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.TableSource.Columns.Remove(PrimaryKeyField);
                        dt.DateFormat = DateFormat;
                        schema = dt.GetColumnSchema();

                        //Get the record values from the current table to be used in Sys_ProcessDocument method
                        recordValues = dt.GetDMLRecordValues();

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }
                        //Call Sys_ProcessDocument method to Create a new record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, schema, recordValues, "A");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            errorDescription = "WalkingCustomers.DoCreate:Empty result value.";
                            GetErrorMessage(errorDescription);
                            return (int)ResultType.Failed;
                        }
                        SequenceName = storedProcedure.SequenceNumber;
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "WalkingCustomers:Server Link Failure.Please Try Later.";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                errorDescription = null;
            }
        }

        ///<summary>
        ///Method is used to update a WalkingCustomers.
        ///</summary>    
        ///<param name="dtCurrentRecord">Table containing updated values</param>
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {

            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message 
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "WalkingCustomers:Walking Customers can not be left blank.";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "WalkingCustomers:Record can not found.";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }


                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get update DML string to be used for update statement by Sys_ProcessDocument API
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        dt.WhereConditionField = WhereConditionField;
                        string[] updateDML = dt.TableToUpdateWhereDML();

                        //Frame where condition for updating the record in the database
                        WhereCondition = PrimaryKeyField + "=" + PrimaryKeyValue;

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        //Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML[0], updateDML[1], "U");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "WalkingCustomers:Empty result value.";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "WalkingCustomers:Server Link Failure.Please Try Later.";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a WalkingCustomers. 
        /// </summary>    
        /// <param name="Sno">FeatureID of Current WalkingCustomers</param> 
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public override int DoDelete(int Sno)
        {
            try
            {
                //Check if Sno is less than 1 then reflect error number and error message
                if (Sno <= 0)
                {
                    ErrorMessage = "WalkingCustomers:Not a valid record.";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Frame where condition for checking the non existence of Current WalkingCustomers in the database
                    WhereCondition = PrimaryKeyField + "=" + Sno;

                    //Call method Sys_GetRecordCount to check whether Current WalkingCustomers doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);

                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if Current WalkingCustomers doesn't exists in the database then reflect error number and error message
                    if (dtRecord.Rows.Count == 0)
                    {
                        ErrorMessage = "WalkingCustomers:WalkingCustomers does not exist.";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }
                    if (TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }
                    //Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, "", WhereCondition, "D");

                    //Check if ResultValue is failed then reflect error number and error message
                    if (resultValue == (int)ResultType.Failed)
                    {
                        ErrorMessage = "WalkingCustomers:Empty result value.";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "WalkingCustomers:Server Link Failure.Please Try Later.";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }


    }

}
