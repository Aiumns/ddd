﻿/*CompetitorMovement Business Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This class implements the functionality related to CompetitorMovement.
 * Created By           :   Dhiraj kumar.
 * Created On           :   19 May 2010.
 * Modified By          :   
 * Modified On          :   

 */

using System;
using System.Data;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;

namespace Cfi.App.CRM.Business
{
    /// <summary>
    /// Class to implement the functionality related to competitorMovement.
    /// </summary>
    public class CompetitorMovement : BaseBusinessSecureObject
    {
        /// <summary>
        /// String to represent the error description.
        /// </summary>
        private string errorDescription = string.Empty;

        /// <summary>
        /// Constructor: Initializes a new instance of CompetitorMovement class. 
        /// </summary>
        public CompetitorMovement() { InitializeEntity(); }

        /// <summary>
        /// Constructor: Initializes a new instance of the Cfi.SoftwareFactory.Application.StoredProcedure class.
        /// </summary>
        /// <param name="sqlTransaction"></param>
        public CompetitorMovement(SqlTransaction sqlTransaction)
        {
            InitializeEntity();

            //if Connection string is blank raise error
            if (string.IsNullOrEmpty(ConnectionString))
                throw new Exception("ConnectionString string is blank! ConnectionString string is required.");

            //if Transaction is noting or is empty raise error
            if (sqlTransaction == null)
                throw new Exception("NULL sqlTransaction! sqlTransaction is required.");

            //Set sqlTransaction to Transaction
            Transaction = sqlTransaction;

            //Set Enabled the Transaction
            TransactionEnabled = true;
        }

        /// <summary>
        /// Method to set the default properties of the base entity i.e. BaseBusinessSecureObject.
        /// </summary>
        private void InitializeEntity()
        {
            PrimaryEntity = "CRMCompetitorMovement";
            PrimaryKeyField = "SNo";
            PrimaryKeyValue = "";
            UpdateFieldToExclude = "SNo";
            ConnectionString = SoftwareFactory.Data.ConnectionString.WebConfigConnectionString;
            NameSpacePrefix = "CRMCompetitorMovement";
            DateFormat = "yyyy-MM-dd HH:mm:ss";
        }

        /// <summary>
        /// This function is used for validating the business objects.
        /// </summary>
        /// <param name="dtCurrentRecord">dtCurrentRecord contains current record.</param>
        /// <param name="currentDataOperation">CurrentDataOperation contains current operation.</param>
        /// <returns>This return Zero(0) if success or One(1) if failed. 
        /// </returns>
        protected override int ValidateBusinessRule(DataTable dtCurrentRecord, DataOperation currentDataOperation)
        {
           
            string SNo = dtCurrentRecord.Rows[0]["SNo"].ToString();

            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                try
                {
                    int count;
                    switch (currentDataOperation)
                    {
                        //Check Business Rule before creating a record
                        //*************************************************************
                        case DataOperation.Create:

                            //Check SNo is blank then raise error.
                            if (string.IsNullOrEmpty(SNo))
                            {
                                ErrorMessage = "GetLocalResourceObject:SNocannotbeblank";
                                ErrorNumber = 1;
                                return (int)ResultType.Failed;
                            }

                          //  Call method Sys_GetRecordCount to check whether Current EmployeeName doesn't exists in the database
                            WhereCondition = "SNo='" + SNo+"'" ;
                            count = storedProcedure.Sys_GetRecordCount(PrimaryEntity, PrimaryKeyField, WhereCondition);
                            if (count > 0)
                            {
                                ErrorMessage = "GetLocalResourceObject:SNoAlreadyExists";
                                ErrorNumber = 1;
                                return (int)ResultType.Failed;
                            }

                            dtCurrentRecord.AcceptChanges();
                            return (int)ResultType.Success;

                        //Check Business Rule before Deleting a record
                        //*************************************************************

                        case DataOperation.Delete:
                            return (int)ResultType.Success;

                        //Check Business Rule before Updating a record
                        //*************************************************************

                        case DataOperation.Update:

                            if (dtCurrentRecord.Rows[0][PrimaryKeyField] != null)
                                PrimaryKeyValue = dtCurrentRecord.Rows[0][PrimaryKeyField].ToString();

                            //Call method Sys_GetRecordCount to check whether Current SNo doesn't exists in the database
                            WhereCondition = "SNo<>'" + PrimaryKeyValue + "' AND SNo='" + SNo + "'";
                            count = storedProcedure.Sys_GetRecordCount(PrimaryEntity, PrimaryKeyField, WhereCondition);
                            if (count > 0)
                            {
                                ErrorMessage = "GetLocalResourceObject:SNoAlreadyExists";
                                ErrorNumber = 1;
                                return (int)ResultType.Failed;
                            }

                            dtCurrentRecord.AcceptChanges();
                            return (int)ResultType.Success;

                        //Check Business Rule before Reading a record
                        //*************************************************************

                        case DataOperation.View:
                            return (int)ResultType.Success;

                        //Check Business Rule for conditions other than Create, Update, Delete and Read 
                        //*************************************************************

                        default:
                            return (int)ResultType.Failed;
                    }
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                finally
                {
                    //Check if dtCurrentRecord is not null then dispose it
                    dtCurrentRecord.Dispose();
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// Method is used to create a New CompetitorMovement.
        /// When error occurs check CompetitorMovement.ErrorNo and CompetitorMovement.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing values of new record to be created</param>
        /// <returns>0 - (int)ResultType.Success,
        /// 1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public override int DoCreate(DataTable dtCurrentRecord)
        {
            string schema;
            string recordValues;
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get the table schema structure for create statement in Sys_ProcessDocument method
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.TableSource.Columns.Remove(PrimaryKeyField);
                        schema = dt.GetColumnSchema();

                        //Get the record values from the current table to be used in Sys_ProcessDocument method
                        recordValues = dt.GetDMLRecordValues();

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }
                        //Call Sys_ProcessDocument method to Create a new record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, schema, recordValues, "A");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to update a CompetitorMovement.
        /// When error occures check CompetitorMovement.ErrorNo and CompetitorMovement.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing updated values</param>
        /// <returns >0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message 
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if Business Rule validation fails then return (int)ResultType.Failed
                if (ValidateBusinessRule(dtCurrentRecord, DataOperation.Update) == (int)ResultType.Failed)
                    return (int)ResultType.Failed;
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get update DML string to be used for update statement by Sys_ProcessDocument API
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        string updateDML = dt.TableToUpdateDML();

                        //Frame where condition for updating the record in the database
                        WhereCondition = PrimaryKeyField + "='" + PrimaryKeyValue + "'";

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        //Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML, WhereCondition, "U");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a CompetitorMovement. 
        /// When error occures check CompetitorMovement.ErrorNo and CompetitorMovement.errorDescription 
        /// for actual error. 
        /// </summary>    
        /// <param name="code">FeatureID of Current CompetitorMovement</param> 
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public override int DoDelete(string code)
        {
            try
            {
                //Check if Sno is less than 1 then reflect error number and error message
                if (string.IsNullOrEmpty(code))
                {
                    ErrorMessage = "GetLocalResourceObject:InvalidCompetitorMovementCode";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Frame where condition for checking the non existence of Current CompetitorMovement in the database
                    WhereCondition = PrimaryKeyField + "='" + code + "'";

                    //Call method Sys_GetRecordCount to check whether Current CompetitorMovement doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);

                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if Current CompetitorMovement doesn't exists in the database then reflect error number and error message
                    if (dtRecord.Rows.Count == 0)
                    {
                        ErrorMessage = "GetLocalResourceObject:CompetitorMovementCodeNotExists";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }
                    if (TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }
                    //Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, "", WhereCondition, "D");

                    //Check if ResultValue is failed then reflect error number and error message
                    if (resultValue == (int)ResultType.Failed)
                    {
                        ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to get a CompetitorMovement List for a Client. 
        /// When error occurs check CompetitorMovement.ErrorNo and CompetitorMovement.errorDescription for actual error. 
        /// </summary>
        /// <param name="code">Primary key string type of Current Table.</param>
        /// <returns>DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.</returns>
        public override DataTable DoRead(string code)
        {

            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    //Frame where condition for getting the CompetitorMovement record from the database
                    WhereCondition = PrimaryKeyField + "='" + code + "'";

                    //Call method GetList to get the CompetitorMovement record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:CompetitorMovementCodeNotExists";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// Method is used to get a CompetitorMovement List for a Client. 
        /// When error occurs check CompetitorMovement.ErrorNo and CompetitorMovement.errorDescription for actual error. 
        /// </summary>
        /// <param name="code">Primary key integer type of Current Table.</param>
        /// <returns>DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.</returns>
        public override DataTable DoRead(int code)
        {

            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    //Frame where condition for getting the CompetitorMovement record from the database
                    WhereCondition = PrimaryKeyField + "=" + code;

                    //Call method GetList to get the CompetitorMovement record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:CompetitorMovementCodeNotExists";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// Method is used to get CompetitorMovement List. 
        /// </summary>
        /// <returns>DataTable list of CompetitorMovement</returns>
        public DataTable GetCompetitorMovement()
        {
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();
                try
                {
                    //Frame where condition for getting the CompetitorMovement record from the database
                    WhereCondition = "";

                    //Call method GetList to get the CompetitorMovement record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "SNo,SNo", WhereCondition);

                    //Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:CompetitorMovementCodeNotExists";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }
    }
}