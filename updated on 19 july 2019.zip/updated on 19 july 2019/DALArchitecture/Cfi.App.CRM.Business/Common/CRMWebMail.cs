﻿/*
   
   Class Name           : CRMWebMail      
   Purpose              : This class implements the functionality related to web mail information.
                          This class provides functionality to Read/Create/Update/Delete the web mail.
   Company              : CargoFlash Infotech
   Author               : Ashutosh Kumar
   Created On           : 25 May 2010.	  
     
   */
using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;

namespace Cfi.App.CRM.Business
{
   public class CRMWebMail : BaseBusinessSecureObject
    {
        // **********************************************************************************************************    
        //Local Internal variables    
        private string errorDescription = string.Empty;
        // **********************************************************************************************************

        #region Constructor Definitation

        /// <summary>
        /// Constructor: Initializes a new instance of .CRMWebMail class. 
        /// </summary>
        public CRMWebMail()
        {
            //Call the Initialize API to set the Variables.
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            Initialize();
            // ReSharper restore DoNotCallOverridableMethodsInConstructor
        }

        /// <summary>
        /// Constructor: Initializes a new instance of the Cfcrm.SoftwareFactory.Application.StoredProcedure class.
        /// </summary>
        /// <param name="sqlTransaction"></param>
        public CRMWebMail(SqlTransaction sqlTransaction)
        {
            //Call the Initialize API to set the Variables.
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            Initialize();
            // ReSharper restore DoNotCallOverridableMethodsInConstructor

            //if Connection string is blank raise error
            if (string.IsNullOrEmpty(ConnectionString))
                throw new Exception("ConnectionString string is blank! ConnectionString string is required.");

            //if Transaction is noting or is empty raise error
            if (sqlTransaction == null)
                throw new Exception("NULL sqlTransaction! sqlTransaction is required.");


            //Set sqlTransaction to Transaction
            Transaction = sqlTransaction;

            //Set Enabled the Transaction
            TransactionEnabled = true;
        }

        #endregion

        #region Destructor Definition

        //Default Destructor 
        /// <summary>
        /// Destructor: Cleanup the CRMWebMail Objects 
        /// </summary>
        ~CRMWebMail()
        {
            //Cleanup of the Enviroment Objects
            Dispose();
        } //End of method.

        #endregion

        #region DisposeMethod

        /// <summary>
        /// Dispose all objects of CRMWebMail class.  
        /// </summary>
        public override void Dispose()
        {
            //Calling dispose method of BaseBusinessSecureObject Class to release memory occupied 
            //by CRMWebMail class objects.
            base.Dispose();
            //Prevent the clean-up code for the objects from being called twice
            GC.SuppressFinalize(this);
        } //End of method.

        #endregion

        #region Initialize

        public void Initialize()
        {
            PrimaryEntity = "CRMWebMail";
            PrimaryKeyField = "SNo";
            PrimaryKeyValue = "";
            UpdateFieldToExclude = "SNo";
            ConnectionString = SoftwareFactory.Data.ConnectionString.WebConfigConnectionString;
            NameSpacePrefix = "CRMWebMail";
            DateFormat = "yyyy-MM-dd HH:mm:ss";
            WhereConditionField = UpdateFieldToExclude;

        }

        #endregion

        #region CheckBusinessRule

        /// <summary>
        /// This function is used for validating the business objects.
        /// </summary>
        /// <param name="dtCurrentRecord">dtCurrentRecord contains current record.</param>
        /// <param name="currentDataOperation">CurrentDataOperation contains current operation.</param>
        /// <returns>This return Zero(0) if success or One(1) if failed. 
        /// </returns>
        protected override int ValidateBusinessRule(DataTable dtCurrentRecord, DataOperation currentDataOperation)
        {
            //string sno = dtCurrentRecord.Rows[0]["SNo"].ToString();
            //string groupName = dtCurrentRecord.Rows[0]["GroupName"].ToString();
            //using (StoredProcedure storedProcedure = new StoredProcedure())
            //{
            //    try
            //    {
            //        int count;
            //        switch (currentDataOperation)
            //        {
            //            //Check Business Rule before creating a record
            //            //*************************************************************
            //            case DataOperation.Create:

            //                //Check employeeName is blank then raise error.
            //                if (string.IsNullOrEmpty(sno))
            //                {
            //                    errorDescription = "CRMWebMail.ValidateBusinessRule:CRMWebMail Name can not be blank.";
            //                    GetErrorMessage(errorDescription);
            //                    return (int)ResultType.Failed;
            //                }

            //                //Call method Sys_GetRecordCount to check whether Current EmployeeName doesn't exists in the database
            //                count = storedProcedure.Sys_GetRecordCount(PrimaryEntity, PrimaryKeyField,
            //                                                             WhereCondition);
            //                if (count > 0)
            //                {
            //                    errorDescription = "CRMWebMail.ValidateBusinessRule:CRMWebMail Name already exists";
            //                    GetErrorMessage(errorDescription);
            //                    return (int)ResultType.Failed;
            //                }

            //                dtCurrentRecord.AcceptChanges();
            return (int)ResultType.Success;

            //            //Check Business Rule before Deleting a record
            //            //*************************************************************

            //            case DataOperation.Delete:
            //                return (int)ResultType.Success;

            //            //Check Business Rule before Updating a record
            //            //*************************************************************

            //            case DataOperation.Update:

            //                if (dtCurrentRecord.Rows[0][PrimaryKeyField] != null)
            //                    PrimaryKeyValue = dtCurrentRecord.Rows[0][PrimaryKeyField].ToString();

            //                //Call method Sys_GetRecordCount to check whether Current EmployeeName doesn't exists in the database
            //                WhereCondition = "GroupName='" + groupName + "'";
            //                count = storedProcedure.Sys_GetRecordCount(PrimaryEntity, PrimaryKeyField,
            //                                                             WhereCondition);
            //                if (count > 0)
            //                {
            //                    errorDescription = "CRMWebMail.ValidateBusinessRule:CRMWebMail Name already exists";
            //                    GetErrorMessage(errorDescription);
            //                    return (int)ResultType.Failed;
            //                }

            //                dtCurrentRecord.AcceptChanges();
            //                return (int)ResultType.Success;

            //            //Check Business Rule before Reading a record
            //            //*************************************************************

            //            case DataOperation.View:
            //                return (int)ResultType.Success;

            //            //Check Business Rule for conditions other than Create, Update, Delete and Read 
            //            //*************************************************************

            //            default:
            //                return (int)ResultType.Failed;
            //        }
            //    }
            //    catch (Exception)
            //    {
            //        //Check if Exception in ValidateBusinessRule then reflect error number and error message
            //        errorDescription = "CRMWebMail.ValidateBusinessRule: Exception in ValidateBusinessRule";
            //        GetErrorMessage(errorDescription);
            //        return (int)ResultType.Failed;
            //    }
            //    finally
            //    {
            //        //Check if dtCurrentRecord is not null then dispose it
            //        dtCurrentRecord.Dispose();
            //        WhereCondition = null; //Assign NULL to WhereCondition
            //        errorDescription = null; //Assign NULL to errorDescription
            //    }
            //}
        }

        #endregion

        #region DoCreate

        /// <summary>
        /// This function is used to create a New CRMWebMail.
        /// When error occurs check CRMWebMail.ErrorNo and CRMWebMail.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing values of new record to be created</param>
        /// <returns>0 - (int)ResultType.Success,
        /// 1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public override int DoCreate(DataTable dtCurrentRecord)
        {
            /*
            *****************************************************************************
            Class Name:       CRMWebMail
            Purpose:          This function is used to create a CRMWebMail.
            Company:          CargoFlash InfoTech
            Author:           
            Created On:       
            *****************************************************************************
            */

            //Local variables.
            //Variable to read Schema from dt table
            string schema;

            //Variable to read RecordValues from dt table
            string recordValues;

            //variable to assign the result value after the creation of the record.

            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message
                if (dtCurrentRecord == null)
                {
                    errorDescription = "CRMWebMail.DoCreate:Record is Null";
                    GetErrorMessage(errorDescription);
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    errorDescription = "CRMWebMail.DoCreate:Record not Found";
                    GetErrorMessage(errorDescription);
                    return (int)ResultType.Failed;
                }


                //Create a new instance of StoreProcedure
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get the table schema structure for create statement in Sys_ProcessDocument method
                    //Records_Fields = Schema
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        //  dt.TableSource.Columns.Remove(PrimaryKeyField);
                        dt.DateFormat = DateFormat;
                        schema = dt.GetColumnSchema();

                        //Get the record values from the current table to be used in Sys_ProcessDocument method
                        //Records_Values = RecordValues
                        recordValues = dt.GetDMLRecordValues();

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }
                        //Call Sys_ProcessDocument method to Create a new record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, schema, recordValues, "A");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            errorDescription = "CRMWebMail.DoCreate:Empty ResultValue";
                            GetErrorMessage(errorDescription);
                            return (int)ResultType.Failed;
                        }
                        SequenceName = storedProcedure.SequenceNumber;
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception)
            {
                //Check if Exception in ValidateBusinessRule then reflect error number and error message
                errorDescription = "CRMWebMail.DoCreate: Exception in DoCreate";
                GetErrorMessage(errorDescription);
                return (int)ResultType.Failed;
            }
            finally
            {
                //Check if dtCurrentRecord is not null then dispose it 
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();

                //Dispose local and global variables
                errorDescription = null; //Assign NULL to errorDescription
            }
        } //End of method.

        #endregion

        #region DoUpdate

        /// <summary>
        /// This function is used to update a CRMWebMail.
        /// When error occures check CRMWebMail.ErrorNo and CRMWebMail.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing updated values</param>
        /// <returns >0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {
            /*
              *****************************************************************************
              Class Name:     CRMWebMail
              Purpose:        It is used to update a CRMWebMail record.
              Company:        CargoFlash InfoTech
              Author:         
              Created On:       
              *****************************************************************************
              */

            //Variable to read UpdateDML from dt table

            //variable for assign result after upation of the record.

            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message 
                if (dtCurrentRecord == null)
                {
                    errorDescription = "CRMWebMail.DoUpdate:Record is Null";
                    GetErrorMessage(errorDescription);
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    errorDescription = "CRMWebMail.DoUpdate:Record Not Found";
                    GetErrorMessage(errorDescription);
                    return (int)ResultType.Failed;
                }

                //Create a new instance of StoreProcedure
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get update DML string to be used for update statement by Sys_ProcessDocument API
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        if (dtCurrentRecord.Columns.Contains("SNo"))
                            dtCurrentRecord.Columns.Remove("SNo");
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        string updateDML = dt.TableToUpdateDML();

                        //Frame where condition for updating the record in the database
                        WhereCondition = PrimaryKeyField + "='" + PrimaryKeyValue + "'";

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        //Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML, WhereCondition, "U");
                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            errorDescription = "CRMWebMail.DoUpdate:Empty ResultValue";
                            GetErrorMessage(errorDescription);
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception)
            {
                //Check if Exception in ValidateBusinessRule then reflect error number and error message
                errorDescription = "CRMWebMail.DoUpdate: Exception in DoUpdate";
                GetErrorMessage(errorDescription);
                return (int)ResultType.Failed;
            }
            finally
            {
                //Check if dtCurrentRecord is not null then dispose it 
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();

                //Dispose local and global variables
                WhereCondition = null; //Assign NULL to WhereCondition
                errorDescription = null; //Assign NULL to errorDescription
            }
        } //End of method.

        #endregion

        #region DoDelete

        /// <summary>
        /// This function is used to delete a CRMWebMail. 
        /// When error occures check CRMWebMail.ErrorNo and CRMWebMail.errorDescription 
        /// for actual error. 
        /// </summary>    
        /// <param name="Sno">FeatureID of Current CRMWebMail</param> 
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public override int DoDelete(int Sno)
        {
            /*
             *****************************************************************************
             Class Name:    CRMWebMail
             Purpose:       This function is used to delete a CRMWebMail.
             Company:       CargoFlash InfoTech
             Author:        
             Created On:     
             *****************************************************************************
             */

            //Local variables

            //variable for assign values after deletion of the current record.
            try
            {
                //Check if Sno is less than 1 then reflect error number and error message
                if (Sno <= 0)
                {
                    errorDescription = "CRMWebMail.DoDelete:Invalid Sno";
                    GetErrorMessage(errorDescription);
                    return (int)ResultType.Failed;
                }
                //Create a new instance of StoreProcedure
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Frame where condition for checking the non existence of Current CRMWebMail in the database
                    WhereCondition = "SNo=" + Sno;

                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if Current CRMWebMail doesn't exists in the database then reflect error number and error message
                    if (dtRecord.Rows.Count == 0)
                    {
                        errorDescription = "CRMWebMail.DoDelete:Sno not Exist";
                        GetErrorMessage(errorDescription);
                        return (int)ResultType.Failed;
                    }
                    if (TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }
                    //Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, "", WhereCondition, "D");

                    //Check if ResultValue is failed then reflect error number and error message
                    if (resultValue == (int)ResultType.Failed)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = storedProcedure.ErrorMessage;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception)
            {
                //Check if Exception in ValidateBusinessRule then reflect error number and error message
                errorDescription = "CRMWebMail.DoDelete: Exception in DoDelete";
                GetErrorMessage(errorDescription);
                return (int)ResultType.Failed;
            }
            finally
            {
                //Dispose local and global variables
                WhereCondition = null; //Assign NULL to WhereCondition
                errorDescription = null; //Assign NULL to errorDescription
            }
        } //End of method.

        #endregion

        #region DoRead

        /// <summary>
        /// This function is used to get a CRMWebMail List for a Client. 
        /// When error occurs check CRMWebMail.ErrorNo and CRMWebMail.errorDescription for actual error. 
        /// </summary>
        /// <param name="sNo">SNo of Current Table</param>
        /// <returns>DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.</returns>
        public override DataTable DoRead(int sNo)
        {
            /*
            *****************************************************************************
            Class Name:       CRMWebMail  
            Purpose:          This function is used to get the list of CRMWebMail.
            Company:          CargoFlash InfoTech
            Author:           
            Created On:       
            *****************************************************************************
            */

            //Create a new instance of StoreProcedure
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    //Frame where condition for getting the CRMWebMail record from the database
                    WhereCondition = "SNo" + "=" + sNo;

                    //Call method GetList to get the CRMWebMail record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        errorDescription = "CRMWebMail.DoRead:dt is Null";
                        GetErrorMessage(errorDescription);
                        return dt;
                    }
                    else
                    {
                        //return data table.
                        return dt;
                    }
                }
                catch (Exception)
                {
                    //Check if Exception in ValidateBusinessRule then reflect error number and error message
                    errorDescription = "CRMWebMail.DoRead: Exception in DoRead";
                    GetErrorMessage(errorDescription);
                    return dt;
                }
                finally
                {
                    //Dispose local and global variables
                    WhereCondition = null; //Assign NULL to WhereCondition
                    errorDescription = null; //Assign NULL to errorDescription
                }
            }
        } //End of method.
        #endregion
        /// <summary>
        /// Used to update case file if any.
        /// </summary>
        /// <param name="caseSno"></param>
        /// <param name="caseFile"></param>
        /// <returns></returns>
        public int UpdateForAttachment(int webMailSno, byte[] attachmentFile,string fileType)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[3];
                SqlParameter paramSNo = new SqlParameter("@SNo", SqlDbType.Int);
                paramSNo.Value = webMailSno;
                sqlParams[0] = paramSNo;
                SqlParameter paramFile = new SqlParameter("@AttachmentFile", SqlDbType.VarBinary);
                paramFile.Value = attachmentFile;
                sqlParams[1] = paramFile;
                SqlParameter paramFileType = new SqlParameter("@FileType", SqlDbType.VarChar);
                paramFileType.Value = fileType;
                sqlParams[2] = paramFileType;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "CRMWebMailUpdateAttachment", sqlParams);
                return (int)ResultType.Success;
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }

        }

    } //End of Class.
}
