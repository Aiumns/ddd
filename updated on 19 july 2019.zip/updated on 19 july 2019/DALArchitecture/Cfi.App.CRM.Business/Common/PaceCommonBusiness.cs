﻿using System;
using System.Data;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using System.Configuration;
namespace  Cfi.App.CRM.Business
{
    public class PaceCommonBusiness : BaseBusinessSecureObject
    {
 private string errorDescription = string.Empty;

        /// <summary>
        /// Constructor: Initializes a new instance of CommonBusiness class. 
        /// </summary>
        public PaceCommonBusiness() { InitializeEntity(); }

        /// <summary>
        /// Constructor: Initializes a new instance of the Cfi.SoftwareFactory.Application.StoredProcedure class.
        /// </summary>
        /// <param name="sqlTransaction"></param>
        public PaceCommonBusiness(SqlTransaction sqlTransaction)
        {
            InitializeEntity();

            //if Connection string is blank raise error
            if(string.IsNullOrEmpty(ConnectionString))
                throw new Exception("ConnectionString string is blank! ConnectionString string is required.");

            //if Transaction is noting or is empty raise error
            if(sqlTransaction == null)
                throw new Exception("NULL sqlTransaction! sqlTransaction is required.");

            //Set sqlTransaction to Transaction
            Transaction = sqlTransaction;

            //Set Enabled the Transaction
            TransactionEnabled = true;
        }

        ///<summary>
        /// Destructor: Cleanup the CommonBusiness Objects 
        /// </summary>
        ~PaceCommonBusiness()
        {
            //Cleanup of the Enviroment Objects
            Dispose();
        }

        /// <summary>
        /// Dispose all objects of CommonBusiness class.  
        /// </summary>
        public override void Dispose()
        {
            //Calling dispose method of BaseBusinessSecureObject Class to release memory occupied 
            //by CommonBusiness class objects.
            base.Dispose();
            //Prevent the clean-up code for the objects from being called twice
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Method to set the default properties of the base entity i.e. BaseBusinessSecureObject.
        /// </summary>
        private void InitializeEntity()
        {           
            PrimaryEntity = "";
            PrimaryKeyField = "";
            PrimaryKeyValue = "";
            UpdateFieldToExclude = "SNo";
            ConnectionString = ConfigurationManager.ConnectionStrings["RateConnectionString"].ConnectionString;
            NameSpacePrefix = "";
            DateFormat = "yyyy-MM-dd HH:mm:ss";
            WhereCondition = "";
        }

        /// <summary>
        /// Method is used to create a New CommonBusiness.
        /// When error occurs check CommonBusiness.ErrorNo and CommonBusiness.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing values of new record to be created</param>
        /// <returns>0 - (int)ResultType.Success,
        /// 1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public override int DoCreate(DataTable dtCurrentRecord)
        {
            string schema = string.Empty;
            string recordValues = string.Empty;
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message
                if(dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if(dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using(StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get the table schema structure for create statement in Sys_ProcessDocument method
                    using(CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        schema = dt.GetColumnSchema();

                        //Get the record values from the current table to be used in Sys_ProcessDocument method
                        recordValues = dt.GetDMLRecordValues();
                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if(TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }
                        //Call Sys_ProcessDocument method to Create a new record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, schema, recordValues, "A");

                        //Check if ResultValue is failed then reflect error number and error message
                        if(resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                        SequenceName = storedProcedure.SequenceNumber;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if(dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to update a CommonBusiness.
        /// When error occures check CommonBusiness.ErrorNo and CommonBusiness.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing updated values</param>
        /// <returns >0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message 
                if(dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if(dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using(StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get update DML string to be used for update statement by Sys_ProcessDocument API

                    using(CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        dt.WhereConditionField = WhereConditionField;
                        string[] updateDML = dt.TableToUpdateWhereDML();

                        //Frame where condition for updating the record in the database
                        WhereCondition = PrimaryKeyField + "=" + PrimaryKeyValue;

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        //Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML[0], updateDML[1], "U");

                        //Check if ResultValue is failed then reflect error number and error message
                        if(resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if(dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a CommonBusiness. 
        /// When error occures check CommonBusiness.ErrorNo and CommonBusiness.errorDescription 
        /// for actual error. 
        /// </summary>    
        /// <param name="Sno">FeatureID of Current CommonBusiness</param> 
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public override int DoDelete(int Sno)
        {
            try
            {
                //Check if Sno is less than 1 then reflect error number and error message
                if(Sno <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:InvalidSno";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                using(StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Frame where condition for checking the non existence of Current CommonBusiness in the database
                    WhereCondition = PrimaryKeyField + "=" + Sno;

                    //Call method Sys_GetRecordCount to check whether Current CommonBusiness doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);

                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if Current CommonBusiness doesn't exists in the database then reflect error number and error message
                    
                    // Removed by Chandra Prakash (there is no need to check this.)
                    //if(dtRecord.Rows.Count == 0)
                    //{
                    //    errorDescription = PrimaryEntity + ".DoDelete:Sno not Exist";
                    //    GetErrorMessage(errorDescription);
                    //    return (int)ResultType.Failed;
                    //}
                    if(TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }
                    //Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, "", WhereCondition, "D");

                    //Check if ResultValue is failed then reflect error number and error message
                    if(resultValue == (int)ResultType.Failed)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = "GetLocalResourceObject:" + ErrorNumber;
                        return (int)ResultType.Failed;

                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a CommonBusiness. 
        /// When error occures check CommonBusiness.ErrorNo and CommonBusiness.errorDescription 
        /// for actual error. 
        /// </summary>    
        /// <param name="code">FeatureID of Current CommonBusiness</param> 
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public override int DoDelete(string code)
        {
            try
            {
                //Check if Sno is less than 1 then reflect error number and error message
                if(string.IsNullOrEmpty(code))
                {
                    ErrorMessage = "GetLocalResourceObject:InvalidCode";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                using(StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Frame where condition for checking the non existence of Current CommonBusiness in the database
                    WhereCondition = PrimaryKeyField + "='" + code + "'";

                    //Call method Sys_GetRecordCount to check whether Current CommonBusiness doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);

                    //DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    ////Check if Current CommonBusiness doesn't exists in the database then reflect error number and error message
                    //if (dtRecord.Rows.Count == 0)
                    //{
                    //    errorDescription = PrimaryEntity +".DoDelete: Sno not Exist";
                    //    GetErrorMessage(errorDescription);
                    //    return (int)ResultType.Failed;
                    //}
                    if(TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }
                    //Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, "", WhereCondition, "D");

                    //Check if ResultValue is failed then reflect error number and error message
                    if(resultValue == (int)ResultType.Failed)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = "GetLocalResourceObject:" + ErrorNumber;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to get a CommonBusiness List for a Client. 
        /// When error occurs check CommonBusiness.ErrorNo and CommonBusiness.errorDescription for actual error. 
        /// </summary>
        /// <param name="sNo">SNo of Current Table</param>
        /// <returns>DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.</returns>
        public override DataTable DoRead(int sNo)
        {
            using(StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    //Frame where condition for getting the CommonBusiness record from the database
                    WhereCondition = PrimaryKeyField + "=" + sNo;

                    //Call method GetList to get the CommonBusiness record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if dt table is blank then reflect error number and error message
                    if(dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// Method is used to get a CommonBusiness List for a Client. 
        /// When error occurs check CommonBusiness.ErrorNo and CommonBusiness.errorDescription for actual error. 
        /// </summary>
        /// <param name="sNo">SNo of Current Table</param>
        /// <returns>DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.</returns>
        public override DataTable DoRead(string code)
        {
            using(StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    //Frame where condition for getting the CommonBusiness record from the database
                    WhereCondition = PrimaryKeyField + "='" + code + "'";

                    //Call method GetList to get the CommonBusiness record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if dt table is blank then reflect error number and error message
                    if(dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        public DataTable GetList(string entityName, string entityFields, string whereCondition)
        {
          
            DataSet dt = null;
            try
            {
                SqlParameter sequenceNumber = new SqlParameter("@SequenceNumber", SqlDbType.Int) { Direction = ParameterDirection.Output };

                SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int) { Direction = ParameterDirection.Output };

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) { Direction = ParameterDirection.Output, Size = 250 };
                SqlParameter[] Parameters = { new SqlParameter("@EntityName", entityName), new SqlParameter("@ActionType", "G"), new SqlParameter("@RecordsFields", entityFields), new SqlParameter("@RecordsValues", whereCondition), sequenceNumber, errorNumber, ValidationMessage };

                dt = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "SysProcessDocument", Parameters);

                if (int.Parse(Parameters[5].Value.ToString()) > 0)
                {
                    ErrorNumber = int.Parse(Parameters[5].Value.ToString());
                    ErrorMessage = Parameters[6].Value.ToString();
                    return null;
                }
                else
                    return dt.Tables[0];
            }
            catch (Exception)
            {
                const string errorDescription = "StoredProcedure.GetList():Internal Error! Could not execute SysProcessDocument";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return null;
            }
            finally
            {
                if (dt != null)
                    dt.Dispose();
            }
        }
    }
}