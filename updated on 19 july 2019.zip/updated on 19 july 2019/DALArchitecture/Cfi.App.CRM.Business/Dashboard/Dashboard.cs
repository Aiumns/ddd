﻿using System;
using System.Data;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;

namespace Cfi.App.CRM.Business
{
    public class Dashboard : BaseBusinessSecureObject
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Dashboard"/> class.
        /// </summary>
        public Dashboard()
        {
            this.InitializeEntity();
        }

        /// <summary>
        /// Finalizes an instance of the <see cref="Dashboard"/> class. 
        /// Destructor: Cleanup the Dashboard Objects 
        /// </summary>
        ~Dashboard()
        {
            // Cleanup of the Enviroment Objects
            this.Dispose();
        }

        /// <summary>
        /// Dispose all objects of Dashboard class.  
        /// </summary>
        public override void Dispose()
        {
            // Calling dispose method of BaseBusinessSecureObject Class to release memory occupied 
            // by Dashboard class objects.
            base.Dispose();

            // Prevent the clean-up code for the objects from being called twice
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Method to set the default properties of the base entity i.e. BaseBusinessSecureObject.
        /// </summary>
        private void InitializeEntity()
        {
            ConnectionString = SoftwareFactory.Data.ConnectionString.WebConfigConnectionString;
        }

        public DataSet GetDashboardAccountData(int compBrSno,string showReportType, DateTime startDate, DateTime endDate, int topRowCount, string ascOrdesc)
        {
            DataSet ds = new DataSet();
            try
            { 
                /// TODO: Send Datetime parameter in datetime format only and handle it into sql as given format
                SqlParameter[] parameters = {  new SqlParameter("@CompBrSNo", compBrSno), 
                                                new SqlParameter("@ShowReportType",showReportType.Trim()),
                                                new SqlParameter("@StartDate", startDate.ToString("MM/dd/yyyy")), 
                                               new SqlParameter("@EndDate", endDate.ToString("MM/dd/yyyy")), 
                                                new SqlParameter("@TopRowCount", topRowCount),
                                                new SqlParameter("@AscOrDesc", ascOrdesc),
                                            };
                ds = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "GetDashboardAccountData", parameters);
            }
            catch (Exception)
            {
                ds = null;                
            }
            return ds;
        }
    }
}
