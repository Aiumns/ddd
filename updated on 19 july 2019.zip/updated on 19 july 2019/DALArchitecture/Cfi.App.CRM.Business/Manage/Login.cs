﻿#region Login Class Description
/* Login Class Description.
         * Company             : CargoFlash Infotech	Pvt. Ltd.
         * Copyright           : Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
         * Purpose             : This class implements the functionality related to Login information of current users.
					             This class provides functionality to Read/Create/Update/Delete the Login Information  of                                   current users.
         * Created By          : Aditya Kumar.
       
        */
#endregion
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;

namespace Cfi.App.CRM.Business
{
    /// <summary>
    /// Class implements the functionality related to Login information of current users.
    /// </summary>
    public class Login : BaseBusinessSecureObject
    {
        /// <summary>
        /// The error description.
        /// </summary>
        private string errorDescription = string.Empty;

        /// <summary>
        /// Initializes a new instance of the <see cref="Login"/> class. 
        /// Constructor: Initializes a new instance of Login class. 
        /// </summary>
        public Login() { InitializeEntity(); }

        /// <summary>
        /// Initializes a new instance of the <see cref="Login"/> class. 
        /// Constructor: Initializes a new instance of the Cfi.SoftwareFactory.Application.StoredProcedure class.
        /// </summary>
        /// <param name="sqlTransaction">
        /// </param>
        public Login(SqlTransaction sqlTransaction)
        {
            InitializeEntity();

            // if Connection string is blank raise error
            if (string.IsNullOrEmpty(ConnectionString))
                throw new Exception("ConnectionString string is blank! ConnectionString string is required.");

            // if Transaction is noting or is empty raise error
            if (sqlTransaction == null)
                throw new Exception("NULL sqlTransaction! sqlTransaction is required.");

            // Set sqlTransaction to Transaction
            Transaction = sqlTransaction;

            // Set Enabled the Transaction
            TransactionEnabled = true;
        }

        /// <summary>
        /// Method to set the default properties of the base entity i.e. BaseBusinessSecureObject.
        /// </summary>
        private void InitializeEntity()
        {
            PrimaryEntity = "Login";
            PrimaryKeyField = "SNo";
            PrimaryKeyValue = "SNo";
            UpdateFieldToExclude = "SNo";
            ConnectionString = SoftwareFactory.Data.ConnectionString.WebConfigConnectionString;
            NameSpacePrefix = "Login";
            DateFormat = "yyyy-MM-dd HH:mm:ss";
            WhereCondition = string.Empty;
            WhereConditionField = UpdateFieldToExclude;
        }

        /// <summary>
        /// Method is used for validating the business objects.
        /// </summary>
        /// <param name="dtCurrentRecord">
        /// dtCurrentRecord contains current record.
        /// </param>
        /// <param name="currentDataOperation">
        /// CurrentDataOperation contains current operation.
        /// </param>
        /// <returns>
        /// This return Zero(0) if success or One(1) if failed. 
        /// </returns>
        protected override int ValidateBusinessRule(DataTable dtCurrentRecord, DataOperation currentDataOperation)
        {
            // set DataTable airlineName value to airlineName
            string loginID = dtCurrentRecord.Rows[0]["LoginID"].ToString();

            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                try
                {
                    int count;
                    switch (currentDataOperation)
                    {
                        // Check Business Rule before creating a record
                        // *************************************************************
                        case DataOperation.Create:

                            // Check airlineName is blank then raise error.
                            if (string.IsNullOrEmpty(loginID))
                            {
                                ErrorMessage = "GetLocalResourceObject:LoginIDCanNotBlank";
                                ErrorNumber = 1;
                                return (int)ResultType.Failed;
                            }

                            // Call method Sys_GetRecordCount to check whether Current EmployeeName doesn't exists in the database
                            WhereCondition = "LoginID='" + loginID + "'";
                            count = storedProcedure.Sys_GetRecordCount(PrimaryEntity, PrimaryKeyField, WhereCondition);
                            if (count > 0)
                            {
                                ErrorMessage = "GetLocalResourceObject:LoginIDAlreadyExists";
                                ErrorNumber = 1;
                                return (int)ResultType.Failed;
                            }

                            dtCurrentRecord.AcceptChanges();
                            return (int)ResultType.Success;

                        // Check Business Rule before Deleting a record
                        // *************************************************************
                        case DataOperation.Delete:
                            return (int)ResultType.Success;

                        // Check Business Rule before Updating a record
                        // *************************************************************
                        case DataOperation.Update:

                            if (dtCurrentRecord.Rows[0][PrimaryKeyField] != null)
                                PrimaryKeyValue = dtCurrentRecord.Rows[0][PrimaryKeyField].ToString();

                            // Call method Sys_GetRecordCount to check whether Current EmployeeName doesn't exists in the database
                            WhereCondition = "SNo<>'" + PrimaryKeyValue + "' AND LoginID='" + loginID + "'";
                            count = storedProcedure.Sys_GetRecordCount(PrimaryEntity, PrimaryKeyField, WhereCondition);
                            if (count > 0)
                            {
                                ErrorMessage = "GetLocalResourceObject:LoginIDAlreadyExists";
                                ErrorNumber = 1;
                                return (int)ResultType.Failed;
                            }

                            dtCurrentRecord.AcceptChanges();
                            return (int)ResultType.Success;

                        // Check Business Rule before Reading a record
                        // *************************************************************
                        case DataOperation.View:
                            return (int)ResultType.Success;

                        // Check Business Rule for conditions other than Create, Update, Delete and Read 
                        // *************************************************************
                        default:
                            return (int)ResultType.Failed;
                    }
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                finally
                {
                    // Check if dtCurrentRecord is not null then dispose it
                    dtCurrentRecord.Dispose();
                    WhereCondition = string.Empty;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// The get login.
        /// </summary>
        /// <returns>
        /// </returns>
        public DataTable GetLogin()
        {
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    // Frame where condition for getting the Country record from the database
                    WhereCondition = string.Empty;

                    // Call method GetList to get the Country record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "SNo,LoginID,EmailID,Name", WhereCondition);

                    // Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:LoginIDNotExists";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// The get login page access detail.
        /// </summary>
        /// <param name="loginSNo">
        /// The login s no.
        /// </param>
        /// <param name="pageSNo">
        /// The page s no.
        /// </param>
        /// <returns>
        /// </returns>
        public DataTable GetLoginPageAccessDetail(string loginSNo, int pageSNo)
        {
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();
                try
                {
                    // Frame where condition for getting the Country record from the database
                    WhereCondition = "LoginSNo=" + loginSNo + " and PageSNo=" + pageSNo;

                    // Call method GetList to get the Country record from the database
                    dt = storedProcedure.GetList("LoginPageTrans", "CanDelete,CanInsert,CanUpdate,CanView", WhereCondition);

                    // Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:LoginIDNotExists";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// The get page object access detail.
        /// </summary>
        /// <param name="loginSNo">
        /// The login s no.
        /// </param>
        /// <param name="pageSNo">
        /// The page s no.
        /// </param>
        /// <returns>
        /// </returns>
        public DataTable GetPageObjectAccessDetail(string loginSNo, int pageSNo)
        {
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();
                try
                {
                    // Frame where condition for getting the Country record from the database
                    WhereCondition = "LoginSNo='" + loginSNo + "' and PageSNo=" + pageSNo;

                    // Call method GetList to get the Country record from the database
                    dt = storedProcedure.GetList("vPageAcessDetailsGetList", "ObjectName,CanView,CanUpdate", WhereCondition);

                    // Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:LoginIDNotExists";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// Method is used to update the LoggedIn status of User
        /// </summary>
        /// <param name="SNo">
        /// SNo of Current User
        /// </param>
        /// <param name="IsLoggedIn">
        /// Status of Current User (when Loggedin or Logged Out)
        /// </param>
        /// <param name="chatStatus">
        /// Chat Status of Current User.
        /// </param>
        public void UpdateUserLoginStatus(int SNo, bool IsLoggedIn)
        {
            try
            {
                SqlParameter[] sqlParameters = new SqlParameter[3];
                SqlParameter param1 = new SqlParameter("@SNo", SNo);
                SqlParameter param2 = new SqlParameter("@IsLoggedIn", IsLoggedIn ? 1 : 0);
                SqlParameter param3 = new SqlParameter("@ChatStatus", null);
                sqlParameters[0] = param1;
                sqlParameters[1] = param2;
                sqlParameters[2] = param3;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "UpdateUserLoggedInStatus", sqlParameters);
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
            }
        }
        /// <summary>
        /// Get sales person of a particular branch.
        /// </summary>
        /// <param name="companyBranchSNo"></param>
        public DataTable GetSalesPersonByBranch(string companyBranchSNo)
        {
            DataSet dsSalesPerson = new DataSet();
            try
            {
                SqlParameter[] sqlParameters = new SqlParameter[1];
                SqlParameter param1 = new SqlParameter("@CompBrSno", companyBranchSNo);
                sqlParameters[0] = param1;

                dsSalesPerson = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "SalesPersonForSales", sqlParameters);

            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
            }
            return dsSalesPerson.Tables[0];
        }
        /// <summary>
        /// Method is used to update the LoggedIn status of User
        /// </summary>
        /// <param name="LoginSNo">
        /// SNo of Current User
        /// </param>
        /// <param name="EntityName">
        /// Pass the Entity Name which value has to be get from AppSetting
        /// </param>
        public void GetAppSettingValues(int LoginSNo, string EntityName)
        {
            try
            {
                SqlParameter[] sqlParameters = new SqlParameter[2];
                SqlParameter param1 = new SqlParameter("@LoginSNo", LoginSNo);
                SqlParameter param2 = new SqlParameter("@EntityName", EntityName);
                sqlParameters[0] = param1;
                sqlParameters[1] = param2;

                DataSet ds = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "AppSettingValues", sqlParameters);
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
            }
        }

        /// <summary>
        /// Method is used to create a New Login.
        /// When error occurs check Login.ErrorNo and Login.errorDescription 
        /// for actual error.
        /// </summary>
        /// <param name="dtCurrentRecord">
        /// Table containing values of new record to be created
        /// </param>
        /// <returns>
        /// 0 - (int)ResultType.Success,
        /// 1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .
        /// </returns>
        public override int DoCreate(DataTable dtCurrentRecord)
        {
            string schema;
            string recordValues;
            try
            {
                // Check if dtCurrentRecord is null then reflect error number and error message
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                // Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                // Check if Business Rule validation fails then return (int)ResultType.Failed
                if (ValidateBusinessRule(dtCurrentRecord, DataOperation.Create) == (int)ResultType.Failed)
                    return (int)ResultType.Failed;

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    // Get the table schema structure for create statement in Sys_ProcessDocument method
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.TableSource.Columns.Remove(PrimaryKeyField);
                        dt.DateFormat = DateFormat;
                        schema = dt.GetColumnSchema();

                        // Get the record values from the current table to be used in Sys_ProcessDocument method
                        recordValues = dt.GetDMLRecordValues();

                        // Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        // Call Sys_ProcessDocument method to Create a new record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, schema, recordValues, "A");

                        // Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }

                        SequenceName = storedProcedure.SequenceNumber;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to update a Login.
        /// When error occures check Login.ErrorNo and Login.errorDescription 
        /// for actual error.
        /// </summary>
        /// <param name="dtCurrentRecord">
        /// Table containing updated values
        /// </param>
        /// <returns>
        /// 0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. 
        /// </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {

            try
            {
                // Check if dtCurrentRecord is null then reflect error number and error message 
                int PrimaryKeyValue = int.Parse(dtCurrentRecord.Rows[0]["SNo"].ToString());
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                // Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                // Check if Business Rule validation fails then return (int)ResultType.Failed
                // if (ValidateBusinessRule(dtCurrentRecord, DataOperation.Update) == (int)ResultType.Failed)
                // {
                // return (int)ResultType.Failed;
                // }
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    // Get update DML string to be used for update statement by Sys_ProcessDocument API
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        dt.WhereConditionField = WhereConditionField;
                        string[] updateDML = dt.TableToUpdateWhereDML();

                        // Frame where condition for updating the record in the database
                        WhereCondition = PrimaryKeyField + "='" + PrimaryKeyValue + "'";

                        // Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        // Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML[0], updateDML[1], "U");

                        // Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a Login. 
        /// When error occures check Login.ErrorNo and Login.errorDescription 
        /// for actual error. 
        /// </summary>
        /// <param name="Sno">
        /// FeatureID of Current Login
        /// </param>
        /// <returns>
        /// 0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.
        /// </returns>
        public override int DoDelete(int Sno)
        {
            try
            {
                // Check if Sno is less than 1 then reflect error number and error message
                if (Sno <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:InvalidSno";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    // Frame where condition for checking the non existence of Current Login in the database
                    WhereCondition = PrimaryKeyField + "=" + Sno;

                    // Call method Sys_GetRecordCount to check whether Current Login doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);
                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    // Check if Current Login doesn't exists in the database then reflect error number and error message
                    if (dtRecord.Rows.Count == 0)
                    {
                        ErrorMessage = "GetLocalResourceObject:DtIsNull";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }

                    if (TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }

                    // Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, string.Empty, WhereCondition, "D");

                    // Check if ResultValue is failed then reflect error number and error message
                    if (resultValue == (int)ResultType.Failed)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = "GetLocalResourceObject:" + ErrorNumber;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a Login. 
        /// When error occures check Login.ErrorNo and Login.errorDescription 
        /// for actual error. 
        /// </summary>
        /// <param name="code">
        /// FeatureID of Current Login
        /// </param>
        /// <returns>
        /// 0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.
        /// </returns>
        public override int DoDelete(string code)
        {
            try
            {
                // Check if Sno is less than 1 then reflect error number and error message
                if (string.IsNullOrEmpty(code))
                {
                    ErrorMessage = "GetLocalResourceObject:InvalidLoginId";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    // Frame where condition for checking the non existence of Current Login in the database
                    WhereCondition = PrimaryKeyField + "='" + code + "'";

                    // Call method Sys_GetRecordCount to check whether Current Login doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);
                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    // Check if Current Login doesn't exists in the database then reflect error number and error message
                    if (dtRecord.Rows.Count == 0)
                    {
                        ErrorMessage = "GetLocalResourceObject:SnoNotExists";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }

                    if (TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }

                    // Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, string.Empty, WhereCondition, "D");

                    // Check if ResultValue is failed then reflect error number and error message
                    if (resultValue == (int)ResultType.Failed)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = storedProcedure.ErrorMessage;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to get a Login List for a Client. 
        /// When error occurs check Login.ErrorNo and Login.errorDescription for actual error. 
        /// </summary>
        /// <param name="sNo">
        /// SNo of Current Table
        /// </param>
        /// <returns>
        /// DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.
        /// </returns>
        public override DataTable DoRead(int sNo)
        {
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    // Frame where condition for getting the Login record from the database
                    WhereCondition = PrimaryKeyField + "=" + sNo;

                    // Call method GetList to get the Login record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    // Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }

        /// <summary>
        /// Method is used to get a Login List for a Client. 
        /// When error occurs check Login.ErrorNo and Login.errorDescription for actual error. 
        /// </summary>
        /// <param name="code">
        /// The code.
        /// </param>
        /// <returns>
        /// DataTable - (int)ResultType.Success.NULL - (int)ResultType.Failed, due to internal error.
        /// </returns>
        public override DataTable DoRead(string code)
        {
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                DataTable dt = new DataTable();

                try
                {
                    // Frame where condition for getting the Login record from the database
                    WhereCondition = PrimaryKeyField + "='" + code + "'";

                    // Call method GetList to get the Login record from the database
                    dt = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    // Check if dt table is blank then reflect error number and error message
                    if (dt == null)
                    {
                        ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                        ErrorNumber = 1;
                        return dt;
                    }
                    else
                        return dt;
                }
                catch (Exception ex)
                {
                    CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                    cfiException.InsertExceptionIntoDatabase(true);
                    ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                    ErrorNumber = 1;
                    return dt;
                }
                finally
                {
                    WhereCondition = null;
                    errorDescription = null;
                }
            }
        }


        /// <summary>
        /// Method to get agent name according to officesno and city/country/localzone/globalzone 
        /// </summary>
        /// <param name="officeSNo">
        /// The office S No.
        /// </param>
        /// <param name="locationType">
        /// The location Type.
        /// </param>
        /// <param name="locationValue">
        /// The location Value.
        /// </param>
        /// <returns>
        /// </returns>
        public int ChangePassword(string oldPassword, string newPassword, int LoginSNo)
        {
            try
            {
                SqlParameter[] Parameters = {
                                                new SqlParameter("LoginSNo", LoginSNo), 
                                                new SqlParameter("OldPassword", oldPassword), 
                                                new SqlParameter("NewPassword", newPassword)
                                            };

                int i = SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "ChangePassword",
                                              Parameters);

                return i;
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return 0;
            }
        }


        /// <summary>
        /// Method to change Password from Secure Hash Algorithm  
        /// </summary>
        /// <param name="password">
        /// <returns>
        /// </returns>
        public string GetSHA1EncryptPassword(string password)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            SHA1CryptoServiceProvider sha1hasher = new SHA1CryptoServiceProvider();
            byte[] hashedDataBytes = sha1hasher.ComputeHash(encoder.GetBytes(password));
            return byteArrayToString(hashedDataBytes);
        }

        /// <summary>
        /// Method to get byte [] to string 
        /// </summary>
        /// <param name="inputArray">
        /// <returns>
        /// </returns>
        private string byteArrayToString(byte[] inputArray)
        {
            StringBuilder output = new StringBuilder("");
            for (int i = 0; i < inputArray.Length; i++)
            {
                output.Append(inputArray[i].ToString("X2"));
            }
            return output.ToString();
        }

        public string GetPassword()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(RandomString(4, true));
            builder.Append(RandomNumber(1000, 9999));
            builder.Append(RandomString(2, false));
            return builder.ToString();
        }

        private int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        private string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }



        /// <summary>
        /// Encrypts specified plaintext using Rijndael symmetric key algorithm
        /// and returns a base64-encoded result.
        /// </summary>
        /// <param name="plainText">
        /// Plaintext value to be encrypted.
        /// </param>
        /// <param name="passPhrase">
        /// Passphrase from which a pseudo-random password will be derived. The
        /// derived password will be used to generate the encryption key.
        /// Passphrase can be any string. In this example we assume that this
        /// passphrase is an ASCII string.
        /// </param>
        /// <param name="saltValue">
        /// Salt value used along with passphrase to generate password. Salt can
        /// be any string. In this example we assume that salt is an ASCII string.
        /// </param>
        /// <param name="hashAlgorithm">
        /// Hash algorithm used to generate password. Allowed values are: "MD5" and
        /// "SHA1". SHA1 hashes are a bit slower, but more secure than MD5 hashes.
        /// </param>
        /// <param name="passwordIterations">
        /// Number of iterations used to generate password. One or two iterations
        /// should be enough.
        /// </param>
        /// <param name="initVector">
        /// Initialization vector (or IV). This value is required to encrypt the
        /// first block of plaintext data. For RijndaelManaged class IV must be 
        /// exactly 16 ASCII characters long.
        /// </param>
        /// <param name="keySize">
        /// Size of encryption key in bits. Allowed values are: 128, 192, and 256. 
        /// Longer keys are more secure than shorter keys.
        /// </param>
        /// <returns>
        /// Encrypted value formatted as a base64-encoded string.
        /// </returns>
        public string Encrypt(string plainText)
        {
            string passPhrase = "Pas5pr@se"; // can be any string
            string saltValue = "s@1tValue";  // can be any string
            string hashAlgorithm = "SHA1"; //can be "MD5"
            int passwordIterations = 2; //can be any number
            string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
            int keySize = 256;

            // Convert strings into byte arrays.
            // Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8 
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our plaintext into a byte array.
            // Let us assume that plaintext contains UTF8-encoded characters.
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

            // First, we must create a password, from which the key will be derived.
            // This password will be generated from the specified passphrase and 
            // salt value. The password will be created using the specified hash 
            // algorithm. Password creation can be done in several iterations.
            PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                            passPhrase,
                                                            saltValueBytes,
                                                            hashAlgorithm,
                                                            passwordIterations);

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            // Create uninitialized Rijndael encryption object.
            RijndaelManaged symmetricKey = new RijndaelManaged();

            // It is reasonable to set encryption mode to Cipher Block Chaining
            // (CBC). Use default options for other symmetric key parameters.
            symmetricKey.Mode = CipherMode.CBC;

            // Generate encryptor from the existing key bytes and initialization 
            // vector. Key size will be defined based on the number of the key 
            // bytes.
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(
                                                             keyBytes,
                                                             initVectorBytes);

            // Define memory stream which will be used to hold encrypted data.
            MemoryStream memoryStream = new MemoryStream();

            // Define cryptographic stream (always use Write mode for encryption).
            CryptoStream cryptoStream = new CryptoStream(memoryStream,
                                                         encryptor,
                                                         CryptoStreamMode.Write);
            // Start encrypting.
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);

            // Finish encrypting.
            cryptoStream.FlushFinalBlock();

            // Convert our encrypted data from a memory stream into a byte array.
            byte[] cipherTextBytes = memoryStream.ToArray();

            // Close both streams.
            memoryStream.Close();
            cryptoStream.Close();

            // Convert encrypted data into a base64-encoded string.
            string cipherText = Convert.ToBase64String(cipherTextBytes);

            // Return encrypted string.
            return cipherText;
        }

        /// <summary>
        /// Decrypts specified ciphertext using Rijndael symmetric key algorithm.
        /// </summary>
        /// <param name="cipherText">
        /// Base64-formatted ciphertext value.
        /// </param>
        /// <param name="passPhrase">
        /// Passphrase from which a pseudo-random password will be derived. The
        /// derived password will be used to generate the encryption key.
        /// Passphrase can be any string. In this example we assume that this
        /// passphrase is an ASCII string.
        /// </param>
        /// <param name="saltValue">
        /// Salt value used along with passphrase to generate password. Salt can
        /// be any string. In this example we assume that salt is an ASCII string.
        /// </param>
        /// <param name="hashAlgorithm">
        /// Hash algorithm used to generate password. Allowed values are: "MD5" and
        /// "SHA1". SHA1 hashes are a bit slower, but more secure than MD5 hashes.
        /// </param>
        /// <param name="passwordIterations">
        /// Number of iterations used to generate password. One or two iterations
        /// should be enough.
        /// </param>
        /// <param name="initVector">
        /// Initialization vector (or IV). This value is required to encrypt the
        /// first block of plaintext data. For RijndaelManaged class IV must be
        /// exactly 16 ASCII characters long.
        /// </param>
        /// <param name="keySize">
        /// Size of encryption key in bits. Allowed values are: 128, 192, and 256.
        /// Longer keys are more secure than shorter keys.
        /// </param>
        /// <returns>
        /// Decrypted string value.
        /// </returns>
        /// <remarks>
        /// Most of the logic in this function is similar to the Encrypt
        /// logic. In order for decryption to work, all parameters of this function
        /// - except cipherText value - must match the corresponding parameters of
        /// the Encrypt function which was called to generate the
        /// ciphertext.
        /// </remarks>
        public string Decrypt(string cipherText)
        {
            string passPhrase = "Pas5pr@se"; // can be any string
            string saltValue = "s@1tValue";  // can be any string
            string hashAlgorithm = "SHA1"; //can be "MD5"
            int passwordIterations = 2; //can be any number
            string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
            int keySize = 256;

            // Convert strings defining encryption key characteristics into byte
            // arrays. Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our ciphertext into a byte array.
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);

            // First, we must create a password, from which the key will be 
            // derived. This password will be generated from the specified 
            // passphrase and salt value. The password will be created using
            // the specified hash algorithm. Password creation can be done in
            // several iterations.
            PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                            passPhrase,
                                                            saltValueBytes,
                                                            hashAlgorithm,
                                                            passwordIterations);

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            // Create uninitialized Rijndael encryption object.
            RijndaelManaged symmetricKey = new RijndaelManaged();

            // It is reasonable to set encryption mode to Cipher Block Chaining
            // (CBC). Use default options for other symmetric key parameters.
            symmetricKey.Mode = CipherMode.CBC;

            // Generate decryptor from the existing key bytes and initialization 
            // vector. Key size will be defined based on the number of the key 
            // bytes.
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(
                                                             keyBytes,
                                                             initVectorBytes);

            // Define memory stream which will be used to hold encrypted data.
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);

            // Define cryptographic stream (always use Read mode for encryption).
            CryptoStream cryptoStream = new CryptoStream(memoryStream,
                                                          decryptor,
                                                          CryptoStreamMode.Read);

            // Since at this point we don't know what the size of decrypted data
            // will be, allocate the buffer long enough to hold ciphertext;
            // plaintext is never longer than ciphertext.
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];

            // Start decrypting.
            int decryptedByteCount = cryptoStream.Read(plainTextBytes,
                                                       0,
                                                       plainTextBytes.Length);

            // Close both streams.
            memoryStream.Close();
            cryptoStream.Close();

            // Convert decrypted data into a string. 
            // Let us assume that the original plaintext string was UTF8-encoded.
            string plainText = Encoding.UTF8.GetString(plainTextBytes,
                                                       0,
                                                       decryptedByteCount);

            // Return decrypted string.   
            return plainText;
        }


        public int GetServerTimeDifference(DateTime applicationServerTime)
        {
            try
            {
                SqlParameter[] Parameters = { new SqlParameter("@ApplicationServerDateTime", applicationServerTime) };
                object serverTimeDiffernce = (object)SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, "ServerTimeDifference", Parameters);
                TimeSpan executionTime = (DateTime.Now - applicationServerTime);
                return Convert.ToInt32(serverTimeDiffernce) + executionTime.Milliseconds;
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return 0;
            }
        }


        public int InsertLoginDetails(string loginType, string loginID, byte[] password, string emailId, string name, string companySNo, string active, int chaSNo )
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[8];


                SqlParameter paramLoginType = new SqlParameter("@LoginType", SqlDbType.VarChar);
                paramLoginType.Value = loginType;
                sqlParams[0] = paramLoginType;

                SqlParameter paramLoginId = new SqlParameter("@LoginId", SqlDbType.VarChar);
                paramLoginId.Value = loginID;
                sqlParams[1] = paramLoginId;

                SqlParameter paramPassword = new SqlParameter("@Password", SqlDbType.VarBinary);
                paramPassword.Value = password;
                sqlParams[2] = paramPassword;

                SqlParameter paramEmailId = new SqlParameter("@EmailId", SqlDbType.VarChar);
                paramEmailId.Value = emailId;
                sqlParams[3] = paramEmailId;

                SqlParameter paramName = new SqlParameter("@Name", SqlDbType.VarChar);
                paramName.Value = name;
                sqlParams[4] = paramName;

                SqlParameter paramCompSNo = new SqlParameter("@CompSNo", SqlDbType.VarChar);
                paramCompSNo.Value = companySNo;
                sqlParams[5] = paramCompSNo;

                SqlParameter paramActive = new SqlParameter("@Active", SqlDbType.VarChar);
                paramActive.Value = active;
                sqlParams[6] = paramActive;

                SqlParameter paramCHASNo = new SqlParameter("@CHASNo", SqlDbType.Int);
                paramCHASNo.Value = chaSNo;
                sqlParams[7] = paramCHASNo;

                int i = (int)SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, "InsertLoginDetails", sqlParams);
                return i;
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
        }


        public int UpdateLoginDetails(int Sno, string loginID, byte[] password, string emailId, string name, string companySNo, string active, int chaSNo)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[8];

                SqlParameter paramLoginSNo = new SqlParameter("@SNo", SqlDbType.Int);
                paramLoginSNo.Value = Sno;
                sqlParams[0] = paramLoginSNo;

                SqlParameter paramLoginId = new SqlParameter("@LoginId", SqlDbType.VarChar);
                paramLoginId.Value = loginID;
                sqlParams[1] = paramLoginId;

                SqlParameter paramPassword = new SqlParameter("@Password", SqlDbType.VarBinary);
                paramPassword.Value = password;
                sqlParams[2] = paramPassword;

                SqlParameter paramEmailId = new SqlParameter("@EmailId", SqlDbType.VarChar);
                paramEmailId.Value = emailId;
                sqlParams[3] = paramEmailId;

                SqlParameter paramName = new SqlParameter("@Name", SqlDbType.VarChar);
                paramName.Value = name;
                sqlParams[4] = paramName;

                SqlParameter paramCompSNo = new SqlParameter("@CompSNo", SqlDbType.VarChar);
                paramCompSNo.Value = companySNo;
                sqlParams[5] = paramCompSNo;

                SqlParameter paramActive = new SqlParameter("@Active", SqlDbType.VarChar);
                paramActive.Value = active;
                sqlParams[6] = paramActive;

                SqlParameter paramCHASNo = new SqlParameter("@CHASNo", SqlDbType.VarChar);
                paramCHASNo.Value = chaSNo;
                sqlParams[7] = paramCHASNo;


                int i = (int)SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, "UpdateLoginDetails", sqlParams);
                return i;
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
        }


    }
}