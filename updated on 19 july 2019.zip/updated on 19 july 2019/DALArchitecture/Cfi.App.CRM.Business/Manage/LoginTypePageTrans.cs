﻿#region LoginTypePageTrans Class Description
/*
    *****************************************************************************
	Class Name      : LoginTypePageTrans      
	Purpose         : This class implements the functionality related to Page Permission information of each Login Type.
					  This class provides functionality to Read/Create/Update/Delete the Page Permission information of each Login Type.
	Company         : CargoFlash Infotech
	Author          : Suman Kumar
	Created On      : 15 oct 2009
    Update By       : Dilip Kumar
    Update On       : 16 Mar 2010
    Description     : Correct The ErrorMessage.
    Updated By      : Dilip Kumar.
    Update On       : 05 Apr 2010.
    Description     : Change error message.
	Approved By:      
	Approved On:      
    *****************************************************************************
	*/
#endregion

using System;
using System.Data;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;

namespace Cfi.App.CRM.Business
{

    public class LoginTypePageTrans : BaseBusinessSecureObject
    {
        private string errorDescription = string.Empty;

        /// <summary>
        /// Constructor: Initializes a new instance of LoginTypePageTrans class. 
        /// </summary>
        public LoginTypePageTrans() { InitializeEntity(); }

        /// <summary>
        /// Constructor: Initializes a new instance of the Cfi.SoftwareFactory.Application.StoredProcedure class.
        /// </summary>
        /// <param name="sqlTransaction"></param>
        public LoginTypePageTrans(SqlTransaction sqlTransaction)
        {
            InitializeEntity();

            //if Connection string is blank raise error
            if (string.IsNullOrEmpty(ConnectionString))
                throw new Exception("ConnectionString string is blank! ConnectionString string is required.");

            //if Transaction is noting or is empty raise error
            if (sqlTransaction == null)
                throw new Exception("NULL sqlTransaction! sqlTransaction is required.");

            //Set sqlTransaction to Transaction
            Transaction = sqlTransaction;

            //Set Enabled the Transaction
            TransactionEnabled = true;
        }

        ///<summary>
        /// Destructor: Cleanup the LoginTypePageTrans Objects 
        /// </summary>
        ~LoginTypePageTrans()
        {
            //Cleanup of the Enviroment Objects
            Dispose();
        }

        /// <summary>
        /// Dispose all objects of LoginTypePageTrans class.  
        /// </summary>
        public override void Dispose()
        {
            //Calling dispose method of BaseBusinessSecureObject Class to release memory occupied 
            //by LoginTypePageTrans class objects.
            base.Dispose();
            //Prevent the clean-up code for the objects from being called twice
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Method to set the default properties of the base entity i.e. BaseBusinessSecureObject.
        /// </summary>
        private void InitializeEntity()
        {
            PrimaryEntity = "LoginTypePageTrans";
            PrimaryKeyField = "SNo";
            PrimaryKeyValue = "";
            UpdateFieldToExclude = "SNo";
            ConnectionString = SoftwareFactory.Data.ConnectionString.WebConfigConnectionString;
            NameSpacePrefix = "LoginTypePageTrans";
            DateFormat = "yyyy-MM-dd HH:mm:ss";
            WhereCondition = "";
            WhereConditionField = UpdateFieldToExclude;
        }

        /// <summary>
        /// Method is used to create a New LoginTypePageTrans.
        /// When error occurs check LoginTypePageTrans.ErrorNo and LoginTypePageTrans.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing values of new record to be created</param>
        /// <returns>0 - (int)ResultType.Success,
        /// 1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public override int DoCreate(DataTable dtCurrentRecord)
        {
            string schema;
            string recordValues;
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get the table schema structure for create statement in Sys_ProcessDocument method
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        //  dt.TableSource.Columns.Remove(PrimaryKeyField);
                        dt.DateFormat = DateFormat;
                        schema = dt.GetColumnSchema();

                        //Get the record values from the current table to be used in Sys_ProcessDocument method
                        recordValues = dt.GetDMLRecordValues();

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }
                        //Call Sys_ProcessDocument method to Create a new record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, schema, recordValues, "A");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to update a LoginTypePageTrans.
        /// When error occures check LoginTypePageTrans.ErrorNo and LoginTypePageTrans.errorDescription 
        /// for actual error.
        /// </summary>    
        ///<param name="dtCurrentRecord">Table containing updated values</param>
        /// <returns >0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error. </returns>
        public override int DoUpdate(DataTable dtCurrentRecord)
        {
            try
            {
                //Check if dtCurrentRecord is null then reflect error number and error message 
                if (dtCurrentRecord == null)
                {
                    ErrorMessage = "GetLocalResourceObject:ResultIsNull";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                //Check if dtCurrentRecord table is blank then reflect error number and error message
                if (dtCurrentRecord.Rows.Count <= 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }

                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Get update DML string to be used for update statement by Sys_ProcessDocument API
                    using (CfiDataTable dt = new CfiDataTable())
                    {
                        dt.TableSource = dtCurrentRecord;
                        dt.DateFormat = DateFormat;
                        dt.UpdateFieldToExclude = UpdateFieldToExclude;
                        dt.WhereConditionField = WhereConditionField;
                        string[] updateDML = dt.TableToUpdateWhereDML();

                        //Check if transaction is enabled then set storedprocedure class as transaction enabled
                        if (TransactionEnabled)
                        {
                            storedProcedure.TransactionEnabled = true;
                            storedProcedure.Transaction = Transaction;
                        }

                        //Call Sys_ProcessDocument method to Update the record.
                        int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, updateDML[0], updateDML[1], "U");

                        //Check if ResultValue is failed then reflect error number and error message
                        if (resultValue == (int)ResultType.Failed)
                        {
                            ErrorMessage = "GetLocalResourceObject:EmptyResultValue";
                            ErrorNumber = 1;
                            return (int)ResultType.Failed;
                        }
                    }
                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                if (dtCurrentRecord != null)
                    dtCurrentRecord.Dispose();
                WhereCondition = null;
                errorDescription = null;
            }
        }

        /// <summary>
        /// Method is used to delete a LoginType. 
        /// When error occures check LoginType.ErrorNo and LoginType.errorDescription 
        /// for actual error. 
        /// </summary>    
        /// <param name="code">FeatureID of Current LoginType</param> 
        /// <returns>0 - (int)ResultType.Success.  1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public override int DoDelete(string code)
        {
            try
            {
                //Check if Sno is less than 1 then reflect error number and error message
                if (string.IsNullOrEmpty(code))
                {
                    ErrorMessage = "GetLocalResourceObject:InvalidLoginType";
                    ErrorNumber = 1;
                    return (int)ResultType.Failed;
                }
                using (StoredProcedure storedProcedure = new StoredProcedure())
                {
                    //Frame where condition for checking the non existence of Current LoginType in the database
                    WhereCondition = "LoginTypeSNo='" + code + "'";

                    //Call method Sys_GetRecordCount to check whether Current LoginType doesn't exists in the database
                    // intCount = storedProcedure.Sys_GetRecordCount(this.ClientID, this.PrimaryEntity, this.WhereCondition);

                    DataTable dtRecord = storedProcedure.GetList(PrimaryEntity, "*", WhereCondition);

                    //Check if Current LoginType doesn't exists in the database then reflect error number and error message
                    if (dtRecord.Rows.Count == 0)
                    {
                        ErrorMessage = "GetLocalResourceObject:SnoNotExists";
                        ErrorNumber = 1;
                        return (int)ResultType.Failed;
                    }
                    if (TransactionEnabled)
                    {
                        storedProcedure.TransactionEnabled = true;
                        storedProcedure.Transaction = Transaction;
                    }
                    //Call Sys_ProcessDocument method to Delete a record.
                    int resultValue = storedProcedure.Sys_ProcessDocument(PrimaryEntity, "", WhereCondition, "D");

                    //Check if ResultValue is failed then reflect error number and error message
                    if (resultValue == (int)ResultType.Failed)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = "GetLocalResourceObject:" + ErrorNumber;
                        return (int)ResultType.Failed;
                    }

                    return (int)ResultType.Success;
                }
            }
            catch (Exception ex)
            {
                CfiExceptions cfiException = new CfiExceptions(ex.Message, ex);
                cfiException.InsertExceptionIntoDatabase(true);
                ErrorMessage = "GetGlobalResourceObject:GlobalCatchErrorMessage";
                ErrorNumber = 1;
                return (int)ResultType.Failed;
            }
            finally
            {
                WhereCondition = null;
                errorDescription = null;
            }
        }
    }
}