using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Configuration;
//Need To Add Two reference system.web,system.extension;
namespace Cfi.App.Pace.Common
{
    public class PACEClass
    {
        public void ClearTextBox(System.Web.UI.HtmlControls.HtmlForm form)
        {

            //System.Web.UI.MasterPage PP = new System.Web.UI.MasterPage();
            System.Web.UI.WebControls.TextBox tt;
            //System.Web.UI.Control cc;
            //cc = PP.FindControl(strM);
            foreach (System.Web.UI.Control cc1 in form.Controls)
            {
                if (cc1 is ContentPlaceHolder)
                {
                    foreach (System.Web.UI.Control cc2 in cc1.Controls)
                    {
                        string str = cc2.ClientID.ToString();

                        if (cc2 is System.Web.UI.WebControls.TextBox)
                        {
                            tt = (System.Web.UI.WebControls.TextBox)cc2;
                            tt.Text = "";
                        }
                    }
                }
            }
        }
    }
}
