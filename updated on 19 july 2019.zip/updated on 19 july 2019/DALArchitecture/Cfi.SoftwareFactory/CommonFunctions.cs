/* Messages UserControl Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright � 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   Used for some functions that can be called by statical methods as follows.
 * Created By           :   Sudhir Yadav.
 * Created On           :   26 Sep 2009.
 * Modified By          :   Dhiraj Kumar
 * Modified On          :   28 oct 2009
 * Description          :   Added new method(FillCheckBoxListFromEnum) to fill checkbox list from an enum.
 * Modified By          :   Sudhir Yadav
 * Modified On          :   1 Nov 2009
 * Description          :   Added the ChangeControlsToLabel method.
 * Modified By          :   Sudhir Yadav
 * Modified On          :   2 Nov 2009
 * Description          :   Added the ClearControlValues method.
 * Modified By          :   Sudhir Yadav
 * Modified On          :   2 Nov 2009
 * Description          :   Added the ClearControlValues method.
 * Modified By          :   Sudhir Yadav
 * Modified On          :   4 Nov 2009
 * Description          :   Changed the method FillCheckBoxListFromDataTable wherein added the parameters first text,first value and the position to place those data.
 * Modified By          :   Manish kumar
 * Modified On          :   12 Jan 2010
 * Description          :   Added new method (IsNumber) to check it is valide number.
 * Modified By          :   Chandra Prakash
 * Modified On          :   08 Feb 2010
 * Description          :   Added the Hidden Field Control in ClearControlValues function.
 * Modified By          :   Sudhir Yadav.
 * Modified On          :   03 Mar 2010.
 * Description          :   Changed ChangeControlsToLabel parameter object[] to Hashtable. Added the overloaded method ChangeControlsToLabel method, with additional parameter, in                              order to exclude the controls specified in hash table.
 * Modified By          :   Sudhir Yadav.
 * Modified On          :   04 Mar 2010.
 * Description          :   Altered the ChangeControlsTolabel method to have code reusability by introducing overload of ChangeControlsToLabel method.
*/
using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cfi.SoftwareFactory.WebControls;

namespace Cfi.SoftwareFactory.Common
{

    #region CommonFunctions Description
    /*
         *************************************************************************************************************
         Class Name         :   CommonFunctions      
         Purpose            :	Used for some functions that can be called by statical methods as follows.
         Company            :	CargoFlash Infotech.
         Author             :   Sudhir Yadav
         Created On         :   26 Sep 2009
         Approved By        :   Sudhir Yadav
         Approved On        :   06 Oct 2009
         Modified By        :   Dhiraj Kumar
         Modified On        :   28 oct 2009
         Description  :   Added new method(FillCheckBoxListFromEnum) to fill checkbox list from an enum.
         Modified By        :   Sudhir Yadav
         Modified On        :   1 Nov 2009
         Description  :   Added the ChangeControlsToLabel method.
         Modified By        :   Sudhir Yadav
         Modified On        :   2 Nov 2009
         Description  :   Added the ClearControlValues method.
         Modified By        :   Sudhir Yadav
         Modified On        :   2 Nov 2009
         Description  :   Added the ClearControlValues method.
         Modified By        :   Sudhir Yadav
         Modified On        :   4 Nov 2009
         Description  :   Changed the method FillCheckBoxListFromDataTable wherein added the parameters first text,first value and the position to place those data.
         Modified By        :   Manish kumar
         Modified On        :   12 Jan 2010
         Description  :   Added new method (IsNumber) to check it is valide number.
         Modified By        :   Chandra Prakash
         Modified On        :   08 Feb 2010
         Description  :   Added the Hidden Field Control in ClearControlValues function.
            
         *************************************************************************************************************
         */
    #endregion

    /// <summary>
    /// Class used for some functions that can be called by statical methods as follows.
    /// </summary>
    public class CommonFunctions
    {
        /// <summary>
        /// Method to set or select a particular value or text in the drop down list.
        /// </summary>
        /// <param name="ddl">
        /// The reference to drop down list in which the value or text is to be selected.
        /// </param>
        /// <param name="val">
        /// The value which is to be selected. It could be a value or a text part in drop down list.
        /// </param>
        /// <param name="isText">
        /// Boolean telling that the val parameter is text or not. Searches the text or value in drop down list accordingly.
        /// </param>
        public static void SetDropDownListSelectedValue(ref CfiDropDownList ddl, string val, bool isText)
        {
            if(isText)
                ddl.SelectedIndex = ddl.Items.IndexOf(ddl.Items.FindByText(val));
            else
            {
                try
                {
                    ddl.SelectedValue = val;
                }
                catch
                {
                    ddl.SelectedIndex = 0;
                }
            }
        }

        /// <summary>
        /// Method to fill the drop down list, along with setting the additional firt text and value in the beginning or in the end of the drop down list.
        /// </summary>
        /// <param name="ddl">
        /// The reference to drop down list in which the value or text is to be selected.
        /// </param>
        /// <param name="dt">
        /// The reference to the datatable. The default bind first two columns in this datatable.
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillDropDownListFromTable(ref CfiDropDownList ddl, DataTable dt, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            ddl.Items.Clear();
            if(dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = dt.Columns[1].ColumnName;
                ddl.DataValueField = dt.Columns[0].ColumnName;
                ddl.DataBind();
            }

            if(firstValue != null || firstText != null)
            {
                ddl.Items.Insert(addAdditionalValueInStarting ? 0 : ddl.Items.Count - 1, new ListItem(firstText, firstValue));
                ddl.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// Method to fill the drop down list specifying the value and the text field also, along with setting the additional firt text and value in the beginning or in the end of the drop down list.
        /// </summary>
        /// <param name="ddl">
        /// The reference to drop down list in which the value or text is to be selected.
        /// </param>
        /// <param name="dt">
        /// The reference to the datatable. The default bind first two columns in this datatable.
        /// </param>
        /// <param name="valueColumn">
        /// The data table column which is bound to the DataValueField field.
        /// </param>
        /// <param name="textColumn">
        /// The data table column which is bound to the DataTextField field.
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillDropDownListFromTable(ref CfiDropDownList ddl, DataTable dt, string valueColumn, string textColumn, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            ddl.Items.Clear();
            if(dt != null && dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = textColumn;
                ddl.DataValueField = valueColumn;
                ddl.DataBind();
            }

            if(firstValue != null || firstText != null)
            {
                ddl.Items.Insert(addAdditionalValueInStarting ? 0 : ddl.Items.Count - 1,
                                 new ListItem(firstText, firstValue));
                ddl.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// Method to fill the drop table, along with setting the additional firt text and value in the beginning or in the end of the data table.
        /// </summary>
        /// <param name="ddl">
        /// The reference to drop down list from which the value or text is to be filled to datatable.
        /// </param>
        /// <param name="dt">
        /// The reference to the datatable. The default bind first two columns in this datatable..
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillDataTableFromDropDown(CfiDropDownList ddl, DataTable dt, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            ddl.Items.Clear();
            if(dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = dt.Columns[1].ColumnName;
                ddl.DataValueField = dt.Columns[0].ColumnName;
                ddl.DataBind();
            }

            if(firstValue != null || firstText != null)
                ddl.Items.Insert(addAdditionalValueInStarting ? 0 : ddl.Items.Count - 1, new ListItem(firstText, firstValue));
        }

        /// <summary>
        /// Method to fill the drop down list from an Enum.
        /// </summary>
        /// <param name="ddl">
        /// The reference to drop down list in which the data is to be bound.
        /// </param>
        /// <param name="enumType">
        /// The typeof enum which will fill the drop down list.
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillDropDownListFromEnum(CfiDropDownList ddl, Type enumType, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            Array values = Enum.GetValues(enumType);
            foreach(int val in values)
                ddl.Items.Add(new ListItem(Enum.GetName(enumType, val).Replace('_', ' '), val.ToString()));
            if(firstValue != null || firstText != null)
                ddl.Items.Insert(addAdditionalValueInStarting ? 0 : ddl.Items.Count - 1, new ListItem(firstText, firstValue));
        }

        /// <summary>
        /// Method to fill the list box from an Enum.
        /// </summary>
        /// <param name="lbx">
        /// The reference to list box in which the data is to be bound.
        /// </param>
        /// <param name="enumType">
        /// The typeof enum which will fill the drop down list.
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillListBoxFromEnum(ListBox lbx, Type enumType, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            Array values = Enum.GetValues(enumType);
            foreach(int val in values)
                lbx.Items.Add(new ListItem(Enum.GetName(enumType, val), val.ToString()));
            if(firstValue != null || firstText != null)
                lbx.Items.Insert(addAdditionalValueInStarting ? 0 : lbx.Items.Count - 1, new ListItem(firstText, firstValue));
        }

        /// <summary>
        /// Method to fill the check box list from a datatable.
        /// </summary>
        /// <param name="cbl">
        /// The reference to list box in which the data is to be bound.
        /// </param>
        /// <param name="dt">
        /// The typeof enum which will fill the drop down list.
        /// </param>
        /// <param name="chkBoxColumn">
        /// The data table column which is bound to the checkbox field.
        /// </param>
        /// <param name="textColumn">
        /// The data table column which is bound to the text field.
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillCheckBoxListFromDataTable(CheckBoxList cbl, DataTable dt, string chkBoxColumn, string textColumn, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            cbl.Items.Clear();
            if(dt.Rows.Count > 0)
            {
                cbl.DataSource = dt;
                cbl.DataTextField = textColumn;
                cbl.DataValueField = chkBoxColumn;
                cbl.DataBind();
            }

            if(firstValue != null || firstText != null)
                cbl.Items.Insert(addAdditionalValueInStarting ? 0 : cbl.Items.Count - 1, new ListItem(firstText, firstValue));
        }

        /// <summary>
        /// Method to fill the radio button list from an Enum.
        /// </summary>
        /// <param name="rbl">
        /// The reference to radio button list in which the data is to be bound.
        /// </param>
        /// <param name="enumType">
        /// The typeof enum which will fill the drop down list.
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillRadioButtonListFromEnum(RadioButtonList rbl, Type enumType, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            Array values = Enum.GetValues(enumType);
            if(enumType.Name == "Active")
                Array.Reverse(values);
            foreach(int val in values)
                rbl.Items.Add(new ListItem(Enum.GetName(enumType, val).Replace('_', ' '), val.ToString()));
            if(firstValue != null || firstText != null)
                rbl.Items.Insert(addAdditionalValueInStarting ? 0 : rbl.Items.Count - 1, new ListItem(firstText, firstValue));
            if(values.Length > 0)
                rbl.SelectedIndex = 0;
            if(enumType.Name == "Active")
                rbl.SelectedValue = "0";
        }

        /// <summary>
        /// Method to fill the CheckBoxList from an Enum.
        /// </summary>
        /// <param name="chk">
        /// The chk.
        /// </param>
        /// <param name="enumType">
        /// The typeof enum which will fill the Checkbox list.
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines whether to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillCheckBoxListFromEnum(CheckBoxList chk, Type enumType, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            Array values = Enum.GetValues(enumType);
            foreach(int val in values)
                chk.Items.Add(new ListItem(Enum.GetName(enumType, val), val.ToString()));
            if(firstValue != null || firstText != null)
                chk.Items.Insert(addAdditionalValueInStarting ? 0 : chk.Items.Count - 1, new ListItem(firstText, firstValue));
        }

        /// <summary>
        /// Method to fill the drop down list from the List box control.
        /// </summary>
        /// <param name="ddl">
        /// The reference to drop down list from which the value or text is to be filled to datatable.
        /// </param>
        /// <param name="lst">
        /// The reference to the listbox. The default bind first two columns in this datatable..
        /// </param>
        /// <param name="firstValue">
        /// The first value to be displayed. Like the value for '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="firstText">
        /// The first text to be displayed. Like '---Select---'. Enter null if not required.
        /// </param>
        /// <param name="addAdditionalValueInStarting">
        /// Determines weather to add first value and first text in the beginning or the end of the control being bound.
        /// </param>
        public static void FillDropDownListFromListItems(ref CfiDropDownList ddl, ref ListBox lst, string firstValue, string firstText, bool addAdditionalValueInStarting)
        {
            ddl.Items.Clear();
            int listCount = lst.Items.Count;
            if(listCount != 0)
            {
                for(int i = 0; i < listCount; i++)
                    ddl.Items.Add(lst.Items[i]);
            }

            if(firstValue != null || firstText != null)
                ddl.Items.Insert(addAdditionalValueInStarting ? 0 : ddl.Items.Count - 1, new ListItem(firstText, firstValue));
            ddl.SelectedIndex = 0;
        }

        /// <summary>
        /// Method to get the dataset from the parameter passed.
        /// </summary>
        /// <param name="ddl">
        /// The drop down list which will be used to get the dataset.
        /// </param>
        /// <returns>
        /// A dataset out of the dropdown list passed as parameter.
        /// </returns>
        public static DataSet GetDataSetFromDropDownList(CfiDropDownList ddl)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Value"));
            dt.Columns.Add(new DataColumn("Text"));
            foreach(ListItem li in ddl.Items)
            {
                DataRow dr = dt.NewRow();
                dr["Value"] = li.Value;
                dr["Text"] = li.Text;
                dt.Rows.Add(dr);
            }

            ds.Tables.Add(dt);
            return ds;
        }

        /// <summary>
        /// Method to get the dataset from the parameter passed.
        /// </summary>
        /// <param name="lb">
        /// The list which will be used to get the dataset.
        /// </param>
        /// <returns>
        /// A dataset out of the list passed as parameter.
        /// </returns>
        public static DataSet GetDataSetFromListBox(ListBox lb)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Value"));
            dt.Columns.Add(new DataColumn("Text"));
            foreach(ListItem li in lb.Items)
            {
                DataRow dr = dt.NewRow();
                dr["Value"] = li.Value;
                dr["Text"] = li.Text;
                dt.Rows.Add(dr);
            }

            ds.Tables.Add(dt);
            return ds;
        }

        /// <summary>
        /// Mehod to truncate the string default to 15 length with added '...' at the end after 15 chars.
        /// </summary>
        /// <param name="strText">
        /// The text to be truncated.
        /// </param>
        /// <returns>
        /// The truncated text.
        /// </returns>
        public string TruncateString(string strText)
        {
            if(strText.Length > 15)
                return strText.Substring(0, 15) + " ...";

            return strText;
        }

        /// <summary>
        /// Method to get the trucated string with added '...' at the end after specified length addressed.
        /// </summary>
        /// <param name="strText">
        /// The text to be truncated.
        /// </param>
        /// <param name="length">
        /// The length upto which the string is to be truncted.
        /// </param>
        /// <returns>
        /// The truncated text.
        /// </returns>
        public static string TruncateString(string strText, int length)
        {
            if(strText != null && strText.Length > length)
                return strText.Substring(0, length - 3) + "...";
            return strText;
        }

        /// <summary>
        /// Method to find a control on a page or form within the specified container control.
        /// </summary>
        /// <param name="container">
        /// The container in which the control passes as parameter 'ID' is to be found.
        /// </param>
        /// <param name="ID">
        /// The ID of the control that is to be found.
        /// </param>
        /// <returns>
        /// Returns the object of the control which is sought and null if the control is not found in the container.
        /// </returns>
        public static Control FindControlRecursive(Control container, string ID)
        {
            if(container.ID == ID)
                return container;

            foreach(Control ctrl in container.Controls)
            {
                Control foundCtrl = FindControlRecursive(ctrl, ID);
                if(foundCtrl != null)
                    return foundCtrl;
            }

            return null;
        }

        /// <summary>
        /// Function to itterate through all the controls in the tree.
        /// </summary>
        /// <param name="htControlsToConvert">
        /// Optional parameter to convert only those controls which are specified in the hashtable (Insert ID in key and value pair). Specify null if all the controls in the container (3rd parameter) are required to be converted to label.
        /// </param>
        /// <param name="container">
        /// The container contains that web control which contains all those web controls which are needed to be converted to labels.
        /// </param>
        public static void ChangeControlsToLabel(Hashtable htControlsToConvert, Control container)
        {
            ChangeControlsToLabel(htControlsToConvert, container, true);
        }

        /// <summary>
        /// Function to itterate through all the controls in the tree.
        /// </summary>
        /// <param name="htControls">
        /// Optional parameter to convert only those controls which are specified in the hashtable (Insert ID in key and value pair). Specify null if all the controls in the container (3rd parameter) are required to be converted to label.
        /// </param>
        /// <param name="container">
        /// The container contains that web control which contains all those web controls which are needed to be converted to labels.
        /// </param>
        /// <param name="convertHashtableControlsToLabel">
        /// The convert Hashtable Controls To Label. If 'true' then the controls with ID's in hastable will be converted, else they will be ignored and others will be converted.
        /// </param>
        public static void ChangeControlsToLabel(Hashtable htControls, Control container, bool convertHashtableControlsToLabel)
        {
            // If the controls is null then the default controls to convert will be considers those are...
            for(int i = 0; i < container.Controls.Count; i++)
            {
                Control ctrl = container.Controls[i];
                if(container.GetType().ToString() != "System.Web.UI.UpdatePanel" && ctrl.ClientID == null)
                    continue;
                if(htControls != null)
                    if(htControls.Contains(ctrl.ClientID == null ? String.Empty : ctrl.ID) && convertHashtableControlsToLabel)
                        continue;
                try
                {
                    ChangeControlsToLabel(ctrl, container, i);
                    ChangeControlsToLabel(htControls, ctrl, convertHashtableControlsToLabel);
                }
                catch
                {
                    continue;
                }
            }
        }

        /// <summary>
        /// Method to convert a contol to label placed on a specified index of the container.
        /// </summary>
        /// <param name="ctrl">
        /// The control needed to be convert.
        /// </param>
        /// <param name="container">
        /// The container contains that web control which contains all those web controls which are needed to be converted to labels.
        /// </param>
        /// <param name="i">
        /// The index of the container where it is to be replaced with the label.
        /// </param>
        private static void ChangeControlsToLabel(Control ctrl, Control container, int i)
        {
            Label lbl;
            switch(ctrl.GetType().ToString())
            {
                case "System.Web.UI.WebControls.TextBox":
                case "Cfi.SoftwareFactory.WebControls.CfiTextBox":
                case "Cfi.SoftwareFactory.WebControls.CfiDatePicker":
                case "Cfi.SoftwareFactory.WebControls.CfiAutocomplete":
                case "Cfi.SoftwareFactory.WebControls.CfiTimePicker":
                    lbl = new Label { Text = ((TextBox)ctrl).Text };
                    container.Controls.RemoveAt(i);
                    container.Controls.AddAt(i, lbl);
                    break;
                case "Cfi.SoftwareFactory.WebControls.CfiDropDownList":
                    lbl = new Label { Text = ((CfiDropDownList)ctrl).SelectedValue == String.Empty ? "N/A" : ((CfiDropDownList)ctrl).SelectedItem.Text };
                    container.Controls.RemoveAt(i);
                    container.Controls.AddAt(i, lbl);
                    break;
                case "System.Web.UI.WebControls.RadioButtonList":
                    lbl = new Label { Text = ((RadioButtonList)ctrl).SelectedItem == null ? String.Empty : ((RadioButtonList)ctrl).SelectedItem.Text };
                    container.Controls.RemoveAt(i);
                    container.Controls.AddAt(i, lbl);
                    break;
                case "System.Web.UI.WebControls.CheckBoxList":
                    lbl = new Label { Text = String.Empty };
                    CheckBoxList cbl = (CheckBoxList)ctrl;
                    foreach(ListItem li in cbl.Items)
                        if(li.Selected)
                            lbl.Text += li.Text + (cbl.AccessKey == "C" ? ", " : "<br />");
                    if(cbl.AccessKey == "C")
                    {
                        lbl.Text.Substring(0, lbl.Text.Length - 3);
                        lbl.Text += ".";
                    }

                    container.Controls.RemoveAt(i);
                    container.Controls.AddAt(i, lbl);
                    break;
                case "System.Web.UI.WebControls.RequiredFieldValidator":
                case "System.Web.UI.WebControls.CompareValidator":
                case "System.Web.UI.WebControls.CustomValidator":
                case "System.Web.UI.WebControls.RangeValidator":
                case "System.Web.UI.WebControls.RegularExpressionValidator":
                case "Cfi.SoftwareFactory.WebControls.CfiRequiredFieldValidator":
                case "Cfi.SoftwareFactory.WebControls.CfiCompareValidator":
                case "Cfi.SoftwareFactory.WebControls.CfiCustomValidator":
                case "Cfi.SoftwareFactory.WebControls.CfiRangeValidator":
                case "Cfi.SoftwareFactory.WebControls.CfiRegularExpressionValidator":
                    lbl = new Label { Text = String.Empty };
                    container.Controls.RemoveAt(i);
                    container.Controls.AddAt(i, lbl);
                    break;
                case "System.Web.UI.WebControls.ListBox":
                    lbl = new Label { Text = String.Empty };
                    foreach(ListItem li in ((ListBox)ctrl).Items)
                        if(li.Selected)
                            lbl.Text += li.Text + "<br />";
                    container.Controls.RemoveAt(i);
                    container.Controls.AddAt(i, lbl);
                    break;
                case "System.Web.UI.WebControls.CheckBox":
                    lbl = new Label { Text = String.Empty };
                    CheckBox cb = (CheckBox)ctrl;
                    lbl.Text = cb.Checked ? "<img src='../images/CheckBoxChecked.gif' height='13' width='13'>" : "<img src='../images/CheckBoxUnchecked.png'  height='13' width='13'>";
                    container.Controls.RemoveAt(i);
                    container.Controls.AddAt(i, lbl);
                    break;
            }
        }

        /// <summary>
        /// Function to itterate through all the controls in the tree.
        /// </summary>
        /// <param name="controlsToClear">
        /// Optional parameter to clear only those controls which are specified in the object array. Specify null if all the controls in the container (3rd parameter) are required to be cleared.
        /// </param>
        /// <param name="container">
        /// The container contains that web control which contains all those web controls which are needed to be cleared.
        /// </param>
        public static void ClearControlValues(object[] controlsToClear, Control container)
        {
            // If the controls is null then the default controls to convert will be considers those are...
            // TextBox, CfiDropDownList, RadioButton, Checkbox, 
            // These will be converted to System.Web.UI.WebControls.Label.
            for(int i = 0; i < container.Controls.Count; i++)
            {
                Control ctrl = container.Controls[i];
                try
                {
                    if(ctrl.GetType().ToString() == "System.Web.UI.WebControls.TextBox")
                        ((TextBox)ctrl).Text = string.Empty;
                    else if(ctrl.GetType().ToString() == "Cfi.SoftwareFactory.WebControls.CfiTextBox")
                        ((CfiTextBox)ctrl).Text = string.Empty;
                    else if (ctrl.GetType().ToString() == "Cfi.SoftwareFactory.WebControls.CfiDropDownList")
                        ((CfiDropDownList)ctrl).SelectedIndex = 0;
                    else if(ctrl.GetType().ToString() == "System.Web.UI.WebControls.RadioButtonList")
                        ((RadioButtonList)ctrl).SelectedIndex = 0;
                    else if(ctrl.GetType().ToString() == "System.Web.UI.WebControls.CheckBoxList")
                        ((CheckBoxList)ctrl).SelectedIndex = 0;
                    else if(ctrl.GetType().ToString() == "System.Web.UI.WebControls.ListBox")
                        ((ListBox)ctrl).SelectedIndex = -1;
                    else if(ctrl.GetType().ToString() == "System.Web.UI.WebControls.HiddenField")
                        ((HiddenField)ctrl).Value = string.Empty;

                    ClearControlValues(controlsToClear, ctrl);
                }
                catch
                {
                    continue;
                }
            }
        }

        /// <summary>
        /// Method to skin the required controls inside a container.
        /// </summary>
        /// <param name="controlsToSkin">
        /// Optional parameter to skin only those controls which are specified in the object array. Specify null if all the controls in the container (3rd parameter) are required to be cleared.
        /// </param>
        /// <param name="container">
        /// The container contains that web control which contains all those web controls which are needed to be skined inside this container.
        /// </param>
        /// <param name="cssClassToApply">
        /// The css class that should be applied to the required fields.
        /// </param>
        public static void SetRequiredFieldsSkin(object[] controlsToSkin, Control container, string cssClassToApply)
        {
            // If the controls is null then the default controls to convert will be considers those are...
            // TextBox, CfiDropDownList, RadioButton, Checkbox, 
            // These will be converted to System.Web.UI.WebControls.Label.
            for(int i = 0; i < container.Controls.Count; i++)
            {
                Control ctrl = container.Controls[i];
                try
                {
                    if(ctrl.GetType().ToString() == "System.Web.UI.WebControls.RequiredFieldValidator" || ctrl.GetType().ToString() == "Cfi.SoftwareFactory.WebControls.CfiRequiredFieldValidator")
                    {
                        Control requiredControl = FindControlRecursive(container, ((RequiredFieldValidator)ctrl).ControlToValidate);
                        switch(requiredControl.GetType().ToString())
                        {
                            case "Cfi.SoftwareFactory.WebControls.CfiTextBox":
                            case "Cfi.SoftwareFactory.WebControls.CfiDatePicker":
                            case "System.Web.UI.WebControls.TextBox":
                            case "Cfi.SoftwareFactory.WebControls.CfiDropDownList":
                            case "System.Web.UI.WebControls.ListBox":
                                ((WebControl)requiredControl).CssClass = cssClassToApply;
                                break;
                        }
                    }

                    SetRequiredFieldsSkin(controlsToSkin, ctrl, cssClassToApply);
                }
                catch
                {
                    continue;
                }
            }
        }

        /// <summary>
        /// Method to get the xml string from the datatable passed.
        /// </summary>
        /// <param name="dt">
        /// The datatable out of which the xml is to be retrieved.
        /// </param>
        /// <returns>
        /// The xml in the string format.
        /// </returns>
        public static string GetXMLFromDataTable(DataTable dt)
        {
            StringWriter sw = new StringWriter();
            dt.WriteXml(sw, XmlWriteMode.IgnoreSchema);
            return sw.ToString();
        }

        /// <summary>
        /// Method to check is it valid number.
        /// </summary>
        /// <param name="number">
        /// provide a valid string to check valid number
        /// </param>
        /// <returns>
        /// The is number.
        /// </returns>
        public static bool IsNumber(string number)
        {
            if(!string.IsNullOrEmpty(number))
            {
                if(Convert.ToDecimal(number) > 0)
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
    }
}