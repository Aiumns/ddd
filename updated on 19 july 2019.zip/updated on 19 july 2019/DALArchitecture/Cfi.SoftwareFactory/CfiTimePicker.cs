﻿/* CfiTimePicker Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   To get a time picker control comprised with all validations.
 * Created By           :   Dhiraj Kumar.
 * Created On           :   19 June 2010.
*/

using System;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

[assembly: TagPrefix("Cfi.Software Factory.WebControls", "Cfi")]

namespace Cfi.SoftwareFactory.WebControls
{
    public class CfiTimePicker : TextBox
    {

        /// <summary>
        /// Get or set the Default Selected Date in the form of string in "hh:mm tt" format.
        /// </summary>
        private string timeFormat = "hh:mmtt";

        /// <summary>
        /// Get or set the Default Selected Time in the form of string in "hh:mm tt" format.
        /// </summary>
        public string DefaultSelectedTimeText
        {
            get
            {
                try
                {
                    DateTime dt = DateTime.Parse(Text, CultureInfo.CurrentCulture);
                    return dt.ToString(timeFormat);
                }
                catch
                {
                    return Text;
                }
            }
        }


        /// <summary>
        /// Get or set the Selected Date of the CfiTimePicker control.
        /// </summary>
        public DateTime SelectedTime
        {
            get
            {
                DateTime dt = DateTime.Parse(Text, CultureInfo.CurrentCulture);
                return dt;
            }
            set
            {
                Text = value.ToString(timeFormat);
            }
        }



        protected override void OnPreRender(EventArgs e)
        {

            // For assigining the JQuery Popup Calendar in the Date TextBox.
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "TimePicker" + this.ClientID, @"$(function () {
	$('#" + this.ClientID + @"').timeEntry({spinnerImage: '" + Page.ResolveUrl("~/Images/TimePicker.png") + @"'});
});
", true);

            // For assigning the JQuery Watermark in the Date TextBox.
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "WaterMark" + ClientID, @"$(
                    function() 
                    {
                        $('#" + ClientID + "').watermark('" + timeFormat + @"');
                    }
                );", true);


            // Added a external Javascript file for the Control.
            //ScriptManager.RegisterClientScriptResource(this, GetType(), "Cfi.SoftwareFactory.Resources.Scripts.jquery.watermark.js");
            ScriptManager.RegisterClientScriptResource(this, GetType(), "Cfi.SoftwareFactory.Resources.Scripts.jquery.TimePicker.js");

            base.OnPreRender(e);
        }
    }
}