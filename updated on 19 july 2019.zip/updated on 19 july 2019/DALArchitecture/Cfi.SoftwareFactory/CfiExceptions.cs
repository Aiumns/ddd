using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Runtime.Serialization;
using System.Threading;
using System.Web;
using Cfi.SoftwareFactory.Data;



namespace Cfi.SoftwareFactory.Common
{
    public class CfiExceptions : ApplicationException
    {
        private readonly Exception innerException;
        private string applicationDomainName;
        private string assemblyName;
        private string assemblyVersion;
        private string callStack;
        private string clientDetails;
        private DateTime dateTimeOfException;
        private string machineName;
        private string message;
        private string requestedUrl;
        private string source;
        private string stackTrace;
        private string supportInformation;
        private string technicalInformation;
        private string threadId;
        private string threadUser;
        private string type;
        private string userId;
        private string whatActionsCanUserDo;
        private string whatHappened;
        private string whatHasBeenAffected;

        public CfiExceptions(string message) : base(message) { }

        public CfiExceptions(string message, Exception inner) : base(message, inner) { innerException = inner; }

        public CfiExceptions(string message, Exception inner, string whatHappened, string whatHasBeenAffected, string whatActionsCanUserDo, string supportInformation)
            : base(message, inner)
        {
            innerException = inner;
            this.whatHappened = whatHappened;
            this.whatHasBeenAffected = whatHasBeenAffected;
            this.whatActionsCanUserDo = whatActionsCanUserDo;
            this.supportInformation = supportInformation;
        }

        protected CfiExceptions(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            whatHappened = info.GetString("whatHappened");
            whatHasBeenAffected = info.GetString("whatHasBeenAffected");
            whatActionsCanUserDo = info.GetString("whatActionsCanUserDo");
            supportInformation = info.GetString("supportInformation");
        }

        /// <summary>
        /// Get the machine name from where the exception evolved.
        /// </summary>
        public string MachineName
        {
            get
            {
                machineName = Environment.MachineName;
                return machineName;
            }
        }

        /// <summary>
        /// Get the source of the exception.
        /// </summary>
        public string Source
        {
            get
            {
                source = innerException.Source;
                return source;
            }
        }

        /// <summary>
        /// Get the type of the exception.
        /// </summary>
        public string Type
        {
            get
            {
                type = GetType().FullName;
                return type;
            }
        }

        /// <summary>
        /// Get the messge of the exception.
        /// </summary>
        public string Message
        {
            get
            {
                message = innerException.Message;
                return message;
            }
        }

        /// <summary>
        /// Get the stackTrace of the exception.
        /// </summary>
        public string StackTrace
        {
            get
            {
                stackTrace = innerException.StackTrace;
                return stackTrace;
            }
        }

        /// <summary>
        /// Get the enviromentStackTrace of the exception.
        /// </summary>
        public string EnviromentStackTrace
        {
            get
            {
                callStack = Environment.StackTrace;
                return callStack;
            }
        }

        /// <summary>
        /// Get the application domain name where the exception occured.
        /// </summary>
        public string ApplicationDomainName
        {
            get
            {
                applicationDomainName = AppDomain.CurrentDomain.FriendlyName;
                return applicationDomainName;
            }
        }

        /// <summary>
        /// Get the assembly name where the exception occured.
        /// </summary>
        public string AssemblyName
        {
            get
            {
                //this.assemblyName = System.Reflection.AssemblyName.GetAssemblyName(.Name;
                return assemblyName;
            }
        }

        /// <summary>
        /// Get the assembly version where the exception occured.
        /// </summary>
        public string AssemblyVersion
        {
            get
            {
                //this.assemblyVersion = System.Reflection.AssemblyName.GetAssemblyName().Version;
                return assemblyVersion;
            }
        }

        /// <summary>
        /// Get the id of the thread in which the exception occured.
        /// </summary>
        public string ThreadId
        {
            get
            {
                threadId = AppDomain.GetCurrentThreadId().ToString();
                return threadId;
            }
        }

        /// <summary>
        /// Get the user of the thread by which the exception occured.
        /// </summary>
        public string ThreadUser
        {
            get
            {
                threadUser = Thread.CurrentPrincipal.ToString();
                return threadUser;
            }
        }

        /// <summary>
        /// Get the current Url which caused the error (Helps in rectifying File not found exceptions which are caught in the application error).
        /// </summary>
        public string RequestedUrl
        {
            get
            {
                requestedUrl = HttpContext.Current.Request.Url.ToString();
                return requestedUrl;
            }
        }

        /// <summary>
        /// Get the detailed technical information.
        /// </summary>
        public string TechnicalInformation
        {
            get
            {
                technicalInformation = "Machine Name:" + MachineName + "</BR>" + "Exception Source: " + Source + " </BR>" + "Exception Type: " + Type + " </BR>" + "Exception Message" + Message + " </BR>" + "Stack Trace: " + StackTrace + " </BR>" + "Call Trace: " + EnviromentStackTrace + " </BR>" + "Application Domain Name: " + ApplicationDomainName + " </BR>" + "Assembly Name" + AssemblyName + " </BR>" + "Assembly Version: " + AssemblyVersion + " </BR>" + "Thread Id: " + ThreadId + " </BR>" + "Thread User: " + ThreadUser + " </BR>" + "Requested Url: " + RequestedUrl + " </BR>" + "Date Time Of Exception: " + DateTimeOfException + " </BR>" + "User Id: " + UserId;
                return technicalInformation;
            }
        }

        /// <summary>
        /// Get the date and time when the exception occured.
        /// </summary>
        public DateTime DateTimeOfException
        {
            get
            {
                dateTimeOfException = DateTime.Now;
                return dateTimeOfException;
            }
        }

        /// <summary>
        /// Get the application user id by whom the exception occured.
        /// </summary>
        public string UserId
        {
            get
            {
                userId = (HttpContext.Current.Session["UserId"] == null) ? "" : HttpContext.Current.Session["UserId"].ToString();
                return userId;
            }
        }

        /// <summary>
        /// Get or set what actually has happened. Probably the message of the custom error handler.
        /// </summary>
        public string WhatHappened { get { return whatHappened; } set { whatHappened = value; } }

        /// <summary>
        /// Get or set which activity of the user is affected.
        /// </summary>
        public string WhatHasBeenAffected { get { return whatHasBeenAffected; } set { whatHasBeenAffected = value; } }

        /// <summary>
        /// Get or set the actions that a user can perform alternatively.
        /// </summary>
        public string WhatActionsCanUserDo { get { return whatActionsCanUserDo; } set { whatActionsCanUserDo = value; } }

        /// <summary>
        /// Get or set support information that needs to be displayed to the end user.
        /// </summary>
        public string SupportInformation { get { return supportInformation; } set { supportInformation = value; } }

        public string ClientDetails
        {
            get
            {
                clientDetails = HttpContext.Current.Request.ServerVariables["ALL_HTTP"];
                return clientDetails;
            }
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("whatHasBeenAffected", whatHasBeenAffected, typeof(string));
            info.AddValue("whatActionsCanUserDo", whatActionsCanUserDo, typeof(string));
            info.AddValue("supportInformation", supportInformation, typeof(string));
            info.AddValue("whatHappened", whatHappened, typeof(string));
            base.GetObjectData(info, context);
        }

        /// <summary>
        /// Method to insert the exception detail in the database.
        /// </summary>
        public void InsertExceptionIntoDatabase(bool sendMail)
        {
            SqlParameter[] parameters = {
                                        new SqlParameter("@MachineName", MachineName), 
                                        new SqlParameter("@Source", Source), 
                                        new SqlParameter("@Type", Type), 
                                        new SqlParameter("@Message", Message), 
                                        new SqlParameter("@StackTrace", StackTrace), 
                                        new SqlParameter("@EnviromentStackTrace", EnviromentStackTrace),                                                new SqlParameter("@ApplicationDomainName", ApplicationDomainName), 
                                        new SqlParameter("@AssemblyName", AssemblyName), 
                                        new SqlParameter("@AssemblyVersion", AssemblyVersion),
                                        new SqlParameter("@ThreadId", ThreadId), 
                                        new SqlParameter("@ThreadUser", ThreadUser), 
                                        new SqlParameter("@WhatHappened", WhatHappened), 
                                        new SqlParameter("@WhatHasBeenAffected", WhatHasBeenAffected), 
                                        new SqlParameter("@WhatActionsCanUserDo", WhatActionsCanUserDo), 
                                        new SqlParameter("@SupportInformation", SupportInformation), 
                                        new SqlParameter("@ClientDetails", ClientDetails),
                                        new SqlParameter("@RequestedUrl", RequestedUrl), 
                                        new SqlParameter("@DateTimeOfException", DateTimeOfException),
                                        new SqlParameter("@UserId", UserId)
                                        };
            SqlHelper.ExecuteScalar(ConnectionString.WebConfigConnectionString, "InsertExceptions", parameters);
            
            if (sendMail)
            {
                //SendExceptionMail("", 2, "", "", "", "", "CFCS Application", TechnicalInformation);
            }
                
        }

        /// <summary>
        /// Method to send the mail to the required authority.
        /// </summary>
        public void SendExceptionMail(string mailServer, int port, string mailServerUserId, string mailServerPassword, string from, string to, string applicationName, string body)
        {
            if (!string.IsNullOrEmpty(mailServer))
            {
                MailMessage msg = new MailMessage();
                msg.To.Add(to);
                msg.From = new MailAddress(from);
                msg.Subject = "Error in application: " + applicationName;
                msg.IsBodyHtml = true;
                msg.Body = body;
                try
                {
                    SmtpClient sClient = new SmtpClient();
                    sClient.Host = mailServer;
                    if (port != 0)
                        sClient.Port = port;
                    if (!string.IsNullOrEmpty(mailServerUserId))
                        sClient.Credentials = new NetworkCredential(mailServerUserId, mailServerPassword);
                    sClient.Send(msg);
                }
                catch (Exception ex)
                {
                    ///TODO: The appropriate msg that says that mail could not be send. if this is not handled then app error handling is barbad. lol.
                }
            }
        }

        public void GetUserExceptionMessagesFromDatabase(string methodName)
        {
            SqlParameter[] parameters = { new SqlParameter("@MethodName", methodName) };
            SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(ConnectionString.WebConfigConnectionString, "GetUserExceptionMessagesFromDatabase", parameters);
            while (sqlDataReader.Read())
            {
                WhatHappened = sqlDataReader["WhatHappened"].ToString();
                WhatHasBeenAffected = sqlDataReader["WhatHasBeenAffected"].ToString();
                WhatActionsCanUserDo = sqlDataReader["WhatActionsCanUserDo"].ToString();
                SupportInformation = sqlDataReader["SupportInformation"].ToString();
            }
        }
    }
}