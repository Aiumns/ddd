﻿/* CfiDatePicker Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   The custom validator used to make the Date Control for every page.
 * Created By           :   Chandra Prakash.
 * Created On           :   13 Jan 2010.
 * Modified By          :   Sudhir Yadav.
 * Modified On          :   21 Jan 2010.
 * Description          :   Changed the script registering code OnPreRender. 
 * Modified By          :   Chandra Prakash.
 * Modified On          :   09 Apr 2010.
 * Description          :   Removed the Culture Dictionary Object and changed the DateTime Format to Current Culture.
 *  Modified By          :  Dhiraj Kumar.
 * Modified On          :   21 June 2010.
 * Description          :   Modified the image path to make it dynamic.
*/

using System;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for CfiDatePicker
/// </summary>

[assembly: TagPrefix("Cfi.Software Factory.WebControls", "Cfi")]

namespace Cfi.SoftwareFactory.WebControls
{

    public class CfiDatePicker : TextBox
    {

        string dateFormat = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;

        /// <summary>
        /// Get or set the Default Selected Date in the form of string in "M/d/yyyy" format.
        /// </summary>
        public string DefaultSelectedDateText
        {
            get
            {
                try
                {
                    DateTime dt = DateTime.Parse(Text, CultureInfo.CurrentCulture);
                    return dt.ToString(dateFormat);
                }
                catch
                {
                    return Text;
                }
            }
        }

        /// <summary>
        /// Get or set the Selected Date of the CfiDatePicker control.
        /// </summary>
        public DateTime SelectedDate
        {
            get
            {
                try
                {
                    DateTime dt = DateTime.Parse(Text, CultureInfo.CurrentCulture);
                    return dt;
                }
                catch
                {
                    throw new CfiDatePickerException("Enter the Date in Date Picker Control.");
                }
            }
            set { Text = value.ToString(dateFormat); }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            //Autocomplete...
            if(AutoCompleteType == AutoCompleteType.Disabled || AutoCompleteType == AutoCompleteType.None)
                Attributes.Add("autocomplete", "off");

            // Added a function in Keypress for Check the character to not accepting the Alpha  
            Attributes.Add("onkeypress", "return CheckCharacter(event, this);" + Attributes["onKeyPress"]);

            base.RenderBeginTag(writer);
        }

        protected override void OnPreRender(EventArgs e)
        {
            // Get the Culture information according to the Culture Session

                string dateFormatConvert = dateFormat.Replace("M", "m").Replace("yy", "y");

                // For assigining the JQuery Popup Calendar in the Date TextBox.
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "DatePicker" + ClientID, @"  $(
                    function()
                    {
                        $('#" + ClientID + @"').datepicker(
                            {
                                showOn: 'button', 
                                buttonImage: '" + Page.ResolveUrl("~/Images/calendar.gif") + @"', 
                                buttonImageOnly: true, 
                                changeMonth: true, 
                                changeYear: true,   
                                dateFormat: '" + dateFormatConvert + @"'
                            }
                        );
                        $('#" + ClientID + @"').next().css({position: 'relative',left:'2px', top: '3px', cursor: 'pointer'});
                        //Set the blur event using jquery event bubbling...
                        $('#" + ClientID + @"').focusout(
                        function() 
                        {
                            return GetDate(this,'" + dateFormat + @"');
                        });
                    }
                ); var childcontrols = $('#" + ClientID + @"').parent().children();
                if (childcontrols.length > 2)
                $(childcontrols[2]).remove();", true);

            // For assigning the JQuery Watermark in the Date TextBox.
            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "WaterMark" + ClientID, @"$(
                    function() 
                    {
                        $('#" + ClientID + "').watermark('" + dateFormat + @"');
                    }
                );", true);

            // Added a external Javascript file for the Control.
            ScriptManager.RegisterClientScriptResource(this, GetType(), "Cfi.SoftwareFactory.Resources.Scripts.CfiDatePicker.js");
            ScriptManager.RegisterClientScriptResource(this, GetType(), "Cfi.SoftwareFactory.Resources.Scripts.jquery.watermark.js");
            base.OnPreRender(e);
        }
    }

    public class CfiDatePickerException : Exception
    {
        public CfiDatePickerException(string message) : base(message) { }
    }
}