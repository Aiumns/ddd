﻿using System;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Cfi.SoftwareFactory.Common.Utilities
{
    /// <summary>
    /// The code 128 encoder.
    /// </summary>
    public class Code128Encoder
    {
        // Methods
        /// <summary>
        /// The ansi to unicode.
        /// </summary>
        /// <param name="ansiString">
        /// The ansi string.
        /// </param>
        /// <returns>
        /// The ansi to unicode.
        /// </returns>
        private object AnsiToUnicode(string ansiString)
        {
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x80)), "€", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x91)), "‘", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x92)), "’", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x93)), "“", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x94)), "”", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x95)), "•", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(150)), "–", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x97)), "—", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x98)), "˜", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x99)), "™", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x9a)), "š", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x9b)), "›", 1, -1, CompareMethod.Binary);
            ansiString = Strings.Replace(ansiString, Conversions.ToString(Strings.Chr(0x9c)), "œ", 1, -1, CompareMethod.Binary);
            return ansiString;
        }

        /// <summary>
        /// The get char value.
        /// </summary>
        /// <param name="inchar">
        /// The inchar.
        /// </param>
        /// <returns>
        /// The get char value.
        /// </returns>
        private int GetCharValue(string inchar)
        {
            int num5;
            int num = Strings.Asc(inchar);
            int num4 = 0x20;
            int num3 = 0x12;
            if (num > 0x90)
                num5 = (num - num4) - num3;
            else
                num5 = num - num4;
            if (num == 0x80)
                num5 = 0;
            return num5;
        }

        /// <summary>
        /// The get check digit.
        /// </summary>
        /// <param name="Data">
        /// The data.
        /// </param>
        /// <returns>
        /// The get check digit.
        /// </returns>
        private string GetCheckDigit(string Data)
        {
            int num6 = 0;
            int num3 = 0x20;
            int num2 = 0x12;
            int num4 = 1;
            int num5 = Strings.Len(Data);
            int num7 = num5;
            for(int i = 1; i <= num7; i++)
            {
                string inchar = Strings.Mid(Data, i, 1);
                if (i == 1)
                    num6 += this.GetCharValue(inchar);
                else
                {
                    num6 += this.GetCharValue(inchar)*num4;
                    num4++;
                }
            }

            num6 = num6%0x67;
            if (num6 == 0)
                return Conversions.ToString(Strings.Chr(0x80));
            if ((num6 + num3) >= 0x7f)
                return Conversions.ToString(Strings.Chr((num6 + num3) + num2));
            return Conversions.ToString(Strings.Chr(num6 + num3));
        }

        /// <summary>
        /// The get code 128 data string.
        /// </summary>
        /// <param name="dataToEncode">
        /// The data to encode.
        /// </param>
        /// <returns>
        /// The get code 128 data string.
        /// </returns>
        public object GetCode128DataString(object dataToEncode)
        {
            int num5 = 0x20;
            int num4 = 0x12;
            int num3 = 0;
            int num7 = 1;
            int num8 = 2;
            string expression = string.Empty;

            string str5 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("", dataToEncode), ""));
            //string str5 = Conversions.ToString(dataToEncode);
            int num6 = Strings.Len(str5);
            if (num6 == 0)
                return string.Empty;
            int start = 1;
            int num9 = num6;
            for(int i = 1; i <= num9; i++)
            {
                string str2;
                if (start == num6)
                {
                    str2 = Strings.Mid(str5, start, 1);
                    if (num3 == 0)
                    {
                        expression = Conversions.ToString(Strings.Chr((0x68 + num5) + num4));
                        num3 = num7;
                    }

                    if (num3 == num8)
                    {
                        expression = expression + Conversions.ToString(Strings.Chr((100 + num5) + num4));
                        num3 = num7;
                    }

                    expression = expression + str2;
                    start++;
                }
                else
                {
                    str2 = Strings.Mid(str5, start, 1);
                    string testString = Strings.Mid(str5, start + 1, 1);
                    bool flag = this.NewNumericTest(str2);
                    if (flag)
                        flag = this.NewNumericTest(testString);
                    if (flag)
                    {
                        string inputStr = str2 + testString;
                        if (num3 == 0)
                        {
                            expression = Conversions.ToString(Strings.Chr((0x69 + num5) + num4));
                            num3 = num8;
                        }

                        if (num3 == num7)
                        {
                            expression = expression + Conversions.ToString(Strings.Chr((0x63 + num5) + num4));
                            num3 = num8;
                        }

                        expression = expression + Conversions.ToString(Strings.Chr(Conversions.ToInteger(this.GetCode3Char(inputStr))));
                        start += 2;
                    }
                    else
                    {
                        str2 = Strings.Mid(str5, start, 1);
                        if (num3 == 0)
                        {
                            expression = expression + Conversions.ToString(Strings.Chr((0x68 + num5) + num4));
                            num3 = num7;
                        }

                        if (num3 == num8)
                        {
                            expression = expression + Conversions.ToString(Strings.Chr((100 + num5) + num4));
                            num3 = num7;
                        }

                        expression = expression + str2;
                        start++;
                    }
                }

                if (start > num6)
                    break;
            }

            expression = Strings.Replace(expression, " ", Conversions.ToString(Strings.Chr(0x80)), 1, -1, CompareMethod.Binary);
            expression = expression + this.GetCheckDigit(expression) + Conversions.ToString(Strings.Chr((0x6a + num5) + num4));
            return Conversions.ToString(this.AnsiToUnicode(expression));
        }

        /// <summary>
        /// The get code 3 char.
        /// </summary>
        /// <param name="inputStr">
        /// The input str.
        /// </param>
        /// <returns>
        /// The get code 3 char.
        /// </returns>
        private string GetCode3Char(string inputStr)
        {
            int num = 0x20;
            int num2 = 0x12;
            int num3 = (int)Math.Round(Conversion.Val(inputStr));
            if (num3 == 0)
                return Conversions.ToString(0x60 + num);
            if ((num3 > 0) & (num3 < 0x5f))
                return Conversions.ToString(num3 + num);
            return Conversions.ToString((num3 + num) + num2);
        }

        /// <summary>
        /// The new numeric test.
        /// </summary>
        /// <param name="testString">
        /// The test string.
        /// </param>
        /// <returns>
        /// The new numeric test.
        /// </returns>
        private bool NewNumericTest(object testString)
        {
            int num = Conversions.ToInteger(NewLateBinding.LateGet(null, typeof(Strings), "Asc", new[] {RuntimeHelpers.GetObjectValue(testString)}, null, null, null));
            bool flag2 = false;
            if ((num >= 0x30) & (num <= 0x39))
                flag2 = true;
            return flag2;
        }
    }
}