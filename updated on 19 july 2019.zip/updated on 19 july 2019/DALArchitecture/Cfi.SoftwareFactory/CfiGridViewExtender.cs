using System;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
using Cfi.SoftwareFactory.Common;



namespace Cfi.SoftwareFactory.WebControls
{
    /// <summary>
    /// Summary description for GridViewExtender
    /// </summary>
    public class CfiGridViewExtender : WebControl
    {
        #region SortDirectionType enum
        public enum SortDirectionType
        {
            None,
            Ascending,
            Descending
        }
        #endregion

        private GridView gv;

        public string GridViewID { get { return ViewState["GridViewID"].ToString(); } set { ViewState["GridViewID"] = value; } }

        public bool AlphaPaging { get { return ViewState["AlphaPaging"] == null ? true : (bool)ViewState["AlphaPaging"]; } set { ViewState["AlphaPaging"] = value; } }

        public string AlphaPagingColumnName { get { return ViewState["AlphaPagingColumnName"] == null ? "" : ViewState["AlphaPagingColumnName"].ToString(); } set { ViewState["AlphaPagingColumnName"] = value; } }

        public DataTable DataTableInitial { get { return ViewState["DataTableInitial"] == null ? (DataTable)((GridView)CommonFunctions.FindControlRecursive(Parent, GridViewID)).DataSource : (DataTable)ViewState["DataTableInitial"]; } set { ViewState["DataTableInitial"] = value; } }

        public string FilteredAlphabet { get { return ViewState["FilteredAlphabet"] == null ? "" : ViewState["FilteredAlphabet"].ToString(); } set { ViewState["FilteredAlphabet"] = value; } }

        public bool ShowAllData { get { return ViewState["ShowAllData"] == null ? false : (bool)ViewState["ShowAllData"]; } set { ViewState["ShowAllData"] = value; } }

        public SortDirectionType SortDirectionGridView { get { return ViewState["SortDirectionGridView"] == null ? SortDirectionType.None : (SortDirectionType)ViewState["SortDirectionGridView"]; } set { ViewState["SortDirectionGridView"] = value; } }

        public string SortColumnGridView { get { return ViewState["SortColumnGridView"] == null ? "" : ViewState["SortColumnGridView"].ToString(); } set { ViewState["SortColumnGridView"] = value; } }

        public void DataBindWithAlphabeticPaging()
        {
            gv = (GridView)CommonFunctions.FindControlRecursive(Parent, GridViewID);
            DataTable dt = DataTableInitial;
            if(ShowAllData == null)
            {
                if(dt.Rows.Count > 0)
                    FilteredAlphabet = dt.Rows[0][AlphaPagingColumnName].ToString().Substring(0, 1).ToUpper();
                else if(ShowAllData)
                    FilteredAlphabet = "All";
                ShowAllData = false;
            }
            DataRow[] dr = null;
            if(SortColumnGridView == "")
                dr = dt.Select((FilteredAlphabet == null || FilteredAlphabet == "" || FilteredAlphabet == "All") ? "" : AlphaPagingColumnName + " LIKE '" + FilteredAlphabet + "%'");
            else if(SortDirectionGridView != SortDirectionType.None)
                dr = dt.Select((FilteredAlphabet == null || FilteredAlphabet == "" || FilteredAlphabet == "All") ? "" : AlphaPagingColumnName + " LIKE '%" + FilteredAlphabet + "%'", SortColumnGridView + " " + (SortDirectionGridView == SortDirectionType.Ascending ? "ASC" : "DESC"));

            DataTable dtTemp = new DataTable();
            foreach(DataColumn dc in dt.Columns)
                dtTemp.Columns.Add(new DataColumn(dc.ColumnName));
            foreach(DataRow dr1 in dr)
            {
                DataRow drTemp = dtTemp.NewRow();
                int noOfColumns = DataTableInitial.Columns.Count;
                for(int j = 0; j < noOfColumns; j++)
                    drTemp[j] = dr1[j];
                dtTemp.Rows.Add(drTemp);
            }
            gv.DataSource = dtTemp;
            DataTableInitial = dt;
            gv.ShowFooter = true;
            gv.DataBind();

            PlaceHolder ph = new PlaceHolder();
            TableCell cell = gv.FooterRow.Cells[0];
            cell.Controls.Clear();
            cell.ColumnSpan = gv.Columns.Count;
            AddAlphabeticPagingCell(ref ph, DataTableInitial, AlphaPagingColumnName);
            cell.Controls.Add(ph);
        }

        private void AddAlphabeticPagingCell(ref PlaceHolder cell, DataTable dt, string sortForColumnName)
        {
            int noOfRows = dt.Rows.Count;
            string firstCharacterVal = string.Empty;
            Hashtable ht = new Hashtable();
            LinkButton lb1 = new LinkButton();
            lb1.CausesValidation = false;
            lb1.Text = "All";
            lb1.CommandArgument = "All";
            lb1.CommandName = "AlphaPaging";
            lb1.Click += Ex;
            cell.Controls.Add(lb1);
            Label lbl1 = new Label();
            lbl1.Text = " ";
            cell.Controls.Add(lbl1);
            for(int i = 0; i < noOfRows; i++)
            {
                firstCharacterVal = dt.Rows[i][sortForColumnName].ToString().Substring(0, 1).ToUpper();
                if(firstCharacterVal == string.Empty || !ht.Contains(firstCharacterVal))
                {
                    ht.Add(firstCharacterVal, "");
                    LinkButton lb = new LinkButton();
                    lb.CausesValidation = false;
                    lb.Text = firstCharacterVal;
                    lb.CommandArgument = firstCharacterVal;
                    lb.CommandName = "AlphaPaging";
                    lb.Click += Ex;
                    cell.Controls.Add(lb);
                    Label lbl = new Label();
                    lbl.Text = " ";
                    cell.Controls.Add(lbl);
                }
            }
        }

        protected void Ex(Object sender, EventArgs e)
        {
            FilteredAlphabet = ((LinkButton)sender).CommandArgument;
            DataBindWithAlphabeticPaging();
        }
    }
}