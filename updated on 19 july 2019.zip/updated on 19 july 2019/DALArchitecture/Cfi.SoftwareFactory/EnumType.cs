﻿namespace Cfi.SoftwareFactory.BaseBusiness
{

    #region EnumType Objects
    /*
     *****************************************************************************
     Enum Name: 	EnumType      
     Purpose:		The enums used in the Software Factory.
     Company:		CargoFlash Infotech 
     Author:		Manish Kumar
     Created On:	26 Sep 2009
     Updated By:    Sudhir Yadav
     Updated On:    24 Dec 2009
     Update Desc:   Removed the enum types used in the application only and left with only the enum types which are used in software factory. The file name has been changed to EnumType.cs from EnumTypes.cs. The name space remains the same.
     *****************************************************************************
     */
    #endregion

    /// <summary>
    /// This enum use for showing the success or failure message of any operation in the application.
    /// </summary>
    public enum ResultType
    {
        Success = 0, //Shows when the result is success for any query or operation.
        Failed = 1, //Shows when the result is failure for any query or operation.
    }


    /// <summary>
    /// This enum use for set the DataOperation enum.
    /// </summary>
    public enum DataOperation
    {
        Create = 1, //this is used for Create Record.
        Update = 2, //this is used for Update Record.
        Delete = 3, //this is used for Delete.
        View = 4, //this is used for Read.
    } //End of Enum

    /// <summary>
    /// Enum for the mode, specific to the UI part. i.e. the display part.
    /// </summary>
    public enum UIMode
    {
        None,
        New,
        View,
        Update,
        Delete,
        Handover,
        Print,
        Label,
        CCA,
        Receipt,
        Plan
    }


    /// <summary>
    /// Enum return True/False
    /// </summary>
    public enum BoolType
    {
        True = 1,
        False = 0
    }
}