using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web;



namespace Cfi.SoftwareFactory.Common.HttpModules
{
    /// <summary>
    /// Summary description for QueryStringModule
    /// </summary>
    public class QueryStringModule : IHttpModule
    {
        private const string ENCRYPTION_KEY = "key";
        private const string PARAMETER_NAME = "enc=";
        private readonly ArrayList folderRejectionList = new ArrayList();
        private readonly ArrayList pageRejectionList = new ArrayList();
        private string[] permittedLinksToEncrypt;
        private string[] rejectedLinksNotToEncrypt;

        #region IHttpModule Members
        public void Dispose()
        {
            // Nothing to dispose
        }

        public void Init(HttpApplication context)
        {
            pageRejectionList.Add("CaptchaImageGenerator.aspx".ToLower());
            pageRejectionList.Add("WebResource.axd".ToLower());
            pageRejectionList.Add("ScriptResource.axd".ToLower());
            pageRejectionList.Add("BarCodeImageGenerator.aspx".ToLower());
            pageRejectionList.Add("Reserved.ReportViewerWebControl.axd".ToLower());
            pageRejectionList.Add("DisplayImage.aspx".ToLower());
            folderRejectionList.Add("Images".ToLower());
            folderRejectionList.Add("EDI".ToLower());
            folderRejectionList.Add("bin".ToLower());
            folderRejectionList.Add("PopCalendar2005".ToLower());
            folderRejectionList.Add("javascript".ToLower());
            folderRejectionList.Add("PopCalendar2005".ToLower());
            folderRejectionList.Add("css".ToLower());
            folderRejectionList.Add("Reports".ToLower());

            //Setting the pages or type of pages which are required to be encrypted, seperated by ';'...
            permittedLinksToEncrypt = new[] {"aspx", "?"};

            //Setting the pages or type of pages which are required not required to be encrypted, seperated by ';'...
            rejectedLinksNotToEncrypt = new[] {"axd", "ToolkitScript", "AjaxControlToolkit", ".js"};

            context.BeginRequest += context_BeginRequest;
        }
        #endregion

        private void context_BeginRequest(object sender, EventArgs e)
        {
            HttpContext context = HttpContext.Current;
            string currentUrl = HttpContext.Current.Request.Url.AbsolutePath.ToLower();
            string currentFileOrWebPageName = Path.GetFileName(currentUrl);
            string currentFolderName = Path.GetDirectoryName(currentUrl);
            currentFolderName = currentFolderName.Substring(currentFolderName.LastIndexOf("\\") + 1, (currentFolderName.Length - currentFolderName.LastIndexOf("\\")) - 1);
            if(!IsStringInList(currentUrl, rejectedLinksNotToEncrypt) && IsStringInList(currentUrl, permittedLinksToEncrypt) && currentUrl.Contains("?"))
            {
                string query = ExtractQuery(context.Request.RawUrl);
                string path = GetVirtualPath();

                if(query.StartsWith(PARAMETER_NAME, StringComparison.OrdinalIgnoreCase))
                {
                    // Decrypts the query string and rewrites the path.
                    string rawQuery = query.Replace(PARAMETER_NAME, string.Empty);
                    string decryptedQuery = Decrypt(rawQuery);
                    context.RewritePath(path, string.Empty, decryptedQuery.Replace("?", ""));
                }
                else if(context.Request.HttpMethod == "GET")
                {
                    // Encrypt the query string and redirects to the encrypted URL.
                    // Remove if you don't want all query strings to be encrypted automatically.
                    string encryptedQuery = query.Contains(PARAMETER_NAME) ? query : Encrypt(query);
                    context.Response.Redirect(path + encryptedQuery);
                }
            }
            //Set the static querystring dispyed as encrypted form...
            if(!pageRejectionList.Contains(currentFileOrWebPageName) && !folderRejectionList.Contains(currentFolderName))
                context.Response.Filter = new HyperLinkEncryptionFilter(context.Response.Filter);
        }

        /// <summary>
        /// Method to check if the url contains the items specified in the string array.
        /// </summary>
        /// <param name="url">The string to be tested for the list.</param>
        /// <param name="list">The list itself which containst the permitted or rejected values.</param>
        /// <returns>Boolean</returns>
        public bool IsStringInList(string url, string[] list)
        {
            foreach(object obj in list)
            {
                if(url.Contains(obj.ToString()))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Parses the current URL and extracts the virtual path without query string.
        /// </summary>
        /// <returns>The virtual path of the current URL.</returns>
        private static string GetVirtualPath()
        {
            string path = HttpContext.Current.Request.RawUrl;
            path = path.Substring(0, path.IndexOf("?"));
            path = path.Substring(path.LastIndexOf("/") + 1);
            return path;
        }

        /// <summary>
        /// Parses a URL and returns the query string.
        /// </summary>
        /// <param name="url">The URL to parse.</param>
        /// <returns>The query string without the question mark.</returns>
        private static string ExtractQuery(string url)
        {
            int index = url.IndexOf("?") + 1;
            return url.Substring(index);
        }

        #region Encryption/decryption
        /// <summary>
        /// The salt value used to strengthen the encryption.
        /// </summary>
        private static readonly byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());

        /// <summary>
        /// Encrypts any string using the Rijndael algorithm.
        /// </summary>
        /// <param name="inputText">The string to encrypt.</param>
        /// <returns>A Base64 encrypted string.</returns>
        public static string Encrypt(string inputText)
        {
            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            byte[] plainText = Encoding.Unicode.GetBytes(inputText);
            PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);

            using(ICryptoTransform encryptor = rijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16)))
            {
                using(MemoryStream memoryStream = new MemoryStream())
                {
                    using(CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(plainText, 0, plainText.Length);
                        cryptoStream.FlushFinalBlock();
                        return "?" + PARAMETER_NAME + Convert.ToBase64String(memoryStream.ToArray());
                    }
                }
            }
        }

        /// <summary>
        /// Decrypts a previously encrypted string.
        /// </summary>
        /// <param name="inputText">The encrypted string to decrypt.</param>
        /// <returns>A decrypted string.</returns>
        public static string Decrypt(string inputText)
        {
            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            byte[] encryptedData = Convert.FromBase64String(inputText);
            PasswordDeriveBytes secretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);

            using(ICryptoTransform decryptor = rijndaelCipher.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
            {
                using(MemoryStream memoryStream = new MemoryStream(encryptedData))
                {
                    using(CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        byte[] plainText = new byte[encryptedData.Length];
                        int decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
                        return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                    }
                }
            }
        }
        #endregion
    }
}