﻿
  
    /*
    *****************************************************************************
	js Name:	        CfiDatePicker.js
	Purpose:		    CfiDatePicker js, used in CfiDatePicker Control.
	Company:		    CargoFlash Infotech
	Author:			    Chandra Prakash
	Created On:		    13 Jan 2010
    *****************************************************************************
	*/
  


// For Date as per keypress by User
function GetDate(clientID, dateCultureFormat) {
    var txtVal = clientID.value;


    var dtconv = ''; var newDate = '';
    var newDate = '';
    if (txtVal != '') {
        var previousDate = txtVal.split('-');
        var oldDate = false;
        if (previousDate.length == 3)
        { newDate = txtVal; oldDate = true; }
        else {
            previousDate = txtVal.split('/');
            if (previousDate.length == 3) {
                newDate = txtVal;
                oldDate = true;
            }
            else {
                previousDate = txtVal.split('\\');
                if (previousDate.length == 3)
                { newDate = txtVal; oldDate = true; }
                else {
                    previousDate = txtVal.split('.');
                    if (previousDate.length == 3)
                    { newDate = txtVal; oldDate = true; }
                    else {
                        previousDate = txtVal.split(' ');
                        if (previousDate.length == 3)
                        { newDate = txtVal; oldDate = true; }
                    }
                }
            }
        }

        var d = new Date();
        var lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
        //var monthDate = new Array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')
        var datePart = '';
        var monthPart = 0;
        var diff = false;
        if (txtVal.indexOf(' ') >= 0) {
            txtVal = txtVal.replace(' ', '');
            txtVal = txtVal.replace(' ', '');
            diff = true;
        }
        if (txtVal.indexOf('-') >= 0) {
            txtVal = txtVal.replace('-', '');
            txtVal = txtVal.replace('-', '');
            diff = true;
        }
        if (txtVal.indexOf('.') >= 0) {
            txtVal = txtVal.replace('.', '');
            txtVal = txtVal.replace('.', '');
            diff = true;
        }

        if (txtVal.indexOf('/') >= 0) {
            txtVal = txtVal.replace('/', '');
            txtVal = txtVal.replace('/', '');
            diff = true;
        }
        if (txtVal.length <= 8) {

            // For Changing Text according to Culture wise
            if (!oldDate) {
                var valculture = dateCultureFormat;
                if (valculture.indexOf('-') > 0) valcult = valculture.split('-');
                else if (valculture.indexOf('/') > 0) valcult = valculture.split('/');
                else if (valculture.indexOf('\\') > 0) valcult = valculture.split('\\');
                else if (valculture.indexOf(' ') > 0) valcult = valculture.split(' ');
                else if (valculture.indexOf('.') > 0) valcult = valculture.split('.');

                if (valcult[0].indexOf('d') >= 0 && valcult[1].indexOf('M') >= 0 && valcult[2].indexOf('y') >= 0) {
                    txtVal = txtVal;
                }
                else if (valcult[0].indexOf('M') >= 0 && valcult[1].indexOf('d') >= 0 && valcult[2].indexOf('y') >= 0) {
                if (txtVal.length == 1) {
                    txtVal = '010' + txtVal
                 }
                else if (txtVal.length <= 2) {
                    if (txtVal * 1 <= 12) {
                        txtVal = '01' + txtVal;
                    }
                    else {
                        txtVal = '0' + txtVal.substring(1) + '0' + txtVal.substring(0, 1);
                    }
                }
                else if (txtVal.length > 2 && txtVal.length <= 4) {
                    if (txtVal.substring(0, 2) * 1 <= 12) {
                        txtVal = txtVal.substring(2) + txtVal.substring(0, 2);
                    }
                    else {
                        txtVal = txtVal.substring(1) + txtVal.substring(0, 1)
                    }
                }
                else {
                    var tVal = txtVal.substring(2);

                    txtVal = tVal.substring(0, 2) + txtVal.substring(0, 2) + tVal.substring(2);
                    if (tVal * 1 > 12) {
                        clientID.value = '';
                        return;
                    }
                }
                }
                else if (valcult[0].indexOf('y') >= 0 && valcult[1].indexOf('M') >= 0 && valcult[2].indexOf('d') >= 0) {
                    if (txtVal.length <= 4) {
                        txtVal = '0101' + txtVal;
                    }
                    else if (txtVal.length > 4) {
                        if (txtVal.substring(4).length <= 2) {
                            if (txtVal.substring(4) * 1 <= 12)
                                txtVal = '01' + txtVal.substring(4) + txtVal.substring(0, 4);
                            else
                                txtVal = txtVal.substring(7) + txtVal.substring(4, 6) + txtVal.substring(0, 4);
                        }
                    }
                }
                // End

                if (txtVal.length == 1 && txtVal.substring(0, 1) == '0') {
                    newDate = '';
                }
                else if (txtVal.length == 1 && txtVal.substring(0, 1) != '0') {
                    datePart = '0' + txtVal;
                    newDate = datePart + '-' + d.getMonth() + 1 + '-' + d.getFullYear();
                }
                else if (txtVal.length == 2 && txtVal.indexOf('0') < 0) {
                    if (txtVal * 1 > lastDay || diff) {
                        datePart = '0' + txtVal.substring(0, 1);
                        monthPart = (txtVal.substring(1) * 1);
                        newDate = datePart + '-' + monthPart + '-' + d.getFullYear();
                    }
                    else {
                        datePart = txtVal;
                        newDate = datePart + '-' + d.getMonth() + 1 + '-' + d.getFullYear();
                    }
                }
                else if (txtVal.length == 2 && txtVal.indexOf('0') >= 0) {
                    if (txtVal.substring(1) == '0') {
                        datePart = txtVal;
                    }
                    if (txtVal.substring(0, 1) == '0') {
                        txtVal = txtVal.substring(1);
                        datePart = '0' + txtVal;
                    }
                    newDate = datePart + '-' + d.getMonth() + 1 + '-' + d.getFullYear();
                }
                else if (txtVal.length == 3 && txtVal.indexOf('0') >= 0) {
                    if (!txtVal.substring(3, 4) == '0')
                        txtVal = txtVal.replace('0', '');
                    datePart = '0' + txtVal.substring(0, 1);
                    monthPart = (txtVal.substring(1) * 1);
                    newDate = datePart + '-' + monthPart + '-' + d.getFullYear();
                }
                else if (txtVal.length == 3 && txtVal.indexOf('0') < 0) {
                    if (txtVal.substring(1) * 1 <= 12) {
                        datePart = '0' + txtVal.substring(0, 1);
                        monthPart = (txtVal.substring(1) * 1);
                    }
                    else {
                        datePart = txtVal.substring(0, 2);
                        monthPart = (txtVal.substring(2) * 1);
                    }
                    var lastDate = new Date(d.getFullYear(), monthPart, 0).getDate();
                    if (datePart <= lastDate)
                        newDate = datePart + '-' + monthPart + '-' + d.getFullYear();
                    else
                        newDate = '';
                }
                else if (txtVal.length == 4 && txtVal.indexOf('0') >= 0) {
                    var txtval1 = txtVal.substring(0, 2);
                    var txtval2 = txtVal.substring(2);
                    datePart = txtval1;
                    monthPart = (txtval2 * 1);
                    newDate = datePart + '-' + monthPart + '-' + d.getFullYear();
                }
                else if (txtVal.length == 4 && txtVal.indexOf('0') < 0) {
                    datePart = txtVal.substring(0, 2);
                    monthPart = (txtVal.substring(2) * 1);
                    var lastDate = new Date(d.getFullYear(), monthPart, 0).getDate();
                    if (datePart * 1 <= lastDate && monthPart <= 12) {
                        newDate = datePart + '-' + monthPart + '-' + d.getFullYear();
                    }
                    else if (datePart * 1 > lastDate) {
                        datePart = '0' + txtVal.substring(0, 1);
                        monthPart = (txtVal.substring(1, 3) * 1);
                        if (monthPart <= 12) {
                            var yearPart = txtVal.substring(2);
                            var currentYear = d.getFullYear().toString();
                            if (yearPart.length < 4) {
                                yearPart = currentYear.substring(0, 4 - yearPart.length) + yearPart;
                            }
                            newDate = datePart + '-' + monthPart + '-' + yearPart;
                        }
                        else {
                            monthPart = (txtVal.substring(1, 1) * 1);

                            var yearPart = txtVal.substring(2);
                            var currentYear = d.getFullYear().toString();
                            if (yearPart.length < 4) {
                                yearPart = currentYear.substring(0, 4 - yearPart.length) + yearPart;
                            }
                            newDate = datePart + '-' + monthPart + '-' + yearPart;
                        }
                    }
                }
                else if (txtVal.length > 4) {
                    var dateAndMonth = txtVal.substring(0, 4);
                    var yearPart = txtVal.substring(4);
                    var currentYear = d.getFullYear().toString();
                    if (yearPart.length < 4) {
                        yearPart = currentYear.substring(0, 4 - yearPart.length) + yearPart;
                    }
                    if (dateAndMonth.length == 4 && dateAndMonth.indexOf('0') >= 0) {
                        var txtval1 = dateAndMonth.substring(0, 2);
                        var txtval2 = dateAndMonth.substring(2);
                        datePart = txtval1;
                        monthPart = (txtval2 * 1);
                        newDate = datePart + '-' + monthPart + '-' + yearPart;
                    }
                    else if (dateAndMonth.length == 4 && dateAndMonth.indexOf('0') < 0) {
                        datePart = dateAndMonth.substring(0, 2);
                        monthPart = (dateAndMonth.substring(2) * 1);
                        var lastDate = new Date(d.getFullYear(), monthPart, 0).getDate();
                        if (datePart * 1 <= lastDate && monthPart <= 12) {
                            newDate = datePart + '-' + monthPart + '-' + yearPart;
                        }
                        else if (datePart * 1 <= lastDate && monthPart > 12) {
                            monthPart = (dateAndMonth.substring(2, 3) * 1);
                            newDate = datePart + '-' + monthPart + '-' + yearPart;
                        }
                    }
                }
                var dateSplit = newDate.split('-');
                var convdt = new Date(dateSplit[2], dateSplit[1] - 1, dateSplit[0]);
                if (newDate.indexOf('undefined') < 0) {
                    clientID.value = newDate;
                    clientID.value = DateFormat(dateCultureFormat, convdt);
                    if (clientID.value.indexOf('N') > 0) clientID.value = '';
                }
                else {
                    clientID.value = '';
                }
            }
        }
        else {

            clientID.value = '';
        }
    }
}

function DateFormat(format, dateobj) {

    months = new Array(
'January', 'February', 'March', 'April',
'May', 'June', 'July', 'August', 'September',
'October', 'November', 'December');

    mons = new Array(
'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
'Aug', 'Sep', 'Oct', 'Nov', 'Dec');

    days = new Array(
'Sunday', 'Monday', 'Tuesday', 'Wednesday',
'Thursday', 'Friday', 'Saturday'
);

    dys = new Array(
'Sun', 'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat');

    // Build vars
    m = dateobj.getMonth() + 1;

    d = dateobj.getDate();
    yy = dateobj.getFullYear();
    if (dateobj.getYear() > 1900)
        yyyy = dateobj.getYear();
    else
        yyyy = 1900 + dateobj.getYear();


    Day = days[dateobj.getDay()];
    Dy = dys[dateobj.getDay()];
    Month = months[m - 1];
    Mon = mons[m - 1];

    if (m.toString().length < 2)
        mm = '0' + m + '';
   else 
        mm = m;
  
    if (d.toString().length < 2) {
        dd = '0' + d + '';
    } else {
        dd = d;
    }

    codes = new Array('Month', 'Mon', 'mm', 'm', 'Day', 'Dy', 'dd', 'd', 'yyyy', 'yy');
    lastmstring = format;
    ReplaceOld('Month', Month);
    ReplaceOld('Mon', Mon);
    ReplaceOld('MM', mm);
    ReplaceOld('M', m);
    ReplaceOld('Day', Day);
    ReplaceOld('Dy', Dy);
    ReplaceOld('dd', dd);
    ReplaceOld('d', d);
    ReplaceOld('yyyy', yyyy);
    ReplaceOld('yy', yy);
    return lastmstring;
}

function ReplaceOld(before, after) {
    indexOfIt = lastmstring.indexOf(before);
    if (indexOfIt >= 0) {
        beforeIt = lastmstring.substring(0, indexOfIt);
        afterIt = lastmstring.substring(indexOfIt + before.length, lastmstring.length);
        lastmstring = beforeIt + after + afterIt;
        ReplaceOld(before, after);
        return true;
    }
    return false;
}

//For checking the character of Date..
function CheckCharacter(evt, clientID) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode == 46) clientID.value += '.';
    if ((charCode > 96 && charCode < 123) || (charCode > 65 && charCode < 91))
        return false;
    else
        return true;
}