﻿/*
*************************************************************************************
File Name:      CfiTextBox.js
Purpose:        For numeric only text box, checks for the negative no insertion also.
Company:        CargoFlash Infotech .
Author:         Sudhir Yadav
Created On:     26 Nov, 2009
******************************************************************************
*/

//For numeric only text boxes, formats the text box according to the places of decimal specified...
function FormatOnBlur(clientID, placesOfDecimal) {
    num = clientID.value;
    if (num == '-')
        num = '0';
    if (num != '') {
        var aabb = num = (parseFloat(num)).toFixed(placesOfDecimal);
        if (aabb.indexOf('.') == 1) {
            aabb = '0' + aabb;
        }
        clientID.value = aabb;
    }
    else {
        clientID.value = '0';
    }
}

// Keep user from entering more than maxLength characters

function doKeypressforMaxLength(control, maxLength) {
    value = control.value;
    if (value.length > maxLength) {
        //event.returnValue = false;
        control.value = control.value.substr(0, maxLength);
    }
    //return (value.length <= maxLength);

}

// Cancel default behavior

function doBeforePasteforMaxLength(control, maxLength) {
    if (maxLength) {
        event.returnValue = false;
    }
}
// Cancel default behavior and create a new paste routine

function doPasteforMaxLength(control, maxLength) {
    value = control.value;
    if (maxLength) {
        event.returnValue = false;
        maxLength = parseInt(maxLength);
        var oTR = control.document.selection.createRange();
        var iInsertLength = maxLength - value.length + oTR.text.length;
        var sData = window.clipboardData.getData("Text").substr(0, iInsertLength);
        oTR.text = sData;
    }
}