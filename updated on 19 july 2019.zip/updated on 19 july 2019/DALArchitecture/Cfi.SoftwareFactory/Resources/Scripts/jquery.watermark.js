﻿/*
Watermark v3.0.3 (November 30, 2009) plugin for jQuery
http://jquery-watermark.googlecode.com/
Copyright (c) 2009 Todd Northrop
http://www.speednet.biz/
Licensed under GPL 3, see  <http://www.gnu.org/licenses/>
*/
(function(a) {
    var k = "function",
        i = "password",
        c = "maxLength",
        e = "type",
        b = true,
        d = false,
        s = "watermark",
        t, m = s,
        h = "watermarkClass",
        p = "watermarkFocus",
        j = "watermarkSubmit",
        l = "watermarkMaxLength",
        g = "watermarkPassword",
        f = "watermarkText",
        r = ":data(" + m + ")",
        n = ":text,:password,:search,textarea",
        o = ["Page_ClientValidate"],
        q = d;
    a.extend(a.expr[":"], {
        data: function(f, h, g) {
            var e, c = /^((?:[^=!^$*]|[!^$*](?!=))+)(?:([!^$*]?=)(.*))?$/.exec(g[3]);
            if (c) {
                e = a(f).data(c[1]);
                if (e !== t) {
                    if (c[2]) {
                        e = "" + e;
                        switch (c[2]) {
                            case "=":
                                return e == c[3];
                            case "!=":
                                return e != c[3];
                            case "^=":
                                return e.slice(0, c[3].length) == c[3];
                            case "$=":
                                return e.slice(-c[3].length) == c[3];
                            case "*=":
                                return e.indexOf(c[3]) !== -1
                        }
                    }
                    return b
                }
            }
            return d
        }
    });
    a.watermark = {
        version: "3.0.3",
        options: {
            className: s,
            useNative: b
        },
        hide: function(b) {
            a(b).filter(r).each(function() {
                a.watermark._hide(a(this))
            })
        },
        _hide: function(a, i) {
            a.css({ color: '#000000' });
            if (a.val() == a.data(f)) {
                a.val("");
                if (a.data(g)) if (a.attr(e) === "text") {
                    var d = a.data(g),
                        b = a.parent();
                    b[0].removeChild(a[0]);
                    b[0].appendChild(d[0]);
                    a = d
                }
                if (a.data(l)) {
                    a.attr(c, a.data(l));
                    a.removeData(l)
                }
                if (i) {
                    a.attr("autocomplete", "off");
                    window.setTimeout(function() {
                        a.select()
                    },
                    0)
                }
            }
            a.removeClass(a.data(h))
        },
        show: function(b) {
            a(b).filter(r).each(function() {
                a.watermark._show(a(this))
            })
        },
        _show: function(d) {
            d.css({ color: '#999999' });
            var r = d.val(),
                j = d.data(f),
                m = d.attr(e);
            if ((r.length == 0 || r == j) && !d.data(p)) {
                q = b;
                if (d.data(g)) if (m === i) {
                    var o = d.data(g),
                        n = d.parent();
                    n[0].removeChild(d[0]);
                    n[0].appendChild(o[0]);
                    d = o;
                    d.attr(c, j.length)
                }
                if (m === "text" || m === "search") {
                    var k = d.attr(c);
                    if (k > 0 && j.length > k) {
                        d.data(l, k);
                        d.attr(c, j.length)
                    }
                }
                d.addClass(d.data(h));
                d.val(j)
            } else a.watermark._hide(d)
        },
        hideAll: function() {
            if (q) {
                a.watermark.hide(n);
                q = d
            }
        },
        showAll: function() {
            a.watermark.show(n)
        }
    };
    a.fn.watermark = function(q, l) {
        var o = "string",
            s = typeof q === o,
            r;
        if (typeof l === "object") {
            r = typeof l.className === o;
            l = a.extend({},
            a.watermark.options, l)
        } else if (typeof l === o) {
            r = b;
            l = a.extend({},
            a.watermark.options, {
                className: l
            })
        } else l = a.watermark.options;
        if (typeof l.useNative !== k) l.useNative = l.useNative ?
        function() {
            return b
        } : function() {
            return d
        };
        return this.each(function() {
            var u = "dragleave",
                t = "dragenter",
                w = this,
                d = a(w);
            if (!d.is(n)) return;
            if (d.data(m)) {
                if (s || r) {
                    a.watermark._hide(d);
                    s && d.data(f, q);
                    r && d.data(h, l.className)
                }
            } else {
                if (l.useNative.call(w, d)) if (("" + d.css("-webkit-appearance")).replace("undefined", "") !== "" && d.attr("tagName") !== "TEXTAREA") {
                    s && d.attr("placeholder", q);
                    return
                }
                d.data(f, s ? q : "");
                d.data(h, l.className);
                d.data(m, 1);
                if (d.attr(e) === i) {
                    var x = d.wrap("<span>").parent(),
                        k = a(x.html().replace(/type=["']?password["']?/i, 'type="text"'));
                    k.data(f, d.data(f));
                    k.data(h, d.data(h));
                    k.data(m, 1);
                    k.attr(c, q.length);
                    k.focus(function() {
                        a.watermark._hide(k, b)
                    }).bind(t, function() {
                        a.watermark._hide(k)
                    }).bind("dragend", function() {
                        window.setTimeout(function() {
                            k.blur()
                        },
                        1)
                    });
                    d.blur(function() {
                        a.watermark._show(d)
                    }).bind(u, function() {
                        a.watermark._show(d)
                    });
                    k.data(g, d);
                    d.data(g, k)
                } else d.focus(function() {
                    d.data(p, 1);
                    a.watermark._hide(d, b)
                }).blur(function() {
                    d.data(p, 0);
                    a.watermark._show(d)
                }).bind(t, function() {
                    a.watermark._hide(d)
                }).bind(u, function() {
                    a.watermark._show(d)
                }).bind("dragend", function() {
                    window.setTimeout(function() {
                        a.watermark._show(d)
                    },
                    1)
                }).bind("drop", function(b) {
                    var a = b.originalEvent.dataTransfer.getData("Text");
                    d.val().replace(a, "") === d.data(f) && d.val(a);
                    d.focus()
                });
                if (w.form) {
                    var o = w.form,
                        v = a(o);
                    if (!v.data(j)) {
                        v.submit(a.watermark.hideAll);
                        if (o.submit) {
                            v.data(j, o.submit);
                            o.submit = function(c, b) {
                                return function() {
                                    var d = b.data(j);
                                    a.watermark.hideAll();
                                    if (d.apply) d.apply(c, Array.prototype.slice.call(arguments));
                                    else d()
                                }
                            } (o, v)
                        } else {
                            v.data(j, 1);
                            o.submit = function(b) {
                                return function() {
                                    a.watermark.hideAll();
                                    delete b.submit;
                                    b.submit()
                                }
                            } (o)
                        }
                    }
                }
            }
            a.watermark._show(d)
        }).end()
    };
    o.length && a(function() {
        for (var b, c, d = o.length - 1; d >= 0; d--) {
            b = o[d];
            c = window[b];
            if (typeof c === k) window[b] = function(b) {
                return function() {
                    a.watermark.hideAll();
                    b.apply(null, Array.prototype.slice.call(arguments))
                }
            } (c)
        }
    })
})(jQuery);