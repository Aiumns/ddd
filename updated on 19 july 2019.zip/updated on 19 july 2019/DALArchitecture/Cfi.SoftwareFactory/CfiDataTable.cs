using System;
using System.Data;
using System.Text;



namespace Cfi.SoftwareFactory.Data
{

    #region CfiDataTable Class Description
    /*
    *************************************************************************************
    Class Name:     StoredProcedure      
    Purpose:        This is CfiDataTable class which provides functionality of insert, update and delete SQL DML.
    Company:        CargoFlash Infotech .
    Author:         Manish kumar
    Created On:     26 Sep, 2009
    Approved By:    Sudhir Yadav
    Approved On:    30 Sep 2009
    Updated By:     Sudhir Yadav
    Updated On:     26 Oct 2009
    Updated Desc:   Done minor code review changes and added the funtionality of retriving multiple rows through ';' delimeter.
    ******************************************************************************
    */
    #endregion

    /// <summary>
    /// This is CfiDataTable class which provides functionality of insert, update and delete SQL DML.
    /// Statements which can be used with the COMMAND Object of ADO.Net to 
    /// manuplate records in database platforms.
    /// </summary>
    public class CfiDataTable : IDisposable
    {
        #region Declare Local Variables
        //Declare Variables 
        private const int MAX_STRING_LIMIT = 32768;
        private const string REPLACE_STRING = "~!~#";
        private bool updateMode; //Used to get the Insert/Update mode

        public CfiDataTable()
        {
            WhereClauseColumns = "";
            StringEnclosedCharactor = "'";
            DateFormat = "yyyy-MM-dd HH:MM:ss";
        }
        #endregion

        #region Set Property Variables
        //Set Property to local variable
        public int ErrorNumber { get; set; }

        public string ErrorMessage { get; set; }

        public string Name { get; set; }

        public string UpdateFieldToExclude { get; set; }

        public string WhereConditionField { get; set; }

        public string DateFormat { get; set; }

        public string StringEnclosedCharactor { get; set; }

        public string WhereClauseColumns { get; set; }

        public DataTable TableSource { get; set; }
        #endregion

        #region Destructor Definition
        //Default Destructor 
        ~CfiDataTable()
        {
            //Cleanup the DBMSAdapter Enviroment
            Dispose();
        }
        #endregion

        #region DisposeMethod
        //Default Dispose Method.
        public virtual void Dispose()
        {
            if(TableSource != null)
                TableSource.Dispose();
            GC.SuppressFinalize(this);
        }
        #endregion

        #region GetUpdateDML
        /// <summary>
        /// This method provides SQL UPDATE DML Statement based on the
        /// Number of rows in the table.
        /// Before calling this method make sure CfiDataTable.TableSource property
        /// is set with table containing one or more rows. The total string lenght of
        /// DML string must not exceed 32768.
        /// </summary>
        /// <returns>string representing DML UPDATE Statements.</returns>
        public string GetUpdateDML()
        {
            StringBuilder UpdateStatement = new StringBuilder();
            string strComma = ", ";
            StringBuilder strRecordValues;
            StringBuilder whereString;

            //Get EntityName from the this
            //if EntityName blank then raise error
            if(string.IsNullOrEmpty(TableSource.TableName))
            {
                ErrorNumber = 0;
                ErrorMessage = "this Name is not specified.";
                return UpdateStatement.ToString();
            }

            //if WhereClauseColumns blank then raise error
            if(string.IsNullOrEmpty(WhereClauseColumns))
            {
                ErrorNumber = 0;
                ErrorMessage = "WhereClauseColumns is not specified.";
                return UpdateStatement.ToString();
            }

            //Read row value from SoruceTable and prepared DML Statement
            //Begin Loop
            //Read Column Name store it into string with ','
            //Go to next index
            //if last index do'nt store ','

            try
            {
                for(int row = 0; row < TableSource.Rows.Count; row++)
                {
                    strRecordValues = new StringBuilder();
                    whereString = new StringBuilder();
                    //Begin Iteration of Columns Collections
                    for(int col = 0; col < TableSource.Columns.Count; col++)
                    {
                        if(col == TableSource.Columns.Count - 1)
                            strComma = "";

                        int PosFound = WhereClauseColumns.Trim().IndexOf(TableSource.Columns[col].ToString().Trim());
                        if(PosFound >= 0)
                        {
                            if(whereString.Length > 0)
                                whereString.Append(" AND ");

                            switch(TableSource.Columns[col].DataType.ToString())
                            {
                                case "System.string" :
                                    whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + TableSource.Rows[row][col] + StringEnclosedCharactor);
                                    break;
                                case "System.DateTime" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL" + strComma);
                                    break;
                                case "System.DateTime2" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL" + strComma);
                                    break;
                                case "System.Date" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL" + strComma);
                                    break;
                                case "System.DateTimeOffset" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL" + strComma);
                                    break;
                                case "System.Guid" :
                                    whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + TableSource.Rows[row][col] + StringEnclosedCharactor);
                                    break;
                                default :
                                    whereString.Append(TableSource.Columns[col].ColumnName + "=" + TableSource.Rows[row][col]);
                                    break;
                            }
                        }
                        PosFound = UpdateFieldToExclude.Trim().IndexOf(TableSource.Columns[col].ToString().Trim());

                        if(PosFound == -1)
                        {
                            switch(TableSource.Columns[col].DataType.ToString())
                            {
                                case "System.string" :
                                    strRecordValues.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + TableSource.Rows[row][col] + StringEnclosedCharactor + strComma);
                                    break;
                                case "System.DateTime" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        strRecordValues.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor + strComma);
                                    else
                                        strRecordValues.Append("NULL" + strComma);
                                    break;
                                case "System.DateTime2" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        strRecordValues.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor + strComma);
                                    else
                                        strRecordValues.Append("NULL" + strComma);
                                    break;
                                case "System.Date" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        strRecordValues.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor + strComma);
                                    else
                                        strRecordValues.Append("NULL" + strComma);
                                    break;
                                case "System.DateTimeOffset" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        strRecordValues.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor + strComma);
                                    else
                                        strRecordValues.Append("NULL" + strComma);
                                    break;
                                case "System.Guid" :
                                    strRecordValues.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + TableSource.Rows[row][col] + StringEnclosedCharactor + strComma);
                                    break;
                                default :
                                    strRecordValues.Append(TableSource.Columns[col].ColumnName + "=" + TableSource.Rows[row][col] + strComma);
                                    break;
                            }
                        }
                    }
                    UpdateStatement.Append("UPDATE " + TableSource.TableName.Trim() + " SET " + strRecordValues + " WHERE " + whereString + " ;");
                }
                if(UpdateStatement.Length > MAX_STRING_LIMIT)
                    throw new Exception("DML Statement string lenght exceeds [" + MAX_STRING_LIMIT + "].");

                return UpdateStatement.ToString();
            }
            catch(Exception)
            {
                return "";
            }
        }
        #endregion

        #region GetDeleteDML
        /// <summary>
        /// This method provides SQL DELETE DML Statement based on the
        /// Number of rows in the table.
        /// Before calling this method make sure CfiDataTable.TableSource property
        /// is set with table containing one or more rows. The total string lenght of
        /// DML string must not exceed 32768.
        /// </summary>
        /// <returns>string representing DML DELETE Statements.</returns>
        public string GetDeleteDML()
        {
            StringBuilder deleteStatement = new StringBuilder();
            StringBuilder whereString;
            //Check SoruceTable is null then raise error

            //Get EntityName from the this
            //if EntityName blank then raise error
            if(string.IsNullOrEmpty(TableSource.TableName))
            {
                ErrorNumber = 0;
                ErrorMessage = "this Name is not specified.";
                return deleteStatement.ToString();
            }

            //if WhereClauseColumns blank then raise error
            if(string.IsNullOrEmpty(WhereClauseColumns))
            {
                ErrorNumber = 0;
                ErrorMessage = "WhereClauseColumns is not specified.";
                return deleteStatement.ToString();
            }

            //Read row value from SoruceTable and prepared DML Statement
            //Begin Loop
            //Read Column Name store it into string with ','
            //Go to next index
            //if last index do'nt store ','

            try
            {
                for(int row = 0; row < TableSource.Rows.Count; row++)
                {
                    whereString = new StringBuilder();
                    //Begin Iteration of Columns Collections
                    for(int col = 0; col < TableSource.Columns.Count; col++)
                    {
                        int PosFound = WhereClauseColumns.Trim().IndexOf(TableSource.Columns[col].ToString().Trim());
                        if(PosFound >= 0)
                        {
                            if(whereString.Length > 0)
                                whereString.Append(" AND ");

                            switch(TableSource.Columns[col].DataType.ToString())
                            {
                                case "System.string" :
                                    whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + TableSource.Rows[row][col] + StringEnclosedCharactor);
                                    break;
                                case "System.DateTime" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL");
                                    break;
                                case "System.DateTime2" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL");
                                    break;
                                case "System.Date" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL");
                                    break;
                                case "System.DateTimeOffset" :
                                    if(TableSource.Rows[row][col].ToString().Length > 0)
                                        whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + DateTime.Parse(TableSource.Rows[row][col].ToString()).ToString(DateFormat) + StringEnclosedCharactor);
                                    else
                                        whereString.Append("NULL");
                                    break;
                                case "System.Guid" :
                                    whereString.Append(TableSource.Columns[col].ColumnName + "=" + StringEnclosedCharactor + TableSource.Rows[row][col] + StringEnclosedCharactor);
                                    break;
                                default :
                                    whereString.Append(TableSource.Columns[col].ColumnName + "=" + TableSource.Rows[row][col]);
                                    break;
                            }
                        }
                    }
                    deleteStatement.Append("DELETE FROM " + TableSource.TableName.Trim() + " WHERE " + whereString + " ;");
                }
                return deleteStatement.ToString();
            }
            catch(Exception)
            {
                return "";
            }
        }
        #endregion

        #region Get Column Schema
        /// <summary>
        /// This method provides list of columns contained in the table
        /// seperated by ','. For examples 'COLUMN1,COLUMN2,COLUMN3....'
        /// </summary>
        /// <returns>string representing name of columns contained in the System.Data.DataTable.</returns>
        public string GetColumnSchema()
        {
            StringBuilder strSchema = new StringBuilder();
            const string COLUMN_DELEMITER = ",";
            try
            {
                for(int i = 0; i < TableSource.Columns.Count; i++)
                    strSchema.Append(TableSource.Columns[i].ColumnName + COLUMN_DELEMITER);
                return strSchema.ToString().Remove(strSchema.ToString().LastIndexOf(","), 1);
            }
            catch(Exception)
            {
                return "";
            }
        }
        #endregion

        #region Table To Get DML Record Values
        /// <summary>
        /// This method provides list of row values contained in the first row
        /// seperated by ','. For examples 'VALUE1,VALUE2,VALUE3....'
        /// </summary>
        /// <returns>string representing ',' seperated values.</returns>
        public string GetDMLRecordValues()
        {
            StringBuilder strRecordValues = new StringBuilder();
            const string ROW_DELEMITER = "`ROW`";
            try
            {
                int noOFColumns = TableSource.Columns.Count;
                int noOFRows = TableSource.Rows.Count;
                for(int j = 0; j < noOFRows; j++)
                {
                    const string COLUMN_DELEMITER = "~COL~";
                    for(int i = 0; i < noOFColumns; i++)
                    {
                        string currentTableCell = TableSource.Rows[j][i].ToString();
                        if(string.IsNullOrEmpty(currentTableCell) || currentTableCell.Length == 0)
                            strRecordValues.Append("NULL" + COLUMN_DELEMITER);
                        else
                        {
                            switch(TableSource.Columns[i].DataType.ToString())
                            {
                                case "System.String" :
                                    strRecordValues.Append((updateMode ? "'" + currentTableCell.Replace(",", REPLACE_STRING) + "'" : "'" + currentTableCell + "'") + COLUMN_DELEMITER);
                                    break;
                                case "System.DateTime" :
                                case "System.DateTime2" :
                                    strRecordValues.Append("'" + DateTime.Parse(currentTableCell).ToString(DateFormat) + "'" + COLUMN_DELEMITER);
                                    break;
                                case "System.Date" :
                                case "System.TimeSpan" :
                                case "System.DateTimeOffset" :
                                    strRecordValues.Append("'" + currentTableCell + "'" + COLUMN_DELEMITER);
                                    break;
                                case "System.Boolean" :
                                    strRecordValues.Append((bool.Parse(currentTableCell) ? "1" : "0") + COLUMN_DELEMITER);
                                    break;
                                default :
                                    strRecordValues.Append(currentTableCell + COLUMN_DELEMITER);
                                    break;
                            }
                        }
                    }
                    strRecordValues.Append(ROW_DELEMITER);
                }
                return strRecordValues.ToString().Replace("~COL~`ROW`", "`ROW`");
            }
            catch(Exception)
            {
                return "";
            }
        }
        #endregion

        #region Table To UpdateDML
        /// <summary>
        /// This method provides list of row values contained in the first row
        /// seperated by ','. For examples 'SET COLUMN1=VALUE1,COLUMN2=VALUE2,COLUMN3=VALUE3....'
        /// </summary>
        /// <returns>string representing ',' seperated values.</returns>
        public string TableToUpdateDML()
        {
            string[] schemaCollection;
            updateMode = true; //Used to set the Update mode

            StringBuilder strRecordValues = new StringBuilder();
            const string STR_COMMA = ", ";

            //get table structure
            string schema = GetColumnSchema();

            //get the value list 
            string recordValues = GetDMLRecordValues();

            try
            {
                //split the table structure into the array
                schemaCollection = schema.Split(',');
                string[] valueSet = recordValues.Split(new[] {"~COL~"}, StringSplitOptions.RemoveEmptyEntries);

                //prepare for loop
                for(int i = 0; i < schemaCollection.Length; i++)
                {
                    int pos = UpdateFieldToExclude.Trim().IndexOf(schemaCollection[i].Trim());
                    if(pos == -1)
                    {
                        if(strRecordValues.Length == 0)
                            strRecordValues.Append(schemaCollection[i].Trim() + "=" + valueSet[i].Trim().Replace(REPLACE_STRING, "~COL~"));
                        else
                            strRecordValues.Append(STR_COMMA + schemaCollection[i].Trim() + "=" + valueSet[i].Replace(REPLACE_STRING, "~COL~").Trim());
                    }
                }
                return strRecordValues.Append("`ROW`").ToString();
            }
            catch(Exception ex)
            {
                ErrorMessage = ex.Message;
                return "";
            }

            //if the field found from exculude fields 
            //skip the loop 
            //otherwise write field name =field value into update dml 
        }
        #endregion

        #region Table To UpdateDML with where condition for one or more than one row
        /// <summary>
        /// This method provides list of row values with where clause for one or more than one rows
        /// </summary>
        /// <returns>string representing ',' seperated values.</returns>
        public string[] TableToUpdateWhereDML()
        {
            string[] schemaCollection;
            string[] updationString = new string[2];
            updateMode = true; //Used to set the Update mode

            StringBuilder strRecordValues = new StringBuilder();
            StringBuilder strConditionValues = new StringBuilder();
            const string ROW_DELEMITER = "`ROW`";

            //get table structure
            string schema = GetColumnSchema();

            //get the value list 
            string recordValues = GetDMLRecordValues();

            try
            {
                //split the table structure into the array
                schemaCollection = schema.Split(',');
                string[] rowSet = recordValues.Split(new[] {"`ROW`"}, StringSplitOptions.RemoveEmptyEntries);
                string[] colSet;
                string[] whereConditionField = WhereConditionField.Split(',');
                string strWhereCondition = "," + WhereConditionField.Trim() + ",";
                if(strWhereCondition.IndexOf("," + UpdateFieldToExclude.Trim() + ",") < 0)
                    strWhereCondition = strWhereCondition + UpdateFieldToExclude.Trim() + ",";
                //prepare for loop
                for(int j = 0; j < rowSet.Length; j++)
                {
                    colSet = rowSet[j].Split(new[] {"~COL~"}, StringSplitOptions.RemoveEmptyEntries);
                    const string COLUMN_DELEMITER = "~COL~";
                    const string UPDATE_DELEMITER = " AND ";
                    for(int i = 0; i < schemaCollection.Length; i++)
                    {
                        int pos = strWhereCondition.Trim().IndexOf("," + schemaCollection[i].Trim() + ",");
                        if(pos == -1)
                            strRecordValues.Append(schemaCollection[i].Trim() + "=" + colSet[i].Trim().Replace(REPLACE_STRING, ",") + COLUMN_DELEMITER);
                        if(pos >= 0)
                            strConditionValues.Append(schemaCollection[i].Trim() + "=" + colSet[i].Trim().Replace(REPLACE_STRING, ",") + UPDATE_DELEMITER);
                    }
                    strRecordValues.Append(ROW_DELEMITER);
                    strConditionValues.Append(ROW_DELEMITER);
                }
                updationString[0] = strRecordValues.ToString().Replace("~COL~`ROW`", "`ROW`");
                updationString[1] = strConditionValues.ToString().Replace(" AND `ROW`", "`ROW`");
                return updationString;
            }
            catch(Exception ex)
            {
                updationString[0] = "";
                updationString[1] = "";
                ErrorMessage = ex.Message;
                return updationString;
            }

            //if the field found from exculude fields 
            //skip the loop 
            //otherwise write field name =field value into update dml 
        }
        #endregion
    }
}