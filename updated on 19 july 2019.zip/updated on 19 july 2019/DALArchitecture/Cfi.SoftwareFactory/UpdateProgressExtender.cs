﻿using System;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace Cfi.SoftwareFactory.WebControls
{
    public class UpdateProgressExtender : UpdateProgress
    {
        public UpdateProgressExtender() { ProgressTemplate = new CustomProgressTemplate(); }

        private UpdatePanel UpdatePanelToExtend
        {
            get
            {
                if(Page.Session["UpdatePanelToExtend" + ID] == null)
                    throw new ArgumentNullException("UpdatePanelToExtend property not Set");
                return (UpdatePanel)Page.Session["UpdatePanelToExtend" + ID];
                ;
            }
            set
            {
                value.Load += DisplayExtendedPanel;
                Page.Session["UpdatePanelToExtend" + ID] = value;
            }
        }

        public string UpdatePanelID { get { return ViewState["UpdatePanelID"].ToString(); } set { ViewState["UpdatePanelID"] = value; } }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            UpdatePanelToExtend = (UpdatePanel)Page.FindControl(UpdatePanelID);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            string progressPanelClientId = (Controls[0].Controls[0]).ClientID;
            string initialScript = " var divOriginal" + progressPanelClientId + " = document.getElementById('" + UpdatePanelToExtend.ClientID + "');\n" + " var divNew" + progressPanelClientId + " = document.getElementById('" + progressPanelClientId + "');\n" + " var divOriginalBounds" + progressPanelClientId + " = Sys.UI.DomElement.getBounds(divOriginal" + progressPanelClientId + ");\n" + " Sys.UI.DomElement.setLocation(divNew" + progressPanelClientId + ", divOriginalBounds" + progressPanelClientId + ".x, divOriginalBounds" + progressPanelClientId + ".y);\n" + " divNew" + progressPanelClientId + ".style.width = divOriginalBounds" + progressPanelClientId + ".width + 'px';\n" + " divNew" + progressPanelClientId + ".style.height = divOriginalBounds" + progressPanelClientId + ".height + 'px';\n";
            //Client script to set the size of this panel equivalent to the update panel...
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "SetEqualSizeScript" + progressPanelClientId, initialScript, true);
            base.Render(writer);
        }

        protected void DisplayExtendedPanel(object sender, EventArgs e) { }
    }


    public class CustomProgressTemplate : ITemplate
    {
        #region ITemplate Members
        public void InstantiateIn(Control container)
        {
            Panel panel = new Panel();
            panel.Style.Add(HtmlTextWriterStyle.BackgroundColor, "Gray");
            panel.Style.Add(HtmlTextWriterStyle.Filter, "alpha(opacity = 60)");
            panel.Style.Add("opacity", "0.60");
            //panel.ID = "UpdateProgressPanel";
            Label lbl = new Label();
            lbl.Text = "Loading Data...";
            lbl.ForeColor = Color.White;
            panel.Controls.Add(lbl);
            container.Controls.Add(panel);
        }
        #endregion
    }
}