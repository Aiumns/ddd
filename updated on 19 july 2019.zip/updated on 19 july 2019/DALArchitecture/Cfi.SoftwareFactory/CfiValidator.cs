/* CfiValidator File Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright � 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   The custom validator inheriting from the respective validators to provide additional functionality along with the base functionality.
 * Description          :   - Added validator class CfiCompareValidator.  Used to compare the two controls.
                            - Added validator class CfiRegularExpressionValidator.  Used to validate the control to validate against a regular expression. 
                            - Added validator class CfiRequiredFieldValidator.  Used to validate for the field is required.
                            - Added validator class CfiRangeValidator.  Used to validate the range of the controls.
                            - Added validator class CfiCustomValidator.  Used for the custom validation of the controls.
                            - All validator classes Inherits from their respective base class and implements the ICfiValidator interface.
                            - Added class CfiValidatorEventHelper. Used to handle the onload and onprerender event of our custom validators. viz: CfiCompareValidator,                                         CfiRegularExpressionValidator, CfiRequiredFieldValidator, CfiRangeValidator, CfiCustomValidator.
                            - Added class CfiValidatorUIHelper. Used to add and remove the required controls and add the required css to the control to validate.
                            - Added class ICfiValidator. Used to define the various properties and to be implemented by the CFI custom validator classes.
 * Created By           :   Sudhir Yadav.
 * Created On           :   13 Mar 2010.
 * Modified By          :   .
 * Modified On          :   .
 * Description          :   . 
*/
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Cfi.SoftwareFactory.WebControls;

[assembly: WebResource("Cfi.SoftwareFactory.Resources.Scripts.CfiValidator.js", "text/javascript")]
namespace Cfi.SoftwareFactory.WebControls
{
    /// <summary>
    /// Class used to compare the two controls. Inherits from the CompareValidator class and implements the ICfiValidator interface.
    /// </summary>
    public class CfiCompareValidator : CompareValidator, ICfiValidator
    {
        /// <summary>
        /// The error client function that will be called on validation errors.
        /// </summary>
        private string errorClientFunction;

        /// <summary>
        /// The error css class. Default is set to validationError supplied in the CfiValidator.css resource.
        /// </summary>
        private string errorCssClass = "validationError";

        /// <summary>
        /// Gets or sets the class that will be applied on control to validate on validation errors.
        /// </summary>
        public string ErrorCssClass { get { return this.errorCssClass; } set { this.errorCssClass = value; } }

        /// <summary>
        /// Gets or sets the client function that will be called on validation errors.
        /// </summary>
        public string ErrorClientFunction { get { return this.errorClientFunction; } set { this.errorClientFunction = value; } }

        /// <summary>
        /// The on load method to handle the onload event of the current validation control.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            CfiValidatorEventHelper.OnLoad(this);
        }

        /// <summary>
        /// The on pre render method to handle the event prior to rendering.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            CfiValidatorEventHelper.OnPreRender(this);
        }
    }

    /// <summary>
    /// Class used to validate the control to validate against a regular expression. Inherits from the RegularExpressionValidator class and implements the ICfiValidator interface.
    /// </summary>
    public class CfiRegularExpressionValidator : RegularExpressionValidator, ICfiValidator
    {
        /// <summary>
        /// The error client function that will be called on validation errors.
        /// </summary>
        private string errorClientFunction;

        /// <summary>
        /// The error css class. Default is set to validationError supplied in the CfiValidator.css resource.
        /// </summary>
        private string errorCssClass = "validationError";

        /// <summary>
        /// Gets or sets the class that will be applied on control to validate on validation errors.
        /// </summary>
        public string ErrorCssClass { get { return this.errorCssClass; } set { this.errorCssClass = value; } }

        /// <summary>
        /// Gets or sets the client function that will be called on validation errors.
        /// </summary>
        public string ErrorClientFunction { get { return this.errorClientFunction; } set { this.errorClientFunction = value; } }

        /// <summary>
        /// The on load method to handle the onload event of the current validation control.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            CfiValidatorEventHelper.OnLoad(this);
        }

        /// <summary>
        /// The on pre render method to handle the event prior to rendering.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            CfiValidatorEventHelper.OnPreRender(this);
        }
    }

    /// <summary>
    /// Class used to validate for the field is required. Inherits from the RequiredFieldValidator class and implements the ICfiValidator interface.
    /// </summary>
    public class CfiRequiredFieldValidator : RequiredFieldValidator, ICfiValidator
    {
        /// <summary>
        /// The error client function that will be called on validation errors.
        /// </summary>
        private string errorClientFunction;

        /// <summary>
        /// The error css class. Default is set to validationError supplied in the CfiValidator.css resource.
        /// </summary>
        private string errorCssClass = "validationError";

        /// <summary>
        /// Gets or sets the class that will be applied on control to validate on validation errors.
        /// </summary>
        public string ErrorCssClass { get { return this.errorCssClass; } set { this.errorCssClass = value; } }

        /// <summary>
        /// Gets or sets the client function that will be called on validation errors.
        /// </summary>
        public string ErrorClientFunction { get { return this.errorClientFunction; } set { this.errorClientFunction = value; } }

        /// <summary>
        /// The on load method to handle the onload event of the current validation control.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            CfiValidatorEventHelper.OnLoad(this);
        }

        /// <summary>
        /// The on pre render method to handle the event prior to rendering.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            CfiValidatorEventHelper.OnPreRender(this);
        }
    }

    /// <summary>
    /// Class used to validate the range of the controls. Inherits from the RangeValidator class and implements the ICfiValidator interface.
    /// </summary>
    public class CfiRangeValidator : RangeValidator, ICfiValidator
    {
        /// <summary>
        /// The error client function that will be called on validation errors.
        /// </summary>
        private string errorClientFunction;

        /// <summary>
        /// The error css class. Default is set to validationError supplied in the CfiValidator.css resource.
        /// </summary>
        private string errorCssClass = "validationError";

        /// <summary>
        /// Gets or sets the class that will be applied on control to validate on validation errors.
        /// </summary>
        public string ErrorCssClass { get { return this.errorCssClass; } set { this.errorCssClass = value; } }

        /// <summary>
        /// Gets or sets the client function that will be called on validation errors.
        /// </summary>
        public string ErrorClientFunction { get { return this.errorClientFunction; } set { this.errorClientFunction = value; } }

        /// <summary>
        /// The on load method to handle the onload event of the current validation control.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            CfiValidatorEventHelper.OnLoad(this);
        }

        /// <summary>
        /// The on pre render method to handle the event prior to rendering.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            CfiValidatorEventHelper.OnPreRender(this);
        }
    }

    /// <summary>
    /// Class used for the custom validation of the controls. Inherits from the CustomValidator class and implements the ICfiValidator interface.
    /// </summary>
    public class CfiCustomValidator : CustomValidator, ICfiValidator
    {
        /// <summary>
        /// The error client function that will be called on validation errors.
        /// </summary>
        private string errorClientFunction;

        /// <summary>
        /// The error css class. Default is set to validationError supplied in the CfiValidator.css resource.
        /// </summary>
        private string errorCssClass = "validationError";

        /// <summary>
        /// Gets or sets the class that will be applied on control to validate on validation errors.
        /// </summary>
        public string ErrorCssClass { get { return this.errorCssClass; } set { this.errorCssClass = value; } }

        /// <summary>
        /// Gets or sets the client function that will be called on validation errors.
        /// </summary>
        public string ErrorClientFunction { get { return this.errorClientFunction; } set { this.errorClientFunction = value; } }

        /// <summary>
        /// The on load method to handle the onload event of the current validation control.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            CfiValidatorEventHelper.OnLoad(this);
        }

        /// <summary>
        /// The on pre render method to handle the event prior to rendering.
        /// </summary>
        /// <param name="e">
        /// The event arguments supplied.
        /// </param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            CfiValidatorEventHelper.OnPreRender(this);
        }
    }

    /// <summary>
    /// Class used to handle the events of our custom validators. viz: CfiCompareValidator, CfiRegularExpressionValidator, CfiRequiredFieldValidator, CfiRangeValidator, CfiCustomValidator.
    /// </summary>
    public class CfiValidatorEventHelper
    {
        /// <summary>
        /// Method to handle the on onload event of the sender, the validation controls in case.
        /// </summary>
        /// <param name="validator">The validation control which when loaded calls this method.</param>
        public static void OnLoad(BaseValidator validator)
        {
            ClientScriptManager cs = validator.Page.ClientScript;

            // For loading the script on the page...
            cs.RegisterClientScriptResource(typeof(ICfiValidator), "Cfi.SoftwareFactory.Resources.Scripts.CfiValidator.js");

            // Adding the css on the page...
            validator.Page.Header.Controls.Add(new LiteralControl(String.Format("<link rel='stylesheet' text='text/css' href='{0}' />", cs.GetWebResourceUrl(typeof(CfiValidatorEventHelper), "Cfi.SoftwareFactory.Resources.Css.CfiValidator.css"))));

            // When pre-rendering, add in external JavaScript file for the update panel script manager...
            ScriptManager.RegisterClientScriptResource(validator.Page, typeof(CfiValidatorEventHelper), "Cfi.SoftwareFactory.Resources.Scripts.CfiValidator.js");
            Control control = validator.Parent.FindControl(validator.ControlToValidate);
            if(control != null)
                if(!cs.IsClientScriptBlockRegistered(validator.GetType(), String.Format("CfiValidator_{0}", validator.ClientID)))
                    cs.RegisterClientScriptBlock(validator.GetType(), String.Format("CfiValidator_{0}", validator.ClientID), String.Format("Page_CfiValidators.push(new Array('{0}', '{1}', '{2}', '{3}'));", validator.ClientID, control.ClientID, ((ICfiValidator)validator).ErrorCssClass, ((ICfiValidator)validator).ErrorClientFunction), true);
        }

        /// <summary>
        /// Method to handle the on prerender event of the sender, the validation controls in case.
        /// </summary>
        /// <param name="validator">The validation control which when loaded calls this method.</param>
        public static void OnPreRender(BaseValidator validator)
        {
            WebControl control = (WebControl)validator.Parent.FindControl(validator.ControlToValidate);
            if(control != null)
            {
                CfiValidatorUIHelper.Remove(control, ((ICfiValidator)validator).ErrorCssClass);
                if(!validator.IsValid)
                {
                    CfiValidatorUIHelper.Add(control, ((ICfiValidator)validator).ErrorCssClass);
                    control.ToolTip = validator.ErrorMessage;
                }
            }
        }
    }

    /// <summary>
    /// Class used to add and remove the required controls and add the required css to the control to validate.
    /// </summary>
    public static class CfiValidatorUIHelper
    {
        /// <summary>
        /// Method to add a class name to any webcontrol.
        /// </summary>
        /// <param name="control">The web control on which the css class name is to be applied.</param>
        /// <param name="className">The name of the css class which will be applied.</param>
        public static void Add(WebControl control, string className)
        {
            if(control == null || className == null) return;
            Remove(control, className);
            control.CssClass = String.Format("{0} {1}", control.CssClass, className).Trim();
        }

        /// <summary>
        /// Method to remove a class name from any webcontrol.
        /// </summary>
        /// <param name="control">The web control from which the css class name removed.</param>
        /// <param name="className">The name of the css class which will be removed.</param>
        public static void Remove(WebControl control, string className)
        {
            if(control == null || className == null) return;
            control.CssClass = control.CssClass.Replace(className, "").Trim();
        }
    }

    /// <summary>
    /// Interface to define the various properties and to be implemented by the CFI custom validator classes.
    /// </summary>
    interface ICfiValidator
    {
        /// <summary>
        /// Gets or sets the class that will be applied on control to validate on validation errors.
        /// </summary>
        string ErrorCssClass
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the client function that will be called on validation errors.
        /// </summary>
        string ErrorClientFunction
        {
            get;
            set;
        }
    }
}
