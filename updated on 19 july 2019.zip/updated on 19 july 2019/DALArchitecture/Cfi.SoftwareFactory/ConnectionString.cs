using System.Web.Configuration;



namespace Cfi.SoftwareFactory.Data
{
    public sealed class ConnectionString
    {
        public static string WebConfigConnectionString { get { return WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString; } }
    }
}