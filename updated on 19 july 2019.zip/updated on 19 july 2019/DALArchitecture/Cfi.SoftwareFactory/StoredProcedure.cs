using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using Cfi.SoftwareFactory.Data;
namespace Cfi.SoftwareFactory.BaseBusiness
{

    #region StoredProcedure Class Description
    /*
    *************************************************************************************
    Class Name:     StoredProcedure      
    Purpose:        Part of Cfi.SoftwareFactory.Application Object.
                    This class manages all StoredProcedres related to the entire component.
    Company:        CargoFlash Infotech .
    Author:         Manish kumar
    Created On:     26 Sep, 2009
     Approved By:   Sudhir Yadav
     Approved On:   30 Sep 2009
    ******************************************************************************
    */
    #endregion

    /// <summary>
    /// This Class acts as an interface between Security Class methods and Security Database stored procedures
    /// </summary>
    public class StoredProcedure : IDisposable
    {
        #region Local Internal Variable
        //Local variables.
        private readonly string connectionString = ConnectionString.WebConfigConnectionString;
#pragma warning disable 618,612
        private readonly string defaultErrorMessage = ConfigurationSettings.AppSettings["DefaultErrorMessage"];
#pragma warning restore 618,612

        //*************************************************
        #endregion

        #region Current Internal Obeject  from framework
        //Current Internal Object from framework.

        //*************************************************************
        #endregion

        #region Constructor Definition
        #endregion

        #region Destructor Definition
        /// <summary>
        /// Destructor: Cleanup the StoredProcedure Objects  
        /// </summary>
        ~StoredProcedure()
        {
            //Cleanup the Enviroment Objects
            Dispose();
        }
        #endregion

        #region DisposeMethod
        /// <summary>
        /// Dispose the all objects of StoredProcedure class.  
        /// </summary>
        public virtual void Dispose()
        {
            //if (Transaction != null)
            //    Transaction.Dispose();

            GC.SuppressFinalize(this);
        }
        #endregion

        #region Set All Property Variable
        public Boolean TransactionEnabled { get; set; }

        public SqlTransaction Transaction { get; set; }

        public int ErrorNumber { get; set; }

        public int SequenceNumber { get; set; }

        public string ErrorMessage { get; set; }
        #endregion

        #region GetList
        /// <summary>
        /// This function is used to Get the list of the data in the datatable. When error occurs check StoredProcedure.ErrorNo and StoredProcedure.errorDescription for actual error.
        /// </summary>
        /// <param name="entityName">EntityName contains table name.</param>
        /// <param name="entityFields">EntityFields contains table primary key.</param>
        /// <param name="whereCondition">WhereCondition contains the where condition of selection.</param>
        /// <returns>Its return the DataTable.</returns>
        public DataTable GetList(string entityName, string entityFields, string whereCondition)
        {
            /*
            *************************************************************************************
            Class Name:      StoredProcedure  
            Purpose:         This function is used to Get the list of the data in the datatable.
            Company:         CargoFlash Infotech
            Author:          Manish Kumar
            Created On:      26 Sep, 2009
            *************************************************************************************
            */

            //Set Local dataTable object.
            DataSet dt = null;
            try
            {
                SqlParameter sequenceNumber = new SqlParameter("@SequenceNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250};
                SqlParameter[] Parameters = {new SqlParameter("@EntityName", entityName), new SqlParameter("@ActionType", "G"), new SqlParameter("@RecordsFields", entityFields), new SqlParameter("@RecordsValues", whereCondition), sequenceNumber, errorNumber, ValidationMessage};

                dt = SqlHelper.ExecuteDataset(connectionString, CommandType.StoredProcedure, "SysProcessDocument", Parameters);

                if(int.Parse(Parameters[5].Value.ToString()) > 0)
                {
                    ErrorNumber = int.Parse(Parameters[5].Value.ToString());
                    ErrorMessage = Parameters[6].Value.ToString();
                    return null;
                }
                else
                    return dt.Tables[0];
            }
            catch(Exception)
            {
                const string errorDescription = "StoredProcedure.GetList():Internal Error! Could not execute SysProcessDocument";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return null;
            }
            finally
            {
                if(dt != null)
                    dt.Dispose();
            }
        }
        #endregion

        #region Sys_ProcessDocument
        /// <summary>
        /// This function is used to perform DML operation based on action. When error occurs check StoredProcedure.ErrorNo and StoredProcedure.errorDescription for actual error.
        /// </summary>
        /// <param name="entityName">EntityName</param>
        /// <param name="recordFields">RecordFields</param>
        /// <param name="recordValues">RecordValues</param>
        /// <param name="dMLAction">DMLAction</param>
        /// <returns>0 - (int)ResultType.Success.
        ///          1 - (int)ResultType.Failed, due to internal error.</returns>
        public int Sys_ProcessDocument(string entityName, string recordFields, string recordValues, string dMLAction)
        {
            /*
            *************************************************************************************
            Class Name:      StoredProcedure  
            Purpose:         This Generic function is used to perform DML operation based on action.
            Company:         CargoFlash Infotech
            Author:          Manish kumar
            Created On:      26  Sep, 2008
            *************************************************************************************
            */

            try
            {
                SqlParameter sequenceNumber = new SqlParameter("@SequenceNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250};
                SqlParameter[] Parameters = {new SqlParameter("@EntityName", entityName), new SqlParameter("@ActionType", dMLAction), new SqlParameter("@RecordsFields", recordFields), new SqlParameter("@RecordsValues", recordValues), sequenceNumber, errorNumber, ValidationMessage};
                if(TransactionEnabled)
                    SqlHelper.ExecuteScalar(Transaction, CommandType.StoredProcedure, "SysProcessDocument", Parameters);
                else
                    SqlHelper.ExecuteScalar(connectionString, CommandType.StoredProcedure, "SysProcessDocument", Parameters);

                if(dMLAction == "A")
                {
                    if(Parameters[4].Value.ToString().Trim() != "")
                        SequenceNumber = int.Parse(Parameters[4].Value.ToString());
                }

                if(int.Parse(Parameters[5].Value.ToString()) > 0)
                {
                    ErrorNumber = int.Parse(Parameters[5].Value.ToString());
                    ErrorMessage = Parameters[6].Value.ToString();
                    return (int)ResultType.Failed;
                }
                return (int)ResultType.Success;
            }
            catch(Exception)
            {
                const string errorDescription = "StoredProcedure.Sys_ProcessDocument():Internal Error! Could not execute SysProcessDocument";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return (int)ResultType.Failed;
            }
        }
        #endregion

        #region Sys_GetRecordCount
        /// <summary>
        /// This function is used to count the number of records. When error occurs check StoredProcedure.ErrorNo and StoredProcedure.errorDescription for actual error.
        /// </summary>
        /// <param name="entityName">EntityName</param>
        /// <param name="primaryKeyField">PrimaryKeyField</param> 
        /// <param name="dMLCondition">DMLCondition</param>
        /// <returns>0 - (int)ResultType.Success.
        ///          1 - (int)ResultType.Failed, due to Business Rule invalidation or internal error.</returns>
        public int Sys_GetRecordCount(string entityName, string primaryKeyField, string dMLCondition)
        {
            /*
            *************************************************************************************
            Class Name:      StoredProcedure  
            Purpose:         This function is used to count the number of records.
            Company:         CargoFlash InfoTech.
            Author:          Manish Kumar
            Created On:      26 Sep, 2009
            *************************************************************************************
            */
            SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int);
            try
            {
                errorNumber.Direction = ParameterDirection.Output;

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250};
                int countReturnValue = 0;
                SqlParameter[] Parameters = {new SqlParameter("@EntityName", entityName), new SqlParameter("@PrimaryKeyField", primaryKeyField), new SqlParameter("@DMLCondition", dMLCondition), errorNumber, ValidationMessage};

                DataSet ds = SqlHelper.ExecuteDataset(SqlHelper.CreateSqlConnection(connectionString), CommandType.StoredProcedure, "SysRecordCount", Parameters);

                if(int.Parse(Parameters[3].Value.ToString()) > 0)
                {
                    ErrorNumber = int.Parse(Parameters[3].Value.ToString());
                    ErrorMessage = Parameters[4].Value.ToString();
                    return (int)ResultType.Failed;
                }
                //if the count found than return else failded.
                if(ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    countReturnValue = int.Parse(ds.Tables[0].Rows[0][0].ToString());

                //Close the DataSet.
                ds.Dispose();
                return countReturnValue;
            }
            catch(Exception)
            {
                const string errorDescription = "StoredProcedure.Sys_GetRecordCount():Internal Error! Could not execute SysRecordCount";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return (int)ResultType.Failed;
            }
        }
        #endregion

        #region GetError
        /// <summary>
        /// 
        /// </summary>
        /// <param name="currentErrorDescription"></param>
        /// <returns></returns>
        public void SysGetError(string currentErrorDescription)
        {
            /*
            *************************************************************************************
            Class Name:      StoredProcedure  
            Purpose:         This function is used to set error number and error message
            Company:         CargoFlash InfoTech.
            Author:          Manish Kumar
            Created On:      26 Sep, 2009
            *************************************************************************************
            */
            try
            {
                SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250};

                SqlParameter[] Parameters = {new SqlParameter("@errorDescription", currentErrorDescription), new SqlParameter("@Culture", HttpContext.Current.Session["Culture"] == null ? "en-US" : HttpContext.Current.Session["Culture"].ToString()), errorNumber, ValidationMessage};
                SqlHelper.ExecuteScalar(connectionString, CommandType.StoredProcedure, "SysGetError", Parameters);
                try
                {
                    if(int.Parse(Parameters[2].Value.ToString()) > 0)
                    {
                        ErrorNumber = int.Parse(Parameters[2].Value.ToString());
                        ErrorMessage = Parameters[3].Value.ToString();
                    }
                }
                catch
                {
                    ErrorNumber = 999;
                    ErrorMessage = defaultErrorMessage;
                }
            }
            catch(Exception)
            {
                const string errorDescription = "StoredProcedure.GetError():Internal Error! Could not execute SysGetError";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
            }
        }
        #endregion

        #region SysGetListArray
        /// <summary>
        /// This function is used to Get the list of the data in the datatable. When error occurs check StoredProcedure.ErrorNo and StoredProcedure.errorDescription for actual error.
        /// </summary>
        /// <param name="entityName">EntityName contains table name.</param>
        /// <param name="entityFields">EntityFields contains table primary key.</param>
        /// <param name="whereCondition">WhereCondition contains the where condition of selection.</param>
        /// <returns>Its return the DataTable.</returns>
        public string SysGetListArray(string entityName, string entityFields, string whereCondition)
        {
            /*
            *************************************************************************************
            Class Name:      StoredProcedure  
            Purpose:         This function is used to set error number and error message
            Company:         CargoFlash InfoTech.
            Author:          Manish Kumar
            Created On:      26 Sep, 2009
            *************************************************************************************
            */
            //Set Local dataTable object.
            string listArray = string.Empty;
            try
            {
                SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250};
                SqlParameter[] Parameters = {new SqlParameter("@EntityName", entityName), new SqlParameter("@RecordsFields", entityFields), new SqlParameter("@RecordsValues", whereCondition), errorNumber, ValidationMessage};

                listArray = Convert.ToString(SqlHelper.ExecuteScalar(connectionString, CommandType.StoredProcedure, "SysGetListArray", Parameters));

                if(int.Parse(Parameters[3].Value.ToString()) > 0)
                {
                    ErrorNumber = int.Parse(Parameters[3].Value.ToString());
                    ErrorMessage = Parameters[4].Value.ToString();
                    return "";
                }
                else
                    return listArray;
            }
            catch(Exception)
            {
                const string errorDescription = "StoredProcedure.SysGetListArray():Internal Error! Could not execute SysGetListArray";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return "";
            }
        }
        #endregion
    } //End of CLass
} //End of namespaces.