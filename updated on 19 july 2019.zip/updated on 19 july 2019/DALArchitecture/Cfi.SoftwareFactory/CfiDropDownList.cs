﻿using System.Web.UI.WebControls;
using System.Web;

namespace Cfi.SoftwareFactory.WebControls
{
    public class CfiDropDownList : DropDownList
    {
        public string ValidationMessage
        {
            set
            {
                this.Attributes.Add("ValidationMessage", (HttpContext.GetGlobalResourceObject("GlobalCSAndJSMsg", value) != null) ? HttpContext.GetGlobalResourceObject("GlobalCSAndJSMsg", value).ToString() : value);
            }
        }
    }
}
