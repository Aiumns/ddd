﻿/* Automcomplete handler Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   This handler is used for generic automcomplete.
 * Created By           :   Dhiraj Kumar    
 * Created On           :   07 Jun 2010   
*/

using System;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Cfi.SoftwareFactory.BaseBusiness;
namespace Cfi.SoftwareFactory
{
    public class GenericAutocompleteHandler : IHttpHandler
    {
        /// <summary>
        /// You will need to configure this handler in the web.config file of your 
        /// web and register it with IIS before being able to use it. For more information
        /// </summary>

        public const string genericAutocompleteHandler =
        "Cfi.SoftwareFactory.GenericAutocompleteHandler.aspx";
        public bool IsReusable
        {
            // Return false in case your Managed Handler cannot be reused for another request.
            // Usually this would be false in case you have some state information preserved per request.
            get { return true; }
        }

      
        public void ProcessRequest(HttpContext context)
        {

            try
            {
                if (HttpContext.Current.Request.QueryString["Entity"] != null && HttpContext.Current.Request.QueryString["LabelField"] != null)
                {
                    using (StoredProcedure storedProcedure = new StoredProcedure())
                    {


                        string labelField = string.Empty;
                        if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["LabelField"]))
                        {
                            labelField = HttpContext.Current.Request.QueryString["LabelField"];
                            labelField = labelField.Trim();
                        }

                        string valueField = string.Empty;
                        if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["ValueField"]))
                        {
                            valueField = HttpContext.Current.Request.QueryString["ValueField"];
                            valueField = valueField.Trim();
                        }
                        string idField = string.Empty;
                        if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["IDField"]))
                        {
                            idField = HttpContext.Current.Request.QueryString["IDField"];
                            idField = idField.Trim();
                        }
                        string condition = string.Empty;
                        if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["WhereCondition"]))
                        {
                            condition = HttpContext.Current.Request.QueryString["WhereCondition"];
                            condition = valueField + " like '" + condition + "%'  or "+labelField.Split(',')[0]+ " like '" + condition + "%' ";
                        }
                        string condition2 = string.Empty;
                        if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["ConditionWhere"]))
                        {
                            condition2 = HttpContext.Current.Request.QueryString["ConditionWhere"];
                            condition = condition2 + " and " + condition;
                        }
                        string fieldSeperaterChar = string.Empty;
                        if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["FieldSeparatorChar"]))
                            fieldSeperaterChar=HttpContext.Current.Request.QueryString["FieldSeparatorChar"];

                        DataTable dt = storedProcedure.GetList(HttpContext.Current.Request.QueryString["Entity"], "Top 15 " + (idField == "" ? "" : idField + "," )+ labelField + ","+ valueField, condition);
                        string responseData = string.Empty;
                        foreach (DataRow dataRow in dt.Rows)
                        {
                            string[] labelFieldArray = labelField.Split(',');
                            string multipleLabelField = string.Empty;
                            if (labelFieldArray.Length > 0)
                            {
                                foreach (string s in labelFieldArray)
                                    multipleLabelField += dataRow[s] + fieldSeperaterChar;
                             multipleLabelField= multipleLabelField.Remove(multipleLabelField.LastIndexOf(fieldSeperaterChar));
                            }
                            responseData += "{";
                            responseData += (idField == "" ? "" : @"""id"": """ + dataRow[idField]+@""",") + @"""label"": """ + multipleLabelField + @""",""value"": """ + dataRow[valueField] + @""", ";
                            responseData = responseData != string.Empty ? responseData.Remove(responseData.LastIndexOf(",")) : responseData;
                            responseData += "},";
                        }
                        context.Response.ContentType = "application/json";
                        context.Response.Write(@"[" + (responseData != string.Empty ? responseData.Remove(responseData.LastIndexOf(",")) : responseData) + "]");
                    }
                }
            }
            catch
            {

            }
        }
    }
}
