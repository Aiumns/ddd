using System;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace Cfi.SoftwareFactory.WebControls
{
    /// <summary>
    /// Summary description for GridViewHyperlinkTemplate
    /// </summary>
    public class GridViewHyperlinkTemplate : ITemplate
    {
        private readonly string code;
        private readonly string columnName;
        private readonly DataControlRowType templateType;

        public GridViewHyperlinkTemplate(DataControlRowType templateType, string columnName, string code)
        {
            this.templateType = templateType;
            this.columnName = columnName;
            this.code = code;
        }

        #region ITemplate Members
        public void InstantiateIn(Control container)
        {
            switch(templateType)
            {
                case DataControlRowType.Header :
                    Literal lc = new Literal();
                    lc.Text = "<b>" + columnName + "</b>";
                    container.Controls.Add(lc);
                    break;
                case DataControlRowType.DataRow :
                    HyperLink hl = new HyperLink();
                    hl.Target = "_blank";
                    hl.CssClass = "ReportNoWrap";
                    hl.DataBinding += hl_DataBinding;
                    container.Controls.Add(hl);
                    break;
                default :
                    break;
            }
        }
        #endregion

        private void hl_DataBinding(Object sender, EventArgs e)
        {
            HyperLink hl = (HyperLink)sender;
            GridViewRow row = (GridViewRow)hl.NamingContainer;
            string[] codeArray = DataBinder.Eval(row.DataItem, code).ToString().Split(":".ToCharArray());
            hl.NavigateUrl = "DisplayDetails.aspx?ShowReportForType=" + codeArray[0] + "&Code=" + codeArray[1];
            hl.Text = codeArray[2];
        }
    }
}