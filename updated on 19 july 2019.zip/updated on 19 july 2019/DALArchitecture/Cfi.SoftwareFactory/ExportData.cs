using System;
using System.Data;
using System.IO;
using System.Text;
using System.Threading;
using System.Web;
using System.Xml;
using System.Xml.Xsl;



namespace Cfi.SoftwareFactory.Common
{
    public class ExportData
    {
        #region ExportFormat enum
        public enum ExportFormat
        {
            CSV = 1,
            Excel = 2
        }
        #endregion

        private readonly string appType;
        private readonly HttpResponse response;

        public ExportData()
        {
            appType = "Web";
            response = HttpContext.Current.Response;
        }

        public ExportData(string ApplicationType)
        {
            appType = ApplicationType;
            if((appType != "Web") && (appType != "Win"))
                throw new Exception("Provide valid application format (Web/Win)");
            if(appType == "Web")
                response = HttpContext.Current.Response;
        }

        private void Export_with_XSLT_Windows(DataSet dsExport, string[] sHeaders, string[] sFileds, ExportFormat FormatType, string FileName)
        {
            try
            {
                MemoryStream stream = new MemoryStream();
                XmlTextWriter writer = new XmlTextWriter(stream, Encoding.UTF8);
                CreateStylesheet(writer, sHeaders, sFileds, FormatType);
                writer.Flush();
                stream.Seek(0L, 0);
                XmlDataDocument document = new XmlDataDocument(dsExport);
                XslTransform transform = new XslTransform();
                transform.Load(new XmlTextReader(stream), null, null);
                StringWriter writer2 = new StringWriter();
                transform.Transform(document, null, writer2, null);
                StreamWriter writer3 = new StreamWriter(FileName);
                writer3.WriteLine(writer2.ToString());
                writer3.Close();
                writer2.Close();
                writer.Close();
                stream.Close();
            }
            catch(Exception exception)
            {
                throw exception;
            }
        }

        private void Export_with_XSLT_Web(DataSet dsExport, string[] sHeaders, string[] sFileds, ExportFormat FormatType, string FileName)
        {
            try
            {
                response.Clear();
                response.Buffer = true;
                if(FormatType == ExportFormat.CSV)
                {
                    response.ContentType = "text/csv";
                    response.AppendHeader("content-disposition", "attachment; filename=" + FileName);
                }
                else
                {
                    response.ContentType = "application/vnd.ms-excel";
                    response.AppendHeader("content-disposition", "attachment; filename=" + FileName);
                }
                MemoryStream stream = new MemoryStream();
                XmlTextWriter writer = new XmlTextWriter(stream, Encoding.UTF8);
                CreateStylesheet(writer, sHeaders, sFileds, FormatType);
                writer.Flush();
                stream.Seek(0L, 0);
                XmlDataDocument document = new XmlDataDocument(dsExport);
                XslTransform transform = new XslTransform();
                transform.Load(new XmlTextReader(stream), null, null);
                StringWriter writer2 = new StringWriter();
                transform.Transform(document, null, writer2, null);
                response.Write(writer2.ToString());
                writer2.Close();
                writer.Close();
                stream.Close();
                response.End();
            }
            catch(ThreadAbortException exception)
            {
                string str = exception.Message;
            }
            catch(Exception exception2)
            {
                throw exception2;
            }
        }

        private void CreateStylesheet(XmlTextWriter writer, string[] sHeaders, string[] sFileds, ExportFormat FormatType)
        {
            try
            {
                string str = "http://www.w3.org/1999/XSL/Transform";
                writer.Formatting = Formatting.Indented;
                writer.WriteStartDocument();
                writer.WriteStartElement("xsl", "stylesheet", str);
                writer.WriteAttributeString("version", "1.0");
                writer.WriteStartElement("xsl:output");
                writer.WriteAttributeString("method", "text");
                writer.WriteAttributeString("version", "4.0");
                writer.WriteEndElement();
                writer.WriteStartElement("xsl:template");
                writer.WriteAttributeString("match", "/");
                for(int i = 0; i < sHeaders.Length; i++)
                {
                    writer.WriteString("\"");
                    writer.WriteStartElement("xsl:value-of");
                    writer.WriteAttributeString("select", "'" + sHeaders[i] + "'");
                    writer.WriteEndElement();
                    writer.WriteString("\"");
                    if(i != (sFileds.Length - 1))
                        writer.WriteString((FormatType == ExportFormat.CSV) ? "," : "\t");
                }
                writer.WriteStartElement("xsl:for-each");
                writer.WriteAttributeString("select", "Export/Values");
                writer.WriteString("\r\n");
                for(int j = 0; j < sFileds.Length; j++)
                {
                    writer.WriteString("\"");
                    writer.WriteStartElement("xsl:value-of");
                    writer.WriteAttributeString("select", sFileds[j]);
                    writer.WriteEndElement();
                    writer.WriteString("\"");
                    if(j != (sFileds.Length - 1))
                        writer.WriteString((FormatType == ExportFormat.CSV) ? "," : "\t");
                }
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
            catch(Exception exception)
            {
                throw exception;
            }
        }

        public void ExportDetails(DataTable DetailsTable, ExportFormat FormatType, string FileName)
        {
            try
            {
                if(DetailsTable.Rows.Count == 0)
                    throw new Exception("There are no details to export.");
                DataSet dsExport = new DataSet("Export");
                DataTable table = DetailsTable.Copy();
                table.TableName = "Values";
                dsExport.Tables.Add(table);
                string[] sHeaders = new string[table.Columns.Count];
                string[] sFileds = new string[table.Columns.Count];
                for(int i = 0; i < table.Columns.Count; i++)
                {
                    sHeaders[i] = table.Columns[i].ColumnName;
                    sFileds[i] = ReplaceSpclChars(table.Columns[i].ColumnName);
                }
                if(appType == "Web")
                    Export_with_XSLT_Web(dsExport, sHeaders, sFileds, FormatType, FileName);
                else if(appType == "Win")
                    Export_with_XSLT_Windows(dsExport, sHeaders, sFileds, FormatType, FileName);
            }
            catch(Exception exception)
            {
                throw exception;
            }
        }

        public void ExportDetails(DataTable DetailsTable, int[] ColumnList, ExportFormat FormatType, string FileName)
        {
            try
            {
                if(DetailsTable.Rows.Count == 0)
                    throw new Exception("There are no details to export");
                DataSet dsExport = new DataSet("Export");
                DataTable table = DetailsTable.Copy();
                table.TableName = "Values";
                dsExport.Tables.Add(table);
                if(ColumnList.Length > table.Columns.Count)
                    throw new Exception("ExportColumn List should not exceed Total Columns");
                string[] sHeaders = new string[ColumnList.Length];
                string[] sFileds = new string[ColumnList.Length];
                for(int i = 0; i < ColumnList.Length; i++)
                {
                    if((ColumnList[i] < 0) || (ColumnList[i] >= table.Columns.Count))
                        throw new Exception("ExportColumn Number should not exceed Total Columns Range");
                    sHeaders[i] = table.Columns[ColumnList[i]].ColumnName;
                    sFileds[i] = ReplaceSpclChars(table.Columns[ColumnList[i]].ColumnName);
                }
                if(appType == "Web")
                    Export_with_XSLT_Web(dsExport, sHeaders, sFileds, FormatType, FileName);
                else if(appType == "Win")
                    Export_with_XSLT_Windows(dsExport, sHeaders, sFileds, FormatType, FileName);
            }
            catch(Exception exception)
            {
                throw exception;
            }
        }

        public void ExportDetails(DataTable DetailsTable, int[] ColumnList, string[] Headers, ExportFormat FormatType, string FileName)
        {
            try
            {
                if(DetailsTable.Rows.Count == 0)
                    throw new Exception("There are no details to export");
                DataSet dsExport = new DataSet("Export");
                DataTable table = DetailsTable.Copy();
                table.TableName = "Values";
                dsExport.Tables.Add(table);
                if(ColumnList.Length != Headers.Length)
                    throw new Exception("ExportColumn List and Headers List should be of same length");
                if((ColumnList.Length > table.Columns.Count) || (Headers.Length > table.Columns.Count))
                    throw new Exception("ExportColumn List should not exceed Total Columns");
                string[] sFileds = new string[ColumnList.Length];
                for(int i = 0; i < ColumnList.Length; i++)
                {
                    if((ColumnList[i] < 0) || (ColumnList[i] >= table.Columns.Count))
                        throw new Exception("ExportColumn Number should not exceed Total Columns Range");
                    sFileds[i] = ReplaceSpclChars(table.Columns[ColumnList[i]].ColumnName);
                }
                if(appType == "Web")
                    Export_with_XSLT_Web(dsExport, Headers, sFileds, FormatType, FileName);
                else if(appType == "Win")
                    Export_with_XSLT_Windows(dsExport, Headers, sFileds, FormatType, FileName);
            }
            catch(Exception exception)
            {
                throw exception;
            }
        }

        private string ReplaceSpclChars(string fieldName)
        {
            fieldName = fieldName.Replace(" ", "_x0020_");
            fieldName = fieldName.Replace("%", "_x0025_");
            fieldName = fieldName.Replace("#", "_x0023_");
            fieldName = fieldName.Replace("&", "_x0026_");
            fieldName = fieldName.Replace("/", "_x002F_");
            return fieldName;
        }
    }
}