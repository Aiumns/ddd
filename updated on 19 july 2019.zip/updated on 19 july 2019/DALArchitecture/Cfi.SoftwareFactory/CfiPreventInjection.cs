using System;
using System.Web;
using System.Web.UI;
using System.Configuration;


/// <summary>
/// Summary description for SampleSqlInjectionScreeningModule
/// </summary>
/// 
/// 
[assembly: TagPrefix("Cfi.SoftwareFactory.Common.HttpModules", "Cfi.SoftwareFactory.Common.HttpModules")]

namespace Cfi.SoftwareFactory.Common.HttpModules
{

    public class CfiPreventInjection : IHttpModule
    {
        public static string[] blackList = {"--",";--",";","/*","*/","@@",
                                           "nchar","varchar","nvarchar",
                                           "alter","begin","cast","create","cursor","delete","drop","exec","execute",
                                           "fetch","insert","kill","open",
                                           "select", "sys","sysobjects","syscolumns",
                                           "table","frame","truncate","iframe"};

        public void Dispose()
        {

        }

        //Tells ASP.NET that there is code to run during BeginRequest
        public void Init(HttpApplication app)
        {
            app.BeginRequest += app_BeginRequest;
        }

        //For each incoming request, check the query-string, form and cookie values for suspicious values.
        void app_BeginRequest(object sender, EventArgs e)
        {
            HttpRequest Request = (sender as HttpApplication).Context.Request;
            if (ConfigurationManager.AppSettings["ValidateQueryString"] == "true")
                foreach (string key in Request.QueryString)
                    CheckInput(Request.QueryString[key]);
            if (ConfigurationManager.AppSettings["ValidateControls"] == "true")
                foreach (string key in Request.Form)
                {
                    if (key.Substring(0, 3) == "txt")
                        CheckInput(Request.Form[key]);
                }
            if (ConfigurationManager.AppSettings["ValidateCookies"] == "true")
                foreach (string key in Request.Cookies)
                    CheckInput(Request.Cookies[key].Value);
        }

        //The utility method that performs the blacklist comparisons
        //You can change the error handling, and error redirect location to whatever makes sense for your site.
        public void CheckInput(string parameter)
        {
            for (int i = 0; i < blackList.Length; i++)
                if ((parameter.IndexOf(blackList[i], StringComparison.OrdinalIgnoreCase) >= 0))
                    HttpContext.Current.Response.Redirect("~/Login.aspx");  //generic error page on your site
        }
    }
}
