/* CfiGridView Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright � 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Description          :   Class contains the extention of the normal grid view. It contains the additional property of the header of the grid view to freeze (limeited to IE only)                            , while the grid can scroll. There is additional inbuild functionality of sorting, i.e one do not have to put in any code to sort the grid.
 * Created By           :   Sudhir Yadav.
 * Created On           :   01 Jul 2009.
 * Modified By          :   Chander Shekhar Sharma.
 * Modified On          :   17 Dec 2009.
 * Description          :   Create property AllowExpandCollapse if this is true than CfiGridViewRow extendes the standard GridView row to render the contents from the last cell as an expandible cell, basically it is used in permission page. 
 * Modified By          :   Dilip Kumar.
 * Modified On          :   03 Apr 2010.
 * Description          :   Change error message. 
 * Modified By          :   Chandra Prakash.
 * Modified On          :   14 Jan 2010.
 * Description          :   Changed the Date Format according to the Culture and Changed the Check Box control to Label for showing images for checked and unchecked.
*/

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Cfi.SoftwareFactory.BaseBusiness;
[assembly: TagPrefix("Cfi.SoftwareFactory.WebControls", "Cfi")]

namespace Cfi.SoftwareFactory.WebControls
{
    /// <summary>
    /// Summary description for GridViewFrozen
    /// </summary>
    public class CfiGridView : GridView
    {
        //Delegate to handle the template button click event...

        #region Delegates
        public delegate void CfiGridViewTemplateButtonClickHandler(object sender, CfiGridViewTemplateButtonClickEventArgs e);
        #endregion

        #region ExtendedColumnLocations enum
        public enum ExtendedColumnLocations
        {
            Left,
            Right
        }
        #endregion

        #region Expend Colleps Template
        private String collapseButtonCssClass;
        private String collapseButtonText = "-";
        private String expandButtonCssClass;
        private String expandButtonText = "+";

        /// <summary>
        /// Sets or gets the CSS class which is applied on the expand button control.
        /// </summary>
        [Category("Styles")]
        public String ExpandButtonCssClass { get { return expandButtonCssClass; } set { expandButtonCssClass = value; } }

        /// <summary>
        /// Sets or gets the CSS class which is applied on the collapse button control.
        /// </summary>
        [Category("Styles")]
        public String CollapseButtonCssClass { get { return collapseButtonCssClass; } set { collapseButtonCssClass = value; } }

        /// <summary>
        /// Sets or gets the expand button's text.
        /// </summary>
        [Category("Appearance")]
        public String ExpandButtonText { get { return expandButtonText; } set { expandButtonText = value; } }

        /// <summary>
        /// Sets or gets the collapse button's text.
        /// </summary>
        [Category("Appearance")]
        public String CollapseButtonText { get { return collapseButtonText; } set { collapseButtonText = value; } }

        /// <summary>
        /// Sets or gets the collapse button's text.
        /// </summary>
        public bool AllowExpandCollapse { get; set; }

        /// <summary>
        /// Overrides GridView.OnInit to perform custom initialization of the control.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if(AllowExpandCollapse)
            {
                string script = @"function TglRow(ctl)
{
	var row = ctl.parentNode.parentNode;
	var tbl = row.parentNode;
	var crow = tbl.rows[row.rowIndex + 1];
	var ihExp = ctl.parentNode.getElementsByTagName('input').item(0);

	tbl = tbl.parentNode;

	var expandClass = tbl.attributes.getNamedItem('expandClass').value;
	var collapseClass = tbl.attributes.getNamedItem('collapseClass').value;
	var expandText = tbl.attributes.getNamedItem('expandText').value;
	var collapseText = tbl.attributes.getNamedItem('collapseText').value;

	
	if (crow.style.display == 'none')
	{
		crow.style.display = '';
		ctl.innerHTML = collapseText;
		ctl.className = collapseClass;
		ihExp.value = '1';
	}
	else
	{
		crow.style.display = 'none';
		ctl.innerHTML = expandText;
		ctl.className = expandClass;
		ihExp.value = '';
	}
}";

                Page.ClientScript.RegisterClientScriptBlock(GetType(), "ExtGrid", script, true);
            }
        }

        /// <summary>
        /// Overrides GridView.CreateRow to create the custom rows in the grid (CfiGridViewRow).
        /// </summary>
        /// <param name="rowIndex"></param>
        /// <param name="dataSourceIndex"></param>
        /// <param name="rowType"></param>
        /// <param name="rowState"></param>
        /// <returns></returns>
        protected override GridViewRow CreateRow(int rowIndex, int dataSourceIndex, DataControlRowType rowType, DataControlRowState rowState)
        {
            if(AllowExpandCollapse)
                return new CfiGridViewRow(rowIndex, dataSourceIndex, rowType, rowState);
            else
                return new GridViewRow(rowIndex, dataSourceIndex, rowType, rowState);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            Attributes["expandClass"] = expandButtonCssClass;
            Attributes["collapseClass"] = collapseButtonCssClass;
            Attributes["expandText"] = expandButtonText;
            Attributes["collapseText"] = collapseButtonText;

            base.Render(writer);
        }
        #endregion

        // Event declaration for template button click event...

        #region ModifierLocationValue enum
        /// <summary>
        /// Enum to set the View, Update and Delete modifier location. Weather to the left or to the right of the grid.
        /// </summary>
        public enum ModifierLocationValue
        {
            Left,
            Right
        }
        #endregion

        /// <summary>
        /// Get or set the display modifiers. i.e weather the columns 'View, Update, Delete are to be displayed.
        /// </summary>
        [Category("ExtendedColumnCollection")]
        [Browsable(true)]
        public ArrayList TemplateCollection
        {
            get { return (ArrayList)ViewState["TemplateCollection"]; }
            set
            {
                ViewState["TemplateCollection"] = value;
                AddCfiTemplateColumn(value);
            }
        }

        public override object DataSource
        {
            get { return base.DataSource; }
            set
            {
                CurrentDataSource = value;

                // Added by Sudhir Yadav. Dt 03 Apr 2010.
                // Changing the data source values to change and display in the auto generate column condition to the appropriate values, for example in datetime: display only date in current culture and boolean: chekboxes...
                object dataSource = value;
                DataTable dtDataSource = null;
                if(typeof(DataTable) == dataSource.GetType())
                    dtDataSource = (DataTable)dataSource;
                else if(typeof(DataSet) == dataSource.GetType())
                    dtDataSource = ((DataSet)dataSource).Tables[0];
                else if(typeof(DataView) == dataSource.GetType())
                    dtDataSource = ((DataView)dataSource).Table;

                DataTable dtTemp = new DataTable();
                foreach(DataColumn dcTemp in dtDataSource.Columns)
                    dtTemp.Columns.Add(new DataColumn(dcTemp.ColumnName, typeof(string)));

                for(int i = 0; i < dtDataSource.Rows.Count; i++)
                {
                    DataRow drTemp = dtTemp.NewRow();
                    DataRow drDataSource = dtDataSource.Rows[i];
                    for(int j = 0; j < dtDataSource.Columns.Count; j++)
                    {
                        DataColumn dcDataSource = dtDataSource.Columns[j];
                        if(dcDataSource.DataType == typeof(bool))
                            drTemp[j] = (bool)drDataSource[dcDataSource.ColumnName] ? "Yes" : "No";
                        else if(dcDataSource.DataType == typeof(System.DateTime))
                            drTemp[j] = ((DateTime)drDataSource[dcDataSource.ColumnName]).ToShortDateString();
                        else
                            drTemp[j] = drDataSource[dcDataSource.ColumnName];
                    }

                    dtTemp.Rows.Add(drTemp);
                }

                base.DataSource = dtTemp;
            }
        }

        protected object CurrentDataSource { get { return ViewState["CurrentDataSource"] ?? DataSource; } set { ViewState["CurrentDataSource"] = value; } }

        /// <summary>
        /// Get or set if the datasource have any data. If the data that is bound is null or does not have any row then a row with blank or null data row will be inserted and the columns cells will be merged.
        /// </summary>
        public bool HaveData { get { return (bool)(ViewState["HaveData"] ?? false); } set { ViewState["HaveData"] = value; } }

        /// <summary>
        /// Get or set the columns which are to be hide from the user.
        /// </summary>
        public string ColumnsToHide { get { return ViewState["ColumnsToHide"] == null ? string.Empty : ViewState["ColumnsToHide"].ToString(); } set { ViewState["ColumnsToHide"] = value; } }

        /// <summary>
        /// Get or set the DataTable
        /// </summary>
        public DataTable CurrentDataTable { get { return (DataTable)(ViewState["CurrentDataTable"] ?? null); } set { ViewState["CurrentDataTable"] = value; } }

        /// <summary>
        /// Access to the GridView's inner table.
        /// </summary>
        protected Table InnerTable { get { return (HasControls()) ? (Table)Controls[0] : null; } }

        private void AddCfiTemplateColumn(ArrayList alTemplateField)
        {
            if(TemplateCollection != null && HaveData)
            {
                foreach(CfiTemplate cfiTemplate in alTemplateField)
                {
                    TemplateField tf = new TemplateField { ItemTemplate = cfiTemplate };
                    //tf.HeaderText = "CfiTemplate";
                    //tf.ControlStyle.Width = new Unit(20, UnitType.Pixel);
                    //tf.ControlStyle.Height = new Unit(20, UnitType.Pixel);
                    //tf.HeaderStyle.Width = new Unit(20, UnitType.Pixel);
                    //tf.HeaderStyle.Height = new Unit(20, UnitType.Pixel);
                    //tf.ItemStyle.Width = new Unit(20, UnitType.Pixel);
                    //tf.ItemStyle.Height = new Unit(20, UnitType.Pixel);
                    //tf.FooterStyle.Width = new Unit(20, UnitType.Pixel);
                    //tf.FooterStyle.Height = new Unit(20, UnitType.Pixel);
                    Columns.Add(tf);
                }
            }
        }

        public event CfiGridViewTemplateButtonClickHandler CfiGridViewTemplateButtonClick;

        protected override void OnSorting(GridViewSortEventArgs e)
        {
            //base.OnSorting(e);
            SortDirection objSortDirection = ViewState[e.SortExpression + "SortDirection"] == null ? SortDirection.Ascending : (SortDirection)ViewState[e.SortExpression + "SortDirection"];
            string sortDirection;
            if(objSortDirection == SortDirection.Ascending)
            {
                objSortDirection = SortDirection.Descending;
                sortDirection = e.SortExpression + " DESC";
            }
            else
            {
                objSortDirection = SortDirection.Ascending;
                sortDirection = e.SortExpression + " ASC";
            }
            ViewState[e.SortExpression + "SortDirection"] = objSortDirection;
            DataView dvTemp = null;
            if(CurrentDataSource.GetType().ToString() == "System.Data.DataSet")
            {
                DataSet ds = (DataSet)CurrentDataSource;
                ds.Tables[0].DefaultView.Sort = sortDirection;
                dvTemp = ds.Tables[0].DefaultView;
            }
            else if(CurrentDataSource.GetType().ToString() == "System.Data.DataTable")
            {
                DataTable dt = (DataTable)CurrentDataSource;
                dt.DefaultView.Sort = sortDirection;
                dvTemp = dt.DefaultView;
            }
            else if(CurrentDataSource.GetType().ToString() == "System.Data.DataView")
            {
                DataView dv = (DataView)CurrentDataSource;
                dv.Sort = sortDirection;
                dvTemp = dv;
            }
            if(dvTemp != null)
                DataSource = dvTemp.Table;
            DataBind();
        }

        protected override void OnRowCommand(GridViewCommandEventArgs e)
        {
            base.OnRowCommand(e);
            if(e.CommandName.StartsWith("Mode:"))
            {
                string[] modeAndPrimaryKeyColumn = e.CommandName.Replace("Mode:", string.Empty).Split(":".ToCharArray());
                string primaryKeyValue = e.CommandArgument.ToString();
                if(CfiGridViewTemplateButtonClick != null)
                    CfiGridViewTemplateButtonClick(e.CommandSource, new CfiGridViewTemplateButtonClickEventArgs((UIMode)Enum.Parse(typeof(UIMode), modeAndPrimaryKeyColumn[0]), modeAndPrimaryKeyColumn[1], primaryKeyValue));
            }
        }

        protected override void OnRowDataBound(GridViewRowEventArgs e)
        {
            base.OnRowDataBound(e);

            if(!AllowExpandCollapse)
            {
                int columnsCount = e.Row.Cells.Count;
                for(int i = 0; i < columnsCount; i++)
                {
                    try
                    {
                        string tableCellText = e.Row.RowType == DataControlRowType.Header ? ((LinkButton)e.Row.Cells[i].Controls[0]).Text.ToLower() : ((LinkButton)HeaderRow.Cells[i].Controls[0]).Text.ToLower();
                        if(ColumnsToHide.Contains(tableCellText))
                            e.Row.Cells[i].Visible = false;
                    }
                    catch
                    {
                        //Do nothing, just kept to avoid any kind of exception when getting the string tableCellText mostly.
                    }
                }
                if(!HaveData && e.Row.RowType == DataControlRowType.DataRow)
                {
                    int cellCount = e.Row.Cells.Count;
                    InnerTable.Rows[1].Cells.Clear();
                    TableCell tc = new TableCell { Text = "No Record Found" };
                    InnerTable.Rows[1].Cells.Add(tc);
                    tc.ColumnSpan = cellCount;
                }
                else
                {
                    if(e.Row.RowType == DataControlRowType.DataRow)
                    {
                        try
                        {
                            int i = 0;
                            if(TemplateCollection != null)
                            {
                                foreach(CfiTemplate cfiTemplate in TemplateCollection)
                                {
                                    LinkButton lnkButton = new LinkButton();
                                    lnkButton.CausesValidation = false;
                                    //lnkButton.CssClass = CssClass ?? "gridlink";
                                    lnkButton.Text = cfiTemplate.Text ?? cfiTemplate.ColumnType.ToString();
                                    lnkButton.Attributes.Add("tooltip", cfiTemplate.Tooltip ?? lnkButton.Text);
                                    lnkButton.Style.Add("cursor", "pointer");

                                    //The command name is supposed to store the mode and the primary key values...
                                    string primaryKeyColumns = string.Empty;
                                    string primaryKeyValues = string.Empty;
                                    for(int j = 0; j < cfiTemplate.PrimaryKeyColumnWithHideAttribute.GetLength(0); j++)
                                    {
                                        string currentColumn = cfiTemplate.PrimaryKeyColumnWithHideAttribute[j, 0];
                                        primaryKeyColumns += currentColumn + ",";
                                        primaryKeyValues += CurrentDataTable.Rows[e.Row.RowIndex][currentColumn] + ",";
                                    }
                                    primaryKeyColumns = primaryKeyColumns.Contains(",") ? primaryKeyColumns.Substring(0, primaryKeyColumns.LastIndexOf(",")).Replace("[", string.Empty).Replace("]", string.Empty) : string.Empty;
                                    primaryKeyValues = primaryKeyValues.Contains(",") ? primaryKeyValues.Substring(0, primaryKeyValues.LastIndexOf(",")) : string.Empty;

                                    lnkButton.CommandName = "Mode:" + cfiTemplate.Mode + ":" + primaryKeyColumns;
                                    lnkButton.CommandArgument = primaryKeyValues;

                                    if(!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Blank)
                                        lnkButton.Attributes["onclick"] = String.Format("javascript:window.open('{0}','{1}','{2}');return false;", cfiTemplate.Hyperlink + primaryKeyValues, "_blank", string.Empty);
                                    else if(!string.IsNullOrEmpty(cfiTemplate.Hyperlink) && cfiTemplate.TargetType == CfiTemplate.HyperlinkTargetType.Self)
                                        lnkButton.Attributes["href"] = cfiTemplate.Hyperlink + primaryKeyValues;
                                    else
                                    {
                                        int rowId = e.Row.RowIndex;
                                        string command = String.Format("{0}${1}", lnkButton.CommandName, rowId);
                                        lnkButton.Attributes["onclick"] = String.Format("javascript:__doPostBack('{0}','{1}')", e.Row.UniqueID + i, command);
                                    }
                                    e.Row.Cells[i].Controls.Add(lnkButton);
                                    e.Row.Cells[i].Attributes.Add("nowrap", "nowrap");
                                    e.Row.Cells[i].Width = new Unit(20, UnitType.Pixel);
                                    e.Row.Cells[i].Height = new Unit(20, UnitType.Pixel);
                                    i++;
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                }

                //If the row that is created is the last one then set the header of the action commands and merge them...
                if(HaveData && e.Row.RowType == DataControlRowType.Footer && TemplateCollection != null) //Merging the CfiTemplate header columns. Only if it have data in it.
                {
                    int cfiCellCount = TemplateCollection.Count;
                    if(cfiCellCount != 0)
                        HeaderRow.Cells[0].Text = "<span class=\"ActionHeaderStyle\" >Action</span>";
                }
            }
        }

        #region Nested type: CfiTemplate
        /// <summary>
        /// Class that inherits the ITemplate and adds its own properties to be used with the CfiGridView.
        /// </summary>
        [Serializable]
        public class CfiTemplate : ITemplate, INamingContainer
        {
            #region GridViewDataControlFieldType enum
            /// <summary>
            /// Enum that contains the common type of template that we already have in our application. Rest can be added on demand.
            /// </summary>
            public enum GridViewDataControlFieldType
            {
                View,
                Update,
                Delete,
                Print,
                Label,
                Handover,
                CCA,
                Receipt,
                Plan
            }
            #endregion

            #region HyperlinkTargetType enum
            /// <summary>
            /// Enum that specifies the target type of the hyperlink that it will be opened in. Blank means in new window. Self means in the same window.
            /// </summary>
            public enum HyperlinkTargetType
            {
                Blank,
                Self
            }
            #endregion

            /// <summary>
            /// Get or set the type of the column of enum typeof(GridViewDataControlFieldType).
            /// </summary>
            public GridViewDataControlFieldType ColumnType { get; set; }

            /// <summary>
            /// Get or set the type of the target of enum typeof(HyperlinkTargetType).
            /// </summary>
            public HyperlinkTargetType TargetType { get; set; }

            /// <summary>
            /// Get or set the name of the primary key column, against which each row will be uniquely identified.
            /// </summary>
            public string[,] PrimaryKeyColumnWithHideAttribute { get; set; }

            /// <summary>
            /// Get or set the hyper link that will be opened. Leave if not required.
            /// </summary>
            public string Hyperlink { get; set; }

            /// <summary>
            /// Get or set the UIMode New, View, Update or Delete.
            /// </summary>
            public UIMode Mode { get; set; }

            /// <summary>
            /// Get or set the tooltip on the webcontrol in the template.
            /// </summary>
            public string Tooltip { get; set; }

            /// <summary>
            /// Get or set the text that needs to be displayed on the webcontrol in the template.
            /// </summary>
            public string Text { get; set; }

            /// <summary>
            /// Get or set the css class of the webcontrol in the template.
            /// </summary>
            public string CssClass { get; set; }

            #region ITemplate Members
            public void InstantiateIn(Control container) { }
            #endregion
        }
        #endregion

        #region Nested type: CfiGridViewTemplateButtonClickEventArgs
        /// <summary>
        /// Event agrs class extended to create the event arguments of the template button clicked.
        /// </summary>
        public class CfiGridViewTemplateButtonClickEventArgs : EventArgs
        {
            public CfiGridViewTemplateButtonClickEventArgs(UIMode uiMode, string primaryKeyColumn, string primaryKeyValue)
            {
                Mode = uiMode;
                PrimaryKeyColumn = primaryKeyColumn;
                PrimaryKeyValue = primaryKeyValue;
            }

            public UIMode Mode { get; set; }

            public string PrimaryKeyColumn { get; set; }
            public string PrimaryKeyValue { get; set; }
        }
        #endregion
    }


    /// <summary>
    /// CfiGridViewRow extendes the standard GridView row to render the contents from the last cell as an expandible cell
    /// </summary>
    public class CfiGridViewRow : GridViewRow
    {
        private HtmlAnchor ctlExpand;
        private TableCell expCell;
        private HtmlInputHidden ihExp;
        private Boolean showExpand;

        /// <summary>
        /// Constructor for CfiGridViewRow
        /// </summary>
        /// <param name="rowIndex"></param>
        /// <param name="dataItemIndex"></param>
        /// <param name="rowType"></param>
        /// <param name="rowState"></param>
        public CfiGridViewRow(int rowIndex, int dataItemIndex, DataControlRowType rowType, DataControlRowState rowState) : base(rowIndex, dataItemIndex, rowType, rowState) { }

        /// <summary>
        /// Gets or sets a value which specifies if the expand boutton should be displayed or not for the current row.
        /// </summary>
        public Boolean ShowExpand { get { return showExpand; } set { showExpand = value; } }

        /// <summary>
        /// Overrides GridViewRow.OnInit to perform custom initialization of the row.
        /// </summary>
        /// <param name="e">event args</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if(RowType == DataControlRowType.Header)
                expCell = new TableHeaderCell();
            else if(RowType == DataControlRowType.DataRow)
            {
                expCell = new TableCell();

                ctlExpand = new HtmlAnchor();
                ctlExpand.HRef = "javascript: void(0);";
                ctlExpand.Attributes["onclick"] = "TglRow(this);";

                ihExp = new HtmlInputHidden();
                ihExp.ID = "e" + DataItemIndex;

                expCell.Controls.Add(ctlExpand);
                expCell.Controls.Add(ihExp);
            }

            if(expCell != null)
            {
                expCell.Width = Unit.Pixel(20);

                Cells.AddAt(0, expCell);
            }
        }

        /// <summary>
        /// Overrides GridViewRow.Render to perform custom rendering of the row.
        /// </summary>
        /// <param name="writer">the HtmlTextWrite object in which the row is rendered</param>
        protected override void Render(HtmlTextWriter writer)
        {
            if(DesignMode)
            {
                base.Render(writer);
                return;
            }

            TableCell c = Cells[Cells.Count - 1];

            if(RowType == DataControlRowType.DataRow)
            {
                if(showExpand)
                {
                    CfiGridView grid = Parent.Parent as CfiGridView;

                    if(ihExp.Value == String.Empty)
                    {
                        ctlExpand.InnerHtml = grid.ExpandButtonText;
                        ctlExpand.Attributes["class"] = grid.ExpandButtonCssClass;
                    }
                    else
                    {
                        ctlExpand.InnerHtml = grid.CollapseButtonText;
                        ctlExpand.Attributes["class"] = grid.CollapseButtonCssClass;
                    }

                    c.Visible = false;
                    base.Render(writer);

                    c.Visible = true;
                    c.ColumnSpan = GetVisibleCellsCount() - 1;
                    c.BackColor = BackColor;

                    if(ihExp.Value == String.Empty)
                        writer.Write("<tr style='display:none'>");
                    else
                        writer.Write("<tr>");

                    c.RenderControl(writer);

                    writer.Write("</tr>");

                    if(RowIndex == grid.Rows.Count - 1)
                    {
                        if((grid.BottomPagerRow == null && grid.FooterRow == null) || ((grid.BottomPagerRow != null && grid.BottomPagerRow.Visible == false) && grid.FooterRow != null && grid.FooterRow.Visible == false))
                        {
                            writer.Write("<tr><td colspan=");
                            writer.Write(c.ColumnSpan);
                            writer.Write("></td></tr>");
                        }
                    }
                }
                else
                {
                    ctlExpand.Visible = ihExp.Visible = false;
                    c.Visible = false;
                    base.Render(writer);
                }
            }
            else if(RowType == DataControlRowType.Header)
            {
                c.Visible = false;
                base.Render(writer);
            }
            else
                base.Render(writer);
        }

        /// <summary>
        /// Helper method which obtains the visible cells count in the current row.
        /// </summary>
        /// <returns></returns>
        private Int32 GetVisibleCellsCount()
        {
            Int32 ret = 0;

            foreach(TableCell c in Cells)
            {
                if(c.Visible)
                    ret++;
            }

            return ret;
        }
    }
}