using System.IO;
using System.Text;
using System.Text.RegularExpressions;



namespace Cfi.SoftwareFactory.Common.HttpModules
{
    public class HyperLinkEncryptionFilter : Stream
    {
        private readonly StringBuilder html = new StringBuilder();
        private readonly string[] permittedLinksToEncrypt;
        private readonly string[] rejectedLinksNotToEncrypt;
        private readonly Stream responseStream;

        public HyperLinkEncryptionFilter(Stream inputStream)
        {
            //Setting the pages or type of pages which are required to be encrypted, seperated by ';'...
            permittedLinksToEncrypt = new[] {"aspx"};

            //Setting the pages or type of pages which are required not required to be encrypted, seperated by ';'...
            rejectedLinksNotToEncrypt = new[] {"axd", "ToolkitScript", "AjaxControlToolkit", ".js"};
            responseStream = inputStream;
        }

        public override bool CanRead { get { return true; } }

        public override bool CanSeek { get { return true; } }

        public override bool CanWrite { get { return true; } }

        public override long Length { get { return 0; } }

        public override long Position { get; set; }

        public override void Close() { responseStream.Close(); }

        public override void Flush() { responseStream.Flush(); }

        public override long Seek(long offset, SeekOrigin direction) { return responseStream.Seek(offset, direction); }

        public override void SetLength(long length) { responseStream.SetLength(length); }

        public override int Read(byte[] buffer, int offset, int count) { return responseStream.Read(buffer, offset, count); }

        public override void Write(byte[] buffer, int offset, int count)
        {
            // string version of the buffer
            string sBuffer = Encoding.UTF8.GetString(buffer, offset, count);

            // end of the HTML file
            Regex oEndFile = new Regex("</html>", RegexOptions.IgnoreCase);
            if(oEndFile.IsMatch(sBuffer))
            {
                // Append the last buffer of data
                html.Append(sBuffer);

                string tempResponse = html.ToString();

                //string newBuffer = Regex.Replace(tempResponse, "\t", string.Empty);
                //newBuffer = Regex.Replace(newBuffer, "\n", string.Empty);
                //newBuffer = Regex.Replace(newBuffer, "\r", string.Empty);
                //newBuffer = Regex.Replace(newBuffer, "<!--", "<!-- \n");
                //newBuffer = Regex.Replace(newBuffer, "// -->", "// --> \n");

                //tempResponse = newBuffer;

                //Implementing something to replace all the...
                byte[] data = Encoding.UTF8.GetBytes(EncryptHyperLinks(tempResponse));
                responseStream.Write(data, 0, data.Length);
            }
            else
                html.Append(sBuffer);
        }

        public string EncryptHyperLinks(string html)
        {
            //Full pattern is the next commented line...
            //string urlPattern = @"http(s)?://([\w-]+\.)+[\w-]+\?\w+=\w+(&\w+=\w+)*";
            const string urlPattern = @"([\w-]+\.)+[\w-]+\?\w+=[\w -]+((&|(&amp;))[\w - \.]+=[\w - \.]+)*";
            //string queryStringPattern = @"\?\w+=\w+(&\w+=\w+)*";
            Regex objRegex = new Regex(urlPattern);
            MatchCollection objCol = objRegex.Matches(html);
            foreach(Match m in objCol)
            {
                string url = m.Value;
                if(url != "")
                {
                    if(!IsStringInList(url, rejectedLinksNotToEncrypt) && IsStringInList(url, permittedLinksToEncrypt))
                    {
                        string path = url.Substring(0, url.IndexOf("?"));
                        string queryString = url.Replace(path, "");
                        path += QueryStringModule.Encrypt(queryString.Replace("&amp;", "&"));
                        html = html.Replace(url, path);
                    }
                }
            }
            return html;
        }

        /// <summary>
        /// Method to check if the url contains the items specified in the string array.
        /// </summary>
        /// <param name="url">The string to be tested for the list.</param>
        /// <param name="list">The list itself which containst the permitted or rejected values.</param>
        /// <returns>Boolean</returns>
        public bool IsStringInList(string url, string[] list)
        {
            foreach(object obj in list)
            {
                if(url.Contains(obj.ToString()))
                    return true;
            }
            return false;
        }
    }
}