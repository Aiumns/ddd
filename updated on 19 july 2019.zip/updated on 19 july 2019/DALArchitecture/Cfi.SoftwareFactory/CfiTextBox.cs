﻿/* CfiTextBox Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   Used to accept only special character depending upon the properties.
 * Created By           :   Sudhir Yadav.
 * Created On           :   28 Oct 2010.
 * Modified By          :   Chandra Prakash.
 * Modified On          :   08 Frb 2010.
 * Description          :   Added a CfiTextBoxTypes - NumericWithZero for adding a numeric value starting with 0.
 * Modified By          :   Sudhir Yadav.
 * Modified On          :   12 Mar 2010.
 * Description          :   Removed NumericWithZero.
 * Modified By          :   Chandra Prakash.
 * Modified On          :   22 Apr 2010.
 * Description          :   Removed ViewState from Properties.
 * Modified By          :   Sudhir Yadav.
 * Modified On          :   11 Jun 2010.
 * Description          :   Added ValidationMessage property to drive the validation summary written in jquery.validation.js for localization/globalization.
*/

#region Using Region
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web;
#endregion

/// <summary>
/// Summary description for CfiTextBox
/// </summary>

[assembly: TagPrefix("Cfi.SoftwareFactory.WebControls", "Cfi")]



namespace Cfi.SoftwareFactory.WebControls
{
    public class CfiTextBox : TextBox
    {
        /// <summary>
        /// Enum for setting the type of the current text box to use.
        /// </summary>
        public enum CfiTextBoxTypes
        {
            Default,
            Numeric,
            Alphabet,
            AlphaNumeric,
            AlphaNumericUpperCase,
            AlphabetUpperCase,
            DefaultUpperCase,
            NumericWithHyphen
        }

        public CfiTextBox()
        {
            this.PlacesOfDecimal = 2;
        }

        public string CurrencySymbol { get; set; }

        public bool AllowNegative { get; set; }

        public CfiTextBoxTypes CfiTextBoxType { get; set; }

        int placesOfDecimal;
        public int PlacesOfDecimal
        {
            get { return placesOfDecimal == null ? 0 : placesOfDecimal; }
            set { placesOfDecimal = value; }
        }

        /// <summary>
        /// Get or set the Text.
        /// </summary>
        public override string Text
        {
            get { return this.CfiTextBoxType.ToString().Contains("Upper") ? base.Text.ToUpper() : base.Text; }
            set { base.Text = value; }
        }

        protected override void OnPreRender(EventArgs e)
        {

            this.RegisterJavascriptCode();
            base.OnPreRender(e);
        }

        /// <summary>
        /// Method to register the javascript based on this.CfiTextBoxTypes.
        /// </summary>
        private void RegisterJavascriptCode()
        {
            // When pre-rendering, add in external JavaScript file for the update panel script manger...
            ScriptManager.RegisterClientScriptResource(this, GetType(), "Cfi.SoftwareFactory.Resources.Scripts.CfiTextBox.js");
            ScriptManager.RegisterClientScriptResource(this, GetType(), "Cfi.SoftwareFactory.Resources.Scripts.jquery.CfiTextBox.js");

            // Autocomplete...
            if (AutoCompleteType == AutoCompleteType.Disabled || AutoCompleteType == AutoCompleteType.None)
                Attributes.Add("autocomplete", "off");

            if (this.CfiTextBoxType == CfiTextBoxTypes.Numeric)
            {
                // AnyNumber, it also have the provision of controling the negative value entry...
                if (this.PlacesOfDecimal > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, GetType(), "Numeric" + this.ClientID, " $('#" + this.ClientID + "').numeric({ currentCulture: '" + System.Threading.Thread.CurrentThread.CurrentCulture + "' });", true);
                    Attributes.Add("onBlur", "FormatOnBlur(this," + this.PlacesOfDecimal + ");" + this.Attributes["onBlur"]);
                }
                else
                    ScriptManager.RegisterClientScriptBlock(this, GetType(), "Numeric" + this.ClientID, " $('#" + this.ClientID + "').numeric();", true);
            }
            else if (this.CfiTextBoxType == CfiTextBoxTypes.Alphabet)
                // Any alphabet, prevents anything else to be entered...
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "Alpha" + this.ClientID, " $('#" + this.ClientID + "').alpha({ allow: '  ' });", true);
            else if (this.CfiTextBoxType == CfiTextBoxTypes.AlphaNumeric)
                // Any alphabet or number, prevents anything else to be entered...
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "AlphaNumeric" + this.ClientID, " $('#" + this.ClientID + "').alphanumeric({ allow: '  ' });", true);
            else if (this.CfiTextBoxType == CfiTextBoxTypes.AlphaNumericUpperCase)
                // Any alphabet with Upper Case or number , prevents anything else to be entered...
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "AlphaNumeric" + this.ClientID, " $('#" + this.ClientID + "').alphanumeric({ allow: '  ' });", true);
            else if (this.CfiTextBoxType == CfiTextBoxTypes.AlphabetUpperCase)
                // Any alphabet or number, prevents anything else to be entered...
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "AlphaUpperCase" + this.ClientID, " $('#" + this.ClientID + "').alpha({ allow: '  ' });", true);
            else if (this.CfiTextBoxType == CfiTextBoxTypes.NumericWithHyphen)
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "NumericWithHyphen" + this.ClientID, " $('#" + this.ClientID + "').numeric({ allow: ' - ' });", true);

            // Keep user from entering more than maxLength characters
            if (MaxLength > 0)
            {
                Attributes.Add("onkeypress", "doKeypressforMaxLength(this," + MaxLength + ");");
                Attributes.Add("onbeforepaste", "doBeforePasteforMaxLength(this," + MaxLength + ");");
                Attributes.Add("onpaste", "doPasteforMaxLength(this," + MaxLength + ");");
            }

            if (this.CfiTextBoxType.ToString().Contains("Upper"))
                Style.Add("text-transform", "uppercase");

            // Script to stop pasting on the text box...
            //            if(this.CfiTextBoxType.ToString().Contains("Alpha") && !this.CfiTextBoxType.ToString().Contains("Default") || !AllowCutCopyPaste)
            //                ScriptManager.RegisterClientScriptBlock(this, GetType(), "AllowCutCopyPaste" + this.ClientID, @"$(function() {
            //                                                        $('#" + this.ClientID + @"').bind('cut copy paste', function(e) {
            //                                                                    e.preventDefault();
            //                                                                });
            //                                                        });", true);
        }


        int minLength;
        /// <summary>
        /// Get or set the minimum length of the text box.
        /// </summary>
        public int MinLength { get { return minLength == null ? 0 : minLength; } set { minLength = value; } }

        bool allowCutCopyPaste;
        /// <summary>
        /// Get or set weather pasting is allowed
        /// </summary>
        private bool AllowCutCopyPaste { get { return allowCutCopyPaste == null ? false : allowCutCopyPaste; } set { allowCutCopyPaste = value; } }

        public string ValidationMessage
        {
            set
            {
                this.Attributes.Add("ValidationMessage", (HttpContext.GetGlobalResourceObject("GlobalCSAndJSMsg", value) != null) ? HttpContext.GetGlobalResourceObject("GlobalCSAndJSMsg", value).ToString() : value);
            }
        }
    }
}