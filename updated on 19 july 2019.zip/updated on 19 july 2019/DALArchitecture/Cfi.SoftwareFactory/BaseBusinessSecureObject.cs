using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;



namespace Cfi.SoftwareFactory.BaseBusiness
{

    #region BaseBusinessSecureObject Description
    /*
*************************************************************************************************************
        Class Name          :   BaseBusinessSecureObject      
        Purpose             :   Base Class for Business Objects that provides common Business Functionality and Attributes.
        Company             :   CargoFlash Infotech 
        Author              :   Manish Kumar
        Created On          :   26 Sep 2009
        Approved By         :   Sudhir Yadav
        Approved On         :   30 Sep 2009
        Modified By         :   Sudhir Yadav
        Modified On         :   10 Nov 2009
*************************************************************************************************************
    */
    #endregion

    /// <summary>
    /// Base Class for Business Objects that provides common Business Functionality and Attributes. It must be inherited from the bussiness objects.
    /// </summary>
    public abstract class BaseBusinessSecureObject : IDisposable
    {
        #region Local Internal Variables
        //Local Internal Variables    
        protected SqlTransaction Transaction;
        protected Boolean TransactionEnabled;
        //***************************************************************************
        #endregion

        #region Variable Related Database Activity
        //Parent Table and Primary Field Name of the Parent Table
        protected string parentEntity = "";
        protected string parentKeyField = "";
        protected string parentKeyValue;
        #endregion

        #region Properties
        public string RecordID { get; set; }

        public string ConnectionString { get; set; }

        /// <summary>
        /// Get or Set RecordName
        /// </summary>
        public string RecordName { get; set; }

        /// <summary>
        /// Get or Set PageNo
        /// </summary>
        public string PageNo { get; set; }

        /// <summary>
        /// Get or Set PageSize
        /// </summary>
        public string PageSize { get; set; }

        /// <summary>
        /// Get or Set OrderBy
        /// </summary>
        public string OrderBy { get; set; }

        /// <summary>
        /// Get or Set NameSpacePrefix
        /// </summary>
        public string NameSpacePrefix { get; set; }

        /// <summary>
        /// Get or Set ErorMessage
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Get or Set LoginSNo
        /// </summary>
        public int LoginSNo { get; set; }
        /// <summary>
        /// Get or Set ErorNumber
        /// </summary>
        public int ErrorNumber { get; set; }

        /// <summary>
        /// Get or Set DateFormat
        /// </summary>
        public string DateFormat { get; set; }

        /// <summary>
        /// Get or Set UserID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// Get or Set ClientID
        /// </summary>
        public int ClientID { get; set; }

        /// <summary>
        ///Get or Set SQLNew
        /// </summary>
        public string SQLNew { get; set; }

        /// <summary>
        /// Get or Set SQLCreate
        /// </summary>
        public string SQLCreate { get; set; }

        /// <summary>
        /// Get or Set SQLEdit
        /// </summary>
        public string SQLEdit { get; set; }

        /// <summary>
        /// Get or Set SQLUpdate
        /// </summary>
        public string SQLUpdate { get; set; }

        /// <summary>
        /// Get or Set SQLList
        /// </summary>
        public string SQLList { get; set; }

        /// <summary>
        /// Get or Set Where Condition
        /// </summary>
        public string WhereCondition { get; set; }

        /// <summary>
        /// Get or Set Where Condition Fields for update
        /// </summary>
        public string WhereConditionField { get; set; }

        /// <summary>
        /// Get or Set UpdateFileToExclude
        /// </summary>
        public string UpdateFieldToExclude { get; set; }

        /// <summary>
        /// Get or Set PrimaryEntity
        /// </summary>
        public string PrimaryEntity { get; set; }

        /// <summary>
        /// Get or Set PrimaryKeyField
        /// </summary>
        public string PrimaryKeyField { get; set; }

        /// <summary>
        /// Get or Set PrimaryKeyValue
        /// </summary>
        public string PrimaryKeyValue { get; set; }

        /// <summary>
        /// Get or Set ChildEntity
        /// </summary>
        public string ChildEntity { get; set; }

        /// <summary>
        /// Get or Set ChildKeyValue
        /// </summary>
        public int ChildKeyValue { get; set; }

        /// <summary>
        /// Get or Set DefaultErorMessage
        /// </summary>
        public string DefaultErrorMessage { get; set; }

        /// <summary>
        /// Get or Set DefaultErorNumber
        /// </summary>
        public int DefaultErrorNumber { get; set; }

        /// <summary>
        /// Get or Set PrimaryKeyStringValue
        /// </summary>
        protected string PrimaryKeyStringValue { get; set; }

        /// <summary>
        /// Get or Set SequenceName
        /// </summary>
        public int SequenceName { get; set; }

        /// <summary>
        /// Get the total no of the pages which is calculated as per the search query specifications.
        /// </summary>
        public string TotalNoOfPages { get; set; }
        #endregion

        #region CheckBusinessRule
        /// <summary>
        /// This function is used to validate the business rule of the related data . 
        /// This function is overridable in Derived Class.
        /// </summary>    
        /// <returns>0 - (int)ResultType.Success,
        ///          1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        protected virtual int ValidateBusinessRule(DataTable dtCurrentRecord, DataOperation CurrentDataOperation) { return (int)ResultType.Success; }
        #endregion

        #region DoCreate
        /// <summary>
        /// This function is used to create new Record. 
        /// This function is overridable in Derived Class.
        /// </summary>    
        /// <returns>0 - (int)ResultType.Success,
        ///          1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public virtual int DoCreate(DataTable dtCurrentRecord) { return (int)ResultType.Success; }
        #endregion

        #region DoUpdate
        /// <summary>
        /// This function is used to Update Existing Record. 
        /// This function is overridable in Derived Class.       
        /// </summary>    
        /// <returns>0 - (int)ResultType.Success,
        ///          1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public virtual int DoUpdate(DataTable dtCurrentRecord) { return (int)ResultType.Success; }
        #endregion

        #region DoDelete
        /// <summary>
        /// This function is used to Delete Existing Record. 
        /// This function is overridable in Derived Class.      
        /// </summary>    
        /// <returns>0 - (int)ResultType.Success,
        ///          1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public virtual int DoDelete(string primaryKeyValue) { return (int)ResultType.Success; }

        /// <summary>
        /// This function is used to Delete Existing Record. 
        /// This function is overridable in Derived Class.      
        /// </summary>    
        /// <returns>0 - (int)ResultType.Success,
        ///          1 - (int)ResultType.Failed, Due to Business rule invalidation or internal error .</returns> 
        public virtual int DoDelete(int primaryKeyValue) { return (int)ResultType.Success; }
        #endregion

        #region DoRead
        /// <summary>
        /// This function is used to Read Existing Record. 
        /// This function is overridable in Derived Class.    
        /// </summary>    
        /// <returns>Table containing all the matching records</returns> 
        public virtual DataTable DoRead(int primaryKeyValue) { return null; }
        #endregion

        #region DoRead
        /// <summary>
        /// This function is used to Read Existing Record. 
        /// This function is overridable in Derived Class.    
        /// </summary>    
        /// <returns>Table containing all the matching records</returns> 
        public virtual DataTable DoRead(string primaryKeyValue) { return null; }
        #endregion

        #region GetList Overloaded
        /// <summary>
        /// This function is used to get all Existing Record. 
        /// This function is overridable in Derived Class.      
        /// </summary>    
        /// <returns>SQLTable table containing all the records</returns> 
        public DataTable GetList(string entityName, string resultFields, string whereCondition)
        {
            //Create a new instance of SystemStoredProcedure
            using(StoredProcedure storedProcedure = new StoredProcedure())
            {
                try
                {
                    DataTable dt = storedProcedure.GetList(entityName, resultFields, whereCondition);
                    if(storedProcedure.ErrorNumber > 0)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = "GetLocalResourceObject:" + ErrorNumber;
                        return null;
                    }
                    return dt;
                }
                catch(Exception)
                {
                    ErrorNumber = storedProcedure.ErrorNumber;
                    ErrorMessage = "GetLocalResourceObject:" + ErrorNumber;
                    return null;
                }
            }
        }
        #endregion


        #region GetList
        /// <summary>
        /// This function is used to get data from the related the data table.
        /// When error occurs check BaseBusinessSecureObject.ErrorNo and BaseBusinessSecureObject.errorDescription for actual error. 
        /// </summary>      
        /// <returns>Its return the dataTable.</returns>
        public DataTable GetList()
        {
            /*
            *************************************************************************************
            Class Name:      BaseBusinessSecureObject  
            Purpose:         This function is used to get data from the related the data table.
            Company:         CargoFlash InfoTech. 
            Author:          Manish Kumar
            Created On:      26 Sep, 2009
            *************************************************************************************
            */
            //Set Local dt object.
            DataSet dt = null;
            try
            {
                SqlParameter[] Parameters = {new SqlParameter("@PageNo", PageNo ?? "1"), new SqlParameter("@PageSize", PageSize ?? "10"), new SqlParameter("@TotalNoOfPages", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 10}, new SqlParameter("@WhereCondition", WhereCondition ?? ""), new SqlParameter("@OrderBy", OrderBy ?? ""), new SqlParameter("@ErrorNumber", SqlDbType.Int) {Direction = ParameterDirection.Output}, new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250}};

                dt = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, NameSpacePrefix + "GetList", Parameters);

                if(int.Parse(Parameters[5].Value.ToString()) > 0)
                {
                    ErrorNumber = int.Parse(Parameters[5].Value.ToString());
                    ErrorMessage = Parameters[6].Value.ToString();
                    return null;
                }
                else
                {
                    TotalNoOfPages = Parameters[2].Value.ToString();
                    return dt.Tables[0];
                }
            }
            catch(Exception)
            {
                string errorDescription = "BaseBusinessSecureObject.GetList():Internal Error! Could not execute " + NameSpacePrefix + "GetList";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return null;
            }
            finally
            {
                if(dt != null)
                    dt.Dispose();
            }
        }
        #endregion

        #region GetRecord
        /// <summary>
        /// This function is used to get one record ata time from the related the data table.
        /// When error occurs check BaseBusinessSecureObject.ErrorNo and BaseBusinessSecureObject.errorDescription for actual error. 
        /// </summary>      
        /// <returns>Its return the dataTable.</returns>
        public DataTable GetRecord()
        {
            /*
            *************************************************************************************
            Class Name:      BaseBusinessSecureObject  
            Purpose:         This function is used to get one record at a time from the related the data table.
            Company:         CargoFlash InfoTech. 
            Author:          Manish Kumar
            Created On:      26 Sep, 2009
            *************************************************************************************
            */
            //Set Local dt object.
            DataSet dt = null;
            try
            {
                SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250};

                SqlParameter[] Parameters = {new SqlParameter("@RecordID", RecordID), errorNumber, ValidationMessage};

                dt = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, NameSpacePrefix + "GetRecord", Parameters);

                if(int.Parse(Parameters[1].Value.ToString()) > 0)
                {
                    ErrorMessage = "GetLocalResourceObject:RecordNotFound";
                    ErrorNumber = 1;
                    return null;
                }
                else
                    return dt.Tables[0];
            }
            catch(Exception)
            {
                string errorDescription = "BaseBusinessSecureObject.GetRecord():Internal Error! Could not execute " + NameSpacePrefix + "GetRecord";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return null;
            }
            finally
            {
                if(dt != null)
                    dt.Dispose();
            }
        }
        #endregion

        #region GetNew
        /// <summary>
        /// This function is used to get New blank table structure from the data base.
        /// When error occurs check BaseBusinessSecureObject.ErrorNo and BaseBusinessSecureObject.errorDescription for actual error. 
        /// </summary>      
        /// <returns>Its return the dataTable.</returns>
        public DataTable GetNew()
        {
            /*
            *************************************************************************************
            Class Name:      BaseBusinessSecureObject  
            Purpose:         This function is used to get New blank table structure from the data base.
            Company:         CargoFlash InfoTech. 
            Author:          Manish Kumar
            Created On:      26 Sep, 2009
            *************************************************************************************
            */
            DataSet dt = null;
            try
            {
                SqlParameter errorNumber = new SqlParameter("@ErrorNumber", SqlDbType.Int) {Direction = ParameterDirection.Output};

                SqlParameter ValidationMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar) {Direction = ParameterDirection.Output, Size = 250};

                SqlParameter[] Parameters = {new SqlParameter("@EntityName", PrimaryEntity), errorNumber, ValidationMessage};

                dt = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "SysGetNew", Parameters);

                if(int.Parse(Parameters[1].Value.ToString()) > 0)
                {
                    ErrorNumber = int.Parse(Parameters[1].Value.ToString());
                    ErrorMessage = Parameters[2].Value.ToString();
                    return null;
                }
                else
                {
                    DataRow dr = dt.Tables[0].NewRow();
                    dt.Tables[0].Rows.Add(dr);
                    return dt.Tables[0];
                }
            }
            catch(Exception ex)
            {
                const string errorDescription = "BaseBusinessSecureObject.GetNew():Internal Error! Could not execute SysGetNew";
                ErrorMessage = errorDescription;
                ErrorNumber = 999;
                return null;
            }
            finally
            {
                if(dt != null)
                    dt.Dispose();
            }
        }
        #endregion

        #region DisposeMethod
        /// <summary>
        /// Dispose the all objects of StoredProcedure class.  
        /// </summary>
        public virtual void Dispose() { GC.SuppressFinalize(this); }
        #endregion

        #region GetErrorMessage
        /// <summary>
        /// This Method used for get Error Message and error number
        /// from Database and set into related property variables.
        /// </summary>
        /// <param name="currentErrorDescription"></param>
        public void GetErrorMessage(string currentErrorDescription)
        {
            //Create a new instance of StoreProcedure
            using(StoredProcedure storedProcedure = new StoredProcedure())
            {
                try
                {
                    //Call GetError API to get the error message.
                    storedProcedure.SysGetError(currentErrorDescription);
                    ErrorNumber = storedProcedure.ErrorNumber;
                    ErrorMessage = storedProcedure.ErrorMessage;

                    //Check Error message for null or blank,If null or Blank then reflect default error message and error number
                    if(string.IsNullOrEmpty(ErrorMessage))
                    {
                        ErrorMessage = DefaultErrorMessage;
                        ErrorNumber = 61502;
                    }
                }
                catch(Exception)
                {
                    //Set the storedProcedure error number from the database.
                    ErrorNumber = storedProcedure.ErrorNumber;
                    ErrorMessage = storedProcedure.ErrorMessage;
                }
            }
        }
        #endregion

        public DataTable GetRequestKeyCollection(DataTable dt, UserControl currentcontrol)
        {
            //Table is already loaded with Control names now loop all control and get the value
            //from Request Form collection
            for(int i = 0; i < dt.Columns.Count; i++)
            {
                try
                {
                    WebControl webControl = (WebControl)CommonFunctions.FindControlRecursive(currentcontrol, dt.Columns[i].ToString().Trim());
                    if(webControl != null)
                    {
                        string collectionName = webControl.ClientID.Replace("_", "$");
                        string controlValue = HttpContext.Current.Request.Form[collectionName].Trim();
                        if(string.IsNullOrEmpty(controlValue.Trim()))
                        {
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = DBNull.Value;
                            continue;
                        }

                        if(dt.Columns[i].DataType.ToString() == "System.Decimal")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToDecimal(controlValue.Trim());
                        else if(dt.Columns[i].DataType.ToString() == "System.int")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToInt32(controlValue.Trim());
                        else if(dt.Columns[i].DataType.ToString().Trim() == "System.SByte")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToSByte(controlValue.Trim());
                        else if(dt.Columns[i].DataType.ToString().Trim() == "System.Int64")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToInt64(controlValue.Trim());
                        else
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = controlValue.Trim();
                    }
                }
                catch(Exception)
                {
                    continue;
                }
            }
            return dt;
        } //End of method.

        public DataTable GetRequestKeyCollection(DataTable dt, Page currentPage)
        {
            //Table is already loaded with Control names now loop all control and get the value
            //from Request Form collection
            for(int i = 0; i < dt.Columns.Count; i++)
            {
                try
                {
                    WebControl webControl = (WebControl)CommonFunctions.FindControlRecursive(currentPage.Master, dt.Columns[i].ToString().Trim());
                    if(webControl != null)
                    {
                        string collectionName = webControl.ClientID.Replace("_", "$");
                        string controlValue = currentPage.Request.Form[collectionName].Trim();
                        if(string.IsNullOrEmpty(controlValue.Trim()))
                        {
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = DBNull.Value;
                            continue;
                        }

                        if(dt.Columns[i].DataType.ToString() == "System.Decimal")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToDecimal(controlValue.Trim());
                        else if(dt.Columns[i].DataType.ToString() == "System.int")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToInt32(controlValue.Trim());
                        else if(dt.Columns[i].DataType.ToString().Trim() == "System.SByte")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToSByte(controlValue.Trim());
                        else if(dt.Columns[i].DataType.ToString().Trim() == "System.Int64")
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = Convert.ToInt64(controlValue.Trim());
                        else
                            dt.Rows[0][dt.Columns[i].ToString().Trim()] = controlValue.Trim();
                    }
                }
                catch(Exception)
                {
                    continue;
                }
            }
            return dt;
        }

        #region GetArrayList Overloaded
        /// <summary>
        /// This function is used to get all Existing Record. 
        /// This function is overridable in Derived Class.      
        /// </summary>    
        /// <returns>SQLTable table containing all the records</returns> 
        public string GetArrayList(string entityName, string resultFields, string whereCondition)
        {
            //Create a new instance of SystemStoredProcedure
            using(StoredProcedure storedProcedure = new StoredProcedure())
            {
                try
                {
                    string ArrayList = storedProcedure.SysGetListArray(entityName, resultFields, whereCondition);
                    if(storedProcedure.ErrorNumber > 0)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = storedProcedure.ErrorMessage;
                        return "";
                    }
                    return ArrayList;
                }
                catch(Exception)
                {
                    ErrorNumber = storedProcedure.ErrorNumber;
                    ErrorMessage = storedProcedure.ErrorMessage;
                    return "";
                }
            }
        }
        #endregion

        /// <summary>
        /// This method used to return no of records, if given condition is match otherwise return 0.
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="resultFields"></param>
        /// <param name="whereCondition"></param>
        /// <returns>return 0 for not match or no of records if found.</returns>
        public int GetRecordCount(string entityName, string resultFields, string whereCondition)
        {
            //Create a new instance of SystemStoredProcedure
            using (StoredProcedure storedProcedure = new StoredProcedure())
            {
                try
                {
                    int count = storedProcedure.Sys_GetRecordCount(entityName, resultFields, whereCondition);
                    if (storedProcedure.ErrorNumber > 0)
                    {
                        ErrorNumber = storedProcedure.ErrorNumber;
                        ErrorMessage = storedProcedure.ErrorMessage;
                        return 0;
                    }
                    return count;
                }
                catch (Exception)
                {
                    ErrorNumber = storedProcedure.ErrorNumber;
                    ErrorMessage = storedProcedure.ErrorMessage;
                    return 0;
                }
            }
        }

        //End of method.
    } //End of Class.
}