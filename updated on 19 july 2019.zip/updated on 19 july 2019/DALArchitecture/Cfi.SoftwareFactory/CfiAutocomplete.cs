﻿
/* CfiAutocomplete Class Description.
 * Company              :   CargoFlash Infotech	Pvt. Ltd.
 * Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
 * Purpose              :   Used to display generic autocomplete help.
 * Created By           :   Dhiraj Kumar.
 * Created On           :   07 June 2010.
 
*/

using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cfi.SoftwareFactory.Common;

/// <summary>
/// Summary description for CfiAutocomplete
/// </summary>

[assembly: TagPrefix("Cfi.SoftwareFactory.WebControls", "Cfi")]



namespace Cfi.SoftwareFactory.WebControls
{
    public class CfiAutocomplete :CfiTextBox
    {
        /// <summary>
        /// Enum for setting the type of the current text box to use.
        /// </summary>
        public enum CfiTextBoxTypes
        {
            Default,
            Alphabet,
            AlphaNumeric,
            AlphaNumericUpperCase,
            AlphabetUpperCase,
            DefaultUpperCase
        }

        public CfiAutocomplete()
        {
            MultiSelectMode = false;
            FieldSeperaterChar = ",";
         
        }
        private string  separatorChar = ",";
        public  string FieldSeperaterChar
        {
            get { return separatorChar; }
            set { separatorChar =value; } 
        }

      
        /// <summary>
        /// Get and set id field of autocomplete
        /// </summary>
        private string idField = "";
        public string IDField { get { return idField == null ? "" : idField; } set { idField = value; } }

        /// <summary>
        /// Get and set label field of autocomplete
        /// </summary>
       private string labelField = "";
        public string LabelField { get { return labelField == null ? "" : labelField; } set { labelField = value; } }

        /// <summary>
        ///Get and set ExtraFunction on autocompelte select    
        /// </summary>
       private string onSelect = "";
        public string AfterSelect { get { return onSelect == null ? "" : onSelect; } set { onSelect = value; } }

        /// <summary>
        ///    Get and set value field of autocomplete  
        ///  </summary>
       private string valueField = "";
        public string ValueField { get { return valueField == null ? "" : valueField; } set { valueField = value; } }

        /// <summary>
        /// Get and set entity name, of which autocomplete help has to display
        /// </summary>
       private string entity = "";
        public string Entity { get { return entity == null ? "" : entity; } set { entity = value; } }

        /// <summary>
        /// Get and set value field of autocomplete
        /// </summary>
      private  string getValue = "";
        public string ValueFieldControlID { get { return getValue == null ? "" : getValue; } set { getValue = value; } }

        /// <summary>
        /// Get and set value field of autocomplete
        /// </summary>
      private  string getID = "";
        public string IDFieldControlID { get { return getID == null ? "" : getID; } set { getID = value; } }

        public CfiTextBoxTypes CfiTextBoxType { get; set; }

        /// <summary>
        /// Get or set the Text.
        /// </summary>
        public override string Text
        {
            get { return this.CfiTextBoxType.ToString().Contains("Upper") ? base.Text.ToUpper() : base.Text; }
            set { base.Text = value; }
        }

     
        /// <summary>
        /// Get or set the Mutiple Mode Selection true.
        /// </summary>
        private bool mutiSelectMode = false;
        public bool MultiSelectMode { get { return mutiSelectMode; } set { mutiSelectMode = value; } }

        private string conditionWhere = "";
        public string ConditionWhere { get { return conditionWhere == null ? "" : conditionWhere; } set { conditionWhere = value; } }

          
        protected override void OnPreRender(EventArgs e)
        {

            this.RegisterJavascriptCode();
            base.OnPreRender(e);
        }

        /// <summary>
        /// Method to register the javascript based on this.CfiTextBoxTypes.
        /// </summary>
        private void RegisterJavascriptCode()
        {
            try
            {
                HiddenField hdnValue = null;
                HiddenField hdnIDValue = null;
                if (!string.IsNullOrEmpty(ValueFieldControlID))
                    hdnValue = (HiddenField)CommonFunctions.FindControlRecursive(Page, ValueFieldControlID);
                if (!string.IsNullOrEmpty(IDFieldControlID))
                    hdnIDValue = (HiddenField)CommonFunctions.FindControlRecursive(Page, IDFieldControlID);
                StringBuilder setJavaScriptcode  =new StringBuilder();
                if (hdnValue != null)
                    setJavaScriptcode.Append("if($('#" + hdnValue.ClientID + @"').val()!=''){$('#" + hdnValue.ClientID + @"').val($('#" + hdnValue.ClientID + @"').val()+','+ui.item.value);}else{$('#" + hdnValue.ClientID + @"').val(ui.item.value);};");
                if (hdnIDValue != null)
                    setJavaScriptcode.Append("if($('#" + hdnIDValue.ClientID + @"').val()!=''){$('#" + hdnIDValue.ClientID + @"').val($('#" + hdnIDValue.ClientID + @"').val()+','+ui.item.id);}else{$('#" + hdnIDValue.ClientID + @"').val(ui.item.id);}");
                ScriptManager.RegisterClientScriptResource(this, GetType(), "Cfi.SoftwareFactory.Resources.Scripts.CfiAutocomplete.js");
                string handlerFile = GenericAutocompleteHandler.genericAutocompleteHandler;
                ScriptManager.RegisterClientScriptBlock(this, GetType(), "GenericAutocomplete"+this.ClientID,
                             @"$(document).ready(function () {
                            function split(val) {
			                        return val.split(/,\s*/);
	                            	}
		                    function extractLast(term) {
			                    return split(term).pop();
		                    }
                   
                        var cache = {}; $('#" + this.ClientID + @"').autocomplete({
                            source: function (request, response) {
                          var exTerm="+(MultiSelectMode==true?"extractLast(request.term)":"request.term")+@" ;
                                if (cache.term == exTerm && cache.content) {
                                    response(cache.content);
                                    return;
                                }
                if (new RegExp(cache.term).test(exTerm) && cache.content ) {
                    response($.ui.autocomplete.filter(cache.content, exTerm));
                    return;
                }
                $.ajax({
                    url: '" + handlerFile + @"',
                    dataType: 'json',
                    cache: false,
                    data: 'Entity=" + Entity + "&LabelField=" + LabelField + "&ValueField=" +
                                                        ValueField + "&IdField=" + IDField + "&FieldSeparatorChar=" +
                                                        FieldSeperaterChar +
                                                         "&ConditionWhere=" +
                                                        ConditionWhere +
                                                        "&WhereCondition='+exTerm" +
                                                        @",
                    success: function (data) {
                        cache.term =exTerm;
                        cache.content = data;
                        response(data);
                    }
                });
            },
            minLength: 1,
search: function() {
				// custom minLength
				var term = extractLast(this.value);
				if (term.length < 1) {
					return false;
				}
			},
focus: function() {
				// prevent value inserted on focus
				return false;
			},
 close: function(event, ui) {},
 select: function(event, ui) {
				var terms = split( this.value );
				// remove the current input
				terms.pop();
				// add the selected item
				terms.push( ui.item.value );
                
           	// add placeholder to get the comma-and-space at the end
				" + (MultiSelectMode == true ? @"terms.push(''); 
				this.value = terms.join(',');" : "this.value = terms.join();") + setJavaScriptcode + AfterSelect + @"
				return false;
			}
        });

    });", true);

            }
            catch
            {
            }
        }




    }
}