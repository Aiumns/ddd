﻿using System;
using System.Collections.Generic;
using System.Text;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;
using System.Data;
using System.Data.SqlClient;
namespace Cfi.App.Pace.Business
{
   public class BMgmt:IMgmt
   {
       #region variable
       Int64 _HoSno;
       Int64 _CompBrSno;
       DateTime _Date;
       String _CompanyName;
       Int64 _CHASno;
       String _CHAChargeStatus;
       #endregion

       #region property
       public String CHAChargeStatus
       {
           get { return _CHAChargeStatus; }
           set { _CHAChargeStatus = value; }
       }
       public Int64 CHASno
       {
           get { return _CHASno; }
           set { _CHASno = value; }
       }
       public Int64 HoSno
       {
           get { return _HoSno; }
           set { _HoSno = value; }
       }
       public Int64 CompBrSno
       {
           get { return _CompBrSno; }
           set { _CompBrSno = value; }
       }
       public DateTime Date
       {
           get { return _Date; }
           set { _Date = value; }
       }
       public String CompanyName
       {
           get { return _CompanyName; }
           set { _CompanyName = value; }
       }
       #endregion

       public BMgmt()
       { }
       public DataSet CompanyHo_Select()
       {
           return DMgmt.CompanyHO_Select();
       }
       public DataSet BranchOffice_Select()
       {
           return DMgmt.BranchOffice_Select(this);
       }
       public DataSet MgmtRecord_Select()
       {
           return DMgmt.MgmtRecord_Select(this);
       }
       public int NoBookingCount()
       {
           return DMgmt.NoBookingSelect(this);
       }
       public int NoOfCHAFiledCount()
       {
           return DMgmt.NoOfCHAFiledSelect(this);
       }
       public int CountCHAChargeStatus()
       {
           return DMgmt.CountCHAChargeStatus(this);
       }
       #region "DashBoard"
       public DataSet GetDashBoardCount()
       {
           return DMgmt.GetDashBoardCount(this);
       }
       public DataSet getPendingRFB()
       {
           return DMgmt.getPendingRFB(this);
       }
       public DataSet GetExportOpenJobDetails()
       {
           return DMgmt.GetExportOpenJobDetails(this);
       }
       public DataSet GetExportInvoicedJobDetails()
       {
           return DMgmt.GetExportInvoicedJobDetails(this);
       }
       public DataSet GetSeaInvDetail()
       {
           return DMgmt.GetSeaInvDetail(this);
       }
       public DataSet GetExportOutstandingBillsDetails()
       {
           return DMgmt.GetExportOutstandingBillsDetails(this);
       }
       public DataSet GetExportCHAShippBillsDetails()
       {
           return DMgmt.GetExportCHAShippBillsDetails(this);
       }
       public DataSet getCrLimExpired()
       {
           return DMgmt.getCrLimExpired(this);
       }
       public DataSet GetExportCHAShippBillsChildDetails(int intSno)
       {
           return DMgmt.GetExportCHAShippBillsChildDetails(intSno);
       }
       public DataSet GetImportOpenJobsDetails()
       {
           return DMgmt.GetImportOpenJobsDetails(this);
       }
       public DataSet GetImportHAWBDetails()
       {
           return DMgmt.GetImportHAWBDetails(this);
       }
       public DataSet GetImportMAWBDetails()
       {
           return DMgmt.GetImportMAWBDetails(this);
       }
       public DataSet GetExportMAWBDetails()
       {
           return DMgmt.GetExportMAWBDetails(this);
       }
       public DataSet GetExportHAWBDetails()
       {
           return DMgmt.GetExportHAWBDetails(this);
       }
       public DataSet GetSeaHblDetails()
       {
           return DMgmt.GetSeaHblDetails(this);
       }
       public DataSet GetImportCANDetails()
       {
           return DMgmt.GetImportCANDetails(this);
       }
       public DataSet GetGoodsDet()
       {
           return DMgmt.GetGoodsDet(this);
       }
       public DataSet GetImportPODDetails()
       {
           return DMgmt.GetImportPODDetails(this);
       }
       public DataSet GetCHAChargeDetails()
       {
           return DMgmt.GetCHAChargeDetails(this);
       }
       public DataSet GetPaymentRecDetails()
       {
           return DMgmt.GetPaymentRecDetails(this);
       }
       public DataSet GetPaymentMadeDetails()
       {
           return DMgmt.GetPaymentMadeDetails(this);
       }
       public DataSet GetPendingWriteOffDetails(string LoginId)
       {
           return DMgmt.GetPendingWriteOffDetails(this,LoginId);
       }
       public DataSet GetNewCustomerDetails()
       {
           return DMgmt.GetNewCustomerDetails(this);
       }
       public DataSet GetRFQRejectedDetails()
       {
           return DMgmt.GetRFQRejectedDetails(this);
       }
       public DataSet MgmtRecord_RFQPending()
       {
           return DMgmt.MgmtRecord_RFQPending(this);
       }
       public DataSet MgmtRecord_PendingDeal()
       {
           return DMgmt.MgmtRecord_PendingDeal(this);
       }
       public DataSet GetRFQConfirmedDetails()
       {
           return DMgmt.GetRFQConfirmedDetails(this);
       } 

       public DataSet GetRFQNewDetails()
       {
           return DMgmt.GetRFQNewDetails(this);
       }
       public DataSet GetBlockCustomerDetails()
       {
           return DMgmt.GetBlockCustomerDetails(this);
       }
       public DataSet GetChecqueBounceDetails()
       {
           return DMgmt.GetChecqueBounceDetails(this);
       }
       public DataSet GetImportOutstandingBillsDetails()
       {
           return DMgmt.GetImportOutstandingBillsDetails(this);
       }
       public DataSet GetAssignedCompany(string strUser)
       {
           return DMgmt.GetAssignedCompany(strUser);
       }
       public DataSet getCompVariables()
       {
           return DMgmt.getCompVariables(this);
       }
       public DataSet GetOnlineUsers(DateTime date)
       {
           return DMgmt.GetOnlineUsers(date);
       }
       #endregion 
   }
}
