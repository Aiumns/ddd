using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;


namespace Cfi.App.Pace.Business
{
    public class BAgentMaster : IAgent
    {
        private String _ApprovalType;
        private String _RequestedBy;
        private String _Flagmainbranch;
        //private String _Address;
        private String _CityCode;
        private String _AccountsRemarks;
        private String _LoginId;
        private Int32 _SNo;
        private String _Flaggroup;
        private String _ModifiedBy;
        private DateTime _ModifiedDate;
        private String _Active;
        private String _Phone;
        private String _CustomerLoginId;
        private String _Address;
        private String _CustCareCity;
        private String _Website;
        private String _Email;
        private String _Fax;
        private String _Password;
        private String _Adcode;
        private String _IECNo;
        private String _AgentName;
        private String _BankAccNo;
        private String _CLApprovedBy;
        private DateTime _CLApprovedAt;
        private DateTime _CreditReviewDate;
        private Decimal _StandardDeal;
        private String _DeliveryStatus;
        private String _ContactName;
        private String _ContactDesign;
        private String _ContactDept;
        private String _ContactAdd;
        private String _ContactPhone;
        private String _ContactMobile;
        private String _ContactEmail;
        private DateTime _DOB;
        private DateTime _DOA; //
        private String _AgentCode;
        private String _PaymentMode;
        private String _CustomerName;
        private String _AgentType;
        private String _GSASNo;
        private Decimal _CreditLimit;
        private String _ApprovalCode;
        private String _IATANo;
        private String _PANNo;
        private Decimal _TDSRate;
        private Decimal _SurchargeRate;
        private Decimal _ExemptionLimit;
        private DateTime _EffectiveDate;
        private String _City;
        private String _PlanName;
        private Decimal _StandardDiscount;
        private Decimal _MaxLimit;
        private String _PrintBy;
        private Decimal _BankGuarantee;
        private String _MTD;
        private String _MobileNo;
        private String _AutoStock;
        private DateTime _EnteredDate;
        private String _EnteredBY;
        private Int32 _CustomerSNo;
        private String _BillingCycle;
        private String _CustomerType;
        private DateTime _ValidFrom;
        private DateTime _ValidTo;
        private String _FlagCustType;
        private Decimal _Amount;
        private DateTime _Date;
        private String _BankName;
        private String _BankAdd;
        private String _EnteredByBank;
        private String _Currency;
        private String _BalSheet2Years1;
        private String _BalSheet2YearsDesc;
        private String _BankConfirmLetter;
        private String _BankConfirmLetterDesc;
        private String _MarketReport;
        private String _MarketReportDesc;
        private String _MRApprovedByName;
        private Int32 _CreditPeriod;
        private Decimal _RateOfInterest;
        private DateTime _BGDate;
        private DateTime _BGClaimPeriod;
        private DateTime _EnteredAt;
        private String _StreetName;
        private String _Town;
        private String _State;
        private String _PinCode;
        private Decimal _GroupCreditLimit;
        private String _NetworkGroupSno;
        private String _NetworkGroupPriority;
        private Int32 _StarRating;
        private String _CountryCode;
        private String _Place;
        private Int32 _CompSno;
        private Int32 _CompBrSno;
        private String _loginFlag;
        private Int32 _loginSno;
        private Int32 _NetworkAgentCitySno;
        private Int32 _InvoiceCreditPeriod;

        private String _LoginPassword;
        private String _LoginCompSNo;
        private String _LoginDisplayName;
        private String _LoginEmailID;
        private String _AdCode;
        private String _Bill;
        private String _CustomerCareCity;
        private String _EnteredBy;
        private String _hdnCustType;
        private String _IataNo;
        private String _IsOscCalCulatedPace;
        private String _Mobile;
        private String _PanNo;
        private String _PhoneNo;
        private String _Street;
        private Int32 _CustBrSno;
        private Int32 _custMastSno;
        private Int32 _CustomerBusinessTypeSno;
        private Int32 _NetWorkAgentCitySno;
        private Int32 _SalesPersonSno;
        private Int32 _flag;
        private String _entryType;
        private bool _isOscCal;
        private Int32 _BrSno;
        private decimal _CreditLimitPace;

        //private decimal _CreditLimit;
        private decimal _UsedLimit;
        private decimal _AvailableLimit;
        //private int _CreditPeriod;
        //private DateTime _CreditReviewDate;
        private decimal _BGAmount;
        //private DateTime _BGDate;
        //private String _BankName;
        private String _BankAddress;
        private String _ApplicantName;
        private String _LegalStatus;
        private String _ROCRegnNo;
        private String _SalesPersonName;
        private String _IndustryType;
        private String _CustomerPremises;
        private String _PartnerName1;
        private String _PartnerAddress1;
        private String _OtherTradeName1;
        private String _PartnerName2;
        private String _PartnerAddress2;
        private String _OtherTradeName2;
        private String _PartnerName3;
        private String _PartnerAddress3;
        private String _OtherTradeName3;
        private decimal _AnnualSales;
        private int _NoOfEmployee;
        private String _LargestCustomerName1;
        private String _LargestCustomerName2;
        private int _OrgBusinessYear;
        private String _OthBisPremiseLocation1;
        private String _OthBisPremiseType1;
        private String _OthBisPremiseFacility1;
        private String _OthBisPremiseLocation2;
        private String _OthBisPremiseType2;
        private String _OthBisPremiseFacility2;
        private String _OthBisPremiseLocation3;
        private String _OthBisPremiseType3;
        private String _OthBisPremiseFacility3;
        private String _OthBisPremiseLocation4;
        private String _OthBisPremiseType4;
        private String _OthBisPremiseFacility4;
        private String _OthBisPremiseLocation5;
        private String _OthBisPremiseType5;
        private String _OthBisPremiseFacility5;
        private String _OthBisPremiseLocation6;
        private String _OthBisPremiseType6;
        private String _OthBisPremiseFacility6;
        private String _OthForwarder1;
        private decimal _OutstandingAmt1;
        private String _OthForwarder2;
        private decimal _OutstandingAmt2;
        private String _OthForwarder3;
        private decimal _OutstandingAmt3;
        private String _OthForwarder4;
        private decimal _OutstandingAmt4;
        private String _OthForwarder5;
        private decimal _OutstandingAmt5;
        private String _OthForwarder6;
        private decimal _OutstandingAmt6;
        private decimal _MonthlyBilling;
        private decimal _MonthlyVolume;
        private decimal _CreditLimitReq;
        private int _CreditPeriReq;
        private String _Status;
        private String _ApprovedBy;
        private DateTime _ApprovedAt;
        private String _CustomerRemarks;
        private String _ServiceTaxNo;
        private String _TanNo;
        private String _TinNo;
        private String _GroupCustomer;
        private String _bill;

        public BAgentMaster()
        {
        }

        public Boolean Checkcity()
        {
            SqlDataReader dr = DataAgentMaster.CheckdCity(this);
            if (dr.Read())
                return true;
            else
                return false;
        }

        public void EditAgent(Int32 strA)
        {
            SqlDataReader dr = DataAgentMaster.SearchAgent(strA);
            if (dr.Read())
            {
                _City = dr["City"].ToString();

                _CustomerType = dr["CustomerType"].ToString();
                _CustomerName = dr["CustomerName"].ToString();
                _Active = dr["Active"].ToString();
                //    _AgentType = dr["AgentType"].ToString();
                //    _MobileNo = dr["MobileNo"].ToString() == "" ? "" : dr["MobileNo"].ToString();
                //_CreditLimit = decimal.Parse(dr["CreditLimit"].ToString() == "" ? "0" : dr["CreditLimit"].ToString());
                //    _PrintBy = dr["PrintBy"].ToString();
                //    _IATANo = dr["IATANo"].ToString();
                //    _BankGuarantee = decimal.Parse(dr["BankGuarantee"].ToString() == "" ? "0" : dr["BankGuarantee"].ToString());
                //    _ApprovalCode = (dr["ApprovalCode"].ToString() == "" ? "" : dr["ApprovalCode"].ToString());
                //    _PlanName = dr["PlanName"].ToString();

                //    _PANNo = dr["PANNo"].ToString() == "" ? "" : dr["PANNo"].ToString();

                //    _PrintBy = dr["PrintBy"].ToString();

                //    _StandardDiscount = decimal.Parse(dr["StandardDiscount"].ToString() == "" ? "0" : dr["StandardDiscount"].ToString());
                //    _AutoStock = dr["autostock"].ToString();
                //    _PaymentMode = dr["PaymentMode"].ToString();
                if (dr["flag"].ToString() == "Y")
                {
                    _CustomerLoginId = dr["LoginId"].ToString();
                    _Password = dr["Pass"].ToString();
                }


                _StreetName = dr["Street"].ToString();
                _State = dr["State"].ToString();
                _PinCode = dr["PostCode"].ToString();
                _CountryCode = dr["CountryCode"].ToString();
                _SalesPersonName = dr["SalesPersonSno"].ToString();
                _CustCareCity = dr["CustCareCity"].ToString();
                _Website = dr["Website"].ToString();
                _Phone = dr["Phone"].ToString();
                _MobileNo = dr["MobileNo"].ToString();
                _Fax = dr["FAX"].ToString();
                _Email = dr["Email"].ToString();
                _NetworkGroupSno = dr["NetworkGroupSno"].ToString();
                if (dr["StarRating"].ToString() == "" || dr["StarRating"].ToString() == null)
                {
                    _StarRating = 0;
                }
                else
                {
                    _StarRating = int.Parse(dr["StarRating"].ToString());
                }
                if (dr["CityCode"].ToString() == null || dr["CityCode"].ToString() == "")
                {
                    _CityCode = "";
                }
                else
                {
                    _CityCode = dr["CityCode"].ToString();
                }
                //_AgentType = dr["AgentType"].ToString();
                _IATANo = dr["IATANo"].ToString();
                _Adcode = dr["ADCode"].ToString();
                _IECNo = dr["ADCode"].ToString();
                _BankName = dr["BankName"].ToString();
                _BankAccNo = dr["BankAccNo"].ToString();
                _BankAdd = dr["BankAddress"].ToString();
                _PANNo = dr["PANNo"].ToString();
                _ServiceTaxNo = dr["ServiceTAXNO"].ToString();
                _TanNo = dr["TANNO"].ToString();
                _TinNo = dr["TINNO"].ToString();

                _InvoiceCreditPeriod = int.Parse(dr["InvoiceCreditPeriod"].ToString());
                if (dr["crlmt"].ToString() == "ycrlmt")
                {
                    _CreditLimit = decimal.Parse(dr["CreditLimit"].ToString() == "" ? "0" : dr["CreditLimit"].ToString());
                    //_CLApprovedBy = dr["CLApprovedBy"].ToString();
                    //_CLApprovedAt = DateTime.Parse (dr["CLApprovedAt"].ToString());

                    if (_CreditLimit != 0)
                    {


                        _CreditReviewDate = Convert.ToDateTime(dr["CLNextReviewDate"].ToString());
                    }
                    _BankGuarantee = decimal.Parse(dr["BGAmount"].ToString() == "" ? "0" : dr["BGAmount"].ToString());
                }
                _PaymentMode = dr["PaymentMode"].ToString();
                _Currency = dr["Currency"].ToString();
                _StandardDeal = decimal.Parse(dr["StandardDeal"].ToString() == "" ? "0" : dr["StandardDeal"].ToString());
                // _DeliveryStatus = dr["DoDelivery"].ToString();
                _BillingCycle = dr["BillingCycle"].ToString();
                _NetworkAgentCitySno =int.Parse(dr["NetworkAgentCitySno"].ToString());
                _GroupCustomer = dr["GroupCustomer"].ToString();
                _bill = dr["Bill"].ToString();
                

            }
        }
        public void EditCreditReview(Int32 strA)
        {
            SqlDataReader dr = DataAgentMaster.CreditReviewData(strA);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    _BalSheet2Years1 = dr["BalSheet2Years1"].ToString();
                    _BalSheet2YearsDesc = dr["BalSheet2YearsDesc"].ToString();
                    _BankConfirmLetter = dr["BankConfirmLetter"].ToString();
                    _BankConfirmLetterDesc = dr["BankConfirmLetterDesc"].ToString();
                    _MarketReport = dr["MarketReport"].ToString();
                    _MarketReportDesc = dr["MarketReportDesc"].ToString();
                    _MRApprovedByName = dr["MRApprovedByName"].ToString();
                    _CreditLimit = decimal.Parse(dr["CreditLimit"].ToString() == "" ? "0" : dr["CreditLimit"].ToString());
                    _CreditPeriod = int.Parse(dr["CreditPeriod"].ToString() == "" ? "0" : dr["CreditPeriod"].ToString());
                    _CreditReviewDate = DateTime.Parse(dr["CreditReviewDate"].ToString());
                    _RateOfInterest = decimal.Parse(dr["RateOfInterest"].ToString() == "" ? "0" : dr["RateOfInterest"].ToString());
                    _BankGuarantee = decimal.Parse(dr["BGAmount"].ToString() == "" ? "0" : dr["BGAmount"].ToString());
                    _BGDate = DateTime.Parse(dr["BGDate"].ToString());
                    _BGClaimPeriod = DateTime.Parse(dr["BGClaimPeriod"].ToString());
                    _BankName = dr["BankName"].ToString();
                    _BankAdd = dr["BankAddress"].ToString();
                }


            }
        }
        public void EditAgentmain(Int32 strA)
        {
            SqlDataReader dr = DataAgentMaster.SearchAgentmain(strA);
            if (dr.Read())
            {

                _CustomerType = dr["CustomerType"].ToString();

                _CustomerName = dr["CustomerName"].ToString();
                if (dr["NetworkGroupSNo"].ToString() != null || dr["NetworkGroupSNo"].ToString() != "")
                {

                    _NetworkGroupSno = dr["NetworkGroupSNo"].ToString();
                }
                else
                {
                    _NetworkGroupSno = "";
                }
                _StarRating = int.Parse(dr["StarRating"].ToString() == "" ? "0" : dr["StarRating"].ToString());

                _IATANo = dr["IATANo"].ToString();
                _GroupCreditLimit = decimal.Parse(dr["GroupCreditLimit"].ToString() == "" ? "0" : dr["GroupCreditLimit"].ToString());

                _GroupCustomer = dr["GroupCustomer"].ToString();
            }
        }
        public String AddAgent()
        {
            return DataAgentMaster.InsertAgent(this);
        }
        public String AddCustomer(string EnteredBy)
        {
            return DataAgentMaster.InsertCustomer(this,EnteredBy);
        }
        public String InsertCustomer( bool IsOscCal)
        {
            return DataAgentMaster.Insert_Customer(this, IsOscCal);
        }
        public String insertCustomerNew(string entryType, int custMastSno, int CustomerBusinessTypeSno, int SalesPersonSno, bool IsOscCal, SqlTransaction tr)
        {
            return DataAgentMaster.insertCustomerNew(this,entryType,custMastSno,CustomerBusinessTypeSno,SalesPersonSno, IsOscCal,tr);
        }
        public String updateCustomer(string entryType, int custMastSno, int CustomerBusinessTypeSno, int SalesPersonSno, bool IsOscCal, SqlTransaction tr)
        {
            return DataAgentMaster.updateCustomer(this, entryType, custMastSno, CustomerBusinessTypeSno,SalesPersonSno, IsOscCal,tr);
        }
        public String AddCustomerCreditreview(SqlTransaction tr)
        {
            return DataAgentMaster.InsertCustomerCreditReview(this,tr);
        }
        public String AddCustomercontacts()
        {
            return DataAgentMaster.InsertCustomercontacts(this);
        }
        public String AddCustomercontactsApprove(SqlTransaction tr)
        {
            return DataAgentMaster.InsertCustomercontactsApprove(this,tr);
        }
        public String AddCustomerCreditLimit(SqlTransaction tr)
        {
            return DataAgentMaster.InsertCustomerCreditLimit(this,tr);
        }
        public String Update_CondCreditReview(SqlTransaction tr)
        {
            return DataAgentMaster.Update_CondCreditReview(this,tr);
        }
        public String UpdateSales_CreditReview(SqlTransaction tr)
        {
            return DataAgentMaster.UpdateSales_CreditReview(this,tr);
        }
        public String Update_CreditReview()
        {
            return DataAgentMaster.Update_CreditReview(this);
        }
        public String AddCustomerCreditLimitbyAccDirect()
        {
            return DataAgentMaster.InsertCustomerCreditLimitbyAccDirect(this);
        }
        public String UpdateCreditReviewNew()
        {
            return DataAgentMaster.UpdateCreditReviewNew(this);
        }
        public String UpdateCustomer(bool oscCal)
        {
            return DataAgentMaster.UpdateCust(this,oscCal);
        }
        public String UpdateCustomerNew(bool oscCal)
        {
            return DataAgentMaster.UpdateCustNew(this, oscCal);
        }
        public String UpdateCustomerMaster()
        {
            return DataAgentMaster.UpdateCustMaster(this);
        }
        public void AddCustomerContact(string DOB, string DOA)
        {
            DataAgentMaster.InsertContacts(this, DOB, DOA);
        }
        public void insertCustomerTDS(int CustBrSno, decimal TDSRate, decimal ECess, DateTime TDSReceivedOn, DateTime TDSValidFrom, DateTime TDSValidTo, string TDSStatus,string EnteredBy)
        {
            DataAgentMaster.insertCustomerTDS(CustBrSno, TDSRate, ECess, TDSReceivedOn, TDSValidFrom, TDSValidTo, TDSStatus,EnteredBy);
        }
        public void updateCustomerTDS(int CustomerTDSSno, int CustBrSno, decimal TDSRate, decimal ECess, DateTime TDSReceivedOn, DateTime TDSValidFrom, DateTime TDSValidTo, string TDSStatus)
        {
            DataAgentMaster.updateCustomerTDS(CustomerTDSSno,CustBrSno, TDSRate,ECess,TDSReceivedOn,TDSValidFrom,TDSValidTo, TDSStatus);
        }
        public void DeleteContact()
        {
            DataAgentMaster.DelContact(this);
        }
        public void Deletecustomer()
        {
            DataAgentMaster.Deletecustomer(this);
        }
        public void AddCreditReview()
        {
            DataAgentMaster.InsertCreditReview(this);
        }
        public void UpdateCreditReview()
        {
            DataAgentMaster.UpdateCreditReview(this);
        }
        public String AddCustomerRegister()
        {
            return DataAgentMaster.InsertCustomerRegister(this);
        }
        public String AddCustomerRegister2()
        {
            return DataAgentMaster.InsertCustomerRegister2(this);
        }

        public String ExistAgent()
        {
            return DataAgentMaster.Exists(this);
        }
        public String ExistCustomer()
        {
            return DataAgentMaster.ExistsCustomer(this);
        }
        public String alreadCustomerCheck()
        {
            return DataAgentMaster.alreadCustomerCheck(this);
        }
        public String ExistLoginId()
        {
            return DataAgentMaster.ExistLoginId(this);
        }

        public String UpdateAgent()
        {
            return DataAgentMaster.UpdatetAgent(this);
        }
        public SqlDataReader getBankG()
        {
            return (SqlDataReader)DataAgentMaster.getBankG(this);
        }
        public SqlDataReader ViewCreditReview()
        {
            return (SqlDataReader)DataAgentMaster.DetailsCreditReview(this);
        }

        public DataSet Plansearch()
        {
            return DataAgentMaster.RetrievePlan();
        }

        public DataSet BindCurrency()
        {
            return DataAgentMaster.Currency();
        }
        public DataSet BindContact()
        {
            return DataAgentMaster.ContactGrid(this);
        }
        public DataSet BindCity()
        {
            return DataAgentMaster.City();
        }
        public DataSet GetCustCareCity()
        {
            return DataAgentMaster.CustCareCity();
        }
        public DataSet City_UserID(string UserID)
        {
            return DataAgentMaster.City_UserID(UserID);
        }
        public DataSet CityBnd()
        {
            return DataAgentMaster.CityBind();
        }

        public SqlDataReader GetAgent()
        {
            return DataAgentMaster.GetAgent();
        }

        public SqlDataReader GetAgentName()
        {
            return DataAgentMaster.getAgentName(this);
        }
        public SqlDataReader GetAgentNameByCode()
        {
            return DataAgentMaster.GetAgentNameByCode(this);
        }

        public String InsertCustomerTaxDetail()
        {
            return DataAgentMaster.InsertCustomerTaxDetail(this);
        }

        public String UpdateCustomerTaxDetail()
        {
            return DataAgentMaster.UpdateCustomerTaxDetail(this);
        }
        public String checkcreditlimit()
        {
            return DataAgentMaster.checkcreditlimit(this);
        }
        public String checkgroup()
        {
            return DataAgentMaster.checkgroupassign(this);
        }
        public SqlDataReader checkgroup2()
        {
            return DataAgentMaster.checkgroupassign2(this);
        }
        public String DeleteCustomerTaxDetail()
        {
            return DataAgentMaster.DeleteCustomerTaxDetail(this);
        }
        public void GetCustomer(int strSNo)
        {
            SqlDataReader dr = DataAgentMaster.GetCustomerTaxDetail(strSNo);
            if (dr.Read())
            {
                this.AgentCode = dr["CustSno"].ToString();
                this.TDSRate = Convert.ToDecimal(dr["TdsExcemption"].ToString());
                this.ExemptionLimit = Convert.ToDecimal(dr["ExcemptionLimit"].ToString());
                this.ValidFrom = DateTime.Parse(dr["validfrom"].ToString());
                this.ValidTo = DateTime.Parse(dr["Validto"].ToString());
            }
        }

        public String ServiceTaxNo
        {
            get { return _ServiceTaxNo; }
            set { _ServiceTaxNo = value; }
        }
        public String TanNo
        {
            get { return _TanNo; }
            set { _TanNo = value; }
        }
        public String TinNo
        {
            get { return _TinNo; }
            set { _TinNo = value; }

        }
        public Int32 InvoiceCreditPeriod
        {
            get { return _InvoiceCreditPeriod; }
            set { _InvoiceCreditPeriod = value; }
        } 
        public string RequestedBy
        {
            get { return _RequestedBy; }
            set { _RequestedBy = value; }
        }
        public decimal CreditLimit
        {
            get { return _CreditLimit; }
            set { _CreditLimit = value; }
        }
        public decimal UsedLimit
        {
            get { return _UsedLimit; }
            set { _UsedLimit = value; }
        }
        public decimal AvailableLimit
        {
            get { return _AvailableLimit; }
            set { _AvailableLimit = value; }
        }
        public int CreditPeriod
        {
            get { return _CreditPeriod; }
            set { _CreditPeriod = value; }
        }
        public DateTime CreditReviewDate
        {
            get { return _CreditReviewDate; }
            set { _CreditReviewDate = value; }
        }
        public decimal BGAmount
        {
            get { return _BGAmount; }
            set { _BGAmount = value; }
        }
        public DateTime BGDate
        {
            get { return _BGDate; }
            set { _BGDate = value; }
        }
        public String BankName
        {
            get { return _BankName; }
            set { _BankName = value; }
        }
        public String BankAddress
        {
            get { return _BankAddress; }
            set { _BankAddress = value; }
        }
        public String ApplicantName
        {
            get { return _ApplicantName; }
            set { _ApplicantName = value; }
        }
        public String LegalStatus
        {
            get { return _LegalStatus; }
            set { _LegalStatus = value; }
        }
        public String ROCRegnNo
        {
            get { return _ROCRegnNo; }
            set { _ROCRegnNo = value; }
        }
        public String SalesPersonName
        {
            get { return _SalesPersonName; }
            set { _SalesPersonName = value; }
        }
        public String IndustryType
        {
            get { return _IndustryType; }
            set { _IndustryType = value; }
        }
        public String CustomerPremises
        {
            get { return _CustomerPremises; }
            set { _CustomerPremises = value; }
        }
        public String PartnerName1
        {
            get { return _PartnerName1; }
            set { _PartnerName1 = value; }
        }
        public String AccountsRemarks
        {
            get { return _AccountsRemarks; }
            set { _AccountsRemarks = value; }
        }
        public String PartnerAddress1
        {
            get { return _PartnerAddress1; }
            set { _PartnerAddress1 = value; }
        }
        public String OtherTradeName1
        {
            get { return _OtherTradeName1; }
            set { _OtherTradeName1 = value; }
        }
        public String PartnerName2
        {
            get { return _PartnerName2; }
            set { _PartnerName2 = value; }
        }
        public String PartnerAddress2
        {
            get { return _PartnerAddress2; }
            set { _PartnerAddress2 = value; }
        }
        public String OtherTradeName2
        {
            get { return _OtherTradeName2; }
            set { _OtherTradeName2 = value; }
        }
        public String PartnerName3
        {
            get { return _PartnerName3; }
            set { _PartnerName3 = value; }
        }
        public String PartnerAddress3
        {
            get { return _PartnerAddress3; }
            set { _PartnerAddress3 = value; }
        }
        public String OtherTradeName3
        {
            get { return _OtherTradeName3; }
            set { _OtherTradeName3 = value; }
        }
        public decimal AnnualSales
        {
            get { return _AnnualSales; }
            set { _AnnualSales = value; }
        }
        public int NoOfEmployee
        {
            get { return _NoOfEmployee; }
            set { _NoOfEmployee = value; }
        }
        public String LargestCustomerName1
        {
            get { return _LargestCustomerName1; }
            set { _LargestCustomerName1 = value; }
        }
        public String LargestCustomerName2
        {
            get { return _LargestCustomerName2; }
            set { _LargestCustomerName2 = value; }
        }
        public int OrgBusinessYear
        {
            get { return _OrgBusinessYear; }
            set { _OrgBusinessYear = value; }
        }

        public String OthBisPremiseLocation1
        {
            get { return _OthBisPremiseLocation1; }
            set { _OthBisPremiseLocation1 = value; }
        }
        public String OthBisPremiseType1
        {
            get { return _OthBisPremiseType1; }
            set { _OthBisPremiseType1 = value; }
        }
        public String OthBisPremiseFacility1
        {
            get { return _OthBisPremiseFacility1; }
            set { _OthBisPremiseFacility1 = value; }
        }
        public String OthBisPremiseLocation2
        {
            get { return _OthBisPremiseLocation2; }
            set { _OthBisPremiseLocation2 = value; }
        }
        public String OthBisPremiseType2
        {
            get { return _OthBisPremiseType2; }
            set { _OthBisPremiseType2 = value; }
        }
        public String OthBisPremiseFacility2
        {
            get { return _OthBisPremiseFacility2; }
            set { _OthBisPremiseFacility2 = value; }
        }
        public String OthBisPremiseLocation3
        {
            get { return _OthBisPremiseLocation3; }
            set { _OthBisPremiseLocation3 = value; }
        }
        public String OthBisPremiseType3
        {
            get { return _OthBisPremiseType3; }
            set { _OthBisPremiseType3 = value; }
        }
        public String OthBisPremiseFacility3
        {
            get { return _OthBisPremiseFacility3; }
            set { _OthBisPremiseFacility3 = value; }
        }
        public String OthBisPremiseLocation4
        {
            get { return _OthBisPremiseLocation4; }
            set { _OthBisPremiseLocation4 = value; }
        }
        public String OthBisPremiseType4
        {
            get { return _OthBisPremiseType4; }
            set { _OthBisPremiseType4 = value; }
        }
        public String OthBisPremiseFacility4
        {
            get { return _OthBisPremiseFacility4; }
            set { _OthBisPremiseFacility4 = value; }
        }
        public String CountryCode
        {
            get { return _CountryCode; }
            set { _CountryCode = value; }
        }
        public String OthBisPremiseLocation5
        {
            get { return _OthBisPremiseLocation5; }
            set { _OthBisPremiseLocation5 = value; }
        }
        public String OthBisPremiseType5
        {
            get { return _OthBisPremiseType5; }
            set { _OthBisPremiseType5 = value; }
        }
        public String OthBisPremiseFacility5
        {
            get { return _OthBisPremiseFacility5; }
            set { _OthBisPremiseFacility5 = value; }
        }
        public String OthBisPremiseLocation6
        {
            get { return _OthBisPremiseLocation6; }
            set { _OthBisPremiseLocation6 = value; }
        }
        public String OthBisPremiseType6
        {
            get { return _OthBisPremiseType6; }
            set { _OthBisPremiseType6 = value; }
        }
        public String OthBisPremiseFacility6
        {
            get { return _OthBisPremiseFacility6; }
            set { _OthBisPremiseFacility6 = value; }
        }
        public String OthForwarder1
        {
            get { return _OthForwarder1; }
            set { _OthForwarder1 = value; }
        }
        public decimal OutstandingAmt1
        {
            get { return _OutstandingAmt1; }
            set { _OutstandingAmt1 = value; }
        }
        public String OthForwarder2
        {
            get { return _OthForwarder2; }
            set { _OthForwarder2 = value; }
        }
        public String Address
        {
            get { return _Address; }
            set { _Address = value; }
        }
        public decimal OutstandingAmt2
        {
            get { return _OutstandingAmt2; }
            set { _OutstandingAmt2 = value; }
        }
        public String OthForwarder3
        {
            get { return _OthForwarder3; }
            set { _OthForwarder3 = value; }
        }
        public decimal OutstandingAmt3
        {
            get { return _OutstandingAmt3; }
            set { _OutstandingAmt3 = value; }
        }
        public String OthForwarder4
        {
            get { return _OthForwarder4; }
            set { _OthForwarder4 = value; }
        }
        public decimal OutstandingAmt4
        {
            get { return _OutstandingAmt4; }
            set { _OutstandingAmt4 = value; }
        }
        public String OthForwarder5
        {
            get { return _OthForwarder5; }
            set { _OthForwarder5 = value; }
        }
        public decimal OutstandingAmt5
        {
            get { return _OutstandingAmt5; }
            set { _OutstandingAmt5 = value; }
        }
        public String OthForwarder6
        {
            get { return _OthForwarder6; }
            set { _OthForwarder6 = value; }
        }
        public decimal OutstandingAmt6
        {
            get { return _OutstandingAmt6; }
            set { _OutstandingAmt6 = value; }
        }
        public decimal MonthlyBilling
        {
            get { return _MonthlyBilling; }
            set { _MonthlyBilling = value; }
        }
        public decimal MonthlyVolume
        {
            get { return _MonthlyVolume; }
            set { _MonthlyVolume = value; }
        }
        public decimal CreditLimitReq
        {
            get { return _CreditLimitReq; }
            set { _CreditLimitReq = value; }
        }
        public int CreditPeriReq
        {
            get { return _CreditPeriReq; }
            set { _CreditPeriReq = value; }
        }
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        public String CityCode
        {
            get { return _CityCode; }
            set { _CityCode = value; }
        }
        public String ApprovedBy
        {
            get { return _ApprovedBy; }
            set { _ApprovedBy = value; }
        }
        public DateTime ApprovedAt
        {
            get { return _ApprovedAt; }
            set { _ApprovedAt = value; }
        }
        public Int32 SNo
        {
            get { return _SNo; }
            set { _SNo = value; }
        }
        public String Currency
        {
            get { return _Currency; }
            set { _Currency = value; }
        }

        public String AgentCode
        {
            get { return _AgentCode; }
            set { _AgentCode = value; }
        }
        public String Active
        {
            get { return _Active; }
            set { _Active = value; }
        }
        public String ModifiedBy
        {
            get { return _ModifiedBy; }
            set { _ModifiedBy = value; }
        }
        public String Flaggroup
        {
            get { return _Flaggroup; }
            set { _Flaggroup = value; }
        }
        public DateTime ModifiedDate
        {
            get { return _ModifiedDate; }
            set { _ModifiedDate = value; }
        }
        public String Phone
        {
            get { return _Phone; }
            set { _Phone = value; }
        }
        public String PaymentMode
        {
            get { return _PaymentMode; }
            set { _PaymentMode = value; }
        }
        public String Password
        {
            get { return _Password; }
            set { _Password = value; }
        }
        public String Flagmainbranch
        {
            get { return _Flagmainbranch; }
            set { _Flagmainbranch = value; }
        }
        public String AgentName
        {
            get { return _AgentName; }
            set { _AgentName = value; }
        }
        public String CustomerName
        {
            get { return _CustomerName; }
            set { _CustomerName = value; }
        }
        public String BillingCycle
        {
            get { return _BillingCycle; }
            set { _BillingCycle = value; }
        }
        public String NetworkGroupSno
        {
            get { return _NetworkGroupSno; }
            set { _NetworkGroupSno = value; }
        }
        public String NetworkGroupPriority
        {
            get { return _NetworkGroupPriority; }
            set { _NetworkGroupPriority = value; }

        }

        public String CustomerType
        {
            get { return _CustomerType; }
            set { _CustomerType = value; }
        }
        public String StreetName
        {
            get { return _StreetName; }
            set { _StreetName = value; }
        }
        public String Town
        {
            get { return _Town; }
            set { _Town = value; }
        }
        public String State
        {
            get { return _State; }
            set { _State = value; }
        }
        public String PinCode
        {
            get { return _PinCode; }
            set { _PinCode = value; }
        }

        public String AgentType
        {
            get { return _AgentType; }
            set { _AgentType = value; }
        }
        public String GSASNo
        {
            get { return _GSASNo; }
            set { _GSASNo = value; }
        }
        public Int32 CustomerSNo
        {
            get { return _CustomerSNo; }
            set { _CustomerSNo = value; }

        }
        public Int32 StarRating
        {
            get { return _StarRating; }
            set { _StarRating = value; }

        }
        public Int32 NetworkAgentCitySno
        {
            get { return _NetworkAgentCitySno; }
            set { _NetworkAgentCitySno = value; }

        }

        //public Decimal CreditLimit
        //{
        //    get { return _CreditLimit; }
        //    set { _CreditLimit = value; }
        //}
        public Decimal GroupCreditLimit
        {
            get { return _GroupCreditLimit; }
            set { _GroupCreditLimit = value; }
        }
        public String ApprovalCode
        {
            get { return _ApprovalCode; }
            set { _ApprovalCode = value; }
        }
        public String FlagCustType
        {
            get { return _FlagCustType; }
            set { _FlagCustType = value; }
        }
        public Decimal Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }
        //public String BankName
        //{
        //    get { return _BankName; }
        //    set { _BankName = value; }
        //}
        public String BankAdd
        {
            get { return _BankAdd; }
            set { _BankAdd = value; }
        }
        public String EnteredByBank
        {
            get { return _EnteredByBank; }
            set { _EnteredByBank = value; }
        }
        public String IATANo
        {
            get { return _IATANo; }
            set { _IATANo = value; }
        }
        public String PANNo
        {
            get { return _PANNo; }
            set { _PANNo = value; }
        }
        public Decimal TDSRate
        {
            get { return _TDSRate; }
            set { _TDSRate = value; }
        }
        public Decimal SurchargeRate
        {
            get { return _SurchargeRate; }
            set { _SurchargeRate = value; }
        }
        public Decimal ExemptionLimit
        {
            get { return _ExemptionLimit; }
            set { _ExemptionLimit = value; }
        }
        public DateTime EffectiveDate
        {
            get { return _EffectiveDate; }
            set { _EffectiveDate = value; }
        }
        public DateTime Date
        {
            get { return _Date; }
            set { _Date = value; }
        }
        public String City
        {
            get { return _City; }
            set { _City = value; }
        }
        public String PlanName
        {
            get { return _PlanName; }
            set { _PlanName = value; }
        }
        public Decimal StandardDiscount
        {
            get { return _StandardDiscount; }
            set { _StandardDiscount = value; }
        }

        public Decimal MaxLimit
        {
            get { return _MaxLimit; }
            set { _MaxLimit = value; }
        }
        public String PrintBy
        {
            get { return _PrintBy; }
            set { _PrintBy = value; }
        }
        public Decimal BankGuarantee
        {
            get { return _BankGuarantee; }
            set { _BankGuarantee = value; }
        }
        public String MTD
        {
            get { return _MTD; }
            set { _MTD = value; }
        }
        public String MobileNo
        {
            get { return _MobileNo; }
            set { _MobileNo = value; }
        }
        public String AutoStock
        {
            get { return _AutoStock; }
            set { _AutoStock = value; }
        }
        public DateTime EnteredDate
        {
            get { return _EnteredDate; }
            set { _EnteredDate = value; }

        }
        public DateTime ValidFrom
        {
            get { return _ValidFrom; }
            set { _ValidFrom = value; }
        }
        public DateTime ValidTo
        {
            get { return _ValidTo; }
            set { _ValidTo = value; }

        }
        public String EnteredBY
        {
            get { return _EnteredBY; }
            set { _EnteredBY = value; }
        }
        public String Place
        {
            get { return _Place; }
            set { _Place = value; }
        }
        public Int32 CompSno
        {
            get { return _CompSno; }
            set { _CompSno = value; }
        }
        public Int32 CompBrSno
        {
            get { return _CompBrSno; }
            set { _CompBrSno = value; }

        }
        public String loginFlag
        {
            get { return _loginFlag; }
            set { _loginFlag = value; }

        }
        public String CustomerLoginId
        {
            get { return _CustomerLoginId; }
            set { _CustomerLoginId = value; }
        }
        //public String Address
        //{
        //    get { return _Address; }
        //    set { _Address = value; }
        //}
        public String CustCareCity
        {
            get { return _CustCareCity; }
            set { _CustCareCity = value; }
        }
        public String Website
        {
            get { return _Website; }
            set { _Website = value; }
        }
        public String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        public String Fax
        {
            get { return _Fax; }
            set { _Fax = value; }
        }
        public String Adcode
        {
            get { return _Adcode; }
            set { _Adcode = value; }
        }
        public String IECNo
        {
            get { return _IECNo; }
            set { _IECNo = value; }
        }
        public String BankAccNo
        {
            get { return _BankAccNo; }
            set { _BankAccNo = value; }
        }
        public String CLApprovedBy
        {
            get { return _CLApprovedBy; }
            set { _CLApprovedBy = value; }
        }
        public DateTime CLApprovedAt
        {
            get { return _CLApprovedAt; }
            set { _CLApprovedAt = value; }
        }
        //public DateTime CreditReviewDate
        //{
        //    get { return _CreditReviewDate; }
        //    set { _CreditReviewDate = value; }
        //}
        public Decimal StandardDeal
        {
            get { return _StandardDeal; }
            set { _StandardDeal = value; }
        }
        public String DeliveryStatus
        {
            get { return _DeliveryStatus; }
            set { _DeliveryStatus = value; }
        }
        public String ContactName
        {
            get { return _ContactName; }
            set { _ContactName = value; }
        }
        public String ContactDesign
        {
            get { return _ContactDesign; }
            set { _ContactDesign = value; }
        }
        public String ContactDept
        {
            get { return _ContactDept; }
            set { _ContactDept = value; }
        }
        public String ContactAdd
        {
            get { return _ContactAdd; }
            set { _ContactAdd = value; }
        }
        public String ContactPhone
        {
            get { return _ContactPhone; }
            set { _ContactPhone = value; }
        }
        public String ContactMobile
        {
            get { return _ContactMobile; }
            set { _ContactMobile = value; }
        }
        public String ContactEmail
        {
            get { return _ContactEmail; }
            set { _ContactEmail = value; }
        }
        public DateTime DOB
        {
            get { return _DOB; }
            set { _DOB = value; }
        }
        public DateTime DOA
        {
            get { return _DOA; }
            set { _DOA = value; }
        }
        public String CustomerRemarks
        {
            get { return _CustomerRemarks; }
            set { _CustomerRemarks = value; }
        }
        public Int32 loginSno
        {
            get { return _loginSno; }
            set { _loginSno = value; }
        }
        public String ApprovalType
        {
            get { return _ApprovalType; }
            set { _ApprovalType = value; }

        }
        private String   _SalesRemarks;
        public String SalesRemarks
        {
            get { return _SalesRemarks; }
            set { _SalesRemarks = value; }
        }
        public string LoginPassword
        {
            get { return _LoginPassword; }
            set { _LoginPassword = value; }
        }
        public string LoginCompSNo
        {
            get { return _LoginCompSNo; }
            set { _LoginCompSNo = value; }
        }
        public string LoginDisplayName
        {
            get { return _LoginDisplayName; }
            set { _LoginDisplayName = value; }
        }
        public string LoginEmailID
        {
            get { return _LoginEmailID; }
            set { _LoginEmailID = value; }
        }
        public string AdCode
        {
            get { return _AdCode; }
            set { _AdCode = value; }
        }
        public string Bill
        {
            get { return _Bill; }
            set { _Bill = value; }
        }
        public string CustomerCareCity
        {
            get { return _CustomerCareCity; }
            set { _CustomerCareCity = value; }
        }
        public string EnteredBy
        {
            get { return _EnteredBy; }
            set { _EnteredBy = value; }
        }
        public string hdnCustType
        {
            get { return _hdnCustType; }
            set { _hdnCustType = value; }
        }
        public string IataNo
        {
            get { return _IataNo; }
            set { _IataNo = value; }
        }
        public string Mobile
        {
            get { return _Mobile; }
            set { _Mobile = value; }
        }
        public string PanNo
        {
            get { return _PanNo; }
            set { _PanNo = value; }
        }
        public string PhoneNo
        {
            get { return _PhoneNo; }
            set { _PhoneNo = value; }
        }
        public string Street
        {
            get { return _Street; }
            set { _Street = value; }
        }
        public int CustBrSno
        {
            get { return _CustBrSno; }
            set { _CustBrSno = value; }
        }
        public int custMastSno
        {
            get { return _custMastSno; }
            set { _custMastSno = value; }
        }
        public int CustomerBusinessTypeSno
        {
            get { return _CustomerBusinessTypeSno; }
            set { _CustomerBusinessTypeSno = value; }
        }
        public int NetWorkAgentCitySno
        {
            get { return _NetWorkAgentCitySno; }
            set { _NetWorkAgentCitySno = value; }
        }
        public int SalesPersonSno
        {
            get { return _SalesPersonSno; }
            set { _SalesPersonSno = value; }
        }
        public int flag
        {
            get { return _flag; }
            set { _flag = value; }
        }
        public string entryType
        {
            get { return _entryType; }
            set { _entryType = value; }
        }
        public bool isOscCal
        {
            get { return _isOscCal; }
            set { _isOscCal = value; }
        }
        public string IsOscCalCulated
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
        public int BrSno
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
        public decimal CreditLimitPace
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        //public DateTime Date
        //{
        //    get { return _Date; }
        //    set { _Date = value; }
        //}
        //public String BankName
        //{
        //    get { return _BankName; }
        //    set { _BankName = value; }
        //}

        //public String BankAdd
        //{
        //    get { return _BankAdd; }
        //    set { _BankAdd = value; }
        //}
        //public String EnteredByBank
        //{
        //    get { return _EnteredByBank; }
        //    set { _EnteredByBank = value; }
        //}
        //public String Currency
        //{
        //    get { return _Currency; }
        //    set { _Currency = value; }
        //}
        public String BalSheet2Years1
        {
            get { return _BalSheet2Years1; }
            set { _BalSheet2Years1 = value; }
        }

        public SqlDataReader getBillingCycle()
        {
            return DataAgentMaster.getBillingCycle();
        }
        public DataSet getAllCusts(string CompBrSNo)
        {
            return DataAgentMaster.getAllCusts(this, CompBrSNo);
        }
        public DataSet getAllCustAddress(string CompBrSNo)
        {
            return DataAgentMaster.getAllCustAddress(this, CompBrSNo);
        }
        public String BalSheet2YearsDesc
        {
            get { return _BalSheet2YearsDesc; }
            set { _BalSheet2YearsDesc = value; }
        }
        public String BankConfirmLetter
        {
            get { return _BankConfirmLetter; }
            set { _BankConfirmLetter = value; }

        }
        public String BankConfirmLetterDesc
        {
            get { return _BankConfirmLetterDesc; }
            set { _BankConfirmLetterDesc = value; }
        }
        public String MarketReport
        {
            get { return _MarketReport; }
            set { _MarketReport = value; }
        }
        public String MarketReportDesc
        {
            get { return _MarketReportDesc; }
            set { _MarketReportDesc = value; }
        }
        public String MRApprovedByName
        {
            get { return _MRApprovedByName; }
            set { _MRApprovedByName = value; }

        }
        public String LoginId
        {
            get { return _LoginId; }
            set { _LoginId = value; }

        }
        public String bill
        {
            get { return _bill; }
            set { _bill = value; }

        }
        //public Int32 CreditPeriod
        //{
        //    get { return _CreditPeriod; }
        //    set { _CreditPeriod = value; }
        //}
        public Decimal RateOfInterest
        {
            get { return _RateOfInterest; }
            set { _RateOfInterest = value; }
        }
        //public DateTime BGDate
        //{
        //    get { return _BGDate; }
        //    set { _BGDate = value; }
        //}
        public DateTime BGClaimPeriod
        {
            get { return _BGClaimPeriod; }
            set { _BGClaimPeriod = value; }
        }
        public DateTime EnteredAt
        {
            get { return _EnteredAt; }
            set { _EnteredAt = value; }
        }
        public String GroupCustomer
        {
           get {return _GroupCustomer;}
           set { _GroupCustomer = value;}
        }
        public SqlDataReader CountryCode_Show()
        {
            return DataAgentMaster.CountryCode_Show();
        }

        public SqlDataReader CountryCode_ShowCity()
        {
            return DataAgentMaster.CountryCode_ShowCity();
        }
        public SqlDataReader CategoryCodeShowcity()
        {
            return DataAgentMaster.CategoryCodeShowcity();
        }

        public SqlDataReader CustType_Show()
        {
            return DataAgentMaster.CustType_Show();
        }
        public SqlDataReader CompHeadBind()
        {
            return DataAgentMaster.CompHeadBind();
        }
        public SqlDataReader CompHeadBindPNP()
        {
            return DataAgentMaster.CompHeadBindPNP();
        }
        public SqlDataReader FindBranchSnoDeat(int Sno)
        {
            return DataAgentMaster.FindBranchSnoDeat(Sno);
        }

        public String UpdateCompLogo(int CustSno, byte[] CLogo, byte[] BLogo, byte[] Logo)
        {
            return DataAgentMaster.UpdateCompLogo(CustSno, CLogo, BLogo, Logo);

        }
        public String InsertCLBranchWise(int BrSno, decimal climit, SqlTransaction tr)
        {
            return DataAgentMaster.InsertCLBranchWise(BrSno, climit,tr);
        }
        public DataSet GetCustomerCreditLimit(string CompBrSNo, string Status, string CustSno)
        {
            return DataAgentMaster.GetCustomerCreditLimit(CompBrSNo, Status, CustSno);
        }
        public SqlDataReader ShowRegistrationDet(int loginSno)
        {
            return DataAgentMaster.ShowRegistrationDet(loginSno);
        }
        public SqlDataReader ShowAssociateDet(int Sno)
        {
            return DataAgentMaster.ShowAssociateDet(Sno);
        }
        public DataSet CreditReviewRenewal(int CompBrSno)
        {
            return DataAgentMaster.CreditReviewRenewal(CompBrSno);
        }
        public String CheckRights(String loginType)
        {
            return DataAgentMaster.CheckRights(loginType);
        }
        public DataSet NewCreditRequest(int CompBrSno)
        {
            return DataAgentMaster.NewCreditRequest(CompBrSno);
        }
        public String UpdateRegDetAssociate(Int32 regDetSno, Int32 AssociateId, String Flag)
        {
            return DataAgentMaster.UpdateRegDetAssociate(regDetSno, AssociateId, Flag);
        }
        public DataSet SupplierReportSelect()
        {
            return DataAgentMaster.SupplierReportSelect(this);
        }
        public SqlDataReader CheckUsedLimit(Int32 CustBrSno)
        {
            return DataAgentMaster.CheckUsedLimit(this,CustBrSno);
        }
        public String checkCreditStatus(Int32 MSno)
        {
            return DataAgentMaster.checkCreditStatus(MSno);
        }
        public String CreditReviewMassage(Int32 MSno)
        {
            return DataAgentMaster.CreditReviewMassage(MSno);
        }
        public String DisapproveCrLimitBySales(SqlTransaction tr)
        {
            return DataAgentMaster.DisapproveCrLimitBySales(this,tr);
        }

        public DataSet getCustomerDetailForConference(int CustMSno, int CustBrSno, int pageSize, int pageNo, string whereCondition)
        {
            return DataAgentMaster.getCustomerDetailForConference(CustMSno,CustBrSno, pageSize, pageNo, whereCondition);
        }
        public String insertCustConferenceDetail(int CustConfSno, int CustMSno, int CustBrSno, string Remarks, string ActionTaken, string Conference, string ConferenceCity, DateTime ConferenceDate, string AttendBy, string AddedBy, string updatedBy)
        {
            return DataAgentMaster.insertCustConferenceDetail(CustConfSno, CustMSno, CustBrSno, Remarks, ActionTaken,Conference, ConferenceCity,ConferenceDate, AttendBy,  AddedBy, updatedBy);
        }

        public string updateCustomerEmail(int SalesPerson)
        {
            return DataAgentMaster.updateCustomerEmail(this,SalesPerson);
        }

        public String InsertCutomerFromPaceExpress(SqlTransaction tr)
        {
            return DataAgentMaster.InsertCutomerFromPaceExpress(this, tr);
        }

        public String UpdateCutomerFromPaceExpress(SqlTransaction tr)
        {
            return DataAgentMaster.UpdateCutomerFromPaceExpress(this, tr);
        }

        public string updateCustomerEmailRedIntl()
        {
            return DataAgentMaster.updateCustomerEmailRedIntl(this);
        }

        public String insertCustomerNewRedIntl(SqlTransaction tr)
        {
            return DataAgentMaster.insertCustomerNewRedIntl(this, tr);
        }

        public String updateCustomerRedIntl( SqlTransaction tr)
        {
            return DataAgentMaster.updateCustomerRedIntl(this, tr);
        }

        public String AddCustomercontactsApproveRedIntl(SqlTransaction tr)
        {
            return DataAgentMaster.AddCustomercontactsApproveRedIntl(this, tr);
        }

        public string Insert_CreditReviewNew(SqlTransaction tr)
        {
            return DataAgentMaster.Insert_CreditReviewNew(this,tr);
        }

        public String InsertCLBranchWiseRedIntl(SqlTransaction tr)
        {
            return DataAgentMaster.InsertCLBranchWiseRedIntl(this, tr);
        }

        public String disapprove(SqlTransaction tr)
        {
            return DataAgentMaster.disapprove(this, tr);
        }

        public String InserCreditReview(SqlTransaction tr)
        {
            return DataAgentMaster.InserCreditReview(this, tr);
        }

        public String updatecustomercontact(SqlTransaction tr)
        {
            return DataAgentMaster.updatecustomercontact(this,tr);
        }

        public String updatecustomercontactApprove(SqlTransaction tr)
        {
            return DataAgentMaster.updatecustomercontactApprove(this, tr);
        }

        public String UpdateSales_CreditReviewRedIntl(SqlTransaction tr)
        {
            return DataAgentMaster.UpdateSales_CreditReviewRedIntl(this, tr);
        }

        public String disapproveCrLimitBySM(SqlTransaction tr)
        {
            return DataAgentMaster.disapproveCrLimitBySM(this, tr);
        }

        public String Update_CondCreditReviewRedintl(SqlTransaction tr)
        {
            return DataAgentMaster.Update_CondCreditReviewRedintl(this, tr);
        }
    }
}
