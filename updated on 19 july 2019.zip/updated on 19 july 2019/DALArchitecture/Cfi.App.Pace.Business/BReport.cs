﻿using System;
using System.Collections.Generic;
using System.Text;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;
using System.Data;
using System.Data.SqlClient;
namespace Cfi.App.Pace.Business
{
    public class BReport
    {
        
        public BReport()
        { }
        public DataSet GetInvoiceBookedChecked()
        {

            return DReport.GetInvoiceBookedChecked();
        }
        public DataSet GetChartData(DateTime dateFrom, string strCompBrSno)
        {
            return DReport.GetChartData(dateFrom, strCompBrSno);
        }
      
        public int InvoiceBooked_Insert(Int64 intInvNo, string strAddedBy)
        {
            return DReport.InvoiceBooked_Insert(intInvNo, strAddedBy);
        }
        public DataSet GetInvoiceBooked(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetInvoiceBooked(strCompBrSNo, strType, datFromDate, datToDate);
        }
        public DataSet GetExRateProfit(string strCompBrSNo, string strType, string strPaymentType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetExRateProfit(strCompBrSNo, strType, strPaymentType, datFromDate, datToDate);
        }
        public DataSet GetBillExecuted(string strType, string strCompBrSNo, string strExecType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillExecuted(strType, strCompBrSNo, strExecType,datFromDate, datToDate );
        }
        public DataSet getTaxableReport(string SNo)
        { 
            return DReport.getTaxableReport(SNo);
        }
        public DataSet getBillReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.getBillReport(strCompBrSNo, strType, datFromDate, datToDate);
        }
        public DataSet getPartywiseBillReport(string strCompBrSNo, string CustBrSno,string CustType, string strType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.getPartywiseBillReport(strCompBrSNo, CustBrSno,CustType, strType, datFromDate, datToDate);
        }
        public DataSet getAwbVsInvoicingReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.getAwbVsInvoicingReport(strCompBrSNo, strType, datFromDate, datToDate);
        }
        public DataSet getAwbVsInvoicingSubAgentReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate, string SubAgentSNo, string BillingCycle)
        {
            return DReport.getAwbVsInvoicingSubAgentReport(strCompBrSNo, strType, datFromDate, datToDate,SubAgentSNo,BillingCycle);
        }
        public DataSet getAwbVsAgentInvoicingReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate, string SubAgentSNo)
        {
            return DReport.getAwbVsAgentInvoicingReport(strCompBrSNo, strType, datFromDate, datToDate, SubAgentSNo);
        }

        public DataSet getAwbVsInvoicePostingReport(string strCompBrSNo, string strType,string strTransfer, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.getAwbVsInvoicePostingReport(strCompBrSNo, strType, strTransfer, datFromDate, datToDate);
        }
        public DataSet getClientwiseProfitability(string strCompBrSNo, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.getClientwiseProfitability(strCompBrSNo, datFromDate, datToDate);
        }
        public DataSet GetCustBrSno(string strCompBrSNo, string CustBrSno)
        {
            return DReport.GetCustBrSno(strCompBrSNo, CustBrSno);
        }
        public DataSet getAllSalesPersons(string strCompBrSNo, string strType,  DateTime datFromDate, DateTime datToDate)
        {
            return DReport.getAllSalesPersons(strCompBrSNo, strType, datFromDate, datToDate);
        }
        public DataSet getAllSalesPersonsReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate,string SalesPerson)
        {
            return DReport.getAllSalesPersonsReport(strCompBrSNo, strType, datFromDate, datToDate, SalesPerson);
        }
        public DataSet GetOutstandingCustomer(string StrAllCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetOutstandingCustomer(StrAllCompBrSNo, strType, datFromDate, datToDate);
        }
        public DataSet GetOutstandingBills(string CompBrSNo, string strType, DateTime Date,string CustMSno,string CustType)
        {
            return DReport.GetOutstandingBills(CompBrSNo, strType, Date, CustMSno,CustType);
        }
        public DataSet GetBillsPayable_Export_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer,Int64 intInvNo)
        {
            return DReport.GetBillsPayable_Export_Local(datFromDate, datToDate, strCompany, strCustomer,intInvNo);
        }
        public DataSet GetBillsPayable_OceanExp_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_OceanExp_Local(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_All_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_All_Local(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_Export_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_Export_AllLocation(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_OceanExp_AllLocation(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_All_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_All_AllLocation(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_Import_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer,Int64 intInvNo)
        {
            return DReport.GetBillsPayable_Import_AllLocation(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_OceanImp_AllLocation(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayableSupplier_Export_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_Export_Local(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_OceanExp_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_OceanExp_Local(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_All_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_All_Local(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableInvoiceNo_Export_Local(DateTime datFromDate, DateTime datToDate,string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_Export_Local(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_OceanExp_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_OceanExp_Local(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_All_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_All_Local(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_Export_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_Export_Overseas(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_OceanExp_Overseas(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_All_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_All_Overseas(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_Export_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_Export_AllLocation(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_OceanExp_AllLocation(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_All_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_All_AllLocation(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_Import_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_Import_AllLocation(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_OceanImp_AllLocation(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_Import_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_Import_Local(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_OceanImp_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_OceanImp_Local(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_Import_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_Import_Overseas(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableInvoiceNo_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            return DReport.GetBillsPayableInvoiceNo_OceanImp_Overseas(datFromDate, datToDate, strSupplier);
        }
        public DataSet GetBillsPayableSupplier_Export_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_Export_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_OceanExp_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_All_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_All_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_Import_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_Import_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_OceanImp_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsPayable_Export_Overseas(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer,Int64 intInvNo)
        {
            return DReport.GetBillsPayable_Export_Overseas(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_OceanExp_Overseas(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_All_Overseas(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_All_Overseas(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayableSupplier_Export_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_Export_Overseas(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_OceanExp_Overseas(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_All_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_All_Overseas(datFromDate, datToDate);
        }
        public DataSet GetBillsPayable_Import_Overseas(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_Import_Overseas(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer,Int64 intInvNo)
        {
            return DReport.GetBillsPayable_OceanImp_Overseas(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayableSupplier_Import_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_Import_Overseas(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_OceanImp_Overseas(datFromDate, datToDate);
        }
        public DataSet GetBillsPayable_Import_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer,Int64 intInvNo)
        {
            return DReport.GetBillsPayable_Import_Local(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayable_OceanImp_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, Int64 intInvNo)
        {
            return DReport.GetBillsPayable_OceanImp_Local(datFromDate, datToDate, strCompany, strCustomer, intInvNo);
        }
        public DataSet GetBillsPayableSupplier_Import_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_Import_Local(datFromDate, datToDate);
        }
        public DataSet GetBillsPayableSupplier_OceanImp_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsPayableSupplier_OceanImp_Local(datFromDate, datToDate);
        }
        public DataSet GetInvoice_Export(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            return DReport.GetInvoice_Export(datFromDate, datToDate, strCompany,shortby );
        }
        public DataSet GetOceanInvoice_Export(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            return DReport.GetOceanInvoice_Export(datFromDate, datToDate, strCompany, shortby);
        }
        //public DataSet InvoiceAll_Select(DateTime frmdate, DateTime tdate, string shortby, string compBrSno, string type)
        //{
        //    return DReport.InvoiceAll_Select(frmdate ,tdate,shortby,compBrSno,type );
        //}
        public DataSet InvoiceAll_Select(DateTime frmdate, DateTime tdate, string shortby, string compBrSno, string type, string customerBranchSno)
        {
            return DReport.InvoiceAll_Select(frmdate, tdate, shortby, compBrSno, type, customerBranchSno);
        }
        public DataSet GetInvoice_Import(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            return DReport.GetInvoice_Import(datFromDate, datToDate, strCompany,shortby );
        }
        public DataSet GetOceanInvoice_Import(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            return DReport.GetOceanInvoice_Import(datFromDate, datToDate, strCompany, shortby);
        }
        public DataSet GetInvoice_All(DateTime datFromDate, DateTime datToDate, string strCompany,string shortby)
        {
            return DReport.GetInvoice_All(datFromDate, datToDate, strCompany,shortby );
        }
        public DataSet getInvocereport(string CompBrSNo, string Type, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.getInvocereport(CompBrSNo,Type,datFromDate,datToDate);
        }
        public DataSet getAWBMonthwiseCount(string Month, string strCompBrSNo, string Year, string strType)
        {
            return DReport.getAWBMonthwiseCount(Month, strCompBrSNo, Year, strType);
        }

        public DataSet AwbNoSelect(string AwbNo, int SNo, string InvoiceNo)
        {
            return DReport.AwbNoSelect(AwbNo,SNo,InvoiceNo);
        }

        public string AwbNoDelete(int SNo,string TableType)
        {
            return DReport.AwbNoDelete(SNo,TableType);
        }
        public DataSet GetCustomerAll()
        {
            return DReport.GetCustomerAll();
        }
        public DataSet GetSupplierAll()
        {
            return DReport.GetSupplierAll();
        }
        public DataSet GetCustomerByCompany(string strCompany,string strType)
        {
            return DReport.GetCustomerByCompany(strCompany,strType);
        }
        public DataSet GetCustomerByCompanyExport(string strCompany)
        {
            return DReport.GetCustomerByCompanyExport(strCompany);
        }
        public DataSet GetSupplierByCompany(string strCompany)
        {
            return DReport.GetSupplierByCompany(strCompany);
        }
        public DataSet GetBillsReceivable_Export_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCreditType)
        {
            return DReport.GetBillsReceivable_Export_Local(datFromDate, datToDate, strCompany, strCustomer, strCreditType);
        }
        public DataSet GetBillsReceivable_OceanExp_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCreditType)
        {
            return DReport.GetBillsReceivable_OceanExp_Local(datFromDate, datToDate, strCompany, strCustomer, strCreditType);
        }
        public DataSet GetBillsReceivable_All_Local(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCreditType)
        {
            return DReport.GetBillsReceivable_All_Local(datFromDate, datToDate, strCompany, strCustomer, strCreditType);
        }
        public DataSet GetBillsReceivable_Export_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCrType)
        {
            return DReport.GetBillsReceivable_Export_AllLocation(datFromDate, datToDate, strCompany, strCustomer, strCrType);
        }
        public DataSet GetBillsReceivable_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCrType)
        {
            return DReport.GetBillsReceivable_OceanExp_AllLocation(datFromDate, datToDate, strCompany, strCustomer, strCrType);
        }
        public DataSet GetBillsReceivable_All_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCrType)
        {
            return DReport.GetBillsReceivable_All_AllLocation(datFromDate, datToDate, strCompany, strCustomer, strCrType);
        }
        public DataSet GetBillsReceivable_Import_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCrType)
        {
            return DReport.GetBillsReceivable_Import_AllLocation(datFromDate, datToDate, strCompany, strCustomer,strCrType);
        }
        public DataSet GetBillsReceivable_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCompany, string strCustomer, string strCrType)
        {
            return DReport.GetBillsReceivable_OceanImp_AllLocation(datFromDate, datToDate, strCompany, strCustomer, strCrType);
        }
        public DataSet GetBillsReceivableCompany_Export_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_Export_Local(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivableCompany(DateTime datFromDate, DateTime datToDate, string strCompany, string strType, string strCountryCode)
        {
            return DReport.GetBillsReceivableCompany(datFromDate, datToDate, strCompany, strType, strCountryCode);
        }
        public DataSet GetBillsPayableCompany(DateTime datFromDate, DateTime datToDate, string strCompany, string strType, string strCountryCode)
        {
            return DReport.GetBillsPayableCompany(datFromDate, datToDate, strCompany, strType, strCountryCode);
        }
        public DataSet GetBillsReceivableCompany_All_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_All_Local(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivableCompany_Export_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_Export_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivableCompany_All_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_All_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivableCompany_Import_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_Import_AllLocation(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivable_Import_Local(DateTime datFromDate, DateTime datToDate,string strCustomer ,string strCompany,string strCrType)
        {
            return DReport.GetBillsReceivable_Import_Local(datFromDate, datToDate,strCustomer ,strCompany,strCrType);
        }
        public DataSet GetBillsReceivable_OceanImp_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            return DReport.GetBillsReceivable_OceanImp_Local(datFromDate, datToDate, strCustomer, strCompany, strCrType);
        }
        public DataSet GetBillsReceivableCompany_Import_RI(DateTime datFromDate, DateTime datToDate, int  CompBrsno)
        {
            return DReport.GetBillsReceivableCompany_Import_RI(datFromDate, datToDate, CompBrsno);
        }

        public DataSet GetBillsReceivableCompany_Import_RI_Name(DateTime datFromDate, DateTime datToDate,string name)
        {
            return DReport.GetBillsReceivableCompany_Import_RI_Name(datFromDate, datToDate,name);
        }


        public DataSet GetBillsReceivableCompany_Import_RI_All(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_Import_RI_All(datFromDate, datToDate);
        }

        public DataSet GetBillsReceivableCompany_Import_Local(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_Import_Local(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivable_Import_Overseas(DateTime datFromDate, DateTime datToDate,string strCustomer ,string strCompany,string strCrType)
        {
            return DReport.GetBillsReceivable_Import_Overseas(datFromDate, datToDate, strCustomer, strCompany, strCrType);
        }
        public DataSet GetBillsReceivable_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            return DReport.GetBillsReceivable_OceanImp_Overseas(datFromDate, datToDate, strCustomer, strCompany, strCrType);
        }
        public DataSet GetBillsReceivableCompany_Import_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_Import_Overseas(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivable_Export_Overseas(DateTime datFromDate, DateTime datToDate,string strCustomer ,string strCompany,string strCrType)
        {
            return DReport.GetBillsReceivable_Export_Overseas(datFromDate, datToDate, strCustomer, strCompany, strCrType);
        }
        public DataSet GetBillsReceivable_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            return DReport.GetBillsReceivable_OceanExp_Overseas(datFromDate, datToDate, strCustomer, strCompany, strCrType);
        }
        public DataSet GetBillsReceivable_All_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            return DReport.GetBillsReceivable_All_Overseas(datFromDate, datToDate, strCustomer, strCompany, strCrType);
        }
        public DataSet GetBillsReceivableCompany_Export_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_Export_Overseas(datFromDate, datToDate);
        }
        public DataSet GetBillsReceivableCompany_All_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            return DReport.GetBillsReceivableCompany_All_Overseas(datFromDate, datToDate);
        }

        public SqlDataReader  getAllCHAUsers()
        {
            return DReport.getAllCHAUsers();
        }
        public DataSet getAllCHACharges(DateTime datFromDate, DateTime datToDate,string AddBy,string CompBrSNo)
        {
            return DReport.getAllCHACharges(datFromDate, datToDate, AddBy, CompBrSNo);
        }
        public DataSet getAllCHAChargesOTH(DateTime datFromDate, DateTime datToDate, string AddBy, string CompBrSNo)
        {
            return DReport.getAllCHAChargesOTH(datFromDate, datToDate, AddBy, CompBrSNo);
        }
        public DataSet getAllCHAChargesNew(DateTime datFromDate, DateTime datToDate,  string CompBrSNo)
        {
            return DReport.getAllCHAChargesNew(datFromDate, datToDate,  CompBrSNo);
        }
        public DataSet getAllCHAChargesCHA(DateTime datFromDate, DateTime datToDate, string CompBrSNo,string CHASNo)
        {
            return DReport.getAllCHAChargesCHA(datFromDate, datToDate, CompBrSNo,CHASNo);
        }


        public DataSet getAllCHAChargesNew1(DateTime datFromDate, DateTime datToDate, string CompBrSNo)
        {
            return DReport.getAllCHAChargesNew1(datFromDate, datToDate, CompBrSNo);
        }
        public DataSet getAllCHAChargesNew10(DateTime datFromDate, DateTime datToDate, string CHA, string CompBrSNo)
        {
            return DReport.getAllCHAChargesNew10(datFromDate, datToDate, CHA, CompBrSNo);
        }
        public DataSet ShippingBillNo_Select_MAWB(string MAWB)
        {
            return DReport.ShippingBillNo_Select_MAWB(MAWB);
        }
        public DataSet getChargewiseDetails(DateTime datFromDate, DateTime datToDate, string CompBrSNo,string ChargeId,string CHA)
        {
            return DReport.getChargewiseDetails(datFromDate, datToDate, CompBrSNo,ChargeId,CHA );
        }

        public DataSet getAllCHABills(DateTime datFromDate, DateTime datToDate, string CompBrSNo, int CHASno)
        {
            return DReport.getAllCHABills(datFromDate, datToDate, CompBrSNo,CHASno);
        }
        public DataSet getAllRFBVSBillCharge(DateTime datFromDate, DateTime datToDate, string  CompBrSNo,string Type)
        {
            return DReport.getAllRFBVSBillCharge(datFromDate, datToDate, CompBrSNo, Type);
        }
        public DataSet GetCM1ActualProfit(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            return DReport.GetCM1ActualProfit(CompBrSno1, FromDate, ToDate, MAWBNO);
        }
        public DataSet GetCM1OverallProfit(int CompBrSno1, DateTime FromDate, DateTime ToDate,string Type,string city)
        {
            return DReport.GetCM1OverallProfit(CompBrSno1, FromDate, ToDate,Type, city);
        }
        public DataSet GetCM1ActualProfitImp(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            return DReport.GetCM1ActualProfitImp(CompBrSno1, FromDate, ToDate, MAWBNO);
        }
        public DataSet GetCM1ActualProfitSeaImp(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            return DReport.GetCM1ActualProfitSeaImp(CompBrSno1, FromDate, ToDate, MAWBNO);
        }
        public DataSet GetCM1ActualProfitSeaExp(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            return DReport.GetCM1ActualProfitSeaExp(CompBrSno1, FromDate, ToDate, MAWBNO);
        }
        public DataSet getPNPsellingCM1profit(int CompBrSno, string MAWBNO,string HAWB, string Type)
        {
            return DReport.getPNPsellingCM1profit(CompBrSno, MAWBNO, HAWB,Type);
        }
        public DataSet getSeaGroups(DateTime fromDate, DateTime toDate, string CompBrSNo, string Type,string CustType)
        {
            return DReport.getSeaGroups(fromDate, toDate, CompBrSNo, Type,CustType);
        }
        public DataSet getSeaReportNone(DateTime fromDate, DateTime toDate, string CompBrSNo,string Type)
        {
            return DReport.getSeaReportNone(fromDate, toDate, CompBrSNo,Type);
        }
        public DataSet getSeaProductwiseReport(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group,string Type)
        {
            return DReport.getSeaProductwiseReport(fromDate, toDate, CompBrSNo, Group,Type  );
        }
        public DataSet getSeaPersonwiseReport(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            return DReport.getSeaPersonwiseReport(fromDate, toDate, CompBrSNo, Group,Type);
        }
        public DataSet getSeaReportOriginwise(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            return DReport.getSeaReportOriginwise(fromDate, toDate, CompBrSNo, Group, Type);
        }
        public DataSet getSeaReportDestwise(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            return DReport.getSeaReportDestwise(fromDate, toDate, CompBrSNo, Group, Type);
        }
        public DataSet getSeaCM1Report(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            return DReport.getSeaCM1Report(fromDate, toDate, CompBrSNo, Group, Type);
        }
        public DataSet getSeaReportSmallShptwise(DateTime fromDate, DateTime toDate, string CompBrSNo, string Type)
        {
            return DReport.getSeaReportSmallShptwise(fromDate, toDate, CompBrSNo,Type);
        }
        public DataSet GetCustomer_PartywiseRpt(int CompBrSno, DateTime fromDate, DateTime toDate)
        {
            return DReport.GetCustomer_PartywiseRpt(CompBrSno, fromDate, toDate);
        }
        public DataSet GetGroupsForCM1Report(DateTime FromDate, DateTime ToDate, string CompBrSNo, string GroupBy, string Type)
        {
            return DReport.GetGroupsForCM1Report(FromDate, ToDate, CompBrSNo, GroupBy, Type);
        }
        public DataSet getGroupsImports(DateTime fromDate, DateTime toDate, string CompBrSNo, string Type)
        {
            return DReport.getGroupsImports(fromDate, toDate, CompBrSNo, Type);
        }
        public DataSet GetOutstandingCustomers(DateTime Date,string CompBrSNo,string Type)
        {
            return DReport.GetOutstandingCustomers(Date, CompBrSNo,Type);
        }
        public SqlDataReader getLogindetail(string UserId)
        {
            return DReport.getLogindetail(UserId);
        }
        public DataSet getLogindetailNew(string UserId)
        {
            return DReport.getLogindetailNew(UserId);
        }
        public DataSet GetCustomer_PartywiseRpt(int CompBrSno, DateTime fromDate, DateTime toDate, string Type)
        {
            return DReport.GetCustomer_PartywiseRpt(CompBrSno, fromDate, toDate, Type);
        }
        public DataSet ClientwisePaymentPerformanceRpt(string strCompBrSNo, string CustBrSno, string CustType, string strType, DateTime datFromDate, DateTime datToDate)
        {
            return DReport.ClientwisePaymentPerformanceRpt(strCompBrSNo, CustBrSno, CustType, strType, datFromDate, datToDate);
        }
        public DataSet GetAllCM1Report(DateTime FromDate, DateTime Todate, string CompBrSno, string GroupBy, string GroupByName, string Type, string Report)
        {
            return DReport.GetAllCM1Report(FromDate, Todate, CompBrSno, GroupBy, GroupByName, Type, Report);
        }
        public DataSet getProductReportNew(DateTime FromDate, DateTime Todate, string CompBrSno, string Type, string Product, string Fair)
        {
            return DReport.getProductReportNew(FromDate, Todate, CompBrSno, Type, Product, Fair);
        }

        public DataSet getCM1(DateTime FromDate, DateTime Todate, string CompBrSno, string GroupBy, string GroupByName, string Type)
        {
            return DReport.getCM1(FromDate, Todate, CompBrSno, GroupBy, GroupByName, Type);
        }
        public DataSet GetCustomerDetailForMail(string Sno,string UserID)
        {
            return DReport.GetCustomerDetailForMail(Sno,UserID);
        }
        // For Pending DO Report
        public DataSet GetPendingDO(DateTime fromDate,DateTime toDate,string CompBrSno,string Type)
        {
            return DReport.GetPendingDO(fromDate, toDate, CompBrSno,Type);
        }
        // For Approved/Unapproved/NotTransfertoTally Invoices
        public DataSet getInvoicesApprovedUnapproved(DateTime fromDate, DateTime toDate, string transferToTally, string completed, string compBrSno, string type)
        {
            return DReport.getInvoicesApprovedUnapproved(fromDate, toDate, transferToTally, completed, compBrSno, type);
        }
        public DataSet getPayableReceivableCustomers(DateTime fromDate, DateTime toDate, string type, string source, string paymentType, string company)
        {
            return DReport.getPayableReceivableCustomers(fromDate, toDate,type,source,paymentType,company);
        }
        public DataSet GetPayableReceivableBills(DateTime fromDate, DateTime toDate, string type, string source, string paymentType, string company,string customerName)
        {
            return DReport.GetPayableReceivableBills(fromDate, toDate, type, source, paymentType, company,customerName);
        }
        //Get ServiceTax Report
        public DataSet GetServiceTaxReport(DateTime fromDate, DateTime toDate, string CompBrSno, string type, string groupBy)
        {
            return DReport.GetServiceTaxReport(fromDate, toDate,CompBrSno,type,groupBy );
        }
        //Get Pending Bills Report
        public DataSet GetPendingBillsReport(DateTime fromDate, DateTime toDate, string type, string CompBrSno)
        {
            return DReport.GetPendingBillsReport(fromDate, toDate,type,CompBrSno);
        }
        // Get Invoicewise Profitability Report
        public DataSet GetInvoicewiseProfitabilityReport(DateTime fromDate, DateTime toDate, int customerBranchSno,string type,string customerType, string companyBranchSno)
        {
            return DReport.GetInvoicewiseProfitabilityReport(fromDate, toDate, customerBranchSno,type,customerType,companyBranchSno);
        }
        //Check Cr Limit for ManagePace
        public DataSet CreditLimitCheck()
        {
            return DReport.CreditLimitCheck();   
        }
        //Update Cr Limit for ManagePace
        public string updateManagePaceCreditLimit(int customerMasterSno,decimal groupCreditLimit,decimal groupUsedCreditLimit,decimal groupAvailableCreditLimit)
        {
            return DReport.updateManagePaceCreditLimit(customerMasterSno, groupCreditLimit, groupUsedCreditLimit, groupAvailableCreditLimit);
        }

        public string UpdateStockMasterSearch(int SNo, string ReceivedFrom, DateTime ReceivedDate,string AirlineType)
        {
            return DReport.UpdateStockMasterSearch(SNo, ReceivedFrom, ReceivedDate,AirlineType);
        }

        public string updateBillDate(int Sno, DateTime BillDate, DateTime InvoiceDueDate)
        {
            return DReport.updateBillDate(Sno, BillDate, InvoiceDueDate);
        }

        public DataSet getCompanyName()
        {
            return DReport.getCompanyName();   
        }
        //Disapprove Bill for ManagePace
        public DataSet BillDisapproveSelect(int SNo,string MawbNo,string InvoiceNo)
        {
            return DReport.BillDisapproveSelect(SNo,MawbNo,InvoiceNo);
        }

        public DataSet AirExport_Mawb(Int64 CompBrSno, string Date)
        {
            return DReport.AirExport_Mawb(CompBrSno, Date);
        }

        public DataSet AirExport_Hawb(Int64 CompBrSno, string Date)
        {
            return DReport.AirExport_Hawb(CompBrSno, Date);
        }

        public DataSet AirExport_MawbI(Int64 CompBrSno, string Date1)
        {
            return DReport.AirExport_MawbI(CompBrSno, Date1);
        }

        public DataSet AirExport_HawbI(Int64 CompBrSno, string Date1)
        {
            return DReport.AirExport_HawbI(CompBrSno, Date1);
        }
        public DataSet BillDateSelect(int SNo, string MawbNo, string InvoiceNo)
        {
            return DReport.BillDateSelect(SNo, MawbNo, InvoiceNo);
        }

        public DataSet Can_Do_Select(int SNo, string MawbNo)
        {
            return DReport.Can_Do_Select(SNo, MawbNo);
        }

        public string Can_Do_Update(int Sno)
        {
            return DReport.Can_Do_Update(Sno);
        }
       
        public string BillDisapproved(int SNo)
        {
            return DReport.BillDisapproved(SNo);
        }
        public DataSet getAdditionalExpenses(string MawbNo,string InvoiceNo)
        {
            return DReport.getAdditionalExpenses(MawbNo,InvoiceNo);
        }
        public DataSet getAirlineDebitNote(DateTime fromDate, DateTime toDate, string CompBrSno, string AirlineCode,string Type)
        {
            return DReport.getAirlineDebitNote(fromDate,toDate,CompBrSno,AirlineCode,Type);
        }
        public DataSet getAllAWBForDebitNote(DateTime fromDate, DateTime toDate, string CompBrSno)
        {
            return DReport.getAllAWBForDebitNote(fromDate, toDate, CompBrSno);
        }
        public DataSet getSubAgentCSR(DateTime fromDate, DateTime toDate, string CompBrSno, string subAgentSno, string subAgentCSRStatus)
        {
            return DReport.getSubAgentCSR(fromDate, toDate, CompBrSno, subAgentSno, subAgentCSRStatus);
        }
        public DataSet getMawbForCSR(DateTime fromDate, DateTime toDate, string CompBrSno, string subAgentSno, string subAgentCSRStatus)
        {
            return DReport.getMawbForCSR(fromDate, toDate, CompBrSno, subAgentSno, subAgentCSRStatus);
        }
        public DataSet getAirlineCSR(DateTime fromDate, DateTime toDate, string CompBrSno, string Airline, string airlineCSRStatus,string type)
        {
            return DReport.getAirlineCSR(fromDate, toDate, CompBrSno, Airline, airlineCSRStatus,type);
        }
        public DataSet getInvoiceNoAndCM1ForAirlineCSR(string MAWB,string CompBrSno)
        {
            return DReport.getInvoiceNoAndCM1ForAirlineCSR(MAWB,CompBrSno);
        }
        public string generateSubAgentCSR(DateTime fromDate, DateTime toDate, int CompBrSno,  int subAgentSno, string generatedBy)
        {
            return DReport.generateSubAgentCSR(fromDate, toDate, CompBrSno, subAgentSno,generatedBy);
        }
        public string generateAirlineCSR(string generatedBy, DateTime fromDate, DateTime toDate, int AWBTableSno, string CompBrSno)
        {
            return DReport.generateAirlineCSR(generatedBy,fromDate, toDate,AWBTableSno,  CompBrSno);
        }
        public DataSet getAirlineDebitNoteView(string AirlineCode, string DebitNoteNo,string Type)
        {
            return DReport.getAirlineDebitNoteView(AirlineCode, DebitNoteNo,Type);
        }
        public DataSet getAirlineCodeForDebitNote(DateTime fromDate, DateTime toDate, int CompBrSno)
        {
            return DReport.getAirlineCodeForDebitNote(fromDate, toDate, CompBrSno);
        }
        public string AdditionalExpSubmitted(int tSNo, string Inv, DateTime InvDate, string MarkpaidBy)
        {
            return DReport.AdditionalExpSubmitted( tSNo,Inv,InvDate,MarkpaidBy);
        }
        public string AdditionalExpSubmittedAir(int tSNo, string Remarks, string Inv, DateTime InvDate,DateTime InvReceiveDate, string MarkpaidBy)
        {
            return DReport.AdditionalExpSubmittedAir(tSNo, Remarks, Inv, InvDate,InvReceiveDate, MarkpaidBy);
        }
        public string AdditionalExpSubmittedRI(int MasterSNo)
        {
            return DReport.AdditionalExpSubmittedRI(MasterSNo);
        }
        public string AdditionalExpSubmittedRIAir(int MasterSNo, string Remarks, string Inv, DateTime InvDate, DateTime InvReceiveDate)
        {
            return DReport.AdditionalExpSubmittedRIAir(MasterSNo, Remarks,Inv,InvDate,InvReceiveDate);
        }
        public string updateAWBForAirlineDebitNote(int AwbSno, int CompBrSno, string AirlineDebitNoteNo, string DebitNoteStatus, DateTime DebitNoteDate, string DebitNoteCreatedBy, DateTime DebitNoteFromDate, DateTime DebitNoteToDate)
        {
            return DReport.updateAWBForAirlineDebitNote(AwbSno,CompBrSno,AirlineDebitNoteNo,DebitNoteStatus,DebitNoteDate,DebitNoteCreatedBy,DebitNoteFromDate,DebitNoteToDate);
        }
        public DataSet getMaxAirlineDebitNoteNo(string AirlineDebitNoteNo)
        {
            return DReport.getMaxAirlineDebitNoteNo(AirlineDebitNoteNo);
        }
         // generate CM1--update billing_trans
        //public string generateCM1(string BMSno, string userID, DateTime fromDate, DateTime toDate)
        //{
        //    return DReport.generateCM1(BMSno, userID, fromDate, toDate);
        //}
        public string generateCM1(string BMSno, string userID,string CompBrSno, string Type, DateTime fromDate, DateTime toDate)
        {
            return DReport.generateCM1(BMSno, userID, CompBrSno, Type, fromDate, toDate);
        }
        public int ChangeStatusActual(int tSNo, string inv, DateTime invDate, string description)
        {
            return DReport.ChangeStatusActual(tSNo,inv,invDate,description);
        }
        public string UpdateCharge(int tSNo, string Remarks, string Inv, DateTime InvDate, DateTime InvReceiveDate)
        {
            return DReport.UpdateCharge(tSNo, Remarks, Inv, InvDate,InvReceiveDate);
        }
        public string UpdateRI(int MasterSNo, string Remarks, string Inv, DateTime InvDate, DateTime InvReceiveDate)
        {
            return DReport.UpdateRI(MasterSNo, Remarks,Inv,InvDate,InvReceiveDate);
        }

        public DataSet GetAirExportTonnage(DateTime fromDate, DateTime toDate, string CompBrSNo, string Airline, string Destination)
        {
            return DReport.GetAirExportTonnage(fromDate, toDate, CompBrSNo, Airline, Destination);
        }

        public DataSet getAccountReview(DateTime fromDate, DateTime toDate, string customerBranchSno, string TypeName, string CompBrSNo)
        {
            return DReport.getAccountReview(fromDate, toDate, customerBranchSno, TypeName, CompBrSNo);
        }

        public DataSet getVendorJEView(DateTime fromDate, DateTime toDate, string customerBranchSno, string TypeName, string CompBrSNo,string ExpType)
        {
            return DReport.getVendorJEView(fromDate, toDate, customerBranchSno, TypeName, CompBrSNo,ExpType);
        }

        public string insertCSRData(int AWBTableSno, int BookingSno, string BMSno, DateTime AWBDate, string freightType, string origin, string destination,
decimal weight, decimal rate, decimal PPCC, decimal AWBFee, decimal HAWBFee, decimal OSC, decimal DA, decimal DC, decimal TotalPP, decimal commAmt, decimal commRate, decimal spotAmt, decimal spotRate, decimal incAmt, decimal incRate, decimal tdsAmt, decimal tdsRate, decimal TC, decimal doorDel, decimal clearance, decimal others, decimal staxAmt, decimal totalDueAmt, int compBrSno, string paymentTableSno, decimal paymentAmt, string MAWB, string CSR, string CustBrSno, string fortNight)
        {
            return DReport.insertCSRData(AWBTableSno, BookingSno, BMSno, AWBDate, freightType, origin, destination, weight, rate, PPCC, AWBFee, HAWBFee, OSC, DA, DC, TotalPP, commAmt, commRate, spotAmt, spotRate, incAmt, incRate, tdsAmt, tdsRate, TC, doorDel, clearance, others, staxAmt, totalDueAmt, compBrSno, paymentTableSno, paymentAmt,MAWB,CSR,CustBrSno,fortNight);
        }
        public int MOTDataEntry(int bankMastSno, string DDNo, DateTime DDDate, decimal Amount, string PayTo, string AddedBy, DateTime AddedDate)
        {
            return DReport.MOTDataEntry(bankMastSno, DDNo, DDDate, Amount, PayTo, AddedBy, AddedDate);
        }
        public DataSet InsertCHAChargeAWB(string Mawbno, int BookingID, string Origin, string Destination, string Currency, int AgentSNo, int ShipperSNo, int ConsigneeSNo, string ShipperUsedBy, string ShipmentType, string FreightType, decimal ChargeableWt, decimal CWtCharges, decimal CValCharges, decimal CTotalDueAgent, decimal CTotalDueCarrier, decimal CTotal, string ShipperSign, DateTime AWBDate, string CarrierSign, DateTime HandOverDate, int CompBrSNo, string AddedBy, DateTime AddedDate, string BillType, string ShipperUsedByCity, string WTCC, string OtherCC, string WTPP, string OtherPP, int CHASNO, string CopyToBaseCompany)
        {
            return DReport.InsertCHAChargeAWB(Mawbno, BookingID, Origin, Destination, Currency, AgentSNo, ShipperSNo, ConsigneeSNo, ShipperUsedBy, ShipmentType, FreightType, ChargeableWt, CWtCharges, CValCharges, CTotalDueAgent, CTotalDueCarrier, CTotal, ShipperSign, AWBDate, CarrierSign, HandOverDate, CompBrSNo, AddedBy, AddedDate, BillType, ShipperUsedByCity, WTCC, OtherCC, WTPP, OtherPP, CHASNO, CopyToBaseCompany);
        }
        public DataSet GetCheque()
        {
            return DReport.GetCheque();
        }
        public DataSet getDetailsOfOutstandingCustomers(string compBrSno, string type)
        {
            return DReport.getDetailsOfOutstandingCustomers(compBrSno,type);
        }
        public DataSet getOverdueDays(int custBrSno, string compBrSno, string type)
        {
            return DReport.getOverdueDays(custBrSno, compBrSno, type);
        }
        public DataSet getAllTerminalCharges(DateTime fromDate, DateTime Todate, string MAWBNo, string HAWBNo, string TransactionNo)
        {
            return DReport.getAllTerminalCharges(fromDate, Todate, MAWBNo, HAWBNo, TransactionNo);
        }


        public DataSet getTerminalChargeDetails(DateTime fromDate, DateTime toDate, string strCity, int strChargeId)
        {
            return DReport.getTerminalChargeDetails(fromDate, toDate, strCity, strChargeId);
        }
        public DataSet GetShipmentLoss(DateTime fromDate, DateTime toDate, string CompBrSno, string reportType)
        {
            return DReport.GetShipmentLoss(fromDate, toDate, CompBrSno, reportType);
        }
        public DataSet GetPartyWiseIncome(DateTime fromDate, DateTime toDate, string customerBranchSno, string TypeName, string CompBrSNo)
        {
            return DReport.GetPartyWiseIncome(fromDate, toDate, customerBranchSno, TypeName, CompBrSNo);
        }
        public DataSet getBookingMail(DateTime fromDate, DateTime toDate, string CompBrSNo)
        {
            return DReport.getBookingMail(fromDate, toDate, CompBrSNo);
        }
        public DataSet getDataInternatiopnalBizReport(string fromDate, string toDate, string networkName, string top, string CompBrSNo)
        {
            return DReport.getDataInternatiopnalBizReport(fromDate, toDate, networkName, top, CompBrSNo);
        }
        public DataSet getBillsForCompletion(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForCompletion(fromDate, toDate, type, CompBrSNo, billType);
        }

        public DataSet getBillsForCompletionTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForCompletionTaxable(fromDate, toDate, type, CompBrSNo, billType);
        }
        public DataSet getBillsForCompletionNonTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForCompletionNonTaxable(fromDate, toDate, type, CompBrSNo, billType);
        }
        public DataSet getBillsForCompletionNonTaxableCD(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForCompletionNonTaxableCD(fromDate, toDate, type, CompBrSNo, billType);
        }
        public DataSet getBillsForCompletionGST(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForCompletionGST(fromDate, toDate, type, CompBrSNo, billType);
        }
        public DataSet getBillsForTallyTransfer(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForTallyTransfer(fromDate, toDate, type, CompBrSNo, billType);
        }

        public DataSet getBillsForTallyTransferTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForTallyTransferTaxable(fromDate, toDate, type, CompBrSNo, billType);
        }
        public DataSet getBillsForTallyTransferNonTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForTallyTransferNonTaxable(fromDate, toDate, type, CompBrSNo, billType);
        }
        public DataSet getBillsForTallyTransferNonTaxableCD(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForTallyTransferNonTaxableCD(fromDate, toDate, type, CompBrSNo, billType);
        }
        public DataSet getBillsForTallyTransferGST(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            return DReport.getBillsForTallyTransferGST(fromDate, toDate, type, CompBrSNo, billType);
        }
        public string updateBillCompleted(string BMSno, string updatedBy, string updatedType,DateTime tallyDate)
        {
            return DReport.updateBillCompleted(BMSno, updatedBy, updatedType,tallyDate);
        }
        public string updateBillCompleted_T(string BMSno, string updatedBy, string updatedType, DateTime tallyDate)
        {
            return DReport.updateBillCompleted_T(BMSno, updatedBy, updatedType, tallyDate);
        }
        public string updateBillCompleted_NT(string BMSno, string updatedBy, string updatedType, DateTime tallyDate)
        {
            return DReport.updateBillCompleted_NT(BMSno, updatedBy, updatedType, tallyDate);
        }

        public string updateBillCompleted_NTCD(string BMSno, string updatedBy, string updatedType, DateTime tallyDate)
        {
            return DReport.updateBillCompleted_NTCD(BMSno, updatedBy, updatedType, tallyDate);
        }
        public DataSet getBillsForTally(string bmSno)
        {
            return DReport.getBillsForTally(bmSno);
        }
        public DataSet getBillsForTallyTaxable(string bmSno)
        {
            return DReport.getBillsForTallyTaxable(bmSno);
        }
        public DataSet getBillsForTallyNonTaxable(string bmSno)
        {
            return DReport.getBillsForTallyNonTaxable(bmSno);
        }

        public DataSet getBillsForTallyNonTaxableCD(string bmSno)
        {
            return DReport.getBillsForTallyNonTaxableCD(bmSno);
        }
        public DataSet GetCustomerType(int CusSNo, string CustNetType)
        {
            return DReport.GetCustomerType(CusSNo, CustNetType);
        }
        public DataSet getHeadNameForTally(string whereCondition)
        {
            return DReport.getHeadNameForTally(whereCondition);
        }
        public string updateTallyHeadName(int Sno, string taxable, string display, string type, string ExpTallyHeadName, string ImpTallyHeadName, string SeaExpTallyHeadName, string SeaImpTallyHeadName)
        {
            return DReport.updateTallyHeadName(Sno, taxable, display, type, ExpTallyHeadName, ImpTallyHeadName, SeaExpTallyHeadName, SeaImpTallyHeadName);
        }
        public string insertCreditLimitUses(int custMastSno, int custBrSno, int compBrSno, string transactionType, decimal amount, decimal creditLimit, decimal usedCrLimitBeforeTransaction, decimal usedCrLimitAfterTransaction, decimal availableCrLimitBeforeTransaction, decimal availableCrLimitAfterTransaction, string creditType, string updatedBy, int bookingSno, int billingSno, int paymentTransSno, int paymentMastSno)
        {
            return DReport.insertCreditLimitUses(custMastSno, custBrSno, compBrSno, transactionType, amount, creditLimit, usedCrLimitBeforeTransaction, usedCrLimitAfterTransaction, availableCrLimitBeforeTransaction, availableCrLimitAfterTransaction, creditType, updatedBy, bookingSno, billingSno, paymentTransSno, paymentMastSno);
        }
        public DataSet getLocalOverseasCustomer(string CustomerCodeType, int compBrSno)
        {
            return DReport.LocalOverseasCustomer(CustomerCodeType,compBrSno);
        }
        public DataSet getSEACostSheet(int SEABLSno, string blType)
        {
            return DReport.getSEACostSheet(SEABLSno, blType);
        }

        public DataSet GetCM1JEWise(DateTime fromDate,DateTime toDate, string CompBrSno, string reportType)
        {
            return DReport.GetCM1JEWise(fromDate, toDate, CompBrSno, reportType);
        }


        public DataSet GetDSRWeekMail(DateTime DSTDate)
        {
            return DReport.GetDSRWeekMail(DSTDate);
        }


        public DataSet GetDSRSalesPerson()
        {
            return DReport.GetDSRSalesPerson();
        }

        public DataSet GetWSRWeekMail(DateTime WSRDate, int CustSNo)
        {
            return DReport.GetWSRWeekMail(WSRDate, CustSNo);
        }

        public DataSet getAwbDetail(int AwbSno,string Type)
        {
            return DReport.getAwbDetail(AwbSno, Type);
        }

        public DataSet getAWBPDFDetail(int AWBSno)
        {
            return DReport.getAWBPDFDetail(AWBSno);
        }
    }
}
