﻿using System;
using System.Collections.Generic;

using System.Text;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;
using System.Data;
using System.Data.SqlClient;
namespace Cfi.App.Pace.Business
{
    public class BCHA:ICHA
    {
       #region Variable

        Int32 _CHAChargeSno;
        Int32 _ChargeId;
        String _Remark;
        Decimal _Amount;

        String _CHAName;
        String _HouseNo;
        String _WebSite;
        String  _CompBrSNo;       
        String _Login_Id;
        String _LoginUser;     
        String _Password;
        String _Street;
        String _Place;
        String _City;
        String _State;
        String _CountryCode;
        String _PostCode;
        String _Phone;
        String _MobileNo;
        String _FAX;
        String _Email;
        String _PANNo;       
        String _EnteredBy;
        String _Active;

        String _UserName;
        String _DisplayName;
        String _UserGroup;
        String _EmailID;      
        String _BrSno;
        String _Sno;
        String _CHASno;


        Int32 _BookRefNo;
        String _AppRemark;
        Decimal _TotalAmt;
        String _Status;
        Decimal _GrandTotal;
        DateTime _BookingDate;
        DateTime _AWBDate;
       
       #endregion
       public BCHA()
       { }
        #region Property

       public Decimal GrandTotal
       {
           get { return _GrandTotal; }

           set { _GrandTotal = value; }

       }
       public Int32 CHAChargeSno
       {
           get { return _CHAChargeSno; }

           set { _CHAChargeSno = value; }
       }
       public Int32 ChargeId
       {
           get { return _ChargeId; }

           set { _ChargeId = value; }
       }
       public String Remark
       {
           get { return _Remark; }

           set { _Remark = value; }
       }
       public Decimal Amount
       {
           get { return _Amount; }

           set { _Amount = value; }
       }
        
        public String EmailID
        {
            get { return _EmailID; }

            set { _EmailID = value; }
        }
        public String CHASno
        {
            get { return _CHASno; }

            set { _CHASno = value; } 
        }
        public String UserName
        { 
            get{return _UserName;}

            set { _UserName = value; }
        }
        public String DisplayName
        {
            get { return _DisplayName; }
            set { _DisplayName = value; }
        }
        public String UserGroup 
        {
            get { return _UserGroup; }
            set { _UserGroup = value; }
        }
             
        public String BrSno
        {
            get { return _BrSno; }
            set { _BrSno = value; }
        }
        public String Sno 
        {
            get { return _Sno; }
            set { _Sno = value; }
        }
       public  String HouseNo
       {
           get { return _HouseNo; }
           set { _HouseNo = value; }
       }
       public  String WebSite
       {
           get { return _WebSite; }
           set { _WebSite = value; }
       }
       public String CHAName
        {
            get { return _CHAName; }
            set { _CHAName = value; }
        }
        public String CompBrSNo
       {
           get { return _CompBrSNo; }
           set { _CompBrSNo = value; }
       }
       public String LoginUser
       {
           get { return _LoginUser; }
           set { _LoginUser = value; }
       }
       public String Login_Id
       {
           get { return _Login_Id; }
           set { _Login_Id = value; }
       }
       public String Password
       {
           get { return _Password; }
           set { _Password = value; }
       }      
       public String Street
       {
           get { return _Street; }
           set { _Street = value; }
       }
       public String Place
       {
           get { return _Place; }
           set { _Place = value; }
       }
       public String City
       {
           get { return _City; }
           set { _City = value; }
       }
       public String State
       {
           get { return _State; }
           set { _State = value; }
       }
       public String CountryCode
       {
           get { return _CountryCode; }
           set { _CountryCode = value; }
       }
       public String PostCode
       {
           get { return _PostCode;  }
           set { _PostCode = value; }
       }
       public String Phone
       {
           get { return _Phone; }
           set { _Phone = value; }
       }
       public String MobileNo
       {
           get { return _MobileNo; }
           set { _MobileNo = value; }
       }
       public String FAX
       {
           get { return _FAX; }
           set { _FAX = value; }
       }
       public String Email
       {
           get { return _Email; }
           set { _Email = value; }
       }
       public String PANNo
       {
           get { return _PANNo; }
           set { _PANNo = value; }
       }       
       public String EnteredBy
       {
           get { return _EnteredBy; }
           set { _EnteredBy = value; }
       }
       public String Active
       {
           get { return _Active; }
           set { _Active = value; }
       }


       public Int32 BookRefNo
       {
           get { return _BookRefNo; }
           set { _BookRefNo = value; }
       }
       public String AppRemark
       {
           get { return _AppRemark; }
           set { _AppRemark = value; }
       }
       public Decimal TotalAmt
       {
           get { return _TotalAmt; }
           set { _TotalAmt = value; }
       } 
      
       public String Status
       {
           get { return _Status; }
           set { _Status = value; }
       }
       public DateTime  BookingDate
       {
           get { return _BookingDate; }

           set { _BookingDate = value; }

       }
       public DateTime AWBDate
       {
           get { return _AWBDate; }
           set{_AWBDate =value; }
       }
        #endregion
       

       public String Insert_CHADetails()
       {
           return DCHA.Insert_CHADetails(this);           
       }
       public SqlDataReader GetCHA_Details(Int32 Sno)
       {
           return DCHA.GetCHA_Details(Sno);
       }
       public String Update_CHADetails(Int32 Sno)
       {
         return DCHA.Update_CHADetails(this, Sno);
       }

       public string Delete_CHADetails(Int32 Sno)
       {
           return DCHA.Delete_CHADetails(this, Sno);
       }
       public SqlDataReader CHADetails_Show()
       {
           return DCHA.CHADetails_Show();
       }
       public SqlDataReader CompDet_CHADet_Show(Int32 Sno)
       {
           return DCHA.CompDet_CHADet_Show(Sno);
       }
       public String login_CreateCHAUser()
       {
           return DCHA.login_CreateCHAUser(this);
       }
       public SqlDataReader CHAUserLogin_Show(Int32 Sno)
       {
           return DCHA.CHAUserLogin_Show(Sno);
       }
       public String login_UpdateCHAUser()
       {
           return DCHA.login_UpdateCHAUser(this);
       }
       public DataSet CHAChargesShow()
       {
           return DCHA.CHAChargesShow();

       }
       public DataSet GetCHABookinShip_Count(Int32 BookiingRefSno)
       {
           return DCHA.GetCHABookinShip_Count(BookiingRefSno);

       }    
   
          

       public String Insert_CHACharges()
       {
           return DCHA.Insert_CHACharges(this);
       }
       //public String Insert_CHACharges2(string mawb, int combrson, decimal chwt)
       //{
       //    return DCHA.Insert_CHACharges2(this, mawb, combrson, chwt);
       //}
       public DataSet Insert_CHACharges2(string mawb, int combrson, decimal chwt, int AwbSno, int CHASNO, int AwbSnoBComp, int bookingIdBComp, string CopyToBaseCompany)
       {
           return DCHA.Insert_CHACharges2(this, mawb, combrson, chwt, AwbSno, CHASNO, AwbSnoBComp, bookingIdBComp, CopyToBaseCompany);
       }
       public String Update_CHACharges()
       {
           return DCHA.Update_CHACharges(this);
       }
       public String Insert_CHAChargesTrans(decimal Rate, int NoOfItem)
       {
           return DCHA.Insert_CHAChargesTrans(this,Rate,NoOfItem);
       }
       public String Insert_CHAChargesTrans2(decimal rate, decimal noitem, int CHAChargeSnoBComp,string CopyToBaseCompany)
       {
           return DCHA.Insert_CHAChargesTrans2(this, rate, noitem, CHAChargeSnoBComp, CopyToBaseCompany);
       }
       public String InsertUpdate_CHAChargesTrans()
       {
           return DCHA.InsertUpdate_CHAChargesTrans(this);
       }        
       public String CHAChargesShowByBookRef()
       {
           return DCHA.CHAChargesShowByBookRef(this);
       }
       public DataSet SelectChargeTransByChargeId2()
       {
           return DCHA.SelectChargeTransByChargeId2(this);

       }
       public DataSet BookingConfirmedShow()
       {
           return DCHA.BookingConfirmedShow(this);

       }
       public  DataSet BookingDetail()
       {
           return DCHA.BookingDetail(this);
       }
       public DataSet Awbdetail()
       {
           return DCHA.Awbdetail(this);
       }
       public DataSet getChargeAmount(int SNo, int CompBrSNo)
       {
           return DCHA.getChargeAmount(SNo, CompBrSNo);
       }

       public SqlDataReader GetCountryName(string Countrid)
       {
           return DCHA.GetCountryName(Countrid);
       }

       public DataSet getGSPChargeAmount(int SNo, int CompBrSNo)
       {
           return DCHA.getGSPChargeAmount(SNo, CompBrSNo);
       }
    }
   
}
