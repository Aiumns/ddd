﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;
using Cfi.App.Pace.Common;

namespace Cfi.App.Pace.Business
{
    public class BLLogin : ILogin
    {
        private Int32 _Lsno;
        private String _LoginId;
        private String _Name;
        private String _Password;
        private String _loginType;
        private String _CityName;
        private String _Active;
        private String _RemoteHostName;
        private String _RemoteIPAddress;
        private String _LocalIPAddress;
        private String _GroupName;
        private String _Email;
        private String _Companysno;
        private byte[] _passwordLogin;
        private Int32 _ChaName;
        private String _CompanyName;
        byte[] _Signature;
        private String _OpType;


        public BLLogin()
        {
        }
        public void EditLoginDetail(Int32 strL)
        {
            SqlDataReader dr = DLLogin.RetrieveLoginDetail(strL);
            if (dr.Read())
            {
                LoginId = dr["loginid"].ToString();
                Name = dr["Displayname"].ToString();
                loginType = dr["logintype"].ToString();
                CityName = dr["city"].ToString();
            }
        }

        public void RetrieveUserDetail()
        {
            SqlDataReader dr = DLLogin.RetrieveUserDetail(this);
            if (dr.Read())
            {
                LoginId = dr["loginID"].ToString();
                Name = dr["DisplayName"].ToString();
                loginType = dr["logintype"].ToString();
                CityName = dr["City"].ToString();
            }
        }

        public String UpdatePass(String userID, String Password, String newPassword)
        {
            return DLLogin.UpdatePass(userID, Password, newPassword);
        }

        public String mailPass(String userID)
        {
            return DLLogin.mailPass(userID);
        }

        public String AddLogin()
        {
            return DLLogin.InsertAdminLogin(this);
        }
        public String AddLoginModified()
        {
            return DLLogin.InsertAdminLoginModified(this);
        }

        public String ReturnName(String strSeesionID)
        {
            return DLLogin.ReturnName(strSeesionID);
        }

        public String Login()
        {
            return DLLogin.Login(this);
        }

        public DataSet BindLoginType()
        {
            return DLLogin.RetrieveLoginType();
        }

        public DataSet getCompany()
        {
            return DLLogin.getcompany();
        }

        public DataSet getCustBranchBySNo(int CustBrSNo)
        {
            return DLLogin.getCustBranchBySNo(CustBrSNo);
        }

        public DataSet getSubAgent(int CompBrSNo)
        {
            return DLLogin.getSubAgent(CompBrSNo);
        }


        public DataSet getOriginalComp(string CompBrSNo)
        {
            return DLLogin.getOriginalComp(CompBrSNo);
        }

        public String UpdateAdminLoginDetail()
        {
            return DLLogin.UpdateAdminLogin(this);
        }
        public String UpdateAdminLoginDetailModified(Int32 Sno)
        {
            return DLLogin.UpdateAdminLoginModified(this, Sno);
        }

        public String DeleteLooginDetail()
        {
            return DLLogin.DeleteLoginDetail(this);
        }
        public string Deletemodified(Int32 Sno)
        {
            return DLLogin.DeleteModified1(this, Sno);
        }


        public String getCompType(string compBrSno)
        {
            return DLLogin.getCompType(compBrSno);
        }
        public String getCompTypeNew(string compBrSno)
        {
            return DLLogin.getCompTypeNew(compBrSno);
        }
        public String getCompInvoicePrefix(string compBrSno)
        {
            return DLLogin.getCompInvoicePrefix(compBrSno);
        }
        public DataSet getCompanyName()
        {
            return DLLogin.getCompanyName();
        }

        public DataSet GetChaDetails()
        {
            return DLLogin.GetChaDetails();
        }

        public DataSet getlistboxdata()
        {
            return DLLogin.RetrieveListboxdata();
        }
        public DataSet getCityName(int HoSno)
        {
            return DLLogin.getCityName(HoSno);
        }
        public DataSet getAlldata(Int32 Sno)
        {
            return DLLogin.RetrieveLoginDetailModified1(Sno);
        }

        public DataSet getHOCompBrSNo()
        {
            return DLLogin.getHOCompBrSNo(this);
        }
        public DataSet getProduct(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate)
        {
            return DLLogin.getProduct(Type, CompBrSno, Fdate, Tdate);
        }
        public DataSet getProductReport(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate, String Product, String GroupBy, int Top)
        {
            return DLLogin.getProductReport(Type, CompBrSno, Fdate, Tdate, Product, GroupBy, Top);
        }
        public DataSet getProductReport_sortbycm1(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate, String Product)
        {
            return DLLogin.getProductReport_sortbycm1(Type, CompBrSno, Fdate, Tdate, Product);
        }
        public DataSet getProductReport_CustomerDetail(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate, String Product, String Customer)
        {
            return DLLogin.getProductReport_CustomerDetail(Type, CompBrSno, Fdate, Tdate, Product, Customer);
        }
        public DataSet getCompNameForReport(int compbrsno)
        {
            return DLLogin.getCompNameForReport(compbrsno);
        }
        public DataSet getLoginName(string LoginId)
        {
            return DLLogin.getLoginName(LoginId);
        }
        public Int32 Lsno
        {
            get { return _Lsno; }
            set { _Lsno = value; }
        }

        public String LoginId
        {
            get { return _LoginId; }
            set { _LoginId = value; }
        }
        public byte[] passwordLogin
        {
            get { return _passwordLogin; }
            set { _passwordLogin = value; }
        }

        public Int32 ChaName
        {
            get { return _ChaName; }
            set { _ChaName = value; }
        }
        public String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        public String RemoteHostName
        {
            get { return _RemoteHostName; }
            set { _RemoteHostName = value; }
        }
        public String Companysno
        {
            get { return _Companysno; }
            set { _Companysno = value; }
        }

        public String GroupName
        {
            get { return _GroupName; }
            set { _GroupName = value; }
        }
        public String CompanyName
        {
            get { return _CompanyName; }
            set { _CompanyName = value; }
        }


        public String RemoteIPAddress
        {
            get { return _RemoteIPAddress; }
            set { _RemoteIPAddress = value; }
        }

        public String LocalIPAddress
        {
            get { return _LocalIPAddress; }
            set { _LocalIPAddress = value; }
        }

        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public String Password
        {
            get { return _Password; }
            set { _Password = value; }
        }

        public String loginType
        {
            get { return _loginType; }
            set { _loginType = value; }
        }

        public String CityName
        {
            get { return _CityName; }
            set { _CityName = value; }
        }

        public String Active
        {
            get { return _Active; }
            set { _Active = value; }
        }

        public byte[] Signature
        {
            get { return _Signature; }
            set { _Signature = value; }
        }

        public String OpType
        {
            get { return _OpType; }
            set { _OpType = value; }
        }

    }
}
