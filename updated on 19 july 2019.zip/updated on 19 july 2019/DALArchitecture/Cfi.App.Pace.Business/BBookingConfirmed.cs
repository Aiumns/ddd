using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;

namespace Cfi.App.Pace.Business
{
    public class BBookingConfirmed : IBookingConfirmed
    {
        private Int32 sNo;
        private Int32 _BookingId;
        private DateTime _BookingDate;
        private String custName;
        private String custCode;
        private String _custCity;
        private String _custBranchSNo;
        private String custLoginId;
        private String _AirlineCode;
        private String _AirlineName;
        private String flightNo;
        private DateTime flightDate;
        private String strHAWBNo;
        private String strMAWBNo;
        private String origin;
        private String _Destination;
        private Decimal _VolWt;
        private Decimal grWt;
        private Decimal chWt;
        private String freightType;
        private DateTime shipmentDate;
        private String shipmentType;
        private String commodity;
        private Decimal decCPP;
        private String pickup;
        private DateTime pickupDate;
        private String pickupTime;
        private String pickupStreet;
        private String pickupLocation;
        private String pickupCity;
        private String pickupState;
        private String pickupZip;
        private String originClearance;
        private String _DestinationClearance;
        private String _Delivery;
        private DateTime _DeliveryDate;
        private String _DeliveryTime;
        private String _DeliveryStreet;
        private String _DeliveryLocation;
        private String _DeliveryCity;
        private String _DeliveryState;
        private String _DeliveryZip;
        private String _AirFreight;
        private String shipperStreet;
        private String shipperLocation;
        private String shipperCity;
        private String shipperState;
        private String shipperZip;
        private String consigneeStreet;
        private String consigneeLocation;
        private String consigneeCity;
        private String consigneeState;
        private String consigneeZip;
        private String consolidate;
        private Int32 _JobEstId;
        private Int32 _BillId;
        private String _AddedBy;
        private DateTime _AddedDate;
        private String _UpdatedBy;
        private DateTime _UpdatedDate;

        private Int32 _BConfId;
        private Int32 chargeId;
        private Decimal _BuyingAmount;
        private Decimal sellingAmount;
        private String _Unit;
        private String _UnitSell;
        private String currency;
        private int compBrSNo;
        private  String _Name;
        private String _Address;
        private String pAN_No;
        private Int32 _BookingRefNo;
        private Int32 _RISno;
        private Decimal _Rate;
        private String strMode;
        private Decimal _Amount;
        private String chequeName;
        private Char _Type;
        private Int32? shipperCustBrSno;
        private Int32? consigneeCustBrSno;
        private String chargesOnWeight;
        private String chargesOnWeightSell;
        private String BankName;
        private String Branch;
        private String ChequeNumber;
        private String ChequeIssuedBy; 
        private Decimal Rupees;
        private Decimal Paise; 
        private String AccountNo;
        private Int32 _BCSNo;
        private String _AWBNO;
        private Decimal _UsedAmt;
        private String _LimitType;
        private Int32 _custMastSno;
        private Int32 _custBrSno;
        private Int32 _compBrSno;
        private String _transactionType;
        private Decimal _amount;
        private Decimal _creditLimit;
        private Decimal _usedCrLimitBeforeTransaction;
        private Decimal _usedCrLimitAfterTransaction;
        private Decimal _availableCrLimitBeforeTransaction;
        private Decimal _availableCrLimitAfterTransaction;
        private String _creditType;
        private String _updatedBy;
        private Int32 _bookingSno;
        private Int32 _billingSno;
        private Int32 _paymentTransSno;
        private Int32 _paymentMastSno;
       

        public BBookingConfirmed() { }
        
        public String ChargesOnWeight
        {
            get { return chargesOnWeight; }
            set { chargesOnWeight = value; }
        }
        public String ChargesOnWeightSell
        {
            get { return chargesOnWeightSell; }
            set { chargesOnWeightSell = value; }
        }
        public Int32? ConsigneeCustBrSno
        {
            get { return consigneeCustBrSno; }
            set { consigneeCustBrSno = value; }
        }
        public Int32? ShipperCustBrSno
        {
            get { return shipperCustBrSno; }
            set { shipperCustBrSno = value; }
        }
        public Decimal  Rate
        {
            get { return _Rate; }
            set { _Rate = value; }
        }
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public String Address
        {
            get { return _Address; }
            set { _Address = value; }
        }
        public String PAN_No
        {
            get { return pAN_No; }
            set { pAN_No = value; }
        }
        public Int32 BookingRefNo
        {
            get { return _BookingRefNo; }
            set { _BookingRefNo = value; }
        }
        public Int32 RISno
        {
            get { return _RISno; }
            set { _RISno = value; }
        }
        public String Mode
        {
            get { return strMode; }
            set { strMode = value; }
        }
        public Decimal Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }
        public String ChequeName
        {
            get { return chequeName; }
            set { chequeName = value; }
        }
        public Char Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        public Int32 SNo
        {
            get { return sNo; }
            set { sNo = value; }
        }
        public Int32 BookingId
        {
            get { return _BookingId; }
            set { _BookingId = value; }
        }
        public DateTime BookingDate
        {
            get { return _BookingDate; }
            set { _BookingDate = value; }
        }
        public String CustName
        {
            get { return custName; }
            set { custName = value; }
        }
        public String CustCode
        {
            get { return custCode; }
            set { custCode = value; }
        }
        public String custCity
        {
            get { return _custCity; }
            set { _custCity = value; }
        }
        public String custBranchSNo
        {
            get { return _custBranchSNo; }
            set { _custBranchSNo = value; }
        }        
        public String CustLoginId
        {
            get { return custLoginId; }
            set { custLoginId = value; }
        }
        public String AirlineCode
        {
            get { return _AirlineCode; }
            set { _AirlineCode = value; }
        }
        public String AirlineName
        {
            get { return _AirlineName; }
            set { _AirlineName = value; }
        }
        public String FlightNo
        {
            get { return flightNo; }
            set { flightNo = value; }
        }
        public DateTime FlightDate
        {
            get { return flightDate; }
            set { flightDate = value; }
        }
        public String HAWBNo
        {
            get { return strHAWBNo; }
            set { strHAWBNo = value; }
        }
        public String MAWBNo
        {
            get { return strMAWBNo; }
            set { strMAWBNo = value; }
        }
        public String Origin
        {
            get { return origin; }
            set { origin = value; }
        }
        public String Destination
        {
            get { return _Destination; }
            set { _Destination = value; }
        }
        public Decimal VolWt
        {
            get { return _VolWt; }
            set { _VolWt = value; }
        }
        public Decimal GrWt
        {
            get { return grWt; }
            set { grWt = value; }
        }
        public Decimal ChWt
        {
            get { return chWt; }
            set { chWt = value; }
        }
        public String FreightType
        {
            get { return freightType; }
            set { freightType = value; }
        }
        public DateTime ShipmentDate
        {
            get { return shipmentDate; }
            set { shipmentDate = value; }
        }
        public String ShipmentType
        {
            get { return shipmentType; }
            set { shipmentType = value; }
        }
        public String Commodity
        {
            get { return commodity; }
            set { commodity = value; }
        }
        public Decimal CPP
        {
            get { return decCPP; }
            set { decCPP = value; }
        }
        public String Pickup
        {
            get { return pickup; }
            set { pickup = value; }
        }
        public DateTime PickupDate
        {
            get { return pickupDate; }
            set { pickupDate = value; }
        }
        public String PickupTime
        {
            get { return pickupTime; }
            set { pickupTime = value; }
        }
        public String PickupStreet
        {
            get { return pickupStreet; }
            set { pickupStreet = value; }
        }
        public String PickupLocation
        {
            get { return pickupLocation; }
            set { pickupLocation = value; }
        }
        public String PickupCity
        {
            get { return pickupCity; }
            set { pickupCity = value; }
        }
        public String PickupState
        {
            get { return pickupState; }
            set { pickupState = value; }
        }
        public String PickupZip
        {
            get { return pickupZip; }
            set { pickupZip = value; }
        }
        public String OriginClearance
        {
            get { return originClearance; }
            set { originClearance = value; }
        }
        public String DestinationClearance
        {
            get { return _DestinationClearance; }
            set { _DestinationClearance = value; }
        }
        public String Delivery
        {
            get { return _Delivery; }
            set { _Delivery = value; }
        }
        public DateTime DeliveryDate
        {
            get { return _DeliveryDate; }
            set { _DeliveryDate = value; }
        }
        public String DeliveryTime
        {
            get { return _DeliveryTime; }
            set { _DeliveryTime = value; }
        }
        public String DeliveryStreet
        {
            get { return _DeliveryStreet; }
            set { _DeliveryStreet = value; }
        }
        public String DeliveryLocation
        {
            get { return _DeliveryLocation; }
            set { _DeliveryLocation = value; }
        }
        public String DeliveryCity
        {
            get { return _DeliveryCity; }
            set { _DeliveryCity = value; }
        }
        public String DeliveryState
        {
            get { return _DeliveryState; }
            set { _DeliveryState = value; }
        }
        public String DeliveryZip
        {
            get { return _DeliveryZip; }
            set { _DeliveryZip = value; }
        }
        public String AirFreight
        {
            get { return _AirFreight; }
            set { _AirFreight = value; }
        }
        public String ShipperStreet
        {
            get { return shipperStreet; }
            set { shipperStreet = value; }
        }
        public String ShipperLocation
        {
            get { return shipperLocation; }
            set { shipperLocation = value; }
        }
        public String ShipperCity
        {
            get { return shipperCity; }
            set { shipperCity = value; }
        }
        public String ShipperState
        {
            get { return shipperState; }
            set { shipperState = value; }
        }
        public String ShipperZip
        {
            get { return shipperZip; }
            set { shipperZip = value; }
        }
        public String ConsigneeStreet
        {
            get { return consigneeStreet; }
            set { consigneeStreet = value; }
        }
        public String ConsigneeLocation
        {
            get { return consigneeLocation; }
            set { consigneeLocation = value; }
        }
        public String ConsigneeCity
        {
            get { return consigneeCity; }
            set { consigneeCity = value; }
        }
        public String ConsigneeState
        {
            get { return consigneeState; }
            set { consigneeState = value; }
        }
        public String ConsigneeZip
        {
            get { return consigneeZip; }
            set { consigneeZip = value; }
        }
        public String Consolidate
        {
            get { return consolidate; }
            set { consolidate = value; }
        }
        public Int32 JobEstId
        {
            get { return _JobEstId; }
            set { _JobEstId = value; }
        }
        public Int32 BillId
        {
            get { return _BillId; }
            set { _BillId = value; }
        }
        public String AddedBy
        {
            get { return _AddedBy; }
            set { _AddedBy = value; }
        }
        public DateTime AddedDate
        {
            get { return _AddedDate; }
            set { _AddedDate = value; }
        }
        public String UpdatedBy
        {
            get { return _UpdatedBy; }
            set { _UpdatedBy = value; }
        }
        public DateTime UpdatedDate
        {
            get { return _UpdatedDate; }
            set { _UpdatedDate = value; }
        }
        public Int32 BConfId
        {
            get { return _BConfId; }
            set { _BConfId = value; }
        }
        public Int32 ChargeId
        {
            get { return chargeId; }
            set { chargeId = value; }
        }
        public Decimal BuyingAmount
        {
            get { return _BuyingAmount; }
            set { _BuyingAmount = value; }
        }
        public Decimal SellingAmount
        {
            get { return sellingAmount; }
            set { sellingAmount = value; }
        }
        public String Unit
        {
            get { return _Unit; }
            set { _Unit = value; }
        }
        public String UnitSell
        {
            get { return _UnitSell; }
            set { _UnitSell = value; }
        }       
        public String Currency
        {
            get { return currency; }
            set { currency = value; }
        }
        public int CompBrSNo
        {
            get { return compBrSNo; }
            set { compBrSNo = value; }
        }
        public String BankName1
        {
            get { return BankName; }
            set { BankName = value; }
        }
        public String Branch1
        {
            get { return Branch; }
            set { Branch = value; }
        }
        public String ChequeNumber1
        {
            get { return ChequeNumber; }
            set { ChequeNumber = value; }
        }
        public String ChequeIssuedBy1
        {
            get { return ChequeIssuedBy; }
            set { ChequeIssuedBy = value; }
        }
        public Decimal Rupees1
        {
            get { return Rupees; }
            set { Rupees = value; }
        }
        public Decimal Paise1
        {
            get { return Paise; }
            set { Paise = value; }
        }
        public String AccountNo1
        {
            get { return AccountNo; }
            set { AccountNo = value; }
        }
        public Int32 BCSNo
        {
            get { return _BCSNo; }
            set { _BCSNo = value; }
        }
        public String AWBNO
        {
            get { return _AWBNO; }
            set { _AWBNO = value; }
        }
        public Decimal UsedAmt
        {
            get { return _UsedAmt; }
            set { _UsedAmt = value; }
        }
        public String LimitType
        {
            get { return _LimitType; }
            set { _LimitType = value; }
        }
        public Int32 custMastSno
        {
            get { return _custMastSno; }
            set { _custMastSno = value; }
        }
        public Int32 custBrSno
        {
            get { return _custBrSno; }
            set { _custBrSno = value; }
        }
        public Int32 compBrSno
        {
            get { return _compBrSno; }
            set { _compBrSno = value; }
        }
        public String transactionType
        {
            get { return _transactionType; }
            set { _transactionType = value; }
        }
        public Decimal amount
        {
            get { return _amount; }
            set { _amount = value; }
        }
        public Decimal creditLimit
        {
            get { return _creditLimit; }
            set { _creditLimit = value; }
        }
        public Decimal usedCrLimitBeforeTransaction
        {
            get { return _usedCrLimitBeforeTransaction; }
            set { _usedCrLimitBeforeTransaction = value; }
        }
        public Decimal usedCrLimitAfterTransaction
        {
            get { return _usedCrLimitAfterTransaction; }
            set { _usedCrLimitAfterTransaction = value; }
        }
        public Decimal availableCrLimitBeforeTransaction
        {
            get { return _availableCrLimitBeforeTransaction; }
            set { _availableCrLimitBeforeTransaction = value; }
        }
        public Decimal availableCrLimitAfterTransaction
        {
            get { return _availableCrLimitAfterTransaction; }
            set { _availableCrLimitAfterTransaction = value; }
        }
        public String creditType
        {
            get { return _creditType; }
            set { _creditType = value; }
        }
        public String updatedBy
        {
            get { return _updatedBy; }
            set { _updatedBy = value; }
        }
        public Int32 bookingSno
        {
            get { return _bookingSno; }
            set { _bookingSno = value; }
        }
        public Int32 billingSno
        {
            get { return _billingSno; }
            set { _billingSno = value; }
        }
        public Int32 paymentTransSno
        {
            get { return _paymentTransSno; }
            set { _paymentTransSno = value; }
        }
        public Int32 paymentMastSno
        {
            get { return _paymentMastSno; }
            set { _paymentMastSno = value; }
        }

      
        public String InsertBookingConfirmed(SqlTransaction tr)
        {
            return DBookingConfirmed.InsertBookingConfirmed(this,tr);
        }
        public String BookingConfirmed_InsertIndrct(SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno,string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType,string AssociateId,int CHA,string pkgs,string  ExhibitionId)
        {
            return DBookingConfirmed.BookingConfirmed_InsertIndrct(this, tr, SalesPerson,Comptype,ParentCompSno,compbrsno,PickupType,OriginClearanceType,DestinationClearanceType,DeliveryType,AirFreightType,AssociateId,CHA,pkgs,ExhibitionId );
        }
        public String BookingConfirmed_InsertIndrctNew(SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno, string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string ExhibitionId,string AllIn)
        {
            return DBookingConfirmed.BookingConfirmed_InsertIndrctNew(this, tr, SalesPerson, Comptype, ParentCompSno, compbrsno, PickupType, OriginClearanceType, DestinationClearanceType, DeliveryType, AirFreightType, AssociateId, CHA, pkgs, ExhibitionId,AllIn);
        }
        public String BookingConfirmed_InsertIndrctGd(SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno, string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string GodownSNo, string ExhibitionId, string onFreight, string onFreightAndClearance)
        {
            return DBookingConfirmed.BookingConfirmed_InsertIndrctGd(this, tr, SalesPerson, Comptype, ParentCompSno, compbrsno, PickupType, OriginClearanceType, DestinationClearanceType, DeliveryType, AirFreightType, AssociateId, CHA, pkgs, GodownSNo, ExhibitionId, onFreight, onFreightAndClearance);
        }
        public String BookingConfirmed_InsertIndrctGdNew(SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno, string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string GodownSNo, string ExhibitionId, string AllIn)
        {
            return DBookingConfirmed.BookingConfirmed_InsertIndrctGdNew(this, tr, SalesPerson, Comptype, ParentCompSno, compbrsno, PickupType, OriginClearanceType, DestinationClearanceType, DeliveryType, AirFreightType, AssociateId, CHA, pkgs, GodownSNo, ExhibitionId,AllIn);
        }
        public DataSet getChequeDepositSlipValue(string SNo)
        {
            return DBookingConfirmed.getChequeDepositSlipValue(SNo);
        }
        public DataSet getChequeDeposit(int SNo,DateTime ChqDt)
        {
            return DBookingConfirmed.getChequeDeposit(SNo,ChqDt);
        }
        public DataSet GetCompanyWiseAccount(string  CompBrSno)
        {
            return DBookingConfirmed.GetCompanyWiseAccount(CompBrSno);
        }

        public String insertBookingTranNew(SqlTransaction tr,  string compbrsno)
        {
            return DBookingConfirmed.insertBookingTranNew(this, tr, compbrsno);
        }
        public int Inserted_ChequeDepositeSlip(string compbrsno, string EnteredBy, int batchno, string datetime, string custBranchSNo)
        {
            return DBookingConfirmed.Inserted_ChequeDepositeSlip(this, compbrsno, EnteredBy, batchno, datetime, custBranchSNo);
        }
        public int Updated_ChequeDepositeSlip(string compbrsno, string EnteredBy, int batchno, int Snotable, string datetime, string custBranchSNo)
        {
            return DBookingConfirmed.Updated_ChequeDepositeSlip(this, compbrsno, EnteredBy, batchno, Snotable, datetime, custBranchSNo);
        }
        public String UpdateBookingTranNew(SqlTransaction tr)
        {
            return DBookingConfirmed.UpdateBookingTranNew(this, tr);
        }


        public String BookingConfirmed_Update(SqlTransaction tr, string Active, string SalesPerson, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs,string ExhibitionId)
        {
            return DBookingConfirmed.BookingConfirmed_Update(this, tr, Active, SalesPerson, PickupType, OriginClearanceType, DestinationClearanceType, DeliveryType, AirFreightType, AssociateId, CHA, pkgs,ExhibitionId);
        }
        public String BookingConfirmed_UpdateNew(SqlTransaction tr, string Active, string SalesPerson, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string ExhibitionId,string AllIn)
        {
            return DBookingConfirmed.BookingConfirmed_UpdateNew(this, tr, Active, SalesPerson, PickupType, OriginClearanceType, DestinationClearanceType, DeliveryType, AirFreightType, AssociateId, CHA, pkgs, ExhibitionId,AllIn);
        }
        public String BookingConfirmed_UpdateForPNP(SqlTransaction tr, string PNPBcnfSno)
        {
            return DBookingConfirmed.BookingConfirmed_UpdateForPNP(this, tr, PNPBcnfSno);
        }
        public String ParentCompSno(string compBrSno)
        {
            return DBookingConfirmed.ParentCompSno(compBrSno);
        }
        public String InsertBookingConfirmedCharges(SqlTransaction tr, string CustBrSNo, string SellingCurrency)
        {
            return DBookingConfirmed.InsertBookingConfirmedCharges(this, tr, CustBrSNo, SellingCurrency);
        }
        public String InsertBookingConfirmedCharges1(SqlTransaction tr, string CustBrSNo, string SellingCurrency,string SupplierName)
        {
            return DBookingConfirmed.InsertBookingConfirmedCharges1(this, tr, CustBrSNo, SellingCurrency, SupplierName);
        }

        public String InsertBookingConfirmedChargesNew(SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt, decimal BuyingSBCessAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt,decimal SellingSBCessAmt, decimal SellingBillAmt, string Status, decimal BuyingExchangeRate, decimal SellingExchangeRate, string UnitSell, string ChargesOnWeightSell, decimal buyRate, decimal sellRate)
        {
              return DBookingConfirmed.InsertBookingConfirmedChargesNew(this, tr, CustBrSNo, SellingCurrency, SupplierName, taxable, BuyingSTaxAmt, BuyingSBCessAmt,BuyingBillAmt, SellingSTaxAmt,SellingSBCessAmt, SellingBillAmt, Status, BuyingExchangeRate, SellingExchangeRate, UnitSell, ChargesOnWeightSell, buyRate, sellRate);
        }
        public String updateChargesInBookingConfirmedCharges(SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt, decimal BuyingSBCessAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt,decimal SellingSBCessAmt, decimal SellingBillAmt, string Status, decimal BuyingExchangeRate, decimal SellingExchangeRate,string UnitSell,string ChargesOnWeightSell,decimal buyRate,decimal sellRate, int BCHSNo)
        {
            return DBookingConfirmed.updateChargesInBookingConfirmedCharges(this, tr, CustBrSNo, SellingCurrency, SupplierName, taxable, BuyingSTaxAmt,BuyingSBCessAmt, BuyingBillAmt, SellingSTaxAmt,SellingSBCessAmt, SellingBillAmt, Status, BuyingExchangeRate, SellingExchangeRate, UnitSell, ChargesOnWeightSell, buyRate, sellRate, BCHSNo);
        }
        public String InsertBookingConfirmedChargesNewPNP(SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt, decimal BuyingSBCessAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt, decimal SellingSBCessAmt, decimal SellingBillAmt, string Status, string MasterSNo, decimal BuyingExchangeRate, decimal SellingExchangeRate, decimal buyRate, decimal sellRate, string unitSell, string ChargesOnWeightSell)
        {
            return DBookingConfirmed.InsertBookingConfirmedChargesNewPNP(this, tr, CustBrSNo, SellingCurrency, SupplierName, taxable, BuyingSTaxAmt,BuyingSBCessAmt, BuyingBillAmt, SellingSTaxAmt,SellingSBCessAmt, SellingBillAmt, Status, MasterSNo, BuyingExchangeRate, SellingExchangeRate, buyRate, sellRate, unitSell, ChargesOnWeightSell);
        }
        public String InsertBookingConfirmedChargesNewestPNP(SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt, decimal SellingBillAmt, string Status, string MasterSNo, decimal BuyingExchangeRate, decimal SellingExchangeRate, string AllInBuy, string AllInSell)
        {
            return DBookingConfirmed.InsertBookingConfirmedChargesNewestPNP(this, tr, CustBrSNo, SellingCurrency, SupplierName, taxable, BuyingSTaxAmt, BuyingBillAmt, SellingSTaxAmt, SellingBillAmt, Status, MasterSNo, BuyingExchangeRate, SellingExchangeRate,AllInBuy,AllInSell);
        }
        public String insertNewBCCharges(SqlTransaction tr)
        {
            return DBookingConfirmed.insertNewBCCharges(this, tr);
        }
        public String deleteBCnfCharges(SqlTransaction tr)
        {
            return DBookingConfirmed.deleteBCnfCharges(this,tr);
        }
        public String deleteBCnfChargesNew(SqlTransaction tr, int chargeID)
        {
            return DBookingConfirmed.deleteBCnfChargesNew(this, tr, chargeID);
        }

        public String InsertRIDetails()
        {
            return DBookingConfirmed.InsertRIDetail(this);
        }
        public string UpdateRIDetails()
        {
            return DBookingConfirmed.UpdateRIDetails(this);
        }

        public DataSet GetRIDetails()
        {
            return DBookingConfirmed.GetRIdetails(this); ;
        }


        public DataSet checkHAWBStock()
        {
            return DBookingConfirmed.checkHAWBStock(this);
        }
        public DataSet checkHAWBStockForPNP()
        {
            return DBookingConfirmed.checkHAWBStockForPNP(this);
        }
        
        public DataSet checkHAWBStockforConsole()
        {
            return DBookingConfirmed.checkHAWBStockforConsole(this);
        }
        public DataSet getConfrmBookBySNo()
        {
            return DBookingConfirmed.getConfrmBookBySNo(this);
        }
        public DataSet getApproveBookBySNo1()
        {
            return DBookingConfirmed.getApproveBookBySNo1(this);
        }

        public DataSet getConfrmBookBySNo1()
        {
            return DBookingConfirmed.getConfrmBookBySNo1(this);
        } 
        public DataSet getConfirmBookChargesForPNP()
        {
            return DBookingConfirmed.getConfirmBookChargesForPNP(this);
        }
        public SqlDataReader  getSalesPerson()
        {
            return DBookingConfirmed.getSalesPerson(this);
        }

        //Gst Applicable from 01 July 2017
        public SqlDataReader getAgentGstNo()
        {
            return DBookingConfirmed.getAgentGstNo(this);
        }
        public DataSet checkCreditLimit()
        {
            return DBookingConfirmed.checkCreditLimit(this);
        }

        public String insertBookingTrans()
        {
            return DBookingConfirmed.insertBookingTrans(this);
        }
        public String updateCreditLimit(decimal TotalAmt,string LimitStatus)
        {
            return DBookingConfirmed.updateCreditLimit(this, TotalAmt, LimitStatus);
        }
        public String restoreCreditLimit(decimal TotalAmt, string LimitStatus)
        {
            return DBookingConfirmed.restoreCreditLimit(this, TotalAmt, LimitStatus);
        }
        public String updateBookingTrans(decimal TotalAmt, string LimitStatus)
        {
            return DBookingConfirmed.updateBookingTrans(this, TotalAmt, LimitStatus);
        }

        public DataSet getBcnfDetails()
        {
            return DBookingConfirmed.getBcnfDetails(this);
        }
       

        public DataSet getSubAgentDet(string custSno)
        {
            return DBookingConfirmed.getSubAgentDet(this, custSno);
        }
        public DataSet getIATAAgentDet(string custSno)
        {
            return DBookingConfirmed.getIATAAgentDet(this, custSno);
        }

        public DataSet getNetAgentDet(string custSno)
        {
            return DBookingConfirmed.getNetAgentDet(this, custSno);
        }
        
        public DataSet getAllAgentsForBCnf(string CompBrSNo)
        {
            return DBookingConfirmed.getAllAgentsForBCnf(this, CompBrSNo);
        }
        public DataSet getBookingsForConsolidation(string CompBrSNo)
        {
            return DBookingConfirmed.getBookingsForConsolidation(this, CompBrSNo);
        }
        public DataSet getBookingsGroupwise(string CompBrSNo)
        {
            return DBookingConfirmed.getBookingsGroupwise(this, CompBrSNo);
        }
        public String addConsoleBookings(string MAWBSNo, string HAWBSNo, string CompBrSNo)
        {
            return DBookingConfirmed.addConsoleBookings(this, MAWBSNo, HAWBSNo,CompBrSNo);
        }
        public SqlDataReader getCHA()
        {
            return DBookingConfirmed.getCHA(this);
        }
        public String getCHASNo()
        {
            return DBookingConfirmed.getCHASNo(this);
        }
        public String checkCHABookingDetails(string BookingRefNo)
        {
            return DBookingConfirmed.checkCHABookingDetails(BookingRefNo);
        }
        public String copyAwbToPace(string NewBookingId)
        {
            return DBookingConfirmed.copyAwbToPace(this, NewBookingId );
        }
        public DataSet getAllMasterStock(DateTime TodayDate,DateTime oneWeekAgo)
        {
            return DBookingConfirmed.getAllMasterStock(this,TodayDate ,oneWeekAgo );
        }
        public DataSet getMasterStock()
        {
            return DBookingConfirmed.getMasterStock(this);
        }
        public DataSet getAllHouseStock()
        {
            return DBookingConfirmed.getAllHouseStock(this);
        }
        public SqlDataReader  getAllPNP()
        {
            return DBookingConfirmed.getAllPNP(this);
        }
        public String checkTallyTransfer()
        {
            return DBookingConfirmed.checkTallyTransfer(this);
        }
        public String updateBillEditable()
        {
            return DBookingConfirmed.updateBillEditable(this);
        }
        public String getAllCrDr()
        {
            return DBookingConfirmed.getAllCrDr(this);
        }
        public String getAllCrDrImp()
        {
            return DBookingConfirmed.getAllCrDrImp(this);
        }
        public DataSet getCompanyBrSNo()
        {
            return DBookingConfirmed.getCompanyBrSNo(this);
        } 
        public String insertBCChargesNew(SqlTransaction tr, string inserted, string ddlChargeNew1, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBRate, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSRate, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount,decimal BuyingExchangeRate,decimal SellingExchangeRate)
        {
            return DBookingConfirmed.insertBCChargesNew(this,tr, inserted,  ddlChargeNew1,  BuyingAirfreight,  ddlBCurrencyNew1,  AfSellingCharges,  ddlSCurrencyNew1,  ddlSupplierNew1,  txtBRate,  txtBCRate,  txtBIRate,  txtBIncOnRate,  txtBSpotRate,  txtBTDSRate,  txtSRate,  txtSCRate,  txtSIRate,  txtSIncOnRate,  txtSSpotRate,  txtSTDSRate,BuyingAmount ,SellingAmount, BuyingExchangeRate, SellingExchangeRate);
        }
        public String insertBCChargesNewest(SqlTransaction tr, string inserted, string ddlChargeNew1, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBRate, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSRate, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount, decimal BuyingExchangeRate, decimal SellingExchangeRate, string AllInBuy, string AllInSell, string CustomerName)
        {
            return DBookingConfirmed.insertBCChargesNewest(this, tr, inserted, ddlChargeNew1, BuyingAirfreight, ddlBCurrencyNew1, AfSellingCharges, ddlSCurrencyNew1, ddlSupplierNew1, txtBRate, txtBCRate, txtBIRate, txtBIncOnRate, txtBSpotRate, txtBTDSRate, txtSRate, txtSCRate, txtSIRate, txtSIncOnRate, txtSSpotRate, txtSTDSRate, BuyingAmount, SellingAmount, BuyingExchangeRate, SellingExchangeRate,AllInBuy,AllInSell, CustomerName);
        }
        public String insertBCChargesDeal(SqlTransaction tr, string BookingConfirmSNo, string BuyingAmount, string SellingAmount, string BuyingCurrency, string SellingCurrency, string awb_rate, string bill_amount, string comm_rate, string inc_rate, string inc_rate_on, string spot_rate, string tds_rate, string awb_rate1, string bill_amount1, string comm_rate1, string inc_rate1, string inc_rate_on1, string spot_rate1, string tds_rate1, string updated_by, string status, string requestedBy, string reqRemarks, string updatedRemarks, string AllInBuy, string AllInSell)
        {
            return DBookingConfirmed.insertBCChargesDeal(this, tr, BookingConfirmSNo, BuyingAmount, SellingAmount, BuyingCurrency, SellingCurrency, awb_rate, bill_amount, comm_rate, inc_rate, inc_rate_on, spot_rate, tds_rate, awb_rate1, bill_amount1, comm_rate1, inc_rate1, inc_rate_on1, spot_rate1, tds_rate1, updated_by, status,requestedBy, reqRemarks, updatedRemarks,AllInBuy,AllInSell);
        }

        public String insertBCRejectDeal(SqlTransaction tr, string BookingConfirmSNo,string status)
        {
            return DBookingConfirmed.insertBCRejectDeal(this, tr, BookingConfirmSNo, status);
        }

        public String insertBCChargesNew2(SqlTransaction tr, string inserted, string ddlChargeNew1, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBRate, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSRate, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount, string SupplierName, decimal BuyingExchangeRate, decimal SellingExchangeRate)
        {
            return DBookingConfirmed.insertBCChargesNew2(this, tr, inserted, ddlChargeNew1, BuyingAirfreight, ddlBCurrencyNew1, AfSellingCharges, ddlSCurrencyNew1, ddlSupplierNew1, txtBRate, txtBCRate, txtBIRate, txtBIncOnRate, txtBSpotRate, txtBTDSRate, txtSRate, txtSCRate, txtSIRate, txtSIncOnRate, txtSSpotRate, txtSTDSRate, BuyingAmount, SellingAmount,SupplierName,BuyingExchangeRate,SellingExchangeRate );
        }
        public String insertBCChargesNewest2(SqlTransaction tr, string inserted, string ddlChargeNew1, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBRate, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSRate, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount, string SupplierName, decimal BuyingExchangeRate, decimal SellingExchangeRate,string AllInBuy,string AllInSell)
        {
            return DBookingConfirmed.insertBCChargesNewest2(this, tr, inserted, ddlChargeNew1, BuyingAirfreight, ddlBCurrencyNew1, AfSellingCharges, ddlSCurrencyNew1, ddlSupplierNew1, txtBRate, txtBCRate, txtBIRate, txtBIncOnRate, txtBSpotRate, txtBTDSRate, txtSRate, txtSCRate, txtSIRate, txtSIncOnRate, txtSSpotRate, txtSTDSRate, BuyingAmount, SellingAmount, SupplierName, BuyingExchangeRate, SellingExchangeRate,AllInBuy,AllInSell);
        }
        public String updateAFChargesInBookingConfirmedCharges(SqlTransaction tr, string inserted, string ddlChargeNew1, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBRate, decimal buyCommAmt, string txtBCRate, decimal buyIncAmt, string txtBIRate, string txtBIncOnRate, decimal buySpotAmt, decimal buySpotDiff, string txtBSpotRate, decimal buyTDSAmt, string txtBTDSRate, string txtSRate, string txtSCRate, decimal txtSCAmt, string txtSIRate, string txtSIncOnRate, decimal txtSIAmt, string txtSSpotRate, decimal txtSSpotAmt, decimal txtSSpotDiff, string txtSTDSRate, decimal txtSTDSAmt, string BuyingAmount, string SellingAmount, string SupplierName, decimal BuyingExchangeRate, decimal SellingExchangeRate, string AllInBuy, string AllInSell, int BCHSNo)
        {
            return DBookingConfirmed.updateAFChargesInBookingConfirmedCharges(this, tr, inserted, ddlChargeNew1, BuyingAirfreight, ddlBCurrencyNew1, AfSellingCharges, ddlSCurrencyNew1, ddlSupplierNew1, txtBRate,buyCommAmt, txtBCRate,buyIncAmt, txtBIRate, txtBIncOnRate,buySpotAmt,buySpotDiff, txtBSpotRate, buyTDSAmt, txtBTDSRate, txtSRate, txtSCRate, txtSCAmt, txtSIRate, txtSIncOnRate,txtSIAmt, txtSSpotRate,txtSSpotAmt,txtSSpotDiff, txtSTDSRate,txtSTDSAmt, BuyingAmount, SellingAmount, SupplierName, BuyingExchangeRate, SellingExchangeRate, AllInBuy, AllInSell, BCHSNo);
        }
        public DataSet RI_Insert()
        {
            return DBookingConfirmed.RI_Insert(this);
        }
        public SqlDataReader RIName_Select()
        {
            return DBookingConfirmed.RIName_Select(this);
        }
        public String RICommission_Insert(string CompBrSno,string PayType,string inv,DateTime invDate,string remarks)
        {
            return DBookingConfirmed.RICommission_Insert(this,CompBrSno,PayType, inv, invDate, remarks );
        }
        public String RICommission_InsertNewest(string CompBrSno, string PayType, string inv, DateTime invDate, string remarks,string billType)
        {
            return DBookingConfirmed.RICommission_InsertNewest(this, CompBrSno, PayType, inv, invDate, remarks,billType);
        }
        public String RICommission_UpdateNew(int RITSno, string CompBrSno, string PayType, string inv, DateTime invDate, string remarks)
        {
            return DBookingConfirmed.RICommission_UpdateNew(this,RITSno, CompBrSno, PayType, inv, invDate, remarks);
        }
        public String RICommission_InsertNew(string CompBrSno,string PayType)
        {
            return DBookingConfirmed.RICommission_InsertNew(this, CompBrSno,PayType);
        }
        public SqlDataReader getGodownDetails(string CompBrSNo)
        {
            return DBookingConfirmed.getGodownDetails(this,CompBrSNo);
        }
        public String hideAWBforBilling(string AWBSNo)
        {
            return DBookingConfirmed.hideAWBforBilling(this, AWBSNo);
        }
        public DataSet  voidBooking(string enteredBy) 
        {
            return DBookingConfirmed.voidBooking(this, enteredBy);
        }
        public String SHICON(string CUSTMast)
        {
            return DBookingConfirmed.SHICON(this, CUSTMast);
        }
        public DataSet GetExhibitionDet(int compbrsno)
        {
            return DBookingConfirmed.GetExhibitionDet(compbrsno);
        }

        public DataSet GetOrigionalDealDeatils(int BCID)
        {
            return DBookingConfirmed.GetOrigionalDealDeatils(BCID);
        }

        public DataSet  getManagerCustomers()
        {
            return DBookingConfirmed.getManagerCustomers(this);
        }
        public String updateCustomernManager(string OldCustBrSNo,string CUSTMast)
        {
            return DBookingConfirmed.updateCustomernManager(this,OldCustBrSNo, CUSTMast);
        }
        public SqlDataReader getLeadSource()
        {
            return DBookingConfirmed.getLeadSource();
        }
        public String getAllCrDrSea()
        {
            return DBookingConfirmed.getAllCrDrSea(this);
        }
        public String getAllCrDrSeaImp()
        {
            return DBookingConfirmed.getAllCrDrSeaImp(this);
        }
        public DataSet checkDealStatus()
        {
            return DBookingConfirmed.checkDealStatus(this);
        }
        public String updateBookingConfirmComplete(int BCSno, string completedBy)
        {
            return DBookingConfirmed.updateBookingConfirmComplete(BCSno,completedBy);
        }
        public DataSet getBankCashDeposit(int BSNo)
        {
            return DBookingConfirmed.getBankCashDeposit(BSNo);
        }

        public DataSet GetBankDeposit()
        {
            return DBookingConfirmed.GetBankDeposit();
        }

        public DataSet getBankCheque(int ChequeSNo, string CompBrSno)
        {
            return DBookingConfirmed.getBankCheque(ChequeSNo, CompBrSno);
        }
        public String InsertTransBookingAwb(string MAWBNo, string HAWBNo, string Origin, string Destination, DateTime FlightDate, int AgentSNo, int ShipperSNo, int ConsigneeSNo, string ShipperAddress, string ConsigneeAddress, DateTime AWBDate, string ShipperUsedBy, string ShipperUsedByCity, string ShipmentType, string SalesPerson, string FreightType, string WTPP, string WTCC, string OtherPP, string OtherCC, int RCP, decimal GrossWt, decimal ChargeableWt, decimal VolumeWt, string NatureofQuantity, int CompBrSNo, int RecCompBrSNo, string AddedBy)
        {
            return DBookingConfirmed.InsertTransBookingAwb(MAWBNo, HAWBNo, Origin, Destination, FlightDate, AgentSNo, ShipperSNo, ConsigneeSNo, ShipperAddress, ConsigneeAddress, AWBDate, ShipperUsedBy, ShipperUsedByCity, ShipmentType, SalesPerson, FreightType, WTPP, WTCC, OtherPP, OtherCC, RCP, GrossWt, ChargeableWt, VolumeWt, NatureofQuantity, CompBrSNo, RecCompBrSNo, AddedBy);
        }

        public String InsertTransBookingSea_bl(string ShippingLine, string HblNo, string MblNo, string JobNo, DateTime BlDate, string ShipperCode, string ShipperName, string ShipperAddressSea, string ShipperPhone, string ShipperEmail, string ConsigneeCode, string ConsigneeName, string ConsigneeAddressSea, string ConsigneePhone, string ConsigneeEmail, string NotifyCode, string NotifyName, string NotifyAddress, string NotifyPhone, string NotifyEmail, string DeliveryCode, string DeliveryName, string DeliveryAddress, string DeliveryPhone, string DeliveryEmail, string LoadingPort, string DischargePort, string ConatinerNo, string ContainerType, string PackageDescription, decimal GrossWtSea, decimal NetWt, int NoOfPackage, decimal Cbm, string Commodity, string FreightType, string ihc, string EnteredBy, string CompBrSNoSea)
        {
            return DBookingConfirmed.InsertTransBookingSea_bl(ShippingLine, HblNo, MblNo, JobNo, BlDate, ShipperCode, ShipperName, ShipperAddressSea, ShipperPhone, ShipperEmail, ConsigneeCode, ConsigneeName, ConsigneeAddressSea, ConsigneePhone, ConsigneeEmail, NotifyCode, NotifyName, NotifyAddress, NotifyPhone, NotifyEmail, DeliveryCode, DeliveryName, DeliveryAddress, DeliveryPhone, DeliveryEmail, LoadingPort, DischargePort, ConatinerNo, ContainerType, PackageDescription, GrossWtSea, NetWt, NoOfPackage, Cbm, Commodity, FreightType, ihc, EnteredBy, CompBrSNoSea);
        }

        public DataSet getTransBilling(int Sno, int CompBrSno, string Type)
        {
            return DBookingConfirmed.getTransBilling(Sno, CompBrSno, Type);
        }

        public String UpdateTransBooking_Awb(int SNo, string MAWBNo, string HAWBNo, string Origin, string Destination, DateTime FlightDate, int AgentSNo, int ShipperSNo, int ConsigneeSNo, string ShipperAddress, string ConsigneeAddress, DateTime AWBDate, string ShipperUsedBy, string ShipperUsedByCity, string ShipmentType, string SalesPerson, string FreightType, string WTPP, string WTCC, string OtherPP, string OtherCC, int RCP, decimal GrossWt, decimal ChargeableWt, decimal VolumeWt, string NatureofQuantity, int CompBrSNo, string BasetoComp)
        {
            return DBookingConfirmed.UpdateTransBooking_Awb(SNo, MAWBNo, HAWBNo, Origin, Destination, FlightDate, AgentSNo, ShipperSNo, ConsigneeSNo, ShipperAddress, ConsigneeAddress, AWBDate, ShipperUsedBy, ShipperUsedByCity, ShipmentType, SalesPerson, FreightType, WTPP, WTCC, OtherPP, OtherCC, RCP, GrossWt, ChargeableWt, VolumeWt, NatureofQuantity, CompBrSNo, BasetoComp);
        }

        public String UpdateTransBooking_Seabl(int SNo, string ShippingLine, string HblNo, string MblNo, string JobNo, DateTime BlDate, string ShipperCode, string ShipperName, string ShipperAddressSea, string ShipperPhone, string ShipperEmail, string ConsigneeCode, string ConsigneeName, string ConsigneeAddressSea, string ConsigneePhone, string ConsigneeEmail, string NotifyCode, string NotifyName, string NotifyAddress, string NotifyPhone, string NotifyEmail, string DeliveryCode, string DeliveryName, string DeliveryAddress, string DeliveryPhone, string DeliveryEmail, string LoadingPort, string DischargePort, string ConatinerNo, string ContainerType, string PackageDescription, decimal GrossWtSea, decimal NetWt, int NoOfPackage, decimal Cbm, string Commodity, string FreightType, string ihc, string ModifiedBy, string CompBrSNoSea, string BasetoComp)
        {
            return DBookingConfirmed.UpdateTransBooking_Seabl(SNo, ShippingLine, HblNo, MblNo, JobNo, BlDate, ShipperCode, ShipperName, ShipperAddressSea, ShipperPhone, ShipperEmail, ConsigneeCode, ConsigneeName, ConsigneeAddressSea, ConsigneePhone, ConsigneeEmail, NotifyCode, NotifyName, NotifyAddress, NotifyPhone, NotifyEmail, DeliveryCode, DeliveryName, DeliveryAddress, DeliveryPhone, DeliveryEmail, LoadingPort, DischargePort, ConatinerNo, ContainerType, PackageDescription, GrossWtSea, NetWt, NoOfPackage, Cbm, Commodity, FreightType, ihc, ModifiedBy, CompBrSNoSea, BasetoComp);
        }
        public DataSet getEmailAddress(int CustBrSno)
        {
            return DBookingConfirmed.getEmailAddress(CustBrSno);
        }

        public String updateEmailAddress(string EmailID, string AlterEmailId, int CustBrSno, string Remarks, int hdnBSNo, int IMPSno, string CHAEmailID)
        {
            return DBookingConfirmed.updateEmailAddress(EmailID, AlterEmailId, CustBrSno, Remarks, hdnBSNo, IMPSno, CHAEmailID);
        }

        public String updateBooking(int hdnBSNo)
        {
            return DBookingConfirmed.updateBooking(hdnBSNo);
        }
        public DataSet getOtherCompanyCustBrSno(int compBrSno)
        {
            return DBookingConfirmed.getOtherCompanyCustBrSno(compBrSno);
        }

        public String updateImport(int hdnBSNo)
        {
            return DBookingConfirmed.updateImport(hdnBSNo);
        }


        public String InsertDSR(string SalesPersonName, string EmailID, DateTime DSRDate, string Place, string Mode, string Type, string Origin, string Destination, string CompName, string ClientName, string ConPhone, string ConMobile, string Commodity, string Remarks, string EnteredBy, DateTime EnteredAt, string CompBrSno, DateTime birthDate, DateTime AnninverseyDate)
        {
            return DBookingConfirmed.InsertDSR(SalesPersonName, EmailID, DSRDate, Place, Mode, Type, Origin, Destination, CompName, ClientName, ConPhone, ConMobile, Commodity, Remarks, EnteredBy, EnteredAt, CompBrSno,birthDate,AnninverseyDate);
        }

        public DataSet GetDSR(int SNo)
        {
            return DBookingConfirmed.GetDSR(SNo);
        }


        public String UpdateDSR(string SalesPersonName, string EmailID, DateTime DSRDate, string Place, string Mode, string Type, string Origin, string Destination, string CompName, string ClientName, string ConPhone, string ConMobile, string Commodity, string Remarks, string ModifiedBy, DateTime ModifiedDate, string CompBrSno, DateTime birthDate, DateTime AnninverseyDate, int SNo)
        {
            return DBookingConfirmed.UpdateDSR(SalesPersonName, EmailID, DSRDate, Place, Mode, Type, Origin, Destination, CompName, ClientName, ConPhone, ConMobile, Commodity, Remarks, ModifiedBy, ModifiedDate, CompBrSno, birthDate, AnninverseyDate, SNo);
        }


        public String UpdateWareHouseRFB(SqlTransaction tr, int RFBSNo, string CompBrSNo, int BookingSno, int pkg)
        {
            return DBookingConfirmed.UpdateWareHouseRFB(this, tr, RFBSNo, CompBrSNo, BookingSno, pkg);
        }

        public String InsertWareHouse_BookingConfirmed(SqlTransaction tr,  string compbrsno, int pkg,int BookingSno)
        {
            return DBookingConfirmed.InsertWareHouse_BookingConfirmed(this, tr, compbrsno, pkg, BookingSno);
        }

        public String getRedRefNo(int BCSNo)
        {
            return DBookingConfirmed.getRedRefNo(BCSNo);
        }

        public String UpdateAWBTracking()
        {
            return DBookingConfirmed.UpdateAWBTracking(this);
        }

        public String restoreCreditLimitRedIntl()
        {
            return DBookingConfirmed.restoreCreditLimitRedIntl(this);
        }

        public String insertCreditLimitUses()
        {
            return DBookingConfirmed.insertCreditLimitUses(this);
        }

        public String updateCreditLimitRedIntl()
        {
            return DBookingConfirmed.updateCreditLimitRedIntl(this);
        }
    }
}

 