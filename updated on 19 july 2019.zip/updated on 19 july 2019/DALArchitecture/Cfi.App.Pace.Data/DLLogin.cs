using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Common;
using System.IO;
using System.Security.Cryptography;
namespace Cfi.App.Pace.Data
{
    public class DLLogin :PaceCommon
    {
        public static String InsertAdminLogin(ILogin LoginMaster)
        {
            SqlParameter[] lParameter ={
                new SqlParameter("@LoginID",LoginMaster.LoginId),
                new SqlParameter("@name",LoginMaster.Name),
                new SqlParameter("@Password",LoginMaster.Password),
                new SqlParameter("@LoginType",LoginMaster.loginType),
                new SqlParameter("@City",LoginMaster.CityName),
                new SqlParameter("@Active",LoginMaster.Active)
               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_AdminLogin", lParameter));
        }

        public static String InsertAdminLoginModified(ILogin LoginMaster)
        {
            SqlParameter[] lParameter ={
                new SqlParameter("@LoginID",LoginMaster.LoginId),
                new SqlParameter("@name",LoginMaster.Name),
             new SqlParameter("@Password", LoginMaster.Password),           
                new SqlParameter("@LoginType",LoginMaster.loginType),
                new SqlParameter("@Companysno",LoginMaster.Companysno),
                new SqlParameter("@Emil",LoginMaster.Email),
                new SqlParameter("@Active",LoginMaster.Active),
                 new SqlParameter("@Cha", LoginMaster.ChaName),
                 new SqlParameter("@Signature", LoginMaster.Signature),
                 new SqlParameter("@OperationType",LoginMaster.OpType)

               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "dsp_insertLogin", lParameter));
        }

        public static String UpdateAdminLogin(ILogin LoginMaster)
        {
            SqlParameter[] uParameter ={
                new  SqlParameter("@sno",LoginMaster.Lsno),
                new SqlParameter("@LoginID",LoginMaster.LoginId),
                new SqlParameter("@name",LoginMaster.Name),
                new SqlParameter("@LoginType",LoginMaster.loginType),
                new SqlParameter("@City",LoginMaster.CityName),                
                new SqlParameter("@Active",LoginMaster.Active)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "UPDATE_ADMINLOGIN", uParameter));
        }
        public static String UpdateAdminLoginModified(ILogin LoginMaster, Int32 Sno)
        {
            SqlParameter[] uParameter ={
              
                new SqlParameter("@LoginID",LoginMaster.LoginId),
                new SqlParameter("@name",LoginMaster.Name),
                 new SqlParameter("@Password", LoginMaster.Password),
                new SqlParameter("@LoginType",LoginMaster.loginType),
                new SqlParameter("@Companysno",LoginMaster.Companysno),
                 new SqlParameter("@Email",LoginMaster.Email),
                 new SqlParameter("@Active",LoginMaster.Active),
                   new SqlParameter("@Signature", LoginMaster.Signature),
                     new SqlParameter("@OperationType", LoginMaster.OpType),
                new  SqlParameter("@Sno", Convert.ToInt32(LoginMaster.Lsno)),
                    new SqlParameter("@Cha", Convert.ToInt32(LoginMaster.ChaName))
                  
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "dsp_updateLogin", uParameter));
        }


        public static String DeleteModified1(ILogin LoginMaster, Int32 Sno)
        {
            SqlParameter[] dParameter ={
            new SqlParameter("@Sno", LoginMaster.Lsno)};
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "dsp_delete", dParameter));
        }

        public static DataSet RetrieveLoginType()
        {
            return SqlHelper.ExecuteDataset(ConnectionString, "SELECT_LOGINTYPE");
        }

        public static DataSet getcompany()
        {
            return SqlHelper.ExecuteDataset(ConnectionString, "GetCompanyDetailForLogin");
        }

        public static DataSet GetChaDetails()
        {
            return SqlHelper.ExecuteDataset(ConnectionString, "getChaDetailsmodifiedlogin");
        }
        public static DataSet RetrieveListboxdata()
        {
            return SqlHelper.ExecuteDataset(ConnectionString, "getcompaydetails");
        }



        public static SqlDataReader RetrieveLoginDetail(Int32 strL)
        {
            SqlParameter[] _lParam = { new SqlParameter("@sno", strL) };
            return SqlHelper.ExecuteReader(ConnectionString, "SELECT_LOGINMASTER", _lParam);
        }

        public static SqlDataReader RetrieveLoginDetailModified(Int32 strL)
        {
            SqlParameter[] _lParam = { new SqlParameter("@sno", strL) };
            return SqlHelper.ExecuteReader(ConnectionString, "dsp_getlogin", _lParam);
        }


        public static DataSet RetrieveLoginDetailModified1(Int32 Sno)
        {
            SqlParameter[] _param = {
               new SqlParameter(" @SNo",Sno ),
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "dsp_getlogin", _param);
        }

        public static SqlDataReader RetrieveUserDetail(ILogin LoginMaster)
        {
            SqlParameter[] _lParam = { new SqlParameter("@LoginID", LoginMaster.LoginId) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveLoginDetails", _lParam);
        }


        public static String DeleteLoginDetail(ILogin LoginMaster)
        {
            SqlParameter[] _lParameters = { new SqlParameter("@sno", LoginMaster.Lsno) };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Delete_LoginMaster", _lParameters));
        }

        public static String ReturnName(String SesionID)
        {
            SqlParameter[] _lParameters = { new SqlParameter("@SesionID", SesionID) };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "_ReturnName", _lParameters));
        }

        public static String Login(ILogin loginP)
        {
            SqlParameter[] _parameters = {                
                new SqlParameter( "@LoginID", loginP.LoginId),
                new SqlParameter( "@Password",loginP.Password),
                new SqlParameter( "@RemoteHostName",loginP.RemoteHostName),
                new SqlParameter( "@RemoteIPAddress",loginP.RemoteIPAddress),
                new SqlParameter( "@LocalIPAddress",loginP.LocalIPAddress)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "_User_Login", _parameters));
        }

        public static String UpdatePass(String userID, String Password, String newPassword)
        {
            SqlParameter[] _parameters = {                
                new SqlParameter( "@_UserID", userID),
                new SqlParameter( "@_Password", Password),
                new SqlParameter( "@_NewPassword", newPassword)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "changeUserPass", _parameters));
        }
        public static String getCompType(String compBrSNo)
        {
            SqlParameter[] _parameters = {                
                new SqlParameter( "@compBrSNo", compBrSNo),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getCompType", _parameters));
        }
        public static String getCompTypeNew(String compBrSNo)
        {
            SqlParameter[] _parameters = {                
                new SqlParameter( "@compBrSNo", compBrSNo),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getCompTypeNew", _parameters));
        }
        public static String getCompInvoicePrefix(String compBrSNo)
        {
            SqlParameter[] _parameters = {                
                new SqlParameter( "@compBrSNo", compBrSNo),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getCompInvoicePrefix", _parameters));
        }
        public static String mailPass(String userID)
        {
            SqlParameter[] _parameters = { new SqlParameter("@_UserID", userID) };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "mailUserPass", _parameters));
        }
        public static DataSet getCustBranchBySNo(int CustBrSNo)
        {
            SqlParameter[] _param = {
               new SqlParameter("@CustBrSNo",CustBrSNo  ),
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getCustBranchBySNo", _param);
        }

        public static DataSet getSubAgent(int CompBrSNo)
        {
            SqlParameter[] _param = {
               new SqlParameter("@CompBrSNo",CompBrSNo),
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getSubAgent", _param);
        }


        public static DataSet getOriginalComp(string CompBrSNo)
        {
            SqlParameter[] _param = {
               new SqlParameter("@CompBrSNo",CompBrSNo),
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getOriginalComp", _param);
        }
        public static DataSet getCompanyName()
        {
            SqlParameter[] _param = {
               
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getCompanyName", _param);
        }

        public static DataSet BindLogintype()
        {
            SqlParameter[] _param = {
               
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "dsp_bindLoginType", _param);
        }

        public static DataSet getCityName(int HoSno)
        {
            SqlParameter[] _param = {
               new SqlParameter("@HoSno",HoSno ),
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getCityName", _param);
        }
        public static DataSet getProduct(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate)
        {
            SqlParameter[] _param = {
               new SqlParameter("@Type",Type ),
                new SqlParameter("@CompBrSno",CompBrSno ),
                new SqlParameter("@Fdate",Fdate ),
                new SqlParameter("@Tdate",Tdate )
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getProduct", _param);
        }
        public static DataSet getProductReport(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate, String Product,String GroupBy,int Top)
        {
            SqlParameter[] _param = {
               new SqlParameter("@Type",Type ),
                new SqlParameter("@CompBrSno",CompBrSno ),
                new SqlParameter("@Fdate",Fdate ),
                new SqlParameter("@Tdate",Tdate ),
                new SqlParameter("@Product",Product ),
                 new SqlParameter("@GroupBy",GroupBy ),
                  new SqlParameter("@Top",Top )
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getProductReport", _param);
        }
        public static DataSet getProductReport_sortbycm1(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate, String Product)
        {
            SqlParameter[] _param = {
               new SqlParameter("@Type",Type ),
                new SqlParameter("@CompBrSno",CompBrSno ),
                new SqlParameter("@Fdate",Fdate ),
                new SqlParameter("@Tdate",Tdate ),
                new SqlParameter("@Product",Product )
                 
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getProductReport_sortbycm1", _param);
        }
        public static DataSet getProductReport_CustomerDetail(String Type, int CompBrSno, DateTime Fdate, DateTime Tdate, String Product, String Customer)
        {
            SqlParameter[] _param = {
               new SqlParameter("@Type",Type ),
                new SqlParameter("@CompBrSno",CompBrSno ),
                new SqlParameter("@Fdate",Fdate ),
                new SqlParameter("@Tdate",Tdate ),
                new SqlParameter("@Product",Product ),
                new SqlParameter("@Customer",Customer )
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getProductReport_CustomerDetail", _param);
        }
        public static DataSet getHOCompBrSNo(ILogin LoginMaster)
        {
            SqlParameter[] _param = {
               new SqlParameter("@LoginId",LoginMaster.LoginId ),
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getHOCompBrSNo", _param);
        }
        public static DataSet getCompNameForReport(int compbrsno)
        {
            SqlParameter[] _param = {
               new SqlParameter("@compbrsno",compbrsno )
               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getCompNameForReport", _param);
        }
        public static DataSet getLoginName(String LoginId)
        {
            SqlParameter[] _param = {
               new SqlParameter("@Loginid",LoginId  ),               
           };
            return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "getLoginName", _param);
        }
    }
}