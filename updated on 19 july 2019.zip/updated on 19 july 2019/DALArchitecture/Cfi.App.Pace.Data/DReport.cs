﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;

namespace Cfi.App.Pace.Data
{
    public class DReport : PaceCommon
    {
        public static DataSet GetInvoiceBookedChecked()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "InvoiceBooked_SelectChecked");
        }
        public static DataSet GetChartData(DateTime dateFrom,string strCompBrSno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@Date",dateFrom),
                                            new SqlParameter("@CompBrSno",strCompBrSno)
                                            
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "ChartGraph", _parameters);
        }
        public static DataSet GetCrmDashBoardChart(string loginId, int compBrSNo)
        {
            SqlParameter[] Parameters =
            {
                new SqlParameter("@UserID", loginId),
                new SqlParameter("@compBrSNo", compBrSNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "ShowCrmDashBoardChart", Parameters);
        }

        public static int InvoiceBooked_Insert(Int64 intInvNo, string strAddedBy)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@BillMasterSno",intInvNo),
                                            new SqlParameter("@AddedBy",strAddedBy)
                                            
            };
            return SqlHelper.ExecuteNonQuery(ConnectionString, "InvoiceBooked_Insert", _parameters);
        }
        public static DataSet GetInvoiceBooked(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@CompBrSno",strCompBrSNo),
                                            new SqlParameter("@Type",strType),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "InvoiceBooked_Select", _parameters);
        }
        public static DataSet GetExRateProfit(string strCompBrSNo, string strType, string strPaymentType, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            
                                            new SqlParameter("@Type",strType),
                                            new SqlParameter("@CompBrSno",strCompBrSNo),
                                            new SqlParameter("@PayType",strPaymentType),
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetExRateProfit", _parameters);
        }
        public static DataSet GetBillExecuted(string strType, string strCompBrSNo, string strExecType,DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            
                                            new SqlParameter("@Type",strType),
                                            new SqlParameter("@CompBrSno",strCompBrSNo),
                                            new SqlParameter("@ExeType",strExecType),
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetBillExecuted", _parameters);
        }
        public static DataSet getTaxableReport(string SNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@Sno",SNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getTaxableReport", _parameters);
        }
        public static DataSet getBillReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),
                                            
                                            new SqlParameter("@Type",strType), 
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillReport", _parameters);
        }
         public static DataSet getPartywiseBillReport(string strCompBrSNo, string CustBrSno,string CustType, string strType, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),
                                             new SqlParameter("@CustBrSno",CustBrSno),
                                              new SqlParameter("@CustType",CustType),
                                            new SqlParameter("@Type",strType), 
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getPartywiseBillReport1", _parameters);
        }
         public static DataSet getAwbVsInvoicingReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
         {
             SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),                                           
                                            new SqlParameter("@Type",strType), 
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            };
             return SqlHelper.ExecuteDataset(ConnectionString, "getAwbVsInvoicingReport", _parameters);
         }
         public static DataSet getAwbVsInvoicingSubAgentReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate, string SubAgentSNo,string BillingCycle)
         {
             SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),                                           
                                            new SqlParameter("@Type",strType), 
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                             new SqlParameter("@SubAgentSno",SubAgentSNo),
                                              new SqlParameter("@BillingCycle",BillingCycle)
            };
             return SqlHelper.ExecuteDataset(ConnectionString, "getAwbVsInvoicingSubAgentReport", _parameters);
         }
         public static DataSet getAwbVsAgentInvoicingReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate, string SubAgentSNo)
         {
             SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),                                           
                                            new SqlParameter("@Type",strType), 
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@SubAgentSNo",SubAgentSNo)
            };
             return SqlHelper.ExecuteDataset(ConnectionString, "getAwbVsAgentInvoicingReport", _parameters);
         }

         public static DataSet getAwbVsInvoicePostingReport(string strCompBrSNo, string strType,string strTransfer, DateTime datFromDate, DateTime datToDate)
         {
             SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),                                           
                                            new SqlParameter("@Type",strType), 
                                            new SqlParameter("@Transfer",strTransfer), 
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            };
             return SqlHelper.ExecuteDataset(ConnectionString, "getAwbVsInvoicingReport", _parameters);
         }
         public static DataSet getClientwiseProfitability(string strCompBrSNo, DateTime datFromDate, DateTime datToDate)
         {
             SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
                                          };
             return SqlHelper.ExecuteDataset(ConnectionString, "getClientwiseProfitability", _parameters);
         }
         public static DataSet GetCustBrSno(string strCompBrSNo, string CustBrSno)
         {
             SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),
                                             new SqlParameter("@CustBrSno",CustBrSno)
                                            
            };
             return SqlHelper.ExecuteDataset(ConnectionString, "GetCustBrSno", _parameters);
         }  
        public static DataSet getAllSalesPersons(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            
                                            new SqlParameter("@Type",strType),
                                            new SqlParameter("@CompBrSno",strCompBrSNo),
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAllSalesPersons", _parameters);
        }
        public static DataSet getAllSalesPersonsReport(string strCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate, string SalesPerson)
        {
            SqlParameter[] _parameters = {
                                            
                                             new SqlParameter("@Type",strType),
                                            new SqlParameter("@CompBrSno",strCompBrSNo),
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@SalesPerson",SalesPerson),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAllSalesPersonsReport", _parameters);
        }
        public static DataSet GetOutstandingCustomer(string StrAllCompBrSNo, string strType, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {                                            
                                            new SqlParameter("@AllCompBrSNo",StrAllCompBrSNo),
                                            new SqlParameter("@Type",strType),
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "OutstandingParty", _parameters);
        }
        public static DataSet GetOutstandingBills(string CompBrSNo, string strType, DateTime Date, string CustMSno,string CustType)
        {
            SqlParameter[] _parameters = {                                            
                                            new SqlParameter("@CompBrSNo",CompBrSNo),
                                            new SqlParameter("@Type",strType),
                                            new SqlParameter("@Date",Date),
                                            new SqlParameter("@CustMSno",CustMSno),
                                             new SqlParameter("@CustType",CustType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "OutstandingPartyBills", _parameters);
        }

        public static DataSet GetBillsPayable_Export_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_Export_Local", _parameters);
        }
        public static DataSet GetBillsPayable_OceanExp_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_OceanExp_Local", _parameters);
        }
        public static DataSet GetBillsPayable_All_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_All_Local", _parameters);
        }
        public static DataSet GetBillsPayable_Export_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_Export_AllLocation", _parameters);
        }
        public static DataSet GetBillsPayable_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_OceanExp_AllLocation", _parameters);
        }
        public static DataSet GetBillsPayable_All_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_All_AllLocation", _parameters);
        }
        public static DataSet GetBillsPayable_Import_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_Import_AllLocation", _parameters);
        }
        public static DataSet GetBillsPayable_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_OceanImp_AllLocation", _parameters);
        }
        public static DataSet GetBillsPayableSupplier_Export_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_Export_Local", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_OceanExp_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_OceanExp_Local", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_All_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_All_Local", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_Export_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_Export_Local", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_OceanExp_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_OceanExp_Local", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_All_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_All_Local", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_Export_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_Export_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_OceanExp_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_All_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_All_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_Export_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_Export_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_OceanExp_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_All_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_All_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_Import_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_Import_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_OceanImp_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_Import_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_Import_Local", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_OceanImp_Local(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_OceanImp_Local", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_Import_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_Import_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableInvoiceNo_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate, string strSupplier)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Suppliername",strSupplier)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableInvoiceNo_OceanImp_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_Export_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_Export_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_OceanExp_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_All_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_All_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_Import_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_Import_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_OceanImp_AllLocation", _parameters);

        }
        public static DataSet GetBillsPayable_Export_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_Export_Overseas", _parameters);
        }
        public static DataSet GetBillsPayable_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_OceanExp_Overseas", _parameters);
        }
        public static DataSet GetBillsPayable_All_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_All_Overseas", _parameters);
        }
        public static DataSet GetBillsPayableSupplier_Export_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_Export_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_OceanExp_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_All_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_All_Overseas", _parameters);

        }
        public static DataSet GetBillsPayable_Import_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_Import_Overseas", _parameters);
        }
        public static DataSet GetBillsPayable_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_OceanImp_Overseas", _parameters);
        }
        public static DataSet GetBillsPayableSupplier_Import_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_Import_Overseas", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_OceanImp_Overseas", _parameters);

        }
        public static DataSet GetBillsPayable_Import_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_Import_Local", _parameters);
        }
        public static DataSet GetBillsPayable_OceanImp_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, Int64 intInvNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@InvoiceNo",intInvNo)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayable_OceanImp_Local", _parameters);
        }
        public static DataSet GetBillsPayableSupplier_Import_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_Import_Local", _parameters);

        }
        public static DataSet GetBillsPayableSupplier_OceanImp_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableSupplier_OceanImp_Local", _parameters);

        }
        public static DataSet GetInvoice_Export(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Company",strCompany),
            new SqlParameter ("@Orderby",shortby )
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "InvoiceExport_Select", _parameters);
        }
        public static DataSet GetOceanInvoice_Export(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Company",strCompany),
            new SqlParameter ("@Orderby",shortby )
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "InvoiceOceanExport_Select", _parameters);
        }
        //public static DataSet InvoiceAll_Select(DateTime frmdate, DateTime tdate, string shortby,string compBrSno,string type)
        //{
        //    SqlParameter[] _parameter ={ new SqlParameter("@FromDate",frmdate),
        //                                    new SqlParameter("@ToDate",tdate),
        //                           new SqlParameter ("@Orderby",shortby ),
        //                           new SqlParameter("@compBrSno",compBrSno),
        //                           new SqlParameter ("@type",type )
        //                           };
        //    return SqlHelper.ExecuteDataset(ConnectionString, "InvoiceAll_Select", _parameter);

        //}
        public static DataSet InvoiceAll_Select(DateTime frmdate, DateTime tdate, string shortby, string compBrSno, string type, string customerBranchSno)
        {
            SqlParameter[] _parameter ={ new SqlParameter("@FromDate",frmdate),
                                            new SqlParameter("@ToDate",tdate),
                                   new SqlParameter ("@Orderby",shortby ),
                                   new SqlParameter("@compBrSno",compBrSno),
                                   new SqlParameter ("@type",type ),
                                   new SqlParameter ("@customerBranchSno",customerBranchSno ),
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "InvoiceAll_Select", _parameter);

        }
        public static DataSet GetInvoice_Import(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Company",strCompany),
            new SqlParameter ("@Orderby",shortby )
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "InvoiceImport_Select", _parameters);
        }
        public static DataSet GetOceanInvoice_Import(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Company",strCompany),
            new SqlParameter ("@Orderby",shortby )
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "InvoiceOceanImport_Select", _parameters);
        }
        public static DataSet GetInvoice_All(DateTime datFromDate, DateTime datToDate, string strCompany, string shortby)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Company",strCompany),
            new SqlParameter ("@Orderby",shortby )
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "Invoice_Select", _parameters);
        }

        public static DataSet getInvocereport(string CompBrSNo,string Type, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                              new SqlParameter("@CompBrSNo",CompBrSNo),
                                               new SqlParameter("@Type",Type),
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getInvocereport", _parameters);
        }

        public static DataSet getAWBMonthwiseCount(string Month, string strCompBrSNo, string Year, string strType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@Month",Month),
                                             new SqlParameter("@CompBrSno",strCompBrSNo), 
                                            new SqlParameter("@Year",Year),
                                             new SqlParameter("@Type",strType), 
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAWBMonthwiseCount", _parameters);
        }

        public static DataSet AwbNoSelect(string AwbNo,int SNo,string InvoiceNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@AwbNo",AwbNo),
                                             new SqlParameter("@SNo",SNo),
                                             new SqlParameter("@InvoiceNo",InvoiceNo),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "AwbNoSelect", _parameters);
        }

        public static string AwbNoDelete(int SNo, string TableType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@SNo",SNo),
                                             new SqlParameter("@TableType",TableType),
            };
            return Convert.ToString( SqlHelper.ExecuteNonQuery(ConnectionString, "AwbNoDelete", _parameters));
        }

        public static DataSet GetCustomerAll()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "Customer_SelectAll");
        }
        public static DataSet GetSupplierAll()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "Supplier_SelectAll");
        }
        public static DataSet GetSupplierByCompany(string strCompany)
        {
            SqlParameter[] _parameters = {
                                           new SqlParameter("@Company",strCompany)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "Supplier_SelectByCompany", _parameters);
        }
        public static DataSet GetCustomerByCompany(string strCompany, string strType)
        {
            SqlParameter[] _parameters = {
                                           new SqlParameter("@Company",strCompany),
                                           new SqlParameter("@Type",strType)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "Customer_SelectByCompany", _parameters);
        }
        public static DataSet GetCustomerByCompanyExport(string strCompany)
        {
            SqlParameter[] _parameters = {
                                           new SqlParameter("@Company",strCompany)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "Customer_SelectByCompanyExport", _parameters);
        }
        public static DataSet GetBillsReceivable_Export_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCreditType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCreditType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_Export_Local", _parameters);
        }
        public static DataSet GetBillsReceivable_OceanExp_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCreditType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCreditType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_OceanExp_Local", _parameters);
        }
        public static DataSet GetBillsReceivable_All_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCreditType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCreditType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_All_Local", _parameters);
        }
        public static DataSet GetBillsReceivable_Export_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                             new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_Export_AllLocation", _parameters);
        }
        public static DataSet GetBillsReceivable_OceanExp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                             new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_OceanExp_AllLocation", _parameters);
        }
        public static DataSet GetBillsReceivable_All_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_All_AllLocation", _parameters);
        }
        public static DataSet GetBillsReceivable_Import_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_Import_AllLocation", _parameters);
        }
        public static DataSet GetBillsReceivable_OceanImp_AllLocation(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_OceanImp_AllLocation", _parameters);
        }
        public static DataSet GetBillsReceivableCompany_Export_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_Export_Local", _parameters);

        }
        public static DataSet GetBillsReceivableCompany(DateTime datFromDate, DateTime datToDate, string strCompany, string strType, string strCountryCode)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@Type",strType),
                                            new SqlParameter("@CountryCode",strCountryCode)
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany", _parameters);

        }
        public static DataSet GetBillsPayableCompany(DateTime datFromDate, DateTime datToDate, string strCompany, string strType, string strCountryCode)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@Type",strType),
                                            new SqlParameter("@CountryCode",strCountryCode)
                         
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillPayableCompany", _parameters);

        }
        public static DataSet GetBillsReceivableCompany_All_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_All_Local", _parameters);

        }
        public static DataSet GetBillsReceivableCompany_Export_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_Export_AllLocation", _parameters);

        }
        public static DataSet GetBillsReceivableCompany_All_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_All_AllLocation", _parameters);

        }
        public static DataSet GetBillsReceivableCompany_Import_AllLocation(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_Import_AllLocation", _parameters);

        }


        public static DataSet GetBillsReceivable_Import_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_Import_Local", _parameters);
        }
        public static DataSet GetBillsReceivable_OceanImp_Local(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_OceanImp_Local", _parameters);
        }
        public static DataSet GetBillsReceivableCompany_Import_Local(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompanyCount_Import_Local", _parameters);

        }
        public static DataSet GetBillsReceivableCompany_Import_RI(DateTime datFromDate, DateTime datToDate, int CompBrSno)
        {
            SqlParameter[] _parameters = {
                                             
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@CompBrSno",CompBrSno)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_RI", _parameters);

        }


        public static DataSet GetBillsReceivableCompany_Import_RI_All(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                             
                                             new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                           
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_RI_All", _parameters);

        }

        public static DataSet GetBillsReceivableCompany_Import_RI_Name(DateTime datFromDate, DateTime datToDate, string Name)
        {
            SqlParameter[] _parameters = {
                                             
                                             new SqlParameter("@FromDate",datFromDate),
                                             new SqlParameter("@ToDate",datToDate),
                                             new SqlParameter("@name",Name),
                                           
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_RI_Name", _parameters);

        }



        public static DataSet GetBillsReceivable_Import_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_Import_Overseas", _parameters);
        }
        public static DataSet GetBillsReceivable_OceanImp_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_OceanImp_Overseas", _parameters);
        }
        public static DataSet GetBillsReceivableCompany_Import_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_Import_Overseas", _parameters);

        }
        public static DataSet GetBillsReceivable_Export_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_Export_Overseas", _parameters);
        }
        public static DataSet GetBillsReceivable_OceanExp_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
             
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_OceanExp_Overseas", _parameters);
        }
        public static DataSet GetBillsReceivable_All_Overseas(DateTime datFromDate, DateTime datToDate, string strCustomer, string strCompany, string strCrType)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@Customer",strCustomer),
                                            new SqlParameter("@Company",strCompany),
                                            new SqlParameter("@CrType",strCrType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivable_All_Overseas", _parameters);
        }
        public static DataSet GetBillsReceivableCompany_Export_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_Export_Overseas", _parameters);

        }
        public static DataSet GetBillsReceivableCompany_All_Overseas(DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "BillReceivableCompany_All_Overseas", _parameters);

        }
        public static SqlDataReader getAllCHAUsers()
        {
            SqlParameter[] _parameters = {
             
            };

            return SqlHelper.ExecuteReader(ConnectionString, "getAllCHAUsers", _parameters);

        }
        public static DataSet getAllCHACharges(DateTime datFromDate, DateTime datToDate, string AddBy, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@AddBy",AddBy)  ,  
                                             new SqlParameter("@CompBrSNo",CompBrSNo)  , 
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCHACharges", _parameters);

        }
        public static DataSet getAllCHAChargesOTH(DateTime datFromDate, DateTime datToDate, string AddBy, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate),
                                            new SqlParameter("@AddBy",AddBy)  ,  
                                             new SqlParameter("@CompBrSNo",CompBrSNo)  , 
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCHAChargesOTH", _parameters);

        }
        public static DataSet getAllCHAChargesNew(DateTime datFromDate, DateTime datToDat, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDat  ),
                                             new SqlParameter("@CompBrSNo",CompBrSNo)  , 
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCHAChargesNew", _parameters);

        }
        public static DataSet getAllCHAChargesCHA(DateTime datFromDate, DateTime datToDat, string CompBrSNo, string CHASNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDat  ),
                                             new SqlParameter("@CompBrSNo",CompBrSNo)  , 
                                             new SqlParameter("@CHASNo",CHASNo)
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCHAChargesNewCHA", _parameters);

        }
        public static DataSet getAllCHAChargesNew1(DateTime datFromDate, DateTime datToDat, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDat  ),
                                           
                                             new SqlParameter("@CompBrSNo",CompBrSNo)  , 
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCHAChargesNew1", _parameters);

        }
        public static DataSet getAllCHAChargesNew10(DateTime datFromDate, DateTime datToDat, string CHA, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDat  ),
                                            new SqlParameter("@CHA",CHA  ),
                                             new SqlParameter("@CompBrSNo",CompBrSNo)  , 
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCHAChargesNew10", _parameters);

        }
        public static DataSet ShippingBillNo_Select_MAWB(string MAWB)
        {
            SqlParameter[] _parameter ={
                                       new SqlParameter ("@MAWB",MAWB )};
            return SqlHelper.ExecuteDataset(ConnectionString, "ShippingBillNo_Select_MAWB", _parameter);

        }
        public static DataSet getChargewiseDetails(DateTime datFromDate, DateTime datToDat, string CompBrSNo, string ChargeId,string CHA)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDat  ),
                                             new SqlParameter("@CompBrSNo",CompBrSNo)  , 
                                              new SqlParameter("@ChargeId",ChargeId )  ,
                                              new SqlParameter("@CHA",CHA )  
             
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getChargewiseDetails", _parameters);

        }
        public static DataSet getAllCHABills(DateTime datFromDate, DateTime datToDat, string CompBrSNo,int CHASno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDat  ),
                                             new SqlParameter("@CompBrSNo",CompBrSNo),
                                                 new SqlParameter("@CHASno",CHASno)
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCHABills", _parameters);

        }
        public static DataSet getAllRFBVSBillCharge(DateTime datFromDate, DateTime datToDat, string  CompBrSNo,string Type)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDat  ),
                                             new SqlParameter("@CompBrSNo",CompBrSNo),
                                             new SqlParameter("@Type",Type)
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getAllRFBVSBillCharge", _parameters);

        }
        public static DataSet GetCM1ActualProfit(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno1",CompBrSno1),
                                             
                                             new SqlParameter("@FromDate",FromDate),
                                            new SqlParameter("@ToDate",ToDate  ),
                                            new SqlParameter("@MAWBNO",MAWBNO )
                                           
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "GetCM1ActualProfit", _parameters);
        }
        public static DataSet GetCM1OverallProfit(int CompBrSno1, DateTime FromDate, DateTime ToDate,string Type, string city)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSNo1",CompBrSno1),
                                             
                                             new SqlParameter("@FromDate",FromDate),
                                            new SqlParameter("@ToDate",ToDate  ),
                                            new SqlParameter("@Type",Type),
                                            new SqlParameter("@City",city)
                                           
                                           
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "GetCM1OverallProfitNew", _parameters);
        }
        public static DataSet GetCM1ActualProfitImp(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno1",CompBrSno1),
                                             
                                             new SqlParameter("@FromDate",FromDate),
                                            new SqlParameter("@ToDate",ToDate  ),
                                            new SqlParameter("@MAWBNO",MAWBNO )
                                           
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "GetCM1ActualProfitImp", _parameters);
        }
        public static DataSet GetCM1ActualProfitSeaImp(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno1",CompBrSno1),
                                             
                                             new SqlParameter("@FromDate",FromDate),
                                            new SqlParameter("@ToDate",ToDate  ),
                                            new SqlParameter("@MAWBNO",MAWBNO )
                                           
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "GetCM1ActualProfitSeaImp", _parameters);
        }
        public static DataSet GetCM1ActualProfitSeaExp(int CompBrSno1, DateTime FromDate, DateTime ToDate, string MAWBNO)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno1",CompBrSno1),
                                             
                                             new SqlParameter("@FromDate",FromDate),
                                            new SqlParameter("@ToDate",ToDate  ),
                                            new SqlParameter("@MAWBNO",MAWBNO )
                                           
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "GetCM1ActualProfitSeaExp", _parameters);
        }
        public static DataSet getPNPsellingCM1profit(int CompBrSno, string MAWBNO)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno1",CompBrSno),
                                             
                                            new SqlParameter("@MAWBNO",MAWBNO )
                                           
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getPNPsellingCM1profit", _parameters);
        }
        public static DataSet getPNPsellingCM1profit(int CompBrSno, string MAWBNO, string HAWB,string Type)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                             
                                            new SqlParameter("@MAWBNO",MAWBNO ),
                                            new SqlParameter("@HAWB",HAWB ),
                                           new SqlParameter("@Type",Type)
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getPNPsellingCM1profitNew", _parameters);
        }
        public static DataSet getSeaGroups(DateTime fromDate, DateTime toDate, string CompBrSNo, string Type,string CustType)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate),
                new SqlParameter("@CompBrSNo",CompBrSNo),
                 new SqlParameter("@Type",Type ),
                 new SqlParameter("@CustType",CustType )
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaGroups", _param);
        }
        public static DataSet getSeaReportNone(DateTime fromDate, DateTime toDate, string CompBrSNo,string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo),
                new SqlParameter("@Type",Type) 
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaReportNone", _param);
        }
        public static DataSet getSeaProductwiseReport(DateTime fromDate, DateTime toDate, string CompBrSNo,string Group, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo),
                new SqlParameter("@Group",Group),
                new SqlParameter("@Type",Type)
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaProductwiseReport", _param);
        }
        public static DataSet getSeaPersonwiseReport(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo),
                new SqlParameter("@Group",Group),
                new SqlParameter("@Type",Type)      
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaPersonwiseReport", _param);
        }
        public static DataSet getSeaReportOriginwise(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo),
                new SqlParameter("@Group",Group),
                new SqlParameter("@Type",Type)           
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaReportOriginwise", _param);
        }
        public static DataSet getSeaReportDestwise(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo),
                new SqlParameter("@Group",Group),
                new SqlParameter("@Type",Type)         
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaReportDestwise", _param);
        }
        public static DataSet getSeaCM1Report(DateTime fromDate, DateTime toDate, string CompBrSNo, string Group, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo) ,
                 new SqlParameter("@Group",Group),
                new SqlParameter("@Type",Type)            
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaCM1Report", _param);
        }
        public static DataSet getSeaReportSmallShptwise(DateTime fromDate, DateTime toDate, string CompBrSNo, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo),
                new SqlParameter("@Type",Type) 
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSeaReportSmallShptwise", _param);
        }
        public static DataSet GetCustomer_PartywiseRpt(int CompBrSno, DateTime fromDate, DateTime toDate)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@CompBrSno",CompBrSno),
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  
                
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetCustomer_PartywiseRptNew", _param);
        }
        public static DataSet GetGroupsForCM1Report(DateTime FromDate, DateTime ToDate, string CompBrSNo, string GroupBy, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@FromDate",FromDate),
                new SqlParameter("@ToDate",ToDate),
                new SqlParameter("@CompBrSNo",CompBrSNo),
                new SqlParameter("@GroupBy",GroupBy),
                 new SqlParameter("@Type",Type )
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetGroupsForCM1Report", _param);
        }
        public static DataSet getGroupsImports(DateTime fromDate, DateTime toDate, string CompBrSNo, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate)  ,
                new SqlParameter("@CompBrSNo",CompBrSNo)    ,
                 new SqlParameter("@Type",Type )
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getGroupsImports1", _param);
        }
        public static DataSet GetOutstandingCustomers(DateTime Date, string CompBrSNo,string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@Date",Date),
                
                new SqlParameter("@CompBrSNo",CompBrSNo) ,
                new SqlParameter("@Type",Type) 
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetOutstandingCustomers", _param);
        }
        public static SqlDataReader getLogindetail(string UserId)
    {
    SqlParameter[] _parameters={
                               new SqlParameter("@UserId",UserId)
                               };
    return SqlHelper.ExecuteReader(PaceCommon.ConnectionString, "getLogindetail", _parameters);
    }
        public static DataSet getLogindetailNew(string UserId)
        {
            SqlParameter[] _parameters ={
                               new SqlParameter("@UserId",UserId)
                               };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getLogindetail", _parameters);
        }
        public static DataSet GetCustomerDetailForMail(string Sno,string UserID)
        {
            SqlParameter[] _parameters ={
                                   new SqlParameter("@Sno",Sno),
                                   new SqlParameter("@UserID",UserID)
                                   };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetCustomerDetailForMail", _parameters);
        }
        public static DataSet GetCustomer_PartywiseRpt(int CompBrSno, DateTime fromDate, DateTime toDate, string Type)
        {
            SqlParameter[] _param = {  
                new SqlParameter("@CompBrSno",CompBrSno),
                new SqlParameter("@fromDate",fromDate),
                new SqlParameter("@toDate",toDate) ,
                new SqlParameter("@Type",Type)  
                
          };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetCustomer_PartywiseRpt1", _param);
        }
        public static DataSet ClientwisePaymentPerformanceRpt(string strCompBrSNo, string CustBrSno, string CustType, string strType, DateTime datFromDate, DateTime datToDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@CompBrSno",strCompBrSNo),
                                             new SqlParameter("@CustBrSno",CustBrSno),
                                              new SqlParameter("@CustType",CustType),
                                            new SqlParameter("@Type",strType), 
                                            new SqlParameter("@FromDate",datFromDate),
                                            new SqlParameter("@ToDate",datToDate)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "ClientwisePaymentPerformanceRpt", _parameters);
        }
        public static DataSet GetAllCM1Report(DateTime FromDate,DateTime Todate, string CompBrSno, string GroupBy, string GroupByName, string Type,string Report)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",FromDate),
                                             new SqlParameter("@Todate",Todate),
                                              new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@GroupBy",GroupBy), 
                                            new SqlParameter("@GroupByName",GroupByName),
                                            new SqlParameter("@Type",Type),
                                            new SqlParameter("@Report",Report)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetAllCM1Report", _parameters);
        }
        public static DataSet getProductReportNew(DateTime FromDate, DateTime Todate, string CompBrSno, string Type, string Product, string Fair)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",FromDate),
                                             new SqlParameter("@Todate",Todate),
                                              new SqlParameter("@CompBrSno",CompBrSno),
                                              new SqlParameter("@Type",Type),
                                            new SqlParameter("@Product",Product),
                                            new SqlParameter("@Fair",Fair),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getProductReportNew", _parameters);
        }
        public static DataSet getCM1(DateTime FromDate, DateTime Todate, string CompBrSno, string GroupBy, string GroupByName, string Type)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",FromDate),
                                             new SqlParameter("@Todate",Todate),
                                              new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@GroupBy",GroupBy), 
                                            new SqlParameter("@GroupByName",GroupByName),
                                            new SqlParameter("@Type",Type)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getCM1", _parameters);
        }
        // For Pending DO Report
        public static DataSet GetPendingDO(DateTime FromDate, DateTime Todate, string CompBrSno,string Type)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",FromDate),
                                             new SqlParameter("@Todate",Todate),
                                              new SqlParameter("@CompBrSno",CompBrSno),
                                              new SqlParameter("@Type",Type)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetPendingDO", _parameters);
        }
        // For Approved/Unapproved/NotTransfertoTally Invoices
        public static DataSet getInvoicesApprovedUnapproved(DateTime fromDate, DateTime toDate, string transferToTally, string completed, string compBrSno, string type)
        {
            SqlParameter[] _parameters ={
                                   new SqlParameter("@fromDate",fromDate),
                                   new SqlParameter("@toDate",toDate),
                                   new SqlParameter("@transferToTally",transferToTally),
                                   new SqlParameter("@completed",completed),
                                   new SqlParameter("@compBrSno",compBrSno),
                                   new SqlParameter("@type",type)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "getInvoicesApprovedUnapproved", _parameters);
        }
        public static DataSet getPayableReceivableCustomers(DateTime fromDate, DateTime toDate, string type, string source, string paymentType, string company)
        {
            SqlParameter[] _parameters ={
                                   new SqlParameter("@fromDate",fromDate),
                                   new SqlParameter("@toDate",toDate),
                                   new SqlParameter("@type",type),
                                   new SqlParameter("@source",source),
                                   new SqlParameter("@paymentType",paymentType),
                                   new SqlParameter("@company",company)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "getPayableReceivableCustomers", _parameters);
        }
        //GetPayableReceivableBills
        public static DataSet GetPayableReceivableBills(DateTime fromDate, DateTime toDate, string type, string source, string paymentType, string company,string customerName)
        {
            SqlParameter[] _parameters ={
                                   new SqlParameter("@fromDate",fromDate),
                                   new SqlParameter("@toDate",toDate),
                                   new SqlParameter("@type",type),
                                   new SqlParameter("@source",source),
                                   new SqlParameter("@paymentType",paymentType),
                                   new SqlParameter("@company",company),
                                   new SqlParameter("@customerName",customerName)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetPayableReceivableBills", _parameters);
        }
        //Get ServiceTax Report
        public static DataSet GetServiceTaxReport(DateTime fromDate, DateTime toDate,  string CompBrSno, string type,string groupBy)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@type",type),
                                            new SqlParameter("@groupBy",groupBy)
                              
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetServiceTaxReport", _parameters);
        }
        //Get Pending Bills Report
        public static DataSet GetPendingBillsReport(DateTime fromDate, DateTime toDate, string type, string CompBrSno)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                            new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSno)
                              
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetPendingBillsReport", _parameters);
        }
        //Get Invoicewise Profitability Report
        public static DataSet GetInvoicewiseProfitabilityReport(DateTime fromDate, DateTime toDate, int customerBranchSno, string type, string customerType, string companyBranchSno)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@customerBranchSno",customerBranchSno),
                                            new SqlParameter("@type",type),
                                            new SqlParameter("@customerType",customerType),
                                            new SqlParameter("@CompBrSno",companyBranchSno)
                              
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "getInvoicewiseProfitabilityReport", _parameters);
        }
        //Check Cr Limit for ManagePace
        public static DataSet CreditLimitCheck()
        {
            SqlParameter[] _parameters ={
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "CreditLimitCheck", _parameters);
        }
        public static String updateManagePaceCreditLimit(int customerMasterSno,decimal groupCreditLimit,decimal groupUsedCreditLimit,decimal groupAvailableCreditLimit)
        {
            SqlParameter[] _param = {      
                                           new SqlParameter("@customerMasterSno",customerMasterSno),
                                           new SqlParameter("@groupCreditLimit",groupCreditLimit),
                                           new SqlParameter("@groupUsedCreditLimit",groupUsedCreditLimit),
                                           new SqlParameter("@groupAvailableCreditLimit",groupAvailableCreditLimit)
               

        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateManagePaceCreditLimit", _param));

        }

        public static String UpdateStockMasterSearch(int SNo, string ReceivedFrom, DateTime ReceivedDate,string AirlineType)
        {
            SqlParameter[] _param = {      
                                           new SqlParameter("@SNo",SNo),
                                           new SqlParameter("@ReceivedFrom",ReceivedFrom),
                                           new SqlParameter("@ReceivedDate",ReceivedDate),
                new SqlParameter("@AirlineType",AirlineType)

        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "UpdateStockMasterSearch", _param));

        }

        public static String updateBillDate(int Sno, DateTime BillDate, DateTime InvoiceDueDate)
        {
            SqlParameter[] _param = {      
                                           new SqlParameter("@Sno",Sno),
                                           new SqlParameter("@BillDate",BillDate),
                                           new SqlParameter("@InvoiceDueDate",InvoiceDueDate)
               

        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateBillDate", _param));

        }

        public static DataSet getCompanyName()
        {
            SqlParameter[] _parameters ={
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "getCompanyName", _parameters);
        }
        public static DataSet BillDisapproveSelect(int SNo,string MawbNo,string InvoiceNo)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@SNo",SNo),
                                            new SqlParameter("@MawbNo",MawbNo),
                                            new SqlParameter("@InvoiceNo",InvoiceNo),
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillDisapproveSelect", _parameters);
        }

        public static DataSet AirExport_Mawb(Int64 CompBrSno, string Date)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@Date",Date)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "AirExport_Mawb", _parameters);
        }


        public static DataSet AirExport_Hawb(Int64 CompBrSno, string Date)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@Date",Date)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "AirExport_Hawb", _parameters);
        }

        public static DataSet AirExport_MawbI(Int64 CompBrSno, string Date1)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@Date",Date1)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "AirExport_MawbI", _parameters);
        }

        public static DataSet AirExport_HawbI(Int64 CompBrSno, string Date1)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@Date",Date1)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "AirExport_HawbI", _parameters);
        }
        public static DataSet BillDateSelect(int SNo, string MawbNo, string InvoiceNo)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@SNo",SNo),
                                            new SqlParameter("@MawbNo",MawbNo),
                                            new SqlParameter("@InvoiceNo",InvoiceNo),
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "BillDateSelect", _parameters);
        }

        public static DataSet Can_Do_Select(int SNo, string MawbNo)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@SNo",SNo),
                                            new SqlParameter("@MawbNo",MawbNo),
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "Can_Do_Select", _parameters);
        }

        public static string Can_Do_Update(int Sno)
        {
            SqlParameter[] _param = {      
                                           new SqlParameter("@Sno",Sno)
               

        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Can_Do_Update", _param));

        }



        public static string BillDisapproved(int SNo)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@SNo",SNo),
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "BillDisapproved", _parameters));
        }
        public static DataSet getAdditionalExpenses(string MawbNo,string InvoiceNo)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@MawbNo",MawbNo),
                                            new SqlParameter("@InvoiceNo",InvoiceNo),
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAdditionalExpenses", _parameters);
        }
        public static string AdditionalExpSubmitted(int tSNo, string Inv, DateTime InvDate, string MarkpaidBy)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@MasterSNo",tSNo),
                                            new SqlParameter("@Inv",Inv),
                                            new SqlParameter("@InvDate",InvDate),
                                            new SqlParameter("@MarkpaidBy",MarkpaidBy),
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "AdditionalExpSubmitted", _parameters));
        }
        public static string AdditionalExpSubmittedAir(int tSNo, string Remarks, string Inv, DateTime InvDate,DateTime InvReceiveDate, string MarkpaidBy)
        {
            SqlParameter[] _parameters ={ 
                                            new SqlParameter("@tSNo",tSNo),
                                             new SqlParameter("@Remarks",Remarks),
                                             new SqlParameter("@Inv",Inv),
                                            new SqlParameter("@InvDate",InvDate),
                                             new SqlParameter("@InvReceiveDate",InvReceiveDate),
                                            new SqlParameter("@MarkpaidBy",MarkpaidBy),
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "AdditionalExpSubmittedAirNew", _parameters));
        }

        public static string AdditionalExpSubmittedRI(int MasterSNo)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@MasterSNo",MasterSNo)
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "AdditionalExpSubmittedRI", _parameters));
        }
        public static string AdditionalExpSubmittedRIAir(int MasterSNo, string Remarks, string Inv, DateTime InvDate, DateTime InvReceiveDate)
        {
            SqlParameter[] _parameters ={
                                           
                                            new SqlParameter("@MasterSNo",MasterSNo),
                                             new SqlParameter("@Remarks",Remarks),
                                               new SqlParameter("@Inv",Inv),
                                            new SqlParameter("@InvDate",InvDate),
                                             new SqlParameter("@InvReceiveDate",InvReceiveDate),
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "AdditionalExpSubmittedRIAir", _parameters));
        }

        public static DataSet getAllAWBForDebitNote(DateTime fromDate, DateTime toDate, string CompBrSno)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@CompBrSno",CompBrSno)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAllAWBForDebitNote", _parameters);
        }
        public static DataSet getSubAgentCSR(DateTime fromDate, DateTime toDate, string CompBrSno,string subAgentSno,string subAgentCSRStatus)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                             new SqlParameter("@SubAgentSno",subAgentSno),
                                             new SqlParameter("@SubAgentCSRStatus",subAgentCSRStatus)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getSubAgentCSR", _parameters);
        }
        public static DataSet getMawbForCSR(DateTime fromDate, DateTime toDate, string CompBrSno, string subAgentSno, string subAgentCSRStatus)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                             new SqlParameter("@SubAgentSno",subAgentSno),
                                             new SqlParameter("@SubAgentCSRStatus",subAgentCSRStatus)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getMawbForCSR", _parameters);
        }

        public static DataSet getAirlineCSR(DateTime fromDate, DateTime toDate, string CompBrSno, string Airline, string airlineCSRStatus,string type)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                             new SqlParameter("@AirlineCode",Airline),
                                             new SqlParameter("@AirlineCSRStatus",airlineCSRStatus),
                                             new SqlParameter("@Type",type),
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAirlineCSR", _parameters);
        }
        public static DataSet getInvoiceNoAndCM1ForAirlineCSR(string MAWB,string compBrSno)
        {
            SqlParameter[] _parameters ={
                                            
                                             new SqlParameter("@MAWB",MAWB),
                                             new SqlParameter("@CompBrSno",compBrSno)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getInvoiceNoAndCM1ForAirlineCSR", _parameters);
        }
        public static String generateSubAgentCSR(DateTime fromDate, DateTime toDate, int CompBrSno, int subAgentSno,string generatedBy)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@compBrSno",CompBrSno),
                                             new SqlParameter("@subAgentSno",subAgentSno),
                                             new SqlParameter("@genratedBy",generatedBy)
                                        };
            return Convert.ToString( SqlHelper.ExecuteScalar(ConnectionString, "generateSubAgentCSR", _parameters));
        }
        public static String generateAirlineCSR(string generatedBy,DateTime fromDate, DateTime toDate,int AWBTableSno, string CompBrSno)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@AirlineCSRCreatedBy",generatedBy),
                                            new SqlParameter("@AirlineFromDate",fromDate),
                                             new SqlParameter("@AirlineToDate",toDate),
                                             new SqlParameter("@AWBTableSno",AWBTableSno),
                                             new SqlParameter("@CompBrSno",CompBrSno)
                                        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "generateAirlineCSR", _parameters));
        }
        public static DataSet getAirlineDebitNote(DateTime fromDate, DateTime toDate, string CompBrSno, string AirlineCode,string Type)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@AirlineCode",AirlineCode),
                                             new SqlParameter("@Type",Type)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAirlineDebitNote", _parameters);
        }
        public static DataSet getAirlineDebitNoteView(string AirlineCode,string DebitNoteNo,string Type)
        {
            SqlParameter[] _parameters ={
                                             
                                            new SqlParameter("@AirlineCode",AirlineCode),
                                            new SqlParameter("@DebitNoteNo",DebitNoteNo),
                                            new SqlParameter("@Type",Type)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAirlineDebitNoteView", _parameters);
        }
        public static DataSet getAirlineCodeForDebitNote(DateTime fromDate, DateTime toDate, int CompBrSno)
        {
            SqlParameter[] _parameters ={
                                             
                                            new SqlParameter("@fromDate",fromDate),
                                            new SqlParameter("@toDate",toDate),
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAirlineCodeForDebitNote", _parameters);
        }
        public static string updateAWBForAirlineDebitNote(int AwbSno,int CompBrSno,string AirlineDebitNoteNo,string DebitNoteStatus,DateTime DebitNoteDate,string DebitNoteCreatedBy,DateTime DebitNoteFromDate,DateTime DebitNoteToDate)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@AwbSno",AwbSno),
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@AirlineDebitNoteNo",AirlineDebitNoteNo),
                                            new SqlParameter("@DebitNoteStatus",DebitNoteStatus),
                                            new SqlParameter("@DebitNoteDate",DebitNoteDate),
                                            new SqlParameter("@DebitNoteCreatedBy",DebitNoteCreatedBy),
                                                new SqlParameter("@DebitNoteFromDate",DebitNoteFromDate),
                                                    new SqlParameter("@DebitNoteToDate",DebitNoteToDate)
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateAWBForAirlineDebitNote", _parameters));
        }
        public static DataSet getMaxAirlineDebitNoteNo(string AirlineDebitNoteNo)
        {
            SqlParameter[] _parameters ={
                                           
                                            new SqlParameter("@DebitNoteNo",AirlineDebitNoteNo)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getMaxAirlineDebitNoteNo", _parameters);
        }
        // generate CM1--update billing_trans
        //public static string generateCM1( string BMSno, string userID, DateTime fromDate, DateTime toDate)
        //{
        //    SqlParameter[] _parameters ={
                                           
        //                                    new SqlParameter("@BMSno",BMSno),
        //                                     new SqlParameter("@userID",userID),
        //                                      new SqlParameter("@fromDate",fromDate),
        //                                       new SqlParameter("@toDate",toDate)
        //                                };
        //    return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "generateCM1", _parameters));
        //}
        public static string generateCM1(string BMSno, string userID, string CompBrSno, string Type, DateTime fromDate, DateTime toDate)
        {
            SqlParameter[] _parameters ={
                                             new SqlParameter("@BMSno",BMSno),
                                             new SqlParameter("@userID",userID),
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                             new SqlParameter("@Type",Type),
                                              new SqlParameter("@fromDate",fromDate),
                                               new SqlParameter("@toDate",toDate)
                                        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "generateCM1", _parameters));
        }
        public static int ChangeStatusActual(int tSNo,string inv,DateTime invDate,string description)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@tSNo",tSNo),
                                             new SqlParameter("@inv",inv),
                                              new SqlParameter("@invDate",invDate),
                                             new SqlParameter("@description",description),
            };
            return SqlHelper.ExecuteNonQuery(ConnectionString, "ChangeStatusActual", _parameters);
        }
        public static string UpdateCharge(int tSNo, string Remarks, string Inv, DateTime InvDate, DateTime InvReceiveDate)
        {
            SqlParameter[] _parameters ={ 
                                            new SqlParameter("@tSNo",tSNo),
                                             new SqlParameter("@Remarks",Remarks),
                                             new SqlParameter("@Inv",Inv),
                                            new SqlParameter("@InvDate",InvDate),
                                             new SqlParameter("@InvReceiveDate",InvReceiveDate),
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "UpdateCharge", _parameters));
        }

        
        public static string UpdateRI(int MasterSNo, string Remarks, string Inv, DateTime InvDate, DateTime InvReceiveDate)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@MasterSNo",MasterSNo),
                                             new SqlParameter("@Remarks",Remarks),
                                              new SqlParameter("@Inv",Inv),
                                            new SqlParameter("@InvDate",InvDate),
                                             new SqlParameter("@InvReceiveDate",InvReceiveDate),
                                   };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "UpdateRI", _parameters));
        }

        public static DataSet GetAirExportTonnage(DateTime fromDate, DateTime toDate, string CompBrSNo, string Airline, string Destination)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                            new SqlParameter("@CompBrSNo",CompBrSNo),
                                             new SqlParameter("@Airline",Airline), 
                                             new SqlParameter("@Destination",Destination)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetAirExportTonnage", _parameters);
        }


        public static DataSet getAccountReview(DateTime fromDate, DateTime toDate, string customerBranchSno, string TypeName, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                    new SqlParameter("@customerBranchSno",customerBranchSno), 
                                              new SqlParameter("@type",TypeName), 
                                            new SqlParameter("@CompBrSNo",CompBrSNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAccountReview", _parameters);
        }
        public static DataSet getVendorJEView(DateTime fromDate, DateTime toDate, string customerBranchSno, string TypeName, string CompBrSNo,String ExpType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                    new SqlParameter("@customerBranchSno",customerBranchSno), 
                                              new SqlParameter("@type",TypeName), 
                                            new SqlParameter("@CompBrSNo",CompBrSNo),
                                            new SqlParameter("@ExpType",ExpType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getVendorJEView", _parameters);
        }

        public static string insertCSRData(int AWBTableSno,int BookingSno,string BMSno,DateTime AWBDate, string freightType,string origin, string destination,
decimal weight,decimal rate,decimal PPCC,decimal AWBFee,decimal HAWBFee,decimal OSC,decimal DA,decimal DC,decimal TotalPP,decimal commAmt, decimal commRate,
decimal spotAmt,decimal spotRate,decimal incAmt,decimal incRate,decimal tdsAmt,decimal tdsRate,decimal TC,decimal doorDel,decimal clearance,decimal others,
    decimal staxAmt,decimal totalDueAmt,int compBrSno,string paymentTableSno,decimal paymentAmt,string MAWB,string CSR,string CustBrSno,string fortNight)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@AWBTableSno",AWBTableSno),
                                             new SqlParameter("@BookingSno",BookingSno), 
                                    new SqlParameter("@BMSno",BMSno), 
                                              new SqlParameter("@AWBDate",AWBDate), 
                                            new SqlParameter("@freightType",freightType),
                                            new SqlParameter("@origin",origin),
                                             new SqlParameter("@destination",destination), 
                                    new SqlParameter("@weight",weight), 
                                              new SqlParameter("@rate",rate), 
                                            new SqlParameter("@PPCC",PPCC),
                                            new SqlParameter("@AWBFee",AWBFee),
                                             new SqlParameter("@HAWBFee",HAWBFee), 
                                    new SqlParameter("@OSC",OSC), 
                                              new SqlParameter("@DA",DA), 
                                            new SqlParameter("@DC",DC),
                                            new SqlParameter("@TotalPP",TotalPP),
                                             new SqlParameter("@commAmt",commAmt), 
                                    new SqlParameter("@commRate",commRate), 
                                              new SqlParameter("@spotAmt",spotAmt), 
                                            new SqlParameter("@spotRate",spotRate),
                                              new SqlParameter("@incAmt",incAmt), 
                                              new SqlParameter("@incRate",incRate), 
                                            new SqlParameter("@tdsAmt",tdsAmt),
                                            new SqlParameter("@tdsRate",tdsRate),
                                             new SqlParameter("@TC",TC), 
                                    new SqlParameter("@doorDel",doorDel), 
                                              new SqlParameter("@clearance",clearance), 
                                            new SqlParameter("@others",others),
                                            new SqlParameter("@staxAmt",staxAmt),
                                             new SqlParameter("@totalDueAmt",totalDueAmt), 
                                    new SqlParameter("@compBrSno",compBrSno), 
                                              new SqlParameter("@paymentTableSno",paymentTableSno), 
                                               new SqlParameter("@paymentAmt",paymentAmt), 
                                            new SqlParameter("@MAWB",MAWB),
                                            new SqlParameter("@CSR",CSR),
                                            new SqlParameter("@CustBrSno",CustBrSno),
                                              new SqlParameter("@FortNight",fortNight)
                                         
            };
            return Convert.ToString(SqlHelper.ExecuteDataset(ConnectionString, "insertCSRData", _parameters));
        }
        public static int MOTDataEntry(int bankMastSno,string DDNo, DateTime DDDate, decimal Amount, string PayTo, string AddedBy, DateTime AddedDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BankMastSno",bankMastSno),
                                             new SqlParameter("@DDNo",DDNo),
                                             new SqlParameter("@DDDate",DDDate), 
                                             new SqlParameter("@Amount",Amount),
                                             new SqlParameter("@PayTo",PayTo), 
                                              new SqlParameter("@AddedBy",AddedBy), 
                                              new SqlParameter("@AddedDate",AddedDate)
                                              
            };
            return Convert.ToInt32( SqlHelper.ExecuteNonQuery(ConnectionString, "MOTDataEntry", _parameters));
        }
        public static DataSet InsertCHAChargeAWB(string Mawbno, int BookingID, string Origin, string Destination, string Currency, int AgentSNo, int ShipperSNo, int ConsigneeSNo, string ShipperUsedBy, string ShipmentType, string FreightType, decimal ChargeableWt, decimal CWtCharges, decimal CValCharges, decimal CTotalDueAgent, decimal CTotalDueCarrier, decimal CTotal, string ShipperSign, DateTime AWBDate, string CarrierSign, DateTime HandOverDate, int CompBrSNo, string AddedBy, DateTime AddedDate, string BillType, string ShipperUsedByCity, string WTCC, string OtherCC, string WTPP, string OtherPP, int CHASNO, string CopyToBaseCompany)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@Mawbno",Mawbno),
                                             new SqlParameter("@BookingID",BookingID), 
                                             new SqlParameter("@Origin",Origin),
                                             new SqlParameter("@Destination",Destination),
                                              new SqlParameter("@Currency",Currency),
                                             new SqlParameter("@AgentSNo",AgentSNo), 
                                             new SqlParameter("@ShipperSNo",ShipperSNo),
                                             new SqlParameter("@ConsigneeSNo",ConsigneeSNo), 
                                              new SqlParameter("@ShipperUsedBy",ShipperUsedBy), 
                                              new SqlParameter("@ShipmentType",ShipmentType),
                                              new SqlParameter("@FreightType",FreightType),
                                              new SqlParameter("@ChargeableWt",ChargeableWt),
                                             new SqlParameter("@CWtCharges",CWtCharges), 
                                             new SqlParameter("@CValCharges",CValCharges),
                                             new SqlParameter("@CTotalDueAgent",CTotalDueAgent), 
                                              new SqlParameter("@CTotalDueCarrier",CTotalDueCarrier), 
                                              new SqlParameter("@CTotal",CTotal),
                                              new SqlParameter("@ShipperSign",ShipperSign),
                                             new SqlParameter("@AWBDate",AWBDate), 
                                             new SqlParameter("@CarrierSign",CarrierSign),
                                             new SqlParameter("@HandOverDate",HandOverDate), 
                                              new SqlParameter("@CompBrSNo",CompBrSNo), 
                                              new SqlParameter("@AddedBy",AddedBy),
                                               new SqlParameter("@AddedDate",AddedDate),
                                               new SqlParameter("@BillType",BillType),
                                               new SqlParameter("@ShipperUsedByCity",ShipperUsedByCity),
                                               new SqlParameter("@WTCC",WTCC),
                                               new SqlParameter("@OtherCC",OtherCC),
                                               new SqlParameter("@WTPP",WTPP),
                                               new SqlParameter("@OtherPP",OtherPP),
                                               new SqlParameter("@CHASNO",CHASNO),
                                               new SqlParameter("@CopyToBaseCompany",CopyToBaseCompany)

                                              
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "InsertCHAChargeAWB", _parameters);
        }
        public static DataSet GetCheque()
        {

            SqlParameter[] _parameters ={
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetChequeEntry", _parameters);
        }
        public static DataSet getDetailsOfOutstandingCustomers(string compBrSno, string type)
        {

            SqlParameter[] _parameters ={
                                            new SqlParameter("@compBrSno",compBrSno),
                                            new SqlParameter("@type",type)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "getDetailsOfOutstandingCustomers", _parameters);
        }
        public static DataSet getOverdueDays(int custBrSno,string compBrSno,string type)
        {

            SqlParameter[] _parameters ={
                                             new SqlParameter("@custBrSno",custBrSno),
                                            new SqlParameter("@compBrSno",compBrSno),
                                             new SqlParameter("@type",type)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "getOverdueDays", _parameters);
        }
        public static DataSet getAllTerminalCharges(DateTime fromDate, DateTime Todate, string MAWBNo, string HAWBNo, string TransactionNo)
        {

            SqlParameter[] _parameters ={
                            new SqlParameter("@FromDate",fromDate),
                            new SqlParameter("@ToDate",Todate),
                            new SqlParameter("@MAWBNO",MAWBNo),
                            new SqlParameter("@HAWBNO",HAWBNo),
                             new SqlParameter("@TransactionNo",TransactionNo),
                            };
            return SqlHelper.ExecuteDataset(ConnectionString, "TCReport_BillingIncome", _parameters);
        }


        public static DataSet getTerminalChargeDetails(DateTime fromDate, DateTime toDate, string strCity, int strChargeId)
        {

            SqlParameter[] _parameters ={
new SqlParameter("@FromDate",fromDate),
new SqlParameter("@ToDate",toDate),
new SqlParameter("@CompBrSno",strCity),
new SqlParameter("@ChargeID",strChargeId),
};
            return SqlHelper.ExecuteDataset(ConnectionString, "getTerminalChargeDetails", _parameters);
        }
        public static DataSet GetShipmentLoss(DateTime fromDate, DateTime toDate, string CompBrSno, string reportType)
        {

            SqlParameter[] _parameters ={
                                             new SqlParameter("@FromDate",fromDate),
                                            new SqlParameter("@ToDate",toDate),
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                             new SqlParameter("@Type",reportType),
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetShipmentLoss", _parameters);
        }
        public static DataSet GetPartyWiseIncome(DateTime fromDate, DateTime toDate, string customerBranchSno, string TypeName, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                    new SqlParameter("@customerBranchSno",customerBranchSno), 
                                              new SqlParameter("@type",TypeName), 
                                            new SqlParameter("@CompBrSNo",CompBrSNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetPartyWiseIncome", _parameters);
        }
        public static DataSet getBookingMail(DateTime fromDate, DateTime toDate, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",fromDate),
                                             new SqlParameter("@ToDate",toDate), 
                                            new SqlParameter("@CompBrSno",CompBrSNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBookingMail", _parameters);
        }
        public static DataSet getDataInternatiopnalBizReport(string fromDate, string toDate,string networkName,string top, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@NetworkName",networkName),
                                             new SqlParameter("@Top",top),
                                            new SqlParameter("@CompBrSno",CompBrSNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getDataInternatiopnalBizReport", _parameters);
        }
        public static DataSet getBillsForCompletion(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForCompletion", _parameters);
        }
        public static DataSet getBillsForCompletionTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForCompletion_T", _parameters);
        }
        public static DataSet getBillsForCompletionNonTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForCompletion_NT", _parameters);
        }


        public static DataSet getBillsForCompletionNonTaxableCD(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForCompletion_NT_CD", _parameters);
        }
        public static DataSet getBillsForCompletionGST(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForCompletionGST", _parameters);
        }
        public static DataSet getBillsForTallyTransfer(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTallyTransfer", _parameters);
        }
        public static DataSet getBillsForTallyTransferTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTallyTransfer_T", _parameters);
        }
        public static DataSet getBillsForTallyTransferNonTaxable(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTallyTransfer_NT", _parameters);
        }

        public static DataSet getBillsForTallyTransferNonTaxableCD(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTallyTransfer_NT_CD", _parameters);
        }
        public static DataSet getBillsForTallyTransferGST(string fromDate, string toDate, string type, string CompBrSNo, string billType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@fromDate",fromDate),
                                             new SqlParameter("@toDate",toDate), 
                                             new SqlParameter("@type",type),
                                            new SqlParameter("@CompBrSno",CompBrSNo),
                                            new SqlParameter("@billType",billType)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTallyTransferGST", _parameters);
        }
        public static string updateBillCompleted(string BMSno, string updatedBy, string updatedType, DateTime tallyDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",BMSno),
                                             new SqlParameter("@updatedBy",updatedBy), 
                                             new SqlParameter("@updatedType",updatedType),
                                             new SqlParameter("@tallyDate",tallyDate)
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateBillCompleted", _parameters));
        }
        public static string updateBillCompleted_T(string BMSno, string updatedBy, string updatedType, DateTime tallyDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",BMSno),
                                             new SqlParameter("@updatedBy",updatedBy), 
                                             new SqlParameter("@updatedType",updatedType),
                                             new SqlParameter("@tallyDate",tallyDate)
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateBillCompleted_T", _parameters));
        }
        public static string updateBillCompleted_NT(string BMSno, string updatedBy, string updatedType, DateTime tallyDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",BMSno),
                                             new SqlParameter("@updatedBy",updatedBy), 
                                             new SqlParameter("@updatedType",updatedType),
                                             new SqlParameter("@tallyDate",tallyDate)
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateBillCompleted_NT", _parameters));
        }

        public static string updateBillCompleted_NTCD(string BMSno, string updatedBy, string updatedType, DateTime tallyDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",BMSno),
                                             new SqlParameter("@updatedBy",updatedBy), 
                                             new SqlParameter("@updatedType",updatedType),
                                             new SqlParameter("@tallyDate",tallyDate)
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateBillCompleted_NT_CD", _parameters));
        }
        public static DataSet getBillsForTally(string bmSno)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",bmSno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTally", _parameters);
        }
        public static DataSet getBillsForTallyTaxable(string bmSno)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",bmSno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTally_T", _parameters);
        }
        public static DataSet getBillsForTallyNonTaxable(string bmSno)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",bmSno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTally_NT", _parameters);
        }
        public static DataSet getBillsForTallyNonTaxableCD(string bmSno)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@BMSno",bmSno)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBillsForTally_NT_CD", _parameters);
        }
        public static DataSet GetCustomerType(int CusSNo, string CustNetType)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@SNo",CusSNo),
                                             new SqlParameter("@NetworkType",CustNetType)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetCustomerType", _parameters);
        }
        public static DataSet getHeadNameForTally(string whereCondition)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@whereCondition",whereCondition)
                                        };
            return SqlHelper.ExecuteDataset(ConnectionString, "getHeadNameForTally", _parameters);
        }
        public static string updateTallyHeadName(int Sno, string taxable, string display, string type, string ExpTallyHeadName, string ImpTallyHeadName, string SeaExpTallyHeadName, string SeaImpTallyHeadName)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@Sno",Sno),
                                             new SqlParameter("@taxable",taxable), 
                                             new SqlParameter("@display",display),
                                             new SqlParameter("@type",type),
                                             new SqlParameter("@ExpTallyHeadName",ExpTallyHeadName), 
                                             new SqlParameter("@ImpTallyHeadName",ImpTallyHeadName),
                                             new SqlParameter("@SeaExpTallyHeadName",SeaExpTallyHeadName),
                                             new SqlParameter("@SeaImpTallyHeadName",SeaImpTallyHeadName)
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateTallyHeadName", _parameters));
        }
        public static string insertCreditLimitUses(int custMastSno ,int custBrSno ,int compBrSno ,string transactionType , decimal amount , decimal creditLimit , decimal usedCrLimitBeforeTransaction , decimal usedCrLimitAfterTransaction , decimal availableCrLimitBeforeTransaction , decimal availableCrLimitAfterTransaction , string creditType , string updatedBy ,int bookingSno , int billingSno , int paymentTransSno , int paymentMastSno)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@custMastSno",custMastSno),
                                             new SqlParameter("@custBrSno",custBrSno),
                                             new SqlParameter("@compBrSno",compBrSno), 
                                             new SqlParameter("@transactionType",transactionType),
                                             new SqlParameter("@amount",amount),
                                             new SqlParameter("@creditLimit",creditLimit),
                                             new SqlParameter("@usedCrLimitBeforeTransaction",usedCrLimitBeforeTransaction), 
                                             new SqlParameter("@usedCrLimitAfterTransaction",usedCrLimitAfterTransaction),
                                             new SqlParameter("@availableCrLimitBeforeTransaction",availableCrLimitBeforeTransaction),
                                             new SqlParameter("@availableCrLimitAfterTransaction",availableCrLimitAfterTransaction),
                                             new SqlParameter("@creditType",creditType),
                                             new SqlParameter("@updatedBy",updatedBy), 
                                             new SqlParameter("@bookingSno",bookingSno),
                                             new SqlParameter("@billingSno",billingSno),
                                             new SqlParameter("@paymentTransSno",paymentTransSno),
                                             new SqlParameter("@paymentMastSno",paymentMastSno)
	
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "insertCreditLimitUses", _parameters));
        }

        public static DataSet LocalOverseasCustomer(string CustomerCodeType,int compBrSno)
        {
            SqlParameter[] _parameters ={                                
                            new SqlParameter("@CountryCodeType",CustomerCodeType),
                            new SqlParameter("@CompBrSno",compBrSno),
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetLocalOverseasCustomer", _parameters);

        }
        public static DataSet getSEACostSheet(int SEABLSno, string blType)
        {
            SqlParameter[] _parameters ={                                
                            new SqlParameter("@SEABLSno",SEABLSno),
                            new SqlParameter("@blType",blType)
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSEACostSheet", _parameters);

        }

        public static DataSet GetCM1JEWise(DateTime fromDate, DateTime toDate, string CompBrSno, string reportType)
        {
            SqlParameter[] _parameters ={                                
                            new SqlParameter("@FromDate",fromDate),
                            new SqlParameter("@ToDate",toDate),
                            new SqlParameter("@CompBrSNo",CompBrSno),
                            new SqlParameter("@Type",reportType)
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "CM1ReportJEWise", _parameters);

        }

        public static DataSet GetDSRWeekMail(DateTime DSRDate)
        {
            SqlParameter[] _parameters ={                                
                            new SqlParameter("@DSRDate",DSRDate)
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetDSRWeekMail", _parameters);

        }

        public static DataSet GetDSRSalesPerson()
        {
            SqlParameter[] _parameters ={   
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetDSRSalesPerson", _parameters);

        }

        public static DataSet GetWSRWeekMail(DateTime WSRDate, int CustSNo)
        {
            SqlParameter[] _parameters ={                                
                            new SqlParameter("@WSRDate",WSRDate),
                            new SqlParameter("@CustSNo",CustSNo)
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "GetWSRWeekMail", _parameters);

        }

        public static DataSet getAwbDetail(int AwbSno,string Type)
        {
            SqlParameter[] _parameters ={                                
                            new SqlParameter("@AwbSno",AwbSno),
                             new SqlParameter("@Type",Type)
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getAwbDetail", _parameters);

        }

        public static DataSet getAWBPDFDetail(int AWBSno)
        {
            SqlParameter[] _parameters ={                                
                            new SqlParameter("@AWBSno",AWBSno)
                                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getAWBPDFDetail", _parameters);

        }


    }
    
}

