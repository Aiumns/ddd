using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;
namespace Cfi.App.Pace.Data
{
    public class DAPages : PaceCommon
    {
        public static DataSet getPageHeaders(IPages IP)
        {
            SqlParameter[] _param = { new SqlParameter("@_Header", IP.Header) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_getPageHeaders", _param);
        }

        public static DataSet getLoginTypes(IPages IP)
        {
            SqlParameter[] _param = { new SqlParameter("@_Group", IP.GroupAccess) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_getLoginType", _param);
        }

        public static DataSet getGroupPages(IPages IP)
        {
            SqlParameter[] _param = { 
                                         new SqlParameter("@name", IP.Name),
                                         new SqlParameter("@sno", IP.SNo)    
        };
            return SqlHelper.ExecuteDataset(ConnectionString, "_Retrive_AllowedPages", _param);
        }



        public static DataSet getGroupAllowedPages(int SNo)
        {
            SqlParameter[] _param = {                                        
                                         new SqlParameter("@sno",SNo)    
        };
            return SqlHelper.ExecuteDataset(ConnectionString, "_Retrive_getGroupAllowedPages", _param);
        }



        public static DataSet getGroupRestrictedPages(int SNo)
        {
            SqlParameter[] _param = {                                        
                                         new SqlParameter("@sno", SNo)    
        };
            return SqlHelper.ExecuteDataset(ConnectionString, "_Retrive_getGroupRestrictedPages", _param);
        }

        public static DataSet getNotGroupPages(IPages IP)
        {
            SqlParameter[] _param = { 
                                        new SqlParameter("@name", IP.Name),
                                        new SqlParameter("@sno", IP.SNo) };
                                       
                                   
            return SqlHelper.ExecuteDataset(ConnectionString, "_Retrive_RestrictPages", _param);
        }

        public static SqlDataReader getPages(IPages IP)
        {
            SqlParameter[] _param = { new SqlParameter("@_SNo", IP.SNo)};
            return SqlHelper.ExecuteReader(ConnectionString, "getPages", _param);
        }

        public static SqlDataReader getUserPages(String Allowed)
        {
            SqlParameter[] _param = { new SqlParameter("@_Allowed", Allowed) };
            return SqlHelper.ExecuteReader(ConnectionString, "getUserPages", _param);
        }

        public static DataSet getAllowedPages(IPages IP)
        {
            SqlParameter[] _param = { new SqlParameter("@_SNo", IP.SNo) };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAllowedPages", _param);
        }

        public static DataSet getRestrictedPages(IPages IP)
        {
            SqlParameter[] _param = {
                                       
                                        new SqlParameter("@_SNo", IP.SNo) };
            return SqlHelper.ExecuteDataset(ConnectionString, "getRestrictedPages", _param);
        }

        public static DataSet getAllPages(IPages IP)
        {

            return SqlHelper.ExecuteDataset(ConnectionString, "Retriveallpages"); // _Retrive_AllPages
        }

        public static SqlDataReader getUserData(IPages IP)
        {
            SqlParameter[] _param = { new SqlParameter("@_SNo", IP.SNo) };
            return SqlHelper.ExecuteReader(ConnectionString, "getUsers", _param);
        }

        public static String RestrictPage(string pageName)
        {
            SqlParameter[] _Param = { new SqlParameter("@_pageName", pageName) };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, "_Restrict_Page", _Param));
        }

        public static String getPageHelp(string pageName)
        {
            SqlParameter[] _Param = { new SqlParameter("@_SNo", pageName) };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, "getPageHelp", _Param));
        }

        public static String ErrorInsert(String _UserID, String _PageName, String _IP, String _PageExists)
        {
            SqlParameter[] sParameter = {
                new SqlParameter ("@_UserID", _UserID),
                new SqlParameter ("@_PageName", _PageName),
                new SqlParameter ("@_IP", _IP),
                new SqlParameter ("@_PageExists", _PageExists)
           };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "PageError_Insert", sParameter));
        }

        public static String Insert(IPages IP)
        {
            SqlParameter[] sParameter = {
                new SqlParameter ("@_PageName", IP.PageName),
                new SqlParameter ("@_Hyperlink", IP.Hyperlink),
                new SqlParameter ("@_Header", IP.HeaderSNo),
                new SqlParameter ("@_GroupAccess", IP.GroupAccess),
                new SqlParameter ("@_ShowInMenu", IP.ShowInMenu),
                new SqlParameter ("@_PagePriority", IP.PagePriority),
                new SqlParameter("@_Description",IP.PageHelp)
           };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Pages_Insert", sParameter));
        }

        public static String insertpagemodified(IPages IP)
        {
            SqlParameter[] sParameter ={
                                                                   
                            
                              new SqlParameter("@pageSno", IP.PageSNo ),
                               new SqlParameter("@Groupsno", IP.GroupSNo)
                            
                                       };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Pages_Insertmodified", sParameter));              
        }



        public static String insertpagemodified1(IPages IP)
        {
            SqlParameter[] sParameter ={
                                                                   
                            
                              new SqlParameter("@pageSno", IP.PageSNo ),
                               new SqlParameter("@Groupsno", IP.GroupSNo)
                            
                                       };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Pages_Insertmodified1", sParameter));
        }


        public static String insertgroup(IPages IP)
        {
            IP.SNo = 0;
            SqlParameter[] sParameter ={

               //new SqlParameter ("@Sno",IP.SNo),
              new SqlParameter("@GroupName",IP.GroupName),
                            new SqlParameter("@GroupType ", IP.GroupType),
                             new SqlParameter("@Multicity", IP.MultiCity) 
                             
                              
        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "insertusergroup", sParameter));
    }

        public static String insertLoginType(IPages IP)
        {
            IP.SNo = 0;
            SqlParameter[] sParameter ={
              new SqlParameter("@GroupName",IP.GroupName),
                            new SqlParameter("@GroupType ", IP.GroupType),
                             new SqlParameter("@Multicity", IP.MultiCity) 
                             
                              
        };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "insertlogintyp", sParameter));
        }


        public static String Update(IPages IP)
        {
            SqlParameter[] sParameter = {
                new SqlParameter ("@_SNo", IP.SNo),
                new SqlParameter ("@_PageName", IP.PageName),
                new SqlParameter ("@_Hyperlink", IP.Hyperlink),
                new SqlParameter ("@_HeaderSNo", IP.SNo),
                new SqlParameter ("@_GroupAccess", IP.GroupAccess),
                new SqlParameter ("@_ShowInMenu", IP.MenuSNo),
                new SqlParameter ("@_PagePriority", IP.DisplayOrder),
                new SqlParameter("@_PageHelp",IP.PageHelp)

           };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "update_PageNew", sParameter));
        }

        public static String updateUserPermissions(IPages IP)
        {
            SqlParameter[] sParameter = {
                new SqlParameter ("@_SNo", IP.SNo),
                new SqlParameter ("@_Allowed", IP.Allowed)
           };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateUserPermissions", sParameter));
        }

        public static String Delete(IPages IP)
        {
            SqlParameter[] sParameter = { new SqlParameter("@_SNo", IP.SNo) };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Pages_Delete", sParameter));
        }

        public static String InsertGroupPages(IPages ipage)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@GroupAccess",ipage.GroupAccess ),
                new SqlParameter( "@AllowedPages",ipage.Allowed ),
                new SqlParameter("@MultiCity",ipage.MultiCity),
                new SqlParameter("@GroupType",ipage.GroupType )
            };
            return (String)SqlHelper.ExecuteScalar(ConnectionString, "Insert_GroupPage", _param);
        }

        public static DataSet RetriveGroupPageDetail(IPages ipage)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@GroupID",ipage.SNo ),
                new SqlParameter("@name", ipage.Name)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "USRGRP_GetGroupPage", _param);
        }
        public static String RemoveGroupPages(IPages ipage)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@GroupID",ipage.SNo ),
            };
            return (String)SqlHelper.ExecuteScalar(ConnectionString, "USRGRP_RemoveGroupPages", _param);
        }
        public static String UpdateGroupPages(IPages ipage)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@GroupAccess",ipage.GroupAccess ),
                new SqlParameter( "@AllowedPages",ipage.Allowed ),
                new SqlParameter("@MultiCity",ipage.MultiCity)
            };
            return (String)SqlHelper.ExecuteScalar(ConnectionString, "USRGRP_UpdateGroupPages", _param);
        }

        public static String UpdatePageallowed(IPages ipage)
        {
            SqlParameter[] _param = {
                   new SqlParameter( "@sno",ipage.SNo),                     
                new SqlParameter( "@GroupId",ipage.GroupSNo ),
                new SqlParameter( "@pagesno", ipage.PageSNo )
                //new SqlParameter( "@Action", action)
            };
            return (String)SqlHelper.ExecuteScalar(ConnectionString, "Updateallowpage", _param);
        }

        public static String UpdatePagerestricted(IPages ipage)
        {
            SqlParameter[] _param = {
                   new SqlParameter( "@sno",ipage.SNo),                     
                new SqlParameter( "@GroupId",ipage.GroupSNo ),
                new SqlParameter( "@pagesno", ipage.PageSNo )
                //new SqlParameter( "@Action", action)
            };
            return (String)SqlHelper.ExecuteScalar(ConnectionString, "Updaterestrictedpage", _param);
        }

        public static String updategrouppage(IPages ipage)
        {

            SqlParameter[] _param = {
                new SqlParameter("@sno", ipage.SNo ),
                  new SqlParameter("@GroupName", ipage.GroupName ),
                   new SqlParameter("@GroupType", ipage.GroupType),
                    new SqlParameter("@Multicity", ipage.MultiCity)
               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateusergroup", _param));


        }
        public static DataSet getAllSubmenu(string MenuSno)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@MenuSNo",MenuSno ),
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAllSubmenu", _param);
        }

        //public static DataSet shopageview(int SNo) // To show allowed page into the list box
        //{
        //    SqlParameter[] _param = {
        //        new SqlParameter("@SNo", SNo )
               
        //    };
        //    return SqlHelper.ExecuteDataset(ConnectionString, "showpageviewlistbox", _param);   
        //}

        //public static DataSet shopagevierestricted(int SNo)
        // {
        //       SqlParameter[] _param = {
        //        new SqlParameter("@SNo", SNo )
                
        //    };
        //    return SqlHelper.ExecuteDataset(ConnectionString, "showrestrictedpagevies", _param);   
        // }
         
        public static String InsertAllSubMenu(string Sno, string Name, string Hyperlink, int MenuSno, int DisplayOrder, string Description)
        {
            SqlParameter[] _param = {
                  new SqlParameter( "@Sno",Sno ), 
                new SqlParameter( "@Name",Name ),
                 new SqlParameter( "@Hyperlink",Hyperlink ),
                 new SqlParameter( "@MenuSno",MenuSno ),
                  new SqlParameter( "@DisplayOrder",DisplayOrder ),
                  new SqlParameter( "@Description",Description ),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_AllSubMenu", _param));
        }
        public static string DeleteAllPages(int Sno)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@SNo",Sno ),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "delete_AllPages", _param));
        }
        public static string InsertHeader(string Name)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@Name",Name ),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_Header", _param));
        }
        public static string DeleteHeader(int Sno)
        {
            SqlParameter[] _param = {
                new SqlParameter( "@Sno",Sno ),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Delete_Header", _param));
        }
    }

}
