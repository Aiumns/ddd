﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;

namespace Cfi.App.Pace.Data
{
    public class CRMReportsSQLHelper : PaceCommon
    {
        public static DataSet GetCloseSalesReportThisMonth(DateTime FromDate, DateTime Todate, string CompBrSno, string GroupBy, string GroupByName, string Type)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@FromDate",FromDate),
                                             new SqlParameter("@Todate",Todate),
                                              new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@GroupBy",GroupBy), 
                                            new SqlParameter("@GroupByName",GroupByName),
                                            new SqlParameter("@Type",Type)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetAllCM1Report", _parameters);
        }  
        
    }
}
