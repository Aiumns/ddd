using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;

namespace Cfi.App.Pace.Data
{

    public class DBookingConfirmed : PaceCommon
    {
        public static String InsertBookingConfirmed(IBookingConfirmed IB, SqlTransaction tr)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@CustName",IB.CustName),  
             new SqlParameter("@CustCode",IB.CustCode),
             new SqlParameter("@custCity",IB.custCity),
             new SqlParameter("@CustLoginId",IB.CustLoginId),
             new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),
             new SqlParameter("@AirlineName",IB.AirlineName),
             new SqlParameter("@AirlineCode",IB.AirlineCode),
             new SqlParameter("@FlightNo",IB.FlightNo),   
             new SqlParameter("@FlightDate",IB.FlightDate),   
             new SqlParameter("@Origin",IB.Origin),   
             new SqlParameter("@Destination",IB.Destination),   
             new SqlParameter("@VolWt",IB.VolWt),   
             new SqlParameter("@GrWt",IB.GrWt),   
             new SqlParameter("@ChWt",IB.ChWt),   
             new SqlParameter("@FreightType",IB.FreightType),   
             new SqlParameter("@ShipmentDate",IB.ShipmentDate),   
             new SqlParameter("@ShipmentType",IB.ShipmentType),
             new SqlParameter("@Commodity",IB.Commodity),   
             new SqlParameter("@CPP",IB.CPP),   
             new SqlParameter("@ShipperStreet",IB.ShipperStreet),   
             new SqlParameter("@ShipperLocation",IB.ShipperLocation),   
             new SqlParameter("@ShipperCity",IB.ShipperCity),   
             new SqlParameter("@ShipperState",IB.ShipperState), 
             new SqlParameter("@ShipperZip",IB.ShipperZip),
             new SqlParameter("@ConsigneeStreet",IB.ConsigneeStreet),
             new SqlParameter("@ConsigneeLocation",IB.ConsigneeLocation),
             new SqlParameter("@ConsigneeCity",IB.ConsigneeCity),   
             new SqlParameter("@ConsigneeState",IB.ConsigneeState),   
             new SqlParameter("@ConsigneeZip",IB.ConsigneeZip),   
             new SqlParameter("@Pickup",IB.Pickup),   
             new SqlParameter("@PickupDate",IB.PickupDate),   
             new SqlParameter("@PickupTime",IB.PickupTime),   
             new SqlParameter("@PickupStreet",IB.PickupStreet),   
             new SqlParameter("@PickupLocation",IB.PickupLocation),   
             new SqlParameter("@PickupCity",IB.PickupCity),   
             new SqlParameter("@PickupState",IB.PickupState),
             new SqlParameter("@PickupZip",IB.PickupZip),   
             new SqlParameter("@OriginClearance",IB.OriginClearance),   
             new SqlParameter("@AirFreight",IB.AirFreight),   
             new SqlParameter("@Consolidate",IB.Consolidate),   
             new SqlParameter("@Delivery",IB.Delivery),   
             new SqlParameter("@DeliveryDate",IB.DeliveryDate), 
             new SqlParameter("@DeliveryTime",IB.DeliveryTime),   
             new SqlParameter("@DeliveryStreet",IB.DeliveryStreet),   
             new SqlParameter("@DeliveryLocation",IB.DeliveryLocation),   
             new SqlParameter("@DeliveryCity",IB.DeliveryCity), 
             new SqlParameter("@DeliveryState",IB.DeliveryState),
             new SqlParameter("@DeliveryZip",IB.DeliveryZip),
             new SqlParameter("@DestinationClearance",IB.DestinationClearance),
             new SqlParameter("@AddedBy",IB.AddedBy),   
             new SqlParameter("@AddedDate",IB.AddedDate)               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_Insert", _parameters));
        }

        public static String BookingConfirmed_InsertIndrct(IBookingConfirmed IB, SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno, string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, int CHA, string pkgs, string ExhibitionId)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@salesPerson",SalesPerson),
                new SqlParameter("@BookingId",IB.BookingId ),
             new SqlParameter("@BookingDate",IB.BookingDate ),
             new SqlParameter("@CustName",IB.CustName),
                new SqlParameter("@custBranchCode",IB.custBranchSNo ),
             new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),
             new SqlParameter("@AirlineName",IB.AirlineName),
             new SqlParameter("@AirlineCode",IB.AirlineCode),
             new SqlParameter("@FlightNo",IB.FlightNo),   
             new SqlParameter("@FlightDate",IB.FlightDate),   
             new SqlParameter("@Origin",IB.Origin),   
             new SqlParameter("@Destination",IB.Destination),   
             new SqlParameter("@VolWt",IB.VolWt),   
             new SqlParameter("@GrWt",IB.GrWt),   
             new SqlParameter("@ChWt",IB.ChWt),   
             new SqlParameter("@FreightType",IB.FreightType),   
             new SqlParameter("@ShipmentDate",IB.ShipmentDate),   
             new SqlParameter("@ShipmentType",IB.ShipmentType),
             new SqlParameter("@Commodity",IB.Commodity),   
             new SqlParameter("@CPP",IB.CPP),   
             new SqlParameter("@ShipperStreet",IB.ShipperStreet),   
             new SqlParameter("@ShipperLocation",IB.ShipperLocation),   
             new SqlParameter("@ShipperCity",IB.ShipperCity),   
             new SqlParameter("@ShipperState",IB.ShipperState), 
             new SqlParameter("@ShipperZip",IB.ShipperZip),
             new SqlParameter("@ConsigneeStreet",IB.ConsigneeStreet),
             new SqlParameter("@ConsigneeLocation",IB.ConsigneeLocation),
             new SqlParameter("@ConsigneeCity",IB.ConsigneeCity),   
             new SqlParameter("@ConsigneeState",IB.ConsigneeState),   
             new SqlParameter("@ConsigneeZip",IB.ConsigneeZip),   
             new SqlParameter("@Pickup",IB.Pickup),   
             new SqlParameter("@PickupDate",IB.PickupDate),   
             new SqlParameter("@PickupTime",IB.PickupTime),   
             new SqlParameter("@PickupStreet",IB.PickupStreet),   
             new SqlParameter("@PickupLocation",IB.PickupLocation),   
             new SqlParameter("@PickupCity",IB.PickupCity),   
             new SqlParameter("@PickupState",IB.PickupState),
             new SqlParameter("@PickupZip",IB.PickupZip),   
             new SqlParameter("@OriginClearance",IB.OriginClearance),   
             new SqlParameter("@AirFreight",IB.AirFreight),   
             new SqlParameter("@Consolidate",IB.Consolidate),   
             new SqlParameter("@Delivery",IB.Delivery),   
             new SqlParameter("@DeliveryDate",IB.DeliveryDate), 
             new SqlParameter("@DeliveryTime",IB.DeliveryTime),   
             new SqlParameter("@DeliveryStreet",IB.DeliveryStreet),   
             new SqlParameter("@DeliveryLocation",IB.DeliveryLocation),   
             new SqlParameter("@DeliveryCity",IB.DeliveryCity), 
             new SqlParameter("@DeliveryState",IB.DeliveryState),
             new SqlParameter("@DeliveryZip",IB.DeliveryZip),
             new SqlParameter("@DestinationClearance",IB.DestinationClearance),
             new SqlParameter("@AddedBy",IB.AddedBy),   
             new SqlParameter("@AddedDate",IB.AddedDate),
               new SqlParameter("@Comptype",Comptype),
             new SqlParameter("@ParentCompSno",ParentCompSno),   
             new SqlParameter("@compbrsno",compbrsno),
             new SqlParameter("@PickupType",PickupType),
             new SqlParameter("@OriginClearanceType",OriginClearanceType),
             new SqlParameter("@DestinationClearanceType",DestinationClearanceType),
             new SqlParameter("@DeliveryType",DeliveryType),
             new SqlParameter("@AirFreightType",AirFreightType),
             new SqlParameter("@AssociateId",AssociateId),
             new SqlParameter("@CHA",CHA ),
             new SqlParameter("@Pkgs",pkgs),
             new SqlParameter("@ExhibitionId",ExhibitionId )
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_InsertIndrct", _parameters));
        }
        public static String BookingConfirmed_InsertIndrctNew(IBookingConfirmed IB, SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno, string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string ExhibitionId, string AllIn)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@salesPerson",SalesPerson),
                new SqlParameter("@BookingId",IB.BookingId ),
             new SqlParameter("@BookingDate",IB.BookingDate ),
             new SqlParameter("@CustName",IB.CustName),
                new SqlParameter("@custBranchCode",IB.custBranchSNo ),
             new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),
             new SqlParameter("@AirlineName",IB.AirlineName),
             new SqlParameter("@AirlineCode",IB.AirlineCode),
             new SqlParameter("@FlightNo",IB.FlightNo),   
             new SqlParameter("@FlightDate",IB.FlightDate),   
             new SqlParameter("@Origin",IB.Origin),   
             new SqlParameter("@Destination",IB.Destination),   
             new SqlParameter("@VolWt",IB.VolWt),   
             new SqlParameter("@GrWt",IB.GrWt),   
             new SqlParameter("@ChWt",IB.ChWt),   
             new SqlParameter("@FreightType",IB.FreightType),   
             new SqlParameter("@ShipmentDate",IB.ShipmentDate),   
             new SqlParameter("@ShipmentType",IB.ShipmentType),
             new SqlParameter("@Commodity",IB.Commodity),   
             new SqlParameter("@CPP",IB.CPP),   
             new SqlParameter("@ShipperStreet",IB.ShipperStreet),   
             new SqlParameter("@ShipperLocation",IB.ShipperLocation),   
             new SqlParameter("@ShipperCity",IB.ShipperCity),   
             new SqlParameter("@ShipperState",IB.ShipperState), 
             new SqlParameter("@ShipperZip",IB.ShipperZip),
             new SqlParameter("@ConsigneeStreet",IB.ConsigneeStreet),
             new SqlParameter("@ConsigneeLocation",IB.ConsigneeLocation),
             new SqlParameter("@ConsigneeCity",IB.ConsigneeCity),   
             new SqlParameter("@ConsigneeState",IB.ConsigneeState),   
             new SqlParameter("@ConsigneeZip",IB.ConsigneeZip),   
             new SqlParameter("@Pickup",IB.Pickup),   
             new SqlParameter("@PickupDate",IB.PickupDate),   
             new SqlParameter("@PickupTime",IB.PickupTime),   
             new SqlParameter("@PickupStreet",IB.PickupStreet),   
             new SqlParameter("@PickupLocation",IB.PickupLocation),   
             new SqlParameter("@PickupCity",IB.PickupCity),   
             new SqlParameter("@PickupState",IB.PickupState),
             new SqlParameter("@PickupZip",IB.PickupZip),   
             new SqlParameter("@OriginClearance",IB.OriginClearance),   
             new SqlParameter("@AirFreight",IB.AirFreight),   
             new SqlParameter("@Consolidate",IB.Consolidate),   
             new SqlParameter("@Delivery",IB.Delivery),   
             new SqlParameter("@DeliveryDate",IB.DeliveryDate), 
             new SqlParameter("@DeliveryTime",IB.DeliveryTime),   
             new SqlParameter("@DeliveryStreet",IB.DeliveryStreet),   
             new SqlParameter("@DeliveryLocation",IB.DeliveryLocation),   
             new SqlParameter("@DeliveryCity",IB.DeliveryCity), 
             new SqlParameter("@DeliveryState",IB.DeliveryState),
             new SqlParameter("@DeliveryZip",IB.DeliveryZip),
             new SqlParameter("@DestinationClearance",IB.DestinationClearance),
             new SqlParameter("@AddedBy",IB.AddedBy),   
             new SqlParameter("@AddedDate",IB.AddedDate),
               new SqlParameter("@Comptype",Comptype),
             new SqlParameter("@ParentCompSno",ParentCompSno),   
             new SqlParameter("@compbrsno",compbrsno),
             new SqlParameter("@PickupType",PickupType),
             new SqlParameter("@OriginClearanceType",OriginClearanceType),
             new SqlParameter("@DestinationClearanceType",DestinationClearanceType),
             new SqlParameter("@DeliveryType",DeliveryType),
             new SqlParameter("@AirFreightType",AirFreightType),
             new SqlParameter("@AssociateId",AssociateId),
             new SqlParameter("@CHA",CHA ),
             new SqlParameter("@Pkgs",pkgs),
             new SqlParameter("@ExhibitionId",ExhibitionId ),
             new SqlParameter("@AllIn",AllIn )
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_InsertIndrctNew", _parameters));
        }
        public static String BookingConfirmed_InsertIndrctGdNew(IBookingConfirmed IB, SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno, string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string GodownSNo, string ExhibitionId, string AllIn)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@salesPerson",SalesPerson),
                new SqlParameter("@BookingId",IB.BookingId ),
             new SqlParameter("@BookingDate",IB.BookingDate ),
             new SqlParameter("@CustName",IB.CustName),
                new SqlParameter("@custBranchCode",IB.custBranchSNo ),
             new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),
             new SqlParameter("@AirlineName",IB.AirlineName),
             new SqlParameter("@AirlineCode",IB.AirlineCode),
             new SqlParameter("@FlightNo",IB.FlightNo),   
             new SqlParameter("@FlightDate",IB.FlightDate),   
             new SqlParameter("@Origin",IB.Origin),   
             new SqlParameter("@Destination",IB.Destination),   
             new SqlParameter("@VolWt",IB.VolWt),   
             new SqlParameter("@GrWt",IB.GrWt),   
             new SqlParameter("@ChWt",IB.ChWt),   
             new SqlParameter("@FreightType",IB.FreightType),   
             new SqlParameter("@ShipmentDate",IB.ShipmentDate),   
             new SqlParameter("@ShipmentType",IB.ShipmentType),
             new SqlParameter("@Commodity",IB.Commodity),   
             new SqlParameter("@CPP",IB.CPP),   
             new SqlParameter("@ShipperStreet",IB.ShipperStreet),   
             new SqlParameter("@ShipperLocation",IB.ShipperLocation),   
             new SqlParameter("@ShipperCity",IB.ShipperCity),   
             new SqlParameter("@ShipperState",IB.ShipperState), 
             new SqlParameter("@ShipperZip",IB.ShipperZip),
             new SqlParameter("@ConsigneeStreet",IB.ConsigneeStreet),
             new SqlParameter("@ConsigneeLocation",IB.ConsigneeLocation),
             new SqlParameter("@ConsigneeCity",IB.ConsigneeCity),   
             new SqlParameter("@ConsigneeState",IB.ConsigneeState),   
             new SqlParameter("@ConsigneeZip",IB.ConsigneeZip),   
             new SqlParameter("@Pickup",IB.Pickup),   
             new SqlParameter("@PickupDate",IB.PickupDate),   
             new SqlParameter("@PickupTime",IB.PickupTime),   
             new SqlParameter("@PickupStreet",IB.PickupStreet),   
             new SqlParameter("@PickupLocation",IB.PickupLocation),   
             new SqlParameter("@PickupCity",IB.PickupCity),   
             new SqlParameter("@PickupState",IB.PickupState),
             new SqlParameter("@PickupZip",IB.PickupZip),   
             new SqlParameter("@OriginClearance",IB.OriginClearance),   
             new SqlParameter("@AirFreight",IB.AirFreight),   
             new SqlParameter("@Consolidate",IB.Consolidate),   
             new SqlParameter("@Delivery",IB.Delivery),   
             new SqlParameter("@DeliveryDate",IB.DeliveryDate), 
             new SqlParameter("@DeliveryTime",IB.DeliveryTime),   
             new SqlParameter("@DeliveryStreet",IB.DeliveryStreet),   
             new SqlParameter("@DeliveryLocation",IB.DeliveryLocation),   
             new SqlParameter("@DeliveryCity",IB.DeliveryCity), 
             new SqlParameter("@DeliveryState",IB.DeliveryState),
             new SqlParameter("@DeliveryZip",IB.DeliveryZip),
             new SqlParameter("@DestinationClearance",IB.DestinationClearance),
             new SqlParameter("@AddedBy",IB.AddedBy),   
             new SqlParameter("@AddedDate",IB.AddedDate),
               new SqlParameter("@Comptype",Comptype),
             new SqlParameter("@ParentCompSno",ParentCompSno),   
             new SqlParameter("@compbrsno",compbrsno),
             new SqlParameter("@PickupType",PickupType),
             new SqlParameter("@OriginClearanceType",OriginClearanceType),
             new SqlParameter("@DestinationClearanceType",DestinationClearanceType),
             new SqlParameter("@DeliveryType",DeliveryType),
             new SqlParameter("@AirFreightType",AirFreightType),
             new SqlParameter("@AssociateId",AssociateId),// Bill
             new SqlParameter("@CHA",CHA ),
             new SqlParameter("@Pkgs",pkgs),
             new SqlParameter("@GodownSNo",GodownSNo),
             new SqlParameter("@ExhibitionId",ExhibitionId),
             new SqlParameter("@ShipperCustBrSNo",IB.ShipperCustBrSno),
             new SqlParameter("@ConsigneeCustBrSNo",IB.ConsigneeCustBrSno),
             new SqlParameter("@AllIn",AllIn)
             
            };
            //return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_InsertIndrctGdNew1", _parameters));
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_InsertIndrctGdNew", _parameters));
        }
        public static String BookingConfirmed_InsertIndrctGd(IBookingConfirmed IB, SqlTransaction tr, string SalesPerson, string Comptype, string ParentCompSno, string compbrsno, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string GodownSNo, string ExhibitionId, string onFreight, string onFreightAndClearance)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@salesPerson",SalesPerson),
                new SqlParameter("@BookingId",IB.BookingId ),
             new SqlParameter("@BookingDate",IB.BookingDate <=DateTime.Parse("Jan 01 1973") ? DateTime.Parse("Jan 01 1900") : IB.BookingDate),
             new SqlParameter("@CustName",IB.CustName),
                new SqlParameter("@custBranchCode",IB.custBranchSNo ),
             new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),
             new SqlParameter("@AirlineName",IB.AirlineName),
             new SqlParameter("@AirlineCode",IB.AirlineCode),
             new SqlParameter("@FlightNo",IB.FlightNo),   
             new SqlParameter("@FlightDate",IB.FlightDate),   
             new SqlParameter("@Origin",IB.Origin),   
             new SqlParameter("@Destination",IB.Destination),   
             new SqlParameter("@VolWt",IB.VolWt),   
             new SqlParameter("@GrWt",IB.GrWt),   
             new SqlParameter("@ChWt",IB.ChWt),   
             new SqlParameter("@FreightType",IB.FreightType),   
             new SqlParameter("@ShipmentDate",IB.ShipmentDate),   
             new SqlParameter("@ShipmentType",IB.ShipmentType),
             new SqlParameter("@Commodity",IB.Commodity),   
             new SqlParameter("@CPP",IB.CPP),   
             new SqlParameter("@ShipperStreet",IB.ShipperStreet),   
             new SqlParameter("@ShipperLocation",IB.ShipperLocation),   
             new SqlParameter("@ShipperCity",IB.ShipperCity),   
             new SqlParameter("@ShipperState",IB.ShipperState), 
             new SqlParameter("@ShipperZip",IB.ShipperZip),
             new SqlParameter("@ConsigneeStreet",IB.ConsigneeStreet),
             new SqlParameter("@ConsigneeLocation",IB.ConsigneeLocation),
             new SqlParameter("@ConsigneeCity",IB.ConsigneeCity),   
             new SqlParameter("@ConsigneeState",IB.ConsigneeState),   
             new SqlParameter("@ConsigneeZip",IB.ConsigneeZip),   
             new SqlParameter("@Pickup",IB.Pickup),   
             new SqlParameter("@PickupDate",IB.PickupDate),   
             new SqlParameter("@PickupTime",IB.PickupTime),   
             new SqlParameter("@PickupStreet",IB.PickupStreet),   
             new SqlParameter("@PickupLocation",IB.PickupLocation),   
             new SqlParameter("@PickupCity",IB.PickupCity),   
             new SqlParameter("@PickupState",IB.PickupState),
             new SqlParameter("@PickupZip",IB.PickupZip),   
             new SqlParameter("@OriginClearance",IB.OriginClearance),   
             new SqlParameter("@AirFreight",IB.AirFreight),   
             new SqlParameter("@Consolidate",IB.Consolidate),   
             new SqlParameter("@Delivery",IB.Delivery),   
             new SqlParameter("@DeliveryDate",IB.DeliveryDate), 
             new SqlParameter("@DeliveryTime",IB.DeliveryTime),   
             new SqlParameter("@DeliveryStreet",IB.DeliveryStreet),   
             new SqlParameter("@DeliveryLocation",IB.DeliveryLocation),   
             new SqlParameter("@DeliveryCity",IB.DeliveryCity), 
             new SqlParameter("@DeliveryState",IB.DeliveryState),
             new SqlParameter("@DeliveryZip",IB.DeliveryZip),
             new SqlParameter("@DestinationClearance",IB.DestinationClearance),
             new SqlParameter("@AddedBy",IB.AddedBy),   
             new SqlParameter("@AddedDate",IB.AddedDate),
               new SqlParameter("@Comptype",Comptype),
             new SqlParameter("@ParentCompSno",ParentCompSno),   
             new SqlParameter("@compbrsno",compbrsno),
             new SqlParameter("@PickupType",PickupType),
             new SqlParameter("@OriginClearanceType",OriginClearanceType),
             new SqlParameter("@DestinationClearanceType",DestinationClearanceType),
             new SqlParameter("@DeliveryType",DeliveryType),
             new SqlParameter("@AirFreightType",AirFreightType),
             new SqlParameter("@AssociateId",AssociateId),//bill
             new SqlParameter("@CHA",CHA ),
             new SqlParameter("@Pkgs",pkgs),
             new SqlParameter("@GodownSNo",GodownSNo),
             new SqlParameter("@ExhibitionId",ExhibitionId),
             new SqlParameter("@ShipperCustBrSNo",IB.ShipperCustBrSno),
             new SqlParameter("@ConsigneeCustBrSNo",IB.ConsigneeCustBrSno),
                new SqlParameter("@Freight",onFreight),
                   new SqlParameter("@FreightAndClearance",onFreightAndClearance)
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_InsertIndrctGd1", _parameters));
            //return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_InsertIndrctGd", _parameters));
        }
        public static String insertBookingTranNew(IBookingConfirmed IB, SqlTransaction tr, string compbrsno)
        {
            SqlParameter[] _parameters = {               
                new SqlParameter("@BookingId",IB.BookingId ),        
             new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),             
             new SqlParameter("@compbrsno",compbrsno)             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "insertBookingTranNew", _parameters));
        }
        public static int Inserted_ChequeDepositeSlip(IBookingConfirmed IB, string CompBrSNo, string EnteredBy, int BatchNo, string datetime, string custBranchSNo)
        {
            SqlParameter[] _parameters = {  
                 new SqlParameter("@BatchNo",BatchNo),
                new SqlParameter("@CompBrSNo",CompBrSNo ), 
        new SqlParameter("@Account_No",IB.AccountNo1), 
             new SqlParameter("@Bank_name",IB.BankName1),
             new SqlParameter("@Branch",IB.Branch1),             
             new SqlParameter("@ChequeNumber",IB.ChequeNumber1),
              new SqlParameter("@ChequeIssuedBy",IB.ChequeIssuedBy1),        
             new SqlParameter("@Rupees",IB.Rupees1),
             new SqlParameter("@Paise",IB.Paise1),             
             new SqlParameter("@EnteredBy",EnteredBy),
             new SqlParameter("@EnteredAt",datetime),
             new SqlParameter("@custBranchSNo",custBranchSNo)
            };
            return SqlHelper.ExecuteNonQuery(ConnectionString, "Inserted_ChequeDepositeSlip", _parameters);
        }
        public static int Updated_ChequeDepositeSlip(IBookingConfirmed IB, string CompBrSNo, string EnteredBy, int BatchNo, int Snotable, string datetime, string custBranchSNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@SNo",Snotable),
                 new SqlParameter("@BatchNo",BatchNo),
                new SqlParameter("@CompBrSNo",CompBrSNo ),
                new SqlParameter("@Account_No",IB.AccountNo1 ),
             new SqlParameter("@Bank_name",IB.BankName1),
             new SqlParameter("@Branch",IB.Branch1),             
             new SqlParameter("@ChequeNumber",IB.ChequeNumber1),
              new SqlParameter("@ChequeIssuedBy",IB.ChequeIssuedBy1),        
             new SqlParameter("@Rupees",IB.Rupees1),
             new SqlParameter("@Paise",IB.Paise1),             
             new SqlParameter("@EnteredBy",EnteredBy),
             new SqlParameter("@EnteredAt",datetime),
              new SqlParameter("@custBranchSNo",custBranchSNo)
            };
            return SqlHelper.ExecuteNonQuery(ConnectionString, "Updated_ChequeDepositeSlip", _parameters);
        }
        public static String UpdateBookingTranNew(IBookingConfirmed IB, SqlTransaction tr)
        {
            SqlParameter[] _parameters = {               
                new SqlParameter("@BookingId",IB.BookingId ),        
             new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo)         
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "UpdateBookingTranNew", _parameters));
        }
        public static String BookingConfirmed_Update(IBookingConfirmed IB, SqlTransaction tr, string Active, string SalesPerson, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string ExhibitionId)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@salesPerson",SalesPerson),
                 new SqlParameter("@SNo",IB.SNo),
             new SqlParameter("@CustName",IB.CustName),
                 new SqlParameter("@custBranchCode",IB.custBranchSNo ),
                    new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),
             new SqlParameter("@AirlineName",IB.AirlineName),
             new SqlParameter("@AirlineCode",IB.AirlineCode),
             new SqlParameter("@FlightNo",IB.FlightNo),   
             new SqlParameter("@FlightDate",IB.FlightDate),   
             new SqlParameter("@Origin",IB.Origin),   
             new SqlParameter("@Destination",IB.Destination),   
             new SqlParameter("@VolWt",IB.VolWt),   
             new SqlParameter("@GrWt",IB.GrWt),   
             new SqlParameter("@ChWt",IB.ChWt),   
             new SqlParameter("@FreightType",IB.FreightType),   
             new SqlParameter("@ShipmentDate",IB.ShipmentDate),   
             new SqlParameter("@ShipmentType",IB.ShipmentType),
             new SqlParameter("@Commodity",IB.Commodity),   
             new SqlParameter("@CPP",IB.CPP),   
             new SqlParameter("@ShipperStreet",IB.ShipperStreet),   
             new SqlParameter("@ShipperLocation",IB.ShipperLocation),   
             new SqlParameter("@ShipperCity",IB.ShipperCity),   
             new SqlParameter("@ShipperState",IB.ShipperState), 
             new SqlParameter("@ShipperZip",IB.ShipperZip),
             new SqlParameter("@ConsigneeStreet",IB.ConsigneeStreet),
             new SqlParameter("@ConsigneeLocation",IB.ConsigneeLocation),
             new SqlParameter("@ConsigneeCity",IB.ConsigneeCity),   
             new SqlParameter("@ConsigneeState",IB.ConsigneeState),   
             new SqlParameter("@ConsigneeZip",IB.ConsigneeZip),   
             new SqlParameter("@Pickup",IB.Pickup),   
             new SqlParameter("@PickupDate",IB.PickupDate),   
             new SqlParameter("@PickupTime",IB.PickupTime),   
             new SqlParameter("@PickupStreet",IB.PickupStreet),   
             new SqlParameter("@PickupLocation",IB.PickupLocation),   
             new SqlParameter("@PickupCity",IB.PickupCity),   
             new SqlParameter("@PickupState",IB.PickupState),
             new SqlParameter("@PickupZip",IB.PickupZip),   
             new SqlParameter("@OriginClearance",IB.OriginClearance),   
             new SqlParameter("@AirFreight",IB.AirFreight),   
             new SqlParameter("@Consolidate",IB.Consolidate),   
             new SqlParameter("@Delivery",IB.Delivery),   
             new SqlParameter("@DeliveryDate",IB.DeliveryDate), 
             new SqlParameter("@DeliveryTime",IB.DeliveryTime),   
             new SqlParameter("@DeliveryStreet",IB.DeliveryStreet),   
             new SqlParameter("@DeliveryLocation",IB.DeliveryLocation),   
             new SqlParameter("@DeliveryCity",IB.DeliveryCity), 
             new SqlParameter("@DeliveryState",IB.DeliveryState),
             new SqlParameter("@DeliveryZip",IB.DeliveryZip),
             new SqlParameter("@DestinationClearance",IB.DestinationClearance),
             new SqlParameter("@UpdatedBy",IB.AddedBy),   
             new SqlParameter("@UpdatedDate",IB.AddedDate),
             new SqlParameter("@Active",Active),
             new SqlParameter("@PickupType",PickupType),
             new SqlParameter("@OriginClearanceType",OriginClearanceType),
             new SqlParameter("@DestinationClearanceType",DestinationClearanceType),
             new SqlParameter("@DeliveryType",DeliveryType),
             new SqlParameter("@AirFreightType",AirFreightType),
             new SqlParameter("@AssociateId",AssociateId),
             new SqlParameter("@CHA",CHA ),
             new SqlParameter("@Pkgs",pkgs),
             new SqlParameter("@ExhibitionId",ExhibitionId),
             new SqlParameter("@ShipperCustBrSno",IB.ShipperCustBrSno),
             new SqlParameter("@ConsigneeCustBrSno",IB.ConsigneeCustBrSno)

            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_Update", _parameters));
        }
        public static String BookingConfirmed_UpdateNew(IBookingConfirmed IB, SqlTransaction tr, string Active, string SalesPerson, string PickupType, string OriginClearanceType, string DestinationClearanceType, string DeliveryType, string AirFreightType, string AssociateId, string CHA, string pkgs, string ExhibitionId, string AllIn)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@salesPerson",SalesPerson),
                 new SqlParameter("@SNo",IB.SNo),
             new SqlParameter("@CustName",IB.CustName),
                 new SqlParameter("@custBranchCode",IB.custBranchSNo ),
                    new SqlParameter("@MAWBNo",IB.MAWBNo),
             new SqlParameter("@HAWBNo",IB.HAWBNo),
             new SqlParameter("@AirlineName",IB.AirlineName),
             new SqlParameter("@AirlineCode",IB.AirlineCode),
             new SqlParameter("@FlightNo",IB.FlightNo),   
             new SqlParameter("@FlightDate",IB.FlightDate),   
             new SqlParameter("@Origin",IB.Origin),   
             new SqlParameter("@Destination",IB.Destination),   
             new SqlParameter("@VolWt",IB.VolWt),   
             new SqlParameter("@GrWt",IB.GrWt),   
             new SqlParameter("@ChWt",IB.ChWt),   
             new SqlParameter("@FreightType",IB.FreightType),   
             new SqlParameter("@ShipmentDate",IB.ShipmentDate),   
             new SqlParameter("@ShipmentType",IB.ShipmentType),
             new SqlParameter("@Commodity",IB.Commodity),   
             new SqlParameter("@CPP",IB.CPP),   
             new SqlParameter("@ShipperStreet",IB.ShipperStreet),   
             new SqlParameter("@ShipperLocation",IB.ShipperLocation),   
             new SqlParameter("@ShipperCity",IB.ShipperCity),   
             new SqlParameter("@ShipperState",IB.ShipperState), 
             new SqlParameter("@ShipperZip",IB.ShipperZip),
             new SqlParameter("@ConsigneeStreet",IB.ConsigneeStreet),
             new SqlParameter("@ConsigneeLocation",IB.ConsigneeLocation),
             new SqlParameter("@ConsigneeCity",IB.ConsigneeCity),   
             new SqlParameter("@ConsigneeState",IB.ConsigneeState),   
             new SqlParameter("@ConsigneeZip",IB.ConsigneeZip),   
             new SqlParameter("@Pickup",IB.Pickup),   
             new SqlParameter("@PickupDate",IB.PickupDate),   
             new SqlParameter("@PickupTime",IB.PickupTime),   
             new SqlParameter("@PickupStreet",IB.PickupStreet),   
             new SqlParameter("@PickupLocation",IB.PickupLocation),   
             new SqlParameter("@PickupCity",IB.PickupCity),   
             new SqlParameter("@PickupState",IB.PickupState),
             new SqlParameter("@PickupZip",IB.PickupZip),   
             new SqlParameter("@OriginClearance",IB.OriginClearance),   
             new SqlParameter("@AirFreight",IB.AirFreight),   
             new SqlParameter("@Consolidate",IB.Consolidate),   
             new SqlParameter("@Delivery",IB.Delivery),   
             new SqlParameter("@DeliveryDate",IB.DeliveryDate), 
             new SqlParameter("@DeliveryTime",IB.DeliveryTime),   
             new SqlParameter("@DeliveryStreet",IB.DeliveryStreet),   
             new SqlParameter("@DeliveryLocation",IB.DeliveryLocation),   
             new SqlParameter("@DeliveryCity",IB.DeliveryCity), 
             new SqlParameter("@DeliveryState",IB.DeliveryState),
             new SqlParameter("@DeliveryZip",IB.DeliveryZip),
             new SqlParameter("@DestinationClearance",IB.DestinationClearance),
             new SqlParameter("@UpdatedBy",IB.AddedBy),   
             new SqlParameter("@UpdatedDate",IB.AddedDate),
             new SqlParameter("@Active",Active),
             new SqlParameter("@PickupType",PickupType),
             new SqlParameter("@OriginClearanceType",OriginClearanceType),
             new SqlParameter("@DestinationClearanceType",DestinationClearanceType),
             new SqlParameter("@DeliveryType",DeliveryType),
             new SqlParameter("@AirFreightType",AirFreightType),
             new SqlParameter("@AssociateId",AssociateId),
             new SqlParameter("@CHA",CHA ),
             new SqlParameter("@Pkgs",pkgs),
             new SqlParameter("@ExhibitionId",ExhibitionId),
             new SqlParameter("@ExhibitionId",IB.ShipperCustBrSno),
             new SqlParameter("@ExhibitionId",IB.ConsigneeCustBrSno),
             new SqlParameter("@AllIn",AllIn)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_UpdateNew", _parameters));
        }
        public static String BookingConfirmed_UpdateForPNP(IBookingConfirmed IB, SqlTransaction tr, string PNPBcnfSno)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@SNo",IB.SNo),
                 new SqlParameter("@PNPBcnfSno",PNPBcnfSno)    
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_UpdateForPNP", _parameters));
        }



        public static DataSet getChequeDepositSlipValue(string SNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@Sno",int.Parse(SNo))
                                         
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "getChequeDepositSlipValue", _parameters);

        }
        public static DataSet getChequeDeposit(int SNo, DateTime ChqDt)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@Sno",SNo),
                                             new SqlParameter("@ChqDt",ChqDt)
                                         
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getChequeDeposit", _parameters);
        }
        public static DataSet GetCompanyWiseAccount(string CompBrSno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@CompBrSno",int.Parse(CompBrSno))
                                         
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "GetCompanyWiseAccount", _parameters);

        }

        public static String InsertBookingConfirmedCharges(IBookingConfirmed IB, SqlTransaction tr, string CustBrSNo, string SellingCurrency)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),
             new SqlParameter("@ChargeId",IB.ChargeId),
             new SqlParameter("@BuyingAmount",IB.BuyingAmount),
             new SqlParameter("@SellingAmount",IB.SellingAmount),
             new SqlParameter("@Unit",IB.Unit),   
             new SqlParameter("@Currency",IB.Currency),
                new SqlParameter("@CustBrSNo",CustBrSNo ) ,
                 new SqlParameter("@SellingCurrency",SellingCurrency ) 
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "BookingConfirmed_InsertCharges", _parameters));
        }
        public static String InsertBookingConfirmedCharges1(IBookingConfirmed IB, SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),
             new SqlParameter("@ChargeId",IB.ChargeId),
             new SqlParameter("@BuyingAmount",IB.BuyingAmount),
             new SqlParameter("@SellingAmount",IB.SellingAmount),
             new SqlParameter("@Unit",IB.Unit),   
             new SqlParameter("@Currency",IB.Currency),
                new SqlParameter("@CustBrSNo",CustBrSNo ) ,
                 new SqlParameter("@SellingCurrency",SellingCurrency ) ,
                 new SqlParameter("@SupplierName",SupplierName ) 
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "BookingConfirmed_InsertCharges1", _parameters));
        }

        public static String InsertBookingConfirmedChargesNew(IBookingConfirmed IB, SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt,decimal BuyingSBCessAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt,decimal SellingSBCessAmt, decimal SellingBillAmt, string Status, decimal BuyingExchangeRate, decimal SellingExchangeRate, string UnitSell, string ChargesOnWeightSell, decimal buyRate, decimal sellRate)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),
             new SqlParameter("@ChargeId",IB.ChargeId),
             new SqlParameter("@BuyingAmount",IB.BuyingAmount),
             new SqlParameter("@SellingAmount",IB.SellingAmount),
             new SqlParameter("@Unit",IB.Unit),   
             new SqlParameter("@Currency",IB.Currency),
             new SqlParameter("@CustBrSNo",CustBrSNo ) ,
              new SqlParameter("@SellingCurrency",SellingCurrency ) ,
                 new SqlParameter("@SupplierName",SupplierName ) ,
                 new SqlParameter("@taxable",taxable ) ,
                 new SqlParameter("@BuyingSTaxAmt",BuyingSTaxAmt ) ,
                 new SqlParameter("@BuyingSBCessAmt",BuyingSBCessAmt ) ,
                 new SqlParameter("@BuyingBillAmt",BuyingBillAmt ) ,
                 new SqlParameter("@SellingSTaxAmt",SellingSTaxAmt ) ,
                   new SqlParameter("@SellingSBCessAmt",SellingSBCessAmt ) ,
                 new SqlParameter("@SellingBillAmt",SellingBillAmt ) ,
                  new SqlParameter("@Status",Status ) ,
                  new SqlParameter("@ChargesOnWeight",IB.ChargesOnWeight) ,
                   new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate ) ,
                  new SqlParameter("@SellingExchangeRate",SellingExchangeRate) ,
                  new SqlParameter("@UnitSell",UnitSell) ,
                  new SqlParameter("@chargesOnWeightSell",ChargesOnWeightSell) ,
                  new SqlParameter("@buyRate",buyRate) ,
                  new SqlParameter("@sellRate",sellRate) 

            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "BookingConfirmed_InsertChargesNew11", _parameters));
            //return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "BookingConfirmed_InsertChargesNew1", _parameters));
        }

        public static String updateChargesInBookingConfirmedCharges(IBookingConfirmed IB, SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt,decimal BuyingSBCessAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt,decimal SellingSBCessAmt, decimal SellingBillAmt, string Status, decimal BuyingExchangeRate, decimal SellingExchangeRate, string UnitSell, string ChargesOnWeightSell, decimal buyRate, decimal sellRate, int BCHSNo)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),
             new SqlParameter("@ChargeId",IB.ChargeId),
             new SqlParameter("@BuyingAmount",IB.BuyingAmount),
             new SqlParameter("@SellingAmount",IB.SellingAmount),
             new SqlParameter("@Unit",IB.Unit),   
             new SqlParameter("@Currency",IB.Currency),
             new SqlParameter("@CustBrSNo",CustBrSNo ) ,
              new SqlParameter("@SellingCurrency",SellingCurrency ) ,
                 new SqlParameter("@SupplierName",SupplierName ) ,
                 new SqlParameter("@taxable",taxable ) ,
                 new SqlParameter("@BuyingSTaxAmt",BuyingSTaxAmt ) ,
                 new SqlParameter("@BuyingSBCessAmt",BuyingSBCessAmt ) ,
                 new SqlParameter("@BuyingBillAmt",BuyingBillAmt ) ,
                 new SqlParameter("@SellingSTaxAmt",SellingSTaxAmt ) ,
                   new SqlParameter("@SellingSBCessAmt",SellingSBCessAmt ) ,
                 new SqlParameter("@SellingBillAmt",SellingBillAmt ) ,
                  new SqlParameter("@Status",Status ) ,
                  new SqlParameter("@ChargesOnWeight",IB.ChargesOnWeight) ,
                   new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate ) ,
                  new SqlParameter("@SellingExchangeRate",SellingExchangeRate) ,
                  new SqlParameter("@UnitSell",UnitSell) ,
                  new SqlParameter("@chargesOnWeightSell",ChargesOnWeightSell) ,
                  new SqlParameter("@buyRate",buyRate) ,
                  new SqlParameter("@sellRate",sellRate) ,
                  new SqlParameter("@BCHSNo",BCHSNo) 
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "updateChargesInBookingConfirmedCharges", _parameters));
        }

        public static String InsertBookingConfirmedChargesNewPNP(IBookingConfirmed IB, SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt, decimal BuyingSBCessAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt, decimal SellingSBCessAmt, decimal SellingBillAmt, string Status, string MasterSNo, decimal BuyingExchangeRate, decimal SellingExchangeRate, decimal buyRate, decimal sellRate, string unitSell, string ChargesOnWeightSell)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),
             new SqlParameter("@ChargeId",IB.ChargeId),
             new SqlParameter("@BuyingAmount",IB.BuyingAmount),
             new SqlParameter("@SellingAmount",IB.SellingAmount),
             new SqlParameter("@Unit",IB.Unit),   
             new SqlParameter("@Currency",IB.Currency),
             new SqlParameter("@CustBrSNo",CustBrSNo ) ,
             new SqlParameter("@SellingCurrency",SellingCurrency ) ,
             new SqlParameter("@SupplierName",SupplierName ) ,
             new SqlParameter("@taxable",taxable ) ,
             new SqlParameter("@BuyingSTaxAmt",BuyingSTaxAmt ) ,
              new SqlParameter("@BuyingSBCessAmt",BuyingSBCessAmt ) ,
             new SqlParameter("@BuyingBillAmt",BuyingBillAmt ) ,
             new SqlParameter("@SellingSTaxAmt",SellingSTaxAmt ) ,
              new SqlParameter("@SellingSBCessAmt",SellingSBCessAmt ) ,
             new SqlParameter("@SellingBillAmt",SellingBillAmt ) ,
             new SqlParameter("@Status",Status ) ,
             new SqlParameter("@MasterSNo",MasterSNo),
             new SqlParameter("@ChargesOnWeight",IB.ChargesOnWeight) ,
             new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate),
             new SqlParameter("@SellingExchangeRate",SellingExchangeRate) ,
              new SqlParameter("@buyRate",buyRate),
             new SqlParameter("@sellRate",sellRate) ,
             new SqlParameter("@unitSell",unitSell),
             new SqlParameter("@ChargesOnWeightSell",ChargesOnWeightSell) 
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "BookingConfirmed_InsertChargesNewestPNP1", _parameters));
            //return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "BookingConfirmed_InsertChargesNewPNP", _parameters));
        }

        public static String InsertBookingConfirmedChargesNewestPNP(IBookingConfirmed IB, SqlTransaction tr, string CustBrSNo, string SellingCurrency, string SupplierName, string taxable, decimal BuyingSTaxAmt, decimal BuyingBillAmt, decimal SellingSTaxAmt, decimal SellingBillAmt, string Status, string MasterSNo, decimal BuyingExchangeRate, decimal SellingExchangeRate, string AllInBuy, string AllInSell)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),
             new SqlParameter("@ChargeId",IB.ChargeId),
             new SqlParameter("@BuyingAmount",IB.BuyingAmount),
             new SqlParameter("@SellingAmount",IB.SellingAmount),
             new SqlParameter("@Unit",IB.Unit),   
             new SqlParameter("@Currency",IB.Currency),
             new SqlParameter("@CustBrSNo",CustBrSNo ) ,
             new SqlParameter("@SellingCurrency",SellingCurrency ) ,
             new SqlParameter("@SupplierName",SupplierName ) ,
             new SqlParameter("@taxable",taxable ) ,
             new SqlParameter("@BuyingSTaxAmt",BuyingSTaxAmt ) ,
             new SqlParameter("@BuyingBillAmt",BuyingBillAmt ) ,
             new SqlParameter("@SellingSTaxAmt",SellingSTaxAmt ) ,
             new SqlParameter("@SellingBillAmt",SellingBillAmt ) ,
             new SqlParameter("@Status",Status ) ,
             new SqlParameter("@MasterSNo",MasterSNo),
             new SqlParameter("@ChargesOnWeight",IB.ChargesOnWeight) ,
             new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate),
             new SqlParameter("@SellingExchangeRate",SellingExchangeRate) ,
             new SqlParameter("@AllInBuy",AllInBuy),
             new SqlParameter("@AllInSell",AllInSell) 
            
            };

            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "BookingConfirmed_InsertChargesNewestPNP", _parameters));
        }

        public static string InsertRIDetail(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@RIName",IB.Name),
             new SqlParameter("@Address",IB.Address),
             new SqlParameter("@PanNo",IB.PAN_No)

              };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "InsertRIDetail", _parameters));

        }

        public static string UpdateRIDetails(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters ={
            new SqlParameter("@Sno", IB.SNo),
            new SqlParameter("@RIName",IB.Name),
            new SqlParameter("@Address", IB.Address),
            new SqlParameter("@PanNo", IB.PAN_No)

        };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "UpdateRIDetails", _parameters));
        }

        public static DataSet GetRIdetails(IBookingConfirmed bbooking)
        {
            SqlParameter[] _param ={
                new SqlParameter("@SNo",bbooking.SNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetRIDetails", _param);
        }



        public static String insertBookingTrans(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@CustBrSNo",IB.custBranchSNo ),
             new SqlParameter("@BConfId",IB.BConfId ),
             new SqlParameter("@Amount",IB.SellingAmount ),
               new SqlParameter("@AddeddBy",IB.AddedBy)
            };
            // return Convert.ToString(SqlHelper.ExecuteNonQuery("insertBookingTrans", _parameters));
            return (String)SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "insertBookingTrans", _parameters);
        }
        public static String updateCreditLimit(IBookingConfirmed IB, decimal UsedAmt, string LimitType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@CustBrSNo",IB.custBranchSNo ),  
                 new SqlParameter("@UsedAmt",UsedAmt  ),
               new SqlParameter("@LimitType",LimitType )
            };

            return (String)SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "updateCreditLimit", _parameters);
        }
        public static String restoreCreditLimit(IBookingConfirmed IB, decimal UsedAmt, string LimitType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@CustBrSNo",IB.custBranchSNo ),  
                 new SqlParameter("@UsedAmt",UsedAmt  ),
               new SqlParameter("@LimitType",LimitType )
            };

            return (String)SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "restoreCreditLimit", _parameters);
        }

        public static String updateBookingTrans(IBookingConfirmed IB, decimal UsedAmt, string LimitType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter("@BConfId",IB.BConfId ),                
                 new SqlParameter("@UsedAmt",UsedAmt  ),
                 new SqlParameter("@UpdatedBy",IB.AddedBy),   
             new SqlParameter("@UpdatedDate",IB.AddedDate),
               new SqlParameter("@LimitType",LimitType ),
                 new SqlParameter("@CustBrSNo",IB.custBranchSNo ),  
            };

            return (String)SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "updateBookingTrans", _parameters);
        }

        public static String deleteBCnfCharges(IBookingConfirmed IB, SqlTransaction tr)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo)   
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "deleteBCnfChargesNew", _parameters));
            //return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "deleteBCnfCharges", _parameters));
        }
        public static String deleteBCnfChargesNew(IBookingConfirmed IB, SqlTransaction tr, int chargeID)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo)  ,
             new SqlParameter("@chargeID",chargeID)   
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "deleteBCnfChargesNewest", _parameters));
            //return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "deleteBCnfCharges", _parameters));
        }
        public static String insertNewBCCharges(IBookingConfirmed IB, SqlTransaction tr)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),
             new SqlParameter("@ChargeId",IB.ChargeId),
             new SqlParameter("@BuyingAmount",IB.BuyingAmount),
             new SqlParameter("@SellingAmount",IB.SellingAmount),
             new SqlParameter("@Unit",IB.Unit),   
             new SqlParameter("@Currency",IB.Currency)                 
            };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(tr, "insertNewBCCharges", _parameters));
        }

        public static DataSet checkHAWBStock(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@custcode",IB.CustCode ),
                    new SqlParameter ("@CompBrSNo",IB.CompBrSNo ),
                    new SqlParameter ("@Origin",IB.Origin),
                    new SqlParameter ("@AlineName",IB.AirlineName )                   
                                       
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "checkHAWBStock", spara);
        }
        public static DataSet checkHAWBStockForPNP(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@custcode",IB.CustCode ),
                    new SqlParameter ("@CompBrSNo",IB.CompBrSNo ),
                    new SqlParameter ("@Origin",IB.Origin),
                    new SqlParameter ("@AlineName",IB.AirlineName )                   
                                       
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "checkHAWBStockForPNP", spara);
        }
        public static String ParentCompSno(String compBrSNo)
        {
            SqlParameter[] _parameters = {                
                new SqlParameter( "@compBrSNo", compBrSNo),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "ParentCompSno", _parameters));
        }
        public static DataSet checkHAWBStockforConsole(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@CompBrSNo",IB.CompBrSNo ),
                     new SqlParameter ("@BcnfId",IB.BConfId )
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "checkHAWBStockforConsole", spara);
        } 
        public static DataSet getConfrmBookBySNo(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",IB.SNo),
                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getConfrmBookBySNo", spara);
        }

        public static DataSet getApproveBookBySNo1(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",IB.SNo),
                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getApproveBookBySNo1", spara);
        }
        public static DataSet getConfrmBookBySNo1(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",IB.SNo),
                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getConfrmBookBySNo1", spara);
        }
        public static DataSet getConfirmBookChargesForPNP(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",IB.SNo),
                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getConfirmBookChargesForPNP", spara);
        }
        public static SqlDataReader getSalesPerson(IBookingConfirmed IB)
        {
            SqlParameter[] spara ={ 
                                 new SqlParameter ("@SNo",IB.CompBrSNo)               
                            
                };
            return SqlHelper.ExecuteReader(PaceCommon.ConnectionString, "getSalesPersonBrSnoWise", spara);
        }

        //Gst Applicable from 01 July 2017
        public static SqlDataReader getAgentGstNo(IBookingConfirmed IB)
        {
            SqlParameter[] spara ={ 
                                 new SqlParameter ("@CompBrSNo",IB.CompBrSNo),
                               
                            
                };
            return SqlHelper.ExecuteReader(PaceCommon.ConnectionString, "getAgentGstNo", spara);
        }
        public static DataSet checkCreditLimit(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",IB.custBranchSNo),
                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "checkCreditLimit", spara);
        }

        public static DataSet getBcnfDetails(IBookingConfirmed IB)
        {
            SqlParameter[] _param = {
              new SqlParameter("@SNo",IB.SNo),
               
           };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getBcnfDetails", _param);
        }
        public static DataSet getAllAgentsForBCnf(IBookingConfirmed IB, string CompBrSNo)
        {
            SqlParameter[] spara =                { 
                 new SqlParameter("@CompBrSNo",CompBrSNo),                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getAllAgentsForBCnf", spara);
        }
        public static DataSet getSubAgentDet(IBookingConfirmed IB, string custSno)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",custSno),                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getSubAgentDet", spara);
        }
        public static DataSet getIATAAgentDet(IBookingConfirmed IB, string custSno)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",custSno),
                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getIATAAgentDet", spara);
        }
        public static DataSet getNetAgentDet(IBookingConfirmed IB, string custSno)
        {
            SqlParameter[] spara = 
                { 
                    new SqlParameter ("@SNo",custSno),
                            
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getNetAgentDet", spara);
        }
        public static DataSet getBookingsForConsolidation(IBookingConfirmed IB, string CompBrSNo)
        {
            SqlParameter[] _param = {
              new SqlParameter("@ShipmentDate",IB.ShipmentDate),
               new SqlParameter("@CompBrSNo",CompBrSNo)
               
           };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getBookingsForConsolidation", _param);
        }
        public static DataSet getBookingsGroupwise(IBookingConfirmed IB, string CompBrSNo)
        {
            SqlParameter[] _param = {
                new SqlParameter("@Origin",IB.Origin ),
                new SqlParameter("@Destination",IB.Destination),
              new SqlParameter("@ShipmentDate",IB.ShipmentDate),
               new SqlParameter("@CompBrSNo",CompBrSNo)               
           };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getBookingsGroupwise", _param);
        }

        public static String addConsoleBookings(IBookingConfirmed IB, string MAWBSNo, string HAWBSNo, string CompBrSNo)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo),             
             new SqlParameter("@MAWBSNo",MAWBSNo),
             new SqlParameter("@MAWBNo",IB.MAWBNo ),
             new SqlParameter("@HAWBSNo",HAWBSNo),   
             new SqlParameter("@HAWBNo",IB.HAWBNo),
                new SqlParameter("@FlightNo",IB.FlightNo  ),
                 new SqlParameter("@CompBrSNo",CompBrSNo  ),
 
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "addConsoleBookings", _parameters));
        }

        public static SqlDataReader getCHA(IBookingConfirmed IB)
        {
            SqlParameter[] spara ={ 
                                 new SqlParameter ("@SNo",IB.CompBrSNo)               
                            
                };
            return SqlHelper.ExecuteReader(PaceCommon.ConnectionString, "getCHA", spara);
        }
        public static String getCHASNo(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@LoginId",IB.AddedBy)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "getCHASNo", _parameters));
        }
        public static String checkCHABookingDetails(string BookingRefNo)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BookingRefNo",BookingRefNo)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "checkCHABookingDetails", _parameters));
        }

        public static String copyAwbToPace(IBookingConfirmed IB,string NewBookingId)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.BConfId ),
             new SqlParameter("@NewBookingId",NewBookingId),
             new SqlParameter("@CompBrSNo",IB.CompBrSNo )
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "copyAwbToPace", _parameters));
        }


        public static DataSet getAllMasterStock(IBookingConfirmed IB, DateTime TodayDate, DateTime oneWeekAgo)
        {
            SqlParameter[] _param = {
                new SqlParameter("@AirlineCode",IB.AirlineCode ),
                new SqlParameter("@TodayDate",TodayDate ),
                new SqlParameter("@oneWeekAgo",oneWeekAgo )
           };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getAllMasterStock", _param);
        }
        public static DataSet getMasterStock(IBookingConfirmed IB)
        {
            SqlParameter[] _param = {
                new SqlParameter("@AirlineCode",IB.AirlineCode ),
           };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getMasterStock", _param);
        }
        public static DataSet getAllHouseStock(IBookingConfirmed IB)
        {
            SqlParameter[] _param = {
                new SqlParameter("@CustCode",IB.CustCode  )            
           };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getAllHouseStock", _param);
        }
        public static SqlDataReader  getAllPNP(IBookingConfirmed IB)
        {
            SqlParameter[] _param = {          
           };
            return SqlHelper.ExecuteReader (PaceCommon.ConnectionString, "getAllPNP", _param);
        }

        public static String checkTallyTransfer(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo  )
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "checkTallyTransfer", _parameters));
        }
        public static String updateBillEditable(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BConfId",IB.SNo  )
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "updateBillEditable", _parameters));
        }
        public static String getAllCrDr(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@SNo",IB.SNo  )
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "getAllCrDr", _parameters));
        }
        public static String getAllCrDrImp(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@SNo",IB.SNo  )
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "getAllCrDrImp", _parameters));
        }
        public static DataSet getCompanyBrSNo(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@CompBrSNo",IB.CompBrSNo)
            };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "getCompanyBrSNo", _parameters);
        }

        public static String insertBCChargesNew(IBookingConfirmed IB, SqlTransaction tr, string BCnfId, string ChrgeId, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBAmountNew1, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSAmountNew1, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount, decimal BuyingExchangeRate, decimal SellingExchangeRate)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@BCnfId",Convert.ToInt32 ( BCnfId)),
                 new SqlParameter("@ChrgeId",Convert.ToInt32 (ChrgeId))  ,
                  new SqlParameter("@BuyingAirfreight",Convert .ToDecimal ( BuyingAirfreight)),
                   new SqlParameter("@ddlBCurrencyNew1",ddlBCurrencyNew1),
                    new SqlParameter("@AfSellingCharges",AfSellingCharges),
                    new SqlParameter("@ddlSCurrencyNew1",ddlSCurrencyNew1),
                    new SqlParameter("@ddlSupplierNew1",ddlSupplierNew1)  ,
                    new SqlParameter("@txtBAmountNew1",txtBAmountNew1),
                    new SqlParameter("@txtBCRate",txtBCRate),
                    new SqlParameter("@txtBIRate",txtBIRate),
                    new SqlParameter("@txtBIncOnRate",txtBIncOnRate),
                    new SqlParameter("@txtBSpotRate",txtBSpotRate),
                    new SqlParameter("@txtBTDSRate",txtBTDSRate),
                    new SqlParameter("@txtSAmountNew1",txtSAmountNew1),
                    new SqlParameter("@txtSCRate",txtSCRate),
                    new SqlParameter("@txtSIRate",txtSIRate),
                    new SqlParameter("@txtSIncOnRate",txtSIncOnRate),
                    new SqlParameter("@txtSSpotRate",txtSSpotRate),
                    new SqlParameter("@txtSTDSRate",txtSTDSRate),
                    new SqlParameter("@BuyingAmount",BuyingAmount),
                    new SqlParameter("@SellingAmount",SellingAmount),
                    new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate),
                    new SqlParameter("@SellingExchangeRate",SellingExchangeRate)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr,"insertBCChargesNew", _parameters));
        }
        public static String insertBCChargesNewest(IBookingConfirmed IB, SqlTransaction tr, string BCnfId, string ChrgeId, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBAmountNew1, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSAmountNew1, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount, decimal BuyingExchangeRate, decimal SellingExchangeRate,string AllInBuy,string AllInSell,string CustomerName)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@BCnfId",Convert.ToInt32 ( BCnfId)),
                 new SqlParameter("@ChrgeId",Convert.ToInt32 (ChrgeId))  ,
                  new SqlParameter("@BuyingAirfreight",Convert .ToDecimal ( BuyingAirfreight)),
                   new SqlParameter("@ddlBCurrencyNew1",ddlBCurrencyNew1),
                    new SqlParameter("@AfSellingCharges",AfSellingCharges),
                    new SqlParameter("@ddlSCurrencyNew1",ddlSCurrencyNew1),
                    new SqlParameter("@ddlSupplierNew1",ddlSupplierNew1)  ,
                    new SqlParameter("@txtBAmountNew1",txtBAmountNew1),
                    new SqlParameter("@txtBCRate",txtBCRate),
                    new SqlParameter("@txtBIRate",txtBIRate),
                    new SqlParameter("@txtBIncOnRate",txtBIncOnRate),
                    new SqlParameter("@txtBSpotRate",txtBSpotRate),
                    new SqlParameter("@txtBTDSRate",txtBTDSRate),
                    new SqlParameter("@txtSAmountNew1",txtSAmountNew1),
                    new SqlParameter("@txtSCRate",txtSCRate),
                    new SqlParameter("@txtSIRate",txtSIRate),
                    new SqlParameter("@txtSIncOnRate",txtSIncOnRate),
                    new SqlParameter("@txtSSpotRate",txtSSpotRate),
                    new SqlParameter("@txtSTDSRate",txtSTDSRate),
                    new SqlParameter("@BuyingAmount",BuyingAmount),
                    new SqlParameter("@SellingAmount",SellingAmount),
                    new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate),
                    new SqlParameter("@SellingExchangeRate",SellingExchangeRate),
                     new SqlParameter("@AllInBuy",AllInBuy),
                    new SqlParameter("@AllInSell",AllInSell),
                    new SqlParameter("@CustomerName",CustomerName)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "insertBCChargesNewest", _parameters));
        }


        public static String insertBCChargesDeal(IBookingConfirmed IB, SqlTransaction tr, string BookingConfirmSNo, string BuyingAmount, string SellingAmount, string BuyingCurrency, string SellingCurrency, string awb_rate, string bill_amount, string comm_rate, string inc_rate, string inc_rate_on, string spot_rate, string tds_rate, string awb_rate1, string bill_amount1, string comm_rate1, string inc_rate1, string inc_rate_on1, string spot_rate1, string tds_rate1, string updated_by, string status, string requestedBy,string reqRemarks, string updatedRemarks, string AllInBuy, string AllInSell)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@BookingConfirmSNo",Convert.ToInt32 ( BookingConfirmSNo)),
                 new SqlParameter("@BuyingAmount",Convert.ToDecimal (BuyingAmount))  ,
                  new SqlParameter("@SellingAmount",Convert.ToDecimal (SellingAmount))  ,
                   new SqlParameter("@BuyingCurrency",BuyingCurrency),
                    new SqlParameter("@SellingCurrency",SellingCurrency),
                    new SqlParameter("@awb_rate",Convert.ToDecimal (awb_rate))  ,
                    new SqlParameter("@bill_amount",Convert.ToDecimal (bill_amount))  ,
                    new SqlParameter("@comm_rate",Convert.ToDecimal (comm_rate))  ,
                    new SqlParameter("@inc_rate",Convert.ToDecimal (inc_rate))  ,
                    new SqlParameter("@inc_rate_on",Convert.ToDecimal (inc_rate_on))  ,
                    new SqlParameter("@spot_rate",Convert.ToDecimal (spot_rate))  ,
                    new SqlParameter("@tds_rate",Convert.ToDecimal (tds_rate))  ,
                    new SqlParameter("@awb_rate1",Convert.ToDecimal (awb_rate1))  ,
                    new SqlParameter("@bill_amount1",Convert.ToDecimal (bill_amount1))  ,
                    new SqlParameter("@comm_rate1",Convert.ToDecimal (comm_rate1))  ,
                    new SqlParameter("@inc_rate1",Convert.ToDecimal (inc_rate1))  ,
                    new SqlParameter("@inc_rate_on1",Convert.ToDecimal (inc_rate_on1))  ,
                    new SqlParameter("@spot_rate1",Convert.ToDecimal (spot_rate1))  ,
                    new SqlParameter("@tds_rate1",Convert.ToDecimal (tds_rate1))  ,
                    new SqlParameter("@updated_by",updated_by),
                    new SqlParameter("@status",status),
                    new SqlParameter("@requestedBy",requestedBy),
                    new SqlParameter("@reqRemarks",reqRemarks),
                    new SqlParameter("@updatedRemarks",updatedRemarks),
                    new SqlParameter("@allInBuy",AllInBuy),
                    new SqlParameter("@allInSell",AllInSell)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "insertBCChargesDeal", _parameters));
        }



        public static String insertBCRejectDeal(IBookingConfirmed IB, SqlTransaction tr, string BookingConfirmSNo, string status)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@BookingConfirmSNo",Convert.ToInt32 ( BookingConfirmSNo)),
                 new SqlParameter("@status",status)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "insertBCRejectDeal", _parameters));
        }



        public static String insertBCChargesNew2(IBookingConfirmed IB, SqlTransaction tr, string BCnfId, string ChrgeId, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBAmountNew1, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSAmountNew1, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount,string SupplierName,decimal BuyingExchangeRate,decimal SellingExchangeRate)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@BCnfId",Convert.ToInt32 ( BCnfId)),
                 new SqlParameter("@ChrgeId",Convert.ToInt32 (ChrgeId))  ,
                  new SqlParameter("@BuyingAirfreight",Convert .ToDecimal ( BuyingAirfreight)),
                   new SqlParameter("@ddlBCurrencyNew1",ddlBCurrencyNew1),
                    new SqlParameter("@AfSellingCharges",AfSellingCharges),
                    new SqlParameter("@ddlSCurrencyNew1",ddlSCurrencyNew1),
                    new SqlParameter("@ddlSupplierNew1",ddlSupplierNew1)  ,
                    new SqlParameter("@txtBAmountNew1",txtBAmountNew1),
                    new SqlParameter("@txtBCRate",txtBCRate),
                    new SqlParameter("@txtBIRate",txtBIRate),
                    new SqlParameter("@txtBIncOnRate",txtBIncOnRate),
                    new SqlParameter("@txtBSpotRate",txtBSpotRate),
                    new SqlParameter("@txtBTDSRate",txtBTDSRate),
                    new SqlParameter("@txtSAmountNew1",txtSAmountNew1),
                    new SqlParameter("@txtSCRate",txtSCRate),
                    new SqlParameter("@txtSIRate",txtSIRate),
                    new SqlParameter("@txtSIncOnRate",txtSIncOnRate),
                    new SqlParameter("@txtSSpotRate",txtSSpotRate),
                    new SqlParameter("@txtSTDSRate",txtSTDSRate),
                    new SqlParameter("@BuyingAmount",BuyingAmount),
                    new SqlParameter("@SellingAmount",SellingAmount),
                     new SqlParameter("@SupplierName",SupplierName),
                     new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate),
                     new SqlParameter("@SellingExchangeRate",SellingExchangeRate)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "insertBCChargesNew2", _parameters));
        }
        public static String insertBCChargesNewest2(IBookingConfirmed IB, SqlTransaction tr, string BCnfId, string ChrgeId, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBAmountNew1, string txtBCRate, string txtBIRate, string txtBIncOnRate, string txtBSpotRate, string txtBTDSRate, string txtSAmountNew1, string txtSCRate, string txtSIRate, string txtSIncOnRate, string txtSSpotRate, string txtSTDSRate, string BuyingAmount, string SellingAmount, string SupplierName, decimal BuyingExchangeRate, decimal SellingExchangeRate,string AllInBuy,string AllInSell)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@BCnfId",Convert.ToInt32 ( BCnfId)),
                 new SqlParameter("@ChrgeId",Convert.ToInt32 (ChrgeId))  ,
                  new SqlParameter("@BuyingAirfreight",Convert .ToDecimal ( BuyingAirfreight)),
                   new SqlParameter("@ddlBCurrencyNew1",ddlBCurrencyNew1),
                    new SqlParameter("@AfSellingCharges",AfSellingCharges),
                    new SqlParameter("@ddlSCurrencyNew1",ddlSCurrencyNew1),
                    new SqlParameter("@ddlSupplierNew1",ddlSupplierNew1)  ,
                    new SqlParameter("@txtBAmountNew1",txtBAmountNew1),
                    new SqlParameter("@txtBCRate",txtBCRate),
                    new SqlParameter("@txtBIRate",txtBIRate),
                    new SqlParameter("@txtBIncOnRate",txtBIncOnRate),
                    new SqlParameter("@txtBSpotRate",txtBSpotRate),
                    new SqlParameter("@txtBTDSRate",txtBTDSRate),
                    new SqlParameter("@txtSAmountNew1",txtSAmountNew1),
                    new SqlParameter("@txtSCRate",txtSCRate),
                    new SqlParameter("@txtSIRate",txtSIRate),
                    new SqlParameter("@txtSIncOnRate",txtSIncOnRate),
                    new SqlParameter("@txtSSpotRate",txtSSpotRate),
                    new SqlParameter("@txtSTDSRate",txtSTDSRate),
                    new SqlParameter("@BuyingAmount",BuyingAmount),
                    new SqlParameter("@SellingAmount",SellingAmount),
                     new SqlParameter("@SupplierName",SupplierName),
                     new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate),
                     new SqlParameter("@SellingExchangeRate",SellingExchangeRate),
                      new SqlParameter("@AllInBuy",AllInBuy),
                     new SqlParameter("@AllInSell",AllInSell)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "insertBCChargesNewest2", _parameters));
        }
        public static String updateAFChargesInBookingConfirmedCharges(IBookingConfirmed IB, SqlTransaction tr, string BCnfId, string ChrgeId, string BuyingAirfreight, string ddlBCurrencyNew1, string AfSellingCharges, string ddlSCurrencyNew1, string ddlSupplierNew1, string txtBAmountNew1,decimal buyCommAmt, string txtBCRate,decimal buyIncAmt, string txtBIRate, string txtBIncOnRate,decimal buySpotAmt,decimal buySpotDiff, string txtBSpotRate,decimal buyTDSAmt, string txtBTDSRate, string txtSAmountNew1, string txtSCRate, decimal txtSCAmt, string txtSIRate, string txtSIncOnRate, decimal txtSIAmt, string txtSSpotRate, decimal txtSSpotAmt, decimal txtSSpotDiff, string txtSTDSRate, decimal txtSTDSAmt, string BuyingAmount, string SellingAmount, string SupplierName, decimal BuyingExchangeRate, decimal SellingExchangeRate, string AllInBuy, string AllInSell, int BCHSNo)
        {
            SqlParameter[] _parameters = {
                 
                 new SqlParameter("@BCnfId",Convert.ToInt32 ( BCnfId)),
                 new SqlParameter("@ChrgeId",Convert.ToInt32 (ChrgeId))  ,
                  new SqlParameter("@BuyingAirfreight",Convert .ToDecimal ( BuyingAirfreight)),
                   new SqlParameter("@ddlBCurrencyNew1",ddlBCurrencyNew1),
                    new SqlParameter("@AfSellingCharges",AfSellingCharges),
                    new SqlParameter("@ddlSCurrencyNew1",ddlSCurrencyNew1),
                    new SqlParameter("@ddlSupplierNew1",ddlSupplierNew1)  ,
                    new SqlParameter("@txtBAmountNew1",txtBAmountNew1),
                     new SqlParameter("@buyCommAmt",buyCommAmt),
                    new SqlParameter("@txtBCRate",txtBCRate),
                     new SqlParameter("@buyIncAmt",buyIncAmt),
                    new SqlParameter("@txtBIRate",txtBIRate),
                    new SqlParameter("@txtBIncOnRate",txtBIncOnRate),
                     new SqlParameter("@buySpotAmt",buySpotAmt),
                      new SqlParameter("@buySpotDiff",buySpotDiff),
                    new SqlParameter("@txtBSpotRate",txtBSpotRate),
                     new SqlParameter("@buyTDSAmt",buyTDSAmt),
                    new SqlParameter("@txtBTDSRate",txtBTDSRate),
                    new SqlParameter("@txtSAmountNew1",txtSAmountNew1),
                    new SqlParameter("@txtSCRate",txtSCRate),
                     new SqlParameter("@txtSCAmt",txtSCAmt),
                    new SqlParameter("@txtSIRate",txtSIRate),
                    new SqlParameter("@txtSIncOnRate",txtSIncOnRate),
                    new SqlParameter("@txtSIAmt",txtSIAmt),
                    new SqlParameter("@txtSSpotRate",txtSSpotRate),
                    new SqlParameter("@txtSSpotAmt",txtSSpotAmt),
                    new SqlParameter("@txtSSpotDiff",txtSSpotDiff),
                    new SqlParameter("@txtSTDSRate",txtSTDSRate),
                    new SqlParameter("@txtSTDSAmt",txtSTDSAmt),
                    new SqlParameter("@BuyingAmount",BuyingAmount),
                    new SqlParameter("@SellingAmount",SellingAmount),
                     new SqlParameter("@SupplierName",SupplierName),
                     new SqlParameter("@BuyingExchangeRate",BuyingExchangeRate),
                     new SqlParameter("@SellingExchangeRate",SellingExchangeRate),
                      new SqlParameter("@AllInBuy",AllInBuy),
                     new SqlParameter("@AllInSell",AllInSell),
                     new SqlParameter("@BCHSNo",BCHSNo)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "updateAFChargesInBookingConfirmedCharges", _parameters));
        }

        public static DataSet RI_Insert(IBookingConfirmed ibc)
        {
        SqlParameter [] _parameters={
                                new SqlParameter ("@Name",ibc.Name),
                                new SqlParameter ("@Address",ibc .Address ),
                                new SqlParameter ("@PAN_No",ibc .PAN_No )
                                
                                };
         return SqlHelper.ExecuteDataset(ConnectionString,"RI_Insert",_parameters );
        }
        public static SqlDataReader RIName_Select(IBookingConfirmed ibc)
        {
            SqlParameter[] _parameters = { };
            return  SqlHelper.ExecuteReader(ConnectionString, "RIName_Select", _parameters);
        
        }
        public static String RICommission_Insert(IBookingConfirmed ibc, string CompBrSNo,string PayType,string inv,DateTime invDate,string remarks)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@Name",ibc.Name),
                                 new SqlParameter ("@RISno",ibc.RISno),
                                 new SqlParameter ("@BookingRefNo",ibc.BookingRefNo ),
                                 new SqlParameter ("@Rate",ibc.Rate),
                                 new SqlParameter ("@Mode",ibc.Mode ),
                                 new SqlParameter ("@Chwt",ibc.ChWt ),
                                 new SqlParameter ("@Amount",ibc.Amount ),
                                 new SqlParameter ("@Date",ibc.AddedDate),
                                 new SqlParameter ("@CompBrSno",CompBrSNo ),
                                 new SqlParameter ("@AddBy",ibc .AddedBy ),
                                 new SqlParameter ("@ChequeName",ibc.ChequeName),
                                 new SqlParameter ("@PaymentType",PayType),
                                 new SqlParameter ("@Inv",inv),
                                 new SqlParameter ("@InvDate",invDate),
                                 new SqlParameter ("@Remarks",remarks)
                                
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "RICommission_Insert", _parameters));
        }
        public static String RICommission_InsertNewest(IBookingConfirmed ibc, string CompBrSNo, string PayType, string inv, DateTime invDate, string remarks, string billType)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@Name",ibc.Name),
                                 new SqlParameter ("@RISno",ibc.RISno),
                                 new SqlParameter ("@BookingRefNo",ibc.BookingRefNo ),
                                 new SqlParameter ("@Rate",ibc.Rate),
                                 new SqlParameter ("@Mode",ibc.Mode ),
                                 new SqlParameter ("@Chwt",ibc.ChWt ),
                                 new SqlParameter ("@Amount",ibc.Amount ),
                                 new SqlParameter ("@Date",ibc.AddedDate),
                                 new SqlParameter ("@CompBrSno",CompBrSNo ),
                                 new SqlParameter ("@AddBy",ibc .AddedBy ),
                                 new SqlParameter ("@ChequeName",ibc.ChequeName),
                                 new SqlParameter ("@PaymentType",PayType),
                                 new SqlParameter ("@Inv",inv),
                                 new SqlParameter ("@InvDate",invDate),
                                 new SqlParameter ("@Remarks",remarks),
                                 new SqlParameter ("@BillType",billType)
                                
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "RICommission_InsertNewest", _parameters));
        }
        public static String RICommission_UpdateNew(IBookingConfirmed ibc,int RITSno, string CompBrSNo, string PayType, string inv, DateTime invDate, string remarks)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter ("@RITSno",RITSno),
                                new SqlParameter ("@Name",ibc.Name),
                                 new SqlParameter ("@RISno",ibc.RISno),
                                 new SqlParameter ("@BookingRefNo",ibc.BookingRefNo ),
                                 new SqlParameter ("@Rate",ibc.Rate),
                                 new SqlParameter ("@Mode",ibc.Mode ),
                                 new SqlParameter ("@Chwt",ibc.ChWt ),
                                 new SqlParameter ("@Amount",ibc.Amount ),
                                 new SqlParameter ("@Date",ibc.AddedDate),
                                 new SqlParameter ("@CompBrSno",CompBrSNo ),
                                 new SqlParameter ("@AddBy",ibc .AddedBy ),
                                 new SqlParameter ("@ChequeName",ibc.ChequeName),
                                 new SqlParameter ("@PaymentType",PayType),
                                 new SqlParameter ("@Inv",inv),
                                 new SqlParameter ("@InvDate",invDate),
                                 new SqlParameter ("@Remarks",remarks)
                                
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "RICommission_UpdateNew", _parameters));
        }
        public static String RICommission_InsertNew(IBookingConfirmed ibc, string CompBrSNo,string PayType)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@Name",ibc.Name),
                                 //new SqlParameter ("@RISno",ibc.RISno),
                                 new SqlParameter ("@BookingRefNo",ibc.BookingRefNo ),
                                 new SqlParameter ("@Rate",ibc.Rate),
                                 new SqlParameter ("@Mode",ibc.Mode ),
                                 new SqlParameter ("@Chwt",ibc.ChWt ),
                                 new SqlParameter ("@Amount",ibc.Amount ),
                                 new SqlParameter ("@Date",ibc.AddedDate),
                                 new SqlParameter ("@CompBrSno",CompBrSNo ),
                                 new SqlParameter ("@AddBy",ibc .AddedBy ),
                                 new SqlParameter ("@ChequeName",ibc.ChequeName),
                                 new SqlParameter ("@Type",ibc.Type),
                                new SqlParameter ("@PaymentType",PayType)
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "RICommission_InsertNew", _parameters));
        }
        public static SqlDataReader getGodownDetails(IBookingConfirmed ibc,String CompBrSNo)
        {
            SqlParameter[] _parameters = {                                          
                           new SqlParameter ("@CompBrSno",CompBrSNo ),
                                         };
            return SqlHelper.ExecuteReader(ConnectionString, "getGodownDetails", _parameters);
        }
        public static String hideAWBforBilling(IBookingConfirmed ibc,string AWBSNo)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@AWBSNo",AWBSNo)                                
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "hideAWBforBilling", _parameters));
        }

        public static DataSet voidBooking(IBookingConfirmed ibc, string enteredBy)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@SNo",ibc.SNo) ,
                                new SqlParameter ("@entered_by",enteredBy) 
                                };
            return SqlHelper.ExecuteDataset(ConnectionString, "voidBooking", _parameters);
        }
        public static String SHICON(IBookingConfirmed ibc,string CUSTMast)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@custBranchSNo",ibc.custBranchSNo) ,
                                new SqlParameter ("@custBranchSNo",CUSTMast) 
                               
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "SHICON", _parameters));
        }
        public static DataSet GetExhibitionDet(int compbrsno)
        {
            SqlParameter[] _parameters ={
                                    new SqlParameter ("@CompBrSno",compbrsno )
                                    };
            return SqlHelper.ExecuteDataset (ConnectionString ,"GetExhibitionDet",_parameters );
        }

        public static DataSet GetOrigionalDealDeatils(int BCID)
        {
            SqlParameter[] _parameters ={
                                    new SqlParameter ("@BC_Sno",BCID )
                                    };

            return SqlHelper.ExecuteDataset(ConnectionString, "GetOrigionalDealDeatils", _parameters);
        }
         
        public static DataSet  getManagerCustomers(IBookingConfirmed ibc)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@custBranchSNo",ibc.CompBrSNo)
                                };
            return SqlHelper.ExecuteDataset(ConnectionString, "customermanager", _parameters);
        }
        public static String updateCustomernManager(IBookingConfirmed ibc,string OldCustBrSNo, string CUSTMast)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@custBranchSNo",ibc.custBranchSNo) ,
                                 new SqlParameter ("@OldcustBranchSNo",OldCustBrSNo) ,
                                new SqlParameter ("@CustomerType",CUSTMast) 
                               
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateCustomernManager", _parameters));
        }
        public static SqlDataReader getLeadSource()
        {
            return SqlHelper.ExecuteReader(PaceCommon.ConnectionString, "GetLeadSource");
        }
        public static String getAllCrDrSea(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@SNo",IB.SNo  )
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "getAllCrDrSea", _parameters));
        }
        public static String getAllCrDrSeaImp(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@SNo",IB.SNo  )
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(PaceCommon.ConnectionString, "getAllCrDrSeaImp", _parameters));
        }
        public static DataSet checkDealStatus(IBookingConfirmed IB)
        {
            SqlParameter[] spara = 
                { 
                     new SqlParameter ("@BcnfId",IB.BConfId )
                };
            return SqlHelper.ExecuteDataset(PaceCommon.ConnectionString, "checkDealStatus", spara);
        }
        public static String updateBookingConfirmComplete(int BCSno,string completedBy)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@BCSno",BCSno) ,
                              new SqlParameter ("@CompletedBy",completedBy)
                               
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateBookingConfirmComplete", _parameters));
        }
        public static DataSet getBankCashDeposit(int BSNo)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@Sno",BSNo)
                                         
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getBankCashDeposit", _parameters);
        }



        public static DataSet GetBankDeposit()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, "BankDepositBySNo");
        }
        public static DataSet getBankCheque(int ChequeSNo, string CompBrSno)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@SNo",ChequeSNo),
                                            new SqlParameter("@CompBrSno",CompBrSno)
                                         
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "ChequePrint", _parameters);
        }
        public static String InsertTransBookingAwb(string MAWBNo, string HAWBNo, string Origin, string Destination, DateTime FlightDate, int AgentSNo, int ShipperSNo, int ConsigneeSNo, string ShipperAddress, string ConsigneeAddress, DateTime AWBDate, string ShipperUsedBy, string ShipperUsedByCity, string ShipmentType, string SalesPerson, string FreightType, string WTPP, string WTCC, string OtherPP, string OtherCC, int RCP, decimal GrossWt, decimal ChargeableWt, decimal VolumeWt, string NatureofQuantity, int CompBrSNo, int RecCompBrSNo, string AddedBy)
        {
            SqlParameter[] _parameters ={
                                
                                new SqlParameter ("@MAWBNo",MAWBNo) ,
                                new SqlParameter ("@HAWBNo",HAWBNo) ,
                                new SqlParameter ("@Origin",Origin) ,
                                new SqlParameter ("@Destination",Destination) ,
                                 new SqlParameter ("@FlightDate",FlightDate) ,
                                 new SqlParameter ("@AgentSNo",AgentSNo) ,
                                  new SqlParameter ("@ShipperSNo",ShipperSNo) ,
                                new SqlParameter ("@ConsigneeSNo",ConsigneeSNo) ,
                                new SqlParameter ("@ShipperAddress",ShipperAddress) ,
                                new SqlParameter ("@ConsigneeAddress",ConsigneeAddress) ,
                                 new SqlParameter ("@AWBDate",AWBDate) ,
                                new SqlParameter ("@ShipperUsedBy",ShipperUsedBy) ,
                                 new SqlParameter ("@ShipperUsedByCity",ShipperUsedByCity) ,                               
                                new SqlParameter ("@ShipmentType",ShipmentType) ,
                                 new SqlParameter ("@SalesPerson",SalesPerson) ,
                                  new SqlParameter ("@FreightType",FreightType) ,
                                new SqlParameter ("@WTPP",WTPP) ,
                                 new SqlParameter ("@WTCC",WTCC) ,
                                   new SqlParameter ("@OtherPP",OtherPP) ,
                                new SqlParameter ("@OtherCC",OtherCC),
                                new SqlParameter ("@RCP",RCP) ,
                                new SqlParameter ("@GrossWt",GrossWt) ,                               
                                new SqlParameter ("@ChargeableWt",ChargeableWt) ,
                                 new SqlParameter ("@VolumeWt",VolumeWt) ,
                                new SqlParameter ("@NatureofQuantity",NatureofQuantity) ,
                                new SqlParameter ("@CompBrSNo",CompBrSNo) ,
                                new SqlParameter ("@RecCompBrSNo",RecCompBrSNo) ,
                                 new SqlParameter ("@AddedBy",AddedBy) 
                               
                              
                               
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "InsertTransBooking", _parameters));
        }


        public static String InsertTransBookingSea_bl(string ShippingLine, string HblNo, string MblNo, string JobNo, DateTime BlDate, string ShipperCode, string ShipperName, string ShipperAddressSea, string ShipperPhone, string ShipperEmail, string ConsigneeCode, string ConsigneeName, string ConsigneeAddressSea, string ConsigneePhone, string ConsigneeEmail, string NotifyCode, string NotifyName, string NotifyAddress, string NotifyPhone, string NotifyEmail, string DeliveryCode, string DeliveryName, string DeliveryAddress, string DeliveryPhone, string DeliveryEmail, string LoadingPort, string DischargePort, string ConatinerNo, string ContainerType, string PackageDescription, decimal GrossWtSea, decimal NetWt, int NoOfPackage, decimal Cbm, string Commodity, string FreightType, string ihc, string EnteredBy, string CompBrSNoSea)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@shipping_line",ShippingLine) ,
                                new SqlParameter ("@hbl_no",HblNo) ,
                                new SqlParameter ("@mbl_no",MblNo) ,
                                new SqlParameter ("@job_no",JobNo) ,
                                new SqlParameter ("@bl_date",BlDate) ,
                                new SqlParameter ("@shipper_code",ShipperCode) ,
                                new SqlParameter ("@shipper_name",ShipperName) ,
                                new SqlParameter ("@shipper_address",ShipperAddressSea) ,
                                new SqlParameter ("@shipper_phone",ShipperPhone) ,
                                new SqlParameter ("@shipper_email",ShipperEmail) ,
                                new SqlParameter ("@consignee_code",ConsigneeCode) ,
                                new SqlParameter ("@consignee_name",ConsigneeName) ,
                                new SqlParameter ("@consignee_phone",ConsigneePhone) ,
                                new SqlParameter ("@consignee_email",ConsigneeEmail) ,
                                new SqlParameter ("@consignee_address",ConsigneeAddressSea) ,
                                new SqlParameter ("@notify_code",NotifyCode) ,
                                new SqlParameter ("@notify_name",NotifyName) ,
                                new SqlParameter ("@notify_address",NotifyAddress) ,
                                new SqlParameter ("@notify_email",NotifyEmail) ,
                                new SqlParameter ("@notify_phone",NotifyPhone) ,
                                new SqlParameter ("@delivery_code",DeliveryCode) ,
                                new SqlParameter ("@delivery_name",DeliveryName) ,
                                new SqlParameter ("@delivery_address",DeliveryAddress) ,
                                 new SqlParameter("@delivery_email",DeliveryEmail) ,                                                                        new SqlParameter ("@delivery_phone",DeliveryPhone) ,
                                new SqlParameter ("@loading_port",LoadingPort) ,
                                new SqlParameter ("@discharge_port",DischargePort),
                                new SqlParameter ("@container_no",ConatinerNo),
                                new SqlParameter ("@container_type",ContainerType),
                                new SqlParameter ("@package_description",PackageDescription),
                                new SqlParameter ("@gross_wt",GrossWtSea),
                                new SqlParameter ("@net_wt",NetWt),
                                new SqlParameter ("@no_of_packages",NoOfPackage),
                                new SqlParameter ("@cbm",Cbm),
                                new SqlParameter ("@commodity",Commodity),
                                new SqlParameter ("@freight_type",FreightType),
                                new SqlParameter ("@ihc",ihc),
                                 new SqlParameter ("@EnteredBy",EnteredBy),
                                new SqlParameter ("@CompBrSNo",CompBrSNoSea)


                               
                                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "InsertTransBooking_Sea", _parameters));
        }

        public static DataSet getTransBilling(int Sno, int CompBrSno, string Type)
        {
            SqlParameter[] _parameters = {
                                            new SqlParameter("@SNo",Sno),
                                            new SqlParameter("@CompBrSno",CompBrSno),
                                            new SqlParameter("@Type",Type)
                                         
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getTransBilling", _parameters);
        }

        public static string UpdateTransBooking_Awb(int SNo, string MAWBNo, string HAWBNo, string Origin, string Destination, DateTime FlightDate, int AgentSNo, int ShipperSNo, int ConsigneeSNo, string ShipperAddress, string ConsigneeAddress, DateTime AWBDate, string ShipperUsedBy, string ShipperUsedByCity, string ShipmentType, string SalesPerson, string FreightType, string WTPP, string WTCC, string OtherPP, string OtherCC, int RCP, decimal GrossWt, decimal ChargeableWt, decimal VolumeWt, string NatureofQuantity, int CompBrSNo, string BasetoComp)
        {
            SqlParameter[] _parameters ={
                                new SqlParameter ("@SNo",SNo) ,
                                new SqlParameter ("@MAWBNo",MAWBNo) ,
                                new SqlParameter ("@HAWBNo",HAWBNo) ,
                                new SqlParameter ("@Origin",Origin) ,
                                new SqlParameter ("@Destination",Destination) ,
                                 new SqlParameter ("@FlightDate",FlightDate) ,
                                 new SqlParameter ("@AgentSNo",AgentSNo) ,
                                  new SqlParameter ("@ShipperSNo",ShipperSNo) ,
                                new SqlParameter ("@ConsigneeSNo",ConsigneeSNo) ,
                                new SqlParameter ("@ShipperAddress",ShipperAddress) ,
                                new SqlParameter ("@ConsigneeAddress",ConsigneeAddress) ,
                                 new SqlParameter ("@AWBDate",AWBDate) ,
                                new SqlParameter ("@ShipperUsedBy",ShipperUsedBy) ,
                                 new SqlParameter ("@ShipperUsedByCity",ShipperUsedByCity) ,                               
                                new SqlParameter ("@ShipmentType",ShipmentType) ,
                                 new SqlParameter ("@SalesPerson",SalesPerson) ,
                                  new SqlParameter ("@FreightType",FreightType) ,
                                new SqlParameter ("@WTPP",WTPP) ,
                                 new SqlParameter ("@WTCC",WTCC) ,
                                   new SqlParameter ("@OtherPP",OtherPP) ,
                                new SqlParameter ("@OtherCC",OtherCC),
                                new SqlParameter ("@RCP",RCP) ,
                                new SqlParameter ("@GrossWt",GrossWt) ,                               
                                new SqlParameter ("@ChargeableWt",ChargeableWt) ,
                                 new SqlParameter ("@VolumeWt",VolumeWt) ,
                                new SqlParameter ("@NatureofQuantity",NatureofQuantity) ,
                                new SqlParameter ("@CompBrSNo",CompBrSNo) ,
                                 new SqlParameter ("@CompBrSNo",BasetoComp) 
                                      };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "UpdateTransBooking_Awb", _parameters));
        }

        public static string UpdateTransBooking_Seabl(int SNo, string ShippingLine, string HblNo, string MblNo, string JobNo, DateTime BlDate, string ShipperCode, string ShipperName, string ShipperAddressSea, string ShipperPhone, string ShipperEmail, string ConsigneeCode, string ConsigneeName, string ConsigneeAddressSea, string ConsigneePhone, string ConsigneeEmail, string NotifyCode, string NotifyName, string NotifyAddress, string NotifyPhone, string NotifyEmail, string DeliveryCode, string DeliveryName, string DeliveryAddress, string DeliveryPhone, string DeliveryEmail, string LoadingPort, string DischargePort, string ConatinerNo, string ContainerType, string PackageDescription, decimal GrossWtSea, decimal NetWt, int NoOfPackage, decimal Cbm, string Commodity, string FreightType, string ihc, string ModifiedBy, string CompBrSNoSea, string BasetoComp)
        {
            SqlParameter[] _parameters = {
                                new SqlParameter ("@SNo",SNo) ,
                                new SqlParameter ("@shipping_line",ShippingLine) ,
                                new SqlParameter ("@hbl_no",HblNo) ,
                                new SqlParameter ("@mbl_no",MblNo) ,
                                new SqlParameter ("@job_no",JobNo) ,
                                new SqlParameter ("@bl_date",BlDate) ,
                                new SqlParameter ("@shipper_code",ShipperCode) ,
                                new SqlParameter ("@shipper_name",ShipperName) ,
                                new SqlParameter ("@shipper_address",ShipperAddressSea) ,
                                new SqlParameter ("@shipper_phone",ShipperPhone) ,
                                new SqlParameter ("@shipper_email",ShipperEmail) ,
                                new SqlParameter ("@consignee_code",ConsigneeCode) ,
                                new SqlParameter ("@consignee_name",ConsigneeName) ,
                                new SqlParameter ("@consignee_phone",ConsigneePhone) ,
                                new SqlParameter ("@consignee_email",ConsigneeEmail) ,
                                new SqlParameter ("@consignee_address",ConsigneeAddressSea) ,
                                new SqlParameter ("@notify_code",NotifyCode) ,
                                new SqlParameter ("@notify_name",NotifyName) ,
                                new SqlParameter ("@notify_address",NotifyAddress) ,
                                new SqlParameter ("@notify_email",NotifyEmail) ,
                                new SqlParameter ("@notify_phone",NotifyPhone) ,
                                new SqlParameter ("@delivery_code",DeliveryCode) ,
                                new SqlParameter ("@delivery_name",DeliveryName) ,
                                new SqlParameter ("@delivery_address",DeliveryAddress) ,
                                new SqlParameter("@delivery_email",DeliveryEmail) ,                                                                         new SqlParameter ("@delivery_phone",DeliveryPhone) ,
                                new SqlParameter ("@loading_port",LoadingPort) ,
                                new SqlParameter ("@discharge_port",DischargePort),
                                new SqlParameter ("@container_no",ConatinerNo),
                                new SqlParameter ("@container_type",ContainerType),
                                new SqlParameter ("@package_description",PackageDescription),
                                new SqlParameter ("@gross_wt",GrossWtSea),
                                new SqlParameter ("@net_wt",NetWt),
                                new SqlParameter ("@no_of_packages",NoOfPackage),
                                new SqlParameter ("@cbm",Cbm),
                                new SqlParameter ("@commodity",Commodity),
                                new SqlParameter ("@freight_type",FreightType),
                                new SqlParameter ("@ihc",ihc),
                                new SqlParameter ("@ModifiedBy",ModifiedBy),
                                new SqlParameter ("@CompBrSNo",CompBrSNoSea),
                                new SqlParameter ("@BasetoComp",BasetoComp)
                                        };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "UpdateTransBooking_Seabl", _parameters));
        }
        public static DataSet getEmailAddress(int CustBrSno)
        {
            SqlParameter[] _parameters = {
new SqlParameter("@CustBrSno",CustBrSno)
                                     };
            return SqlHelper.ExecuteDataset(ConnectionString, "getEmailAddress", _parameters);
        }

        public static string updateEmailAddress(string EmailID, string AlterEmailId, int CustBrSno, string Remarks, int hdnBSNo, int IMPSno, string CHAEmailID)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@Email",EmailID),
                                             new SqlParameter("@AlternateEmail",AlterEmailId),
                                             new SqlParameter("@CustBrSno",CustBrSno),
                                             new SqlParameter("@Remarks",Remarks),
                                             new SqlParameter("@BSNO",hdnBSNo),
                                             new SqlParameter("@ImpSNo",IMPSno),
                                             new SqlParameter("@CHAEmailID",CHAEmailID)
                                     };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateEmailAddress", _parameters));
        }


        public static string updateBooking(int hdnBSNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@Sno",hdnBSNo)
                                     };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateBookingEmail", _parameters));
        }
        public static DataSet getOtherCompanyCustBrSno(int compBrSno)
        {
            SqlParameter[] _parameters = {
new SqlParameter("@compBrSno",compBrSno)
                                     };
            return SqlHelper.ExecuteDataset(ConnectionString, "getOtherCompanyCustBrSno", _parameters);
        }

        public static string updateImport(int hdnBSNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@Sno",hdnBSNo)
                                     };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "updateImportEmail", _parameters));
        }


        public static string InsertDSR(string SalesPersonName, string EmailID, DateTime DSRDate, string Place, string Mode, string Type, string Origin, string Destination, string CompName, string ClientName, string ConPhone, string ConMobile, string Commodity, string Remarks, string EnteredBy, DateTime EnteredAt, string CompBrSno, DateTime birthDate, DateTime AnninverseyDate)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@SalesPersonName",SalesPersonName),
                                             new SqlParameter("@EmailID",EmailID),
                                             new SqlParameter("@DSRDate",DSRDate),
                                             new SqlParameter("@Place",Place),
                                             new SqlParameter("@Mode",Mode),
                                             new SqlParameter("@Type",Type),
                                             new SqlParameter("@Origin",Origin),
                                             new SqlParameter("@Destination",Destination),
                                             new SqlParameter("@CompName",CompName),
                                             new SqlParameter("@ClientName",ClientName),
                                             new SqlParameter("@ConPhone",ConPhone),
                                             new SqlParameter("@ConMobile",ConMobile),
                                             new SqlParameter("@Commodity",Commodity),
                                             new SqlParameter("@Remarks",Remarks),
                                             new SqlParameter("@EnteredBy",EnteredBy),
                                             new SqlParameter("@EnteredAt",EnteredAt),
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                             new SqlParameter("@BirthDate",birthDate),
                                             new SqlParameter("@AnninverseryDate",AnninverseyDate)
                                     };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "InsertDSR", _parameters));
        }

        public static DataSet GetDSR(int SNo)
        {
            SqlParameter[] _parameters ={
                                            new SqlParameter("@SNo",SNo)
                                   };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetDSR", _parameters);

        }

        public static string UpdateDSR(string SalesPersonName, string EmailID, DateTime DSRDate, string Place, string Mode, string Type, string Origin, string Destination, string CompName, string ClientName, string ConPhone, string ConMobile, string Commodity, string Remarks, string ModifiedBy, DateTime ModifiedDate, string CompBrSno, DateTime birthDate, DateTime AnninverseyDate, int SNo)
        {
            SqlParameter[] _parameters = {
                                             new SqlParameter("@SalesPersonName",SalesPersonName),
                                             new SqlParameter("@EmailID",EmailID),
                                             new SqlParameter("@DSRDate",DSRDate),
                                             new SqlParameter("@Place",Place),
                                             new SqlParameter("@Mode",Mode),
                                             new SqlParameter("@Type",Type),
                                             new SqlParameter("@Origin",Origin),
                                             new SqlParameter("@Destination",Destination),
                                             new SqlParameter("@CompName",CompName),
                                             new SqlParameter("@ClientName",ClientName),
                                             new SqlParameter("@ConPhone",ConPhone),
                                             new SqlParameter("@ConMobile",ConMobile),
                                             new SqlParameter("@Commodity",Commodity),
                                             new SqlParameter("@Remarks",Remarks),
                                             new SqlParameter("@CompBrSno",CompBrSno),
                                             new SqlParameter("@BirthDate",birthDate),
                                             new SqlParameter("@AnninverseryDate",AnninverseyDate),
                                             new SqlParameter("@ModifiedBy",ModifiedBy),
                                             new SqlParameter("@ModifiedDate",ModifiedDate),
                                             new SqlParameter("@SNo",SNo)
                                     };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "UpdateDSR", _parameters));
        }

        public static String UpdateWareHouseRFB(IBookingConfirmed IB, SqlTransaction tr, int RFBSNo, string CompBrSNo, int BookingSno, int pkg)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@CustomerName",IB.CustName),
             new SqlParameter("@CustBrSno",IB.custBranchSNo ),
             new SqlParameter("@Mawb_No",IB.MAWBNo),
             new SqlParameter("@Hawb_No",IB.HAWBNo),
             new SqlParameter("@GrossWt",IB.VolWt),   
             new SqlParameter("@VolumeWt",IB.GrWt), 
             new SqlParameter("@UpdatedBy",IB.AddedBy),   
             new SqlParameter("@UpdatedDate",IB.AddedDate),
             new SqlParameter("@ShipperSno",IB.ShipperCustBrSno),
             new SqlParameter("@ConsingeeSno",IB.ConsigneeCustBrSno),
              new SqlParameter("@RFBSNo",RFBSNo),
                new SqlParameter("@CompBrSno",CompBrSNo ),
                new SqlParameter("@BookingSno",BookingSno ),
             new SqlParameter("@Packages",pkg)
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "UpdateWareHouseRFB", _parameters));
        }

        public static String InsertWareHouse_BookingConfirmed(IBookingConfirmed IB, SqlTransaction tr, string compbrsno, int pkg,int BookingSno)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@CustomerName",IB.CustName),
             new SqlParameter("@CustBrSno",IB.custBranchSNo ),
             new SqlParameter("@Mawb_No",IB.MAWBNo),
             new SqlParameter("@Hawb_No",IB.HAWBNo),
             new SqlParameter("@GrossWt",IB.VolWt),   
             new SqlParameter("@VolumeWt",IB.GrWt), 
             new SqlParameter("@UpdatedBy",IB.AddedBy),   
             new SqlParameter("@UpdatedDate",IB.AddedDate),
             new SqlParameter("@ShipperSno",IB.ShipperCustBrSno),
             new SqlParameter("@ConsingeeSno",IB.ConsigneeCustBrSno),
                new SqlParameter("@CompBrSno",compbrsno ),
                new SqlParameter("@BookingSno",BookingSno ),
             new SqlParameter("@Packages",pkg)
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "InsertWareHouse_BookingConfirmed", _parameters));
            //return Convert.ToString(SqlHelper.ExecuteScalar(tr, "BookingConfirmed_InsertIndrctGd", _parameters));
        }


        public static String getRedRefNo(int BCSNo)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BCSNo",BCSNo)             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getRedRefNo", _parameters));
        }

        public static String UpdateAWBTracking(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@BCSNo",IB.BCSNo),           
             new SqlParameter("@AWBNO",IB.AWBNO)     
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "UpdateAWBTracking", _parameters));
        }

        public static String restoreCreditLimitRedIntl(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@CustBranchSNo",IB.custBranchSNo),           
             new SqlParameter("@Amount",IB.UsedAmt),
             new SqlParameter("@LimitType",IB.LimitType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "restoreCreditLimit", _parameters));
        }

        public static String updateCreditLimitRedIntl(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@CustBranchSNo",IB.custBranchSNo),           
             new SqlParameter("@Used",IB.UsedAmt),
             new SqlParameter("@LimitType",IB.LimitType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "updateCreditLimit", _parameters));
        }

        public static String insertCreditLimitUses(IBookingConfirmed IB)
        {
            SqlParameter[] _parameters = {
             new SqlParameter("@custMastSno",IB.custMastSno),           
             new SqlParameter("@custBrSno",IB.custBrSno),
             new SqlParameter("@compBrSno",IB.compBrSno),
             new SqlParameter("@transactionType",IB.transactionType),           
             new SqlParameter("@amount",IB.amount),
             new SqlParameter("@creditLimit",IB.creditLimit),
             new SqlParameter("@usedCrLimitBeforeTransaction",IB.usedCrLimitBeforeTransaction),           
             new SqlParameter("@usedCrLimitAfterTransaction",IB.usedCrLimitAfterTransaction),
             new SqlParameter("@availableCrLimitBeforeTransaction",IB.availableCrLimitBeforeTransaction),
             new SqlParameter("@availableCrLimitAfterTransaction",IB.availableCrLimitAfterTransaction),           
             new SqlParameter("@creditType",IB.creditType),
             new SqlParameter("@updatedBy",IB.updatedBy),
             new SqlParameter("@bookingSno",IB.bookingSno),           
             new SqlParameter("@billingSno",IB.billingSno),
             new SqlParameter("@paymentTransSno",IB.paymentTransSno),
             new SqlParameter("@paymentMastSno",IB.paymentMastSno),
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "insertCreditLimitUses", _parameters));
        }
    }   
}
