using System;
using System.Collections.Generic;
using System.Text;

using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;

namespace Cfi.App.Pace.Data
{
   public  class GeneralData :PaceCommon 
    {
        public static DataSet getSPHC(String Code)
        {
            SqlParameter[] _param = { new SqlParameter("@_Code", Code) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveHandlingCode", _param);
        }

        public static SqlDataReader RetriveAllULD(String strR)
        {
            SqlParameter[] _param = { new SqlParameter("@ULDName", strR) };
            return SqlHelper.ExecuteReader(ConnectionString, "getULDName", _param);
        }

        public static SqlDataReader RetriveULDDetails(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_CityName", strC) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveULDDetails", _param);
        }

        public static SqlDataReader RetriveAllCity(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_CityCode", strC) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAllCity", _param);
        }
        public static SqlDataReader RetriveAllUserID(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_UserId", strC) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAllUserID", _param);
        }       

        public static SqlDataReader checkCommodity(String str)
        {
            SqlParameter[] _param = { new SqlParameter("@_CommodityCode", str) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAllCommodityByDesc", _param);
        }

        public static SqlDataReader RetriveCustomer(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_CustomerCode", strC) };
            return SqlHelper.ExecuteReader(ConnectionString, "[_RetriveCustomerCode]", _param);
        }
       public static SqlDataReader RetriveCustomerWithAccess(String strC)
       {
           SqlParameter[] _param = { new SqlParameter("@CustomerCity", strC) };
           return SqlHelper.ExecuteReader(ConnectionString, "[_RetriveCustomer_Details]", _param);
       }
       public static SqlDataReader RetriveCustomerWithBranch(String CompBrSNo)
       {
           SqlParameter[] _param = { new SqlParameter("@CompBrSNo", CompBrSNo) };
           return SqlHelper.ExecuteReader(ConnectionString, "[_RetriveCustomer_DetailsBranchwise]", _param);
       }
        public static SqlDataReader RetriveDailyFlightsCity()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveDailyFlightsCity");
        }

        public static SqlDataReader RetriveViaCity(String Origin)
        {
            SqlParameter[] _param = { new SqlParameter("@_Origin", Origin) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveViaCity");
        }

        public static SqlDataReader getRateMasterOrigin()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "getRateMasterOrigin");
        }

        public static SqlDataReader getRateMasterDestination(String Origin)
        {
            SqlParameter[] _param = { new SqlParameter("@_Origin", Origin) };
            return SqlHelper.ExecuteReader(ConnectionString, "getRateMasterDestination", _param);
        }

        public static int getRMDestination(String Origin)
        {
            SqlParameter[] _param = { new SqlParameter("@_Origin", Origin) };
            return Convert.ToInt16(SqlHelper.ExecuteScalar(ConnectionString, "getRMDestination", _param));
        }

        public static SqlDataReader getRateMasterHandoverDestination(String Origin, DateTime Date)
        {
            SqlParameter[] _param = { 
                new SqlParameter("@_Origin", Origin),
                new SqlParameter("@_Date", Date) 
            };
            return SqlHelper.ExecuteReader(ConnectionString, "getRateMasterHandoverDestination", _param);
        }

        public static int getRateMasterHandoverDestinationCount(String Origin, DateTime Date)
        {
            SqlParameter[] _param = { new SqlParameter("@_Origin", Origin), new SqlParameter("@_Date", Date) };
            return Convert.ToInt16(SqlHelper.ExecuteScalar(ConnectionString, "getRateMasterHandoverDestinationCount", _param));
        }

        public static SqlDataReader RetriveAllCountry(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_CountryCode", strC) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAllCountry", _param);
        }

        public static DataSet FillCity(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_Name", strC) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveCitypop", _param);
        }
       public static DataSet FillCompanyCity(String strC)
       {
           SqlParameter[] _param = { new SqlParameter("@_Name", strC) };
           return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveCompanyCitypop", _param);
       }
       public static DataSet FillCitystock(String strC)
       {
           SqlParameter[] _param = { new SqlParameter("@_Name", strC) };
           return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveCitypop1", _param);
       }
        public static DataSet FillCustomer(String name, String AgentCode)
        {
            SqlParameter[] _param = { new SqlParameter("@_Name", name), new SqlParameter("@_AgentCode", AgentCode) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveCustomer", _param);
        }

        public static DataSet FillCountry(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_Name", strC) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveCountry", _param);
        }

        public static DataSet RetriveAllCityDataset(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_CityCode", strC) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveAllCity", _param);
        }

        public static DataSet RetriveAllCountryDataset(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_CountryCode", strC) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveAllCountry", _param);
        }

        public static DataSet RetriveAllDataDataset(String strC)
        {
            return SqlHelper.ExecuteDataset(ConnectionString, CommandType.Text, strC);
        }

        public static DataSet RetriveAllShipment(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_Shipment", strC) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveAllShipment", _param);
        }

        public static DataSet getAgentsByCity(String city)
        {
            SqlParameter[] _param = { new SqlParameter("@_City", city) };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAgentsByCity", _param);
        }

        public static DataSet RetriveAllCommodity(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_Commodity", strC) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveAllCommodity", _param);
        }

        public static DataSet RetriveAllCurency(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_Currency", strC) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveAllCurrency", _param);
        }

        public static SqlDataReader RetriveAgentbyAgent(String AgentCode)
        {
            SqlParameter[] _param = { new SqlParameter("@_AgentCode", AgentCode) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAgentbyAgent", _param);
        }

        public static SqlDataReader RetriveAgentbyCity(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_CityCode", strC) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAgentbyCity", _param);
        }

        public static int getAgentbyCity(String Origin)
        {
            SqlParameter[] _param = { new SqlParameter("@_Origin", Origin) };
            return Convert.ToInt16(SqlHelper.ExecuteScalar(ConnectionString, "RetriveAgentbyCity", _param));
        }

        public static SqlDataReader RetriveCreditLimitByAgent(String strC, SqlTransaction tr)
        {
            SqlParameter[] _param = { new SqlParameter("@_AgentCode", strC) };
            return SqlHelper.ExecuteReader(tr, "_RetriveCreditLimitByAgent", _param);
        }

        public static DataSet RetriveFlightType()
        {
            return SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "_RetriveAllFlightType");
        }

        public static DataSet RetriveDueCarrier()
        {
            return SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "_RetriveAllCarrier");
        }

        public static DataSet ReturnDueCarrierDetails(Int32 dsno, Decimal vpkg, Decimal min, DateTime vf, DateTime vt, String ow)
        {
            SqlParameter[] _param = { 
                new SqlParameter("@_DSNo", dsno),
                new SqlParameter("@_VPKG", vpkg),
                new SqlParameter("@_Min", min),
                new SqlParameter("@_VF", vf),
                new SqlParameter("@_VT", vt),
                new SqlParameter("@_OW", ow)
                };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveAllCarrierDetails", _param);
        }

        public static String UpdateCarrierAll(Int32 dsno, Decimal vpkg, Decimal min, DateTime vf, DateTime vt, Int32 rid, String ow, String etby)
        {
            SqlParameter[] _param = { 
                new SqlParameter("@_DSNo", dsno),
                new SqlParameter("@_VPKG", vpkg),
                new SqlParameter("@_Min", min),
                new SqlParameter("@_VF", vf),
                new SqlParameter("@_VT", vt),
                new SqlParameter("@_RID", rid),
                new SqlParameter("@_Enteredby",etby),
                new SqlParameter("@_OW", ow)
                };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "_UpdateCarrierAll", _param));
        }

        public static String UpdateCarrierDate(Int32 sno, DateTime vt, String etby)
        {
            SqlParameter[] _param = { new SqlParameter("@_SNo", sno), new SqlParameter("@_VT", vt), new SqlParameter("@_Enteredby", etby) };
            return Convert.ToString(SqlHelper.ExecuteNonQuery(ConnectionString, "_UpdateCarrierDate", _param));
        }

        public static String getFlightData(String @_AirlineCode, DateTime @_FlightDate, String @_Origin, String @_Destination, Int64 @_ChWt, Int64 @_GrWt, String @_ShipmentType, String @_Commodity, String @_FreightType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt),
		        new SqlParameter( "@_GrWt", @_GrWt),
		        new SqlParameter( "@_ShipmentType", @_ShipmentType),
		        new SqlParameter( "@_Commodity", @_Commodity),
                new SqlParameter( "@_FreightType", @_FreightType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getFlightsAndRates", _parameters));
        }

        public static String getFlightDataByFlightNo(String @_AirlineCode, DateTime @_FlightDate, String @_FlightNo, String @_Origin, String @_Destination, Int64 @_ChWt, Int64 @_GrWt, String @_ShipmentType, String @_Commodity, String @_FreightType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
                new SqlParameter( "@FlightNo", @_FlightNo),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt),
		        new SqlParameter( "@_GrWt", @_GrWt),
		        new SqlParameter( "@_ShipmentType", @_ShipmentType),
		        new SqlParameter( "@_Commodity", @_Commodity),
                new SqlParameter( "@_FreightType", @_FreightType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getFlightAndRatesByFlightNo", _parameters));
        }

        public static String getHandoverFlightDataExport(String @_AirlineCode, DateTime @_FlightDate, String @_Origin, String @_Destination, Int64 @_ChWt)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getHandoverFlightsAndRatesExport", _parameters));
        }

        public static String getHandoverFlightData(String @_AirlineCode, DateTime @_FlightDate, String @_Origin, String @_Destination, Int64 @_ChWt, Int64 @_GrWt, String @_ShipmentType, String @_Commodity, String @_FreightType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt),
		        new SqlParameter( "@_GrWt", @_GrWt),
		        new SqlParameter( "@_ShipmentType", @_ShipmentType),
		        new SqlParameter( "@_Commodity", @_Commodity),
                new SqlParameter( "@_FreightType", @_FreightType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getHandoverFlightsAndRates", _parameters));
        }

        public static String getHandoverFlightDataByFlightNo(String @_AirlineCode, DateTime @_FlightDate, String @_FlightNo, String @_Origin, String @_Destination, Int64 @_ChWt, Int64 @_GrWt, String @_ShipmentType, String @_Commodity, String @_FreightType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
                new SqlParameter( "@FlightNo", @_FlightNo),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt),
		        new SqlParameter( "@_GrWt", @_GrWt),
		        new SqlParameter( "@_ShipmentType", @_ShipmentType),
		        new SqlParameter( "@_Commodity", @_Commodity),
                new SqlParameter( "@_FreightType", @_FreightType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getHandoverFlightDataByFlightNo", _parameters));
        }

        public static String getHandoverFlightDataByCarrier(String @_CarrierCode, String @_AirlineCode, DateTime @_FlightDate, String @_Origin, String @_Destination, Int64 @_ChWt, Int64 @_GrWt, String @_ShipmentType, String @_Commodity, String @_FreightType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_FlightCode" , @_CarrierCode),
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt),
		        new SqlParameter( "@_GrWt", @_GrWt),
		        new SqlParameter( "@_ShipmentType", @_ShipmentType),
		        new SqlParameter( "@_Commodity", @_Commodity),
                new SqlParameter( "@_FreightType", @_FreightType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getHandoverFlightsAndRatesByCarrier", _parameters));
        }

        public static String getHandoverFlightDataByFlightNoByCarrier(String @_CarrierCode, String @_AirlineCode, DateTime @_FlightDate, String @_FlightNo, String @_Origin, String @_Destination, Int64 @_ChWt, Int64 @_GrWt, String @_ShipmentType, String @_Commodity, String @_FreightType)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_FlightCode" , @_CarrierCode),
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
                new SqlParameter( "@FlightNo", @_FlightNo),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt),
		        new SqlParameter( "@_GrWt", @_GrWt),
		        new SqlParameter( "@_ShipmentType", @_ShipmentType),
		        new SqlParameter( "@_Commodity", @_Commodity),
                new SqlParameter( "@_FreightType", @_FreightType)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getHandoverFlightDataByFlightNoByCarrier", _parameters));
        }

        public static String getHandoverFlightDataByFlightNoExport(String @_AirlineCode, DateTime @_FlightDate, String @_FlightNo, String @_Origin, String @_Destination, Int64 @_ChWt)
        {
            SqlParameter[] _parameters = {
                new SqlParameter( "@_AirlineCode" , @_AirlineCode),
		        new SqlParameter( "@_FlightDate", @_FlightDate),
                new SqlParameter( "@FlightNo", @_FlightNo),
		        new SqlParameter( "@_Origin", @_Origin),
		        new SqlParameter( "@_Destination", @_Destination),
		        new SqlParameter( "@_ChWt", @_ChWt)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "getHandoverFlightDataByFlightNoExport", _parameters));
        }

        public static SqlDataReader RetriveAllCurrencyFromCity(String strR)
        {
            SqlParameter[] _param = { new SqlParameter("@_Currency", strR) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAllCurrencyFromCity", _param);
        }

        public static SqlDataReader RetriveAllTimeZone(String strC)
        {
            SqlParameter[] _param = { new SqlParameter("@_timeZone", strC) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAllTimeZone", _param);
        }

        public static SqlDataReader RetriveAgentbyAgentImport(String AirlineCode)
        {
            SqlParameter[] _param = { new SqlParameter("@_AirlineCode", AirlineCode) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAgentbyAgentImport", _param);
        }

        public static SqlDataReader RetriveFromAWBImport(String AWBNo)
        {
            SqlParameter[] _param = { new SqlParameter("@AWBNo", AWBNo) };
            return SqlHelper.ExecuteReader(ConnectionString, "_RetriveFromAWBImport", _param);
        }

        public static DataSet FillAWBNo(String AWBNo)
        {
            SqlParameter[] _param = { new SqlParameter("@_AWBNo", AWBNo) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveAWBNO", _param);
        }

        public static DataSet FillFlightNo(String FlightNo)
        {
            SqlParameter[] _param = { new SqlParameter("@_FlightNo", FlightNo) };
            return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveFlightNo", _param);
        }
       public static SqlDataReader RetriveAllLoginID(String strC)
       {
           SqlParameter[] _param = { new SqlParameter("@_LoginID", strC) };
           return SqlHelper.ExecuteReader(ConnectionString, "_RetriveAllLoginID", _param);
       }
       public static DataSet RetriveCity()
       {
           return SqlHelper.ExecuteDataset(ConnectionString, "_RetriveCity");
       }
       public static SqlDataReader RetriveCountry()
       {
           return SqlHelper.ExecuteReader(ConnectionString, "_RetriveCountry");
       }
       public static SqlDataReader RetriveCurrency()
       {
           return SqlHelper.ExecuteReader(ConnectionString, "_RetriveCurrency");
       }
       public static SqlDataReader RetriveCategory(string CountryCode)
       {
           SqlParameter[] _param ={ new SqlParameter("@CountryCode", CountryCode) };
           return SqlHelper.ExecuteReader(ConnectionString, "_RetriveCategory",_param);
       }

       public static DataSet GetGroupName()
       {
           return SqlHelper.ExecuteDataset(ConnectionString, "usrgrp_GetUserGroupName");
       }
       public static SqlDataReader getCompanyCity()
       {
           return SqlHelper.ExecuteReader(ConnectionString, "getCompanyCity");
       }
       public static DataSet getCountryAllDetail()
       {
           SqlParameter[] _param ={ new SqlParameter("@SNo", "All") };
           return SqlHelper.ExecuteDataset(ConnectionString, "getCountryAllDetail",_param);
       }
       public static DataSet getCurrencyNew()
       {
           return SqlHelper.ExecuteDataset(ConnectionString, "getCurrencyNew");
       }
       public static DataSet getActiveCustomerCare()
       {
           return SqlHelper.ExecuteDataset(ConnectionString, "getActiveCustomerCare");
       }
       public static DataSet getCountryDetailForIndia()
       {
           return SqlHelper.ExecuteDataset(ConnectionString, "getCountryDetailForIndia");
       }
       public static DataSet getAgentsByCityName(String city)
       {
           SqlParameter[] _param = { new SqlParameter("@_City", city) };
           return SqlHelper.ExecuteDataset(ConnectionString, "getAgentsByCityName", _param);
       }
       //public static Boolean  allowedpage(string str)
       //{
       //    bool flag = false;
       //    string pagename =GetCurrentPageName();
       //    string[] allowedpage = str.ToString().Split(',');
           
       //    if (pagename != "")
       //    {
       //        pagename = pagename.Trim();
       //        string pagesno = getpagesno(pagename);
       //        for (int z = 0; z < allowedpage.Length; z++)
       //        {
       //            if (allowedpage[z].ToString().Trim() == pagesno.Trim())
       //            {
       //                flag = true;
       //            }

       //        }
       //        if (flag == false)
       //        {
       //            return false;
       //        }
       //        else
       //        {
       //            return true;
       //        }
       //    }
       //}
       //public  static string GetCurrentPageName()
       //{
       //    string sPath = System.Web.HttpContext.Current.Request.Url.AbsolutePath;
       //    System.IO.FileInfo oInfo = new System.IO.FileInfo(sPath);
       //    string sRet = oInfo.Name;

       //    DataSet ds = getPageDetails(sRet);
       //    if (ds.Tables[0].Rows.Count > 0)
       //    {
       //        foreach (DataRow dr in ds.Tables[0].Rows)
       //        {
       //            sRet = "" + dr["header"].ToString() + " &gt;&gt; " + dr["pageNAme"].ToString();
       //        }
       //    }
       //    else
       //    {
       //        sRet = "" + "Home";
       //    }
       //    return sRet;
       //}
       public static  string getpagesno(string parameter)
       {
           SqlParameter[] rParam = { new SqlParameter("@pagename", parameter) };
           return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "checkpage", rParam));

       }
       public static  DataSet getPageDetails(string parameter)
       {
           SqlParameter[] rParam = { new SqlParameter("@pageLink", parameter) };
           return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "GetPageName", rParam);
       }

    }
}
