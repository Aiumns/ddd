﻿using System;
using System.Collections.Generic;
using System.Text;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;
using System.Data;
using System.Data.SqlClient;

namespace Cfi.App.Pace.Data
{
    public class DCHA :PaceCommon
    {
        public static String Insert_CHADetails(ICHA IC)
        {
            SqlParameter[] _Param ={
           new SqlParameter("@CHAName",IC.CHAName),
           new SqlParameter("@HouseNo",IC.HouseNo),
           new SqlParameter("@StreetNo",IC.Street),
           new SqlParameter("@Place",IC.Place),
           new SqlParameter("@PostCode",IC.PostCode),
           new SqlParameter("@Phone",IC.Phone),
           new SqlParameter("@Fax",IC.FAX),
            new SqlParameter("@Mobile",IC.MobileNo),
           new SqlParameter("@Email",IC.Email),
           new SqlParameter("@WebSite",IC.WebSite),
           new SqlParameter("@State",IC.State),
           new SqlParameter("@CountryCode",IC.CountryCode),
           new SqlParameter("@CompBrSno",IC.CompBrSNo),
           new SqlParameter("@AddedBy",IC.EnteredBy),          
           new SqlParameter("@Active",IC.Active)
          
           };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CHADetails", _Param));
        }
        public static SqlDataReader GetCHA_Details(Int32 Sno)
        {
           SqlParameter[] _Param ={
           new SqlParameter("@SNo",Sno)
                                  };
          return SqlHelper.ExecuteReader(ConnectionString, "GetCHADetails", _Param); 

        }
        public static String Update_CHADetails(ICHA IC,Int32 Sno)
        {
            SqlParameter[] _Param ={
           new SqlParameter("@Sno",Sno),
           new SqlParameter("@CHAName",IC.CHAName),         
           new SqlParameter("@StreetNo",IC.Street),
           new SqlParameter("@Place",IC.Place),
           new SqlParameter("@PostCode",IC.PostCode),
           new SqlParameter("@Phone",IC.Phone),
           new SqlParameter("@Fax",IC.FAX),
            new SqlParameter("@Mobile",IC.MobileNo),
           new SqlParameter("@Email",IC.Email),
           new SqlParameter("@WebSite",IC.WebSite),
           new SqlParameter("@State",IC.State),
           new SqlParameter("@CountryCode",IC.CountryCode),
           new SqlParameter("@CompBrSno",IC.CompBrSNo),                 
           new SqlParameter("@Active",IC.Active)
          
           };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Update_CHADetails", _Param));
        }


        public static String Delete_CHADetails(ICHA IC, Int32 Sno)
        {
            SqlParameter[] dParameter ={
            new SqlParameter("@sno",Sno)};
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Delete_CHADetails", dParameter));
        }

        public static SqlDataReader CHADetails_Show()
        {           
           return SqlHelper.ExecuteReader(ConnectionString, "CHADetails_Show"); 
        }
        public static SqlDataReader CompDet_CHADet_Show(Int32 Sno)
        {
           SqlParameter[] _Param ={
           new SqlParameter("@SNo",Sno)
                                  };
           return SqlHelper.ExecuteReader(ConnectionString, "CompDet_CHADet_Show", _Param); 
        }
        public static string login_CreateCHAUser(ICHA iuser)
        {
            SqlParameter[] _param ={
                new SqlParameter("@UserName",iuser.UserName),
                new SqlParameter("@DisplayName",iuser.DisplayName),
                new SqlParameter("@UserGroup",iuser.UserGroup), 
                new SqlParameter("@EmailID",iuser.EmailID),
                new SqlParameter("@Password",iuser.Password),
                new SqlParameter("@BrSno",iuser.BrSno),
                new SqlParameter("@CHASno",iuser.CHASno)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "login_CreateCHAUser", _param));
        
        }
        public static SqlDataReader CHAUserLogin_Show(Int32 Sno)
        {
            SqlParameter[] _Param ={
           new SqlParameter("@SNo",Sno)
                                  };
            return SqlHelper.ExecuteReader(ConnectionString, "CHAUserLogin_Show", _Param);
        }
       public static string login_UpdateCHAUser(ICHA iuser)
        {
            SqlParameter[] _param ={
                new SqlParameter("@Sno",int.Parse(iuser.Sno)),
                new SqlParameter("@DisplayName",iuser.DisplayName),
                new SqlParameter("@UserGroup",iuser.UserGroup), 
                new SqlParameter("@EmailID",iuser.EmailID),
                new SqlParameter("@Password",iuser.Password),
                new SqlParameter("@BrSno",iuser.BrSno),
                new SqlParameter("@CHASno",iuser.CHASno)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "login_UpdateCHAUser", _param));
        
        }
       public static DataSet CHAChargesShow()
        {
            
            return SqlHelper.ExecuteDataset(ConnectionString, "CHAChargesShow");
        }

       public static DataSet GetCHABookinShip_Count(Int32 BookingRefSno)
        {
            SqlParameter[] _Param ={
           new SqlParameter("@BookiingRefSno",BookingRefSno)
                                  };
            return SqlHelper.ExecuteDataset(ConnectionString, "GetCHABookinShip_Count", _Param);
        }

       public static string Insert_CHACharges(ICHA iuser)
       {          
           SqlParameter[] _param ={
                new SqlParameter("@BookRefNo",iuser.BookRefNo),
                new SqlParameter("@AppRemark",iuser.AppRemark),
                new SqlParameter("@TotalAmt",iuser.TotalAmt), 
                new SqlParameter("@Status",iuser.Status),
                new SqlParameter("@AddBy",iuser.EnteredBy),
                
              
            };
           return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CHACharges", _param));

       }
       public static DataSet Insert_CHACharges2(ICHA iuser, string Awb, int compbrso, decimal chwt, int AwbSno, int CHASNO, int AwbSnoBComp, int bookingIdBComp, string CopyToBaseCompany)
       {
           SqlParameter[] _param ={
                new SqlParameter("@BookRefNo",iuser.BookRefNo),
                new SqlParameter("@AppRemark",iuser.AppRemark),
                new SqlParameter("@TotalAmt",iuser.TotalAmt), 
                new SqlParameter("@Status",iuser.Status),
                new SqlParameter("@AddBy",iuser.EnteredBy),
                new SqlParameter("@MAWB",Awb),
                new SqlParameter("@CompBrSno",compbrso),
                new SqlParameter("@chwt",chwt),
                new SqlParameter("@AwbSno",AwbSno),
                new SqlParameter("@CHASNO",CHASNO),
                new SqlParameter("@AwbSnoBComp",AwbSnoBComp),
                new SqlParameter("@BookRefNoBComp",bookingIdBComp),
                new SqlParameter("@CopyToBaseCompany",CopyToBaseCompany)
            };
           return SqlHelper.ExecuteDataset(ConnectionString, "Insert_CHACharges2", _param);

       }
       public static string Update_CHACharges(ICHA iuser)
       {
           SqlParameter[] _param ={
                new SqlParameter("@BookRefNo",iuser.BookRefNo),
                new SqlParameter("@AppRemark",iuser.AppRemark),
                new SqlParameter("@TotalAmt",iuser.TotalAmt), 
                new SqlParameter("@Status",iuser.Status)
               
              
                                  };
           return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Update_CHACharges", _param));

       }
       public static string Insert_CHAChargesTrans(ICHA iuser,decimal Rate,int NoOfItem)
       {          
           SqlParameter[] _param ={
                new SqlParameter("@CHAChargeSno",iuser.CHAChargeSno),
                new SqlParameter("@ChargeId",iuser.ChargeId),
                new SqlParameter("@Remark",iuser.Remark), 
                new SqlParameter("@Amount",iuser.Amount),
                 new SqlParameter("@Rate",Rate),  
                  new SqlParameter("@NoOfItem",NoOfItem),  
                new SqlParameter("@GrnadTotal",iuser.GrandTotal)
            };
           return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CHAChargesTrans", _param));

       }
       public static string Insert_CHAChargesTrans2(ICHA iuser, decimal rate, decimal noitem, int CHAChargeSnoBComp,string CopyToBaseCompany)
       {          
           SqlParameter[] _param ={
                new SqlParameter("@CHAChargeSno",iuser.CHAChargeSno),
                new SqlParameter("@ChargeId",iuser.ChargeId),
                new SqlParameter("@Remark",iuser.Remark), 
                new SqlParameter("@Amount",iuser.Amount),               
                new SqlParameter("@GrnadTotal",iuser.GrandTotal),
                new SqlParameter("@rate",rate),
                new SqlParameter("@NoOfitem",noitem),
                new SqlParameter("@CHAChargeSnoBComp",CHAChargeSnoBComp),
                new SqlParameter("@CopyToBaseCompany",CopyToBaseCompany)
            };
           return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CHAChargesTrans2", _param));

       }
       public static string InsertUpdate_CHAChargesTrans(ICHA iuser)
       {          
           SqlParameter[] _param ={
                new SqlParameter("@CHAChargeSno",iuser.CHAChargeSno),
                new SqlParameter("@ChargeId",iuser.ChargeId),
                new SqlParameter("@Remark",iuser.Remark), 
                new SqlParameter("@Amount",iuser.Amount),                                      new SqlParameter("@GrnadTotal",iuser.GrandTotal)
            };
           return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "InsertUpdate_CHAChargesTrans", _param));

       }
        

       public static string CHAChargesShowByBookRef(ICHA iuser)
       {          
           SqlParameter[] _param ={
                new SqlParameter("@BookRefNo",iuser.BookRefNo)
               
            };
           return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "CHAChargesShowByBookRef", _param));

       }
       public static DataSet SelectChargeTransByChargeId2(ICHA CHA)
       {
           SqlParameter[] spara = {new SqlParameter("@BookRefNo",CHA.BookRefNo),
                                    new SqlParameter("@ChargeId",CHA.ChargeId)
                                  };
           return SqlHelper.ExecuteDataset(ConnectionString, "CHAChargeTrans_SelectByChId2", spara);
       }
       public static DataSet BookingConfirmedShow(ICHA CHA)
       {
           SqlParameter[] spara = {new SqlParameter("@BookRefNo",CHA.BookRefNo)
                                  
                                  };
           return SqlHelper.ExecuteDataset(ConnectionString, "BookingConfirmedShow", spara);
       }
       public static DataSet BookingDetail(ICHA CHA)
       {
           SqlParameter[] sparameter ={
          new SqlParameter("@BookingDate",CHA.BookingDate ),
          new SqlParameter("@CompBrSno",CHA.CompBrSNo )
        };
           return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "chartshow", sparameter);
       }
       public static DataSet Awbdetail(ICHA CHA)
       {
           SqlParameter[] sparameter ={
                                  new SqlParameter ("@AWBDate",CHA .AWBDate ),
                                  new SqlParameter("@CompBrSno",CHA.CompBrSNo )
                                  };
           return SqlHelper.ExecuteDataset(Cfi.App.Pace.Common.PaceCommon.ConnectionString, "mawbandhawbcountNEW", sparameter);
       }
       public static DataSet getChargeAmount(int SNo, int CompBrSNo)
       {

           SqlParameter[] _parameters ={
                                             new SqlParameter("@SNo",SNo),
                                             new SqlParameter("@CompBrSNo",CompBrSNo)
                                   };
           return SqlHelper.ExecuteDataset(ConnectionString, "getChargeAmount", _parameters);
       }
         public static SqlDataReader GetCountryName(String Countrid)
       {
           SqlParameter[] _param ={
                 new SqlParameter("@Countrid", Countrid)
            };
           return SqlHelper.ExecuteReader(ConnectionString, "spgetcounteryname", _param);
       }


         public static DataSet getGSPChargeAmount(int SNo, int CompBrSNo)
         {

             SqlParameter[] _parameters ={
                                             new SqlParameter("@SNo",SNo),
                                             new SqlParameter("@CompBrSNo",CompBrSNo)
                                   };
             return SqlHelper.ExecuteDataset(ConnectionString, "getGSPChargeAmount", _parameters);
         }
    }
}
