

using System;
using System.Collections.Generic;
using System.Text;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;
using System.Data;
using System.Data.SqlClient;

namespace Cfi.App.Pace.Data
{
    public class DataAgentMaster : PaceCommon
    {
        public static String InsertAgent(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@AgentName",Agent.AgentName),
                new SqlParameter("@AgentType",Agent.AgentType),             
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@ApprovalCode",Agent.ApprovalCode),
                new SqlParameter("@IATANo",Agent.IATANo),
                new SqlParameter("@PANNo",Agent.PANNo),               
                new SqlParameter("@City",Agent.City),
                new SqlParameter("@PlanName",Agent.PlanName),
                new SqlParameter("@StandardDiscount",Agent.StandardDiscount),     
                new SqlParameter("@PrintBy",Agent.PrintBy),
                new SqlParameter("@BankGuarantee",Agent.BankGuarantee),
                new SqlParameter("@Mobileno",Agent.MobileNo),
                new SqlParameter("@AutoStock",Agent.AutoStock),
                new SqlParameter("@PaymentMode",Agent.PaymentMode),
                new SqlParameter("@EnteredBY",Agent.EnteredBY),
                new SqlParameter("@CustomerType",Agent.CustomerType),
                new SqlParameter("@BillingCycle",Agent.BillingCycle),
                new SqlParameter("@FlagCustType",Agent.FlagCustType),
                new SqlParameter("@Amount",Agent.Amount),
                new SqlParameter("@Date",Agent.Date),
                new SqlParameter("@BankName",Agent.BankName),
                new SqlParameter("@BankAdd",Agent.BankAdd),
                new SqlParameter("@EnteredByBank",Agent.EnteredByBank),
                new SqlParameter("@Currency",Agent.Currency)
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_AgentMaster1", aparameter));
        }
        public static String InsertCustomer(IAgent Agent, string EnteredBy)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@CityID",Agent.CityCode),
                 new SqlParameter("@FlagCustType",Agent.FlagCustType),
                 new SqlParameter("@CustomerType",Agent.CustomerType),
                 new SqlParameter("@CustomerName",Agent.CustomerName),                
                 new SqlParameter("@Address",Agent.Address),
                 new SqlParameter("@NetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@StarRating",Agent.StarRating),
                 new SqlParameter("@PinCode",Agent.PinCode),                
                 new SqlParameter("@CustomerCity",Agent.City),
                 new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@CustomerWebsite",Agent.Website),               
                 new SqlParameter("@CustomerPhoneNo",Agent.Phone),
                 new SqlParameter("@CustomerFax",Agent.Fax),
                 new SqlParameter("@CustomerMobileNo",Agent.MobileNo),
                 new SqlParameter("@CustomerEmail",Agent.Email),
                 new SqlParameter("@AgentType",Agent.AgentType),
                 new SqlParameter("@IataNo",Agent.IATANo),
                 new SqlParameter("@PanNo",Agent.PANNo),               
                 new SqlParameter("@PaymentMode",Agent.PaymentMode),
                 new SqlParameter("@BillingCycle",Agent.BillingCycle),
                 new SqlParameter("@Currency",Agent.Currency),         
               
                 new SqlParameter("@StandardDeal",Agent.StandardDeal),
                 new SqlParameter("@EnteredBy",Agent.EnteredBY),
                 new SqlParameter("@EnteredDate",Agent.EnteredDate),
                 new SqlParameter("@AdCode",Agent.Adcode),
                 new SqlParameter("@IECNo",Agent.IECNo),
                 new SqlParameter("@BankName",Agent.BankName),
                 new SqlParameter("@BankAccNo",Agent.BankAccNo),
                 new SqlParameter("@BankAddress",Agent.BankAdd),
                 new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@Password",Agent.Password),
                 new SqlParameter("@Flagmainbranch",Agent.Flagmainbranch),
                 new  SqlParameter ("@Street",Agent.StreetName),
                 new  SqlParameter ("@Place",Agent.Place),
                 new  SqlParameter ("@State",Agent.State),
                 new  SqlParameter ("@CountryCode",Agent.CountryCode),
                 new  SqlParameter ("@CompSno",Agent.CompSno),
                 new  SqlParameter ("@CompBrSno",Agent.CompBrSno),
                 new  SqlParameter ("@loginFlag",Agent.loginFlag),
                new  SqlParameter ("@NetWorkAgentCitySno",Agent.NetworkAgentCitySno), 
                new  SqlParameter ("@loginSno",Agent.loginSno), 
                 new  SqlParameter ("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new  SqlParameter ("@ServiceTaxNo",Agent.ServiceTaxNo),
                 new  SqlParameter ("@TanNo",Agent.TanNo),
                 new  SqlParameter ("@TinNo",Agent.TinNo),
                 new  SqlParameter ("@GroupCustomer",Agent.GroupCustomer),
                 new  SqlParameter ("@EnteredBy",EnteredBy),
                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CustomerFinal", aparameter));
        }
        public static String Insert_Customer(IAgent Agent,bool isOscCal)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@CityID",Agent.CityCode),
                 new SqlParameter("@FlagCustType",Agent.FlagCustType),
                 new SqlParameter("@CustomerType",Agent.CustomerType),
                 new SqlParameter("@CustomerName",Agent.CustomerName),                
                 new SqlParameter("@Address",Agent.Address),
                 new SqlParameter("@NetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@StarRating",Agent.StarRating),
                 new SqlParameter("@PinCode",Agent.PinCode),                
                 new SqlParameter("@CustomerCity",Agent.City),
                 new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@CustomerWebsite",Agent.Website),               
                 new SqlParameter("@CustomerPhoneNo",Agent.Phone),
                 new SqlParameter("@CustomerFax",Agent.Fax),
                 new SqlParameter("@CustomerMobileNo",Agent.MobileNo),
                 new SqlParameter("@CustomerEmail",Agent.Email),
                 new SqlParameter("@AgentType",Agent.AgentType),
                 new SqlParameter("@IataNo",Agent.IATANo),
                 new SqlParameter("@PanNo",Agent.PANNo),               
                 new SqlParameter("@PaymentMode",Agent.PaymentMode),
                 new SqlParameter("@BillingCycle",Agent.BillingCycle),
                 new SqlParameter("@Currency",Agent.Currency),         
               
                 new SqlParameter("@StandardDeal",Agent.StandardDeal),
                 new SqlParameter("@EnteredBy",Agent.EnteredBY),
                 new SqlParameter("@EnteredDate",Agent.EnteredDate),
                 new SqlParameter("@AdCode",Agent.Adcode),
                 new SqlParameter("@IECNo",Agent.IECNo),
                 new SqlParameter("@BankName",Agent.BankName),
                 new SqlParameter("@BankAccNo",Agent.BankAccNo),
                 new SqlParameter("@BankAddress",Agent.BankAdd),
                 new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@Password",Agent.Password),
                 new SqlParameter("@Flagmainbranch",Agent.Flagmainbranch),
                 new  SqlParameter ("@Street",Agent.StreetName),
                 new  SqlParameter ("@Place",Agent.Place),
                 new  SqlParameter ("@State",Agent.State),
                 new  SqlParameter ("@CountryCode",Agent.CountryCode),
                 new  SqlParameter ("@CompSno",Agent.CompSno),
                 new  SqlParameter ("@CompBrSno",Agent.CompBrSno),
                 new  SqlParameter ("@loginFlag",Agent.loginFlag),
                new  SqlParameter ("@NetWorkAgentCitySno",Agent.NetworkAgentCitySno), 
                new  SqlParameter ("@loginSno",Agent.loginSno), 
                 new  SqlParameter ("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new  SqlParameter ("@ServiceTaxNo",Agent.ServiceTaxNo),
                 new  SqlParameter ("@TanNo",Agent.TanNo),
                 new  SqlParameter ("@TinNo",Agent.TinNo),
                 new  SqlParameter ("@GroupCustomer",Agent.GroupCustomer),
                 new SqlParameter("@Bill",Agent.bill),
                   new  SqlParameter ("@IsOscCalCulated",isOscCal)
                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "InsertCustomer", aparameter));
        }
        public static String insertCustomerNew(IAgent Agent, string entryType, int custMastSno, int CustomerBusinessTypeSno, int SalesPersonSno, bool isOscCal, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@EntryType",entryType),
                 new SqlParameter("@CustMastSno",custMastSno),
                 new SqlParameter("@CustBrSno",Agent.CustomerSNo),
                 new SqlParameter("@CustomerType",Agent.CustomerType),
                 new SqlParameter("@GroupCustomer",Agent.GroupCustomer),
                 new SqlParameter("@IataNo",Agent.IATANo),
                 new SqlParameter("@Active",Agent.Active),
                 new SqlParameter("@SalesPersonSno",SalesPersonSno),
                 new SqlParameter("@Bill",Agent.bill),
                 new SqlParameter("@NetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@StarRating",Agent.StarRating),
                 new SqlParameter("@CustomerBusinessTypeSno",CustomerBusinessTypeSno),
                 new SqlParameter("@IsOscCalCulated",isOscCal),
                 new SqlParameter("@CustomerName",Agent.CustomerName), 
                 new SqlParameter("@Street",Agent.StreetName),
                 new SqlParameter("@City",Agent.City),
                 new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@NetWorkAgentCitySno",Agent.NetworkAgentCitySno),
                 new SqlParameter("@State",Agent.State),
                 new SqlParameter("@PinCode",Agent.PinCode),  
                 new SqlParameter("@CountryCode",Agent.CountryCode),
                 new SqlParameter("@PhoneNo",Agent.Phone),
                 new SqlParameter("@Fax",Agent.Fax),
                 new SqlParameter("@Mobile",Agent.MobileNo),
                 new SqlParameter("@Email",Agent.Email),
                 new SqlParameter("@Website",Agent.Website),
                 new SqlParameter("@AdCode",Agent.Adcode),
                 new SqlParameter("@IECNo",Agent.IECNo),
                 new SqlParameter("@BankName",Agent.BankName),
                 new SqlParameter("@BankAccNo",Agent.BankAccNo),
                 new SqlParameter("@BankAddress",Agent.BankAdd),
                 new SqlParameter("@PanNo",Agent.PANNo),  
                 new SqlParameter("@ServiceTaxNo",Agent.ServiceTaxNo),
                 new SqlParameter("@TanNo",Agent.TanNo),
                 new SqlParameter("@TinNo",Agent.TinNo),
                 new SqlParameter("@PaymentMode",Agent.PaymentMode),
                 new SqlParameter("@Currency",Agent.Currency),         
                 new SqlParameter("@StandardDeal",Agent.StandardDeal),
                 new SqlParameter("@BillingCycle",Agent.BillingCycle),
                 new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new SqlParameter("@loginFlag",Agent.loginFlag),
                 new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@Password",Agent.Password),
                 new SqlParameter("@CompBrSno",Agent.CompBrSno),
                 new SqlParameter("@EnteredBy",Agent.EnteredBY)  
              };

            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "insertCustomerNew", aparameter));
        }
        public static String updateCustomer(IAgent Agent, string entryType, int custMastSno, int CustomerBusinessTypeSno, int SalesPersonSno, bool isOscCal, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@EntryType",entryType),
                 new SqlParameter("@CustMastSno",custMastSno),
                 new SqlParameter("@CustBrSno",Agent.CustomerSNo),
                 new SqlParameter("@CustomerType",Agent.CustomerType),
                 new SqlParameter("@GroupCustomer",Agent.GroupCustomer),
                 new SqlParameter("@IataNo",Agent.IATANo),
                 new SqlParameter("@Active",Agent.Active),
                 new SqlParameter("@SalesPersonSno",SalesPersonSno),
                 new SqlParameter("@Bill",Agent.bill),
                 new SqlParameter("@NetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@StarRating",Agent.StarRating),
                 new SqlParameter("@CustomerBusinessTypeSno",CustomerBusinessTypeSno),
                 new SqlParameter("@IsOscCalCulated",isOscCal),
                 new SqlParameter("@Street",Agent.StreetName),
                 new SqlParameter("@City",Agent.City),
                 new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@NetWorkAgentCitySno",Agent.NetworkAgentCitySno),
                 new SqlParameter("@State",Agent.State),
                 new SqlParameter("@PinCode",Agent.PinCode),  
                 new SqlParameter("@CountryCode",Agent.CountryCode),
                 new SqlParameter("@PhoneNo",Agent.Phone),
                 new SqlParameter("@Fax",Agent.Fax),
                 new SqlParameter("@Mobile",Agent.MobileNo),
                 new SqlParameter("@Email",Agent.Email),
                 new SqlParameter("@Website",Agent.Website),
                 new SqlParameter("@AdCode",Agent.Adcode),
                 new SqlParameter("@IECNo",Agent.IECNo),
                 new SqlParameter("@BankName",Agent.BankName),
                 new SqlParameter("@BankAccNo",Agent.BankAccNo),
                 new SqlParameter("@BankAddress",Agent.BankAdd),
                 new SqlParameter("@PanNo",Agent.PANNo),  
                 new SqlParameter("@ServiceTaxNo",Agent.ServiceTaxNo),
                 new SqlParameter("@TanNo",Agent.TanNo),
                 new SqlParameter("@TinNo",Agent.TinNo),
                 new SqlParameter("@PaymentMode",Agent.PaymentMode),
                 new SqlParameter("@Currency",Agent.Currency),         
                 new SqlParameter("@StandardDeal",Agent.StandardDeal),
                 new SqlParameter("@BillingCycle",Agent.BillingCycle),
                 new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new SqlParameter("@loginFlag",Agent.loginFlag),
                 new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@Password",Agent.Password),
                 new SqlParameter("@CompBrSno",Agent.CompBrSno),
                 new SqlParameter("@UpdatedBy",Agent.ModifiedBy)  
              };

            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "updateCustomer", aparameter));
        }
        public static String InsertCustomerCreditReview(IAgent Agent,SqlTransaction tr)
        {
            SqlParameter[] aparameter ={                  
                  new SqlParameter("@PanNo",Agent.PANNo),
                  new SqlParameter("@LoginID",Agent.LoginId),
                  new SqlParameter("@CustomerName",Agent.CustomerName),
                  new SqlParameter("@ApplicantName",Agent.ApplicantName),
                  new SqlParameter("@LegalStatus",Agent.LegalStatus),               
                  new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),                
                  new SqlParameter("@SalesPersonName",Agent.SalesPersonName),                
                  new SqlParameter("@IndustryType",Agent.IndustryType),
                  new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                  new SqlParameter("@PartnerName1",Agent.PartnerName1),               
                new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),
                new SqlParameter("@PartnerName2",Agent.PartnerName2),
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),               
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee), 
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),
                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4 ),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5 ),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),
                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt6),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),
                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Status",Agent.Status),
                new SqlParameter("@RequestedDate",Agent.EnteredDate),
                new SqlParameter("@CustomerBranchSno",Agent.SNo),
                new SqlParameter("@RequestedBy",Agent.RequestedBy),
                new SqlParameter("@CustomerRemarks",Agent.CustomerRemarks),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@CompBrSno",Agent.CompBrSno)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "InserCreditReview", aparameter));
        }
        public static String InsertCustomercontacts(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@LoginID",Agent.LoginId),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Name",Agent.ContactName),
                 new SqlParameter("@Designation",Agent.ContactDesign),              
                 new SqlParameter("@Telephone",Agent.ContactPhone),                
                 new SqlParameter("@FAx",Agent.Fax),                
                 new SqlParameter("@Emal",Agent.Email),
                 new SqlParameter("@Depart",Agent.ContactDept),
                 new SqlParameter("@CustomerBranchSno",Agent.SNo),

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updatecustomercontact", aparameter));
        }
        public static String InsertCustomercontactsApprove(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@CustomerBranchSno",Agent.CustomerSNo),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Name",Agent.ContactName),
                 new SqlParameter("@Designation",Agent.ContactDesign),               
                 new SqlParameter("@Telephone",Agent.ContactPhone),
                 new SqlParameter("@FAx",Agent.Fax),                
                 new SqlParameter("@Emal",Agent.Email),
                 new SqlParameter("@Depart",Agent.ContactDept) 

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "updatecustomercontactApprove", aparameter));
        }

        public static String InsertCustomerCreditLimit(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@Address",Agent.Address),
                new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@ApplicantName",Agent.ApplicantName),
                new SqlParameter("@LegalStatus",Agent.LegalStatus),
                new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                new SqlParameter("@IndustryType",Agent.IndustryType),
                new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                 new SqlParameter("@PartnerName1",Agent.PartnerName1),
                 new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                 new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),

                new SqlParameter("@PartnerName2",Agent.PartnerName2),
                
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                 new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),

                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@ApproveBy",Agent.ApprovedBy),
                new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@AccountsRemarks",Agent.AccountsRemarks),
                new SqlParameter("@CustomerSNo",Agent.CustomerSNo),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@ApprovalType",Agent.ApprovalType)
                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "Insert_CreditReviewNew", aparameter));
        }
        public static String Update_CondCreditReview(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@Address",Agent.Address),
                new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@ApplicantName",Agent.ApplicantName),
                new SqlParameter("@LegalStatus",Agent.LegalStatus),
                new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                new SqlParameter("@IndustryType",Agent.IndustryType),
                new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                new SqlParameter("@PartnerName1",Agent.PartnerName1),
                new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),
                new SqlParameter("@PartnerName2",Agent.PartnerName2),                
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                 new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),

                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@ApproveBy",Agent.ApprovedBy),
                new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@AccountsRemarks",Agent.AccountsRemarks),
                new SqlParameter("@CustomerSNo",Agent.CustomerSNo),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@ApprovalType",Agent.ApprovalType)
                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "Update_CondCreditReview", aparameter));
        }
        public static String UpdateSales_CreditReview(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Address",Agent.Address),
                 new SqlParameter("@PanNo",Agent.PANNo),
                 new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                 new SqlParameter("@ApplicantName",Agent.ApplicantName),
                 new SqlParameter("@LegalStatus",Agent.LegalStatus),
                 new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                 new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                 new SqlParameter("@IndustryType",Agent.IndustryType),
                 new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                 new SqlParameter("@PartnerName1",Agent.PartnerName1),
                 new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                 new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),

                 new SqlParameter("@PartnerName2",Agent.PartnerName2),
                
                 new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                 new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                 new SqlParameter("@PartnerName3",Agent.PartnerName3),
                 new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                 new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                 new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                 new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                 new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                 new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                 new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                 new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                 new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                 new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),
                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@ApproveBy",Agent.ApprovedBy),
                new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@SalesRemarks",Agent.AccountsRemarks),
                new SqlParameter("@CustomerSNo",Agent.CustomerSNo),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "UpdateSales_CreditReview", aparameter));
        }
        public static String Update_CreditReview(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@Address",Agent.Address),
                new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@ApplicantName",Agent.ApplicantName),
                new SqlParameter("@LegalStatus",Agent.LegalStatus),
                new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                new SqlParameter("@IndustryType",Agent.IndustryType),
                new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                 new SqlParameter("@PartnerName1",Agent.PartnerName1),
                 new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                 new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),

                new SqlParameter("@PartnerName2",Agent.PartnerName2),
                
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                 new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),
                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@ApproveBy",Agent.ApprovedBy),
                new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@AccountsRemarks",Agent.AccountsRemarks),
                new SqlParameter("@CustomerSNo",Agent.CustomerSNo),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Update_CreditReview", aparameter));
        }
        public static String InsertCustomerCreditLimitbyAccDirect(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@BGclaimPeriod",Agent.BGClaimPeriod),
                 new SqlParameter("@Address",Agent.Address),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@ApplicantName",Agent.ApplicantName),
                new SqlParameter("@LegalStatus",Agent.LegalStatus),
                new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                new SqlParameter("@IndustryType",Agent.IndustryType),
                new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                 new SqlParameter("@PartnerName1",Agent.PartnerName1),
                 new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                 new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),

                new SqlParameter("@PartnerName2",Agent.PartnerName2),
                
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseFacility3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                 new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                 new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                 new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                 new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                 new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),

                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                 new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),

                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),

                //new SqlParameter("@StreetName",Agent.StreetName),
                //new SqlParameter("@Town",Agent.Town),
                //new SqlParameter("@State",Agent.State),
                 //new SqlParameter("@CLApprovedBy",Agent.CLApprovedBy),
                 //new SqlParameter("@NetworkGroupSno",Agent.NetworkGroupSno),
                // new SqlParameter("@StarRating",Agent.StarRating),

                //new SqlParameter("@CLApprovedAt",Agent.CLApprovedAt),
                
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
            new SqlParameter("@BankAddress",Agent.BankAddress),
            new SqlParameter("@ApproveBy",Agent.ApprovedBy),
              new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                 new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@AccountsRemarks",Agent.AccountsRemarks),
             
           

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CreditReviewNewbyAcc", aparameter));
        }
        public static String UpdateCreditReviewNew(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Address",Agent.Address),
                 new SqlParameter("@PanNo",Agent.PANNo),
                  new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@ApplicantName",Agent.ApplicantName),
                new SqlParameter("@LegalStatus",Agent.LegalStatus),
                new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                new SqlParameter("@IndustryType",Agent.IndustryType),
                new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                 new SqlParameter("@PartnerName1",Agent.PartnerName1),
                 new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                 new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),

                new SqlParameter("@PartnerName2",Agent.PartnerName2),
                
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseFacility3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                 new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                 new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                 new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                 new SqlParameter("@OthForwarder3",Agent.OthForwarder3),
                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),
                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@ModyfiedBy",Agent.ModifiedBy),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate),
                new SqlParameter("@BankName",Agent.BankName),                
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@ModifiedDate",Agent.ModifiedDate)  
           

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updatecreditreviewnew", aparameter));
        }
        public static String UpdateCust(IAgent Agent,bool oscCal)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CityID",Agent.CityCode),
                new SqlParameter("@FlagCustType",Agent.FlagCustType),
                new SqlParameter("@CustomerType",Agent.CustomerType),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@Address",Agent.Address),                
                new SqlParameter("@PinCode",Agent.PinCode),
                new SqlParameter("@CustomerCity",Agent.City),
                new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                new SqlParameter("@CustomerWebsite",Agent.Website),               
                new SqlParameter("@CustomerPhoneNo",Agent.Phone),
                new SqlParameter("@CustomerFax",Agent.Fax),
                new SqlParameter("@CustomerMobileNo",Agent.MobileNo),
                new SqlParameter("@CustomerEmail",Agent.Email),
                new SqlParameter("@AgentType",Agent.AgentType),
                new SqlParameter("@IataNo",Agent.IATANo),
                new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@BankGurantee",Agent.BankGuarantee),
                new SqlParameter("@PaymentMode",Agent.PaymentMode),
                new SqlParameter("@BillingCycle",Agent.BillingCycle),
                new SqlParameter("@Currency",Agent.Currency),                
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditReview",Agent.CreditReviewDate),
                new SqlParameter("@StandardDeal",Agent.StandardDeal),
                new SqlParameter("@EnteredBy",Agent.EnteredBY),
                new SqlParameter("@EnteredDate",Agent.EnteredDate),
                new SqlParameter("@AdCode",Agent.Adcode),
                new SqlParameter("@IECNo",Agent.IECNo),
                new SqlParameter("@BankName",Agent.BankName),
                new SqlParameter("@BankAccNo",Agent.BankAccNo),
                new SqlParameter("@BankAddress",Agent.BankAdd),
                new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                new SqlParameter("@Password",Agent.Password),
                new SqlParameter("@CustSNo",Agent.CustomerSNo),
                new SqlParameter("@Active",Agent.Active),
                new SqlParameter("@Street",Agent.StreetName),
                new SqlParameter("@Place",Agent.Place),
                new SqlParameter("@State",Agent.State),
                new SqlParameter("@CountryCode",Agent.CountryCode),
                new SqlParameter("@loginFlag",Agent.loginFlag),
                new SqlParameter("@CompSno",Agent.CompSno) ,
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@NetworkAgentCitySno",Agent.NetworkAgentCitySno),
                new  SqlParameter ("@ServiceTaxNo",Agent.ServiceTaxNo),
                new  SqlParameter ("@TanNo",Agent.TanNo),
                new  SqlParameter ("@TinNo",Agent.TinNo),
                new  SqlParameter ("@IsOscCalCulated",oscCal)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Update_Customer", aparameter));
        }
        public static String UpdateCustNew(IAgent Agent, bool oscCal)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CityID",Agent.CityCode),
                new SqlParameter("@FlagCustType",Agent.FlagCustType),
                new SqlParameter("@CustomerType",Agent.CustomerType),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@Address",Agent.Address),                
                new SqlParameter("@PinCode",Agent.PinCode),
                new SqlParameter("@CustomerCity",Agent.City),
                new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                new SqlParameter("@CustomerWebsite",Agent.Website),               
                new SqlParameter("@CustomerPhoneNo",Agent.Phone),
                new SqlParameter("@CustomerFax",Agent.Fax),
                new SqlParameter("@CustomerMobileNo",Agent.MobileNo),
                new SqlParameter("@CustomerEmail",Agent.Email),
                new SqlParameter("@AgentType",Agent.AgentType),
                new SqlParameter("@IataNo",Agent.IATANo),
                new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@BankGurantee",Agent.BankGuarantee),
                new SqlParameter("@PaymentMode",Agent.PaymentMode),
                new SqlParameter("@BillingCycle",Agent.BillingCycle),
                new SqlParameter("@Currency",Agent.Currency),                
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditReview",Agent.CreditReviewDate),
                new SqlParameter("@StandardDeal",Agent.StandardDeal),
                new SqlParameter("@EnteredBy",Agent.EnteredBY),
                new SqlParameter("@EnteredDate",Agent.EnteredDate),
                new SqlParameter("@AdCode",Agent.Adcode),
                new SqlParameter("@IECNo",Agent.IECNo),
                new SqlParameter("@BankName",Agent.BankName),
                new SqlParameter("@BankAccNo",Agent.BankAccNo),
                new SqlParameter("@BankAddress",Agent.BankAdd),
                new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                new SqlParameter("@Password",Agent.Password),
                new SqlParameter("@CustSNo",Agent.CustomerSNo),
                new SqlParameter("@Active",Agent.Active),
                new SqlParameter("@Street",Agent.StreetName),
                new SqlParameter("@Place",Agent.Place),
                new SqlParameter("@State",Agent.State),
                new SqlParameter("@CountryCode",Agent.CountryCode),
                new SqlParameter("@loginFlag",Agent.loginFlag),
                new SqlParameter("@CompSno",Agent.CompSno) ,
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@NetworkAgentCitySno",Agent.NetworkAgentCitySno),
                new  SqlParameter ("@ServiceTaxNo",Agent.ServiceTaxNo),
                new  SqlParameter ("@TanNo",Agent.TanNo),
                new  SqlParameter ("@TinNo",Agent.TinNo),
                 new  SqlParameter ("@GroupCustomer",Agent.GroupCustomer),
                   new SqlParameter("@bill",Agent.bill),
                new  SqlParameter ("@IsOscCalCulated",oscCal)
              

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Update_CustomerNew", aparameter));
        }
        public static String UpdateCustMaster(IAgent Agent)
        {
            SqlParameter[] aparameter ={

                new SqlParameter("@NetworkGroupSNo",Agent.NetworkGroupSno),
                new SqlParameter("@StarRating",Agent.StarRating),
                new SqlParameter("@CustomerType",Agent.CustomerType),
                new SqlParameter("@CustomerName",Agent.CustomerName),              
                new SqlParameter("@IataNo",Agent.IATANo), 
                new SqlParameter("@Sno",Agent.SNo)
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateCustomerMaster", aparameter));
        }
        public static String InsertContacts(IAgent Agent, string DOB, string DOA)
        {
            SqlParameter[] aparameter ={
             
                new SqlParameter("@ContactName",Agent.ContactName),
                new SqlParameter("@ContactDesignation",Agent.ContactDesign),
                new SqlParameter("@ContactDept",Agent.ContactDept),
                new SqlParameter("@ContactAddress",Agent.ContactAdd),
                new SqlParameter("@ContactPhone",Agent.ContactPhone),
                new SqlParameter("@ContactMobile",Agent.ContactMobile),
                new SqlParameter("@ContactEmail",Agent.Email),
                new SqlParameter("@ContactDob",DOB),
                new SqlParameter("@ContactDoa",DOA),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@CompBrSno",Agent.CompBrSno),
                new SqlParameter("@CustSno",Agent.CustomerSNo)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "customercontact", aparameter));
        }
        public static String insertCustomerTDS(int CustBrSno, decimal TDSRate, decimal ECess, DateTime TDSReceivedOn, DateTime TDSValidFrom, DateTime TDSValidTo, string TDSStatus, string EnteredBy)
        {
            SqlParameter[] aparameter ={
          
                new SqlParameter("@CustBrSno",CustBrSno),
                new SqlParameter("@TDSRate",TDSRate),
                new SqlParameter("@ECess",ECess),
                new SqlParameter("@TDSReceivedOn",TDSReceivedOn),
                new SqlParameter("@TDSValidFrom",TDSValidFrom),
                new SqlParameter("@TDSValidTo",TDSValidTo),
                new SqlParameter("@TDSStatus",TDSStatus),
                new SqlParameter("@EnteredBy",EnteredBy),

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "insertCustomerTDS", aparameter));
        }
        public static String updateCustomerTDS(int CustomerTDSSno, int CustBrSno, decimal TDSRate, decimal ECess, DateTime TDSReceivedOn, DateTime TDSValidFrom, DateTime TDSValidTo, string TDSStatus)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CustomerTDSSno",CustomerTDSSno),
                new SqlParameter("@CustBrSno",CustBrSno),
                new SqlParameter("@TDSRate",TDSRate),
                new SqlParameter("@ECess",ECess),
                new SqlParameter("@TDSReceivedOn",TDSReceivedOn),
                new SqlParameter("@TDSValidFrom",TDSValidFrom),
                new SqlParameter("@TDSValidTo",TDSValidTo),
                new SqlParameter("@TDSStatus",TDSStatus),
               

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateCustomerTDS", aparameter));
        }
        public static String DelContact(IAgent Agent)
        {
            SqlParameter[] aparameter ={      
             
                new SqlParameter("@CustSNo",Agent.CustomerSNo )

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "deletecontact", aparameter));
        }
        public static String Deletecustomer(IAgent Agent)
        {
            SqlParameter[] aparameter ={

                
             
                new SqlParameter("@CustSNo",Agent.CustomerSNo )
               
              

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "deletecustomer", aparameter));
        }
        public static String RequestExits(String Login)
        {
            SqlParameter[] aparameter ={             
                new SqlParameter("@LoginID",Login)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "ExitsRequest", aparameter));
        }
        public static SqlDataReader fetchrecordscreditlimit(int snoo)
        {
            SqlParameter[] aparameter ={

                
             
                new SqlParameter("@Sno",snoo )
               
              

              };
            return SqlHelper.ExecuteReader(ConnectionString, "fechrecordscreditlimit", aparameter);
        }
        public static String DisapproveCrLm(int sno, string remarks, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={             
                new SqlParameter("@Sno",sno),
                new SqlParameter("@AccountsRemarks",remarks)
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "disapprove", aparameter));
        }
        public static String DisapproveCrLimitBySales(IAgent IA, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={             
                new SqlParameter("@Sno",IA.SNo),
                new SqlParameter("@SalesRemarks",IA.SalesRemarks),
                new SqlParameter("@ModifiedBy",IA.ModifiedBy)                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "disapproveCrLimitBySM", aparameter));
        }
        public static String InsertCreditReview(IAgent Agent)
        {
            SqlParameter[] aparameter ={                
             
                new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@BalSheet2Years1",Agent.BalSheet2Years1),
                new SqlParameter("@BalSheet2YearsDesc",Agent.BalSheet2YearsDesc),
                new SqlParameter("@BankConfirmLetter",Agent.BankConfirmLetter),
                new SqlParameter("@BankConfirmLetterDesc",Agent.BankConfirmLetterDesc),
                new SqlParameter("@MarketReport",Agent.MarketReport),
                new SqlParameter("@MarketReportDesc",Agent.MarketReportDesc),
                new SqlParameter("@MRApprovedByName",Agent.MRApprovedByName),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@CLApprovedBy",Agent.CLApprovedBy),
                new SqlParameter("@CLApprovedAt",Agent.CLApprovedAt),
                new SqlParameter("@RateOfInterest",Agent.RateOfInterest),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate),
                new SqlParameter("@BGClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@BankName",Agent.BankName),
                new SqlParameter("@BankAddress",Agent.BankAdd),
                new SqlParameter("@EnteredBy",Agent.EnteredBY),
                new SqlParameter("@EnteredAt",Agent.EnteredAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CreditReview", aparameter));
        }
        public static String UpdateCreditReview(IAgent Agent)
        {
            SqlParameter[] aparameter ={

                
             
                new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@BalSheet2Years1",Agent.BalSheet2Years1),
                new SqlParameter("@BalSheet2YearsDesc",Agent.BalSheet2YearsDesc),
                new SqlParameter("@BankConfirmLetter",Agent.BankConfirmLetter),
                new SqlParameter("@BankConfirmLetterDesc",Agent.BankConfirmLetterDesc),
                new SqlParameter("@MarketReport",Agent.MarketReport),
                new SqlParameter("@MarketReportDesc",Agent.MarketReportDesc),
                new SqlParameter("@MRApprovedByName",Agent.MRApprovedByName),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                
                new SqlParameter("@RateOfInterest",Agent.RateOfInterest),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate),
                new SqlParameter("@BGClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@BankName",Agent.BankName),
                new SqlParameter("@BankAddress",Agent.BankAdd),
                new SqlParameter("@ModifiedBy",Agent.ModifiedBy),
                new SqlParameter("@ModifiedDate",Agent.ModifiedDate),
              

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updatecreditreview", aparameter));
        }

        public static String InsertCustomerRegister(IAgent Agent)
        {
            SqlParameter[] aparameter ={             
                new SqlParameter("@CustomerType",Agent.CustomerType),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@CustomerStreetname",Agent.StreetName),
                new SqlParameter("@CustomerTown",Agent.Town),
                new SqlParameter("@CustomerState",Agent.State),
                new SqlParameter("@CustomerPincode",Agent.PinCode),
                new SqlParameter("@CustomerCity",Agent.City),
                new SqlParameter("@CustomerFax",Agent.Fax),
                new SqlParameter("@CustomerMobileNo",Agent.MobileNo),
                new SqlParameter("@CustomerEmail",Agent.Email),
                new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                new SqlParameter("@Password",Agent.Password),               
                new SqlParameter("@CustomerWebsite",Agent.Website),
                new SqlParameter("@CustomerPhone",Agent.Phone),
                new SqlParameter("@CustomerADCode",Agent.Adcode),
                new SqlParameter("@CustomerIECNo",Agent.IECNo),
                new SqlParameter("@CustomerBankName",Agent.BankName),
                new SqlParameter("@CustomerBankAccNo",Agent.BankAccNo),
                new SqlParameter("@CustomerBankAdress",Agent.BankAdd),
                new SqlParameter("@CustomerPanNo",Agent.PANNo),
                new SqlParameter("@Currency",Agent.Currency),
                new SqlParameter("@EnteredDate",Agent.EnteredDate),
                 new SqlParameter("@Place",Agent.Place), 
                  new SqlParameter("@CountryCode",Agent.CountryCode), 
                   new SqlParameter("@IATANO",Agent.IATANo),
                        new SqlParameter("@CompSno",Agent.CompSno)
                
         };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CustomerRegisterFinal", aparameter));
        }

        public static String InsertCustomerRegister2(IAgent Agent)
        {
            SqlParameter[] aparameter ={             
                new SqlParameter("@CustomerType",Agent.CustomerType),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@CustomerStreetname",Agent.StreetName),
                new SqlParameter("@CustomerTown",Agent.Town),
                new SqlParameter("@CustomerState",Agent.State),
                new SqlParameter("@CustomerPincode",Agent.PinCode),
                new SqlParameter("@CustomerCity",Agent.City),
                new SqlParameter("@CustomerFax",Agent.Fax),
                new SqlParameter("@CustomerMobileNo",Agent.MobileNo),
                new SqlParameter("@CustomerEmail",Agent.Email),
                new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                new SqlParameter("@Password",Agent.Password),               
                new SqlParameter("@CustomerWebsite",Agent.Website),
                new SqlParameter("@CustomerPhone",Agent.Phone),
                new SqlParameter("@CustomerADCode",Agent.Adcode),
                new SqlParameter("@CustomerIECNo",Agent.IECNo),
                new SqlParameter("@CustomerBankName",Agent.BankName),
                new SqlParameter("@CustomerBankAccNo",Agent.BankAccNo),
                new SqlParameter("@CustomerBankAdress",Agent.BankAdd),
                new SqlParameter("@CustomerPanNo",Agent.PANNo),
                new SqlParameter("@Currency",Agent.Currency),
                new SqlParameter("@EnteredDate",Agent.EnteredDate),
                 new SqlParameter("@Place",Agent.Place), 
                  new SqlParameter("@CountryCode",Agent.CountryCode), 
                   new SqlParameter("@IATANO",Agent.IATANo),
                        new SqlParameter("@CompSno",Agent.CompSno)
                
         };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CustomerRegisterFinal2", aparameter));
        }

        public static String Exists(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CustomerLogin",Agent.CustomerLoginId)
               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "alreadyagent", aparameter));
        }
        public static String ExistsCustomer(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@CompBrSno",Agent.CompBrSno)
               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "alreadCustomer", aparameter));
        }
        public static String alreadCustomerCheck(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CustomerName",Agent.CustomerName),
                   new SqlParameter("@CompBrsno",Agent.CompBrSno)
               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "alreadCustomerCheck", aparameter));
        }
        //public static String returnCustomer(string Agentlogin)
        //{
        //    SqlParameter[] aparameter ={
        //        new SqlParameter("@LoginID",Agentlogin)

        //    };
        //    return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "returncustomername", aparameter));
        //}
        public static String ExistLoginId(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@LoginId",Agent.CustomerLoginId)
               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "alreadloginid", aparameter));
        }

        public static String UpdatetAgent(IAgent Agent)
        {
            SqlParameter[] uParameter ={
                new SqlParameter("@sno",Agent.SNo),
                new SqlParameter("@AgentName",Agent.AgentName),
                new SqlParameter("@AgentType",Agent.AgentType),
                new SqlParameter("@ApprovalCode",Agent.ApprovalCode),
                new SqlParameter("@IATANo",Agent.IATANo),
                new SqlParameter("@PANNo",Agent.PANNo),
             
                new SqlParameter("@PlanName",Agent.PlanName),
                new SqlParameter("@StandardDiscount",Agent.StandardDiscount),
               
                new SqlParameter("@PrintBy",Agent.PrintBy),
                new SqlParameter("@BankGuarantee",Agent.BankGuarantee),
                new SqlParameter("@Mobileno",Agent.MobileNo),
                new SqlParameter("@autostock",Agent.AutoStock),
                new SqlParameter("@PaymentMode",Agent.PaymentMode),
                new SqlParameter("@EnteredBY",Agent.EnteredBY),
                 new SqlParameter("@CustomerType",Agent.CustomerType),
                new SqlParameter("@BillingCycle",Agent.BillingCycle),
                new SqlParameter("@FlagCustType",Agent.FlagCustType),
                new SqlParameter("@Amount",Agent.Amount),
                new SqlParameter("@Date",Agent.Date),
                new SqlParameter("@BankName",Agent.BankName),
                new SqlParameter("@BankAdd",Agent.BankAdd),
                new SqlParameter("@EnteredByBank",Agent.EnteredByBank),
                new SqlParameter("@Currency",Agent.Currency)
               
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Update_AgentMaster", uParameter));
        }

        public static SqlDataReader SearchAgent(Int32 strA)
        {
            SqlParameter[] _aParam = { new SqlParameter("@sno", strA) };
            return SqlHelper.ExecuteReader(ConnectionString, "Search_AgentMaster", _aParam);
        }
        public static SqlDataReader CreditReviewData(Int32 strA)
        {
            SqlParameter[] _aParam = { new SqlParameter("@sno", strA) };
            return SqlHelper.ExecuteReader(ConnectionString, "AllCreditReviewData", _aParam);
        }
        public static SqlDataReader allpendingstock(string city)
        {
            SqlParameter[] _aParam = { new SqlParameter("@City", city) };
            return SqlHelper.ExecuteReader(ConnectionString, "pendingstock", _aParam);
        }
        public static SqlDataReader SearchAgentmain(Int32 strA)
        {
            SqlParameter[] _aParam = { new SqlParameter("@sno", strA) };
            return SqlHelper.ExecuteReader(ConnectionString, "Search_AgentMastermain", _aParam);
        }
        public static SqlDataReader Retrievecustpan(int st)
        {
            SqlParameter[] _aParam = { new SqlParameter("@Sno", st) };
            return SqlHelper.ExecuteReader(ConnectionString, "rcustomernamepanno", _aParam);
        }
        public static SqlDataReader BasicDet_Customer(int st)
        {
            SqlParameter[] _aParam = { new SqlParameter("@Sno", st) };
            return SqlHelper.ExecuteReader(ConnectionString, "BasicDet_Customer", _aParam);
        }

        public static DataSet RetrievePlan()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, "Search_PLBPlan");
        }
        public static SqlDataReader getBillingCycle()
        {

            return SqlHelper.ExecuteReader(ConnectionString, "getBillingCycle");
        }

        public static DataSet Currency()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, "bindcurrency");
        }
        public static DataSet ContactGrid(IAgent ID)
        {
            SqlParameter[] _aParam = { new SqlParameter("@sno", ID.SNo) };
            return SqlHelper.ExecuteDataset(ConnectionString, "contactgrid", _aParam);
        }
        public static DataSet City()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, "Cityboth");
        }
        public static DataSet CustCareCity()
        {

            return SqlHelper.ExecuteDataset(ConnectionString, "CustCareCity");
        }
        public static DataSet City_UserID(string userId)
        {
            SqlParameter[] _aParam = { new SqlParameter("@UserID", userId) };
            return SqlHelper.ExecuteDataset(ConnectionString, "Cityboth2", _aParam);
        }
        public static DataSet CityBind()
        {
            return SqlHelper.ExecuteDataset(ConnectionString, "City_Bind");
        }
        public static SqlDataReader getBankG(IAgent IA)
        {
            SqlParameter[] _param = { new SqlParameter("@CustomerSNo", IA.CustomerSNo) };
            return SqlHelper.ExecuteReader(ConnectionString, "getBankG", _param);
        }
        public static SqlDataReader getAgentName(IAgent IA)
        {
            SqlParameter[] _aParam = { new SqlParameter("@CustomerCode", IA.AgentCode) };
            return SqlHelper.ExecuteReader(ConnectionString, "GetAgentName", _aParam);
        }
        public static SqlDataReader GetAgentNameByCode(IAgent IA)
        {
            SqlParameter[] _aParam = { new SqlParameter("@CustomerCode", IA.AgentCode) };
            return SqlHelper.ExecuteReader(ConnectionString, "GetAgentNameByCode", _aParam);
        }

        public static SqlDataReader DetailsCreditReview(IAgent IA)
        {
            SqlParameter[] _param = { new SqlParameter("@Sno", IA.SNo) };
            return SqlHelper.ExecuteReader(ConnectionString, "ViewCreditReview", _param);
        }


        public static SqlDataReader CheckdCity(IAgent IA)
        {
            SqlParameter[] _aParam = { new SqlParameter("@CityName", IA.City) };
            return SqlHelper.ExecuteReader(ConnectionString, "Check_City", _aParam);
        }

        public static SqlDataReader GetAgent()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "GetAgent");
        }

        public static SqlDataReader BrowseCreditRequest()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "ShowCreditRequest");
        }

        public static String InsertCustomerTaxDetail(IAgent IA)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@AgentCode",IA.AgentCode),
                new SqlParameter("@TdsExcemption",IA.TDSRate),
                new SqlParameter("@ExcemptionLimit",IA.ExemptionLimit),
                new SqlParameter("@ValidFrom",IA.ValidFrom),
                new SqlParameter("@ValidTo",IA.ValidTo),
                new SqlParameter("@EnteredBY",IA.EnteredBY)
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Insert_CustomerTaxDetail", aparameter));
        }

        public static SqlDataReader GetCustomerTaxDetail(Int32 Strsno)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@SNo",Strsno)
             };
            return SqlHelper.ExecuteReader(ConnectionString, "GetCustomerTaxDetail", aparameter);
        }

        public static String UpdateCustomerTaxDetail(IAgent IA)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@SNo",IA.SNo),
                new SqlParameter("@AgentCode",IA.AgentCode),
                new SqlParameter("@TdsExcemption",IA.TDSRate),
                new SqlParameter("@ExcemptionLimit",IA.ExemptionLimit),
                new SqlParameter("@ValidFrom",IA.ValidFrom),
                new SqlParameter("@ValidTo",IA.ValidTo),
                new SqlParameter("@EnteredBY",IA.EnteredBY)
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Update_CustomerTaxDetail", aparameter));
        }
        public static String checkcreditlimit(IAgent IA)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@Sno",IA.SNo)
                
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "checkcreditreview", aparameter));
        }
        public static String checkgroupassign(IAgent IA)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@Sno",IA.SNo)                
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "checkgroup", aparameter));
        }
        public static SqlDataReader checkgroupassign2(IAgent IA)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@Sno",IA.SNo)
                
                
            };
            return SqlHelper.ExecuteReader(ConnectionString, "checkgroup2", aparameter);
        }
        public static String returncustbranchsno(string loginid)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@LoginId",loginid)
                
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "returnbranchsno", aparameter));
        }
        public static SqlDataReader fetchcontactsinfo(int number)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@Sno",number)
                
                
            };
            return SqlHelper.ExecuteReader(ConnectionString, "fetchcontactinfo", aparameter);
        }


        public static SqlDataReader FillCreditApplication(string CustSNo)
        {

            SqlParameter[] aparameter ={
                new SqlParameter("@CustSNo",CustSNo)
                
                
            };
            return SqlHelper.ExecuteReader(ConnectionString, "GetCreditAppData", aparameter);
        }


        public static String DeleteCustomerTaxDetail(IAgent IA)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@SNo",IA.SNo)
                           
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Delete_CustomerTaxDetail", aparameter));
        }
        public static DataSet getAllCusts(IAgent IA, string CompBrSNo)
        {
            SqlParameter[] _aParam = {
            new SqlParameter("@CompBrSNo",CompBrSNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCusts", _aParam);
        }
        public static DataSet getAllCustAddress(IAgent IA, string CompBrSNo)
        {
            SqlParameter[] _aParam = { 
            new SqlParameter("@CompBrSNo",CompBrSNo)
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "getAllCustAddress", _aParam);
        }

        public static SqlDataReader CountryCode_Show()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "CountryCode_Show");

        }

        public static SqlDataReader CountryCode_ShowCity()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "countrycode_showforcity");

        }

        public static SqlDataReader CategoryCodeShowcity()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "GetCategoryList");  
        }
        public static SqlDataReader CustType_Show()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "CustType_Show");

        }
        public static SqlDataReader CompHeadBind()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "CompHeadBind");
        }
        public static SqlDataReader CompHeadBindPNP()
        {
            return SqlHelper.ExecuteReader(ConnectionString, "CompHeadBindPNP");
        }
        public static SqlDataReader FindBranchSnoDeat(int sno)
        {
            SqlParameter[] _aParam = { 
            new SqlParameter("@Sno",sno)
            };

            return SqlHelper.ExecuteReader(ConnectionString, "FindBranchSnoDeat", _aParam);
        }
        public static String UpdateCompLogo(int CustSno, byte[] CLogo, byte[] BLogo, byte[] Logo)
        {
            SqlParameter[] _param = {

                new SqlParameter("@Sno",CustSno),
                new SqlParameter("@Complogo",CLogo),
                new SqlParameter("@Complogo",BLogo),
                new SqlParameter("@Complogo",Logo)
                 };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "Companylogo_UpDate", _param));
        }
        public static String InsertCLBranchWise(Int32 BrSno, Decimal CreditLimt, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@BrSno",BrSno),
                new SqlParameter("@CreditLimit",CreditLimt)               
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(tr, "InsertCLBranchWise", aparameter));
        }

        public static DataSet GetCustomerCreditLimit(string CompBrSNo, string Status, string CustSno)
        {
            SqlParameter[] _aParam = { 
            new SqlParameter("@CompBrSNo",CompBrSNo),
            new SqlParameter("@Status",Status),
            new SqlParameter("@CustSno",CustSno)           
            };
            return SqlHelper.ExecuteDataset(ConnectionString, "CreditViewAppCust", _aParam);
        }
        public static SqlDataReader ShowRegistrationDet(int LoginSno)
        {
            SqlParameter[] _aParam = { 
            new SqlParameter("@Sno",LoginSno)
            };

            return SqlHelper.ExecuteReader(ConnectionString, "ShowRegistrationDet", _aParam);
        }
        public static SqlDataReader ShowAssociateDet(int Sno)
        {
            SqlParameter[] _aParam = { 
            new SqlParameter("@Sno",Sno)
            };

            return SqlHelper.ExecuteReader(ConnectionString, "ShowAssociateDet", _aParam);
        }
        public static DataSet CreditReviewRenewal(int CompBrSno)
        {
            SqlParameter[] _aParam = { 
            new SqlParameter("@CompBrSno",CompBrSno)
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "CreditReviewRenewal", _aParam);

        }
        //public static DataSet GetCountryName(string Countrid)
        //{
        //    SqlParameter[] _aParam = { 
        //    new SqlParameter("@Countrid",Countrid)
        //    };

        //    return SqlHelper.ExecuteDataset(ConnectionString, "spgetcounteryname", _aParam);

        //}

        public static String CheckRights(String LoginType)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@LoginType",LoginType)
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "CheckRights", aparameter));
        }
        public static DataSet NewCreditRequest(int CompBrSno)
        {
            SqlParameter[] _aParam = { 
            new SqlParameter("@CompBrSno",CompBrSno)
            };

            return SqlHelper.ExecuteDataset(ConnectionString, "NewCreditRequest", _aParam);

        }
        public static String UpdateRegDetAssociate(Int32 regDetSno, Int32 AssociateId, String Flag)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@regDetSno",regDetSno),
                new SqlParameter("@AssociateId",AssociateId),
                new SqlParameter("@flag",Flag)
                 
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "UpdateRegDetAssociate", aparameter));
        }

        public static DataSet SupplierReportSelect(IAgent Agent)
        {
            SqlParameter[] _aParam = { new SqlParameter("@CompBrSNo", Agent.CompBrSno) };

            return SqlHelper.ExecuteDataset(ConnectionString, "getSuppliersREport", _aParam);
        }
        public static SqlDataReader CheckUsedLimit(IAgent IA, Int32 CustBRSno)
        {
            SqlParameter[] _aParam = { 
              new SqlParameter("@CustBrSno",CustBRSno),
              new SqlParameter("@CompBrSno",IA.CompBrSno),
              new SqlParameter("@Flaggroup",IA.Flaggroup)
            };

            return SqlHelper.ExecuteReader(ConnectionString, "CheckUsedLimit", _aParam);
        }
        public static String checkCreditStatus(Int32 MSno)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@Msno",MSno)
             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "checkCreditStatus", aparameter));
        }
        public static String CreditReviewMassage(Int32 MSno)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@Msno",MSno)             
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "CreditReviewMassage", aparameter));
        }

        public static DataSet getCustomerDetailForConference(int CustMSno,int CustBrSno, int pageSize, int pageNo, string whereCondition)
        {
            SqlParameter[] _aParam = { new SqlParameter("@CustMSno", CustMSno),
                                         new SqlParameter("@CustBrSno", CustBrSno),
                                     new SqlParameter("@pageSize",pageSize),
                                     new SqlParameter("@pageNo", pageNo),
                                     new SqlParameter("@whereCondition", whereCondition)
                                     };

            return SqlHelper.ExecuteDataset(ConnectionString, "getCustomerDetailForConference", _aParam);
        }
        public static String insertCustConferenceDetail(int CustConfSno, int CustMSno, int CustBrSno, string Remarks, string ActionTaken,string Conference, string ConferenceCity,DateTime ConferenceDate, string AttendBy, string AddedBy, string updatedBy)
        {
            SqlParameter[] aparameter ={
                                           new SqlParameter("@CustConfSno",CustConfSno),
                                           new SqlParameter("@CustMSno",CustMSno),
                new SqlParameter("@CustBrSno",CustBrSno),
                new SqlParameter("@Remarks",Remarks),
                new SqlParameter("@ActionTaken",ActionTaken),
                new SqlParameter("@Conference",Conference),
                new SqlParameter("@ConferenceCity",ConferenceCity),
                new SqlParameter("@ConferenceDate",ConferenceDate),
                new SqlParameter("@AttendBy",AttendBy),
                new SqlParameter("@AddedBy",AddedBy),
                new SqlParameter("@updatedBy",updatedBy)
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "insertCustConferenceDetail", aparameter));
        }

        public static String updateCustomerEmail(IAgent Agent,int SalesPerson)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CustBrSNo",Agent.CustomerSNo),
                new SqlParameter("@Email",Agent.Email) ,
                new SqlParameter("@SalesPerson",SalesPerson)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(ConnectionString, "updateCustomerEmail", aparameter));
        }

        public static String InsertCutomerFromPaceExpress(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@PhdnCustType",Agent.hdnCustType),
                 new SqlParameter("@PcustMastSno",Agent.custMastSno),
                 new SqlParameter("@PCustBrSno",Agent.CustBrSno),
                 new SqlParameter("@PCustomerType",Agent.CustomerType),
                 new SqlParameter("@PGroupCustomer",Agent.GroupCustomer),
                 new SqlParameter("@PIataNo",Agent.IATANo),
                 new SqlParameter("@PActive",Agent.Active),
                 new SqlParameter("@PSalesPersonSno",Agent.SalesPersonSno),
                 new SqlParameter("@PBill",Agent.Bill),
                 new SqlParameter("@PNetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@PStarRating",Agent.StarRating),
                 new SqlParameter("@PCustomerBusinessTypeSno",Agent.CustomerBusinessTypeSno),
                 new SqlParameter("@PIsOscCalCulated",Agent.isOscCal),
                 new SqlParameter("@PCustomerName",Agent.CustomerName), 
                 new SqlParameter("@PStreet",Agent.Street),
                 new SqlParameter("@PCity",Agent.City),
                 new SqlParameter("@PCustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@PNetWorkAgentCitySno",Agent.NetworkAgentCitySno),
                 new SqlParameter("@PState",Agent.State),
                 new SqlParameter("@PPinCode",Agent.PinCode),  
                 new SqlParameter("@PCountryCode",Agent.CountryCode),
                 new SqlParameter("@PPhoneNo",Agent.PhoneNo),
                 new SqlParameter("@PFax",Agent.Fax),
                 new SqlParameter("@PMobile",Agent.Mobile),
                 new SqlParameter("@PEmail",Agent.Email),
                 new SqlParameter("@PWebsite",Agent.Email),
                 new SqlParameter("@PAdCode",Agent.Adcode),
                 new SqlParameter("@PIECNo",Agent.IECNo),
                 new SqlParameter("@PBankName",Agent.BankName),
                 new SqlParameter("@PBankAccNo",Agent.BankAccNo),
                 new SqlParameter("@PBankAddress",Agent.BankAddress),
                 new SqlParameter("@PPanNo",Agent.PANNo),  
                 new SqlParameter("@PServiceTaxNo",Agent.ServiceTaxNo),
                 new SqlParameter("@PTanNo",Agent.TanNo),
                 new SqlParameter("@PTinNo",Agent.TinNo),
                 new SqlParameter("@PPaymentMode",Agent.PaymentMode),
                 new SqlParameter("@PCurrency",Agent.Currency),         
                 new SqlParameter("@PStandardDeal",Agent.StandardDeal),
                 new SqlParameter("@PBillingCycle",Agent.BillingCycle),
                 new SqlParameter("@PInvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new SqlParameter("@PloginFlag",Agent.loginFlag),
                 new SqlParameter("@PCustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@PPassword",Agent.Password),
                 new SqlParameter("@PCompBrSno",Agent.CompBrSno),
                 new SqlParameter("@PEnteredBy",Agent.EnteredBY),

                 new SqlParameter("@LoginId",Agent.LoginId),
                 new SqlParameter("@LoginPassword",Agent.LoginPassword),
                 new SqlParameter("@LoginCompSNo",Agent.LoginCompSNo),
                 new SqlParameter("@LoginDisplayName",Agent.LoginDisplayName),
                 new SqlParameter("@LoginEmailID",Agent.LoginEmailID)  
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "InsertCutomerFromPaceExpress", aparameter));
            //return Convert.ToString(SqlHelper.ExecuteScalar(tr,Cfi.App.Pace.Common.PaceCommon.PaceConnectionString,"InsertCutomerFromRedIntl", aparameter));
        }

        public static String UpdateCutomerFromPaceExpress(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@PEntryType",Agent.hdnCustType),
                 new SqlParameter("@PcustMastSno",Agent.custMastSno),
                 new SqlParameter("@PCustBrSno",Agent.CustBrSno),
                 new SqlParameter("@PCustomerType",Agent.CustomerType),
                 new SqlParameter("@PGroupCustomer",Agent.GroupCustomer),
                 new SqlParameter("@PIataNo",Agent.IATANo),
                 new SqlParameter("@PActive",Agent.Active),
                 new SqlParameter("@PSalesPersonSno",Agent.SalesPersonSno),
                 new SqlParameter("@PBill",Agent.Bill),
                 new SqlParameter("@PNetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@PStarRating",Agent.StarRating),
                 new SqlParameter("@PCustomerBusinessTypeSno",Agent.CustomerBusinessTypeSno),
                 new SqlParameter("@PIsOscCalCulated",Agent.isOscCal),
                 new SqlParameter("@PStreet",Agent.Street),
                 new SqlParameter("@PCity",Agent.City),
                 new SqlParameter("@PCustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@PNetWorkAgentCitySno",Agent.NetworkAgentCitySno),
                 new SqlParameter("@PState",Agent.State),
                 new SqlParameter("@PPinCode",Agent.PinCode),  
                 new SqlParameter("@PCountryCode",Agent.CountryCode),
                 new SqlParameter("@PPhoneNo",Agent.Phone),
                 new SqlParameter("@PFax",Agent.Fax),
                 new SqlParameter("@PMobile",Agent.MobileNo),
                 new SqlParameter("@PEmail",Agent.Email),
                 new SqlParameter("@PWebsite",Agent.Email),
                 new SqlParameter("@PAdCode",Agent.Adcode),
                 new SqlParameter("@PIECNo",Agent.IECNo),
                 new SqlParameter("@PBankName",Agent.BankName),
                 new SqlParameter("@PBankAccNo",Agent.BankAccNo),
                 new SqlParameter("@PBankAddress",Agent.BankAddress),
                 new SqlParameter("@PPanNo",Agent.PANNo),  
                 new SqlParameter("@PServiceTaxNo",Agent.ServiceTaxNo),
                 new SqlParameter("@PTanNo",Agent.TanNo),
                 new SqlParameter("@PTinNo",Agent.TinNo),
                 new SqlParameter("@PPaymentMode",Agent.PaymentMode),
                 new SqlParameter("@PCurrency",Agent.Currency),         
                 new SqlParameter("@PStandardDeal",Agent.StandardDeal),
                 new SqlParameter("@PBillingCycle",Agent.BillingCycle),
                 new SqlParameter("@PInvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new SqlParameter("@PloginFlag",Agent.loginFlag),
                 new SqlParameter("@PCustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@PPassword",Agent.Password),
                 new SqlParameter("@PCompBrSno",Agent.CompBrSno),
                 new SqlParameter("@PModifiedBy",Agent.ModifiedBy) ,

                 new SqlParameter("@LoginId",Agent.LoginId),
                 new SqlParameter("@LoginPassword",Agent.LoginPassword),
                 new SqlParameter("@LoginCompSNo",Agent.LoginCompSNo),
                 new SqlParameter("@LoginDisplayName",Agent.LoginDisplayName),
                 new SqlParameter("@LoginEmailID",Agent.LoginEmailID)  
 
              };

            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "UpdateCutomerFromPaceExpress", aparameter));
        }

        public static String updateCustomerEmailRedIntl(IAgent Agent)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@CustBrSNo",Agent.CustomerSNo),
                new SqlParameter("@Email",Agent.Email) ,
                new SqlParameter("@SalesPerson",Agent.SalesPersonSno)
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "updateCustomerEmail", aparameter));
        }

        public static String insertCustomerNewRedIntl(IAgent Agent,  SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@EntryType",Agent.entryType),
                 new SqlParameter("@CustMastSno",Agent.custMastSno),
                 new SqlParameter("@CustBrSno",Agent.CustomerSNo),
                 new SqlParameter("@CustomerType",Agent.CustomerType),
                 new SqlParameter("@GroupCustomer",Agent.GroupCustomer),
                 new SqlParameter("@IataNo",Agent.IATANo),
                 new SqlParameter("@Active",Agent.Active),
                 new SqlParameter("@SalesPersonSno",Agent.SalesPersonSno),
                 new SqlParameter("@Bill",Agent.bill),
                 new SqlParameter("@NetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@StarRating",Agent.StarRating),
                 new SqlParameter("@CustomerBusinessTypeSno",Agent.CustomerBusinessTypeSno),
                 new SqlParameter("@IsOscCalCulated",Agent.isOscCal),
                 new SqlParameter("@CustomerName",Agent.CustomerName), 
                 new SqlParameter("@Street",Agent.StreetName),
                 new SqlParameter("@City",Agent.City),
                 new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@NetWorkAgentCitySno",Agent.NetworkAgentCitySno),
                 new SqlParameter("@State",Agent.State),
                 new SqlParameter("@PinCode",Agent.PinCode),  
                 new SqlParameter("@CountryCode",Agent.CountryCode),
                 new SqlParameter("@PhoneNo",Agent.Phone),
                 new SqlParameter("@Fax",Agent.Fax),
                 new SqlParameter("@Mobile",Agent.MobileNo),
                 new SqlParameter("@Email",Agent.Email),
                 new SqlParameter("@Website",Agent.Website),
                 new SqlParameter("@AdCode",Agent.Adcode),
                 new SqlParameter("@IECNo",Agent.IECNo),
                 new SqlParameter("@BankName",Agent.BankName),
                 new SqlParameter("@BankAccNo",Agent.BankAccNo),
                 new SqlParameter("@BankAddress",Agent.BankAdd),
                 new SqlParameter("@PanNo",Agent.PANNo),  
                 new SqlParameter("@ServiceTaxNo",Agent.ServiceTaxNo),
                 new SqlParameter("@TanNo",Agent.TanNo),
                 new SqlParameter("@TinNo",Agent.TinNo),
                 new SqlParameter("@PaymentMode",Agent.PaymentMode),
                 new SqlParameter("@Currency",Agent.Currency),         
                 new SqlParameter("@StandardDeal",Agent.StandardDeal),
                 new SqlParameter("@BillingCycle",Agent.BillingCycle),
                 new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new SqlParameter("@loginFlag",Agent.loginFlag),
                 new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@Password",Agent.Password),
                 new SqlParameter("@CompBrSno",Agent.CompBrSno),
                 new SqlParameter("@EnteredBy",Agent.EnteredBY)  
              };

            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "insertCustomerNew", aparameter));
        }

        public static String updateCustomerRedIntl(IAgent Agent,SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@EntryType",Agent.entryType),
                 new SqlParameter("@CustMastSno",Agent.custMastSno),
                 new SqlParameter("@CustBrSno",Agent.CustomerSNo),
                 new SqlParameter("@CustomerType",Agent.CustomerType),
                 new SqlParameter("@GroupCustomer",Agent.GroupCustomer),
                 new SqlParameter("@IataNo",Agent.IATANo),
                 new SqlParameter("@Active",Agent.Active),
                 new SqlParameter("@SalesPersonSno",Agent.SalesPersonSno),
                 new SqlParameter("@Bill",Agent.bill),
                 new SqlParameter("@NetworkGroupSno",Agent.NetworkGroupSno),
                 new SqlParameter("@StarRating",Agent.StarRating),
                 new SqlParameter("@CustomerBusinessTypeSno",Agent.CustomerBusinessTypeSno),
                 new SqlParameter("@IsOscCalCulated",Agent.isOscCal),
                 new SqlParameter("@Street",Agent.StreetName),
                 new SqlParameter("@City",Agent.City),
                 new SqlParameter("@CustomerCareCity",Agent.CustCareCity),
                 new SqlParameter("@NetWorkAgentCitySno",Agent.NetworkAgentCitySno),
                 new SqlParameter("@State",Agent.State),
                 new SqlParameter("@PinCode",Agent.PinCode),  
                 new SqlParameter("@CountryCode",Agent.CountryCode),
                 new SqlParameter("@PhoneNo",Agent.Phone),
                 new SqlParameter("@Fax",Agent.Fax),
                 new SqlParameter("@Mobile",Agent.MobileNo),
                 new SqlParameter("@Email",Agent.Email),
                 new SqlParameter("@Website",Agent.Website),
                 new SqlParameter("@AdCode",Agent.Adcode),
                 new SqlParameter("@IECNo",Agent.IECNo),
                 new SqlParameter("@BankName",Agent.BankName),
                 new SqlParameter("@BankAccNo",Agent.BankAccNo),
                 new SqlParameter("@BankAddress",Agent.BankAdd),
                 new SqlParameter("@PanNo",Agent.PANNo),  
                 new SqlParameter("@ServiceTaxNo",Agent.ServiceTaxNo),
                 new SqlParameter("@TanNo",Agent.TanNo),
                 new SqlParameter("@TinNo",Agent.TinNo),
                 new SqlParameter("@PaymentMode",Agent.PaymentMode),
                 new SqlParameter("@Currency",Agent.Currency),         
                 new SqlParameter("@StandardDeal",Agent.StandardDeal),
                 new SqlParameter("@BillingCycle",Agent.BillingCycle),
                 new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                 new SqlParameter("@loginFlag",Agent.loginFlag),
                 new SqlParameter("@CustomerLoginId",Agent.CustomerLoginId),
                 new SqlParameter("@Password",Agent.Password),
                 new SqlParameter("@CompBrSno",Agent.CompBrSno),
                 new SqlParameter("@UpdatedBy",Agent.ModifiedBy)  
              };

            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "updateCustomer", aparameter));
        }

        public static String AddCustomercontactsApproveRedIntl(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@CustomerBranchSno",Agent.CustomerSNo),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Name",Agent.ContactName),
                 new SqlParameter("@Designation",Agent.ContactDesign),               
                 new SqlParameter("@Telephone",Agent.ContactPhone),
                 new SqlParameter("@FAx",Agent.Fax),                
                 new SqlParameter("@Emal",Agent.Email),
                 new SqlParameter("@Depart",Agent.ContactDept) 

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "updatecustomercontactApprove", aparameter));
        }

        public static String Insert_CreditReviewNew(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@Address",Agent.Address),
                new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@ApplicantName",Agent.ApplicantName),
                new SqlParameter("@LegalStatus",Agent.LegalStatus),
                new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                new SqlParameter("@IndustryType",Agent.IndustryType),
                new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                 new SqlParameter("@PartnerName1",Agent.PartnerName1),
                 new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                 new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),

                new SqlParameter("@PartnerName2",Agent.PartnerName2),
                
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                 new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),

                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@ApproveBy",Agent.ApprovedBy),
                new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@AccountsRemarks",Agent.AccountsRemarks),
                new SqlParameter("@CustomerSNo",Agent.CustomerSNo),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@ApprovalType",Agent.ApprovalType)
                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "Insert_CreditReviewNew", aparameter));
        }

        public static String InsertCLBranchWiseRedIntl(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                new SqlParameter("@BrSno",Agent.BrSno),
                new SqlParameter("@CreditLimit",Agent.CreditLimitPace)               
                
            };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "InsertCLBranchWise", aparameter));
        }

        public static String disapprove(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={             
                new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@AccountsRemarks",Agent.AccountsRemarks)
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "disapprove", aparameter));
        }

        public static String InserCreditReview(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={                  
                  new SqlParameter("@PanNo",Agent.PANNo),
                  new SqlParameter("@LoginID",Agent.LoginId),
                  new SqlParameter("@CustomerName",Agent.CustomerName),
                  new SqlParameter("@ApplicantName",Agent.ApplicantName),
                  new SqlParameter("@LegalStatus",Agent.LegalStatus),               
                  new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),                
                  new SqlParameter("@SalesPersonName",Agent.SalesPersonName),                
                  new SqlParameter("@IndustryType",Agent.IndustryType),
                  new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                  new SqlParameter("@PartnerName1",Agent.PartnerName1),               
                new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),
                new SqlParameter("@PartnerName2",Agent.PartnerName2),
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),               
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee), 
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),
                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4 ),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5 ),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),
                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt6),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),
                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Status",Agent.Status),
                new SqlParameter("@RequestedDate",Agent.EnteredDate),
                new SqlParameter("@CustomerBranchSno",Agent.SNo),
                new SqlParameter("@RequestedBy",Agent.RequestedBy),
                new SqlParameter("@CustomerRemarks",Agent.CustomerRemarks),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@CompBrSno",Agent.CompBrSno)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "InserCreditReview", aparameter));
        }

        public static String updatecustomercontact(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@LoginID",Agent.LoginId),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Name",Agent.ContactName),
                 new SqlParameter("@Designation",Agent.ContactDesign),              
                 new SqlParameter("@Telephone",Agent.ContactPhone),                
                 new SqlParameter("@FAx",Agent.Fax),                
                 new SqlParameter("@Emal",Agent.Email),
                 new SqlParameter("@Depart",Agent.ContactDept),
                 new SqlParameter("@CustomerBranchSno",Agent.SNo),

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "updatecustomercontact", aparameter));
        }

        public static String updatecustomercontactApprove(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@CustomerBranchSno",Agent.CustomerSNo),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Name",Agent.ContactName),
                 new SqlParameter("@Designation",Agent.ContactDesign),               
                 new SqlParameter("@Telephone",Agent.ContactPhone),
                 new SqlParameter("@FAx",Agent.Fax),                
                 new SqlParameter("@Emal",Agent.Email),
                 new SqlParameter("@Depart",Agent.ContactDept) 

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "updatecustomercontactApprove", aparameter));
        }

        public static String UpdateSales_CreditReviewRedIntl(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                 new SqlParameter("@CustomerName",Agent.CustomerName),
                 new SqlParameter("@Address",Agent.Address),
                 new SqlParameter("@PanNo",Agent.PANNo),
                 new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                 new SqlParameter("@ApplicantName",Agent.ApplicantName),
                 new SqlParameter("@LegalStatus",Agent.LegalStatus),
                 new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                 new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                 new SqlParameter("@IndustryType",Agent.IndustryType),
                 new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                 new SqlParameter("@PartnerName1",Agent.PartnerName1),
                 new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                 new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),

                 new SqlParameter("@PartnerName2",Agent.PartnerName2),
                
                 new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                 new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                 new SqlParameter("@PartnerName3",Agent.PartnerName3),
                 new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                 new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                 new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                 new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                 new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                 new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                 new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                 new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                 new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                 new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),
                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@ApproveBy",Agent.ApprovedBy),
                new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@SalesRemarks",Agent.AccountsRemarks),
                new SqlParameter("@CustomerSNo",Agent.CustomerSNo),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod)

              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "UpdateSales_CreditReview", aparameter));
        }

        public static String disapproveCrLimitBySM(IAgent IA, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={             
                new SqlParameter("@Sno",IA.SNo),
                new SqlParameter("@SalesRemarks",IA.SalesRemarks),
                new SqlParameter("@ModifiedBy",IA.ModifiedBy)                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "disapproveCrLimitBySM", aparameter));
        }

        public static String Update_CondCreditReviewRedintl(IAgent Agent, SqlTransaction tr)
        {
            SqlParameter[] aparameter ={
                 new SqlParameter("@Sno",Agent.SNo),
                new SqlParameter("@CustomerName",Agent.CustomerName),
                new SqlParameter("@Address",Agent.Address),
                new SqlParameter("@PanNo",Agent.PANNo),
                new SqlParameter("@BankClaimPeriod",Agent.BGClaimPeriod),
                new SqlParameter("@ApplicantName",Agent.ApplicantName),
                new SqlParameter("@LegalStatus",Agent.LegalStatus),
                new SqlParameter("@ROCRegnNo",Agent.ROCRegnNo),
                new SqlParameter("@SalesPersonName",Agent.SalesPersonName),
                new SqlParameter("@IndustryType",Agent.IndustryType),
                new SqlParameter("@CustomerPremises",Agent.CustomerPremises),
                new SqlParameter("@PartnerName1",Agent.PartnerName1),
                new SqlParameter("@PartnerAddress1",Agent.PartnerAddress1),
                new SqlParameter("@OtherTradeName1",Agent.OtherTradeName1),
                new SqlParameter("@PartnerName2",Agent.PartnerName2),                
                new SqlParameter("@PartnerAddress2",Agent.PartnerAddress2),
                new SqlParameter("@OtherTradeName2",Agent.OtherTradeName2 ),
                new SqlParameter("@PartnerName3",Agent.PartnerName3),
                new SqlParameter("@PartnerAddress3",Agent.PartnerAddress3),
                new SqlParameter("@OtherTradeName3",Agent.OtherTradeName3),
                new SqlParameter("@AnnualSales",Agent.AnnualSales),
                 new SqlParameter("@NoOfEmployee",Agent.NoOfEmployee),
                new SqlParameter("@LargestCustomerName1",Agent.LargestCustomerName1),
                new SqlParameter("@LargestCustomerName2",Agent.LargestCustomerName2),
                new SqlParameter("@OrgBusinessYear",Agent.OrgBusinessYear),
                new SqlParameter("@OthBisPremiseLocation1",Agent.OthBisPremiseLocation1),
                new SqlParameter("@OthBisPremiseType1",Agent.OthBisPremiseType1),
                new SqlParameter("@OthBisPremiseFacility1",Agent.OthBisPremiseFacility1),
                 new SqlParameter("@OthBisPremiseLocation2",Agent.OthBisPremiseLocation2),
                 new SqlParameter("@OthBisPremiseType2",Agent.OthBisPremiseType2),
                 new SqlParameter("@OthBisPremiseFacility2",Agent.OthBisPremiseFacility2),

                new SqlParameter("@OthBisPremiseLocation3",Agent.OthBisPremiseLocation3),
                
                new SqlParameter("@OthBisPremiseType3",Agent.OthBisPremiseType3),
                new SqlParameter("@OthBisPremiseFacility3",Agent.OthBisPremiseFacility3 ),
                new SqlParameter("@OthBisPremiseLocation4",Agent.OthBisPremiseLocation4),
                new SqlParameter("@OthBisPremiseType4",Agent.OthBisPremiseType4),
                new SqlParameter("@OthBisPremiseFacility4",Agent.OthBisPremiseFacility4),
                new SqlParameter("@OthBisPremiseLocation5",Agent.OthBisPremiseLocation5),
                 new SqlParameter("@OthBisPremiseType5",Agent.OthBisPremiseType5),
                new SqlParameter("@OthBisPremiseFacility5",Agent.OthBisPremiseFacility5),
                new SqlParameter("@OthBisPremiseLocation6",Agent.OthBisPremiseLocation6),
                new SqlParameter("@OthBisPremiseType6",Agent.OthBisPremiseType6),
                new SqlParameter("@@OthBisPremiseFacility6",Agent.OthBisPremiseFacility6),
                new SqlParameter("@OthForwarder1",Agent.OthForwarder1),
                new SqlParameter("@OutstandingAmt1",Agent.OutstandingAmt1),
                new SqlParameter("@OthForwarder2",Agent.OthForwarder2),
                new SqlParameter("@OutstandingAmt2",Agent.OutstandingAmt2),
                new SqlParameter("@OthForwarder3",Agent.OthForwarder3),

                new SqlParameter("@OutstandingAmt3",Agent.OutstandingAmt3),
                
                new SqlParameter("@OthForwarder4",Agent.OthForwarder4),
                new SqlParameter("@OutstandingAmt4",Agent.OutstandingAmt4 ),
                new SqlParameter("@OthForwarder5",Agent.OthForwarder5  ),
                new SqlParameter("@OutstandingAmt5",Agent.OutstandingAmt5),
                new SqlParameter("@OthForwarder6",Agent.OthForwarder6),
                new SqlParameter("@OutstandingAmt6",Agent.OutstandingAmt6),
                new SqlParameter("@MonthlyBilling",Agent.MonthlyBilling),
                new SqlParameter("@MonthlyVolume",Agent.MonthlyVolume),
                new SqlParameter("@CreditLimitReq",Agent.CreditLimitReq),

                new SqlParameter("@CreditPeriReq",Agent.CreditPeriReq),
                new SqlParameter("@Name",Agent.ContactName ),
                new SqlParameter("@Designation",Agent.ContactDesign ),
                new SqlParameter("@Telephone",Agent.ContactPhone),
                new SqlParameter("@FAx",Agent.Fax),
                new SqlParameter("@Emal",Agent.Email),
                new SqlParameter("@Depart",Agent.ContactDept ),
                new SqlParameter("@CreditLimit",Agent.CreditLimit),
                new SqlParameter("@CreditPeriod",Agent.CreditPeriod),
                new SqlParameter("@CreditReviewDate",Agent.CreditReviewDate),
                new SqlParameter("@BGAmount",Agent.BankGuarantee),
                new SqlParameter("@BGDate",Agent.BGDate ),
                new SqlParameter("@BankName",Agent.BankName ),
                new SqlParameter("@BankAddress",Agent.BankAddress),
                new SqlParameter("@ApproveBy",Agent.ApprovedBy),
                new SqlParameter("@ApproveAt",Agent.ApprovedAt),
                new SqlParameter("@Flaggroup",Agent.Flaggroup),
                new SqlParameter("@AccountsRemarks",Agent.AccountsRemarks),
                new SqlParameter("@CustomerSNo",Agent.CustomerSNo),
                new SqlParameter("@InvoiceCreditPeriod",Agent.InvoiceCreditPeriod),
                new SqlParameter("@ApprovalType",Agent.ApprovalType)
                
              };
            return Convert.ToString(SqlHelper.ExecuteScalar(Cfi.App.Pace.Common.PaceCommon.REDINTLConnectionString, "Update_CondCreditReview", aparameter));
        }
    }
}
