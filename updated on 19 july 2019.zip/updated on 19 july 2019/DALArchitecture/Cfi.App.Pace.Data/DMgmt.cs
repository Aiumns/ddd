﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Interface;
using Cfi.App.Pace.Data;
namespace Cfi.App.Pace.Data
{
   public class DMgmt :PaceCommon
    {
       /// <summary>
       /// Used to select company Head office.
       /// </summary>
       /// <returns></returns>
       public static DataSet CompanyHO_Select()
       {
           return SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "CompanyHO_Select");
       }
       /// <summary>
       /// Select branch based on head office.
       /// </summary>
       /// <param name="Mgmt"></param>
       /// <returns></returns>
       public static DataSet BranchOffice_Select(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          //new SqlParameter("@HoSno",Mgmt.HoSno)
                                          new SqlParameter("@Name",Mgmt.CompanyName)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "BranchOffice_Select", lParameter);
       }
       public static DataSet MgmtRecord_Select(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_Select", lParameter);
       }
       public static int NoBookingSelect(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@CHASno",Mgmt.CHASno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return int.Parse(SqlHelper.ExecuteScalar(ConnectionString, "MgmtCHABooking_Select", lParameter).ToString());
       }
       public static int NoOfCHAFiledSelect(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CHASno",Mgmt.CHASno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return int.Parse(SqlHelper.ExecuteScalar(ConnectionString, "MgmtCHAFiled_Select", lParameter).ToString());
       }
       public static int CountCHAChargeStatus(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CHASno",Mgmt.CHASno),
                                          new SqlParameter("@Status",Mgmt.CHAChargeStatus),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return int.Parse(SqlHelper.ExecuteScalar(ConnectionString, "MgmtCHAStatus_Select", lParameter).ToString());
       }
        #region "DashBoard"
       public static DataSet GetDashBoardCount(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "GetDashBoardCount", lParameter);
       }

       public static DataSet getPendingRFB(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "getPendingRFB", lParameter);
       }
       public static DataSet GetExportOpenJobDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_Select1", lParameter);
       }
       public static DataSet GetExportInvoicedJobDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_InvoicedJobs", lParameter);
       }
       public static DataSet GetSeaInvDetail(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_SeaInvDetail", lParameter);
       }
       public static DataSet GetExportOutstandingBillsDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_Outstanding", lParameter);
       }
       public static DataSet GetImportOutstandingBillsDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ImpOutstanding", lParameter);
       }
       public static DataSet GetExportCHAShippBillsDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_CHASBills", lParameter);
       }
       public static DataSet getCrLimExpired(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "getCrLimExpired", lParameter);
       }
       public static DataSet GetExportCHAShippBillsChildDetails(int intSno)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@SNo",intSno)
                                         
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ShippingBills", lParameter);
       }
       public static DataSet GetImportOpenJobsDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_OpenJobImp", lParameter);
       }
       public static DataSet GetImportHAWBDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ImpHawb", lParameter);
       }
       public static DataSet GetImportMAWBDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ImpMawb", lParameter);
       }
       public static DataSet GetExportMAWBDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ExpMawb", lParameter);
       }
       public static DataSet GetExportHAWBDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ExpHawb", lParameter);
       }
       public static DataSet GetSeaHblDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_SeaHBL", lParameter);
       }
       public static DataSet GetImportCANDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ImpInvoicedJobs", lParameter);
       }
       public static DataSet GetGoodsDet(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_GoodsRec", lParameter);
       }
       public static DataSet GetImportPODDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_ImpPOD", lParameter);
       }
       public static DataSet GetCHAChargeDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_CHACharges", lParameter);
       }
       public static DataSet GetPaymentRecDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_PaymentRecd", lParameter);
       }
       public static DataSet GetPaymentMadeDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_PaymentMade", lParameter);
       }
       public static DataSet GetPendingWriteOffDetails(IMgmt Mgmt, string LoginId)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date),
                                          new SqlParameter("@LoginId",LoginId)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_PendingWriteOff", lParameter);
       }
       public static DataSet GetNewCustomerDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_NewCustomers", lParameter);
       }
       public static DataSet GetRFQRejectedDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_RFQRejected", lParameter);
       } 
       public static DataSet MgmtRecord_RFQPending(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_RFQPending", lParameter);
       }
       public static DataSet MgmtRecord_PendingDeal(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                         
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "Pending_Deal", lParameter);
       }
       public static DataSet GetRFQConfirmedDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_RFQConfirmed", lParameter);
       }
       public static DataSet GetRFQNewDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_NewRFQ", lParameter);
       }
       public static DataSet GetBlockCustomerDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_BlockedCustomers", lParameter);
       }
       public static DataSet GetChecqueBounceDetails(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno),
                                          new SqlParameter("@Date",Mgmt.Date)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "MgmtRecord_BounceCheque", lParameter);
       }
       public static DataSet GetAssignedCompany(string strUser)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@UserId",strUser),
                                          
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "AssignedCompany", lParameter);
       }
       public static DataSet getCompVariables(IMgmt Mgmt)
       {
           SqlParameter[] lParameter = {
                                          new SqlParameter("@CompBrSno",Mgmt.CompBrSno)
                                        };
           return SqlHelper.ExecuteDataset(ConnectionString, "getCompVariables", lParameter);
       }
       public static DataSet GetOnlineUsers(DateTime date)
       {
       SqlParameter [] _param={
                              new SqlParameter("@date",date)
                              };
           return SqlHelper.ExecuteDataset(ConnectionString,"GetOnlineUsers",_param);
       }
        #endregion 
    }
}
