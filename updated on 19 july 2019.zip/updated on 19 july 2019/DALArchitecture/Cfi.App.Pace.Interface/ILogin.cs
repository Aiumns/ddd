﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Cfi.App.Pace.Interface
{
    public interface ILogin
    {
        Int32 Lsno { get; set; }
        String LoginId { get; set; }
        String Name { get; set; }
        String Password { get; set; }

        String loginType { get; set; }
        String CityName { get; set; }
        String Active { get; set; }
        String RemoteHostName { get; set; }
        String RemoteIPAddress { get; set; }
        String LocalIPAddress { get; set; }
        String GroupName { get; set; }
        String Email { get; set; }
        String Companysno { get; set; }

        byte[] passwordLogin { get; set; }
        Int32 ChaName { get; set; }
        String CompanyName { get; set; }
        byte[] Signature { get; set; }
        String OpType { get; set; }

    }
}
