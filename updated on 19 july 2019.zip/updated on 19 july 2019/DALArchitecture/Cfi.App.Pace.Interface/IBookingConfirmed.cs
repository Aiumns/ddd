using System;
using System.Collections.Generic;
using System.Text;

namespace Cfi.App.Pace.Interface
{
    public interface IBookingConfirmed
    { 
        Int32 SNo { get; set; }
        Int32 BookingId { get; set; }
        DateTime BookingDate { get; set; }
        String CustName { get; set; }
        String CustCode { get; set; }
        String custCity { get; set; }
        String custBranchSNo { get; set; }
        String CustLoginId { get; set; }
        String AirlineCode { get; set; }
        String AirlineName { get; set; }
        String FlightNo { get; set; }
        DateTime FlightDate { get; set; }
        String HAWBNo { get; set; }
        String MAWBNo { get; set; }
        String Origin { get; set; }
        String Destination { get; set; }
        Decimal VolWt { get; set; }
        Decimal GrWt { get; set; }
        Decimal ChWt { get; set; }
        String FreightType { get; set; }
        DateTime ShipmentDate { get; set; }
        String ShipmentType { get; set; }
        String Commodity { get; set; }
        Decimal CPP { get; set; }
        String Pickup { get; set; }
        DateTime PickupDate { get; set; }
        String PickupTime { get; set; }
        String PickupStreet { get; set; }
        String PickupLocation { get; set; }
        String PickupCity { get; set; }
        String PickupState { get; set; }
        String PickupZip { get; set; }
        String OriginClearance { get; set; }
        String DestinationClearance { get; set; }
        String Delivery { get; set; }
        DateTime DeliveryDate { get; set; }
        String DeliveryTime { get; set; }
        String DeliveryStreet { get; set; }
        String DeliveryLocation { get; set; }
        String DeliveryCity { get; set; }
        String DeliveryState { get; set; }
        String DeliveryZip { get; set; }
        String AirFreight { get; set; }
        String ShipperStreet { get; set; }
        String ShipperLocation { get; set; }
        String ShipperCity { get; set; }
        String ShipperState { get; set; }
        String ShipperZip { get; set; }
        String ConsigneeStreet { get; set; }
        String ConsigneeLocation { get; set; }
        String ConsigneeCity { get; set; }
        String ConsigneeState { get; set; }
        String ConsigneeZip { get; set; }
        String Consolidate { get; set; }
        Int32 JobEstId { get; set; }
        Int32 BillId { get; set; }
        String AddedBy { get; set; }
        DateTime AddedDate { get; set; }
        String UpdatedBy { get; set; }
        DateTime UpdatedDate { get; set; }

        Int32 BConfId { get; set; }
        Int32 ChargeId { get; set; }
        Decimal BuyingAmount { get; set; }
        Decimal SellingAmount { get; set; }
        String Unit { get; set; }
        String Currency { get; set; }
        int CompBrSNo { get;set;}
        String Name { get; set; }
        String Address { get; set; }
        String PAN_No { get; set; }
        Int32  BookingRefNo { get; set; }
        Int32 RISno { get; set; }
        String Mode { get; set; }
        Decimal  Rate { get; set; }
        Decimal Amount { get; set; }
        String ChequeName { get; set; }
        Char Type { get; set; }
        Int32? ShipperCustBrSno { get; set; }
        Int32? ConsigneeCustBrSno { get; set; }
        String ChargesOnWeight { get; set; }
        String BankName1 { get; set; }
       String Branch1 { get; set; }
     String ChequeNumber1 { get; set; }
       String ChequeIssuedBy1 { get; set; }
       Decimal Rupees1 { get; set; }
        Decimal Paise1 { get; set; }
        String AccountNo1 { get; set; } 
        Int32 BCSNo { get; set; }
        String AWBNO { get; set; }
        Decimal UsedAmt { get; set; }
        String LimitType { get; set; }
        Int32 custMastSno { get; set; }
        Int32 custBrSno { get; set; }
        Int32 compBrSno { get; set; }
        String transactionType { get; set; }
        Decimal amount { get; set; }
        Decimal creditLimit { get; set; }
        Decimal usedCrLimitBeforeTransaction { get; set; }
        Decimal usedCrLimitAfterTransaction { get; set; }
        Decimal availableCrLimitBeforeTransaction { get; set; }
        Decimal availableCrLimitAfterTransaction { get; set; }
        String creditType { get; set; }
        String updatedBy { get; set; }
        Int32 bookingSno { get; set; }
        Int32 billingSno { get; set; }
        Int32 paymentTransSno { get; set; }
        Int32 paymentMastSno { get; set; }
    }
}
