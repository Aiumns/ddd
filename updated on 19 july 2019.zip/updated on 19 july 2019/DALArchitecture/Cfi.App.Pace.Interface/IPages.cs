using System;
using System.Collections.Generic;
using System.Text;

namespace Cfi.App.Pace.Interface
{
  public interface IPages
    {
        Int32 SNo { get;set;}
        String PageName { get;set;}
        String Hyperlink { get;set;}
        String ShowInMenu { get;set;}
        Int32 PagePriority { get;set;}
        String Header { get;set;}
        Int32 HeaderSNo { get;set;}
        String GroupAccess { get;set;}
        Char MultiCity { get;set;}

        String GroupType { get; set; }
        String UserName { get;set;}
        String UserID { get;set;}
        String LoginType { get;set;}
        String Allowed { get;set;}
        String PageGroup { get;set;}
        String PageHelp { get;set;}
        Int32 PageSNo { get; set; }
        String Name { get; set; }
        Int32 MenuSNo { get; set; }
        Int32 DisplayOrder { get; set; }
        Int32 LoginSNo { get; set; }
      
        String DisplayName { get; set; }
        Int32 CHASNO { get; set; }
        String GroupName { get; set; }
        String Pagesno1 { get; set; }
        Int32 GroupSNo { get; set; }

        
        
       
         
        
       
    }
}
