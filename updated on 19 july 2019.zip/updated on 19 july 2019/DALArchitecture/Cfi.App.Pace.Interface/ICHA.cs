﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Cfi.App.Pace.Interface
{
    public interface ICHA
    {
        String CompBrSNo { get; set; }      
        String Login_Id { get; set; }
        String LoginUser { get; set; }        
        String Password { get; set; } 
        String Street { get; set; }
        String Place { get; set; }
        String City { get; set; }
        String State { get; set; }
        String CountryCode { get; set; }
        String PostCode { get; set; }
        String Phone { get; set; }
        String MobileNo { get; set; }
        String FAX { get; set; }
        String Email { get; set; }
        String PANNo { get; set; }       
        String EnteredBy { get; set; }
        String Active { get; set; }
        String CHAName { get; set; }
        String WebSite { get; set; }
        String   UserName{ get; set; }
         String  DisplayName { get; set; }
         String  UserGroup { get; set; }
         String  EmailID { get; set; }        
         String  BrSno { get; set; }
         String  Sno { get; set; }
         String CHASno { get; set; }
         String HouseNo { get; set; }
         Int32 BookRefNo{get;set;}
         String AppRemark{get;set;}
         Decimal TotalAmt { get; set; }
         String Status{get;set;}

        Int32 CHAChargeSno {get;set;}
        Int32 ChargeId {get;set;}
        String Remark {get;set;}
        Decimal Amount { get; set; }
        Decimal GrandTotal { get; set; }
        DateTime BookingDate { get; set; }
        DateTime AWBDate { get; set; }
       
    }
}
