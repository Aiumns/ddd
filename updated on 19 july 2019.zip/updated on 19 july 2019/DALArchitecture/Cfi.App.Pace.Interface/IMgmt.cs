﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cfi.App.Pace.Interface
{
    public interface IMgmt
    {
        Int64 HoSno { get; set; }
        Int64 CompBrSno { get; set; }
        DateTime Date { get; set; }
        String CompanyName { get; set; }
        Int64 CHASno { get; set; }
        String CHAChargeStatus { get; set; }
    }
}
