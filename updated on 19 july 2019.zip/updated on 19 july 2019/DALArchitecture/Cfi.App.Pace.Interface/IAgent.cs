using System;
using System.Collections.Generic;
using System.Text;

namespace Cfi.App.Pace.Interface
{
    public interface IAgent
    {
        Int32 loginSno { get; set; }
        Int32 SNo { get;set;}
        String AgentCode { get;set;}
        String AgentName { get;set;}
        String AgentType { get;set;}
        String Password { get;set;}
        String Active { get;set;}
        String Place { get;set;}
        String bill { get; set; }

        String CustomerName { get;set;}
        String CustomerType { get;set;}
        String GSASNo { get;set;}
        Decimal CreditLimit { get;set;}
        String ApprovalCode { get;set;}
        String IATANo { get;set;}
        String PANNo { get;set;}
        Decimal TDSRate { get;set;}
        Decimal SurchargeRate { get;set;}
        Decimal ExemptionLimit { get;set;}
        DateTime EffectiveDate { get;set;}
        String City { get;set;}
        String PlanName { get;set;}
        Decimal StandardDiscount { get;set;}
        Decimal MaxLimit { get;set;}
        String PrintBy { get;set;}
        Decimal BankGuarantee { get;set;}
        String MTD { get;set;}
        String MobileNo { get;set;}
        DateTime EnteredDate { get;set;}
        String EnteredBY { get;set;}
        String AutoStock { get;set;}
        String PaymentMode {get;set;}
        Int32 CustomerSNo { get;set;}
        String  BillingCycle { get;set;}
        DateTime ValidFrom { get;set;}
        DateTime ValidTo { get;set;}
        String FlagCustType { get;set;}
        Decimal Amount { get;set;}
        DateTime Date { get;set;}
        String BankName { get;set;}
        String BankAdd { get;set;}
        String EnteredByBank { get;set;}
        String Currency { get;set;}
       
        String CustomerLoginId { get;set;}
        String Address { get;set;}
        String CustCareCity { get;set;}
        String Website { get;set;}
        String Email { get;set;}
        String Fax { get;set;}
        String Phone { get;set;}
        String Adcode { get;set;}
        String IECNo { get;set;}
        String BankAccNo { get;set;}
        String CLApprovedBy { get;set;}
        DateTime CLApprovedAt { get;set; }
        DateTime CreditReviewDate { get;set;}
        Decimal StandardDeal { get;set;}
        String DeliveryStatus { get;set;}
        String ContactName { get;set;}
        String ContactDesign { get;set;}
        String ContactDept { get;set;}
        String ContactAdd { get;set;}
        String ContactPhone { get;set;}
        String ContactMobile { get;set;}
        String ContactEmail { get;set;}
        DateTime DOB{get;set;}
        DateTime DOA{get;set;}
        String BalSheet2Years1 { get;set;}
        String BalSheet2YearsDesc { get;set;}
        String BankConfirmLetter { get;set;}
        String BankConfirmLetterDesc { get;set;}
        String MarketReport { get;set;}
        String MarketReportDesc { get;set;}
        String MRApprovedByName { get;set;}
        Int32 CreditPeriod { get;set;}
        Decimal RateOfInterest { get;set;}
        DateTime BGDate { set;get; }
        DateTime BGClaimPeriod { set;get;}
        DateTime EnteredAt { get;set;}
        String Flagmainbranch { get;set;}
        String StreetName { get;set;}
        String Town { get;set;}
        String State { get;set;}
        String PinCode { get;set;}
        Decimal GroupCreditLimit { get;set;}
        String ModifiedBy { get;set;}
        DateTime ModifiedDate { get;set;}
        String Flaggroup { get;set;}
        String NetworkGroupSno { get;set;}
        Int32 StarRating { get;set;}
        String LoginId { get;set;}
        String CountryCode {get;set;}       
       
        String BankAddress {get;set;}
        String ApplicantName {get;set;}
        String LegalStatus {get;set;}
        String ROCRegnNo {get;set;}
        String SalesPersonName {get;set;}
        String IndustryType {get;set;}
        String CustomerPremises {get;set;}
        String PartnerName1 {get;set;}
        String PartnerAddress1 {get;set;}
        String OtherTradeName1  {get;set;}
        String PartnerName2  {get;set;}
        String PartnerAddress2 {get;set;}
        String OtherTradeName2 {get;set;}
        String PartnerName3 {get;set;}
        String PartnerAddress3 {get;set;}
        String OtherTradeName3 {get;set;}
        decimal AnnualSales {get;set;}
       int NoOfEmployee {get;set;}
       String LargestCustomerName1 {get;set;}
       String LargestCustomerName2 {get;set;}
        int OrgBusinessYear {get;set;}
       String  OthBisPremiseLocation1 {get;set;}
        String OthBisPremiseType1 {get;set;}
        String OthBisPremiseFacility1 {get;set;}
        String OthBisPremiseLocation2 {get;set;}
        String OthBisPremiseType2 {get;set;}
        String OthBisPremiseFacility2 {get;set;}
        String OthBisPremiseLocation3 {get;set;}
        String OthBisPremiseType3 {get;set;}
        String OthBisPremiseFacility3 {get;set;}
        String OthBisPremiseLocation4 {get;set;}
        String OthBisPremiseType4 {get;set;}
        String OthBisPremiseFacility4 {get;set;}
        String OthBisPremiseLocation5 {get;set;}
        String OthBisPremiseType5 {get;set;}
        String OthBisPremiseFacility5 {get;set;}
        String OthBisPremiseLocation6 {get;set;}
        String OthBisPremiseType6 {get;set;}
        String OthBisPremiseFacility6 {get;set;}
        String OthForwarder1 {get;set;}
        decimal OutstandingAmt1 {get;set;}
        String OthForwarder2 {get;set;}
        decimal OutstandingAmt2 {get;set;}
        String OthForwarder3 {get;set;}
        decimal OutstandingAmt3 {get;set;}
        String OthForwarder4 {get;set;}
        decimal OutstandingAmt4 {get;set;}
        String OthForwarder5 {get;set;}
        decimal OutstandingAmt5 {get;set;}
        String OthForwarder6 {get;set;}
        decimal OutstandingAmt6 {get;set;}
        decimal MonthlyBilling {get;set;}
        decimal MonthlyVolume {get;set;}
        decimal CreditLimitReq {get;set;}
        int CreditPeriReq {get;set;}
        String Status	{get;set;}
        String ApprovedBy {get;set;}
        DateTime ApprovedAt {get;set;}
        String AccountsRemarks { get;set;}
        String CustomerRemarks { get; set; }
        String NetworkGroupPriority { get;set;}
        String CityCode { get;set;}
        Int32 CompSno{get;set;}
        Int32 CompBrSno{get;set;}
        String loginFlag {get;set;}
        Int32 NetworkAgentCitySno { get;set;}
        //String Address { get;set;}
        String RequestedBy { get; set;}
        Int32 InvoiceCreditPeriod { get; set; }
        String ServiceTaxNo { get; set; }
        String TanNo { get; set; }
        String TinNo { get; set; }
        String GroupCustomer { get; set; }
        String ApprovalType { get; set; }
        String SalesRemarks { get; set; }

        String LoginPassword { get; set; }
        String LoginCompSNo { get; set; }
        String LoginDisplayName { get; set; }
        String LoginEmailID { get; set; }
        String AdCode { get; set; }
        String Bill { get; set; }
        String CustomerCareCity { get; set; }
        String EnteredBy { get; set; }
        String hdnCustType { get; set; }
        String IataNo { get; set; }
        String IsOscCalCulated { get; set; }
        String Mobile { get; set; }
        String PanNo { get; set; }
        String PhoneNo { get; set; }
        String Street { get; set; }
        Int32 CustBrSno { get; set; }
        Int32 custMastSno { get; set; }
        Int32 CustomerBusinessTypeSno { get; set; }
        Int32 NetWorkAgentCitySno { get; set; }
        Int32 SalesPersonSno { get; set; }
        Int32 flag { get; set; }
        String entryType { get; set; }
        bool isOscCal { get; set; }
        // bool IsOscCalCulatedPace { get; set; }
        Int32 BrSno { get; set; }
        decimal CreditLimitPace { get; set; }
    }
}
