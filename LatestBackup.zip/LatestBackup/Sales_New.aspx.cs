using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Xml;
using System.Globalization;
public partial class Booking_Edit : System.Web.UI.Page
{
    #region Summary
    decimal total = 0;
    /// <summary>
    /// <class>Sales</class>
    /// <class>Sales Edit</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Rajinder Singh Lamba</createdBy>
    /// <createdOn>DEC 22, 2007</createdOn>
    /// <modifications>
    ///		<modification>
    ///			<changeDescription></changeDescription>
    ///			<modifiedBy>Rajinder Singh Lamba</modifiedBy>
    ///			<modifiedOn>FEB 23, 2008</modifiedOn>
    ///		</modification>
    /// </modifications>			
    /// </summary>		
    #endregion
    //bool IsExemption = false;
    //DisplayWrap dw = new DisplayWrap();    
    //SqlConnection con;
    //SqlCommand com;
    //SqlCommand cmd;
    //string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    public string calendarControl = "";   
    public string strCity = "";
    DataTable dtTemp = null;
    DataTable dtCarr = null;
    DisplayWrap obj = new DisplayWrap();   
    protected void Page_Load(object sender, EventArgs e)
    {
         ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;         
         if(!IsPostBack)
           {
              maketable();               
           }
    }   
    public void maketable()
    {
        dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Route";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Currency";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dtTemp.Rows.Add(dr);
        Session["dtTemp"] = dtTemp;
        ViewState["dtBeginCharges"] = dtTemp;

        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();

        //dc1 = new DataColumn();
        //dc1.ColumnName = "Origin_Code";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "Destination_code";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "rate";
        //dc1.DataType = System.Type.GetType("System.Decimal");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "flight_no";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "flight_date";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);

        //dc1 = new DataColumn();
        //dc1.ColumnName = "Carrier";
        //dc1.DataType = System.Type.GetType("System.String");
        //dtTemp.Columns.Add(dc1);       
    }
    public DataTable GetCarrLoad()
    {
        dtCarr = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtCarr.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "CarrierCode";
        dc1.DataType = System.Type.GetType("System.String");
        dtCarr.Columns.Add(dc1);


        DataRow dr = dtCarr.NewRow();
        dr[0] = 1;
        dr[1] = "jitendra";
        dtCarr.Rows.Add(dr);

        DataRow dr2 = dtCarr.NewRow();        
        dr2[1] = "Manish";
        dtCarr.Rows.Add(dr2);
        Session["Carrdll"] = dtCarr;
        return dtCarr;
    }
    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            //lblmsg.Visible = true;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        else
        {
            //lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
    }
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();                
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            ///////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
        }
        else
        {
            maketable();
            DataTable dtBeginCharges = (DataTable)ViewState["dtBeginCharges"];
            Session["dtTemp"] = dtBeginCharges;
            grdCal.DataSource = dtBeginCharges;
            grdCal.DataBind();
        }
    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];        
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        string L = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text;       
        string Currency = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("DropDownList1")).SelectedValue;
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = L;              
                dr[2] = Currency;                
            }
        }
        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();
    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();
                //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames                
                string L = ((TextBox)grdCal.FooterRow.FindControl("txtl")).Text;
                string Currency = ((DropDownList)grdCal.FooterRow.FindControl("DropDownList1")).SelectedValue;               
                dr[1] = L;
                dr[2] = Currency;
                dt.Rows.Add(dr);
                Session["dtTemp"] = dt;
                grdCal.DataSource = dt;
                grdCal.DataBind();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }
    protected void grdCal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && grdCal.EditIndex == e.Row.RowIndex)
        {
            DropDownList DropDownList1 = (DropDownList)e.Row.FindControl("DropDownList1");
            DropDownList1.DataSource = obj.GetAllFromQuery("select top 10 SNo,CityCode,CityName as CarrierCode  from CityMaster");
            DropDownList1.DataTextField = "CarrierCode";
            DropDownList1.DataValueField = "CarrierCode";
            DropDownList1.DataBind();
            string Carrier = (e.Row.DataItem as DataRowView)["Currency"].ToString();
            DropDownList1.Items.FindByValue(Carrier).Selected = true;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {            
            DropDownList DropDownList1 = (DropDownList)e.Row.FindControl("DropDownList1");
            DropDownList1.DataSource = obj.GetAllFromQuery("select top 10 SNo,CityCode,CityName as CarrierCode  from CityMaster");
            DropDownList1.DataTextField = "CarrierCode";
            DropDownList1.DataValueField = "CarrierCode";
            DropDownList1.DataBind();
            //Add Default Item in the DropDownList.
            DropDownList1.Items.Insert(0, new ListItem("Please select"));
        }
    }
    protected void grdCal_DataBound(object sender, EventArgs e)
    {

    }
}
