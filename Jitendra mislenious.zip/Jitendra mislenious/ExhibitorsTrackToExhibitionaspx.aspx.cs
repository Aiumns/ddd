﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Xml;
using System.Globalization;
public partial class Cargo_ExhibitorsTrackToExhibitionaspx : BasePage
{
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        maketable();
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
    public void maketable()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Communication";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "SalesPersonSno";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Remarks";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        

        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
        ViewState["dtBeginCharges"] = dtTemp;
    }

    public void fillVolumeDimension(string Id)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            //////strQuery = "select * from Sales_Trans where Stock_id = '" + Id + "'";
            DisplayWrap de = new DisplayWrap();
            DataTable dttrans = de.GetAllFromQuery("Select stock_id from Sales where sales_id=" + Id + " ");
            if (dttrans.Rows.Count > 0)
            {
                strQuery = "select convert(varchar,Date,103) as Date, * from ExhibitorsCommunication  where sno=" + dttrans.Rows[0]["Sno"].ToString();
            }
        }
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = tableVolumewt();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            ////if (dr["Measurement_Unit"].ToString() != "" || dr["Measurement_Unit"].ToString() != null)
            ////    rbCal.SelectedValue = dr["Measurement_Unit"].ToString();
            dw = dt.NewRow();
            dw[0] = i++;

            string len = dr["Communication"].ToString();
            string width = dr["Date"].ToString();
            string Height = dr["SalesPersonSno"].ToString();

            string l = dr["Communication"].ToString();
            string w = dr["Date"].ToString();
            string h = dr["SalesPersonSno"].ToString();

            ////decimal l = System.Math.Round(decimal.Parse(len), MidpointRounding.AwayFromZero);
            ////decimal w = System.Math.Round(decimal.Parse(width), MidpointRounding.AwayFromZero);
            ////decimal h = System.Math.Round(decimal.Parse(Height), MidpointRounding.AwayFromZero);

            dw[1] = l;
            dw[2] = w;
            dw[3] = h;
            dw[4] = dr["Remarks"].ToString();
            

            dt.Rows.Add(dw);

        }
        if (dt.Rows.Count > 0)
        {
            grdCal.DataSource = dt;
            grdCal.DataBind();
            Session["dtTemp"] = dt;
        }
        else
        {
            Session["dtTemp"] = null;
            maketableVolumewt();
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        con.Close();
    }

    public void maketableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Communication";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "SalesPersonSno";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Remarks";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

       


        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
       
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
    }

    public DataTable tableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Communication";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "SalesPersonSno";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Remarks";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        Session["dtTem"] = dtTemp;
        return dtTemp;
    }
    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        else
        {
            lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }

    }
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                ////int Pieces = 0;
                ////decimal VoulmeWt = 0;
                ////foreach (DataRow rw in dt.Rows)
                ////{
                ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                ////}
                ////str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                ////txtPieces.Text = Pieces.ToString();
                ////if (txtGw.Text != "")
                ////{
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////    if (decimal.Parse(txtGw.Text) > VoulmeWt)
                ////    {
                ////        txtCw.Text = txtGw.Text;
                ////    }
                ////    else
                ////    {
                ////        txtCw.Text = VoulmeWt.ToString();
                ////    }
                ////}
                ////else
                ////{
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////}
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            ///////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
        }
        else
        {
            maketable();
            DataTable dtBeginCharges = (DataTable)ViewState["dtBeginCharges"];
            Session["dtTemp"] = dtBeginCharges;
            grdCal.DataSource = dtBeginCharges;
            grdCal.DataBind();
        }


    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        //string [] Key = {"SNo"}; 
        //grdCal.DataKeyNames = Key;
        //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames
        // int SNo = Convert.ToInt16(((TextBox)grdCal.FindControl("txtSNo")).Text);

        /////Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text);
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        //string L = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text;
        string W = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtw")).Text;
        string H = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txth")).Text;
        decimal P = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtp")).Text);

        //string fltno = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtfltno")).Text;

        //string fltdt = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtfltdt")).Text;

        string Carrier = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlcarr")).SelectedValue;

        string Salesperson = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlsales")).SelectedValue;

        //string Currency = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlCurr")).SelectedValue;
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                //dr[1] = L;
                dr[2] = W;
                dr[3] = Salesperson;
                dr[4] = P;
                //dr[5] = fltno;
                //dr[6] = fltdt;
                dr[1] = Carrier;
                //dr[8] = Currency;
                //////dt.Rows.Add(dr);
            }
        }


        // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

        // Calculatin Volume Wait
        ////decimal Volume_Wt;

        ////if (rbCal.SelectedValue == "Cm")
        ////{
        ////    Volume_Wt = (L * W * H * P) / 6000;
        ////}
        ////else
        ////{
        ////    Volume_Wt = (L * W * H * P) / 366;

        ////}
        ////foreach (DataRow dr in dt.Rows)
        ////{
        ////    if (dr["SNo"].ToString() == SNo.ToString())
        ////    {
        ////        dr[1] = L;
        ////        dr[2] = W;
        ////        dr[3] = H;
        ////        dr[4] = P;
        ////        dr[5] = Math.Round(Volume_Wt, 3);
        ////    }
        ////}

        //////txtVolWt.Value = Convert.ToString(Math.Round(Volume_Wt, 2));
        ////if (txtGw.Text != "")
        ////{
        ////    Volume_Wt = Math.Round(Volume_Wt, 3);
        ////    txtVolwt.Text = Volume_Wt.ToString();
        ////    if (decimal.Parse(txtGw.Text) > Volume_Wt)
        ////    {
        ////        txtCw.Text = txtGw.Text;
        ////    }
        ////    else
        ////    {
        ////        Volume_Wt = Math.Round(Volume_Wt, 3);
        ////        txtCw.Text = Volume_Wt.ToString();
        ////    }
        ////}
        ////else
        ////{
        ////    Volume_Wt = Math.Round(Volume_Wt, 3);
        ////    txtVolwt.Text = Volume_Wt.ToString();
        ////}
        //ViewState["Volume_Wt"] = Convert.ToString(Math.Round(Volume_Wt, 2));
        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();

        ////int Pieces = 0;
        ////decimal VoulmeWt = 0;
        ////foreach (DataRow rw in dt.Rows)
        ////{
        ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
        ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
        ////}
        ////string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
        ////txtPieces.Text = Pieces.ToString();
        ////VoulmeWt = Math.Round(VoulmeWt, 3);
        ////txtVolwt.Text = VoulmeWt.ToString();
        /////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();                
                string Carrier = ((DropDownList)grdCal.FooterRow.FindControl("ddlcarr")).SelectedItem.Text;
                string W = ((TextBox)grdCal.FooterRow.FindControl("txtw")).Text;
                string salesperson = ((DropDownList)grdCal.FooterRow.FindControl("ddlsales")).SelectedValue;                       
                string P = Convert.ToString(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);

                //by jj
                ////Determine the RowIndex of the Row whose Button was clicked.
                //int rowIndex = Convert.ToInt32(e.CommandArgument);
                ////Reference the GridView Row.
                //GridViewRow row = grdCal.Rows[rowIndex];
                ////Fetch value of Name.
                //string name = (row.FindControl("txtw") as TextBox).Text;
                //End

                //dr[2] = W;
                //dr[3] = salesperson;
                //dr[4] = P;
                ////dr[5] = fltno;
                ////dr[6] = fltdt;
                //dr[1] = Carrier;
                //////dr[8] = Currency;
                //dt.Rows.Add(dr);

                //Session["dtTemp"] = dt;
                //grdCal.DataSource = dt;
                //grdCal.DataBind();


                ////string fltno = ((TextBox)grdCal.FooterRow.FindControl("txtfltno")).Text;
                ////string fltdt = ((TextBox)grdCal.FooterRow.FindControl("txtfltdt")).Text;
                
               

               ///// string Currency = ((DropDownList)grdCal.FooterRow.FindControl("ddlCurr")).SelectedValue;
                // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

                // Calculatin Volume Wait
                ////decimal Volume_Wt;
                ////if (rbCal.SelectedValue == "Cm")
                ////{
                ////    Volume_Wt = (L * W * H * P) / 6000;
                ////}
                ////else
                ////{
                ////    Volume_Wt = (L * W * H * P) / 366;
                ////}


                //Prepare the Insert Command of the DataSource control
                //dr[1] = L;
               
                ////int Pieces = 0;
                ////decimal VoulmeWt = 0;
                ////foreach (DataRow rw in dt.Rows)
                ////{
                ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                ////}
                ////string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                ////txtPieces.Text = Pieces.ToString();
                ////if (txtGw.Text != "")
                ////{
                ////    VoulmeWt = Math.Round(VoulmeWt, 3);
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////    if (decimal.Parse(txtGw.Text) > VoulmeWt)
                ////    {
                ////        txtCw.Text = txtGw.Text;
                ////    }
                ////    else
                ////    {
                ////        VoulmeWt = Math.Round(VoulmeWt, 3);
                ////        txtCw.Text = VoulmeWt.ToString();
                ////    }
                ////}
                ////else
                ////{
                ////    VoulmeWt = Math.Round(VoulmeWt, 3);
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////}

                //ViewState["Volume_Wt"]=VoulmeWt.ToString();
                ////Session["dtTemp"] = dt;
                ////grdCal.DataSource = dt;
                ////grdCal.DataBind();
                ///////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;

                //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Order added successfully');</script>");
                //string s1 = "SELECT Fltno,hh,mm,fltdate,id FROM ac_fltDetails_tran ORDER BY fltno";
                //AccessDataSource1.SelectCommand = s1;


                //GridViewRow gv = GridView2.Rows[0];
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;

                //fill();


            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }
    protected void lnkCal_Click(object sender, EventArgs e)
    {
        grdCal.Visible = true;
        /////rbCal.Visible = true;
    }
    protected void grdCal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && grdCal.EditIndex == e.Row.RowIndex)
        {
            //Label ddlcarr = (e.Row.FindControl("lblcarr") as Label);
            DropDownList ddlcarr = (e.Row.FindControl("ddlsales") as DropDownList);
            ddlcarr.DataSource = GetData("select distinct DisplayName as SalespersonSno from Login where LoginType='SALES-PERSON' and Active='Y' order by DisplayName");
            ddlcarr.DataTextField = "SalespersonSno";
            ddlcarr.DataValueField = "SalespersonSno";
            //ddlcarr.DataBind();
            //Add Default Item in the DropDownList.
            // Label lblcarr = (e.Row.FindControl("lblcarr") as Label);
            // HiddenField hfStatus = (e.Row.FindControl("hfcarr") as HiddenField);
            // string selectedCarrier = (e.Row.FindControl("lblcarr") as Label).Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            string Carrier = (e.Row.DataItem as DataRowView)["SalespersonSno"].ToString();
            ddlcarr.Items.FindByValue(Carrier).Selected = true;


            //Bind Currency
            ////DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            ////ddlcarrency.DataSource = GetData("select Sno,CurrencyCode from CurrencyMaster order by CurrencyCode");
            ////ddlcarrency.DataTextField = "CurrencyCode";
            ////ddlcarrency.DataValueField = "CurrencyCode";
            ////ddlcarrency.DataBind();
            // ddlcarrency.Items.Insert(0, new ListItem("Please select"));
            //Add Default Item in the DropDownList.
            //string selectedcurrency = (e.Row.FindControl("ddlCurr") as DropDownList).SelectedItem.Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            //ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;
            ////string selectedcurrency = (e.Row.DataItem as DataRowView)["Currency"].ToString();
            ////ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;

            /////////
            ////total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//
            ////txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList ddlcarr = (e.Row.FindControl("ddlsales") as DropDownList);
            ddlcarr.DataSource = GetData("select distinct DisplayName as SalespersonSno from Login where LoginType='SALES-PERSON' and Active='Y' order by DisplayName");
            ddlcarr.DataTextField = "SalespersonSno";
            ddlcarr.DataValueField = "SalespersonSno";
            ddlcarr.DataBind();

            //string Carrier = (e.Row.FindControl("ddlcarr") as DropDownList).SelectedItem.Text;
            //ddlcarr.Items.FindByValue(Carrier).Selected = true;
            //Add Default Item in the DropDownList.
           // ddlcarr.Items.Insert(0, new ListItem("Please select"));


            //Bind Currency
            //DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            //ddlcarrency.DataSource = GetData("select Sno,CurrencyCode from CurrencyMaster order by CurrencyCode");
            //ddlcarrency.DataTextField = "CurrencyCode";
            //ddlcarrency.DataValueField = "CurrencyCode";
            //ddlcarrency.DataBind();
            //ddlcarrency.Items.Insert(0, new ListItem("Please select"));

            ///////////
            //total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//Convert.ToInt32(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);;//
            //txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }

    }
    #region Insert_BookingDimesion
    public void Insert_BookingDimesion(SqlTransaction tr, SqlConnection con, long SalesID)
    {
        //string insert;
        ////con = new SqlConnection(strCon);
        //DataTable dtDimension = new DataTable();
        //if (Session["dtTemp"] != null)
        //{
        //    dtDimension = (DataTable)Session["dtTemp"];

        //    for (int i = 0; i < dtDimension.Rows.Count; i++)
        //    {

        //        insert = "insert into Sales_Dimensions(Sales_ID,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit) values(@Sales_ID,@No_of_Packages,@Length,@Breadth,@Height,@Total,@Measurement_Unit)";

        //        SqlCommand com = new SqlCommand(insert, con, tr);
        //        com.CommandType = CommandType.Text;
        //        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        //        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
        //        com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
        //        com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
        //        com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
        //        com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
        //        if (rbCal.SelectedValue == "")
        //        {
        //            com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = "CM";
        //        }
        //        else
        //        {
        //            com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = rbCal.SelectedValue;
        //        }
        //        com.ExecuteNonQuery();
        //    }
        //}
    }
    #endregion
    #region Update_BookingDimesion
    public void Update_BookingDimesion(SqlTransaction tr, SqlConnection con, long SalesID)
    {
        string update;

        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {
            dtDimension = (DataTable)Session["dtTemp"];

            for (int i = 0; i < dtDimension.Rows.Count; i++)
            {


                update = "update ExhibitorsCommunication set ExbitorSno=@ExbitorSno,Communication=@Communication,Date=@Date,SalesPersonSno=@SalesPersonSno,Remarks=@Remarks where sno=@Sno";

                SqlCommand com = new SqlCommand(update, con, tr);
                com.CommandType = CommandType.Text;
                ////com.Parameters.Add("@Sales_Dimension_ID", SqlDbType.Int).Value = SalesID;
                com.Parameters.Add("@ExbitorSno", SqlDbType.BigInt).Value = SalesID;
                com.Parameters.Add("@Communication", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
                com.Parameters.Add("@Date", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
                com.Parameters.Add("@SalesPersonSno", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
                com.Parameters.Add("@Remarks", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
                
                ////if (rbCal.SelectedValue == "")
                ////{
                ////    com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = "CM";
                ////}
                ////else
                ////{
                ////    com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = rbCal.SelectedValue;
                ////}
                com.ExecuteNonQuery();

            }
        }
    }
    #endregion


    private DataSet GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;
                sda.SelectCommand = cmd;
                using (DataSet ds = new DataSet())
                {
                    sda.Fill(ds);
                    return ds;
                }
            }
        }
    }
}