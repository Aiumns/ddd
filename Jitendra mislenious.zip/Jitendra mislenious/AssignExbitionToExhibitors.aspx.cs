﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Cfi.App.Pace.Business;
using Cfi.App.Pace.Data;
using System.Text;
using Cfi.App.CRM.Business;
using System.Net.Mail;
using System.Net;
using System.IO;
public partial class Cargo_AssignExbitionToExhibitors : BasePage
{
    //string Agent = "";
    int Exhibitions = 0;   
    //string CityDest = "";
    DisplayWrap dw = new DisplayWrap();
    string strCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    //string SnoFromExbArabPlast = "";
    bool Flag;
    protected void Page_Load(object sender, EventArgs e)
    {       
        //btnsubmit.Attributes.Add("onclick", "return checkgridcontrols();return false;");
        if (Session["EMailID"] == null)
        {
           Response.Redirect("Login.aspx");
        }
        else
        {            
            if (!IsPostBack)
            {
                   LoadExName();
                   fillSalesPerson();   
                   string SnoFromExbArabPlast = Convert.ToString(HttpUtility.UrlDecode(Request.QueryString["SnoFromArabPlast"]));
                   ViewState["SnoFromExbArabPlast"] = Convert.ToString(HttpUtility.UrlDecode(Request.QueryString["SnoFromArabPlast"]));
                   if (string.IsNullOrEmpty(SnoFromExbArabPlast) == false)
                   {
                       ////////LoadExbitor();
                       ddlExhibitions.SelectedIndex = ddlExhibitions.Items.IndexOf(ddlExhibitions.Items.FindByValue(SnoFromExbArabPlast));
                       int selectevalue = Convert.ToInt32(ddlExhibitions.SelectedItem.Value);
                       LoadExhibitorByExhibition(selectevalue);
                   }
                   else
                   {
                       btnsubmit.Visible = false;
                       btncancel.Visible = false;    
                   }
                  txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");           
            }
        }
    }
    private string PopulateBody(string Salesperson,string Exbitionname,string addedRow)
    {
        string body = string.Empty;
        using (StreamReader reader = new StreamReader(Server.MapPath("~/Cargo/EmailBody.htm")))
        {
            body = reader.ReadToEnd();
        }
        body = body.Replace("exbname", Exbitionname);
        body = body.Replace("{SalesName}", Salesperson);     
        body = body.Replace("<tr></tr>", addedRow);
        return body;
    }   

    public void SendMail(string body,string salespersonname)
    {
        
        DataTable dtsalesperson = dw.GetAllFromQuery("Select emailId from login where displayname='" + salespersonname + "'");
        if (dtsalesperson.Rows.Count > 0)
        {
            string email = dtsalesperson.Rows[0]["EmailId"].ToString();
            MailMessage mail = new MailMessage();
            mail.IsBodyHtml = true;
            mail.From = new MailAddress("ddalal@cargoflash.com");
            mail.To.Add(email);
            mail.CC.Add("bhuwan.fulara@reliablecargo.in,ceo@reliablecargo.in,ddalal@cargoflash.com");
            ////mail.To.Add("ddalal@cargoflash.net");
           
            //mail.To.Add("jjayswal@cargoflash.net");
            //mail.Bcc.Add("jjayswal@cargoflash.net");
            //mail.Attachments.Add(new Attachment(filepath));
            mail.Subject = "Assigned Exhibitor Details with Exhibition";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = System.Net.Mail.MailPriority.High;
            mail.Body = body;
            try
            {
                SmtpClient smtp = new SmtpClient("mail.cargoflash.com");
                smtp.Credentials = new NetworkCredential("test@cargoflash.net", "Admin$567");
                smtp.Send(mail);
               
            }
            catch
            {

            }
            finally
            {

            }
        }
        
    }

    void LoadExName()
    {
        try
        {
            string strExbName = "select distinct Sno,Exname from FairDetails_Ex where ISNULL(Exname,'')!='' order by sno desc";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand cmdiner = new SqlCommand(strExbName, con);
            SqlDataReader dr;
            dr = cmdiner.ExecuteReader();
            ddlExhibitions.Items.Clear();
            ddlExhibitions.Items.Insert(0, "- -Select- -");
            ddlExhibitions.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlExhibitions.Items.Add(new ListItem(dr["Exname"].ToString(), dr["Sno"].ToString()));
            }
            con.Close();
        }
        catch (Exception)
        {
            throw;
        }
    }

    void LoadExbitor(int ExhSnos)
    {
        try
        {
            con = new SqlConnection(strCon);
            con.Open();
            /////string StrAgent = "select * from ExhibitorsList order by sno desc";
            string StrAgent = "select * from ExhibitorsList where ExhibitionSno=" + ExhSnos + " order by Exbname";
            SqlDataAdapter sda = new SqlDataAdapter(StrAgent, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            sda.Dispose();
            con.Close();
        }
        catch (Exception)
        {
            
            throw;
        }
    }

    void LoadExhibitorByExhibition(int Exhibitions)
    {
        try
        {
            string[] strsss;
            string[] strsales;
            GridView1.Visible = true;
            lblExhibitorname.Visible = true;
            //Exhibitions = Convert.ToInt32(ddlExhibitions.SelectedValue);
            btncancel.Visible = true;
            LoadExbitor(Exhibitions);
            DataTable dtAssignExbToExhibitors = dw.GetAllFromQuery("select ExbSno,ExhibitorSno,SalesPerson from AssignExbToExhibitors where ExbSno=" + Exhibitions + "");
            if (dtAssignExbToExhibitors.Rows.Count > 0)
            {
                strsss = Convert.ToString(dtAssignExbToExhibitors.Rows[0]["ExhibitorSno"]).Split(',');
                for (int i = 0; i < strsss.Length; i++)
                {
                    foreach (GridViewRow gv in GridView1.Rows)
                    {
                        if (gv.RowType == DataControlRowType.DataRow)
                        {
                            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                            string lblAID = GridView1.DataKeys[gv.RowIndex].Value.ToString();
                            if (strsss[i] == lblAID && ChkBxItem.Checked == false)
                            {
                                ChkBxItem.Checked = true;
                            }
                        }
                    }
                }
                strsales = Convert.ToString(dtAssignExbToExhibitors.Rows[0]["SalesPerson"]).Split(',');               
                foreach (string salesid in strsales)
                {
                    for (int icount = 0; icount < lstsalesperson.Items.Count; icount++)
                    {
                        if (salesid == lstsalesperson.Items[icount].Value.ToString())
                        {
                            lstsalesperson.Items[icount].Selected = true;
                        }
                    }                 
                }
            }
            btnsubmit.Visible = true;
        }
        catch (Exception)
        {
            
            throw;
        }
    }

    protected void ddlExhibitions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
           int Exhibitions = Convert.ToInt32(ddlExhibitions.SelectedValue);
           LoadExhibitorByExhibition(Exhibitions);
        }
        catch (Exception)
        {            
            throw;
        }
       
        //foreach (GridViewRow gv in GridView1.Rows)
        //{ 
            //DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");          
            //string strSalesPerson = "select * from ExhibitorsList order by Exbname";
            //con.Open();
            //SqlCommand cmdiner = new SqlCommand(strSalesPerson, con);
            //SqlDataReader dr;
            //dr = cmdiner.ExecuteReader();
            //ddlSalesPerson.Items.Clear();
            //ddlSalesPerson.Items.Insert(0, "- -Select- -");
            //ddlSalesPerson.Items[0].Value = "0";
            //while (dr.Read())
            //{
            //    ddlSalesPerson.Items.Add(new ListItem(dr["Exbname"].ToString(), dr["Sno"].ToString()));
            //}
            //con.Close();
            //Label lblAID = (Label)gv.FindControl("lblSNO");
            //int agentid = Convert.ToInt32(lblAID.Text);
            //string strbind = "select * from ExhibitorsList order by Exbname";
            //SqlDataAdapter sdb = new SqlDataAdapter(strbind, con);
            //DataTable dt2 = new DataTable();
            //sdb.Fill(dt2);
            //CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
            //if (dt2.Rows.Count > 0)
            //{
            //    ChkBxItem.Checked = false;
            //    ddlSalesPerson.SelectedValue = dt2.Rows[0]["Sno"].ToString();
            //}
            //ChkBxItem.Attributes.Add("onclick", " resetdropdownlist();");
        //}        
    }

    public string FormatDateMM(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }

    public void fillSalesPerson()
    {
        DataTable dtsales = dw.GetAllFromQuery("select DISTINCT upper(DisplayName) AS DisplayName,Sno from Login where Active='Y' and UPPER(LoginType) LIKE'%SALES-PERSON%'");
        //BBookingConfirmed BC = new BBookingConfirmed();
        //BC.CompBrSNo = int.Parse(Session["CompBrSNo"].ToString());
        //SqlDataReader dr = BC.getSalesPerson();
        //chksalesperson.Items.Clear();
        //chksalesperson.Items.Add(new ListItem("Select", "0"));
       foreach(DataRow row in dtsales.Rows)
        {
            //chksalesperson.Items.Add(new ListItem(row["DisplayName"].ToString(), row["Sno"].ToString()));
            lstsalesperson.Items.Add(new ListItem(row["DisplayName"].ToString(), row["Sno"].ToString()));
        }       
    }

    void UpdateExbitorByExhibition(string Exbitorsnolists, int exbitionSno)
    {
        //select case when sno in(select Sno from ExhibitorsList where sno in(1) and ExhibitionSno=1) then 1 else (case when sno in(select Sno from ExhibitorsList where sno in(1) and ExhibitionSno!=1) then 0 else 0 end) end  from ExhibitorsList where sno in(1)
        //string str= "update ExhibitorsList set ExhibitionSno=" + exbitionSno + " where Sno in(" + Exbitorsnolist + ")";
        //cmd = new SqlCommand("update ExhibitorsList set ExhibitionSno=" + exbitionSno + " where sno in(" + Exbitorsnolist + ")", con);
        ////cmd = new SqlCommand("update ExhibitorsList set ExhibitionSno=case when sno in(" + Exbitorsnolist + ") then " + exbitionSno + " else 0 end where sno in(select sno from ExhibitorsList WHERE ExhibitionSno=" + exbitionSno + ")", con);
        ////con.Open();
        ////cmd.ExecuteNonQuery();
        ////con.Close();


        //select case when sno in(select Sno from ExhibitorsList where sno in(1) and ExhibitionSno=1) then 1 else (case when sno in(select Sno from ExhibitorsList where sno in(1) and ExhibitionSno!=1) then 0 else 0 end) end  from ExhibitorsList where sno in(1)
        //string str= "update ExhibitorsList set ExhibitionSno=" + exbitionSno + " where Sno in(" + Exbitorsnolist + ")";
        //cmd = new SqlCommand("update ExhibitorsList set ExhibitionSno=" + exbitionSno + " where sno in(" + Exbitorsnolists + ")", con);

        //cmd = new SqlCommand("update ExhibitorsList set ExhibitionSno=case when sno in(" + Exbitorsnolists + ") then " + exbitionSno + " else null end where sno in(select sno from ExhibitorsList WHERE ExhibitionSno=" + exbitionSno + " OR ExhibitionSno=null)", con);
        cmd = new SqlCommand("update ExhibitorsList set ExhibitionSno=case when sno in(" + Exbitorsnolists + ") then " + exbitionSno + " else 0 end where ExhibitionSno=" + exbitionSno + "", con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string strID = "";
        string StrnameanAddress = "";
        string strsales = "";
        //string strsalesName = "";
        int Sid;
        Sid = Convert.ToInt32(ddlExhibitions.SelectedValue);        
        con = new SqlConnection(strCon);       
        try
        {
            //strsalesName = "";
            foreach (GridViewRow gv in GridView1.Rows)
            {
                CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
                //DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");
                //int agentid = Convert.ToInt32(lblAID.Text);
                Label lblAID = (Label)gv.FindControl("lblSNO");
                if (ChkBxItem.Checked)
                {                    
                    //string Name = GridView1.Rows[gv.RowIndex].Cells[2].Text;
                    //string Address = GridView1.Rows[gv.RowIndex].Cells[1].Text; 
                    Label lblname = (Label)gv.FindControl("lblname");
                    Label lbladdress = (Label)gv.FindControl("lbladdress");
                    strID += lblAID.Text + ",";
                    //strExhbitorName += lblAID.Text + ",";
                    StrnameanAddress = "<tr><td>" + lblname.Text + "</td><td>" + lbladdress.Text + "</td></tr>";
                }
            }
           strID = strID.TrimEnd(',');
           foreach (ListItem item in lstsalesperson.Items)
            {
                if (item.Selected)
                {
                   strsales += item.Value + ",";
                   //strsalesName += item.Text + ",";
                   //string body = PopulateBody(item.Text, ddlExhibitions.SelectedItem.Text, StrnameanAddress);
                   //SendMail(body);
                }
            }
            strsales = strsales.TrimEnd(',');            
            if (string.IsNullOrEmpty(strID) == false)
            {
              
                int status = 0;
                DataTable dtExb = dw.GetAllFromQuery("select * from AssignExbToExhibitors where ExbSno=" + Sid + "");
                if (dtExb.Rows.Count > 0)
                {                   
                    DateTime effected = Convert.ToDateTime(FormatDateMM(txtValidFrom.Text));
                    cmd = new SqlCommand("update AssignExbToExhibitors set ExhibitorSno=@ExhibitorSno,SalesPerson=@SalesPerson where ExbSno=" + Sid + "", con);
                    con.Open();                 
                    cmd.Parameters.AddWithValue("@ExhibitorSno", strID);
                    cmd.Parameters.AddWithValue("@SalesPerson", strsales);
                    status = cmd.ExecuteNonQuery();
                    con.Close();
                    if (status > 0)
                    {
                        foreach (ListItem item in lstsalesperson.Items)
                        {
                            if (item.Selected)
                            {
                                string body = PopulateBody(item.Text, ddlExhibitions.SelectedItem.Text, StrnameanAddress);
                                SendMail(body, item.Text);
                            }
                        }
                        //SendMail(item.Text);
                        UpdateExbitorByExhibition(strID, Sid);
                        //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Assign Exbition Updated Successfuly!');", true);
                        string param = "";
                        if (ViewState["SnoFromExbArabPlast"] != null)
                        {
                            param = Convert.ToString(ViewState["SnoFromExbArabPlast"]);
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Assign Exbition Updated Successfuly');window.location ='Add_ExbArabPlast.aspx?SnoBackFromExbAssign=" + param + "';", true);
                        }                        
                       // ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Assign Exbition Updated Successfuly');window.location ='Add_ExbArabPlast.aspx?SnoBackFromExbAssign='" + strID + "'';", true);                             
                        //Response.Redirect("~/Cargo/AddExhibitors.aspx?SnoFromArabPlast=" + ExbSnoval + "");
                    }
                }
                else
                {                  
                    DateTime effected = Convert.ToDateTime(FormatDateMM(txtValidFrom.Text));
                    cmd = new SqlCommand("insert into AssignExbToExhibitors(ExbSno,ExhibitorSno,SalesPerson) values(@ExbSno,@ExhibitorSno,@SalesPerson)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@ExbSno", Sid);
                    cmd.Parameters.AddWithValue("@ExhibitorSno", strID);
                    cmd.Parameters.AddWithValue("@SalesPerson", strsales);
                    status = cmd.ExecuteNonQuery();
                    con.Close();
                    if (status > 0)
                    {
                        foreach (ListItem item in lstsalesperson.Items)
                        {
                            if (item.Selected)
                            {
                                string body = PopulateBody(item.Text, ddlExhibitions.SelectedItem.Text, StrnameanAddress);
                                SendMail(body,item.Text);
                            }
                        }
                        UpdateExbitorByExhibition(strID, Sid);
                        //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Assign Exbition Successfuly!');", true);
                        string param = "";
                        if (ViewState["SnoFromExbArabPlast"] != null)
                        {
                            param = Convert.ToString(ViewState["SnoFromExbArabPlast"]);
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Assign Exbition Successfuly');window.location ='Add_ExbArabPlast.aspx?SnoBackFromExbAssign=" + param + "';", true);
                        }
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Assign Exbition Successfuly');window.location ='Add_ExbArabPlast.aspx?SnoBackFromExbAssign='" +  + "'';", true);                             
                    }
                }             
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDivShow", "alert('Please Select At Least One Record From below...!');", true);
                //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", "Please Select At least one record from bellow", true);  
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();

        }

        //by jj
        //string strScript = "alert('Saved Successfully.');location.replace('AssignExbitionToExhibitors.aspx');";
        //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);

        //GridView1.Visible = false;
        //btnsubmit.Visible = false;
        //lblmessage.Visible = true;
        //lblmessage.Text = "Recorde Saved sucessfully";
        //txtValidFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
        //lblmessage.Focus();
        //Response.Redirect("Assign_Agent.aspx");

    }

    public int check(int aid)
    {

        con = new SqlConnection(strCon);
        string strcmdcheck = "select Sno from ExhibitorsList where Sno=" + aid + "";
        con.Open();
        cmd = new SqlCommand(strcmdcheck, con);
        SqlDataAdapter sdac = new SqlDataAdapter(strcmdcheck, con);

        DataTable dtc = new DataTable();
        sdac.Fill(dtc);

        if (dtc.Rows.Count > 0)
        {
            Session["Ssid"] = dtc.Rows[0]["Sno"].ToString();
            con.Close();
            return 1;

        }
        else
        {
            con.Close();
            return 0;

        }
    }  

    //public bool validatepage()
    //{
    //    bool returnval=true;
    //        foreach (GridViewRow gv in GridView1.Rows)
    //        {
    //            CheckBox ChkBxItem = (CheckBox)gv.FindControl("chkMain");
    //            DropDownList ddlSalesPerson = (DropDownList)gv.FindControl("ddlSalesPerson");

    //            Sid = Convert.ToInt32(ddlSalesPerson.SelectedValue);
    //            if ((ChkBxItem.Checked && Sid > 0) || (!ChkBxItem.Checked && Sid == 0))
    //                returnval= true;
    //            else
    //            {
    //                returnval= false;
    //                break;
    //            }
    //        }
    //        return returnval;
    //}
   
    protected void btncancel_Click(object sender, EventArgs e)
    {
        int ExbSnoval = 0;
        if (Convert.ToInt32(Session["SnoFromExbDetails"]) != 0)
        {
            ExbSnoval = Convert.ToInt32(Session["SnoFromExbDetails"]);
            //Response.Redirect("~/Cargo/Add_ExbArabPlast.aspx?SnoBackFromExbAssign=" + ExbSnoval + "");alert('You Want To Cancel!')
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "window.location ='Add_ExbArabPlast.aspx?SnoBackFromExbAssign=" + ExbSnoval + "';", true);
            //ClientScript.RegisterStartupScript(this.GetType(), "scr", string.Format("location.href='Add_ExbArabPlast.aspx?SnoBackFromExbAssign={0}';", ExbSnoval), true);
        }
    }
}