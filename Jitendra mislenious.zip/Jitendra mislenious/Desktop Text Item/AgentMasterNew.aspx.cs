﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class AgentMasterNew : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlCommand cmd;
    DisplayWrap dw = new DisplayWrap();
    SqlDataReader red;
    SqlParameter pram;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    public string strLen = "";
    public string strLen1 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            // strLen = "<script>var FillDest =new Array(" + Dest() + ")</script>";
            // strLen1 = "<script>var FillCity =new Array(" + City() + ")</script>";
            if (!IsPostBack && Request.QueryString["GstNo"] == null)
            {
                btnadd.Attributes.Add("onclick", "return CheckEmpty();");
                btnadd.Visible = true;
                lblpagename.Text = "Add Agent";
                btnupdate.Visible = false;
                FillAgentMaster();
                FillStateMaster();
                //  ddlAirlineName.Enabled = true;
                // FillStatus();
                // TodayDate = DateTime.Now.ToShortDateString();
                // loginid = Session["EMailID"].ToString();
            }
            else if (!IsPostBack && Request.QueryString["GstNo"] != null)
            {
                if (!IsPostBack)
                {
                    /////btnupdate.Attributes.Add("onclick", "return CheckEmpty();");
                    btnadd.Visible = false; ;
                    btnupdate.Visible = true;
                    lblpagename.Text = "Update Agent Details";
                    FillAgentMaster();
                    FillStateMaster();
                    //ddlAirlineName.Enabled = false;
                    // FillStatus();
                    search();
                    //TodayDate = DateTime.Now.ToShortDateString();
                    //loginid = Session["EMailID"].ToString();
                }
            }
        }
    }

    public void FillAgentMaster()
    {
        //string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select  Agent_ID,Agent_Name AS AgentName from Agent_master ORDER BY AGENT_NAME", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlAgentName.DataSource = red;
        ddlAgentName.DataTextField = "AgentName";
        ddlAgentName.DataValueField = "Agent_ID";
        ddlAgentName.DataBind();
        con.Close();
        cmd.Dispose();
        //////ddlAgentName.Items.Insert(0, new ListItem("Select Agent", "-1"));
    }

    public void FillStateMaster()
    {
        //string Airline_Access = Rights();
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("select (StateCode +'-'+ State) StateName,StateCode from GstStateCode", con);
        con.Open();
        red = cmd.ExecuteReader();
        ddlStateCode.DataSource = red;
        ddlStateCode.DataTextField = "StateName";
        ddlStateCode.DataValueField = "StateCode";
        ddlStateCode.DataBind();
        con.Close();
        cmd.Dispose();
        ////ddlStateCode.Items.Insert(0, new ListItem("Select State", "-1"));
    }  

    public void search()
    {
        // FillCityMaster();
        string idfl;
        idfl = Request.QueryString["GstNo"].ToString();
        string agentname = Request.QueryString["Agentname"].ToString();
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand("select AGS.AgentName,(GS.StateCode +'-'+ GS.State) StateName,AGS.Address,AGS.GstNo,AGS.CityCode from GstStateCode GS inner join AgentGstNo AGS on GS.STATECODE=AGS.STATECODE where  AGS.GstNo='" + idfl + "' and agentname='" + agentname + "'", con);
        cmd.CommandType = CommandType.Text;
       // cmd.Parameters.AddWithValue("@Gstno", idfl);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                ////ddlAgentName.Items.FindByText(dr["AgentName"].ToString()).Selected = true;

                ddlAgentName.SelectedItem.Text = dr["AgentName"].ToString();
                ////ddlAgentName.Enabled = false;
                ////ddlStateCode.Items.FindByText(dr["StateName"].ToString()).Selected = true;
                ddlStateCode.SelectedItem.Text = dr["StateName"].ToString();
                /////ddlStateCode.Enabled = false;
                txtaddress.Text = dr["Address"].ToString();
                txtgstno.Text = dr["GstNo"].ToString();
                //txtgstno.ReadOnly = true;
                txtCityCode.Text = dr["CityCode"].ToString();
            }
        }
        con.Close();
        cmd.Dispose();
    }

    protected void txtgstno_TextChanged(object sender, EventArgs e)
    {
        DataSet dsnew = CheckExits2("", "", txtgstno.Text);
        if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        {
            string message = "alert('Current GST. NO. Already Exist')";
            ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        }
        else if (ds.Tables[0].Rows[0]["checkval"].ToString() == "4")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        {
            string message = "alert('Current GST. NO. Already Exist')";
            ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        }
        else
        {

        }
    }  

    protected void btnadd_Click(object sender, EventArgs e)
    {
        if (ddlAgentName.SelectedItem.Text != "Select Agent" && ddlStateCode.SelectedValue.ToString() != "-1" && txtgstno.Text != "")
        {
            DataSet dsnew = CheckExits2(ddlAgentName.SelectedItem.Text, ddlStateCode.SelectedValue.ToString(), txtgstno.Text);
            if (ds.Tables[0].Rows[0]["checkval"].ToString() == "1")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
            {
                string message = "alert('Selected Agent Details Already Exist')";
                ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
            }
            else if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
            {
                string message = "alert('Current Agent Already Exist For This State')";
                ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
            }
            else if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
            {
                string message = "alert('Current GST. NO. Already Exist')";
                ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
            }
            else if (ds.Tables[0].Rows[0]["checkval"].ToString() == "4")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
            {
                string message = "alert('Current GST. NO. Already Exist')";
                ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
            }       
            else
            {                
                 Add();
            }
        }
        else 
        {
            string message = "alert('Please Provide Valid Input')";
            ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        }
        #region commented 
        //else if (ddlAgentName.SelectedItem.Text != "Select Agent" && ddlStateCode.SelectedValue.ToString() != "-1" && txtgstno.Text == "")
        //{
        //    DataSet dsnew = CheckExits2(ddlAgentName.SelectedItem.Text, ddlStateCode.SelectedValue.ToString(),"");
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected Agent Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Current GST. NO. Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "6")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected State Already Have Another GST. NO.')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    else //if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2" && ds.Tables[1].Rows[0]["checkval"].ToString() == "4") // F F
        //    {
        //        //string message = "alert('Its Ok')";
        //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //        //Add();
        //    }
        //}
        //else if (ddlAgentName.SelectedItem.Text != "Select Agent" && ddlStateCode.SelectedValue.ToString() == "-1" && txtgstno.Text == "")
        //{
        //    DataSet dsnew = CheckExits2(ddlAgentName.SelectedItem.Text, "", "");
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected Agent Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Current GST. NO. Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "6")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected State Already Have Another GST. NO.')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    else //if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2" && ds.Tables[1].Rows[0]["checkval"].ToString() == "4") // F F
        //    {
        //        //string message = "alert('Its Ok')";
        //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //       // Add();
        //    }
        //}
        //else if (ddlAgentName.SelectedItem.Text == "Select Agent" && ddlStateCode.SelectedValue.ToString() == "-1" && txtgstno.Text == "")
        //{
        //    DataSet dsnew = CheckExits2("", "","");
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected Agent Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Current GST. NO. Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "6")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected State Already Have Another GST. NO.')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    else //if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2" && ds.Tables[1].Rows[0]["checkval"].ToString() == "4") // F F
        //    {
        //        //string message = "alert('Its Ok')";
        //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //        // Add();
        //    }
        //}
        //else if (ddlAgentName.SelectedItem.Text != "Select Agent" && ddlStateCode.SelectedValue.ToString() == "-1" && txtgstno.Text != "")
        //{
        //    DataSet dsnew = CheckExits2(ddlAgentName.SelectedItem.Text, "", txtgstno.Text);
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected Agent Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Current GST. NO. Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "6")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected State Already Have Another GST. NO.')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    else //if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2" && ds.Tables[1].Rows[0]["checkval"].ToString() == "4") // F F
        //    {
        //        //string message = "alert('Its Ok')";
        //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //        // Add();
        //    }
        //}
        //else if (ddlAgentName.SelectedItem.Text == "Select Agent" && ddlStateCode.SelectedValue.ToString() != "-1" && txtgstno.Text != "")
        //{
        //    DataSet dsnew = CheckExits2("", ddlStateCode.SelectedValue.ToString(), txtgstno.Text);
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected Agent Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Current GST. NO. Already Exist')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "6")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
        //    {
        //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
        //        //string message = "alert('Selected Agent Already Have A GstNo.')";
        //        string message = "alert('Selected State Already Have Another GST. NO.')";
        //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //    }
        //    else //if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2" && ds.Tables[1].Rows[0]["checkval"].ToString() == "4") // F F
        //    {
        //        //string message = "alert('Its Ok')";
        //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
        //        // Add();
        //    }
        //} 
        #endregion
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        if (ddlAgentName.SelectedItem.Text != "Select Agent" && ddlStateCode.SelectedValue.ToString() != "-1" && txtgstno.Text != "")
        {
            DataSet dsnew = CheckExits2(" ", " ", txtgstno.Text);
            if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  
            {
                string message = "alert('Current GST. NO. Already Exist')";
                ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
            }
            if (ds.Tables[0].Rows[0]["checkval"].ToString() == "4") 
            {
                string message = "alert('Current GST. NO. Already Exist')";
                ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
            }
            else 
            {
                Update();
            }
        }
    }

    public void Add()
    {
        string insert1;
        con = new SqlConnection(strCon);
        try
        {
            string str = "";
            str = "insert into AgentGstNo(AgentName,CityCode,City,Address,GstNo,StateCode) values('" + ddlAgentName.SelectedItem.Text + "','" + txtCityCode.Text + "','" + txtCityCode.Text + "','" + txtaddress.Text + "','" + txtgstno.Text + "','" + ddlStateCode.SelectedValue + "')";
            SqlCommand cmd = new SqlCommand(str, con);
            con.Open();
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();


            con.Open();
            str = "update agentgstno set GstNo=dbo.RemoveSpecialChars(GstNo),Address=dbo.RemoveSpecialChars(Address)";
            SqlCommand cmd1 = new SqlCommand(str, con);
            cmd1.ExecuteNonQuery();
            cmd1.Dispose();
            con.Close();

            Response.Redirect("ShowAgentMasterNew.aspx");
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            //Response.Write(er);
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void Update()
    {
        //string insert1;
        string strupdate = string.Empty;
        string Gstno;
        con = new SqlConnection(strCon);
        try
        {
            Gstno = Request.QueryString["GstNo"].ToString();
            con.Open();
            strupdate = "update AgentGstNo set  AgentName='" + ddlAgentName.SelectedItem.Text + "',CityCode='" + txtCityCode.Text + "',City='" + txtCityCode.Text + "',Address='" + txtaddress.Text + "', GstNo='" + txtgstno.Text + "',StateCode='" + ddlStateCode.SelectedValue + "' where GstNo='" + Gstno + "' and agentname='" + ddlAgentName.SelectedItem.Text + "'";
            SqlCommand cmd = new SqlCommand(strupdate, con);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();


            con.Open();
            strupdate = "update agentgstno set GstNo=dbo.RemoveSpecialChars(GstNo),Address=dbo.RemoveSpecialChars(Address)";
            SqlCommand cmd1 = new SqlCommand(strupdate, con);
            cmd1.ExecuteNonQuery();
            cmd1.Dispose();
            con.Close();

            Response.Redirect("ShowAgentMasterNew.aspx");
        }
        catch (SqlException sqlex)
        {
            string er = sqlex.Message;
            ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + sqlex.Message.ToString().Replace("'", "") + "');</script>");
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    //protected void ddlAgentName_SelectedIndexChanged(object sender, EventArgs e)
    //{        
    //        DataSet dsnew = CheckExits2(ddlAgentName.SelectedItem.Text, "", "");          
    //        if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
    //        {
    //            // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
    //            //string message = "alert('Selected Agent Already Have A GstNo.')";
    //            string message = "alert('Selected Agent Already Exist')";
    //            ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //        }           
    //        else 
    //        {
    //            //string message = "alert('Its Ok')";
    //            //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //            // Add();
    //        }
    //    //Its Ok Bellow
    //    //if (ddlAgentName.SelectedItem.Text != "Select Agent")
    //    //{
    //    //    DataSet dsnew = CheckExits(ddlAgentName.SelectedItem.Text, "", "");
    //    //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "1")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
    //    //    {
    //    //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
    //    //        //string message = "alert('Selected Agent Already Have A GstNo.')";
    //    //        string message = "alert('Selected Agent Already Exist')";
    //    //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //    //    }
    //    //    else //if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2" && ds.Tables[1].Rows[0]["checkval"].ToString() == "4") // F F
    //    //    {
    //    //        //string message = "alert('Its Ok')";
    //    //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //    //    }
    //    //}
    //}

    //protected void ddlStateCode_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    DataSet dsnew = CheckExits2("", ddlStateCode.SelectedValue.ToString(), "");      
    //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "3")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
    //    {
    //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
    //        //string message = "alert('Selected Agent Already Have A GstNo.')";
    //        string message = "alert('Selected State Already Have Another GST. NO.')";
    //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //    }        
    //    else
    //    {
    //        //string message = "alert('Its Ok')";
    //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //        // Add();
    //    }

    //    //Its Ok Bellow
    //    //if (ddlStateCode.SelectedValue.ToString() != "-1")
    //    //{
    //    //    DataSet dsnew = CheckExits("", ddlStateCode.SelectedValue.ToString(), "");
    //    //    if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2")  //  T F && ds.Tables[1].Rows[0]["checkval"].ToString() == "4"
    //    //    {
    //    //        // string message = "alert('Current GST. NO. Already Exist For Selected Agent')";
    //    //        //string message = "alert('Selected Agent Already Have A GstNo.')";
    //    //        string message = "alert('Selected State Already Have Another GST. NO.')";
    //    //        ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //    //    }
    //    //    else //if (ds.Tables[0].Rows[0]["checkval"].ToString() == "2" && ds.Tables[1].Rows[0]["checkval"].ToString() == "4") // F F
    //    //    {
    //    //        //string message = "alert('Its Ok')";
    //    //        //ScriptManager.RegisterClientScriptBlock((sender as Control), this.GetType(), "alert", message, true);
    //    //    }
    //    //}
    //}

    public DataSet CheckExits(string agnetname,string statecode,string Gstno)
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("ExistAgentGst_temp2", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Agent_Name", agnetname);
        //cmd.Parameters.AddWithValue("@City", CityCode);
        cmd.Parameters.AddWithValue("@State", statecode);
        cmd.Parameters.AddWithValue("@Gstno", Gstno);       
        //com.Parameters.AddWithValue("@CitySno", ddlCityCode.SelectedValue);  
        da = new SqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);      
        con.Close();
        cmd.Dispose();
        return ds;
    }

    public DataSet CheckExits2(string agnetname, string statecode, string Gstno)
    {
        con = new SqlConnection(strCon);
        cmd = new SqlCommand("ExistAgentGst_temp_Final", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Agent_Name", agnetname);
        //cmd.Parameters.AddWithValue("@City", CityCode);
        cmd.Parameters.AddWithValue("@State", statecode);
        cmd.Parameters.AddWithValue("@Gstno", Gstno);
        //com.Parameters.AddWithValue("@CitySno", ddlCityCode.SelectedValue);  
        da = new SqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        cmd.Dispose();
        return ds;
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowAgentMasterNew.aspx");
    }
}