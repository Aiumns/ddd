﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CascadingDropDownInMVC4.Models;
namespace CascadingDropDownInMVC4.Controllers
{
    public class EmployeeController : Controller
    {
        public ActionResult Index()
        {
            EmployeeManagementEntities db = new EmployeeManagementEntities();
            ViewBag.Country = new SelectList(db.tblcountries, "CountryID", "CountryName");
            return View();
        }

        // Json Call to get state
        public JsonResult GetStates(string id)
        {
            List<SelectListItem> states = new List<SelectListItem>();
            var stateList = this.Getstate(Convert.ToInt32(id));
            var stateData = stateList.Select(m => new SelectListItem()
            {
                Text = m.StateName,
                Value = m.StateID.ToString(),
            });
            return Json(stateData, JsonRequestBehavior.AllowGet);
        }

        // Get State from DB by country ID
        public IList<tblState> Getstate(int CountryId)
        {
            EmployeeManagementEntities db = new EmployeeManagementEntities();

            return db.tblStates.Where(m => m.CountryID == CountryId).ToList();
        }

        [HttpPost]
        public ActionResult Index(FormCollection formdata)
        {
            // Get Employee informaiton to insert into Data Base
            using (EmployeeManagementEntities objContext = new EmployeeManagementEntities())
            {
                tblemployee Tbl = new tblemployee();
                //  
                Tbl.Name = formdata["TxtName"].ToString();
                Tbl.Designation = formdata["Mobile"];
                Tbl.Email = formdata["TxtEmailID"].ToString();
                Tbl.Country = formdata["TxtAddress"].ToString();
                Tbl.State = formdata["TxtAddress"].ToString();
                Tbl.City = formdata["TxtAddress"].ToString();

                //  
                objContext.Entry(Tbl);
                //  
                int i = objContext.SaveChanges();
                if (i > 0)
                {
                    ViewBag.Msg = "Data Saved Suuceessfully.";
                }
            } 
              
            return RedirectToAction("Index", "Home");
        }

    }

}
