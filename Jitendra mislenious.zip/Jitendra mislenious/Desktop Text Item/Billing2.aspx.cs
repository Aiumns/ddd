﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.IO;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Cfi.App.Pace.Business;
using System.Text;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using Cfi.SoftwareFactory.WebControls;
using System.Net;
using System.Net.Mail;
public partial class Cargo_Billing2 : BasePage
{
    BInvoice inv = new BInvoice();
    BReport bReport = new BReport();
    BAWB ba = new BAWB();
    BSea bSea = new BSea();
    BAgentMaster ag = new BAgentMaster();
    BImportsawb bimp = new BImportsawb();
    BImport bImport = new BImport();
    BDestinationDet des = new BDestinationDet();
    BBookingConfirmed BC = new BBookingConfirmed();
    BDoorDelivery door = new BDoorDelivery();
    BWareHouse bWareHouse = new BWareHouse();
    public string invoiceHeading = string.Empty, strType = string.Empty, strSno = string.Empty, strBillType = string.Empty;
    StringBuilder strData = new StringBuilder();
    DataTable dtIncome = new DataTable();
    DataTable dtExpense = new DataTable();
    DataTable dtRIExpense = new DataTable();
    StringBuilder strBindData = new StringBuilder();
    DisplayWrap dw = new DisplayWrap();
    CommonBusiness comBusins = new CommonBusiness();
    public static string Belongs2city = "";

    //protected void Page_Init(object sender, EventArgs e)
    //{
    //    StringBuilder strPageCreate = new StringBuilder();
    //    strPageCreate.Append("jQuery(function () {  try {  $.ajax({url: '../Services/CreateBillingPage.ashx?Type=" + Request.QueryString["Type"].ToUpper() + "&CompBrSno=" + Session["CompBrSno"].ToString() + "' ,dataType: 'text',success: function (result) {    if (result != '') {  document.getElementById('<%=ltrlData.ClientID %>').innerHTML=result;  return true; }  }  });  } catch (e) {  return false;}      });");

    //    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForPageCreate",
    //                                        strPageCreate.ToString(), true);
    //}

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }

        //string Check = Session["CompName"].ToString().Split('-')[0];
        //double a = 1.23;
        //double b = 1.58;
        //double Result = Math.Round(a);
        //double Result1 = Math.Round(b);

        string url = string.Empty, decQString = string.Empty;
        if (Request.QueryString["BillType"] == null)
        {
            url = HttpContext.Current.Request.Url.AbsoluteUri;
            FormsAuthenticationTicket tk = FormsAuthentication.Decrypt(url.Split('?')[1]);
            decQString = tk.Name;
        }

        if (!IsPostBack)
        {
            // get Current STax Rate
            using (CommonBusiness comBusiness = new CommonBusiness())
            {
                //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                //////Update on 09Jun2017: Conditionaly tax or Gst picked
                
                //////DataTable dtStax = comBusiness.GetList("STaxRate", "IsNull(TotalSTaxRate,0) as TotalSTaxRate,DATEPART(YEAR,FromDate) AS Year,IsNull(STaxRate,0) as STaxRate,ECESS,SHEC,IsNull(SBCessTax,0) as SBCessTax,IsNull(KKCessTax,0) as KKCessTax,FromDate,ToDate", string.Empty);

                DataTable dtStax = comBusiness.GetList("STaxRate", "IsNull(TotalSTaxRate,0) as TotalSTaxRate,DATEPART(YEAR,FromDate) AS Year,IsNull(STaxRate,0) as STaxRate,ECESS,SHEC,IsNull(SBCessTax,0) as SBCessTax,IsNull(KKCessTax,0) as KKCessTax,FromDate,ToDate", " GETDATE() BETWEEN FromDate AND ToDate");
                foreach (DataRow drStax in dtStax.Rows)
                {
                    hdnStaxRates.Value = hdnStaxRates.Value + drStax["Year"] + "-" + drStax["TotalSTaxRate"] + "-" + drStax["STaxRate"] + "-" + drStax["ECESS"] + "-" + drStax["SHEC"] + ",";
                    hdnStaxRate.Value = drStax["TotalSTaxRate"].ToString();
                    if (Convert.ToDateTime(drStax["Fromdate"]) >= Convert.ToDateTime("2015-11-15"))
                    {
                        hdnSBCesTax.Value = drStax["SBCessTax"].ToString();
                    }
                    if (Convert.ToDateTime(drStax["Fromdate"]) >= Convert.ToDateTime("2016-06-01"))
                    {
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ////hdnKKCesTax.Value = dtStax.Rows[0]["KKCessTax"].ToString();
                        hdnKKCesTax.Value = drStax["KKCessTax"].ToString();
                        //****************End of Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    }
                }
            }
            // get previous page url

            ViewState["PreviousPage"] = Request.UrlReferrer != null ? (HttpContext.Current.Request.Url.AbsoluteUri.ToString() == Request.UrlReferrer.ToString() ? null : Request.UrlReferrer.ToString()) : null;
            hdnChargesApprovedMsg.Value = "Bill can't be generated because following charges are yet to be APPROVED :- ";
            hdnCompleted.Value = "N";
            hdnCompBrSno.Value = Session["CompBrSno"].ToString();
            hdnCompBrType.Value = Session["CompBrType"].ToString().ToUpper();
            BC.CompBrSNo = int.Parse(Session["CompBrSno"].ToString());

            if (Request.QueryString["BillType"] == null)
            {
                // type
                strType = decQString.Split('&')[0].Split('=')[1];
                hdnType.Value = decQString.Split('&')[0].Split('=')[1].ToUpper();
                // sno
                hdnSno.Value = decQString.Split('&')[1].Split('=')[1];
                // bill type
                hdnBillType.Value = decQString.Split('&')[2].Split('=')[1].ToUpper();
                // awb type
                hdnAWBType.Value = decQString.Split('&')[3].Split('=')[1];

            }
            else
            {
                // type
                strType = Request.QueryString["Type"].ToUpper();
                hdnType.Value = Request.QueryString["Type"].ToUpper();
                // sno
                hdnSno.Value = Request.QueryString["Sno"];
                // bill type
                hdnBillType.Value = Request.QueryString["BillType"].ToUpper();
                // awb type
                hdnAWBType.Value = Request.QueryString["AwbType"];
            }
            invoiceHeading = (hdnType.Value == "IMPORT" ? (hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "CREDITNOTE" ? "AIR IMPORT : " : "CARGO ARRIVAL NOTICE CUM ") : (hdnType.Value == "OCEANEXP" ? "SEA EXPORT : " : (hdnType.Value == "OCEANIMP" ? "SEA IMPORT : " : "AIR " + hdnType.Value + " : "))) + (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA " : (hdnBillType.Value == "OTHER" ? "OTHER " : string.Empty)) + (hdnBillType.Value == "DEBITNOTE" ? "DEBIT NOTE" : (hdnBillType.Value.Contains("CREDITNOTE") ? "CREDIT NOTE" : (hdnBillType.Value.Contains("BROKERAGE") ? "BROKERAGE INVOICE" : "INVOICE")));

            // Create Page
            if (hdnType.Value.Contains("OCEAN") && hdnAWBType.Value == "M" && hdnBillType.Value.Contains("CREDITNOTE"))
                hdnDNCNRows.Value = "20";
            if (hdnType.Value.Contains("OCEAN") && hdnAWBType.Value == "M" && hdnBillType.Value.Contains("BROKERAGE"))
                hdnDNCNRows.Value = "1";
            inv.SNo = int.Parse(hdnSno.Value);
            // get data for update
            if (hdnBillType.Value == "MODIFY" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" || hdnBillType.Value == "PERFORMATOINVOICE")
            {
                using (CommonBusiness cBus = new CommonBusiness())
                {
                    //DataSet dsDetailUpdate = hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.getPerformaInvoiceForUpdate() : hdnBillType.Value == "PERFORMATOINVOICE" ? inv.getPerformaToCreateInvoice() : inv.getInvoiceForUpdateNew();
                    //hdnInvoiceNo.Value = dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString();
                    hdnInvoiceNo.Value = hdnBillType.Value.Contains("PERFORMA") ? cBus.GetList("performainvoicemaster", "InvoiceNo", "sno='" + inv.SNo + "'").Rows[0][0].ToString() : cBus.GetList("billing_master", "InvoiceNo", "sno='" + inv.SNo + "'").Rows[0][0].ToString();
                }
            }
            else
                hdnInvoiceNo.Value = (hdnType.Value.Contains("EXP") ? "EXP/" : "IMP/") + (hdnType.Value.Contains("OCEAN") ? "S/DEL" : "A/DEL");
            getInitialData(hdnType.Value, 0, "Create");
            ltrlData.Text = strData.ToString();


            // For Create Invoice/Performa Invoice /////////////////////////////////////////////////////////////////////////////////////////////////////////
            // if (Request.QueryString["BillType"].ToString() != "Other")
            // {
            //strBindData.Append("document.getElementById('txtInvName').readonly='readonly';");
            //if (hdnBillType.Value == "OTHER" && hdnType.Value !="IMPORT")Request.QueryString["BillType"] == null
            if (hdnBillType.Value == "OTHER" && (hdnType.Value != "IMPORT" || Request.QueryString["BillType"] != null) && inv.SNo == 0)
            {
                SqlDataReader drMaxBillDate = inv.getMaxBillDate(hdnType.Value, int.Parse(Session["CompBrSno"].ToString()), hdnBillType.Value);
                if (drMaxBillDate.Read())
                    strBindData.Append("document.getElementById('txtBillDate').value='" + DateTime.Parse(drMaxBillDate["bill_date"].ToString()).ToString("dd-MM-yyyy") + "';");
                strBindData.Append("document.getElementById('txtDueDate').value='" + DateTime.Today.Date.ToString("dd-MM-yyyy") + "';");
                strBindData.Append("document.getElementById('ddlInvoiceType').value='OTHER';");
                strBindData.Append("document.getElementById('txtChWt').value='1.00';");
                hdnAWBTableSno.Value = hdnSno.Value;
                ViewState["CustIID"] = "0";
                DataRow drowI = dtIncome.NewRow();
                dtIncome.Columns.Add("tsno", typeof(int));
                dtIncome.Columns.Add("headcode", typeof(int));
                dtIncome.Columns.Add("headtype", typeof(string));
                drowI[0] = 0;
                drowI[1] = 0;
                drowI[2] = "0";
                dtIncome.Rows.Add(drowI);
                Session["dtIncome"] = dtIncome;
                DataRow drowE = dtExpense.NewRow();
                dtExpense.Columns.Add("tsno", typeof(int));
                dtExpense.Columns.Add("headcode", typeof(int));
                dtExpense.Columns.Add("headtype", typeof(string));
                dtExpense.Rows.Add(drowE);
                Session["dtExpense"] = dtExpense;
                DataRow drowRI = dtRIExpense.NewRow();
                dtRIExpense.Columns.Add("sno", typeof(string));
                dtRIExpense.Columns.Add("BillType", typeof(string));
                drowRI[0] = 0;
                dtRIExpense.Rows.Add(drowRI);
                Session["dtRIExpense"] = dtRIExpense;
                hdnInvoiceNo.Value = (hdnType.Value.Contains("EXP") ? "EXP/" : "IMP/") + (hdnType.Value.Contains("OCEAN") ? "S/O/DEL" : "A/O/DEL");
            }
            else if (hdnBillType.Value == "FROMBOOKING" || hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "CREATE" || hdnBillType.Value == "OTHER")
            {
                hdnInvoiceNo.Value = (hdnType.Value.Contains("EXP") ? "EXP/" : "IMP/") + (hdnType.Value.Contains("OCEAN") ? "S/DEL" : "A/DEL");
                hdnAWBTableSno.Value = hdnSno.Value;
                // set button text
                btnSave.Text = "Save";
                // get AWB Table Sno
                inv.awbtable_sno = int.Parse(hdnSno.Value);
                // get data for update
                DataSet dsDetailCreate = hdnType.Value == "EXPORT" ? inv.getCnfBookingBySNoNew(inv.awbtable_sno) : (hdnType.Value == "IMPORT" ? bimp.getImportAWBDetail(Convert.ToInt32(hdnSno.Value)) : inv.getseabl());
                //getInvoiceForUpdateNew
                // Available Credit Limit
                hdnAvlCrLimit.Value = dsDetailCreate.Tables[0].Rows[0]["AvlcrLimit"].ToString();//hdnBillType.Value == "PERFORMAINVOICE" ? "0" :
                // Customer Type
                hdnCustType.Value = dsDetailCreate.Tables[0].Rows[0]["CustType"].ToString().ToUpper();//hdnBillType.Value == "PERFORMAINVOICE" ? "CASH" :

                DataSet dsInvoiceDetails = hdnType.Value == "EXPORT" ? inv.getInvoiceDetails(Convert.ToInt64(dsDetailCreate.Tables[0].Rows[0]["BookingId"].ToString()), dsDetailCreate.Tables[0].Rows[0]["Mawbno"].ToString().Trim(), dsDetailCreate.Tables[0].Rows[0]["Hawbno"].ToString().Trim(), int.Parse(Session["CompBrSno"].ToString())) : (hdnType.Value == "IMPORT" ? bimp.getImportAWBDetail(Convert.ToInt32(hdnSno.Value)) : inv.getSeaMBLBillingCharges(dsDetailCreate.Tables[0].Rows[0]["Job_No"].ToString().Substring(0, dsDetailCreate.Tables[0].Rows[0]["Job_No"].ToString().Length - dsDetailCreate.Tables[0].Rows[0]["Job_No"].ToString().Split('/')[dsDetailCreate.Tables[0].Rows[0]["Job_No"].ToString().Split('/').Length - 1].Length), dsDetailCreate.Tables[0].Rows[0]["mbl_no"].ToString(), int.Parse(Session["CompBrSno"].ToString())));
                //, (hdnBillType.Value == "PERFORMAINVOICE" ? "PERFORMA" : "INVOICE")
                // set old values for mail
                hdnOldCustomerName.Value = (dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "CustomerName" : (hdnType.Value == "IMPORT" ? "con_name" : "BillTo")].ToString());
                strBindData.Append("document.getElementById('txtInvName').value=\"" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "CustomerName" : (hdnType.Value == "IMPORT" ? "con_name" : "BillTo")].ToString() + "\";");
                strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "CustBrSNo" : (hdnType.Value == "IMPORT" ? "con_code" : "BillTo_Code")].ToString().Trim() + "';");
                ViewState["CustIID"] = hdnType.Value == "EXPORT" ? dsDetailCreate.Tables[0].Rows[0]["CustBrSNo"].ToString() : (hdnType.Value == "IMPORT" ? dsDetailCreate.Tables[0].Rows[0]["con_code"].ToString().Trim() : dsDetailCreate.Tables[0].Rows[0]["BillTo_Code"].ToString());
                ViewState["CustIID"] = ViewState["CustIID"].ToString() == "" ? "0" : ViewState["CustIID"].ToString();

                // strBindData.Append("document.getElementById('txtActName').value='" + dsDetailCreate.Tables[0].Rows[0]["act_name"].ToString() + "';");
                // strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailCreate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                strBindData.Append("document.getElementById('txtInv2Add').value=\"" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "CustAdd" : (hdnType.Value == "IMPORT" ? "con_address" : "Address")].ToString().Replace("\n", " ").Replace("\r", " ").Replace("\t", " ") + "\";");

                // bill date as MAWB date
                strBindData.Append("document.getElementById('txtBillDate').value='" + (hdnType.Value == "EXPORT" ? DateTime.Parse(dsDetailCreate.Tables[0].Rows[0]["AWBDate"].ToString()).ToString("dd-MM-yyyy") : DateTime.Today.Date.ToString("dd-MM-yyyy")) + "';");
                // bill date as MAX bill date in billing_master
                //strBindData.Append("document.getElementById('txtBillDate').value='" + DateTime.Parse(dsDetailCreate.Tables[0].Rows[0]["bill_date"].ToString()).ToString("dd-MM-yyyy") + "';");
                //strBindData.Append("document.getElementById('txtBillDate').value='28-03-2011';");
                if (hdnType.Value == "IMPORT")
                {
                    // for Import check invoice status
                    hdnInvoiceStatus.Value = dsDetailCreate.Tables[0].Rows[0]["InvoiceStatus"].ToString().ToUpper();
                    hdnApprovedAmt.Value = (dsDetailCreate.Tables[0].Rows[0]["ApprovedAmount"].ToString() == string.Empty ? "0" : dsDetailCreate.Tables[0].Rows[0]["ApprovedAmount"].ToString());
                    ViewState["ActCust"] = dsDetailCreate.Tables[0].Rows[0]["ActualCustomer"].ToString();
                    //strBindData.Append("document.getElementById('txtActName').value='" + dsDetailCreate.Tables[0].Rows[0]["ActualCustomer"].ToString() + "';");
                    Belongs2city = dsDetailCreate.Tables[0].Rows[0]["City"].ToString();
                    hdnOldInvCodeType.Value = "CAN CUSTOMER";
                }

                //Add no. of day in due date
                int intCrPeriod = Convert.ToInt32(dsDetailCreate.Tables[0].Rows[0]["InvoiceCreditPeriod"].ToString());
                DateTime dateBill = DateTime.Parse(dsDetailCreate.Tables[0].Rows[0]["bill_date"].ToString());
                DateTime dateDue = dateBill.AddDays(intCrPeriod);

                if (dateDue >= DateTime.Today.Date && hdnType.Value != "IMPORT")
                    strBindData.Append("document.getElementById('txtDueDate').value='" + dateDue.ToString("dd-MM-yyyy") + "';");
                else
                    strBindData.Append("document.getElementById('txtDueDate').value='" + DateTime.Today.Date.ToString("dd-MM-yyyy") + "';");

                strBindData.Append("document.getElementById('ddlSalesPerson').value='" + dsDetailCreate.Tables[0].Rows[0]["SalesPersonNew"].ToString().ToUpper() + "';");

                #region Gst Applicable for filling GstNo
                ////DataTable dtagentGstNo = dw.GetAllFromQuery("select GstNo from AgentGstNo where AgentBranchsno=" + ViewState["CustIID"] + "");
                ////if (dtagentGstNo.Rows.Count > 0)
                ////{
                ////    strBindData.Append("document.getElementById('ddlGstNo').value='" + dtagentGstNo.Rows[0]["GstNo"].ToString().ToUpper() + "';");
                ////}
                ////else
                ////{
                ////    strBindData.Append("document.getElementById('ddlGstNo').value='07nahiHai';");
                ////}
                #endregion End of GstNo Filling

                if (hdnBillType.Value == "OTHER")
                    strBindData.Append("document.getElementById('ddlInvoiceType').value='OTHER';");
                else
                    strBindData.Append("document.getElementById('ddlInvoiceType').value=\"" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "shipmenttype" : (hdnType.Value == "IMPORT" ? "shipment_type" : "container_type")].ToString().ToUpper() + "\";");

                if (dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "shipmenttype" : (hdnType.Value == "IMPORT" ? "shipment_type" : "container_type")].ToString().ToUpper() == "EXHIBITION")
                    strBindData.Append("document.getElementById('ddlexhibitionlist').value='" + (dsDetailCreate.Tables[0].Rows[0]["ExhibitionId"].ToString() == string.Empty ? "Select" : dsDetailCreate.Tables[0].Rows[0]["ExhibitionId"].ToString()).ToUpper() + "';");
                if (dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "shipmenttype" : (hdnType.Value == "IMPORT" ? "shipment_type" : "container_type")].ToString().ToUpper() == "OTHER")
                    strBindData.Append("document.getElementById('ddlProductOther').value='" + (dsDetailCreate.Tables[0].Rows[0]["ProductOther"].ToString() == string.Empty ? "Select" : dsDetailCreate.Tables[0].Rows[0]["ProductOther"].ToString()).ToUpper() + "';");

                strBindData.Append("document.getElementById('txtMAWB').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "Mawbno" : (hdnType.Value == "IMPORT" ? "Mawb_no" : "mbl_no")].ToString().Trim() + "';");
                strBindData.Append("document.getElementById('rbtnPP').checked=('" + dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() + "'=='PREPAID');");
                strBindData.Append("document.getElementById('rbtnCC').checked=('" + dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() + "'=='COLLECT');");

                strBindData.Append("document.getElementById('txtMAWBDate').value='" + DateTime.Parse(dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "AWBDate" : (hdnType.Value == "IMPORT" ? "awb_date" : "bl_date")].ToString()).ToString("dd-MM-yyyy") + "';");
                strBindData.Append("document.getElementById('txtHAWB').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "Hawbno" : (hdnType.Value == "IMPORT" ? "Hawb_no" : "hbl_no")].ToString().Trim() + "';");


                strBindData.Append("document.getElementById('txtShipper').value=\"" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "ShipperName" : (hdnType.Value == "IMPORT" ? "sh_name" : "shipper_name")].ToString() + "\";");
                strBindData.Append("document.getElementById('txtConsignee').value=\"" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "ConsigneeName" : (hdnType.Value == "IMPORT" ? "Con_name" : "consignee_name")].ToString() + "\";");
                strBindData.Append("document.getElementById('txtOrigin').value=\"" + dsDetailCreate.Tables[0].Rows[0][(hdnType.Value.Contains("OCEAN") ? "receipt_place" : "Origin")].ToString() + "\";");
                strBindData.Append("document.getElementById('txtDestination').value=\"" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "Destination" : (hdnType.Value == "IMPORT" ? "dstn" : "delivery_place")].ToString() + "\";");
                strBindData.Append("document.getElementById('txtNoOfPackages').value=\"" + dsDetailCreate.Tables[0].Rows[0][(hdnType.Value.Contains("OCEAN") ? "no_of_packages" : "RCP")].ToString() + "\";");
                strBindData.Append("document.getElementById('txtGrossWt').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "GrWt" : "Gross_Wt"].ToString() + "';");
                strBindData.Append("document.getElementById('txtVolWt').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "VolWt" : (hdnType.Value == "IMPORT" ? "Volume_Wt" : "cbm")].ToString() + "';");
               
                strBindData.Append("document.getElementById('txtChWt').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "ChWt" : (hdnType.Value == "IMPORT" ? "Chargeable_Wt" : "Gross_Wt")].ToString() + "';");

                if (hdnType.Value != "IMPORT")
                    strBindData.Append("document.getElementById('txtBillingChWt').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "ChWt" : "billingCBM"].ToString() + "';");


                strBindData.Append("document.getElementById('txtAirline').value='" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "EXPORT" ? "AirlineName" : (hdnType.Value == "IMPORT" ? "Airline" : "shipping_line")].ToString() + "';");
                strBindData.Append("document.getElementById('txtCommodity').value=\"" + dsDetailCreate.Tables[0].Rows[0][hdnType.Value == "IMPORT" ? "nature_goods" : "Commodity"].ToString().Replace("\n", " ").Replace("\r", " ").Replace("\t", " ") + "\";");
                strBindData.Append("document.getElementById('txtCurrency').value='" + (dsInvoiceDetails.Tables[0].Rows.Count == 0 || hdnType.Value.Contains("OCEAN") ? "INR" : dsInvoiceDetails.Tables[0].Rows[0][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "COLLECT" && hdnType.Value == "EXPORT" ? "BuyingCurrency" : "SellingCurrency")]) + "';");
                strBindData.Append("document.getElementById('hdnCurrency').value='" + (dsInvoiceDetails.Tables[0].Rows.Count == 0 || hdnType.Value.Contains("OCEAN") ? "INR" : dsInvoiceDetails.Tables[0].Rows[0][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "COLLECT" && hdnType.Value == "EXPORT" ? "BuyingCurrency" : "SellingCurrency")]) + "';");
                strBindData.Append("document.getElementById('txtExchangeRateTop').value='" + (dsInvoiceDetails.Tables[0].Rows.Count == 0 || hdnType.Value.Contains("OCEAN") ? "1.00" : dsInvoiceDetails.Tables[0].Rows[0][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "COLLECT" && hdnType.Value == "EXPORT" ? "BuyingExchangeRate" : "SellingExchangeRate")]) + "';");
                if (hdnType.Value == "EXPORT")
                {
                    strBindData.Append("document.getElementById('txtExpInvNo').value='" + dsDetailCreate.Tables[0].Rows[0]["ExportInvoiceNo"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtIECNo').value='" + dsDetailCreate.Tables[0].Rows[0]["IECNo"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtShippingBillNos').value='" + dsDetailCreate.Tables[0].Rows[0]["ShippingBills"].ToString() + "';");
                }
                else if (hdnType.Value.Contains("OCEAN"))
                {
                    strBindData.Append("document.getElementById('txtIECNo').value=\"" + dsDetailCreate.Tables[0].Rows[0]["container_no"].ToString() + "\";");
                    strBindData.Append("document.getElementById('txtShippingBillNos').value='" + dsDetailCreate.Tables[0].Rows[0]["SBNo"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtPrintablenote').value=\"" + dsDetailCreate.Tables[0].Rows[0]["package_description"].ToString().Replace('"', ' ') + "\";");
                }


                ///////////////////////////////////////////// INCOME /////////////////////////////////////////////////////




                DataTable dtIncomeCreate = new DataTable();
                DataTable dtExpensesCreate = new DataTable();
                // EXPORT Charges
                if (hdnType.Value == "EXPORT")
                {
                    ViewState["TotalIncome"] = dsInvoiceDetails.Tables[5].Rows.Count > 0 ? dsInvoiceDetails.Tables[5].Rows[0][0].ToString() : "0";
                    hdnOldIncomeAmount.Value = dsInvoiceDetails.Tables[5].Rows.Count > 0 ? dsInvoiceDetails.Tables[5].Rows[0][0].ToString() : "0";
                    hdnChargesApprovedMsg.Value += dsInvoiceDetails.Tables[1].Rows.Count > 0 && dsInvoiceDetails.Tables[1].Rows[0]["Status"].ToString().ToUpper() == "PENDING" ? "*CHA Cahrges*" : string.Empty;
                    hdnChargesApprovedMsg.Value += dsInvoiceDetails.Tables[2].Rows.Count > 0 && dsInvoiceDetails.Tables[2].Rows[0]["Status"].ToString().ToUpper() == "PENDING" ? "*Imprest Cahrges*" : string.Empty;
                    hdnChargesApprovedMsg.Value += dsInvoiceDetails.Tables[3].Rows.Count > 0 && dsInvoiceDetails.Tables[3].Rows[0]["Status"].ToString().ToUpper() == "PENDING" ? "*Godown Cahrges*" : string.Empty;
                    dtIncomeCreate = dsInvoiceDetails.Tables[0].Clone();
                    dtExpensesCreate = dsInvoiceDetails.Tables[0].Clone();
                    // For Booking Confirmed charges 
                    for (int i0 = 0; i0 < dsInvoiceDetails.Tables[0].Rows.Count; i0++)
                    {
                        DataRow dr = dsInvoiceDetails.Tables[0].Rows[i0];
                        dtIncomeCreate.LoadDataRow(dr.ItemArray, false);
                        dtExpensesCreate.LoadDataRow(dr.ItemArray, false);
                    }
                    // For CHA Charges
                    for (int i1 = 0; i1 < dsInvoiceDetails.Tables[1].Rows.Count; i1++)
                    {
                        DataRow dr = dsInvoiceDetails.Tables[1].Rows[i1];
                        dtIncomeCreate.LoadDataRow(dr.ItemArray, false);
                        dtExpensesCreate.LoadDataRow(dr.ItemArray, false);
                    }
                    // For Imprest Charges
                    for (int i2 = 0; i2 < dsInvoiceDetails.Tables[2].Rows.Count; i2++)
                    {
                        DataRow dr = dsInvoiceDetails.Tables[2].Rows[i2];
                        dtIncomeCreate.LoadDataRow(dr.ItemArray, false);
                        dtExpensesCreate.LoadDataRow(dr.ItemArray, false);
                    }
                    // For Godown Charges
                    for (int i3 = 0; i3 < dsInvoiceDetails.Tables[3].Rows.Count; i3++)
                    {
                        DataRow dr = dsInvoiceDetails.Tables[3].Rows[i3];
                        dtIncomeCreate.LoadDataRow(dr.ItemArray, false);
                        dtExpensesCreate.LoadDataRow(dr.ItemArray, false);
                    }
                    // For Terminal Charges
                    for (int i4 = 0; i4 < dsInvoiceDetails.Tables[4].Rows.Count; i4++)
                    {
                        DataRow dr = dsInvoiceDetails.Tables[4].Rows[i4];
                        dtIncomeCreate.LoadDataRow(dr.ItemArray, false);
                        dtExpensesCreate.LoadDataRow(dr.ItemArray, false);
                    }
                    // For Inter Company charges
                    for (int i5 = 0; i5 < dsInvoiceDetails.Tables[6].Rows.Count; i5++)
                    {
                        DataRow dr = dsInvoiceDetails.Tables[6].Rows[i5];
                        if (dsInvoiceDetails.Tables[4].Rows[i5]["headtype"].ToString().ToUpper().Trim() == "E")
                            dtIncomeCreate.LoadDataRow(dr.ItemArray, false);
                        else if (dsInvoiceDetails.Tables[6].Rows[i5]["headtype"].ToString().ToUpper().Trim() == "I")
                            dtExpensesCreate.LoadDataRow(dr.ItemArray, false);
                    }
                    //// All In 
                    //DataRow[] drAllInBuy = dtIncomeCreate.Select("chargeid=18 and ChargeSource='Booking' and taxable='N' and AllInBuy='Y'");
                    //dtIncomeCreate.Rows.RemoveAt(dtIncomeCreate.Rows.IndexOf(dtIncomeCreate.Select("chargeid=21")[0]));
                    //DataRow[] drAllInSell = dtIncomeCreate.Select("chargeid=18 and ChargeSource='Booking' and taxable='N' and AllInSell='Y'");
                    //dtIncomeCreate.Rows.RemoveAt(dtIncomeCreate.Rows.IndexOf(dtIncomeCreate.Select("chargeid=21")[0]));
                }
                // IMPORT Charges
                else if (hdnType.Value == "IMPORT")
                {
                    ViewState["TotalIncome"] = "0";
                    hdnOldIncomeAmount.Value = "0";
                    dtIncomeCreate.Columns.Add("ChargeSource", typeof(string));
                    dtIncomeCreate.Columns.Add("ChargeID", typeof(int));
                    dtIncomeCreate.Columns.Add("HeadName", typeof(string));
                    dtIncomeCreate.Columns.Add("Taxable", typeof(string));
                    dtIncomeCreate.Columns.Add("SellingAmount", typeof(decimal));
                    dtIncomeCreate.Columns.Add("SellingExchangeRate", typeof(decimal));
                    dtIncomeCreate.Columns.Add("Remarks", typeof(string));

                    dtExpensesCreate.Columns.Add("ChargeSource", typeof(string));
                    dtExpensesCreate.Columns.Add("ChargeID", typeof(int));
                    dtExpensesCreate.Columns.Add("HeadName", typeof(string));
                    dtExpensesCreate.Columns.Add("Taxable", typeof(string));
                    dtExpensesCreate.Columns.Add("CustomerName", typeof(string));
                    dtExpensesCreate.Columns.Add("CustBrSN", typeof(int));
                    dtExpensesCreate.Columns.Add("BuyingAmount", typeof(decimal));
                    dtExpensesCreate.Columns.Add("BuyingCurrency", typeof(string));
                    dtExpensesCreate.Columns.Add("BuyingExchangeRate", typeof(decimal));
                    dtExpensesCreate.Columns.Add("Remarks", typeof(string));

                    DataRow drowIncomeImportDO = dtIncomeCreate.NewRow();
                    drowIncomeImportDO[0] = "BOOKING";
                    drowIncomeImportDO[1] = 44;
                    drowIncomeImportDO[2] = "D. O. Charges";
                    drowIncomeImportDO[3] = "Y";
                    drowIncomeImportDO[4] = (Session["CompBrSNo"].ToString() == "12" || Session["CompBrSNo"].ToString() == "30" || Session["CompBrSNo"].ToString() == "32" || Session["CompBrSNo"].ToString() == "22" ? 4600 : 2850);
                    drowIncomeImportDO[5] = 1.00;
                    drowIncomeImportDO[6] = string.Empty;
                    dtIncomeCreate.Rows.Add(drowIncomeImportDO);
                    DataRow drowIncomeImportCC = dtIncomeCreate.NewRow();
                    drowIncomeImportCC[0] = "BOOKING";
                    drowIncomeImportCC[1] = 40;
                    drowIncomeImportCC[2] = "Courier charges";
                    drowIncomeImportCC[3] = "Y";
                    drowIncomeImportCC[4] = (Session["CompBrSNo"].ToString() == "12" || Session["CompBrSNo"].ToString() == "30" || Session["CompBrSNo"].ToString() == "32" || Session["CompBrSNo"].ToString() == "22" ? 25 : 51);
                    drowIncomeImportCC[5] = 1.00;
                    drowIncomeImportCC[6] = string.Empty;
                    dtIncomeCreate.Rows.Add(drowIncomeImportCC);
                    if (Session["CompBrSNo"].ToString() == "12" || Session["CompBrSNo"].ToString() == "30" || Session["CompBrSNo"].ToString() == "32" || Session["CompBrSNo"].ToString() == "22")
                    {
                        DataRow drowIncomeImportCT = dtIncomeCreate.NewRow();
                        drowIncomeImportCT[0] = "BOOKING";
                        drowIncomeImportCT[1] = 27;
                        drowIncomeImportCT[2] = "Cartage/Transportation Charges";
                        drowIncomeImportCT[3] = "Y";
                        drowIncomeImportCT[4] = 50;
                        drowIncomeImportCT[5] = 1.00;
                        drowIncomeImportCT[6] = string.Empty;
                        dtIncomeCreate.Rows.Add(drowIncomeImportCT);
                    }
                    if (dsInvoiceDetails.Tables[1].Rows.Count > 0)
                    {

                        // For Imprest Charges
                        for (int i2 = 0; i2 < dsInvoiceDetails.Tables[1].Rows.Count; i2++)
                        {
                            DataRow drInc = dtIncomeCreate.NewRow();
                            DataRow drExp = dtExpensesCreate.NewRow();
                            drInc[0] = "IMPREST";
                            drInc[1] = dsInvoiceDetails.Tables[0].Rows[i2]["ChargeId"].ToString();
                            drInc[2] = dsInvoiceDetails.Tables[0].Rows[i2]["HeadName"].ToString();
                            drInc[3] = dsInvoiceDetails.Tables[0].Rows[i2]["Taxable"].ToString().ToUpper();
                            drInc[4] = dsInvoiceDetails.Tables[0].Rows[i2]["SellingAmount"].ToString();
                            drInc[5] = 1.00;
                            drInc[6] = string.Empty;
                            dtIncomeCreate.Rows.Add(drInc);
                            drExp[0] = "IMPREST";
                            drExp[1] = dsInvoiceDetails.Tables[0].Rows[i2]["ChargeId"].ToString();
                            drExp[2] = dsInvoiceDetails.Tables[0].Rows[i2]["HeadName"].ToString();
                            drExp[3] = dsInvoiceDetails.Tables[0].Rows[i2]["Taxable"].ToString().ToUpper();
                            drExp[4] = dsInvoiceDetails.Tables[0].Rows[i2]["CustomerName"].ToString();
                            drExp[5] = dsInvoiceDetails.Tables[0].Rows[i2]["CustBrSN"].ToString();
                            drExp[6] = dsInvoiceDetails.Tables[0].Rows[i2]["BuyingAmount"].ToString();
                            drExp[7] = "INR";
                            drExp[8] = 1.00;
                            drExp[9] = string.Empty;
                            dtExpensesCreate.Rows.Add(drExp);

                        }

                    }

                }
                // for OCEAN MBL get all HBL(sub job ) charges as Charge Source "MBL"
                else if (hdnType.Value.Contains("OCEAN"))
                {
                    ////using (CommonBusiness commBus = new CommonBusiness())
                    ////{
                    ////    DataTable seaMBLBookingCharges = commBus.GetList("SeaMBLBillingCharges", "*", "");
                    //if (hdnAWBType.Value == "M")
                    //{
                    //    // For Income charges 
                    //    DataView dvSeaMBLIncome = new DataView(dsInvoiceDetails.Tables[0], "headtype='I'", "headcode", DataViewRowState.CurrentRows);
                    //    DataView dvSeaMBLExp = new DataView(dsInvoiceDetails.Tables[0], "(headtype='P' or headtype='E') and billType='BOOKING'", "headcode", DataViewRowState.CurrentRows);
                    //    dtIncomeCreate = dvSeaMBLIncome.ToTable().Clone();
                    //    dtExpensesCreate = dvSeaMBLExp.ToTable().Clone();
                    //    for (int i0 = 0; i0 < dvSeaMBLIncome.ToTable().Rows.Count; i0++)
                    //    {
                    //        DataRow drSeaInc = dvSeaMBLIncome.ToTable().Rows[i0];
                    //        dtIncomeCreate.LoadDataRow(drSeaInc.ItemArray, false);
                    //    }
                    //    // For Expense charges comer from Booking
                    //    for (int i1 = 0; i1 < dvSeaMBLExp.ToTable().Rows.Count; i1++)
                    //    {
                    //        DataRow drSeaExp = dvSeaMBLExp.ToTable().Rows[i1];
                    //        dtExpensesCreate.LoadDataRow(drSeaExp.ItemArray, false);
                    //    }

                    //}
                    //else
                    //{
                    DataView dvSeaMBLIncome = new DataView(dsInvoiceDetails.Tables[1], "headtype='I' and (hblno='" + (hdnAWBType.Value == "M" ? string.Empty : dsDetailCreate.Tables[0].Rows[0]["hbl_no"].ToString().Trim()) + "'" + (hdnAWBType.Value == "M" ? " or chargesource='HBL'" : string.Empty) + ")", "headcode", DataViewRowState.CurrentRows);
                    DataView dvSeaMBLExp = new DataView(dsInvoiceDetails.Tables[1], "(headtype='P' or headtype='E') and (hblno='" + (hdnAWBType.Value == "M" ? string.Empty : dsDetailCreate.Tables[0].Rows[0]["hbl_no"].ToString().Trim()) + "'" + (hdnAWBType.Value == "M" ? " or chargesource='HBL'" : string.Empty) + ")", "headcode", DataViewRowState.CurrentRows);
                    dtIncomeCreate = dvSeaMBLIncome.ToTable().Clone();
                    dtExpensesCreate = dvSeaMBLExp.ToTable().Clone();
                    for (int i0 = 0; i0 < dvSeaMBLIncome.ToTable().Rows.Count; i0++)
                    {
                        DataRow drSeaInc = dvSeaMBLIncome.ToTable().Rows[i0];
                        drSeaInc["ChargeSource"] = hdnAWBType.Value == "H" && drSeaInc["Chargesource"].ToString().ToUpper() == "HBL" ? "MBL" : drSeaInc["Chargesource"].ToString();
                        dtIncomeCreate.LoadDataRow(drSeaInc.ItemArray, false);

                    }
                    // For Expense charges 
                    for (int i1 = 0; i1 < dvSeaMBLExp.ToTable().Rows.Count; i1++)
                    {
                        DataRow drSeaExp = dvSeaMBLExp.ToTable().Rows[i1];
                        drSeaExp["ChargeSource"] = hdnAWBType.Value == "H" && drSeaExp["Chargesource"].ToString().ToUpper() == "HBL" ? "MBL" : drSeaExp["Chargesource"].ToString();
                        dtExpensesCreate.LoadDataRow(drSeaExp.ItemArray, false);
                    }

                    //}
                    ////}
                }
                DataRow drowI = dtIncome.NewRow();
                dtIncome.Columns.Add("tsno", typeof(int));
                dtIncome.Columns.Add("headcode", typeof(int));
                dtIncome.Columns.Add("headtype", typeof(string));
                dtIncome.Columns.Add("chargesource", typeof(string));
                drowI[0] = 0;
                drowI[1] = 0;
                drowI[2] = "0";
                drowI[3] = "0";
                dtIncome.Rows.Add(drowI);
                if (hdnType.Value.Contains("OCEAN") && dtIncomeCreate.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtIncomeCreate.Rows)
                    {
                        DataRow drow = dtIncome.NewRow();
                        drow[0] = dr["Sno"];
                        drow[1] = dr["headcode"];
                        drow[2] = dr["headtype"];
                        drow[3] = dr["chargesource"];
                        dtIncome.Rows.Add(drow);
                    }
                }
                Session["dtIncome"] = dtIncome;
                DataRow drowE = dtExpense.NewRow();
                dtExpense.Columns.Add("tsno", typeof(int));
                dtExpense.Columns.Add("headcode", typeof(int));
                dtExpense.Columns.Add("headtype", typeof(string));
                dtExpense.Columns.Add("chargesource", typeof(string));
                dtExpense.Rows.Add(drowE);
                if (hdnType.Value.Contains("OCEAN") && dtExpensesCreate.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtExpensesCreate.Rows)
                    {
                        DataRow drowExp = dtExpense.NewRow();
                        drowExp[0] = dr["Sno"];
                        drowExp[1] = dr["headcode"];
                        drowExp[2] = dr["headtype"];
                        drowExp[3] = dr["chargesource"];
                        dtExpense.Rows.Add(drowExp);
                    }
                }
                Session["dtExpense"] = dtExpense;
                DataRow drowRI = dtRIExpense.NewRow();
                dtRIExpense.Columns.Add("sno", typeof(string));
                dtRIExpense.Columns.Add("BillType", typeof(string));
                drowRI[0] = 0;
                dtRIExpense.Rows.Add(drowRI);
                Session["dtRIExpense"] = dtRIExpense;
                int rowAt = -1;
                string allInBuy = string.Empty;
                string allInSell = string.Empty;
                // AIR FREIGHT CHARGE, Airline Due Carrier and Due Agent
                if (hdnType.Value == "EXPORT")
                {
                    DataRow[] drAirFreightIncomeExport = dtIncomeCreate.Select("chargeid=18 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drAirDCIncomeExport = dtIncomeCreate.Select("chargeid=21 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drDueAgentIncomeExport = dtIncomeCreate.Select("chargeid=154 and ChargeSource='Booking' and taxable='Y'");

                    // Air Freight
                    if (drAirFreightIncomeExport.Length > 0)
                    {
                        rowAt = dtIncomeCreate.Rows.IndexOf(drAirFreightIncomeExport[0]);
                        strBindData.Append("document.getElementById('hdnAFIncome').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "SellingAmount" : "BuyingAmount")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtIncomeAmount0').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "SellingAmount" : "BuyingAmount")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtDescription0').value=\"" + dtIncomeCreate.Rows[rowAt]["Remarks"].ToString().ToUpper() + "\";");
                        strBindData.Append("document.getElementById('txtRateIncome').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "Awb_rate1" : "awb_rate")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnAFRate').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "Awb_rate1" : "awb_rate")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtCommIncome').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "Comm_rate1" : "comm_rate")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtIncIncome').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "inc_rate1" : "inc_rate")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtIncOnIncome').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "inc_rate_on1" : "inc_rate_on")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtSpotIncome').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "spot_rate1" : "spot_rate")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtTDSIncome').value='" + dtIncomeCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "tds_rate1" : "tds_rate")].ToString().ToUpper() + "';");
                        allInBuy = (dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? dtIncomeCreate.Rows[rowAt]["AllInBuy"].ToString().ToUpper() : dtIncomeCreate.Rows[rowAt]["AllInSell"].ToString().ToUpper());
                        allInSell = (dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? dtIncomeCreate.Rows[rowAt]["AllInSell"].ToString().ToUpper() : "N");
                        dtIncomeCreate.Rows.RemoveAt(dtIncomeCreate.Rows.IndexOf(drAirFreightIncomeExport[0]));
                    }
                    // Airline Due Carrier
                    if (drAirDCIncomeExport.Length > 0)
                    {
                        if (allInSell != "Y")
                        {
                            rowAt = dtIncomeCreate.Rows.IndexOf(drAirDCIncomeExport[0]);
                            strBindData.Append("document.getElementById('txtDescription1').value=\"" + dtIncomeCreate.Rows[rowAt]["Remarks"].ToString() + "\";");
                            strBindData.Append("document.getElementById('txtIncomeAmount1').value='" + Math.Round(decimal.Parse(dtIncomeCreate.Rows[rowAt]["SellingAmount"].ToString()) / decimal.Parse(dtIncomeCreate.Rows[rowAt]["SellingExchangeRate"].ToString()), 2) + "';");
                        }
                        dtIncomeCreate.Rows.RemoveAt(dtIncomeCreate.Rows.IndexOf(drAirDCIncomeExport[0]));
                    }
                    // Due Agent
                    if (drDueAgentIncomeExport.Length > 0)
                    {
                        rowAt = dtIncomeCreate.Rows.IndexOf(drDueAgentIncomeExport[0]);
                        strBindData.Append("document.getElementById('txtDescription2').value=\"" + dtIncomeCreate.Rows[rowAt]["Remarks"].ToString() + "\";");
                        strBindData.Append("document.getElementById('txtIncomeAmount2').value='" + Math.Round(decimal.Parse(dtIncomeCreate.Rows[rowAt]["SellingAmount"].ToString()) / decimal.Parse(dtIncomeCreate.Rows[rowAt]["SellingExchangeRate"].ToString()), 2) + "';");
                        dtIncomeCreate.Rows.RemoveAt(dtIncomeCreate.Rows.IndexOf(drDueAgentIncomeExport[0]));
                    }
                    else
                    {
                        strBindData.Append("document.getElementById('txtIncomeAmount2').value='400.00';");
                    }

                }
                // For Other Charges
                for (int incomeRow = 0; incomeRow < dtIncomeCreate.Rows.Count; incomeRow++)
                {
                    rowAt = incomeRow + (hdnType.Value == "EXPORT" ? 3 : 0);
                    strBindData.Append("document.getElementById('ddlIncomeChargeType" + rowAt + "').value='" + (dtIncomeCreate.Rows[incomeRow]["ChargeSource"].ToString() == string.Empty ? "BOOKING" : dtIncomeCreate.Rows[incomeRow]["ChargeSource"].ToString().ToUpper()) + "';");
                    strBindData.Append("document.getElementById('ddlIncomeCharges" + rowAt + "').value='" + (dtIncomeCreate.Rows[incomeRow]["ChargeID"].ToString() + "~" + dtIncomeCreate.Rows[incomeRow]["HeadName"].ToString().Trim().ToUpper() + "~" + dtIncomeCreate.Rows[incomeRow]["Taxable"].ToString().ToUpper()) + "';");
                    if (hdnType.Value.Contains("OCEAN"))
                    {
                        strBindData.Append("document.getElementById('hdnIncomeTSno" + rowAt + "').value='" + dtIncomeCreate.Rows[incomeRow]["Sno"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlIncCurr" + rowAt + "').value='" + dtIncomeCreate.Rows[incomeRow]["currency"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtIncExRate" + rowAt + "').value='" + dtIncomeCreate.Rows[incomeRow]["exchangeRate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtIncAmt" + rowAt + "').value='" + Math.Round(decimal.Parse(dtIncomeCreate.Rows[incomeRow]["SellingAmount"].ToString()) / decimal.Parse(dtIncomeCreate.Rows[incomeRow]["SellingExchangeRate"].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('txtIncomeAmount" + rowAt + "').value='" + dtIncomeCreate.Rows[incomeRow]["SellingAmount"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtDescription" + rowAt + "').value=\"" + dtIncomeCreate.Rows[incomeRow]["Remarks"].ToString() + "\";");
                        //+(dtIncomeCreate.Rows[incomeRow]["currency"].ToString()=="INR"?string.Empty: " " + dtIncomeCreate.Rows[incomeRow]["currency"].ToString() + "[" + Math.Round(decimal.Parse(dtIncomeCreate.Rows[incomeRow]["SellingAmount"].ToString()) / decimal.Parse(dtIncomeCreate.Rows[incomeRow]["SellingExchangeRate"].ToString()), 2) + "X" + dtIncomeCreate.Rows[incomeRow]["exchangeRate"].ToString() + "]")
                    }
                    else
                    {
                        strBindData.Append("document.getElementById('txtIncomeAmount" + rowAt + "').value='" + Math.Round(decimal.Parse(dtIncomeCreate.Rows[incomeRow]["SellingAmount"].ToString()) / decimal.Parse(dtIncomeCreate.Rows[incomeRow]["SellingExchangeRate"].ToString()), 2) + "';");

                        strBindData.Append("document.getElementById('txtDescription" + rowAt + "').value=\"" + dtIncomeCreate.Rows[incomeRow]["Remarks"].ToString() + "\";");
                    }
                    if (hdnType.Value.Contains("OCEAN"))
                    {
                        hdnOldIncomeAmount.Value = (decimal.Parse(hdnOldIncomeAmount.Value) + (decimal.Parse(dtIncomeCreate.Rows[incomeRow]["SellingAmount"].ToString()))).ToString();
                    }
                }
                ///////////////////////////////////// EXPENSES ///////////////////////////////////////////

                rowAt = -1;
                // AIR FREIGHT CHARGE, Airline Due Carrier and Due Agent
                if (hdnType.Value == "EXPORT" && dtExpensesCreate.Rows.Count > 0)
                {
                    DataRow[] drAirFreightExpExport = dtExpensesCreate.Select("chargeid=18 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drAirDCExpExport = dtExpensesCreate.Select("chargeid=21 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drDueAgentExpExport = dtExpensesCreate.Select("chargeid=154 and ChargeSource='Booking' and taxable='Y'");

                    // Air Freight
                    if (drAirFreightExpExport.Length > 0)
                    {
                        rowAt = dtExpensesCreate.Rows.IndexOf(drAirFreightExpExport[0]);
                        strBindData.Append("document.getElementById('txtExpSupplier0').value='" + dtExpensesCreate.Rows[rowAt]["CustomerName"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnExpSupplierSno0').value='" + dtExpensesCreate.Rows[rowAt]["CustBrSN"].ToString() + "';");

                        strBindData.Append("document.getElementById('ddlExpCurr0').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "BuyingCurrency" : "SellingCurrency")].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpExRate0').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "BuyingExchangeRate" : "SellingExchangeRate")].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpAmt0').value='" + Math.Round(decimal.Parse(dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "BuyingAmount" : "SellingAmount")].ToString()) / decimal.Parse(dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "BuyingExchangeRate" : "SellingExchangeRate")].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('txtExpINRAmt0').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "BuyingAmount" : "SellingAmount")].ToString() + "';");
                        strBindData.Append("document.getElementById('hdnAFExpense').value='" + Math.Round(decimal.Parse(dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "BuyingAmount" : "SellingAmount")].ToString()) / decimal.Parse(dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "BuyingExchangeRate" : "SellingExchangeRate")].ToString()), 2) + "';");

                        strBindData.Append("document.getElementById('txtRateExp').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "awb_rate" : "awb_rate1")].ToString() + "';");
                        strBindData.Append("document.getElementById('hdnRateExp').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "awb_rate" : "awb_rate1")].ToString() + "';");
                        strBindData.Append("document.getElementById('txtCommExp').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "comm_rate" : "comm_rate1")].ToString() + "';");
                        strBindData.Append("document.getElementById('txtIncExp').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "inc_rate" : "inc_rate1")].ToString() + "';");
                        strBindData.Append("document.getElementById('txtIncOnExp').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "inc_rate_on" : "inc_rate_on1")].ToString() + "';");
                        strBindData.Append("document.getElementById('txtSpotExp').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "spot_rate" : "spot_rate1")].ToString() + "';");
                        strBindData.Append("document.getElementById('txtTDSExp').value='" + dtExpensesCreate.Rows[rowAt][(dsDetailCreate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() == "PREPAID" ? "tds_rate" : "tds_rate1")].ToString() + "';");
                        dtExpensesCreate.Rows.RemoveAt(dtExpensesCreate.Rows.IndexOf(drAirFreightExpExport[0]));
                    }
                    // Airline Due Carrier
                    if (drAirDCExpExport.Length > 0)
                    {
                        if (allInBuy != "Y")
                        {
                            rowAt = dtExpensesCreate.Rows.IndexOf(drAirDCExpExport[0]);
                            strBindData.Append("document.getElementById('txtExpSupplier1').value='" + dtExpensesCreate.Rows[rowAt]["CustomerName"].ToString().ToUpper() + "';");
                            strBindData.Append("document.getElementById('hdnExpSupplierSno1').value='" + dtExpensesCreate.Rows[rowAt]["CustBrSN"].ToString() + "';");
                            strBindData.Append("document.getElementById('ddlExpCurr1').value='" + dtExpensesCreate.Rows[rowAt]["BuyingCurrency"].ToString().ToUpper() + "';");
                            strBindData.Append("document.getElementById('txtExpExRate1').value='" + dtExpensesCreate.Rows[rowAt]["BuyingExchangeRate"].ToString() + "';");
                            strBindData.Append("document.getElementById('txtExpAmt1').value='" + Math.Round(decimal.Parse(dtExpensesCreate.Rows[rowAt]["BuyingAmount"].ToString()) / decimal.Parse(dtExpensesCreate.Rows[rowAt]["BuyingExchangeRate"].ToString()), 2) + "';");
                            strBindData.Append("document.getElementById('txtExpINRAmt1').value='" + dtExpensesCreate.Rows[rowAt]["BuyingAmount"].ToString() + "';");
                            strBindData.Append("document.getElementById('txtExpRemarks1').value=\"" + dtExpensesCreate.Rows[rowAt]["Remarks"].ToString() + "\";");
                        }
                        dtExpensesCreate.Rows.RemoveAt(dtExpensesCreate.Rows.IndexOf(drAirDCExpExport[0]));
                    }
                    else if (drAirDCExpExport.Length > 0 && allInSell == "Y")
                    {
                        rowAt = dtExpensesCreate.Rows.IndexOf(drAirDCExpExport[0]);
                        dtExpensesCreate.Rows.RemoveAt(dtExpensesCreate.Rows.IndexOf(drAirDCExpExport[0]));
                    }
                    // Due Agent
                    if (drDueAgentExpExport.Length > 0)
                    {
                        rowAt = dtExpensesCreate.Rows.IndexOf(drDueAgentExpExport[0]);
                        strBindData.Append("document.getElementById('txtExpSupplier2').value='" + dtExpensesCreate.Rows[rowAt]["CustomerName"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnExpSupplierSno2').value='" + dtExpensesCreate.Rows[rowAt]["CustBrSN"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpCurr2').value='" + dtExpensesCreate.Rows[rowAt]["BuyingCurrency"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpExRate2').value='" + dtExpensesCreate.Rows[rowAt]["BuyingExchangeRate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpAmt2').value='" + Math.Round(decimal.Parse(dtExpensesCreate.Rows[rowAt]["BuyingAmount"].ToString()) / decimal.Parse(dtExpensesCreate.Rows[rowAt]["BuyingExchangeRate"].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('txtExpINRAmt2').value='" + dtExpensesCreate.Rows[rowAt]["BuyingAmount"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpRemarks2').value=\"" + dtExpensesCreate.Rows[rowAt]["Remarks"].ToString() + "\";");
                        dtExpensesCreate.Rows.RemoveAt(dtExpensesCreate.Rows.IndexOf(drDueAgentExpExport[0]));
                    }
                    else
                    {
                        strBindData.Append("document.getElementById('ddlExpCurr2').value='INR';");
                        strBindData.Append("document.getElementById('txtExpExRate2').value='1.00';");
                        strBindData.Append("document.getElementById('txtExpAmt2').value='400.00';");
                        strBindData.Append("document.getElementById('txtExpINRAmt2').value='400.00';");
                        strBindData.Append("document.getElementById('txtExpSTaxAmt2').value='41.20';");
                    }
                }

                for (int expRow = 0; expRow < dtExpensesCreate.Rows.Count; expRow++)
                {
                    rowAt = expRow + (strType.ToUpper() == "EXPORT" ? 3 : 0);
                    strBindData.Append("document.getElementById('ddlExpChargeType" + rowAt + "').value='" + (dtExpensesCreate.Rows[expRow]["ChargeSource"].ToString() == string.Empty ? "BOOKING" : dtExpensesCreate.Rows[expRow]["ChargeSource"].ToString().ToUpper()) + "';");
                    if (hdnType.Value.Contains("OCEAN"))
                    {
                        strBindData.Append("document.getElementById('hdnExpTSno" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["Sno"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpType" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["headtype"].ToString() + "';");
                    }
                    strBindData.Append("document.getElementById('ddlExpCharges" + rowAt + "').value='" + (dtExpensesCreate.Rows[expRow]["ChargeID"].ToString() + "~" + dtExpensesCreate.Rows[expRow]["HeadName"].ToString().Trim().ToUpper() + "~" + dtExpensesCreate.Rows[expRow]["Taxable"].ToString().ToUpper()) + "';");
                    strBindData.Append("document.getElementById('txtExpSupplier" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["CustomerName"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('hdnExpSupplierSno" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["CustBrSN"].ToString() + "';");
                    strBindData.Append("document.getElementById('ddlExpCurr" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["BuyingCurrency"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('txtExpExRate" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["BuyingExchangeRate"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpAmt" + rowAt + "').value='" + Math.Round(decimal.Parse(dtExpensesCreate.Rows[expRow]["BuyingAmount"].ToString()) / decimal.Parse(dtExpensesCreate.Rows[expRow]["BuyingExchangeRate"].ToString()), 2) + "';");
                    strBindData.Append("document.getElementById('txtExpINRAmt" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["BuyingAmount"].ToString() + "';");
                    if (hdnType.Value == "OCEANEXP" || hdnType.Value == "OCEANIMP")
                    {
                        strBindData.Append("document.getElementById('txtExpSTaxAmt" + rowAt + "').value='" + dtExpensesCreate.Rows[expRow]["stax_amt"].ToString() + "';");
                    }
                    else
                    { }
                    strBindData.Append("document.getElementById('txtExpRemarks" + rowAt + "').value=\"" + dtExpensesCreate.Rows[expRow]["Remarks"].ToString() + "\";");
                }

            }
            //////////////////// For Update ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            else if (hdnBillType.Value == "MODIFY" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" || hdnBillType.Value == "PERFORMATOINVOICE")
            {
                // set button text
                btnSave.Text = hdnBillType.Value == "PERFORMATOINVOICE" ? "Save" : "Update";

                // get Sno
                //inv.SNo = Request.QueryString["BillType"].ToString() == "PerformaInvoiceModify" || Request.QueryString["BillType"].ToString() == "PerformaToInvoice" ? int.Parse(Request.QueryString["Sno"].ToString()) : int.Parse(Session["InvoiceSNo"].ToString());
                inv.SNo = int.Parse(hdnSno.Value);
                // get data for update
                DataSet dsDetailUpdate = hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.getPerformaInvoiceForUpdate() : hdnBillType.Value == "PERFORMATOINVOICE" ? inv.getPerformaToCreateInvoice() : inv.getInvoiceForUpdateNew();

                hdnAWBTableSno.Value = dsDetailUpdate.Tables[0].Rows[0]["awbtable_sno"].ToString();
                // Available Credit Limit
                hdnAvlCrLimit.Value = dsDetailUpdate.Tables[0].Rows[0]["AvlcrLimit"].ToString().ToUpper();//hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "0" :
                // Customer Type
                hdnCustType.Value = dsDetailUpdate.Tables[0].Rows[0]["CustType"].ToString().ToUpper();//hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "CASH" : 
                // get Income data
                dtIncome = dsDetailUpdate.Tables[1];
                Session["dtIncome"] = dsDetailUpdate.Tables[1];
                // get expense data
                dtExpense = hdnBillType.Value == "PERFORMATOINVOICE" ? dsDetailUpdate.Tables[4] : dsDetailUpdate.Tables[2];
                Session["dtExpense"] = hdnBillType.Value == "PERFORMATOINVOICE" ? dsDetailUpdate.Tables[4] : dsDetailUpdate.Tables[2];
                // get RI data
                dtRIExpense = dsDetailUpdate.Tables[3];
                Session["dtRIExpense"] = dsDetailUpdate.Tables[3];
                // set old values for mail
                hdnOldCustomerName.Value = dsDetailUpdate.Tables[0].Rows[0]["invto_Name"].ToString();
                hdnOldCustomeAddress.Value = dsDetailUpdate.Tables[0].Rows[0]["invto_address"].ToString();
                hdnOldCM1.Value = dsDetailUpdate.Tables[0].Rows[0]["CM1"].ToString();
                hdnOldChWt.Value = dsDetailUpdate.Tables[0].Rows[0]["chargeable_wt"].ToString();
                hdnOldCurrency.Value = dsDetailUpdate.Tables[0].Rows[0]["curr_code"].ToString();
                hdnOldExRate.Value = dsDetailUpdate.Tables[0].Rows[0]["exchange_rate"].ToString();
                hdnOldInvCodeType.Value = dsDetailUpdate.Tables[0].Rows[0]["invto_code_type"].ToString();
                hdnInvoiceNo.Value = dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString();
                if (hdnType.Value == "IMPORT")
                {
                    if (hdnOldInvCodeType.Value.ToUpper() == "CAN CUSTOMER")
                    {
                        // for Import check invoice status
                        // hdnInvoiceStatus.Value =  dsDetailUpdate.Tables[0].Rows[0]["InvoiceStatus"].ToString();
                        // hdnApprovedAmt.Value = (dsDetailUpdate.Tables[0].Rows[0]["ApprovedAmount"].ToString() == string.Empty ? "0" : dsDetailUpdate.Tables[0].Rows[0]["ApprovedAmount"].ToString());
                        strBindData.Append("document.getElementById('rbtnCANCustomer').checked=true;");
                        strBindData.Append("document.getElementById('lblInvoiceNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtInvName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "\";");
                        strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        ViewState["CustIID"] = dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                        strBindData.Append("document.getElementById('txtActName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString() + "\";");
                        strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                    }
                    else if (hdnOldInvCodeType.Value.ToUpper() == "ACTUAL CUSTOMER")
                    {
                        strBindData.Append("document.getElementById('rbtnActCustomer').checked=true;");
                        strBindData.Append("document.getElementById('lblInvoiceNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtInvName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "\";");
                        strBindData.Append("document.getElementById('txtActCust').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "\";");
                        strBindData.Append("document.getElementById('hndActCustSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                        strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        ViewState["CustIID"] = dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                        strBindData.Append("document.getElementById('txtActName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString() + "\";");
                        strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtActualCustomer').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["invto_address"].ToString().Replace("\n", " ") + "\";");
                    }
                    else if (hdnOldInvCodeType.Value.ToUpper() == "SUB AGENT")
                    {
                        strBindData.Append("document.getElementById('rbtnSubAgent').checked=true;");
                        strBindData.Append("document.getElementById('txtSubAgent').style.display ='block';");
                        strBindData.Append("document.getElementById('lblInvoiceNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtSubAgent').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "\";");
                        strBindData.Append("document.getElementById('hndSubAgentSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtInvName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["consignee"].ToString() + "\";");
                        strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        ViewState["CustIID"] = dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                        strBindData.Append("document.getElementById('txtActName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString() + "\";");
                        strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                    }
                }
                else
                {
                    strBindData.Append("document.getElementById('lblInvoiceNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtInvName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "\";");
                    strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                    ViewState["CustIID"] = dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                    strBindData.Append("document.getElementById('txtActName').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString() + "\";");
                    strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                }
                strBindData.Append("document.getElementById('txtInv2Add').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["invto_address"].ToString().Replace("\n", " ") + "\";");
                //strBindData.Append("document.getElementById('txtBillDate').value='" +(hdnBillType.Value == "PERFORMATOINVOICE"?"": DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["bill_date"].ToString()).ToString("dd-MM-yyyy") )+ "';");
                strBindData.Append("document.getElementById('txtBillDate').value='" + (DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["bill_date"].ToString()).ToString("dd-MM-yyyy")) + "';");

                if (DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["inv_due_date"].ToString()) >= DateTime.Today.Date)
                    strBindData.Append("document.getElementById('txtDueDate').value='" + DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["inv_due_date"].ToString()).ToString("dd-MM-yyyy") + "';");
                else
                    strBindData.Append("document.getElementById('txtDueDate').value='" + DateTime.Today.Date.ToString("dd-MM-yyyy") + "';");

                #region Gst Applicable for filling GstNo from Billing_Master
                //////DataTable dtagentGstNo = dw.GetAllFromQuery("select GstNo from CustomerBranch where sno=" + ViewState["CustIID"] + "");

                strBindData.Append("document.getElementById('ddlGstNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["GstNo"].ToString().ToUpper() + "';");
                #endregion End of GstNo Filling

                strBindData.Append("document.getElementById('ddlSalesPerson').value='" + dsDetailUpdate.Tables[0].Rows[0]["sales_person"].ToString().ToUpper() + "';");

                strBindData.Append("document.getElementById('ddlInvoiceType').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["inv_type"].ToString().ToUpper() + "\";");
                if (dsDetailUpdate.Tables[0].Rows[0]["inv_type"].ToString().ToUpper().Contains("EXHIBITION"))
                    strBindData.Append("document.getElementById('ddlexhibitionlist').value='" + (dsDetailUpdate.Tables[0].Rows[0]["ExhibitionId"].ToString() == string.Empty ? "Select" : dsDetailUpdate.Tables[0].Rows[0]["ExhibitionId"].ToString()).ToUpper() + "';");
                else if (dsDetailUpdate.Tables[0].Rows[0]["inv_type"].ToString().ToUpper().Contains("OTHER"))
                    strBindData.Append("document.getElementById('ddlexhibitionlist').value='" + dsDetailUpdate.Tables[0].Rows[0]["ProductOther"].ToString().ToUpper() + "';");

                strBindData.Append("document.getElementById('txtMAWB').value='" + dsDetailUpdate.Tables[0].Rows[0]["mawb_no"].ToString().Trim() + "';");
                strBindData.Append("document.getElementById('rbtnPP').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["freight_type"].ToString().ToUpper().Trim() + "'=='PP');");
                strBindData.Append("document.getElementById('rbtnCC').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["freight_type"].ToString().ToUpper().Trim() + "'=='CC');");

                strBindData.Append("document.getElementById('txtMAWBDate').value='" + DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["mawb_date"].ToString()).ToString("dd-MM-yyyy") + "';");
                strBindData.Append("document.getElementById('txtHAWB').value='" + dsDetailUpdate.Tables[0].Rows[0]["hawb_no"].ToString().Trim() + "';");
                strBindData.Append("document.getElementById('txtETDDate').value='" + (dsDetailUpdate.Tables[0].Rows[0]["ETDDate"].ToString() == "" ? string.Empty : DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["ETDDate"].ToString()).ToString("dd-MM-yyyy")) + "';");

                strBindData.Append("document.getElementById('txtShipper').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["shipper"].ToString() + "\";");
                strBindData.Append("document.getElementById('txtConsignee').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["consignee"].ToString() + "\";");
                strBindData.Append("document.getElementById('txtOrigin').value='" + dsDetailUpdate.Tables[0].Rows[0]["origin"].ToString() + "';");
                strBindData.Append("document.getElementById('txtDestination').value='" + dsDetailUpdate.Tables[0].Rows[0]["destination"].ToString() + "';");
                strBindData.Append("document.getElementById('txtNoOfPackages').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["pkgs"].ToString() + "\";");
                strBindData.Append("document.getElementById('txtGrossWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["gross_wt"].ToString() + "';");
                strBindData.Append("document.getElementById('txtVolWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["vol_wt"].ToString() + "';");
                if (hdnType.Value != "EXPORT" || dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString().Contains("/O/"))
                {
                    strBindData.Append("document.getElementById('txtChWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["chargeable_wt"].ToString() + "';");
                    if (hdnType.Value.Contains("OCEAN"))
                        strBindData.Append("document.getElementById('txtBillingChWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["billingCBM"].ToString() + "';");
                    //if (hdnType.Value.Contains("OCEAN"))
                    //{
                    //    ////strData.Append("<div style='float:left;padding:0 2px 0 2px'> <b> <label id='lblvolumeperkg'>Volume Per Kg</label></b></div><div style='float:left'><span id='spanvolumePerKg' style='color: red; display: block;'>*</span></div><div style='float:left'><input type='text'  id='txtvolumeperkg' name='txtVolumeperKg' style='width:80px'>" + (decimal.Parse(dsDetailUpdate.Tables[0].Rows[0]["billingCBM"].ToString())*167) + "</div></div></td></tr>");
                    //}
                }
                else
                {
                    strBindData.Append("document.getElementById('txtChWt').value='" + (dsDetailUpdate.Tables[0].Rows[0]["BookingChWt"].ToString() == string.Empty ? dsDetailUpdate.Tables[0].Rows[0]["chargeable_wt"].ToString() : dsDetailUpdate.Tables[0].Rows[0]["BookingChWt"].ToString()) + "';");
                    strBindData.Append("document.getElementById('txtBillingChWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["chargeable_wt"].ToString() + "';");
                }
                strBindData.Append("document.getElementById('txtAirline').value='" + dsDetailUpdate.Tables[0].Rows[0]["airline"].ToString() + "';");
                strBindData.Append("document.getElementById('txtCommodity').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["commodity"].ToString() + "\";");
                strBindData.Append("document.getElementById('txtCurrency').value='" + dsDetailUpdate.Tables[0].Rows[0]["curr_code"].ToString() + "';");
                strBindData.Append("document.getElementById('hdnCurrency').value='" + dsDetailUpdate.Tables[0].Rows[0]["curr_code"].ToString() + "';");
                strBindData.Append("document.getElementById('txtExchangeRateTop').value='" + dsDetailUpdate.Tables[0].Rows[0]["exchange_rate"].ToString() + "';");
                strBindData.Append("document.getElementById('txtExpInvNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["ExpInvNo"].ToString() + "';");
                strBindData.Append("document.getElementById('txtIECNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["IECNo"].ToString() + "';");
                strBindData.Append("document.getElementById('txtShippingBillNos').value='" + dsDetailUpdate.Tables[0].Rows[0]["ShippingBillsNo"].ToString() + "';");
                strBindData.Append("document.getElementById('txtPrintablenote').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["note"].ToString().Replace('"', ' ') + "\";");
                strBindData.Append("document.getElementById('txtNonPrintableNote').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["note1"].ToString() + "\";");
                strBindData.Append("document.getElementById('rbtnStaxYes').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["ServiceTax"].ToString().ToUpper() + "'=='Y');");
                strBindData.Append("document.getElementById('rbtnStaxNo').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["ServiceTax"].ToString().ToUpper() + "'=='N');");
                ///////////////////////////////////////////// INCOME /////////////////////////////////////////////////////
                decimal oldIncome = 0;
                DataTable dtIncomeUpdate = dsDetailUpdate.Tables[1].Clone();
                for (int i1 = 0; i1 < dsDetailUpdate.Tables[1].Rows.Count; i1++)
                {
                    DataRow dr1 = dsDetailUpdate.Tables[1].Rows[i1];
                    dtIncomeUpdate.LoadDataRow(dr1.ItemArray, false);

                }
                //if (hdnType.Value.Contains("OCEAN"))
                //{
                //    inv.awbtable_sno = int.Parse(dsDetailUpdate.Tables[0].Rows[0]["awbtable_sno"].ToString());
                //    DataSet dsInvoiceDetails = inv.getSeaMBLBillingCharges(inv.getseabl().Tables[0].Rows[0]["Job_No"].ToString().Remove(0, inv.getseabl().Tables[0].Rows[0]["Job_No"].ToString().Length - inv.getseabl().Tables[0].Rows[0]["Job_No"].ToString().Split('/')[inv.getseabl().Tables[0].Rows[0]["Job_No"].ToString().Split('/').Length - 1].Length), inv.getseabl().Tables[0].Rows[0]["mbl_no"].ToString(), int.Parse(Session["CompBrSno"].ToString()));
                //    // For Income charges 
                //    DataView dvSeaMBLIncome = new DataView(dsInvoiceDetails.Tables[0], "headtype='I'", "headcode", DataViewRowState.CurrentRows);
                //    //DataView dvSeaMBLExp = new DataView(dsInvoiceDetails.Tables[0], "headtype='P' or headtype='E'", "headcode", DataViewRowState.CurrentRows);
                //    //dtIncomeCreate = dvSeaMBLIncome.ToTable().Clone();
                //    //dtExpensesCreate = dvSeaMBLExp.ToTable().Clone();
                //    for (int i0 = 0; i0 < dvSeaMBLIncome.ToTable().Rows.Count; i0++)
                //    {
                //        DataRow drSeaInc = dvSeaMBLIncome.ToTable().Rows[i0];
                //        dtIncomeUpdate.LoadDataRow(drSeaInc.ItemArray, false);
                //    }

                //}

                int rowAt = -1;
                // AIR FREIGHT CHARGE, Airline Due Carrier and Due Agent
                if (hdnType.Value == "EXPORT" && hdnInvoiceNo.Value.Split('/')[2] != "O")
                {
                    DataRow[] drAirFreightIncomeExport = dtIncomeUpdate.Select("headcode=17 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drAirDCIncomeExport = dtIncomeUpdate.Select("headcode=21 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drDueAgentIncomeExport = dtIncomeUpdate.Select("headcode=154 and ChargeSource='Booking' and taxable='Y'");

                    // Air Freight
                    if (drAirFreightIncomeExport.Length > 0)
                    {
                        rowAt = dtIncomeUpdate.Rows.IndexOf(drAirFreightIncomeExport[0]);
                        strBindData.Append("document.getElementById('hdnIncomeTSno0').value='" + dtIncomeUpdate.Rows[rowAt]["tsno"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnAFIncome').value='" + dtIncomeUpdate.Rows[rowAt]["amount"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtIncomeAmount0').value='" + dtIncomeUpdate.Rows[rowAt]["amount"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtDescription0').value=\"" + dtIncomeUpdate.Rows[rowAt]["description"].ToString().ToUpper() + "\";");
                        strBindData.Append("document.getElementById('txtRateIncome').value='" + dtIncomeUpdate.Rows[rowAt]["awb_rate"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnAFRate').value='" + dtIncomeUpdate.Rows[rowAt]["awb_rate"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtCommIncome').value='" + dtIncomeUpdate.Rows[rowAt]["comm_rate"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtIncIncome').value='" + dtIncomeUpdate.Rows[rowAt]["inc_rate"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtIncOnIncome').value='" + dtIncomeUpdate.Rows[rowAt]["inc_rate_on"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtSpotIncome').value='" + dtIncomeUpdate.Rows[rowAt]["spot_rate"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtTDSIncome').value='" + dtIncomeUpdate.Rows[rowAt]["tds_rate"].ToString().ToUpper() + "';");
                        oldIncome = oldIncome + decimal.Parse(dtIncomeUpdate.Rows[rowAt]["bill_amount"].ToString());
                        dtIncomeUpdate.Rows.RemoveAt(dtIncomeUpdate.Rows.IndexOf(drAirFreightIncomeExport[0]));
                        dtIncomeUpdate.AcceptChanges();
                    }
                    // Airline Due Carrier
                    if (drAirDCIncomeExport.Length > 0)
                    {
                        rowAt = dtIncomeUpdate.Rows.IndexOf(drAirDCIncomeExport[0]);
                        strBindData.Append("document.getElementById('hdnIncomeTSno1').value='" + dtIncomeUpdate.Rows[rowAt]["tsno"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtDescription1').value=\"" + dtIncomeUpdate.Rows[rowAt]["description"].ToString() + "\";");
                        strBindData.Append("document.getElementById('txtIncomeAmount1').value='" + Math.Round(decimal.Parse(dtIncomeUpdate.Rows[rowAt]["amount"].ToString()) / decimal.Parse(dtIncomeUpdate.Rows[rowAt]["ExchangeRate"].ToString()), 2) + "';");
                        oldIncome = oldIncome + decimal.Parse(dtIncomeUpdate.Rows[rowAt]["bill_amount"].ToString());
                        dtIncomeUpdate.Rows.RemoveAt(dtIncomeUpdate.Rows.IndexOf(drAirDCIncomeExport[0]));
                        dtIncomeUpdate.AcceptChanges();
                    }
                    // Due Agent
                    if (drDueAgentIncomeExport.Length > 0)
                    {
                        rowAt = dtIncomeUpdate.Rows.IndexOf(drDueAgentIncomeExport[0]);
                        strBindData.Append("document.getElementById('hdnIncomeTSno2').value='" + dtIncomeUpdate.Rows[rowAt]["tsno"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtDescription2').value=\"" + dtIncomeUpdate.Rows[rowAt]["description"].ToString() + "\";");
                        strBindData.Append("document.getElementById('txtIncomeAmount2').value='" + Math.Round(decimal.Parse(dtIncomeUpdate.Rows[rowAt]["amount"].ToString()) / decimal.Parse(dtIncomeUpdate.Rows[rowAt]["ExchangeRate"].ToString()), 2) + "';");
                        oldIncome = oldIncome + decimal.Parse(dtIncomeUpdate.Rows[rowAt]["bill_amount"].ToString());
                        dtIncomeUpdate.Rows.RemoveAt(dtIncomeUpdate.Rows.IndexOf(drDueAgentIncomeExport[0]));
                        dtIncomeUpdate.AcceptChanges();
                    }
                    else
                    {
                        strBindData.Append("document.getElementById('txtIncomeAmount2').value='0';");
                        oldIncome = oldIncome + 0;
                    }
                }
                // For Other Charges
                for (int incomeRow = 0; incomeRow < dtIncomeUpdate.Rows.Count; incomeRow++)
                {
                    rowAt = incomeRow + (strType.ToUpper() == "EXPORT" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? 3 : 0);
                    strBindData.Append("document.getElementById('hdnIncomeTSno" + rowAt + "').value='" + dtIncomeUpdate.Rows[incomeRow]["tsno"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('ddlIncomeChargeType" + rowAt + "').value='" + (dtIncomeUpdate.Rows[incomeRow]["ChargeSource"].ToString() == string.Empty ? "BOOKING" : (hdnType.Value.Contains("OCEAN") && hdnAWBType.Value == "H" && dtIncomeUpdate.Rows[incomeRow]["ChargeSource"].ToString().ToUpper() == "HBL" ? "MBL" : dtIncomeUpdate.Rows[incomeRow]["ChargeSource"].ToString().ToUpper())) + "';");
                    strBindData.Append("document.getElementById('ddlIncomeCharges" + rowAt + "').value='" + (dtIncomeUpdate.Rows[incomeRow]["headCode"].ToString() + "~" + dtIncomeUpdate.Rows[incomeRow]["headname"].ToString().Replace('*', ' ').Trim().ToUpper() + "~" + dtIncomeUpdate.Rows[incomeRow]["taxable"].ToString().ToUpper()) + "';");
                    if (hdnType.Value.Contains("OCEAN"))
                    {
                        strBindData.Append("document.getElementById('ddlIncCurr" + rowAt + "').value='" + dtIncomeUpdate.Rows[incomeRow]["currency"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtIncExRate" + rowAt + "').value='" + dtIncomeUpdate.Rows[incomeRow]["exchangeRate"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlIncStatus" + rowAt + "').value='" + dtIncomeUpdate.Rows[incomeRow]["Status"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtIncAmt" + rowAt + "').value='" + Math.Round(decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["Amount"].ToString()) / decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["ExchangeRate"].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('txtIncomeAmount" + rowAt + "').value='" + (dsDetailUpdate.Tables[0].Rows[0]["curr_code"].ToString().ToUpper() != "INR" ? Math.Round(decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["amount"].ToString()) / decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["ExchangeRate"].ToString()), 2).ToString() : dtIncomeUpdate.Rows[incomeRow]["Amount"].ToString()) + "';");
                        strBindData.Append("document.getElementById('txtDescription" + rowAt + "').value=\"" + (dtIncomeUpdate.Rows[incomeRow]["description"].ToString() == string.Empty && dsDetailUpdate.Tables[0].Rows[0]["curr_code"].ToString() == "INR" && dtIncomeUpdate.Rows[incomeRow]["currency"].ToString() != "INR" ? dtIncomeUpdate.Rows[incomeRow]["description"].ToString() + " " + dtIncomeUpdate.Rows[incomeRow]["currency"].ToString() + "[" + Math.Round(decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["Amount"].ToString()) / decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["ExchangeRate"].ToString()), 2) + "X" + dtIncomeUpdate.Rows[incomeRow]["exchangeRate"].ToString() + "]" : dtIncomeUpdate.Rows[incomeRow]["description"].ToString()) + "\";");
                    }
                    else
                    {
                        strBindData.Append("document.getElementById('txtDescription" + rowAt + "').value=\"" + dtIncomeUpdate.Rows[incomeRow]["description"].ToString() + "\";");
                        strBindData.Append("document.getElementById('txtIncomeAmount" + rowAt + "').value='" + Math.Round(decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["amount"].ToString()) / decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["ExchangeRate"].ToString()), 2) + "';");
                    }
                    if (hdnType.Value.Contains("OCEAN") && hdnAWBType.Value == "H" && dtIncomeUpdate.Rows[rowAt]["ChargeSource"].ToString().ToUpper() == "HBL")
                    {
                        // CM1Status==CNStatus
                        if (dtIncomeUpdate.Rows[rowAt]["CM1Status"].ToString() == "Y")
                        {
                            strBindData.Append("document.getElementById('ddlIncomeChargeType" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('ddlIncomeCharges" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('ddlIncCurr" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtIncExRate" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtIncAmt" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtIncomeAmount" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtDescription" + rowAt + "').disabled=true;");

                        }
                    }
                    else
                    {
                        oldIncome = oldIncome + decimal.Parse(dtIncomeUpdate.Rows[incomeRow]["bill_amount"].ToString());
                    }
                }
                hdnOldIncomeAmount.Value = oldIncome.ToString();
                ///////////////////////////////////// EXPENSES ///////////////////////////////////////////
                decimal oldActExp = 0, oldEstExp = 0;
                DataTable dtExpensesUpdate = dsDetailUpdate.Tables[2].Clone();
                for (int e0 = 0; e0 < dsDetailUpdate.Tables[2].Rows.Count; e0++)
                {
                    DataRow dr2 = dsDetailUpdate.Tables[2].Rows[e0];
                    dtExpensesUpdate.LoadDataRow(dr2.ItemArray, false);

                }
                rowAt = -1;
                // AIR FREIGHT CHARGE, Airline Due Carrier and Due Agent
                if (hdnType.Value == "EXPORT" && hdnInvoiceNo.Value.Split('/')[2] != "O")
                {
                    DataRow[] drAirFreightExpExport = dtExpensesUpdate.Select("headcode=18 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drAirDCExpExport = dtExpensesUpdate.Select("headcode=21 and ChargeSource='Booking' and taxable='N'");
                    DataRow[] drDueAgentExpExport = dtExpensesUpdate.Select("headcode=154 and ChargeSource='Booking' and taxable='Y'");

                    // Air Freight
                    if (drAirFreightExpExport.Length > 0)
                    {
                        rowAt = dtExpensesUpdate.Rows.IndexOf(drAirFreightExpExport[0]);
                        strBindData.Append("document.getElementById('hdnExpTSno0').value='" + dtExpensesUpdate.Rows[rowAt]["tsno"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpSupplier0').value='" + dtExpensesUpdate.Rows[rowAt]["supplier_name"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnExpSupplierSno0').value='" + dtExpensesUpdate.Rows[rowAt]["supplier_sno"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpInvNo0').value='" + dtExpensesUpdate.Rows[rowAt]["inv"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpInvDate0').value='" + (dtExpensesUpdate.Rows[rowAt]["invDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[rowAt]["invDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                        strBindData.Append("document.getElementById('txtExpInvDueDate0').value='" + (dtExpensesUpdate.Rows[rowAt]["invDueDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[rowAt]["invDueDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                        strBindData.Append("document.getElementById('txtExpConCrdt0').value='" + dtExpensesUpdate.Rows[rowAt]["concrdt"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpCurr0').value='" + dtExpensesUpdate.Rows[rowAt]["currency"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpExRate0').value='" + dtExpensesUpdate.Rows[rowAt]["ExchangeRate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpAmt0').value='" + Math.Round(decimal.Parse(dtExpensesUpdate.Rows[rowAt]["amount"].ToString()) / decimal.Parse(dtExpensesUpdate.Rows[rowAt]["ExchangeRate"].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('txtExpINRAmt0').value='" + dtExpensesUpdate.Rows[rowAt]["amount"].ToString() + "';");
                        strBindData.Append("document.getElementById('hdnAFExpense').value='" + Math.Round(decimal.Parse(dtExpensesUpdate.Rows[rowAt]["amount"].ToString()) / decimal.Parse(dtExpensesUpdate.Rows[rowAt]["ExchangeRate"].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('ddlExpType0').value='" + dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpStatus0').value='" + dtExpensesUpdate.Rows[rowAt]["Status"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtRateExp').value='" + dtExpensesUpdate.Rows[rowAt]["awb_rate"].ToString() + "';");
                        strBindData.Append("document.getElementById('hdnRateExp').value='" + dtExpensesUpdate.Rows[rowAt]["awb_rate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtCommExp').value='" + dtExpensesUpdate.Rows[rowAt]["comm_rate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtIncExp').value='" + dtExpensesUpdate.Rows[rowAt]["inc_rate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtIncOnExp').value='" + dtExpensesUpdate.Rows[rowAt]["inc_rate_on"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtSpotExp').value='" + dtExpensesUpdate.Rows[rowAt]["spot_rate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtTDSExp').value='" + dtExpensesUpdate.Rows[rowAt]["tds_rate"].ToString() + "';");
                        oldActExp = oldActExp + decimal.Parse(dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() == "E" ? dtExpensesUpdate.Rows[rowAt]["bill_amount"].ToString() : "0");
                        oldEstExp = oldEstExp + decimal.Parse(dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() == "P" ? dtExpensesUpdate.Rows[rowAt]["bill_amount"].ToString() : "0");
                        dtExpensesUpdate.Rows.RemoveAt(dtExpensesUpdate.Rows.IndexOf(drAirFreightExpExport[0]));
                        dtExpensesUpdate.AcceptChanges();
                    }
                    // Airline Due Carrier
                    if (drAirDCExpExport.Length > 0)
                    {
                        rowAt = dtExpensesUpdate.Rows.IndexOf(drAirDCExpExport[0]);
                        strBindData.Append("document.getElementById('hdnExpTSno1').value='" + dtExpensesUpdate.Rows[rowAt]["tsno"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpSupplier1').value='" + dtExpensesUpdate.Rows[rowAt]["supplier_name"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnExpSupplierSno1').value='" + dtExpensesUpdate.Rows[rowAt]["supplier_sno"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpInvNo1').value='" + dtExpensesUpdate.Rows[rowAt]["inv"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpInvDate1').value='" + (dtExpensesUpdate.Rows[rowAt]["invDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[rowAt]["invDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                        strBindData.Append("document.getElementById('txtExpInvDueDate1').value='" + (dtExpensesUpdate.Rows[rowAt]["invDueDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[rowAt]["invDueDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                        strBindData.Append("document.getElementById('txtExpTDS1').value='" + dtExpensesUpdate.Rows[rowAt]["tds_rate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpConCrdt1').value='" + dtExpensesUpdate.Rows[rowAt]["ConCrdt"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpCurr1').value='" + dtExpensesUpdate.Rows[rowAt]["currency"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpExRate1').value='" + dtExpensesUpdate.Rows[rowAt]["ExchangeRate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpAmt1').value='" + Math.Round(decimal.Parse(dtExpensesUpdate.Rows[rowAt]["amount"].ToString()) / decimal.Parse(dtExpensesUpdate.Rows[rowAt]["ExchangeRate"].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('txtExpINRAmt1').value='" + dtExpensesUpdate.Rows[rowAt]["amount"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpType1').value='" + dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpStatus1').value='" + dtExpensesUpdate.Rows[rowAt]["Status"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpSTaxAmt1').value='" + dtExpensesUpdate.Rows[rowAt]["stax_amt"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpRemarks1').value=\"" + dtExpensesUpdate.Rows[rowAt]["description"].ToString() + "\";");
                        oldActExp = oldActExp + decimal.Parse(dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() == "E" ? dtExpensesUpdate.Rows[rowAt]["bill_amount"].ToString() : "0");
                        oldEstExp = oldEstExp + decimal.Parse(dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() == "P" ? dtExpensesUpdate.Rows[rowAt]["bill_amount"].ToString() : "0");
                        dtExpensesUpdate.Rows.RemoveAt(dtExpensesUpdate.Rows.IndexOf(drAirDCExpExport[0]));
                        dtExpensesUpdate.AcceptChanges();
                    }
                    // Due Agent
                    if (drDueAgentExpExport.Length > 0)
                    {
                        rowAt = dtExpensesUpdate.Rows.IndexOf(drDueAgentExpExport[0]);
                        strBindData.Append("document.getElementById('hdnExpTSno2').value='" + dtExpensesUpdate.Rows[rowAt]["tsno"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpSupplier2').value='" + dtExpensesUpdate.Rows[rowAt]["supplier_name"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('hdnExpSupplierSno2').value='" + dtExpensesUpdate.Rows[rowAt]["supplier_sno"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpInvNo2').value='" + dtExpensesUpdate.Rows[rowAt]["inv"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpInvDate2').value='" + (dtExpensesUpdate.Rows[rowAt]["invDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[rowAt]["invDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                        strBindData.Append("document.getElementById('txtExpInvDueDate2').value='" + (dtExpensesUpdate.Rows[rowAt]["invDueDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[rowAt]["invDueDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                        strBindData.Append("document.getElementById('txtExpTDS2').value='" + dtExpensesUpdate.Rows[rowAt]["tds_rate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpConCrdt2').value='" + dtExpensesUpdate.Rows[rowAt]["ConCrdt"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpCurr2').value='" + dtExpensesUpdate.Rows[rowAt]["currency"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpExRate2').value='" + dtExpensesUpdate.Rows[rowAt]["ExchangeRate"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpAmt2').value='" + Math.Round(decimal.Parse(dtExpensesUpdate.Rows[rowAt]["amount"].ToString()) / decimal.Parse(dtExpensesUpdate.Rows[rowAt]["ExchangeRate"].ToString()), 2) + "';");
                        strBindData.Append("document.getElementById('txtExpINRAmt2').value='" + dtExpensesUpdate.Rows[rowAt]["amount"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpType2').value='" + dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() + "';");
                        strBindData.Append("document.getElementById('ddlExpStatus2').value='" + dtExpensesUpdate.Rows[rowAt]["Status"].ToString().ToUpper() + "';");
                        strBindData.Append("document.getElementById('txtExpSTaxAmt2').value='" + dtExpensesUpdate.Rows[rowAt]["stax_amt"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtExpRemarks2').value=\"" + dtExpensesUpdate.Rows[rowAt]["description"].ToString() + "\";");
                        oldActExp = oldActExp + decimal.Parse(dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() == "E" ? dtExpensesUpdate.Rows[rowAt]["bill_amount"].ToString() : "0");
                        oldEstExp = oldEstExp + decimal.Parse(dtExpensesUpdate.Rows[rowAt]["headtype"].ToString() == "P" ? dtExpensesUpdate.Rows[rowAt]["bill_amount"].ToString() : "0");
                        dtExpensesUpdate.Rows.RemoveAt(dtExpensesUpdate.Rows.IndexOf(drDueAgentExpExport[0]));
                        dtExpensesUpdate.AcceptChanges();
                    }
                    else
                    {
                        strBindData.Append("document.getElementById('txtExpAmt2').value='0';");
                        strBindData.Append("document.getElementById('txtExpINRAmt2').value='0';");
                        strBindData.Append("document.getElementById('txtExpSTaxAmt2').value='0';");
                        oldActExp = oldActExp + 0;
                        oldEstExp = oldEstExp + 0;
                    }
                }
                // for other expenses
                for (int expRow = 0; expRow < dtExpensesUpdate.Rows.Count; expRow++)
                {
                    rowAt = expRow + (hdnType.Value == "EXPORT" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? 3 : 0);
                    strBindData.Append("document.getElementById('hdnExpTSno" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["tsno"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('ddlExpChargeType" + rowAt + "').value='" + (dtExpensesUpdate.Rows[expRow]["ChargeSource"].ToString() == string.Empty ? "BOOKING" : (hdnType.Value.Contains("OCEAN") && hdnAWBType.Value == "H" && dtExpensesUpdate.Rows[expRow]["ChargeSource"].ToString().ToUpper() == "HBL" ? "MBL" : dtExpensesUpdate.Rows[expRow]["ChargeSource"].ToString().ToUpper())) + "';");
                    strBindData.Append("document.getElementById('ddlExpCharges" + rowAt + "').value='" + (dtExpensesUpdate.Rows[expRow]["headCode"].ToString() + "~" + dtExpensesUpdate.Rows[expRow]["headname"].ToString().Replace('*', ' ').Trim().ToUpper() + "~" + (dtExpensesUpdate.Rows[expRow]["headname"].ToString().Contains("*") ? "Y" : dtExpensesUpdate.Rows[expRow]["taxable"].ToString().ToUpper())) + "';");
                    strBindData.Append("document.getElementById('txtExpSupplier" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["supplier_name"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('hdnExpSupplierSno" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["supplier_sno"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpInvNo" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["inv"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpInvDate" + rowAt + "').value='" + (dtExpensesUpdate.Rows[expRow]["invDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[expRow]["invDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                    strBindData.Append("document.getElementById('txtExpInvDueDate" + rowAt + "').value='" + (dtExpensesUpdate.Rows[expRow]["invDueDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dtExpensesUpdate.Rows[expRow]["invDueDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                    strBindData.Append("document.getElementById('txtExpTDS" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["tds_rate"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpConCrdt" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["ConCrdt"].ToString() + "';");
                    strBindData.Append("document.getElementById('ddlExpCurr" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["currency"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('txtExpExRate" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["ExchangeRate"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpAmt" + rowAt + "').value='" + Math.Round(decimal.Parse(dtExpensesUpdate.Rows[expRow]["amount"].ToString()) / decimal.Parse(dtExpensesUpdate.Rows[expRow]["ExchangeRate"].ToString()), 2) + "';");
                    strBindData.Append("document.getElementById('txtExpINRAmt" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["amount"].ToString() + "';");
                    strBindData.Append("document.getElementById('ddlExpType" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["headtype"].ToString().Trim() + "';");
                    strBindData.Append("document.getElementById('ddlExpStatus" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["Status"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('txtExpSTaxAmt" + rowAt + "').value='" + dtExpensesUpdate.Rows[expRow]["stax_amt"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpRemarks" + rowAt + "').value=\"" + dtExpensesUpdate.Rows[expRow]["description"].ToString() + "\";");
                    if (hdnType.Value.Contains("OCEAN") && hdnAWBType.Value == "H" && dtExpensesUpdate.Rows[expRow]["ChargeSource"].ToString().ToUpper() == "HBL")
                    {
                        // CM1status==CnStatus
                        if (dtExpensesUpdate.Rows[expRow]["CM1Status"].ToString() == "Y")
                        {
                            strBindData.Append("document.getElementById('ddlExpChargeType" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('ddlExpCharges" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpSupplier" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('hdnExpSupplierSno" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpInvNo" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpInvDate" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpInvDueDate" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpTDS" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpConCrdt" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('ddlExpCurr" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpExRate" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpAmt" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpINRAmt" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('ddlExpType" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('ddlExpStatus" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpSTaxAmt" + rowAt + "').disabled=true;");
                            strBindData.Append("document.getElementById('txtExpRemarks" + rowAt + "').disabled=true;");
                        }
                    }
                    else
                    {
                        oldActExp = oldActExp + decimal.Parse(dtExpensesUpdate.Rows[expRow]["headtype"].ToString() == "E" ? dtExpensesUpdate.Rows[expRow]["bill_amount"].ToString() : "0");
                        oldEstExp = oldEstExp + decimal.Parse(dtExpensesUpdate.Rows[expRow]["headtype"].ToString() == "P" ? dtExpensesUpdate.Rows[expRow]["bill_amount"].ToString() : "0");
                    }
                }
                //////////////////////////////////////////////////RI DETAIL////////////////////////////////////////////////
                for (int riDetail = 0; riDetail < dsDetailUpdate.Tables[3].Rows.Count; riDetail++)
                {
                    strBindData.Append("document.getElementById('hdnRISno" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["Sno"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('ddlRIName" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["Name"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('txtRIChequeName" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["ChequeName"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('ddlRIMode" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["Type"].ToString().ToUpper() + "';");
                    strBindData.Append("document.getElementById('txtRIRate" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["Rate"].ToString() + "';");
                    strBindData.Append("document.getElementById('ddlRIRateOn" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["Mode"].ToString().Trim().ToUpper() + "';");
                    strBindData.Append("document.getElementById('txtRIAmount" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["Amount"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtRIInvoiceNo" + riDetail + "').value='" + dsDetailUpdate.Tables[3].Rows[riDetail]["inv"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtRIInvoiceDate" + riDetail + "').value='" + (dsDetailUpdate.Tables[3].Rows[riDetail]["invDate"].ToString() == string.Empty ? string.Empty : DateTime.Parse(dsDetailUpdate.Tables[3].Rows[riDetail]["invDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                    strBindData.Append("document.getElementById('txtRIRemarks" + riDetail + "').value=\"" + dsDetailUpdate.Tables[3].Rows[riDetail]["Remarks"].ToString() + "\";");

                    oldActExp = oldActExp + decimal.Parse(dsDetailUpdate.Tables[3].Rows[riDetail]["Amount"].ToString());
                }

                hdnOldActualExpAmt.Value = oldActExp.ToString();
                hdnOldEstExpAmt.Value = oldEstExp.ToString();
            }
            // DebitNote, CreditNote and Brokerage Invoice Create
            else if (hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value.Contains("CREDITNOTE") || hdnBillType.Value.Contains("BROKERAGE"))
            {
                // set button text
                btnSave.Text = "Save";
                //if (hdnBillType.Value == "MBLCREDITNOTE") { }

                // get Sno
                //inv.SNo = Request.QueryString["BillType"].ToString() == "PerformaInvoiceModify" || Request.QueryString["BillType"].ToString() == "PerformaToInvoice" ? int.Parse(Request.QueryString["Sno"].ToString()) : int.Parse(Session["InvoiceSNo"].ToString());
                inv.SNo = hdnBillType.Value.Contains("MBL") ? 0 : int.Parse(hdnSno.Value);
                if (hdnBillType.Value.Contains("MBL"))
                    inv.awbtable_sno = int.Parse(hdnSno.Value);
                // get data for update
                DataSet dsDetailUpdate = hdnBillType.Value.Contains("MBL") ? inv.getseabl() : inv.getInvoiceForUpdateNew();
                hdnInvoiceNo.Value = hdnBillType.Value.Contains("MBL") ? string.Empty : dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString();
                hdnAWBTableSno.Value = hdnBillType.Value.Contains("MBL") ? hdnSno.Value : dsDetailUpdate.Tables[0].Rows[0]["awbtable_sno"].ToString();
                // Available Credit Limit
                hdnAvlCrLimit.Value = hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "0" : dsDetailUpdate.Tables[0].Rows[0]["AvlcrLimit"].ToString().ToUpper();
                // Customer Type
                hdnCustType.Value = hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "0" : dsDetailUpdate.Tables[0].Rows[0]["CustType"].ToString();

                // set old values for mail
                hdnOldCustomerName.Value = dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value == "MBLCREDITNOTE" ? "BillTo" : (hdnBillType.Value == "MBLBROKERAGE" ? "shipping_line" : "invto_Name"))].ToString();
                hdnOldCustomeAddress.Value = hdnBillType.Value.Contains("MBL") ? string.Empty : dsDetailUpdate.Tables[0].Rows[0]["invto_address"].ToString();
                hdnOldCM1.Value = hdnBillType.Value.Contains("MBL") ? "0" : dsDetailUpdate.Tables[0].Rows[0]["CM1"].ToString();
                hdnOldChWt.Value = dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "net_wt" : "chargeable_wt")].ToString();
                hdnOldCurrency.Value = dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "BillingCurrency" : "curr_code")].ToString();
                hdnOldExRate.Value = dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "BillingExRate" : "exchange_rate")].ToString();
                hdnOldInvCodeType.Value = hdnBillType.Value.Contains("MBL") ? string.Empty : dsDetailUpdate.Tables[0].Rows[0]["invto_code_type"].ToString();
                if (hdnType.Value == "IMPORT")
                {
                    if (hdnOldInvCodeType.Value.ToUpper() == "CAN CUSTOMER")
                    {
                        strBindData.Append("document.getElementById('rbtnCANCustomer').checked=true;");
                        strBindData.Append("document.getElementById('lblInvoiceNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtInvName').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "';");
                        strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        ViewState["CustIID"] = dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                        strBindData.Append("document.getElementById('txtActName').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString() + "';");
                        strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                    }
                    else if (hdnOldInvCodeType.Value.ToUpper() == "ACTUAL CUSTOMER")
                    {
                        strBindData.Append("document.getElementById('rbtnActCustomer').checked=true;");
                        strBindData.Append("document.getElementById('lblInvoiceNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtInvName').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtActCust').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "';");
                        strBindData.Append("document.getElementById('hndActCustSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                        strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        ViewState["CustIID"] = dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                        strBindData.Append("document.getElementById('txtActName').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString() + "';");
                        strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtActualCustomer').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_address"].ToString().Replace("\n", " ") + "';");
                    }
                    else if (hdnOldInvCodeType.Value.ToUpper() == "SUB AGENT")
                    {
                        strBindData.Append("document.getElementById('rbtnSubAgent').checked=true;");
                        strBindData.Append("document.getElementById('txtSubAgent').style.display ='block';");

                        strBindData.Append("document.getElementById('lblInvoiceNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtSubAgent').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString() + "';");
                        strBindData.Append("document.getElementById('hndSubAgentSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        strBindData.Append("document.getElementById('txtInvName').value='" + dsDetailUpdate.Tables[0].Rows[0]["consignee"].ToString() + "';");
                        strBindData.Append("document.getElementById('hndinvSno').value='" + dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString() + "';");
                        ViewState["CustIID"] = dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                        strBindData.Append("document.getElementById('txtActName').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString() + "';");
                        strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString() + "';");
                    }
                }
                else
                {
                    strBindData.Append("document.getElementById('lblInvoiceNo').value='" + (hdnBillType.Value.Contains("MBL") ? string.Empty : dsDetailUpdate.Tables[0].Rows[0]["InvoiceNo"].ToString()) + "';");
                    strBindData.Append("document.getElementById('txtInvName').value='" + (hdnBillType.Value == "MBLCREDITNOTE" ? string.Empty : (hdnBillType.Value == "MBLBROKERAGE" ? dsDetailUpdate.Tables[0].Rows[0]["shipping_line"].ToString() : dsDetailUpdate.Tables[0].Rows[0]["invto_name"].ToString())) + "';");
                    strBindData.Append("document.getElementById('hndinvSno').value='" + (hdnBillType.Value.Contains("MBL") ? "0" : dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString()) + "';");
                    ViewState["CustIID"] = hdnBillType.Value.Contains("MBL") ? "0" : dsDetailUpdate.Tables[0].Rows[0]["invto_code"].ToString();
                    strBindData.Append("document.getElementById('txtActName').value='" + (hdnBillType.Value.Contains("MBL") ? string.Empty : dsDetailUpdate.Tables[0].Rows[0]["act_name"].ToString()) + "';");
                    strBindData.Append("document.getElementById('hiddenActCustSNo').value='" + (hdnBillType.Value.Contains("MBL") ? "0" : dsDetailUpdate.Tables[0].Rows[0]["act_code"].ToString()) + "';");
                }
                strBindData.Append("document.getElementById('txtInv2Add').value=\"" + (hdnBillType.Value.Contains("MBL") ? string.Empty : dsDetailUpdate.Tables[0].Rows[0]["invto_address"].ToString().Replace("\n", " ")) + "\";");
                //strBindData.Append("document.getElementById('txtBillDate').value='" +(hdnBillType.Value == "PERFORMATOINVOICE"?"": DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["bill_date"].ToString()).ToString("dd-MM-yyyy") )+ "';");
                strBindData.Append("document.getElementById('txtBillDate').value='" + (hdnBillType.Value.Contains("MBL") ? DateTime.Today.Date.ToString("dd-MM-yyyy") : (DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["bill_date"].ToString()).ToString("dd-MM-yyyy"))) + "';");

                if (hdnBillType.Value.Contains("MBL"))
                    strBindData.Append("document.getElementById('txtDueDate').value='" + DateTime.Today.Date.ToString("dd-MM-yyyy") + "';");
                else
                    if (DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["inv_due_date"].ToString()) >= DateTime.Today.Date)
                        strBindData.Append("document.getElementById('txtDueDate').value='" + DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0]["inv_due_date"].ToString()).ToString("dd-MM-yyyy") + "';");


                #region Gst Applicable for filling GstNo
                /////DataTable dtagentGstNo = dw.GetAllFromQuery("select GstNo from CustomerBranch where sno=" + ViewState["CustIID"] + "");
                strBindData.Append("document.getElementById('ddlGstNo').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "GstNo" : "GstNo")].ToString().ToUpper() + "';");
                #endregion End of GstNo Filling


                strBindData.Append("document.getElementById('ddlSalesPerson').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "SalesPerson" : "sales_person")].ToString().ToUpper() + "';");
                //Gst From 01 July 2017
                ////strBindData.Append("document.getElementById('ddlGstNo').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "GstNo" : "GstNo")].ToString().ToUpper() + "';");
                strBindData.Append("document.getElementById('ddlInvoiceType').value=\"" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "container_type" : "inv_type")].ToString().ToUpper() + "\";");
                if (dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "container_type" : "inv_type")].ToString().ToUpper().Contains("EXHIBITION"))
                    strBindData.Append("document.getElementById('ddlexhibitionlist').value='" + (dsDetailUpdate.Tables[0].Rows[0]["ExhibitionId"].ToString() == string.Empty ? "Select" : dsDetailUpdate.Tables[0].Rows[0]["ExhibitionId"].ToString()).ToUpper() + "';");

                strBindData.Append("document.getElementById('txtMAWB').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "mbl_no" : "mawb_no")].ToString().Trim() + "';");
                if (hdnBillType.Value.Contains("MBL"))
                {
                    strBindData.Append("document.getElementById('rbtnPP').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() + "'=='PREPAID');");
                    strBindData.Append("document.getElementById('rbtnCC').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["FreightType"].ToString().ToUpper().Trim() + "'=='COLLECT');");
                }
                else
                {
                    strBindData.Append("document.getElementById('rbtnPP').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["freight_type"].ToString().ToUpper().Trim() + "'=='PP');");
                    strBindData.Append("document.getElementById('rbtnCC').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["freight_type"].ToString().ToUpper().Trim() + "'=='CC');");
                }

                strBindData.Append("document.getElementById('txtMAWBDate').value='" + DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "bl_date" : "mawb_date")].ToString()).ToString("dd-MM-yyyy") + "';");
                strBindData.Append("document.getElementById('txtHAWB').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "hbl_no" : "hawb_no")].ToString().Trim() + "';"); ;
                strBindData.Append("document.getElementById('txtETDDate').value='" + (dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "ETD" : "ETDDate")].ToString() == "" ? string.Empty : DateTime.Parse(dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "ETD" : "ETDDate")].ToString()).ToString("dd-MM-yyyy")) + "';");

                strBindData.Append("document.getElementById('txtShipper').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "shipper_name" : "shipper")].ToString() + "';");
                strBindData.Append("document.getElementById('txtConsignee').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "consignee_name" : "consignee")].ToString() + "';");
                strBindData.Append("document.getElementById('txtOrigin').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "receipt_place" : "Origin")].ToString() + "';");
                strBindData.Append("document.getElementById('txtDestination').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "delivery_place" : "destination")].ToString() + "';");
                strBindData.Append("document.getElementById('txtNoOfPackages').value=\"" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "no_of_packages" : "pkgs")].ToString() + "\";");
                strBindData.Append("document.getElementById('txtGrossWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["gross_wt"].ToString() + "';");
                strBindData.Append("document.getElementById('txtVolWt').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "cbm" : "vol_wt")].ToString() + "';");
                if (hdnType.Value == "EXPORT")
                {
                    strBindData.Append("document.getElementById('txtChWt').value='" + (dsDetailUpdate.Tables[0].Rows[0]["BookingChWt"].ToString() == string.Empty ? dsDetailUpdate.Tables[0].Rows[0]["chargeable_wt"].ToString() : dsDetailUpdate.Tables[0].Rows[0]["BookingChWt"].ToString()) + "';");
                    strBindData.Append("document.getElementById('txtBillingChWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["chargeable_wt"].ToString() + "';");
                }
                else
                {
                    strBindData.Append("document.getElementById('txtChWt').value='" + dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value.Contains("MBL") ? "net_wt" : "chargeable_wt")].ToString() + "';");
                    if (hdnType.Value.Contains("OCEAN"))
                        strBindData.Append("document.getElementById('txtBillingChWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["billingCBM"].ToString() + "';");
                    else
                        strBindData.Append("document.getElementById('txtBillingChWt').value='" + dsDetailUpdate.Tables[0].Rows[0]["chargeable_wt"].ToString() + "';");
                }
                if (hdnBillType.Value.Contains("MBL"))
                {
                    strBindData.Append("document.getElementById('txtAirline').value='" + dsDetailUpdate.Tables[0].Rows[0]["shipping_line"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtCommodity').value='" + dsDetailUpdate.Tables[0].Rows[0]["commodity"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtCurrency').value='" + dsDetailUpdate.Tables[0].Rows[0]["BillingCurrency"].ToString() + "';");
                    strBindData.Append("document.getElementById('hdnCurrency').value='" + dsDetailUpdate.Tables[0].Rows[0]["BillingCurrency"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExchangeRateTop').value='" + dsDetailUpdate.Tables[0].Rows[0]["BillingExRate"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpInvNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["Invoice"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtIECNo').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["IECNo"].ToString() + "\";");
                    strBindData.Append("document.getElementById('txtShippingBillNos').value='" + dsDetailUpdate.Tables[0].Rows[0]["shippingBillsList"].ToString() + "';");
                    strBindData.Append("document.getElementById('rbtnStaxYes').checked;");
                }
                else
                {
                    strBindData.Append("document.getElementById('txtAirline').value='" + dsDetailUpdate.Tables[0].Rows[0]["airline"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtCommodity').value='" + dsDetailUpdate.Tables[0].Rows[0]["commodity"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtCurrency').value='" + dsDetailUpdate.Tables[0].Rows[0]["curr_code"].ToString() + "';");
                    strBindData.Append("document.getElementById('hdnCurrency').value='" + dsDetailUpdate.Tables[0].Rows[0]["curr_code"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExchangeRateTop').value='" + dsDetailUpdate.Tables[0].Rows[0]["exchange_rate"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtExpInvNo').value='" + dsDetailUpdate.Tables[0].Rows[0]["ExpInvNo"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtIECNo').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["IECNo"].ToString() + "\";");
                    strBindData.Append("document.getElementById('txtShippingBillNos').value='" + dsDetailUpdate.Tables[0].Rows[0]["ShippingBillsNo"].ToString() + "';");
                    strBindData.Append("document.getElementById('txtPrintablenote').value=\"" + dsDetailUpdate.Tables[0].Rows[0]["note"].ToString().Replace('"', ' ') + "\";");
                    strBindData.Append("document.getElementById('txtNonPrintableNote').value='" + dsDetailUpdate.Tables[0].Rows[0]["note1"].ToString() + "';");
                    strBindData.Append("document.getElementById('rbtnStaxYes').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["ServiceTax"].ToString().ToUpper() + "'=='Y');");
                    strBindData.Append("document.getElementById('rbtnStaxNo').checked=('" + dsDetailUpdate.Tables[0].Rows[0]["ServiceTax"].ToString().ToUpper() + "'=='N');");
                }
                if (hdnType.Value.Contains("OCEAN") && hdnAWBType.Value == "M" && (hdnBillType.Value.Contains("CREDITNOTE") || hdnBillType.Value.Contains("BROKERAGE")))
                {
                    //dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Remove(0, dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Length - dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Split('/')[dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Split('/').Length-1].Length)
                    string seaJobRefNo = dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Length > 1 ? dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Substring(0, dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Length - dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Split('/')[dsDetailUpdate.Tables[0].Rows[0]["Job_No"].ToString().Split('/').Length - 1].Length - 1) : string.Empty;
                    if (hdnBillType.Value.Contains("CREDITNOTE"))
                    {
                        DataSet dsCredit = inv.getSeaMBLBillingCharges(seaJobRefNo, dsDetailUpdate.Tables[0].Rows[0][(hdnBillType.Value == "MBLCREDITNOTE" ? "mbl_no" : "mawb_no")].ToString(), int.Parse(Session["CompBrSno"].ToString()));
                        DataView dvCredit = new DataView(dsCredit.Tables[1], "(headtype='P' OR headtype='E') and cnstatus='N' and ((chargesource='HBL') or (hblNo='' and chargesource='BOOKING')) ", "sno", DataViewRowState.CurrentRows);
                        //(headtype='P' OR headtype='E') and cnstatus='N' and ((chargesource='HBL') or (hblNo='' and chargesource='BOOKING')) 
                        for (int crRow = 0; crRow < dvCredit.ToTable().Rows.Count; crRow++)
                        {
                            strBindData.Append("document.getElementById('hdnDNCNTSno" + crRow + "').value='" + dvCredit.ToTable().Rows[crRow]["sno"].ToString().ToUpper() + "';");
                            strBindData.Append("document.getElementById('ddlDNCNCharges" + crRow + "').value='" + (dvCredit.ToTable().Rows[crRow]["headcode"].ToString() + "~" + dvCredit.ToTable().Rows[crRow]["HeadName"].ToString().Trim().ToUpper() + "~" + dvCredit.ToTable().Rows[crRow]["Taxable"].ToString().ToUpper()) + "';");
                            strBindData.Append("document.getElementById('txtDNCNDescription" + crRow + "').value=\"" + dvCredit.ToTable().Rows[crRow]["remarks"].ToString().ToUpper() + " " + dvCredit.ToTable().Rows[crRow]["Currency"].ToString() + "[" + (Math.Round(decimal.Parse(dvCredit.ToTable().Rows[crRow]["bill_amount"].ToString()) / decimal.Parse(dvCredit.ToTable().Rows[crRow]["exchangeRate"].ToString()), 2)) + "X" + dvCredit.ToTable().Rows[crRow]["exchangeRate"].ToString() + "]\";");
                            strBindData.Append("document.getElementById('txtDNCNAmount" + crRow + "').value='" + (Math.Round(decimal.Parse(dvCredit.ToTable().Rows[crRow]["bill_amount"].ToString()) / decimal.Parse(dsDetailUpdate.Tables[0].Rows[0][hdnBillType.Value != "MBLCREDITNOTE" ? "exchange_rate" : "BillingExRate"].ToString()), 2)) + "';");

                        }
                    }
                    else if (hdnBillType.Value.Contains("BROKERAGE"))
                    {
                        strBindData.Append("document.getElementById('hdnDNCNTSno0').value='0';");
                        strBindData.Append("document.getElementById('ddlDNCNCharges0').value='169~BROKARAGE~N';");
                        strBindData.Append("document.getElementById('txtDNCNDescription0').value='';");
                        strBindData.Append("document.getElementById('txtDNCNAmount0').value='" + (Math.Round(((decimal.Parse(dsDetailUpdate.Tables[0].Rows[0]["baseFreightAmount"].ToString()) / decimal.Parse(dsDetailUpdate.Tables[0].Rows[0]["BillingExRate"].ToString())) * 2) / 100, 2)) + "';");
                    }
                }
            }
            //  }
            hdnCustIID.Value = ViewState["CustIID"].ToString();
            if (strBindData.ToString() != string.Empty)
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptBindValueForCreate",
                                                         strBindData.ToString().Replace("\n", " ").Replace("\r", " ").Replace("\t", " ").Replace("\\s", " ").Trim(), true);
            if (hdnCustType.Value.ToUpper() != "CASH" && hdnBillType.Value != "CREDITNOTE" && hdnOldInvCodeType.Value.ToUpper() != "CAN CUSTOMER")
            {
                int checkFlag;
                // (int.Parse(hdnIncomeAmtNew.Value) - int.Parse(hdnOldIncomeAmount.Value)).ToString()
                checkFlag = checkCreditLimitStatus(hdnOldCustomerName.Value, "0", ViewState["CustIID"].ToString());
                if (checkFlag == 0)
                {
                    if (ViewState["PreviousPage"] != null && hdnType.Value.Contains("PORT"))	//Check if the ViewState and EXPORT or IMPORT
                    //contains Previous page URL
                    {
                        hdnPreviousPage.Value = ViewState["PreviousPage"].ToString();
                        //Redirect to Previous page by retrieving the PreviousPage Url from ViewState.
                    }
                }
            }
        }
    }

    protected void getInitialData(string Type, int Sno, string billType)
    {
        //string invoiceNo = string.Empty;
        //int tableCountDS = dsBillDetail.Tables.Count;
        string MAWB = Type.ToUpper().Contains("OCEAN") ? "MBL" : "MAWB";
        string HAWB = Type.ToUpper().Contains("OCEAN") ? "HBL" : "HAWB";
        DataSet dsCharges = inv.getChargesForBilling(Type);
        // invoiceType and invoiceNo
        strData.Append("<table border='1' class='formTable'><tr style='color:red'><td colspan='4'><b> * Fields are mandatory</b></td></tr><tr><td style='width:100px'><b>BillType</b></td><td style='width:300px'>" + Type + "</td><td style='width:100px'><b>InvoiceNo</b></td><td style='width:300px'><input type='text' readonly='readonly' id='lblInvoiceNo' name='lblInvoiceNo' style='width:300px'></input></td></tr>");
        if (hdnType.Value == "IMPORT")
        {
            strData.Append("<tr><td><b>Invoice Raised on</b></td><td colspan='3'><input type='radio' id='rbtnCANCustomer' name='rbtnCustomer' value='CAN Customer' checked='checked' onclick=\"return getSubAgent();\"/>CAN Customer<input type='radio' name='rbtnCustomer' id='rbtnActCustomer' value='Actual Customer' onclick=\"return getSubAgent();\"/>Act. Customer<input type='radio' name='rbtnCustomer' id='rbtnSubAgent' value='Sub Agent' onclick=\"return getSubAgent();\"/>Sub Agent</td></tr>");
            strData.Append("<tr><td><b>Sub Agent</b></td><td colspan='3'><input type='text' id='txtSubAgent' name='txtSubAgent' style='dispaly:none;width:300px' /> <input type='hidden' id='hndSubAgentSno' name='hndSubAgentSno' /></td></tr>");
        }
        // InvoiceToName and ActualCustomerName
        strData.Append("<tr><td><b>Invoice To Name <span style='color:red'>*</span></b></td><td><div style='float:left'><input  type='text' id='txtInvName' name='txtInvName' style='width:300px' onblur=\"return Agentdata();\" /> <input type='hidden' id='hndinvSno' name='hndinvSno' /><input  type='text' id='txtActCust' name='txtActCust' style='display:none;width:300px' /> <input type='hidden' id='hndActCustSno' name='hndActCustSno' /></div><div style='float:left'>Avl. Cr. Limit :<img src='../Images/India_Rupee_Symbol_Transparent.gif' style='height:14px;width:10px'/> <label id='lblCrLimit'></label></div></td><td><b>Actual Customer</b></td><td><input type='text' id='txtActName' name='txtActName' style='width:300px' /> <input type='hidden' id='hiddenActCustSNo' name='hiddenActCustSNo'/></td></tr>");
        // InvoiceToAddress and ActualCustomerAddress
        strData.Append("<tr><td valign='top'><b>Invoice To Address</b></td><td valign='top'><textarea style='width:300px;height:70px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtInv2Add' name='txtInv2Add' ></textarea></td><td valign='top'><b>Actual Customer Address</b></td><td><textarea type='text' id='txtActualCustomer' name='txtActualCustomer' style='width:300px;height:70px;vertical-align:text-top'></textarea> </td></tr>");

        //strData.Append("<tr><td><b>Agent List<span style='color:red'>*</span></b></td><td><div style='float:left'><input  type='text' id='txtAgentName' name='txtAgentName' style='width:300px' onblur=\"return A();\" /> <input type='hidden' id='hndAgentSno' name='hndAgentSno' /></div></td><td></td></tr>");
        // BillDate and DueDate
        //<a href='javascript: void(0);' id='lnkNextBillDate'  onClick=\"nextDate('txtBillDate');\"> <img  src='../Images/calender.png'></a>
        strData.Append("<tr><td valign='top'><b>Bill Date <span style='color:red'>*</span></b></td><td><input style='width:145px;' type='text' id='txtBillDate' name='txtBillDate' readonly='readonly' /><a href='javascript:void(0);' id='lnkBillDate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtBillDate');\"> <img  src='../Images/calender.png' id='imgBillDate'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td><td valign='top'><b>Bill Due Date <span style='color:red'>*</span></b></td><td><input type='text' id='txtDueDate' name='txtDueDate' style='width:145px' readonly='readonly' /><a href='javascript:void(0);'  onClick=\"setYears(1947, " + (DateTime.Now.Year + 1) + ");showCalender(this, 'txtDueDate');\"> <img  src='../Images/calender.png'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td></tr>");

        #region Gst Applicable
        // GST No filling :updated  on 02 Jun 2017
        strData.Append("<tr><td><b>Select GstNo" + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><select id='lstGstNoCust' name='lstGstNoCust' style='width:150px' onchange=\"return fillGstAddress();\">");
        strData.Append("<tr><td><b>Select Gst StateCode" + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><select id='ddGstStateCode' name='ddGstStateCode' style='width:150px' onchange=\"return fillGstStateCode();\">");
        // Fill GstStateCode

        DataTable dtGstStateCode = dw.GetAllFromQuery("Select StateCode,state from GstStateCode order by StateCode");
        strData.Append("<option value='SELECT'>SELECT</option>");
        if (dtGstStateCode.Rows.Count > 0)
        {
            foreach (DataRow drGstStateCode in dtGstStateCode.Rows)
            {
                strData.Append("<option value=\"" + drGstStateCode["StateCode"].ToString().ToUpper()+"\">" + drGstStateCode["State"].ToString().ToUpper() + "</option>");
            }
        }
        strData.Append("<tr><td><b>Invoice To GST-No:" + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='ddlGstNo' name='ddlGstNo' style='width:300px' /> <input type='hidden' id='hiddenGstNo' name='hiddenGstNo'/>");



        strData.Append("<tr><td valign='top'><b>Gst To Address</b></td><td valign='top'><textarea style='width:300px;height:20px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtgstAdd' name='txtgstAdd'></textarea></td><td><b></b></td><td></td></tr>");
        

        string CustBrsno = "";
        BC.CompBrSNo = int.Parse(Session["CompBrSno"].ToString());

        ////SqlDataReader drGstNo = BC.getAgentGstNo();
        ////////DataTable dtgst = new DataTable();
        ////////dtgst.Load(drGstNo);
        ////strData.Append("<option value='SELECT'>SELECT</option>");
        ////while (drGstNo.Read())
        ////{
        ////    strData.Append("<option value='" + drGstNo["GstNo"].ToString().ToUpper() + "'>" + drGstNo["GstNo"].ToString().ToUpper() + "</option>");
        ////}
        ////drGstNo.Close();
        // End of GST No filling :updated  on 02 Jun 2017
        #endregion End of Gst
        // SalesPerson and Product
        strData.Append("<tr><td><b>Sales Person" + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><select id='ddlSalesPerson' name='ddlSalesPerson' style='width:150px'>");
        // Fill Sales Person
        BC.CompBrSNo = int.Parse(Session["CompBrSno"].ToString());
        SqlDataReader drSales = BC.getSalesPerson();
        strData.Append("<option value='SELECT'>SELECT</option>");
        while (drSales.Read())
        {
            strData.Append("<option value='" + drSales["DisplayName"].ToString().ToUpper() + "'>" + drSales["DisplayName"].ToString().ToUpper() + "</option>");
        }
        drSales.Close();
        strData.Append("</select></td><td><b>Product Type" + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><div id='divexhibitionSelect' name='divexhibitionSelect' style='float:left; padding: 5px 0px 0px 0px ;Width:30%'><select id='ddlInvoiceType' name='ddlInvoiceType' style='width:98%' onchange=\"return ExhibitionDet();\">");
        // Fill Product
        if (hdnType.Value.Contains("OCEAN"))
        {
            DataSet dsContainer = bSea.getConatainer();
            strData.Append("<option value='SELECT'>SELECT</option>");
            if (dsContainer.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drContainer in dsContainer.Tables[0].Rows)
                {
                    strData.Append("<option value=\"" + drContainer["cont_type"].ToString().ToUpper() + "\">" + drContainer["cont_type"].ToString().ToUpper() + "</option>");
                }
            }
        }
        else
        {
            SqlDataReader drProducts = bimp.getAllProducts();
            strData.Append("<option value='SELECT'>SELECT</option>");
            while (drProducts.Read())
            {
                strData.Append("<option value=\"" + drProducts["ProductName"].ToString().ToUpper() + "\">" + drProducts["ProductName"].ToString().ToUpper() + "</option>");
            }
            drProducts.Close();
        }
        strData.Append("</select></div><div id='divexhibition' name='divexhibition' style='float:left; display: none; padding: 5px 0px 0px 3px; Width:60%'><b>Fair:</b> <select id='ddlexhibitionlist' name='ddlexhibitionlist' style='width:80%'>");
        // Fill exhibition detail
        DataSet dsexhibition = BC.GetExhibitionDet(Convert.ToInt32(Session["CompBrSno"].ToString()));
        for (int exhibition = 0; exhibition < dsexhibition.Tables[0].Rows.Count; exhibition++)
        {
            strData.Append("<option value='" + dsexhibition.Tables[0].Rows[exhibition]["SNo"].ToString() + "'>" + dsexhibition.Tables[0].Rows[exhibition]["Name"].ToString() + "</option>");
        }

        strData.Append("</select><input type='hidden' id='hdnupdate' name='hdnupdate'  /></div><div id='divProductOther' style='float:left;display: none;padding: 5px 0px 0px 3px; width:200px'><b>Type : </b><select  id='ddlProductOther' name='ddlProductOther' style='width:150px'>");
        // Fill Product Other
        SqlDataReader drProductsOther = inv.getProductOtherType(hdnType.Value.Contains("OCEAN") ? "SEA" : "AIR");
        while (drProductsOther.Read())
            strData.Append("<option value=\"" + drProductsOther["OtherType"].ToString() + "\">" + drProductsOther["OtherType"].ToString() + "</option>");
        strData.Append("</select></div></td></tr>");
        // MAWB and MAWB Date
        strData.Append("<tr><td><b>" + MAWB + " <span style='color:red'>*</span></b></td><td><input type='text' id='txtMAWB' name='txtMAWB' style='width:145px'/><input type='radio' id='rbtnPP' name='rbtnFreightType' value='PP' checked='checked'/>PP<input type='radio' name='rbtnFreightType' id='rbtnCC' value='CC'/>CC</td><td><b>" + MAWB + " Date<span style='color:red'>*</span></b></td><td><input type='text' id='txtMAWBDate' name='txtMAWBDate' style='width:145px'/><a href='javascript:void(0);' id='linkMAWBDate' onClick=\"setYears(1947, " + (DateTime.Now.Year + 1) + ");showCalender(this, 'txtMAWBDate');\"> <img src='../Images/calender.png' id='imgMAWBDate'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td></tr>");
        // HAWB No and ETD Date
        strData.Append("<tr><td><b>" + HAWB + " " + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtHAWB' name='txtHAWB' style='width:145px'/></td><td><b>ETD Date</b></td><td><input type='text' id='txtETDDate' name='txtETDDate' style='width:145px'/><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtETDDate');\"> <img src='../Images/calender.png'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td></tr>");
        // Shipper and Consignee
        strData.Append("<tr><td><b>Shipper" + (hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" && hdnType.Value.Substring(0, 5) != "OCEAN" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtShipper' name='txtShipper' style='width:300px'/><input type='hidden' id='hdnShipper' name='hdnShipper'/></td><td><b>Consignee" + (hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" && hdnType.Value.Substring(0, 5) != "OCEAN" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtConsignee' name='txtConsignee' style='width:300px'/><input type='hidden' id='hdnConsignee' name='hdnConsignee'/></td></tr>");
        // Origin and Destination
        strData.Append("<tr><td><b>Origin" + (hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtOrigin' name='txtOrigin' style='width:145px'/><input type='hidden' id='hdnOrgCity' name='hdnOrgCity'/> </td><td><b>Destination" + (hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtDestination' name='txtDestination' style='width:145px'/><input type='hidden' id='hdnDestCity' name='hdnDestCity'/></td></tr>");
        // No of Pkgs and Gross Wt
        strData.Append("<tr><td><b>No Of Packages</b></td><td><input type='text' id='txtNoOfPackages' name='txtNoOfPackages' value='0' style='width:145px'/></td><td><b>Gross Weight" + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtGrossWt' name='txtGrossWt' value='0.00'    style='width:145px'/></td></tr>");
        // Volume Wt and Chargeable Wt
        strData.Append("<tr><td><b>Volume Weight" + (hdnType.Value.Contains("OCEAN") ? "(CBM)" : string.Empty) + "" + (hdnBillType.Value != "OTHER" && hdnType.Value != "IMPORT" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtVolWt' name='txtVolWt'  value='0.00' style='width:145px'/></td><td><div style='float:left'><b>Chargeable Weight</div>" + (hdnBillType.Value != "OTHER" ? " <div style='float:left'><span id='spanChWt' style='color:red'>*</span></div>" : string.Empty) + "</b></td><td><div style='float:left'><input type='text' id='txtChWt' name='txtChWt' value='0.00' style='width:145px'/></div><div style='float:left;padding:0 2px 0 2px'> <b> <label id='lblBillingChWt'>" + (hdnType.Value.Contains("OCEAN") ? "Billing CBM" : "Billing ChWt") + "</label></b></div><div style='float:left'><span id='spanBillingChWtCBM' style='color:red'>*</span></div><div style='float:left'><input type='text' id='txtBillingChWt' onblur=\"return calculateVolume();\" name='txtBillingChWt' value='0.00' style='width:85px' " + (hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value.Contains("CREDITNOTE") || hdnBillType.Value.Contains("BROKERAGE") ? "onclick=\"return test(this.id);\"  onblur=\"return calculateExRate();\"" : string.Empty) + "/></div></td></tr>");
        // Airline and Commodity
        strData.Append("<tr><td><b>" + (hdnType.Value.Contains("OCEAN") ? "Shipping Line" : "Airline") + "" + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input type='text' id='txtAirline' name='txtAirline' style='width:145px'/><input type='hidden' id='hdnAirline' name='hdnAirline'/></td><td><b>Commodity " + (hdnBillType.Value != "OTHER" ? " <span style='color:red'>*</span>" : string.Empty) + "</b></td><td><div style='float:left'><input type='text' id='txtCommodity' name='txtCommodity' style='width:145px'/><input type='hidden' id='hdnCommodity' name='hdnCommodity'/></div>");
        if(hdnType.Value.Contains("OCEAN"))
        {
            strData.Append("<div style='float:left;padding:0 2px 0 2px'> <b> <label id='lblvolumeperkg'>Volume Per Kg</label></b></div><div style='float:left'><span id='spanvolumePerKg' style='color: red; display: block;'>*</span></div><div style='float:left'><input type='text'  id='txtvolumeperkg' name='txtVolumeperKg' style='width:80px'></div></div></td></tr>");
        }

        // Currency and Exchange Rate
        strData.Append("<tr><td><b>Currency <span style='color:red'>*</span></b></td><td><input type='text' id='txtCurrency' name='txtCurrency' style='width:145px'/> <input type='hidden' id='hdnCurrency' name='hdnCurrency' /></td><td><b>Exchange Rate <span style='color:red'>*</span></b></td><td><input type='text' id='txtExchangeRateTop' name='txtExchangeRateTop' " + (hdnType.Value == "EXPORT" ? "onblur=\"return calculateExRate();\"" : string.Empty) + " value='1.00' style='width:145px'/></td></tr>");
        // Exp./Shipper Invoice No and IEC No
        strData.Append("<tr><td><b>" + (hdnType.Value.Contains("OCEAN") ? "Dr. Note" : "Exp./Shipper Invoice") + " No</b></td><td><input type='text' id='txtExpInvNo' name='txtExpInvNo' style='width:145px'/></td><td><b>" + (hdnType.Value.Contains("OCEAN") ? "Container" : "IEC") + " No</b></td><td><input type='text' id='txtIECNo' name='txtIECNo' style='width:145px'/></td></tr>");
        // ShippingBillNo No 
        strData.Append("<tr><td><b>Shipping Bill Nos</b></td><td colspan='3'><input type='text' id='txtShippingBillNos' name='txtShippingBillNos' style='width:98%'/></td></tr>");
        // Printable Note
        strData.Append("<tr><td><b>Printable Note</b></td><td colspan='3'><input type='text' id='txtPrintablenote' name='txtPrintablenote' style='width:98%'/></td></tr>");
        // Not Printable Note
        strData.Append("<tr><td><b>Not Printable Note</b></td><td colspan='3'><input type='text' id='txtNonPrintableNote' name='txtNonPrintableNote' style='width:98%'/></td></tr>");
        // Service Tax Applicable
        strData.Append("<tr><td><b>Service Tax Applicable</b></td><td colspan='3'><input type='radio' name='rbtnSTax' id='rbtnStaxYes' value='Y' checked='checked'/>Y<input type='radio' name='rbtnSTax' id='rbtnStaxNo' value='N'/>N (Service Tax will be calculated @ <label id='lblStaxRate'></label> % on * marked Income Heads) </td></tr>");
        //////////////////////////////// DEBIT NOTE and CREDIT NOTE //////////////////////////////////////////////
        if (hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value.Contains("CREDITNOTE") || hdnBillType.Value.Contains("BROKERAGE"))
        {
            strData.Append("<tr class='pageHead'><td align='center' colspan='4'><b>CHARGES</b></td></tr>");
            strData.Append("<tr><td align='center' colspan='4'>");

            strData.Append("<table border='1' cellspacing='0px' ><tr style='width: 100%; background-image: url(../Images/Bar.jpg); background-position:center; background-repeat:repeat-x;height:20px;color:black;font-size:9pt;font-weight:bold;text-align:center'><td  style='width:9%'>ChargeType</td><td style='width:20%'>Particulars</td><td style='width:39%'>Description</td><td style='width:30%'>Amount</td></tr>");
            for (int dncn = 0; dncn < int.Parse(hdnDNCNRows.Value); dncn++)
            {
                strData.Append("<tr><td><select id='ddlDNCNChargeType" + dncn + "' name='ddlDNCNChargeType" + dncn + "' style='width:98%;' ><option value='DRCR'>DRCR</option></select></td><td><select id='ddlDNCNCharges" + dncn + "' name='ddlDNCNCharges" + dncn + "' style='width:98%' onchange=\"return checkDNCNCharges('ddlDNCNCharges" + dncn + "','" + dncn + "');\">");
                strData.Append("<option value='SELECT'>SELECT</option>");
                for (int dncnCharges = 0; dncnCharges < dsCharges.Tables[0].Rows.Count; dncnCharges++)
                {
                    strData.Append("<option value='" + (dsCharges.Tables[0].Rows[dncnCharges]["Sno"].ToString() + "~" + dsCharges.Tables[0].Rows[dncnCharges]["headname"].ToString().Trim().ToUpper() + "~" + dsCharges.Tables[0].Rows[dncnCharges]["Taxable"].ToString().ToUpper()) + "'>" + dsCharges.Tables[0].Rows[dncnCharges]["ChargeName"].ToString().ToUpper() + "</option>");
                }

                strData.Append("</select><input type='hidden' id='hdnDNCNTSno" + dncn + "' name='hdnDNCNTSno" + dncn + "' value='0'/></td><td><input type='text' id='txtDNCNDescription" + dncn + "' name='txtDNCNDescription" + dncn + "' style='width:98%'/></td><td><input type='text' id='txtDNCNAmount" + dncn + "' name='txtDNCNAmount" + dncn + "' style='width:32%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\" onchange=\"dncnChargeValidation('ddlDNCNCharges" + dncn + "','txtDNCNAmount" + dncn + "');\"/></td></tr>");
            }
            strData.Append("</table>");

            strData.Append("</td></tr>");
        }
        else
        {
            //////////////////////////////////////////// INCOME//////////////////////////////////////////////////
            DataSet dsCurrency = bImport.ImportCurrencyNew();
            strData.Append("<tr class='pageHead'><td align='center' colspan='4'><b>INCOME</b></td></tr>");
            strData.Append("<tr><td align='center' colspan='4'>");

            strData.Append("<table border='1' cellspacing='0px' ><tr style='width: 100%; background-image: url(../Images/Bar.jpg); background-position:center; background-repeat:repeat-x;height:20px;color:black;font-size:9pt;font-weight:bold;text-align:center'><td  style='width:9%'>ChargeType</td><td style='width:20%'>Particulars</td>" + (hdnType.Value.Contains("OCEAN") ? "<td style='width:4%'><label id='lblIncCurrHeader'>Curr</label></td><td style='width:4%'><label id='lblIncExRateHeader'>Ex.Rate</label></td><td style='width:4%'><label id='lblIncStatusHeader'>On</label></td><td style='width:8%'><label id='lblIncAmtHeader'>Amt</label></td><td style='width:10%'><label id='lblIncINRAmtHeader'>INR Amt</label></td>" : "<td style='width:30%'>Amount</td>") + "<td style='width:39%'>Description</td></tr>");
            for (int i = 0; i < int.Parse(hdnIncomeRows.Value); i++)
            {
                // AIR FREIGHT CHARGE, Airline Due Carrier and Due Agent
                if (Type.ToUpper() == "EXPORT" && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" && i < 3)
                {
                    if (i == 0)
                    {
                        // Air Freight
                        strData.Append("<tr id='trIncAirFreight'><td>BOOKING</td><td>AIR FREIGHT <input type='hidden' id='hdnIncomeTSno" + i + "' name='hdnIncomeTSno" + i + "' value='0'/></td><td>");

                        strData.Append("<table width='100%' ><tr><td></td><td><input id='txtRateIncome' name='txtRateIncome' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\"  onblur=\"return calculateExRate();\"/> <input type='hidden' id='hdnAFRate' name='hdnAFRate' value='0'/> </td><td>Rate</td><td></td><td></td></tr>");
                        strData.Append("<tr><td style='width:30%'></td><td style='width:15%'><input id='txtCommIncome' name='txtCommIncome' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td style='width:15%'>% Comm.</td><td style='width:15%'></td><td style='width:15%'></td></tr>");
                        strData.Append("<tr><td><input id='txtIncomeAmount" + i + "' name='txtIncomeAmount" + i + "' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\" /><input type='hidden' id='hdnAFIncome' name='hdnAFIncome' value='0'/> </td><td><input id='txtIncIncome' name='txtIncIncome' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td>% Inc. on</td><td><input id='txtIncOnIncome' name='txtIncOnIncome' value='95.00' style='text-align:right;width:98%'/></td><td>%</td></tr>");
                        strData.Append("<tr><td></td><td><input id='txtSpotIncome' name='txtSpotIncome' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td>Spot Rate</td><td></td><td></td></tr>");
                        strData.Append("<tr><td></td><td><input id='txtTDSIncome' name='txtTDSIncome' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td>% TDS</td><td></td><td></td></tr></table>");

                        strData.Append("</td><td><input type='text' id='txtDescription" + i + "' name='txtDescription" + i + "' style='width:98%'/></td></tr>");
                    }
                    else if (i == 1)
                    {
                        // Airline Due Carrier
                        strData.Append("<tr id='trIncAirlineDueCarrier'><td>BOOKING</td><td>AIR DUE CARRIER<input type='hidden' id='hdnIncomeTSno" + i + "' name='hdnIncomeTSno" + i + "' value='0'/></td><td><input id='txtIncomeAmount" + i + "' name='txtIncomeAmount" + i + "' style='width:32%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\" onchange=\"incomeChargeValidation('ddlIncomeChargeType" + i + "','ddlIncomeCharges" + i + "','txtIncomeAmount" + i + "');\"/></td><td><input type='text' id='txtDescription" + i + "' name='txtDescription" + i + "' style='width:98%'/></td></tr>");
                    }
                    else if (i == 2)
                    {
                        // Due Agent
                        strData.Append("<tr id='trIncDueAgent'><td>BOOKING</td><td>DUE AGENT * <input type='hidden' id='hdnIncomeTSno" + i + "' name='hdnIncomeTSno" + i + "' value='0'/></td><td><input id='txtIncomeAmount" + i + "' name='txtIncomeAmount" + i + "' style='width:32%;text-align:right' value='400.00' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\" onchange=\"incomeChargeValidation('ddlIncomeChargeType" + i + "','ddlIncomeCharges" + i + "','txtIncomeAmount" + i + "');\"/></td><td><input type='text' id='txtDescription" + i + "' name='txtDescription" + i + "' style='width:98%'/></td></tr>");
                    }


                }
                else// ((Type.ToUpper() == "EXPORT" && i > 2) || Type.ToUpper() != "EXPORT")
                {
                    strData.Append("<tr><td><select id='ddlIncomeChargeType" + i + "' name='ddlIncomeChargeType" + i + "' style='width:98%;' ><option value='SELECT'>SELECT</option><option value='BOOKING'>BOOKING</option><option value='CHA'>CHA</option><option value='IMPREST'>IMPREST</option><option value='GSP'>GSP</option><option value='GODOWN'>GODOWN</option><option value='TC'>TC</option>" + (hdnType.Value.Contains("OCEAN") ? "<option value='" + (hdnAWBType.Value == "H" ? "M" : "H") + "BL'>" + (hdnAWBType.Value == "H" ? "M" : "H") + "BL</option>" : string.Empty) + "</select></td><td><select id='ddlIncomeCharges" + i + "' name='ddlIncomeCharges" + i + "' style='width:98%' onchange=\"return checkIncomeCharges('ddlIncomeCharges" + i + "','" + i + "');\">");
                    strData.Append("<option value='SELECT'>SELECT</option>");
                    for (int incomeCharges = 0; incomeCharges < dsCharges.Tables[0].Rows.Count; incomeCharges++)
                    {
                        strData.Append("<option value='" + (dsCharges.Tables[0].Rows[incomeCharges]["Sno"].ToString() + "~" + dsCharges.Tables[0].Rows[incomeCharges]["headname"].ToString().Trim().ToUpper() + "~" + dsCharges.Tables[0].Rows[incomeCharges]["Taxable"].ToString().ToUpper()) + "'>" + dsCharges.Tables[0].Rows[incomeCharges]["ChargeName"].ToString().ToUpper() + "</option>");
                    }

                    strData.Append("</select><input type='hidden' id='hdnIncomeTSno" + i + "' name='hdnIncomeTSno" + i + "' value='0'/></td>");
                    if (hdnType.Value.Contains("OCEAN"))
                    {
                        strData.Append("<td><select id='ddlIncCurr" + i + "' name='ddlIncCurr" + i + "' style='width:98%' onchange=\"CurrencyIncomeAmount('ddlIncStatus" + i + "','ddlIncCurr" + i + "','txtIncomeAmount" + i + "','txtIncExRate" + i + "','txtIncAmt" + i + "','txtDescription" + i + "');\">");
                        foreach (DataRow drCurr in dsCurrency.Tables[0].Rows)
                        {
                            strData.Append("<option value='" + drCurr["CurrencyCode"] + "'" + (drCurr["CurrencyCode"].ToString() == "INR" ? "selected='selected'" : string.Empty) + ">" + drCurr["CurrencyCode"] + "</option>");
                        }
                        strData.Append("</td><td><input type='text' id='txtIncExRate" + i + "' name='txtIncExRate" + i + "' style='width:90%;text-align:right' value='1.00' onblur=\"CurrencyIncomeAmount('ddlIncStatus" + i + "','ddlIncCurr" + i + "','txtIncomeAmount" + i + "','txtIncExRate" + i + "','txtIncAmt" + i + "','txtDescription" + i + "');\"/></td><td><select id='ddlIncStatus" + i + "' name='ddlIncStatus" + i + "' onchange=\"CurrencyIncomeAmount('ddlIncStatus" + i + "','ddlIncCurr" + i + "','txtIncomeAmount" + i + "','txtIncExRate" + i + "','txtIncAmt" + i + "','txtDescription" + i + "');\"><option selected='selected' value='FIX'>FIX</option><option value='CBM'>CBM</option><option value='PKG'>PKG</option></select></select></td><td><input type='text' id='txtIncAmt" + i + "' name='txtIncAmt" + i + "' style='width:95%;text-align:right' value='0' onblur=\"CurrencyIncomeAmount('ddlIncStatus" + i + "','ddlIncCurr" + i + "','txtIncomeAmount" + i + "','txtIncExRate" + i + "','txtIncAmt" + i + "','txtDescription" + i + "');\"/></td>");
                    }
                    strData.Append("<td><input type='text' id='txtIncomeAmount" + i + "' name='txtIncomeAmount" + i + "' style='width:" + (hdnType.Value.Contains("OCEAN") ? "95%" : "32%") + ";text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\" onchange=\"incomeChargeValidation('ddlIncomeChargeType" + i + "','ddlIncomeCharges" + i + "','txtIncomeAmount" + i + "');\"/></td><td><input type='text' id='txtDescription" + i + "' name='txtDescription" + i + "' style='width:98%'/></td></tr>");
                }

            }
            strData.Append("</table>");

            strData.Append("</td></tr>");
            ////////////////////////////////////////////EXPENSES////////////////////////////////////////
            strData.Append("<tr class='pageHead'><td align='center' colspan='4'><b>EXPENSE</b></td></tr>");
            strData.Append("<tr><td align='center' colspan='4'>");
            strData.Append("<table border='1' cellspacing='0px' ><tr style='width: 100%; background-image: url(../Images/Bar.jpg); background-position:center; background-repeat:repeat-x;height:20px;color:black;font-size:9pt;font-weight:bold;text-align:center'><td style='width: 5%'>Ch.Type</td><td style='width: 9%'>Particulars</td><td style='width: 10%'>Supplier</td><td style='width: 7%'>InvNo.</td><td style='width: 7%'>InvDate</td><td style='width: 7%'>DueDate</td><td style='width: 4%'>TDS</td><td style='width: 4%'>ConCr</td><td style='width: 4%'>Curr</td><td style='width: 4%'>ExRate</td><td style='width: 5%'>Amt</td><td style='width: 6%'>INRAmt</td><td style='width: 4%'>STax</td><td style='width: 5%'>Type</td><td style='width: 5%'>Status</td><td colspan='3' style='width: 14%'>Remarks</td></tr>");

            for (int exp = 0; exp < int.Parse(hdnExpRows.Value); exp++)
            {
                // AIR FREIGHT CHARGE, Airline Due Carrier and Due Agent
                if (Type.ToUpper() == "EXPORT" && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" && exp < 3)
                {
                    if (exp == 0)
                    {
                        // Air Freight
                        strData.Append("<tr style='font-size:10px' id='trExpAirFreight'><td>BOOKING</td><td>AIR FREIGHT<input type='hidden' id='hdnExpTSno" + exp + "' name='hdnExpTSno" + exp + "' value='0'/></td><td><input type='text' id='txtExpSupplier0' name='txtExpSupplier0' style='width:95%'/><input type='hidden' id='hdnExpSupplierSno0' name='hdnExpSupplierSno0'/></td><td><input type='text' id='txtExpInvNo0' name='txtExpInvNo0' style='width:90%'/></td><td><input type='text' id='txtExpInvDate0' name='txtExpInvDate0' style='width:65%' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\" /><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDate0');\"> <img src='../Images/calender.png' width='20%'></a>");
                        // Inv date Calender
                        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                        strData.Append("</td><td><input type='text' id='txtExpInvDueDate0' name='txtExpInvDueDate0' style='width:65%' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\" /><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDueDate0');\"> <img src='../Images/calender.png' width='20%'></a>");
                        // Due Date Calender
                        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                        strData.Append("</td><td></td><td><input type='text' id='txtExpConCrdt0' name='txtExpConCrdt0' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlExpCurr0' name='ddlExpCurr0' style='width:98%' onchange=\"CurrencyAmount('ddlExpCurr0','txtExpINRAmt0','txtExpExRate0','txtExpAmt0','ddlExpCharges0','txtExpSTaxAmt0','ddlExpChargeType0');\">");
                        for (int expCurrRow0 = 0; expCurrRow0 < dsCurrency.Tables[0].Rows.Count; expCurrRow0++)
                        {
                            strData.Append("<option value='" + dsCurrency.Tables[0].Rows[expCurrRow0]["CurrencyCode"] + "'" + (dsCurrency.Tables[0].Rows[expCurrRow0]["CurrencyCode"].ToString() == "INR" ? "selected='selected'" : string.Empty) + ">" + dsCurrency.Tables[0].Rows[expCurrRow0]["CurrencyCode"] + "</option>");
                        }
                        strData.Append("</select></td><td><input type='text' id='txtExpExRate0' name='txtExpExRate0' style='width:90%;text-align:right' value='1.00' onblur=\"CurrencyAmount('ddlExpCurr0','txtExpINRAmt0','txtExpExRate0','txtExpAmt0','ddlExpCharges0','txtExpSTaxAmt0','ddlExpChargeType0');\"/></td><td><input type='text' id='txtExpAmt0' name='txtExpAmt0' style='width:90%;text-align:right' value='0' onblur=\"CurrencyAmount('ddlExpCurr0','txtExpINRAmt0','txtExpExRate0','txtExpAmt0','ddlExpCharges0','txtExpSTaxAmt0','ddlExpChargeType0');\"/></td><td><input type='text' id='txtExpINRAmt0' name='txtExpINRAmt0' style='width:90%;text-align:right' value='0' onchange=\"CurrencyAmount('ddlExpCurr0','txtExpINRAmt0','txtExpExRate0','txtExpAmt0','ddlExpCharges0','txtExpSTaxAmt0','ddlExpChargeType0');\"/><input type='hidden' id='hdnAFExpense' name='hdnAFExpense' value='0'/> </td><td></td><td><select id='ddlExpType0' name='ddlExpType0' style='width:98%'><option value='P'>ESTIMATED</option><option value='E'>ACTUAL</option></select></td><td><select id='ddlExpStatus0' name='ddlExpStatus0' style='width:98%' onchange=\"checkEstAct('" + exp + "');\"><option value='UNPAID'>UNPAID</option><option value='PAID'>PAID</option></select></td><td>");

                        strData.Append("<table width='100%' ><tr><td><input id='txtRateExp' name='txtRateExp' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return calculateFreightExpenseIATA();\"/><input type='hidden' id='hdnRateExp' name='hdnRateExp' value='0'/></td><td>Rate</td><td></td><td></td></tr>");
                        strData.Append("<tr><td style='width:30%'><input id='txtCommExp' name='txtCommExp' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td style='width:25%'>% Comm.</td><td style='width:30%'></td><td style='width:10%'></td></tr>");
                        strData.Append("<tr><td><input id='txtIncExp' name='txtIncExp' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td>% Inc. on</td><td><input id='txtIncOnExp' name='txtIncOnExp' value='95.00' style='text-align:right;width:98%'/></td><td>%</td></tr>");
                        strData.Append("<tr><td><input id='txtSpotExp' name='txtSpotExp' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td>Spot Rate</td><td></td><td></td></tr>");
                        strData.Append("<tr><td><input id='txtTDSExp' name='txtTDSExp' value='0' style='text-align:right;width:98%' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td>% TDS</td><td></td><td></td></tr></table>");

                        strData.Append("</td></tr>");
                    }
                    else if (exp == 1)
                    {
                        // Airline Due Carrier
                        strData.Append("<tr style='font-size:10px' id='trExpAirlineDueCarrier'><td>BOOKING</td><td>AIRLINE D. CAR.<input type='hidden' id='hdnExpTSno" + exp + "' name='hdnExpTSno" + exp + "' value='0'/></td><td><input type='text' id='txtExpSupplier1' name='txtExpSupplier1' style='width:95%'/><input type='hidden' id='hdnExpSupplierSno1' name='hdnExpSupplierSno1'/></td><td><input type='text' id='txtExpInvNo1' name='txtExpInvNo1'style='width:90%'/></td><td><input type='text' id='txtExpInvDate1' name='txtExpInvDate1' style='width:65%' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\" /><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDate1');\"> <img src='../Images/calender.png' width='20%'></a>");
                        // Inv date Calender
                        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                        strData.Append("</td><td><input type='text' id='txtExpInvDueDate1' name='txtExpInvDueDate1' style='width:65%' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\" /><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDueDate1');\"> <img src='../Images/calender.png' width='20%'></a>");
                        // Due Date Calender
                        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                        strData.Append("</td><td><input type='text' id='txtExpTDS1' name='txtExpTDS1' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><input type='text' id='txtExpConCrdt1' name='txtExpConCrdt1' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlExpCurr1' name='ddlExpCurr1' style='width:98%' onchange=\"CurrencyAmount('ddlExpCurr1','txtExpINRAmt1','txtExpExRate1','txtExpAmt1','ddlExpCharges1','txtExpSTaxAmt1','ddlExpChargeType1');\">");
                        for (int expCurrRow1 = 0; expCurrRow1 < dsCurrency.Tables[0].Rows.Count; expCurrRow1++)
                        {

                            strData.Append("<option value='" + dsCurrency.Tables[0].Rows[expCurrRow1]["CurrencyCode"] + "' " + (dsCurrency.Tables[0].Rows[expCurrRow1]["CurrencyCode"].ToString() == "INR" ? "selected='selected'" : string.Empty) + ">" + dsCurrency.Tables[0].Rows[expCurrRow1]["CurrencyCode"] + "</option>");
                        }
                        strData.Append("</select></td><td><input type='text' id='txtExpExRate1' name='txtExpExRate1' style='width:90%;text-align:right' value='1.00' onblur=\"CurrencyAmount('ddlExpCurr1','txtExpINRAmt1','txtExpExRate1','txtExpAmt1','ddlExpCharges1','txtExpSTaxAmt1','ddlExpChargeType1');\"/></td><td><input type='text' id='txtExpAmt1' name='txtExpAmt1' style='width:90%;text-align:right' value='0' onblur=\"CurrencyAmount('ddlExpCurr1','txtExpINRAmt1','txtExpExRate1','txtExpAmt1','ddlExpCharges1','txtExpSTaxAmt1','ddlExpChargeType1');\"/></td><td><input type='text' id='txtExpINRAmt1' name='txtExpINRAmt1' style='width:90%;text-align:right' value='0' onchange=\"CurrencyAmount('ddlExpCurr1','txtExpINRAmt1','txtExpExRate1','txtExpAmt1','ddlExpCharges1','txtExpSTaxAmt1','ddlExpChargeType1');\"/></td><td><input type='text' id='txtExpSTaxAmt1' name='txtExpSTaxAmt1' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlExpType1' name='ddlExpType1' style='width:98%'><option value='E'>ACTUAL</option><option value='P'>ESTIMATED</option></select></td><td><select id='ddlExpStatus1' name='ddlExpStatus1' style='width:98%' onchange=\"checkEstAct('" + exp + "');\"><option value='UNPAID'>UNPAID</option><option value='PAID'>PAID</option></select></td><td><input id='txtExpRemarks1' name='txtExpRemarks1' style='width:95%'/></td></tr>");
                    }
                    else if (exp == 2)
                    {
                        // Due Agent
                        strData.Append("<tr style='font-size:10px' id='trExpDueAgent'><td>BOOKING</td><td>DUE AGENT *<input type='hidden' id='hdnExpTSno" + exp + "' name='hdnExpTSno" + exp + "' value='0'/></td><td><input type='text' id='txtExpSupplier2' name='txtExpSupplier2' style='width:95%'/><input type='hidden' id='hdnExpSupplierSno2' name='hdnExpSupplierSno2'/></td><td><input type='text' id='txtExpInvNo2' name='txtExpInvNo2' style='width:90%'/></td><td><input type='text' id='txtExpInvDate2' name='txtExpInvDate2' style='width:65%' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\"/><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDate2');\"> <img src='../Images/calender.png' width='20%'></a>");

                        // Inv date Calender
                        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                        strData.Append("</td><td><input type='text' id='txtExpInvDueDate2' name='txtExpInvDueDate2' style='width:65%' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\"/><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDueDate2');\"> <img src='../Images/calender.png' width='20%'></a>");
                        // Due Date Calender
                        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                        strData.Append("</td><td><input type='text' id='txtExpTDS2' name='txtExpTDS2' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><input type='text' id='txtExpConCrdt2' name='txtExpConCrdt2' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlExpCurr2' name='ddlExpCurr2' style='width:98%' onchange=\"CurrencyAmount('ddlExpCurr2','txtExpINRAmt2','txtExpExRate2','txtExpAmt2',,'txtExpSTaxAmt2','ddlExpCharges2','txtExpSTaxAmt2','ddlExpChargeType2');\">");

                        for (int expCurrRow2 = 0; expCurrRow2 < dsCurrency.Tables[0].Rows.Count; expCurrRow2++)
                        {
                            strData.Append("<option value='" + dsCurrency.Tables[0].Rows[expCurrRow2]["CurrencyCode"] + "' " + (dsCurrency.Tables[0].Rows[expCurrRow2]["CurrencyCode"].ToString() == "INR" ? "selected='selected'" : string.Empty) + ">" + dsCurrency.Tables[0].Rows[expCurrRow2]["CurrencyCode"] + "</option>");
                        }
                        strData.Append("</select></td><td><input type='text' id='txtExpExRate2' name='txtExpExRate2' style='width:90%;text-align:right' value='1.00' onblur=\"CurrencyAmount('ddlExpCurr2','txtExpINRAmt2','txtExpExRate2','txtExpAmt2','ddlExpCharges2','txtExpSTaxAmt2','ddlExpChargeType2');\"/></td><td><input type='text' id='txtExpAmt2' name='txtExpAmt2' style='width:90%;text-align:right' value='400.00' onblur=\"CurrencyAmount('ddlExpCurr2','txtExpINRAmt2','txtExpExRate2','txtExpAmt2','ddlExpCharges2','txtExpSTaxAmt2','ddlExpChargeType2');\"/></td><td><input type='text' id='txtExpINRAmt2' name='txtExpINRAmt2' style='width:90%;text-align:right' value='400.00' onchange=\"CurrencyAmount('ddlExpCurr2','txtExpINRAmt2','txtExpExRate2','txtExpAmt2','ddlExpCharges2','txtExpSTaxAmt2','ddlExpChargeType2');\"/></td><td><input type='text' id='txtExpSTaxAmt2' name='txtExpSTaxAmt2' style='width:90%;text-align:right' value='" + (Math.Round(400 * decimal.Parse(hdnStaxRate.Value) / 100, 2)) + "' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlExpType2' name='ddlExpType2' style='width:98%'><option value='E'>ACTUAL</option><option value='P'>ESTIMATED</option></select></td><td><select id='ddlExpStatus2' name='ddlExpStatus2' style='width:98%' onchange=\"checkEstAct('" + exp + "');\"><option value='UNPAID'>UNPAID</option><option value='PAID'>PAID</option></select></td><td><input id='txtExpRemarks2' name='txtExpRemarks2' style='width:95%'/></td></tr>");
                    }


                }
                else// if ((Type.ToUpper() == "EXPORT" && exp > 2) || Type.ToUpper() != "EXPORT")
                {
                    strData.Append("<tr style='font-size:10px'><td><select id='ddlExpChargeType" + exp + "' name='ddlExpChargeType" + exp + "' style='width:98%;' ><option value='SELECT'>SELECT</option><option value='BOOKING'>BOOKING</option><option value='CHA'>CHA</option><option value='IMPREST'>IMPREST</option><option value='GSP'>GSP</option><option value='GODOWN'>GODOWN</option><option value='TC'>TC</option>" + (hdnType.Value.Contains("OCEAN") ? "<option value='" + (hdnAWBType.Value == "H" ? "M" : "H") + "BL'>" + (hdnAWBType.Value == "H" ? "M" : "H") + "BL</option>" : string.Empty) + "</select></td><td><select id='ddlExpCharges" + exp + "' name='ddlExpCharges" + exp + "' style='width:98%' onchange=\"return checkExpenseCharges('ddlExpCharges" + exp + "','" + exp + "');\">");
                    strData.Append("<option value='SELECT'>SELECT</option>");
                    for (int expCharges = 0; expCharges < dsCharges.Tables[0].Rows.Count; expCharges++)
                    {
                        strData.Append("<option value='" + (dsCharges.Tables[0].Rows[expCharges]["Sno"].ToString() + "~" + dsCharges.Tables[0].Rows[expCharges]["HeadName"].ToString().Trim().ToUpper() + "~" + dsCharges.Tables[0].Rows[expCharges]["Taxable"].ToString().ToUpper()) + "'>" + dsCharges.Tables[0].Rows[expCharges]["ChargeName"].ToString().ToUpper() + "</option>");
                    }

                    strData.Append("</select><input type='hidden' id='hdnExpTSno" + exp + "' name='hdnExpTSno" + exp + "' value='0'/></td><td><input type='text' id='txtExpSupplier" + exp + "' name='txtExpSupplier" + exp + "' style='width:95%'/><input type='hidden' id='hdnExpSupplierSno" + exp + "' name='hdnExpSupplierSno" + exp + "'/></td><td><input type='text' id='txtExpInvNo" + exp + "' name='txtExpInvNo" + exp + "' style='width:90%'/></td><td><input type='text' id='txtExpInvDate" + exp + "' name='txtExpInvDate" + exp + "' style='width:65%' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\"/><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDate" + exp + "');\" > <img src='../Images/calender.png' width='20%'></a>");
                    // Inv date Calender
                    strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                    strData.Append("</td><td><input type='text' id='txtExpInvDueDate" + exp + "' name='txtExpInvDueDate" + exp + "' onfocus=\"getDueDateExp('txtExpInvDate" + exp + "','txtExpInvDueDate" + exp + "');\" style='width:65%'/><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtExpInvDueDate" + exp + "');\"> <img src='../Images/calender.png' width='20%'></a>");
                    // Due Date Calender
                    strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                    strData.Append("</td><td><input type='text' id='txtExpTDS" + exp + "' name='txtExpTDS" + exp + "' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><input type='text' id='txtExpConCrdt" + exp + "'  name='txtExpConCrdt" + exp + "'  style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlExpCurr" + exp + "' name='ddlExpCurr" + exp + "' style='width:98%' onchange=\"CurrencyAmount('ddlExpCurr" + exp + "','txtExpINRAmt" + exp + "','txtExpExRate" + exp + "','txtExpAmt" + exp + "','ddlExpCharges" + exp + "','txtExpSTaxAmt" + exp + "','ddlExpChargeType" + exp + "');\">");
                    for (int expCurrRow = 0; expCurrRow < dsCurrency.Tables[0].Rows.Count; expCurrRow++)
                    {

                        strData.Append("<option value='" + dsCurrency.Tables[0].Rows[expCurrRow]["CurrencyCode"] + "' " + (dsCurrency.Tables[0].Rows[expCurrRow]["CurrencyCode"].ToString() == "INR" ? "selected='selected'" : string.Empty) + ">" + dsCurrency.Tables[0].Rows[expCurrRow]["CurrencyCode"] + "</option>");
                    }
                    strData.Append("</select></td><td><input type='text' id='txtExpExRate" + exp + "' name='txtExpExRate" + exp + "' style='width:90%;text-align:right' value='1.00' onblur=\"CurrencyAmount('ddlExpCurr" + exp + "','txtExpINRAmt" + exp + "','txtExpExRate" + exp + "','txtExpAmt" + exp + "','ddlExpCharges" + exp + "','txtExpSTaxAmt" + exp + "','ddlExpChargeType" + exp + "');\"/></td><td><input type='text' id='txtExpAmt" + exp + "' name='txtExpAmt" + exp + "' style='width:90%;text-align:right' value='0' onblur=\"CurrencyAmount('ddlExpCurr" + exp + "','txtExpINRAmt" + exp + "','txtExpExRate" + exp + "','txtExpAmt" + exp + "','ddlExpCharges" + exp + "','txtExpSTaxAmt" + exp + "','ddlExpChargeType" + exp + "');\"/></td><td><input type='text' id='txtExpINRAmt" + exp + "' name='txtExpINRAmt" + exp + "' style='width:90%;text-align:right' value='0' onchange=\"CurrencyAmount('ddlExpCurr" + exp + "','txtExpINRAmt" + exp + "','txtExpExRate" + exp + "','txtExpAmt" + exp + "','ddlExpCharges" + exp + "','txtExpSTaxAmt" + exp + "','ddlExpChargeType" + exp + "');\"/></td><td><input type='text' id='txtExpSTaxAmt" + exp + "' name='txtExpSTaxAmt" + exp + "' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlExpType" + exp + "' name='ddlExpType" + exp + "' style='width:98%'><option value='E'>ACTUAL</option><option value='P'>ESTIMATED</option></select></td><td><select id='ddlExpStatus" + exp + "'  name='ddlExpStatus" + exp + "' style='width:98%' onchange=\"checkEstAct('" + exp + "');\"><option value='UNPAID'>UNPAID</option><option value='PAID'>PAID</option></select></td><td><input id='txtExpRemarks" + exp + "'  name='txtExpRemarks" + exp + "' style='width:95%'/></td></tr>");
                }
                StringBuilder strJavascriptExpSupplier = new StringBuilder();
                strJavascriptExpSupplier.Append(
                     @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/SupplierAirline.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "',  Width: 264,ValueControlID:document.getElementById('hdnExpSupplierSno" + exp + "').id  };  $('#txtExpSupplier" + exp + "').autocomplete(options);   });");
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForExpSupplier" + exp,
                                                    strJavascriptExpSupplier.ToString(), true);
            }
            strData.Append("</table>");

            strData.Append("</td></tr>");

            ///////////////////////////////////////////// RI DETAIL//////////////////////////////////////
            strData.Append("<tr class='pageHead'><td align='center' colspan='4'><div style='float:left;position:absolute;text-decoration:blink'> <a href='javascript:addNewRIDivShow();' style='color:white;'> Add New</a></div><b>RI DETAIL</b></td></tr>");
            strData.Append("<tr><td align='center' colspan='4'>");

            strData.Append("<table width='100%' border='1' cellspacing='0px'><tr style='width: 100%; background-image: url(../Images/Bar.jpg); background-position:center; background-repeat:repeat-x;height:20px;color:black;font-size:9pt;font-weight:bold;text-align:center'><td style='width: 5%'>Ch.Type</td><td style='width: 14%'>RI Name</td><td style='width: 14%'>RI Cheque Name</td><td style='width: 7%'>Mode</td><td style='width: 5%'>Rate</td><td style='width: 10%'>Rate On</td><td style='width: 8%'>Amount</td><td style='width: 10%'>InvoiceNo</td><td style='width: 8%'>InvoiceDate</td><td style='width: 19%'>Remarks</td></tr>");
            for (int r = 0; r < int.Parse(hdnRIRows.Value); r++)
            {
                strData.Append("<tr><td style='width: 5%'>RI</td><td><select id='ddlRIName" + r + "' name='ddlRIName" + r + "' style='width:98%' onchange=\"return calculateRICommission('txtRIRate" + r + "','ddlRIRateOn" + r + "','ddlRIName" + r + "','txtRIChequeName" + r + "','txtRIAmount" + r + "');\">");
                SqlDataReader drRIName = BC.RIName_Select();
                strData.Append("<option value='SELECT'>SELECT</option>");

                while (drRIName.Read())
                {
                    strData.Append("<option value='" + drRIName["Name"].ToString() + "'>" + drRIName["Name"].ToString() + "</option>");

                }
                strData.Append("</select></td><td><input type='hidden' id='hdnRISno" + r + "' name='hdnRISno" + r + "' value='0'/><input type='text' id='txtRIChequeName" + r + "' name='txtRIChequeName" + r + "' style='width:95%'/></td><td><select id='ddlRIMode" + r + "'  name='ddlRIMode" + r + "' style='width:98%'><option value='CASH'>CASH</option><option value='CHEQUE'>CHEQUE</option></select></td><td><input type='text' id='txtRIRate" + r + "' name='txtRIRate" + r + "' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><select id='ddlRIRateOn" + r + "'  name='ddlRIRateOn" + r + "' style='width:98%' onchange=\"return calculateRICommission('txtRIRate" + r + "','ddlRIRateOn" + r + "','ddlRIName" + r + "','txtRIChequeName" + r + "','txtRIAmount" + r + "');\"><option value='SELECT'>SELECT</option><option value='FIXED'>FIXED</option><option value='PER KG'>PER KG</option>" + (hdnType.Value.Contains("OCEAN") ? "<option value='PER CBM'>PER CBM</option>" : string.Empty) + "<option value='%'>%</option></select></td><td><input type='text' id='txtRIAmount" + r + "' name='txtRIAmount" + r + "' style='width:95%;text-align:right' value='0' onblur=\"return hiddenfld(this.id);return calculateRICommission('txtRIRate" + r + "','ddlRIRateOn" + r + "','ddlRIName" + r + "','txtRIChequeName" + r + "','txtRIAmount" + r + "');\" onclick=\"return test(this.id);\"/></td><td><input type='text' id='txtRIInvoiceNo" + r + "' style='width:95%'/></td><td><input type='text' id='txtRIInvoiceDate" + r + "' name='txtRIInvoiceDate" + r + "' style='width:70%;'/><a href='javascript:void(0);' onClick=\"setYears(1947, " + (DateTime.Now.Year + 5) + ");showCalender(this, 'txtRIInvoiceDate" + r + "');\"> <img src='../Images/calender.png'></a>");
                strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
                strData.Append("</td><td><input type='text' id='txtRIRemarks" + r + "' name='txtRIRemarks" + r + "' style='width:98%;'/></td></tr>");
            }

            strData.Append("</table>");

            strData.Append("</td></tr>");
        }
        ///////////////////////////////////////////// IMPORTANT //////////////////////////////////////
        strData.Append("<tr class='pageHead'><td align='center' colspan='4'><b>IMPORTANT</b></td></tr>");
        strData.Append("<tr><td align='center' colspan='4'>");
        strData.Append("<table border='1' class='formTable'><tr><td style='width:5%;text-align:right'><b>1:-</b></td><td>You could not change Bill Date, MAWB/MBL, MAWB/MBL Date and HAWB/HBL at the time of Bill Creation/Updation. These could be change in Other Invoice Creation/Updation.</td></tr>");
        strData.Append("<tr><td style='width:5%;text-align:right'><b>2:-</b></td><td>System will take Bill Date automatically as last bill date according to Invoice series.</td></tr>");
        strData.Append("<tr><td style='width:5%;text-align:right'><b>3:-</b></td><td>Note that at the time of Customer, Shipper, Consignee, Currency and Suppliers selection, use <b>UP DOWN ARROW and TAB keys.</b></td></tr>");
        strData.Append("<tr><td style='width:5%;text-align:right'><b>4:-</b></td><td><b>For Air Export</b>, Due Agent charge showing in Income part as Rs. 400 (taxable, service tax calculated automatically) and in Expense part as Rs. 400 and STax Rs. 41.20 by default.</td></tr>");
        strData.Append("<tr><td style='width:5%;text-align:right'><b>5:-</b></td><td><b>Service Tax automatically calculate in STaxAmt of Expense part, if expense charges are taxable. Expense amount is the sum of INR Amount and STax amount. If you are not want STax Amount then you can edit with 0.</b></td></tr>");
        strData.Append("<tr><td style='width:5%;text-align:right'><b>6:-</b></td><td>In Income part enter amount in Billing Currency.</td></tr>");
        strData.Append("<tr><td style='width:5%;text-align:right'><b>7:-</b></td><td>Charge Type showing as Booking, CHA, Godown, Imprest, GSP and TC. You must be select any one option at the time of charge entry.</td></tr>");
        strData.Append("</table>");
        strData.Append("</td></tr>");
        strData.Append("</table>");








        // Load Coustomer
        if (hdnType.Value != "IMPORT")
        {
            Page.ClientScript.RegisterClientScriptInclude(this.GetType(), "scriptBindJSFile", ResolveClientUrl("~/Scripts/Common/JQuery/jquery.autocomplete.js"));



            // Load Customer for export and ocean
            StringBuilder strJavascript = new StringBuilder();
            strJavascript.Append(
                 @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&Bill=Y',  Width: 500,valueControlID:document.getElementById('hndinvSno').id,onExtraFunction:getInvToNameSNo }; $('#txtInvName').autocomplete(options); });");
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForCustomers",
                                                strJavascript.ToString(), true);
        }
        else
        {
            Page.ClientScript.RegisterClientScriptInclude(this.GetType(), "scriptBindJSFile", ResolveClientUrl("~/Scripts/Common/JQuery/jquery.autocompletePace.js"));
            // Load CAN Customer
            StringBuilder strJavascriptCANCustomer = new StringBuilder();
            if (Session["CompBrType"].ToString().ToUpper() != "PNP")
            {
                strJavascriptCANCustomer.Append(
                     @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/CanCustomer.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "',  Width: 350,ValueControlID:document.getElementById('hndinvSno').id,onExtraFunction:getCANSNo};  $('#txtInvName').autocomplete(options); });");
            }
            else
            {
                strJavascriptCANCustomer.Append(
                         @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=CONSIGNEE',  Width: 350,ValueControlID:document.getElementById('hndinvSno').id,onExtraFunction:getCANSNo};  $('#txtInvName').autocomplete(options); });");
            }
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForCANCustomers",
                                                strJavascriptCANCustomer.ToString(), true);
            // Load Sub Agent
            StringBuilder strJavascriptSubAgent = new StringBuilder();
            strJavascriptSubAgent.Append(
                 @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=SUB&Bill=Y',  Width: 350,ValueControlID:document.getElementById('hndSubAgentSno').id,onExtraFunction:getSubAgentSNo}; $('#txtSubAgent').autocomplete(options); });");
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForSubAgents",
                                                strJavascriptSubAgent.ToString(), true);

            // Load import Actual Customer
            StringBuilder strJavascriptImpActCust = new StringBuilder();
            strJavascriptImpActCust.Append(
                 @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&Bill=Y',  Width: 350,ValueControlID:document.getElementById('hndActCustSno').id,onExtraFunction:getImpActCustSNo}; $('#txtActCust').autocomplete(options); });");
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForImpActCust",
                                                strJavascriptImpActCust.ToString(), true);
        }
        // Load Actual Customer
        StringBuilder strJavascriptActCust = new StringBuilder();
        strJavascriptActCust.Append(
             @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "',  Width: 350,ValueControlID:document.getElementById('hiddenActCustSNo').id,onExtraFunction:getActCustSNo};    $('#txtActName').autocomplete(options);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForActCust", strJavascriptActCust.ToString(), true);

       #region GstNo Upload 09 June 2017
        // Load GstNo
////        StringBuilder strJavascriptGst = new StringBuilder();
////        strJavascriptGst.Append(
////             @"var options;
////    jQuery(function() {
////        options = {            
////serviceUrl: './Handlers/AgentGstNo.ashx',  Width: 150,ValueControlID:document.getElementById('hiddenGstNo').id};
////        $('#ddlGstNo').autocomplete(options);
////             });");
////        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForGstNo",
////                                            strJavascriptGst.ToString(), true);
        #endregion End of GstNo Upload

        // Load Shipper
        StringBuilder strJavascriptShip = new StringBuilder();
        if (hdnType.Value != "IMPORT")
        {
            strJavascriptShip.Append(
                 @"var options;
    jQuery(function() {
        options = {            
    serviceUrl: './Handlers/ShipperConsignee.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=SHIPPER',  Width: 350,ValueControlID:document.getElementById('hdnShipper').id};   $('#txtShipper').autocomplete(options);  });");
        }
        else
        {
            if (Session["CompBrType"].ToString().ToUpper() != "PNP")
            {
                strJavascriptShip.Append(
                     @"var options;
    jQuery(function() {
        options = {            
    serviceUrl: './Handlers/ImportShippers.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "',  Width: 350,ValueControlID:document.getElementById('hdnShipper').id};   $('#txtShipper').autocomplete(options);  });");
            }
            else
            {
                strJavascriptShip.Append(
                     @"var options;
    jQuery(function() {
        options = {            
    serviceUrl: './Handlers/ShipperConsignee.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=SHIPPER',  Width: 350,ValueControlID:document.getElementById('hdnShipper').id};   $('#txtShipper').autocomplete(options);  });");
            }
        }
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForShippers",
                                            strJavascriptShip.ToString(), true);

        // Load Consignee
        StringBuilder strJavascriptCon = new StringBuilder();
        if (hdnType.Value != "IMPORT")
        {
            strJavascriptCon.Append(
                 @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/ShipperConsignee.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=CONSIGNEE',  Width: 400,ValueControlID:document.getElementById('hdnConsignee').id}; $('#txtConsignee').autocomplete(options);  });");
        }
        else
        {
            if (Session["CompBrType"].ToString().ToUpper() != "PNP")
            {
                strJavascriptCon.Append(
                    @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/CanCustomer.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "',  Width: 400,ValueControlID:document.getElementById('hdnConsignee').id}; $('#txtConsignee').autocomplete(options);  });");
            }
            else
            {
                strJavascriptCon.Append(
                    @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/ShipperConsignee.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=CONSIGNEE',  Width: 400,ValueControlID:document.getElementById('hdnConsignee').id}; $('#txtConsignee').autocomplete(options);  });");
            }
        }
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForConsignees",
                                            strJavascriptCon.ToString(), true);

        // Load origin
        StringBuilder strJavascriptOrigin = new StringBuilder();
        strJavascriptOrigin.Append(
             @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/" + (hdnType.Value.Contains("OCEAN") ? @"CityNameCityCode" : @"CityCodeCityName") + @".ashx',  Width: 150,ValueControlID:document.getElementById('hdnOrgCity').id
        };
        $('#txtOrigin').autocomplete(options);  
             });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForOrigin",
                                            strJavascriptOrigin.ToString(), true);
        // Load Destination
        StringBuilder strJavascriptDest = new StringBuilder();
        strJavascriptDest.Append(
             @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/" + (hdnType.Value.Contains("OCEAN") ? @"CityNameCityCode" : @"CityCodeCityName") + @".ashx',  Width: 150,ValueControlID:document.getElementById('hdnDestCity').id
        };
        $('#txtOrigin').autocomplete(options);
        $('#txtDestination').autocomplete(options);        
             });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDest",
                                            strJavascriptDest.ToString(), true);
        // Load ShippingLine
        if (hdnType.Value.Contains("OCEAN"))
        {
            StringBuilder strJavascriptShippingLine = new StringBuilder();
            strJavascriptShippingLine.Append(
                 @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/ShippingLine.ashx',  Width: 150,ValueControlID:document.getElementById('hdnAirline').id
        };
        $('#txtAirline').autocomplete(options);
             });");
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForShippingLine",
                                                strJavascriptShippingLine.ToString(), true);
        }
        // Load Airline
        else if (hdnType.Value == "EXPORT" || hdnType.Value == "IMPORT")
        {
            StringBuilder strJavascriptAirline = new StringBuilder();
            strJavascriptAirline.Append(
                 @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/Airline.ashx',  Width: 150,ValueControlID:document.getElementById('hdnAirline').id
        };
        $('#txtAirline').autocomplete(options);
             });");
            ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForAirline",
                                                strJavascriptAirline.ToString(), true);
        }
        // Load Commodity
        StringBuilder strJavascriptCommodity = new StringBuilder();
        strJavascriptCommodity.Append(
             @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/Commodity.ashx',  Width: 150,ValueControlID:document.getElementById('hdnCommodity').id
        };
        $('#txtCommodity').autocomplete(options);
             });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForCommodity",
                                            strJavascriptCommodity.ToString(), true);
        // Load Currency
        StringBuilder strJavascriptCurrency = new StringBuilder();
        strJavascriptCurrency.Append(
             @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/Currency.ashx',  Width: 150,ValueControlID:document.getElementById('hdnCurrency').id,onExtraFunction:showHideIncColForOce
        };
        $('#txtCurrency').autocomplete(options);
             });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForCurrency",
                                            strJavascriptCurrency.ToString(), true);

    }

    public int checkCreditLimitStatus(string Customer, string IncomeAmt, string CustBrSNo)
    {

        if (Customer == "Select")
        {
            hdnErrMsg.Value = "Please Choose Customers for all the Incomes.";
            return 0;
        }
        BC.custBranchSNo = CustBrSNo;
        DataSet dsCheckCrLimt = BC.checkCreditLimit();
        if (dsCheckCrLimt.Tables[0].Rows[0]["UserStatus"].ToString() == "Blocked")
        {
            hdnErrMsg.Value = "Unable to bill this shipment because " + Customer + " has been Blacklisted. ";
            return 0;
        }
        if (dsCheckCrLimt.Tables[0].Rows[0]["PaymentMode"].ToString() == "Credit")
        {
            string CrLimitStatus = "";
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() == "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() == "0.00")
            {
                //hdnErrMsg.Value = "Unable to book this shipment because Availaible Credit Limit defined for " + Customer + " is Zero.";
                //return 0;
                if (Convert.ToDecimal(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString()) < Convert.ToDecimal(IncomeAmt))
                {
                    hdnErrMsg.Value = "Unable to bill this shipment because of less Credit Limit for " + Customer;
                    return 0;
                }
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() == "" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() == "")
            {
                hdnErrMsg.Value = "Unable to bill this shipment because of  Credit Limit is not defined for  " + Customer + ".";
                return 0;
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["BReviewDate"].ToString() == string.Empty || dsCheckCrLimt.Tables[0].Rows[0]["GReviewDate"].ToString() == string.Empty)
            {
                hdnErrMsg.Value = "Unable to bill this shipment because Credit Limit for " + Customer + " not reviewed.";
                return 0;
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != string.Empty)
            {
                CrLimitStatus = "Branch";
                if (Convert.ToDateTime(dsCheckCrLimt.Tables[0].Rows[0]["BReviewDate"].ToString()) < System.DateTime.Today)
                {
                    hdnErrMsg.Value = "Unable to bill this shipment because Credit Limit has expired for this customer on  " + dsCheckCrLimt.Tables[0].Rows[0]["BReviewDate"].ToString();
                    return 0;
                }
                if (Convert.ToDecimal(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString()) < Convert.ToDecimal(IncomeAmt))
                {
                    hdnErrMsg.Value = "Unable to bill this shipment because of less Credit Limit for " + Customer;
                    return 0;
                }
                hdnErrMsg.Value = "";
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != string.Empty)
            {
                CrLimitStatus = "Group";
                if (Convert.ToDateTime(dsCheckCrLimt.Tables[0].Rows[0]["GReviewDate"].ToString()) < System.DateTime.Today)
                {
                    hdnErrMsg.Value = "Unable to bill this shipment because Credit Limit has expired for this customer on  " + dsCheckCrLimt.Tables[0].Rows[0]["GReviewDate"].ToString();
                    return 0;
                }
                if (Convert.ToDecimal(dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) < Convert.ToDecimal(IncomeAmt))
                {
                    hdnErrMsg.Value = "Unable to bill this shipment because of less Credit Limit for " + Customer;
                    return 0;
                }
                hdnErrMsg.Value = "";
            }

        }
        //hdnErrMsg.Value = "";
        return 1;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //return;

        string billDateCompare = Request.Form["txtBillDate"].Split('-')[1] + '-' + Request.Form["txtBillDate"].Split('-')[0] + '-' + Request.Form["txtBillDate"].Split('-')[2];

        if (DateTime.Parse(billDateCompare) < DateTime.Parse("05/01/2017"))
        {
            if (Request.Form["ddlGstNo"].ToString() == "")
            {
                hdnErrMsg.Value = "Must enter Gst No  or Select GstState Code";
                return;
            }
        }

        #region Gst State Code Appicable from 01 july 2017
       
        DataTable dtCompGstNo=dw.GetAllFromQuery("select GstNo from CompanyDetails where sno="+Session["CompBrSNo"].ToString()+"");
        string CompGstno="07"; //delhi state code by default
        if(dtCompGstNo.Rows.Count>0)
        {
            CompGstno=dtCompGstNo.Rows[0]["GstNo"].ToString();
            CompGstno = CompGstno.Substring(0, 2);
        }
        string gstNoStateCode = "07";
        string GstNo = Request.Form["ddlGstNo"].ToString();
        if (GstNo == "")
        {
            gstNoStateCode = "07";
        }
        else
        {
            gstNoStateCode = GstNo.Substring(0,2);

        }
     
        #endregion


        GeneralFunction GF = new GeneralFunction();
        SqlConnection con = new SqlConnection(GF.ConnectionString);
        SqlTransaction tr = null;
        string InvoiceNo = "0";
        decimal bookingChWt = 0;
        decimal billingCBM = 0;

       
        try
        {
            con.Open();
            tr = con.BeginTransaction();
            string billDate, dueDate, awbDate;
            billDate = Request.Form["txtBillDate"].Split('-')[1] + '-' + Request.Form["txtBillDate"].Split('-')[0] + '-' + Request.Form["txtBillDate"].Split('-')[2];
            dueDate = Request.Form["txtDueDate"].Split('-')[1] + '-' + Request.Form["txtDueDate"].Split('-')[0] + '-' + Request.Form["txtDueDate"].Split('-')[2];
            //awbDate = Request.Form["txtMAWBDate"].Split('-')[1] + '-' + Request.Form["txtMAWBDate"].Split('-')[0] + '-' + Request.Form["txtMAWBDate"].Split('-')[2];
            try
            {
                awbDate = hdnMAWBDate.Value.Split('-')[1] + '-' + hdnMAWBDate.Value.Split('-')[0] + '-' + hdnMAWBDate.Value.Split('-')[2];
            }
            catch (Exception excep)
            {
                awbDate = Request.Form["txtMAWBDate"].Split('-')[1] + '-' + Request.Form["txtMAWBDate"].Split('-')[0] + '-' + Request.Form["txtMAWBDate"].Split('-')[2];
            }
            try
            {

                if (DateTime.Parse(billDate) > DateTime.Parse(dueDate))
                {
                    hdnErrMsg.Value = "Invoice Due Date must be equal or greater than Invoice Date.";
                    return;
                }
                else if (DateTime.Parse(dueDate) < DateTime.Parse(DateTime.Now.ToString("MM/dd/yyyy")))
                {
                    hdnErrMsg.Value = "Invoice Due Date must be equal or greater than today Date.";
                    return;
                }
            }
            catch (Exception exA)
            {

                if (DateTime.Parse(Request.Form["txtBillDate"].ToString()) > DateTime.Parse(Request.Form["txtDueDate"].ToString()))
                {
                    hdnErrMsg.Value = "Invoice Due Date must be equal or greater than Invoice Date.";
                    return;
                }
                else if (DateTime.Parse(Request.Form["txtDueDate"].ToString()) < DateTime.Parse(DateTime.Now.ToString("dd MMM yyyy")))
                {
                    hdnErrMsg.Value = "Invoice Due Date must be equal or greater than today Date.";
                    return;
                }
            }
            //decimal incomeAmount = 0;// with stax if rbtnstax == 'y'
            //decimal incomeSTaxAmt = 0;
            //decimal expenseAmount = 0;// with stax if txtexpstaxamt1-24 !=0
            //decimal expenseSTaxAmt = 0;
            //for (int expenseRow = 0; expenseRow < int.Parse(hdnExpRows.Value); expenseRow++)
            //{
            //    // Calculate Expense Air Freight for Export shipment
            //    if (expenseRow == 0 && Request.Form["txtExpINRAmt0"].ToString() != "0" && hdnType.Value == "EXPORT")
            //    {
            //        inv.rate_income = decimal.Parse(Request.Form["txtRateExp"]);
            //        inv.spot_rate_income = decimal.Parse(Request.Form["txtSpotExp"]);
            //        inv.chargeable_wt = decimal.Parse(Request.Form["txtChWt"]);

            //        inv.spot_diff_income = inv.spot_rate_income > 0 ? (inv.rate_income - inv.spot_rate_income) * inv.chargeable_wt : 0;
            //        inv.commissionable_income = inv.spot_rate_income > 0 ? inv.spot_rate_income * inv.chargeable_wt : inv.rate_income * inv.chargeable_wt;
            //        inv.comm_rate_income = decimal.Parse(Request.Form["txtCommExp"]);
            //        inv.comm_amt_income = inv.commissionable_income * (inv.comm_rate_income / 100);
            //        inv.inc_rate_income = decimal.Parse(Request.Form["txtIncExp"]);
            //        inv.inc_rate_on_income = decimal.Parse(Request.Form["txtIncOnExp"]);
            //        inv.incentivable_income = inv.commissionable_income * (inv.inc_rate_on_income / 100);
            //        inv.inc_amt_income = inv.incentivable_income * (inv.inc_rate_income / 100);
            //        inv.others_income = 0;
            //        decimal tds_appl_amt1 = inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income;
            //        inv.tds_rate_income = decimal.Parse(Request.Form["txtTDSExp"]);
            //        inv.tds_amt_income = tds_appl_amt1 * (inv.tds_rate_income / 100);

            //        //HiddenIncome.Value = AFIncome.Text;
            //        expenseAmount = expenseAmount + (Request.Form["rbtnFreightType"] == "PP" ? (decimal.Parse(Request.Form["txtExpINRAmt0"]) - inv.comm_amt_income - inv.inc_amt_income - inv.spot_diff_income + inv.tds_amt_income) : (inv.comm_amt_income + inv.inc_amt_income - inv.spot_diff_income));

            //    }
            //    else if (Request.Form["txtExpINRAmt" + expenseRow].ToString() != "0")
            //    {
            //        expenseSTaxAmt = expenseSTaxAmt + decimal.Parse(Request.Form["txtExpSTaxAmt" + expenseRow]);
            //        expenseAmount = expenseAmount + (Request.Form["txtExpINRAmt" + expenseRow].ToString() != "0" ? decimal.Parse(Request.Form["txtIncomeAmount" + expenseRow]) : 0) + decimal.Parse(Request.Form["txtExpSTaxAmt" + expenseRow]);

            //    }
            //}
            //for (int riRow = 0; riRow < int.Parse(hdnRIRows.Value); riRow++)
            //{
            //    expenseAmount = expenseAmount + (Request.Form["txtRIAmount" + riRow].ToString() != "0" ? decimal.Parse(Request.Form["txtRIAmount" + riRow]) : 0);
            //}


            //for (int incomeRow = 0; incomeRow < int.Parse(hdnIncomeRows.Value); incomeRow++)
            //{
            //    // Calculate Income Air Freight for Export shipment
            //    if (incomeRow == 0 && Request.Form["txtIncomeAmount0"].ToString() != "0" && hdnType.Value == "EXPORT")
            //    {
            //        inv.rate_income = decimal.Parse(Request.Form["txtRateIncome"]);
            //        inv.spot_rate_income = decimal.Parse(Request.Form["txtSpotIncome"]);
            //        inv.chargeable_wt = decimal.Parse(Request.Form["txtChWt"]);

            //        inv.spot_diff_income = inv.spot_rate_income > 0 ? (inv.rate_income - inv.spot_rate_income) * inv.chargeable_wt : 0;
            //        inv.commissionable_income = inv.spot_rate_income > 0 ? inv.spot_rate_income * inv.chargeable_wt : inv.rate_income * inv.chargeable_wt;
            //        inv.comm_rate_income = decimal.Parse(Request.Form["txtCommIncome"]);
            //        inv.comm_amt_income = inv.commissionable_income * (inv.comm_rate_income / 100);
            //        inv.inc_rate_income = decimal.Parse(Request.Form["txtIncIncome"]);
            //        inv.inc_rate_on_income = decimal.Parse(Request.Form["txtIncOnIncome"]);
            //        inv.incentivable_income = inv.commissionable_income * (inv.inc_rate_on_income / 100);
            //        inv.inc_amt_income = inv.incentivable_income * (inv.inc_rate_income / 100);
            //        inv.others_income = 0;
            //        decimal tds_appl_amt1 = inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income;
            //        inv.tds_rate_income = decimal.Parse(Request.Form["txtTDSIncome"]);
            //        inv.tds_amt_income = tds_appl_amt1 * (inv.tds_rate_income / 100);

            //        //HiddenIncome.Value = AFIncome.Text;
            //        incomeAmount = incomeAmount + (Request.Form["rbtnFreightType"] == "PP" ? (decimal.Parse(Request.Form["txtIncomeAmount0"]) - inv.comm_amt_income - inv.inc_amt_income - inv.spot_diff_income + inv.tds_amt_income) : (inv.comm_amt_income + inv.inc_amt_income - inv.spot_diff_income));

            //    }
            //    else if (incomeRow == 1 && Request.Form["txtIncomeAmount1"].ToString() != "0" && hdnType.Value == "EXPORT")
            //        incomeAmount = incomeAmount + Math.Round(decimal.Parse(Request.Form["txtIncomeAmount" + incomeRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);
            //    else if (incomeRow == 2 && Request.Form["txtIncomeAmount2"].ToString() != "0" && hdnType.Value == "EXPORT")
            //    {
            //        incomeAmount = incomeAmount + Math.Round(decimal.Parse(Request.Form["txtIncomeAmount" + incomeRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2) + Math.Round(decimal.Parse(Request.Form["txtIncomeAmount" + incomeRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"]) * decimal.Parse("0.103"), 2);
            //        incomeSTaxAmt = incomeSTaxAmt + (Request.Form["rbtnSTax"] == "Y" ? Math.Round((decimal.Parse(Request.Form["txtIncomeAmount" + incomeRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"])) * decimal.Parse("0.103"), 2) : 0);
            //    }
            //    else if (((hdnType.Value == "EXPORT" && incomeRow > 2) || hdnType.Value != "EXPORT") && Request.Form["ddlIncomeCharges" + incomeRow] != "SELECT" && Request.Form["txtIncomeAmount" + incomeRow].ToString() != "0")
            //    {
            //        incomeAmount = incomeAmount + (Request.Form["txtIncomeAmount" + incomeRow].ToString() != "0" ? Math.Round(decimal.Parse(Request.Form["txtIncomeAmount" + incomeRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2) + (Request.Form["rbtnSTax"] == "Y" && Request.Form["ddlIncomeCharges" + incomeRow].Split('~')[2].ToUpper() == "Y" ? Math.Round((decimal.Parse(Request.Form["txtIncomeAmount" + incomeRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"])) * decimal.Parse("0.103"), 2) : 0) : 0);
            //        incomeSTaxAmt = incomeSTaxAmt + (Request.Form["rbtnSTax"] == "Y" && Request.Form["ddlIncomeCharges" + incomeRow].Split('~')[2].ToUpper() == "Y" ? Math.Round((decimal.Parse(Request.Form["txtIncomeAmount" + incomeRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"])) * decimal.Parse("0.103"), 2) : 0);
            //    }
            //}
            if (hdnType.Value == "IMPORT")
            {
                if (Request.Form["rbtnCustomer"] == "CAN Customer")
                {
                    //if (decimal.Parse(hdnCANAmount.Value) > 7000 && hdnBillType.Value != "CREDITNOTE" && hdnCustType.Value.ToUpper() == "CASH" && Request.Form["rbtnFreightType"].ToString().ToUpper() == "PP")
                    //{
                    //    if (hdnInvoiceStatus.Value.ToUpper() != "APPROVED" && decimal.Parse(hdnCANAmount.Value) > decimal.Parse(hdnApprovedAmt.Value))
                    //    {
                    //        sendMail(Request.Form["txtMAWB"].ToString(), Request.Form["txtHAWB"].ToString(), 0, decimal.Parse(hdnCANAmount.Value), "CAN");
                    //        hdnPreviousPage.Value = ViewState["PreviousPage"].ToString();
                    //        return;
                    //    }
                    //}

                    inv.invto_code_type = "CAN Customer";
                    try
                    {
                        if (Request.Form["hndinvSno"] == "")
                        {
                            inv.invto_code = ViewState["CustIID"].ToString();
                            inv.invto_name = Request.Form["txtInvName"];
                        }
                        else
                        {
                            inv.invto_code = Request.Form["hndinvSno"];
                            inv.invto_name = Request.Form["txtInvName"];
                        }
                    }
                    catch
                    {
                        inv.invto_code = ViewState["CustIID"].ToString();
                        inv.invto_name = Request.Form["txtInvName"];
                    }
                    inv.invto_address = Request.Form["txtInv2Add"];
                }
                if (Request.Form["rbtnCustomer"] == "Actual Customer")
                {
                    inv.invto_code_type = "Actual Customer";
                    try
                    {
                        if (Request.Form["hiddenActCustSNo"] == "0")
                        {
                            //**********updated on 17 Nov 2016 Actual CustomerSno not picked
                            ////inv.invto_code = ViewState["ActCust"].ToString();
                            inv.invto_code = Request.Form["hndinvSno"];
                            inv.invto_name = Request.Form["txtActName"];
                            //////inv.act_code = ViewState["ActCust"].ToString();
                            //**********updated on 17 Nov 2016 Actual CustomerSno not picked


                            inv.act_code = Request.Form["hndinvSno"];
                        }
                        //**********updated on 17 Nov 2016 Actual CustomerSno not picked
                       else if (Request.Form["hiddenActCustSNo"] == "")
                        {
                            /////inv.invto_code = ViewState["ActCust"].ToString();

                           //**********updated on 17 Nov 2016 Actual CustomerSno not picked
                            inv.invto_code = Request.Form["hndinvSno"];
                            inv.invto_name = Request.Form["txtActName"];
                            inv.act_code = Request.Form["hndinvSno"];
                        }
                        //**********end of updated on 17 Nov 2016 Actual CustomerSno not picked
                        else 
                        {
                            if (Request.Form["hiddenActCustSNo"] == "undefined")
                            {
                                ////inv.invto_code = Request.Form["hiddenActCustSNo"];
                                ////inv.act_code = Request.Form["hiddenActCustSNo"];
                                ////inv.invto_name = Request.Form["txtActName"];

                                //**********updated on 17 Nov 2016 Actual CustomerSno not picked
                                inv.invto_code = Request.Form["hndinvSno"];
                                inv.invto_name = Request.Form["txtActName"];
                                inv.act_code = Request.Form["hndinvSno"];
                            }
                            else
                            {
                                inv.invto_code = Request.Form["hiddenActCustSNo"];
                                inv.act_code = Request.Form["hiddenActCustSNo"];
                                inv.invto_name = Request.Form["txtActName"];
                            }
                        }
                    }
                    catch
                    {
                        inv.invto_code = Request.Form["hiddenActCustSNo"];
                        inv.act_code = Request.Form["hiddenActCustSNo"];
                        inv.invto_name = Request.Form["txtActName"];
                    }
                    inv.invto_address = Request.Form["txtActualCustomer"];
                }
                if (Request.Form["rbtnCustomer"] == "Sub Agent")
                {
                    inv.invto_code_type = "Sub Agent";
                    try
                    {

                        inv.invto_code = Request.Form["hndSubAgentSno"];
                        inv.invto_name = Request.Form["txtSubAgent"];
                    }
                    catch
                    {
                        inv.invto_code = "0";
                        inv.invto_name = Request.Form["txtSubAgent"];
                    }
                    inv.invto_address = Request.Form["txtInv2Add"];
                }
                inv.act_ledger_code = "";
                inv.act_name = Request.Form["txtActName"];
            }
            else
            {
                inv.invto_ledger_code = "";
                inv.invto_code_type = "";
                inv.invto_code = Request.Form["hndinvSno"];
                inv.act_code = Request.Form["hiddenActCustSNo"];
                inv.invto_name = Request.Form["txtInvName"];
                inv.invto_address = Request.Form["txtInv2Add"];
                inv.act_ledger_code = "";
                inv.act_name = Request.Form["txtActName"];
            }

            /////// Check for Credit Limit  for customer ///////
            int Flag = 0;
            if (hdnBillType.Value != "PERFORMAINVOICE" && hdnBillType.Value != "PERFORMAINVOICEMODIFY" && (hdnType.Value == "IMPORT" ? Request.Form["rbtnCustomer"] != "CAN Customer" : 0 == 0) && hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE")
            {

                //decimal AddedAmt1 = incomeAmount - decimal.Parse(hdnOldIncomeAmount.Value);

                //Flag = checkCreditLimitStatus(inv.invto_name, AddedAmt1.ToString(), inv.invto_code);
                Flag = checkCreditLimitStatus(inv.invto_name, hdnUpdateCrAmount.Value, inv.invto_code);

                if (Flag == 0)
                {
                    Page_Init(Page, new System.EventArgs());
                    //btnSave.Visible = false;
                    return;
                }
            }
            /////// END Credit limit check ///////
            //return;
            // get data for Billing Master Insert/Update
            inv.SNo = int.Parse(hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMATOINVOICE" || hdnBillType.Value == "CREATE" || hdnBillType.Value.Contains("CREDITNOTE") || hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value.Contains("BROKERAGE") ? "0" : hdnSno.Value);
            inv.belongs2city = Belongs2city;
            inv.awbtable_sno = int.Parse(hdnAWBTableSno.Value);
            inv.bill_type = hdnBillType.Value == "DEBITNOTE" ? "DN" : (hdnBillType.Value.Contains("BROKERAGE") ? "BR" : (hdnBillType.Value.Contains("CREDITNOTE") ? "CN" : (hdnBillType.Value == "OTHER" ? "OTH" : (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PFI" : (hdnType.Value == "EXPORT" ? "AIR" : (hdnType.Value == "IMPORT" ? "IMP" : "OCE"))))));
            try { inv.bill_date = DateTime.Parse(billDate); }
            catch { inv.bill_date = DateTime.Parse(Request.Form["txtBillDate"].ToString()); }
            inv.freight_type = Request.Form["rbtnFreightType"];
            inv.invoice_pfx = (hdnType.Value == "IMPORT" ? Session["InvoicePrefix"].ToString() : hdnType.Value.Substring(0, 3));
            inv.invoice_no = 0;
            try { inv.inv_due_date = DateTime.Parse(dueDate); }
            catch { inv.inv_due_date = DateTime.Parse(Request.Form["txtDueDate"].ToString()); }
            inv.inv_type = Request.Form["ddlInvoiceType"];
            inv.sales_person = Request.Form["ddlSalesPerson"];
            //Gst From 01 July 2017
            inv.Gst_No = Request.Form["ddlGstNo"];

            inv.mawb_no = Request.Form["txtMAWB"];
            try { inv.mawb_date = DateTime.Parse(awbDate); }
            catch { inv.mawb_date = DateTime.Parse(Request.Form["txtMAWBDate"].ToString()); }
            inv.hawb_no = Request.Form["txtHAWB"];
            inv.airline = Request.Form["txtAirline"];
            inv.shipper = Request.Form["txtShipper"];
            inv.consignee = Request.Form["txtConsignee"];
            inv.origin = Request.Form["txtOrigin"];
            inv.destination = Request.Form["txtDestination"];
            inv.pkgs = Request.Form["txtNoOfPackages"];
            inv.gross_wt = decimal.Parse(Request.Form["txtGrossWt"]);
            inv.vol_wt = decimal.Parse(Request.Form["txtVolWt"]);//lblInvoiceNo
            if (hdnType.Value.Contains("OCEAN"))
                billingCBM = Request.Form["txtBillingChWt"] == null || Request.Form["txtBillingChWt"] == string.Empty ? 0 : decimal.Parse(Request.Form["txtBillingChWt"]);
            if (btnSave.Text.ToUpper() == "SAVE")
            {
                inv.chargeable_wt = hdnType.Value == "EXPORT" && hdnBillType.Value != "OTHER" ? decimal.Parse(Request.Form["txtBillingChWt"]) : (decimal.Parse(Request.Form["txtChWt"]) == 0 ? 1 : decimal.Parse(Request.Form["txtChWt"]));
                bookingChWt = hdnType.Value == "EXPORT" && hdnBillType.Value != "OTHER" ? decimal.Parse(Request.Form["txtChWt"]) : 0;
            }
            else
            {
                inv.chargeable_wt = hdnType.Value == "EXPORT" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? decimal.Parse(Request.Form["txtBillingChWt"]) : (decimal.Parse(Request.Form["txtChWt"]) == 0 ? 1 : decimal.Parse(Request.Form["txtChWt"]));
                bookingChWt = hdnType.Value == "EXPORT" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? decimal.Parse(Request.Form["txtChWt"]) : 0;

            }
            inv.shipping_bill_no = Request.Form["txtShippingBillNo"];
            inv.commodity = Request.Form["txtCommodity"];
            //inv.curr_code = Request.Form["hdnCurrency."];
            inv.curr_code = Request.Form["txtCurrency"];
            inv.note = Request.Form["txtPrintablenote"];
            inv.note1 = Request.Form["txtNonPrintableNote"];
           

            #region Gst Applicable from 1st july 2017

            //// get STax Rate
            using (CommonBusiness comBusiness = new CommonBusiness())
            {
                hdnStaxRate.Value = comBusiness.GetList("STaxRate", "TotalSTaxRate", "FromDate<='" + inv.bill_date.ToString() + "' and ToDate>='" + inv.bill_date.ToString() + "'").Rows[0][0].ToString();
                hdnSBCesTax.Value = comBusiness.GetList("STaxRate", "SBCessTax", "FromDate<='" + inv.bill_date.ToString() + "' and ToDate>='" + inv.bill_date.ToString() + "'").Rows[0][0].ToString();
                hdnKKCesTax.Value = comBusiness.GetList("STaxRate", "KKCessTax", "FromDate<='" + inv.bill_date.ToString() + "' and ToDate>='" + inv.bill_date.ToString() + "'").Rows[0][0].ToString();
            }
            if (DateTime.Parse(billDate) < DateTime.Parse("05/01/2017"))
            {
               
                inv.service_tax_rate = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnStaxRate.Value).ToString() : "0.00");
                inv.SBCessTax = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnSBCesTax.Value).ToString() : "0.00");
                inv.KKCessTax = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnKKCesTax.Value).ToString() : "0.00");
            }
            else
            {
                if (gstNoStateCode == CompGstno)
                {
                    //SGST and CGST applicable
                    inv.service_tax_rate = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnStaxRate.Value).ToString() : "0.00");
                    inv.SBCessTax = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnSBCesTax.Value).ToString() : "0.00");
                    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    inv.KKCessTax = 0;
                }
                else
                {
                    //IGST applicable

                    inv.service_tax_rate = 0;
                    inv.SBCessTax = 0;
                    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                    inv.KKCessTax = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnKKCesTax.Value).ToString() : "0.00");
                }
            }
            //****************End of Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
            #endregion
            inv.Service_Tax_Rate_12Pct = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnServiceTaxRate.Value).ToString() : "0.00");
            inv.Service_Tax_Rate_ECESSPct = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnECESS.Value).ToString() : "0.00");
            inv.Service_Tax_Rate_SHECPct = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnSHEC.Value).ToString() : "0.00");
            inv.due_carrier_income = hdnType.Value == "EXPORT" && hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE" && hdnBillType.Value != "MBLBROKERAGE" && hdnBillType.Value != "DEBITNOTE" ? decimal.Parse(Request.Form["txtIncomeAmount1"]) : 0;
            inv.due_agent_income = hdnType.Value == "EXPORT" && hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE" && hdnBillType.Value != "MBLBROKERAGE" && hdnBillType.Value != "DEBITNOTE" ? decimal.Parse(Request.Form["txtIncomeAmount2"]) : 0;
           
            ////****************Added on 22 June 2016 : KK cess: SB Cess in StaxRate ************
            decimal taxcal = 0;
            decimal income = 0;
            decimal sb = 0;
            decimal kk = 0;
            decimal stx = 0;
            decimal sbvalue = 0;
            decimal kkvalue = 0;

            if (gstNoStateCode == CompGstno)
            {
                //SGST and CGST applicable
                stx = decimal.Parse(hdnStaxRate.Value);
                sb = decimal.Parse(hdnSBCesTax.Value);
                kk =0;
            }

            else
            {
                //IGST applicable
                stx =0;
                sb =0;
                kk = decimal.Parse(hdnKKCesTax.Value);
            }

            income = hdnType.Value == "EXPORT" && hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE" && hdnBillType.Value != "MBLBROKERAGE" && hdnBillType.Value != "DEBITNOTE" ? decimal.Parse(Request.Form["txtIncomeAmount2"]) : 0;
            if (Request.Form["rbtnSTax"] == "Y")
            {
                sbvalue = income * (sb / 100);
                kkvalue = income * (kk / 100);
            }
            ////if (DateTime.Parse(billDate) >= DateTime.Parse("06-01-2016"))
            ////    taxcal = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(income * (stx + kk + sb) / 100).ToString() : "0.00");
            ////else
              
            ////taxcal = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(income*(stx+sb)/100).ToString(): "0.00");
            taxcal = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(income * (stx + kk + sb) / 100).ToString() : "0.00");
            inv.tot_stax_rate = taxcal;// incomeSTaxAmt;
            //**********************************END of 22 June 2016 *********************************************
            /////inv.tot_stax_rate = decimal.Parse(hdnIncSTaxAmt.Value);// incomeSTaxAmt;


            inv.discount_amt = 0;
            inv.discount_remark = "";
            inv.recd_amt = 0;
            inv.status = "";
            inv.created_from = "";
            inv.entered_by = Session["UserId"].ToString();
            inv.entered_at = System.DateTime.Now;
            inv.exchange_rate = decimal.Parse(Request.Form["txtExchangeRateTop"]);
            inv.g_tot_income = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse(hdnIncomeAmtNew.Value);//incomeAmount;
            inv.tot_expense = hdnBillType.Value.Contains("CREDITNOTE") ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse(hdnExpAmtNew.Value);//expenseAmount;
            ////****************Added on 22 June 2016 : KK cess: SB Cess in StaxRate ************
            if(Request.Form["rbtnSTax"] == "Y")
            {
                inv.g_tot_income = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse(hdnIncomeAmtNew.Value) + sbvalue + kkvalue;//incomeAmount;

                inv.tot_expense = hdnBillType.Value.Contains("CREDITNOTE") ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse(hdnExpAmtNew.Value) + sbvalue + kkvalue;//expenseAmount;
            ////    if (DateTime.Parse(billDate) >= DateTime.Parse("06-01-2016"))
            ////        inv.g_tot_income = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse(hdnIncomeAmtNew.Value) + sbvalue + kkvalue;//incomeAmount;
            ////    else
                 
            ////    inv.g_tot_income = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse(hdnIncomeAmtNew.Value)+sbvalue;//incomeAmount;
            ////
            }
            
            /////inv.tot_income = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? (decimal.Parse(hdnDNCNAmt.Value) - decimal.Parse(hdnDNCNStaxAmt.Value)) : (decimal.Parse(hdnIncomeAmtNew.Value) - decimal.Parse(hdnIncSTaxAmt.Value));//incomeAmount - incomeSTaxAmt;
            inv.tot_income = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? (decimal.Parse(hdnDNCNAmt.Value) - decimal.Parse(hdnDNCNStaxAmt.Value) - sbvalue - kkvalue) : (inv.g_tot_income - taxcal);//incomeAmount - incomeSTaxAmt;

            ////****************Added on 22 June 2016 : KK cess: SB Cess in StaxRate ************


            //////inv.tot_expense = hdnBillType.Value.Contains("CREDITNOTE") ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse(hdnExpAmtNew.Value);//expenseAmount;

            ////****************Added on 22 June 2016 : KK cess: SB Cess in StaxRate ************
            ////inv.tot_stax_rate = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? decimal.Parse(hdnDNCNStaxAmt.Value) : decimal.Parse(hdnIncSTaxAmt.Value);//incomeSTaxAmt;
            inv.tot_stax_rate = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? decimal.Parse(hdnDNCNStaxAmt.Value) : taxcal;//incomeSTaxAmt;
            //**********************************END of 22 June 2016 *********************************************

            ////////EXHIBITION////////
            int ExhibitionId = 0;
            hdnErrMsg.Value = Request.Form["ddlexhibitionlist"] == "SELECT" && Request.Form["ddlInvoiceType"] == "EXHIBITION" ? "Please Select Exhibition Name." : string.Empty;
            ExhibitionId = Request.Form["ddlInvoiceType"].Contains("EXHIBITION") ? int.Parse(Request.Form["ddlexhibitionlist"]) : 0;
            DateTime ETD = DateTime.MaxValue;
            try
            {
                ETD = Request.Form["txtETDDate"] != "" ? DateTime.Parse(Request.Form["txtETDDate"].Split('-')[1] + '-' + Request.Form["txtETDDate"].Split('-')[0] + '-' + Request.Form["txtETDDate"].Split('-')[2]) : DateTime.MaxValue;
            }
            catch (Exception excep)
            {
                ETD = Request.Form["txtETDDate"] != "" ? DateTime.Parse(Request.Form["txtETDDate"]) : DateTime.MaxValue;
            }
            //return;
            // Insert data in Billing Master
            if (btnSave.Text.ToUpper() == "SAVE")
            {
                int BCnfSNo;// AWBTable Sno
                try { BCnfSNo = int.Parse(hdnSno.Value); }
                catch { BCnfSNo = 0; }
                //try
                //{
                if (hdnBillType.Value.Contains("MBL"))
                    hdnSno.Value = "0";
                InvoiceNo = (hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value.Contains("CREDITNOTE") || hdnBillType.Value.Contains("BROKERAGE")) ? (hdnType.Value != "IMPORT" ? inv.insertBilling_masterCrDr(inv.awbtable_sno, Session["CompBrSNo"].ToString(), Session["CompBrType"].ToString(), hdnSno.Value, hdnType.Value, bookingChWt, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"])) : inv.insertBilling_masterCrDrImport(inv.awbtable_sno, Session["CompBrSno"].ToString(), Session["CompBrType"].ToString(), hdnSno.Value, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"]))) : (hdnBillType.Value == "PERFORMAINVOICE" ? inv.insertPerformaInvoiceMaster(BCnfSNo, Session["CompBrSNo"].ToString(), Session["CompBrType"].ToString(), string.Empty, ETD, Request.Form["txtExpInvNo"], ExhibitionId, Request.Form["rbtnSTax"], hdnType.Value, bookingChWt, billingCBM, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"])) : (hdnType.Value == "EXPORT" ? inv.insertBilling_masterNew2(BCnfSNo, Session["CompBrSNo"].ToString(), Session["CompBrType"].ToString(), string.Empty, ETD, Request.Form["txtExpInvNo"], ExhibitionId, Request.Form["rbtnSTax"], Request.Form["txtShippingBillNos"], Request.Form["txtIECNo"], bookingChWt, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"])) : (hdnType.Value == "IMPORT" ? inv.insertBilling_masterImportNew(Convert.ToInt32(hdnSno.Value), Session["CompBrSNo"].ToString(), ExhibitionId, Request.Form["rbtnSTax"], (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"])) : inv.insertBilling_masterSea(Convert.ToInt32(hdnSno.Value), Session["CompBrSNo"].ToString(), hdnType.Value, Request.Form["txtDNote"], Request.Form["rbtnSTax"], ExhibitionId, billingCBM, (Request.Form["ddlProductOther"] == null ? string.Empty : Request.Form["ddlProductOther"])))));
                if (hdnBillType.Value.Contains("MBL"))
                    hdnSno.Value = InvoiceNo;

                if (hdnBillType.Value == "PERFORMATOINVOICE")
                {
                    inv.SNo = Convert.ToInt32(hdnSno.Value);
                    string amt = inv.updatePerformaInvoice(Session["CompBrSNo"].ToString(), string.Empty, ETD, Request.Form["txtExpInvNo"], ExhibitionId, Request.Form["rbtnSTax"], Convert.ToInt32(InvoiceNo), bookingChWt, billingCBM, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"]));
                }
                //}
                //catch
                //{ }
                inv.SNo = Convert.ToInt32(InvoiceNo == "0" ? string.Empty : InvoiceNo);

                // Update WareHouse
                if (hdnBillType.Value != "PERFORMAINVOICE")
                {
                    GeneralFunction gfUpdate = new GeneralFunction();
                    SqlConnection conUpdate = new SqlConnection(gfUpdate.ConnectionString);
                    conUpdate.Open();
                    SqlTransaction trUpdate = conUpdate.BeginTransaction();
                    try
                    {
                        bWareHouse.updateWareHouseFromBilling(trUpdate, int.Parse(hdnAWBTableSno.Value), inv.SNo, hdnType.Value);
                        trUpdate.Commit();
                    }
                    catch (SqlException sql)
                    {
                        trUpdate.Rollback();
                    }
                    finally
                    {
                        if (conUpdate != null && conUpdate.State == ConnectionState.Open)
                            conUpdate.Close();
                    }
                }
            }
            // Update data in Billing Master
            string PaidAmount = "0";
            if (btnSave.Text.ToUpper() == "UPDATE")
            {
                inv.SNo = int.Parse(hdnSno.Value);
                InvoiceNo = hdnSno.Value;
                PaidAmount = hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.updatePerformaInvoice(Session["CompBrSNo"].ToString(), string.Empty, ETD, Request.Form["txtExpInvNo"], ExhibitionId, Request.Form["rbtnSTax"], 0, bookingChWt, billingCBM, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"])) : (hdnType.Value == "EXPORT" ? inv.updateBilling_masterNew3(Session["CompBrSNo"].ToString(), string.Empty, ETD, Request.Form["txtExpInvNo"], ExhibitionId, Request.Form["rbtnSTax"], Request.Form["txtShippingBillNos"], Request.Form["txtIECNo"], bookingChWt, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"])) : (hdnType.Value == "IMPORT" ? inv.updateBilling_masterNew2(Session["CompBrSNo"].ToString(), ExhibitionId, Request.Form["rbtnSTax"], (Request.Form["ddlProductOther"] == null ? string.Empty : Request.Form["ddlProductOther"])) : inv.updateBilling_masterSea(Session["CompBrSNo"].ToString(), Request.Form["txtDNote"], Request.Form["rbtnSTax"], ExhibitionId, billingCBM, (Request.Form["ddlProductOther"] == null || Request.Form["ddlInvoiceType"].ToUpper() != "OTHER" ? string.Empty : Request.Form["ddlProductOther"]))));


            }
            // Insert data in Billing Trans
            if (hdnBillType.Value != "DEBITNOTE" && hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE" && hdnBillType.Value != "MBLBROKERAGE")
            {

                ////////////////// INCOME //////////////////////
                dtIncome = (DataTable)Session["dtIncome"];
                //if (dtIncome.Rows.Count == 0)
                //    return;

                for (int inc = 0; inc < int.Parse(hdnIncomeRows.Value); inc++)
                {
                    DataRow[] drIncome = dtIncome.Select("tsno='" + Request.Form["hdnIncomeTSno" + inc] + "'  and headtype='I'");
                    //and headcode='" + (hdnType.Value == "EXPORT" && inc < 3 ? (inc == 0 ? "17" : (inc == 1 ? "21" : "154")) : (Request.Form["ddlIncomeCharges" + inc] == "SELECT" ? "0" : Request.Form["ddlIncomeCharges" + inc].Split('~')[0])) + "'

                    if (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) != 0 && Request.Form["ddlIncomeCharges" + inc] != "SELECT" && Request.Form["ddlIncomeChargeType" + inc] != "SELECT")
                    {
                        inv.master_sno = inv.SNo;
                        inv.headtype = Convert.ToChar("I");
                        inv.headcode = (hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc == 0 ? 17 : (inc == 1 ? 21 : 154)) : int.Parse(Request.Form["ddlIncomeCharges" + inc].Split('~')[0]));
                        inv.headname = (hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc == 0 ? "Air Freight" : (inc == 1 ? "Airline Due Carrier" : "Due Agent")) : Request.Form["ddlIncomeCharges" + inc].Split('~')[1]);
                        inv.supplier_ledger_code = "";
                        inv.supplier_name = Request.Form["txtInvName"];
                        inv.supplier_sno = Request.Form["hndinvSno"];
                        inv.taxable = char.Parse((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc == 0 ? "N" : (inc == 1 ? "N" : "Y")) : Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper()));
                        inv.awb_rate = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? decimal.Parse(Request.Form["txtRateIncome"]) : 0);
                        inv.amount = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? decimal.Parse(Request.Form["txtIncomeAmount" + inc]) : Math.Round(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2));
                       if (Session["CompName"].ToString().Split('-')[0].Contains("RED EXPRESS"))
                        { 
                            inv.ServiceTax12Pct = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.Service_Tax_Rate_12Pct / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.Service_Tax_Rate_12Pct / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]),2);
                            inv.ECess = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.Service_Tax_Rate_ECESSPct / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.Service_Tax_Rate_ECESSPct / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);
                            inv.HECess = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.Service_Tax_Rate_SHECPct / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.Service_Tax_Rate_SHECPct / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);
                            inv.Roundoff = Math.Round(Math.Round(inv.ServiceTax12Pct + inv.ECess + inv.HECess) - (inv.ServiceTax12Pct + inv.ECess + inv.HECess), 2);
                            //inv.stax_amt = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]));
                            inv.stax_amt = (inv.ServiceTax12Pct + inv.ECess + inv.HECess + inv.Roundoff);
                        }
                        else
                           inv.stax_amt = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);



                          //=============Add ByPradeep======================
                       inv.SBCessAmt = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.SBCessTax / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.SBCessTax / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.SBCessTax / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.SBCessTax / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);
                       //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                       inv.KKCessAmt = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.KKCessTax / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.KKCessTax / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.KKCessTax / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.KKCessTax / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);
                       //****************End of Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        if (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O")
                        {
                            inv.rate_income = decimal.Parse(Request.Form["txtRateIncome"]);
                            inv.spot_rate_income = decimal.Parse(Request.Form["txtSpotIncome"]);
                            inv.chargeable_wt = decimal.Parse(Request.Form["txtBillingChWt"]);

                            inv.spot_diff_income = inv.spot_rate_income > 0 ? (inv.rate_income - inv.spot_rate_income) * inv.chargeable_wt : 0;
                            inv.commissionable_income = inv.spot_rate_income > 0 ? inv.spot_rate_income * inv.chargeable_wt : (inv.curr_code == "INR" ? inv.rate_income * inv.chargeable_wt : inv.rate_income * inv.exchange_rate);
                            inv.comm_rate_income = decimal.Parse(Request.Form["txtCommIncome"]);
                            inv.comm_amt_income = inv.commissionable_income * (inv.comm_rate_income / 100);
                            inv.inc_rate_income = decimal.Parse(Request.Form["txtIncIncome"]);
                            inv.inc_rate_on_income = decimal.Parse(Request.Form["txtIncOnIncome"]);
                            inv.incentivable_income = inv.commissionable_income * (inv.inc_rate_on_income / 100);
                            inv.inc_amt_income = inv.incentivable_income * (inv.inc_rate_income / 100);
                            inv.others_income = 0;
                            //decimal tds_appl_amt1 = inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income;
                            inv.tds_rate_income = decimal.Parse(Request.Form["txtTDSIncome"]);
                            inv.tds_amt_income = (inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income) * (inv.tds_rate_income / 100);
                        }

                        inv.comm_rate = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.comm_rate_income : 0);
                        inv.comm_amt = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.comm_amt_income : 0);
                        inv.inc_rate = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.inc_rate_income : 0);
                        inv.inc_rate_on = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.inc_rate_on_income : 0);
                        inv.inc_amt = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.inc_amt_income : 0);
                        inv.spot_rate = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.spot_rate_income : 0);
                        inv.spot_amt = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inv.spot_rate_income * inv.chargeable_wt) : 0);
                        inv.spot_difference = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.spot_diff_income : 0);
                        if (inv.headname == "COMMISSION" || inv.headname == "INCENTIVE" && hdnBillType.Value != "DEBITNOTE" && hdnType.Value == "EXPORT")
                        {
                            //************Added on 05 Apr 2017: Tds Rate 5 from 10*****************
                            //*******From 1st April 2017: Tds rate should be 5 from 10*******
                            /////inv.tds_rate = 10;
                            inv.tds_rate = 5;
                            inv.on_tds_amt = inv.amount;
                            ////inv.tds_amt = Math.Round(((inv.amount * 10) / 100), 2);
                            inv.tds_amt = Math.Round(((inv.amount * 5) / 100), 2);
                            //************ End of 05 Apr 2017: Tds Rate 5 from 10******************************//
                            inv.tds_amt_income = inv.tds_amt;
                        }
                        else
                        {
                            inv.tds_rate = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.tds_rate_income : 0);
                            inv.on_tds_amt = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income) : 0);
                            inv.tds_amt = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.tds_amt_income : 0);
                        }
                        //=================add by pradeep inv.SBCessAmt======================
                        inv.bill_amount = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (Request.Form["rbtnFreightType"] == "PP" ? (decimal.Parse(Request.Form["txtIncomeAmount0"]) - inv.comm_amt_income - inv.inc_amt_income - inv.spot_difference + inv.tds_amt_income) : (inv.comm_amt_income + inv.inc_amt_income - inv.spot_difference)) : (inv.amount + inv.stax_amt +inv.SBCessAmt+inv.KKCessAmt + ((inv.headname.Contains("COMMISSION") || inv.headname.Contains("INCENTIVE") && hdnBillType.Value != "DEBITNOTE" && hdnType.Value == "EXPORT") ? inv.tds_amt : 0)));

                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ///////inv.bill_amount = (hdnType.Value == "EXPORT" && inc == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (Request.Form["rbtnFreightType"] == "PP" ? (decimal.Parse(Request.Form["txtIncomeAmount0"]) - inv.comm_amt_income - inv.inc_amt_income - inv.spot_difference + inv.tds_amt_income) : (inv.comm_amt_income + inv.inc_amt_income - inv.spot_difference)) : (inv.amount + inv.stax_amt + inv.KKCessAmt + ((inv.headname.Contains("COMMISSION") || inv.headname.Contains("INCENTIVE") && hdnBillType.Value != "DEBITNOTE" && hdnType.Value == "EXPORT") ? inv.tds_amt : 0)));
                        //****************End of Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************



                        inv.curr_code = Request.Form["txtCurrency"];
                        inv.description = Request.Form["txtDescription" + inc];

                        if (btnSave.Text.ToUpper() == "SAVE" || drIncome.Length == 0)
                        {
                            inv.curr_code = Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncCurr" + inc] : Request.Form["txtCurrency"];
                            string strInsert = string.Empty;
                            // insert into biiling_tran
                            if (Request.Form["ddlIncomeChargeType" + inc] != null)
                            {
                                if (Request.Form["ddlIncomeChargeType" + inc].ToUpper() == "MBL" && hdnAWBType.Value == "H")
                                {
                                    //return;
                                    // for Ocean HBL Invoices
                                    //if(drIncome.Length == 0)
                                    strInsert = inv.insertSeaMBLBillingCharges(tr, Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), "HBL", string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"), inv.mawb_date, Session["UserID"].ToString(), int.Parse(Session["CompBrSno"].ToString()), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"));
                                    //else
                                    //if (hdnBillType.Value == "PERFORMATOINVOICE")
                                    inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnIncomeTSno" + inc].ToString()), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                                }
                                else if (Request.Form["ddlIncomeChargeType" + inc].ToUpper() != "HBL")
                                {
                                    strInsert = hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.insertPerformaInvoiceTrans(Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), Convert.ToDateTime("Jan 01 1900"), 0) : inv.insertBilling_transNew(Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"));

                                }
                                DataView dvSeaMBLCharge = new DataView(dtIncome, "tsno='" + Request.Form["hdnIncomeTSno" + inc] + "'  and headtype='I'", "tsno", DataViewRowState.CurrentRows);
                                if (dvSeaMBLCharge.ToTable().Rows.Count > 0)
                                {
                                    if (Request.Form["ddlIncomeChargeType" + inc].ToUpper() != "HBL" && hdnAWBType.Value == "M" && dvSeaMBLCharge.ToTable().Rows[0]["ChargeSource"].ToString().Contains("HBL"))
                                    {
                                        inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnIncomeTSno" + inc]), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                                    }
                                    if (dvSeaMBLCharge.ToTable().Rows[0]["ChargeSource"].ToString().Contains("BOOKING"))
                                    {
                                        inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnIncomeTSno" + inc]), "BOOKING", Session["UserID"].ToString(), inv.SNo);
                                    }

                                }

                            }
                            else if ((hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]) != "HBL")
                            {
                                strInsert = hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.insertPerformaInvoiceTrans(Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), Convert.ToDateTime("Jan 01 1900"), 0) : inv.insertBilling_transNew(Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"));

                            }
                        }
                        else if (btnSave.Text.ToUpper() == "UPDATE" && drIncome.Length > 0)
                        {
                            string strUpdate = string.Empty;
                            if (Request.Form["ddlIncomeChargeType" + inc] != null)
                            {
                                if (Request.Form["ddlIncomeChargeType" + inc].ToUpper() == "MBL" && hdnAWBType.Value == "H")
                                {
                                    // for Ocean HBL Invoices
                                    inv.curr_code = Request.Form["txtCurrency"] == "INR" ? Request.Form["ddlIncCurr" + inc] : Request.Form["txtCurrency"];
                                    strUpdate = inv.updateSeaMBLBillingCharges(tr, int.Parse(Request.Form["hdnIncomeTSno" + inc]), Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), "HBL", string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"), Session["UserID"].ToString());
                                }
                                else
                                {
                                    DataView dvSeaMBLChargeUpdate = new DataView(dtIncome, "tsno='" + Request.Form["hdnIncomeTSno" + inc] + "'  and (headtype='I') and ChargeSource='HBL'", "tsno", DataViewRowState.CurrentRows);
                                    if (dvSeaMBLChargeUpdate.ToTable().Rows.Count > 0)
                                    {
                                        if (Request.Form["ddlIncomeChargeType" + inc].ToUpper() != "HBL" && hdnAWBType.Value == "M" && dvSeaMBLChargeUpdate.ToTable().Rows[0]["ChargeSource"].ToString().Contains("HBL"))
                                        {
                                            string strInsertFromSeaMblChgs = hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.insertPerformaInvoiceTrans(Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), Convert.ToDateTime("Jan 01 1900"), 0) : inv.insertBilling_transNew(Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"));
                                            inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnIncomeTSno" + inc]), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                                        }
                                        if (Request.Form["ddlIncomeChargeType" + inc].ToUpper() != "BOOKING" && dvSeaMBLChargeUpdate.ToTable().Rows[0]["BillType"].ToString().Contains("BOOKING"))
                                        {
                                            inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnIncomeTSno" + inc]), "BOOKING", Session["UserID"].ToString(), inv.SNo);
                                        }
                                    }
                                    // update billing_trans
                                    strUpdate = hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.updatePerformaInvoiceTrans(int.Parse(Request.Form["hdnIncomeTSno" + inc]), Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), Convert.ToDateTime("Jan 01 1900"), 0) : inv.updateBilling_transNew(int.Parse(Request.Form["hdnIncomeTSno" + inc]), Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"), Session["UserID"].ToString());
                                }
                            }
                            else
                            {
                                // update billing_trans
                                strUpdate = hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? inv.updatePerformaInvoiceTrans(int.Parse(Request.Form["hdnIncomeTSno" + inc]), Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), Convert.ToDateTime("Jan 01 1900"), 0) : inv.updateBilling_transNew(int.Parse(Request.Form["hdnIncomeTSno" + inc]), Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["txtIncExRate" + inc] : Request.Form["txtExchangeRateTop"]), (hdnType.Value == "EXPORT" && inc < 3 ? "BOOKING" : Request.Form["ddlIncomeChargeType" + inc]), string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" && hdnType.Value.Contains("OCEAN") ? Request.Form["ddlIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"), Session["UserID"].ToString());
                            }
                            dtIncome.Rows.RemoveAt(dtIncome.Rows.IndexOf(drIncome[0]));
                        }
                    }
                }
                ////////////////// EXPENSES //////////////////////
                dtExpense = (DataTable)Session["dtExpense"];
                for (int ex = 0; ex < int.Parse(hdnExpRows.Value); ex++)
                {
                    DataRow[] drExpense = dtExpense.Select("tsno='" + Request.Form["hdnExpTSno" + ex] + "'  and headtype='" + (Request.Form["ddlExpType" + ex]) + "'");
                    //and headcode='" + (hdnType.Value == "EXPORT" && ex < 3 ? (ex == 0 ? "18" : (ex == 1 ? "21" : "154")) : (Request.Form["ddlExpCharges" + ex] == "SELECT" ? "0" : Request.Form["ddlExpCharges" + ex].Split('~')[0])) + "'
                    if (decimal.Parse(Request.Form["txtExpAmt" + ex]) != 0 && Request.Form["ddlExpCharges" + ex] != "SELECT" && Request.Form["ddlExpChargeType" + ex] != "SELECT")
                    {
                        inv.master_sno = inv.SNo;
                        inv.headtype = Convert.ToChar(Request.Form["ddlExpType" + ex]);
                        inv.headcode = (hdnType.Value == "EXPORT" && ex < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex == 0 ? 18 : (ex == 1 ? 21 : 154)) : int.Parse(Request.Form["ddlExpCharges" + ex].Split('~')[0]));
                        inv.headname = (hdnType.Value == "EXPORT" && ex < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex == 0 ? "Air Freight (IATA)" : (ex == 1 ? "Airline Due Carrier" : "Due Agent")) : Request.Form["ddlExpCharges" + ex].Split('~')[1]);
                        inv.supplier_ledger_code = "";
                        inv.supplier_name = Request.Form["txtExpSupplier" + ex];
                        SqlDataReader drSuppSno = inv.getSupplierSno(Request.Form["txtExpSupplier" + ex], int.Parse(Session["CompBrSno"].ToString()));
                        inv.supplier_sno = drSuppSno.Read() ? drSuppSno[0].ToString() : Request.Form["hdnExpSupplierSno" + ex];

                        inv.taxable = char.Parse((hdnType.Value == "EXPORT" && ex < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex == 0 ? "N" : (ex == 1 ? "N" : "Y")) : Request.Form["ddlExpCharges" + ex].Split('~')[2].ToUpper()));
                        inv.awb_rate = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? decimal.Parse(Request.Form["txtRateExp"]) : 0);
                        inv.amount = decimal.Parse(Request.Form["txtExpAmt" + ex]) * decimal.Parse(Request.Form["txtExpExRate" + ex]);
                        if (Session["CompName"].ToString().Split('-')[0].Contains("RED EXPRESS"))
                        {
                            //////updated on 06 june 2017
                            
                           ///////// inv.stax_amt =Math.Round((hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? 0 : (decimal.Parse(Request.Form["txtExpSTaxAmt" + ex]))));
                        }
                        else
                        {
                            ////updated on 06 june 2017

                            ////inv.stax_amt = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? 0 : inv.curr_code
                            ////   == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpSTaxAmt" + ex])) : (decimal.Parse(Request.Form["txtExpSTaxAmt" + ex])));
                            //////inv.stax_amt = Math.Round((hdnType.Value == "EXPORT" && inc < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inc < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)))) : (Request.Form["ddlIncomeCharges" + inc].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtIncomeAmount" + inc]) * (inv.service_tax_rate / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);

                            inv.stax_amt = Math.Round((hdnType.Value == "EXPORT" && ex < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code  == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)))) : (Request.Form["ddlExpCharges" + ex].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);

                            ////inv.stax_amt = Math.Round((hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code
                            ////   == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)))) : (Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);


                            ////inv.stax_amt = Math.Round((hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? 0 : inv.curr_code
                            ////   == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100))));

                            ////// same as income amount mentioned below.
                            ///////inv.stax_amt = Math.Round((hdnType.Value == "EXPORT" && ex < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)))) : (Request.Form["ddlExpCharges" + ex].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.service_tax_rate / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);

                            //////=============Add ByPradeep======================

                            inv.SBCessAmt = Math.Round((hdnType.Value == "EXPORT" && ex < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.SBCessTax / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.SBCessTax / 100)))) : (Request.Form["ddlExpCharges" + ex].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.SBCessTax / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.SBCessTax / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);


                            //=============Add ByPradeep======================
                            ////inv.SBCessAmt = Math.Round((hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? 0 : inv.curr_code
                            ////   == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.SBCessTax / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.SBCessTax / 100))));


                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            inv.KKCessAmt = Math.Round((hdnType.Value == "EXPORT" && ex < 3 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (ex < 2 ? 0 : (Request.Form["rbtnSTax"].ToUpper() == "N" ? 0 : inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.KKCessTax / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.KKCessTax / 100)))) : (Request.Form["ddlExpCharges" + ex].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.KKCessTax / 100)) : (decimal.Parse(Request.Form["txtExpAmt" + ex]) * (inv.KKCessTax / 100)) : 0)) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);

                            //****************End of Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        }
                        if (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O")
                        {
                            inv.rate_income = decimal.Parse(Request.Form["txtRateExp"]);
                            inv.spot_rate_income = decimal.Parse(Request.Form["txtSpotExp"]);
                            inv.chargeable_wt = decimal.Parse(Request.Form["txtChWt"]);
                            inv.spot_diff_income = inv.spot_rate_income > 0 ? (inv.rate_income - inv.spot_rate_income) * inv.chargeable_wt : 0;
                            inv.commissionable_income = inv.spot_rate_income > 0 ? inv.spot_rate_income * inv.chargeable_wt : inv.rate_income * inv.chargeable_wt;
                            inv.comm_rate_income = decimal.Parse(Request.Form["txtCommExp"]);
                            inv.comm_amt_income = inv.commissionable_income * (inv.comm_rate_income / 100);
                            inv.inc_rate_income = decimal.Parse(Request.Form["txtIncExp"]);
                            inv.inc_rate_on_income = decimal.Parse(Request.Form["txtIncOnExp"]);
                            inv.incentivable_income = inv.commissionable_income * (inv.inc_rate_on_income / 100);
                            inv.inc_amt_income = inv.incentivable_income * (inv.inc_rate_income / 100);
                            inv.others_income = 0;
                            // decimal tds_appl_amt1 = inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income;
                            inv.tds_rate_income = decimal.Parse(Request.Form["txtTDSExp"]);
                            inv.tds_amt_income = (inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income) * (inv.tds_rate_income / 100);
                        }
                        inv.comm_rate = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.comm_rate_income : 0);
                        inv.comm_amt = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.comm_amt_income : 0);
                        inv.inc_rate = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.inc_rate_income : 0);
                        inv.inc_rate_on = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.inc_rate_on_income : 0);
                        inv.inc_amt = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.inc_amt_income : 0);
                        inv.spot_rate = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.spot_rate_income : 0);
                        inv.spot_amt = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inv.spot_rate_income * inv.chargeable_wt) : 0);
                        inv.spot_difference = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.spot_diff_income : 0);
                        inv.tds_rate = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.tds_rate_income : 0);
                        inv.on_tds_amt = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (inv.spot_diff_income + inv.comm_amt_income + inv.inc_amt_income) : 0);
                        inv.tds_amt = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? inv.tds_amt_income : 0);
                        
                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ////inv.bill_amount = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (Request.Form["rbtnFreightType"] == "PP" ? (decimal.Parse(Request.Form["txtExpAmt0"]) - inv.comm_amt_income - inv.inc_amt_income - inv.spot_difference + inv.tds_amt_income) : (inv.comm_amt_income + inv.inc_amt_income - inv.spot_difference)) : (inv.amount + inv.stax_amt+inv.SBCessAmt));
                        inv.bill_amount = (hdnType.Value == "EXPORT" && ex == 0 && hdnBillType.Value != "OTHER" && hdnInvoiceNo.Value.Split('/')[2] != "O" ? (Request.Form["rbtnFreightType"] == "PP" ? (decimal.Parse(Request.Form["txtExpAmt0"]) - inv.comm_amt_income - inv.inc_amt_income - inv.spot_difference + inv.tds_amt_income) : (inv.comm_amt_income + inv.inc_amt_income - inv.spot_difference)) : (inv.amount + inv.stax_amt + inv.SBCessAmt + inv.KKCessAmt));
                        //****************End of Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        inv.curr_code = Request.Form["ddlExpCurr" + ex];
                        inv.description = Request.Form["txtExpRemarks" + ex];
                        string invDate, invDueDate;

                        invDate = (Request.Form["txtExpInvNo" + ex] == string.Empty || Request.Form["txtExpInvDate" + ex] == string.Empty ? "01-01-1900" : (Request.Form["txtExpInvDate" + ex].Split('-')[1] + '-' + Request.Form["txtExpInvDate" + ex].Split('-')[0] + '-' + Request.Form["txtExpInvDate" + ex].Split('-')[2]));
                        invDueDate = (Request.Form["txtExpInvNo" + ex] == string.Empty || Request.Form["txtExpInvDueDate" + ex] == string.Empty ? "01-01-1900" : (Request.Form["txtExpInvDueDate" + ex].Split('-')[1] + '-' + Request.Form["txtExpInvDueDate" + ex].Split('-')[0] + '-' + Request.Form["txtExpInvDueDate" + ex].Split('-')[2]));

                        if (btnSave.Text.ToUpper() == "SAVE" || drExpense.Length == 0)
                        {
                            if (Request.Form["ddlExpType" + ex] == "E")
                            {
                                if (Request.Form["ddlExpChargeType" + ex] != null)
                                {
                                    if (Request.Form["ddlExpChargeType" + ex].ToString().ToUpper() == "MBL" && hdnAWBType.Value == "H")
                                    {
                                        //if (drExpense.Length == 0)
                                        inv.insertSeaMBLBillingCharges(tr, decimal.Parse(Request.Form["txtExpExRate" + ex]), "HBL", Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], 0, DateTime.Parse(invDueDate), inv.mawb_date, Session["UserID"].ToString(), int.Parse(Session["CompBrSno"].ToString()), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"));
                                        //else
                                        inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnExpTSno" + ex]), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                                    }
                                    else if (Request.Form["ddlExpChargeType" + ex].ToString().ToUpper() != "HBL")
                                    {
                                        if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY")
                                        {
                                            inv.insertPerformaInvoiceTrans(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], Convert.ToDateTime("Jan 01 1900"), 0);
                                        }
                                        else
                                        {
                                            inv.insertBilling_transNew(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], decimal.Parse(Request.Form["txtExpConCrdt" + ex] == string.Empty ? "0" : Request.Form["txtExpConCrdt" + ex]), DateTime.Parse(invDueDate));
                                        }
                                    }
                                    DataView dvSeaMBLChargeExp = new DataView(dtExpense, "tsno='" + Request.Form["hdnExpTSno" + ex] + "'  and (headtype='E' or headtype='P')", "tsno", DataViewRowState.CurrentRows);
                                    if (dvSeaMBLChargeExp.ToTable().Rows.Count > 0)
                                    {
                                        if (Request.Form["ddlExpChargeType" + ex].ToUpper() != "HBL" && hdnAWBType.Value == "M" && dvSeaMBLChargeExp.ToTable().Rows[0]["ChargeSource"].ToString().Contains("HBL"))
                                        {
                                            inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnExpTSno" + ex]), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                                        }
                                        if (dvSeaMBLChargeExp.ToTable().Rows[0]["ChargeSource"].ToString().Contains("BOOKING"))
                                        {
                                            inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnExpTSno" + ex]), "BOOKING", Session["UserID"].ToString(), inv.SNo);
                                        }

                                    }
                                }
                                else
                                {
                                    if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY")
                                    {
                                        inv.insertPerformaInvoiceTrans(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], Convert.ToDateTime("Jan 01 1900"), 0);
                                    }
                                    else
                                    {
                                        inv.insertBilling_transNew(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], decimal.Parse(Request.Form["txtExpConCrdt" + ex] == string.Empty ? "0" : Request.Form["txtExpConCrdt" + ex]), DateTime.Parse(invDueDate));
                                    }
                                }

                            }
                            else
                            {


                                inv.headtype = Convert.ToChar("P");
                                if (Request.Form["ddlExpChargeType" + ex] != null)
                                {
                                    if (Request.Form["ddlExpChargeType" + ex].ToString().ToUpper() == "MBL" && hdnAWBType.Value == "H")
                                    {
                                        if (drExpense.Length == 0)
                                            inv.insertSeaMBLBillingCharges(tr, decimal.Parse(Request.Form["txtExpExRate" + ex]), "HBL", Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], 0, DateTime.Parse(invDueDate), inv.mawb_date, Session["UserID"].ToString(), int.Parse(Session["CompBrSno"].ToString()), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"));
                                        else
                                            inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnExpTSno" + ex]), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                                    }
                                    else if (Request.Form["ddlExpChargeType" + ex].ToString().ToUpper() != "HBL")
                                    {
                                        if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY")
                                        {
                                            inv.insertPerformaInvoiceTransEstimated(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex]);
                                        }
                                        else
                                        {
                                            inv.insertBilling_transEstmtdNew(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], decimal.Parse(Request.Form["txtExpConCrdt" + ex] == string.Empty ? "0" : Request.Form["txtExpConCrdt" + ex]), DateTime.Parse(invDueDate));
                                        }
                                        DataView dvSeaMBLChargeEstExp = new DataView(dtExpense, "tsno='" + Request.Form["hdnExpTSno" + ex] + "'  and (headtype='E' or headtype='P')", "tsno", DataViewRowState.CurrentRows);
                                        if (dvSeaMBLChargeEstExp.ToTable().Rows.Count > 0)
                                        {
                                            if (Request.Form["ddlIncomeChargeType" + ex].ToUpper() != "HBL" && hdnAWBType.Value == "M" && dvSeaMBLChargeEstExp.ToTable().Rows[0]["ChargeSource"].ToString().Contains("HBL"))
                                            {
                                                inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnExpTSno" + ex]), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                                            }
                                            if (dvSeaMBLChargeEstExp.ToTable().Rows[0]["ChargeSource"].ToString().Contains("BOOKING"))
                                            {
                                                inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnExpTSno" + ex]), "BOOKING", Session["UserID"].ToString(), inv.SNo);
                                            }

                                        }
                                    }
                                }
                                else
                                {
                                    if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY")
                                    {
                                        inv.insertPerformaInvoiceTransEstimated(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex]);
                                    }
                                    else
                                    {
                                        inv.insertBilling_transEstmtdNew(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], decimal.Parse(Request.Form["txtExpConCrdt" + ex] == string.Empty ? "0" : Request.Form["txtExpConCrdt" + ex]), DateTime.Parse(invDueDate));
                                    }
                                }
                            }
                        }
                        else if (btnSave.Text.ToUpper() == "UPDATE" && drExpense.Length > 0)
                        {
                            inv.headtype = char.Parse(Request.Form["ddlExpType" + ex]);
                            //if (Request.Form["ddlExpType" + ex] == "ACTUAL")
                            //{
                            if (Request.Form["ddlExpChargeType" + ex] != null)
                            {
                                if (Request.Form["ddlExpChargeType" + ex].ToString().ToUpper() == "MBL" && hdnAWBType.Value == "H")
                                {
                                    inv.updateSeaMBLBillingCharges(tr, int.Parse(Request.Form["hdnExpTSno" + ex]), decimal.Parse(Request.Form["txtExpExRate" + ex]), "HBL", Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], 0, DateTime.Parse(invDueDate), Session["UserID"].ToString());
                                }
                                else if (Request.Form["ddlExpChargeType" + ex].ToString().ToUpper() != "HBL")
                                {
                                    if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY")
                                    {
                                        inv.updatePerformaInvoiceTrans(int.Parse(Request.Form["hdnExpTSno" + ex]), decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], Convert.ToDateTime("Jan 01 1900"), 0);
                                    }
                                    else
                                    {
                                        inv.updateBilling_transNew(int.Parse(Request.Form["hdnExpTSno" + ex]), decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], decimal.Parse(Request.Form["txtExpConCrdt" + ex] == string.Empty ? "0" : Request.Form["txtExpConCrdt" + ex]), DateTime.Parse(invDueDate), Session["UserID"].ToString());
                                    }
                                }
                            }
                            else
                            {
                                if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY")
                                {
                                    inv.updatePerformaInvoiceTrans(int.Parse(Request.Form["hdnExpTSno" + ex]), decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], Convert.ToDateTime("Jan 01 1900"), 0);
                                }
                                else
                                {
                                    inv.updateBilling_transNew(int.Parse(Request.Form["hdnExpTSno" + ex]), decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], decimal.Parse(Request.Form["txtExpConCrdt" + ex] == string.Empty ? "0" : Request.Form["txtExpConCrdt" + ex]), DateTime.Parse(invDueDate), Session["UserID"].ToString());
                                }
                            }
                            //}
                            //else
                            //{


                            //    inv.headtype = Convert.ToChar("P");
                            //    if (Request.QueryString["type"].ToString() == "PerformaInvoice" || Request.QueryString["type"].ToString() == "PerformaInvoiceModify")
                            //    {
                            //        inv.insertPerformaInvoiceTransEstimated(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex]);
                            //    }
                            //    else
                            //    {
                            //        inv.insertBilling_transEstmtdNew(decimal.Parse(Request.Form["txtExpExRate" + ex]), Request.Form["ddlExpChargeType" + ex] == null ? "BOOKING" : Request.Form["ddlExpChargeType" + ex], Request.Form["txtExpInvNo" + ex], DateTime.Parse(invDate), Request.Form["ddlExpStatus" + ex], decimal.Parse(Request.Form["txtExpConCrdt" + ex]), DateTime.Parse(invDueDate));
                            //    }
                            //}
                            dtExpense.Rows.RemoveAt(dtExpense.Rows.IndexOf(drExpense[0]));
                        }

                    }
                }
                /////////////////// RI ////////////////////////////
                dtRIExpense = (DataTable)Session["dtRIExpense"];
                DateTime riInvDate;
                for (int r = 0; r < int.Parse(hdnRIRows.Value); r++)
                {
                    DataRow[] drRI = dtRIExpense.Select("Sno='" + Request.Form["hdnRISno" + r] + "' and BillType='" + (hdnBillType.Value.Contains("PERFORMAINVOICE") ? "PERFORMA" : "INVOICE") + "'");
                    if (decimal.Parse(Request.Form["txtRIRate" + r]) != 0)
                    {
                        BC.Name = Request.Form["ddlRIName" + r];
                        BC.BookingRefNo = inv.SNo;
                        BC.Rate = decimal.Parse(Request.Form["txtRIRate" + r]);
                        BC.Mode = Request.Form["ddlRIRateOn" + r];
                        BC.ChWt = decimal.Parse(Request.Form["txtChWt"]);
                        BC.Amount = decimal.Parse(Request.Form["txtRIAmount" + r]);
                        BC.AddedDate = DateTime.Now;
                        BC.AddedBy = Session["UserID"].ToString();
                        BC.ChequeName = Request.Form["txtRIChequeName" + r];
                        riInvDate = DateTime.Parse(Request.Form["txtRIInvoiceDate" + r] == string.Empty ? "01-01-1900" : (Request.Form["txtRIInvoiceDate" + r].Split('-')[1] + '-' + Request.Form["txtRIInvoiceDate" + r].Split('-')[0] + '-' + Request.Form["txtRIInvoiceDate" + r].Split('-')[2]));
                        if (btnSave.Text.ToUpper() == "SAVE" || drRI.Length == 0)
                        {
                            BC.RICommission_InsertNewest(Session["CompBrSno"].ToString(), Request.Form["ddlRIMode" + r], Request.Form["txtRIInvoiceNo" + r], riInvDate, Request.Form["txtRIRemarks" + r], hdnBillType.Value.Contains("PERFORMAINVOICE") ? "PERFORMA" : "INVOICE");
                        }
                        else if (btnSave.Text.ToUpper() == "UPDATE" && drRI.Length > 0 && drRI[0].ToString() != "0")
                        {
                            BC.RICommission_UpdateNew(int.Parse(Request.Form["hdnRISno" + r]), Session["CompBrSno"].ToString(), Request.Form["ddlRIMode" + r], Request.Form["txtRIInvoiceNo" + r], riInvDate, Request.Form["txtRIRemarks" + r]);
                            dtRIExpense.Rows.RemoveAt(dtRIExpense.Rows.IndexOf(drRI[0]));
                        }
                    }
                }
                //}
                ///////////////////////////////// DELETE CHARGES //////////////////////////////////////
                if (btnSave.Text.ToUpper() == "UPDATE")
                {
                    string seaMBLTSno = string.Empty, tsno = string.Empty, risno = string.Empty;
                    if (dtIncome.Rows.Count > 0)
                    {
                        for (int dtI = 0; dtI < dtIncome.Rows.Count; dtI++)
                        {
                            if (dtIncome.Rows[dtI]["ChargeSource"].ToString().Contains("BL"))
                                seaMBLTSno = seaMBLTSno + dtIncome.Rows[dtI]["tsno"] + ",";
                            else
                                tsno = tsno + dtIncome.Rows[dtI]["tsno"] + ",";
                        }
                    }
                    if (dtExpense.Rows.Count > 0)
                    {
                        for (int dtE = 0; dtE < dtExpense.Rows.Count; dtE++)
                        {
                            if (dtExpense.Rows[dtE]["ChargeSource"].ToString().Contains("BL"))
                                seaMBLTSno = seaMBLTSno + dtExpense.Rows[dtE]["tsno"] + ",";
                            else
                                tsno = tsno + dtExpense.Rows[dtE]["tsno"] + ",";
                        }
                    }
                    if (dtRIExpense.Rows.Count > 0)
                    {
                        for (int dtE = 0; dtE < dtRIExpense.Rows.Count; dtE++)
                        {
                            risno = risno + dtRIExpense.Rows[dtE]["Sno"] + ",";
                        }
                    }

                    // delete from PerformaInvoiceTrans/Billing_tran
                    for (int tsn = 0; tsn < tsno.Split(',').Length - 1; tsn++)
                    {
                        if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY")
                            inv.deletePerformaInvoiceTransNew(int.Parse(tsno.Split(',')[tsn]));
                        else
                            inv.deleteBilling_transNew(int.Parse(tsno.Split(',')[tsn]));
                    }
                    // delete from seaMBLCharges
                    for (int seaMblTsn = 0; seaMblTsn < seaMBLTSno.Split(',').Length - 1; seaMblTsn++)
                    {
                        inv.modified_by = Session["UserID"].ToString();
                        inv.deleteSeaMBLCharges(int.Parse(seaMBLTSno.Split(',')[seaMblTsn]), ((hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY") ? "PERFORMA" : "INVOICE"));

                    }
                    // delete from RICommission
                    for (int risn = 0; risn < risno.Split(',').Length - 1; risn++)
                    {
                        inv.deleteRICommission(int.Parse(risno.Split(',')[risn]), hdnBillType.Value.Contains("PERFORMAINVOICE") ? "PERFORMA" : "INVOICE");
                    }
                }
            }
            else
            {
                ////////////////////DEBIT NOTE, CREDIT NOTE AND BROKERAGE/////////////////////////////////////////
                using (CommonBusiness comBusiness = new CommonBusiness())
                    hdnStaxRate.Value = comBusiness.GetList("STaxRate", "TotalSTaxRate", "FromDate<='" + inv.bill_date.ToString() + "' and ToDate>='" + inv.bill_date.ToString() + "'").Rows[0][0].ToString();
                inv.service_tax_rate = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnStaxRate.Value).ToString() : "0.00");
                inv.Service_Tax_Rate_12Pct = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnServiceTaxRate.Value).ToString() : "0.00");
                inv.Service_Tax_Rate_ECESSPct = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnECESS.Value).ToString() : "0.00");
                inv.Service_Tax_Rate_SHECPct = decimal.Parse(Request.Form["rbtnSTax"] == "Y" ? Convert.ToDecimal(hdnSHEC.Value).ToString() : "0.00");
                for (int dncnChargesRow = 0; dncnChargesRow < int.Parse(hdnDNCNRows.Value); dncnChargesRow++)
                {
                    if (Request.Form["ddlDNCNCharges" + dncnChargesRow] != null && decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow].ToString()) > 0)
                    {
                        inv.master_sno = inv.SNo;
                        inv.headtype = hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "MBLBROKERAGE" ? Convert.ToChar("I") : Convert.ToChar("E");
                        inv.headcode = int.Parse(Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[0]);
                        inv.headname = Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[1];
                        inv.supplier_ledger_code = "";
                        inv.supplier_name = Request.Form["txtInvName"];
                        inv.supplier_sno = Request.Form["hndinvSno"];
                        inv.taxable = char.Parse(Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper());
                        inv.awb_rate = 0;
                        inv.amount = Math.Round(decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * decimal.Parse(Request.Form["txtExchangeRateTop"]), 2);
                        if (Session["CompName"].ToString().Split('-')[0].Contains("RED EXPRESS"))
                        {
                            ////*************************uodated on 06 June 2017 *****************
                            //////inv.ServiceTax12Pct = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? (decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.Service_Tax_Rate_12Pct / 100)) : 0) * ((decimal.Parse(Request.Form["txtExchangeRateTop"]))),2); ;
                            //////inv.ECess = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? (decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.Service_Tax_Rate_ECESSPct / 100)) : 0) * ((decimal.Parse(Request.Form["txtExchangeRateTop"]))),2); ;
                            //////inv.HECess = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? (decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.Service_Tax_Rate_SHECPct / 100)) : 0) * ((decimal.Parse(Request.Form["txtExchangeRateTop"]))),2); ;
                            //////inv.Roundoff = Math.Round(Math.Round(inv.ServiceTax12Pct + inv.ECess + inv.HECess) - (inv.ServiceTax12Pct + inv.ECess + inv.HECess), 2);
                            //////inv.stax_amt = (inv.ServiceTax12Pct + inv.ECess + inv.HECess + inv.Roundoff);
                            //inv.stax_amt = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ?(decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.service_tax_rate / 100)) : 0) * ((decimal.Parse(Request.Form["txtExchangeRateTop"]))));
                        }
                        else
                        {
                            ////*************************uodated on 06 June 2017 *****************
                            //////////inv.stax_amt = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.service_tax_rate / 100)) : 0) * (inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExchangeRateTop"])) : (decimal.Parse(Request.Form["txtExchangeRateTop"]))), 2);

                            inv.stax_amt = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.service_tax_rate / 100)) : (decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.service_tax_rate / 100)) : 0) * (inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExchangeRateTop"])) : (decimal.Parse(Request.Form["txtExchangeRateTop"]))), 2);


                            inv.SBCessAmt = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.SBCessTax / 100)) : (decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.SBCessTax / 100)) : 0) * (inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExchangeRateTop"])) : (decimal.Parse(Request.Form["txtExchangeRateTop"]))), 2);

                            inv.KKCessAmt = Math.Round((Request.Form["ddlDNCNCharges" + dncnChargesRow].Split('~')[2].ToUpper() == "Y" && Request.Form["rbtnSTax"].ToUpper() == "Y" ? inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.KKCessTax / 100)) : (decimal.Parse(Request.Form["txtDNCNAmount" + dncnChargesRow]) * (inv.KKCessTax / 100)) : 0) * (inv.curr_code == "INR" ? Math.Ceiling(decimal.Parse(Request.Form["txtExchangeRateTop"])) : (decimal.Parse(Request.Form["txtExchangeRateTop"]))), 2);
                            

                         

                        }
                        inv.comm_rate = 0;
                        inv.comm_amt = 0;
                        inv.inc_rate = 0;
                        inv.inc_rate_on = 0;
                        inv.inc_amt = 0;
                        inv.spot_rate = 0;
                        inv.spot_amt = 0;
                        inv.spot_difference = 0;
                        inv.tds_rate = 0;
                        inv.on_tds_amt = 0;
                        inv.tds_amt = 0;

                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                        ////inv.bill_amount = (inv.amount + inv.stax_amt + inv.SBCessAmt);
                        inv.bill_amount = (inv.amount + inv.stax_amt + inv.SBCessAmt + inv.KKCessAmt);
                        //****************End of Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                       
                        inv.curr_code = Request.Form["txtCurrency"];
                        inv.description = Request.Form["txtDNCNDescription" + dncnChargesRow];
                        //return;
                        inv.insertBilling_transNew(Convert.ToDecimal(Request.Form["txtExchangeRateTop"]), "DRCR", string.Empty, Convert.ToDateTime("Jan 01 1900"), string.Empty, 0, Convert.ToDateTime("Jan 01 1900"));
                        // update CNstatus=Y for Ocean, awbtype=M at the time of CreditNote
                        if (hdnType.Value.Contains("OCEAN") && hdnBillType.Value.Contains("CREDITNOTE") && hdnAWBType.Value == "M")
                        {
                            inv.updateSeaMBLBillingCNStatus(tr, int.Parse(Request.Form["hdnDNCNTSno" + dncnChargesRow]), (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" ? "PERFORMA" : "INVOICE"), Session["UserID"].ToString(), inv.SNo);
                        }
                    }
                }
            }
            //////////////////////////////////////////// CREDIT LIMIT UPDATE ////////////////////////////////////////////////

            //-----------Update Customer credit limit according to new charges ----------------------
            string Status = "";
            //if (hdnBillType.Value != "PERFORMAINVOICE" && hdnBillType.Value != "PERFORMAINVOICEMODIFY" && (hdnType.Value == "IMPORT" ? inv.invto_code_type.ToUpper() != "CAN CUSTOMER" : "0" == "0"))
            if (inv.invto_code_type.ToUpper() != "CAN CUSTOMER")
            {
                try
                {
                    // reverse credit limit for old customer
                    ///////////By mayank Feb 13 2013/////////
                    // BC.custBranchSNo = ViewState["CustIID"].ToString();
                    /////////////////////////////////////////
                    BC.custBranchSNo = hdnCustIID.Value;
                    DataSet dsCheckCrLimt = BC.checkCreditLimit();
                    if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != string.Empty)
                    {
                        Status = "Branch";
                    }
                    if (dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != string.Empty)
                    {
                        Status = "Group";
                    }
                    if (dsCheckCrLimt.Tables[0].Rows[0]["PaymentMode"].ToString().ToUpper() != "CASH")
                    {
                        if (hdnOldInvCodeType.Value.ToUpper() != "CAN CUSTOMER" && hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE" && hdnBillType.Value != "DEBITNOTE")
                        {
                            BC.restoreCreditLimit(decimal.Parse(hdnOldIncomeAmount.Value), Status);

                            bReport.insertCreditLimitUses(int.Parse(dsCheckCrLimt.Tables[0].Rows[0]["custMastSno"].ToString()), int.Parse(BC.custBranchSNo), int.Parse(Session["CompBrSno"].ToString()), "Billing", decimal.Parse("-" + hdnOldIncomeAmount.Value), (Status == "Group" ? decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["groupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["branchLimit"].ToString())), decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["usedLimit"].ToString()), (decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["usedLimit"].ToString()) - decimal.Parse(hdnOldIncomeAmount.Value)), (Status == "Group" ? decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString())), ((Status == "Group" ? decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString())) + decimal.Parse(hdnOldIncomeAmount.Value)), Status, Session["UserID"].ToString(), 0, int.Parse(InvoiceNo), 0, 0);
                        }
                    }


                    //---------------------------END--------------------------------------------------------------
                    string CrLimitStatus = "";
                    // deduct credit limit for new customer
                    BC.custBranchSNo = inv.invto_code;//hdnCustBrSno.Value == string.Empty ? ViewState["CustIID"].ToString() : hdnCustBrSno.Value;
                    DataSet dsCheckCrLimt1 = BC.checkCreditLimit();// && inv.invto_code_type.ToUpper()!="CAN CUSTOMER"
                    if (dsCheckCrLimt1.Tables[0].Rows[0]["PaymentMode"].ToString().ToUpper() == "CREDIT" && inv.invto_code_type.ToUpper() != "CAN CUSTOMER")
                    {
                        if (dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != "0.00" && dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != string.Empty)
                            CrLimitStatus = "Branch";
                        if (dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != "0.00" && dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != string.Empty)
                            CrLimitStatus = "Group";
                        //BC.updateCreditLimit(incomeAmount, CrLimitStatus);
                        //BC.updateCreditLimit(hdnBillType.Value != "CREDITNOTE" ? decimal.Parse(hdnUpdateCrAmount.Value) : decimal.Parse( '-' + hdnUpdateCrAmount.Value), CrLimitStatus);
                        hdnIncomeAmtNew.Value = hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE" && hdnBillType.Value != "DEBITNOTE" ? hdnIncomeAmtNew.Value : (hdnBillType.Value == "DEBITNOTE" ? hdnDNCNAmt.Value : '-' + hdnDNCNAmt.Value);
                        BC.updateCreditLimit(hdnBillType.Value != "CREDITNOTE" && hdnBillType.Value != "MBLCREDITNOTE" && hdnBillType.Value != "DEBITNOTE" ? decimal.Parse(hdnIncomeAmtNew.Value) : (hdnBillType.Value == "DEBITNOTE" ? decimal.Parse(hdnDNCNAmt.Value) : decimal.Parse('-' + hdnDNCNAmt.Value)), CrLimitStatus);
                        bReport.insertCreditLimitUses(int.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["custMastSno"].ToString()), int.Parse(BC.custBranchSNo), int.Parse(Session["CompBrSno"].ToString()), "Billing", decimal.Parse(hdnIncomeAmtNew.Value), (Status == "Group" ? decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["groupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["branchLimit"].ToString())), decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["usedLimit"].ToString()), (decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["usedLimit"].ToString()) + decimal.Parse(hdnIncomeAmtNew.Value)), (Status == "Group" ? decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString())), ((Status == "Group" ? decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString())) - decimal.Parse(hdnIncomeAmtNew.Value)), Status, Session["UserID"].ToString(), 0, int.Parse(InvoiceNo), 0, 0);
                    }
                }
                catch
                {
                }
            }
            tr.Commit();
            //---------------------------END--------------------------------------------------------------
            hdnCompleted.Value = "Y";
            if (hdnErrMsg.Value == string.Empty)
            {
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "PageRedirect", "window.location='" + ((hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" || hdnBillType.Value == "PERFORMATOINVOICE") ? "BrowsePerformaInvoice.aspx?type=" + hdnType.Value : (hdnType.Value == "EXPORT" ? "BrowseInvoice.aspx" : (hdnType.Value == "IMPORT" ? "BrowseImportInvoice.aspx" : (hdnType.Value == "OCEANEXP" ? "BrowseInvoiceSea.aspx" : "BrowseInvoiceSeaImp.aspx")))) + "';", true);

            }

        }
        catch (Exception ex)
        {
            btnSave.Style.Add("display", "block");
            btnSave.Text = InvoiceNo != "0" ? "UPDATE" : "SAVE";
            //if (ex.ToString().Contains("deadlock"))
            //{
            //    btnSave_Click(btnSave, new System.EventArgs());

            //}
            //else
            //{
            tr.Rollback();
            string url = HttpContext.Current.Request.Url.AbsoluteUri;
            if (Request.QueryString["BillType"] == null)
            {
                FormsAuthenticationTicket tk = FormsAuthentication.Decrypt(url.Split('?')[1]);
                url = url.Split('?')[0] + "?" + tk.Name;

                //url = InvoiceNo != "0" ? url.Split('&')[0] + "&Sno=" + InvoiceNo + "&BillType="+(hdnBillType.Value.Contains("PERFORMAINVOICEMODIFY")?hdnBillType.Value: "Modify")+"&" + url.Split('&')[3] : url;
                url = InvoiceNo != "0" ? url.Split('?')[1].Split('&')[0] + "&Sno=" + InvoiceNo + "&BillType=" + (hdnBillType.Value.Contains("PERFORMAINVOICEMODIFY") ? hdnBillType.Value : "Modify") + "&" + url.Split('&')[3] : url.Split('?')[1];
            }
            else
                url = InvoiceNo != "0" ? url.Split('&')[0] + "&Sno=" + InvoiceNo + "&BillType=" + (hdnBillType.Value.Contains("PERFORMAINVOICEMODIFY") ? hdnBillType.Value : "Modify") + "&" + url.Split('&')[3] : url;

            FormsAuthenticationTicket tkNew = new FormsAuthenticationTicket(url, true, 20);
            Response.Redirect("Billing.aspx?" + FormsAuthentication.Encrypt(tkNew));
            //}          

        }
        finally
        {

            if (con != null && con.State == ConnectionState.Open)
                con.Close();
            string result = string.Empty;
            //Update/Insert into CM1BillWise
            if (hdnBillType.Value == "MODIFY" || hdnBillType.Value == "FROMBOOKING" || hdnBillType.Value == "CREATE" || hdnBillType.Value == "PERFORMATOINVOICE" || hdnBillType.Value == "OTHER" || hdnBillType.Value == "MBLCREDITNOTE")
                result = inv.updateCM1BillWise(int.Parse(InvoiceNo));
            if (hdnBillType.Value == "DEBITNOTE" || hdnBillType.Value == "CREDITNOTE")
                result = inv.updateCM1BillWise(int.Parse(hdnSno.Value));

            if (hdnBillType.Value == "MODIFY" && hdnErrMsg.Value == string.Empty)
                sendMail(inv.mawb_no, inv.hawb_no, inv.SNo, decimal.Parse(hdnOldIncomeAmount.Value), "Invoice");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ////Redirect to Previous page by retrieving the PreviousPage Url from ViewState.
        //hdnPreviousPage.Value = ViewState["PreviousPage"].ToString();

        if (hdnBillType.Value == "PERFORMAINVOICE" || hdnBillType.Value == "PERFORMAINVOICEMODIFY" || hdnBillType.Value == "PERFORMATOINVOICE")
            Response.Redirect("BrowsePerformaInvoice.aspx?type=" + strType);
        else if (hdnType.Value == "EXPORT")
            Response.Redirect("BrowseInvoice.aspx");
        else if (hdnType.Value == "IMPORT")
            Response.Redirect("BrowseImportInvoice.aspx");
        else if (hdnType.Value == "OCEANEXP")
            Response.Redirect("BrowseInvoiceSea.aspx");
        else if (hdnType.Value == "OCEANIMP")
            Response.Redirect("BrowseInvoiceSeaImp.aspx");

    }
    protected void sendMail(string MAWB, string HAWB, int BMSno, decimal oldBillingAmount, string InvoiceType)
    {
        try
        {
            MailMessage msg = new MailMessage();
            BReport bReport = new BReport();
            string msgBody = string.Empty;
            string subject = string.Empty;
            string mailTo = string.Empty;
            string cretedUpdatetBy = string.Empty;
            DataSet dsUserName = bReport.getLogindetailNew(Session["UserId"].ToString());
            cretedUpdatetBy = dsUserName.Tables[0].Rows[0]["DisplayName"].ToString();
            DataSet dsDataForMail = inv.getDetailForMail(BMSno);
            if (btnSave.Text.ToUpper() == "UPDATE" && InvoiceType.ToUpper() == "INVOICE")
            {
                msg.From = new MailAddress("'INVOICE UPDATED'<info@pacexpress.net>");
                subject = "INVOICE No:" + dsDataForMail.Tables[0].Rows[0]["InvoiceNo"] + " updated in " + Session["CompName"].ToString().Split('-')[0] + "-" + Session["CompName"].ToString().Split('-')[2];
                msgBody += @"<table colspan='0' border='1'>";
                msgBody += @"<tr style='color:white;background-color:#c20000'><td colspan='4' align='center'><b>" + (Session["CompName"].ToString().Split('-')[0] + "-" + Session["CompName"].ToString().Split('-')[2]) + @"</b></td></tr>";
                msgBody += @"<tr style='color:white;background-color:#333333'><td><b> Invoice No </b></td><td><b> MAWB/HAWB No </b></td><td><b> Sales Person </b></td><td><b> Updated By </b></td></tr>";
                msgBody += @"<tr style='color:black;background-color:#ffffff'><td>" + dsDataForMail.Tables[0].Rows[0]["InvoiceNo"] + @"</td>";
                msgBody += @"<td>" + MAWB + @" / " + HAWB + @"</td>";
                msgBody += @"<td>" + dsDataForMail.Tables[0].Rows[0]["sales_person"] + @"</td>";
                //Gst from 01 July 2017
                msgBody += @"<td>" + dsDataForMail.Tables[0].Rows[0]["GStNo"] + @"</td>";
                msgBody += @"<td>" + cretedUpdatetBy + @" - " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + @"</td></tr>";

                msgBody += @"<tr style='color:white;background-color:#333333'><td colspan='4' align='center'><b> Invoice Details </b></td></tr>";

                msgBody += @"<tr style='color:white;background-color:#333333'><td>&nbsp;</td><td colspan='2' align='center'><b>Previous</b></td><td align='center'><b>Modified</b></td></tr>";

                msgBody += @"<tr><td style='color:white;background-color:#333333'><b>Customer Name </b></td><td colspan='2'>" + hdnOldCustomerName.Value + @"</td><td>" + dsDataForMail.Tables[0].Rows[0]["invto_name"] + @"</td></tr>";
                msgBody += @"<tr><td style='color:white;background-color:#333333'><b>Customer Address </b></td><td colspan='2'>" + hdnOldCustomeAddress.Value + @"</td><td>" + dsDataForMail.Tables[0].Rows[0]["invto_address"] + @"</td></tr>";
                msgBody += @"<tr><td style='color:white;background-color:#333333'><b> Currency </b></td><td colspan='2'>" + hdnOldCurrency.Value + @" Ex Rate " + hdnOldExRate.Value + @"</td><td>" + dsDataForMail.Tables[0].Rows[0]["curr_code"] + @" Ex Rate " + dsDataForMail.Tables[0].Rows[0]["exchange_rate"] + @"</td></tr>";
                msgBody += @"<tr><td style='color:white;background-color:#333333'><b>Chargeable Weight </b></td><td colspan='2'>" + hdnOldChWt.Value + @"</td><td>" + dsDataForMail.Tables[0].Rows[0]["chargeable_wt"] + @"</td></tr>";
                msgBody += @"<tr><td style='color:white;background-color:#333333'><b>Billed Amount </b></td><td colspan='2'>" + oldBillingAmount + @"</td><td>" + (dsDataForMail.Tables[0].Rows[0]["Income"].ToString() == string.Empty ? "0" : dsDataForMail.Tables[0].Rows[0]["Income"].ToString()) + @"</td></tr>";

                msgBody += @"<tr><td style='color:white;background-color:#333333'><b>Actual Expenses </b></td><td colspan='2'>" + hdnOldActualExpAmt.Value + @"</td><td>" + (dsDataForMail.Tables[0].Rows[0]["ActualExpense"].ToString() == string.Empty ? "0" : dsDataForMail.Tables[0].Rows[0]["ActualExpense"].ToString()) + @"</td></tr>";
                msgBody += @"<tr><td style='color:white;background-color:#333333'><b>Estimated Expenses </b></td><td colspan='2'>" + hdnOldEstExpAmt.Value + @"</td><td>" + (dsDataForMail.Tables[0].Rows[0]["EstimatedExpense"].ToString() == string.Empty ? "0" : dsDataForMail.Tables[0].Rows[0]["EstimatedExpense"].ToString()) + @"</td></tr>";

                msgBody += @"<tr><td style='color:white;background-color:#333333'><b>CM1 </b></td><td colspan='2'>" + hdnOldCM1.Value + @"</td><td>" + dsDataForMail.Tables[0].Rows[0]["CM1"] + @"</td></tr>";
                msgBody += @"</table>";
            }
            //else if (InvoiceType.ToUpper() != "INVOICE")
            //{
            //    subject = InvoiceType.ToUpper() + " No:" + dsDataForMail.Tables[0].Rows[0]["InvoiceNo"] + " created in " + Session["CompName"].ToString().Split('-')[0] + "-" + Session["CompName"].ToString().Split('-')[2];
            //    msgBody += @"<table colspan='0' border='1'>";

            //    msgBody += @"<tr style='color:white;background-color:#c20000'><td colspan='4' align='center'><b>" + (Session["CompName"].ToString().Split('-')[0] + "-" + Session["CompName"].ToString().Split('-')[2]) + @"</b></td></tr>";

            //    msgBody += @"<tr style='color:white;background-color:#333333'><td><b>  " + InvoiceType + @" No </b></td><td><b> MAWB/HAWB No </b></td><td><b> Sales Person </b></td><td><b> Created By </b></td></tr>";

            //    msgBody += @"<tr><td>" + dsDataForMail.Tables[0].Rows[0]["InvoiceNo"] + @"</td>";
            //    msgBody += @"<td>" + MAWB + @" / " + HAWB + @"</td>";
            //    msgBody += @"<td>" + dsDataForMail.Tables[0].Rows[0]["sales_person"] + @"</td>";
            //    msgBody += @"<td>" + cretedUpdatetBy + @" - " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + @"</td></tr>";

            //    msgBody += @"<tr style='color:white;background-color:#333333'><td colspan='4' align='center'><b> Invoice Details </b></td></tr>";

            //    msgBody += @"<tr><td style='color:white;background-color:#333333'><b> Customer Name </b></td><td colspan='3'>" + dsDataForMail.Tables[0].Rows[0]["invto_name"] + @"</td></tr>";
            //    msgBody += @"<tr><td style='color:white;background-color:#333333'><b> Customer Address </b></td><td colspan='3'>" + dsDataForMail.Tables[0].Rows[0]["invto_address"] + @"</td></tr>";

            //    msgBody += @"<tr><td style='color:white;background-color:#333333'><b> Currency </b></td><td colspan='3'>" + dsDataForMail.Tables[0].Rows[0]["curr_code"] + @" Ex Rate " + dsDataForMail.Tables[0].Rows[0]["exchange_rate"] + @"</td></tr>";
            //    msgBody += @"<tr><td style='color:white;background-color:#333333'><b>Chargeable Weight </b></td><td colspan='3'>" + dsDataForMail.Tables[0].Rows[0]["chargeable_wt"] + @"</td></tr>";

            //    msgBody += @"<tr><td style='color:white;background-color:#333333'><b> Billed Amount </b></td><td colspan='3'>" + (InvoiceType.ToUpper() == "DEBITNOTE" ? dsDataForMail.Tables[0].Rows[0]["Income"].ToString() : dsDataForMail.Tables[0].Rows[0]["ActualExpense"].ToString()) + @"</td></tr>";

            //    msgBody += @"</table>";

            //}
            else if (btnSave.Text.ToUpper() == "SAVE" && InvoiceType.ToUpper() == "CAN")
            {
                oldBillingAmount = Math.Round(oldBillingAmount, 2);
                msg.From = new MailAddress("'REQUEST FOR CAN CREATION'<info@pacexpress.net>");
                subject = "Request for CAN creating in " + Session["CompName"].ToString().Split('-')[0] + "-" + Session["CompName"].ToString().Split('-')[2];
                msgBody += @"<table colspan='0' border='1'>";

                msgBody += @"<tr style='color:white;background-color:#c20000'><td colspan='4' align='center'><b>" + (Session["CompName"].ToString().Split('-')[0] + "-" + Session["CompName"].ToString().Split('-')[2]) + @"</b></td></tr>";

                msgBody += @"<tr style='color:white;background-color:#333333'><td><b> MAWB/HAWB No </b></td><td><b> Requested Amt </b></td><td><b> Requested By </b></td></tr>";

                msgBody += @"<tr><td>" + MAWB + @" / " + HAWB + @"</td>";
                msgBody += @"<td>" + oldBillingAmount + @"</td>";
                msgBody += @"<td>" + cretedUpdatetBy + @" - " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + @"</td></tr>";
                string ApprovedBy = string.Empty;
                if (Session["CompName"].ToString().Split(' ')[0] == "PACE")
                    ApprovedBy = "kksharma";
                else if (Session["CompName"].ToString().Split(' ')[0] == "PACE[WS]")
                    ApprovedBy = "dkapoor";
                else if (Session["CompName"].ToString().Split(' ')[0] == "THREE" || Session["CompName"].ToString().Split(' ')[0] == "RED")
                    ApprovedBy = "bhuwan";
                //else if (Session["CompName"].ToString().Split(' ')[0] == "RED")
                //    ApprovedBy = "vsharma";
                else if (Session["CompName"].ToString().Split(' ')[0] == "CWICK")
                    ApprovedBy = "jaswinder";

                //   FormsAuthenticationTicket ticket = new System.Web.Security.FormsAuthenticationTicket("Company=" + (Session["CompName"].ToString().Split('-')[0].Replace("&", "and") + "-" + Session["CompName"].ToString().Split('-')[2]) + "&MAWBHAWB=" + MAWB + "/" + HAWB + "&ReqAmt=" + oldBillingAmount + "&ReqBy=" + cretedUpdatetBy + "-" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + "&AWBSno=" + hdnAWBTableSno.Value + "&ApprovedBy=" + ApprovedBy, true, 20);

                ////   msgBody += @"<tr><td colspan='3' style='text-align:left'>From outstation 1- <a href='http://systems.pacexpress.net/pace/Login.aspx?fp=i&t=l&RedirectTo=" + FormsAuthentication.Encrypt(ticket) + @"'>Click here</a> or 2- <a href='http://115.119.84.21/pace/Login.aspx?fp=i&t=l&RedirectTo=" + FormsAuthentication.Encrypt(ticket) + @"'>Click here</a>. From office(Mahipalpur, Delhi) <a href='http://192.168.1.225/pace/Login.aspx?fp=i&t=l&RedirectTo=" + FormsAuthentication.Encrypt(ticket) + @"'>Click here</a>.</td></tr>";


                string Apamount = "0.0";
                string dt = "12-31-9999";
                BInvoice Bi = new BInvoice();
                int sno = Bi.InsertCanRequestedHistory(Convert.ToInt32(hdnAWBTableSno.Value), "REQUESTED", Convert.ToDecimal(Apamount), ApprovedBy, cretedUpdatetBy, Convert.ToDecimal(oldBillingAmount), DateTime.Now, Convert.ToDateTime(dt), "");

                string qvalue = "Company=" + (Session["CompName"].ToString().Split('-')[0].Replace("&", "and") + "-" + Session["CompName"].ToString().Split('-')[2]) + "&MAWBHAWB=" + MAWB + "/" + HAWB + "&ReqAmt=" + oldBillingAmount + "&ReqBy=" + cretedUpdatetBy + "-" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + "&AWBSno=" + hdnAWBTableSno.Value + "&ApprovedBy=" + ApprovedBy;
                //  FormsAuthenticationTicket ticket = new System.Web.Security.FormsAuthenticationTicket("Sno="+sno.ToString()[0],true,20);
                string sno1 = Encode(qvalue.ToString());
                msgBody += @"<tr><td colspan='3' style='text-align:left'>From outstation 1- <a href='http://systems.pacexpress.net/pace/Cargo/RequestedCAN.aspx?fp=" + sno1 + @"'>Click here</a> or 2- <a href='http://115.119.84.21/pace/Cargo/RequestedCAN.aspx?fp=" + sno1 + @"'>Click here</a>. From office(Mahipalpur, Delhi) <a href='http://192.168.1.225/pace/Cargo/RequestedCAN.aspx?fp=" + sno1 + @"'>Click here</a>.</td></tr>";
                msgBody += @"</table>";
                //Insert Into CANRequestedHistory Table...................................................................
                //End Query
                //Update RequestedCan Invoice Status.......
                string query = Bi.UpdateInvoiceCAN(Convert.ToInt32(hdnAWBTableSno.Value), ApprovedBy, Convert.ToDecimal(Apamount), Convert.ToDateTime(dt), "Requested", "", cretedUpdatetBy, Convert.ToDecimal(oldBillingAmount), DateTime.Now).ToString();
                //End Query
            }
            msgBody += @"<b>**Note: This is autogenerated mail, please do not reply.</b>";
            //mailTo = "asrivastava@cargoflash.com,anandvfan@gmail.com";
            if (Session["CompName"].ToString().Split(' ')[0] == "PACE")
            {
                if (btnSave.Text.ToUpper() == "SAVE" && InvoiceType.ToUpper() == "CAN")
                      mailTo = "credit@pacexpress.net";
                else
                      mailTo = "credit@pacexpress.net";
            }
            else if (Session["CompName"].ToString().Split(' ')[0] == "PACE[WS]")
                  mailTo = "credit@pacexpress.net";
            //else if (Session["CompName"].ToString().Split(' ')[0] == "THREE")
            //    mailTo = "athakur@pacexpress.net,paceaccounts@pacexpress.net,pacecredit@pacexpress.net";
            else if (Session["CompName"].ToString().Split(' ')[0] == "RED")
                  mailTo = "credit@pacexpress.net";
            else if (Session["CompName"].ToString().Split(' ')[0] == "RED")
                  mailTo = "credit@pacexpress.net";
            else if (Session["CompName"].ToString().Split(' ')[0] == "CWICK")
                  mailTo = "credit@pacexpress.net";
            else if (dsDataForMail.Tables[0].Rows[0]["sales_person"].ToString() == "YASH CHOPRA" && (Session["CompName"].ToString().Split(' ')[0] == "THREE" || Session["CompName"].ToString().Split(' ')[0] == "RED"))
            {
                  mailTo = "credit@pacexpress.net";
            }

            if (btnSave.Text.ToUpper() == "UPDATE" && InvoiceType.ToUpper() == "INVOICE")
            {
                if (dsDataForMail.Tables[0].Rows[0]["sales_person"].ToString().ToUpper() != "SELECT" && dsDataForMail.Tables[0].Rows[0]["sales_person"].ToString().ToUpper() != "NOMINATION")
                {
                    mailTo = mailTo + "," + dsDataForMail.Tables[0].Rows[0]["SalesPersonEmail"].ToString();
                }
            }
            msg.To.Add(mailTo);
            msg.Subject = subject;
            msg.IsBodyHtml = true;
            msg.Body = msgBody;
            //SmtpClient smtp = new SmtpClient("mail.groupconcorde.com");
            SmtpClient smtp = new SmtpClient("mail.cargoflash.com");
            smtp.Credentials = new NetworkCredential("test@cargoflash.com", "Admin$567");
            smtp.Send(msg);
        }
        catch (Exception ex)
        {
            // Response.Redirect("BrowseInvoice.aspx");
        }
    }
    protected void btnRIAdd_Click(object sender, EventArgs e)
    {
        BBookingConfirmed bc = new BBookingConfirmed();
        bc.Name = txtRINewName.Text;
        bc.Address = txtRIAddress.Text;
        bc.PAN_No = txtRIPANNo.Text;
        bc.RI_Insert();
        txtRIAddress.Text = "";
        txtRINewName.Text = "";
        txtRIPANNo.Text = "";
        //fillRIName();
        hdnCompleted.Value = "N";
        string url = HttpContext.Current.Request.Url.AbsoluteUri;
        Response.Redirect(url);

    }
    public string Encode(string data)
    {
        try
        {
            byte[] encData_byte = new byte[data.Length];
            encData_byte = System.Text.Encoding.UTF8.GetBytes(data);
            string encodedData = Convert.ToBase64String(encData_byte);
            return encodedData;
        }
        catch (Exception e)
        {
            throw new Exception("Error in base64Encode" + e.Message);
        }
    }
  
}