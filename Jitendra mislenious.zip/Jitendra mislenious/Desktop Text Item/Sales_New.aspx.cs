using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Xml;
using System.Globalization;

public partial class Booking_Edit : System.Web.UI.Page
{

    #region Summary
    /// <summary>
    /// <class>Sales</class>
    /// <class>Sales Edit</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Rajinder Singh Lamba</createdBy>
    /// <createdOn>DEC 22, 2007</createdOn>
    /// <modifications>
    ///		<modification>
    ///			<changeDescription></changeDescription>
    ///			<modifiedBy>Rajinder Singh Lamba</modifiedBy>
    ///			<modifiedOn>FEB 23, 2008</modifiedOn>
    ///		</modification>
    /// </modifications>			
    /// </summary>		
    #endregion

    DisplayWrap dw = new DisplayWrap();
    BLWrap bw = new BLWrap();
    SqlConnection con;
    SqlCommand com;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    public string calendarControl = "";
    int NA = 0;
    DataTable Etdt = new DataTable();
    //************ Bool flag IsExemption: added to check TdsExemption of Agent on 07 Jan 2014*********

    bool IsExemption = false;
    //************End of Tds Exemption *************************************************************
    protected void Page_Load(object sender, EventArgs e)
    {
       
        Button1.Attributes.Add("OnClick", "chkTrucker();");
        HtmlGenericControl body = (HtmlGenericControl)Page.Master.FindControl("MyBody");

        // body.Attributes.Add("onload", "OnOff()");

        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            hdnEmail.Value = Session["EMailID"].ToString();
            ViewState["edit"] = "0";
            ViewState["et"] = "1";
           
            if (!IsPostBack)
            {

                txtValuationCharge.Attributes.Add("onblur", "Valuation()");
                txtTax.Attributes.Add("onblur", "Tax()");
                Session["dtOtherCharges"] = null;
                string SalesID = "";
                DataTable dtSalesEdit = new DataTable();
                //ViewState["IncentiveAmount"] = hdn_Inc_amt.Value;
                //ViewState["CommissionAmount"] = hdn_comm_amt.Value;
                //ViewState["FreightDiffAmount"] = hdn_frt_diff_amt.Value;
                //ViewState["Total_UsedExemption_Limit"] = hdn_tot_usedex_limit.Value
                if (hdn_ex_cross_limit.Value == "")
                {
                    ViewState["Ex_crossed_limit"] = "N";
                }
                else
                {
                    ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
                }
                txtcertificate_no.Text = hdn_certificate_no.Value;
                if (Request.QueryString["Sales_ID"] != null)
                {
                    LoadTrucker();
                    SalesID = Request.QueryString["Sales_ID"];
                    dtSalesEdit = dw.GetAllFromQuery("Select status,Approved_for_CSR,CSR_DATE,CSR_Remarks from sales where status in(11,12) and Sales_ID=" + SalesID);
                }

                if (dtSalesEdit.Rows.Count > 0)
                {
                    if (dtSalesEdit.Rows[0]["Approved_for_CSR"].ToString() == "28")
                    {
                        //body.Attributes.Add("onload", "AWB()");
                        FillSalesFields();
                        //tdAWBDate.Disabled = true;

                        DateTime CSR_DATE = Convert.ToDateTime(dtSalesEdit.Rows[0]["CSR_DATE"].ToString());
                        txtCSRDate.Text = FormatDateDD(CSR_DATE.ToShortDateString()); txtCSRDate.Enabled = false;

                        txtCSRRemarks.Text = Convert.ToString(dtSalesEdit.Rows[0]["CSR_Remarks"]);
                        tdCSRRemarks.Visible = true;
                        tdTextCSR.Visible = true;
                        //  Button2.Visible = false;
                        btnSModify.Visible = true;
                        UpdateSales.Visible = false;
                        Label1.Text = "* The CSR is already approved,If you made any change it will create CR/DR Note. *";
                        Label1.ForeColor = System.Drawing.Color.Red;
                        tdTextCSR.Visible = true;
                        tdCSRRemarks.Visible = true;

                    }
                    else
                    {
                        //body.Attributes.Add("onload", "AWB()");
                        //txtCSRRemarks.Text = Convert.ToString(dtSalesEdit.Rows[0]["CSR_Remarks"]);
                        //tdCSRRemarks.Visible = true;
                        //tdTextCSR.Visible = true;
                        //LoadTrucker();
                        btnSModify.Visible = false;
                        UpdateSales.Visible = true;
                        tdCSRDate.Visible = false;
                        tdtxtCSRDate.Visible = false;
                        FillSalesFields();
                    }
                    Button1.Visible = false;
                }
                else
                {
                    LoadTrucker();
                    tdCSRDate.Visible = false;
                    tdtxtCSRDate.Visible = false;
                    Button1.Visible = true;
                    UpdateSales.Visible = false;
                    tr_cert.Visible = false;
                    FillAllFields();
                }
            }
        }
    }
    protected DataTable MakeTableCharges()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "Sno";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "FeeName";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "Fee";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "PaymentType";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        DataRow dr = dt.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dt.Rows.Add(dr);
        return dt;

        //Session["dtOtherCharges"] = dt;
        //ViewState["dtBeginCharges"] = dt;
    }
    public void fillOtherCharges(string bookingId)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "select * from Other_Charges where booking_Id = '" + bookingId + "'";
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = MakeTableCharges();
        dt.Rows[0].Delete();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            dw = dt.NewRow();
            dw[0] = i++;

            string amount = dr["Amount"].ToString();
            decimal amt = System.Math.Round(decimal.Parse(amount), MidpointRounding.AwayFromZero);
            dw[1] = dr["Charge_Name"].ToString();
            dw[2] = amt;
            dw[3] = dr["Prepaid_or_Collect"].ToString();
            dt.Rows.Add(dw);

        }
        Session["dtOtherCharges"] = dt;
        if (dt.Rows.Count > 0)
        {
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            grd.DataSource = MakeTableCharges();
            grd.DataBind();
        }
        con.Close();
    }
    public void FillSalesFields()
    {
        string SalesID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            SalesID = Request.QueryString["Sales_ID"];
        }
        DateTime CurrentDate = DateTime.Now;
        string strCurrentDate = CurrentDate.ToShortDateString();
        txtCSRDate.Text = FormatDateDD(strCurrentDate);
        
        //DataTable dtSales = dw.GetAllFromQuery("SELECT Booking_AWB.*,Sales.* FROM   Booking_AWB INNER JOIN Sales ON  Booking_AWB.Sales_ID =Sales.Sales_ID  where Sales.Sales_ID=" + SalesID);
        DataTable dtSales = dw.GetAllFromQuery("SELECT * FROM Sales where Sales_ID=" + SalesID);
        if (dtSales.Rows.Count > 0)
        {
            txtTruckOrigin.Text = dtSales.Rows[0]["Truckingorigin"].ToString();
            txtTruckerAmt.Text = dtSales.Rows[0]["TruckerAmount"].ToString();
            txtTruckerPerkg.Text = dtSales.Rows[0]["TruckerPerKg"].ToString();
            ddlTruckerSupplier.SelectedValue = dtSales.Rows[0]["TruckerSupplier_Id"].ToString();
            txtVendorAwbNo.Text = dtSales.Rows[0]["VendorAwbNo"].ToString();

            ViewState["Booking_ID"] = dtSales.Rows[0]["Booking_ID"].ToString();
            ViewState["Stock_ID"] = dtSales.Rows[0]["Stock_ID"].ToString();
            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select AirWayBill_No,Agent_ID from stock_Master where Stock_ID=" + dtSales.Rows[0]["Stock_ID"].ToString());

            DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + dtAirWayBillNo.Rows[0]["Agent_ID"].ToString());
            if (dtAgent.Rows.Count > 0)
            {
                ViewState["Agent_ID"] = dtAirWayBillNo.Rows[0]["Agent_ID"].ToString();
                lblAgent.Text = dtAgent.Rows[0]["Agent_Name"].ToString();
            }

            if (dtAirWayBillNo.Rows.Count > 0)
            {
                txtAWBNO.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
                string AirlineCode = txtAWBNO.Text.Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Airline_ID=" + AirlineID.Rows[0]["Airline_ID"].ToString() + " and Belongs_To_City=" + dtSales.Rows[0]["City_ID"].ToString());
                long City_ID = long.Parse(dtSales.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                DataTable dtCity = dw.GetAllFromQuery("select City_Code,City_Name from City_Master where City_ID=" + dtSales.Rows[0]["City_ID"].ToString());
                if (dtCity.Rows.Count > 0)
                {
                    txtOrigin.Text = dtCity.Rows[0]["City_Code"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString();
                }
                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    ViewState["AirlineDetailID"] = AirlineDetailID;
                    hdnAirlineDetailId.Value = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();

                    if (AirlineDetailID.ToString() != "163" && AirlineDetailID.ToString() != "166")
                        ET.Style.Add("display", "None");


                }
            }
            fillOtherCharges(ViewState["Booking_ID"].ToString());
            LOAD_SCD();
            ddlDestination.SelectedValue = dtSales.Rows[0]["Destination_ID"].ToString();
            ddlShipmentType.SelectedValue = dtSales.Rows[0]["Shipment_ID"].ToString();
            ddlScr.SelectedValue = dtSales.Rows[0]["Special_Commodity_ID"].ToString();
            DateTime AWB_Date = DateTime.Parse(dtSales.Rows[0]["AWB_Date"].ToString());
            txtAWBDate.Text = FormatDateDD(AWB_Date.ToShortDateString());
            ViewState["Flight_Open_ID"] = dtSales.Rows[0]["Flight_Open_ID"].ToString();
            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtSales.Rows[0]["Flight_Open_ID"].ToString());
            if (dtFlight.Rows.Count > 0)
            {
                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

                if (dtFlightNo.Rows.Count > 0)
                {
                    //txtFlightNo.Text = dtFlightNo.Rows[0]["Flight_No"].ToString();
                }
            }
            txtFlightNo.Text = dtSales.Rows[0]["Flight_No"].ToString();
            DateTime FlightDate = Convert.ToDateTime(dtSales.Rows[0]["Flight_Date"].ToString());
            txtFlightDate.Text = FormatDateDD(FlightDate.ToShortDateString());

            #region ShipperConsignee Details on 04 Nov 2011
            //******Shipper consignee Details (Now picked from Shipper_Details, not from Sales Table********

            ////txtShipper.Text = dtSales.Rows[0]["Shipper_Name"].ToString();
            ////txtShipperAddress.Text = dtSales.Rows[0]["Shipper_Address"].ToString();
            ////txtConsignee.Text = dtSales.Rows[0]["Consignee_Name"].ToString();
            ////txtConsigneeAddress.Text = dtSales.Rows[0]["Consignee_Address"].ToString();

            DataTable dtShipperConsigneeDetails = dw.GetAllFromQuery("Select * from Shipper_Details where stock_id=" + dtSales.Rows[0]["Stock_Id"].ToString() + "");

            if (dtShipperConsigneeDetails.Rows.Count > 0)
            {
                txtShipper.Text = dtShipperConsigneeDetails.Rows[0]["Shipper_Name"].ToString();
                txtShipperAddress.Text = dtShipperConsigneeDetails.Rows[0]["Shipper_Address"].ToString();
                txtConsignee.Text = dtShipperConsigneeDetails.Rows[0]["Consignee_Name"].ToString();
                txtConsigneeAddress.Text = dtShipperConsigneeDetails.Rows[0]["Consignee_Address"].ToString();
            }
            else
            {
                txtShipper.Text = "";
                txtShipperAddress.Text = "";
                txtConsignee.Text = "";
                txtConsigneeAddress.Text = "";
            }


            //******************End Of Shipper Consignee Details************************
            #endregion
            #region Checking AGentWiseTDS
            
            #endregion
            txtPieces.Text = dtSales.Rows[0]["No_of_Packages"].ToString();
            txtVolwt.Text = dtSales.Rows[0]["Volume_Weight"].ToString();
            txtGw.Text = dtSales.Rows[0]["Gross_Weight"].ToString();
            txtCw.Text = dtSales.Rows[0]["Charged_Weight"].ToString();

            rbFType.SelectedValue = dtSales.Rows[0]["Freight_Type"].ToString();
            txtTariffRate.Text = dtSales.Rows[0]["Tariff_Rate"].ToString();
            txtSpAmt.Text = dtSales.Rows[0]["Freight_Amount"].ToString();
            lblFreightAmount.Text = txtSpAmt.Text;
            txtSpRate.Text = dtSales.Rows[0]["Special_Rate"].ToString();
            txtFreightAmount.Text = dtSales.Rows[0]["Special_Amount"].ToString();

            DataTable dtAirlineCharges = dw.GetAllFromQuery(" select * from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            Hidden1.Value = dtAirlineCharges.Rows[0]["ACI_Fees"].ToString();
            Hidden2.Value = dtAirlineCharges.Rows[0]["DisBursementCharges"].ToString();
            DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue);

            if (dtAirlineCharges.Rows.Count > 0)
            {
                if (dtAirlineCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenFSC.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
                        }
                    }
                    else
                    {
                        HiddenFSC.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
                        }
                    }
                }
                if (dtAirlineCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenWSC.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
                        }
                    }
                    else
                    {
                        HiddenWSC.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
                        }
                    }
                }
                if (dtAirlineCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenXRay.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
                        }
                    }
                    else
                    {
                        HiddenXRay.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
                        }
                    }
                }
            }

            DataTable dtFix_Charges = dw.GetAllFromQuery("select * from fix_charges where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            {
                if (dtFix_Charges.Rows.Count > 0)
                {
                    hndXray_fixCharges.Value = dtFix_Charges.Rows[0]["Min_XRay_Charges"].ToString();
                }
            }
            //*********** From Sales Table***************
            DataTable dtSalesField = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
            if (dtSalesField.Rows.Count > 0)
            {

                if (dtSalesField.Rows[0]["Agent_Min_Status"].ToString() == "13")
                {
                    ChkMinAgent.Checked = true;
                }
                else
                {
                    ChkMinAgent.Checked = false;
                }
                txtSpotRate.Text = dtSalesField.Rows[0]["Spot_Rate"].ToString();
               

                txtIATACommission.Text = dtSalesField.Rows[0]["Commission"].ToString();
                txtSCR_Incentive.Text = dtSalesField.Rows[0]["Special_Commodity_Incentive"].ToString();
                txtTDS.Text = dtSalesField.Rows[0]["TDS"].ToString();
                txtcertificate_no.Text = dtSalesField.Rows[0]["Certificate_No"].ToString();
                if (txtcertificate_no.Text=="")
                {
                    tr_cert.Attributes.Add("style", "display:none");
                   
                    //tr_cert.Visible = false;
                }
                txtSurcharge.Text = dtSalesField.Rows[0]["Surcharge"].ToString();
                txtEducationalCess.Text = dtSalesField.Rows[0]["Education_Cess"].ToString();

                if (dtSalesField.Rows[0]["Principle_Min_Status"].ToString() == "13")
                {
                    ChkMinAirline.Checked = true;
                }
                else
                {
                    ChkMinAirline.Checked = false;
                }
                txtPRate.Text = dtSalesField.Rows[0]["Principle_Rate"].ToString();
                txtPAmount.Text = dtSalesField.Rows[0]["Principle_Amount"].ToString();

                txtPSpotRate.Text = dtSalesField.Rows[0]["Principle_Spot_Rate"].ToString();
                txtSpotRateRemarks.Text = dtSalesField.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
                txtRemarks.Text = dtSalesField.Rows[0]["Other_Remarks"].ToString();
            }
            //*********End From Sales Table***************


            rbDueFreight.SelectedValue = dtSales.Rows[0]["DueCarrier_Type"].ToString();
            txtRFSC.Value = dtSales.Rows[0]["FSCRate"].ToString();
            txtRWSC.Value = dtSales.Rows[0]["WSCRate"].ToString();
            txtRXRAY.Value = dtSales.Rows[0]["XRayRate"].ToString();
            decimal Fuel_Surcharges = decimal.Parse(dtSales.Rows[0]["Fuel_Surcharges"].ToString());
            Fuel_Surcharges = Math.Round(Fuel_Surcharges, MidpointRounding.AwayFromZero);
            txtFSC.Text = Fuel_Surcharges.ToString();
            FSC.Value = Fuel_Surcharges.ToString();
            //TextBox1.Text = dtHandover.Rows[0]["Fuel_Surcharges"].ToString();

            decimal War_Surcharges = decimal.Parse(dtSales.Rows[0]["War_Surcharges"].ToString());
            War_Surcharges = Math.Round(War_Surcharges, MidpointRounding.AwayFromZero);
            txtWSC.Text = War_Surcharges.ToString();
            WSC.Value = War_Surcharges.ToString();
            //TextBox2.Text = dtHandover.Rows[0]["War_Surcharges"].ToString();


            decimal Xray_Charges = decimal.Parse(dtSales.Rows[0]["Xray_Charges"].ToString());
            Xray_Charges = Math.Round(Xray_Charges, MidpointRounding.AwayFromZero);
            txtXRAY.Text = Xray_Charges.ToString();
            XRay.Value = Xray_Charges.ToString();
            //TextBox3.Text = dtHandover.Rows[0]["Xray_Charges"].ToString();

            // Add  Miscellaneous Charges 4th march 2012 //////

            decimal MSC_Charges = decimal.Parse(dtSales.Rows[0]["MSC_Charges"].ToString());
            MSC_Charges = Math.Round(MSC_Charges, MidpointRounding.AwayFromZero);
            txtMSC.Text = MSC_Charges.ToString();

            ///////// txtET.Text = dtSalesField.Rows[0]["ETChrg"].ToString();

            decimal ETChrg = decimal.Parse(dtSales.Rows[0]["ETCharges"].ToString());
            ETChrg = Math.Round(ETChrg, MidpointRounding.AwayFromZero);
            txtET.Text = ETChrg.ToString();
            hdnET.Value = ETChrg.ToString();


            decimal ABC = Fuel_Surcharges + War_Surcharges + Xray_Charges+ETChrg;
            Hidden3.Value = ABC.ToString();
            txtHouses.Value = dtSales.Rows[0]["No_of_houses"].ToString();
            decimal ACI = decimal.Parse(dtSales.Rows[0]["Total_ACI_Fees"].ToString());
            ACI = Math.Round(ACI, MidpointRounding.AwayFromZero);
            txtACIFee.Text = ACI.ToString();
            decimal AWB = decimal.Parse(dtSales.Rows[0]["AWB_Fees"].ToString());
            AWB = Math.Round(AWB, MidpointRounding.AwayFromZero);
            txtAWBFee.Text = AWB.ToString();
            decimal DB = decimal.Parse(dtSales.Rows[0]["Disbursement_Charges"].ToString());
            DB = Math.Round(DB, MidpointRounding.AwayFromZero);
            txtDisbursmentCharges.Text = DB.ToString();
            decimal Cartage = decimal.Parse(dtSales.Rows[0]["Cartridge_Charges"].ToString());
            Cartage = Math.Round(Cartage, MidpointRounding.AwayFromZero);
            txtCatrage.Text = Cartage.ToString();
            decimal Other = decimal.Parse(dtSales.Rows[0]["Other_DueCarrier"].ToString());
            Other = Math.Round(Other, MidpointRounding.AwayFromZero);
            txtOthers.Text = Other.ToString();
            decimal Total_DueCarrier = decimal.Parse(dtSales.Rows[0]["Total_DueCarrier"].ToString());
            Total_DueCarrier = Math.Round(Total_DueCarrier, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = Total_DueCarrier.ToString();
            // Hidden3.Value = txtDueCarrier.Text;
            decimal VC = decimal.Parse(dtSales.Rows[0]["Valuation_Charge"].ToString());
            VC = Math.Round(VC, MidpointRounding.AwayFromZero);
            txtValuationCharge.Text = VC.ToString();
            decimal TX = decimal.Parse(dtSales.Rows[0]["Tax"].ToString());
            TX = Math.Round(TX, MidpointRounding.AwayFromZero);
            txtTax.Text = TX.ToString();
            decimal TDP = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Prepaid"].ToString());
            TDP = Math.Round(TDP, MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = TDP.ToString();
            decimal TDC = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Collect"].ToString());
            TDC = Math.Round(TDC, MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = TDC.ToString();
            decimal DueAgent = decimal.Parse(txtDueAgentP.Text) + decimal.Parse(txtDueAgentC.Text);
            txtDueAgent.Text = DueAgent.ToString();
            decimal TP = decimal.Parse(dtSales.Rows[0]["Total_Prepaid"].ToString());
            TP = Math.Round(TP, MidpointRounding.AwayFromZero);
            txtPrepaid.Text = TP.ToString();
            decimal TC = decimal.Parse(dtSales.Rows[0]["Total_Collect"].ToString());
            TC = Math.Round(TC, MidpointRounding.AwayFromZero);
            txtCollect.Text = TC.ToString();
            //txtAgentDealRemarks.Text = dtSales.Rows[0]["Agent_Deal_Remarks"].ToString();

        }
    }

    public void FillAllFields()
    {


        string HandoverID = "";
        if (Request.QueryString["Handover_ID"] != null)
        {
            HandoverID = Request.QueryString["Handover_ID"];
        }
        con = new SqlConnection(strCon);
        com = new SqlCommand("SALES_LOAD", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@HandoverID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dtHandover = new DataTable();
        da.Fill(dtHandover);

        //dtHandover = dw.GetAllFromQuery("SELECT Booking_AWB.*,Handover.* FROM   Booking_AWB INNER JOIN Handover ON  Booking_AWB.Handover_ID =Handover.Handover_ID  where Handover.Handover_ID=" + HandoverID);
        if (dtHandover.Rows.Count > 0)
        {
            ViewState["Booking_ID"] = dtHandover.Rows[0]["Booking_ID"].ToString();
            ViewState["Stock_ID"] = dtHandover.Rows[0]["Stock_ID"].ToString();
            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select AirWayBill_No,Agent_ID from stock_Master where Stock_ID=" + dtHandover.Rows[0]["Stock_ID"].ToString());

            DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + dtAirWayBillNo.Rows[0]["Agent_ID"].ToString());
            if (dtAgent.Rows.Count > 0)
            {
                ViewState["Agent_ID"] = dtAirWayBillNo.Rows[0]["Agent_ID"].ToString();
                lblAgent.Text = dtAgent.Rows[0]["Agent_Name"].ToString();
            }

            if (dtAirWayBillNo.Rows.Count > 0)
            {
                txtAWBNO.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
                string AirlineCode = txtAWBNO.Text.Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Airline_ID=" + AirlineID.Rows[0]["Airline_ID"].ToString() + " and Belongs_To_City=" + dtHandover.Rows[0]["City_ID"].ToString());
                long City_ID = long.Parse(dtHandover.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                DataTable dtCity = dw.GetAllFromQuery("select City_Code,City_Name from City_Master where City_ID=" + dtHandover.Rows[0]["City_ID"].ToString());
                if (dtCity.Rows.Count > 0)
                {
                    txtOrigin.Text = dtCity.Rows[0]["City_Code"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString();
                }
                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    ViewState["AirlineDetailID"] = AirlineDetailID;
                    hdnAirlineDetailId.Value = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
                }
            }

            LOAD_SCD();
            ddlDestination.SelectedValue = dtHandover.Rows[0]["Destination_ID"].ToString();
            ddlShipmentType.SelectedValue = dtHandover.Rows[0]["Shipment_ID"].ToString();
            ddlScr.SelectedValue = dtHandover.Rows[0]["Special_Commodity_ID"].ToString();
            fillOtherCharges(ViewState["Booking_ID"].ToString());

            //****AWBDate************************
            DataTable dtStock = dw.GetAllFromQuery("select Used_Date from Stock_Master where Stock_ID=" + ViewState["Stock_ID"].ToString());
            DateTime str = DateTime.Parse(dtStock.Rows[0]["Used_Date"].ToString());
            txtAWBDate.Text = FormatDateDD(str.ToShortDateString());
            //****AWBDate************************
            ViewState["Flight_Open_ID"] = dtHandover.Rows[0]["Flight_Open_ID"].ToString();
            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtHandover.Rows[0]["Flight_Open_ID"].ToString());
            if (dtFlight.Rows.Count > 0)
            {
                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

                if (dtFlightNo.Rows.Count > 0)
                {
                    txtFlightNo.Text = dtFlightNo.Rows[0]["Flight_No"].ToString();
                }

                DateTime FlightDate = Convert.ToDateTime(dtFlight.Rows[0]["Flight_Date"].ToString());
                txtFlightDate.Text = FormatDateDD(FlightDate.ToShortDateString());
            }



            #region ShipperConsignee Details on 04 Nov 2011
            //******Shipper consignee Details (Now picked from Shipper_Details, not from Sales Table********

            ////txtShipper.Text = dtHandover.Rows[0]["Shipper_Name"].ToString();
            ////txtShipperAddress.Text = dtHandover.Rows[0]["Shipper_Address"].ToString();
            ////txtConsignee.Text = dtHandover.Rows[0]["Consignee_Name"].ToString();
            ////txtConsigneeAddress.Text = dtHandover.Rows[0]["Consignee_Address"].ToString();


            DataTable dtShipperConsigneeDetails = dw.GetAllFromQuery("Select * from Shipper_Details where stock_id=" + dtHandover.Rows[0]["Stock_Id"].ToString() + "");

            if (dtShipperConsigneeDetails.Rows.Count > 0)
            {
                txtShipper.Text = dtShipperConsigneeDetails.Rows[0]["Shipper_Name"].ToString();
                txtShipperAddress.Text = dtShipperConsigneeDetails.Rows[0]["Shipper_Address"].ToString();
                txtConsignee.Text = dtShipperConsigneeDetails.Rows[0]["Consignee_Name"].ToString();
                txtConsigneeAddress.Text = dtShipperConsigneeDetails.Rows[0]["Consignee_Address"].ToString();
            }
            else
            {
                txtShipper.Text = "";
                txtShipperAddress.Text = "";
                txtConsignee.Text = "";
                txtConsigneeAddress.Text = "";
            }


            //******************End Of Shipper Consignee Details************************
            #endregion

            txtPieces.Text = dtHandover.Rows[0]["No_of_Packages"].ToString();
            txtVolwt.Text = dtHandover.Rows[0]["Volume_Weight"].ToString();
            txtGw.Text = dtHandover.Rows[0]["Gross_Weight"].ToString();
            txtCw.Text = dtHandover.Rows[0]["Charged_Weight"].ToString();




            //*********************** Condition on  AddToSales Condition on Insentive and Frieght on 23_June_2010
            //Actual_Discount = Convert.ToString((dtHandover.Rows[0]["Freight_Amount"].ToString()== "" ? 0: decimal.Parse(dtHandover.Rows[0]["Freight_Amount"].ToString())) * 5 / 100);
            //if ((dtHandover.Rows[0]["spot_rate"].ToString()== "" ? 0: decimal.Parse(dtHandover.Rows[0]["spot_rate"].ToString())) > 0)
            //{
            //    SpotAmount=Convert.ToString((dtHandover.Rows[0]["Freight_Amount"].ToString()== "" ? 0: decimal.Parse(dtHandover.Rows[0]["Freight_Amount"].ToString())) - ((dtHandover.Rows[0]["spot_rate"].ToString()== "" ? 0: decimal.Parse(dtHandover.Rows[0]["spot_rate"].ToString())) * (dtHandover.Rows[0]["Charged_Weight"].ToString()== "" ? 0: decimal.Parse(dtHandover.Rows[0]["Charged_Weight"].ToString()))));
            //}

            //CommAmount = Convert.ToString(((dtHandover.Rows[0]["Freight_Amount"].ToString()== "" ? 0: decimal.Parse(dtHandover.Rows[0]["Freight_Amount"].ToString())) * (dtHandover.Rows[0]["commission"].ToString()== "" ? 0: decimal.Parse(dtHandover.Rows[0]["commission"].ToString()))) / 100);

            //Inc_Amount = Convert.ToString((((dtHandover.Rows[0]["Freight_Amount"].ToString() == "" ? 0 : decimal.Parse(dtHandover.Rows[0]["Freight_Amount"].ToString())) - decimal.Parse(CommAmount)) * (dtHandover.Rows[0]["Special_Commodity_Incentive"].ToString() == "" ? 0 : decimal.Parse(dtHandover.Rows[0]["Special_Commodity_Incentive"].ToString()))) / 100);


            //Current_Discount = Convert.ToString((SpotAmount == "" ? 0 : decimal.Parse(SpotAmount) + (CommAmount == "" ? 0 : decimal.Parse(CommAmount)) + (Inc_Amount == "" ? 0 : decimal.Parse(Inc_Amount))));

            //Overall_Amount = Convert.ToString((Actual_Discount == "" ? 0 : decimal.Parse(Actual_Discount)) - (Actual_Discount == "" ? 0 : decimal.Parse(Current_Discount)));
            //*************************************End of Condition on Insentive and Frieght on 23_June_2010



            rbFType.SelectedValue = dtHandover.Rows[0]["Freight_Type"].ToString();
            txtTariffRate.Text = dtHandover.Rows[0]["Tariff_Rate"].ToString();
            txtSpAmt.Text = dtHandover.Rows[0]["Freight_Amount"].ToString();
            lblFreightAmount.Text = txtSpAmt.Text;
            txtSpRate.Text = dtHandover.Rows[0]["Special_Rate"].ToString();
            txtFreightAmount.Text = dtHandover.Rows[0]["Special_Amount"].ToString();


            //*****Calculation of Minimum of Existing Slab*****************

            //DataTable dtSlabID = dw.GetAllFromQuery("select Slab_ID from Slab_Master where Slab_Start<=" + txtCw.Text + " and Slab_End>=" + txtCw.Text);//Beneficial Rate Ka slabID is slab id ka next slabID hoga\
            decimal chgwt = 0;
            chgwt = Convert.ToDecimal(txtCw.Text);
            DataTable dtSlabID = dw.GetAllFromQuery("select Slab_ID from Slab_Master where Slab_Start<=" + Math.Round(chgwt, MidpointRounding.AwayFromZero) + " and Slab_End>=" + Math.Round(chgwt, MidpointRounding.AwayFromZero));//Beneficial Rate Ka slabID is slab id ka next slabID hoga\
            string strSlab = "";
            foreach (DataRow rw in dtSlabID.Rows)
            {
                strSlab = strSlab + rw["Slab_ID"].ToString() + ",";
            }
            strSlab = strSlab.Remove(strSlab.LastIndexOf(','));

            DataTable dtAgentRateID = dw.GetAllFromQuery("select Agent_Rate_ID from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and Destination=" + ddlDestination.SelectedValue + " and Shipment_ID=" + ddlShipmentType.SelectedValue + " and Status=2 and valid_from <= '" + FormatDateDD(txtFlightDate.Text) + "' and valid_to >= '" + FormatDateDD(txtFlightDate.Text) + "'");
            long AgentRateID = 0;
            if (dtAgentRateID.Rows.Count > 0)
            {
                AgentRateID = long.Parse(dtAgentRateID.Rows[0]["Agent_Rate_ID"].ToString());

                DataTable dtFinalSlab = dw.GetAllFromQuery("select  Slab_ID from Agent_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Agent_Rate_ID='" + AgentRateID + "' and Slab_ID in(" + strSlab + ")");

                int SlabID = 0;
                if (dtFinalSlab.Rows.Count <= 0)
                {
                    DataTable dtSlabNotExist = dw.GetAllFromQuery("select max(Slab_ID) as Slab_ID from Agent_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Agent_Rate_ID='" + AgentRateID + "' ");
                    if (dtSlabNotExist.Rows.Count > 0)
                    {
                        SlabID = int.Parse(dtSlabNotExist.Rows[0]["Slab_ID"].ToString());
                    }

                }
                else//********if (dtFinalSlab.Rows.Count <= 0)********
                {
                    if (dtFinalSlab.Rows.Count > 0)
                    {
                        SlabID = int.Parse(dtFinalSlab.Rows[0]["Slab_ID"].ToString());
                    }
                }

                DataTable dtMin = dw.GetAllFromQuery("select Price_Value as Min from Agent_Slab_Rate where Slab_ID=1 and Agent_Rate_ID=" + AgentRateID);

                string Agent_Min;
                if (dtMin.Rows.Count > 0)
                {
                    Agent_Min = dtMin.Rows[0]["Min"].ToString();
                    ViewState["Min"] = Agent_Min;
                }
            }
            decimal Min = 0;
            if (ViewState["Min"] != null)
            {
                Min = Convert.ToDecimal(ViewState["Min"].ToString());
            }
            HTariffMinimum.Value = Min.ToString();
            if (decimal.Parse(txtSpAmt.Text) == decimal.Parse(txtFreightAmount.Text) && Min == decimal.Parse(txtFreightAmount.Text))
            {
                ChkMinAgent.Checked = true;
            }

            //*****End Calculation of Minimum of Existing Slab**************


            //*****Calculation of Principle Amount*******************

            DataTable dtPSlabID = dw.GetAllFromQuery("select Slab_ID from Slab_Master where Slab_Start<=" + Math.Round(decimal.Parse(txtCw.Text), MidpointRounding.AwayFromZero) + " and     Slab_End>=" + Math.Round(decimal.Parse(txtCw.Text), MidpointRounding.AwayFromZero));//Beneficial Rate Ka slabID is slab id ka next slabID hoga\
            string strPSlab = "";
            foreach (DataRow rw in dtPSlabID.Rows)
            {
                strPSlab = strPSlab + rw["Slab_ID"].ToString() + ",";
            }
            strPSlab = strPSlab.Remove(strPSlab.LastIndexOf(','));

            DataTable dtRateID = dw.GetAllFromQuery("select Rate_ID from Principle_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and Destination=" + ddlDestination.SelectedValue + " and Shipment_ID=" + ddlShipmentType.SelectedValue + " and Status=2 and valid_from <= '" + FormatDateDD(txtFlightDate.Text) + "' and valid_to >= '" + FormatDateDD(txtFlightDate.Text) + "'");

            if (dtRateID.Rows.Count > 0)
            {
                DataTable dtFinalSlab = dw.GetAllFromQuery("select  Slab_ID from Principle_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Rate_ID='" + dtRateID.Rows[0]["Rate_ID"].ToString() + "' and Slab_ID in(" + strPSlab + ")");

                int SlabID = 0;
                if (dtFinalSlab.Rows.Count <= 0)
                {
                    DataTable dtSlabNotExist = dw.GetAllFromQuery("select max(Slab_ID) as Slab_ID from Principle_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Rate_ID='" + dtRateID.Rows[0]["Rate_ID"].ToString() + "' ");
                    if (dtSlabNotExist.Rows.Count > 0)
                    {
                        SlabID = int.Parse(dtSlabNotExist.Rows[0]["Slab_ID"].ToString());

                    }
                }
                else
                {
                    if (dtFinalSlab.Rows.Count > 0)
                    {
                        SlabID = int.Parse(dtFinalSlab.Rows[0]["Slab_ID"].ToString());

                    }
                }
                DataTable dtPriceValue = dw.GetAllFromQuery("select  Price_Value from Principle_Slab_Rate where                              Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Rate_ID='" + dtRateID.Rows[0]["Rate_ID"].ToString() + "' and Slab_ID =" + SlabID.ToString());
                if (dtPriceValue.Rows.Count > 0)
                {
                    txtPRate.Text = dtPriceValue.Rows[0]["Price_Value"].ToString();
                    decimal PAmount = decimal.Parse(txtPRate.Text) * decimal.Parse(txtCw.Text);
                    PAmount = Math.Round(PAmount, MidpointRounding.AwayFromZero);
                    txtPAmount.Text = PAmount.ToString();
                }

                DataTable dtMin = dw.GetAllFromQuery("select Price_Value as Min from Principle_Slab_Rate where Slab_ID=1 and           Rate_ID=" + dtRateID.Rows[0]["Rate_ID"].ToString());

                string Principle_Min;
                if (dtMin.Rows.Count > 0)
                {
                    Principle_Min = dtMin.Rows[0]["Min"].ToString();
                    HPrincipleMinimum.Value = Principle_Min.ToString();
                    ViewState["Principle_Min"] = Principle_Min;
                }
            }

            decimal PMin = 0;
            if (ViewState["Principle_Min"] != null)
            {
                PMin = Convert.ToDecimal(ViewState["Principle_Min"].ToString());
            }

            if (decimal.Parse(txtPAmount.Text) < PMin)
            {
                ChkMinAirline.Checked = true;
                txtPAmount.Text = PMin.ToString();
                txtPRate.Text = PMin.ToString();
            }
            //****End Calculation of Principle Amount****************

            DataTable dtAirlineCharges = dw.GetAllFromQuery(" select * from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            Hidden1.Value = dtAirlineCharges.Rows[0]["ACI_Fees"].ToString();
            Hidden2.Value = dtAirlineCharges.Rows[0]["DisBursementCharges"].ToString();
            DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue);


            if (dtAirlineCharges.Rows.Count > 0)
            {
                if (dtAirlineCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenFSC.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
                        }
                    }
                    else
                    {
                        HiddenFSC.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
                        }
                    }
                }
                if (dtAirlineCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenWSC.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
                        }
                    }
                    else
                    {
                        HiddenWSC.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
                        }
                    }
                }
                if (dtAirlineCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenXRay.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
                        }
                    }
                    else
                    {
                        HiddenXRay.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
                        }
                    }
                }
            }
            if (HTextBox1.Value == "")
            {
                HTextBox1.Value = "0";
                txtRFSC.Value = "0";
            }
            else
            {
                txtRFSC.Value = HTextBox1.Value;
            }
            if (HTextBox2.Value == "")
            {
                HTextBox2.Value = "0";
                txtRWSC.Value = "0";
            }
            else
            {
                txtRWSC.Value = HTextBox2.Value;
            }
            if (HTextBox3.Value == "")
            {
                HTextBox3.Value = "0";
                txtRXRAY.Value = "0";
            }
            else
            {
                txtRXRAY.Value = HTextBox3.Value;
            }
            DataTable dtFix_Charges = dw.GetAllFromQuery("select * from fix_charges where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            {
                if (dtFix_Charges.Rows.Count > 0)
                {
                    hndXray_fixCharges.Value = dtFix_Charges.Rows[0]["Min_XRay_Charges"].ToString();
                }
            }
            if (hndXray_fixCharges.Value == "")
            {
                hndXray_fixCharges.Value = "0";
            }


            //*********** From Sales Table***************
            //*************************Added on 13 Jan 2010***************


            DataTable dtSales = dw.GetAllFromQuery("select * from Sales where Handover_ID=" + HandoverID);

            ////////DataTable dtSales = dw.GetAllFromQuery("select s.*,isnull(h.Commission,0) as COMM,isnull(h.Special_Commodity_Incentive,0) as Spc_COMM_INC,isnull(h.Spot_Rate,0) as SpotRate from Sales s inner join handover h on s.stock_id=h.stock_id where h.Handover_ID=" + HandoverID);

            //**************************END*******************************************************
            bool flag = false;
            if (dtSales.Rows.Count > 0)
            {
                flag = true;
                //***********************Added On 13 Jan 2010
                txtIATACommission.Text = dtSales.Rows[0]["Commission"].ToString();
                txtSCR_Incentive.Text = dtSales.Rows[0]["Special_Commodity_Incentive"].ToString();
                txtSpotRate.Text = dtSales.Rows[0]["Spot_Rate"].ToString();

                //////txtIATACommission.Text = dtSales.Rows[0]["COMM"].ToString();
                //////txtIATACommission.Enabled = false;
                //////txtSCR_Incentive.Text = dtSales.Rows[0]["Spc_COMM_INC"].ToString();
                //////txtSCR_Incentive.Enabled = false;
                //////txtSpotRate.Text = dtSales.Rows[0]["SpotRate"].ToString();
                //////txtSpotRate.Enabled = false;

                //***********************END*******************************************

                if (dtSales.Rows[0]["Principle_Spot_Rate"].ToString() == "")
                {
                    txtPSpotRate.Text = "0";

                }
                else
                {
                    txtPSpotRate.Text = dtSales.Rows[0]["Principle_Spot_Rate"].ToString();
                }

                txtSpotRateRemarks.Text = dtSales.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
            }
            else
            {
                if (dtHandover.Rows[0]["Adhoc_Rate"].ToString() == "")
                {
                    txtPSpotRate.Text = "0";
                }
                else
                {
                    txtPSpotRate.Text = dtHandover.Rows[0]["Adhoc_Rate"].ToString();
                }
            }
            //else
            //{
            //    SqlConnection connew = new SqlConnection(strCon);
            //    SqlCommand comnew = new SqlCommand("G_DEAL", connew);
            //    comnew.CommandType = CommandType.StoredProcedure;
            //    comnew.Parameters.Add("@DestinationID", SqlDbType.BigInt).Value = long.Parse(ddlDestination.SelectedValue);
            //    comnew.Parameters.Add("@Chwt", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
            //    comnew.Parameters.Add("@AirlineDetailID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
            //    SqlDataAdapter danew = new SqlDataAdapter(comnew);
            //    DataTable dtGdeal = new DataTable();
            //    danew.Fill(dtGdeal);
            //    txtIATACommission.Text = dtGdeal.Rows[0]["Commission"].ToString();
            //    txtSCR_Incentive.Text = dtGdeal.Rows[0]["Special_Commodity_Incentive"].ToString();
            //    txtSpotRate.Text = dtGdeal.Rows[0]["Spot_Rate"].ToString();
            //}
            if (flag == true)
            {
                decimal Pspot = 0, PR = 0;
                if (txtPSpotRate.Text != "")
                {
                    Pspot = decimal.Parse(txtPSpotRate.Text);
                }
                if (txtPRate.Text != "")
                {
                    PR = decimal.Parse(txtPRate.Text);
                }
                if (Pspot != 0)
                {
                    decimal PAmt = decimal.Parse(txtPSpotRate.Text) * decimal.Parse(txtCw.Text);
                    PAmt = Math.Round(PAmt, MidpointRounding.AwayFromZero);
                    txtPAmount.Text = PAmt.ToString();
                }
            }
            else if (decimal.Parse(txtPSpotRate.Text) > 0) //*********************Added Adhoc Rate On 15 June 2011************
            {

                decimal PrinAmt = decimal.Parse(txtPSpotRate.Text) * decimal.Parse(txtCw.Text);
                PrinAmt = Math.Round(PrinAmt, MidpointRounding.AwayFromZero);
                txtPAmount.Text = PrinAmt.ToString();
            }
            //************************End Adhoc Rate*****************
            //*********End From Sales Table***************


            rbDueFreight.SelectedValue = dtHandover.Rows[0]["DueCarrier_Type"].ToString();
            decimal Fuel_Surcharges = decimal.Parse(dtHandover.Rows[0]["Fuel_Surcharges"].ToString());
            Fuel_Surcharges = Math.Round(Fuel_Surcharges, MidpointRounding.AwayFromZero);
            txtFSC.Text = Fuel_Surcharges.ToString();
            FSC.Value = Fuel_Surcharges.ToString();
            //TextBox1.Text = dtHandover.Rows[0]["Fuel_Surcharges"].ToString();

            decimal War_Surcharges = decimal.Parse(dtHandover.Rows[0]["War_Surcharges"].ToString());
            War_Surcharges = Math.Round(War_Surcharges, MidpointRounding.AwayFromZero);
            txtWSC.Text = War_Surcharges.ToString();
            WSC.Value = War_Surcharges.ToString();
            //TextBox2.Text = dtHandover.Rows[0]["War_Surcharges"].ToString();

            decimal Xray_Charges = decimal.Parse(dtHandover.Rows[0]["Xray_Charges"].ToString());
            Xray_Charges = Math.Round(Xray_Charges, MidpointRounding.AwayFromZero);
            txtXRAY.Text = Xray_Charges.ToString();
            XRay.Value = Xray_Charges.ToString();


            if (ViewState["AirlineDetailID"].ToString() != "163" && ViewState["AirlineDetailID"].ToString() != "166")
                ET.Style.Add("display", "none");


            ////decimal ETChrg = decimal.Parse(dtSales.Rows[0]["ETChrg"].ToString());
            ////ETChrg = Math.Round(ETChrg, MidpointRounding.AwayFromZero);
            //txtET.Text = "0";
            //hdnET.Value = "0";


            //TextBox3.Text = dtHandover.Rows[0]["Xray_Charges"].ToString();
            decimal ABC = Fuel_Surcharges + War_Surcharges + Xray_Charges;
            Hidden3.Value = ABC.ToString();
            txtHouses.Value = dtHandover.Rows[0]["No_of_houses"].ToString();
            decimal ACI = decimal.Parse(dtHandover.Rows[0]["Total_ACI_Fees"].ToString());
            ACI = Math.Round(ACI, MidpointRounding.AwayFromZero);
            txtACIFee.Text = ACI.ToString();
            decimal AWB = decimal.Parse(dtHandover.Rows[0]["AWB_Fees"].ToString());
            AWB = Math.Round(AWB, MidpointRounding.AwayFromZero);
            txtAWBFee.Text = AWB.ToString();

            // Add  Miscellaneous Charges 4th march 2012 //////

            decimal MSC_Charges = decimal.Parse(dtHandover.Rows[0]["MSC_Charges"].ToString());
            MSC_Charges = Math.Round(MSC_Charges, MidpointRounding.AwayFromZero);
            txtMSC.Text = MSC_Charges.ToString();

            /////////

            // ******* Only Collect shipment can Have DBC charges  on 28 June 2010******
            if (rbDueFreight.SelectedValue == "COLLECT")
            {
                decimal DB = decimal.Parse(dtHandover.Rows[0]["Disbursement_Charges"].ToString());
                DB = Math.Round(DB, MidpointRounding.AwayFromZero);
                txtDisbursmentCharges.Text = DB.ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = "0";
            }

            //***********************End of DBC Implementation********************************************
            decimal Cartage = decimal.Parse(dtHandover.Rows[0]["Cartridge_Charges"].ToString());
            Cartage = Math.Round(Cartage, MidpointRounding.AwayFromZero);
            txtCatrage.Text = Cartage.ToString();
            decimal Total_DueCarrier = decimal.Parse(dtHandover.Rows[0]["Total_DueCarrier"].ToString());
            Total_DueCarrier = Math.Round(Total_DueCarrier, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = Total_DueCarrier.ToString();
            //Hidden3.Value = txtDueCarrier.Text;
            decimal VC = decimal.Parse(dtHandover.Rows[0]["Valuation_Charge"].ToString());
            VC = Math.Round(VC, MidpointRounding.AwayFromZero);
            txtValuationCharge.Text = VC.ToString();
            decimal TX = decimal.Parse(dtHandover.Rows[0]["Tax"].ToString());
            TX = Math.Round(TX, MidpointRounding.AwayFromZero);
            txtTax.Text = TX.ToString();
            decimal TDP = decimal.Parse(dtHandover.Rows[0]["TotalDueAgent_Prepaid"].ToString());
            TDP = Math.Round(TDP, MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = TDP.ToString();
            decimal TDC = decimal.Parse(dtHandover.Rows[0]["TotalDueAgent_Collect"].ToString());
            TDC = Math.Round(TDC, MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = TDC.ToString();
            decimal DueAgent = decimal.Parse(txtDueAgentP.Text) + decimal.Parse(txtDueAgentC.Text);
            txtDueAgent.Text = DueAgent.ToString();
            decimal TP = decimal.Parse(dtHandover.Rows[0]["Total_Prepaid"].ToString());
            TP = Math.Round(TP, MidpointRounding.AwayFromZero);
            txtPrepaid.Text = TP.ToString();
            decimal TC = decimal.Parse(dtHandover.Rows[0]["Total_Collect"].ToString());
            TC = Math.Round(TC, MidpointRounding.AwayFromZero);
            txtCollect.Text = TC.ToString();
            txtAgentDealRemarks.Text = dtHandover.Rows[0]["Agent_Deal_Remarks"].ToString();
            string AWB_Date = FormatDateMM(txtAWBDate.Text);
            //#region TDS Calculation
            
            

            ////****TDS**************
            ////string Vf = "04/01/";
            ////int Yf = DateTime.Now.Year;
            ////Vf = Vf + Yf.ToString();

            ////string Vt = "03/31/";
            ////int Yt = DateTime.Now.Year + 1;
            ////Vt = Vt + Yt.ToString();

            //string AWB_Date = FormatDateMM(txtAWBDate.Text);
            DataTable dtCompany = dw.GetAllFromQuery("select Company_ID from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            if (dtCompany.Rows.Count > 0)
            {
                ViewState["CompanyID"] = dtCompany.Rows[0]["Company_ID"].ToString();
            }
            DataTable dtAgentwiseTDS = new DataTable();
            //string v_from = "";
            //string v_to = "";
            //string ex_limit = "";
            //string ag_tds_id = "";
            //string strAirline_Detail_Id = "";

            if (dtCompany.Rows.Count > 0)
            {

                ////////////////Start *****Modify on 3 June 2014 By Hemant Sharma for Replacement of  Effective from date I/O valid_from date*******//////////
                dtAgentwiseTDS = dw.GetAllFromQuery("select Agent_TDS_ID,Airline_Detail_ID,Exempted_TDS_Rate,TDS_Exemption_Limit,TDS_Status_Limited,convert(varchar,Effective_From,103) as Effective_From,convert(varchar,valid_to,103) as valid_to,Certificate_No from Agentwise_TDS where  Effective_From <='" + AWB_Date + "'" + " and valid_to >='" + AWB_Date + "'" + " and Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Company_ID=" + dtCompany.Rows[0]["Company_ID"].ToString() + "  and Airline_Detail_ID like '%" + ViewState["AirlineDetailID"].ToString() + "%' AND Exemption_Limit_Crossed='N'");
                ////////End--Modify on 3 June 2014 By Hemant Sharma for Replacement of  Effective from date I/O valid_from date/////////
            }
            if (dtAgentwiseTDS.Rows.Count>0)
            {
                IsExemption = true;
                //txtcertificate_no.Visible = true;
                tr_cert.Visible = true;
            }
            //DataTable dtHandoverTotalAmount = dw.GetAllFromQuery("SELECT Booking_AWB.Total_DueCarrier, Handover.Freight_Amount from Booking_AWB INNER JOIN Handover ON Booking_AWB.Handover_ID = Handover.Handover_ID where Handover.Handover_ID=" + HandoverID);
            //decimal HandOverAmount_cert = 0;
            //if (dtHandoverTotalAmount.Rows.Count > 0)
            //{
            //    HandOverAmount_cert = decimal.Parse(dtHandoverTotalAmount.Rows[0]["Total_DueCarrier"].ToString()) + decimal.Parse(dtHandoverTotalAmount.Rows[0]["Freight_Amount"].ToString());
            //}
            //for(int i=0;i<dtAgentwiseTDS.Rows.Count;i++)
            //{
            //    if ( HandOverAmount_cert <=Convert.ToDecimal( dtAgentwiseTDS.Rows[i]["TDS_Exemption_Limit"].ToString()))
            //    {
            //       // HandOverAmount_cert = Convert.ToDecimal(dtAgentwiseTDS.Rows[i]["TDS_Exemption_Limit"].ToString());
            //        ViewState["TDS_Exemption_Limit"] = Convert.ToDecimal(dtAgentwiseTDS.Rows[i]["TDS_Exemption_Limit"].ToString());
            //        ViewState["Exempted_TDS_Rate"] = dtAgentwiseTDS.Rows[i]["Exempted_TDS_Rate"].ToString();
            //        ViewState["Certificate_No"] = dtAgentwiseTDS.Rows[i]["Certificate_No"].ToString();
            //        break;
            //    }
                
            //}
           

            //ViewState["Ex_crossed_limit"] = 'N';
            //DataTable dtUsedTDS = new DataTable();
            //decimal UsedExemptionLimit = TDS();
            //ViewState["Total_UsedExemption_Limit"] = UsedExemptionLimit;
            //if (dtCompany.Rows.Count > 0)
            //{
            //    ViewState["CompanyID"] = dtCompany.Rows[0]["Company_ID"].ToString();
            //}

            //#region IF(TDS  Found IN Agentwise TDS Table)
            //if (dtAgentwiseTDS.Rows.Count > 0)
            //{
            //    v_from = dtAgentwiseTDS.Rows[0]["Valid_from"].ToString();
            //    v_to = dtAgentwiseTDS.Rows[0]["Valid_to"].ToString();
            //    ex_limit = dtAgentwiseTDS.Rows[0]["TDS_Exemption_Limit"].ToString();
            //    ag_tds_id = dtAgentwiseTDS.Rows[0]["Agent_TDS_ID"].ToString();
            //    strAirline_Detail_Id = dtAgentwiseTDS.Rows[0]["Airline_Detail_ID"].ToString();
            //    ViewState["Agent_TDS_ID"] = ag_tds_id;
            //    if (dtAgentwiseTDS.Rows[0]["TDS_Status_Limited"].ToString() == "13")
            //     {
            //        dtUsedTDS = dw.GetAllFromQuery("select * from Agentwise_Used_TDS where csr_DATE BETWEEN '" + FormatDateMM(v_from) + "' AND '" + FormatDateMM(v_to) + "' AND Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Company_ID=" + dtCompany.Rows[0]["Company_ID"].ToString() + " and Airline_Detail_ID in (" + strAirline_Detail_Id + ")");


            //        if (dtUsedTDS.Rows.Count > 0)//**********AgentwiseTDS************************************
            //        {
            //            decimal UEL = 0;
            //            foreach (DataRow rw in dtUsedTDS.Rows)
            //            {
            //                UEL = UEL + decimal.Parse(rw["Used_Exemption_Limit"].ToString());
            //            }
            //            decimal Total_UsedExemption_Limit = UsedExemptionLimit + UEL;

            //            if (Total_UsedExemption_Limit <=Convert.ToDecimal( ViewState["TDS_Exemption_Limit"]))
            //            {
            //                ViewState["Total_UsedExemption_Limit"] = Total_UsedExemption_Limit;
            //                dtUsedTDS.Rows[0]["Used_Exemption_Limit"].ToString();
            //                txtTDS.Text = ViewState["Exempted_TDS_Rate"].ToString();
            //                txtcertificate_no.Text = ViewState["Certificate_No"].ToString();
            //                //  txtSurcharge.Text = dtAgentwiseTDS.Rows[0]["SurCharge"].ToString();
            //                //  txtEducationalCess.Text = dtAgentwiseTDS.Rows[0]["Education_Cess"].ToString();
            //                DataTable dtTDS = dw.GetAllFromQuery("select TDS,SurCharge,Education_Cess from TDS where  valid_from <= '" + AWB_Date + "'" + " and valid_to >= '" + AWB_Date + "'");
            //                if (dtTDS.Rows.Count > 0)
            //                {
            //                    txtEducationalCess.Text = dtTDS.Rows[0]["Education_Cess"].ToString();
            //                }
            //                else
            //                {
            //                    txtEducationalCess.Text = "0";
            //                }
            //            }
            //            else//**********GeneralTDS************************************
            //            {
            //                DataTable dtTDS = dw.GetAllFromQuery("select TDS,SurCharge,Education_Cess from TDS where  valid_from <= '" + AWB_Date + "'" + " and valid_to >= '" + AWB_Date + "'");

            //                if (dtTDS.Rows.Count > 0)
            //                {
            //                    lblError.Text = lblAgent.Text + " has Crossed Exemption Limit " + ex_limit + " From " + v_from + " To " + v_to;
            //                    ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + lblError.Text + "');</script>");
            //                    ViewState["Ex_crossed_limit"] = 'Y';
            //                    txtTDS.Text = dtTDS.Rows[0]["TDS"].ToString();
            //                    //txtSurcharge.Text = dtTDS.Rows[0]["SurCharge"].ToString();
            //                    txtEducationalCess.Text = dtTDS.Rows[0]["Education_Cess"].ToString();
            //                }
            //                else
            //                {
            //                    txtTDS.Text = "0";
            //                    txtEducationalCess.Text = "0";
            //                }
            //            }
            //        }

            //    }//End of********dtAgentwiseTDS.Rows[0]["TDS_Status_Limited"].ToString() == "13"

            //    else//**********GeneralTDS**************
            //    {
            //        DataTable dtTDS = dw.GetAllFromQuery("select TDS,SurCharge,Education_Cess from TDS where  valid_from <= '" + AWB_Date + "'" + " and valid_to >= '" + AWB_Date + "'");

            //        if (dtTDS.Rows.Count > 0)
            //        {

            //            txtTDS.Text = dtAgentwiseTDS.Rows[0]["Exempted_TDS_Rate"].ToString();
            //            //txtSurcharge.Text = dtTDS.Rows[0]["SurCharge"].ToString();
            //            txtEducationalCess.Text = dtTDS.Rows[0]["Education_Cess"].ToString();
            //        }
            //        else
            //        {
            //            txtTDS.Text = dtAgentwiseTDS.Rows[0]["Exempted_TDS_Rate"].ToString();
            //            txtEducationalCess.Text = "0";
            //        }

            //    }
            //}   //*************End TDS Not Found IN dtAgentwiseTDS TDS Table********  
            //#endregion

            //#region ELSE(Use Generic TDS From TDS Table)
            //else
            //{
            //    DataTable dtTDS = dw.GetAllFromQuery("select TDS,SurCharge,Education_Cess from TDS where  valid_from <= '" + AWB_Date + "'" + " and valid_to >= '" + AWB_Date + "'");
            //    if (dtTDS.Rows.Count > 0)
            //    {
            //        txtTDS.Text = dtTDS.Rows[0]["TDS"].ToString();
            //        //txtSurcharge.Text = dtTDS.Rows[0]["SurCharge"].ToString();
            //        txtEducationalCess.Text = dtTDS.Rows[0]["Education_Cess"].ToString();
            //    }
            //    else
            //    {
            //        txtTDS.Text = "0";
            //        txtEducationalCess.Text = "0";
            //    }

            //}
            //#endregion

            //#endregion
            //*******************Surcharge Calculation***********

            #region Surcharge Calculations
            string FinancialYear = String.Empty;

            string CSR_Date = (txtAWBDate.Text);
            DateTime curDate = DateTime.Parse(FormatDateDD(txtAWBDate.Text));
            string FinancialYearFirst = String.Empty;
            string FinancialYearLast = String.Empty;

            if (curDate.Month <= 3)
            {
                int startYr = curDate.Year - 1;
                FinancialYearFirst = startYr.ToString();
                FinancialYearLast = curDate.Year.ToString();
            }
            else
            {
                int endYr = curDate.Year + 1;
                FinancialYearFirst = curDate.Year.ToString();
                FinancialYearLast = endYr.ToString();
            }
            FinancialYear = FinancialYearFirst.ToString() + "-" + FinancialYearLast.ToString();

            DataTable dtAgentwiseSurcharge = dw.GetAllFromQuery("select * from Agentwise_Surcharge where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Financial_Year='" + FinancialYear + "'");
            //if (dtAgentwiseSurcharge.Rows.Count <= 0)
            //{
            //    //InsertAgentWiseSurcharge(FinancialYear);
            //}
            DataTable dtTDS_Surcharge = dw.GetAllFromQuery("select SurCharge,Company_SurCharge_Limit,NonCompany_SurCharge_Limit from TDS where  valid_from <= '" + AWB_Date + "'" + " and valid_to >= '" + AWB_Date + "'");
            if (dtAgentwiseSurcharge.Rows.Count > 0)
            {
                if (dtTDS_Surcharge.Rows.Count > 0)
                {
                    txtSurcharge.Text = dtTDS_Surcharge.Rows[0]["SurCharge"].ToString();
                }
                else
                {
                    txtSurcharge.Text = "0";
                }
            }
            else
            {
                if (dtTDS_Surcharge.Rows.Count > 0)
                {
                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand cmd = new SqlCommand("SURCHARGE_REPORT", con1);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("COMPANY_ID", ViewState["CompanyID"].ToString());
                    cmd.Parameters.AddWithValue("AGENT_ID", ViewState["Agent_ID"].ToString());
                    cmd.Parameters.AddWithValue("FROM_DATE", ("04/01/" + FinancialYearFirst.ToString()));
                    cmd.Parameters.AddWithValue("TO_DATE", FormatDateDD(txtAWBDate.Text));
                    cmd.Parameters.AddWithValue("Airline_Detail_ID", ViewState["AirlineDetailID"].ToString());
                    cmd.Parameters.AddWithValue("REPORT_TYPE", "TOTAL");
                    SqlDataAdapter da_SQL = new SqlDataAdapter(cmd);
                    DataTable dtAgentwiseTotal = new DataTable();
                    da_SQL.Fill(dtAgentwiseTotal);

                    // DataTable dtAgentwiseTotal = dw.GetAllFromQuery("select  Sum(Used_Exemption_Limit) as Used_Exemption_Limit from Agentwise_Used_TDS where Agent_ID=" + ViewState["Agent_ID"].ToString() + " group by Agent_ID");

                    decimal TotalAgentUsedLimit = 0;
                    if (dtAgentwiseTotal.Rows.Count > 0)
                    {
                        TotalAgentUsedLimit = decimal.Parse(dtAgentwiseTotal.Rows[0]["Used_Exemption_Limit"].ToString());
                    }

                    TotalAgentUsedLimit = TotalAgentUsedLimit + TDS();
                    ViewState["TotalAgentUsedLimit"] = TotalAgentUsedLimit;
                    DataTable dtAgentType = dw.GetAllFromQuery("select Agent_Type from Agent_Master where Agent_ID=" + ViewState["Agent_ID"].ToString());
                    if (dtAgentType.Rows.Count > 0)
                    {
                        if (dtAgentType.Rows[0]["Agent_Type"].ToString() == "21")
                        {
                            decimal Company_SurCharge_Limit = decimal.Parse(dtTDS_Surcharge.Rows[0]["Company_SurCharge_Limit"].ToString());
                            if (TotalAgentUsedLimit > Company_SurCharge_Limit)
                            {
                                InsertAgentWiseSurcharge(FinancialYear, Convert.ToDecimal(dtTDS_Surcharge.Rows[0]["SurCharge"].ToString()));
                                if (dtTDS_Surcharge.Rows.Count > 0)
                                {
                                    txtSurcharge.Text = dtTDS_Surcharge.Rows[0]["SurCharge"].ToString();
                                }
                                else
                                {
                                    txtSurcharge.Text = "0";
                                }
                            }
                            else
                            {
                                txtSurcharge.Text = "0";
                            }
                        }
                        else
                        {
                            decimal NonCompany_SurCharge_Limit = decimal.Parse(dtTDS_Surcharge.Rows[0]["NonCompany_SurCharge_Limit"].ToString());
                            if (TotalAgentUsedLimit > NonCompany_SurCharge_Limit)
                            {
                                InsertAgentWiseSurcharge(FinancialYear, Convert.ToDecimal(dtTDS_Surcharge.Rows[0]["SurCharge"].ToString()));
                                if (dtTDS_Surcharge.Rows.Count > 0)
                                {
                                    txtSurcharge.Text = dtTDS_Surcharge.Rows[0]["SurCharge"].ToString();
                                }
                                else
                                {
                                    txtSurcharge.Text = "0";
                                }
                            }
                            else
                            {
                                txtSurcharge.Text = "0";
                            }
                        }
                    }//*****End of (dtAgentType.Rows.Count > 0)
                }
                else
                {
                    txtSurcharge.Text = "0";
                }
            }
            //***************End Surcharge Calculation***********
            #endregion End Surcharge Calculations


            //*********On 01_March_2011  For OtherCharges:MH-DEL & MH-MUM,dest CGK, JKT, DPS, MES, SUB has 240 Other charges*****************
            string OtherRemarks = "";
            decimal OtherPoints = 0;
            if (dtHandover.Rows[0]["Tpe_Charges"].ToString() != "" && decimal.Parse(dtHandover.Rows[0]["Tpe_Charges"].ToString()) != 0)
            {
                OtherRemarks += "Tpe Charges";
                OtherPoints += decimal.Parse(dtHandover.Rows[0]["Tpe_Charges"].ToString());
            }
            if (dtHandover.Rows[0]["Cgc_Charges"].ToString() != "" && decimal.Parse(dtHandover.Rows[0]["Cgc_Charges"].ToString()) != 0)
            {
                OtherRemarks += OtherRemarks == "" ? "Cgc Charges" : ",Cgc Charges";
                OtherPoints += decimal.Parse(dtHandover.Rows[0]["Cgc_Charges"].ToString());
            }
            txtOthers.Text = OtherPoints.ToString();
            txtRemarks.Text = OtherRemarks;

            if ((ViewState["AirlineDetailID"].ToString() == "147" || ViewState["AirlineDetailID"].ToString() == "148") && (dtHandover.Rows[0]["Destination_ID"].ToString() == "1717" || dtHandover.Rows[0]["Destination_ID"].ToString() == "1815" || dtHandover.Rows[0]["Destination_ID"].ToString() == "2077" || dtHandover.Rows[0]["Destination_ID"].ToString() == "2265" || dtHandover.Rows[0]["Destination_ID"].ToString() == "2679"))
            {
                txtOthers.Text = "240";
            }

        }
    }

    #region InsertAgentWiseSurcharge
    public void InsertAgentWiseSurcharge(string FinancialYear, decimal Surcharge)
    {
        try
        {
            String CSR_Period = "";
            string Debit_Node_ID = "";
            DataTable DtAirline = dw.GetAllFromQuery("SELECT airline_detail_id FROM AIRLINE_DETAIL WHERE COMPANY_ID=" + ViewState["CompanyID"].ToString() + "");
            if (DtAirline.Rows.Count > 0)
            {

                //***************************Updated On 15 Feb 2012: Tk-On-Awb datewise, Rest Airline On Flightdatewise********************//

                //////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297" || txtAWBNO.Text.Trim().Substring(0, 3) == "360")
                //////{
                //////    CSR_Period = FormatDateDD(txtFlightDate.Text);

                //////}
                //////else
                //////{
                //////    CSR_Period = FormatDateDD(txtAWBDate.Text);
                //////}

                if  ((txtAWBNO.Text.Trim().Substring(0, 3) == "235") || (txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
                {
                    CSR_Period = FormatDateDD(txtAWBDate.Text);

                }
                else
                {
                    CSR_Period = FormatDateDD(txtFlightDate.Text);

                }

                //*******************************End Of 15 Feb 2012***************************************************************************

                for (int i = 0; i < DtAirline.Rows.Count; i++)
                {
                    string[] ARR = FinancialYear.Split('-');
                    string From_Date = "04/01/" + ARR[0];
                    string To_Date = FormatDateDD(txtAWBDate.Text);
                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand cmd = new SqlCommand("SURCHARGE_REPORT", con1);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("COMPANY_ID", ViewState["CompanyID"].ToString());
                    cmd.Parameters.AddWithValue("AGENT_ID", ViewState["Agent_ID"].ToString());
                    cmd.Parameters.AddWithValue("FROM_DATE", From_Date);
                    cmd.Parameters.AddWithValue("TO_DATE", To_Date);
                    cmd.Parameters.AddWithValue("Airline_Detail_ID", DtAirline.Rows[i]["Airline_Detail_ID"].ToString());
                    cmd.Parameters.AddWithValue("REPORT_TYPE", "SINGLE");
                    SqlDataReader dr_agent = cmd.ExecuteReader();
                    if (dr_agent.HasRows)
                    {
                        if (dr_agent.Read())
                        {
                            decimal TDSableAmt = Convert.ToDecimal(dr_agent["ONLY_TDS"].ToString());
                            decimal Surcharge_Amt = ((TDSableAmt * Convert.ToDecimal(txtTDS.Text)) / 100) * Surcharge / 100;
                            string insert;

                            insert = "insert into Surcharge_DebitNote(Agent_ID,Airline_Detail_ID,CSR_Period,TDSable_Amount,Surcharge_Amount) values(@Agent_ID,@Airline_Detail_ID,@CSR_Period,@TDSable_Amount,@Surcharge_Amount)";
                            con = new SqlConnection(strCon);
                            con.Open();
                            SqlCommand com = new SqlCommand(insert, con);
                            com.CommandType = CommandType.Text;

                            com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
                            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.VarChar).Value = DtAirline.Rows[i]["Airline_Detail_ID"].ToString();
                            //com.Parameters.Add("@CSR_Period", SqlDbType.VarChar).Value = From_Date + "-" + To_Date;
                            com.Parameters.Add("@CSR_Period", SqlDbType.VarChar).Value = CSR_Period;
                            com.Parameters.Add("@TDSable_Amount", SqlDbType.Decimal).Value = TDSableAmt;
                            com.Parameters.Add("@Surcharge_Amount", SqlDbType.Decimal).Value = Surcharge_Amt;
                            com.ExecuteNonQuery();
                            com.Dispose();
                            DataTable Dt_Id = dw.GetAllFromQuery("select ident_current('Surcharge_DebitNote') as Debit_Node_ID");

                            if (Debit_Node_ID == "")
                            {
                                Debit_Node_ID = (Dt_Id.Rows[0]["Debit_Node_ID"].ToString());
                            }
                            else
                            {
                                Debit_Node_ID = Debit_Node_ID + "," + (Dt_Id.Rows[0]["Debit_Node_ID"].ToString());

                            }
                        }

                    }
                }
            }



            string insert_Query = "INSERT into Agentwise_Surcharge(Agent_ID,Financial_Year,Surcharge_Status,Debit_Node_ID) values(@Agent_ID,@Financial_Year,@Surcharge_Status,@Debit_Node_ID)";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com_Query = new SqlCommand(insert_Query, con);
            com_Query.CommandType = CommandType.Text;
            com_Query.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
            com_Query.Parameters.Add("@Financial_Year", SqlDbType.VarChar).Value = FinancialYear;
            com_Query.Parameters.Add("@Surcharge_Status", SqlDbType.Int).Value = 13;
            com_Query.Parameters.Add("@Debit_Node_ID", SqlDbType.VarChar).Value = Debit_Node_ID;
            com_Query.ExecuteNonQuery();
            com_Query.Dispose();

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    #endregion

    #region DeleteOldOtherCahrges
    public void DeleteOtherCharges(long BookingID)
    {
        dw.GetAllFromQuery("delete from Other_Charges where Booking_ID=" + BookingID);
    }
    #endregion

    #region Update_OtherCharges
    public void Update_OtherCharges(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string insert;
        DeleteOtherCharges(BookingID);
        if (Session["dtOtherCharges"] != null)
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                insert = "insert into Other_Charges(Booking_ID,AirWayBill_No,Charge_Name,Amount,Prepaid_or_Collect) values(@Booking_ID,@AirWayBill_No,@Charge_Name,@Amount,@Prepaid_or_Collect)";

                SqlCommand com = new SqlCommand(insert, con, tr);
                com.CommandType = CommandType.Text;
                com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
                com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text;
                com.Parameters.Add("@Charge_Name", SqlDbType.VarChar).Value = dt.Rows[i]["FeeName"].ToString();
                com.Parameters.Add("@Amount", SqlDbType.Decimal).Value = dt.Rows[i]["Fee"].ToString();
                com.Parameters.Add("@Prepaid_or_Collect", SqlDbType.VarChar).Value = dt.Rows[i]["PaymentType"].ToString();
                com.ExecuteNonQuery();
            }
        }
    }
    #endregion

    public DataSet ConvertXMLToDataSet(StringBuilder xmlData)
    {
        StringReader stream = null;
        XmlTextReader reader = null;
        try
        {
            string s1 = @"<?xml version=""1.0"" encoding=""UTF-8""?><tabledata xmlns:sql=""urn:schemas-microsoft-com:xml-sql"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">";
            string s2 = @"</tabledata>";
            DataSet xmlDS = new DataSet();
            stream = new StringReader(s1 + xmlData.ToString() + s2);
            reader = new XmlTextReader(stream);
            xmlDS.ReadXml(reader);
            return xmlDS;
        }
        catch
        {
            return null;
        }
        finally
        {
            if (reader != null) reader.Close();
        }
    }
    public void LOAD_SCD()
    {
        try
        {
            con = new SqlConnection(strCon);
            com = new SqlCommand("LOAD_SCD", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            StringBuilder xmlData = new StringBuilder(dt.Rows[0]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlShipmentType, "Shipment_Master", "Shipment_Name", "Shipment_ID");
            xmlData = new StringBuilder(dt.Rows[1]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlScr, "Special_Commodity_Master", "Special_Commodity_Name", "Special_Commodity_ID");
            xmlData = new StringBuilder(dt.Rows[2]["Data"].ToString());
            ddlDestination.DataSource = ConvertXMLToDataSet(xmlData).Tables[0];
            ddlDestination.DataTextField = "Destination";
            ddlDestination.DataValueField = "Destination_ID";
            ddlDestination.DataBind();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadDestination()
    {
        try
        {
            string strAgent = "";
            strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString();
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Clear();
            //ddlDestination.Items.Insert(0, "- -Select- -");
            //ddlDestination.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadTrucker()
    {
        try
        {
            string strTrucker = "";
            strTrucker = "Select Sno,Supplier_Name from Trucking_Supplier ";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strTrucker, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlTruckerSupplier.Items.Clear();
            ddlTruckerSupplier.Items.Insert(0, "- -Select- -");
            ddlTruckerSupplier.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlTruckerSupplier.Items.Add(new ListItem(dr["Supplier_Name"].ToString(), dr["SNo"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadCommodity()
    {
        try
        {
            string strAgent = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlScr.Items.Insert(0, "- -Select- -");
            ddlScr.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    public void LoadShipmentType()
    {
        try
        {
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlShipmentType.Items.Insert(0, "- -Select- -");
            ddlShipmentType.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlShipmentType.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        if (hdn_ex_cross_limit.Value == "")//////////handler not hit case//////
        {
            
            ViewState["Ex_crossed_limit"] = "N";
        }
        else
        {
            ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
        }
        txtcertificate_no.Text = hdn_certificate_no.Value;
        ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
        DataTable dtFlight = GetFlightDetails(txtFlightNo.Text, txtFlightDate.Text);
        if (dtFlight.Rows.Count == 0)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "AlertFlight", "<script>alert('Flight not found on this flight Date. Open flight or check flight schedule');</script>");
            return;
        }
        else
        {
            ViewState["Flight_Open_Id_New"] = dtFlight.Rows[0]["Flight_Open_ID"];
        
        }
        string Actual_Discount = "";
        string SpotRate = "";
        string SpotAmount = "";
        string CommAmount = "";
        string Inc_Amount = "";
        string Current_Discount = "";
        string Overall_Amount = "";
        string _Chargd_weight = "";
        string _spotRate = "";
        string _Commission = "";
        string _Special_commodity_incentive = "";
        string _Frieght_Amount = "";
        _Chargd_weight = txtCw.Text;
        _spotRate = txtSpotRate.Text;
        _Commission = txtIATACommission.Text;
        _Special_commodity_incentive = txtSCR_Incentive.Text;
        _Frieght_Amount = txtSpAmt.Text;



        //*********************** Condition on  AddToSales Condition on Insentive and Frieght on 23_June_2010
        Actual_Discount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * 5 / 100);
        if ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) > 0)
        {
            SpotAmount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) * (_Chargd_weight == "" ? 0 : decimal.Parse(_Chargd_weight))));
        }

        CommAmount = Convert.ToString(((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * (_Commission == "" ? 0 : decimal.Parse(_Commission))) / 100);

        Inc_Amount = Convert.ToString((((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - decimal.Parse(CommAmount)) * (_Special_commodity_incentive == "" ? 0 : decimal.Parse(_Special_commodity_incentive))) / 100);


        Current_Discount = Convert.ToString((SpotAmount == "" ? 0 : decimal.Parse(SpotAmount)) + (CommAmount == "" ? 0 : decimal.Parse(CommAmount)) + (Inc_Amount == "" ? 0 : decimal.Parse(Inc_Amount)));

        Overall_Amount = Convert.ToString((Current_Discount == "" ? 0 : decimal.Parse(Current_Discount)) - (Actual_Discount == "" ? 0 : decimal.Parse(Actual_Discount)));
        //*************************************End of Condition on Insentive and Frieght on 23_June_2010

        string AWbNum = txtAWBNO.Text.Trim().Substring(0, 3);

        if (Overall_Amount.Contains("-") && AWbNum != "235")
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('IATA COMM IS LESS AS PER IATA RULE');</script>");
        }
        else
        {

            if ((txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim())) > 0 && ddlTruckerSupplier.SelectedItem.Text == "- -Select- -")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('Please Select Trucker Supplier Name');</script>");
                ddlTruckerSupplier.Focus();
            }
            else
            {

                con = new SqlConnection(strCon);
                con.Open();
                 SqlTransaction tranupdate = con.BeginTransaction();

                decimal UsedExemptionLimit = TDS();

                //decimal TDS_Amount = UsedExemptionLimit;
                //decimal FinalTDS=TDS_Amount * decimal.Parse(txtTDS.Text);
                //FinalTDS = FinalTDS / 100;
                //decimal Sur

                ViewState["Total_UsedExemption_Limit"] = UsedExemptionLimit;
                string HandoverID = "";
                if (Request.QueryString["Handover_ID"] != null)
                {
                    HandoverID = Request.QueryString["Handover_ID"];
                }
                DataTable dtHandover = dw.GetAllFromQuery("select * from  Sales where Handover_ID=" + HandoverID);
                DataTable dtHandoverTotalAmount = dw.GetAllFromQuery("SELECT Booking_AWB.Total_DueCarrier, Handover.Freight_Amount from Booking_AWB INNER JOIN Handover ON Booking_AWB.Handover_ID = Handover.Handover_ID where Handover.Handover_ID=" + HandoverID);
                decimal HandOverAmount = 0;
                if (dtHandoverTotalAmount.Rows.Count > 0)
                {
                    HandOverAmount = decimal.Parse(dtHandoverTotalAmount.Rows[0]["Total_DueCarrier"].ToString()) + decimal.Parse(dtHandoverTotalAmount.Rows[0]["Freight_Amount"].ToString());
                }
                decimal Used_Limit = 0;
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtSpAmt.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
                }
                else
                {
                    Used_Limit = decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - decimal.Parse(txtDueAgentC.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
                }
                Used_Limit = -HandOverAmount + Used_Limit;
                DataTable dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString());

                //*************Added on 28 Mar 2011 Offline City (Agent) case*************//
                if (dtUsed_Limit.Rows.Count <= 0)
                {
                    string ULimit = "";
                    DataTable dtOfflineCity = dw.GetAllFromQuery("select offline_CityId from booking_master where booking_id=" + dtHandover.Rows[0]["Booking_Id"].ToString() + " and Offline_CityID!=''");
                    if (dtOfflineCity.Rows.Count > 0)
                    {
                        dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtOfflineCity.Rows[0]["offline_CityId"].ToString() + "");
                        if (dtUsed_Limit.Rows.Count > 0)
                        {
                            ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                        }
                        else
                        {
                            dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtOfflineCity.Rows[0]["offline_CityId"].ToString() + "");
                            if (dtUsed_Limit.Rows.Count > 0)
                            {
                                ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                            }
                        }


                        if (ULimit == "")
                        {
                            ULimit = "0";
                        }

                        Used_Limit = decimal.Parse(ULimit) + Used_Limit;
                        Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);
                    }

                }
                else
                {
                    Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) + Used_Limit;
                    Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);

                }
                //*************End********************************

                ////Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) + Used_Limit;
                ////Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);

                DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Sales where AirWayBill_No='" + txtAWBNO.Text.Trim() + "'");
                if (dtAWBCheck.Rows.Count <= 0)
                {
                    try
                    {
                        if (dtHandover.Rows.Count > 0)
                        {

                            Update_Sales(tranupdate, con, HandoverID);
                            //Update_BookingAWB(tranupdate, con, HandoverID, dtHandover.Rows[0]["Sales_ID"].ToString());

                            DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                            if (dtOtherChargesID.Rows.Count > 0)
                            {
                                if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                                {
                                    dtOtherChargesID.Rows[0].Delete();
                                }
                            }
                            long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
                            Update_OtherCharges(tranupdate, con, BookingID);
                            Update_AWBDate(tranupdate, con);
                            Update_Handover(tranupdate, con, HandoverID, dtHandover.Rows[0]["Sales_ID"].ToString());
                            //dw.GetAllFromQuery("update Handover set Added_To_Sales=11 where Handover_ID='" + HandoverID + "'");
                            Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());
                            //dw.GetAllFromQuery("update Stock_Master set Status=11" + "  where Stock_ID='" + dtHandover.Rows[0]["Stock_ID"].ToString() + "'");
                            //tranupdate.Save(Stock);

                            Update_AgentLimit(tranupdate, con, Used_Limit);
                            if (IsExemption == true)
                            InsertUsedLimit(tranupdate, con);
                            if (ViewState["Ex_crossed_limit"].ToString() == "Y")
                            {
                                UpdateAgentWiseTDSStatus(tranupdate, con);
                            }
                            //tranupdate.Save(AgentLimit);
                            tranupdate.Commit();
                            con.Close();

                            // Response.Redirect("AddToSales.aspx");
                        }
                        if (dtHandover.Rows.Count <= 0)
                        {
                            Insert_Sales(tranupdate, con, HandoverID);
                            DataTable dtSalesID = dw.GetAllFromQuery("select ident_current('Sales') as SalesID");
                            //Update_BookingAWB(tranupdate, con, HandoverID, dtSalesID.Rows[0]["SalesID"].ToString());
                            DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                            if (dtOtherChargesID.Rows.Count > 0)
                            {
                                if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                                {
                                    dtOtherChargesID.Rows[0].Delete();
                                }
                            }
                            long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
                            Update_OtherCharges(tranupdate, con, BookingID);
                            Update_AWBDate(tranupdate, con);
                            Update_Handover(tranupdate, con, HandoverID, dtSalesID.Rows[0]["SalesID"].ToString());

                            //dw.GetAllFromQuery("update Handover set Added_To_Sales=11 where Handover_ID='" + HandoverID + "'");

                            Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());

                            //decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtFreightAmount.Text);                
                            Update_AgentLimit(tranupdate, con, Used_Limit);
                            if (IsExemption == true)
                            InsertUsedLimit(tranupdate, con);
                            if (ViewState["Ex_crossed_limit"].ToString() == "Y")
                            {
                                UpdateAgentWiseTDSStatus(tranupdate, con);
                            }
                            tranupdate.Commit();
                            con.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                        tranupdate.Rollback();
                    }
                    //Response.Redirect("handoverdetails.aspx");
                    Response.Redirect("handoverdetails.aspx?id=" + txtAWBNO.Text);
                }
                else
                {
                    lblSales.Visible = true;
                }
            }
        }
    }
    #region AgentwiseSurcharge_Insert
    public void AgentwiseSurcharge_Insert(SqlTransaction tr, SqlConnection con)
    {
        string insert;

        insert = "insert into Agentwise_Surcharge(Agent_ID,Financial_Year) values(@Agent_ID,@Financial_Year)";
        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        string FinancialYear = DateTime.Now.Year.ToString() + "-" + Convert.ToString(DateTime.Now.Year + 1);
        com.Parameters.Add("@Financial_Year", SqlDbType.VarChar).Value = FinancialYear;
        com.ExecuteNonQuery();
    }
    #endregion

    #region Update_AWBDate
    public void Update_AWBDate(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Stock_Master set Used_Date='" + FormatDateMM(txtAWBDate.Text) + "'" + "  where Stock_ID=" + ViewState["Stock_ID"].ToString();
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }
    #endregion

    #region InsertUsedLimit
    public void InsertUsedLimit(SqlTransaction tr, SqlConnection con)
    {
        string insert;

        insert = "insert into Agentwise_Used_TDS(Agent_ID,Stock_ID,Company_ID,Airline_Detail_ID,CSR_Date,Freight_Diff_Amount,Commission_Amount,Incentive_Amount,Used_Exemption_Limit,Entered_By,Entered_On,Certificate_No) values(@Agent_ID,@Stock_ID,@Company_ID,@Airline_Detail_ID,@CSR_Date,@Freight_Diff_Amount,@Commission_Amount,@Incentive_Amount,@Used_Exemption_Limit,@Entered_By,@Entered_On,@Certificate_No)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = int.Parse(ViewState["CompanyID"].ToString());
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());

        //********************Update On 15 Feb 2012: TK-On-AwbDateWise, rest of Airline on FlightDateWise*************************


        //////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297")
        //////{
        //////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        //////}

        if ((txtAWBNO.Text.Trim().Substring(0, 3) == "235") || (txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        }
        else
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        }


        //******************************************End of 15 FEB 2012*****************************************************


        decimal dfa = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        com.Parameters.Add("@Freight_Diff_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        decimal Coam = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        com.Parameters.Add("@Commission_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        decimal Incentiver = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Incentive_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Used_Exemption_Limit", SqlDbType.Decimal).Value = decimal.Parse(ViewState["Total_UsedExemption_Limit"].ToString());
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text;
        com.ExecuteNonQuery();
    }

    #endregion

    #region UpdateAgentWiseTDSStatus
    public void UpdateAgentWiseTDSStatus(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Agentwise_TDS set Exemption_limit_crossed=@Exemption_limit_crossed where Agent_ID=@Agent_ID and Agent_TDS_ID=@Agent_TDS_ID";

        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Exemption_limit_crossed", SqlDbType.Char).Value = ViewState["Ex_crossed_limit"].ToString();
        com.Parameters.Add("@Agent_ID", SqlDbType.Int).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Agent_TDS_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_TDS_ID"].ToString());



        com.ExecuteNonQuery();
    }

    #endregion
    #region TDS
    public decimal TDS()
    {
        decimal FreightDiffRate = 0, FreightDiffAmount = 0;
        if (ChkMinAgent.Checked == true)
        {
            FreightDiffRate = decimal.Parse(txtTariffRate.Text) - decimal.Parse(txtSpotRate.Text);
            FreightDiffAmount = FreightDiffRate;
        }
        else
        {
            if (decimal.Parse(txtSpotRate.Text) != 0)
            {
                FreightDiffRate = decimal.Parse(txtTariffRate.Text) - decimal.Parse(txtSpotRate.Text);
                FreightDiffAmount = FreightDiffRate * decimal.Parse(txtCw.Text);
            }
            else
            {
                FreightDiffAmount = 0;
            }
        }
        ViewState["FreightDiffAmount"] = FreightDiffAmount;

        decimal FreightAmt = decimal.Parse(txtSpAmt.Text);//Commissionalbe Amount
        decimal Commission = decimal.Parse(txtIATACommission.Text);//Commission Rate
        decimal Incentive = decimal.Parse(txtSCR_Incentive.Text);

        decimal CommissionAmount = FreightAmt * Commission;
        CommissionAmount = CommissionAmount / 100;
        ViewState["CommissionableAmount"] = CommissionAmount;

        decimal IncentiveAmount = FreightAmt - CommissionAmount;
        IncentiveAmount = IncentiveAmount * Incentive;
        IncentiveAmount = IncentiveAmount / 100;
        ViewState["IncentiveAmount"] = IncentiveAmount;

        //********Main TDS Formula*******************************************
        decimal UsedExemptionLimit = FreightDiffAmount + CommissionAmount + IncentiveAmount;
        //UsedExemptionLimit = UsedExemptionLimit + TotalAgentUsedLimit;
        return UsedExemptionLimit;
        //********End Main TDS Formula*******************************************
    }
    #endregion

    #region Update_AgentLimit
    public void Update_AgentLimit(SqlTransaction tr, SqlConnection con, decimal Used_Limit)
    {
        string update;

        update = "update Agent_Branch set Used_Limit=" + Used_Limit + " where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString();
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion


    #region Update_Stock
    public void Update_Stock(SqlTransaction tr, SqlConnection con, string StockID)
    {
        string update;

        update = "update Stock_Master set Status=11" + "  where Stock_ID=" + StockID;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion

    #region Update_HandOver
    public void Update_Handover(SqlTransaction tr, SqlConnection con, string HandoverID, string SalesID)
    {
        string update;

        update = "update Handover set Added_To_Sales=@Added_To_Sales,Agent_Deal_Remarks=@Agent_Deal_Remarks where Handover_ID=@Handover_ID";
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtAgentDealRemarks.Text;
        com.Parameters.Add("@Added_To_Sales", SqlDbType.Int).Value = 11;

        com.ExecuteNonQuery();

    }


    #endregion

    #region Update_BookingAWB
    public void Update_BookingAWB(SqlTransaction tr, SqlConnection con, string HandoverID, string SalesID)
    {
        string update;

        update = "update Booking_AWB set Sales_ID=@Sales_ID,Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges where Handover_ID=@Handover_ID";


        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;

        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;

        // com.Parameters.Add("@AWC_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = txtHouses.Value;
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = txtDueAgentP.Text;
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = txtDueAgentC.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = txtDueCarrier.Text;
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = txtPrepaid.Text;
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = txtCollect.Text;
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(WSC.Value);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(FSC.Value);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(XRay.Value);


        //com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        //com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        //com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        //com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        //com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        //com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        com.ExecuteNonQuery();

    }


    #endregion

    #region Insert_Sales
    public void Insert_Sales(SqlTransaction tr, SqlConnection con, string HandoverID)
    {
        

        string insert;

        insert = "insert into Sales(Booking_ID,Handover_ID,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,FSCRate,WSCRate,XRayRate,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,GSAComm_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Remarks,TDS,Surcharge,Education_Cess,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,TruckerAmount,TruckerPerKg,TruckerSupplier_id,TruckingOrigin,VendorAwbNo,SubAgent_Id,SubAgntRefNo,Cpp_FinalAgentCity,MSC_Charges,KE_Principle_Rate,KE_Principle_Spot_Rate,KE_Principle_Min_Status,KE_Principle_Amount,ETCharges,Certificate_No) values(@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Remarks,@TDS,@Surcharge,@Education_Cess,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@TruckerAmount,@TruckerPerKg,@TruckerSupplier_id,@TruckingOrigin,@VendorAwbNo,@SubAgent_Id,@SubAgntRefNo,@Cpp_FinalAgentCity,@MSC_Charges,@KE_Principle_Rate,@KE_Principle_Spot_Rate,@KE_Principle_Min_Status,@KE_Principle_Amount,@ETCharges,@Certificate_No)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["Booking_ID"]);
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = txtFlightNo.Text.Trim();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Flight_Open_Id_New"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        //********************************Updated Csr Date on 15 Feb 2012, TK-On Awb Date , rest are on Flight Date.************************************



        ////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297" || txtAWBNO.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        ////}

        if( (txtAWBNO.Text.Trim().Substring(0, 3) == "235")||(txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        }
        else
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        }

        //********************************End Of Csr Date Updataion of 15 Feb 2012*****************************************************************************************


        //com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        string strOrgin = txtOrigin.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        // com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = ddlDestination.SelectedItem.Text;
        strDestination = strDestination.Substring(0, 3);
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(txtHouses.Value);
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentP.Text);
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentC.Text);
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtDueCarrier.Text);
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtPrepaid.Text);
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtCollect.Text);
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRFSC.Value);
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRWSC.Value);
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(txtRXRAY.Value);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpotRate.Text);
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(txtIATACommission.Text);
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(txtSCR_Incentive.Text);

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);


        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        DataTable dtGSA = dw.GetAllFromQuery("select GSAComm_Rate from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtGSA.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtOthers.Text); ;
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;

        DataTable dtBooking_AWBDetails = dw.GetAllFromQuery("select Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity from Booking_AWB where Handover_ID=" + HandoverID);

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Nature_and_Quantity"].ToString();
        ////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        ////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        ////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        ////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(txtTDS.Text);
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(txtSurcharge.Text);
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(txtEducationalCess.Text);
        #region Generating CSR Serial Auto Number

        //string CSR_Date=(txtAWBDate.Text);

        string CSR_Date;

        ////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297" || txtAWBNO.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    CSR_Date = (txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    CSR_Date = (txtAWBDate.Text);
        ////}


        if ((txtAWBNO.Text.Trim().Substring(0, 3) == "235") || (txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
       
        {
            CSR_Date = (txtAWBDate.Text);

        }
        else
        {
            CSR_Date = (txtFlightDate.Text);

        }



        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }

        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion

        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = ddlTruckerSupplier.SelectedValue;
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;


        #region SubAgent
        DataTable SubAgentId = dw.GetAllFromQuery("Select isnull(subAgent_Id,0) as subAgent_Id,SubAgntRefNo from Booking_Master where stock_id=" + ViewState["Stock_ID"].ToString() + "");

        if (SubAgentId.Rows.Count > 0)
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = SubAgentId.Rows[0]["subAgent_Id"].ToString() == "0" ? (object)DBNull.Value : int.Parse(SubAgentId.Rows[0]["subAgent_Id"].ToString());
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = SubAgentId.Rows[0]["SubAgntRefNo"].ToString();
        }
        else
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = (object)DBNull.Value;
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = "";

        }


        #endregion



        DataTable dtCppAgentCity = dw.GetAllFromQuery("select Offline_City from agent_Master where agent_id=" + long.Parse(ViewState["Agent_ID"].ToString()) + " and Offline_Agent='Y'");



        if (dtCppAgentCity.Rows.Count > 0)
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(dtCppAgentCity.Rows[0]["Offline_City"].ToString());
        }
        else
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        }

        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);

        //================================ Updated on 2nd july 2012 rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
       
        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text ;
        //======================================================================================================



        com.ExecuteNonQuery();

        #region ShipperConsignee Insertion
        com = new SqlCommand("Insert_Shipper_Details", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.ExecuteNonQuery();
        #endregion
    }
    #endregion

    #region Update_Sales
    public void Update_Sales(SqlTransaction tr, SqlConnection con, string HandoverID)
    {
        string update;


        update = "update Sales set Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_Name=@Shipment_Name,Shipment_ID=@Shipment_ID,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,FSCRate=@FSCRate,WSCRate=@WSCRate,XRayRate=@XRayRate,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Spot_Rate=@Spot_Rate,Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Special_Rate=@Special_Rate,Special_Amount=@Special_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,GSAComm_Rate=@GSAComm_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Other_DueCarrier=@Other_DueCarrier,Other_Remarks=@Other_Remarks,Currency=@Currency,CHGS_Code=@CHGS_Code,Declared_Carriage_Value=@Declared_Carriage_Value,Declared_Custom_Value=@Declared_Custom_Value,Handling_Information=@Handling_Information,Nature_and_Quantity=@Nature_and_Quantity,Remarks=@Remarks,TDS=@TDS,Surcharge=@Surcharge,Education_Cess=@Education_Cess,CSR_SNo=@CSR_SNo,Sales_Added_Date=@Sales_Added_Date,Agent_Min_Status=@Agent_Min_Status,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Entered_By=@Entered_By,Entered_On=@Entered_On,Add_To_Deal=@Add_To_Deal,TruckerAmount=@TruckerAmount,TruckerPerKg=@TruckerPerKg,TruckerSupplier_id=@TruckerSupplier_id,TruckingOrigin=@TruckingOrigin,VendorAwbNo=@VendorAwbNo,SubAgent_Id=@SubAgent_Id,SubAgntRefNo=@SubAgntRefNo,Cpp_FinalAgentCity=@Cpp_FinalAgentCity,MSC_Charges=@MSC_Charges,KE_Principle_Rate=@KE_Principle_Rate,KE_Principle_Spot_Rate=@KE_Principle_Spot_Rate,KE_Principle_Min_Status=@KE_Principle_Min_Status,KE_Principle_Amount=@KE_Principle_Amount,ETCharges=@ETCharges,Certificate_No=@Certificate_No where Handover_ID=@Handover_ID";


        SqlCommand com = new SqlCommand(update, con, tr);

        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = txtFlightNo.Text.Trim();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Flight_Open_Id_New"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        //*******************************Updated on 15 Feb 2012, Tk-On-Awb date, rest Airlines on -Flight Datewise**************************************

        ////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297" || txtAWBNO.Text.Trim().Substring(0, 3) == "360" || txtAWBNO.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        ////}

        if ((txtAWBNO.Text.Trim().Substring(0, 3) == "235") || (txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        }
        else
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        }


        //*******************************End of 15 Feb 2012*************************************************************


        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        string strOrgin = txtOrigin.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = ddlDestination.SelectedItem.Text;
        strDestination = strDestination.Substring(0, 3);
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(txtHouses.Value);
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentP.Text);
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentC.Text);
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtDueCarrier.Text);
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtPrepaid.Text);
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtCollect.Text);

        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRFSC.Value);
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRWSC.Value);
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(txtRXRAY.Value);
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);

        //com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(WSC.Value);
        //com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(FSC.Value);
        //com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(XRay.Value);

        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpotRate.Text);
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(txtIATACommission.Text);
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(txtSCR_Incentive.Text);

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);



        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);


        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        DataTable dtGSA = dw.GetAllFromQuery("select GSAComm_Rate from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtGSA.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtOthers.Text); ;
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;

        DataTable dtBooking_AWBDetails = dw.GetAllFromQuery("select Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity from Booking_AWB where Handover_ID=" + HandoverID);

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Nature_and_Quantity"].ToString();
        ////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value =txtShipper.Text;
        ////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        ////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        ////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(txtTDS.Text);
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(txtSurcharge.Text);
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(txtEducationalCess.Text);
        #region Generating CSR Serial Auto Number

        //string CSR_Date = (txtAWBDate.Text);
        string CSR_Date;

        //************************************Updated On 15 Feb 2012: Tk-On-Awb Date and Rest Airline on -FlightDate***************************


        ////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297" || txtAWBNO.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    CSR_Date = (txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    CSR_Date = (txtAWBDate.Text);
        ////}

        if ((txtAWBNO.Text.Trim().Substring(0, 3) == "235") || (txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
        {
            CSR_Date = (txtAWBDate.Text);

        }
        else
        {
            CSR_Date = (txtFlightDate.Text);

        }
        //********************************END of 15 Feb 2012***************************************************************************************
        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }

        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion

        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 20;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = ddlTruckerSupplier.SelectedValue;
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;

        #region SubAgent
        DataTable SubAgentId = dw.GetAllFromQuery("Select isnull(subAgent_Id,0) as subAgent_Id,SubAgntRefNo from Booking_Master where stock_id=" + ViewState["Stock_ID"].ToString() + "");

        if (SubAgentId.Rows.Count > 0)
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = SubAgentId.Rows[0]["subAgent_Id"].ToString() == "0" ? (object)DBNull.Value : int.Parse(SubAgentId.Rows[0]["subAgent_Id"].ToString());
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = SubAgentId.Rows[0]["SubAgntRefNo"].ToString();
        }
        else
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = (object)DBNull.Value;
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = "";

        }

        #endregion

        DataTable dtCppAgentCity = dw.GetAllFromQuery("select Offline_City from agent_Master where agent_id=" + long.Parse(ViewState["Agent_ID"].ToString()) + " and Offline_Agent='Y'");



        if (dtCppAgentCity.Rows.Count > 0)
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(dtCppAgentCity.Rows[0]["Offline_City"].ToString());
        }
        else
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        }

        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);

        //================================Updated on  2nd july 2012 rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text;
        //======================================================================================================
        com.ExecuteNonQuery();

        #region ShipperConsignee Insertion
        com = new SqlCommand("Insert_Shipper_Details", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.ExecuteNonQuery();
        #endregion

    }
    #endregion


    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }



    protected void ddlScr_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    #region Edit_Sales
    public void Edit_Sales(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;


        update = "update Sales set CSR_SNo=@CSR_SNo,Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_Name=@Shipment_Name,Shipment_ID=@Shipment_ID,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,FSCRate=@FSCRate,WSCRate=@WSCRate,XRayRate=@XRayRate,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Spot_Rate=@Spot_Rate,Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Special_Rate=@Special_Rate,Special_Amount=@Special_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Other_DueCarrier=@Other_DueCarrier,Other_Remarks=@Other_Remarks,Remarks=@Remarks,TDS=@TDS,Surcharge=@Surcharge,Education_Cess=@Education_Cess,Approved_for_CSR=@Approved_for_CSR,Sales_Added_Date=@Sales_Added_Date,Agent_Min_Status=@Agent_Min_Status,CSR_Remarks=@CSR_Remarks,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Entered_By=@Entered_By,Entered_On=@Entered_On,TruckerAmount=@TruckerAmount,TruckerPerKg=@TruckerPerKg,TruckerSupplier_id=@TruckerSupplier_id,TruckingOrigin=@TruckingOrigin,VendorAwbNo=@VendorAwbNo,Cpp_FinalAgentCity=@Cpp_FinalAgentCity,MSC_Charges=@MSC_Charges,KE_Principle_Rate=@KE_Principle_Rate,KE_Principle_Spot_Rate=@KE_Principle_Spot_Rate,KE_Principle_Min_Status=@KE_Principle_Min_Status,KE_Principle_Amount=@KE_Principle_Amount,ETCharges=@ETCharges ,Certificate_No=@Certificate_No where Sales_ID=@Sales_ID";


        SqlCommand com = new SqlCommand(update, con, tr);

        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(SalesID);

        #region Generating CSR Serial Auto Number
        string CSR_Date;

        //********************************Updated On 15 Feb 2012 TK-On-Awb Date and rest Airline on FlightWise********************************//

        //////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297" || txtAWBNO.Text.Trim().Substring(0, 3) == "180")
        //////{
        //////    CSR_Date = (txtFlightDate.Text);

        //////}
        //////else
        //////{
        //////     CSR_Date = (txtAWBDate.Text);
        //////}

        if ((txtAWBNO.Text.Trim().Substring(0, 3) == "235") || (txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
        {
            CSR_Date = (txtAWBDate.Text);

        }
        else
        {
            CSR_Date = (txtFlightDate.Text);

        }
        //*********************************************End of 15 Feb 2012***********************************************************//

        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }
        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = txtFlightNo.Text.Trim();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Flight_Open_Id_New"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
        string Sales_ID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            Sales_ID = Request.QueryString["Sales_ID"];
        }
        DataTable dtSales_ID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + Sales_ID);
        if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
        }
        else
        {
            //com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
            //********************************Updated On 15 Feb 2012 :Tk-On-Awb date and Rest Airlines on FlightDateWise*************************


            ////if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297" || txtAWBNO.Text.Trim().Substring(0, 3) == "360" || txtAWBNO.Text.Trim().Substring(0, 3) == "180")
            ////{
            ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

            ////}
            ////else
            ////{
            ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
            ////}


            if ((txtAWBNO.Text.Trim().Substring(0, 3) == "235") || (txtAWBNO.Text.Trim().Substring(0, 3) == "071"))
            {
                com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
            }
            else
            {
                com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
            }

            //****************************End of 15 Feb 2012*****************************************************************************************
        }
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        string strOrgin = txtOrigin.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = ddlDestination.SelectedItem.Text;
        strDestination = strDestination.Substring(0, 3);
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        //com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(txtHouses.Value);
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        //com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentP.Text);
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentC.Text);
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtDueCarrier.Text);
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtPrepaid.Text);
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtCollect.Text);
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRFSC.Value);
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRWSC.Value);
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(txtRXRAY.Value);
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpotRate.Text);
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(txtIATACommission.Text);
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(txtSCR_Incentive.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);
        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtOthers.Text); ;
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        ////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        ////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        ////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        ////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(txtTDS.Text);
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(txtSurcharge.Text);
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(txtEducationalCess.Text);
        if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        {
            com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 28;
        }
        else
        {
            com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 29;
        }
        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = status;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@CSR_Remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = int.Parse(ddlTruckerSupplier.SelectedValue);
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;
        DataTable dtCppAgentCity = dw.GetAllFromQuery("select Offline_City from agent_Master where agent_id=" + long.Parse(ViewState["Agent_ID"].ToString()) + " and Offline_Agent='Y'");
        if (dtCppAgentCity.Rows.Count > 0)
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(dtCppAgentCity.Rows[0]["Offline_City"].ToString());
        }
        else
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        }
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);

        //================================ Updated On 2nd july 2012  rates for ke  =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text;
        //======================================================================================================

        com.ExecuteNonQuery();
        #region ShipperConsignee Insertion
        com = new SqlCommand("Insert_Shipper_Details", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();

        
        com.ExecuteNonQuery();
        #endregion
    }
    #endregion

    #region Edit_BookingAWB
    public void Edit_BookingAWB(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;
        update = "update Booking_AWB set Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges,MSC_Charges=@MSC_Charges where Sales_ID=@Sales_ID";
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        //com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;

        // com.Parameters.Add("@AWC_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = txtHouses.Value;
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = txtDueAgentP.Text;
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = txtDueAgentC.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = txtDueCarrier.Text;
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = txtPrepaid.Text;
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = txtCollect.Text;
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);
        com.ExecuteNonQuery();
    }
    #endregion

    #region Edit_Handover
    public void Edit_Handover(SqlTransaction tr, SqlConnection con, string HandoverID)
    {
        string update;

        update = "update Handover set Agent_Deal_Remarks=@Agent_Deal_Remarks where Handover_ID=@Handover_ID";
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtAgentDealRemarks.Text;
        //com.Parameters.Add("@Added_To_Sales", SqlDbType.Int).Value = 11;

        com.ExecuteNonQuery();

    }


    #endregion

    #region EditUsedLimit
    public void EditUsedLimit(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Agentwise_Used_TDS set CSR_Date=@CSR_Date,Freight_Diff_Amount=@Freight_Diff_Amount,Commission_Amount=@Commission_Amount,Incentive_Amount=@Incentive_Amount,Used_Exemption_Limit=@Used_Exemption_Limit,Entered_By=@Entered_By,Entered_On=@Entered_On ,Certificate_No=@Certificate_No where Agent_ID=@Agent_ID and Stock_ID=@Stock_ID and Airline_Detail_ID=@Airline_Detail_ID";

        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        // com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = int.Parse(ViewState["CompanyID"].ToString());
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
        //string Sales_ID = "";
        //if (Request.QueryString["Sales_ID"] != null)
        //{
        //    Sales_ID = Request.QueryString["Sales_ID"];
        //}
        //DataTable dtSales_ID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + Sales_ID);
        //if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        //{
        //    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
        //}
        //else
        //{
        //    //com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
        //    if (txtAWBNO.Text.Trim().Substring(0, 3) == "232" || txtAWBNO.Text.Trim().Substring(0, 3) == "297")
        //    {
        //        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        //    }
        //    else
        //    {
        //        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        //    }
        //}

        decimal dfa = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        com.Parameters.Add("@Freight_Diff_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        decimal Coam = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        com.Parameters.Add("@Commission_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        decimal Incentiver = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Incentive_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Used_Exemption_Limit", SqlDbType.Decimal).Value = decimal.Parse(ViewState["Total_UsedExemption_Limit"].ToString());
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text == null ? "" : txtcertificate_no.Text;

        com.ExecuteNonQuery();
    }

    #endregion

    #region Insert_Sales_History
    public void Insert_Sales_History(SqlTransaction tr, SqlConnection con, DataTable dtSales)
    {
        string insert;

        insert = "insert into Sales_History(Sales_ID,CSR_SNo,Booking_ID,Handover_ID,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Remarks,TDS,Surcharge,Education_Cess,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,TruckerAmount,TruckerPerKg,TruckerSupplier_id,TruckingOrigin,VendorAwbNo,MSC_Charges,ETCharges) values(@Sales_ID,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Remarks,@TDS,@Surcharge,@Education_Cess,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@TruckerAmount,@TruckerPerKg,@TruckerSupplier_id,@TruckingOrigin,@VendorAwbNo,@MSC_Charges,@ETCharges)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Sales_ID"].ToString());
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["CSR_SNo"].ToString());
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Booking_ID"].ToString());
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Handover_ID"].ToString());
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["Flight_No"].ToString();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Flight_Open_ID"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["AirWayBill_No"].ToString();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["AWB_Date"].ToString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["CSR_Date"].ToString();
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Flight_Date"].ToString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Special_Commodity_ID"].ToString());
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Shipment_ID"].ToString());
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["City_Code"].ToString();
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["City_ID"].ToString());
        // com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Destination_ID"].ToString());
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Airline_Detail_ID"].ToString());
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Disbursement_Charges"].ToString());
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["AWB_Fees"].ToString());
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Valuation_Charge"].ToString());
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Tax"].ToString());
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["No_of_houses"].ToString());
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_ACI_Fees"].ToString());
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Cartridge_Charges"].ToString());
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = dtSales.Rows[0]["DueCarrier_Type"].ToString();
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Prepaid"].ToString());
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Collect"].ToString());
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_DueCarrier"].ToString());
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_Prepaid"].ToString());
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_Collect"].ToString());
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["War_Surcharges"].ToString());
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Fuel_Surcharges"].ToString());
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Xray_Charges"].ToString());
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Charged_Weight"].ToString());
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Spot_Rate"].ToString());
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Commission"].ToString());
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Special_Commodity_Incentive"].ToString());

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtSales.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Freight_Amount"].ToString());

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Special_Rate"].ToString());
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Special_Amount"].ToString());


        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Spot_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Principle_Spot_Rate"].ToString();
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Other_DueCarrier"].ToString());
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Other_Remarks"].ToString();
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtSales.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtSales.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtSales.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtSales.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtSales.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Address"].ToString();
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Remarks"].ToString();
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["TDS"].ToString());
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Surcharge"].ToString());
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Education_Cess"].ToString());
        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Sales_Added_Date"].ToString();
        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Agent_Min_Status"].ToString());

        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Principle_Min_Status"].ToString());
        int adddeal = (dtSales.Rows[0]["Add_To_Deal"].ToString() == "" ? 14 : int.Parse(dtSales.Rows[0]["Add_To_Deal"].ToString()));
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = adddeal;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Status"].ToString());
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = dtSales.Rows[0]["Entered_By"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = dtSales.Rows[0]["Entered_On"].ToString();
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = ddlTruckerSupplier.SelectedValue;
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["MSC_Charges"].ToString());
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["ETCharges"].ToString());
        com.ExecuteNonQuery();
    }
    #endregion

    protected void UpdateSales_Click(object sender, EventArgs e)
    {
        txtcertificate_no.Text = hdn_certificate_no.Value;
        if (hdn_ex_cross_limit.Value == "")
        {
            ViewState["Ex_crossed_limit"] = "N";
        }
        else
        {
            ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
        }
        DataTable dtFlight = GetFlightDetails(txtFlightNo.Text, txtFlightDate.Text);
        if (dtFlight.Rows.Count == 0)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "AlertFlight1", "<script>alert('Flight not found on this flight Date. Open flight or check flight schedule');</script>");
            return;
        }
        else
        {
            ViewState["Flight_Open_Id_New"] = dtFlight.Rows[0]["Flight_Open_ID"];

        }



        string Actual_Discount = "";
        string SpotRate = "";
        string SpotAmount = "";
        string CommAmount = "";
        string Inc_Amount = "";
        string Current_Discount = "";
        string Overall_Amount = "";


        string _Chargd_weight = "";
        string _spotRate = "";
        string _Commission = "";
        string _Special_commodity_incentive = "";
        string _Frieght_Amount = "";
        _Chargd_weight = txtCw.Text;
        _spotRate = txtSpotRate.Text;
        _Commission = txtIATACommission.Text;
        _Special_commodity_incentive = txtSCR_Incentive.Text;
        _Frieght_Amount = txtSpAmt.Text;



        //*********************** Condition on  AddToSales Condition on Insentive and Frieght on 23_June_2010
        Actual_Discount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * 5 / 100);
        if ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) > 0)
        {
            SpotAmount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) * (_Chargd_weight == "" ? 0 : decimal.Parse(_Chargd_weight))));
        }

        CommAmount = Convert.ToString(((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * (_Commission == "" ? 0 : decimal.Parse(_Commission))) / 100);

        Inc_Amount = Convert.ToString((((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - decimal.Parse(CommAmount)) * (_Special_commodity_incentive == "" ? 0 : decimal.Parse(_Special_commodity_incentive))) / 100);


        Current_Discount = Convert.ToString((SpotAmount == "" ? 0 : decimal.Parse(SpotAmount)) + (CommAmount == "" ? 0 : decimal.Parse(CommAmount)) + (Inc_Amount == "" ? 0 : decimal.Parse(Inc_Amount)));

        Overall_Amount = Convert.ToString((Current_Discount == "" ? 0 : decimal.Parse(Current_Discount)) - (Actual_Discount == "" ? 0 : decimal.Parse(Actual_Discount)));
        //*************************************End of Condition on Insentive and Frieght on 23_June_2010
        string AWbNum = txtAWBNO.Text.Trim().Substring(0, 3);
        if (Overall_Amount.Contains("-") && AWbNum != "235")
        /////if (Overall_Amount.Contains("-"))
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('IATA COMM IS LESS AS PER IATA RULE');</script>");
        }
        else
        {
            if ((txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim())) > 0 && ddlTruckerSupplier.SelectedItem.Text == "- -Select- -")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('Please Select Trucker Supplier Name');</script>");
                ddlTruckerSupplier.Focus();
            }
            else
            {

                con = new SqlConnection(strCon);
                con.Open();
                SqlTransaction tranupdate = con.BeginTransaction();
                decimal UsedExemptionLimit = TDS();
                ViewState["Total_UsedExemption_Limit"] = UsedExemptionLimit;
                string SalesID = "";
                if (Request.QueryString["Sales_ID"] != null)
                {
                    SalesID = Request.QueryString["Sales_ID"];
                }
                DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);

                decimal OldSalesAmount = 0;
                if (dtHandoverID.Rows.Count > 0)
                {
                    DataTable dtDiscount = dw.GetAllFromQuery("select Used_Exemption_Limit from Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString());
                    decimal Used_Exemption_Limit = 0;
                    if (dtDiscount.Rows.Count > 0)
                    {
                        Used_Exemption_Limit = decimal.Parse(dtDiscount.Rows[0]["Used_Exemption_Limit"].ToString());
                    }
                    if (dtHandoverID.Rows[0]["Freight_Type"].ToString() == "PREPAID")
                    {
                        OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Total_DueCarrier"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Freight_Amount"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) + +decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - Used_Exemption_Limit;
                    }
                    else
                    {
                        OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) - decimal.Parse(dtHandoverID.Rows[0]["TotalDueAgent_Collect"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - Used_Exemption_Limit;
                    }

                }
                decimal NewSalesAmount = 0;

                if (rbFType.SelectedValue == "PREPAID")
                {
                    NewSalesAmount = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtSpAmt.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
                }
                else
                {
                    NewSalesAmount = decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - decimal.Parse(txtDueAgentC.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
                }

                // NewSalesAmount = -OldSalesAmount + NewSalesAmount;
                DataTable dtUsed_Limit = dw.GetAllFromQuery("SELECT Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString());


                //********************Added ON 29 Mar 2011 For(offline City Agent case)********************
                decimal Used_Limit = 0;
                if (dtUsed_Limit.Rows.Count <= 0)
                {
                    string ULimit = "";
                    dtUsed_Limit = dw.GetAllFromQuery("select Offline_CityID from booking_master where booking_id=" + dtHandoverID.Rows[0]["Booking_ID"].ToString() + " and Offline_CityID!=''");
                    if (dtUsed_Limit.Rows.Count > 0)
                    {
                        //********Offline Case***************
                        dtUsed_Limit = dw.GetAllFromQuery("SELECT Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString());


                        if (dtUsed_Limit.Rows.Count > 0)
                        {
                            ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                        }
                        else
                        {
                            dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString() + "");
                            if (dtUsed_Limit.Rows.Count > 0)
                            {
                                ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                            }
                        }


                        if (ULimit == "")
                        {
                            ULimit = "0";
                        }

                        Used_Limit = decimal.Parse(ULimit) - OldSalesAmount + NewSalesAmount;
                    }
                }
                else
                {
                    //**********Online Case****************
                    Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
                }
                //********************END***************************************************
                //////decimal Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
                Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);
                try
                {
                    Edit_Sales(tranupdate, con, SalesID);
                    Insert_Sales_History(tranupdate, con, dtHandoverID);
                    //Edit_BookingAWB(tranupdate, con, SalesID);
                    Update_AWBDate(tranupdate, con);
                    Edit_Handover(tranupdate, con, dtHandoverID.Rows[0]["Handover_ID"].ToString());

                    DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                    if (dtOtherChargesID.Rows.Count > 0)
                    {
                        if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                        {
                            dtOtherChargesID.Rows[0].Delete();
                        }
                    }
                    long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
                    Update_OtherCharges(tranupdate, con, BookingID);
                    //Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());

                    //decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtFreightAmount.Text);
                    Update_AgentLimit(tranupdate, con, Used_Limit);

                    EditUsedLimit(tranupdate, con);

                    tranupdate.Commit();
                    con.Close();


                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    tranupdate.Rollback();
                }
                //if (dtHandoverID.Rows[0]["Approved_for_CSR"].ToString() == "28")
                //{
                //    con = new SqlConnection(strCon);
                //    con.Open();
                //    SqlTransaction tr = con.BeginTransaction();
                //    try
                //    {
                //        Insert_Sales_DrCr1(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                //        Insert_Sales_DrCr2(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                //        tr.Commit();
                //        con.Close();
                //    }

                //    catch (Exception ex)
                //    {
                //        Response.Write(ex.Message);
                //        tr.Rollback();
                //    }
                //}
                Response.Redirect("SalesEdit.aspx");
            }
        }
    }
    protected void btnSModify_Click(object sender, EventArgs e)
    {

        DataTable dtFlight = GetFlightDetails(txtFlightNo.Text, txtFlightDate.Text);
        if (dtFlight.Rows.Count == 0)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "AlertFlight2", "<script>alert('Flight not found on this flight Date. Open flight or check flight schedule');</script>");
            return;
        }
        else
        {
            ViewState["Flight_Open_Id_New"] = dtFlight.Rows[0]["Flight_Open_ID"];
        }
        if ((txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim())) > 0 && ddlTruckerSupplier.SelectedItem.Text == "- -Select- -")
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('Please Select Trucker Supplier Name');</script>");
            ddlTruckerSupplier.Focus();
        }
        else
        {
            con = new SqlConnection(strCon);
            con.Open();
            SqlTransaction tranupdate = con.BeginTransaction();
            decimal UsedExemptionLimit = TDS();
            ViewState["Total_UsedExemption_Limit"] = UsedExemptionLimit;
            string SalesID = "";
            if (Request.QueryString["Sales_ID"] != null)
            {
                SalesID = Request.QueryString["Sales_ID"];
            }
            DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);

            decimal OldSalesAmount = 0;
            if (dtHandoverID.Rows.Count > 0)
            {
                //DataTable dtDiscount = dw.GetAllFromQuery("select Used_Exemption_Limit from Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString());
                ////////**************Changes made by Hemant Sharma on 11'th April 2014***********/////////
            #region Changes made by Hemant Sharma on 11'th April 2014
            
            
                DataTable dtDiscount=dw.GetAllFromQuery("IF EXISTS (SELECT Used_Exemption_Limit FROM  Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString()+") BEGIN SELECT  Used_Exemption_Limit FROM  Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString()+" END  ELSE BEGIN SELECT 0 AS Used_Exemption_Limit END");
            #endregion
                if (dtHandoverID.Rows[0]["Freight_Type"].ToString() == "PREPAID")
                {
                    OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Total_DueCarrier"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Freight_Amount"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - decimal.Parse(dtDiscount.Rows[0]["Used_Exemption_Limit"].ToString());
                }
                else
                {
                    OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) - decimal.Parse(dtHandoverID.Rows[0]["TotalDueAgent_Collect"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - decimal.Parse(dtDiscount.Rows[0]["Used_Exemption_Limit"].ToString());
                }
            }
            decimal NewSalesAmount = 0;
            if (rbFType.SelectedValue == "PREPAID")
            {
                NewSalesAmount = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtSpAmt.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }
            else
            {
                NewSalesAmount = decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - decimal.Parse(txtDueAgentC.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }

            // NewSalesAmount = -OldSalesAmount + NewSalesAmount;
            DataTable dtUsed_Limit = dw.GetAllFromQuery("SELECT isnull(Used_Limit,0) as Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString());




            //********************Added ON 29 Mar 2011 For(offline City Agent case)********************

            //////decimal Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;

            decimal Used_Limit = 0;
            if (dtUsed_Limit.Rows.Count <= 0)
            {
                string ULimit = "";
                dtUsed_Limit = dw.GetAllFromQuery("select Offline_CityID from booking_master where booking_id=" + dtHandoverID.Rows[0]["Booking_ID"].ToString() + " and Offline_CityID!=''");
                if (dtUsed_Limit.Rows.Count > 0)
                {
                    //********Offline Case***************
                    dtUsed_Limit = dw.GetAllFromQuery("SELECT Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString());


                    if (dtUsed_Limit.Rows.Count > 0)
                    {
                        ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                    }
                    else
                    {
                        dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString() + "");
                        if (dtUsed_Limit.Rows.Count > 0)
                        {
                            ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                        }
                    }

                    if (ULimit == "")
                    {
                        ULimit = "0";
                    }

                    Used_Limit = decimal.Parse(ULimit) - OldSalesAmount + NewSalesAmount;
                    //Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
                }
            }
            else
            {
                //**********Online Case****************
                Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
            }
            //********************END***************************************************

            Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);
            string AWBDate = txtAWBDate.Text;
            string CSRdate = txtCSRDate.Text;
            string[] d = AWBDate.Split(new char[] { '/' });
            string strD = d[0];
            int D = Convert.ToInt32(d[0]);
            string strM = d[1];
            int M = Convert.ToInt32(d[1]);
            string strYY = d[2];
            int YY = Convert.ToInt32(d[2]);

            string[] g = CSRdate.Split(new char[] { '/' });
            string strDD = g[0];
            int DD = Convert.ToInt32(g[0]);
            string strMM = g[1];
            int MM = Convert.ToInt32(g[1]);
            string strYYYY = g[2];
            int YYYY = Convert.ToInt32(g[2]);
            string strDate = "";
            if (D <= 15)
            {
                strDate = "16/" + strM + "/" + strYY;
                strDate = FormatDateMM(strDate);

            }
            else
            {
                int Month = M + 1;
                int Year = YY;
                if (Month == 13)
                {
                    Month = 1;
                    Year = YY + 1;
                }
                strDate = "01/" + Month.ToString() + "/" + Year.ToString();
                strDate = FormatDateMM(strDate);
            }
            CSRdate = FormatDateMM(CSRdate);
            //if (DateTime.Parse(CSRdate) >= DateTime.Parse(strDate))
            //{
            try
            {
                Edit_Sales(tranupdate, con, SalesID);

                Insert_Sales_History(tranupdate, con, dtHandoverID);

                DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                if (dtOtherChargesID.Rows.Count > 0)
                {
                    if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                    {
                        dtOtherChargesID.Rows[0].Delete();
                    }
                }
                long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
                Update_OtherCharges(tranupdate, con, BookingID);
                //Edit_BookingAWB(tranupdate, con, SalesID);
                Update_AWBDate(tranupdate, con);
                Edit_Handover(tranupdate, con, dtHandoverID.Rows[0]["Handover_ID"].ToString());

                //Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());

                //decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtFreightAmount.Text);
                Update_AgentLimit(tranupdate, con, Used_Limit);

                EditUsedLimit(tranupdate, con);

                tranupdate.Commit();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                tranupdate.Rollback();
            }
            //DataTable dtDrCr = dw.GetAllFromQuery("select Sales_ID from Sales_DrCr where Sales_ID=" + SalesID);

            if (dtHandoverID.Rows[0]["Approved_for_CSR"].ToString() == "28")
            {
                con = new SqlConnection(strCon);
                con.Open();
                SqlTransaction tr = con.BeginTransaction();
                try
                {

                     
                    //if user want to create crdr
                    if (hdn_Modify.Value == "CRDR")
                    {
                        UpdateApproveStatus(tr, con, SalesID);
                        Insert_Sales_DrCr1(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                        Insert_Sales_DrCr2(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                    }
                    else
                    {
                        Update_Approve_CSR(tr, con, Convert.ToInt32(SalesID), dtHandoverID.Rows[0]["AirWayBill_No"].ToString());
                    }
                    ////Start changes made by kuldeep on 16 june 2014
                    //Update_Approve_CSR(Convert.ToInt32(SalesID), dtHandoverID.Rows[0]["AirWayBill_No"].ToString());
                    ////End changes made by kuldeep on 16 june 2014
                    tr.Commit();
                    con.Close();
                }

                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    tr.Rollback();
                }
            }
            Response.Redirect("SalesEdit.aspx");
            //}
            //else
            //{
            //    lblMessage.Visible = true;
            //}
        }//End of UpdateSalesClick
    }
    //created on 18-06-2014  Created by:kuldeep
    #region UpdateApproveStatus 
    #region UPdate CSR_Detail
    public void Update_Approve_CSR(SqlTransaction tr,SqlConnection con, int SalesID, string awbNo)
    {
        DateTime FROM_DATE, TO_DATE, date;
        DisplayWrap dpw = new DisplayWrap();



        try
        {




            string SqlQuery = " select AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID, a.CSR_SNo,a.CSR_Date FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Sales_ID='" + SalesID.ToString() + "'";

            com = new SqlCommand(SqlQuery, con, tr);
            int COUNT = 1;
            //SqlDataReader dr = com.ExecuteReader();
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dr = new DataTable();
            da.Fill(dr);
            if (dr.Rows.Count > 0)
            {
                date = Convert.ToDateTime(dr.Rows[0]["CSR_Date"]);
                if (date.Day <= 15)
                {
                    DateTime.TryParseExact(date.Month.ToString() + "/01/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out FROM_DATE);
                    DateTime.TryParseExact(date.Month.ToString() + "/15/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out TO_DATE);
                }
                else
                {
                    DateTime.TryParseExact(date.Month.ToString() + "/16/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out FROM_DATE);
                    DateTime Date = (Convert.ToDateTime(FROM_DATE.Month.ToString() + "/" + FROM_DATE.Year.ToString())).AddMonths(1).AddDays(-1);
                    string LastDate = Date.Day.ToString();
                    //TO_DATE = DateTime.ParseExact(date.Month.ToString() + "/LastDate/" + date.Year.ToString(), "MM/dd/yyyy", null);
                    DateTime.TryParseExact(date.Month.ToString() + "/" + LastDate + "/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out TO_DATE);

                }



                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal EduChrg = 0;
                decimal TotTds = 0;
                decimal Total = 0;
                decimal GrandTotal = 0;
                decimal Freight_Amount = 0;
                decimal Total_DueCarrier = 0;
                decimal TotTax = 0;
                decimal Agent_Expenses = 0;
                decimal Freight_Diff_Amount = 0;
                decimal IATA_Commission = 0;
                decimal Amount_Excluding_TDS = 0;
                decimal LastTdsRate = 0;
                decimal LastSurcharge = 0;
                decimal LastEducation_Cess = 0;
                decimal TDS_Amount = 0;
                decimal surCharge = 0;
                decimal Amount_Including_TDS = 0;

                decimal TotComm_CRDR = 0;
                decimal TotDiscount_CRDR = 0;
                decimal TotFrAmount_CRDR = 0;
                decimal TotFrAmountCC_CRDR = 0;
                decimal EduChrg_CRDR = 0;
                decimal TotTds_CRDR = 0;
                decimal Total_CRDR = 0;
                decimal GrandTotal_CRDR = 0;
                decimal Freight_Amount_CRDR = 0;
                decimal Total_DueCarrier_CRDR = 0;
                decimal TotTax_CRDR = 0;
                decimal Agent_Expenses_CRDR = 0;
                decimal Freight_Diff_Amount_CRDR = 0;
                decimal IATA_Commission_CRDR = 0;
                decimal Amount_Excluding_TDS_CRDR = 0;
                decimal LastTdsRate_CRDR = 0;
                decimal LastSurcharge_CRDR = 0;
                decimal LastEducation_Cess_CRDR = 0;
                decimal TDS_Amount_CRDR = 0;
                decimal surCharge_CRDR = 0;
                decimal Amount_Including_TDS_CRDR = 0;
                int Amount_Type_CRDR;

                string AGENT_ID = dr.Rows[0]["AGENT_ID"].ToString();
                string Agent_Name = dr.Rows[0]["Agent_name"].ToString();
                string Agent_Code = dr.Rows[0]["Agent_Code"].ToString();
                string Agent_Address = dr.Rows[0]["Agent_Address"].ToString();
                string CSR_SERIALNo = dr.Rows[0]["CSR_SNo"].ToString();
                long CSR_SNo = 0;
                long CSR_SNo_CRDR = 0;
                string CSR_Durationperiod = FROM_DATE.ToString("MM/dd/yy") + "-" + TO_DATE.ToString("MM/dd/yy");
                string period = FROM_DATE.ToString("dd/MM/yy") + "-" + TO_DATE.ToString("dd/MM/yy");
                string CSR_No = dr.Rows[0]["Agent_Code"].ToString() + "-" + awbNo.Substring(0, 3) + "-" + period;
                int Amount_Type;
                string Sales_Type = "";
                string Sales_Type_CRDR = "";
                DateTime CSR_From = FROM_DATE;
                DateTime CSR_To = TO_DATE;
                string Entered_By = Session["EMailID"].ToString();
                DateTime Entered_On = DateTime.Now;
                if (dr.Rows[0]["AGENT_ID"].ToString() == "405")
                {

                }

                SqlCommand com_csr = new SqlCommand("APPROVE_CSR_DETAILS", con, tr);
                com_csr.CommandType = CommandType.StoredProcedure;
                com_csr.Parameters.AddWithValue("agent_id", AGENT_ID);
                com_csr.Parameters.AddWithValue("CSR_SNo", CSR_SERIALNo);
                com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
                com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
                com_csr.Parameters.AddWithValue("Airline_Detail_ID", dr.Rows[0]["Airline_Detail_ID"].ToString());
                SqlDataAdapter da2 = new SqlDataAdapter(com_csr);
                DataTable dt_csr = new DataTable();
                da2.Fill(dt_csr);
                //SqlDataReader dr_csr = com_csr.ExecuteReader();

                string VarDate = "07/31/2008";
                string Mh_Priod = "08/15/2008";
                foreach (DataRow dr_csr in dt_csr.Rows)
                {
                    if (dr_csr["Sales_Type"].ToString().Trim() == "INV")
                    {
                        Sales_Type = dr_csr["Sales_Type"].ToString().Trim();
                        CSR_SNo = long.Parse(dr_csr["csr_sno"].ToString());
                        Freight_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        Total_DueCarrier += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);

                        Freight_Diff_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(Mh_Priod))
                            {
                                IATA_Commission += 0;
                            }
                            else
                            {
                                IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(VarDate))
                            {
                                IATA_Commission += 0;
                            }
                            else
                            {
                                IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        Amount_Excluding_TDS += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

                        if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                        {

                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                            }
                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }

                        }
                        else
                        {
                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }

                        }
                        LastTdsRate = decimal.Parse(dr_csr["tds"].ToString());
                        LastSurcharge = decimal.Parse(dr_csr["surcharge"].ToString());
                        LastEducation_Cess = decimal.Parse(dr_csr["Education_Cess"].ToString());


                        TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);

                        string amountPP = null;
                        string amountCC = null;
                        if (dr_csr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr_csr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            amountPP = dr_csr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
                        }


                        TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {

                            if ((FROM_DATE) > DateTime.Parse(VarDate))
                            {
                                TotComm += 0;
                                TotDiscount += 0;
                                Agent_Expenses += 0;
                            }
                            else
                            {
                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {

                            if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                            {
                                TotComm += 0;
                                TotDiscount += 0;
                                Agent_Expenses += 0;
                            }
                            else
                            {
                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }

                        else
                        {
                            TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        }
                    }
                    else if (dr_csr["Sales_Type"].ToString().Trim() == "CRDR")
                    {
                        Sales_Type_CRDR = dr_csr["Sales_Type"].ToString().Trim();
                        CSR_SNo_CRDR = long.Parse(dr_csr["csr_sno"].ToString());
                        Freight_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        Total_DueCarrier_CRDR += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        Agent_Expenses_CRDR += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        Freight_Diff_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);


                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(Mh_Priod))
                            {

                                IATA_Commission_CRDR += 0;
                            }
                            else
                            {
                                IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(VarDate))
                            {
                                IATA_Commission_CRDR += 0;
                            }
                            else
                            {
                                IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                        }
                        Amount_Excluding_TDS_CRDR += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

                        if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                        {

                            TotTds_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                            surCharge_CRDR -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            EduChrg_CRDR -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            TotTds_CRDR += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                            surCharge_CRDR += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            EduChrg_CRDR += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                        }
                        LastTdsRate_CRDR = decimal.Parse(dr_csr["tds"].ToString());
                        LastSurcharge_CRDR = decimal.Parse(dr_csr["surcharge"].ToString());
                        LastEducation_Cess_CRDR = decimal.Parse(dr_csr["Education_Cess"].ToString());
                        TDS_Amount_CRDR = Math.Round((TotTds_CRDR + surCharge_CRDR + EduChrg_CRDR), MidpointRounding.AwayFromZero);
                        string amountPP_CRDR = null;
                        string amountCC_CRDR = null;
                        if (dr_csr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP_CRDR = "0";
                            amountCC_CRDR = dr_csr["Freight_Amount"].ToString();
                            TotFrAmountCC_CRDR += Math.Round(decimal.Parse(amountCC_CRDR), MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            amountPP_CRDR = dr_csr["Freight_Amount"].ToString();
                            amountCC_CRDR = "0";
                            TotFrAmount_CRDR += Math.Round(decimal.Parse(amountPP_CRDR), MidpointRounding.AwayFromZero);
                        }
                        TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotComm_CRDR += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        TotDiscount_CRDR += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                    }
                }
                Total = Math.Round(((TotFrAmount + Total_DueCarrier + TotTax) - (Agent_Expenses + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                Decimal Debit_Surcharge = 0;
                DataTable dt_Sur = dpw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + AGENT_ID + " AND AIRLINE_DETAIL_ID=" + dr.Rows[0]["Airline_Detail_ID"].ToString() + " AND (CSR_PERIOD>='" + FROM_DATE + "' AND CSR_PERIOD<='" + TO_DATE + "')");
                if (dt_Sur.Rows.Count > 0)
                {
                    Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                    EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * LastEducation_Cess / 100)), MidpointRounding.AwayFromZero);
                    TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);


                }
                GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                Amount_Including_TDS = GrandTotal;

                if (Amount_Including_TDS < 0)
                {
                    Amount_Type = 24;
                }
                else
                {
                    Amount_Type = 23;
                }

                /************************/
                Total_CRDR = Math.Round(((TotFrAmount_CRDR + Total_DueCarrier_CRDR + TotTax_CRDR) - (Agent_Expenses_CRDR + TotDiscount_CRDR + TotComm_CRDR)), MidpointRounding.AwayFromZero);


                GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                Amount_Including_TDS_CRDR = GrandTotal_CRDR;
                if (Amount_Including_TDS_CRDR < 0)
                {
                    Amount_Type_CRDR = 24;
                }
                else
                {
                    Amount_Type_CRDR = 23;
                }


                SqlCommand strcom;
                SqlCommand durationIdcmd = new SqlCommand("SELECT CSR_Duration_ID FROM CSR_Duration WHERE CSR_Duration='" + CSR_Durationperiod + "' ", con, tr);
                int CSR_Duration_ID = Convert.ToInt32(durationIdcmd.ExecuteScalar());

                if (GrandTotal != 0)
                {
                    strcom = new SqlCommand("spGCCS_UpdateCSRDetail", con, tr);
                    strcom.CommandType = CommandType.StoredProcedure;
                    strcom.Parameters.AddWithValue("@COUNT", COUNT);
                    strcom.Parameters.AddWithValue("@AGENT_ID", Convert.ToInt64(AGENT_ID));
                    strcom.Parameters.AddWithValue("@Airline_Detail_ID", dr.Rows[0]["Airline_Detail_ID"].ToString());
                    strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                    strcom.Parameters.AddWithValue("@Sales_Type", "INV");
                    strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo);
                    strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                    strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                    strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                    strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                    strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount);
                    strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC);
                    strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount);
                    strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier);
                    strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses);
                    strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount);
                    strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission);
                    strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total);
                    strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate);
                    strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge);
                    strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess);
                    strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount) + Debit_Surcharge));
                    strcom.Parameters.AddWithValue("@Surcharge_Amount", (surCharge + Debit_Surcharge));
                    strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount);
                    strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg);
                    strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS);
                    strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type);
                    strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                    strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                    strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                    strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
                    strcom.ExecuteNonQuery();

                }
                /************************************/
                if (GrandTotal_CRDR != 0)
                {

                    strcom = new SqlCommand("spGCCS_UpdateCSRDetail", con,tr);
                    strcom.CommandType = CommandType.StoredProcedure;
                    strcom.Parameters.AddWithValue("@COUNT", COUNT);
                    strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
                    strcom.Parameters.AddWithValue("@Airline_Detail_ID", dr.Rows[0]["Airline_Detail_ID"].ToString());
                    strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                    strcom.Parameters.AddWithValue("@Sales_Type", "CRDR");
                    strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo_CRDR);
                    strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                    strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                    strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                    strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                    strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount_CRDR);
                    strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC_CRDR);
                    strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount_CRDR);
                    strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier_CRDR);
                    strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses_CRDR);
                    strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount_CRDR);
                    strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission_CRDR);
                    strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total_CRDR);
                    strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate_CRDR);
                    strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge_CRDR);
                    strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess_CRDR);
                    strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount_CRDR) + Debit_Surcharge));
                    strcom.Parameters.AddWithValue("@Surcharge_Amount", surCharge_CRDR);
                    strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount_CRDR);
                    strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg_CRDR);
                    strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS_CRDR);
                    strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type_CRDR);
                    strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                    strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                    strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                    strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
                    strcom.ExecuteNonQuery();
                }


                com_csr.Dispose();



            }


        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }


    }
    #endregion 

    public void UpdateApproveStatus(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;
        update = "update Sales set Approved_for_CSR=29 , Sales_type='CRDR' where Sales_ID=" + SalesID;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }
    #endregion

    #region Insert_Sales_DrCr1

    public void Insert_Sales_DrCr1(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {

        string insert;

        insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Booking_ID,Handover_ID,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,FSCRate,WSCRate,XRayRate,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,GSAComm_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Remarks,TDS,Surcharge,Education_Cess,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,MSC_Charges,KE_Principle_Rate,KE_Principle_Spot_Rate,KE_Principle_Min_Status,KE_Principle_Amount,ETCharges) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Remarks,@TDS,@Surcharge,@Education_Cess,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@MSC_Charges,@KE_Principle_Rate,@KE_Principle_Spot_Rate,@KE_Principle_Min_Status,@KE_Principle_Amount,@ETCharges)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "INV";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["Booking_ID"]);
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = txtFlightNo.Text.Trim();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Flight_Open_Id_New"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text.Trim();
        DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
        DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        string strOrgin = txtOrigin.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();

        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Disbursement_Charges"].ToString());
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["AWB_Fees"].ToString());
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Valuation_Charge"].ToString());
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tax"].ToString());
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_houses"].ToString());
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_ACI_Fees"].ToString());
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Cartridge_Charges"].ToString());
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Prepaid"].ToString());
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Collect"].ToString());
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_DueCarrier"].ToString());
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Collect"].ToString());
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["FSCRate"].ToString());
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["WSCRate"].ToString());
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["XRayRate"].ToString());
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["War_Surcharges"].ToString());
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Fuel_Surcharges"].ToString());
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Xray_Charges"].ToString());


        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Spot_Rate"].ToString());
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Commission"].ToString());
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Commodity_Incentive"].ToString());

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Freight_Amount"].ToString());

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Rate"].ToString());
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Amount"].ToString());



        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Other_DueCarrier"].ToString());
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Other_Remarks"].ToString();

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TDS"].ToString());
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Surcharge"].ToString());
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Education_Cess"].ToString());

        com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        // com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

        com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["MSC_Charges"].ToString());

        //================================ Updated On 2nd july 2012  rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["ETCharges"].ToString());
        //======================================================================================================
        com.ExecuteNonQuery();

    }
    #endregion

    #region Insert_Sales_DrCr2
    public void Insert_Sales_DrCr2(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {
        string insert;

        insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Booking_ID,Handover_ID,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,GSAComm_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Remarks,TDS,Surcharge,Education_Cess,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,MSC_Charges,KE_Principle_Rate,KE_Principle_Spot_Rate,KE_Principle_Min_Status,KE_Principle_Amount,ETCharges) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Remarks,@TDS,@Surcharge,@Education_Cess,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@MSC_Charges,@KE_Principle_Rate,@KE_Principle_Spot_Rate,@KE_Principle_Min_Status,@KE_Principle_Amount,@ETCharges)";


        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["Booking_ID"]);
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = txtFlightNo.Text.Trim();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Flight_Open_Id_New"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = txtAWBNO.Text.Trim();
        DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtCSRDate.Text);
        DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        string strOrgin = txtOrigin.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtOrigin.Text.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();

        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Disbursement_Charges"].ToString());
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["AWB_Fees"].ToString());
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Valuation_Charge"].ToString());
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tax"].ToString());
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_houses"].ToString());
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_ACI_Fees"].ToString());
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Cartridge_Charges"].ToString());
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Prepaid"].ToString());
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Collect"].ToString());
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Total_DueCarrier"].ToString());
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Collect"].ToString());
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["FSCRate"].ToString());
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["WSCRate"].ToString());
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["XRayRate"].ToString());
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["War_Surcharges"].ToString());
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Fuel_Surcharges"].ToString());
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Xray_Charges"].ToString());

        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Spot_Rate"].ToString());
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Commission"].ToString());
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Commodity_Incentive"].ToString());

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Freight_Amount"].ToString());

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Rate"].ToString());
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Amount"].ToString());
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Other_DueCarrier"].ToString());
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Other_Remarks"].ToString();
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TDS"].ToString());
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Surcharge"].ToString());
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Education_Cess"].ToString());

        com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        // com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["MSC_Charges"].ToString());

        //================================ Updated On 2nd july 2012  rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        //======================================================================================================
        com.ExecuteNonQuery();
    }
    #endregion




    protected void grd_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd.EditIndex = -1;
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        grd.DataSource = dt;
        grd.DataBind();
    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["Sno"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
            }
            TextBox txthader = grd.FooterRow.FindControl("txtheader") as TextBox;
            TextBox txtfee = grd.FooterRow.FindControl("txtvalue") as TextBox;
            DropDownList drp = (DropDownList)(grd.FooterRow.FindControl("ddlgrd"));
            string paymenttype = drp.SelectedItem.Text;
            DataRow dr = dt.NewRow();
            dr[1] = txthader.Text;
            dr[2] = txtfee.Text;
            dr[3] = paymenttype;
            dt.Rows.Add(dr);
            Session["dtOtherCharges"] = dt;
            decimal DueAgent = 0, DueAgentP = 0, DueAgentC = 0;
            foreach (DataRow rw in dt.Rows)
            {
                DueAgent = DueAgent + Convert.ToDecimal(rw["Fee"].ToString());
                if (rw["PaymentType"].ToString() == "PREPAID")
                {
                    DueAgentP = DueAgentP + Convert.ToDecimal(rw["Fee"].ToString());
                }
                if (rw["PaymentType"].ToString() == "COLLECT")
                {
                    DueAgentC = DueAgentC + Convert.ToDecimal(rw["Fee"].ToString());
                }
            }
            //****************************************
            txtDueAgentP.Text = DueAgentP.ToString();
            txtDueAgentC.Text = DueAgentC.ToString();
            txtDueAgent.Text = DueAgent.ToString();
            //****************************************

            //******Calculation of Dbcharges****************
            decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = dueP.ToString();
            decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = dueC.ToString();
            decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
            txtPrepaid.Text = PP.ToString();
            decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
            txtCollect.Text = CC.ToString();
            if (txtDueAgentC.Text != "0")
            {
                decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                //Taking 10% of Dbcharges*******************
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                {
                    txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                }
                else
                {
                    txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                }
            }
            else
            {
                txtDisbursmentCharges.Text = "0";
            }
            //****End of Dbcharges**************************

            //*****Managing Values After PostBack***********

            decimal ACI = decimal.Parse(Hidden1.Value) * decimal.Parse(txtHouses.Value);
            txtACIFee.Text = ACI.ToString();
            //decimal Due = decimal.Parse(Hidden3.Value) + (ACI - decimal.Parse(Hidden1.Value));
            decimal ThreeCharges = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text);
            decimal Result = ThreeCharges + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtOthers.Text);
            Result = Math.Round(Result, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = Result.ToString();

            //*****End of Manage Values******************

            grd.DataSource = dt;
            grd.DataBind();

            if (rbDueFreight.SelectedValue == "PREPAID")
            {
                decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Total_Prepaid = Total_Prepaid + decimal.Parse(txtSpAmt.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = txtDueAgentC.Text;
                }
                else
                {
                    decimal Total_Collect = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueAgentC.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = Total_Prepaid.ToString();
                }
            }
            else
            {
                decimal Total_Collect = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentC.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    decimal Total_Prepaid = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueAgentP.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = Total_Collect.ToString();
                }
                else
                {
                    Total_Collect = Total_Collect + decimal.Parse(txtSpAmt.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = txtDueAgentP.Text;
                }
            }
        }
    }
    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (ViewState["edit"].ToString() == ViewState["et"].ToString())
            {
                Label lbl = (Label)e.Row.Cells[3].FindControl("lblpaymenttype");
                DropDownList ddl = (DropDownList)e.Row.Cells[3].FindControl("ddlgrd");
                if (ViewState["edit"].ToString() == "PREPAID")
                {
                    //ddl.SelectedIndex=2;
                }
                else
                {
                    //ddl.SelectedIndex=1;

                }
            }
            if (grd.EditIndex == e.Row.RowIndex)
            {
                //DropDownList ddlGrd = (DropDownList)e.Row.FindControl("ddlgrd");
                //ddlGrd.SelectedItem.Text = ViewState["PaymentMode"].ToString();

                //ddlGrd.Items.Add(new ListItem("PREPAID","PREPAID"));
                //ddlGrd.Items.Add(new ListItem("COLLECT","COLLECT"));
                //ddlGrd.SelectedIndex = ddlGrd.Items.IndexOf(ddlGrd.Items.FindByText((e.Row.c));

            }

        }
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int Sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "PREPAID")
                    {
                        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentP.Text = DueAgentP.ToString();
                        txtPrepaid.Text = Prepaid.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "COLLECT")
                    {
                        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentC.Text = DueAgentC.ToString();
                        decimal Collect = decimal.Parse(txtCollect.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtCollect.Text = Collect.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    dt.Rows[e.RowIndex].Delete();

                    //******Calculation of DbCharges*****************
                    decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = dueP.ToString();
                    decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = dueC.ToString();
                    decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = PP.ToString();
                    decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
                    txtCollect.Text = CC.ToString();
                    if (txtDueAgentC.Text != "0")
                    {
                        decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                        //Taking 10% of Dbcharges*******************
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                        decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                        if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                        {
                            txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                        }
                        else
                        {
                            txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                        }
                    }
                    else
                    {
                        txtDisbursmentCharges.Text = "0";
                    }
                    //***End of Calculation of DbCharges*****************
                }
                break;
            }
        }//****End of Foreach loop**********

        //**********Calculation of DueCarrier on Update*********
        decimal ThreeCharges = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text);
        decimal Result = ThreeCharges + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtOthers.Text);
        Result = Math.Round(Result, MidpointRounding.AwayFromZero);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        if (dt.Rows.Count > 0)
        {
            Session["dtOtherCharges"] = dt;
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            DataTable dtBeginCharges = MakeTableCharges();
            Session["dtOtherCharges"] = dtBeginCharges;
            grd.DataSource = dtBeginCharges;
            grd.DataBind();
        }

    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grd.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
        }
        else
        {
            lblmsg.Visible = false;
            Label edit = (Label)grd.Rows[e.NewEditIndex].FindControl("lblpaymenttype");
            Label txtFee = (Label)grd.Rows[e.NewEditIndex].FindControl("txtvalue");
            ViewState["Fee"] = txtFee.Text;
            ViewState["PaymentMode"] = edit.Text;
            ViewState["edit"] = edit.Text;
            ViewState["et"] = ViewState["edit"];
            grd.EditIndex = e.NewEditIndex;
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            grd.DataSource = dt;
            grd.DataBind();
        }
    }
    protected void grd_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        string strheader = ((TextBox)grd.Rows[e.RowIndex].FindControl("txtheader")).Text;
        //int value =Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        decimal value = Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        DropDownList drp = (DropDownList)(grd.Rows[e.RowIndex].FindControl("ddlgrd"));
        string paymenttype = drp.SelectedItem.Text;

        decimal Fee = Convert.ToDecimal(ViewState["Fee"]);
        string PaymentMode = Convert.ToString(ViewState["PaymentMode"]);

        //********* FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                }
            }
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                }
            }
        }

        //********End of FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "COLLECT")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //}
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "PREPAID")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();

            //    }
            //}

        }

        //************** Calculation Of DbCharges*********
        decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
        txtDueAgentP.Text = dueP.ToString();
        decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
        txtDueAgentC.Text = dueC.ToString();
        decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
        txtPrepaid.Text = PP.ToString();
        decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
        txtCollect.Text = CC.ToString();
        if (txtDueAgentC.Text != "0")
        {
            decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
            //Taking 10% of Dbcharges*******************
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
            decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
            if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
            {
                txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
            }
        }
        else
        {
            txtDisbursmentCharges.Text = "0";
        }

        //********End of Calculation Of DbCharges*********

        //**********Calculation of DueCarrier on Update*********
        decimal ThreeCharges = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text);
        decimal Result = ThreeCharges + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtOthers.Text);
        Result = Math.Round(Result, MidpointRounding.AwayFromZero);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == sno.ToString())
            {
                dr[1] = strheader;
                dr[2] = value;
                dr[3] = paymenttype;
            }
        }
        Session["dtOtherCharges"] = dt;
        grd.DataSource = dt;
        grd.EditIndex = -1;
        grd.DataBind();


    }


    protected DataTable GetFlightDetails(string Flight_No, string Flight_Date)
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand("GetFlightOpenId", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Flight_Date", FormatDateDD(Flight_Date));
        com.Parameters.AddWithValue("@Flight_No", Flight_No);
        con.Open();
        DataTable dt = new DataTable();
        SqlDataAdapter sda = new SqlDataAdapter(com);
        sda.Fill(dt);
        con.Close();
        return dt;
    }
    #region UPdate CSR_Detail
    ////public void Update_Approve_CSR(int SalesID, string awbNo)
    ////{
    ////    DateTime FROM_DATE, TO_DATE, date;
    ////    DisplayWrap dpw = new DisplayWrap();


    ////    SqlConnection con_First = new SqlConnection(strCon);
    ////    try
    ////    {

    ////        con_First.Open();


    ////        string SqlQuery = " select distinct AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID, a.CSR_SNo,a.CSR_Date FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Sales_ID='" + SalesID.ToString() + "'";

    ////        com = new SqlCommand(SqlQuery, con_First);
    ////        int COUNT = 1;
    ////        SqlDataReader dr = com.ExecuteReader();
    ////        if (dr.HasRows)
    ////        {

    ////            while (dr.Read())
    ////            {
    ////                date = Convert.ToDateTime(dr["CSR_Date"]);
    ////                if (date.Day <= 15)
    ////                {
    ////                    FROM_DATE = DateTime.ParseExact(date.Month.ToString("MM") + "/01/" + date.Year.ToString(), "MM/dd/yyyy", null);
    ////                    TO_DATE = DateTime.ParseExact(date.Month.ToString("MM") + "/15/" + date.Year.ToString(), "MM/dd/yyyy", null);
    ////                }
    ////                else
    ////                {
    ////                    FROM_DATE = DateTime.ParseExact(date.Month.ToString("MM") + "/16/" + date.Year.ToString(), "MM/dd/yyyy", null);
    ////                    DateTime Date = (Convert.ToDateTime(FROM_DATE.Month.ToString() + "/" + FROM_DATE.Year.ToString())).AddMonths(1).AddDays(-1);
    ////                    string LastDate = Date.Day.ToString();
    ////                    TO_DATE = DateTime.ParseExact(date.Month.ToString("MM") + "/LastDate/" + date.Year.ToString(), "MM/dd/yyyy", null);


    ////                }



    ////                decimal TotComm = 0;
    ////                decimal TotDiscount = 0;
    ////                decimal TotFrAmount = 0;
    ////                decimal TotFrAmountCC = 0;
    ////                decimal EduChrg = 0;
    ////                decimal TotTds = 0;
    ////                decimal Total = 0;
    ////                decimal GrandTotal = 0;
    ////                decimal Freight_Amount = 0;
    ////                decimal Total_DueCarrier = 0;
    ////                decimal TotTax = 0;
    ////                decimal Agent_Expenses = 0;
    ////                decimal Freight_Diff_Amount = 0;
    ////                decimal IATA_Commission = 0;
    ////                decimal Amount_Excluding_TDS = 0;
    ////                decimal LastTdsRate = 0;
    ////                decimal LastSurcharge = 0;
    ////                decimal LastEducation_Cess = 0;
    ////                decimal TDS_Amount = 0;
    ////                decimal surCharge = 0;
    ////                decimal Amount_Including_TDS = 0;

    ////                decimal TotComm_CRDR = 0;
    ////                decimal TotDiscount_CRDR = 0;
    ////                decimal TotFrAmount_CRDR = 0;
    ////                decimal TotFrAmountCC_CRDR = 0;
    ////                decimal EduChrg_CRDR = 0;
    ////                decimal TotTds_CRDR = 0;
    ////                decimal Total_CRDR = 0;
    ////                decimal GrandTotal_CRDR = 0;
    ////                decimal Freight_Amount_CRDR = 0;
    ////                decimal Total_DueCarrier_CRDR = 0;
    ////                decimal TotTax_CRDR = 0;
    ////                decimal Agent_Expenses_CRDR = 0;
    ////                decimal Freight_Diff_Amount_CRDR = 0;
    ////                decimal IATA_Commission_CRDR = 0;
    ////                decimal Amount_Excluding_TDS_CRDR = 0;
    ////                decimal LastTdsRate_CRDR = 0;
    ////                decimal LastSurcharge_CRDR = 0;
    ////                decimal LastEducation_Cess_CRDR = 0;
    ////                decimal TDS_Amount_CRDR = 0;
    ////                decimal surCharge_CRDR = 0;
    ////                decimal Amount_Including_TDS_CRDR = 0;
    ////                int Amount_Type_CRDR;

    ////                string AGENT_ID = dr["AGENT_ID"].ToString();
    ////                string Agent_Name = dr["Agent_name"].ToString();
    ////                string Agent_Code = dr["Agent_Code"].ToString();
    ////                string Agent_Address = dr["Agent_Address"].ToString();
    ////                string CSR_SERIALNo = dr["CSR_SNo"].ToString();
    ////                long CSR_SNo = 0;
    ////                long CSR_SNo_CRDR = 0;
    ////                string period = FROM_DATE.ToString("dd/MM/yyyy") + "-" + TO_DATE.ToString("dd/MM/yyyy");
    ////                string CSR_No = dr["Agent_Code"].ToString() + "-" + awbNo.Substring(0, 3) + "-" + period;
    ////                int Amount_Type;
    ////                string Sales_Type = "";
    ////                string Sales_Type_CRDR = "";
    ////                DateTime CSR_From = FROM_DATE;
    ////                DateTime CSR_To = TO_DATE;
    ////                string Entered_By = Session["EMailID"].ToString();
    ////                DateTime Entered_On = DateTime.Now;
    ////                if (dr["AGENT_ID"].ToString() == "405")
    ////                {

    ////                }
    ////                SqlConnection con1 = new SqlConnection(strCon);
    ////                con1.Open();
    ////                SqlCommand com_csr = new SqlCommand("APPROVE_CSR_DETAILS", con1);
    ////                com_csr.CommandType = CommandType.StoredProcedure;
    ////                com_csr.Parameters.AddWithValue("agent_id", AGENT_ID);
    ////                com_csr.Parameters.AddWithValue("CSR_SNo", CSR_SERIALNo);
    ////                com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
    ////                com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
    ////                com_csr.Parameters.AddWithValue("Airline_Detail_ID", dr["Airline_Detail_ID"].ToString());

    ////                SqlDataReader dr_csr = com_csr.ExecuteReader();
    ////                string VarDate = "07/31/2008";
    ////                string Mh_Priod = "08/15/2008";
    ////                while (dr_csr.Read())
    ////                {
    ////                    if (dr_csr["Sales_Type"].ToString().Trim() == "INV")
    ////                    {
    ////                        Sales_Type = dr_csr["Sales_Type"].ToString().Trim();
    ////                        CSR_SNo = long.Parse(dr_csr["csr_sno"].ToString());
    ////                        Freight_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                        Total_DueCarrier += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
    ////                        TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);

    ////                        Freight_Diff_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                        {
    ////                            if (FROM_DATE > DateTime.Parse(Mh_Priod))
    ////                            {
    ////                                IATA_Commission += 0;
    ////                            }
    ////                            else
    ////                            {
    ////                                IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
    ////                            }
    ////                        }
    ////                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                        {
    ////                            if (FROM_DATE > DateTime.Parse(VarDate))
    ////                            {
    ////                                IATA_Commission += 0;
    ////                            }
    ////                            else
    ////                            {
    ////                                IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
    ////                            }
    ////                        }
    ////                        else
    ////                        {
    ////                            IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
    ////                        }

    ////                        Amount_Excluding_TDS += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

    ////                        if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
    ////                        {

    ////                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                            {

    ////                                if ((FROM_DATE) > DateTime.Parse(VarDate))
    ////                                {
    ////                                    TotTds -= 0;
    ////                                    surCharge -= 0;
    ////                                    EduChrg -= 0;
    ////                                }
    ////                                else
    ////                                {
    ////                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

    ////                                }
    ////                            }
    ////                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                            {

    ////                                if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
    ////                                {
    ////                                    TotTds -= 0;
    ////                                    surCharge -= 0;
    ////                                    EduChrg -= 0;
    ////                                }
    ////                                else
    ////                                {
    ////                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
    ////                                }
    ////                            }
    ////                            else
    ////                            {
    ////                                TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                                surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
    ////                            }

    ////                        }
    ////                        else
    ////                        {
    ////                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                            {

    ////                                if ((FROM_DATE) > DateTime.Parse(VarDate))
    ////                                {
    ////                                    TotTds += 0;
    ////                                    surCharge += 0;
    ////                                    EduChrg += 0;
    ////                                }
    ////                                else
    ////                                {
    ////                                    TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                                    surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
    ////                                }
    ////                            }
    ////                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                            {

    ////                                if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
    ////                                {
    ////                                    TotTds += 0;
    ////                                    surCharge += 0;
    ////                                    EduChrg += 0;
    ////                                }
    ////                                else
    ////                                {
    ////                                    TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                                    surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
    ////                                }
    ////                            }
    ////                            else
    ////                            {
    ////                                TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                                surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
    ////                            }

    ////                        }
    ////                        LastTdsRate = decimal.Parse(dr_csr["tds"].ToString());
    ////                        LastSurcharge = decimal.Parse(dr_csr["surcharge"].ToString());
    ////                        LastEducation_Cess = decimal.Parse(dr_csr["Education_Cess"].ToString());


    ////                        TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);

    ////                        string amountPP = null;
    ////                        string amountCC = null;
    ////                        if (dr_csr["Freight_type"].ToString() == "COLLECT")
    ////                        {
    ////                            amountPP = "0";
    ////                            amountCC = dr_csr["Freight_Amount"].ToString();
    ////                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

    ////                        }
    ////                        else
    ////                        {
    ////                            amountPP = dr_csr["Freight_Amount"].ToString();
    ////                            amountCC = "0";
    ////                            TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
    ////                        }


    ////                        TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
    ////                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                        {

    ////                            if ((FROM_DATE) > DateTime.Parse(VarDate))
    ////                            {
    ////                                TotComm += 0;
    ////                                TotDiscount += 0;
    ////                                Agent_Expenses += 0;
    ////                            }
    ////                            else
    ////                            {
    ////                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
    ////                                Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
    ////                            }
    ////                        }
    ////                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                        {

    ////                            if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
    ////                            {
    ////                                TotComm += 0;
    ////                                TotDiscount += 0;
    ////                                Agent_Expenses += 0;
    ////                            }
    ////                            else
    ////                            {
    ////                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
    ////                                Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
    ////                            }
    ////                        }

    ////                        else
    ////                        {
    ////                            TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                            TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
    ////                            Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
    ////                        }
    ////                    }
    ////                    else if (dr_csr["Sales_Type"].ToString().Trim() == "CRDR")
    ////                    {
    ////                        Sales_Type_CRDR = dr_csr["Sales_Type"].ToString().Trim();
    ////                        CSR_SNo_CRDR = long.Parse(dr_csr["csr_sno"].ToString());
    ////                        Freight_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                        Total_DueCarrier_CRDR += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
    ////                        TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
    ////                        Agent_Expenses_CRDR += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
    ////                        Freight_Diff_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);


    ////                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                        {
    ////                            if (FROM_DATE > DateTime.Parse(Mh_Priod))
    ////                            {

    ////                                IATA_Commission_CRDR += 0;
    ////                            }
    ////                            else
    ////                            {
    ////                                IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
    ////                            }
    ////                        }
    ////                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
    ////                        {
    ////                            if (FROM_DATE > DateTime.Parse(VarDate))
    ////                            {
    ////                                IATA_Commission_CRDR += 0;
    ////                            }
    ////                            else
    ////                            {
    ////                                IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
    ////                            }
    ////                        }
    ////                        else
    ////                        {
    ////                            IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
    ////                        }
    ////                        Amount_Excluding_TDS_CRDR += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

    ////                        if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
    ////                        {

    ////                            TotTds_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                            surCharge_CRDR -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                            EduChrg_CRDR -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
    ////                        }
    ////                        else
    ////                        {
    ////                            TotTds_CRDR += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
    ////                            surCharge_CRDR += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
    ////                            EduChrg_CRDR += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

    ////                        }
    ////                        LastTdsRate_CRDR = decimal.Parse(dr_csr["tds"].ToString());
    ////                        LastSurcharge_CRDR = decimal.Parse(dr_csr["surcharge"].ToString());
    ////                        LastEducation_Cess_CRDR = decimal.Parse(dr_csr["Education_Cess"].ToString());
    ////                        TDS_Amount_CRDR = Math.Round((TotTds_CRDR + surCharge_CRDR + EduChrg_CRDR), MidpointRounding.AwayFromZero);
    ////                        string amountPP_CRDR = null;
    ////                        string amountCC_CRDR = null;
    ////                        if (dr_csr["Freight_type"].ToString() == "COLLECT")
    ////                        {
    ////                            amountPP_CRDR = "0";
    ////                            amountCC_CRDR = dr_csr["Freight_Amount"].ToString();
    ////                            TotFrAmountCC_CRDR += Math.Round(decimal.Parse(amountCC_CRDR), MidpointRounding.AwayFromZero);

    ////                        }
    ////                        else
    ////                        {
    ////                            amountPP_CRDR = dr_csr["Freight_Amount"].ToString();
    ////                            amountCC_CRDR = "0";
    ////                            TotFrAmount_CRDR += Math.Round(decimal.Parse(amountPP_CRDR), MidpointRounding.AwayFromZero);
    ////                        }
    ////                        TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
    ////                        TotComm_CRDR += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                        TotDiscount_CRDR += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
    ////                    }
    ////                }
    ////                Total = Math.Round(((TotFrAmount + Total_DueCarrier + TotTax) - (Agent_Expenses + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
    ////                Decimal Debit_Surcharge = 0;
    ////                DataTable dt_Sur = dpw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + AGENT_ID + " AND AIRLINE_DETAIL_ID=" + dr["Airline_Detail_ID"].ToString() + " AND (CSR_PERIOD>='" + FROM_DATE + "' AND CSR_PERIOD<='" + TO_DATE + "')");
    ////                if (dt_Sur.Rows.Count > 0)
    ////                {
    ////                    Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
    ////                    EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * LastEducation_Cess / 100)), MidpointRounding.AwayFromZero);
    ////                    TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);


    ////                }
    ////                GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
    ////                Amount_Including_TDS = GrandTotal;

    ////                if (Amount_Including_TDS < 0)
    ////                {
    ////                    Amount_Type = 24;
    ////                }
    ////                else
    ////                {
    ////                    Amount_Type = 23;
    ////                }

    ////                /************************/
    ////                Total_CRDR = Math.Round(((TotFrAmount_CRDR + Total_DueCarrier_CRDR + TotTax_CRDR) - (Agent_Expenses_CRDR + TotDiscount_CRDR + TotComm_CRDR)), MidpointRounding.AwayFromZero);


    ////                GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
    ////                Amount_Including_TDS_CRDR = GrandTotal_CRDR;
    ////                if (Amount_Including_TDS_CRDR < 0)
    ////                {
    ////                    Amount_Type_CRDR = 24;
    ////                }
    ////                else
    ////                {
    ////                    Amount_Type_CRDR = 23;
    ////                }
    ////                using (con)
    ////                {
    ////                    con = new SqlConnection(strCon);
    ////                    con.Open();
    ////                    SqlCommand strcom;
    ////                    SqlCommand durationIdcmd = new SqlCommand("SELECT CSR_Duration_ID FROM CSR_Duration WHERE CSR_Duration='" + period + "' ", con);
    ////                    int CSR_Duration_ID = Convert.ToInt32(durationIdcmd.ExecuteScalar());

    ////                    if (GrandTotal != 0)
    ////                    {
    ////                        strcom = new SqlCommand("spGCCS_UpdateCSRDetail", con);
    ////                        strcom.CommandType = CommandType.StoredProcedure;
    ////                        strcom.Parameters.AddWithValue("@COUNT", COUNT);
    ////                        strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
    ////                        strcom.Parameters.AddWithValue("@Airline_Detail_ID", dr["Airline_Detail_ID"].ToString());
    ////                        strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
    ////                        strcom.Parameters.AddWithValue("@Sales_Type", "INV");
    ////                        strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo);
    ////                        strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
    ////                        strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
    ////                        strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
    ////                        strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
    ////                        strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount);
    ////                        strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC);
    ////                        strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount);
    ////                        strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier);
    ////                        strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses);
    ////                        strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount);
    ////                        strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission);
    ////                        strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total);
    ////                        strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate);
    ////                        strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge);
    ////                        strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess);
    ////                        strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount) + Debit_Surcharge));
    ////                        strcom.Parameters.AddWithValue("@Surcharge_Amount", (surCharge + Debit_Surcharge));
    ////                        strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount);
    ////                        strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg);
    ////                        strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS);
    ////                        strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type);
    ////                        strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
    ////                        strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
    ////                        strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
    ////                        strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
    ////                        strcom.ExecuteNonQuery();
    ////                    }
    ////                    /************************************/
    ////                    if (GrandTotal_CRDR != 0)
    ////                    {

    ////                        strcom = new SqlCommand("spGCCS_UpdateCSRDetail", con);
    ////                        strcom.CommandType = CommandType.StoredProcedure;
    ////                        strcom.Parameters.AddWithValue("@COUNT", COUNT);
    ////                        strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
    ////                        strcom.Parameters.AddWithValue("@Airline_Detail_ID", dr["Airline_Detail_ID"].ToString());
    ////                        strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
    ////                        strcom.Parameters.AddWithValue("@Sales_Type", "CRDR");
    ////                        strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo_CRDR);
    ////                        strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
    ////                        strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
    ////                        strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
    ////                        strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
    ////                        strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount_CRDR);
    ////                        strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total_CRDR);
    ////                        strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess_CRDR);
    ////                        strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount_CRDR) + Debit_Surcharge));
    ////                        strcom.Parameters.AddWithValue("@Surcharge_Amount", surCharge_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS_CRDR);
    ////                        strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type_CRDR);
    ////                        strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
    ////                        strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
    ////                        strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
    ////                        strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
    ////                        strcom.ExecuteNonQuery();
    ////                    }
    ////                }
    ////                COUNT++;
    ////                dr_csr.Dispose();
    ////                com_csr.Dispose();
    ////                con1.Close();
    ////            }
    ////            lblmsg.Visible = true;
    ////            lblmsg.Text = "Approved SuccessFully";
    ////            Button1.Visible = false;

    ////        }
    ////        con_First.Close();

    ////    }

    ////    catch (SqlException sqe)
    ////    {
    ////        string err = sqe.ToString();
    ////    }
    ////    finally
    ////    {
    ////        if (con_First != null && con_First.State == ConnectionState.Open)
    ////            con_First.Close();
    ////    }


    ////}
    #endregion 

   
}
