﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class ShowAgentMasterNew : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    SqlConnection con;
    SqlCommand com;
    //    SqlDataReader red;
    DataSet ds;
    SqlDataAdapter adp;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        if (!IsPostBack)
        {
            Search();
        }
    }
    protected void lnk_Click(object sender, EventArgs e)
    {
        Response.Redirect("AgentMasterNew.aspx");
    }

    public void Search()
    {
        //int CitySno = GetcitySno();
        con = new SqlConnection(strCon);
        com = new SqlCommand("ShowAgentGst", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Agent_Name", txtsearch.Text);
        //com.Parameters.AddWithValue("@CitySno", ddlCityCode.SelectedValue);  
        adp = new SqlDataAdapter(com);
        ds = new DataSet();
        adp.Fill(ds);
        grd.DataSource = ds;
        grd.DataBind();
        con.Close();
        com.Dispose();
    }

    ////public void modify(Object sender, CommandEventArgs e)
    ////{
    ////    Response.Redirect("AgentMasterNew.aspx?GstNo=" + e.CommandName + "&action=e");
    ////}


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Search();
    }
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd.PageIndex = e.NewPageIndex;
        Search();
    }
}