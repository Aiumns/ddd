﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace mvcdemo.Models
{
   public class RUser
    {
        [ScaffoldColumn(false)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter name"), MaxLength(30)]        
        [DisplayName("Name")]
        [Display(Name = "User Name")]   
        [DataType(DataType.Text)]
        public string UserName { get; set; }

        [DisplayName("User Role")]
        [DataType(DataType.Text)]
        [Required(ErrorMessage = "Please Select User Payroll")]  
        public UserRoles UserPayroll { get; set; }

        [DisplayName("User Profile")]
        [DataType(DataType.ImageUrl)]
        [Required(ErrorMessage = "Please Upload Profile")]  
        public string UserProfile { get; set; }  //File Upload

        [DisplayName("User Address")]
        [DataType(DataType.Text)]
        [Required(ErrorMessage = "Please Enter Address")]  
        public string Address { get; set; }

        [DisplayName("Phone Number")]
        [DataType(DataType.PhoneNumber)]
        [Required(ErrorMessage = "Please Enter Contact No")]  
        public string ContactNo { get; set; }
        
        [DisplayName("Email Address")]
        [DataType(DataType.EmailAddress)]
        [Required(ErrorMessage = "Please Enter Email ID")]  
        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessage = "Email is not valid.")]  
        public string EmailId { get; set; }
        
        [DisplayName("Date of Birth")]       
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MMM/yyyy}")]  
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; } //DateCalender 

        [DisplayName("Gender")]
        [Display(Name = "User Gender")]          
        public Genders Gender { get; set; } //Radio Button
     
        [DisplayName("User Type")]
        [Display(Name = "User Type")]       
        public UserTypes UserType { get; set; } //Option button                                                 
      
        [DisplayName("Country")]
        [Display(Name = "User Country")]       
        public int CountryId { get; set; }

        [DisplayName("State")]
        [Display(Name = "User State")]     
        public int StateId { get; set; }

        [DisplayName("City")]
        [Display(Name = "User City")]       
        public int CityId { get; set; }

        [DisplayName("Pincode")]
        [Display(Name = "User Pincode")]     
        [DataType(DataType.PostalCode)]
        public string Pincode { get; set; }

        [DisplayName("Status")]
        [Display(Name = "IsActive")]      
        public bool IsActive { get; set; }  

    }
   public enum Genders
    {
       [Display(Name = "Male")]
       Male = 1,
       [Display(Name = "Female")]
       Female = 2,
       [Display(Name = "Other")]
       Other = 3
    }
   public enum UserTypes
    { 
       [Display(Name="Admin")] 
       Admin=1,

       [Display(Name = "Sales")]
       Sales = 1,

       [Display(Name = "HR")]
       HR = 1,
    }
   
   public enum UserRoles
   {
       [Display(Name = "Permanent")]
       Permanent = 1,

       [Display(Name="Contract")] 
       Contract=2
   }


    //public class Country
    //{
    //    public int CountryId { get; set; }
    //    public string CountryName { get; set; }
    //}

    //public class State
    //{
    //    public int StateId { get; set; }
    //    public string StateName { get; set; }
    //}

    //public class City
    //{
    //    public int CityId { get; set; }
    //    public string CityName { get; set; }
    //}
}