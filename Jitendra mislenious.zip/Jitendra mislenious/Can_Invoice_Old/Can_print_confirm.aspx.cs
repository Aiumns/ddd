using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Business;
//Hirdayanand Mishra on Dated 16/07/2009.

public partial class Cargo_Can_print_confirm : BasePage
{
    DisplayWrap dw = new DisplayWrap();
    protected void Page_Load(object sender, EventArgs e)
    {
        HiddenField1.Value = Request.QueryString[0].ToString();
        //HiddenField1.Value = 2;

    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {   string url="";

         DataTable dtOcean = dw.GetAllFromQuery("select * from billing_tran where master_sno in (select sno from billing_master where bill_date>='07/01/2017' and sno=" + HiddenField1.Value + ") and headname like 'Ocean%' and taxable='Y' and tsno is not null");
         if (dtOcean.Rows.Count > 0 && dtOcean != null)
         {
        if (RadioButton1.Checked == true && RadioButton3.Checked == true)

            url = "Can_print_OceanFrt.aspx?SNo=" + HiddenField1.Value + "&type=p&in=n&Email=n";

            if (RadioButton2.Checked == true && RadioButton3.Checked == true)
                url = "Can_print_OceanFrt.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n&Email=n";


        if (RadioButton1.Checked == true && RadioButton4.Checked == true)
            url = "Can_print_OceanFrt.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y&Email=n";


         if (RadioButton2.Checked == true && RadioButton4.Checked == true)

             url = "Can_print_OceanFrt.aspx?SNo=" + HiddenField1.Value + "&type=l&in=y&Email=n";


      


        //if (RadioButton2.Checked == true && RadioButton4.Checked==true )
        //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n";

        //if (RadioButton1.Checked == true && RadioButton3.Checked==true)

        //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y";


       Response.Redirect(url);
        }

        else
        {
             if (RadioButton1.Checked == true && RadioButton3.Checked == true)

                url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=p&in=n&Email=n";

            if (RadioButton2.Checked == true && RadioButton3.Checked == true)
                url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n&Email=n";


        if (RadioButton1.Checked == true && RadioButton4.Checked == true)
            url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y&Email=n";


         if (RadioButton2.Checked == true && RadioButton4.Checked == true)

             url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=y&Email=n";


      


        //if (RadioButton2.Checked == true && RadioButton4.Checked==true )
        //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n";

        //if (RadioButton1.Checked == true && RadioButton3.Checked==true)

        //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y";


       Response.Redirect(url);
      
        }
      
           
    }

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }
    ////public void OnConfirm(object sender, EventArgs e)
    ////{
    ////    string confirmValue = Request.Form["confirm_value"];
    ////    if (confirmValue == "Yes")
    ////    {

    ////        string url = "";
    ////        if (RadioButton1.Checked == true && RadioButton3.Checked == true)

    ////            url = "Can_printWithAttachment.aspx?SNo=" + HiddenField1.Value + "&type=p&in=n&Email=n";

    ////        if (RadioButton2.Checked == true && RadioButton3.Checked == true)
    ////            url = "Can_printWithAttachment.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n&Email=n";


    ////        if (RadioButton1.Checked == true && RadioButton4.Checked == true)
    ////            url = "Can_printWithAttachment.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y&Email=n";


    ////        if (RadioButton2.Checked == true && RadioButton4.Checked == true)

    ////            url = "Can_printWithAttachment.aspx?SNo=" + HiddenField1.Value + "&type=l&in=y&Email=n";
           



    ////        Response.Redirect(url);
    ////    }
    ////    else
    ////    {
    ////        Response.Redirect("BrowseImportInvoice.aspx");
    ////    }
    ////}


    protected void btnNTaxable_Click(object sender, EventArgs e)
    {
        string url = "";
        if (RadioButton1.Checked == true && RadioButton3.Checked == true)

            url = "Can_print_NoNTaxable.aspx?SNo=" + HiddenField1.Value + "&type=p&in=n&Email=n";

        if (RadioButton2.Checked == true && RadioButton3.Checked == true)
            url = "Can_print_NoNTaxable.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n&Email=n";


        if (RadioButton1.Checked == true && RadioButton4.Checked == true)
            url = "Can_print_NoNTaxable.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y&Email=n";


        if (RadioButton2.Checked == true && RadioButton4.Checked == true)

            url = "Can_print_NoNTaxable.aspx?SNo=" + HiddenField1.Value + "&type=l&in=y&Email=n";





        //if (RadioButton2.Checked == true && RadioButton4.Checked==true )
        //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n";

        //if (RadioButton1.Checked == true && RadioButton3.Checked==true)

        //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y";


        Response.Redirect(url);
    }
    protected void btnTaxable_Click(object sender, EventArgs e)
    {
        string url = "";

        DataTable dtOcean = dw.GetAllFromQuery("select * from billing_tran where master_sno in (select sno from billing_master where bill_date>='07/01/2017' and sno=" + HiddenField1.Value + ") and headname like 'Ocean%' and taxable='Y' and tsno is not null");
        if (dtOcean.Rows.Count > 0 && dtOcean != null)
        {
            if (RadioButton1.Checked == true && RadioButton3.Checked == true)

                url = "Can_Print_OceanFrtTaxable.aspx?SNo=" + HiddenField1.Value + "&type=p&in=n&Email=n";

            if (RadioButton2.Checked == true && RadioButton3.Checked == true)
                url = "Can_Print_OceanFrtTaxable.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n&Email=n";


            if (RadioButton1.Checked == true && RadioButton4.Checked == true)
                url = "Can_Print_OceanFrtTaxable.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y&Email=n";


            if (RadioButton2.Checked == true && RadioButton4.Checked == true)

                url = "Can_Print_OceanFrtTaxable.aspx?SNo=" + HiddenField1.Value + "&type=l&in=y&Email=n";





            //if (RadioButton2.Checked == true && RadioButton4.Checked==true )
            //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n";

            //if (RadioButton1.Checked == true && RadioButton3.Checked==true)

            //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y";


            Response.Redirect(url);
        }

        else
        {
            if (RadioButton1.Checked == true && RadioButton3.Checked == true)

                url = "Can_print_Taxable.aspx?SNo=" + HiddenField1.Value + "&type=p&in=n&Email=n";

            if (RadioButton2.Checked == true && RadioButton3.Checked == true)
                url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n&Email=n";


            if (RadioButton1.Checked == true && RadioButton4.Checked == true)
                url = "Can_print_Taxable.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y&Email=n";


            if (RadioButton2.Checked == true && RadioButton4.Checked == true)

                url = "Can_print_Taxable.aspx?SNo=" + HiddenField1.Value + "&type=l&in=y&Email=n";





            //if (RadioButton2.Checked == true && RadioButton4.Checked==true )
            //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=l&in=n";

            //if (RadioButton1.Checked == true && RadioButton3.Checked==true)

            //    url = "Can_print.aspx?SNo=" + HiddenField1.Value + "&type=p&in=y";


            Response.Redirect(url);
        }
    }

}


   

